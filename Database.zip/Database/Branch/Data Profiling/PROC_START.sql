--/* ************************* INPUTS TO ANY FUNCTION ********************************** /
CREATE OR REPLACE  TYPE TYPE_CHKVALS AS  varray(250) OF VARCHAR2(400); 

CREATE OR REPLACE TYPE TYPE_CHECKUNITS AS OBJECT
(
 FILEID VARCHAR2(20),
 DMFILEID VARCHAR2(20),
 LAYOUT_ID VARCHAR2(20),
 SUB_LAYOUT_ID VARCHAR2(20),
 CHK_LEVEL VARCHAR2(20),
 FIELD_NAME VARCHAR2(34),
 FIELD_SN NUMBER,
 CHECK_ID	NUMBER,
 CHKNAME VARCHAR2(100),
 CHKTHRESHOLD NUMBER,
 CHECKVALUETYPE VARCHAR2(20),
 CHECKVALUE VARCHAR2(400),
 CHECKVALUELIST  TYPE_CHKVALS,
 INVALID_DATA_SET TYPE_FUNCTION_RESULTS_SET,
 TOTAL_INVALID_COUNT NUMBER,
 TOTAL_COUNT NUMBER,
 INVALID_PERCENTAGE NUMBER,
 CHECK_REMARKS VARCHAR(100) 
);
/

CREATE TYPE TYPE_DISTINCT_INPUT AS OBJECT (
    CHK_VALUE VARCHAR2(400),
    VAL_COUNT NUMBER
    );
CREATE  TYPE TYPE_DISTINCT_INPUT_SET IS TABLE OF TYPE_DISTINCT_INPUT

--/* ************************* OUTPUT OF ANY FUNCTION ********************************** */
CREATE TYPE TYPE_FUNCTION_RESULTS AS OBJECT (
    INVALID_VALUE VARCHAR2(400),
    INVALID_REASON VARCHAR2(400),
    INVALID_COUNT NUMBER
    );
CREATE  TYPE TYPE_FUNCTION_RESULTS_SET IS TABLE OF TYPE_FUNCTION_RESULTS



--/* ************************* ANANYMOUS BLOCK ********************************** */

DECLARE
    TYPE TYPE_CHECK_UNIT_LIST IS VARRAY(20) OF TYPE_CHECKUNITS;  --CHECK UNITS IS SELF SUFFICIENT OBJECT
    TYPE TYPE_FIELD_CHECK_UNITS IS TABLE OF  TYPE_CHECK_UNIT_LIST INDEX BY VARCHAR2(34);  -- TOTAL CHECKS OF A FIELD
    DISTINCT_INPUT_SET TYPE_DISTINCT_INPUT_SET;     -- INPUT SET OF A FIELD (DISTINCT VALUES AND COUNT)
    TYPE TYPE_FIELD_LIST IS VARRAY(1000) OF VARCHAR2(34);   
    FIELD_LIST TYPE_FIELD_LIST;         -- UNIQUE FIELDS LIST
    TOTAL INTEGER;                 -- JUST FOR LOOPING
    CHECKUNITS   TYPE_CHECKUNITS;
    CHECK_UNIT_LIST TYPE_CHECK_UNIT_LIST;
    FIELD_CHECK_UNITS TYPE_FIELD_CHECK_UNITS;
    TEMP  TYPE_CHECKUNITS;
    DYNAMIC_QUERY CLOB;
    LOG_QUERY CLOB;
    LOG_SEQ NUMBER;
    DETAIL_SEQ NUMBER;
    RESULTS_SET TYPE_FUNCTION_RESULTS_SET;
	  FILE_START_TIME DATE;
  	FILE_END_TIME DATE;
	  CHECK_START_TIME DATE;
	  CHECK_END_TIME DATE;
    CHK_FAILED_FLAG BOOLEAN;
    CHK_STATUS VARCHAR2(100);
    ORA_ERROR_MSG VARCHAR2(400);
    FILE_ERR_FLAG BOOLEAN ;
    FILE_SUCCESS_FLAG BOOLEAN;
    FILE_MSG VARCHAR2(100);
BEGIN
    
  -- PREPARE A LIST OF FIELDS FOR WHICH CHECKS ARE ENABLED
  -- SUPPOSE WE HAVE TWO NOW
  
  FIELD_LIST:=TYPE_FIELD_LIST('luminx_group','END_DATE_THIS_RECD','MIDDLE_INITIAL');
  TOTAL:=  FIELD_LIST.Count;
  --Dbms_Output.put_line('TOTAL Unique Fields is : '||TOTAL);

  -- ************************   BUILDING FIELD CHECK UNITS  ***********************************************************

  -- SUPPOSE FOR FIRST FIELD,WE HAVE TWO CHECKS AND FOR SECOND FIELD, WE HAVE ONLY ONE CHECK
  FOR i IN 1.. TOTAL LOOP
      --BUILD THIS FROM PROCEDURE
       IF i=1 THEN
         BEGIN
          CHECK_UNIT_LIST:= TYPE_CHECK_UNIT_LIST();
          CHECKUNITS:=TYPE_CHECKUNITS('999','A250','147','1','GLOBAL',FIELD_LIST(i),4444,1,'CHKREPEAT',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
          CHECK_UNIT_LIST.extend(1);
          CHECK_UNIT_LIST(1):=CHECKUNITS;
          CHECK_UNIT_LIST.extend(1);
          CHECKUNITS:=TYPE_CHECKUNITS('999','A250','147','1','GLOBAL',FIELD_LIST(i),4444,2,'CHKNULL',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
          CHECK_UNIT_LIST(2):=CHECKUNITS;
          FIELD_CHECK_UNITS(FIELD_LIST(i)):=CHECK_UNIT_LIST;
         END;
       ELSE
         BEGIN
          CHECK_UNIT_LIST:= TYPE_CHECK_UNIT_LIST();
          CHECKUNITS:=TYPE_CHECKUNITS('999','A250','147','1','GLOBAL',FIELD_LIST(i),5555,2,'CHKNULL',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
          CHECK_UNIT_LIST.extend(1);
          CHECK_UNIT_LIST(1):=CHECKUNITS;
          FIELD_CHECK_UNITS(FIELD_LIST(i)):=CHECK_UNIT_LIST;
         END;
       END IF;
  END LOOP;
-- ************************ ****************** ******************* *********************** ************************

-- **************** CONSUMING CHECKS NOW ------------------------------------
 --/*
	FILE_START_TIME:=SYSDATE;
  FILE_ERR_FLAG:=FALSE;
  FILE_SUCCESS_FLAG:=TRUE;
	SELECT  importdb.dp_rpt_main_log_seq.NEXTVAL INTO LOG_SEQ FROM dual;
	
  Log_QUERY:='INSERT INTO IMPORTDB.DP_RPT_MAIN_LOG(log_sn, fileid, 	dmfileid, start_time, current_status) 
											                      VALUES( :a,     :b,        :c,      :d,           :e )';
  BEGIN EXECUTE IMMEDIATE Log_QUERY USING LOG_SEQ,'12345','A250',FILE_START_TIME,'RUNNING'; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(SQLERRM,1,400));END;											
  BEGIN
    FOR i IN 1.. TOTAL LOOP
      DYNAMIC_QUERY:=' SELECT TYPE_DISTINCT_INPUT('||FIELD_LIST(i)||',CNT)  FROM
        (
          SELECT '||FIELD_LIST(i)||',Count(*) AS CNT  FROM profiling_test_table  GROUP BY '||FIELD_LIST(i)|| 
        ')';
      EXECUTE IMMEDIATE DYNAMIC_QUERY BULK COLLECT INTO DISTINCT_INPUT_SET;
      CHECK_UNIT_LIST:=FIELD_CHECK_UNITS(FIELD_LIST(i));

      FOR j IN 1..CHECK_UNIT_LIST.Count LOOP
    
        SELECT  importdb.dp_rpt_detail_log_seq.NEXTVAL INTO DETAIL_SEQ FROM dual; -- FOR TESTING ONLY
	      CHECK_START_TIME:=SYSDATE;
          --INSERT INTO CHECK DETAIL LOG
	      Log_QUERY:='INSERT INTO IMPORTDB.DP_RPT_DETAIL_LOG(	det_sn, 	mas_id,log_sn,field_name, field_sn, check_name, check_status, start_time) VALUES 
														                              (  :a ,       :b,     :c,   :d,           :e,       :f,         :g,           :h)';
        BEGIN EXECUTE IMMEDIATE Log_QUERY USING DETAIL_SEQ,CHECK_UNIT_LIST(j).CHECK_ID,LOG_SEQ,CHECK_UNIT_LIST(j).FIELD_NAME,CHECK_UNIT_LIST(j).FIELD_SN,CHECK_UNIT_LIST(j).CHKNAME,'RUNNING',CHECK_START_TIME; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(SQLERRM,1,400));END;
          BEGIN
            CHK_FAILED_FLAG:=FALSE;
            CASE CHECK_UNIT_LIST(j).CHKNAME
              WHEN 'CHKREPEAT' THEN 
                BEGIN
                Dbms_Output.put_line('-------------------------------------------------------------------');
                Dbms_Output.put_line('CHK REPEAT STARTED AT '|| To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                TEMP:=CHKALNUMREPEEAT(DISTINCT_INPUT_SET,CHECK_UNIT_LIST(j));
                Dbms_Output.put_line('CHK REPEAT ENDED AT '|| To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                Dbms_Output.put_line('-------------------------------------------------------------------');
                END;
              WHEN 'CHKNULL' THEN 
                BEGIN
                Dbms_Output.put_line('-------------------------------------------------------------------');
                Dbms_Output.put_line('CHK NULL STARTED AT '||To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                TEMP:=CHKNULL(DISTINCT_INPUT_SET,CHECK_UNIT_LIST(j));

                Dbms_Output.put_line(TEMP.TOTAL_COUNT);
                Dbms_Output.put_line('CHK NULL ENDED AT '|| To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                Dbms_Output.put_line('-------------------------------------------------------------------');
                END;
              ELSE  Dbms_Output.put_line('CHECK FUNCTION NOT FOUND');
            END CASE;
            FILE_SUCCESS_FLAG:= FILE_SUCCESS_FLAG AND (TEMP.CHECK_REMARKS='PASSED');
          EXCEPTION
            WHEN OTHERS THEN BEGIN  CHK_FAILED_FLAG:=TRUE; ORA_ERROR_MSG:=SubStr(SQLERRM,1,400); END;
          END;
          CHECK_END_TIME:=SYSDATE;
     
        --
        --KEEP CHECK DETAIL LOG END TIME
    
    
        -- INSERT INVALID DETAILS
		    BEGIN
          IF TEMP.INVALID_DATA_SET IS NOT NULL THEN 
            RESULTS_SET:= TEMP.INVALID_DATA_SET;
		
            FORALL z IN RESULTS_SET.FIRST .. RESULTS_SET.LAST
              INSERT INTO IMPORTDB.dp_rpt_results VALUES (DETAIL_SEQ,RESULTS_SET(z).INVALID_VALUE,RESULTS_SET(z).INVALID_REASON,RESULTS_SET(z).INVALID_COUNT);
          END IF;
	      EXCEPTION
		      WHEN OTHERS THEN 
			    BEGIN
				    Dbms_Output.put_line(SubStr(SQLERRM,1,400));
			    END;
	      END;

        IF (NOT CHK_FAILED_FLAG) THEN
            CHK_STATUS:='COMPLETED SUCCESSFULLY';
            Log_QUERY:='UPDATE IMPORTDB.DP_RPT_DETAIL_LOG SET check_status=:a, end_time=:b,invalid_percentage=:c, CHK_REMARKS=:d WHERE det_sn=:e';
            BEGIN EXECUTE IMMEDIATE Log_QUERY USING CHK_STATUS,CHECK_END_TIME,To_Char(TEMP.INVALID_PERCENTAGE,'90.90'),TEMP.CHECK_REMARKS,DETAIL_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;
        ELSE
            CHK_STATUS:='EXCEPTION';
            Log_QUERY:='UPDATE IMPORTDB.DP_RPT_DETAIL_LOG SET check_status=:a, end_time=:b,oracle_error_message=:c WHERE det_sn=:c';
            BEGIN EXECUTE IMMEDIATE Log_QUERY USING CHK_STATUS,CHECK_END_TIME,ORA_ERROR_MSG,DETAIL_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;

        END IF;


      END LOOP;


    END LOOP;
    FILE_END_TIME:= SYSDATE;
  EXCEPTION
    WHEN OTHERS THEN 
      BEGIN
      FILE_END_TIME:= SYSDATE;
      ORA_ERROR_MSG:=SubStr(SQLERRM,1,400);
      FILE_ERR_FLAG:=TRUE;
      END;
  END;

  IF (NOT FILE_ERR_FLAG) THEN
    FILE_MSG:='FILE CHECKS FAILED';
    IF FILE_SUCCESS_FLAG THEN
      FILE_MSG:='ALL CHECKS PASSED';
    END IF;
    Log_QUERY:='UPDATE IMPORTDB.DP_RPT_MAIN_LOG SET current_status=''COMPLETED SUCCESSFULLY'', end_time=:a,overall_profiling_status=:b  WHERE log_sn=:c';
    BEGIN EXECUTE IMMEDIATE Log_QUERY USING FILE_END_TIME,FILE_MSG,LOG_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;
  ELSE
    Log_QUERY:='UPDATE IMPORTDB.DP_RPT_MAIN_LOG SET current_status=''EXCEPTION'', end_time=:a,oracle_error_message=:b WHERE det_sn=:c';
    BEGIN EXECUTE IMMEDIATE Log_QUERY USING FILE_END_TIME,ORA_ERROR_MSG,LOG_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;

  END IF;
    
EXCEPTION
  WHEN OTHERS THEN
  Dbms_Output.put_line(Dbms_Utility.FORMAT_ERROR_BACKTRACE);

--------- ****************************** ---------------------------------

END;

--   ROLLBACK
--   SELECT * FROM               IMPORTDB.dp_rpt_results
--   SELECT * FROM               IMPORTDB.Dp_rpt_main_log
--   SELECT * FROM               IMPORTDB.dp_rpt_detail_log

       
                                      


         
                                      
