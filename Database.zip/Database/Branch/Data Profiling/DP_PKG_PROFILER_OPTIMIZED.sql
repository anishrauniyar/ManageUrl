CREATE OR REPLACE PACKAGE DP_PKG_PROFILER 
AUTHID CURRENT_USER
IS
PROCEDURE RUNPROFILER(FILEID IN VARCHAR2);
PROCEDURE BUILDCHECKMATRIX(FILEID IN VARCHAR2);
PROCEDURE RUNCHECKS;
END  DP_PKG_PROFILER;
/

GRANT EXECUTE ON DP_PKG_PROFILER TO PUBLIC;


CREATE OR REPLACE PACKAGE BODY DP_PKG_PROFILER IS
	TYPE TYPE_CHECK_UNIT_LIST IS VARRAY(20) OF TYPE_CHECKUNITS;  --CHECK UNITS IS SELF SUFFICIENT OBJECT
    TYPE TYPE_FIELD_CHECK_UNITS IS TABLE OF  TYPE_CHECK_UNIT_LIST INDEX BY VARCHAR2(34);  -- TOTAL CHECKS OF A FIELD
    DISTINCT_INPUT_SET TYPE_DISTINCT_INPUT_SET;     -- INPUT SET OF A FIELD (DISTINCT VALUES AND COUNT)
    TYPE TYPE_FIELD_LIST IS VARRAY(1000) OF VARCHAR2(34);   
    FIELD_LIST TYPE_FIELD_LIST;         -- UNIQUE FIELDS LIST
    TOTAL INTEGER;                 -- JUST FOR LOOPING
    CHECKUNITS   TYPE_CHECKUNITS;
    CHECK_UNIT_LIST TYPE_CHECK_UNIT_LIST;
    FIELD_CHECK_UNITS TYPE_FIELD_CHECK_UNITS;
	--
   

PROCEDURE RUNPROFILER(FILEID IN VARCHAR2) IS
BEGIN
	dbms_output.put_line('Profiling For File '|| FILEID || ' Started');
	BUILDCHECKMATRIX(FILEID);
	RUNCHECKS();
END RUNPROFILER;	

PROCEDURE BUILDCHECKMATRIX(FILEID IN VARCHAR2) IS
BEGIN
  FIELD_LIST:=TYPE_FIELD_LIST('luminx_group','END_DATE_THIS_RECD','MIDDLE_INITIAL');
  TOTAL:=  FIELD_LIST.Count;
  --Dbms_Output.put_line('TOTAL Unique Fields is : '||TOTAL);

  -- ************************   BUILDING FIELD CHECK UNITS  ***********************************************************

  -- SUPPOSE FOR FIRST FIELD,WE HAVE TWO CHECKS AND FOR SECOND FIELD, WE HAVE ONLY ONE CHECK
  FOR i IN 1.. TOTAL LOOP
      --BUILD THIS FROM PROCEDURE
       IF i=1 THEN
         BEGIN
          CHECK_UNIT_LIST:= TYPE_CHECK_UNIT_LIST();
          CHECKUNITS:=TYPE_CHECKUNITS('999','A250','147','1','GLOBAL',FIELD_LIST(i),4444,1,'CHKREPEAT',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
          CHECK_UNIT_LIST.extend(1);
          CHECK_UNIT_LIST(1):=CHECKUNITS;
          CHECK_UNIT_LIST.extend(1);
          CHECKUNITS:=TYPE_CHECKUNITS('999','A250','147','1','GLOBAL',FIELD_LIST(i),4444,2,'CHKNULL',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
          CHECK_UNIT_LIST(2):=CHECKUNITS;
          FIELD_CHECK_UNITS(FIELD_LIST(i)):=CHECK_UNIT_LIST;
         END;
       ELSE
         BEGIN
          CHECK_UNIT_LIST:= TYPE_CHECK_UNIT_LIST();
          CHECKUNITS:=TYPE_CHECKUNITS('999','A250','147','1','GLOBAL',FIELD_LIST(i),5555,2,'CHKNULL',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
          CHECK_UNIT_LIST.extend(1);
          CHECK_UNIT_LIST(1):=CHECKUNITS;
          FIELD_CHECK_UNITS(FIELD_LIST(i)):=CHECK_UNIT_LIST;
         END;
       END IF;
  END LOOP;
END BUILDCHECKMATRIX;


PROCEDURE RUNCHECKS IS

    DYNAMIC_QUERY CLOB;
    LOG_QUERY CLOB;
    LOG_SEQ NUMBER;
    DETAIL_SEQ NUMBER;
    RESULTS_SET TYPE_FUNCTION_RESULTS_SET;
	FILE_START_TIME DATE;
  	FILE_END_TIME DATE;
	CHECK_START_TIME DATE;
	CHECK_END_TIME DATE;
    CHK_FAILED_FLAG BOOLEAN;
    CHK_STATUS VARCHAR2(100);
    ORA_ERROR_MSG VARCHAR2(400);
    FILE_ERR_FLAG BOOLEAN ;
    FILE_SUCCESS_FLAG BOOLEAN;
    FILE_MSG VARCHAR2(100);
BEGIN
  FILE_START_TIME:=SYSDATE;
  FILE_ERR_FLAG:=FALSE;
  FILE_SUCCESS_FLAG:=TRUE;
	SELECT  importdb.dp_rpt_main_log_seq.NEXTVAL INTO LOG_SEQ FROM dual;
	
  Log_QUERY:='INSERT INTO IMPORTDB.DP_RPT_MAIN_LOG(log_sn, fileid, 	dmfileid, start_time, current_status) 
											                      VALUES( :a,     :b,        :c,      :d,           :e )';
  BEGIN EXECUTE IMMEDIATE Log_QUERY USING LOG_SEQ,'12345','A250',FILE_START_TIME,'RUNNING'; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(SQLERRM,1,400));END;											
  BEGIN
    FOR i IN 1.. TOTAL LOOP
      DYNAMIC_QUERY:=' SELECT TYPE_DISTINCT_INPUT('||FIELD_LIST(i)||',CNT)  FROM
        (
          SELECT '||FIELD_LIST(i)||',Count(*) AS CNT  FROM profiling_test_table  GROUP BY '||FIELD_LIST(i)|| 
        ')';
      EXECUTE IMMEDIATE DYNAMIC_QUERY BULK COLLECT INTO DISTINCT_INPUT_SET;
      CHECK_UNIT_LIST:=FIELD_CHECK_UNITS(FIELD_LIST(i));

      FOR j IN 1..CHECK_UNIT_LIST.Count LOOP
    
        SELECT  importdb.dp_rpt_detail_log_seq.NEXTVAL INTO DETAIL_SEQ FROM dual; -- FOR TESTING ONLY
	      CHECK_START_TIME:=SYSDATE;
          --INSERT INTO CHECK DETAIL LOG
	      Log_QUERY:='INSERT INTO IMPORTDB.DP_RPT_DETAIL_LOG(	det_sn, 	mas_id,log_sn,field_name, field_sn, check_name, check_status, start_time) VALUES 
														                              (  :a ,       :b,     :c,   :d,           :e,       :f,         :g,           :h)';
        BEGIN EXECUTE IMMEDIATE Log_QUERY USING DETAIL_SEQ,CHECK_UNIT_LIST(j).CHECK_ID,LOG_SEQ,CHECK_UNIT_LIST(j).FIELD_NAME,CHECK_UNIT_LIST(j).FIELD_SN,CHECK_UNIT_LIST(j).CHKNAME,'RUNNING',CHECK_START_TIME; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(SQLERRM,1,400));END;
          BEGIN
            CHK_FAILED_FLAG:=FALSE;
            CASE CHECK_UNIT_LIST(j).CHKNAME
              WHEN 'CHKREPEAT' THEN 
                BEGIN
                Dbms_Output.put_line('-------------------------------------------------------------------');
                Dbms_Output.put_line('CHK REPEAT STARTED AT '|| To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                DP_PKG_FUNCTIONS.CHKALNUMREPEEAT(DISTINCT_INPUT_SET,CHECK_UNIT_LIST(j));
                Dbms_Output.put_line('CHK REPEAT ENDED AT '|| To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                Dbms_Output.put_line('-------------------------------------------------------------------');
                END;
              WHEN 'CHKNULL' THEN 
                BEGIN
                Dbms_Output.put_line('-------------------------------------------------------------------');
                Dbms_Output.put_line('CHK NULL STARTED AT '||To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                DP_PKG_FUNCTIONS.CHKNULL(DISTINCT_INPUT_SET,CHECK_UNIT_LIST(j));

                Dbms_Output.put_line(CHECK_UNIT_LIST(j).TOTAL_COUNT);
                Dbms_Output.put_line('CHK NULL ENDED AT '|| To_Char(SYSDATE,'YYYYMMDD HH24:MI:SS'));
                Dbms_Output.put_line('-------------------------------------------------------------------');
                END;
              ELSE  Dbms_Output.put_line('CHECK FUNCTION NOT FOUND');
            END CASE;
            FILE_SUCCESS_FLAG:= FILE_SUCCESS_FLAG AND (CHECK_UNIT_LIST(j).CHECK_REMARKS='CHECK PASSED');
          EXCEPTION
            WHEN OTHERS THEN BEGIN  CHK_FAILED_FLAG:=TRUE; ORA_ERROR_MSG:=SubStr(SQLERRM,1,400); END;
          END;
          CHECK_END_TIME:=SYSDATE;
     
        --
        --KEEP CHECK DETAIL LOG END TIME
    
    
        -- INSERT INVALID DETAILS
		    BEGIN
          IF CHECK_UNIT_LIST(j).INVALID_DATA_SET IS NOT NULL THEN 
            RESULTS_SET:= CHECK_UNIT_LIST(j).INVALID_DATA_SET;
		
            FORALL z IN RESULTS_SET.FIRST .. RESULTS_SET.LAST
              INSERT INTO IMPORTDB.dp_rpt_results VALUES (DETAIL_SEQ,RESULTS_SET(z).INVALID_VALUE,RESULTS_SET(z).INVALID_REASON,RESULTS_SET(z).INVALID_COUNT);
          END IF;
	      EXCEPTION
		      WHEN OTHERS THEN 
			    BEGIN
				    Dbms_Output.put_line(SubStr(SQLERRM,1,400));
			    END;
	      END;

        IF (NOT CHK_FAILED_FLAG) THEN
            CHK_STATUS:='COMPLETED SUCCESSFULLY';
            Log_QUERY:='UPDATE IMPORTDB.DP_RPT_DETAIL_LOG SET check_status=:a, end_time=:b,invalid_percentage=:c, CHK_REMARKS=:d WHERE det_sn=:e';
            BEGIN EXECUTE IMMEDIATE Log_QUERY USING CHK_STATUS,CHECK_END_TIME,To_Char(CHECK_UNIT_LIST(j).INVALID_PERCENTAGE,'90.90'),CHECK_UNIT_LIST(j).CHECK_REMARKS,DETAIL_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;
        ELSE
            CHK_STATUS:='EXCEPTION';
            Log_QUERY:='UPDATE IMPORTDB.DP_RPT_DETAIL_LOG SET check_status=:a, end_time=:b,oracle_error_message=:c WHERE det_sn=:c';
            BEGIN EXECUTE IMMEDIATE Log_QUERY USING CHK_STATUS,CHECK_END_TIME,ORA_ERROR_MSG,DETAIL_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;

        END IF;


      END LOOP;


    END LOOP;
    FILE_END_TIME:= SYSDATE;
  EXCEPTION
    WHEN OTHERS THEN 
      BEGIN
      FILE_END_TIME:= SYSDATE;
      ORA_ERROR_MSG:=SubStr(SQLERRM,1,400);
      FILE_ERR_FLAG:=TRUE;
      END;
  END;

  IF (NOT FILE_ERR_FLAG) THEN
    FILE_MSG:='FILE CHECKS FAILED';
    IF FILE_SUCCESS_FLAG THEN
      FILE_MSG:='ALL CHECKS PASSED';
    END IF;
    Log_QUERY:='UPDATE IMPORTDB.DP_RPT_MAIN_LOG SET current_status=''COMPLETED SUCCESSFULLY'', end_time=:a,overall_profiling_status=:b  WHERE log_sn=:c';
    BEGIN EXECUTE IMMEDIATE Log_QUERY USING FILE_END_TIME,FILE_MSG,LOG_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;
  ELSE
    Log_QUERY:='UPDATE IMPORTDB.DP_RPT_MAIN_LOG SET current_status=''EXCEPTION'', end_time=:a,oracle_error_message=:b WHERE det_sn=:c';
    BEGIN EXECUTE IMMEDIATE Log_QUERY USING FILE_END_TIME,ORA_ERROR_MSG,LOG_SEQ; EXCEPTION WHEN OTHERS THEN dbms_output.put_line(substr(Log_QUERY,1,400));END;

  END IF;
    
EXCEPTION
  WHEN OTHERS THEN
  Dbms_Output.put_line(Dbms_Utility.FORMAT_ERROR_BACKTRACE);

--------- ****************************** ---------------------------------

END RUNCHECKS;
END DP_PKG_PROFILER;
/*

BEGIN
   DP_PKG_PROFILER.RUNPROFILER('12345');
END;


*/	