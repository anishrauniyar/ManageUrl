PROMPT CREATE OR REPLACE FUNCTION vh_to_number
CREATE OR REPLACE FUNCTION vh_to_number (NUMBER_STRING IN VARCHAR2)
             RETURN NUMBER
AS
     CHECK_NUMBER NUMBER;
     CLEANME VARCHAR2(2000);
BEGIN
    CLEANME := NUMBER_STRING;
    IF (SUBSTR(NUMBER_STRING, -1 ) = '-' ) THEN CLEANME := '-'||REGEXP_REPLACE (NUMBER_STRING,'-$'); ELSIF ((SUBSTR(NUMBER_STRING, -1 ) = '+') AND (SUBSTR(NUMBER_STRING, 1,1 )!='-' )) THEN CLEANME := REGEXP_REPLACE (NUMBER_STRING,'\+$','');  END IF;
    IF (SUBSTR(NUMBER_STRING, 1,1 ) = '(' ) AND (SUBSTR(NUMBER_STRING, -1 ) = ')' )   THEN CLEANME := '-'||SUBSTR (NUMBER_STRING,2,length(NUMBER_STRING)-2); END IF;

    CHECK_NUMBER := REGEXP_REPLACE(NVL(CLEANME,'NULL'),'[,$]','') ;
       RETURN CHECK_NUMBER;
  EXCEPTION WHEN OTHERS THEN
        RETURN 0;
END;
/

GRANT EXECUTE ON vh_to_number TO public;
---------------------------------------------------------------------------------------------------------------------------------------------------


PROMPT CREATE OR REPLACE FUNCTION DP_CHECK_REPETITION
CREATE OR REPLACE FUNCTION DP_CHECK_REPETITION (P_STRING IN VARCHAR2)
             RETURN NUMBER
AS
     RETURN_NUMBER NUMBER;
     REPEAT_CHARACTER VARCHAR2(2000);
     QUERY_RESULT VARCHAR2(2);
BEGIN
  REPEAT_CHARACTER:=SubStr(P_STRING,1,1);
  IF P_STRING IS NOT NULL THEN
    BEGIN 
      SELECT 1  INTO QUERY_RESULT FROM DUAL WHERE REGEXP_LIKE(P_STRING,'^'||REPEAT_CHARACTER||'+$') ;
      IF QUERY_RESULT = 1 THEN
         RETURN_NUMBER :=1;
      END IF;
    END;
    
  ELSE 
    RETURN_NUMBER:= 0;
  END IF; 
  RETURN  RETURN_NUMBER;
EXCEPTION 
WHEN OTHERS THEN 
RETURN 0;   
END;
/

GRANT EXECUTE ON DP_CHECK_REPETITION TO public;
---------------------------------------------------------------------------------------------------------------------------------------------------
