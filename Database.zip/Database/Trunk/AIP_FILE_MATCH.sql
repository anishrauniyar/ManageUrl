--STEP 1: Load the java class Match.class in utility schema
--STEP 2: Create function to call this loaded java object
--STEP 3: Create Synonyms and give necessary permissions
--If class file is not available(step 1 ), compile the java source with jdk 1.6(not above)

 -- LOAD JAVA OBJECT(FROM PUTTY) AS
/*
  loadjava -u utility/password -verbose -resolve Match.class
 */

 -- OR  AS 
 -- loadjava -u importdb/password -verbose -resolve JavaPattern.jar      //(To load the jar file)


--TO DROP THE JAVA
	-- dropjava -user importdb/oracle -verbose Match 

 --VERIFY THE JAVA OBJECT--------------------------------------------
--  SELECT * FROM user_objects WHERE OBJECT_TYPE LIKE '%JAVA%';
-------------------------------------------------------------------

------------------------CREATE A BINDING FUNCTION-----------------------------

CREATE FUNCTION aip_file_match (String VARCHAR2, pattern VARCHAR2) RETURN NUMBER
AS
LANGUAGE JAVA NAME 'Match.checkPattern(java.lang.String, java.lang.String) return int';

-------------------------------------------------------------------------------------------------------

-----------------------CREATE SYNONYM---------------------------------------------------

  CREATE PUBLIC SYNONYM  aip_file_match FOR utility.aip_file_match
   GRANT EXECUTE ON utility.aip_file_match TO public;
  COMMIT;

-------------------------------------------------------------------------------------


--USAGE-----------------------------------------------------------------------
SELECT 1 FROM dual WHERE  aip_file_match('String_To_Check','Pattern')=1
-----------------------------------------------------------------------------------



