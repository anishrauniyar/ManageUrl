PROMPT CREATE OR REPLACE VIEW aip_dashboard_ctl
CREATE OR REPLACE VIEW aip_dashboard_ctl (
  controltype,
  fileid,
  filename,
  receivedmonth,
  category,
  shortpayor,
  payername,
  vh_billed_amt,
  vh_allowed_amt,
  vh_paid_amt,
  vh_employee_amt,
  vh_employee_cnt,
  vh_member_cnt,
  vh_record_cnt,
  v_billed_amt,
  v_allowed_amt,
  v_paid_amt,
  v_employee_amt,
  v_employee_cnt,
  v_member_cnt,
  v_record_cnt,
  var_billed_amount,
  var_allowed_amount,
  var_paid_amount,
  var_emp_amount,
  var_emp_count,
  var_mem_count,
  var_rec_count,
  clientid,
  ctlfileid,
  ctldmfileid,
  ctlfilename,
  datalayoutid,
  ctllayout,
  datafiledate,
  ctlfiledate,
  ctl_status,
  aip_file_id,
  dmfileid
) AS
SELECT
controltype,
a.fileid||'_'||a.dmfileid AS fileid,
a.filename,
To_Char(To_Date(a.file_date,'YYYY-MM-DD HH24:mi:ss'),'YYYYMM') ReceivedMonth    ,
a.DATATYPE AS category,
c.shortpayor ,
c.payor as payername,
b.billedamount AS vh_billed_amt,
b.allowedamount AS vh_allowed_amt,
b.paidamount AS vh_paid_amt,
b.employeepaid AS vh_employee_amt,
b.empcount AS vh_employee_cnt,
b.memcount AS vh_member_cnt,
IMPORT_RECORD_CNT AS vh_record_cnt ,
a.billed_amt AS v_billed_amt,
a.allowed_amt AS v_allowed_amt,
a.paid_amt AS v_paid_amt,
a.employee_amt AS  ,
a.employee_cnt AS v_employee_cnt ,
a.member_cnt AS v_member_cnt,
a.record_cnt AS v_record_cnt,
(NVL(b.billedamount,0)-NVL(a.billed_amt,0)) AS var_billed_amount ,
(NVL(b.allowedamount,0)-NVL(a.allowed_amt,0)) AS var_allowed_amount,
(NVL(b.paidamount,0)-NVL(a.paid_amt,0)) AS var_paid_amount ,
(NVL(b.employeepaid,0)-NVL(a.employee_amt,0)) AS var_emp_amount ,
(NVL(b.empcount,0)-NVL(a.employee_cnt,0)) AS var_emp_count,
(NVL(b.memcount,0)-NVL(a.member_cnt,0)) AS var_mem_count,
Nvl(IMPORT_RECORD_CNT,0)-NVL(a.record_cnt,0) AS var_rec_count,
a.clientid ,
a.ctlfileid ctlfileid,
a.ctldmfileid ctldmfileid,
a.ctlfilename   ,
a.datalayoutid ,
a.ctllayout ,
a.datafiledate,
a.ctlfiledate ,
a.ctl_status,
a.fileid AS aip_file_id,
a.dmfileid
FROM   (  -- Get all data files having control line
          SELECT 'INLINE CONTROL TOTAL' AS controltype,a.*,
          Nvl(trim(ctlfilename),DATAFILENAME) AS ctlfilename, unknfilename, datafilename, importeddate, category, empname, payor, payornname, fromdate, todate, billed_amt, allowed_amt,
          paid_amt, employee_amt, employee_cnt, member_cnt, record_cnt , a.layoutid AS datalayoutid ,NULL AS ctllayout  , a.file_date AS datafiledate , 'NA' AS ctlfiledate , ctl_status,
          'NA' ctlfileid,
          'NA' ctldmfileid
          FROM imp_main_log a
          JOIN imp_vh_control_total d
          ON a.fileid=d.fileid   AND a.EXCEPTIONFLAG is NULL   AND a.STATUS_OF_IMPORT='SUCCESS'
          UNION ALL
          -- get all files which has separate ctl file but sourcefilename is coming in ctl file
          SELECT 'FILE CONTROL TOTAL - Match with embedded Data File Name' AS controltype,a.* ,
          Trim(ctlfilename) AS ctlfilename, unknfilename, datafilename, importeddate, category, empname, payor, payornname, fromdate, todate, billed_amt, allowed_amt,
          paid_amt, employee_amt, employee_cnt, member_cnt, record_cnt , a.layoutid AS datalayoutid,d.ctllayout  , a.file_date AS datafiledate , d.file_date AS ctlfiledate, d.ctl_status,
          d.fileid AS ctlfileid,
          d.dmfileid AS  ctldmfileid
          FROM imp_main_log a
          JOIN (SELECT d.*, i.file_date , i.layoutid AS ctllayout,i.dmfileid FROM imp_vh_control_total d JOIN imp_main_log i ON d.fileid=i.fileid
                 AND i.processstatus='CONTROL' AND layoutid!=1) d
          ON a.filename=d.datafilename  and a.clientid=d.clientid AND
          To_Char(To_Date(a.file_date,'yyyy-mm-dd hh24:mi:ss'),'YYYYMM')=To_Char(To_Date(d.file_date,'yyyy-mm-dd hh24:mi:ss'),'YYYYMM')
          where a.EXCEPTIONFLAG is NULL AND a.STATUS_OF_IMPORT='SUCCESS'
          and  NOT EXISTS  (SELECT 1 FROM imp_vh_control_total c WHERE a.fileid=c.fileid)
         -- get all data files for which separate control file is coming , match based on  rule
          UNION ALL
          SELECT DISTINCT 'FILE CONTROL TOTAL - Match with CTL Pattern' AS controltype,a.*,
          Trim(ctlfilename) AS ctlfilename, unknfilename, datafilename, importeddate, category, empname, payor, payornname,
          fromdate, todate, billed_amt, allowed_amt,
          paid_amt, employee_amt, employee_cnt, member_cnt, record_cnt   , a.layoutid AS datalayoutid ,ctllayout
          , a.file_date AS datafiledate ,d.file_date AS ctlfiledate, d.ctl_status  ,
          d.fileid as ctlfileid,
          d.dmfileid as ctldmfileid
          FROM imp_main_log a
          JOIN (SELECT REGEXP_REPLACE(trim(d.ctlfilename),ctl_first_string,ctl_second_string,1,1,'i') AS derived_datafile ,    -- test
                d.*, i.file_date,SN,    PATTERN,  CTL_MATCH_RULE ,i.layoutid AS ctllayout,i.dmfileid
          FROM imp_vh_control_total d
                            JOIN imp_main_log i
                          ON d.fileid=i.fileid AND d.clientid=i.clientid AND i.processstatus='CONTROL'   AND i.layoutid!=1
                            JOIN imp_clientpatterns p
                          ON i.clientid=p.clientid AND (aip_file_match(i.filename,p.pattern)=1 OR aip_file_match(i.filename,p.ctl_pattern)=1 )
                ) d
          ON Upper(derived_datafile) =Upper(a.filename)
          and a.clientid=d.clientid
          AND To_Char(To_Date(a.file_date,'yyyy-mm-dd hh24:mi:ss'),'YYYYMM')=To_Char(To_Date(d.file_date,'yyyy-mm-dd hh24:mi:ss'),'YYYYMM')
          WHERE    a.EXCEPTIONFLAG is NULL   AND a.STATUS_OF_IMPORT='SUCCESS'
          and  NOT EXISTS  (SELECT 1 FROM imp_vh_control_total c WHERE a.fileid=c.fileid)   -- and  a.clientid='759'
         ) a
left JOIN rpt_main_log    c
ON a.fileid||'_'||a.dmfileid = c.fileid
AND  REPORTTYPE='DSR'  AND sublayoutid=1
left join rpt_dsr b
ON c.sn=b.sn 	AND  FLAG ='Source File'
JOIN imp_layouts c
ON a.layoutid=c.layoutid
/


PROMPT CREATE OR REPLACE VIEW aip_dashboard_exception
CREATE OR REPLACE VIEW aip_dashboard_exception (
  fileid,
  dmfileid,
  filename,
  file_date,
  oldlayoutid,
  newlayoutid,
  status_of_import,
  processstatus,
  newdatatype,
  empgrp,
  skiprows,
  delimiter,
  processfilepath,
  importserver,
  ignoreexception,
  payor,
  clientid,
  original_filename,
  colorflag,
  pattern_sn,
  overriddendate,
  releaseno,
  defaultpatternsn
) AS
SELECT
fileid,
dmfileid,
filename,
b.file_date,
b.layoutid  AS oldlayoutid,
nvl(a.layoutid,'0') AS newlayoutid ,
CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN Nvl(Trim(STATUS_OF_IMPORT),info13) ELSE NULL END AS STATUS_OF_IMPORT,
CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN PROCESSSTATUS ELSE NULL END AS PROCESSSTATUS   ,
UPPER(a.DATATYPE)   AS newdatatype,
a.EMPLOYERGROUP  AS empgrp ,
a.skiprow  SKIPROWS,
a.LAYOUTTYPEID  AS  DELIMITER,
processfilepath,
b.IMPORTSERVER ,
nvl(a.ignoreexception,'N') AS ignoreexception,
a.PAYOR    AS payor ,
b.clientid ,
Nvl(b.aip_filename,b.filename) AS original_filename,
CASE WHEN B.LAYOUTID!= nvl(a.layoutid,'0') THEN 'Y' END AS colorflag ,
CASE WHEN ISOVERRIDDEN ='Y' THEN a.sn else NULL END AS pattern_sn,
a.OVERRIDDENDATE,
coalesce(b.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno ,
a.sn AS defaultpatternsn
FROM (
      SELECT b.fileid,b.dmfileid, b.filename, b.layoutid , b.datatype, b.file_date, b.file_record_cnt,
      b.import_record_cnt, b.status_of_import,  b.processfilepath, b.IMPORTSERVER, b.processstatus,
      b.cuttingfloor ,b.clientid ,b.empgrp  ,c.aip_filename  ,coalesce(m.info13,c.info13) AS info13
       , To_Date (b.file_date,'YYYY-MM-DD HH24:MI:SS' ) AS filedate  , B.RELEASENO
      FROM imp_main_log  b
      left JOIN aip_dmfilelist_log   c
      ON b.clientid=c.client_id AND b.dmfileid=c.dmfile_id  AND b.filename=c.filename
      left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN
                        ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
      ON m.fileid=b.fileid||'_'||b.dmfileid
      WHERE  ( PROCESSSTATUS IN ('EXCEPTIONS','UNKNOWN','RUNNING','MANUAL SUBMITTED EXCEPTIONS','DONOTUSE') or import_record_cnt=0
      OR coalesce(m.info13,c.info13)='Control Total file unprocessed')
      AND EXCEPTIONFLAG IS null
    ) b
left JOIN  ( SELECT i.* , g.LAYOUTTYPEID ,h.datatype , h.payor   , Nvl(i.skiprows,h.skiprow)  AS  skiprow
              FROM imp_clientpatterns i
               left JOIN  imp_layouts h
               ON i.layoutid=h.layoutid
                left JOIN imp_sub_layouts k
               ON k.layoutid=h.layoutid  AND   k.sublayoutid=1
                LEFT JOIN  tbl_filepatterns_layout g
               on Nvl(i.delimiter,k.layouttype)=g.LAYOUTTYPE  )  a
ON b.clientid = a.clientid  AND aip_file_match (b.filename,a.pattern)=1
left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON b.clientid=cm.clientid
                AND b.filedate >=  cm.data_start_date  AND  b.filedate <= cm.data_end_date
UNION
SELECT
fileid,
dmfileid,
filename,
b.file_date,
b.layoutid  AS oldlayoutid,
coalesce(a.ctl_layoutid,a.layoutid,0) AS NEWLAYOUTID,
CASE WHEN B.LAYOUTID=coalesce(a.ctl_layoutid,a.layoutid,0) THEN  Nvl(Trim(STATUS_OF_IMPORT),info13) ELSE NULL END AS STATUS_OF_IMPORT,
CASE WHEN B.LAYOUTID=coalesce(a.ctl_layoutid,a.layoutid,0) THEN PROCESSSTATUS ELSE NULL END AS PROCESSSTATUS ,
UPPER(a.DATATYPE)   AS newdatatype,
a.EMPLOYERGROUP  AS empgrp ,
a.skiprow  SKIPROWS,
a.LAYOUTTYPEID  AS  DELIMITER,
processfilepath,
b.IMPORTSERVER ,
nvl(a.ignoreexception,'N') AS ignoreexception,
a.PAYOR    AS payor ,
b.clientid ,
Nvl(b.aip_filename,b.filename) AS original_filename,
CASE WHEN B.LAYOUTID!= coalesce(a.ctl_layoutid,a.layoutid,0) THEN 'Y' END AS colorflag,
CASE WHEN ISOVERRIDDEN ='Y' THEN a.sn else NULL END AS pattern_sn,
OVERRIDDENDATE,
coalesce(b.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno,
a.sn AS defaultpatternsn
FROM (
      SELECT b.fileid,b.dmfileid, b.filename, b.layoutid , b.datatype, b.file_date, b.file_record_cnt,
      b.import_record_cnt, b.status_of_import,  b.processfilepath, b.IMPORTSERVER, b.processstatus,
      b.cuttingfloor ,b.clientid ,b.empgrp  ,c.aip_filename  ,coalesce(m.info13,c.info13) AS info13
       , To_Date (b.file_date,'YYYY-MM-DD HH24:MI:SS' ) AS filedate  , B.RELEASENO
      FROM imp_main_log  b
      left JOIN aip_dmfilelist_log   c
      ON b.clientid=c.client_id AND b.dmfileid=c.dmfile_id  AND b.filename=c.filename
      left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN
                        ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
      ON m.fileid=b.fileid||'_'||b.dmfileid
      WHERE  ( PROCESSSTATUS = 'CONTROL'
                AND  coalesce(m.info13,c.info13)='Control Total file unprocessed')
      AND EXCEPTIONFLAG IS null
    ) b
left JOIN  ( SELECT i.* , g.LAYOUTTYPEID ,h.datatype , h.payor   , Nvl(i.skiprows,h.skiprow)  AS  skiprow
              FROM imp_clientpatterns i
               left JOIN  imp_layouts h
               ON i.layoutid=h.layoutid
                left JOIN imp_sub_layouts k
               ON k.layoutid=h.layoutid  AND   k.sublayoutid=1
                LEFT JOIN  tbl_filepatterns_layout g
               on Nvl(i.delimiter,k.layouttype)=g.LAYOUTTYPE  )  a
ON b.clientid = a.clientid  AND aip_file_match (b.filename,Nvl(a.ctl_pattern,a.pattern))=1
left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON b.clientid=cm.clientid
                AND b.filedate >=  cm.data_start_date  AND  b.filedate <= cm.data_end_date
/


PROMPT CREATE OR REPLACE VIEW aip_dashboard_inventory
CREATE OR REPLACE VIEW aip_dashboard_inventory (
  exceptionflag,
  flag,
  fileid,
  filename,
  clientid,
  layoutid,
  datatype,
  file_size,
  filedate,
  timestamp,
  file_hashkey,
  file_record_cnt,
  import_record_cnt,
  unique_records_hash,
  dup_record_cnt,
  status_import,
  path,
  getstat,
  starttime,
  endtime,
  transfer_status,
  dmfileid,
  processfilepath,
  processstatus,
  emailstatus,
  cuttingfloor,
  process_type,
  process_type_detail,
  importserver,
  info13,
  exceptiondetail,
  processtime,
  empgrp,
  exception_remark,
  payor,
  releaseno,
  dpstatus,
  approvedby,
  approveddate
) AS
SELECT
A.EXCEPTIONFLAG,
A.FLAG,
A.RAWFILEID AS FILEID ,
A.FILENAME ,
A.CLIENTID ,
A.LAYOUTID ,
A.DATATYPE,
ROUND(A.FILE_SIZE/1024,2) AS FILE_SIZE,
A.RECEIVEDDATE FILEDATE,
A.TIMESTAMP ,
A.FILE_HASHKEY AS FILE_HASHKEY,
A.FILE_RECORD_CNT,
A.IMPORT_RECORD_CNT,
A.UNIQUE_RECORDS_HASH,
A.DUP_RECORD_CNT,
CASE WHEN STATUS_OF_IMPORT='SUCCESS' AND IMPORT_RECORD_CNT=0 AND FILE_RECORD_CNT!=0 THEN '0 RECORD IMPORTED'
     WHEN STATUS_OF_IMPORT='SUCCESS' AND IMPORT_RECORD_CNT=0 AND FILE_RECORD_CNT=0 THEN '0 FILE SIZE RECEIVED'
    -- WHEN STATUS_OF_IMPORT='SUCCESS' AND a.sn IS NOT NULL THEN STATUS_OF_IMPORT || ' (With Exceptions)'
     WHEN a.info13='File not imported due to layout mismatch error' THEN exceptiondetail ELSE  STATUS_OF_IMPORT  END AS STATUS_IMPORT,
A.PATH ,
A.GETSTAT,
A.STARTTIME,
A.ENDTIME,
A.TRANSFER_STATUS,
A.dmfileid AS DMFILEID ,
A.PROCESSFILEPATH,
CASE WHEN A.dmfile_id IS NULL  AND  CRONENDTIME IS NULL THEN 'FILE QUEUED IN PROCESSING'
     WHEN A.RAWFILEID IS NULL  AND  CRONENDTIME IS NOT NULL THEN NVL(Upper(A.INFO13),'ERROR IN PROCESSING')
     WHEN A.EXCEPTIONFLAG  IS NOT NULL THEN 'FILE MANUALLY SET AS ' || a.exceptionflag
     ELSE  Upper(A.PROCESSSTATUS) END AS PROCESSSTATUS,
A.EMAILSTATUS,
A.CUTTINGFLOOR,
A.PROCESS_TYPE,
A.PROCESS_TYPE_DETAIL,
A.IMPORTSERVER  ,
A.INFO13 ,
A.EXCEPTIONDETAIL ,
A.PROCESSTIME,
A.EMPGRP ,
A.EXCEPTION_REMARK,
A.PAYOR,
A.RELEASENO,
reportstatus AS dpstatus,
approvedby AS approvedby,
approveddate  AS approveddate
FROM
( SELECT
    b.EXCEPTIONFLAG,  a.FILENAME , a.CLIENTID ,b.LAYOUTID , b.DATATYPE,  a.filesize as FILE_SIZE,   b.TIMESTAMP ,
     a.hashvalue FILE_HASHKEY , b.FILE_RECORD_CNT, b.IMPORT_RECORD_CNT,  b.UNIQUE_RECORDS_HASH, b.DUP_RECORD_CNT,
     Nvl(Trim(b.STATUS_OF_IMPORT),coalesce(m.info13,a.info13)) AS STATUS_OF_IMPORT ,
     a.RECEIVEDDATE AS RECEIVEDDATE, a.PATH, b.GETSTAT, b.STARTTIME, b.ENDTIME,  b.TRANSFER_STATUS,b.FILEID ,b.PROCESSFILEPATH,
     b.PROCESSSTATUS  ,
     b.EMAILSTATUS,a.endtime AS CRONENDTIME,b.CUTTINGFLOOR, b.PROCESS_TYPE,  b.PROCESS_TYPE_DETAIL,b.IMPORTSERVER,
     coalesce(m.info13,a.info13) AS INFO13 ,
     b.fileid AS rawfileid ,b.file_date, c.flag,a.fileid AS dmfileid,  a.dmfile_id   ,
     CASE WHEN coalesce(m.info13,a.info13)='File not imported due to layout mismatch error' AND e.exceptiondetail IS NOT NULL AND  b.PROCESSSTATUS='IMPORTED'
            THEN 'Ignore Exception has been set for the layout, file is imported with exception . Refer AIP stats file for more details.'
          WHEN coalesce(m.info13,a.info13)='File not imported due to layout mismatch error' AND e.exceptiondetail IS NOT NULL
            THEN e.exceptiondetail || ' . Total # of File Records are ' || b.FILE_RECORD_CNT || '. Refer AIP stats file for more details.'
          END AS  exceptiondetail , a.processtime  , b.empgrp ,
     CASE WHEN APPROVEDSTATUS='Y' THEN 'APPROVED'
          WHEN APPROVEDSTATUS='N' THEN 'REJECTED'
          WHEN DPSTATUS = 'FAILED' THEN 'REVIEW'
          WHEN DPSTATUS = 'EXCEPTION' THEN 'EXCEPTION'
          WHEN DPSTATUS='RUNNING' THEN 'RUNNING'
          WHEN DPSTATUS = 'PASSED' THEN 'PASS' END AS reportstatus  ,
     b.exception_remark,b.payor ,
     coalesce(b.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno,approvedby,approveddate
    FROM
            ( SELECT   d.clientid, d.fileid , e.dmfile_id , Nvl (e.filename, d.FILENAME ) AS FILENAME , d.FILESIZE  ,d.CHECKSUM AS hashvalue,e.info13 ,
              To_Date(e.FILEDATE,'YYYY-MM-DD hh24:mi:ss') AS  FILEDATE , d.DESTPATH AS PATH  ,e.aip_filename,e.endtime  , d.RECEIVEDDATE  ,
              Round(To_number(( To_date(e.endtime, 'YYYY-MM-DD HH24:MI:SS') -
                      To_date(e.processtime, 'YYYY-MM-DD HH24:MI:SS') ) * 24 * 60), 4) AS processtime
          FROM imp_dmfilelist d
          left join   aip_dmfilelist_log   e
           ON  d.fmonid=e.fmonid and d.CLIENTID=e.CLIENT_ID AND d.fileid=e.dmfile_id   ) a
left JOIN (SELECT b.*,Nvl(l.payor,'UNKNOWN') AS payor FROM imp_main_log  b left JOIN imp_layouts l ON b.layoutid=l.layoutid ) b
ON  a.clientid=b.clientid AND a.dmfile_id=b.dmfileid  AND a.filename=b.filename
left join (SELECT  'Duplicate # '||Count(hashvalue) flag, CLIENT_ID , hashvalue FROM aip_dmfilelist_log  b
           GROUP BY hashvalue ,CLIENT_ID HAVING  Count(hashvalue) >1) c
ON c.hashvalue=a.hashvalue AND c.client_id=a.clientid
left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN  ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
ON m.fileid=b.fileid||'_'||b.dmfileid
left JOIN
(         SELECT s.fileid, listagg(s.exceptiondetail,' ') within GROUP (ORDER BY s.fileid,sublayoutid) AS  exceptiondetail
          FROM (  SELECT fileid,CHECKTYPE ,CHECKDETAIL , result ,sublayoutid ,
                  'Defined Layout' || CASE WHEN CHECKTYPE ='CHKNUMFIELDS' THEN ' # Fields is ' WHEN CHECKTYPE ='CHKLENFIXED' THEN ' Length is ' END
                  || regexp_substr (CHECKDETAIL,'[0-9]+')
                  || ' , where as File contains ' ||  regexp_substr (RESULT,'[0-9]+') || ' records having '
                  || CASE WHEN CHECKTYPE ='CHKNUMFIELDS' THEN ' # Fields ' WHEN CHECKTYPE ='CHKLENFIXED' THEN ' Length ' END
                  || regexp_substr (RESULT,'(-)[0-9]+')
                    AS exceptiondetail
                  FROM   imp_file_stats_log
                  WHERE  result != '0[...]'
                  AND checktype IN ( 'CHKLENFIXED', 'CHKNUMFIELDS' )   ) s
        GROUP BY   s.fileid ) e
ON e.fileid=b.fileid||'_'||b.dmfileid
left JOIN dp_dashboard_report_display rep
ON b.fileid=rep.fileid
            left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON a.clientid=cm.clientid
                AND a.filedate >=  cm.data_start_date  AND  a.filedate <= cm.data_end_date
order by c.hashvalue ,   Nvl(m.PROCESSTIME,a.endtime)   desc
)  a
/


PROMPT CREATE OR REPLACE VIEW aip_dashboard_inventory_recon
CREATE OR REPLACE VIEW aip_dashboard_inventory_recon (
  fileid,
  dmfileid,
  filename,
  clientid,
  layoutid,
  datatype,
  file_size,
  filedate,
  file_record_cnt,
  transfer_record,
  import_record_cnt,
  status_import,
  processstatus,
  importserver,
  info13,
  exceptiondetail,
  empgrp,
  exception_remark,
  payor,
  aitablename,
  hischemaname,
  hitablename,
  transferstatus,
  retransfer_detail,
  wherecondition,
  releaseno,
  summary_import_cnt
) AS
SELECT a.fileid,a.dmfileid, a.filename, a.clientid, a.layoutid, a.datatype, a.file_size, a.filedate, a.file_record_cnt,b.transfer_record,
b.import_record_cnt,  a.status_import,  a.processstatus,
a.importserver, a.info13, a.exceptiondetail, a.empgrp, a.exception_remark,
a.payor,  b.aitablename ,b.hischemaname , b.hitablename, b.transfer_status AS transferstatus, b.retransfer_detail ,b.wherecondition,a.releaseno   ,
a.import_record_cnt AS summary_import_cnt
FROM
AIP_DASHBOARD_INVENTORY A
left JOIN AIP_DASHBOARD_TRANSFER b
ON a.fileid =b.fileid
/


PROMPT CREATE OR REPLACE VIEW aip_dashboard_inventory_w
CREATE OR REPLACE VIEW aip_dashboard_inventory_w (
  exceptionflag,
  flag,
  fileid,
  filename,
  clientid,
  layoutid,
  datatype,
  file_size,
  filedate,
  timestamp,
  file_hashkey,
  file_record_cnt,
  import_record_cnt,
  unique_records_hash,
  dup_record_cnt,
  status_import,
  path,
  getstat,
  starttime,
  endtime,
  transfer_status,
  dmfileid,
  processfilepath,
  processstatus,
  emailstatus,
  cuttingfloor,
  process_type,
  process_type_detail,
  importserver,
  info13,
  exceptiondetail,
  processtime,
  empgrp,
  exception_remark,
  payor,
  releaseno
) AS
SELECT
A.EXCEPTIONFLAG,
A.FLAG,
A.RAWFILEID AS FILEID ,
A.FILENAME ,
A.CLIENTID ,
A.LAYOUTID ,
A.DATATYPE,
ROUND(A.FILE_SIZE/1024,2) AS FILE_SIZE,
A.RECEIVEDDATE FILEDATE,
A.TIMESTAMP ,
A.FILE_HASHKEY AS FILE_HASHKEY,
A.FILE_RECORD_CNT,
A.IMPORT_RECORD_CNT,
A.UNIQUE_RECORDS_HASH,
A.DUP_RECORD_CNT,
CASE WHEN STATUS_OF_IMPORT='SUCCESS' AND IMPORT_RECORD_CNT=0 AND FILE_RECORD_CNT!=0 THEN '0 RECORD IMPORTED'
     WHEN STATUS_OF_IMPORT='SUCCESS' AND IMPORT_RECORD_CNT=0 AND FILE_RECORD_CNT=0 THEN '0 FILE SIZE RECEIVED'
     WHEN STATUS_OF_IMPORT='SUCCESS' AND a.sn IS NOT NULL THEN STATUS_OF_IMPORT || ' (With Exceptions)'
     WHEN a.info13='File not imported due to layout mismatch error' THEN exceptiondetail ELSE  STATUS_OF_IMPORT  END AS STATUS_IMPORT,
A.PATH ,
A.GETSTAT,
A.STARTTIME,
A.ENDTIME,
A.TRANSFER_STATUS,
A.dmfileid AS DMFILEID ,
A.PROCESSFILEPATH,
CASE WHEN A.dmfile_id IS NULL  AND  CRONENDTIME IS NULL THEN 'FILE QUEUED IN PROCESSING'
     WHEN A.RAWFILEID IS NULL  AND  CRONENDTIME IS NOT NULL THEN NVL(Upper(A.INFO13),'ERROR IN PROCESSING')
     WHEN A.EXCEPTIONFLAG  IS NOT NULL THEN 'FILE MANUALLY SET AS ' || a.exceptionflag
     ELSE  Upper(A.PROCESSSTATUS) END AS PROCESSSTATUS,
A.EMAILSTATUS,
A.CUTTINGFLOOR,
A.PROCESS_TYPE,
A.PROCESS_TYPE_DETAIL,
A.IMPORTSERVER  ,
A.INFO13 ,
A.EXCEPTIONDETAIL ,
A.PROCESSTIME,
A.EMPGRP ,
A.EXCEPTION_REMARK,
A.PAYOR,
A.RELEASENO
FROM
( SELECT
    b.EXCEPTIONFLAG,  a.FILENAME , a.CLIENTID ,b.LAYOUTID , b.DATATYPE,  a.filesize as FILE_SIZE,   b.TIMESTAMP ,
     a.hashvalue FILE_HASHKEY , b.FILE_RECORD_CNT, b.IMPORT_RECORD_CNT,  b.UNIQUE_RECORDS_HASH, b.DUP_RECORD_CNT,
     Nvl(Trim(b.STATUS_OF_IMPORT),coalesce(m.info13,a.info13)) AS STATUS_OF_IMPORT ,
     a.RECEIVEDDATE AS RECEIVEDDATE, a.PATH, b.GETSTAT, b.STARTTIME, b.ENDTIME,  b.TRANSFER_STATUS,b.FILEID ,b.PROCESSFILEPATH,
     b.PROCESSSTATUS  ,
     b.EMAILSTATUS,a.endtime AS CRONENDTIME,b.CUTTINGFLOOR, b.PROCESS_TYPE,  b.PROCESS_TYPE_DETAIL,b.IMPORTSERVER,
     coalesce(m.info13,a.info13) AS INFO13 ,
     b.fileid AS rawfileid ,b.file_date, c.flag,a.fileid AS dmfileid,  a.dmfile_id   ,
     CASE WHEN coalesce(m.info13,a.info13)='File not imported due to layout mismatch error' AND e.exceptiondetail IS NOT NULL AND  b.PROCESSSTATUS='IMPORTED'
            THEN 'Ignore Exception has been set for the layout, file is imported with exception . Refer AIP stats file for more details.'
          WHEN coalesce(m.info13,a.info13)='File not imported due to layout mismatch error' AND e.exceptiondetail IS NOT NULL
            THEN e.exceptiondetail || ' . Total # of File Records are ' || b.FILE_RECORD_CNT || '. Refer AIP stats file for more details.'
          END AS  exceptiondetail , a.processtime  , b.empgrp  ,ex.sn ,b.exception_remark,b.payor ,
          coalesce(b.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno
    FROM
            ( SELECT   d.clientid, d.fileid , e.dmfile_id , Nvl (e.filename, d.FILENAME ) AS FILENAME , d.FILESIZE  ,d.CHECKSUM AS hashvalue,e.info13 ,
              To_Date(e.FILEDATE,'YYYY-MM-DD hh24:mi:ss') AS  FILEDATE , d.DESTPATH AS PATH  ,e.aip_filename,e.endtime  , d.RECEIVEDDATE  ,
              Round(To_number(( To_date(e.endtime, 'YYYY-MM-DD HH24:MI:SS') -
                      To_date(e.processtime, 'YYYY-MM-DD HH24:MI:SS') ) * 24 * 60), 4) AS processtime
          FROM imp_dmfilelist d
          left join   aip_dmfilelist_log   e
           ON  d.fmonid=e.fmonid and d.CLIENTID=e.CLIENT_ID AND d.fileid=e.dmfile_id   ) a
left JOIN (SELECT b.*,Nvl(l.payor,'UNKNOWN') AS payor FROM imp_main_log  b left JOIN imp_layouts l ON b.layoutid=l.layoutid ) b
ON  a.clientid=b.clientid AND a.dmfile_id=b.dmfileid  AND a.filename=b.filename
left join (SELECT  'Duplicate # '||Count(hashvalue) flag, CLIENT_ID , hashvalue FROM aip_dmfilelist_log  b
           GROUP BY hashvalue ,CLIENT_ID HAVING  Count(hashvalue) >1) c
ON c.hashvalue=a.hashvalue AND c.client_id=a.clientid
left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN  ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
ON m.fileid=b.fileid||'_'||b.dmfileid
left JOIN
(         SELECT s.fileid, listagg(s.exceptiondetail,' ') within GROUP (ORDER BY s.fileid,sublayoutid) AS  exceptiondetail
          FROM (  SELECT fileid,CHECKTYPE ,CHECKDETAIL , result ,sublayoutid ,
                  'Defined Layout' || CASE WHEN CHECKTYPE ='CHKNUMFIELDS' THEN ' # Fields is ' WHEN CHECKTYPE ='CHKLENFIXED' THEN ' Length is ' END
                  || regexp_substr (CHECKDETAIL,'[0-9]+')
                  || ' , where as File contains ' ||  regexp_substr (RESULT,'[0-9]+') || ' records having '
                  || CASE WHEN CHECKTYPE ='CHKNUMFIELDS' THEN ' # Fields ' WHEN CHECKTYPE ='CHKLENFIXED' THEN ' Length ' END
                  || regexp_substr (RESULT,'(-)[0-9]+')
                    AS exceptiondetail
                  FROM   imp_file_stats_log
                  WHERE  result != '0[...]'
                  AND checktype IN ( 'CHKLENFIXED', 'CHKNUMFIELDS' )   ) s
        GROUP BY   s.fileid ) e
ON e.fileid=b.fileid||'_'||b.dmfileid
left JOIN
      (SELECT fileid,Count(*) AS sn FROM
          (
          SELECT fileid,reporttype,puchcharflag,a.sn,
          CASE WHEN CHKTYPE='NUMBERCHECK' AND PUCHCHARFLAG ='Y' THEN exception_num_chk(pc(flval))
                WHEN CHKTYPE='NUMBERCHECK' AND PUCHCHARFLAG ='N' THEN exception_num_chk(flval)
                WHEN chktype='DATECHECK' THEN flval END as flval,chktype FROM
                (SELECT fileid,reporttype,puchcharflag,sn FROM rpt_main_log a JOIN imp_layouts b
                  on a.layoutid=b.layoutid AND a.sublayoutid=1 AND REPORTTYPE='DTE_NUM_CHK') a
                INNER JOIN
                (SELECT sn, flval
                ,CHKTYPE
                FROM rpt_chk_date_number) b
                ON a.sn=b.sn )
                WHERE flval!='0' and flval IS NOT NULL
                GROUP BY fileid
          ) ex
                ON  b.fileid||'_'||b.dmfileid=ex.fileid
            left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON a.clientid=cm.clientid
                AND a.filedate >=  cm.data_start_date  AND  a.filedate <= cm.data_end_date
--ORDER BY  c.hashvalue ,  To_Number(b.LAYOUTID),To_Number(b.FILEID)
order by c.hashvalue ,   Nvl(m.PROCESSTIME,a.endtime)   desc
)  a
/


PROMPT CREATE OR REPLACE VIEW aip_dashboard_reimport
CREATE OR REPLACE VIEW aip_dashboard_reimport (
  fileid,
  dmfileid,
  filename,
  file_date,
  oldlayoutid,
  newlayoutid,
  status_of_import,
  processstatus,
  newdatatype,
  empgrp,
  skiprows,
  delimiter,
  processfilepath,
  importserver,
  import_record_cnt,
  ignoreexception,
  payor,
  clientid,
  original_filename,
  colorflag,
  pattern_sn,
  overriddendate,
  releaseno,
  defaultpatternsn
) AS
SELECT
    FILEID,
    DMFILEID,
    FILENAME,
    B.FILE_DATE,
    B.LAYOUTID  AS OLDLAYOUTID,
    nvl(a.layoutid,'0') AS NEWLAYOUTID,
    CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN  Nvl(Trim(STATUS_OF_IMPORT),info13) ELSE NULL END AS STATUS_OF_IMPORT,
    CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN PROCESSSTATUS ELSE NULL END AS PROCESSSTATUS ,
    a.DATATYPE AS NEWDATATYPE,
    a.EMPLOYERGROUP  AS EMPGRP ,
    a.skiprow  AS SKIPROWS,
    a.LAYOUTTYPEID   AS  DELIMITER,
    PROCESSFILEPATH,
    B.IMPORTSERVER,
    CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN   B.IMPORT_RECORD_CNT ELSE NULL END AS IMPORT_RECORD_CNT ,
    NVL(a.IGNOREEXCEPTION,'N') AS IGNOREEXCEPTION,
    a.PAYOR  AS PAYOR  ,
    B.CLIENTID ,
     Nvl(b.aip_filename,b.filename) AS original_filename,
     CASE WHEN B.LAYOUTID!= nvl(a.layoutid,'0') THEN 'Y' END AS colorflag,
     CASE WHEN ISOVERRIDDEN ='Y' THEN a.sn else NULL END AS pattern_sn,
     OVERRIDDENDATE,
     coalesce(b.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno,
     a.sn AS defaultpatternsn
    FROM (
           SELECT b.fileid,b.dmfileid, b.filename, b.layoutid , b.datatype, b.file_date, b.file_record_cnt,
            b.import_record_cnt, b.status_of_import,  b.processfilepath, b.IMPORTSERVER, b.processstatus,
            b.cuttingfloor ,b.clientid   ,b.empgrp,c.aip_filename  ,coalesce(m.info13,c.info13) as info13
            , To_Date (b.file_date,'YYYY-MM-DD HH24:MI:SS' ) AS filedate  , B.RELEASENO
            FROM imp_main_log  b
            left JOIN aip_dmfilelist_log   c
            ON b.clientid=c.client_id AND b.dmfileid=c.dmfile_id  AND b.filename=c.filename
            left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN
                        ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
            ON m.fileid=b.fileid||'_'||b.dmfileid
            WHERE  ( PROCESSSTATUS IN ('IMPORTED','RUNNING','MANUAL SUBMITTED REIMPORT') )
            AND EXCEPTIONFLAG IS null
    ) b
        left JOIN  ( SELECT i.* , g.LAYOUTTYPEID ,h.datatype  , h.payor , Nvl(i.skiprows,h.skiprow)  AS  skiprow
                      FROM imp_clientpatterns i
                      left JOIN  imp_layouts h
                      ON i.layoutid=h.layoutid
                        left JOIN imp_sub_layouts k
                      ON k.layoutid=h.layoutid  AND   k.sublayoutid=1
                        LEFT JOIN  tbl_filepatterns_layout g
                      on Nvl(i.delimiter,k.layouttype)=g.LAYOUTTYPE )  a
        ON b.clientid = a.clientid
           AND aip_file_match(b.filename,a.pattern)=1
        left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON b.clientid=cm.clientid
                AND b.filedate >=  cm.data_start_date  AND  b.filedate <= cm.data_end_date
UNION
SELECT
    FILEID,
    DMFILEID,
    FILENAME,
    B.FILE_DATE,
    B.LAYOUTID  AS OLDLAYOUTID,
    coalesce(a.ctl_layoutid,a.layoutid,0) AS NEWLAYOUTID,
    CASE WHEN B.LAYOUTID=coalesce(a.ctl_layoutid,a.layoutid,0) THEN  Nvl(Trim(STATUS_OF_IMPORT),info13) ELSE NULL END AS STATUS_OF_IMPORT,
    CASE WHEN B.LAYOUTID=coalesce(a.ctl_layoutid,a.layoutid,0) THEN PROCESSSTATUS ELSE NULL END AS PROCESSSTATUS ,
    UPPER(a.DATATYPE)   AS NEWDATATYPE,
    a.EMPLOYERGROUP  AS EMPGRP ,
    a.skiprow  AS SKIPROWS,
    a.LAYOUTTYPEID   AS  DELIMITER,
    PROCESSFILEPATH,
    B.IMPORTSERVER,
    CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN  B.IMPORT_RECORD_CNT ELSE NULL END AS IMPORT_RECORD_CNT ,
    NVL(a.IGNOREEXCEPTION,'N') AS IGNOREEXCEPTION,
    a.PAYOR  AS PAYOR  ,
    B.CLIENTID ,
     Nvl(b.aip_filename,b.filename) AS original_filename,
     CASE WHEN B.LAYOUTID!= coalesce(a.ctl_layoutid,a.layoutid,0) THEN 'Y' END AS colorflag,
     CASE WHEN ISOVERRIDDEN ='Y' THEN a.sn else NULL END AS  pattern_sn  ,
     OVERRIDDENDATE,
     coalesce(b.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno,
     a.sn AS defaultpatternsn
    FROM (
           SELECT b.fileid,b.dmfileid, b.filename, b.layoutid , b.datatype, b.file_date, b.file_record_cnt,
            b.import_record_cnt, b.status_of_import,  b.processfilepath, b.IMPORTSERVER, b.processstatus,
            b.cuttingfloor ,b.clientid   ,b.empgrp,c.aip_filename  ,coalesce(m.info13,c.info13) AS info13,
            To_Date (b.file_date,'YYYY-MM-DD HH24:MI:SS' ) AS filedate , B.RELEASENO
            FROM imp_main_log  b
            left JOIN aip_dmfilelist_log   c
            ON b.clientid=c.client_id AND b.dmfileid=c.dmfile_id  AND b.filename=c.filename
            left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN
                        ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
            ON m.fileid=b.fileid||'_'||b.dmfileid
            WHERE  ( PROCESSSTATUS IN ('CONTROL')
            AND coalesce(m.info13,c.info13) ='Control Total file successfully processed')
            AND EXCEPTIONFLAG IS null
    ) b
        left JOIN  (  SELECT i.* , g.LAYOUTTYPEID ,h.datatype  , h.payor , Nvl(i.skiprows,h.skiprow)  AS  skiprow
                      FROM imp_clientpatterns i
                      left JOIN  imp_layouts h
                      ON nvl(i.ctl_layoutid,i.layoutid)=h.layoutid
                        left JOIN imp_sub_layouts k
                      ON k.layoutid=h.layoutid  AND   k.sublayoutid=1
                        LEFT JOIN  tbl_filepatterns_layout g
                      on Nvl(i.delimiter,k.layouttype)=g.LAYOUTTYPE )  a
        ON b.clientid = a.clientid
           AND aip_file_match(b.filename,Nvl(a.ctl_pattern,a.pattern))=1
       left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON b.clientid=cm.clientid
                AND b.filedate >=  cm.data_start_date  AND  b.filedate <= cm.data_end_date
/


PROMPT CREATE OR REPLACE VIEW aip_dashboard_transfer
CREATE OR REPLACE VIEW aip_dashboard_transfer (
  fileid,
  filename,
  payor,
  clientid,
  layoutid,
  datatype,
  file_size,
  file_date,
  timestamp,
  file_hashkey,
  file_record_cnt,
  import_record_cnt,
  unique_records_hash,
  dup_record_cnt,
  status_of_import,
  fullpath,
  getstat,
  starttime,
  endtime,
  transfer_status,
  dmfileid,
  processfilepath,
  processstatus,
  emailstatus,
  cuttingfloor,
  process_type,
  process_type_detail,
  importserver,
  empgrp,
  aitablename,
  hiservername,
  hischemaname,
  hitablename,
  wherecondition,
  sn,
  retransfer_detail,
  transfer_record,
  releaseno
) AS
SELECT a.FILEID, FILENAME,d.Payor, a.CLIENTID, a.LAYOUTID, a.DATATYPE,
round(a.FILE_SIZE/1024,2) AS file_size, a.FILE_DATE, 	TIMESTAMP, FILE_HASHKEY,
FILE_RECORD_CNT, b.recordcount AS  IMPORT_RECORD_CNT, UNIQUE_RECORDS_HASH, 	DUP_RECORD_CNT, STATUS_OF_IMPORT,
FULLPATH, GETSTAT, STARTTIME, ENDTIME, e.histatus as TRANSFER_STATUS,a.DMFILEID,PROCESSFILEPATH,
PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL 	,importserver , a.empgrp  ,
b.aitablename,c.HISERVERNAME,c.HISCHEMANAME,c.hitablename,c.wherecondition,e.sn
,CASE WHEN Nvl(e.file_cnt,0) > 1 THEN 'Transfer Request has been done '|| e.file_cnt|| ' times for same file' ELSE NULL END AS retransfer_detail
,e.hirows AS transfer_record,
coalesce(a.releaseno,cm.release_number,'Release Tag Not Generated') AS releaseno
FROM IMP_MAIN_LOG a
left JOIN imp_main_det_log b
  ON a.fileid||'_'||a.dmfileid = b.fileid
left JOIN 	hi_legacy_transfer c
  ON a.empgrp=c.empgrp and  c.aitablename=b.aitablename
    AND a.clientid=c.clientid
left join imp_layouts d
  on a.layoutid=d.layoutid
left JOIN (select e.*, f.file_cnt
           FROM hi_main_log e INNER JOIN (SELECT Max(sn) AS sn, Count(fileid) AS file_cnt , clientid FROM hi_main_log GROUP BY clientid,fileid ,hitablename) f
           ON e.sn=f.sn)  e
  ON e.fileid=a.fileid AND e.aitablename=b.aitablename AND c.hitablename=e.hitablename
left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON a.clientid=cm.clientid
                AND  To_Date(a.FILE_DATE,'YYYY-MM-DD hh24:mi:ss') >=  cm.data_start_date  AND  To_Date(a.FILE_DATE,'YYYY-MM-DD hh24:mi:ss') <= cm.data_end_date
WHERE STATUS_OF_IMPORT='SUCCESS' AND EXCEPTIONFLAG IS NULL
ORDER BY  To_Number(a.FILEID) DESC,aitablename,c.hiservername,c.hischemaname
/


PROMPT CREATE OR REPLACE VIEW aip_import_summary_view
CREATE OR REPLACE VIEW aip_import_summary_view (
  client_id,
  client_name,
  data_manager_id,
  file_name,
  aip_layout_id,
  payor,
  file_data_type,
  file_size,
  raw_record_count,
  imported_count,
  layout_detail,
  file_date,
  process_information,
  process_time,
  exception_details,
  ord,
  endtime,
  executed_from,
  info1,
  fileid
) AS
SELECT client_id             AS CLIENT_ID,
       clientname1           AS CLIENT_NAME,
       dmfile_id             AS DATA_MANAGER_ID,
       filename              AS FILE_NAME,
       layoutid              AS  AIP_Layout_Id,
       Nvl(payor, 'Unknown') AS PAYOR,
       Nvl(datatype, 'UNKN') AS FILE_DATA_TYPE,
       filesize              AS FILE_SIZE,
       file_record_cnt       AS RAW_RECORD_COUNT,
       import_record_cnt     AS IMPORTED_COUNT,
       CASE
         WHEN layouttype IS NOT NULL
              AND layouttype = 'Fixed length' THEN 'Fixed Length: '
                                                   ||layoutdetail
         WHEN layouttype IS NOT NULL THEN 'Delimitted: '
                                          ||layoutdetail
       END                   AS LAYOUT_DETAIL,
       filedate              AS FILE_DATE,
       CASE
         WHEN import_record_cnt = '0' AND file_record_cnt!=0 THEN 'Import Exception 0 Record Imported'
         ELSE process
       END                   AS PROCESS_INFORMATION,
       ptime                 AS PROCESS_TIME,
       CASE WHEN processstatus='IMPORTED' AND  exceptiondetial  IS NOT NULL THEN 'Ignore Exception has been Set for a file. '  || coalesce(manualrunstatus,exceptiondetial)
           ELSE exceptiondetial END   AS EXCEPTION_DETAILS,
       CASE
         WHEN Upper(process) LIKE '%ERROR%' THEN 1
         ELSE 2
       END                   AS ord  ,
        ENDTIME AS endtime ,
        EXECUTED_BY AS EXECUTED_from,
        info1,
        fileid
FROM   (  SELECT
               b.file_record_cnt,
               b.import_record_cnt,
               c.clientname  AS clientname1,
               b.datatype,
               b.payor,
               b.skiprow,
               b.trailerskip,
               b.layoutdetail,
               b.processstatus,
               layouttype,
               b.fileid,
Round(To_number(
( To_date(a.endtime, 'YYYY-MM-DD HH24:MI:SS') -
            To_date(a.processtime, 'YYYY-MM-DD HH24:MI:SS') ) * 24 * 60), 4) AS
ptime,
--regexp_instr(a.info13)
CASE
  WHEN Upper(coalesce(m.info13,a.info13)) LIKE '%IMPORTED SUCCESSFULLY%' THEN
  'Imported Successfully'
  ELSE coalesce(m.info13,a.info13)
END
AS Process,
a.*,
Nvl(b.layoutid,0) AS layoutid,
d.exceptiondetial, m.info13 as manualrunstatus
FROM   (SELECT a.*,b.info1
 FROM   aip_dmfilelist_log a,
        aip_cron_log b
 WHERE  a.fmonid = b.fmonid  ) a
left join (SELECT i.*,
                  l.payor,
                  l.skiprow,
                  l.trailerskip,
                  s.layoutdetail,
                  s.layouttype
           FROM   imp_main_log i
                  left JOIN imp_layouts l
                  ON   i.layoutid = l.layoutid
                  left JOIN imp_sub_layouts s
                  ON  l.layoutid = s.layoutid
                  AND sublayoutid = 1  ) b
       ON a.dmfile_id = b.dmfileid
          AND  b.filename=a.filename
left join hawkeyemaster.m_clients c
       ON a.client_id = c.clientid
left JOIN
(         SELECT s.fileid, listagg(s.exceptiondetail,' ') within GROUP (ORDER BY s.fileid,sublayoutid) AS  exceptiondetial
          FROM (  SELECT fileid,CHECKTYPE ,CHECKDETAIL , result ,sublayoutid                     ,
                  'Defined Layout' || CASE WHEN CHECKTYPE ='CHKNUMFIELDS' THEN ' # Fields is ' WHEN CHECKTYPE ='CHKLENFIXED' THEN ' Length is ' END
                  || regexp_substr (CHECKDETAIL,'[0-9]+')
                  || ' , where as File contains ' ||  regexp_substr (RESULT,'[0-9]+') || ' records having '
                  || CASE WHEN CHECKTYPE ='CHKNUMFIELDS' THEN ' # Fields ' WHEN CHECKTYPE ='CHKLENFIXED' THEN ' Length ' END
                  || regexp_substr (RESULT,'(-)[0-9]+')
                  ||' . Get Stats Result : '
                  ||result
                    AS exceptiondetail
                  FROM   imp_file_stats_log
                  WHERE  result != '0[...]'
                  AND checktype IN ( 'CHKLENFIXED', 'CHKNUMFIELDS' )   ) s
        GROUP BY   s.fileid ) d
       ON b.fileid
          ||'_'
          ||b.dmfileid = d.fileid
left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN  ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
  ON m.fileid=b.fileid||'_'||b.dmfileid
 )
ORDER  BY ord,
          process
/


PROMPT CREATE OR REPLACE VIEW aip_users_view
CREATE OR REPLACE VIEW aip_users_view (
  userid,
  privilage_name
) AS
SELECT a.userid,p.PRIVILAGE_NAME
FROM aipd_users a
     left JOIN aip_role_privs r
                ON a.user_role = r.ROLE_ID
     left JOIN  aip_user_privilages p
                ON r.PRIVILAGE_ID = p.privilage_id
   ORDER BY a.userid
/


PROMPT CREATE OR REPLACE VIEW dp_dashboard_client_config
CREATE OR REPLACE VIEW dp_dashboard_client_config (
  layoutid,
  sublayoutid,
  columnid,
  columnname,
  datatype,
  checkname,
  threshold,
  fieldsn,
  checkid,
  inputtype,
  category,
  checklevel,
  inputdetail,
  configsn,
  clientid,
  function_name,
  is_enabled,
  businessname,
  requiredflag
) AS
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname,
Upper( datatype) AS datatype,
m.name ,
threshold,
a.sn ,
m.mas_id ,
input_type,
a.category ,
check_level    ,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE l.input_detail END AS input_detail,
l.configsn AS configsn  ,
l.client_id clientid,
m.function_name,
l.is_enabled,
a.businessname,
Nvl(l.requiredFlag,'N') AS requiredflag
FROM
(SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
left JOIN
(
SELECT
 Nvl(cc.cli_sn,ll.lay_sn) AS configsn ,
 Nvl(cc.mas_id,ll.mas_id) AS  mas_id ,
 Nvl(cc.field_sn,ll.field_sn) AS  field_sn,
 Nvl(cc.threshold,ll.threshold) AS threshold,
 Nvl(cc.INPUT_TYPE,ll.INPUT_TYPE) AS INPUT_TYPE,
 Nvl(cc.INPUT_DETAIL,ll.INPUT_DETAIL) AS INPUT_DETAIL,
 Nvl(cc.layoutid,ll.layoutid) AS layoutid   ,
 cc.client_id ,
 CASE WHEN   cc.cli_sn IS NOT NULL THEN 'CLIENT'
      WHEN   ll.lay_sn IS NOT NULL  THEN 'LAYOUT' END  AS check_level ,
 Nvl(cc.IS_ENABLED,ll.IS_ENABLED) AS is_enabled,
 Nvl(cc.requiredflag,ll.requiredflag) AS requiredFlag
FROM
     ( SELECT * FROM dp_layouts_configuration WHERE   effective_to IS  null) ll
     full outer JOIN
      (SELECT * FROM dp_clients_configuration WHERE   effective_to IS  null  ) cc
      ON ll.mas_id=cc.mas_id   AND ll.FIELD_SN=cc.FIELD_SN
) l
ON a.SN=l.field_sn
left join  dp_checks_master   m
ON  l.mas_id=m.mas_id
UNION
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname    ,
Upper( datatype) AS datatype,
c.name ,
c.SYS_DFLT_THRSHLD,
a.sn ,
c.MAS_ID ,
'DEFAULT' input_type ,
c.category_name,
'DEFAULT' check_level,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE NULL END AS input_detail,
NULL configsn  ,
NULL clientid,
c.function_name,
1 AS is_enabled,
a.businessname,
'N' AS requiredflag
FROM
( SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
 JOIN
 (
      select  c.cat_sn,c.category_name  ,cl.default_flag, m.name,m.mas_id,  m.sys_dflt_thrshld,m.function_name
      FROM dp_check_categories c
      JOIN dp_catgry_chk_list cl
      ON c.CAT_SN=cl.CAT_SN
      JOIN dp_checks_master m
      ON cl.mas_id=m.mas_id
      where is_enabled=1 AND  cl.default_flag=1
)  c
ON   a.category=c.CATEGORY_NAME
/

GRANT SELECT ON dp_dashboard_client_config TO public;

PROMPT CREATE OR REPLACE VIEW dp_dashboard_layout_config
CREATE OR REPLACE VIEW dp_dashboard_layout_config (
  layoutid,
  sublayoutid,
  columnid,
  columnname,
  datatype,
  checkname,
  threshold,
  fieldsn,
  checkid,
  inputtype,
  category,
  checklevel,
  inputdetail,
  layoutsn,
  function_name,
  is_enabled,
  businessname,
  requiredflag
) AS
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname,
Upper( datatype) AS datatype,
m.name ,
threshold,
a.sn ,
m.mas_id ,
input_type,
a.category ,
CASE when l.field_sn is NOT NULL then 'LAYOUT'  END check_level ,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE l.input_detail END AS input_detail,
lay_sn,
m.function_name,
l.is_enabled,
a.businessname,
Nvl(l.requiredflag,'N') AS requiredflag
FROM
(SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE' ) a
left JOIN
(SELECT * FROM dp_layouts_configuration  WHERE effective_to IS  NULL ) l
ON a.SN=l.field_sn
left join  dp_checks_master   m
ON  l.mas_id=m.mas_id
UNION
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname    ,
Upper( datatype) AS datatype,
c.name ,
c.SYS_DFLT_THRSHLD,
a.sn ,
c.MAS_ID ,
'DEFAULT' input_type ,
c.category_name,
'DEFAULT' check_level,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE NULL END AS input_detail,
NULL lay_sn,
c.function_name,
c.is_enabled AS is_enabled ,
a.businessname,
'N' AS requiredFlag
FROM
(SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
 JOIN
 (
      select  c.cat_sn,c.category_name  ,cl.default_flag, m.name,m.mas_id,  m.sys_dflt_thrshld,m.function_name,m.is_enabled
      FROM dp_check_categories c
      JOIN dp_catgry_chk_list cl
      ON c.CAT_SN=cl.CAT_SN
      JOIN dp_checks_master m
      ON cl.mas_id=m.mas_id
      where is_enabled=1 AND  cl.default_flag=1
)  c
ON   a.category=c.CATEGORY_NAME
/

GRANT SELECT ON dp_dashboard_layout_config TO public;

PROMPT CREATE OR REPLACE VIEW dp_dashboard_pattern_config
CREATE OR REPLACE VIEW dp_dashboard_pattern_config (
  layoutid,
  sublayoutid,
  columnid,
  columnname,
  datatype,
  checkname,
  threshold,
  fieldsn,
  checkid,
  inputtype,
  category,
  checklevel,
  inputdetail,
  configsn,
  clientid,
  function_name,
  is_enabled,
  pattern_sn,
  businessname,
  requiredflag
) AS
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname,
Upper( datatype) AS datatype,
m.name ,
threshold,
a.sn ,
m.mas_id ,
input_type,
a.category ,
check_level    ,
CASE WHEN Upper(a.category) ='DATE' AND l.isoverridden='Y' THEN l.overriddendate  ELSE l.input_detail END AS input_detail,
l.configsn AS configsn  ,
l.client_id clientid,
m.function_name,
l.is_enabled,
pattern_sn,
a.businessname,
Nvl(requiredflag,'N') AS requiredFlag
FROM
( SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
left JOIN
(
SELECT
 coalesce(pp.pat_sn,cc.cli_sn,ll.lay_sn) AS configsn ,
 coalesce(pp.mas_id,cc.mas_id,ll.mas_id) AS  mas_id ,
 coalesce(pp.field_sn,cc.field_sn,ll.field_sn) AS  field_sn,
 coalesce(pp.threshold,cc.threshold,ll.threshold) AS threshold,
 coalesce(pp.input_type,cc.INPUT_TYPE,ll.INPUT_TYPE) AS INPUT_TYPE,
 coalesce(pp.input_detail,cc.INPUT_DETAIL,ll.INPUT_DETAIL) AS INPUT_DETAIL,
 coalesce(pp.layoutid,cc.layoutid,ll.layoutid) AS layoutid   ,
 coalesce(cc.client_id,pp.client_id) AS client_id ,
 CASE WHEN   pp.pat_sn IS NOT NULL THEN 'PATTERN'
      WHEN   cc.cli_sn IS NOT NULL THEN 'CLIENT'
      WHEN   ll.lay_sn IS NOT NULL  THEN 'LAYOUT' END  AS check_level ,
 coalesce(pp.IS_ENABLED,cc.IS_ENABLED,ll.IS_ENABLED) AS is_enabled ,
 pp.pattern_sn ,
 pp.isoverridden,
 pp.overriddendate,
 coalesce(pp.requiredflag,cc.requiredflag,ll.requiredflag) AS requiredflag
FROM
        ( SELECT * FROM dp_layouts_configuration WHERE  effective_to IS null) ll
     full outer JOIN
         (SELECT * FROM dp_clients_configuration WHERE  effective_to IS  null  ) cc
      ON ll.mas_id=cc.mas_id   AND ll.FIELD_SN=cc.FIELD_SN
     full OUTER join
      (SELECT a.*,b.isoverridden,b.overriddendate
         FROM dp_patterns_configuration a JOIN imp_clientpatterns  b
          ON a.pattern_sn=b.sn AND a.client_id=b.clientid  AND a.layoutid=b.layoutid WHERE  effective_to IS  null  ) pp
    ON  cc.mas_id=pp.mas_id AND cc.field_sn=pp.field_sn AND cc.client_id=pp.client_id
) l
ON a.SN=l.field_sn
left join  dp_checks_master   m
ON  l.mas_id=m.mas_id
UNION
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname    ,
Upper( datatype) AS datatype,
c.name ,
c.SYS_DFLT_THRSHLD,
a.sn ,
c.MAS_ID ,
'DEFAULT' input_type ,
c.category_name,
'DEFAULT' check_level,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE NULL END AS input_detail,
NULL configsn  ,
NULL clientid,
c.function_name,
NULL AS is_enabled,
NULL AS pattern_sn,
a.businessname,
'N' AS requiredflag
FROM
( SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
 JOIN
 (
      select  c.cat_sn,c.category_name  ,cl.default_flag, m.name,m.mas_id,  m.sys_dflt_thrshld,m.function_name
      FROM dp_check_categories c
      JOIN dp_catgry_chk_list cl
      ON c.CAT_SN=cl.CAT_SN
      JOIN dp_checks_master m
      ON cl.mas_id=m.mas_id
      where is_enabled=1  AND cl.default_flag=1
)  c
ON   a.category=c.CATEGORY_NAME
/

GRANT SELECT ON dp_dashboard_pattern_config TO public;

PROMPT CREATE OR REPLACE VIEW dp_dashboard_report_display
CREATE OR REPLACE VIEW dp_dashboard_report_display (
  fileid,
  dmfileid,
  filename,
  payor,
  layoutid,
  clientid,
  clientname,
  reportlocation,
  empgrp,
  importeddate,
  filedate,
  dpstatus,
  reportstatus,
  approvedstatus,
  patternsn,
  reportsn,
  datatype,
  releaseno,
  approvedby,
  approveddate,
  startdate,
  enddate,
  exceptionremark
) AS
SELECT
a.fileid ,
a.dmfileid,
b.filename,
c.payor,
b.layoutid,
b.clientid,
d.clientname,
e.report_location AS reportlocation,
b.empgrp,
To_Date(endtime,'YYYY-MM-DD HH24:MI:SS') AS importeddate,
 filedate,
case when current_status= 'COMPLETED SUCCESSFULLY' and
OVERALL_PROFILING_STATUS ='FILE CHECKS FAILED'
then 'FAILED' WHEN current_status='EXCEPTION' THEN 'EXCEPTION'
WHEN current_status='RUNNING' THEN 'RUNNING' 
WHEN OVERALL_PROFILING_STATUS='ALL CHECKS PASSED (WITH NO CHECKS)' THEN 'PASSED(WITH NO CHECKS)' else 'PASSED' end AS dpstatus,
e.report_status AS reportstatus,
e.approval_status AS approvedstatus  ,
b.pattern_sn AS patternsn ,
e.sn AS reportsn,
b.datatype,
cm.release_number releaseno,
e.approved_by AS approvedby,
e.approved_date AS approveddate,
a.start_time AS startdate,
a.end_time AS enddate,
b.exception_remark AS exceptionremark
FROM
(SELECT  * FROM dp_rpt_main_log  WHERE log_sn IN (SELECT Max(log_sn) FROM dp_rpt_main_log GROUP BY fileid) ) a
left JOIN
(SELECT fileid, To_Date(file_date,'YYYY-MM-DD HH24:MI:SS')  AS filedate , layoutid , datatype, clientid, dmfileid , endtime,pattern_sn,empgrp,filename,exception_remark  FROM imp_main_log) b
ON a.fileid=b.fileid
left JOIN imp_layouts c
ON b.layoutid=c.layoutid
left JOIN hawkeyemaster.m_clients  d
ON b.clientid=d.clientid
left JOIN dp_profiler_report   e
ON  a.fileid=e.fileid
AND a.log_sn=e.sn
left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON b.clientid=cm.clientid
                AND b.filedate >=  cm.data_start_date  AND  b.filedate <= cm.data_end_date
ORDER BY endtime desc
/

