 /*
 ALTER TABLE imp_layouts ADD (
 ICD10FLAG VARCHAR2(5)
 );

 
ALTER TABLE imp_layouts_fields ADD (
CATEGORY VARCHAR2(200),
BUSINESSNAME VARCHAR2(100)
);

--*/


PROMPT =========================================================================
PROMPT TABLE DEFINITIONS
PROMPT =========================================================================

PROMPT CREATE TABLE dp_rpt_results
CREATE TABLE dp_rpt_results (
  det_sn         NUMBER         NOT NULL,
  invalid_value  VARCHAR2(2000) NULL,
  invalid_reason VARCHAR2(100)  NULL,
  invalid_count  NUMBER         NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_rpt_main_log
CREATE TABLE dp_rpt_main_log (
  log_sn                   NUMBER        NOT NULL,
  fileid                   VARCHAR2(20)  NOT NULL,
  dmfileid                 VARCHAR2(100) NULL,
  start_time               DATE          NULL,
  end_time                 DATE          NULL,
  current_status           VARCHAR2(100) NULL,
  oracle_error_message     VARCHAR2(400) NULL,
  exceptions_remarks       VARCHAR2(100) NULL,
  overall_profiling_status VARCHAR2(100) NULL,
  layoutid                 NUMBER        NULL,
  clientid                 VARCHAR2(20)  NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_rpt_detail_log
CREATE TABLE dp_rpt_detail_log (
  det_sn               NUMBER        NOT NULL,
  mas_id               NUMBER        NOT NULL,
  log_sn               NUMBER        NOT NULL,
  sublayoutid          NUMBER        NULL,
  field_name           VARCHAR2(100) NULL,
  field_sn             NUMBER        NULL,
  check_name           VARCHAR2(100) NULL,
  required_flag        VARCHAR2(1)   NULL,
  check_level          VARCHAR2(100) NULL,
  check_status         VARCHAR2(100) NULL,
  start_time           DATE          NULL,
  end_time             DATE          NULL,
  chk_remarks          VARCHAR2(100) NULL,
  oracle_error_message VARCHAR2(400) NULL,
  total_record         NUMBER        NULL,
  invalid_percentage   NUMBER        NULL,
  threshold            NUMBER        NULL,
  total_invalid        NUMBER        NULL,
  null_count           NUMBER        NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_profiler_report
CREATE TABLE dp_profiler_report (
  sn              NUMBER         NOT NULL,
  fileid          VARCHAR2(20)   NULL,
  dmfileid        VARCHAR2(20)   NULL,
  report_status   VARCHAR2(100)  NULL,
  report_location VARCHAR2(2000) NULL,
  approval_status VARCHAR2(100)  NULL,
  approved_by     VARCHAR2(200)  NULL,
  approved_date   DATE           NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_patterns_configuration
CREATE TABLE dp_patterns_configuration (
  pat_sn         NUMBER        NOT NULL,
  mas_id         NUMBER        NOT NULL,
  field_sn       NUMBER        NOT NULL,
  pattern_sn     NUMBER        NOT NULL,
  client_id      VARCHAR2(10)  NOT NULL,
  is_enabled     NUMBER        NULL,
  user_log       VARCHAR2(100) NULL,
  date_created   DATE          NULL,
  effective_from DATE          NOT NULL,
  effective_to   DATE          NULL,
  updated_by     VARCHAR2(100) NULL,
  input_type     VARCHAR2(100) NULL,
  threshold      NUMBER        NULL,
  layoutid       VARCHAR2(100) NULL,
  input_detail   VARCHAR2(100) NULL,
  requiredflag   VARCHAR2(1)   NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_pat_values
CREATE TABLE dp_pat_values (
  sn             NUMBER        NOT NULL,
  pat_sn         NUMBER        NOT NULL,
  value_list     VARCHAR2(100) NULL,
  created_date   DATE          NULL,
  created_by     VARCHAR2(100) NULL,
  updated_by     VARCHAR2(100) NULL,
  effective_from DATE          NOT NULL,
  effective_to   DATE          NULL,
  is_active      VARCHAR2(100) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_master_input_types
CREATE TABLE dp_master_input_types (
  sn         NUMBER       NULL,
  mas_id     NUMBER       NULL,
  input_type VARCHAR2(50) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_layouts_configuration
CREATE TABLE dp_layouts_configuration (
  lay_sn         NUMBER        NOT NULL,
  mas_id         NUMBER        NOT NULL,
  field_sn       NUMBER        NOT NULL,
  layoutid       VARCHAR2(100) NOT NULL,
  is_enabled     NUMBER        NULL,
  user_log       VARCHAR2(100) NULL,
  date_created   DATE          NULL,
  effective_from DATE          NOT NULL,
  effective_to   DATE          NULL,
  updated_by     VARCHAR2(100) NULL,
  input_type     VARCHAR2(100) NULL,
  threshold      NUMBER        NULL,
  input_detail   VARCHAR2(100) NULL,
  requiredflag   VARCHAR2(1)   NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_layout_values
CREATE TABLE dp_layout_values (
  sn             NUMBER        NOT NULL,
  lay_sn         NUMBER        NOT NULL,
  value_list     VARCHAR2(100) NULL,
  created_date   DATE          NULL,
  created_by     VARCHAR2(100) NULL,
  updated_by     VARCHAR2(100) NULL,
  effective_from DATE          NOT NULL,
  effective_to   DATE          NULL,
  is_active      VARCHAR2(100) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_error_codes
CREATE TABLE dp_error_codes (
  error_sn      NUMBER        NOT NULL,
  error_code    VARCHAR2(100) NOT NULL,
  error_message VARCHAR2(400) NOT NULL
)
/



PROMPT CREATE TABLE dp_clients_configuration
CREATE TABLE dp_clients_configuration (
  cli_sn         NUMBER        NOT NULL,
  mas_id         NUMBER        NOT NULL,
  field_sn       NUMBER        NULL,
  client_id      VARCHAR2(100) NULL,
  is_enabled     NUMBER        NULL,
  user_log       VARCHAR2(100) NULL,
  date_created   DATE          NULL,
  effective_from DATE          NOT NULL,
  effective_to   DATE          NULL,
  updated_by     VARCHAR2(100) NULL,
  input_type     VARCHAR2(100) NULL,
  threshold      NUMBER        NULL,
  layoutid       VARCHAR2(100) NULL,
  input_detail   VARCHAR2(100) NULL,
  requiredflag   VARCHAR2(1)   NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_client_values
CREATE TABLE dp_client_values (
  sn             NUMBER        NOT NULL,
  cli_sn         NUMBER        NOT NULL,
  value_list     VARCHAR2(100) NULL,
  created_date   DATE          NULL,
  created_by     VARCHAR2(100) NULL,
  updated_by     VARCHAR2(100) NULL,
  effective_from DATE          NOT NULL,
  effective_to   DATE          NULL,
  is_active      VARCHAR2(100) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_checks_master
CREATE TABLE dp_checks_master (
  mas_id            NUMBER        NOT NULL,
  name              VARCHAR2(255) NOT NULL,
  function_name     VARCHAR2(50)  NOT NULL,
  sys_dflt_thrshld  NUMBER        NULL,
  is_enabled        NUMBER        NULL,
  date_created      DATE          NULL,
  effective_from    DATE          NOT NULL,
  effective_to      DATE          NULL,
  updated_by        VARCHAR2(100) NULL,
  short_description VARCHAR2(150) NULL,
  long_description  VARCHAR2(500) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_check_categories
CREATE TABLE dp_check_categories (
  cat_sn        NUMBER        NOT NULL,
  category_name VARCHAR2(100) NOT NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_catgry_chk_list
CREATE TABLE dp_catgry_chk_list (
  lis_sn       NUMBER  NOT NULL,
  mas_id       NUMBER  NOT NULL,
  cat_sn       NUMBER  NOT NULL,
  default_flag INTEGER NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT =========================================================================
PROMPT CHECK CONSTRAINTS
PROMPT =========================================================================

PROMPT ALTER TABLE dp_master_input_types ADD CONSTRAINT check_input_type CHECK
ALTER TABLE dp_master_input_types
  ADD CONSTRAINT check_input_type CHECK (
    INPUT_TYPE IN ('RANGE','NOT EQUAL','EQUAL','LIST','DEFAULT',null)
  )
/

PROMPT =========================================================================
PROMPT PRIMARY AND UNIQUE CONSTRAINTS
PROMPT =========================================================================

PROMPT ALTER TABLE dp_rpt_main_log ADD PRIMARY KEY
ALTER TABLE dp_rpt_main_log
  ADD PRIMARY KEY (
    log_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_rpt_detail_log ADD PRIMARY KEY
ALTER TABLE dp_rpt_detail_log
  ADD PRIMARY KEY (
    det_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_profiler_report ADD PRIMARY KEY
ALTER TABLE dp_profiler_report
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_patterns_configuration ADD PRIMARY KEY
ALTER TABLE dp_patterns_configuration
  ADD PRIMARY KEY (
    pat_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_pat_values ADD PRIMARY KEY
ALTER TABLE dp_pat_values
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_pat_values ADD CONSTRAINT pattern_values_unique UNIQUE
ALTER TABLE dp_pat_values
  ADD CONSTRAINT pattern_values_unique UNIQUE (
    pat_sn,
    value_list
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_layouts_configuration ADD PRIMARY KEY
ALTER TABLE dp_layouts_configuration
  ADD PRIMARY KEY (
    lay_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_layout_values ADD PRIMARY KEY
ALTER TABLE dp_layout_values
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_layout_values ADD CONSTRAINT layout_values_unique UNIQUE
ALTER TABLE dp_layout_values
  ADD CONSTRAINT layout_values_unique UNIQUE (
    lay_sn,
    value_list
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_error_codes ADD PRIMARY KEY
ALTER TABLE dp_error_codes
  ADD PRIMARY KEY (
    error_sn
  )
/

PROMPT ALTER TABLE dp_clients_configuration ADD PRIMARY KEY
ALTER TABLE dp_clients_configuration
  ADD PRIMARY KEY (
    cli_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_client_values ADD PRIMARY KEY
ALTER TABLE dp_client_values
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_client_values ADD CONSTRAINT client_values_unique UNIQUE
ALTER TABLE dp_client_values
  ADD CONSTRAINT client_values_unique UNIQUE (
    cli_sn,
    value_list
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_checks_master ADD PRIMARY KEY
ALTER TABLE dp_checks_master
  ADD PRIMARY KEY (
    mas_id
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_check_categories ADD PRIMARY KEY
ALTER TABLE dp_check_categories
  ADD PRIMARY KEY (
    cat_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_catgry_chk_list ADD PRIMARY KEY
ALTER TABLE dp_catgry_chk_list
  ADD PRIMARY KEY (
    lis_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT =========================================================================
PROMPT FOREIGN CONSTRAINTS
PROMPT =========================================================================

PROMPT ALTER TABLE dp_rpt_results ADD CONSTRAINT fk_details_results FOREIGN KEY
ALTER TABLE dp_rpt_results
  ADD CONSTRAINT fk_details_results FOREIGN KEY (
    det_sn
  ) REFERENCES dp_rpt_detail_log (
    det_sn
  )
/

PROMPT ALTER TABLE dp_rpt_detail_log ADD CONSTRAINT fk_chkmstr_detail_log FOREIGN KEY
ALTER TABLE dp_rpt_detail_log
  ADD CONSTRAINT fk_chkmstr_detail_log FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_rpt_detail_log ADD CONSTRAINT fk_main_detail_log FOREIGN KEY
ALTER TABLE dp_rpt_detail_log
  ADD CONSTRAINT fk_main_detail_log FOREIGN KEY (
    log_sn
  ) REFERENCES dp_rpt_main_log (
    log_sn
  )
/

PROMPT ALTER TABLE dp_patterns_configuration ADD CONSTRAINT fk_master_pattern FOREIGN KEY
ALTER TABLE dp_patterns_configuration
  ADD CONSTRAINT fk_master_pattern FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_master_input_types ADD CONSTRAINT fk_mas_id FOREIGN KEY
ALTER TABLE dp_master_input_types
  ADD CONSTRAINT fk_mas_id FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_layouts_configuration ADD CONSTRAINT fk_master_layout FOREIGN KEY
ALTER TABLE dp_layouts_configuration
  ADD CONSTRAINT fk_master_layout FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_layout_values ADD CONSTRAINT fk_layout_values FOREIGN KEY
ALTER TABLE dp_layout_values
  ADD CONSTRAINT fk_layout_values FOREIGN KEY (
    lay_sn
  ) REFERENCES dp_layouts_configuration (
    lay_sn
  )
/

PROMPT ALTER TABLE dp_clients_configuration ADD CONSTRAINT fk_master_client FOREIGN KEY
ALTER TABLE dp_clients_configuration
  ADD CONSTRAINT fk_master_client FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_client_values ADD CONSTRAINT fk_client_value FOREIGN KEY
ALTER TABLE dp_client_values
  ADD CONSTRAINT fk_client_value FOREIGN KEY (
    cli_sn
  ) REFERENCES dp_clients_configuration (
    cli_sn
  )
/

PROMPT ALTER TABLE dp_catgry_chk_list ADD CONSTRAINT fk_cetgry_sn FOREIGN KEY
ALTER TABLE dp_catgry_chk_list
  ADD CONSTRAINT fk_cetgry_sn FOREIGN KEY (
    cat_sn
  ) REFERENCES dp_check_categories (
    cat_sn
  )
/

PROMPT ALTER TABLE dp_catgry_chk_list ADD CONSTRAINT fk_master_id FOREIGN KEY
ALTER TABLE dp_catgry_chk_list
  ADD CONSTRAINT fk_master_id FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/
PROMPT =========================================================================
PROMPT SEQUENCES
PROMPT =========================================================================

PROMPT CREATE SEQUENCE dp_catgry_chk_list_seq
CREATE SEQUENCE dp_catgry_chk_list_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_check_categories_seq
CREATE SEQUENCE dp_check_categories_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_checks_master_seq
CREATE SEQUENCE dp_checks_master_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_cli_config_seq
CREATE SEQUENCE dp_cli_config_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_cli_values_seq
CREATE SEQUENCE dp_cli_values_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_error_codes_seq
CREATE SEQUENCE dp_error_codes_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_input_types_sn_seq
CREATE SEQUENCE dp_input_types_sn_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_lay_config_seq
CREATE SEQUENCE dp_lay_config_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_lay_values_seq
CREATE SEQUENCE dp_lay_values_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_pat_config_seq
CREATE SEQUENCE dp_pat_config_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_pat_values_seq
CREATE SEQUENCE dp_pat_values_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/


PROMPT CREATE SEQUENCE dp_rpt_detail_log_seq
CREATE SEQUENCE dp_rpt_detail_log_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/

GRANT ALTER,SELECT ON dp_rpt_detail_log_seq TO tempimport;

PROMPT CREATE SEQUENCE dp_rpt_main_log_seq
CREATE SEQUENCE dp_rpt_main_log_seq
  MINVALUE 1
  MAXVALUE 9999999999
  INCREMENT BY 1
  NOCYCLE
  ORDER
  NOCACHE
/

GRANT ALTER,SELECT ON dp_rpt_main_log_seq TO tempimport;




PROMPT =========================================================================
PROMPT TRIGGERS
PROMPT =========================================================================
/*
PROMPT CREATE OR REPLACE TRIGGER trig_dp_rpt_main_log
CREATE OR REPLACE TRIGGER trig_dp_rpt_main_log BEFORE INSERT ON dp_rpt_main_log FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_RPT_MAIN_LOG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LOG_SN:=SN; END;
/
*/
/*
PROMPT CREATE OR REPLACE TRIGGER trig_dp_rpt_detail_log_seq
CREATE OR REPLACE TRIGGER trig_dp_rpt_detail_log_seq BEFORE INSERT ON dp_rpt_detail_log FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_RPT_DETAIL_LOG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LOG_SN:=SN; END;
/
*/
/*
PROMPT CREATE OR REPLACE TRIGGER trig_dp_pat_config
CREATE OR REPLACE TRIGGER trig_dp_pat_config BEFORE INSERT ON dp_patterns_configuration FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_PAT_CONFIG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.PAT_SN:=SN; END;
/
*/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_pat_values
CREATE OR REPLACE TRIGGER trig_dp_pat_values BEFORE INSERT ON dp_pat_values FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_PAT_VALUES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_master_input_types
CREATE OR REPLACE TRIGGER trig_dp_master_input_types BEFORE INSERT ON dp_master_input_types FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_INPUT_TYPES_SN_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/
/*
PROMPT CREATE OR REPLACE TRIGGER trig_dp_lay_config
CREATE OR REPLACE TRIGGER trig_dp_lay_config BEFORE INSERT ON dp_layouts_configuration FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_LAY_CONFIG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LAY_SN:=SN; END;
/
*/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_lay_values
CREATE OR REPLACE TRIGGER trig_dp_lay_values BEFORE INSERT ON dp_layout_values FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_LAY_VALUES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_error_codes
CREATE OR REPLACE TRIGGER trig_dp_error_codes BEFORE INSERT ON dp_error_codes FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_ERROR_CODES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.ERROR_SN:=SN; END;
/
/*
PROMPT CREATE OR REPLACE TRIGGER trig_dp_cli_config
CREATE OR REPLACE TRIGGER trig_dp_cli_config BEFORE INSERT ON dp_clients_configuration FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CLI_CONFIG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.CLI_SN:=SN; END;
/
*/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_cli_values
CREATE OR REPLACE TRIGGER trig_dp_cli_values BEFORE INSERT ON dp_client_values FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CLI_VALUES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_checks_master
CREATE OR REPLACE TRIGGER trig_dp_checks_master BEFORE INSERT ON dp_checks_master FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CHECKS_MASTER_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.MAS_ID:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_check_categories
CREATE OR REPLACE TRIGGER trig_dp_check_categories BEFORE INSERT ON dp_check_categories FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CHECK_CATEGORIES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.CAT_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_catgry_chk_list
CREATE OR REPLACE TRIGGER trig_dp_catgry_chk_list BEFORE INSERT ON dp_catgry_chk_list FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CATGRY_CHK_LIST_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LIS_SN:=SN; END;
/

PROMPT =========================================================================
PROMPT GRANTS
PROMPT =========================================================================

GRANT ALTER,DEBUG,DELETE,FLASHBACK,INDEX,INSERT,ON COMMIT REFRESH,QUERY REWRITE,REFERENCES,SELECT,UPDATE ON dp_rpt_results TO tempimport;
GRANT ALTER,DEBUG,DELETE,FLASHBACK,INDEX,INSERT,ON COMMIT REFRESH,QUERY REWRITE,REFERENCES,SELECT,UPDATE ON dp_rpt_main_log TO tempimport;
GRANT ALTER,DEBUG,DELETE,FLASHBACK,INDEX,INSERT,ON COMMIT REFRESH,QUERY REWRITE,REFERENCES,SELECT,UPDATE ON dp_rpt_detail_log TO tempimport;
/*
GRANT SELECT ON dp_pat_values TO public;
GRANT SELECT ON dp_layout_values TO public;
GRANT SELECT ON dp_client_values TO public;
*/


--------------------------------------------VIEWS---------------------------------------------------
PROMPT CREATE OR REPLACE VIEW dp_dashboard_client_config
CREATE OR REPLACE VIEW dp_dashboard_client_config (
  layoutid,
  sublayoutid,
  columnid,
  columnname,
  datatype,
  checkname,
  threshold,
  fieldsn,
  checkid,
  inputtype,
  category,
  checklevel,
  inputdetail,
  configsn,
  clientid,
  function_name,
  is_enabled,
  businessname,
  requiredflag
) AS
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname,
Upper( datatype) AS datatype,
m.name ,
threshold,
a.sn ,
m.mas_id ,
input_type,
a.category ,
check_level    ,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE l.input_detail END AS input_detail,
l.configsn AS configsn  ,
l.client_id clientid,
m.function_name,
l.is_enabled,
a.businessname,
Nvl(l.requiredFlag,'N') AS requiredflag
FROM
(SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
left JOIN
(
SELECT
 Nvl(cc.cli_sn,ll.lay_sn) AS configsn ,
 Nvl(cc.mas_id,ll.mas_id) AS  mas_id ,
 Nvl(cc.field_sn,ll.field_sn) AS  field_sn,
 Nvl(cc.threshold,ll.threshold) AS threshold,
 Nvl(cc.INPUT_TYPE,ll.INPUT_TYPE) AS INPUT_TYPE,
 Nvl(cc.INPUT_DETAIL,ll.INPUT_DETAIL) AS INPUT_DETAIL,
 Nvl(cc.layoutid,ll.layoutid) AS layoutid   ,
 cc.client_id ,
 CASE WHEN   cc.cli_sn IS NOT NULL THEN 'CLIENT'
      WHEN   ll.lay_sn IS NOT NULL  THEN 'LAYOUT' END  AS check_level ,
 Nvl(cc.IS_ENABLED,ll.IS_ENABLED) AS is_enabled,
 Nvl(cc.requiredflag,ll.requiredflag) AS requiredFlag
FROM
     ( SELECT * FROM dp_layouts_configuration WHERE   effective_to IS  null) ll
     full outer JOIN
      (SELECT * FROM dp_clients_configuration WHERE   effective_to IS  null  ) cc
      ON ll.mas_id=cc.mas_id   AND ll.FIELD_SN=cc.FIELD_SN
) l
ON a.SN=l.field_sn
left join  dp_checks_master   m
ON  l.mas_id=m.mas_id
UNION
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname    ,
Upper( datatype) AS datatype,
c.name ,
c.SYS_DFLT_THRSHLD,
a.sn ,
c.MAS_ID ,
'DEFAULT' input_type ,
c.category_name,
'DEFAULT' check_level,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE NULL END AS input_detail,
NULL configsn  ,
NULL clientid,
c.function_name,
1 AS is_enabled,
a.businessname,
'N' AS requiredflag
FROM
( SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
 JOIN
 (
      select  c.cat_sn,c.category_name  ,cl.default_flag, m.name,m.mas_id,  m.sys_dflt_thrshld,m.function_name
      FROM dp_check_categories c
      JOIN dp_catgry_chk_list cl
      ON c.CAT_SN=cl.CAT_SN
      JOIN dp_checks_master m
      ON cl.mas_id=m.mas_id
      where is_enabled=1 AND  cl.default_flag=1
)  c
ON   a.category=c.CATEGORY_NAME
/

GRANT SELECT ON dp_dashboard_client_config TO public;

PROMPT CREATE OR REPLACE VIEW dp_dashboard_layout_config
CREATE OR REPLACE VIEW dp_dashboard_layout_config (
  layoutid,
  sublayoutid,
  columnid,
  columnname,
  datatype,
  checkname,
  threshold,
  fieldsn,
  checkid,
  inputtype,
  category,
  checklevel,
  inputdetail,
  layoutsn,
  function_name,
  is_enabled,
  businessname,
  requiredflag
) AS
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname,
Upper( datatype) AS datatype,
m.name ,
threshold,
a.sn ,
m.mas_id ,
input_type,
a.category ,
CASE when l.field_sn is NOT NULL then 'LAYOUT'  END check_level ,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE l.input_detail END AS input_detail,
lay_sn,
m.function_name,
l.is_enabled,
a.businessname,
Nvl(l.requiredflag,'N') AS requiredflag
FROM
(SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE' ) a
left JOIN
(SELECT * FROM dp_layouts_configuration  WHERE effective_to IS  NULL ) l
ON a.SN=l.field_sn
left join  dp_checks_master   m
ON  l.mas_id=m.mas_id
UNION
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname    ,
Upper( datatype) AS datatype,
c.name ,
c.SYS_DFLT_THRSHLD,
a.sn ,
c.MAS_ID ,
'DEFAULT' input_type ,
c.category_name,
'DEFAULT' check_level,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE NULL END AS input_detail,
NULL lay_sn,
c.function_name,
c.is_enabled AS is_enabled ,
a.businessname,
'N' AS requiredFlag
FROM
(SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
 JOIN
 (
      select  c.cat_sn,c.category_name  ,cl.default_flag, m.name,m.mas_id,  m.sys_dflt_thrshld,m.function_name,m.is_enabled
      FROM dp_check_categories c
      JOIN dp_catgry_chk_list cl
      ON c.CAT_SN=cl.CAT_SN
      JOIN dp_checks_master m
      ON cl.mas_id=m.mas_id
      where is_enabled=1 AND  cl.default_flag=1
)  c
ON   a.category=c.CATEGORY_NAME
/

GRANT SELECT ON dp_dashboard_layout_config TO public;

PROMPT CREATE OR REPLACE VIEW dp_dashboard_pattern_config
CREATE OR REPLACE VIEW dp_dashboard_pattern_config (
  layoutid,
  sublayoutid,
  columnid,
  columnname,
  datatype,
  checkname,
  threshold,
  fieldsn,
  checkid,
  inputtype,
  category,
  checklevel,
  inputdetail,
  configsn,
  clientid,
  function_name,
  is_enabled,
  pattern_sn,
  businessname,
  requiredflag
) AS
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname,
Upper( datatype) AS datatype,
m.name ,
threshold,
a.sn ,
m.mas_id ,
input_type,
a.category ,
check_level    ,
CASE WHEN Upper(a.category) ='DATE' AND l.isoverridden='Y' THEN l.overriddendate  ELSE l.input_detail END AS input_detail,
l.configsn AS configsn  ,
l.client_id clientid,
m.function_name,
l.is_enabled,
pattern_sn,
a.businessname,
Nvl(requiredflag,'N') AS requiredFlag
FROM
( SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
left JOIN
(
SELECT
 coalesce(pp.pat_sn,cc.cli_sn,ll.lay_sn) AS configsn ,
 coalesce(pp.mas_id,cc.mas_id,ll.mas_id) AS  mas_id ,
 coalesce(pp.field_sn,cc.field_sn,ll.field_sn) AS  field_sn,
 coalesce(pp.threshold,cc.threshold,ll.threshold) AS threshold,
 coalesce(pp.input_type,cc.INPUT_TYPE,ll.INPUT_TYPE) AS INPUT_TYPE,
 coalesce(pp.input_detail,cc.INPUT_DETAIL,ll.INPUT_DETAIL) AS INPUT_DETAIL,
 coalesce(pp.layoutid,cc.layoutid,ll.layoutid) AS layoutid   ,
 coalesce(cc.client_id,pp.client_id) AS client_id ,
 CASE WHEN   pp.pat_sn IS NOT NULL THEN 'PATTERN'
      WHEN   cc.cli_sn IS NOT NULL THEN 'CLIENT'
      WHEN   ll.lay_sn IS NOT NULL  THEN 'LAYOUT' END  AS check_level ,
 coalesce(pp.IS_ENABLED,cc.IS_ENABLED,ll.IS_ENABLED) AS is_enabled ,
 pp.pattern_sn ,
 pp.isoverridden,
 pp.overriddendate,
 coalesce(pp.requiredflag,cc.requiredflag,ll.requiredflag) AS requiredflag
FROM
        ( SELECT * FROM dp_layouts_configuration WHERE  effective_to IS null) ll
     full outer JOIN
         (SELECT * FROM dp_clients_configuration WHERE  effective_to IS  null  ) cc
      ON ll.mas_id=cc.mas_id   AND ll.FIELD_SN=cc.FIELD_SN
     full OUTER join
      (SELECT a.*,b.isoverridden,b.overriddendate
         FROM dp_patterns_configuration a JOIN imp_clientpatterns  b
          ON a.pattern_sn=b.sn AND a.client_id=b.clientid  AND a.layoutid=b.layoutid WHERE  effective_to IS  null  ) pp
    ON  cc.mas_id=pp.mas_id AND cc.field_sn=pp.field_sn AND cc.client_id=pp.client_id
) l
ON a.SN=l.field_sn
left join  dp_checks_master   m
ON  l.mas_id=m.mas_id
UNION
SELECT
a.layoutid  ,
sublayoutid ,
columnid    ,
columnname    ,
Upper( datatype) AS datatype,
c.name ,
c.SYS_DFLT_THRSHLD,
a.sn ,
c.MAS_ID ,
'DEFAULT' input_type ,
c.category_name,
'DEFAULT' check_level,
CASE WHEN a.category ='DATE' THEN a.datetypedetial ELSE NULL END AS input_detail,
NULL configsn  ,
NULL clientid,
c.function_name,
NULL AS is_enabled,
NULL AS pattern_sn,
a.businessname,
'N' AS requiredflag
FROM
( SELECT a.layoutid, a.sublayoutid, a.columnid, a.columnname, a.datatype, a.datetypedetial, a.fieldlength, a.sn,
   Upper(a.category) AS   category, a.businessname
  FROM imp_layouts_fields  a JOIN imp_sub_layouts b ON a.layoutid=b.layoutid AND a.sublayoutid=b.sublayoutid AND SUBLAYOUTDESC='DATAFILE') a
 JOIN
 (
      select  c.cat_sn,c.category_name  ,cl.default_flag, m.name,m.mas_id,  m.sys_dflt_thrshld,m.function_name
      FROM dp_check_categories c
      JOIN dp_catgry_chk_list cl
      ON c.CAT_SN=cl.CAT_SN
      JOIN dp_checks_master m
      ON cl.mas_id=m.mas_id
      where is_enabled=1  AND cl.default_flag=1
)  c
ON   a.category=c.CATEGORY_NAME
/

GRANT SELECT ON dp_dashboard_pattern_config TO public;

PROMPT CREATE OR REPLACE VIEW dp_dashboard_report_display
CREATE OR REPLACE VIEW dp_dashboard_report_display (
  fileid,
  dmfileid,
  filename,
  payor,
  layoutid,
  clientid,
  clientname,
  reportlocation,
  empgrp,
  importeddate,
  filedate,
  dpstatus,
  reportstatus,
  approvedstatus,
  patternsn,
  reportsn,
  datatype,
  releaseno,
  approvedby,
  approveddate
) AS
SELECT
a.fileid ,
a.dmfileid,
b.filename,
c.payor,
b.layoutid,
b.clientid,
d.clientname,
e.report_location AS reportlocation,
b.empgrp,
To_Date(endtime,'YYYY-MM-DD HH24:MI:SS') AS importeddate,
 filedate,
case when current_status= 'COMPLETED SUCCESSFULLY' and
OVERALL_PROFILING_STATUS ='FILE CHECKS FAILED'
then 'FAILED'  else 'PASSED' end AS dpstatus,
e.report_status AS reportstatus,
e.approval_status AS approvedstatus  ,
b.pattern_sn AS patternsn ,
e.sn AS reportsn,
b.datatype,
cm.release_number releaseno,
e.approved_by AS approvedby,
e.approved_date AS approveddate
FROM
(SELECT  * FROM dp_rpt_main_log  WHERE log_sn IN (SELECT Max(log_sn) FROM dp_rpt_main_log GROUP BY fileid) ) a
left JOIN
(SELECT fileid, To_Date(file_date,'YYYY-MM-DD HH24:MI:SS')  AS filedate , layoutid , datatype, clientid, dmfileid , endtime,pattern_sn,empgrp,filename  FROM imp_main_log) b
ON a.fileid=b.fileid
left JOIN imp_layouts c
ON b.layoutid=c.layoutid
left JOIN hawkeyemaster.m_clients  d
ON b.clientid=d.clientid
left JOIN dp_profiler_report   e
ON  a.fileid=e.fileid
AND a.log_sn=e.sn
left JOIN ( SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m  ) cm
                ON b.clientid=cm.clientid
                AND b.filedate >=  cm.data_start_date  AND  b.filedate <= cm.data_end_date
ORDER BY endtime desc
/

/* TABLE INSERTIONS */
------------------------------------------------------------------------------------------------------------------------
--------- TABLE INSERTIONS--------------------------------


-----------------------------------------------------;

Insert Into DP_CHECKS_MASTER VALUES (1,'Valid Value Check' , 'CHKVAL' , '100', '1', SYSDATE,SYSDATE,null,null,'Valid Value Check' , 'A Check to confirm that no new values are received which are not mapped in the Scrub.' );
Insert Into DP_CHECKS_MASTER VALUES (2,'Value Repeat Check' , 'CHKALNUMREPEAT' , '98', '1', SYSDATE,SYSDATE,null,null,'Value Repeat Check' , 'A Check to find any repetitive values which potentially could be deemed exceptions.  Examples:  all nines (or the same digit) for phone or ssn numbers.' );
Insert Into DP_CHECKS_MASTER VALUES (3,'Empty Check' , 'CHKNULL' , '99.5', '1', SYSDATE,SYSDATE,null,null,'Empty Check' , 'A Check to find any NULL values on the field.' );
Insert Into DP_CHECKS_MASTER VALUES (4,'Length Check' , 'CHKLEN' , '100', '1', SYSDATE,SYSDATE,null,null,'Length Check' , 'A Check to validate field contents do not exceed a specified min and max number of characters.' );
Insert Into DP_CHECKS_MASTER VALUES (5,'Format Check' , 'CHKFORMAT' , '100', '0', SYSDATE,SYSDATE,null,null,'Format Check' , 'A Check to find if the format is as expected (Numeric, Character or Date)' );
Insert Into DP_CHECKS_MASTER VALUES (6,'Date Format Check' , 'CHKDATE' , '99', '1', SYSDATE,SYSDATE,null,null,'Date Format Check' , 'A Check to confirm valid dates are populated and in synch with the time period we are receiving' );
Insert Into DP_CHECKS_MASTER VALUES (7,'ICD 9 Format Check' , 'CHKICD9DIAG' , '99.5', '1', SYSDATE,SYSDATE,null,null,'ICD 9 Format Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (8,'ICD 10 Format Check' , 'CHKICD10DIAG' , '99.5', '1', SYSDATE,SYSDATE,null,null,'ICD 10 Format Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (9,'Revenue Code Format Check' , 'CHKREVENUE' , '100', '1', SYSDATE,SYSDATE,null,null,'Revenue Code Format Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (10,'Procedure Code Check(CPT/HCPC)' , 'CHKCPT' , '100', '1', SYSDATE,SYSDATE,null,null,'Procedure Code Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (11,'ICD 9 Surgical Format Check' , 'CHKICD9SPC' , '99.5', '1', SYSDATE,SYSDATE,null,null,'ICD 9 Surgical Format Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (12,'Type of Bill Format Check' , 'CHKBILL' , '98', '1', SYSDATE,SYSDATE,null,null,'Type of Bill Format Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (13,'Place of Service Check' , 'CHKPLCOFSRVC' , '98', '1', SYSDATE,SYSDATE,null,null,'Place of Service Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (14,'DRG Code Check' , 'CHKDRG' , '100', '1', SYSDATE,SYSDATE,null,null,'Drug Code Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (15,'Discharge Code Check' , 'CHKPATDISSTAT' , '98', '1', SYSDATE,SYSDATE,null,null,'Discharge Code Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (16,'NDC Code Check' , 'CHKNDC' , '100', '1', SYSDATE,SYSDATE,null,null,'NDC Code Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (17,'Days of Supply Check' , 'CHKDAYSSUPPLY' , '95', '1', SYSDATE,SYSDATE,null,null,'Days of Supply Check' , '' );
Insert Into DP_CHECKS_MASTER VALUES (18,'NPI' , 'CHKNPI' , '100', '1', SYSDATE,SYSDATE,null,null,'NPI Code Check' , '' );
--Insert Into DP_CHECKS_MASTER VALUES (19,'VALID VALUE' , 'CHKVAL' , '100', '1', SYSDATE,SYSDATE,null,null,'Valid Value Check ' , 'A Check to confirm that no new values are received which are not mapped in the Scrub.' );
Insert Into DP_CHECKS_MASTER VALUES (19,'Numeric Check' , 'CHKISNUMERIC' , '100', '1', SYSDATE,SYSDATE,null,null,'Numeric Check ' , 'A Check to confirm whether the input is number or not' );
Insert Into DP_CHECKS_MASTER VALUES (20,'ICD 9/10 Distribution' , 'DISTICD' , null, '1', SYSDATE,SYSDATE,null,null,'ICD 9/10 DIAG Distribution' , 'Show Distribution of ICD Diag Field' );

----------------------------
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(1,'NOT EQUAL');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(1,'EQUAL');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(4,'EQUAL');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(4,'RANGE');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(1,'LIST');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(3,'DEFAULT');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(7,'DEFAULT');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(8,'DEFAULT');
INSERT INTO dp_master_input_types(mas_id,input_type) VALUES(20,'DISTRIBUTION');
---------------------------------------------------------------------------------------------------------------------------
INSERT INTO DP_CHECK_CATEGORIES VALUES('1' , 'DATE');
INSERT INTO DP_CHECK_CATEGORIES VALUES('2' , 'DIAGNOSIS');
INSERT INTO DP_CHECK_CATEGORIES VALUES('3' , 'VARCHAR2');
INSERT INTO DP_CHECK_CATEGORIES VALUES('4' , 'NUMBER');
INSERT INTO DP_CHECK_CATEGORIES VALUES('5' , 'PROCEDURE');
INSERT INTO DP_CHECK_CATEGORIES VALUES('6' , 'DRUG');
INSERT INTO DP_CHECK_CATEGORIES VALUES('7' , 'PROVIDER');
-------------------------------------------------------------------------------------------------------------------------

INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('34','2','2',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('35','3','2',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('36','4','2',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('37','5','2',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('38','6','2',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('39','7','2',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('11','1','6',1);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('12','1','3',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('13','1','5',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('14','2','7',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('15','2','8',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('16','3','1',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('17','3','4',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('18','3','5',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('19','3','3',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('20','4','1',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('23','4','9',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('24','4','10',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('25','4','11',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('26','4','12',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('27','4','13',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('28','4','14',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('29','4','15',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('30','4','16',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('31','4','17',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('32','4','18',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('33','4','19',1);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('53','3','7',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('54','3','8',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('55','3','9',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('56','3','10',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('57','3','11',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('58','3','12',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('59','3','13',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('60','3','14',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('61','3','15',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('62','3','16',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('63','3','17',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('64','3','18',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('64','2','20',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('64','3','20',null);
INSERT INTO DP_CATGRY_CHK_LIST(lis_sn,cat_sn,mas_id,default_flag) VALUES ('64','4','20',null);
 
------------------------------------------------------------------------------------------------------------------------


