PROMPT =========================================================================
PROMPT TABLE DEFINITIONS
PROMPT =========================================================================

PROMPT CREATE TABLE dp_catgry_chk_list
CREATE TABLE dp_catgry_chk_list (
  lis_sn       NUMBER  NOT NULL,
  mas_id       NUMBER  NOT NULL,
  cat_sn       NUMBER  NOT NULL,
  default_flag INTEGER NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_check_categories
CREATE TABLE dp_check_categories (
  cat_sn        NUMBER        NOT NULL,
  category_name VARCHAR2(100) NOT NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_checks_master
CREATE TABLE dp_checks_master (
  mas_id            NUMBER        NOT NULL,
  name              VARCHAR2(255) NOT NULL,
  function_name     VARCHAR2(50)  NOT NULL,
  sys_dflt_thrshld  NUMBER        NULL,
  is_enabled        NUMBER        NULL,
  date_created      DATE          NULL,
  effective_from    DATE          NOT NULL,
  effective_to      DATE          NULL,
  updated_by        VARCHAR2(100) NULL,
  short_description VARCHAR2(150) NULL,
  long_description  VARCHAR2(500) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_client_values
CREATE TABLE dp_client_values (
  sn             NUMBER        NOT NULL,
  cli_sn         NUMBER        NOT NULL,
  value_list     VARCHAR2(100) NULL,
  created_date   DATE          NULL,
  created_by     VARCHAR2(100) NULL,
  updated_by     VARCHAR2(100) NULL,
  effective_from DATE          NULL,
  effective_to   DATE          NULL,
  is_active      VARCHAR2(100) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_clients_configuration
CREATE TABLE dp_clients_configuration (
  cli_sn         NUMBER        NOT NULL,
  mas_id         NUMBER        NOT NULL,
  field_sn       NUMBER        NULL,
  client_id      VARCHAR2(100) NULL,
  is_enabled     NUMBER        NULL,
  user_log       VARCHAR2(100) NULL,
  date_created   DATE          NULL,
  effective_to   DATE          NULL,
  effective_from DATE          NULL,
  updated_by     VARCHAR2(100) NULL,
  input_type     VARCHAR2(100) NULL,
  threshold      NUMBER        NULL,
  layoutid       VARCHAR2(100) NULL,
  input_detail   VARCHAR2(100) NULL,
  requiredflag   VARCHAR2(1)   NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_error_codes
CREATE TABLE dp_error_codes (
  error_sn      NUMBER        NOT NULL,
  error_code    VARCHAR2(100) NOT NULL,
  error_message VARCHAR2(400) NOT NULL
)
/



PROMPT CREATE TABLE dp_layout_values
CREATE TABLE dp_layout_values (
  sn             NUMBER        NOT NULL,
  lay_sn         NUMBER        NOT NULL,
  value_list     VARCHAR2(100) NULL,
  created_date   DATE          NULL,
  created_by     VARCHAR2(100) NULL,
  updated_by     VARCHAR2(100) NULL,
  effective_from DATE          NULL,
  effective_to   DATE          NULL,
  is_active      VARCHAR2(100) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_layouts_configuration
CREATE TABLE dp_layouts_configuration (
  lay_sn         NUMBER        NOT NULL,
  mas_id         NUMBER        NOT NULL,
  field_sn       NUMBER        NOT NULL,
  layoutid       VARCHAR2(100) NOT NULL,
  is_enabled     NUMBER        NULL,
  user_log       VARCHAR2(100) NULL,
  date_created   DATE          NULL,
  effective_to   DATE          NULL,
  effective_from DATE          NULL,
  updated_by     VARCHAR2(100) NULL,
  input_type     VARCHAR2(100) NULL,
  threshold      NUMBER        NULL,
  input_detail   VARCHAR2(100) NULL,
  requiredflag   VARCHAR2(1)   NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_master_input_types
CREATE TABLE dp_master_input_types (
  sn         NUMBER       NULL,
  mas_id     NUMBER       NULL,
  input_type VARCHAR2(50) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_pat_values
CREATE TABLE dp_pat_values (
  sn             NUMBER        NOT NULL,
  pat_sn         NUMBER        NOT NULL,
  value_list     VARCHAR2(100) NULL,
  created_date   DATE          NULL,
  created_by     VARCHAR2(100) NULL,
  updated_by     VARCHAR2(100) NULL,
  effective_from DATE          NULL,
  effective_to   DATE          NULL,
  is_active      VARCHAR2(100) NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_patterns_configuration
CREATE TABLE dp_patterns_configuration (
  pat_sn         NUMBER        NOT NULL,
  mas_id         NUMBER        NOT NULL,
  field_sn       NUMBER        NOT NULL,
  pattern_sn     NUMBER        NOT NULL,
  client_id      VARCHAR2(10)  NOT NULL,
  is_enabled     NUMBER        NULL,
  user_log       VARCHAR2(100) NULL,
  date_created   DATE          NULL,
  effective_to   DATE          NULL,
  effective_from DATE          NULL,
  updated_by     VARCHAR2(100) NULL,
  input_type     VARCHAR2(100) NULL,
  threshold      NUMBER        NULL,
  layoutid       VARCHAR2(100) NULL,
  input_detail   VARCHAR2(100) NULL,
  requiredflag   VARCHAR2(1)   NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_profiler_report
CREATE TABLE dp_profiler_report (
  sn              NUMBER         NOT NULL,
  fileid          VARCHAR2(20)   NULL,
  dmfileid        VARCHAR2(20)   NULL,
  report_status   VARCHAR2(100)  NULL,
  report_location VARCHAR2(2000) NULL,
  approval_status VARCHAR2(100)  NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_rpt_detail_log
CREATE TABLE dp_rpt_detail_log (
  det_sn               NUMBER        NOT NULL,
  mas_id               NUMBER        NOT NULL,
  log_sn               NUMBER        NOT NULL,
  field_name           VARCHAR2(100) NULL,
  field_sn             NUMBER        NULL,
  check_name           VARCHAR2(100) NULL,
  check_status         VARCHAR2(100) NULL,
  start_time           DATE          NULL,
  end_time             DATE          NULL,
  invalid_percentage   NUMBER        NULL,
  chk_remarks          VARCHAR2(100) NULL,
  oracle_error_message VARCHAR2(400) NULL,
  sublayoutid          NUMBER        NULL,
  total_record         NUMBER        NULL,
  check_level          VARCHAR2(100) NULL,
  threshold            NUMBER        NULL,
  required_flag        VARCHAR2(1)   NULL,
  total_invalid        NUMBER        NULL,
  null_count           NUMBER        NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_rpt_main_log
CREATE TABLE dp_rpt_main_log (
  log_sn                   NUMBER        NOT NULL,
  fileid                   VARCHAR2(20)  NOT NULL,
  dmfileid                 VARCHAR2(100) NULL,
  start_time               DATE          NULL,
  end_time                 DATE          NULL,
  current_status           VARCHAR2(100) NULL,
  oracle_error_message     VARCHAR2(400) NULL,
  exceptions_remarks       VARCHAR2(100) NULL,
  overall_profiling_status VARCHAR2(100) NULL,
  layoutid                 NUMBER        NULL,
  clientid                 VARCHAR2(20)  NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT CREATE TABLE dp_rpt_results
CREATE TABLE dp_rpt_results (
  det_sn         NUMBER         NOT NULL,
  invalid_value  VARCHAR2(2000) NULL,
  invalid_reason VARCHAR2(100)  NULL,
  invalid_count  NUMBER         NULL
)
  STORAGE (
    NEXT       1024 K
  )
/



PROMPT =========================================================================
PROMPT CHECK CONSTRAINTS
PROMPT =========================================================================

PROMPT ALTER TABLE dp_master_input_types ADD CONSTRAINT check_input_type CHECK
ALTER TABLE dp_master_input_types
  ADD CONSTRAINT check_input_type CHECK (
    INPUT_TYPE IN ('RANGE','NOT EQUAL','EQUAL','LIST','DEFAULT',null)
  )
/

PROMPT =========================================================================
PROMPT PRIMARY AND UNIQUE CONSTRAINTS
PROMPT =========================================================================

PROMPT ALTER TABLE dp_catgry_chk_list ADD PRIMARY KEY
ALTER TABLE dp_catgry_chk_list
  ADD PRIMARY KEY (
    lis_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_check_categories ADD PRIMARY KEY
ALTER TABLE dp_check_categories
  ADD PRIMARY KEY (
    cat_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_checks_master ADD PRIMARY KEY
ALTER TABLE dp_checks_master
  ADD PRIMARY KEY (
    mas_id
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_client_values ADD PRIMARY KEY
ALTER TABLE dp_client_values
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_client_values ADD CONSTRAINT client_values_unique UNIQUE
ALTER TABLE dp_client_values
  ADD CONSTRAINT client_values_unique UNIQUE (
    cli_sn,
    value_list
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_clients_configuration ADD PRIMARY KEY
ALTER TABLE dp_clients_configuration
  ADD PRIMARY KEY (
    cli_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_error_codes ADD PRIMARY KEY
ALTER TABLE dp_error_codes
  ADD PRIMARY KEY (
    error_sn
  )
/

PROMPT ALTER TABLE dp_layout_values ADD PRIMARY KEY
ALTER TABLE dp_layout_values
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_layout_values ADD CONSTRAINT layout_values_unique UNIQUE
ALTER TABLE dp_layout_values
  ADD CONSTRAINT layout_values_unique UNIQUE (
    lay_sn,
    value_list
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_layouts_configuration ADD PRIMARY KEY
ALTER TABLE dp_layouts_configuration
  ADD PRIMARY KEY (
    lay_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_pat_values ADD PRIMARY KEY
ALTER TABLE dp_pat_values
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_pat_values ADD CONSTRAINT pattern_values_unique UNIQUE
ALTER TABLE dp_pat_values
  ADD CONSTRAINT pattern_values_unique UNIQUE (
    pat_sn,
    value_list
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_patterns_configuration ADD PRIMARY KEY
ALTER TABLE dp_patterns_configuration
  ADD PRIMARY KEY (
    pat_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_profiler_report ADD PRIMARY KEY
ALTER TABLE dp_profiler_report
  ADD PRIMARY KEY (
    sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_rpt_detail_log ADD PRIMARY KEY
ALTER TABLE dp_rpt_detail_log
  ADD PRIMARY KEY (
    det_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT ALTER TABLE dp_rpt_main_log ADD PRIMARY KEY
ALTER TABLE dp_rpt_main_log
  ADD PRIMARY KEY (
    log_sn
  )
  USING INDEX
    STORAGE (
      NEXT       1024 K
    )
/

PROMPT =========================================================================
PROMPT FOREIGN CONSTRAINTS
PROMPT =========================================================================

PROMPT ALTER TABLE dp_catgry_chk_list ADD CONSTRAINT fk_cetgry_sn FOREIGN KEY
ALTER TABLE dp_catgry_chk_list
  ADD CONSTRAINT fk_cetgry_sn FOREIGN KEY (
    cat_sn
  ) REFERENCES dp_check_categories (
    cat_sn
  )
/

PROMPT ALTER TABLE dp_catgry_chk_list ADD CONSTRAINT fk_master_id FOREIGN KEY
ALTER TABLE dp_catgry_chk_list
  ADD CONSTRAINT fk_master_id FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_client_values ADD CONSTRAINT fk_client_value FOREIGN KEY
ALTER TABLE dp_client_values
  ADD CONSTRAINT fk_client_value FOREIGN KEY (
    cli_sn
  ) REFERENCES dp_clients_configuration (
    cli_sn
  )
/

PROMPT ALTER TABLE dp_clients_configuration ADD CONSTRAINT fk_master_client FOREIGN KEY
ALTER TABLE dp_clients_configuration
  ADD CONSTRAINT fk_master_client FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_layout_values ADD CONSTRAINT fk_layout_values FOREIGN KEY
ALTER TABLE dp_layout_values
  ADD CONSTRAINT fk_layout_values FOREIGN KEY (
    lay_sn
  ) REFERENCES dp_layouts_configuration (
    lay_sn
  )
/

PROMPT ALTER TABLE dp_layouts_configuration ADD CONSTRAINT fk_master_layout FOREIGN KEY
ALTER TABLE dp_layouts_configuration
  ADD CONSTRAINT fk_master_layout FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_master_input_types ADD CONSTRAINT fk_mas_id FOREIGN KEY
ALTER TABLE dp_master_input_types
  ADD CONSTRAINT fk_mas_id FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_patterns_configuration ADD CONSTRAINT fk_master_pattern FOREIGN KEY
ALTER TABLE dp_patterns_configuration
  ADD CONSTRAINT fk_master_pattern FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_rpt_detail_log ADD CONSTRAINT fk_chkmstr_detail_log FOREIGN KEY
ALTER TABLE dp_rpt_detail_log
  ADD CONSTRAINT fk_chkmstr_detail_log FOREIGN KEY (
    mas_id
  ) REFERENCES dp_checks_master (
    mas_id
  )
/

PROMPT ALTER TABLE dp_rpt_detail_log ADD CONSTRAINT fk_main_detail_log FOREIGN KEY
ALTER TABLE dp_rpt_detail_log
  ADD CONSTRAINT fk_main_detail_log FOREIGN KEY (
    log_sn
  ) REFERENCES dp_rpt_main_log (
    log_sn
  )
/

PROMPT ALTER TABLE dp_rpt_results ADD CONSTRAINT fk_details_results FOREIGN KEY
ALTER TABLE dp_rpt_results
  ADD CONSTRAINT fk_details_results FOREIGN KEY (
    det_sn
  ) REFERENCES dp_rpt_detail_log (
    det_sn
  )
/

PROMPT =========================================================================
PROMPT TRIGGERS
PROMPT =========================================================================

PROMPT CREATE OR REPLACE TRIGGER trig_dp_catgry_chk_list
CREATE OR REPLACE TRIGGER trig_dp_catgry_chk_list BEFORE INSERT ON dp_catgry_chk_list FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CATGRY_CHK_LIST_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LIS_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_check_categories
CREATE OR REPLACE TRIGGER trig_dp_check_categories BEFORE INSERT ON dp_check_categories FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CHECK_CATEGORIES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.CAT_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_checks_master
CREATE OR REPLACE TRIGGER trig_dp_checks_master BEFORE INSERT ON dp_checks_master FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CHECKS_MASTER_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.MAS_ID:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_cli_values
CREATE OR REPLACE TRIGGER trig_dp_cli_values BEFORE INSERT ON dp_client_values FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CLI_VALUES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_cli_config
CREATE OR REPLACE TRIGGER trig_dp_cli_config BEFORE INSERT ON dp_clients_configuration FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_CLI_CONFIG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.CLI_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_error_codes
CREATE OR REPLACE TRIGGER trig_dp_error_codes BEFORE INSERT ON dp_error_codes FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_ERROR_CODES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.ERROR_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_lay_values
CREATE OR REPLACE TRIGGER trig_dp_lay_values BEFORE INSERT ON dp_layout_values FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_LAY_VALUES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_lay_config
CREATE OR REPLACE TRIGGER trig_dp_lay_config BEFORE INSERT ON dp_layouts_configuration FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_LAY_CONFIG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LAY_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_master_input_types
CREATE OR REPLACE TRIGGER trig_dp_master_input_types BEFORE INSERT ON dp_master_input_types FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_INPUT_TYPES_SN_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_pat_values
CREATE OR REPLACE TRIGGER trig_dp_pat_values BEFORE INSERT ON dp_pat_values FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_PAT_VALUES_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_pat_config
CREATE OR REPLACE TRIGGER trig_dp_pat_config BEFORE INSERT ON dp_patterns_configuration FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_PAT_CONFIG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.PAT_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_rpt_detail_log_seq
CREATE OR REPLACE TRIGGER trig_dp_rpt_detail_log_seq BEFORE INSERT ON dp_rpt_detail_log FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_RPT_DETAIL_LOG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LOG_SN:=SN; END;
/

PROMPT CREATE OR REPLACE TRIGGER trig_dp_rpt_main_log
CREATE OR REPLACE TRIGGER trig_dp_rpt_main_log BEFORE INSERT ON dp_rpt_main_log FOR EACH ROW
DECLARE SN INT;  BEGIN SELECT DP_RPT_MAIN_LOG_SEQ.NEXTVAL INTO SN FROM DUAL; :NEW.LOG_SN:=SN; END;
/

PROMPT =========================================================================
PROMPT GRANTS
PROMPT =========================================================================

GRANT SELECT ON dp_client_values TO public;
GRANT SELECT ON dp_layout_values TO public;
GRANT SELECT ON dp_pat_values TO public;
GRANT ALTER,DEBUG,DELETE,FLASHBACK,INDEX,INSERT,ON COMMIT REFRESH,QUERY REWRITE,REFERENCES,SELECT,UPDATE ON dp_rpt_detail_log TO tempimport;
GRANT ALTER,DEBUG,DELETE,FLASHBACK,INDEX,INSERT,ON COMMIT REFRESH,QUERY REWRITE,REFERENCES,SELECT,UPDATE ON dp_rpt_main_log TO tempimport;
GRANT ALTER,DEBUG,DELETE,FLASHBACK,INDEX,INSERT,ON COMMIT REFRESH,QUERY REWRITE,REFERENCES,SELECT,UPDATE ON dp_rpt_results TO tempimport;
