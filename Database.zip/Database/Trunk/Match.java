/**
 * @author Ayam Pokhrel,i81236
 */
/**
 * Don't Compile this class with jdk or jre above version 1.6 (as oracle 11g only supports java classes compiled within 
 * version 1.6
 */
/*
 * Compile as below:
 * javac -source 1.6 -target 1.6 Match.java
 */
import java.util.regex.Pattern;
import java.util.regex.Matcher;
/**
 * 
 * @author i81236
 * This is the class for AIP_FILE_MATCH function. It simply uses Java Regex. This class should be loaded in utility schema
 * (oracle regexp_like doesn't support complex regular expressions)
 *
 */

public class Match {

	public static int checkPattern(String checkString, String pattern) {
		int returnValue = 0;
		if (pattern == null || checkString == null) {
			return 0;
		}
		pattern = pattern.replaceAll("\\.\\*\\*", ".*");

		try {
			Pattern p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
			Matcher m = p.matcher(checkString);
			returnValue = m.matches() == true ? 1 : 0;

		} catch (Exception e) {
			return 0;
		}
		return returnValue;
	}
	 
}
