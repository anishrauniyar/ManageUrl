PROMPT CREATE OR REPLACE FUNCTION exception_num_chk
CREATE OR REPLACE FUNCTION exception_num_chk (NUMBER_STRING IN VARCHAR2)
             RETURN VARCHAR2
AS
     CHECK_NUMBER NUMBER;
     CLEANME VARCHAR2(2000);
-- Check if number_string is valid number or not, retruns NULL in case of exception
-- To be used in AIP_DASHBOARD_INVENTORY for number exception checks
BEGIN
    CLEANME := NUMBER_STRING;
    IF (SUBSTR(NUMBER_STRING, -1 ) = '-' ) THEN CLEANME := '-'||REPLACE (NUMBER_STRING,'-',''); END IF;
    CHECK_NUMBER := REGEXP_REPLACE(NVL(CLEANME,'NULL'),'[,()$]','') ;
       RETURN CHECK_NUMBER;
  EXCEPTION WHEN OTHERS THEN
        RETURN 'EXCEPTION';
END;
/
