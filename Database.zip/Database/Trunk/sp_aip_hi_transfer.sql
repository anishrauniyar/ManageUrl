PROMPT CREATE OR REPLACE PROCEDURE sp_aip_hi_transfer
CREATE OR REPLACE PROCEDURE sp_aip_hi_transfer (P_CID VARCHAR2 , P_FILEIDLIST VARCHAR2 , P_IMPORTSERVER VARCHAR2,p_schemaname VARCHAR2, p_sn NUMBER DEFAULT NULL)  IS
-- Procedure to move data from AIP Server to Client Server
-- To be executed in HI schema where data needs to be transferred, reads/update logs from FLMS for transfer , copies data from AI tables to HI tables
-- Uses HI_LEGACY_TRANSFER and HI_LEGACY_LABEL_CHG config table to transfer data
-- Transfers data only in append mode.
-- exec sp_aip_hi_transfer ('721' ,  '32982_1613258', 'nveigerwork','HI0721001_T')
-- exec sp_aip_hi_transfer ('759' ,  '43457_1596941', 'nveigerwork','HI0759001',123) -- for failure re-run


  VQUERY clob;
  VHPAYERID VARCHAR2(100);
  VROWINSERTED INTEGER ;
  VERRMSG VARCHAR2(500);
  VSTARTTIME DATE;
  VTABLENAME VARCHAR2(100);
  VCID VARCHAR2(10);
  VTRANSFERTYPE VARCHAR2(50);
  VCNT NUMBER(19,4) ;
  VSQLSTRING clob;
  VJOBNUM BINARY_INTEGER ;
  JOBCNT NUMBER (19,0);
  VCOND VARCHAR2(4000 ) ;
  VFILELIST VARCHAR2(4000);

  TYPE FILE_REC IS RECORD
  (FILEID VARCHAR2(200),
   DMFILEID   VARCHAR2(100),
   LAYOUTID VARCHAR2(100),
   FILENAME VARCHAR2(500),
   EMPGRP VARCHAR2(500),
   SUBLAYOUTID VARCHAR2(500),
   RECORDCOUNT NUMBER  ,
   AITABLENAME VARCHAR2(50),
   TRANSFERTYPE VARCHAR2(50),
   HITABLENAME VARCHAR2(50),
   HISCHEMANAME VARCHAR2(50) ,
   WHERECONDITION VARCHAR2(500) ,
   SN  NUMBER,
   HISERVERNAME VARCHAR2(50)

  ) ;

  TYPE FILE_SET IS TABLE OF FILE_REC ;
  FILE_LIST FILE_SET;
  VFILENAME VARCHAR2(500) ;
  VEMPGRP VARCHAR2(500);

  AICOLUMNLIST clob;
  HICOLUMNLIST clob;

  VBKPDATE VARCHAR2(50);
  AISCHEMA VARCHAR2(50);
  VWHERECONDITION VARCHAR2(4000);
  IMPORTSERVER VARCHAR2(50);

  TYPE TRANS_REC IS RECORD
  (
  FILEID VARCHAR2(50),
  DMFILEID VARCHAR2(50),
  LAYOUTID VARCHAR2(50),
  SUBLAYOUTID VARCHAR2(50),
  CLIENTID VARCHAR2(50),
  EMPLOYERNAME VARCHAR2(100),
  AITABLENAME VARCHAR2(50),
  HISCHEMANAME VARCHAR2(50),
  HITABLENAME VARCHAR2(50),
  TRANSFERTYPE VARCHAR2(50) ,
  WHERECONDITION VARCHAR2(4000),
  SN NUMBER ,
  LEGACY_SN number
  );
  TYPE TRANS_SET IS TABLE OF TRANS_REC ;
  TRANSFER TRANS_SET;
  filecnt NUMBER(19,0);

BEGIN

  VCID:=LPAD(P_CID,4,'0');
  VFILELIST := REPLACE(P_FILEIDLIST,',',''',''')   ;
  AISCHEMA:='AI'||VCID;

  IF  p_sn IS NOT NULL THEN
         vcond:= 'join hi_main_log@importdb f
          on a.fileid=f.fileid and c.sn=f.legacy_sn  and f.sn='||p_sn||' ' ;
  END IF;


  IF P_IMPORTSERVER IS NOT NULL THEN   IMPORTSERVER:='@'||P_IMPORTSERVER ; END IF;


 -- PICKUP FILES FROM IMPORT LOG IN SUCCESS MODE FOR TRANSFER.
          EXECUTE IMMEDIATE  'SELECT A.FILEID , A.DMFILEID, A.LAYOUTID,A.FILENAME,A.EMPGRP,B.SUBLAYOUTID,B.RECORDCOUNT,B.AITABLENAME,''APPEND'' TRANSFERTYPE,
                              C.HITABLENAME,C.HISCHEMANAME,C.WHERECONDITION,C.SN , c.HISERVERNAME
                              FROM  IMP_MAIN_LOG@IMPORTDB A
                              JOIN IMP_MAIN_DET_LOG@IMPORTDB B
                                ON A.FILEID||''_''||A.DMFILEID =B.FILEID
                              LEFT JOIN   HI_LEGACY_TRANSFER@IMPORTDB C
                                ON  A.CLIENTID=C.CLIENTID AND B.AITABLENAME=C.AITABLENAME AND A.EMPGRP=C.EMPGRP
                              '||vcond||' WHERE  a.STATUS_OF_IMPORT =''SUCCESS'' AND a.CLIENTID = '''||P_CID||'''
                              AND B.FILEID IN ('''||VFILELIST||''') and upper(C.HISCHEMANAME)=upper( '''||p_schemaname||''' )'
          BULK COLLECT INTO FILE_LIST;

         -- Dbms_Output.put_line(FILE_LIST.Count);

    IF FILE_LIST.Count >= 1 THEN

          FOR I IN FILE_LIST.FIRST..FILE_LIST.LAST
              LOOP

                VSTARTTIME:=SYSDATE;
						 -- Check if file is in failed/queued state , to re--run 
                            SELECT Count(*) INTO vcnt FROM hi_main_log@importdb WHERE  HISTATUS  IN ('FAILED','QUEUED') AND fileid=''||FILE_LIST(I).FILEID||'' AND sn=''||p_sn||'' ;


                              IF   (vcnt = 0 )  THEN


                                  INSERT INTO   HI_MAIN_LOG@IMPORTDB  ( FILEID,DMFILEID ,LAYOUTID, SUBLAYOUTID, CLIENTID, EMPLOYERNAME,
                                  AITABLENAME, HISCHEMANAME,HITABLENAME, WHERECONDITION,HISTATUS, HISTARTTIME, TRANSFERTYPE,legacy_sn)
                                  VALUES (FILE_LIST(I).FILEID,FILE_LIST(I).DMFILEID,FILE_LIST(I).LAYOUTID,FILE_LIST(I).SUBLAYOUTID,P_CID,FILE_LIST(I).EMPGRP,FILE_LIST(I).AITABLENAME,
                                  FILE_LIST(I).HISCHEMANAME,
                                  FILE_LIST(I).HITABLENAME,FILE_LIST(I).WHERECONDITION,'QUEUED',VSTARTTIME,FILE_LIST(I).TRANSFERTYPE,FILE_LIST(I).sn);  -- change next val sequnece
                                  COMMIT ;
                              ELSE

                            VWHERECONDITION:=REPLACE(FILE_LIST(I).WHERECONDITION,'''','''''');

                              EXECUTE IMMEDIATE 'UPDATE  HI_MAIN_LOG@IMPORTDB
                              SET HISTATUS=''QUEUED'' , HISTARTTIME =sysdate , HIENDTIME = NULL , HIERRMSG=null,
                              HISCHEMANAME='''||FILE_LIST(I).HISCHEMANAME||''',
                              HITABLENAME='''||FILE_LIST(I).HITABLENAME||''' , WHERECONDITION='''||VWHERECONDITION||''' WHERE   SN= '''||P_SN||''' ';
                              COMMIT;

                            END IF;

                END LOOP;
      END IF ;
      -- START PROCESSING TRANSFER FOR EACH FILE

       EXECUTE IMMEDIATE ' SELECT FILEID, DMFILEID , LAYOUTID, SUBLAYOUTID, CLIENTID, EMPLOYERNAME,
                           AITABLENAME, HISCHEMANAME,HITABLENAME,TRANSFERTYPE, WHERECONDITION,SN, LEGACY_SN FROM HI_MAIN_LOG@IMPORTDB
                           WHERE HISTATUS=''QUEUED'' AND FILEID||''_''||DMFILEID IN ('''||VFILELIST||''') and upper(HISCHEMANAME)=upper( '''||p_schemaname||''' ) '
       BULK COLLECT INTO TRANSFER;



        IF TRANSFER.Count >=1 THEN

          FOR I IN  TRANSFER.FIRST..TRANSFER.LAST
             LOOP

                   --Dbms_Output.put_line('LOOP');
                    EXECUTE IMMEDIATE 'UPDATE  HI_MAIN_LOG@IMPORTDB  SET HISTATUS=''RUNNING'' WHERE SN= '''||transfer(i).SN||'''  ' ;
                    COMMIT;
				-- Check for Where clause if defined for a tranfer
                  IF transfer(i).WHERECONDITION IS NULL THEN
                  VWHERECONDITION:='  A.FILEID= '''||transfer(i).FILEID||'_' ||transfer(i).DMFILEID||''' '    ;
                    ELSE
                    VWHERECONDITION:='  A.FILEID= '''||transfer(i).FILEID||'_' ||transfer(i).DMFILEID||''' AND '||transfer(i).WHERECONDITION     ;
                  END IF;


                    VWHERECONDITION:=REPLACE(VWHERECONDITION,'''','''');


                  -- Check if HI table exists else create
                    SELECT Count(1) INTO vcnt FROM tab WHERE TNAME=Upper(''||transfer(i).HITABLENAME||'') ;
                    IF  (vcnt =0 ) THEN
                    BEGIN

					-- Prepare HI Column List based on transfer configuration
                        EXECUTE IMMEDIATE ' SELECT rtrim (xmlagg (xmlelement (e, column_name || '','')).EXTRACT (''//text()'').getclobval(), '','') column_name
                                            FROM ( SELECT column_name ||'' AS ''|| Nvl(b.HICOLUMNNAME,a.column_name )  AS COLUMN_NAME
                                                    FROM all_tab_cols'||IMPORTSERVER||'   A
                                                    LEFT JOIN   HI_LEGACY_LABEL_CHG@IMPORTDB  B
                                                    ON  A.COLUMN_ID=B.AICOLUMNID AND B.SN='||transfer(i).LEGACY_SN||'
                                                    WHERE A.OWNER=Upper('''||AISCHEMA||''')
                                                    AND A.TABLE_NAME=Upper('''||transfer(i).AITABLENAME||''')
                                                    AND   nvl(b.HICOLUMNID,1) !=0

                                                    order by column_id
                                                ) ' INTO  HICOLUMNLIST ;


                        VQUERY:='CREATE TABLE '||transfer(i).HISCHEMANAME||'.'||transfer(i).HITABLENAME||'
                          AS SELECT '||HICOLUMNLIST||' FROM '||AISCHEMA||'.'||transfer(i).AITABLENAME||IMPORTSERVER||'  A
                          WHERE 1=2';



                          EXECUTE IMMEDIATE VQUERY;
                          EXCEPTION WHEN OTHERS THEN  NULL;
                    END;
                    END IF;

                    BEGIN


					-- Prepare AI column list for transfer
                      EXECUTE IMMEDIATE ' SELECT rtrim (xmlagg (xmlelement (e, column_name || '','')).EXTRACT (''//text()'').getclobval(), '','') column_name
                                          FROM (select column_name,column_id FROM all_tab_cols'||IMPORTSERVER||'  a
                                          LEFT JOIN   HI_LEGACY_LABEL_CHG@IMPORTDB  B
                                          ON  A.COLUMN_ID=B.AICOLUMNID AND B.SN='||transfer(i).LEGACY_SN||'
                                          WHERE OWNER=Upper('''||AISCHEMA||''')
                                          AND TABLE_NAME=Upper('''||transfer(i).AITABLENAME||''')
                                          AND   nvl(b.HICOLUMNID,1) !=0
                                          and a.COLUMN_NAME not in (''UDF1'',''UDF2'',''UDF3'',''UDF4'',''UDF5'')
                                          order by column_id) ' INTO  AICOLUMNLIST ;


					-- Prepare HI column list for transfer
                      EXECUTE IMMEDIATE ' SELECT rtrim (xmlagg (xmlelement (e, column_name || '','')).EXTRACT (''//text()'').getclobval(), '','') column_name
                                          FROM (    SELECT  NVL(B.HICOLUMNNAME,A.COLUMN_NAME ) AS COLUMN_NAME
                                                      FROM all_tab_cols'||IMPORTSERVER||'   A
                                                      LEFT JOIN   HI_LEGACY_LABEL_CHG@IMPORTDB  B
                                                      ON  A.COLUMN_ID=B.AICOLUMNID AND B.SN='||transfer(i).LEGACY_SN||'
                                                      WHERE A.OWNER=Upper('''||AISCHEMA||''')
                                                      AND A.TABLE_NAME=Upper('''||transfer(i).AITABLENAME||''')
                                                      AND   nvl(b.HICOLUMNID,1) !=0
                                                      and a.COLUMN_NAME not in (''UDF1'',''UDF2'',''UDF3'',''UDF4'',''UDF5'')
                                                      order by column_id
                                                  ) ' INTO  HICOLUMNLIST ;


                      EXCEPTION WHEN OTHERS THEN NULL;

                    END ;

                 --  check if file already exists in HI, raise exception
                 -----------------------------------------------------
				BEGIN	
		  
                 EXECUTE IMMEDIATE 'SELECT Count(*) FROM ' || transfer(i).HISCHEMANAME||'.'||transfer(i).HITABLENAME|| 
                 ' where fileid= '''||transfer(i).FILEID||'_' ||transfer(i).DMFILEID||''' '  INTO filecnt;
				EXCEPTION WHEN OTHERS THEN
                   VERRMSG:='Error at File Check in HI : '|| SUBSTR(SQLERRM, 1,400);
                   EXECUTE IMMEDIATE 'UPDATE  HI_MAIN_LOG@IMPORTDB  SET HISTATUS=''FAILED'', HIERRMSG = '''||VERRMSG||''' , HIENDTIME=SYSDATE
                   WHERE    SN= '''||transfer(i).SN||''' ' ;                                                                                     
   				   COMMIT;   
                  -- EXIT;				   
                END;  
               -- Dbms_Output.PUT_LINE(filecnt);

                IF filecnt > 0 THEN 
						 EXECUTE IMMEDIATE 'UPDATE  HI_MAIN_LOG@IMPORTDB  SET HISTATUS=''FAILED'', HIROWS = 0 , 
						 HIERRMSG= ''AIP file already exists in HI Table, cleanup table for file and re-run'' , HIENDTIME=SYSDATE  , ENABLESCRUBFLAG=''Y''
						 WHERE   SN= '''||transfer(i).SN||''' ' ;
						 COMMIT;
                ELSE 
                --- 	Inserting AI to HI 
                        VQUERY:= 'INSERT /*+ APPEND PARALLEL */INTO '||transfer(i).HISCHEMANAME||'.'||transfer(i).HITABLENAME||' ('||HICOLUMNLIST||')
                        SELECT  /*+ PARALLEL */ '||AICOLUMNLIST||' FROM  '||AISCHEMA||'.'||transfer(i).AITABLENAME||IMPORTSERVER||' A  WHERE '||VWHERECONDITION||' ' ;
                    

                            BEGIN

                              EXECUTE IMMEDIATE VQUERY;

                                VROWINSERTED :=SQL%ROWCOUNT;
                                COMMIT;

                                EXECUTE IMMEDIATE 'UPDATE  HI_MAIN_LOG@IMPORTDB  SET HISTATUS=''SUCCESS'', HIROWS = '||VROWINSERTED||' , HIENDTIME=SYSDATE  , ENABLESCRUBFLAG=''Y''
                                WHERE   SN= '''||transfer(i).SN||''' ' ;
                                COMMIT;
                            EXCEPTION WHEN OTHERS THEN

                                VERRMSG:='Error at Insert from AI to HI: '|| SUBSTR(SQLERRM, 1,400);
                                VERRMSG:=REPLACE(VERRMSG,'''','''''');

                                EXECUTE IMMEDIATE 'UPDATE  HI_MAIN_LOG@IMPORTDB  SET HISTATUS=''FAILED'', HIERRMSG = '''||VERRMSG||''' , HIENDTIME=SYSDATE
                                WHERE    SN= '''||transfer(i).SN||''' ' ;                                                                                     
   				                      COMMIT;                                        
                            END;  
                    END IF;
                                                                                                                            
                END LOOP;                                                      

        
       END IF;
         --EXECUTE IMMEDIATE 'ALTER SESSION CLOSE DATABASE LINK IMPORTDB';
          -- COMMIT;


END sp_aip_hi_transfer  ;
/



