PROMPT CREATE OR REPLACE PACKAGE pkg_aip_file_report
CREATE OR REPLACE PACKAGE pkg_aip_file_report
AUTHID CURRENT_USER
IS
-- Package to run AIP reports for DSR and DATE Number Checks at File Level
--- exec  pkg_aip_file_report.exe_report('103434_1713894');
--- exec  pkg_aip_file_report.exe_report('103976_1731515','DSR');

  PROCEDURE EXE_REPORT(PFILEID  VARCHAR2 , REPORTTYPE VARCHAR2 DEFAULT 'ALL');
  PROCEDURE SP_DSR_AIP (PCID VARCHAR2,PLAYOUTID VARCHAR2, PSCHEMANAME VARCHAR2, PTABLENAME VARCHAR2 ,PFILEID VARCHAR2,SN IN VARCHAR2 ,SUBLAYOUTID VARCHAR2 );
  PROCEDURE SP_DSR_MM_CALC(FILEID IN VARCHAR2,CLIENTID IN VARCHAR2,COVERAGECODE IN VARCHAR2,EMPGRP IN VARCHAR2,SCHEMA_NAME IN VARCHAR2,TABLE_NAME IN VARCHAR2,EFF_DATE IN VARCHAR2,END_DATE IN VARCHAR2,MEMID IN VARCHAR2,ENRID IN VARCHAR2,CYCLESTARTDTE IN DATE, CYCLEENDDTE IN DATE,LAYOUTID IN NUMBER,SUBLAYOUTID IN VARCHAR2,sn IN varchar2);
  PROCEDURE SP_DATE_NUMBER_CHK(SCHEMANAME IN VARCHAR2,tablename IN varchar2,LID IN VARCHAR2,SLID IN VARCHAR2,SN IN VARCHAR2,punchchar varchar2)    ;


END pkg_aip_file_report;
/

PROMPT CREATE OR REPLACE PACKAGE BODY pkg_aip_file_report
CREATE OR REPLACE PACKAGE BODY pkg_aip_file_report IS

PROCEDURE EXE_REPORT(PFILEID  VARCHAR2 , REPORTTYPE VARCHAR2)
IS
-- REPORT TYPE - ALL , DSR
VBLPAIDAMOUNT VARCHAR2(500);
vtablename VARCHAR2(50);
vsn NUMBER(19,0);
vfileid VARCHAR2(50);
BEGIN

     -- Start Calling DSR and Date Number check procedures
        FOR FILELIST IN
                      ( SELECT  A.CLIENTID , A.LAYOUTID,'AI'||lpad(A.clientid,4,'0')  AS schemaname,
                        'AI_'||A.LAYOUTID||'_'||C.SUBLAYOUTID||'_'||B.shortpayor AS tablename  ,C.SUBLAYOUTID AS sublayoutid    , B.shortpayor ,PUCHCHARFLAG
                        FROM imp_main_log@flms A , IMP_LAYOUTS@flms B, IMP_SUB_LAYOUTS@flms C
                        WHERE fileid||'_'||dmfileid=''||pfileid||'' AND  A.LAYOUTID=B.LAYOUTID AND   A.LAYOUTID=C.LAYOUTID AND c.SUBLAYOUTDESC='DATAFILE' )

        LOOP


          IF reporttype='ALL' OR reporttype IS NULL THEN

           EXECUTE IMMEDIATE 'DELETE FROM RPT_DSR@flms WHERE SN  in (select sn from rpt_main_log@flms
                              where fileid= '''||PFILEID||'''   and REPORTTYPE=''DSR'') ';
           COMMIT;

           BEGIN
             SELECT sn into vsn FROM rpt_main_log@flms WHERE fileid=''||pfileid||'' AND sublayoutid=''||filelist.sublayoutid||'' AND reporttype='DSR' ;
           EXCEPTION  WHEN OTHERS THEN NULL ;
           END ;
           --Dbms_Output.put_line('DSR : ' || vsn );

            IF vsn IS NULL THEN

              EXECUTE IMMEDIATE  'INSERT INTO rpt_main_log@flms  (FILEID,REPORTTYPE, STATUS, STARTTIME, ENDTIME,layoutid,sublayoutid)
                                    VALUES ('''||PFILEID||''', ''DSR'', ''RUNNING'', SYSDATE, NULL,'''||filelist.layoutid||''','''||filelist.sublayoutid||''')' ;
               COMMIT;

               SELECT sn into vsn FROM rpt_main_log@flms WHERE fileid=''||pfileid||'' AND sublayoutid=''||filelist.sublayoutid||'' AND reporttype='DSR' ;


              ELSE
              --Dbms_Output.put_line('DSR : ' || vsn );
              EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''RUNNING'' , STARTTIME= SYSDATE, ENDTIME=NULL WHERE   REPORTTYPE=''DSR'' and SN='''||vSN||'''  ' ;
              COMMIT;

            END IF;

            -- Calling DSR Report
            SP_DSR_AIP (FILELIST.CLIENTID ,FILELIST.LAYOUTID , FILELIST.SCHEMANAME , FILELIST.TABLENAME ,PFILEID,VSN ,FILELIST.SUBLAYOUTID   );


           -- Calling Date Check Report                                   12
           -- calculate T table name
           vfileid:= substr(PFILEID,1,InStr(PFILEID,'_')-1) ;
           vtablename:=Upper('T_'||filelist.layoutid||'_'||filelist.sublayoutid||'_'||VFILEID) ;

          -- check if T table exists then call the Date/Number Check else not required.

          SELECT Count(*) INTO vsn FROM dba_objects WHERE OBJECT_TYPE='TABLE' AND owner=''||FILELIST.SCHEMANAME||'' and  OBJECT_NAME ='' ||vtablename||'' ;
          --Dbms_Output.put_line(vtablename);
          --Dbms_Output.put_line('table check - '||vsn);


         IF vsn > 0  THEN

            EXECUTE IMMEDIATE 'DELETE FROM RPT_CHK_DATE_NUMBER@flms where SN  in (select sn from rpt_main_log@flms
                              where fileid ='''||PFILEID||'''  and REPORTTYPE=''DTE_NUM_CHK'') ';
            COMMIT;

           BEGIN
           vsn:=NULL;
            SELECT sn into vsn FROM rpt_main_log@flms WHERE fileid=''||pfileid||'' AND sublayoutid=''||filelist.sublayoutid||'' AND reporttype='DTE_NUM_CHK';
           EXCEPTION  WHEN OTHERS THEN NULL ;
           END ;

            --Dbms_Output.put_line('DATE : ' || vsn );

            IF vsn IS NULL THEN

            --Dbms_Output.put_line('INSERT ' || vsn );
              EXECUTE IMMEDIATE  'INSERT INTO rpt_main_log@flms  (FILEID,REPORTTYPE, STATUS, STARTTIME, ENDTIME, LAYOUTID,SUBLAYOUTID)
                                    VALUES ('''||PFILEID||''', ''DTE_NUM_CHK'', ''RUNNING'', SYSDATE, NULL,'''||filelist.layoutid||''','''||filelist.sublayoutid||''')' ;

              COMMIT;
              SELECT sn into vsn FROM rpt_main_log@flms WHERE fileid=''||pfileid||'' AND sublayoutid=''||filelist.sublayoutid||'' AND reporttype='DTE_NUM_CHK';
            ELSE
              EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''RUNNING'' , STARTTIME= SYSDATE WHERE   REPORTTYPE=''DTE_NUM_CHK'' and SN='''||vSN||'''  ' ;
              COMMIT;

           END IF;
            --Dbms_Output.put_line('calling date check');

           SP_DATE_NUMBER_CHK(FILELIST.SCHEMANAME ,VTABLENAME,FILELIST.LAYOUTID,FILELIST.SUBLAYOUTID,VSN, FILELIST.PUCHCHARFLAG)   ;
         END IF ;

          ELSIF reporttype='DSR' THEN



             begin
              SELECT sn into vsn FROM rpt_main_log@flms WHERE fileid=''||pfileid||'' AND sublayoutid=''||filelist.sublayoutid||'' AND reporttype='DSR' ;

              EXCEPTION WHEN OTHERS THEN NULL ;
             END ;



              EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''RUNNING'' , STARTTIME= SYSDATE , ENDTIME= NULL WHERE   REPORTTYPE=''DSR'' and SN='''||vSN||'''  ' ;
              COMMIT;


              SP_DSR_AIP (FILELIST.CLIENTID ,FILELIST.LAYOUTID , FILELIST.SCHEMANAME , FILELIST.TABLENAME ,PFILEID,VSN ,FILELIST.SUBLAYOUTID   );


          END IF;
        END LOOP;



END EXE_REPORT;

PROCEDURE SP_DATE_NUMBER_CHK(SCHEMANAME IN VARCHAR2,tablename IN varchar2,LID IN VARCHAR2,SLID IN VARCHAR2,SN IN VARCHAR2,PUNCHCHAR VARCHAR2)
IS
    VBQUERY VARCHAR2(32000);
		DT_NUM_FUNCTION VARCHAR2(50);
    ErrMsg VARCHAR2(500);
    cnt NUMBER(19,0);
    vconvertval VARCHAR2(200);

BEGIN
 -- Dbms_Output.put_line('in date check') ;
 EXECUTE IMMEDIATE ' CREATE TABLE '||SCHEMANAME||'.ZZZ_CHK_DATE_NUMBER_'||sn||' ( CHKTYPE varchar2(100), SN varchar2(100), DATAFORMAT varchar2(50) , COLID varchar2(50), COLNAME varchar2(50), FLVAL varchar2(500), RC varchar2(50)) ' ;


  FOR i IN (
	  SELECT DATATYPE,COLUMNID,COLUMNNAME, DATETYPEDETIAL FROM IMP_LAYOUTS_FIELDS@flms
	  WHERE LAYOUTID=LID AND SUBLAYOUTID=SLID AND (Upper(DATATYPE) LIKE 'NUM%' OR Upper(DATATYPE) LIKE 'DATE%')
	  ORDER BY To_Number(columnid)
	  )
  LOOP

	    IF Upper(i.DATATYPE) IN ( 'DATE' , 'DATETIME' ) THEN
   --   Dbms_Output.put_line('DATE');

          VBQUERY:='
          insert into '||SCHEMANAME||'.ZZZ_CHK_DATE_NUMBER_'||sn||'
          WITH ZZZ_TEMP_DATE AS  (
	          SELECT /*+ Parallel(a,4) +*/ '||i.COLUMNNAME||',count(*) as RCC  FROM '||SCHEMANAME||'.'||tablename||' group by '||i.COLUMNNAME||'
	          )
	          SELECT ''DATECHECK'' CHKTYPE,'''||SN||''' SN,'''||i.DATETYPEDETIAL||'''  AS DATAFORMAT, '''||i.COLUMNID||''' AS COLID, '''||i.COLUMNNAME||''' AS COLNAME, a.FLVAL AS FLVAL,a.RC FROM (
	          SELECT /*+ Parallel(a,4) +*/ RCC AS RC,'||i.COLUMNNAME||' FLVAL,VH_TO_DATE('||i.COLUMNNAME||','''||i.DATETYPEDETIAL||''') CONVERTEDVAL FROM  ZZZ_TEMP_DATE  a
	          ORDER  BY  1 DESC
	          ) a WHERE  CONVERTEDVAL IS NULL AND ROWNUM <6';
        ELSIF Upper(i.DATATYPE) IN ( 'NUMBER','MONEY','FLOAT','INTEGER') THEN
       --  Dbms_Output.put_line('NUMBER');

         -- if punch char enabled for numeirc field

          IF PUNCHCHAR='Y' THEN
            vconvertval:= 'VH_TO_NUMBER(PC('||i.COLUMNNAME||'))' ;
            ELSE vconvertval:= 'VH_TO_NUMBER('||i.COLUMNNAME||')';   END  IF;



          VBQUERY:='
          insert into '||SCHEMANAME||'.ZZZ_CHK_DATE_NUMBER_'||sn||'
          WITH ZZZ_TEMP_DATE AS  (
	          SELECT /*+ Parallel(a,4) +*/ '||i.COLUMNNAME||',count(*) as RCC FROM  '||SCHEMANAME||'.'||tablename||'  group by '||i.COLUMNNAME||'
	          )
	          SELECT ''NUMBERCHECK'' CHKTYPE, '''||SN||''' SN,'''||i.DATETYPEDETIAL||'''  AS DATAFORMAT, '''||i.COLUMNID||''' AS COLID, '''||i.COLUMNNAME||''' AS COLNAME, a.FLVAL AS FLVAL,a.RC FROM (
	          SELECT /*+ Parallel(a,4) +*/ RCC AS RC,'||i.COLUMNNAME||' FLVAL,'||vconvertval||' CONVERTEDVAL FROM  ZZZ_TEMP_DATE  a
	          ORDER  BY  1 DESC
	          ) a WHERE  CONVERTEDVAL =0 AND ROWNUM <6';
        END IF;

      --  Dbms_Output.put_line(VBQUERY) ;

          BEGIN
                EXECUTE IMMEDIATE VBQUERY ;
                commit;


          EXCEPTION WHEN OTHERS THEN
            ErrMsg:=substr(SQLERRM, 1,400);
            EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''FAILED'' , ErrMsg='''||ErrMsg||''', endtime= SYSDATE WHERE   REPORTTYPE=''DTE_NUM_CHK'' and SN='''||SN||'''  ' ;
            COMMIT;
          END ;

      END LOOP;

     BEGIN
            EXECUTE IMMEDIATE 'INSERT INTO RPT_CHK_DATE_NUMBER@flms
                                        (
	                                        CHKTYPE, SN, DATAFORMAT, COLID, COLNAME, FLVAL, RC
                                        ) select * from  '||SCHEMANAME||'.ZZZ_CHK_DATE_NUMBER_'||sn||'
                                      ' ;
            COMMIT;
            EXECUTE IMMEDIATE 'DROP TABLE '||SCHEMANAME||'.ZZZ_CHK_DATE_NUMBER_'||sn||' '  ;
            --EXECUTE IMMEDIATE 'DROP TABLE  '||SCHEMANAME||'.'||tablename||' ' ;
            EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''SUCCESS'' , endtime= SYSDATE WHERE   REPORTTYPE=''DTE_NUM_CHK'' and status=''RUNNING'' and SN='''||SN||'''  ' ;
            COMMIT;

     EXCEPTION WHEN OTHERS THEN
            ErrMsg:=substr(SQLERRM, 1,400);
            EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''FAILED'' , ErrMsg='''||ErrMsg||''', endtime= SYSDATE WHERE   REPORTTYPE=''DTE_NUM_CHK'' and SN='''||SN||'''  ' ;
            COMMIT;
     END;

END SP_DATE_NUMBER_CHK;





PROCEDURE SP_DSR_MM_CALC(FILEID IN VARCHAR2,CLIENTID IN VARCHAR2,COVERAGECODE IN VARCHAR2, EMPGRP IN VARCHAR2,SCHEMA_NAME IN VARCHAR2,TABLE_NAME IN VARCHAR2,EFF_DATE IN VARCHAR2,END_DATE IN VARCHAR2,MEMID IN VARCHAR2,ENRID IN VARCHAR2,CYCLESTARTDTE IN DATE, CYCLEENDDTE IN DATE,LAYOUTID IN NUMBER, SUBLAYOUTID IN VARCHAR2, sn IN varchar2)
IS

                YYYY_MM VARCHAR2(10);
                REFDATE VARCHAR2(20);
                NOOFMTH INT ;
                VBQUERY VARCHAR2(32000);
                VBQUERYTABLE VARCHAR2(25000);
                ERRMSG VARCHAR2(32000);
                MIN_EFFDATE DATE;
                VSTARTTIME DATE;
                VERRMSG VARCHAR2(400);
                CYCLESTARTDATE DATE ;
                CYCLEENDDATE DATE ;
                RECCNT NUMBER(19,0);
 BEGIN

             CYCLESTARTDATE :=  CYCLESTARTDTE ;
             CYCLEENDDATE := CYCLEENDDTE ;
             VSTARTTIME:=SYSDATE;


             execute immediate 'SELECT Count(*)  FROM  '||SCHEMA_NAME||'.'||TABLE_NAME||' WHERE fileid='''||fileid||''' ' into reccnt ;



            begin
             execute immediate  'CREATE TABLE '||SCHEMA_NAME||'.ZZZ_ELIG'||'_'||sn||'  AS
                                (
                                SELECT  /*+ PARALLEL(A,4) */ DISTINCT
                                fileid, '''||SCHEMA_NAME||''' as schemaname,
                                 '''||TABLE_NAME||''' as tablename,'
                                ||' NVL('''||COVERAGECODE||''',''MED'')  AS CCD,'
                                ||'CAST('||ENRID||' AS VARCHAR2(500))'||' AS EID ,'
                                ||'CAST('||MEMID||' AS VARCHAR2(500))'||' AS MID,EMPGRP,
                                 NVL('||EFF_DATE||',TO_DATE(''12/31/9999'',''MM/DD/YYYY'')) AS ED,
                                 NVL('||END_DATE||',TO_DATE(''12/31/9999'',''MM/DD/YYYY'')) AS TD
                                 ,sourcefilename,receivedmonth
                                FROM '  ||SCHEMA_NAME||'.'||TABLE_NAME||'  A  where fileid='''||FILEID||''' ) ' ;

             EXCEPTION
                  WHEN OTHERS THEN  NULL ;
            END ;


             VBQUERYTABLE:='
                          insert /*+ APPEND */ into RPT_DSR@flms
                            (SN	,
                            schemaname	,
                            empgrp	,
                            coveragecode,
                            flag	,
                            yymm	,
                            empcount	,
                            memcount	,
                            recordcount	,
                            tablename	,
                            filename	,
                            rcvmonth	,
                            rundate
                            )'
                          ;

                          NOOFMTH := ROUND(MONTHS_BETWEEN(CYCLEENDDATE,CYCLESTARTDATE));

                        --   NOOFMTH:=20;
                     FOR I IN 0..NOOFMTH-1
                          LOOP
                                YYYY_MM :=   TO_CHAR(ADD_MONTHS(CYCLESTARTDATE,I),'YYYYMM');
                                REFDATE  :=  TO_CHAR(ADD_MONTHS(CYCLESTARTDATE,I),'YYYYMM');


                          IF I=0 THEN
                            VBQUERY:=VBQUERYTABLE||
                            '
                            SELECT /*+ PARALLEL(A,8) */
                            '''||SN||''', SCHEMANAME, '''||empgrp||''' , CCD,''Member Month'',
                            '''||REFDATE||''' AS RDT , COUNT(DISTINCT EID) AS ECNT,COUNT(DISTINCT MID) AS MCNT,'||reccnt||',  TABLENAME,sourcefilename,receivedmonth,sysdate FROM '||SCHEMA_NAME||'.ZZZ_ELIG'||'_'||sn||' A
                            WHERE ED <= LAST_DAY(TO_DATE('''||REFDATE||''',''YYYYMM'')) AND TD > TO_DATE('''||REFDATE||''',''YYYYMM'') GROUP BY  SCHEMANAME, TABLENAME, CCD,sourcefilename,receivedmonth';

                          ELSE
                            VBQUERY:=VBQUERY ||
                            '
                            UNION ALL
                            SELECT /*+ PARALLEL(A,8) */
                            '''||SN||''', SCHEMANAME,  '''||empgrp||''' , CCD,''Member Month'',
                            '''||REFDATE||''' AS RDT ,  COUNT(DISTINCT EID) AS ECNT,COUNT(DISTINCT MID) AS MCNT,'||reccnt||',  TABLENAME,sourcefilename,receivedmonth,sysdate
                            FROM  '||SCHEMA_NAME||'.ZZZ_ELIG'||'_'||sn||' A
                            WHERE ED <= LAST_DAY(TO_DATE('''||REFDATE||''',''YYYYMM'')) AND TD > TO_DATE('''||REFDATE||''',''YYYYMM'') GROUP BY SCHEMANAME, TABLENAME, CCD, sourcefilename,receivedmonth ';
                            END IF ;
                           VSTARTTIME:=SYSDATE;
                     END LOOP;

                  BEGIN
                  --   Dbms_Output.put_line(vbQuery);
                    EXECUTE IMMEDIATE vbQuery;
                    COMMIT;
                  EXCEPTION
                  WHEN OTHERS THEN
                    ErrMsg:=substr(SQLERRM, 1,400);
                    EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''FAILED'' , ErrMsg='''||ErrMsg||''', endtime= SYSDATE WHERE   REPORTTYPE=''DSR'' and fileid='''||fileid||''' and sublayoutid='''||sublayoutid||'''' ;
                    COMMIT;
                 END;


       BEGIN
        EXECUTE IMMEDIATE  'DROP TABLE '||SCHEMA_NAME||'.ZZZ_ELIG'||'_'||sn||' ';

       EXCEPTION WHEN OTHERS THEN NULL ; END;

END SP_DSR_MM_CALC;


PROCEDURE SP_DSR_AIP (PCID VARCHAR2,PLAYOUTID VARCHAR2, PSCHEMANAME VARCHAR2, PTABLENAME VARCHAR2 ,PFILEID VARCHAR2,SN VARCHAR2,SUBLAYOUTID VARCHAR2)
    IS

        VBQUERY   VARCHAR2(10000);
        ERRMSG        VARCHAR2(10000);
        VSTARTTIME DATE;
        CYCLESTARTDTE DATE ;
        CYCLEENDDTE DATE;
        VEMPGRP     VARCHAR(50) ;
        RECCNT  NUMBER(19,0);
        VSERVICEDTE VARCHAR2(500);
        VFILELIST VARCHAR2(4000);
        VCOND VARCHAR2(4000);
        vflagpaid VARCHAR2(50);
        vflagservice VARCHAR2(50);



    BEGIN

       vcond:= ' WHERE fileid = '''||pfileid||''' ';



      -- Check if DSR rules are set ,if yes proceed else exit.
       SELECT Count(*) INTO  RECCNT FROM (
       SELECT DISTINCT LAYOUTID FROM PS_RULES_CLIENT@flms WHERE CLIENTID=''||PCID||'' AND LAYOUTID=''||PLAYOUTID||''
       UNION ALL
       SELECT DISTINCT LAYOUTID  FROM PS_RULES_MASTER@flms WHERE LAYOUTID=''||PLAYOUTID||''
        );

        IF RECCNT=0 THEN
        EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''NO DSR RULES SET'' , endtime= SYSDATE WHERE  REPORTTYPE=''DSR'' and fileid='''||pfileid||''' and sublayoutid='''||sublayoutid||''' ' ;
        COMMIT;
        RETURN;

        END IF;


      -- Get rules for layout
       FOR RULE IN (        select layouttype, Nvl(PAIDAMT,'NULL') AS PAIDAMT  ,Nvl(ENRID,'NULL') AS ENRID,
                            Nvl(MEMID,'NULL') AS MEMID ,Nvl(BILLEDAMT,'NULL') AS BILLEDAMT ,Nvl(COVERAGECODE,NULL) AS COVERAGECODE ,
                            Nvl(EFFDATE,'NULL') AS EFFDATE , Nvl(PAIDDATE,'NULL') AS PAIDDATE ,Nvl(SERVICEDATE,'NULL') AS SERVICEDATE,Nvl(ALLOWEDAMT,'NULL') AS ALLOWEDAMT,
                            Nvl(ENRPAID,'NULL') AS ENRPAID, Nvl(TERMDATE,'NULL') AS TERMDATE , Nvl(FILLDATE,'NULL') AS FILLDATE  ,Nvl(END_DATE,'NULL') AS END_DATE FROM (
                            SELECT  layouttype, COLUMNNAME  ,
                            COALESCE(C.RULE,B.RULE,B.SRCFIELD,A.DEFAULTRULE) AS RULE
                            FROM PS_MASTER@flms  A
                            LEFT JOIN
                            (SELECT * FROM PS_RULES_CLIENT@flms WHERE CLIENTID=''||PCID||'' AND LAYOUTID=''||PLAYOUTID||'') C
                            ON
                            A.COLUMNNAME = C.TGTFIELD
                            LEFT JOIN
                            (SELECT * FROM PS_RULES_MASTER@flms WHERE LAYOUTID=''||PLAYOUTID||'') B
                            ON
                            A.COLUMNNAME = B.TGTFIELD
                            WHERE A.LAYOUTTYPE=(SELECT DATATYPE FROM IMP_LAYOUTS@flms WHERE LAYOUTID=''||PLAYOUTID||'')
                            and COLUMNNAME in ('PAIDAMT'  ,'ENRID','MEMID','BILLEDAMT','COVERAGECODE','EFFDATE' , 'PAIDDATE','SERVICEDATE','ALLOWEDAMT','ENRPAID', 'TERMDATE','FILLDATE','END_DATE') )
                          pivot ( Max(rule)  FOR columnname IN    ('PAIDAMT' as PAIDAMT,'ENRID' as ENRID,'MEMID' AS MEMID,'BILLEDAMT' AS BILLEDAMT,'COVERAGECODE' AS COVERAGECODE
                          ,'EFFDATE' AS EFFDATE ,
                          'PAIDDATE' AS PAIDDATE,'SERVICEDATE' AS SERVICEDATE,'ALLOWEDAMT' AS ALLOWEDAMT,'ENRPAID' AS ENRPAID, 'TERMDATE' AS TERMDATE , 'FILLDATE' as FILLDATE, 'END_DATE' AS END_DATE) )

                      )
        LOOP

               IF Upper(rule.layouttype) = 'ELIGIBILITIES'  THEN


--               BEGIN
--                   SELECT  CYCLESTARTDATE,   add_months(CYCLEENDDATE ,1) INTO CYCLESTARTDTE,CYCLEENDDTE  FROM HR_GLOBAL_RUNDATES@hawkeyerules
--                   WHERE clientid=''||PCID||'';
--               EXCEPTION WHEN OTHERS THEN NULL ;
--               END ;

                CYCLESTARTDTE:=Add_Months(Trunc(SYSDATE),-12) ;
                CYCLEENDDTE:=Trunc(SYSDATE) ;


               SP_DSR_MM_CALC(PFILEID ,PCID ,RULE.COVERAGECODE  ,VEMPGRP ,PSCHEMANAME,PTABLENAME ,RULE.EFFDATE ,RULE.END_DATE,RULE.MEMID ,RULE.ENRID ,CYCLESTARTDTE , CYCLEENDDTE ,PLAYOUTID ,sublayoutid,SN) ;

               END IF ;

                IF UPPER(RULE.LAYOUTTYPE) = 'CLAIMS' THEN
                  vservicedte:= Nvl(RULE.SERVICEDATE,'NULL');
                  vflagpaid:='Medical - Paid Date'    ;
                  vflagservice:='Medical - Service Date';
                ELSIF UPPER(RULE.LAYOUTTYPE) = 'RXCLAIMS'
                  then vservicedte:= Nvl(RULE.FILLDATE,'NULL') ;
                    vflagpaid:='Pharmacy - Paid Date'    ;
                  vflagservice:='Pharmacy - Fill Date';

                ELSE   vservicedte:='NULL';
               END IF;

        --------------------------------------------------------------------------------
                    vbquery := '
                    insert /*+ APPEND */ into RPT_DSR@flms
                    (SN	,
                    schemaname	,
                    empgrp	,
                    flag	,
                    yymm	,
                    billedamount	,
                    paidamount	,
                    allowedamount	,
                    employeepaid	,
                    empcount	,
                    memcount	,
                    recordcount	,
                    tablename	,
                    filename	,
                    rcvmonth	,
                    rundate
                    )
                      WITH
                        zzz_dsr AS  (
                              select /*+ parallel(a,4) */
                              '''||SN||''' AS SN,
                              a.EMPGRP empgrp,
                              to_char(nvl('||RULE.PAIDDATE||', to_date(''01/01/1900'', ''mm/dd/yyyy'')), ''yyyymm'') paid_yymm,
                              to_char(nvl('||vservicedte||', to_date(''01/01/1900'', ''mm/dd/yyyy'')), ''yyyymm'') service_yymm,
                              sum('||RULE.BILLEDAMT||') billedamount,
                              sum('||RULE.PAIDAMT||') paidamount,
                              sum('||RULE.ALLOWEDAMT||') allowedamount,
                              sum('||RULE.ENRPAID||') employeepaid,
                              '||RULE.ENRID||' empcount,
                              '||RULE.MEMID||' memcount,
                               count(*) recordcount,
                              a.sourcefilename ,
                              a.receivedmonth
                              from '||PSCHEMANAME||'.'||PTABLENAME||' a
                              ' ||VCOND || '
                              group by
                              a.EMPGRP,
                              to_char(nvl('||rule.PAIDDATE||', to_date(''01/01/1900'', ''mm/dd/yyyy'')), ''yyyymm''),
                              to_char(nvl('||vservicedte||', to_date(''01/01/1900'', ''mm/dd/yyyy'')), ''yyyymm'') ,
                              a.sourcefilename,
                              a.receivedmonth,
                              '||RULE.ENRID||' ,
                              '||RULE.MEMID||' )
                              select SN , '''||PSCHEMANAME||''', empgrp , ''Source File'' as flag, NULL as yymm, sum(billedamount) as billedamount, sum(paidamount) as paidamount
                      	        , sum(allowedamount) as allowedamount	, sum(employeepaid) as employeepaid	, count(distinct empcount ) 	as empcount
                              , count(distinct memcount) 	as memcount,  sum(recordcount)  as recordcount	, '''||PTABLENAME||''' as  tablename	, sourcefilename	, receivedmonth	, sysdate rundate
                              from  zzz_dsr group by SN , empgrp  , sourcefilename ,receivedmonth

                            ';

                            IF UPPER(RULE.LAYOUTTYPE)  IN ('CLAIMS','RXCLAIMS') THEN
                             vbquery := vbquery ||  '
                             union all
                             select SN , '''||PSCHEMANAME||''', empgrp ,'''||vflagpaid||''' as flag, paid_yymm as yymm, sum(billedamount) as billedamount, sum(paidamount) as paidamount
                      	        , sum(allowedamount) as allowedamount	, sum(employeepaid) as employeepaid	, count(distinct empcount ) 	as empcount
                              , count(distinct memcount) 	as memcount,  sum(recordcount)  as recordcount	, '''||PTABLENAME||''' as  tablename	, sourcefilename	, receivedmonth	, sysdate rundate
                              from  zzz_dsr group by SN ,empgrp ,paid_yymm  ,  sourcefilename	, receivedmonth
                              union all
                              select SN , '''||PSCHEMANAME||''', empgrp , '''||vflagservice||''' as flag, service_yymm as yymm, sum(billedamount) as billedamount, sum(paidamount) as paidamount
                      	        , sum(allowedamount) as allowedamount	, sum(employeepaid) as employeepaid	, count(distinct empcount ) 	as empcount
                              , count(distinct memcount) 	as memcount, sum(recordcount) as recordcount	, '''||PTABLENAME||''' as  tablename	, sourcefilename	, receivedmonth	, sysdate rundate
                              from  zzz_dsr group by SN ,empgrp ,service_yymm , sourcefilename	, receivedmonth'    ;
                          END IF;


                  VSTARTTIME:=SYSDATE;
                  BEGIN
                    EXECUTE IMMEDIATE vbQuery;
                    COMMIT;
                    EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''SUCCESS'' ,ErrMsg=NULL, endtime= SYSDATE WHERE   REPORTTYPE=''DSR'' and fileid='''||pfileid||''' and sublayoutid='''||sublayoutid||'''' ;
                    COMMIT;

                  EXCEPTION
                  WHEN OTHERS THEN
                      ErrMsg:=substr(SQLERRM, 1,400);
                      EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''FAILED'' , ErrMsg='''||ErrMsg||''', endtime= SYSDATE WHERE REPORTTYPE=''DSR'' and fileid='''||pfileid||''' and sublayoutid='''||sublayoutid||'''' ;
                    COMMIT;


                  END;

    END LOOP;

           -- If No rules have been setup
           SELECT  Count(*) INTO  reccnt
                            FROM PS_MASTER@flms  A
                            LEFT JOIN
                            (SELECT * FROM PS_RULES_CLIENT@flms WHERE CLIENTID=''||PCID||'' AND LAYOUTID=''||PLAYOUTID||'') C
                            ON
                            A.COLUMNNAME = C.TGTFIELD
                            LEFT JOIN
                            (SELECT * FROM PS_RULES_MASTER@flms WHERE LAYOUTID=''||PLAYOUTID||'') B
                            ON
                            A.COLUMNNAME = B.TGTFIELD
                            WHERE A.LAYOUTTYPE=(SELECT DATATYPE FROM IMP_LAYOUTS@flms WHERE LAYOUTID=''||PLAYOUTID||'')        ;

        IF reccnt =0 THEN

            vbquery:=' insert /*+ APPEND */ into RPT_DSR@flms
                    (SN	,
                    schemaname	,
                    empgrp	,
                    flag	,
                    recordcount	,
                    tablename	,
                    filename	,
                    rcvmonth	,
                    rundate
                    )

                              select /*+ parallel(a,4) */
                              '''||sn||''' as sn,
                              '''||pschemaname||''',
                               a.EMPGRP empgrp,
                              ''Source File'' ,
                               count(*),
                              '''||PTABLENAME||'''  ,
                              a.sourcefilename ,
                              a.receivedmonth   ,
                              sysdate
                              from '||PSCHEMANAME||'.'||PTABLENAME||' a
                              ' ||VCOND || '
                              group by
                              a.EMPGRP,
                              a.sourcefilename,
                              a.receivedmonth
                               ' ;

              VSTARTTIME:=SYSDATE;
                  BEGIN
                    EXECUTE IMMEDIATE vbQuery;
                    EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''SUCCESS'' , endtime= SYSDATE WHERE  REPORTTYPE=''DSR'' and fileid='''||pfileid||'''  and sublayoutid='''||sublayoutid||''' ' ;
                    COMMIT;

                  EXCEPTION
                  WHEN OTHERS THEN
                      ErrMsg:=substr(SQLERRM, 1,400);
                      EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@flms  SET status=''FAILED'' , ErrMsg='''||ErrMsg||''', endtime= SYSDATE WHERE  REPORTTYPE=''DSR'' and fileid='''||pfileid||''' and sublayoutid='''||sublayoutid||''' ' ;
                    COMMIT;


                  END;
             END IF ;

  END SP_DSR_AIP;

END pkg_aip_file_report;
/

GRANT EXECUTE ON pkg_aip_file_report TO public;

--------------------------------------------------------------------------------------------------------------------------------
------------------------------------ Wrapper procedure to invoke  PKG_AIP_FILE_REPORT --------------------
--   To be executed in Utility Schema of AIP Import Server ----------
--  CHANGE THE IMPORTSERVER NAME IF THERE ARE MULTIPLE IMPORT SERVERS BEFORE EXECUTING THE SCRIPT
--  CHANGE @FLMS to another link in case FLMS ,link has changed
--------------------------------------------------------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PROCEDURE aip_run_report
CREATE OR REPLACE PROCEDURE aip_run_report IS
VBLJOBCOUNT NUMBER;
VJOBNUM  BINARY_INTEGER;
VBLQUERY VARCHAR2(1000);
-- Procedure to get list if files for which DSR and Date Number Check Report to be generated.
-- Calls  PKG_AIP_FILE_REPORT
BEGIN

        -- get list of files for which report to be generated
  FOR i IN (
                SELECT  a.fileid||'_'||a.dmfileid AS fileid ,Nvl(b.sn,0) AS sn   FROM imp_main_log@flms a
                left JOIN  (SELECT Max(sn) AS sn , fileid FROM aip_manualrun_log@flms GROUP BY fileid ) b
                ON a.fileid||'_'||a.dmfileid=b.fileid
                WHERE
                NOT EXISTS (SELECT 1 from rpt_main_log@flms c WHERE c.fileid=a.fileid||'_'||a.dmfileid AND c.manualimport_sn=Nvl(b.sn,0) )
                AND a.status_of_import='SUCCESS'   AND IMPORT_RECORD_CNT !=0  AND IMPORTSERVER='nveigerwork'

            )
              LOOP
                   LOOP
                      DBMS_LOCK.SLEEP(0.01);
                      SELECT COUNT(*) INTO VBLJOBCOUNT FROM USER_JOBS WHERE UPPER(WHAT) LIKE '%AIP_REPORT%';

                      IF VBLJOBCOUNT < 4  THEN
                        EXIT;
                      END IF;
                    END LOOP;


                   IF  i.sn !=0 THEN
                   --  Dbms_Output.put_line(i.sn);

                    EXECUTE IMMEDIATE 'UPDATE rpt_main_log@flms SET MANUALIMPORT_SN='||i.sn||' where fileid='''||i.fileid||'''  ' ;
                    COMMIT;
                   END IF;
                  VBLQUERY:= '--AIP_REPORT
                               BEGIN PKG_AIP_FILE_REPORT.EXE_REPORT('''||i.fileid||'''); END ;';
                  Dbms_Output.put_line(VBLQUERY);
                  DBMS_JOB.SUBMIT(JOB=>VJOBNUM,WHAT=>VBLQUERY,INSTANCE=>1);
                  COMMIT;

              END LOOP;

END;
/


--------------------------------------------------------------------------------------------------------------------------------
--ORACLE  SCHEDULER
--------------------------------------------------------------------------------------------------------------------------------
------------------------------------Scheduler for PKG_AIP_FILE_REPORT -------------------

BEGIN
  -- Job defined entirely to run AIP Reports
  DBMS_SCHEDULER.create_job (
    job_name        => 'RUN_AIP_FILE_REPORTS',
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN AIP_RUN_REPORT; END ;',
    start_date      => SYSTIMESTAMP,
    repeat_interval => 'freq=minutely; interval=5',
    end_date        => NULL,
    enabled         => TRUE,
    comments        => 'Job Created to run AIP reports') ;

END;
/
--- See job status
-- SELECT owner, job_name, enabled FROM dba_scheduler_jobs  where JOB_NAME='RUN_AIP_FILE_REPORTS'
-- SELECT * FROM dba_scheduler_job_log   where JOB_NAME='RUN_AIP_FILE_REPORTS' order by   LOG_ID desc
-- SELECT * FROM   dba_scheduler_job_run_details   where JOB_NAME='RUN_AIP_FILE_REPORTS'
-- SELECT * FROM dba_scheduler_running_jobs
-- SELECT * FROM dba_jobs_running
------ to run,drop and stop the command
-- EXEC dbms_scheduler.run_job('RUN_AIP_FILE_REPORTS')
-- EXEC dbms_scheduler.enable('RUN_AIP_FILE_REPORTS')

-- EXEC dbms_scheduler.stop_job('RUN_AIP_FILE_REPORTS')            
-- EXEC dbms_scheduler.drop_job('RUN_AIP_FILE_REPORTS')


---SELECT * FROM user_jobs

---- REPORT TABLES
-- rpt_main_log , rpt_dsr , rpt_chk_date_number . Join rpt_main_log with other tables using sn
