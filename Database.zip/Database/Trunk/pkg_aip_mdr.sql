PROMPT CREATE OR REPLACE PACKAGE pkg_aip_mdr
CREATE OR REPLACE PACKAGE pkg_aip_mdr
AUTHID CURRENT_USER
IS
-- Package to run MDR based on the Request triggered from AIP Dashboard , it runs based on Report Id
-- If report ID contains list of files, MDR is generated only for those files
-- if report ID doesn't contain file list, all the files which falls into the time range of the report will be generated
-- exec pkg_aip_mdr.EXE_MDR(23,10)

procedure EXE_MDR(VREPORTID NUMBER,VSAMPLERECORD NUMBER DEFAULT 10);
PROCEDURE SP_MDR_AIP( SCHEMANAME VARCHAR2 ,TABLENAME VARCHAR2 , PAIDAMT VARCHAR2 , PFILEID VARCHAR2 ,SN IN VARCHAR2, VSAMPLERECORD NUMBER ) ;
END  pkg_aip_mdr;
/

PROMPT CREATE OR REPLACE PACKAGE BODY pkg_aip_mdr
CREATE OR REPLACE PACKAGE BODY pkg_aip_mdr IS

PROCEDURE exe_mdr(vreportid number,VSAMPLERECORD NUMBER DEFAULT 10)
IS

vcondition VARCHAR2(4000);
vFILEIDLIST VARCHAR2(4000);
vstartdate VARCHAR2(50);
venddate  VARCHAR2(50);
vsn NUMBER;
VBLPAIDAMOUNT VARCHAR2(500);
vquery VARCHAR2(4000);

TYPE FILE_REC IS RECORD
  (

    CLIENTID VARCHAR2(20),
    LAYOUTID VARCHAR2(20),
    SCHEMANAME VARCHAR2(20),
    TABLENAME  VARCHAR2(50),
    SUBLAYOUTID  VARCHAR2(20),
    SHORTPAYOR VARCHAR2(20) ,
    FILEID  VARCHAR2(4000)

  ) ;

TYPE FILE_SET IS TABLE OF FILE_REC ;
filelist FILE_SET;

VJOBNUM  BINARY_INTEGER;
VJQUERY VARCHAR2(1000);
VBLJOBCOUNT NUMBER;

BEGIN
       --Dbms_Output.put_line('start');

--        SELECT FILEID , STARTDATE,ENDDATE INTO VFILEIDLIST ,VSTARTDATE,VENDDATE
--        FROM IMP_INVENTORY_REP_LOG@FLMS A
--        JOIN  imp_inventory_rep_log_details@FLMS  B
--        ON  A.REPORTID=B.REPORTID
--        WHERE  A.REPORTID=VREPORTID  ;

--          Dbms_Output.put_line(VFILEIDLIST);



--        IF vFILEIDLIST IS   NULL THEN

--          vcondition:=  ' AND TO_DATE(A.FILE_DATE,''YYYY-MM-DD HH24:MI:SS'') BETWEEN  E.STARTDATE AND  Nvl(E.ENDDATE,sysdate)';
--       ELSE

--            vFILEIDLIST:='('''||REPLACE(vFILEIDLIST,',',''',''' )||''')' ;
--            vcondition:=  ' and a.fileid||''_''||a.dmfileid IN '||vFILEIDLIST||' ' ;
--          Dbms_Output.put_line(vcondition);

--        END IF;

        vquery:= 'SELECT  A.CLIENTID , A.LAYOUTID,d.AISCHEMANAME AS schemaname,
                           d.AITABLENAME AS tablename
                          ,C.SUBLAYOUTID AS sublayoutid , B.shortpayor  ,
                          F.fileid
                          FROM
                            IMP_MAIN_LOG@FLMS A ,
                            IMP_LAYOUTS@FLMS B,
                            IMP_SUB_LAYOUTS@FLMS C ,
                            IMP_MAIN_DET_LOG@FLMS D ,
                            IMP_INVENTORY_REP_LOG@FLMS  E ,
                            IMP_INVENTORY_REP_LOG_DETAILS@FLMS  F

                          WHERE A.LAYOUTID=B.LAYOUTID
                            AND A.LAYOUTID=C.LAYOUTID
                            AND A.FILEID||''_''||A.DMFILEID=D.FILEID
                            AND C.SUBLAYOUTID=D.SUBLAYOUTID
                            AND C.SUBLAYOUTDESC=''DATAFILE''
                            AND A.CLIENTID=E.CLIENTID
                            AND E.REPORTID=F.REPORTID
                            AND F.FILEID=D.FILEID
                            AND E.REPORTID='||VREPORTID||' ' ;



      EXECUTE IMMEDIATE vquery BULK COLLECT INTO filelist;

     IF  FILELIST.Count >=1 THEN

         FOR I IN  FILELIST.FIRST..FILELIST.LAST
         LOOP


             LOOP
                    DBMS_LOCK.SLEEP(0.01);
                    SELECT COUNT(*) INTO VBLJOBCOUNT FROM USER_JOBS WHERE UPPER(WHAT) LIKE '%--MDR%';

                    IF VBLJOBCOUNT < 4  THEN
                      EXIT;
                    END IF;
             END LOOP;


            EXECUTE IMMEDIATE 'DELETE FROM RPT_MDR@FLMS WHERE SN  in (select sn from rpt_main_log@FLMS  where   reporttype=''MDR'' and fileid= '''||filelist(i).FILEID||''' ) ';
            EXECUTE IMMEDIATE 'DELETE FROM RPT_MAIN_LOG@FLMS  WHERE FILEID ='''||filelist(i).FILEID||'''  and sublayoutid ='''||filelist(i).sublayoutid||'''  and reporttype=''MDR'' ';


            EXECUTE IMMEDIATE  'INSERT INTO rpt_main_log@FLMS  (FILEID,REPORTTYPE, STATUS, STARTTIME, ENDTIME,layoutid,sublayoutid)
                                  VALUES ('''||filelist(i).FILEID||''', ''MDR'', ''RUNNING'', SYSDATE, NULL,'''||filelist(i).layoutid||''','''||filelist(i).sublayoutid||''')' ;
            COMMIT;

            SELECT sn into vsn FROM rpt_main_log@FLMS WHERE fileid=''||filelist(i).fileid||'' AND sublayoutid=''||filelist(i).sublayoutid||'' AND reporttype='MDR';

            BEGIN

            EXECUTE IMMEDIATE   ' SELECT
                                COALESCE(C.RULE,NVL(B.RULE,B.SRCFIELD),A.DEFAULTRULE) AS RULE
                                FROM PS_MASTER@FLMS  A
                                LEFT JOIN
                                (SELECT * FROM PS_RULES_CLIENT@FLMS WHERE CLIENTID='''||filelist(i).CLIENTID||''' AND LAYOUTID='''||filelist(i).LAYOUTID||''') C
                                ON
                                A.COLUMNNAME = C.TGTFIELD
                                LEFT JOIN
                                (SELECT * FROM PS_RULES_MASTER@FLMS WHERE LAYOUTID='''||filelist(i).LAYOUTID||''') B
                                ON
                                A.COLUMNNAME = B.TGTFIELD
                                WHERE A.LAYOUTTYPE=(SELECT DATATYPE FROM IMP_LAYOUTS@FLMS WHERE LAYOUTID='''||filelist(i).LAYOUTID||''')
                                AND A.COLUMNNAME=''PAIDAMT''  ' INTO  VBLPAIDAMOUNT ;
              EXCEPTION WHEN No_Data_Found THEN NULL ;
            END;
          -- Dbms_Output.put_line(' calling MDR for : ' ||filelist(i).FILEID);
          -- Dbms_Output.put_line( 'Paidamount: ' || VBLPAIDAMOUNT);

            VBLPAIDAMOUNT:=REPLACE(Upper(VBLPAIDAMOUNT),'A.');
            --SP_MDR_AIP( filelist(i).SCHEMANAME  ,filelist(i).TABLENAME  , VBLPAIDAMOUNT , filelist(i).FILEID,VSN  ) ;

            VJQUERY:= '--MDR:'||VREPORTID||':
                      begin pkg_aip_mdr.SP_MDR_AIP( '''||filelist(i).SCHEMANAME||'''  ,'''||filelist(i).TABLENAME||'''  , '''||VBLPAIDAMOUNT||''', '''||filelist(i).FILEID||''','''||VSN||''','''||VSAMPLERECORD||''' ); end ;' ;
              --Dbms_Output.put_line( VJQUERY) ;
              DBMS_JOB.SUBMIT(JOB=>VJOBNUM,WHAT=>VJQUERY,INSTANCE=>1);
              COMMIT;


         END LOOP;
       END IF;

       LOOP
          DBMS_LOCK.SLEEP(0.1);
          SELECT COUNT(*) INTO VBLJOBCOUNT FROM USER_JOBS WHERE UPPER(WHAT) LIKE '%--MDR:'||VREPORTID||':%' AND FAILURES IS NULL ;
		--	Dbms_Output.put_line(VBLJOBCOUNT);
          IF VBLJOBCOUNT=0 THEN
                EXECUTE IMMEDIATE   'UPDATE  imp_inventory_rep_log@FLMS
                  SET   STATUS=''COMPLETE''  ,   processenddate=sysdate  WHERE reportid= '''||vreportid||''' ';
                COMMIT;
				EXIT;
          END IF;
       END LOOP;

END EXE_MDR;

PROCEDURE sp_mdr_aip(SCHEMANAME VARCHAR2 ,TABLENAME VARCHAR2 , PAIDAMT VARCHAR2 , PFILEID VARCHAR2,SN VARCHAR2 , VSAMPLERECORD NUMBER )
IS

    ROWINSERTED NUMBER ;
    ERRMSG VARCHAR2(4000);
    VBLQUERY VARCHAR2(32767);
    VNUM NUMBER;
    VBLJOBCOUNT NUMBER;
    VBLNULLCHARLIST VARCHAR2(200);
    VBLPAIDAMOUNT   VARCHAR2(4000);
    VBLCOLVALUE VARCHAR2(200);
    VJOBNUM  BINARY_INTEGER;
    vjobcnt NUMBER(19,4) ;
    RECCNT NUMBER(19,0);
    VFILELIST VARCHAR2(4000);
    vcond VARCHAR2 (4000) ;
    vclientid VARCHAR2(100);


    vquery CLOB;
    vquery1 CLOB;
    vquery2 CLOB  ;
    vqueryamt CLOB;
    VCNT NUMBER;
    vorder varchar2(500);

  TYPE FILE_REC IS RECORD
  (COLUMN_ID NUMBER ,
   COLUMN_NAME   VARCHAR2(100)
  ) ;

  TYPE FILE_SET IS TABLE OF FILE_REC ;
  T1 FILE_SET;
  div NUMBER;
  vdivcnt NUMBER ;


BEGIN
      VQUERY:=' ';
      VQUERY1:=' ';
      VQUERY2:=' ';
      vqueryamt:=' ' ;

      vcond:= ' WHERE fileid = '''||pfileid||''' ';
      VBLPAIDAMOUNT:=NVL(REPLACE(PAIDAMT,'''',''''''),0);

     -- IF  VBLPAIDAMOUNT=NULL OR VBLPAIDAMOUNT='0' THEN
        vorder:= ' order by count_notnull ';
      --ELSE
        --vorder:= ' order by PAIDAMT ';
      --END IF ;

      -- bulk collect



      EXECUTE IMMEDIATE
        'SELECT COLUMN_ID,COLUMN_NAME
        FROM ALL_TAB_COLS
        WHERE OWNER=UPPER('''||SCHEMANAME||''')
        AND TABLE_NAME=UPPER('''||TABLENAME||''')
        AND (COLUMN_NAME  ) NOT LIKE ''UDF%'' AND COLUMN_NAME  NOT IN
        (''SOURCEFILENAME'',''RECEIVEDMONTH'',''IMPORTEDDATE'' ,''HASHKEY'',''ROWNUMBER'',''CLIENTID'',''EMPGRP'', ''FILEID'',''PAYORNAME'')
        ORDER BY COLUMN_ID '  BULK COLLECT INTO T1 ;



      VCNT:=1;
      vdivcnt:=1;
      vquery:='SELECT /* + PARALLEL */ F1,TOTALCOUNT,F2,F3,F4 FROM ( SELECT ';
      vqueryamt:=' with zzz_mdr_'||sn||' as (select * from '||SCHEMANAME||'.'||TABLENAME||vcond|| ' ) select * from (';


         IF t1.Count <=20 THEN
         div:=t1.Count  ;
         else
         div:=ceil(t1.Count/4 ) ;
         END IF ;

       IF t1.Count >=1 THEN

        FOR I IN T1.FIRST..T1.LAST
           LOOP

              VCNT:=VCNT+1;
              VBLCOLVALUE:='NVL(CAST('||T1(i).COLUMN_NAME||' AS VARCHAR2(500)),''BLANKNULL'')';
              -- dbms_output.put_line(VCNT);

              Dbms_Lob.append(VQUERY1,''''||T1(i).COLUMN_NAME||''' AS F1'||VCNT||',COUNT('||T1(i).COLUMN_NAME||') AS F2'||VCNT||' , COUNT(DISTINCT '||T1(i).COLUMN_NAME||') AS F3'||VCNT||' ,'||T1(i).COLUMN_ID ||' AS F4'||VCNT||', ') ;
              Dbms_Lob.append(VQUERY2,' ( F1'||VCNT||', F2'||VCNT||', F3'||VCNT|| ', F4'||VCNT||'),') ;

              Dbms_Lob.append(vqueryamt , ' select * from ( select /* + PARALLEL */ '''||T1(i).COLUMN_NAME||''' as fieldname,'|| VBLCOLVALUE||' as COLVALUE,count(*) as COUNT_NOTNULL , sum('||VBLPAIDAMOUNT||') as PAIDAMT,
              '||T1(i).column_id||' as column_id FROM zzz_mdr_'||sn||' group by '||T1(i).COLUMN_NAME||' , '||T1(i).column_id ||vorder||'  desc ) where rownum <= '|| VSAMPLERECORD ||' union all');



             If (  vcnt > div   )  THEN


               vdivcnt:=vdivcnt+1    ;
            --   dbms_output.put_line(vdivcnt);

              Dbms_Lob.append( vquery , VQUERY1||' count(*) as TOTALCOUNT FROM '||SCHEMANAME||'.'||TABLENAME||vcond||' ) UNPIVOT ( (F1,F2,F3,F4) FOR A IN ( '|| RTrim(VQUERY2,',') || '))') ;
             BEGIN
                    BEGIN
                        EXECUTE IMMEDIATE 'drop table  '||SCHEMANAME||'.ZZZ_mdr_1_'||sn||' ';
                        EXECUTE IMMEDIATE 'drop table  '||SCHEMANAME||'.ZZZ_mdr_1_'||sn||' ';
                    EXCEPTION WHEN OTHERS THEN NULL ;
                    END ;
                    EXECUTE IMMEDIATE 'CREATE TABLE '||SCHEMANAME||'.ZZZ_mdr_1_'||sn||' AS ' || vquery;
                    EXECUTE IMMEDIATE 'CREATE TABLE '||SCHEMANAME||'.ZZZ_mdr_2_'||sn||' AS ' || rTrim(vqueryamt,'union all')||')';

                -- Dbms_Output.put_line(vquery);
                -- Dbms_Output.put_line(vqueryamt);

                    EXECUTE IMMEDIATE
                        'insert into rpt_mdr@FLMS (sn,typevalue,fieldname,colvalue,totalcount,count_notnull,count_distinct,paidamt,COLUMN_ID)
                        select '''||sn||''' as SN, ''DENSITY'' as TYPEVALUE, F1, ''COLVALUE'' as COLVALUE, TOTALCOUNT, F2, F3, 0 as PAIDAMT, F4 from '||SCHEMANAME||'.ZZZ_mdr_1_'||sn||'
                        UNION ALL
                        SELECT '''||sn||''' as sn, Decode(colvalue,''BLANKNULL'',''TOPREC-NULL'',''TOPREC'') AS typevalue, fieldname, colvalue, 0 as totalcount, count_notnull,
                        0 as count_distinct, paidamt, column_id from '||SCHEMANAME||'.ZZZ_mdr_2_'||sn||'
                        ';
                    COMMIT;
                      EXECUTE IMMEDIATE 'drop TABLE '||SCHEMANAME||'.ZZZ_mdr_1_'||sn||' ';
                      EXECUTE IMMEDIATE 'drop TABLE '||SCHEMANAME||'.ZZZ_mdr_2_'||sn||' ';

              EXCEPTION WHEN OTHERS  THEN
           --  Dbms_Output.put_line( 'In EXP') ;

                      ERRMSG:=substr(SQLERRM, 1,100);
                      EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@FLMS  SET status=''FAILED'' , endtime= SYSDATE  , ERRMSG= '''||ERRMSG||'''
                      WHERE  REPORTTYPE=''MDR'' and fileid='''||pfileid||''' ' ;
                      COMMIT;

                      EXIT;
              END ;


                VCNT:=1;
                VQUERY1:=' ';
                VQUERY2:=' ';

                vquery:='SELECT /* + PARALLEL */ F1,TOTALCOUNT,F2,F3,F4 FROM ( SELECT ';
                vqueryamt:=' with zzz_mdr_'||sn||' as (select * from '||SCHEMANAME||'.'||TABLENAME||vcond|| ' ) select * from (';

                IF vdivcnt=4 THEN div:= t1.Count - (div * 3 ) ; END IF;
            END IF ;

          END LOOP;
           IF vdivcnt=5  THEN
            EXECUTE IMMEDIATE 'UPDATE  rpt_main_log@FLMS  SET status=''SUCCESS'' , endtime= SYSDATE  , ERRMSG=NULL
                      WHERE  REPORTTYPE=''MDR'' and fileid='''||pfileid||''' ' ;
                      COMMIT;
            END IF;
         END IF ;


END SP_MDR_AIP;
END pkg_aip_mdr;
/

GRANT EXECUTE ON pkg_aip_mdr TO public;
