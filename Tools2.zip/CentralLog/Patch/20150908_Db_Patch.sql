--Chart Features
ALTER TABLE datapointsconfig ADD  CHART_QUERY VARCHAR2(1000);

SELECT * from   datapointsconfig ORDER BY id ASC;

SELECT CHART_QUERY from CENTRALLOG.datapointsconfig WHERE NAME = 'Lives (A/T)';

------------------------------
--Chart Query Features Patch
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--ID=1
SELECT * FROM ( SELECT * FROM  ( SELECT APP_ID AS "APP ID", ACTIVE_LIVES "Active Lives", TERMED_LIVES "Termed Lives" FROM CENTRALLOG.VW_LIVES_DETAILS order by APP_ID ) ORDER BY "Active Lives" DESC, "Termed Lives" DESC ) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT APP_ID AS "APP ID", ACTIVE_LIVES "Active Lives", TERMED_LIVES "Termed Lives" FROM CENTRALLOG.VW_LIVES_DETAILS order by APP_ID ) ORDER BY "Active Lives" DESC, "Termed Lives" DESC ) WHERE ROWNUM <= 5' WHERE id = 1;
--ID=2
SELECT * FROM ( SELECT * FROM  ( SELECT APP_ID "APP ID", CLMCOUNT_MED "Medical Claims", CLMCOUNT_RX "Rx Claims", TOTAL_LIVES "Total Lives" FROM CENTRALLOG.VW_CLIENT_METRIC ORDER BY APP_ID,P_MONTH desc ) ORDER BY "Medical Claims" DESC, "Rx Claims" DESC, "Total Lives" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT APP_ID "APP ID", CLMCOUNT_MED "Medical Claims", CLMCOUNT_RX "Rx Claims", TOTAL_LIVES "Total Lives" FROM CENTRALLOG.VW_CLIENT_METRIC ORDER BY APP_ID,P_MONTH desc ) ORDER BY "Medical Claims" DESC, "Rx Claims" DESC, "Total Lives" DESC) WHERE ROWNUM <= 5' WHERE id = 2;
--ID=3
SELECT * FROM ( SELECT * FROM  ( SELECT p_month "Processed Month", count_numbers "# of App processed" FROM vw_app_process_monthly ORDER BY p_month desc ) ORDER BY "# of App processed" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT p_month "Processed Month", count_numbers "# of App processed" FROM vw_app_process_monthly ORDER BY p_month desc ) ORDER BY "# of App processed" DESC) WHERE ROWNUM <= 5' WHERE id=3;

--ID=5
SELECT * FROM ( SELECT * FROM  ( SELECT appid "APP ID", reprocessing_count "Reprocessing Count", total_lives "Lives Reprocessed", total_claims "Total Claims",   total_rxclaims "Total Rxclaims"   FROM VW_REPROCESSING_DETAILS ORDER BY appid,p_month DESC ) ORDER BY "Reprocessing Count" DESC, "Lives Reprocessed" DESC, "Total Claims"  DESC, "Total Rxclaims"  DESC ) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT appid "APP ID", reprocessing_count "Reprocessing Count", total_lives "Lives Reprocessed", total_claims "Total Claims",   total_rxclaims "Total Rxclaims"   FROM VW_REPROCESSING_DETAILS ORDER BY appid,p_month DESC ) ORDER BY "Reprocessing Count" DESC, "Lives Reprocessed" DESC, "Total Claims"  DESC, "Total Rxclaims"  DESC ) WHERE ROWNUM <= 5' WHERE id=5;

--ID=7
SELECT * FROM ( SELECT * FROM  ( SELECT clientid "Client ID",payordes "Payor Name",tablename "Table Name" from vw_pyr_feed order by clientid ) ORDER BY "Payor Name" DESC, "Table Name" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT clientid "Client ID",payordes "Payor Name",tablename "Table Name" from vw_pyr_feed order by clientid ) ORDER BY "Payor Name" DESC, "Table Name" DESC) WHERE ROWNUM <= 5' WHERE id=7;

--ID=8
SELECT * FROM ( SELECT * FROM  ( SELECT sourceid "Source ID",filecount "Number of Files",sum_size_mb "Size in MB" from files_by_clientsource order by sourceid,p_month  DESC  ) ORDER BY "Number of Files" DESC, "Size in MB" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT sourceid "Source ID",filecount "Number of Files",sum_size_mb "Size in MB" from files_by_clientsource order by sourceid,p_month  DESC  ) ORDER BY "Number of Files" DESC, "Size in MB" DESC) WHERE ROWNUM <= 5' WHERE id=8;

--ID=9
SELECT * FROM ( SELECT * FROM  ( SELECT dataproviderid "Client ID",totalefforthours "Rework Effort" FROM vw_defect_cr_imp order by dataproviderid, p_month desc  ) ORDER BY "Rework Effort" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT dataproviderid "Client ID",totalefforthours "Rework Effort" FROM vw_defect_cr_imp order by dataproviderid, p_month desc  ) ORDER BY "Rework Effort" DESC) WHERE ROWNUM <= 5' WHERE id=9;

--ID=10
SELECT * FROM ( SELECT * FROM  ( SELECT app_id "APP ID",total_hrs "Hours" FROM VW_PROCESSING_HOURS order by app_id,p_month desc  ) ORDER BY "Hours" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT app_id "APP ID",total_hrs "Hours" FROM VW_PROCESSING_HOURS order by app_id,p_month desc  ) ORDER BY "Hours" DESC) WHERE ROWNUM <= 5' WHERE id=10;

--ID=11
SELECT * FROM ( SELECT * FROM  ( SELECT app_id "APP ID",total_hrs "Hours" FROM VW_PROCESSING_HOURS order by app_id,p_month desc  ) ORDER BY "Hours" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  ( SELECT app_id "APP ID",total_hrs "Hours" FROM VW_PROCESSING_HOURS order by app_id,p_month desc  ) ORDER BY "Hours" DESC) WHERE ROWNUM <= 5' WHERE id=11;

--ID=14
SELECT * FROM ( SELECT * FROM  (  SELECT HOST_NAME "Server",ASM_SPACE "Space Used(%)",CPU_UTIL "CPU Used(%)", MEM_UTIL "Memory Used(%)" FROM UTILIZATION_METRICS_COLLECTION WHERE ASM_SPACE IS NOT NULL AND CPU_UTIL IS NOT NULL AND MEM_UTIL IS NOT NULL   ORDER BY COLLECTION_DATE DESC) ORDER BY "Space Used(%)" DESC,"CPU Used(%)" DESC,"Memory Used(%)" DESC ) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='SELECT * FROM ( SELECT * FROM  (  SELECT HOST_NAME "Server",ASM_SPACE "Space Used(%)",CPU_UTIL "CPU Used(%)", MEM_UTIL "Memory Used(%)" FROM UTILIZATION_METRICS_COLLECTION WHERE ASM_SPACE IS NOT NULL AND CPU_UTIL IS NOT NULL AND MEM_UTIL IS NOT NULL   ORDER BY COLLECTION_DATE DESC) ORDER BY "Space Used(%)" DESC,"CPU Used(%)" DESC,"Memory Used(%)" DESC ) WHERE ROWNUM <= 5' WHERE id=14;

--ID=15
SELECT * FROM (  ) ORDER BY "Hours" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='' WHERE id=14;

--ID=16
SELECT * FROM (  ) ORDER BY "Hours" DESC) WHERE ROWNUM <= 5;
UPDATE datapointsconfig SET CHART_QUERY='' WHERE id=14;

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------------
--ICE REPORT Features Patch
---------------------------------------------------------------------------------------------------------
SELECT * FROM  categoryfordatapoints ORDER BY id asc;
INSERT INTO categoryfordatapoints (NAME, DES) VALUES (6, 'ICE Report', '');

SELECT * FROM datapointsconfig ORDER BY id asc;
INSERT INTO datapointsconfig (ID,NAME,DES,QUERY,CREATEDON,CREATEDBY,CATEGORYID,CHART_QUERY)
VALUES (16, 'AGE Report', 'AGE Report', 'select * from datapointsconfig',SYSDATE, 'bpupadhyay',6, '');

UPDATE datapointsconfig SET QUERY='SELECT issuetypename,phasename,days FROM vw_vw_age_report_ice' WHERE id=16;


--Category Query
SELECT  a.CATEGORYID AS CATEGORYID, b.NAME as categoryName
FROM datapointsconfig a, categoryfordatapoints b
WHERE a.categoryid=b.id ORDER BY a.categoryid , a.id;

--Menu Query
SELECT a.NAME AS labelName, a.QUERY AS sql, a.CATEGORYID AS CATEGORYID, b.NAME as categoryName
FROM datapointsconfig a, categoryfordatapoints b
WHERE a.categoryid=b.id  ORDER BY a.categoryid , a.id

-----------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------------------
---Header Map Feature Patch
-----------------------------------------------------------------------------------------------------------
ALTER TABLE datapointsconfig ADD  HEADER_MAP VARCHAR2(1000);

SELECT * from   datapointsconfig ORDER BY id ASC;

--eg. --App Detail(APP ID@APP NAME),Client Detail(CLIENT ID@CLIENT NAME)

--ID=1
UPDATE datapointsconfig SET HEADER_MAP='App Detail(APP ID@APP NAME)' WHERE id = 1;




