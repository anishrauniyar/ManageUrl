package com.vit.service;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import com.vit.dao.LogDAO;
import com.vit.domain.ChartModel;
import com.vit.domain.DataPoint;
import com.vit.domain.DataPoints;
import com.vit.domain.LogFile;
import com.vit.domain.SQLColumn;
import com.vit.utility.WebConstants;

/**
 * ServiceImpl for Central Log
 *
 * @author i80260
 * @modified by vadhikari
 *
 */
public class LogServiceImpl implements LogService {

    private LogDAO logDao;

    @Override
    public LogFile selectDataPointsDetails(LogFile logFileObject)
            throws Exception {
        return logDao.selectDataPointsDetails(logFileObject);
    }

    public void setLogDao(LogDAO logDao) {
        this.logDao = logDao;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.service.LogService#getMetaDataInformation(java.lang.String)
     */
    @Override
    public List<SQLColumn> getMetaDataInformation(String strSQL)
            throws Exception {
        return logDao.getMetaDataInformation(strSQL);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.service.LogService#prepareQuery(com.vit.domain.LogFile)
     */
    @Override
    public LogFile prepareQuery(LogFile logFileObject,
            LinkedHashMap<String, String> appID,
            LinkedHashMap<String, String> clientID) throws Exception {
        String strSQL = "SELECT ";
        String selectSQL = " ";
        String filterSQL = " WHERE 1 = 1 ";
        String orderby = " Order By 1 ";
        String sql = "";
        List<String> labelList = new ArrayList<String>();
        List<String> dataTypeList = new ArrayList<String>();
        int i = 0;
        for (SQLColumn column : logFileObject.getDataPoint().getDbColumnList()) {
            if (column.isSelected()) {
                i++;
                if (i != 1) {
                    selectSQL += ", ";
                }

                selectSQL += "\"" + column.getName() + "\"";
                // selectSQL += column.getLabelAs();
                labelList.add(column.getName());
                dataTypeList.add(column.getTypeName());

                if (logFileObject.getSortBy() != null) {
                    if (column.getName().equalsIgnoreCase(
                            logFileObject.getSortFieldName())) {
                        orderby = " Order By " + column.getLabelAs() + " "
                                + logFileObject.getSortBy();
                    }

                }

                if (column.getFilterCondition() != null
                        && !column.getFilterCondition().trim().isEmpty()) {
                    filterSQL += getFormattedFilterCondition(column);

                } else if (column.getTypeName().equalsIgnoreCase("VARCHAR2")
                        && column.getName().equalsIgnoreCase("Processed Month")) {

                    if (!column.getYear().equalsIgnoreCase("ALL")) {
                        if (!column.getMonth().equalsIgnoreCase("ALL")) {

                            filterSQL += "AND  UPPER(" + column.getLabelAs()
                                    + ")  " + "LIKE '%" + column.getYear()
                                    + "-" + column.getMonth() + "%' ESCAPE '!'";
                        } else {
                            filterSQL += "AND  UPPER(" + column.getLabelAs()
                                    + ")  " + "LIKE '%" + column.getYear()
                                    + "-%' ESCAPE '!'";
                        }

                    } else {
                        if (!column.getMonth().equalsIgnoreCase("ALL")) {

                            filterSQL += "AND  UPPER(" + column.getLabelAs()
                                    + ")  " + "LIKE '%-" + column.getMonth()
                                    + "%' ESCAPE '!'";
                        }

                    }

                } else if ((logFileObject.getAppID() != null)
                        && (column.getName().equalsIgnoreCase("app id"))) {
                    if (logFileObject.getAppID().length > 0) {
                        String[] appids = logFileObject.getAppID();
                        filterSQL += "AND " + column.getLabelAs() + " in (";
                        int count = 0;
                        for (String appid : appids) {
                            // System.out.println(client);
                            count++;
                            if (count != appids.length) {
                                filterSQL += "'" + appid + "',";
                            } else {
                                filterSQL += "'" + appid + "'";
                            }
                        }

                        filterSQL += "  ) ";
                    } else if (column.isAllClientSelected()) {
                        Set set = appID.entrySet();
                        Iterator itr = set.iterator();

                        filterSQL += "AND " + column.getLabelAs() + " in (";
                        int count = 0;

                        while (itr.hasNext()) {
                            count++;
                            Map.Entry me = (Map.Entry) itr.next();
                            if (count != appID.size()) {
                                filterSQL += "'" + me.getKey() + "',";
                            } else {
                                filterSQL += "'" + me.getKey() + "'";
                            }

                        }

                        filterSQL += "  ) ";

                    }

                } else if ((logFileObject.getAppName() != null)
                        && (column.getName().equalsIgnoreCase("app name"))
                        && logFileObject.getAppName().length > 0) {
                    String[] appids = logFileObject.getAppName();
                    filterSQL += "AND " + column.getLabelAs() + " in (";
                    int count = 0;
                    for (String appid : appids) {
                        // System.out.println(client);
                        count++;
                        if (count != appids.length) {
                            filterSQL += "'" + appid + "',";
                        } else {
                            filterSQL += "'" + appid + "'";
                        }
                    }

                    filterSQL += "  ) ";
                } else if ((logFileObject.getClientID() != null)
                        && (column.getName().equalsIgnoreCase("client id"))) {
                    if (logFileObject.getClientID().length > 0) {

                        String[] appids = logFileObject.getClientID();
                        filterSQL += "AND " + column.getLabelAs() + " in (";
                        int count = 0;
                        for (String appid : appids) {
                            // System.out.println(client);
                            count++;
                            if (count != appids.length) {
                                filterSQL += "'" + appid + "',";
                            } else {
                                filterSQL += "'" + appid + "'";
                            }
                        }

                        filterSQL += "  ) ";
                    } else if (column.isAllClientSelected()) {
                        Set set = clientID.entrySet();
                        Iterator itr = set.iterator();

                        filterSQL += "AND " + column.getLabelAs() + " in (";
                        int count = 0;

                        while (itr.hasNext()) {
                            count++;
                            Map.Entry me = (Map.Entry) itr.next();
                            if (count != clientID.size()) {
                                filterSQL += "'" + me.getKey() + "',";
                            } else {
                                filterSQL += "'" + me.getKey() + "'";
                            }

                        }

                        filterSQL += "  ) ";
                    }
                } else if ((logFileObject.getClientName() != null)
                        && (column.getName().equalsIgnoreCase("client name"))
                        && logFileObject.getClientName().length > 0) {
                    String[] appids = logFileObject.getClientName();
                    filterSQL += "AND " + column.getLabelAs() + " in (";
                    int count = 0;
                    for (String appid : appids) {
                        // System.out.println(client);
                        count++;
                        if (count != appids.length) {
                            filterSQL += "'" + appid + "',";
                        } else {
                            filterSQL += "'" + appid + "'";
                        }
                    }

                    filterSQL += "  ) ";
                } else if (column.getTypeName().equalsIgnoreCase("DATE")) {

                    filterSQL += getFormattedFilterCondition(column);

                } else if (column.getTypeName().equalsIgnoreCase("VARCHAR2")
                        && column.getName().equalsIgnoreCase("defect type")
                        && !column.getDefectType().equalsIgnoreCase("ALL")) {
                    filterSQL += "AND  UPPER(" + column.getLabelAs() + ")  "
                            + "LIKE '%" + column.getDefectType().toUpperCase()
                            + "%' ESCAPE '!'";

                } else if (column.getTypeName().equalsIgnoreCase("CHAR")
                        && column.getName().equalsIgnoreCase("stage")
                        && !column.getStage().equalsIgnoreCase("ALL")) {
                    filterSQL += "AND  UPPER(" + column.getLabelAs() + ")  "
                            + "LIKE '%" + column.getStage().toUpperCase()
                            + "%' ESCAPE '!'";

                }
            }

        }

        int pos = logFileObject.getDataPoint().getSql().toLowerCase()
                .indexOf("order");
        if (pos > 0) {
            sql = logFileObject.getDataPoint().getSql().substring(0, pos);
            if (logFileObject.getSortBy().length() == 0) {
                orderby = logFileObject
                        .getDataPoint()
                        .getSql()
                        .substring(pos,
                                logFileObject.getDataPoint().getSql().length());
            }

        } else {
            sql = logFileObject.getDataPoint().getSql();
        }

        logFileObject.setQueryForExcel(strSQL + selectSQL + " FROM (  " + sql
                + filterSQL + orderby + " )");
        strSQL = strSQL
                + selectSQL
                + " FROM (  "
                + sql.replace("SELECT", "SELECT ROW_NUMBER() OVER ( " + orderby
                        + " ) AS rn, ")
                + filterSQL
                + orderby
                + "  ) "
                + " "
                + " WHERE 1= 1 "
                + "AND rn BETWEEN '"
                + (logFileObject.getCurrPage() * WebConstants.PAGE_SIZE - (WebConstants.PAGE_SIZE - 1))
                + "'  and  '"
                + (logFileObject.getCurrPage() * WebConstants.PAGE_SIZE) + "' ";

        logFileObject.setQueryForPagination(" SELECT COUNT(*) FROM ( " + sql
                + filterSQL + orderby + " ) ");
        logFileObject.setPreparedQuery(strSQL);

        logFileObject.setLabelList(labelList);
        logFileObject.setDataTypeList(dataTypeList);
        return logFileObject;
    }

    public String getFormattedFilterCondition(SQLColumn column) {

        int col = 0;

        if (column.getTypeName().equalsIgnoreCase("DATE")) {
            col = 1;
        } else if (column.getTypeName().equalsIgnoreCase("NUMBER")) {
            col = 2;
        }

        switch (col) {

            case 1:
                return "AND " + column.getLabelAs() + " " + " BETWEEN to_date('"
                        + column.getStartDate() + "','dd/mm/yyyy') AND to_date('"
                        + column.getEndDate() + "','dd/mm/yyyy')";

            case 2:

                return "AND " + column.getLabelAs() + " " + column.getLogicalOps()
                        + " " + column.getFilterCondition().trim();

            default:
                return "AND  UPPER("
                        + column.getLabelAs()
                        + ")  "
                        + "LIKE '%"
                        + changeSQLText(column.getFilterCondition().trim())
                        .toUpperCase() + "%' ESCAPE '!'";

        }
    }

    public String getDateRange(String d) {
        String delim = "";
        String d1 = "";
        String d2 = "";
        String x = "";
        d = d.toLowerCase().replaceAll("between", "").replaceAll("and", "-");
        if (d.indexOf(">") >= 0) {
            delim = ">";
        } else if (d.indexOf("<") >= 0) {
            delim = "<";
        } else if (d.indexOf("-") >= 0) {
            delim = "-";
        }

        if (delim.length() > 0) {
            StringTokenizer st = new StringTokenizer(d, delim);
            while (st.hasMoreTokens()) {
                d2 = st.nextElement().toString();
                if (d1.length() == 0) {
                    d1 = d2;
                }
            }
        } else {
            d2 = d;
            delim = "=";
        }

        if (delim.equals("-")) {
            x = " BETWEEN to_date('" + d1 + "','mm/dd/yyyy') AND to_date('"
                    + d2 + "','mm/dd/yyyy')";
        } else {
            x = " " + delim + " to_date('" + d2 + "','mm/dd/yyyy')";
        }
        return x;
    }

    private String getSQLSubQuery(String s) {
        if ((s.indexOf(">") == 0) || (s.indexOf("<") == 0)) {
            return (s);
        } else if (s.indexOf("-") > 0) {
            return (" BETWEEN " + s.substring(0, s.indexOf("-")) + " AND " + s
                    .substring(s.indexOf("-") + 1));
        } else {
            return ("=" + s);
        }
    }

    private String changeSQLText(String s) {
        if (s.trim().equals("")) {
            return ("NULL");
        } else {

            s = s.replaceAll("'", "''").trim();
            // s=s.replaceAll("\\[","[[]").trim();
            s = s.replaceAll("\\_", "!_").trim();
            s = s.replaceAll("\\%", "!%").trim();
            return s;
        }
    }

    @Override
    public LogFile getQueryResult(LogFile logFileObject) throws Exception {
        return logDao.getQueryResult(logFileObject);
    }

    /*
     * public static void main(String[] args) { LogServiceImpl impl = new
     * LogServiceImpl(); String test = impl.getSQLSubQuery("20");
     * System.out.println(test); }
     */
    @Override
    public int getQueryResultForPagination(LogFile logFileObject)
            throws Exception {
        return logDao.getQueryResultForPagination(logFileObject);
    }

    @Override
    public List<String> getData(String strSQL) throws Exception {

        return logDao.getData(strSQL);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.service.LogService#getMenu(java.lang.String)
     */
    @Override
    public List<DataPoint> getMenu(String strSQL) throws Exception {

        return logDao.getMenu(strSQL);
    }

    @Override
    public boolean updateDataSourceConfiguration(LogFile logFileObject)
            throws Exception {
        return logDao.updateDataSourceConfiguration(logFileObject);
    }

    @Override
    public LinkedHashMap<String, String> getClientAppMapList(String strSQL)
            throws Exception {

        return logDao.getClientAppMapList(strSQL);
    }

    @Override
    public boolean updateHitCount(LogFile logFileObject)
            throws Exception {
        return logDao.updateHitCount(logFileObject);
    }

    public static void main(String[] args) {
        String sql = "SELECT APP_ID 'APP ID',APP_ID , APP_NAME AS 'APPER', APP_NAME 'APP NAME', ACTIVE_LIVES 'Active Lives', TERMED_LIVES 'Termed Lives' FROM CENTRALLOG.VW_LIVES_DETAILS"
                .toUpperCase().trim().replace("SELECT", "").replace("AS", " ");
        int position = sql.indexOf("FROM");
        sql = sql.substring(0, position);
        System.out.println("sql:" + sql);
        Hashtable hs = new Hashtable();
        String[] tokens = sql.split(",");
        for (String token : tokens) {
            String[] tok = token.split("'");
            if (tok.length > 1 && tok.length < 3) {
                hs.put(tok[1].trim(), tok[0].trim());
                System.out.println("[" + tok[1].trim() + "]" + "["
                        + tok[0].trim() + "]");

            }
        }

        System.out.println("VAL:" + hs.get("APP NAME"));

    }

    @Override
    public List<ChartModel> generateChart(String datapointName) {
        return logDao.generateChart(datapointName);
    }

    public Object fireQuery(String psQuery, Object[] args, Class<?> classs) {
        return logDao.fireQuery(psQuery, args, classs);
    }

}
