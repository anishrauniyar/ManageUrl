package com.vit.service;

import com.vit.domain.ChartModel;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.vit.domain.DataPoint;
import com.vit.domain.DataPoints;
import com.vit.domain.LogFile;
import com.vit.domain.SQLColumn;

/**
 * Service for Central Log
 *
 * @author i80260
 * @modified by Vadhikari
 */
public interface LogService {

    LogFile selectDataPointsDetails(LogFile logFileObject) throws Exception;

    List<SQLColumn> getMetaDataInformation(String strSQL) throws Exception;

    LogFile prepareQuery(LogFile logFileObject, LinkedHashMap<String, String> appID, LinkedHashMap<String, String> clientID) throws Exception;

    LogFile getQueryResult(LogFile logFileObject) throws Exception;

    int getQueryResultForPagination(LogFile logFileObject) throws Exception;

    List<String> getData(String strSQL) throws Exception;

    List<DataPoint> getMenu(String strSQL) throws Exception;

    LinkedHashMap<String, String> getClientAppMapList(String strSQL) throws Exception;

    boolean updateDataSourceConfiguration(LogFile logFileObject) throws Exception;

    public List<ChartModel> generateChart(String datapointName);

    boolean updateHitCount(LogFile logFileObject) throws Exception;

    Object fireQuery(String psQuery, Object[] args, Class<?> classs);
}
