/**
 * 
 */
package com.vit.utility;

/**
 * @author i80874
 *
 */

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.vit.domain.LogFile;
import com.vit.domain.SQLColumn;

/**
 * This class builds an Excel spreadsheet document using Apache POI library.
 * 
 * @author www.codejava.net
 * 
 */
public class ExcelBuilder extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		WorkBookUtil bookUtil = new WorkBookUtil(workbook);

		// get data model which is passed by the Spring container
		LogFile logFileObject = (LogFile) model.get("excelData");
		
		response.setHeader("Content-Disposition", "inline; filename=CentralLog.xls");

		HSSFSheet sheet = workbook.createSheet("sheet1");
		int tempRowIndex = 0;
		Row header = sheet.createRow(tempRowIndex);
		int tempCell = 0;

		for (SQLColumn column : logFileObject.getDataPoint().getDbColumnList()) {

			Cell cell = header.createCell(tempCell);
			cell.setCellStyle(bookUtil.getStyle().get("heading_style"));
			cell.setCellValue(column.getName());
			tempCell++;

		}
		tempRowIndex++;
		for (Map<String, Object> map : logFileObject.getLogList()) {

			Row dataRow = sheet.createRow(tempRowIndex);
			tempCell = 0;
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				Cell dataCell = dataRow.createCell(tempCell);
				
				Object value = entry.getValue();
				if (value != null) {
					if (value instanceof String) {
						dataCell.setCellStyle(bookUtil.getStyle().get("normal_style"));
						dataCell.setCellValue((String) value);
					} else if (value instanceof Double) {
						dataCell.setCellStyle(bookUtil.getStyle().get("integer_style"));
						dataCell.setCellValue((Double) value);		
						
					} else if (value instanceof BigDecimal) {
						dataCell.setCellStyle(bookUtil.getStyle().get("integer_style"));
						dataCell.setCellValue(new Double(value.toString()));
						
					} else if (value instanceof Date) {
						dataCell.setCellStyle(bookUtil.getStyle().get("normal_style"));
						dataCell.setCellValue((Date) value);
					} else {
						dataCell.setCellStyle(bookUtil.getStyle().get("normal_style"));
						dataCell.setCellValue(value.toString());
					}
				} else {
					dataCell.setCellValue("");
				}
				tempCell++;
			}

			tempRowIndex++;
		}

	}
	

}
