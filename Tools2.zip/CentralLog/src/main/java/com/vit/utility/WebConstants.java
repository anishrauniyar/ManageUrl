package com.vit.utility;
/**
 * Constants
 * @author i80260
 *
 */
public interface WebConstants 
{
	String BASE_URL = "CentralLog";
	int PAGE_SIZE = 20; 
	int DEFAULT_START_INDEX = 0;
	String INITIAL_INDEX = "initialIndex";
	String MAXINDEX = "maxIndex";
	String DASH = "-";
	String CFL_XML = "centralLogConfig.xml";
	String VERTICAL_PIPE = "\\|";
	String ARROW = "->";
	String COMMA = ",";
	String EMPTY_SPACE = "";
	String SINGLE_SPACE = " ";
	String TAB = "\t";
	String NEWLINE = "\n";
	String FALSE = "false";
	String TRUE = "true";
	String WHERE = "WHERE";
	String DOUBLE_ARROW = "-->";
	String EQUALS = "=";
	String OR = "OR";
	String QUOTE = "'";
	String AND = "AND";
	String TABLENAME = "TABLENAME";
	String FIELDNAME = "FIELDNAME";
	String ORDER_BY = "ORDER BY";
	String REPLACE_QUERY = "REPLACE_QUERY";
	String AS = " AS ";
	String SINGLE_QUOTE = "\"";
	String COUNT_STAR = "COUNT(*)";
	String ALL_VALUE = "-ALL-";
	String LIKE = "LIKE";
	String WILDCARD = "%";
	String SEMICOLON = ";";
	
	String DEFAULT_DATE_FORMAT = "mm/dd/yyyy";
	
	String menuQuery = "SELECT a.NAME AS labelName, a.QUERY AS sql, a.CATEGORYID AS CATEGORYID, b.NAME as categoryName " +
						" FROM datapointsconfig a, categoryfordatapoints b" +
						" WHERE a.categoryid=b.id  ORDER BY a.categoryid , a.id";

	String categoryQuery = "SELECT  a.CATEGORYID AS CATEGORYID, b.NAME as categoryName " +
	" FROM datapointsconfig a, categoryfordatapoints b" +
	" WHERE a.categoryid=b.id ORDER BY a.categoryid , a.id";

	
	//String menuQuery = "SELECT name AS labelName, query AS sql, CATEGORYID FROM datapointsconfig ORDER BY id";
	
	String clientNameQuery = "SELECT DISTINCT clientname,clientid FROM vw_clientinfo_active ORDER BY clientname";
	String clientIDQuery = "SELECT DISTINCT clientid ,clientname FROM vw_clientinfo_active ORDER BY clientid";
	String appIDQuery = "SELECT DISTINCT applicationid,applicationname FROM vw_clientinfo_active ORDER BY applicationid";
	String appNameQuery = "SELECT DISTINCT applicationname,applicationid FROM vw_clientinfo_active ORDER BY applicationname";

	String INSERT_HIT_COUNT = "INSERT INTO URL_HIT(URL) values (?)";


}
