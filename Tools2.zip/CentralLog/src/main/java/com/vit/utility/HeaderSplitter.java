/*
 * Date : 2015-09-07
 * Author : Bhuwan Prasad Upadhyay
 */
package com.vit.utility;

import com.vit.domain.HeaderModel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author i81324
 */
public class HeaderSplitter {

    /**
     *
     *
     * @param headerMap
     * @param labelList
     * @return
     */
    public static List<HeaderModel> getSubHeaderForString(String headerMap, List<String> labelList) {
        if (headerMap != null) {
            List<HeaderModel> headerModels = new ArrayList<>();
            for (String s : headerMap.split(",")) {
                HeaderModel headerModel = new HeaderModel();
                headerModel.setHeader(s.trim().substring(0, s.indexOf("(")));
                String subHeader = s.trim().substring(s.indexOf("(") + 1, s.indexOf(")"));
                List<String> asList = Arrays.asList(subHeader.split("@"));
                int colSpane = 0;
                for (String label : asList) {
                    if (labelList.contains(label)) {
                        colSpane++;
                    }
                }
                headerModel.setColSpan(colSpane);
                headerModels.add(headerModel);
            }
            return headerModels;
        }
        return null;
    }

}
