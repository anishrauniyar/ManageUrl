/**
 * 
 */
package com.vit.utility;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * @author i80752
 * 
 */
public class WorkBookUtil {

	private Workbook vhrWorkBook;

	Map<String, CellStyle> styles = new HashMap<String, CellStyle>();

	public WorkBookUtil(Workbook vhrWorkBook) {
		this.vhrWorkBook = vhrWorkBook;
		this.setStyles();
	}

	public void setStyles() {

		DataFormat df = vhrWorkBook.createDataFormat();		
		short nf = df.getFormat("#,###");
		short nf1 = df.getFormat("#,##0.00");
		short nf2 = df.getFormat("0");
		short cf = df.getFormat("$#,##0.00");
		short pf = df.getFormat("0.00##\\%");

		HSSFCellStyle vh_inv, heading_style, heading_style2, heading_style3, heading_style_dy, integer_style, integer_style2, integer_style3, 
		normal_style, normalRed_style, normalBold_style, percentage_style, no_style, styleForsummary, styleForsummary2, dollarstyle, heading_style_gray, 
		heading_stylepb, redfilled_style, yellowFilled_Style, redfilled_dollar_style, redfilled_percentage_style, redfilled_integer_style,
		yellowFilled_dollar_style, yellowFilled_percentage_style, yellowFilled_integer_style;

		Font vh_invFont = vhrWorkBook.createFont();
		vh_invFont.setFontName("Arial");
		vh_invFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		vh_invFont.setFontHeightInPoints((short) 10);
		vh_invFont.setColor(HSSFColor.BLACK.index);

		Font Font = vhrWorkBook.createFont();
		Font.setFontName("Arial");
		Font.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		Font.setFontHeightInPoints((short) 8);
		Font.setColor(HSSFColor.BLACK.index);

		Font headingFont = vhrWorkBook.createFont();
		headingFont.setFontName("Calibri");
		headingFont.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		headingFont.setFontHeightInPoints((short) 11);
		headingFont.setColor(HSSFColor.BLACK.index);

		Font Font2 = vhrWorkBook.createFont();
		Font2.setFontName("Arial");
		Font2.setBoldweight(Font.BOLDWEIGHT_BOLD);
		Font2.setFontHeightInPoints((short) 8);
		Font2.setColor(HSSFColor.BLACK.index);

		Font Font3 = vhrWorkBook.createFont();
		Font3.setFontName("Calibri");
		Font3.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		Font3.setFontHeightInPoints((short) 11);
		Font3.setColor(HSSFColor.WHITE.index);

		Font Font4 = vhrWorkBook.createFont();
		Font4.setFontName("Arial");
		Font4.setBoldweight(Font.BOLDWEIGHT_BOLD);
		Font4.setFontHeightInPoints((short) 8);
		Font4.setColor(HSSFColor.BLACK.index);

		Font FontRed = vhrWorkBook.createFont();
		FontRed.setFontName("Arial");
		FontRed.setBoldweight(Font.BOLDWEIGHT_BOLD);
		FontRed.setFontHeightInPoints((short) 8);
		FontRed.setColor(HSSFColor.RED.index);

		Font whiteFont = vhrWorkBook.createFont();
		whiteFont.setFontName("Arial");
		whiteFont.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		whiteFont.setFontHeightInPoints((short) 8);
		whiteFont.setColor(HSSFColor.WHITE.index);

		Font FontCalibri9 = vhrWorkBook.createFont();
		FontCalibri9.setFontName("Calibri");
		FontCalibri9.setBoldweight(Font.BOLDWEIGHT_BOLD);
		FontCalibri9.setFontHeightInPoints((short) 9);
		FontCalibri9.setColor(HSSFColor.BLACK.index);

		dollarstyle = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		dollarstyle.setAlignment(CellStyle.ALIGN_RIGHT);
		dollarstyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		dollarstyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		dollarstyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		dollarstyle.setFont(Font);
		dollarstyle.setDataFormat(cf);
		styles.put("dollar_style", dollarstyle);

		heading_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		heading_style.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		heading_style.setFillForegroundColor(IndexedColors.LIGHT_BLUE
				.getIndex());
		heading_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style.setFont(Font3);
		styles.put("heading_style", heading_style);

		heading_stylepb = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		heading_stylepb.setAlignment(CellStyle.ALIGN_CENTER);
		heading_stylepb.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		heading_stylepb.setFillForegroundColor(IndexedColors.PALE_BLUE
				.getIndex());
		heading_stylepb.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_stylepb.setFont(Font4);
		styles.put("heading_stylepb", heading_stylepb);



		integer_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		integer_style.setAlignment(CellStyle.ALIGN_RIGHT);
		integer_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		integer_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style.setFont(Font);
		integer_style.setDataFormat(nf);
		styles.put("integer_style", integer_style);

		integer_style2 = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		integer_style2.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style2.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		integer_style2.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style2.setFont(Font);
		integer_style2.setDataFormat(nf2);
		styles.put("integer_style2", integer_style2);

		integer_style3 = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		integer_style3.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style3.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		integer_style3.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style3.setFont(Font);
		integer_style3.setDataFormat(nf1);
		styles.put("integer_style3", integer_style3);

		normal_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		normal_style.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		normal_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normal_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style.setFont(Font);
		styles.put("normal_style", normal_style);

		normalRed_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		normalRed_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalRed_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		normalRed_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalRed_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalRed_style.setFont(FontRed);
		styles.put("normalRed_style", normalRed_style);

		redfilled_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		redfilled_style.setAlignment(CellStyle.ALIGN_LEFT);
		redfilled_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		redfilled_style.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
		redfilled_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_style.setFont(whiteFont);
		styles.put("redfilled_style", redfilled_style);

		redfilled_dollar_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		redfilled_dollar_style.setAlignment(CellStyle.ALIGN_LEFT);
		redfilled_dollar_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		redfilled_dollar_style.setFillForegroundColor(IndexedColors.ORANGE
				.getIndex());
		redfilled_dollar_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_dollar_style.setFont(whiteFont);
		redfilled_dollar_style.setDataFormat(cf);
		styles.put("redfilled_dollar_style", redfilled_dollar_style);

		redfilled_percentage_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		redfilled_percentage_style.setAlignment(CellStyle.ALIGN_LEFT);
		redfilled_percentage_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		redfilled_percentage_style.setFillForegroundColor(IndexedColors.ORANGE
				.getIndex());
		redfilled_percentage_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_percentage_style.setFont(whiteFont);
		redfilled_percentage_style.setDataFormat(pf);
		styles.put("redfilled_percentage_style", redfilled_percentage_style);

		redfilled_integer_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		redfilled_integer_style.setAlignment(CellStyle.ALIGN_LEFT);
		redfilled_integer_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		redfilled_integer_style.setFillForegroundColor(IndexedColors.ORANGE
				.getIndex());
		redfilled_integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_integer_style.setFont(whiteFont);
		redfilled_integer_style.setDataFormat(nf);
		styles.put("redfilled_integer_style", redfilled_integer_style);

		yellowFilled_Style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		yellowFilled_Style.setAlignment(CellStyle.ALIGN_LEFT);
		yellowFilled_Style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		yellowFilled_Style.setFillForegroundColor(IndexedColors.YELLOW
				.getIndex());
		yellowFilled_Style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_Style.setFont(Font);
		styles.put("yellowFilled_Style", yellowFilled_Style);

		yellowFilled_dollar_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		yellowFilled_dollar_style.setAlignment(CellStyle.ALIGN_LEFT);
		yellowFilled_dollar_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		yellowFilled_dollar_style.setFillForegroundColor(IndexedColors.YELLOW
				.getIndex());
		yellowFilled_dollar_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_dollar_style.setFont(Font);
		yellowFilled_dollar_style.setDataFormat(cf);
		styles.put("yellowFilled_dollar_style", yellowFilled_dollar_style);

		yellowFilled_percentage_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		yellowFilled_percentage_style.setAlignment(CellStyle.ALIGN_LEFT);
		yellowFilled_percentage_style
				.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		yellowFilled_percentage_style
				.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
		yellowFilled_percentage_style
				.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_percentage_style.setFont(Font);
		yellowFilled_percentage_style.setDataFormat(pf);
		styles.put("yellowFilled_percentage_style",
				yellowFilled_percentage_style);

		yellowFilled_integer_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		yellowFilled_integer_style.setAlignment(CellStyle.ALIGN_LEFT);
		yellowFilled_integer_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		yellowFilled_integer_style.setFillForegroundColor(IndexedColors.YELLOW
				.getIndex());
		yellowFilled_integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_integer_style.setFont(Font);
		yellowFilled_integer_style.setDataFormat(nf);
		styles.put("yellowFilled_integer_style", yellowFilled_integer_style);

		normalBold_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		normalBold_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalBold_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		normalBold_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalBold_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalBold_style.setFont(Font2);
		styles.put("normalBold_style", normalBold_style);

		percentage_style = (HSSFCellStyle) createBorderedStyle(vhrWorkBook);
		percentage_style.setAlignment(CellStyle.ALIGN_LEFT);
		percentage_style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		percentage_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		percentage_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		percentage_style.setFont(Font);
		percentage_style.setDataFormat(pf);
		styles.put("percentage_style", percentage_style);

		

		CellStyle backGroundEven = vhrWorkBook.createCellStyle();
		backGroundEven.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
		backGroundEven.setFillPattern(CellStyle.BIG_SPOTS);
		styles.put("backGroundEven", backGroundEven);

		CellStyle backGroundOdd = vhrWorkBook.createCellStyle();
		backGroundOdd.setFillBackgroundColor(IndexedColors.WHITE.getIndex());
		backGroundOdd.setFillPattern(CellStyle.BIG_SPOTS);
		styles.put("backGroundOdd", backGroundOdd);

	}

	public Map<String, CellStyle> getStyle() {
		return styles;

	}

	private static CellStyle createBorderedStyle(Workbook wb) {
		CellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		return style;

	}

}
