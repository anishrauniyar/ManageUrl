package com.vit.utility;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.io.ClassPathResource;
import com.vit.domain.DataPoints;
import com.vit.domain.LogFile;


/**
 * Utility class
 * 
 * @author i80260
 * 
 */
public class CentralLogUtil {

	/**
	 * if the session hold the data point, load form session other wise load
	 * from xml file.
	 */
	public static DataPoints getdataPoints(HttpSession session) {
		DataPoints dataPoints = (DataPoints) session.getAttribute("dataPoints");
		if (dataPoints == null) {
			try {
				dataPoints = generateMenuFileFromXML();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JAXBException e) {
				e.printStackTrace();
			}
		}
		return dataPoints;
	}

	/**
	 * 
	 * @return
	 * @throws IOException
	 * @throws JAXBException
	 *             generate Menu File From XML
	 */
	private static DataPoints generateMenuFileFromXML() throws IOException,
			JAXBException {
		ClassPathResource cpr = new ClassPathResource(WebConstants.CFL_XML);
		InputStream file = cpr.getInputStream();
		JAXBContext jaxbContext = JAXBContext.newInstance(DataPoints.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		return (DataPoints) jaxbUnmarshaller.unmarshal(file);
	}

	@Cacheable(value = "dataPoints")
	public String getDataPoints(boolean returnCached) {
		return new Date().toString();

	}

	/**
	 * 
	 * @param labelName
	 * @return generate Static Label Name List
	 */
	public static List<String> generateStaticLabelNameList(String labelName) {
		String labelNameArray[] = labelName.split(WebConstants.SEMICOLON);
		List<String> labelNameList = new ArrayList<String>();
		for (int i = 0; i < labelNameArray.length; i++) {
			labelNameList.add(labelNameArray[i]);
		}
		return labelNameList;
	}

	/**
	 * 
	 * @param dbColumnName
	 * @return generate Static DbColumn Name
	 */
	public static List<String> generateStaticDbColumnName(String dbColumnName) {
		String dbColumnNameArray[] = dbColumnName.split(WebConstants.SEMICOLON);
		List<String> dbColumnList = new ArrayList<String>();
		for (int i = 0; i < dbColumnNameArray.length; i++) {
			dbColumnList.add(dbColumnNameArray[i]);
		}
		return dbColumnList;
	}

	/**
	 * 
	 * @return generate Dynamic DbColumn List
	 */
	public static List<String> generateDynamicDbColumnList(String dbColumnName) {
		String dbColumnNameArray[] = dbColumnName
				.split(WebConstants.VERTICAL_PIPE);
		List<String> dbColumnNameList = new ArrayList<String>();
		for (int i = 0; i < dbColumnNameArray.length; i++) {
			dbColumnNameList.add(dbColumnNameArray[i]);
		}
		return dbColumnNameList;
	}

	/**
	 * 
	 * @param labelName
	 * @return generate Dynamic LabelName And ClientMap
	 */
	public static Map<String, List<String>> generateDynamicLabelNameAndClientMap(
			String labelName) {
		Map<String, List<String>> localVarClientNameAndClientList = new HashMap<String, List<String>>();
		String labelNameAndClientNameArray[] = labelName
				.split(WebConstants.VERTICAL_PIPE);
		for (int i = 0; i < labelNameAndClientNameArray.length; i++) {
			String labelNameAndClientWiseVar = labelNameAndClientNameArray[i];
			String labelNameClientNameArray[] = labelNameAndClientWiseVar
					.split(WebConstants.ARROW);
			String clientNameArray[] = labelNameClientNameArray[1]
					.split(WebConstants.SEMICOLON);
			String uiLabelName = labelNameClientNameArray[0];
			List<String> clientList = new ArrayList<String>();
			for (int j = 0; j < clientNameArray.length; j++) {
				clientList.add(clientNameArray[j]);
			}
			localVarClientNameAndClientList.put(uiLabelName, clientList);
		}
		return localVarClientNameAndClientList;

	}

	/**
	 * remove Escape And Special Character from string
	 * 
	 * @param input
	 * @return
	 */
	public static String removeEscapeAndSpecialCharacter(String input) {
		input = input.trim();
		input = input.replace(WebConstants.TAB, WebConstants.EMPTY_SPACE);
		input = input.replace(WebConstants.NEWLINE, WebConstants.EMPTY_SPACE);
		return input;
	}

	/**
	 * generate Dynamic LabelName And Dbcolumn Map
	 * 
	 * @param labelNameAndClientMap
	 * @param dbColumnList
	 * @return
	 */
	public static Map<String, String> generateDynamicLabelNameAndDbcolumnMap(
			Map<String, List<String>> labelNameClientMap,
			List<String> dbColumnList) {
		Map<String, String> labelNameAndClientMap = new HashMap<String, String>();
		int i = 0;
		for (Entry<String, List<String>> entry : labelNameClientMap.entrySet()) {
			String key = entry.getKey();
			labelNameAndClientMap.put(key, dbColumnList.get(i++));
		}
		return labelNameAndClientMap;
	}

	/**
	 * set Parameter Passed From UI And GenerateQuery
	 * 
	 * @return
	 */
	public static LogFile setParameterPassedFromUIAndGenerateQuery(
			LogFile logFileObject) {
		return logFileObject;
	}
}
