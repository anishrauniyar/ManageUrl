/**
 * 
 */
package com.vit.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.vit.utility.CentralLogUtil;

/**
 * @author i80752
 *
 */
public class Test {
	
	public static void main (String[] args)
	{

	ApplicationContext applicationContext = new FileSystemXmlApplicationContext("D:\\ProjectCodes\\CentralLog\\Branch\\2.0\\" +
			"src\\main\\webapp\\WEB-INF\\CentralLog\\appServlet\\servlet-context.xml");
	CentralLogUtil centralLogUtil = (CentralLogUtil)applicationContext.getBean("test");
	System.out.println(centralLogUtil.getDataPoints(true));
	try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(centralLogUtil.getDataPoints(true));
	}
	
	
	
}
