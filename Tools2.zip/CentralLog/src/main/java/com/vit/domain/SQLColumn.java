/**
 * @class:  SQLColumn.java
 * @author: Vivek Adhikari
 * @since:  March 6, 2014
 * 
 */
package com.vit.domain;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author Vivek Adhikari
 * 
 *
 */
public class SQLColumn implements Serializable {


	private static final long serialVersionUID = -8676808526216710361L;
	private String  name;
	private int type;
	private String typeName;
	private String  labelAs;
	private String filterCondition;
	private String startDate;
	private String endDate ;	
	private String logicalOps;	
	private String defectType;
	private String stage;
	
	private String year;
	private String month;
	
	private boolean selected = true;
	private boolean allClientSelected = false;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the type
	 */
	public int getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(int type) {
		this.type = type;
	}
	/**
	 * @return the typeName
	 */
	public String getTypeName() {
		return typeName;
	}
	/**
	 * @param typeName the typeName to set
	 */
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	/**
	 * @return the filterCondition
	 */
	public String getFilterCondition() {
		return filterCondition;
	}
	/**
	 * @param filterCondition the filterCondition to set
	 */
	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}
	/**
	 * @return the selected
	 */
	public boolean isSelected() {
		return selected;
	}
	/**
	 * @param selected the selected to set
	 */
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartDate() {
		if(startDate == null){
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	        Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.DATE, -365);  
	        return dateFormat.format(cal.getTime());
		}
		return startDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getEndDate() {
		if(endDate == null){
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	        Calendar cal = Calendar.getInstance();	       
	        return dateFormat.format(cal.getTime());
		}
		return endDate;
	}
	public void setLogicalOps(String logicalOps) {
		this.logicalOps = logicalOps;
	}
	public String getLogicalOps() {
		return logicalOps;
	}
	public void setLabelAs(String labelAs) {
		this.labelAs = labelAs;
	}
	public String getLabelAs() {
		return labelAs;
	}
	public void setDefectType(String defectType) {
		this.defectType = defectType;
	}
	public String getDefectType() {
		return defectType;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getStage() {
		return stage;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getYear() {
		return year;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getMonth() {
		return month;
	}
	public void setAllClientSelected(boolean allClientSelected) {
		this.allClientSelected = allClientSelected;
	}
	public boolean isAllClientSelected() {
		return allClientSelected;
	}
	
	
	
	
	
	
}
