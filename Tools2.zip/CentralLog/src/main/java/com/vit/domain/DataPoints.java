package com.vit.domain;

import java.io.Serializable;
import java.util.List;

/**
 * Represents the datapoints
 * @author skhattri
 *
 */

public class DataPoints implements Serializable
{
	private static final long serialVersionUID = 8337485561097659639L;
	private List<DataPoint>dataPoint;
	private List<String> clientNameList;
	public List<DataPoint> getDataPoint() {
		return dataPoint;
	}

	public void setDataPoint(List<DataPoint> dataPoint) {
		this.dataPoint = dataPoint;
	}

	public void setClientNameList(List<String> clientNameList) {
		this.clientNameList = clientNameList;
	}

	public List<String> getClientNameList() {
		return clientNameList;
	}
	

}
