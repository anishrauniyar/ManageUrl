package com.vit.domain;

/**
 * Created by i81324 on 9/3/2015.
 */
public class ChartModel {
    
    private String name;
    private double y;
    private String id;

    public ChartModel() {
    }

    public ChartModel(String name, double y, String id) {
        this.name = name;
        this.y = y;
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setY(double y) {
        this.y = y;
    }

    public String getName() {
        return name;
    }

    public double getY() {
        return y;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    
    
}
