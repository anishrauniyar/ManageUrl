package com.vit.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.vit.utility.CentralLogUtil;

public class DataPoint implements Serializable
{
	private static final long serialVersionUID = -2395917060070157429L;
	private String labelName;
	private String sql;
	private String createdBy;
	private String desc;
	private String CATEGORYID;
	private String categoryName;
	private List<SQLColumn> dbColumnList;
	private List<String> clientNameList;
	
	

	public String getLabelName() {
		return labelName;
	}
	public void setLabelName(String labelName) {
		this.labelName = CentralLogUtil.removeEscapeAndSpecialCharacter(labelName);
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = CentralLogUtil.removeEscapeAndSpecialCharacter(sql);
	}
	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}
	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
	/**
	 * @return the dbColumnList
	 */
	public List<SQLColumn> getDbColumnList() {
		return dbColumnList;
	}
	/**
	 * @param dbColumnList the dbColumnList to set
	 */
	public void setDbColumnList(List<SQLColumn> dbColumnList) {
		this.dbColumnList = dbColumnList;
	}
	public void setClientNameList(List<String> clientNameList) {
		this.clientNameList = clientNameList;
	}
	public List<String> getClientNameList() {
		return clientNameList;
	}
	public void setCATEGORYID(String cATEGORYID) {
		CATEGORYID = cATEGORYID;
	}
	public String getCATEGORYID() {
		return CATEGORYID;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCategoryName() {
		return categoryName;
	}


	
}
