package com.vit.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
/**
 * Contains Log detail for the Central Server
 * @author i80260
 *
 */
public class LogFile implements Serializable
{
	private static final long serialVersionUID = -7128235147149800358L;
	private String description;
	private List<String>labelList;
	private List<String>dataTypeList;
	private Set<String > categorySet;
	private List<Map<String, Object>> logList;
	

	private DataPoint dataPoint;
	private String categoryID="1";
	private String errorMessage;
	private DataPoints dataPoints;
	private String selectedDataPoint;
	private String preparedQuery;
	private String queryForPagination;
	
	private String generateQuery ;
	
	private String generateLabels;
	
	private int currPage=1;
	private int totalPages=10;
	private String runQuery="true";
	private String queryForExcel;
	
	private String [] clientName;
	private String [] clientID;
	
	private String [] appID;
	private String [] appName;
	
	private String sortFieldName;	
	private String sortBy;
	
	

	
	public List<String> getLabelList() {
		return labelList;
	}

	public void setLabelList(List<String> labelList) {
		this.labelList = labelList;
	}
	public DataPoint getDataPoint() {
		return dataPoint;
	}

	public void setDataPoint(DataPoint dataPoint) {
		this.dataPoint = dataPoint;
	}
	;
	
	
	public String getSelectedDataPoint() {
		return selectedDataPoint;
	}

	public void setSelectedDataPoint(String selectedDataPoint) {
		this.selectedDataPoint = selectedDataPoint;
	}
	
	public DataPoints getDataPoints() {
		return dataPoints;
	}
	public void setDataPoints(DataPoints dataPoints) {
		this.dataPoints = dataPoints;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public List<Map<String, Object>>  getLogList() {
		return logList;
	}
	public void setLogList(List  logList) {
		this.logList = logList;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
	/**
	 * @return the generateQuery
	 */
	public String getGenerateQuery() {
		return generateQuery;
	}

	/**
	 * @param generateQuery the generateQuery to set
	 */
	public void setGenerateQuery(String generateQuery) {
		this.generateQuery = generateQuery;
	}

	/**
	 * @return the preparedQuery
	 */
	public String getPreparedQuery() {
		return preparedQuery;
	}

	/**
	 * @param preparedQuery the preparedQuery to set
	 */
	public void setPreparedQuery(String preparedQuery) {
		this.preparedQuery = preparedQuery;
	}

	/**
	 * @return the generateLabels
	 */
	public String getGenerateLabels() {
		return generateLabels;
	}

	/**
	 * @param generateLabels the generateLabels to set
	 */
	public void setGenerateLabels(String generateLabels) {
		this.generateLabels = generateLabels;
	}

	/**
	 * @return the queryForPagination
	 */
	public String getQueryForPagination() {
		return queryForPagination;
	}

	/**
	 * @param queryForPagination the queryForPagination to set
	 */
	public void setQueryForPagination(String queryForPagination) {
		this.queryForPagination = queryForPagination;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setCurrPage(int currPage) {
		this.currPage = currPage;
	}

	public int getCurrPage() {
		return currPage;
	}

	public void setRunQuery(String runQuery) {
		this.runQuery = runQuery;
	}

	public String getRunQuery() {
		return runQuery;
	}

	public void setQueryForExcel(String queryForExcel) {
		this.queryForExcel = queryForExcel;
	}

	public String getQueryForExcel() {
		return queryForExcel;
	}

	public void setClientName(String [] clientName) {
		this.clientName = clientName;
	}

	public String [] getClientName() {
		return clientName;
	}

	public void setClientID(String [] clientID) {
		this.clientID = clientID;
	}

	public String [] getClientID() {
		return clientID;
	}

	public void setAppID(String [] appID) {
		this.appID = appID;
	}

	public String [] getAppID() {
		return appID;
	}

	public void setAppName(String [] appName) {
		this.appName = appName;
	}

	public String [] getAppName() {
		return appName;
	}

	public void setCategoryID(String categoryID) {
		this.categoryID = categoryID;
	}

	public String getCategoryID() {
		return categoryID;
	}

	public void setDataTypeList(List<String> dataTypeList) {
		this.dataTypeList = dataTypeList;
	}

	public List<String> getDataTypeList() {
		return dataTypeList;
	}

	public void setCategorySet(Set<String > categorySet) {
		this.categorySet = categorySet;
	}

	public Set<String > getCategorySet() {
		return categorySet;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortFieldName(String sortFieldName) {
		this.sortFieldName = sortFieldName;
	}

	public String getSortFieldName() {
		return sortFieldName;
	}

		
	
	
}
