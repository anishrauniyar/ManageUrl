/*
 * Date : 2015-09-07
 * Author : Bhuwan Prasad Upadhyay
 */
package com.vit.domain;

import java.util.List;

/**
 *
 * @author i81324
 */
public class HeaderModel {

    private String header;
    private int colSpan;

    public HeaderModel(String header, int colSpan) {
        this.header = header;
        this.colSpan = colSpan;
    }

    public HeaderModel() {
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public int getColSpan() {
        return colSpan;
    }

    public void setColSpan(int colSpan) {
        this.colSpan = colSpan;
    }


    
}
