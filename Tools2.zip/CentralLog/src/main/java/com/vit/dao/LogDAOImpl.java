package com.vit.dao;

import com.vit.domain.ChartModel;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.vit.domain.DataPoint;
import com.vit.domain.LogFile;
import com.vit.domain.SQLColumn;
import com.vit.utility.WebConstants;
import org.springframework.jdbc.core.RowMapper;

/**
 * DAO Impl for Central Log
 *
 * @author i80260
 * @modified by i80752
 *
 */
public class LogDAOImpl implements LogDAO {

    private JdbcTemplate jdbcTemplate;
    Logger log = Logger.getLogger(this.getClass());

    @Override
    public LogFile selectDataPointsDetails(LogFile logFileObject)
            throws Exception {
        return logFileObject;
    }

    /**
     * generate LogList For Livesdetails
     */
    private List<List> generateLogListForLivesdetails(
            List<Map<String, Object>> resultObject, List<String> dbColumnList) {
        List<List> logList = new ArrayList<List>();
        for (Map row : resultObject) {
            List dataPointList = new ArrayList();
            for (String dbColumn : dbColumnList) {
                if (dbColumn.contains(WebConstants.AS)) {
                    dbColumn = dbColumn
                            .substring(
                                    dbColumn.lastIndexOf(WebConstants.AS) + 4)
                            .replace(WebConstants.SINGLE_QUOTE,
                                    WebConstants.EMPTY_SPACE).trim();
                }
                dataPointList.add(row.get(dbColumn));
            }
            logList.add(dataPointList);
        }
        return logList;
    }

    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        System.out.println("Setting datasource >>> ");
    }

    /**
     * @return the jdbcTemplate
     */
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    /**
     * @param jdbcTemplate the jdbcTemplate to set
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.dao.LogDAO#getMetaDataInformation(java.lang.String)
     */
    @Override
    public List<SQLColumn> getMetaDataInformation(String strSQL)
            throws Exception {

        // ----------for retriving column name vs column label as---------------
        String sqler = strSQL;
        sqler = sqler.toUpperCase().trim().replace("SELECT", "")
                .replace(" AS ", " ");
        int position = sqler.indexOf("FROM");
        sqler = sqler.substring(0, position);
        final Hashtable<String, String> hs = new Hashtable<String, String>();
        String[] tokens = sqler.split(",");
        for (String token : tokens) {
            String[] tok = token.trim().split("\"");
            if (tok.length > 1 && tok.length < 3) {
                hs.put(tok[1].trim(), tok[0].trim());
            }
        }

        // ----------for retriving column name vs column label as---------------
        System.out.println("---------------------------------------" + sqler);
        final List<SQLColumn> columns = new ArrayList<SQLColumn>();
        jdbcTemplate.query(strSQL, new ResultSetExtractor<Integer>() {
            @Override
            public Integer extractData(ResultSet rs) throws SQLException,
                    DataAccessException {
                ResultSetMetaData rsmd = rs.getMetaData();
                int columnCount = rsmd.getColumnCount();
                for (int i = 1; i <= columnCount; i++) {

                    SQLColumn column = new SQLColumn();
                    column.setName(rsmd.getColumnName(i));
                    column.setType(rsmd.getColumnType(i));
                    column.setTypeName(rsmd.getColumnTypeName(i));
                    if (hs.get(rsmd.getColumnLabel(i).toUpperCase()) != null) {
                        column.setLabelAs(hs.get(rsmd.getColumnLabel(i).toUpperCase()));
                    } else {
                        column.setLabelAs(rsmd.getColumnName(i).toUpperCase());
                    }

                    columns.add(column);
                }
                return columnCount;
            }
        });
        return columns;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.dao.LogDAO#getQueryResult(com.vit.domain.LogFile)
     */
    @Override
    public LogFile getQueryResult(LogFile logFileObject) throws Exception {
        List logList = jdbcTemplate.queryForList(logFileObject
                .getPreparedQuery());
        logFileObject.setLogList(logList);
        return logFileObject;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.vit.dao.LogDAO#getQueryResultForPagination(com.vit.domain.LogFile)
     */
    @Override
    public int getQueryResultForPagination(LogFile logFileObject)
            throws Exception {
        return jdbcTemplate.queryForInt(logFileObject.getQueryForPagination());
        // return 0;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.dao.LogDAO#getData(java.lang.String)
     */
    @Override
    public List getData(String strSQL) throws Exception {
        return jdbcTemplate.queryForList(strSQL);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.dao.LogDAO#getMenu()
     */
    @Override
    public List<DataPoint> getMenu(String strSQL) throws Exception {

        List<DataPoint> dataPoints = jdbcTemplate.query(WebConstants.menuQuery,
                new BeanPropertyRowMapper(DataPoint.class));
        for (DataPoint point : dataPoints) {
            point.setDbColumnList(getMetaDataInformation(point.getSql()));
        }
        return dataPoints;

    }

    private static String INSERT_NEW_REPORT = "INSERT INTO DATAPOINTSCONFIG(NAME, DES, QUERY, CREATEDON, CREATEDBY) values (?,?,?,sysdate,?)";

    /*
     * (non-Javadoc)
     * 
     * @see com.vit.dao.LogDAO#updateReportConfiguration(com.vit.domain.LogFile)
     */
    @Override
    public boolean updateDataSourceConfiguration(LogFile logFileObject)
            throws Exception {
        boolean isUpdated = false;
        jdbcTemplate.update(INSERT_NEW_REPORT, new Object[]{
            logFileObject.getDataPoint().getLabelName(),
            logFileObject.getDataPoint().getDesc(),
            logFileObject.getDataPoint().getSql(),
            logFileObject.getDataPoint().getCreatedBy()});
        isUpdated = true;
        return isUpdated;
    }

    @Override
    public LinkedHashMap<String, String> getClientAppMapList(String strSQL) {
        LinkedHashMap<String, String> map = (LinkedHashMap) jdbcTemplate.query(strSQL,
                new ResultSetExtractor() {
                    public Object extractData(ResultSet rs) throws SQLException {
                        LinkedHashMap map = new LinkedHashMap();
                        while (rs.next()) {
                            String client = rs.getString(1);
                            String id = rs.getString(2);
                            map.put(client, client + " ( " + id + " )");
                        }
                        ;
                        return map;
                    }
                ;
        });

		return map;
    }

    @Override
    public List<ChartModel> generateChart(String datapointName) {
        log.info("Fetch chart query for data " + datapointName + " " + datapointName.length());
        String queryForChart = jdbcTemplate.queryForObject("SELECT CHART_QUERY from CENTRALLOG.datapointsconfig WHERE NAME = ?", new Object[]{datapointName.trim()}, String.class);
        log.info("Chart Query : " + queryForChart);
        if (queryForChart != null && !queryForChart.isEmpty()) {
            return jdbcTemplate.query(queryForChart, new RowMapper<ChartModel>() {

                @Override
                public ChartModel mapRow(ResultSet rs, int rowNum) throws SQLException {
                    StringBuilder nameSb = new StringBuilder();
                    for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {

                        nameSb.append(rs.getMetaData().getColumnName(i)).append("=").append(rs.getObject(i)).append("<br/>");
                    }
                    double sum = 0.0;
                    for (int i = 2; i <= rs.getMetaData().getColumnCount(); i++) {
                        try {
                            sum += Double.valueOf(rs.getObject(i).toString());
                        } catch (SQLException | NumberFormatException | NullPointerException e) {

                        }
                    }
                    return new ChartModel(nameSb.toString(), sum, rs.getObject(1).toString());
                }
            });
        }
        return new ArrayList<ChartModel>();
    }
	
	@Override
	public boolean updateHitCount(LogFile logFileObject)
			throws Exception {
		boolean isUpdated = false;
		jdbcTemplate.update(WebConstants.INSERT_HIT_COUNT, new Object[] {
				logFileObject.getDataPoint().getLabelName()
				 });
		isUpdated = true;
		return isUpdated;
	}

    @Override
    public Object fireQuery(String psQuery, Object[] args, Class<?> classs) {
        return jdbcTemplate.queryForObject(psQuery, args, classs);
    }

        
}
