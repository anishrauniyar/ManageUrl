package com.vit.dao;

import com.vit.domain.ChartModel;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.vit.domain.DataPoint;
import com.vit.domain.DataPoints;
import com.vit.domain.LogFile;
import com.vit.domain.SQLColumn;

/**
 *
 * @author i80260 DAO for Central Log
 * @modified by vadhikari
 */
public interface LogDAO {

    LogFile selectDataPointsDetails(LogFile logFileObject) throws Exception;

    List<SQLColumn> getMetaDataInformation(String strSQL) throws Exception;

    LogFile getQueryResult(LogFile logFileObject) throws Exception;

    int getQueryResultForPagination(LogFile logFileObject) throws Exception;

    List<String> getData(String strSQL) throws Exception;

    boolean updateDataSourceConfiguration(LogFile logFileObject) throws Exception;

    List<DataPoint> getMenu(String strSQL) throws Exception;

    LinkedHashMap<String, String> getClientAppMapList(String strSQL) throws Exception;

    boolean updateHitCount(LogFile logFileObject) throws Exception;

    public List<ChartModel> generateChart(String datapointName);

    Object fireQuery(String psQuery, Object[] args, Class<?> classs);

}
