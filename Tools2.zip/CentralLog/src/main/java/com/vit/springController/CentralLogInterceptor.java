package com.vit.springController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
/**
 * Custom Interceptor
 * @author i80260
 *
 */
public class CentralLogInterceptor implements HandlerInterceptor 
{
	Logger log = Logger.getLogger(this.getClass());

	@Override
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) throws Exception 
	{
		if(log.isDebugEnabled())
		{
			log.debug("Interceptor invoked as Pre-Processing.");
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception 
	{
		if(log.isDebugEnabled())
		{
			log.debug("Interceptor invoked as Post-Processing.");
		}
	}

	@Override
	public void afterCompletion(HttpServletRequest request,HttpServletResponse response, Object handler, Exception ex)throws Exception 
	{
		if(log.isDebugEnabled())
		{
			log.debug("Interceptor invoked as After-Processing.");
		}
	}
}