/**
 * 
 */
package com.vit.springController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.vit.domain.DataPoints;
import com.vit.domain.LogFile;
import com.vit.service.LogService;
import com.vit.utility.CentralLogUtil;

/**
 * @author i80752
 * 
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

	private Logger log = Logger.getLogger(this.getClass());

	@Autowired
	private LogService logService;

	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public ModelAndView adminPanel(
			@ModelAttribute("logFileObject") LogFile logFileObject,
			BindingResult result, HttpSession session) {
		if (log.isDebugEnabled()) {
			log.debug("Inside CentralLog Admin page.");
		}
		ModelAndView modelAndView;
		DataPoints dataPoints = SelectLogController.dataPoints;
		logFileObject.setDataPoints(dataPoints);

		modelAndView = new ModelAndView("adminHome", "logFileObject",
				logFileObject);
		return modelAndView;
	}

	@RequestMapping(value = "/addReport", method = RequestMethod.POST)
	public ModelAndView adminReport(
			@ModelAttribute("logFileObject") LogFile logFileObject,
			BindingResult result, HttpSession session,
			HttpServletRequest request) {

		if (log.isDebugEnabled()) {
			log.debug("Inside CentralLog Report Add page.");
		}

		ModelAndView modelAndView;
		DataPoints dataPoints = SelectLogController.dataPoints;
		logFileObject.setDataPoints(dataPoints);
		logFileObject.getDataPoint().setCreatedBy(request.getRemoteAddr());

		try {
			/**
			 * Reset cached bean if update operation is true
			 */
			if(logService.updateDataSourceConfiguration(logFileObject))
			{
				logFileObject.getDataPoint().setLabelName("");
				logFileObject.getDataPoint().setSql("");
				logFileObject.getDataPoint().setDesc("");
				new SelectLogController().reloadCache();
				logFileObject.setDataPoints(SelectLogController.dataPoints);
			}
			
		} catch (Exception e) {
			logFileObject.setErrorMessage(e.getMessage());
		}
		modelAndView = new ModelAndView("adminHome", "logFileObject",
				logFileObject);
		return modelAndView;
	}

}
