package com.vit.springController;

import com.google.gson.Gson;
import com.vit.domain.ChartModel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.vit.domain.DataPoint;
import com.vit.domain.DataPoints;
import com.vit.domain.LogFile;
import com.vit.exception.SpringException;
import com.vit.service.LogService;
import com.vit.utility.HeaderSplitter;
import com.vit.utility.WebConstants;
import javax.servlet.http.HttpServletRequest;

/**
 * Select Controller for Log
 *
 * @author i80260
 * @modified by vadhikari
 * @modified by bpupadhyay
 *
 */
@Controller
public class SelectLogController {

    private Logger log = Logger.getLogger(this.getClass());

    static DataPoints dataPoints;
    // static LinkedHashMap<String, String> logicalOps;
    static LinkedHashMap<String, String> clientName;
    static LinkedHashMap<String, String> clientID;
    static LinkedHashMap<String, String> appID;
    static LinkedHashMap<String, String> appName;
    static LinkedHashMap<String, String> categoryID;

    @Autowired
    private LogService logService;

    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        dataBinder.registerCustomEditor(Date.class, new CustomDateEditor(
                new SimpleDateFormat("dd/MM/yyyy"), true));
    }

    /**
     * @Added by i81324(bpupadhyay)
     * @Date 2015-09-09
     * @Purpose to show admin page
     * @return
     */
    @RequestMapping(value = "/Admin", method = RequestMethod.GET)
    public ModelAndView adminPage() {
        ModelAndView mav = new ModelAndView("adminHome");
        return mav;
    }

    /**
     * @Added by i81324(bpupadhyay)
     * @Date 2015-09-09
     * @Purpose to reset application configuration
     * @return
     */
    @RequestMapping(value = "/resetApplication", method = RequestMethod.GET)
    public ModelAndView resetApplication() {
        ModelAndView mav = new ModelAndView();
        resetConfiguration();
        mav.setViewName("redirect:/home");
        return mav;
    }

    /**
     * @Added by i81324(bpupadhyay)
     * @Date 2015-09-09
     * @Purpose to rest application configuration
     * @return
     */
    private void resetConfiguration() {
        dataPoints = null;
        clientName = null;
        clientID = null;
        appID = null;
        appName = null;
        categoryID = null;
    }

    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public ModelAndView home(HttpSession session) {
        if (log.isDebugEnabled()) {
            log.debug("Inside CentralLog home page.");
        }

        // dataPoints = (DataPoints) session.getAttribute("dataPoints");
        List<DataPoint> dataPoint;
        if (dataPoints == null) {
            try {
                dataPoint = logService.getMenu("");
                dataPoints = new DataPoints();
                dataPoints.setDataPoint(dataPoint);
                // dataPoints.setClientNameList(logService.getClientNameList(WebConstants.clientListQuery));
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        // DataPoints dataPoints = CentralLogUtil.getdataPoints(session);
        LogFile logFileObject = new LogFile();
        logFileObject.setDataPoints(dataPoints);
        logFileObject.setGenerateQuery("false");
        logFileObject.setGenerateLabels("false");
        // dataPoints.getDataPoint().

        ModelAndView modelAndView = new ModelAndView("home", "logFileObject",
                logFileObject);
        try {

            if (clientName == null) {
                clientName = logService
                        .getClientAppMapList(WebConstants.clientNameQuery);
            }
            if (clientID == null) {
                clientID = logService
                        .getClientAppMapList(WebConstants.clientIDQuery);
            }
            if (appID == null) {
                appID = logService.getClientAppMapList(WebConstants.appIDQuery);
            }
            if (appName == null) {
                appName = logService
                        .getClientAppMapList(WebConstants.appNameQuery);
            }
            if (categoryID == null) {
                categoryID = logService
                        .getClientAppMapList(WebConstants.categoryQuery);
            }

            modelAndView.addObject("clientIDList", clientID);
            modelAndView.addObject("clientNameList", clientName);
            modelAndView.addObject("appIDList", appID);
            modelAndView.addObject("appNameList", appName);
            modelAndView.addObject("categoryIDSet", categoryID);

        } catch (Exception e) {
            e.printStackTrace();
        }
        // session.setAttribute("dataPoints", dataPoints);
        return modelAndView;
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public ModelAndView logout(HttpSession session) {
        if (log.isDebugEnabled()) {
            log.debug("Inside CentralLog logout page.");
        }
        // session.setAttribute("dataPoints", null);
        ModelAndView modelAndView = new ModelAndView("home", "logFileObject",
                null);
        return modelAndView;
    }

    @RequestMapping(value = "/dataPoint", method = {RequestMethod.GET,
        RequestMethod.POST})
    public ModelAndView dataPoint(
            @ModelAttribute("logFileObject") LogFile logFileObject,
            BindingResult result, HttpSession session) {
        ModelAndView modelAndView;
        // DataPoints dataPoints = (DataPoints)
        // session.getAttribute("dataPoints");
        List<DataPoint> dataPointss;
        if (dataPoints == null) {
            try {
                dataPointss = logService.getMenu("");
                dataPoints = new DataPoints();
                dataPoints.setDataPoint(dataPointss);
                // dataPoints.setClientNameList(logService.getClientNameList(WebConstants.clientListQuery));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // DataPoints dataPoints = CentralLogUtil.getdataPoints(session);
        logFileObject.setDataPoints(dataPoints);
        logFileObject.setGenerateLabels("true");
        logFileObject.setGenerateQuery("false");
        if (log.isDebugEnabled()) {
            log.debug("DataPointSelected: "
                    + logFileObject.getSelectedDataPoint());
        }
        logFileObject
                .setDataPoint(this.getUserSelectedDataPoint(logFileObject));

        try {
            logService.updateHitCount(logFileObject);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
            log.error(e1.getLocalizedMessage());
        }

        /*
         * try {
         * 
         * logFileObject.getDataPoint().setDbColumnList(
         * logService.getMetaDataInformation(this
         * .getUserSelectedDataPoint(logFileObject).getSql())); } catch
         * (Exception e) { logFileObject.setErrorMessage(e.getMessage()); }
         */
        // System.out.println("dataclient:"+logFileObject.getDataPoints().getClientNameList().size());
        modelAndView = new ModelAndView("home", "logFileObject", logFileObject);
        try {

            if (clientName == null) {
                clientName = logService
                        .getClientAppMapList(WebConstants.clientNameQuery);
            }
            if (clientID == null) {
                clientID = logService
                        .getClientAppMapList(WebConstants.clientIDQuery);
            }
            if (appID == null) {
                appID = logService.getClientAppMapList(WebConstants.appIDQuery);
            }
            if (appName == null) {
                appName = logService
                        .getClientAppMapList(WebConstants.appNameQuery);
            }
            if (categoryID == null) {
                categoryID = logService
                        .getClientAppMapList(WebConstants.categoryQuery);
            }

            modelAndView.addObject("clientNameList", clientName);
            modelAndView.addObject("clientIDList", clientID);
            modelAndView.addObject("appIDList", appID);
            modelAndView.addObject("appNameList", appName);
            modelAndView.addObject("categoryIDSet", categoryID);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return modelAndView;
    }

    /*@RequestMapping(value = "/hello", method = RequestMethod.GET, produces = { MediaType.APPLICATION_ATOM_XML_VALUE })
     public @ResponseBody
     String hello() {
     String name1 = "test";
     String gender = "test";
     String email = "test";
     String phone = "test";
     String city = "test";

     // System.out.println(name);
     System.out.println(gender);
     System.out.println(email);
     System.out.println(phone);
     System.out.println(city);

     String str = "{\"user\": { \"name\": \"" + name1 + "\",\"gender\": \""
     + gender + "\",\"email\": \"" + email + "\",\"phone\": \""
     + phone + "\",\"city\": \"" + city + "\"}}";
     return str;

     }*/

    /*@requestmapping(value = "/helloo", method = requestmethod.post)
     public @responsebody
     string helloo(@requestbody logfile logfileobject) {
     string name1 = "test";
     string gender = "test";
     string email = "test";
     string phone = "test";
     string city = "test";

     // system.out.println(name);
     system.out.println(gender);
     system.out.println(email);
     system.out.println(phone);
     system.out.println(city);

     system.out.println("loggile:" + logfileobject.getcategoryid());

     string str = "{\"user\": { \"name\": \"" + name1 + "\",\"gender\": \""
     + gender + "\",\"email\": \"" + email + "\",\"phone\": \""
     + phone + "\",\"city\": \"" + city + "\"}}";
     return str;

     }

     @requestmapping(value = "/datapointer", method = requestmethod.post)
     public @responsebody
     string datapointer(@requestbody logfile logfileobject) {
     string name1 = "test";
     string gender = "test";
     string email = "test";
     string phone = "test";
     string city = "test";

     // system.out.println(name);
     system.out.println(gender);
     system.out.println(email);
     system.out.println(phone);
     system.out.println(city);

     system.out.println("logfileobject" + logfileobject.getcategoryid());

     logfileobject.setdatapoints(datapoints);

     datapoint datapoint1 = this.getuserselecteddatapoint(logfileobject);
     datapoint1.setdbcolumnlist(logfileobject.getdatapoint()
     .getdbcolumnlist());

     logfileobject.setdatapoint(datapoint1);

     logfileobject.setgeneratelabels("false");
     logfileobject.setgeneratequery("true");
     system.out.println(" i am called.....");

     try {

     if (logfileobject.getrunquery().equalsignorecase("true")) {
     // logfileobject = logservice.preparequery(logfileobject);

     } else {
     // logfileobject = logservice.preparequery(logfileobject);
     }

     } catch (exception e) {
     logfileobject.seterrormessage(e.getmessage());
     }

     try {
     logservice.getqueryresult(logfileobject);
     } catch (exception e) {
     logfileobject.seterrormessage(e.getmessage());
     }

     string str = "{\"user\": { \"name\": \"" + name1 + "\",\"gender\": \""
     + gender + "\",\"email\": \"" + email + "\",\"phone\": \""
     + phone + "\",\"city\": \"" + city + "\"}}";
     return str;

     }

     @requestmapping(value = "/generatereporter", method = requestmethod.post, produces = { mediatype.application_json_value }, consumes = { mediatype.application_json_value })
     @responsebody
     public logfile generatereport(@requestbody logfile logfileobject) {
     // return smartphoneservice.create(smartphone);
     system.out.println(" i am calling.....");

     // logfileobject.setdatapoints(datapoints);

     try {

     datapoint datapoint1 = this.getuserselecteddatapoint(logfileobject);
     datapoint1.setdbcolumnlist(logfileobject.getdatapoint()
     .getdbcolumnlist());

     logfileobject.setdatapoint(datapoint1);

     logfileobject.setgeneratelabels("false");
     logfileobject.setgeneratequery("true");
     system.out.println(" i am called.....");

     if (logfileobject.getrunquery().equalsignorecase("true")) {
     // logfileobject = logservice.preparequery(logfileobject);

     } else {
     // logfileobject = logservice.preparequery(logfileobject);
     }

     } catch (exception e) {
     logfileobject.seterrormessage(e.getmessage());
     }

     try {
     return logservice.getqueryresult(logfileobject);
     } catch (exception e) {
     logfileobject.seterrormessage(e.getmessage());
     }
     return logfileobject;

     }*/
    @RequestMapping(value = "/generateReport", method = {RequestMethod.GET,
        RequestMethod.POST})
    @ExceptionHandler({SpringException.class})
    public ModelAndView dataPoint1(
            @ModelAttribute("logFileObject") LogFile logFileObject,
            BindingResult result, HttpSession session) {

        ModelAndView modelAndView;
        // DataPoints dataPoints = (DataPoints)
        // session.getAttribute("dataPoints");
        List<DataPoint> dataPoint;
        if (dataPoints == null) {
            try {
                dataPoint = logService.getMenu("");
                dataPoints = new DataPoints();
                dataPoints.setDataPoint(dataPoint);
                // dataPoints.setClientNameList(logService.getClientNameList(WebConstants.clientListQuery));
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        // DataPoints dataPoints = CentralLogUtil.getdataPoints(session);
        logFileObject.setDataPoints(dataPoints);
        DataPoint dataPoint1 = null;
        try {
            dataPoint1 = this.getUserSelectedDataPoint(logFileObject);
        } catch (SpringException sce) {
            throw new SpringException(
                    "Data Label which has selected doesnot exits. Invalid Data Point selection");
        }

        dataPoint1.setDbColumnList(logFileObject.getDataPoint()
                .getDbColumnList());

        logFileObject.setDataPoint(dataPoint1);

        logFileObject.setGenerateLabels("false");
        logFileObject.setGenerateQuery("true");

        try {

            if (logFileObject.getRunQuery().equalsIgnoreCase("true")) {
                logFileObject.setCurrPage(1);

                logFileObject = logService.prepareQuery(logFileObject, appID,
                        clientID);
                double dd = (double) logService
                        .getQueryResultForPagination(logFileObject)
                        / (double) WebConstants.PAGE_SIZE;
                logFileObject.setTotalPages((int) Math.ceil(dd));

                session.setAttribute("excelQuery",
                        logFileObject.getQueryForExcel());

            } else {

                logFileObject = logService.prepareQuery(logFileObject, appID,
                        clientID);
            }

        } catch (Exception e) {
            logFileObject.setErrorMessage(e.getMessage());
        }

        try {
            logService.getQueryResult(logFileObject);
        } catch (Exception e) {
            logFileObject.setErrorMessage(e.getMessage());
        }

        modelAndView = new ModelAndView("home", "logFileObject", logFileObject);
        try {
            String sql = "SELECT HEADER_MAP from CENTRALLOG.datapointsconfig WHERE NAME = ?";
            String headerMap = (String) logService.fireQuery(sql, new Object[]{logFileObject.getDataPoint().getLabelName()}, String.class);
            modelAndView.addObject("headerMaps", HeaderSplitter.getSubHeaderForString(headerMap, logFileObject.getLabelList()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {

            if (clientName == null) {
                clientName = logService
                        .getClientAppMapList(WebConstants.clientNameQuery);
            }
            if (clientID == null) {
                clientID = logService
                        .getClientAppMapList(WebConstants.clientIDQuery);
            }
            if (appID == null) {
                appID = logService.getClientAppMapList(WebConstants.appIDQuery);
            }
            if (appName == null) {
                appName = logService
                        .getClientAppMapList(WebConstants.appNameQuery);
            }
            if (categoryID == null) {
                categoryID = logService
                        .getClientAppMapList(WebConstants.categoryQuery);
            }

            modelAndView.addObject("clientNameList", clientName);
            modelAndView.addObject("clientIDList", clientID);
            modelAndView.addObject("appIDList", appID);
            modelAndView.addObject("appNameList", appName);
            modelAndView.addObject("categoryIDSet", categoryID);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return modelAndView;
    }

    @RequestMapping(value = "/sendExcel", method = RequestMethod.GET)
    public ModelAndView sendExcel(HttpSession session) {
        if (log.isDebugEnabled()) {
            log.debug("Inside CentralLog Send to Excel ");
        }
        LogFile logFileObject = new LogFile();

        try {
            if ((String) session.getAttribute("excelQuery") != null) {

                System.out.println("Query from session is >>>> "
                        + (String) session.getAttribute("excelQuery"));

                try {

                    DataPoint dataPoint = new DataPoint();
                    dataPoint.setDbColumnList(logService
                            .getMetaDataInformation((String) session
                                    .getAttribute("excelQuery")));
                    logFileObject.setDataPoint(dataPoint);
                    logFileObject.setPreparedQuery((String) session
                            .getAttribute("excelQuery"));
                    logFileObject = logService.getQueryResult(logFileObject);
                } catch (Exception e1) {
                    logFileObject.setErrorMessage(e1.getMessage());
                }

            } else {
                throw new SpringException(
                        "Some error occured ! please try again letter");
            }

        } catch (Exception e) {
            logFileObject.setErrorMessage(e.getMessage());
        }

        // return a view which will be resolved by an excel view resolver
        return new ModelAndView("excelView", "excelData", logFileObject);
    }

    private DataPoint getUserSelectedDataPoint(LogFile logFileObject) {
        List<DataPoint> dataPointList = logFileObject.getDataPoints()
                .getDataPoint();
        for (DataPoint dataPoint : dataPointList) {
            if (dataPoint.getLabelName().equals(
                    logFileObject.getSelectedDataPoint())) {
                return dataPoint;
            }
        }
        throw new SpringException(
                "Data Label which has selected doesnot exits. Invalid Data Point selection");

    }

    @RequestMapping(value = "/reload", method = RequestMethod.GET)
    public void reloadCache() {
        List<DataPoint> dataPoint;
        try {
            dataPoint = logService.getMenu("");
            dataPoints = new DataPoints();
            dataPoints.setDataPoint(dataPoint);
            // dataPoints.setClientNameList(logService.getClientNameList(WebConstants.clientListQuery));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * @param request
     * @Added by i81324(bpupadhyay)
     * @Date 2015-09-09
     * @Purpose to generate graph model
     * @return
     */
    @RequestMapping(value = "/genChart", method = RequestMethod.GET)
    @ResponseBody
    public String genChart(HttpServletRequest request) {
        try {
            Gson gson = new Gson();
            String datapointName = request.getParameter("datapointName");
            log.info("DATA-POINT : " + datapointName);
            if (datapointName != null & !datapointName.isEmpty()) {
                log.info("Go For Call....");
                List<ChartModel> generateChart = logService.generateChart(datapointName);
                log.info("Chart SIze " + generateChart.size());
                return gson.toJson(generateChart);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            return "{}";
        }
        return "{}";
    }

}
