$(function() {

    $('#side-menu').metisMenu();

});

//Loads the correct sidebar on window load,
//collapses the sidebar on window resize.
$(function() {
    $(window).bind("load resize", function() {
        width = (this.window.innerWidth > 0) ? this.window.innerWidth : this.screen.width;
        if (width <=768) {
            $('div.sidebar-collapse').addClass('collapse')
        } else {
            $('div.sidebar-collapse').removeClass('collapse')
        }
    })
})

$('.toggle-menu').click(function() {
	$( '.navbar-static-side' ).hide();
	$('#page-wrapper').css("margin-left", "0");
	$( '.collapse-menu' ).show();
	$( '.expand-menu' ).hide();
	
});
$('.collapse-menu').click(function() {
	$( ".navbar-static-side" ).show();
	$('#page-wrapper').css("margin-left", "250px");
	$( '.collapse-menu' ).hide();
	$( '.expand-menu' ).show();
});




