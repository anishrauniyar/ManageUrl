CREATE OR REPLACE PROCEDURE exec_sql(STRING IN VARCHAR2) AS
CURSOR_NAME INTEGER;
RET INTEGER;
BEGIN
	CURSOR_NAME := DBMS_SQL.OPEN_CURSOR;
	BEGIN
		DBMS_SQL.PARSE(CURSOR_NAME,
STRING, DBMS_SQL.native);
		RET := DBMS_SQL.EXECUTE(CURSOR_NAME);
	EXCEPTION
		WHEN
OTHERS THEN
			DBMS_SQL.CLOSE_CURSOR(CURSOR_NAME);
			RAISE;
	END
;	DBMS_SQL.CLOSE_CURSOR(CURSOR_NAME);
END;
/


CREATE OR REPLACE PROCEDURE sp_addclientstouser(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblUserID 	IN VARCHAR2  DEFAULT NULL)
AS
BEGIN
MERGE INTO ztbl_DTS_UsersAndClients a USING (SELECT vblUserID USERID, vblClientID CLIENTID FROM dual) b
ON (a.USERID = b.USERID AND a.CLIENTID = b.CLIENTID)
WHEN NOT MATCHED THEN INSERT VALUES (b.USERID, b.CLIENTID, NULL); 
END SP_ADDCLIENTSTOUSER;
/


CREATE OR REPLACE PROCEDURE sp_addmappingdethist(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSNo 	IN NUMBER  DEFAULT NULL,
vblSetNo 	IN NUMBER  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
vblKeyField 	IN VARCHAR2  DEFAULT NULL,
vblModifiedOn 	IN DATE  DEFAULT NULL)
AS
vblversion 	VARCHAR2(20);
vblTransactionID 	NUMBER(10,0);

BEGIN
	FOR rec IN ( SELECT   Version
							 FROM ztbl_DTS_DTS_Mast
								WHERE ClientID = vblClientID
								 AND DTSNo = vblDTSNo)
	LOOP
	   vblversion := rec.Version ;

	END LOOP;

	FOR rec IN ( SELECT   TransactionID
							 FROM ztbl_DTS_Mapping_Hist
									WHERE ClientID = vblClientID
									 AND DTSNo = vblDTSNo
									 AND SetNo = vblSetNo
									 AND Category = vblCategory
									 AND KeyField = vblKeyField
									 AND ModifiedOn = vblModifiedOn)
	LOOP
	   vblTransactionID := rec.TransactionID ;

	END LOOP;
	IF  vblTransactionID IS NULL THEN
		RETURN ;
	END IF;
	DELETE FROM ztbl_DTS_Mapping_Source_Hist
		WHERE TransactionID = vblTransactionID;

	DELETE FROM ztbl_DTS_Mapping_Rule_Hist
		WHERE TransactionID = vblTransactionID;

	INSERT INTO ztbl_DTS_Mapping_Source_Hist (TransactionID, TableName, FieldName, FieldFormat, Version)
		SELECT  vblTransactionID, TableName, FieldName, FieldFormat, vblversion
		 FROM ztbl_DTS_Mapping_Source
				WHERE ClientID = vblClientID
				 AND DTSNo = vblDTSNo
				 AND SetNo = vblSetNo
				 AND Category = vblCategory
				 AND KeyField = vblKeyField;

	INSERT INTO ztbl_DTS_Mapping_Rule_Hist (TransactionID, BusinessRule, Version)
		SELECT vblTransactionID, BusinessRule, vblversion
		 FROM ztbl_DTS_Mapping_Rule
				WHERE ClientID = vblClientID
				 AND DTSNo = vblDTSNo
				 AND SetNo = vblSetNo
				 AND Category = vblCategory
				 AND KeyField = vblKeyField;

	DBMS_OUTPUT.PUT_LINE('detailed hist aded for ' || vblClientID) ;
END SP_ADDMAPPINGDETHIST;
/

/**
 * author: I80482 
  * Date: Mar 16, 2012
  * File: d2Hawkeye.dts.test.java.updateDTSMappingHistory
  * Purpose:Commented for cleaning purpose

 */
/*
CREATE OR REPLACE PROCEDURE sp_addmappinghistory(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSNo 	IN NUMBER  DEFAULT NULL,
vblSetNo 	IN NUMBER  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
vblKeyField 	IN VARCHAR2  DEFAULT NULL,
vblUserID 	IN VARCHAR2  DEFAULT NULL,
vblModifiedOn 	IN DATE  DEFAULT NULL)
AS
vblLastApprovedOn 	DATE;
CreatedOn 	DATE;
StoO_selcnt INT;
BEGIN

	--ModifiedOn :=  NVL(ModifiedOn, SYSDATE);

	SELECT   MAX(NVL(ModifiedOn, SYSDATE))
	INTO vblLastApprovedOn
	 FROM ztbl_DTS_Mast_Hist
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo
			 AND Status = 'A';

	IF  vblLastApprovedOn IS NULL THEN
		RETURN ;
	END IF;

	BEGIN
	StoO_selcnt := 0;
	SELECT 1 INTO StoO_selcnt
	FROM DUAL
	WHERE  EXISTS (
			SELECT  *
			 FROM ztbl_DTS_Mapping_Hist
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo
			 AND SetNo = vblSetNo
			 AND Category = vblCategory
			 AND KeyField = vblKeyField
			 AND ModifiedOn > vblLastApprovedOn);

	END;
	IF StoO_selcnt != 0 THEN
		UPDATE ztbl_DTS_Mapping_Hist
		SET 			UserID = vblUserID,
					ModifiedOn = vblModifiedOn
					WHERE ClientID = vblClientID
					 AND DTSNo = vblDTSNo
					 AND SetNo = vblSetNo
					 AND Category = vblCategory
					 AND KeyField = vblKeyField
					 AND ModifiedOn > vblLastApprovedOn;

	ELSE
		INSERT INTO ztbl_DTS_Mapping_Hist (ClientID, DTSNo, SetNo, Category, KeyField, UserID, ModifiedOn)
			VALUES (vblClientID, vblDTSNo,vblSetNo,vblCategory,vblKeyField,vblUserID, 																		vblModifiedOn);

	END IF;

	sp_AddMappingDetHist(vblClientID,vblDTSNo,vblSetNo,vblCategory,vblKeyField,vblModifiedOn);

END SP_ADDMAPPINGHISTORY;
/
*/
CREATE OR REPLACE PROCEDURE sp_copydts(
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 		IN VARCHAR2  DEFAULT NULL,
vblDestinationClient 	IN VARCHAR2  DEFAULT NULL,
vblUser			IN VARCHAR2  DEFAULT NULL)
AS
vblDestName 	VARCHAR2(100);
vblDestDTSNo 	VARCHAR2(4);
vblDatabaseID 	VARCHAR2(10);
vblVersion 	VARCHAR2(10);
vblserverid 	VARCHAR2(10);
vblclientName 	VARCHAR2(100);

BEGIN
	FOR rec IN ( SELECT  ClientName FROM ztbl_DTS_Clients WHERE ClientID = vblDestinationClient)
	LOOP
	   vblDestName := rec.ClientName ;
	END LOOP;

	SELECT MAX(DTSNo) + 1 INTO vblDestDTSNo FROM ztbl_DTS_DTS_Set WHERE ClientID = vblDestinationClient;
	SELECT MAX(DatabaseID) INTO vblDatabaseID FROM ztbl_DTS_Databases WHERE ClientID = vblDestinationClient;

	FOR rec IN ( SELECT Version FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblSourceClient and DTSNo = vblDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;
	IF  vblDestDTSNo is NULL THEN
	BEGIN
		vblDestDTSNo := 1;
	END;
	END IF;
	IF  vblDatabaseID is NULL THEN
	BEGIN

		--FOR rec IN ( SELECT  ServerID  FROM ztbl_DTS_Servers)
		--LOOP
		--   serverid := rec.ServerID ;

		--END LOOP;

		FOR rec IN ( SELECT   ClientName  FROM ztbl_DTS_Clients  WHERE ClientID = vblDestinationClient)
		LOOP
		   vblclientName := rec.ClientName ;

		END LOOP;
		INSERT INTO ztbl_DTS_Databases (ClientID, ServerID, DatabaseName)
			VALUES (vblDestinationClient, vblserverId, vblclientName);


		SELECT MAX(DatabaseID) INTO vblDatabaseID FROM ztbl_DTS_Databases
					WHERE ClientID = vblDestinationClient;

	END;
	END IF;
	INSERT INTO ztbl_DTS_DTS_Mast (ClientID, DTSNo, CreationDate, CreatedBy, Remarks, Version)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SYSDATE
		CreationDate, vblUser CreatedBy, 'Copied from ' || c.ClientName
		Remarks, m.Version Version
		 FROM ztbl_DTS_DTS_Mast m, ztbl_DTS_Clients c
				WHERE m.ClientID = c.ClientID
				 and m.ClientID = vblSourceClient
				 and m.DTSNo = vblDTSNo;

	INSERT INTO ztbl_DTS_SourceTableSpace (ClientID, DTSNo, TableName, FieldName, FieldFormat, DatabaseID)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, TableName,
		FieldName, FieldFormat, vblDatabaseID DatabaseID
		 FROM ztbl_DTS_SourceTableSpace sts
				WHERE sts.ClientID = vblSourceClient
				 AND sts.DTSNo = vblDTSno;

	INSERT INTO ztbl_DTS_DTS_Set (ClientID, DTSNo, SetNo)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo
		 FROM ztbl_DTS_DTS_Set
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;

	INSERT INTO ztbl_DTS_SETNAMES (ClientID, DTSNo, SetNo, CATEGORY, SETNAME)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo, CATEGORY, SETNAME
		 FROM ztbl_DTS_SETNAMES
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;

	INSERT INTO ztbl_DTS_Mapping_Highlights (ClientID, DTSNo, Category, KeyField, Version, Priority)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, Category,
		KeyField, vblVersion, Priority
		 FROM ztbl_DTS_Mapping_Highlights
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;

	INSERT INTO ztbl_DTS_Mapping_Rule (ClientID, DTSNo, SetNo, Category, KeyField, Version, BusinessRule, Example, TranslatedRule)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo,
		Category, KeyField, vblVersion, BusinessRule, Example, TranslatedRule
		 FROM ztbl_DTS_Mapping_Rule
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;

 /*[SPCONV-ERR(147)]:(LIKE) if using '[' Manual conversion required*/

	DELETE  ztbl_DTS_Mapping_Rule
		WHERE Category LIKE '%general%'
		 and KeyField = 'ClientID'
		 and ClientID = vblDestinationClient
		 and DTSNo = vblDestDTSNo
		 and Version = vblVersion;

	INSERT INTO ztbl_DTS_Mapping_Rule (ClientID, DTSNo, SetNo, Category, KeyField, Version, BusinessRule, TranslatedRule)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo,
		'General Info' Category, 'ClientID' KeyField, vblVersion Version,
		vblDestinationClient BusinessRule, vblDestinationClient TranslatedRule
		 FROM ztbl_DTS_DTS_Set
				WHERE ClientID = vblDestinationClient
				 and DTSNo = vblDestDTSNo;

 /*[SPCONV-ERR(179)]:(LIKE) if using '[' Manual conversion required*/

	DELETE  ztbl_DTS_Mapping_Rule
		WHERE Category LIKE '%general%'
		 and KeyField = 'ClientName'
		 and ClientID = vblDestinationClient
		 and DTSNo = vblDestDTSNo
		 and Version = vblVersion;

	INSERT INTO ztbl_DTS_Mapping_Rule (ClientID, DTSNo, SetNo, Category, KeyField, Version, BusinessRule, TranslatedRule)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo,
		'General Info' Category, 'ClientName' KeyField, vblVersion Version,
		vblDestName BusinessRule, vblDestName TranslatedRule
		 FROM ztbl_DTS_DTS_Set
				WHERE ClientID = vblDestinationClient
				 and DTSNo = vblDestDTSNo;

	INSERT INTO ztbl_DTS_Mapping_Source (ClientID, DTSNo, SetNo, Category, KeyField, Version, TableName, FieldName, FieldFormat, DatabaseID)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo,
		Category, KeyField, vblVersion, TableName, FieldName, FieldFormat,
		vblDatabaseID DatabaseID
		 FROM ztbl_DTS_Mapping_Source
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;

	UPDATE ztbl_DTS_Clients SET Version = vblVersion WHERE ClientId = vblDestinationClient;

END SP_COPYDTS;
/

CREATE OR REPLACE PROCEDURE sp_copydtsselectedsets(
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL,
vblDestinationClient 	IN VARCHAR2  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
vblSets 	IN VARCHAR2  DEFAULT NULL)
AS
vblDestName 	VARCHAR2(100);
vblDestDTSNo 	VARCHAR2(4);
vblDatabaseID 	VARCHAR2(10);
vblVersion 	VARCHAR2(10);
strSQL 	VARCHAR2(8000);

BEGIN
	FOR rec IN ( SELECT   ClientName FROM ztbl_DTS_Clients WHERE ClientID = vblDestinationClient)
	LOOP
	   vblDestName := rec.ClientName ;

	END LOOP;

	SELECT MAX(DTSNo) INTO vblDestDTSNo FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblDestinationClient;

	SELECT MAX(DatabaseID) INTO vblDatabaseID
	 FROM ztbl_DTS_Databases WHERE ClientID = vblDestinationClient;

	FOR rec IN ( SELECT   Version  FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblSourceClient
									 and DTSNo = vblDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;
	strSQL := 'insert into ztbl_DTS_Mapping_Highlights
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	Priority
)
select
	''' || vblDestinationClient || '''	as ClientID,
	' || vblDestDTSNo || '		as DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	Priority
from ztbl_DTS_Mapping_Highlights
where ClientID = ''' || vblSourceClient || ''' AND DTSno = ' || vblDTSno || ' AND Category = ''' || vblCategory || ''' AND SetNo IN (' || vblSets || ')';
	EXEC_SQL (strSQL);

	strSQL := 'insert into ztbl_DTS_Mapping_Rule
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	BusinessRule,
	Example,
	TranslatedRule
)
select
	''' || vblDestinationClient || ''' as ClientID,
	' || vblDestDTSNo || ' AS DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	BusinessRule,
	Example,
	TranslatedRule
from ztbl_DTS_Mapping_Rule where ClientID = ''' || vblSourceClient || ''' AND DTSno= ' || vblDTSno || ' AND Category = ''' || vblCategory || ''' AND SetNo IN (' || vblSets || ')';
	EXEC_SQL (strSQL);

 /*[SPCONV-ERR(87)]:(LIKE) if using '[' Manual conversion required*/

	IF  vblCategory LIKE '%general%' THEN
	BEGIN
		strSQL := 'update	ztbl_DTS_Mapping_Rule
set	BusinessRule = ''' || vblDestinationClient || ''',
	TranslatedRule = ''' || vblDestinationClient || ''' where	Category like ''%general%''
	and KeyField=''ClientID''
	and ClientID=''' || vblDestinationClient || ''' and DTSNo=' || vblDestDTSNo || ' and Version=''' || vblVersion || ''' and SetNo IN (' || vblSets || ')';
		EXEC_SQL (strSQL);

		strSQL := 'update	ztbl_DTS_Mapping_Rule
set	BusinessRule = ''' || vblDestName || ''',
	TranslatedRule = ''' || vblDestName || ''' where	Category like ''%general%''
	and KeyField=''ClientName''
	and ClientID=''' || vblDestinationClient || ''' and DTSNo=' || vblDestDTSNo || ' and Version=''' || vblVersion || ''' and SetNo IN (' || vblSets || ')';
		EXEC_SQL (strSQL);

	END;
	END IF;
	strSQL := 'insert into ztbl_DTS_Mapping_Source
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	TableName,
	FieldName,
	FieldFormat,
	DatabaseID
)
SELECT
	''' || vblDestinationClient || ''' as ClientID,
	' || vblDestDTSNo || ' AS DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	TableName,
	FieldName,
	FieldFormat,
	' || vblDatabaseID || ' as DatabaseID
FROM ztbl_DTS_Mapping_Source where ClientID = ''' || vblSourceClient || ''' AND DTSno = ' || vblDTSno || ' AND Category = ''' || vblCategory || ''' AND SetNo IN (' || vblSets || ')';
	EXEC_SQL (strSQL);

END SP_COPYDTSSELECTEDSETS;
/

CREATE OR REPLACE PROCEDURE sp_copydtsselectedsetsprep(
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL,
vblDestinationClient 	IN VARCHAR2  DEFAULT NULL,
vblUser_ 	IN VARCHAR2  DEFAULT NULL)
AS
vblDestName 	VARCHAR2(100);
vblDestDTSNo 	VARCHAR2(4);
vblDatabaseID 	VARCHAR2(10);
vblVersion 	VARCHAR2(10);
vblserverid 	VARCHAR2(10);
vblclientName 	VARCHAR2(100);

BEGIN
	FOR rec IN ( SELECT   ClientName FROM ztbl_DTS_Clients WHERE ClientID = vblDestinationClient)
	LOOP
	   vblDestName := rec.ClientName ;

	END LOOP;

	SELECT   MAX(DTSNo) + 1
	INTO vblDestDTSNo
	 FROM ztbl_DTS_DTS_Set
			WHERE ClientID = vblDestinationClient;

	SELECT   MAX(DatabaseID)
	INTO vblDatabaseID
	 FROM ztbl_DTS_Databases
			WHERE ClientID = vblDestinationClient;

	FOR rec IN ( SELECT   Version FROM ztbl_DTS_DTS_Mast
		WHERE ClientID = vblSourceClient  and DTSNo = vblDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;
	IF  vblDestDTSNo is NULL THEN
	BEGIN
		vblDestDTSNo := 1;
	END;
	END IF;
	IF  vblDatabaseID is NULL THEN
	BEGIN

		--FOR rec IN ( SELECT   ServerID  FROM ztbl_DTS_Servers
		--  WHERE ServerName = 'Washington')
		--LOOP
		--   serverid := rec.ServerID ;
		--END LOOP;

		FOR rec IN ( SELECT   ClientName  FROM ztbl_DTS_Clients
		   WHERE ClientID = vblDestinationClient)
		LOOP
		   vblclientName := rec.ClientName ;

		END LOOP;
		INSERT INTO ztbl_DTS_Databases (ClientID, ServerID, DatabaseName)
			VALUES (vblDestinationClient,vblserverId, vblclientName);
		SELECT   MAX(DatabaseID) INTO vblDatabaseID
			 FROM ztbl_DTS_Databases
					WHERE ClientID = vblDestinationClient;
	END;
	END IF;
	INSERT INTO ztbl_DTS_DTS_Mast (ClientID, DTSNo, CreationDate, CreatedBy, Remarks, Version)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SYSDATE
		CreationDate, vblUser_ CreatedBy, 'Copied from ' || c.ClientName
		Remarks, m.Version Version
		 FROM ztbl_DTS_DTS_Mast m, ztbl_DTS_Clients c
				WHERE m.ClientID = c.ClientID
				 and m.ClientID = vblSourceClient
				 and m.DTSNo = vblDTSNo;

	INSERT INTO ztbl_DTS_SourceTableSpace (ClientID, DTSNo, TableName, FieldName, FieldFormat, DatabaseID)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, TableName,
		FieldName, FieldFormat, vblDatabaseID DatabaseID
		 FROM ztbl_DTS_SourceTableSpace sts
				WHERE sts.ClientID = vblSourceClient
				 AND sts.DTSNo = vblDTSno;

	INSERT INTO ztbl_DTS_DTS_Set (ClientID, DTSNo, SetNo)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo
		 FROM ztbl_DTS_DTS_Set
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;

	INSERT INTO ZTBL_DTS_SETNAMES (ClientID, DTSNo, SetNo, CATEGORY, SETNAME)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SetNo, CATEGORY, SETNAME
		 FROM ZTBL_DTS_SETNAMES 
				WHERE ClientID = vblSourceClient
				 AND DTSno = vblDTSno;


	UPDATE ztbl_DTS_Clients
	SET 		Version = vblVersion
			WHERE ClientId = vblDestinationClient;

END SP_COPYDTSSELECTEDSETSPREP;
/

CREATE OR REPLACE PROCEDURE sp_copyset(
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL,
vblSourceDTSSetNo 	IN VARCHAR2  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL)
AS
vblDestDTSSetNo 	VARCHAR2(4);

BEGIN

	SELECT MAX(SETNo) + 1 INTO vblDestDTSSetNo FROM ztbl_DTS_DTS_Set
		WHERE DTSNo = vblDTSNo  AND ClientID = vblSourceClient;

	INSERT INTO ztbl_DTS_DTS_Set (ClientID, DTSNo, SetNo)
		SELECT DISTINCT  ClientID, DTSNo, vblDestDTSSetNo
		 FROM ztbl_DTS_DTS_Set
				WHERE DTSNo = vblDTSNo
				 AND ClientID = vblSourceClient;
				 
		 

	INSERT INTO ztbl_DTS_Mapping_Rule (ClientID, DTSNo, SetNo, Category, KeyField, Version, BusinessRule, Example, TranslatedRule)
		SELECT  ClientID, DTSNo, vblDestDTSSetNo, Category, KeyField, Version,
		BusinessRule, Example, TranslatedRule
		 FROM ztbl_DTS_Mapping_Rule
				WHERE DTSNo = vblDTSNo
				 AND ClientID = vblSourceClient
				 AND Category = vblCategory
				 AND SetNo = vblSourceDTSSetNo;

	INSERT INTO ztbl_DTS_Mapping_Source (ClientID, DTSNo, SetNo, Category, KeyField, Version, TableName, FieldName, FieldFormat, DatabaseID)
		SELECT  ClientID, DTSNo, vblDestDTSSetNo, Category, KeyField, Version,
		TableName, FieldName, FieldFormat, DatabaseID
		 FROM ztbl_DTS_Mapping_Source
				WHERE DTSNo = vblDTSNo
				 AND ClientID = vblSourceClient
				 AND Category = vblCategory
				 AND SetNo = vblSourceDTSSetNo;

END SP_COPYSET;
/

CREATE OR REPLACE PROCEDURE sp_deletedts(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSNo 	IN NUMBER  DEFAULT NULL,
spType 	IN CHAR  DEFAULT NULL)
AS
BEGIN
	IF  spType = 'P' THEN
	BEGIN
		DELETE  ztbl_DTS_AttachedDocuments
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

		DELETE  ztbl_DTS_Mapping_Highlights
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

		DELETE  ztbl_DTS_Mapping_Rule
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

		DELETE  ztbl_DTS_Mapping_Source
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

		DELETE  ztbl_DTS_SourceTableSpace
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

		DELETE  ztbl_DTS_DTS_Set
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

		DELETE  ztbl_DTS_DTS_Mast
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

	END;
	ELSE
		UPDATE ztbl_DTS_DTS_Mast
		SET 			Status = 'D'
					WHERE ClientID = vblClientID
					 AND DTSNo = vblDTSNo;

	END IF;
END SP_DELETEDTS;
/

CREATE OR REPLACE PROCEDURE sp_managecategory(
vblSN 	IN NUMBER  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
vblCategoryDesc 	IN VARCHAR2  DEFAULT NULL,
spMode 	IN CHAR  DEFAULT NULL)
AS
newSN 	NUMBER(10,0);
BEGIN
	IF  spMode = 'D' THEN
		DELETE  ztbl_DTS_Categories WHERE SN = vblSN;

	ELSE
		IF  spMode = 'U' THEN
			UPDATE ztbl_DTS_Categories SET 	Category = vblCategory,
				CategoryDesc = vblCategoryDesc	WHERE SN = vblSN;

		ELSE
			IF  spMode = 'I' THEN
			BEGIN

				SELECT MAX(SN) INTO newSN  FROM ztbl_DTS_Categories;

				IF  newSN IS NULL THEN

					newSN :=  0;

				END IF;

				newSN :=  newSN + 1;

				INSERT INTO ztbl_DTS_Categories
					VALUES (newSN, vblCategory, vblCategoryDesc);

			END;
			END IF;
			END IF;
			END IF;
END SP_MANAGECATEGORY;
/

CREATE OR REPLACE PROCEDURE sp_managekeyfield(
vblSN IN NUMBER  DEFAULT NULL,
vblCategory IN VARCHAR2  DEFAULT NULL,
vblKeyfield IN VARCHAR2  DEFAULT NULL,
vblVersion IN VARCHAR2  DEFAULT NULL,
vblFieldFormat IN VARCHAR2  DEFAULT NULL,
vblTargetTable IN VARCHAR2 DEFAULT NULL,
vblTargetField IN VARCHAR2 DEFAULT NULL,
spMode 	IN CHAR  DEFAULT NULL)
AS
newSN 	NUMBER(10,0);

BEGIN
	--IF  spMode = 'D' THEN
	--   BEGIN
		--DELETE ztbl_DTS_Mapping_Mast WHERE Category = vblCategory AND Keyfield = vblKeyfield AND SN = vblSN;
		--DELETE ztbl_DTS_Mapping_Target WHERE Category = vblCategory AND Keyfield = vblKeyfield;
 	--   END;
	--ELSE
		IF  spMode = 'U' THEN
			UPDATE ztbl_DTS_Mapping_Mast
			SET Keyfield = vblKeyfield, FieldFormat = vblFieldFormat
			WHERE Category = vblCategory AND SN = vblSN And Version = vblVersion;

			UPDATE ztbl_DTS_Mapping_Target
			SET Keyfield = vblKeyfield,  TableName = vblTargetTable, FieldName = vblTargetField
			WHERE Category = vblCategory AND keyfield=vblKeyfield AND Version = vblVersion;

		ELSE
			IF  spMode = 'I' THEN
			BEGIN

				SELECT MAX(SN) INTO newSN FROM ztbl_DTS_Mapping_Mast WHERE Category = Category;

				IF  newSN IS NULL THEN
					newSN :=  0;
				END IF;

				newSN :=  newSN + 1;

				INSERT INTO ztbl_DTS_Mapping_Mast (SN, CATEGORY, KEYFIELD, VERSION, FIELDFORMAT) VALUES (newSN, vblCategory, vblKeyfield, vblVersion, vblFieldFormat);
				INSERT INTO ztbl_DTS_Mapping_Target (CATEGORY, KEYFIELD, VERSION, TABLENAME, FIELDNAME) VALUES
				(vblCategory, vblKeyfield, vblVersion, vblTargetTable, vblTargetField);
			END;
			END IF;
		END IF;
	--END IF;
END SP_MANAGEKEYFIELD;
/

CREATE OR REPLACE PROCEDURE sp_renumberdtsset(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
OldSetNo 	IN NUMBER  DEFAULT NULL,
NewSetNo 	IN NUMBER  DEFAULT NULL)
AS
BEGIN
	UPDATE ztbl_DTS_Mapping_Highlights
	SET 	SetNo = NewSetNo
		WHERE ClientID = vblClientID
		 and DTSno = vblDTSno
		 and SetNo = OldSetNo
		 and Category = vblCategory;

	UPDATE ztbl_DTS_Mapping_Rule
	SET 		SetNo = NewSetNo
			WHERE ClientID = vblClientID
			 and DTSno = vblDTSno
			 and SetNo = OldSetNo
			 and Category = vblCategory;

	UPDATE ztbl_DTS_Mapping_Source
	SET 		SetNo = NewSetNo
			WHERE ClientID = vblClientID
			 and DTSno = vblDTSno
			 and SetNo = OldSetNo
			 and Category = vblCategory;

END SP_RENUMBERDTSSET;
/

CREATE OR REPLACE PROCEDURE sp_repairdtssetnumbers(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL)
AS
BEGIN
	DELETE FROM ztbl_DTS_DTS_Set
	WHERE ClientID = vblClientID
	 and DTSno =vblDTSno
	 and SetNo  NOT IN (
		SELECT  a.SetNo
		 FROM (
		SELECT DISTINCT  b.ClientID, b.DTSNo, b.SetNo
		 FROM ztbl_DTS_Mapping_Highlights b
		UNION
		SELECT DISTINCT  c.ClientID, c.DTSNo, c.SetNo
		 FROM ztbl_DTS_Mapping_Source c
		UNION
		SELECT DISTINCT  d.ClientID, d.DTSNo, d.SetNo
		 FROM ztbl_DTS_Mapping_Rule d ) a
	WHERE a.ClientID = ClientID
	 and a.DTSno = DTSno  );
	 
	DELETE FROM ZTBL_DTS_SETNAMES WHERE ClientID = vblClientID AND DTSNO =vblDTSno
	AND SETNO NOT IN
	(
	SELECT SETNO FROM ztbl_DTS_DTS_Set WHERE ClientID = vblClientID AND DTSNO =vblDTSno
	);

END SP_REPAIRDTSSETNUMBERS;
/



CREATE OR REPLACE PROCEDURE sp_updatedtsstatus(
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSNo 	IN NUMBER  DEFAULT NULL,
vblStatus 	IN VARCHAR2  DEFAULT NULL,
vblUserID 	IN VARCHAR2  DEFAULT NULL,
vblRemarks 	IN VARCHAR2  DEFAULT NULL,
vblModifiedOn_ 	IN DATE  DEFAULT NULL)
AS
vblLastStatus 	VARCHAR2(1);
vblModifiedOn DATE;
BEGIN

	vblModifiedOn :=  NVL(vblModifiedOn_, SYSDATE);

	FOR rec IN ( SELECT   Status  FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblClientID
									 AND DTSNo = vblDTSNo)
	LOOP
	   vblLastStatus := UPPER(rec.Status) ;

	END LOOP;
	IF  NVL(vblLastStatus, 'C') = 'C' AND  UPPER(vblStatus) = 'M' THEN
		RETURN ;
	END IF;
	UPDATE ztbl_DTS_DTS_Mast
	SET 		Status = vblStatus,
			LastUpdated = vblModifiedOn,
			ApprovedBy = CASE vblStatus WHEN 'A' THEN vblUserID END
			WHERE ClientID = vblClientID
			 AND DTSNo = vblDTSNo;

	IF  NVL(vblLastStatus, 'C') <> vblStatus THEN
		INSERT INTO ztbl_DTS_Mast_Hist (ClientID, DTSNo, Status, UserID, ModifiedOn, Remarks)
			VALUES (vblClientID, vblDTSNo,vblStatus,vblUserID,vblModifiedOn,vblRemarks);

	END IF;
END SP_UPDATEDTSSTATUS;
/



CREATE OR REPLACE PROCEDURE SP_DTS_HISTORY
(
	vblCLIENTID IN VARCHAR2,
	vblDTSNO IN NUMBER,
	vblSETNO IN NUMBER,
	vblCATEGORY IN VARCHAR2,
	vblKEYFIELD IN VARCHAR2,
	vblVERSION IN VARCHAR2,
	vblSRCFLDTXT IN VARCHAR2,
	vblMAPRLETXT IN VARCHAR2,
	vblUPDATEDBY IN VARCHAR2
)
AS
vblCount NUMBER(10);
BEGIN
	SELECT COUNT(*) INTO vblCount FROM ZTBL_DTS_HISTORY WHERE
		CLIENTID = vblCLIENTID AND DTSNO = vblDTSNO AND SETNO = vblSETNO AND
		CATEGORY = vblCATEGORY AND KEYFIELD = vblKEYFIELD AND VERSION = vblVERSION AND
		SRCFLDTXT = vblSRCFLDTXT AND MAPRLETXT = vblMAPRLETXT;

	IF vblCount = 0 THEN
		INSERT INTO ZTBL_DTS_HISTORY
		(
			CLIENTID,
			DTSNO,
			SETNO,
			CATEGORY,
			KEYFIELD,
			VERSION,
			HISTDATE,
			SRCFLDTXT,
			MAPRLETXT,
			UPDATEDBY
		)	
		SELECT
			vblCLIENTID,
			vblDTSNO,
			vblSETNO,
			vblCATEGORY,
			vblKEYFIELD,
			vblVERSION,
			SYSDATE,
			vblSRCFLDTXT,
			vblMAPRLETXT,
			vblUPDATEDBY
		FROM 
			DUAL;
	END IF;
END;
/
