/*


  RALLY#       : US10688
  PURPOSE      : DDL script to create lookup tables 
  CREATED BY   : Washim Khan
  CREATED DATE : 28th May 2014
  REVIEWED BY  :
  SCHEMA       : HAWKEYEMASTER5
  SERVER       : RAC


*/
ALTER TABLE M_CLIENTPARAMS DROP CONSTRAINT COMPOSIT_FK ;
DROP TABLE M_PARAM_VALUES;
DROP TABLE M_PARAM_PROPS;
create table M_PARAM_PROPS
(
        PARAMID             VARCHAR2(20) ,
        PARAM_NAME          varchar2(50) ,
        TABLE_TYPE          varchar2(30) ,
        IS_ACTIVE           varchar2(3)  ,
        PARAM_DESC          varchar2(500) ,
		 CONSTRAINT paramid_pk PRIMARY KEY (PARAMID)
  
);

create table M_PARAM_VALUES
(
      PARAMID    VARCHAR2(20) ,
      PARAM_VALUE Varchar2(100) ,
      CONSTRAINT composit_pk primary key ( paramid , param_value) ,
	  CONSTRAINT paramid_fk FOREIGN KEY (PARAMID)    
      references M_PARAM_PROPS(PARAMID)
      on delete cascade
    
);


/*

Verification script :

  select count(1) from all_tables where owner = 'HAWKEYEMASTER5' and table_name = 'M_PARAM_PROPS';
 Expected Result :
  
   count 
   -----
     1 
  select count(1) from all_tables where owner = 'HAWKEYEMASTER5' and table_name = 'M_PARAM_VALUES';
Expected Result :
  
   count 
   -----
     1	
*/