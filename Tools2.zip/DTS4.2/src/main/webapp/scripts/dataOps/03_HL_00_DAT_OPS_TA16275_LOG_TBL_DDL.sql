
/*


  RALLY#       : US10239
  PURPOSE      : DDL script for DATAOPS_LOG table.
  CREATED BY   : Washim Khan
  CREATED DATE : 
  REVIEWED BY  :
  SCHEMA       : HELOG
  SERVER       : RAC


*/

DROP TABLE DATAOPS_LOG;
CREATE TABLE DATAOPS_LOG 
   (  CLIENTID varchar2(30 byte), 
	  USERID VARCHAR2(30 BYTE), 
      APPID varchar2(30 byte), 
      PARAMETERNAME varchar2(50) ,
      NEWVALUE VARCHAR2(100), 
      OLDVALUE varchar2(100), 
      ACTIONDATE date, 
      ACTIONDESC VARCHAR2(100 BYTE), 
      TABLE_TYPE varchar2(30 byte),
	  TRANSACTION_ID number
   );

/*

Verification script :

  select count(1) from all_tables where owner = 'HELOG' and table_name = 'DATAOPS_LOG';
  
Expected Result :
  
   count 
   -----
     1

	
*/