
/*


  RALLY#       : US11697
  PURPOSE      : DDL script for Email logging table.
  CREATED BY   : Washim Khan
  CREATED DATE : 28th May 2014
  REVIEWED BY  :
  SCHEMA       : HELOG
  SERVER       : RAC


*/

DROP TABLE EMAIL_LOG;
create table EMAIL_LOG (
TRANSACTION_ID    number         ,                                                                                                                                                                      
SEND_TO           varchar2(500)  ,                                                                                                                                                                     
SEND_FROM         VARCHAR2(50)   ,                                                                                                                                                                     
SUBJECT           varchar2(100)  ,                                                                                                                                                                     
MESSAGE           varchar2(500)  ,                                                                                                                                                                     
SEND_STATUS       varchar2(50)   ,                                                                                                                                                                     
LOG_DATE          date
);

/*

Verification script :

  select count(1) from all_tables where owner = 'HELOG' and table_name = 'EMAIL_LOG';
  
Expected Result :
  
   count 
   -----
     1

	
*/