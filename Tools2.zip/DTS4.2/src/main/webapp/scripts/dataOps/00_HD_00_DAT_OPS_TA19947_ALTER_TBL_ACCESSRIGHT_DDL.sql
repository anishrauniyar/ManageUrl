
/*


  RALLY#       : US12416
  PURPOSE      : Added column  ALLOWQCAPPROVE
  CREATED BY   : Washim Khan
  CREATED DATE : 16th July 2014
  REVIEWED BY  :
  SCHEMA       : HAWKEYEDTS
  SERVER       : RAC


*/

Alter table ZTBL_DTS_ACCESSRIGHTS add 
(
ALLOWQCAPPROVE VARCHAR2(1) DEFAULT ('N') NULL
);


/*

 Verification Script :-
 
   select count(1) from all_tab_cols where owner = 'HAWKEYEDTS' and table_name = 'ZTBL_DTS_ACCESSRIGHTS' and column_name = 'ALLOWQCAPPROVE';
   
   Expected Result :
   
    Count(1)
	--------
	   1
	
*/
   