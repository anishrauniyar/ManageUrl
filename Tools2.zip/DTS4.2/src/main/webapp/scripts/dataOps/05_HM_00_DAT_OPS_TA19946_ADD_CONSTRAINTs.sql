/*


  RALLY#       : US12416
  PURPOSE      : Add Unique constraint on M_Param_Props table and Drop Foreign Key constraint from M_Client_Params
  CREATED BY   : Washim Khan
  CREATED DATE : 17th July 2014
  REVIEWED BY  :
  Modified BY  : Chandra K. Gauro
  PURPOSE      : Added HAWKEYEMASTER5 in query.
  SCHEMA       : HAWKEYEMASTER5
  SERVER       : RAC


*/

DECLARE 
  num_rows integer;
BEGIN
   SELECT count(*)
      INTO num_rows
   FROM all_constraints
   WHERE constraint_name = 'COMPOSIT_FK' and owner='HAWKEYEMASTER5';

   IF num_rows > 0 THEN 
       EXECUTE IMMEDIATE 'ALTER TABLE HAWKEYEMASTER5.M_CLIENTPARAMS DROP CONSTRAINT COMPOSIT_FK';
   END IF;
END;
/


/*ALTER TABLE M_CLIENTPARAMS ADD CONSTRAINT COMPOSIT_FK FOREIGN KEY (PARAMID ,PARAMVAL) REFERENCES M_PARAM_VALUES(PARAMID , PARAM_VALUE);*/

DECLARE 
  num_rows integer;
BEGIN
   SELECT count(*)
      INTO num_rows
   FROM all_constraints
   WHERE constraint_name = 'PARAMNAME_UK'  and owner='HAWKEYEMASTER5' ;

   IF num_rows = 0 THEN 
       EXECUTE IMMEDIATE 'ALTER TABLE HAWKEYEMASTER5.M_PARAM_PROPS ADD CONSTRAINT PARAMNAME_UK UNIQUE (PARAM_NAME)';
   END IF;
END;
/

/*
Verification Script

select count(0) from all_constraints where constraint_name = 'COMPOSIT_FK' and owner = 'HAWKEYEMASTER5';

select count(1) from all_constraints where constraint_name = 'PARAMNAME_UK' and owner = 'HAWKEYEMASTER5';


*/