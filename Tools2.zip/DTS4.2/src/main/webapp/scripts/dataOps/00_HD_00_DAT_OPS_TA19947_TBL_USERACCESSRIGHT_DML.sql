/*


  RALLY#       : US12416
  PURPOSE      : Insert data for dataops users
  CREATED BY   : Washim Khan
  CREATED DATE : 16th July 2014
  REVIEWED BY  :
  SCHEMA       : HAWKEYEDTS
  SERVER       : RAC


*/

INSERT INTO ZTBL_DTS_ACCESSGROUPS(ACCESSGROUP,GROUPDESC) VALUES ('DOP','DataOps Users');
COMMIT;

/*

Verification Script :-

  select count(1) from ZTBL_DTS_ACCESSGROUPS where ACCESSGROUP = 'DOP' and GROUPDESC = 'DataOps Users';
  
  Expected Result :
  
   count 
   -----
     1
	 
	 
*/