--Selecting the table structure.
select * from ZTBL_DTS_MAPPING_MAST        ;
select * from ZTBL_DTS_MAPPING_RULE        ;
select * from ZTBL_DTS_MAPPING_SOURCE      ;
select * from ZTBL_DTS_MAPPING_TARGET ;
select * from ZTBL_DTS_TEMPLATE_DEFS ;
SELECT * FROM ZTBL_DTS_CLIENT_KEYFIELDS;
select * from ZTBL_DTS_CLIENT_TEMPLATES       ;
select * from ZTBL_DTS_TEMPLATES     ;

--Taking backup of the tables
create table ZTBL_DTS_MAPPING_MAST_Feb13       as select * from ZTBL_DTS_MAPPING_MAST       ;
create table ZTBL_DTS_MAPPING_RULE_Feb13       as select * from ZTBL_DTS_MAPPING_RULE       ;
create table ZTBL_DTS_MAPPING_SOURCE_Feb13     as select * from ZTBL_DTS_MAPPING_SOURCE     ;
create table ZTBL_DTS_MAPPING_TARGET_Feb13     as select * from ZTBL_DTS_MAPPING_TARGET     ;
create table ZTBL_DTS_TEMPLATE_DEFS_Feb13      as select * from ZTBL_DTS_TEMPLATE_DEFS      ;
create table ZTBL_DTS_CLIENT_KEYFLDS_Feb13 as select * from  ZTBL_DTS_CLIENT_KEYFIELDS           ;
create table ZTBL_DTS_CLIENT_TEMPL_Feb13     as select * from ZTBL_DTS_CLIENT_TEMPLATES       ;
create table ZTBL_DTS_TEMPLATES_Feb13          as select * from ZTBL_DTS_TEMPLATES      ;

--Taking data from updated latest values from excel provided by Ops team

--Insert data from excel provided by Ops team
--Use DataProvidedByOps.SQL file for data for data.

--Update with field used by DTS to make compability
merge INTO hawkeyedts.ztbl_DTS_NewMappingDetails a
USING(SELECT DISTINCT b.Category,b.tableName, b.keyfield,b.FieldName FROM ztbl_dts_mapping_target b
,
ztbl_DTS_NewMappingDetails a
where Upper(a.Category) = Upper(b.tableName) AND
Upper(a.keyfield)=Upper(b.FieldName)
and b.version =2) b
ON (Upper(a.Category) = Upper(b.tableName) AND
Upper(a.keyfield)=Upper(b.FieldName))
WHEN matched THEN UPDATE
SET
a.NewCategory=Upper(b.Category), a.NewKeyField=Upper(b.keyfield);

COMMIT;
--Updating missing fields that are not in existing dts
UPDATE HAWKEYEDTS.ZTBL_DTS_NEWMAPPINGDETAILS SET  NEWCATEGORY=Category,   NEWKEYFIELD=KeyField WHERE NewKeyField IS NULL;

COMMIT;
-----------------------------------------------------Main Patch starts-------------------------------
--Cleaning old versions 1.0
--Delete unnecessary version record e.g. 1.0
delete from ZTBL_DTS_MAPPING_TARGET  where version LIKE '%1%';
delete from ZTBL_DTS_MAPPING_MAST    where version LIKE '%1%';
delete from ZTBL_DTS_DTS_MAST        where version LIKE '%1%';
--Line Pos Text
--142      Delete - 190 row(s), executed in 0 sec.
--143      Delete - 216 row(s), executed in 0.016 sec.
--144      Delete - 1 row(s), executed in 0 sec.
--         Total execution time 0.016 sec.
----------------Version updated----------
--Creating template for CDF
--Update existing template to make derived template
UPDATE
--SELECT * from
ZTBL_DTS_TEMPLATES
SET templatetype='D';
--------------------Creating new template for CDF
--delete from ZTBL_DTS_TEMPLATES where templateid='542';
INSERT INTO ZTBL_DTS_TEMPLATES
SELECT
        sq_templates.NEXTVAL templateid,--Automatically udpated so need to see templateid after insert
        'DefaultTemplateNew' templatename,
        'Default template to include all clients for CDF and HP' templatedesc,
        '2.0' templateversion,
        'P' templatetype
FROM dual;

--SELECT templateid FROM ZTBL_DTS_TEMPLATES WHERE templatename='DefaultTemplateNew';
--------------------Inserting all the keyfields of excel into newly created template
INSERT INTO ZTBL_DTS_TEMPLATE_DEFS(templateid, category, keyfield)
SELECT (SELECT TemplateID FROM ZTBL_DTS_TEMPLATES WHERE templatename='DefaultTemplateNew' AND ROWNUM<2) AS templateid, Newcategory, Newkeyfield  FROM ztbl_DTS_NewMappingDetails

ORDER BY 2;
--Insert - 747 row(s), executed in 0 sec.
--Finding remaining fields from other template clientwise and inserting them into Client Specific table
--Please use same templateName as found in ZTBL_DTS_TEMPLATES for CDF
INSERT INTO ztbl_dts_client_keyfields( clientid, category, keyfield)
SELECT  distinct
        a.ClientID,
        a.Category,
        a.KeyField
FROM
        ztbl_dts_mapping_source a
WHERE NOT EXISTS
(SELECT 1 FROM ZTBL_DTS_TEMPLATE_DEFS b WHERE b.TemplateID in (SELECT templateid FROM ZTBL_DTS_TEMPLATES WHERE templatename='DefaultTemplateNew') AND a.Category= b.Category AND a.KeyField = b.KeyField)
AND NOT EXISTS
(SELECT 1 FROM ztbl_dts_client_keyfields f  WHERE a.Category= f.Category AND a.KeyField = f.KeyField AND a.ClientID = f.ClientID)
ORDER BY 1,2;
--Insert - 503 row(s), executed in 0.046 sec.


---Inserting remaining values into keyfield table for remaining  due to only mapped on rules
INSERT INTO ztbl_dts_client_keyfields( clientid, category, keyfield)
SELECT * FROM(
SELECT ClientID,category, keyfield FROM  ztbl_dts_mapping_source
UNION
SELECT ClientID,category, keyfield FROM  ztbl_dts_mapping_rule)a
WHERE NOT exists
(SELECT 1 from ztbl_dts_client_keyfields b WHERE a.ClientID = b.ClientID AND a.CATEGORY =b.Category  AND a.KeyField =b.KeyField)
AND NOT exists
(SELECT 1 from ZTBL_DTS_TEMPLATE_DEFS c WHERE c.TemplateID in(SELECT templateid FROM ZTBL_DTS_TEMPLATES WHERE templatename='DefaultTemplateNew') AND a.CATEGORY =c.Category  AND a.KeyField =c.KeyField)

;
--Insert - 298 row(s), executed in 0.109 sec.
--INSERTING missing field FROM template INTO client specific FOR cdf
INSERT INTO ztbl_dts_client_keyfields( clientid, category, keyfield)
SELECT t.ClientID, a.Category,a.KeyField FROM ztbl_dts_client_templates t inner join
(SELECT DISTINCT templateid,Category,KeyField FROM ZTBL_DTS_TEMPLATE_DEFS a

WHERE a.TemplateID not in(SELECT templateid FROM ZTBL_DTS_TEMPLATES WHERE templatename='DefaultTemplateNew') AND NOT EXISTS
(SELECT * FROM ZTBL_DTS_TEMPLATE_DEFS b WHERE b.TemplateID in(SELECT templateid FROM ZTBL_DTS_TEMPLATES WHERE templatename='DefaultTemplateNew') AND a.category =b.category AND a.keyfield= b.keyfield)
 AND a.KeyField IS NOT NULL) a
ON t.templateId=a.TemplateID
WHERE NOT EXISTS
(SELECT 1 from ztbl_dts_client_keyfields b WHERE t.ClientID = b.ClientID AND a.CATEGORY =b.Category  AND a.KeyField =b.KeyField)
and t.ClientID<>'000'
ORDER BY 1,2,3;
--Insert - 1504 row(s), executed in 0.031 sec.
--Assigning the new template to all CDF clients
--UPDATE ztbl_dts_client_templates SET TemplateID ='542' WHERE ClientID IN(
--SELECT ClientID FROM ZTBL_DTS_MAPPING_SOURCE);
----Update - 42 row(s), executed in 0.078 sec.

----------------Creating only one template completed-------------------
COMMIT;

--ztbl_DTS_ClientView
--In case of recovery
Deleting datas (Be careful)
drop table ZTBL_DTS_MAPPING_MAST        ;
drop table ZTBL_DTS_MAPPING_RULE        ;
drop table ZTBL_DTS_MAPPING_SOURCE      ;
drop table ZTBL_DTS_MAPPING_TARGET      ;
drop table ZTBL_DTS_TEMPLATE_DEFS       ;
DROP TABLE ZTBL_DTS_CLIENT_TEMPLATES;
DROP TABLE ZTBL_DTS_TEMPLATES;
drop table ZTBL_DTS_CLIENT_KEYFIELDS;

--Recovering data only if needed
create table  ZTBL_DTS_MAPPING_MAST          as select * from ZTBL_DTS_MAPPING_MAST_Feb13   ;
create table  ZTBL_DTS_MAPPING_RULE          as select * from ZTBL_DTS_MAPPING_RULE_Feb13   ;
create table  ZTBL_DTS_MAPPING_SOURCE        as select * from ZTBL_DTS_MAPPING_SOURCE_Feb13 ;
create table  ZTBL_DTS_MAPPING_TARGET        as select * from ZTBL_DTS_MAPPING_TARGET_Feb13 ;
create table  ZTBL_DTS_TEMPLATE_DEFS         as select * from ZTBL_DTS_TEMPLATE_DEFS_Feb13  ;
create table  ZTBL_DTS_CLIENT_KEYFIELDS      as select * from ztbl_dts_client_keyflds_Feb13   ;
create table  ZTBL_DTS_CLIENT_TEMPLATES      as select * from ZTBL_DTS_CLIENT_TEMPL_Feb13;
create table  ZTBL_DTS_TEMPLATES              as select * from ZTBL_DTS_TEMPLATES_Feb13  ;
