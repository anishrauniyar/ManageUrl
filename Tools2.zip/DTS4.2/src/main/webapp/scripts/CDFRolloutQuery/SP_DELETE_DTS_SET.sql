create or replace PROCEDURE              "SP_DELETE_DTS_SET" (
	var_ClientID IN VARCHAR2,
	var_DTSNo in NUMBER,
	var_SetNo in NUMBER,
	var_UserID in VARCHAR2,
	var_Category in VARCHAR2,
	var_Remarks in VARCHAR2   --Changed text to remarks
  )

       --Begin of procedure
	AS

  var_NEWSETNO NUMBER;
  var_count NUMBER;
  BEGIN
	-- get the maximun new set no


  SELECT nvl(MAX(SETNO),0)+1 into var_NewSetNo FROM ZTBL_DTS_DTS_SET_ARCHIVE WHERE CLIENTID=var_ClientID AND DTSNO=var_DTSNo AND CATEGORY=var_Category;

  -- 'A' for archive
	-- 'O' for open

	IF (trim(var_Category) IS NOT NULL ) THEN

  BEGIN  --Begin of If var_category.....

       SELECT count(*) into var_count FROM ztbl_DTS_DTS_Set WHERE ClientID=var_ClientID AND DTSNo=var_DTSNo AND SetNo=var_SetNo;

	     IF var_count >0 THEN

              BEGIN  --Begin of if var_count > 0

			        -- insert the data in archive along with the all the required data.

		          INSERT INTO ztbl_DTS_DTS_Set_Archive
              SELECT
              var_ClientID,var_DTSNo,var_NewSetNo,var_SetNo,var_Category,var_UserID,sysdate,var_Remarks,'O'
              from dual;

              INSERT INTO ztbl_DTS_Mapping_Rule_Archive
               SELECT
                 ClientID,DTSNo,var_NewSetNo,Category,KeyField,Version,BusinessRule,Example,TranslatedRule
			         FROM ztbl_DTS_Mapping_Rule WHERE ClientID=var_ClientID AND DTSNo=var_DTSNo AND SetNo=var_SetNo AND Category=var_Category;

		          INSERT INTO ztbl_DTS_Mapping_Src_Archive -- used for ztbl_DTS_Mapping_Source_Archive
              SELECT
                 ClientID,DTSNo,var_NewSetNo,Category,KeyField,Version,TableName,FieldName,FieldFormat,DatabaseID
			        FROM ztbl_DTS_Mapping_Source WHERE ClientID=var_ClientID AND DTSNo=var_DTSNo AND SetNo=var_SetNo AND Category=var_Category;

		          INSERT INTO ztbl_DTS_Mapping_HL_Archive
              SELECT
                 ClientID,DTSNo,Category,KeyField,Version,Priority,var_NewSetNo
			         FROM ztbl_DTS_Mapping_Highlights WHERE ClientID=var_ClientID AND DTSNo=var_DTSNo AND SetNo=var_SetNo AND Category=var_Category;
              
              INSERT INTO ZTBL_DTS_SRCTBL_CONF_ARCHIVE
              select clientid,dtsno,category,setname,tablename,userid,'SetName > '||setname||' deleted.' Remarks, var_UserID modifiedBy from ZTBL_DTS_SOURCETABLE_CONFIG a where clientID=var_ClientID and  DTSNo=var_DTSNo  AND  Category=var_Category 
                and SetName in (select distinct setname from ZTBL_DTS_SETNAMES 
                where category like a.Category and clientid=a.clientid and dtsno=a.dtsNo and setNo = var_SetNo);



		          --delete data from the non-archive table once the data have been copied to archive
		          delete from ztbl_DTS_Mapping_Rule where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo=var_SetNo AND Category=var_Category;
		          delete from ztbl_DTS_Mapping_Highlights where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo=var_SetNo AND Category=var_Category;
		          delete from ztbl_DTS_Mapping_Source where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo=var_SetNo AND Category=var_Category;
              delete from ZTBL_DTS_BUCKET_DETAILS where category like var_Category and 
                bucketid in ( select BUCKETID from  ZTBL_DTS_BUCKET where clientid=var_ClientID and DTSNo=var_DTSNo 
                        ) and setname like ( select setname from ztbl_dts_setnames 
                        where clientid=var_ClientID and DTSNo=var_DTSNo and category=var_Category and setno=var_SetNo );
             
              delete from ZTBL_DTS_SOURCETABLE_CONFIG a where clientID=var_ClientID and  DTSNo=var_DTSNo  AND  Category=var_Category 
                and SetName in (select distinct setname from ZTBL_DTS_SETNAMES 
                where category like a.Category and clientid=a.clientid and dtsno=a.dtsNo and setNo = var_SetNo);
                    
              delete from ZTBL_DTS_SETNAMES where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo=var_SetNo AND Category=var_Category;
              

		          --reduce the set no as there is some constraints that do not allow to delete that corresponding set from the ztbl_DTS_DTS_Set table
		          update ztbl_DTS_Mapping_Rule set SetNo=(SetNo-1) where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo>var_SetNo AND Category=var_Category;
		          update ztbl_DTS_Mapping_Highlights set SetNo=(SetNo-1) where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo>var_SetNo AND Category=var_Category;
		          update ztbl_DTS_Mapping_Source set SetNo=(SetNo-1) where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo>var_SetNo AND Category=var_Category;
              update ZTBL_DTS_SETNAMES set SetNo=(SetNo-1) where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo>var_SetNo AND Category=var_Category;

		          --finally delete the set from ztbl_DTS_DTS_Set if there is no any category in that set


              SELECT COUNT (*) into var_count
              FROM ztbl_DTS_DTS_Set a
				          INNER JOIN (SELECT c.ClientID, c.DTSNo, c.SetNo, c.Category  FROM ztbl_DTS_Mapping_Source c
					          UNION ALL SELECT d.ClientID, d.DTSNo, d.SetNo, d.Category FROM ztbl_DTS_Mapping_Rule d ) b
					          ON a.ClientID=b.ClientID AND a.DTSNo=b.DTSNo AND a.SetNo=b.SetNo WHERE b.DTSNo=var_DTSNo
					          AND b.ClientID=var_ClientID AND b.Category in (SELECT Category FROM ztbl_DTS_Categories)
					          AND a.SetNo=(SELECT MAX(SetNo) from ztbl_DTS_DTS_Set where clientID=var_ClientID and DTSNo=var_DTSNo);



                if var_count = 0 then
			          delete from ztbl_DTS_DTS_Set  where clientID=var_ClientID and DTSNo=var_DTSNo and SetNo=(SELECT MAX(SetNo) from ztbl_DTS_DTS_Set where clientID=var_ClientID and DTSNo=var_DTSNo);
                END IF ;


                END;  --End of if var_count > 0
                END IF;
                --If there is no error then commit.
                COMMIT;


          EXCEPTION
            WHEN Others THEN
              begin

              ROLLBACK;
              end;
	        END; --End of If var_category.....
       END IF;
END; -- End of procedure
 