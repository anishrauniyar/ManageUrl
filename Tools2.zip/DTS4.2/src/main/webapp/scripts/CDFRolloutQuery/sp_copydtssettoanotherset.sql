create or replace PROCEDURE sp_copydtssettoanotherset (
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblSourceDTSNo 	IN VARCHAR2  DEFAULT NULL,
vblSourceCategory 	IN VARCHAR2  DEFAULT NULL,
vblSourceSets 	IN VARCHAR2  DEFAULT NULL,
vblDestClient 	IN VARCHAR2  DEFAULT NULL,
vblDestDTSno 	IN VARCHAR2  DEFAULT NULL
)
AS
vblDestName 	VARCHAR2(100);
vblDatabaseID 	VARCHAR2(10);
vblDestSetNo NUMBER;
vblVersion 	VARCHAR2(10);
strSQL 	VARCHAR2(8000);
vblSrcSetName 	VARCHAR2(100);
vblDestSetName 	VARCHAR2(100);


BEGIN

  select  setname into vblSrcSetName from ZTBL_DTS_SETNAMES
   WHERE ClientID =  vblSourceClient  AND DTSno= vblSourceDTSNo  AND Category = vblSourceCategory  AND SetNo =vblSourceSets;

  select  setname||'_'||to_char(sysdate,'ssdmihhmmddyyyy') into vblDestSetName from ZTBL_DTS_SETNAMES
   WHERE ClientID =  vblSourceClient  AND DTSno= vblSourceDTSNo  AND Category = vblSourceCategory  AND SetNo =vblSourceSets;

	FOR rec IN ( SELECT   ClientName FROM ztbl_DTS_Clients WHERE ClientID = vblDestClient)

	LOOP
	   vblDestName := rec.ClientName ;

	END LOOP;

  SELECT NVL(MAX(a.SetNo)+1,1) INTO vblDestSetNo FROM ztbl_DTS_DTS_Set a
                 INNER JOIN
                 (SELECT c.ClientID, c.DTSNo, c.SetNo, c.Category
                 FROM ztbl_DTS_Mapping_Source c UNION ALL
                 SELECT d.ClientID, d.DTSNo, d.SetNo, d.Category FROM ztbl_DTS_Mapping_Rule d
                 ) b
                 ON a.ClientID=b.ClientID AND a.DTSNo=b.DTSNo AND a.SetNo=b.SetNo
                 WHERE b.DTSNo= vblDestDTSno   AND b.ClientID=vblDestClient
                 AND b.Category='' || vblSourceCategory || '';

	SELECT MAX(DatabaseID) INTO vblDatabaseID
	 FROM ztbl_DTS_Databases WHERE ClientID = vblDestClient;

strSQL:='INSERT INTO ztbl_DTS_SourceTableSpace (ClientID, DTSNo, TableName, FieldName, FieldFormat,DatabaseID)
		SELECT  '''||vblDestClient||''' ClientID, '||vblDestDTSno||' DTSNo, TableName,
		FieldName, FieldFormat,'||vblDatabaseID||' DatabaseID
		 FROM ztbl_DTS_SourceTableSpace sts
				WHERE sts.ClientID = ''' || vblSourceClient || '''
				 AND sts.DTSNo = ' || vblSourceDTSNo || '                                 
              minus
                SELECT  ClientID, DTSNo, TableName,
		FieldName, FieldFormat,DatabaseID
		 FROM ztbl_DTS_SourceTableSpace sts
				WHERE sts.ClientID = '''||vblDestClient||'''
				 AND sts.DTSNo = '||vblDestDTSno||'';
   EXEC_SQL (strSQL);
   strSQL:='INSERT INTO ztbl_DTS_DTS_Set (ClientID,DTSNo,SetNo) VALUES ('''||vblDestClient||''','||vblDestDTSno||','||vblDestSetNo||')';
   EXEC_SQL (strSQL);

   strSQL:='INSERT INTO ZTBL_DTS_SETNAMES (ClientID, DTSNo, SetNo, CATEGORY, SETNAME)
		SELECT  '''|| vblDestClient ||'''	as ClientID, ' || vblDestDTSNo || '		as DTSNo, ' || vblDestSetNo || '		as SetNo,
    CATEGORY, '''||vblDestSetName||'''    setname
		 FROM ZTBL_DTS_SETNAMES
				WHERE ClientID = ''' || vblSourceClient || ''' AND DTSno= ' || vblSourceDTSNo || ' AND Category = ''' || vblSourceCategory || ''' AND SetNo IN (' || vblSourceSets || ')';
  EXEC_SQL (strSQL);

  
   strSQL:=' insert into  ztbl_dts_sourcetable_config

   select '''||vblDestClient||''' CLIENTID,'|| vblDestDTSNo ||'  DTSNO,CATEGORY,  '''||vblDestSetName||'''    setname
    , TABLENAME,  USERID
		from ztbl_dts_sourcetable_config
				WHERE ClientID = ''' || vblSourceClient || ''' AND DTSno= ' || vblSourceDTSNo || ' AND Category = ''' || vblSourceCategory || ''' AND SetName like '''|| vblSrcSetName || '''';

  EXEC_SQL (strSQL);





	FOR rec IN ( SELECT   Version  FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblSourceClient
									 and DTSNo = vblSourceDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;
	strSQL := 'insert into ztbl_DTS_Mapping_Highlights
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	Priority
)
select
	''' || vblDestClient || '''	as ClientID,
	' || vblDestDTSNo || '		as DTSNo,
	' || vblDestSetNo || '		as SetNo,
	Category,
	KeyField,
	Version,
	Priority
from ztbl_DTS_Mapping_Highlights hi
where hi.ClientID = ''' || vblSourceClient || ''' AND DTSno = ' || vblSourceDTSNo || ' AND Category = ''' || vblSourceCategory || ''' 
AND SetNo IN (' || vblSourceSets || ')
AND hi.keyfield in (
    SELECT keyfield FROM ZTBL_DTS_TEMPLATE_DEFS tpldef   inner join ZTBL_DTS_TEMPLATES tpl on
    tpl.templateid=tpldef.templateid
    and  tpl.templatetype=''P''
    and tpldef.category= ''' || vblSourceCategory || '''
    )';

EXEC_SQL (strSQL);

	strSQL := 'insert into ztbl_DTS_Mapping_Rule
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	BusinessRule,
	Example,
	TranslatedRule
)
select
	''' || vblDestClient || ''' as ClientID,
	' || vblDestDTSNo || ' AS DTSNo,
	' || vblDestSetNo || '		as SetNo,
	Category,
	KeyField,
	Version,
	BusinessRule,
	Example,
	TranslatedRule
from ztbl_DTS_Mapping_Rule mr where ClientID = ''' || vblSourceClient || ''' AND DTSno= ' || vblSourceDTSNo || ' 
AND Category = ''' || vblSourceCategory || ''' AND SetNo IN (' || vblSourceSets || ')
AND mr.keyfield in (
    SELECT keyfield FROM ZTBL_DTS_TEMPLATE_DEFS tpldef   inner join ZTBL_DTS_TEMPLATES tpl on
    tpl.templateid=tpldef.templateid
    and  tpl.templatetype=''P''
    and tpldef.category= ''' || vblSourceCategory || '''
    )';


	EXEC_SQL (strSQL);

 /*[SPCONV-ERR(87)]:(LIKE) if using '[' Manual conversion required*/

	IF  vblSourceCategory LIKE '%general%' THEN
	BEGIN
		strSQL := 'update	ztbl_DTS_Mapping_Rule
set	BusinessRule = ''' || vblDestClient || ''',
	TranslatedRule = ''' || vblDestClient || ''' where	Category like ''%general%''
	and KeyField=''ClientID''
	and ClientID=''' || vblDestClient || ''' and DTSNo=' || vblDestDTSNo || ' and Version=''' || vblVersion || ''' and SetNo IN (' || vblDestSetNo || ')';
  --dbms_output.put_line(strSQL);

		EXEC_SQL (strSQL);

		strSQL := 'update	ztbl_DTS_Mapping_Rule
set	BusinessRule = ''' || vblDestName || ''',
	TranslatedRule = ''' || vblDestName || ''' where	Category like ''%general%''
	and KeyField=''ClientName''
	and ClientID=''' || vblDestClient || ''' and DTSNo=' || vblDestDTSNo || ' and Version=''' || vblVersion || ''' and SetNo IN (' || vblDestSetNo || ')';

		EXEC_SQL (strSQL);

	END;
	END IF;
	strSQL := 'insert into ztbl_DTS_Mapping_Source
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	TableName,
	FieldName,
	FieldFormat,
	DatabaseID
)
SELECT
	''' || vblDestClient || ''' as ClientID,
	' || vblDestDTSNo || ' AS DTSNo,
	' || vblDestSetNo || '		as SetNo,
	Category,
	KeyField,
	Version,
	replace(tablename,''' || vblSourceClient || ''',''' || vblDestClient || ''') Tablename,
	FieldName,
	FieldFormat,
	' || vblDatabaseID || ' as DatabaseID
FROM ztbl_DTS_Mapping_Source ms where ClientID = ''' || vblSourceClient || ''' AND DTSno = ' || vblSourceDTSNo || ' 
AND Category = ''' || vblSourceCategory || ''' AND SetNo IN (' || vblSourceSets || ')
AND ms.keyfield in (
    SELECT keyfield FROM ZTBL_DTS_TEMPLATE_DEFS tpldef   inner join ZTBL_DTS_TEMPLATES tpl on
    tpl.templateid=tpldef.templateid
    and  tpl.templatetype=''P''
    and tpldef.category= ''' || vblSourceCategory || '''
    )';


	EXEC_SQL (strSQL);

END sp_copydtssettoanotherset;