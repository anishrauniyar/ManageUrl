create or replace PROCEDURE              "SP_COPYDTSSELECTEDSETS" (
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL,
vblDestinationClient 	IN VARCHAR2  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
vblSets 	IN VARCHAR2  DEFAULT NULL,
vblUser_ 	IN VARCHAR2  DEFAULT NULL)
AS
vblDestName 	VARCHAR2(100);
vblDestDTSNo 	VARCHAR2(4);
vblDatabaseID 	VARCHAR2(10);
vblVersion 	VARCHAR2(10);
strSQL 	VARCHAR2(8000);
vblsetno NUMBER := 1;
vblTempSetno VARCHAR2(100);


BEGIN
	FOR rec IN ( SELECT   ClientName FROM ztbl_DTS_Clients WHERE ClientID = vblDestinationClient)
	LOOP
	   vblDestName := rec.ClientName ;

	END LOOP;

	SELECT MAX(DTSNo) INTO vblDestDTSNo FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblDestinationClient;

	SELECT MAX(DatabaseID) INTO vblDatabaseID
	 FROM ztbl_DTS_Databases WHERE ClientID = vblDestinationClient;

	FOR rec IN ( SELECT   Version  FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblSourceClient
									 and DTSNo = vblDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;  
        

         
         FOR rec IN ( SELECT   Version  FROM ztbl_DTS_DTS_Mast WHERE ClientID = vblSourceClient
									 and DTSNo = vblDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;           
         
                
        strSQL := 'INSERT INTO ZTBL_DTS_SETNAMES (ClientID, DTSNo, SetNo, CATEGORY, SETNAME)
		SELECT  '''||vblDestinationClient||''' as ClientID, '||vblDestDTSNo||' as DTSNo, SetNo, CATEGORY, SETNAME
		 FROM ZTBL_DTS_SETNAMES 
				WHERE ClientID = '''||vblSourceClient||'''
				 AND DTSno = '||vblDTSno||'
                                 AND CATEGORY = '''||vblCategory||'''
                                 AND Category in (SELECT distinct category FROM ZTBL_DTS_TEMPLATE_DEFS tpldef
                                                   inner join ZTBL_DTS_TEMPLATES tpl on
                                                   tpl.templateid = tpldef.templateid
                                                   and  tpl.templatetype = ''P'')
                                 AND setno in (' ||vblSets|| ')';
        -- dbms_output.put_line(strSQL);
         EXEC_SQL (strSQL);
         commit;
         
         FOR setn IN (select setno from ZTBL_DTS_SETNAMES where clientid=vblDestinationClient and dtsno=vblDestDTSNo
                                and category=vblCategory order by setno)                                
   LOOP
   vblTempSetno := setn.setno;
             strSQL := 'Update ZTBL_DTS_SETNAMES set setno='||vblsetno||' where ClientID='''||vblDestinationClient||'''
                  and dtsno='||vblDestDTSNo||' and category='''||vblCategory||''' and setno='||vblTempSetno||'';
                  -- dbms_output.put_line(strSQL);
                   EXEC_SQL (strSQL);
                   vblsetno := vblsetno + 1;
   END LOOP;       
    commit;
    

              
       strSQL := 'INSERT INTO ztbl_dts_sourcetable_config (ClientID, DTSNo, CATEGORY, setname, TABLENAME,USERID)
		SELECT  '''||vblDestinationClient||''' as ClientID, '||vblDestDTSNo||' as DTSNo, CATEGORY, SETNAME, Tablename,'''||vblUser_||''' as userid
		 FROM ztbl_dts_sourcetable_config 
				WHERE ClientID = '''||vblSourceClient||'''
				 AND DTSno = '||vblDTSno||'
                                 AND Category= '''||vblCategory||'''
                                 AND Category in (SELECT distinct category FROM ZTBL_DTS_TEMPLATE_DEFS tpldef
                                                   inner join ZTBL_DTS_TEMPLATES tpl on
                                                   tpl.templateid = tpldef.templateid
                                                   and  tpl.templatetype = ''P'')
                                 AND setname in (select setname from ZTBL_DTS_SETNAMES where ClientID = '''||vblSourceClient||'''
				 AND DTSno = '||vblDTSno||'
                                 AND Category= '''||vblCategory||''' AND setno in (' || vblSets || '))';
        -- dbms_output.put_line(strSQL);
         EXEC_SQL (strSQL);
        commit;
        
	strSQL := 'insert into ztbl_DTS_Mapping_Highlights
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	Priority
)
SELECT ''' || vblDestinationClient || '''	as ClientID, ' || vblDestDTSNo || '		as DTSNo,SetNo,Category,
 KeyField,Version,Priority FROM ztbl_DTS_Mapping_Highlights hi
 WHERE hi.clientid=''' || vblSourceClient || ''' and dtsno=' || vblDTSno || ' AND Category = ''' || vblCategory || ''' and setno in (' || vblSets || ') 
 and hi.keyfield in(
    SELECT keyfield FROM ZTBL_DTS_TEMPLATE_DEFS tpldef
    inner join ZTBL_DTS_TEMPLATES tpl on
    tpl.templateid = tpldef.templateid
    and  tpl.templatetype = ''P''
    and tpldef.category = ''' || vblCategory || '''
    )';
--dbms_output.put_line(strSQL);
EXEC_SQL (strSQL);
commit;

	strSQL := 'insert into ztbl_DTS_Mapping_Rule
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	BusinessRule,
	Example,
	TranslatedRule
)
select
	''' || vblDestinationClient || ''' as ClientID,
	' || vblDestDTSNo || ' AS DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	BusinessRule,
	Example,
	TranslatedRule
from ztbl_DTS_Mapping_Rule where ClientID = ''' || vblSourceClient || ''' AND DTSno= ' || vblDTSno || ' AND keyfield in(
 SELECT keyfield FROM ZTBL_DTS_TEMPLATE_DEFS tpldef
    inner join ZTBL_DTS_TEMPLATES tpl on
    tpl.templateid=tpldef.templateid
    and  tpl.templatetype=''P''
    and tpldef.category = ''' || vblCategory || '''
 )
 AND Category = ''' || vblCategory || '''
 AND SetNo IN (' || vblSets || ')';
--dbms_output.put_line(strSQL);
  EXEC_SQL (strSQL);

 /*[SPCONV-ERR(87)]:(LIKE) if using '[' Manual conversion required*/

	IF  vblCategory LIKE '%general%' THEN
	BEGIN
		strSQL := 'update	ztbl_DTS_Mapping_Rule
set	BusinessRule = ''' || vblDestinationClient || ''',
	TranslatedRule = ''' || vblDestinationClient || ''' where	Category like ''%general%''
	and KeyField=''ClientID''
	and ClientID=''' || vblDestinationClient || ''' and DTSNo=' || vblDestDTSNo || ' and Version=''' || vblVersion || ''' and SetNo IN (' || vblSets || ')';
		EXEC_SQL (strSQL);

		strSQL := 'update	ztbl_DTS_Mapping_Rule
set	BusinessRule = ''' || vblDestName || ''',
	TranslatedRule = ''' || vblDestName || ''' where	Category like ''%general%''
	and KeyField=''ClientName''
	and ClientID=''' || vblDestinationClient || ''' and DTSNo=' || vblDestDTSNo || ' and Version=''' || vblVersion || ''' and SetNo IN (' || vblSets || ')';
		EXEC_SQL (strSQL);

	END;
	END IF;
	strSQL := 'insert into ztbl_DTS_Mapping_Source
(
	ClientID,
	DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	TableName,
	FieldName,
	FieldFormat,
	DatabaseID
)
SELECT
	''' || vblDestinationClient || ''' as ClientID,
	' || vblDestDTSNo || ' AS DTSNo,
	SetNo,
	Category,
	KeyField,
	Version,
	TableName,
	FieldName,
	FieldFormat,
	' || vblDatabaseID || ' as DatabaseID
FROM ztbl_DTS_Mapping_Source where ClientID = ''' || vblSourceClient || ''' AND DTSno = ' || vblDTSno || ' AND keyfield in (
 SELECT keyfield FROM ZTBL_DTS_TEMPLATE_DEFS tpldef
    inner join ZTBL_DTS_TEMPLATES tpl on
    tpl.templateid=tpldef.templateid
    and  tpl.templatetype=''P''
    and tpldef.category = ''' || vblCategory || '''
)
AND Category = ''' || vblCategory || ''' AND SetNo IN (' || vblSets || ')';
--dbms_output.put_line(strSQL);	
EXEC_SQL (strSQL);

    strSQL := 'delete from  ztbl_dts_dts_set where ClientID='''||vblDestinationClient||''' and dtsno='||vblDestDTSNo||'';
   -- dbms_output.put_line(strSQL);
    EXEC_SQL (strSQL);
    
    strSQL := 'insert into ztbl_dts_dts_set  
    select distinct  clientid, dtsno, setno from ZTBL_DTS_SETNAMES  where ClientID='''||vblDestinationClient||'''
                  and dtsno='||vblDestDTSNo||'';
                 --  dbms_output.put_line(strSQL);
                   EXEC_SQL (strSQL);

END SP_COPYDTSSELECTEDSETS; 