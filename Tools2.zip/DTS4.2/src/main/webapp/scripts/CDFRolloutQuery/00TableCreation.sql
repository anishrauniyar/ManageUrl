--------------additional keyfields table create----------------------------
create table ZTBL_DTS_CLIENT_KEYFIELDS (
CLIENTID VARCHAR2(3),
CATEGORY VARCHAR2(20),
KEYFIELD VARCHAR2(255)
);

----------update Table ZTBL_DTS_TEMPLATES--------------------------------
alter table ZTBL_DTS_TEMPLATES add TEMPLATETYPE CHAR(1);

CREATE TABLE ztbl_dts_srctbl_conf_archive (
  clientid   VARCHAR2(20)  NULL,
  dtsno      NUMBER(10,0)  NULL,
  category   VARCHAR2(100) NULL,
  setname    VARCHAR2(100) NULL,
  tablename  VARCHAR2(255) NULL,
  userid     VARCHAR2(50)  NULL,
  remarks    CHAR(66)      NULL,
  modifiedby VARCHAR2(50)  NULL
);
--Creating table
DROP TABLE ztbl_DTS_NewMappingDetails;
CREATE TABLE ztbl_DTS_NewMappingDetails
(
        Category VARCHAR2(30),
        KeyField VARCHAR2(255),
        FieldFormat VARCHAR2(20),
        NewCategory VARCHAR2(30),
        NewKeyField VARCHAR2(255),
        Remarks VARCHAR2(50)
);
COMMIT;
--Category related operation:
 ALTER TABLE ztbl_dts_clients
  ADD ( clienttype VARCHAR(5) );