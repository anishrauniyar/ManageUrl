CREATE OR REPLACE PROCEDURE sp_managecategory (
vblSN 	IN NUMBER  DEFAULT NULL,
vblCategory 	IN VARCHAR2  DEFAULT NULL,
vblCategoryDesc 	IN VARCHAR2  DEFAULT NULL,
vblOldCategoryName IN VARCHAR2  DEFAULT NULL,
spMode 	IN CHAR  DEFAULT NULL)
AS
newSN 	NUMBER(10,0);
BEGIN
	IF  spMode = 'D' THEN
		DELETE  ztbl_DTS_Categories WHERE SN = vblSN;

	ELSE
		IF  spMode = 'U' THEN
			UPDATE ztbl_DTS_Categories SET 	Category = vblCategory,
				CategoryDesc = vblCategoryDesc	WHERE SN = vblSN;

      update  ZTBL_DTS_BUCKET_DETAILS      set category=vblCategory
      where category=vblOldCategoryName;
        UPDATE  ZTBL_DTS_CATEGORIES          set category=vblCategory
        WHERE category=vblOldCategoryName;
        UPDATE  ZTBL_DTS_CLIENT_KEYFIELDS    set category=vblCategory
        WHERE category=vblOldCategoryName;
        UPDATE  ZTBL_DTS_FILTER_MAPPING      set category=vblCategory
        WHERE category=vblOldCategoryName ;
        UPDATE  ZTBL_DTS_HISTORY             set category=vblCategory
        WHERE category=vblOldCategoryName  ;
        UPDATE  ZTBL_DTS_MAPPING_HIGHLIGHTS  set category=vblCategory
        WHERE category=vblOldCategoryName   ;
        UPDATE  ZTBL_DTS_MAPPING_HIST        set category=vblCategory
        WHERE category=vblOldCategoryName ;
        UPDATE  ZTBL_DTS_MAPPING_MAST        set category=vblCategory
        WHERE category=vblOldCategoryName  ;
        UPDATE  ZTBL_DTS_MAPPING_RULE        set category=vblCategory
        WHERE category=vblOldCategoryName;
        UPDATE  ZTBL_DTS_MAPPING_SOURCE      set category=vblCategory
        WHERE category=vblOldCategoryName ;
        UPDATE  ZTBL_DTS_MAPPING_TARGET      set category=vblCategory
        WHERE category=vblOldCategoryName;
        UPDATE  ZTBL_DTS_NEWMAPPINGDETAILS   set category=vblCategory
        WHERE category=vblOldCategoryName ;
        UPDATE  ZTBL_DTS_SENDTOEXCELFILTER   set category=vblCategory
        WHERE category=vblOldCategoryName ;
        UPDATE  ZTBL_DTS_SETNAMES            set category=vblCategory
        WHERE category=vblOldCategoryName;
        UPDATE  ZTBL_DTS_SOURCETABLE_CONFIG  set category=vblCategory
        WHERE category=vblOldCategoryName ;
        UPDATE  ZTBL_DTS_TEMPLATE_DEFS     	 set category=vblCategory
        WHERE category=vblOldCategoryName;



		ELSE
			IF  spMode = 'I' THEN
			BEGIN

				SELECT MAX(SN) INTO newSN  FROM ztbl_DTS_Categories;

				IF  newSN IS NULL THEN

					newSN :=  0;

				END IF;

				newSN :=  newSN + 1;

				INSERT INTO ztbl_DTS_Categories
					VALUES (newSN, vblCategory, vblCategoryDesc);

			END;
			END IF;
			END IF;
			END IF;
END SP_MANAGECATEGORY;
/

