create or replace PROCEDURE              "SP_REPAIRDTSSETNUMBERS" (
vblClientID 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL)
AS
BEGIN
	DELETE FROM ztbl_DTS_DTS_Set
	WHERE ClientID = vblClientID
	 and DTSno =vblDTSno
	 and SetNo  NOT IN (
		SELECT  a.SetNo
		 FROM (
		SELECT DISTINCT  b.ClientID, b.DTSNo, b.SetNo
		 FROM ztbl_DTS_Mapping_Highlights b
		UNION
		SELECT DISTINCT  c.ClientID, c.DTSNo, c.SetNo
		 FROM ztbl_DTS_Mapping_Source c
		UNION
		SELECT DISTINCT  d.ClientID, d.DTSNo, d.SetNo
		 FROM ztbl_DTS_Mapping_Rule d ) a
	WHERE a.ClientID = ClientID
	 and a.DTSno = DTSno  );

END SP_REPAIRDTSSETNUMBERS;
 
 
 
 