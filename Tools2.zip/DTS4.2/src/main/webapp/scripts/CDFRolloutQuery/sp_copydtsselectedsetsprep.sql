create or replace PROCEDURE              "SP_COPYDTSSELECTEDSETSPREP" (
vblSourceClient 	IN VARCHAR2  DEFAULT NULL,
vblDTSno 	IN VARCHAR2  DEFAULT NULL,
vblDestinationClient 	IN VARCHAR2  DEFAULT NULL,
vblUser_ 	IN VARCHAR2  DEFAULT NULL)
AS
vblDestName 	VARCHAR2(100);
vblDestDTSNo 	VARCHAR2(4);
vblDatabaseID 	VARCHAR2(10);
vblVersion 	VARCHAR2(10);
vblserverid 	VARCHAR2(10);
vblclientName 	VARCHAR2(100);

BEGIN
	FOR rec IN ( SELECT   ClientName FROM ztbl_DTS_Clients WHERE ClientID = vblDestinationClient)
	LOOP
	   vblDestName := rec.ClientName ;

	END LOOP;

	SELECT   MAX(DTSNo) + 1
	INTO vblDestDTSNo
	 FROM ztbl_DTS_DTS_Set
			WHERE ClientID = vblDestinationClient;

	SELECT   MAX(DatabaseID)
	INTO vblDatabaseID
	 FROM ztbl_DTS_Databases
			WHERE ClientID = vblDestinationClient;

	FOR rec IN ( SELECT   Version FROM ztbl_DTS_DTS_Mast
		WHERE ClientID = vblSourceClient  and DTSNo = vblDTSNo)
	LOOP
	   vblVersion := rec.Version ;

	END LOOP;
	IF  vblDestDTSNo is NULL THEN
	BEGIN
		vblDestDTSNo := 1;
	END;
	END IF;
	IF  vblDatabaseID is NULL THEN
	BEGIN

		--FOR rec IN ( SELECT   ServerID  FROM ztbl_DTS_Servers
		--  WHERE ServerName = 'Washington')
		--LOOP
		--   serverid := rec.ServerID ;
		--END LOOP;

		FOR rec IN ( SELECT   ClientName  FROM ztbl_DTS_Clients
		   WHERE ClientID = vblDestinationClient)
		LOOP
		   vblclientName := rec.ClientName ;

		END LOOP;
		INSERT INTO ztbl_DTS_Databases (ClientID, ServerID, DatabaseName)
			VALUES (vblDestinationClient,vblserverId, vblclientName);
		SELECT   MAX(DatabaseID) INTO vblDatabaseID
			 FROM ztbl_DTS_Databases
					WHERE ClientID = vblDestinationClient;
	END;
	END IF;
	INSERT INTO ztbl_DTS_DTS_Mast (ClientID, DTSNo, CreationDate, CreatedBy, Remarks, Version)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, SYSDATE
		CreationDate, vblUser_ CreatedBy, 'Copied from ' || c.ClientName
		Remarks, m.Version Version
		 FROM ztbl_DTS_DTS_Mast m, ztbl_DTS_Clients c
				WHERE m.ClientID = c.ClientID
				 and m.ClientID = vblSourceClient
				 and m.DTSNo = vblDTSNo;
                                 
	INSERT INTO ztbl_DTS_SourceTableSpace (ClientID, DTSNo, TableName, FieldName, FieldFormat, DatabaseID)
		SELECT  vblDestinationClient ClientID, vblDestDTSNo DTSNo, TableName,
		FieldName, FieldFormat, vblDatabaseID DatabaseID
		 FROM ztbl_DTS_SourceTableSpace sts
				WHERE sts.ClientID = vblSourceClient
				 AND sts.DTSNo = vblDTSno;
	UPDATE ztbl_DTS_Clients
	SET 		Version = vblVersion
			WHERE ClientId = vblDestinationClient;

END SP_COPYDTSSELECTEDSETSPREP;
 
 