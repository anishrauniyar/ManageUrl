/*
  PURPOSE      : To updated m_clientparams in HAWKEYEMASTER  
  CREATED BY   : Raju KC
  CREATED DATE : 2nd June 2015
  REVIEWED BY  : Chandra Kishor Gauro
  SCHEMA       : HAWKEYEMASTER
  SERVER       : Servers listed in DTS that has HAWKEYEMASTER schema.
*/


-- Backup Table HAWKEYEMASTER.m_clientparams --
BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE BACKUP.m_clientparams_06022015 AS SELECT * FROM HAWKEYEMASTER.m_clientparams';
    Dbms_Output.PUT_LINE('BACKUP CREATED');
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE = -955 THEN
      DBMS_OUTPUT.PUT_LINE('BACKUP AREADY EXISTS');
    ELSE
      DBMS_OUTPUT.PUT_LINE('ERROR OCCURED'||SQLERRM);
    END IF;
END;
/

--Update Script 1
UPDATE hawkeyemaster.m_clientparams
SET    paramid = '115'
WHERE  Upper(paramname) = Upper('DXCG_MultiMode')
       AND paramid <> '115'; 

--Update Script 2 
UPDATE hawkeyemaster.m_clientparams
SET    paramid = '121'
WHERE  Upper(paramname) = Upper('DXCG_AVOID_MAP_DRIVE')
       AND paramid <> '121'; 

COMMIT;

/* 
Verification Script
--AFTER
SELECT paramid
FROM   hawkeyemaster.m_clientparams
WHERE  Upper(paramname) = Upper('DXCG_MultiMode'); 

PARAMID
-------
115

SELECT paramid
FROM   hawkeyemaster.m_clientparams
WHERE  Upper(paramname) = Upper('DXCG_AVOID_MAP_DRIVE'); 

PARAMID
-------
121

*/