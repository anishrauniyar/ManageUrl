--- DROP OBJECTS
/*
DECLARE vblSQL VARCHAR2(500);
BEGIN
FOR RC IN (SELECT OBJECT_NAME, OBJECT_TYPE FROM ALL_OBJECTS WHERE OWNER=USER AND UPPER(OBJECT_TYPE) IN ('TABLE','SEQUENCE','PROCEDURE','TRIGGER','VIEW')) 
  LOOP
     vblSQL := 'DROP ' || RC.OBJECT_TYPE || ' "' || RC.OBJECT_NAME || '"';
     BEGIN
      EXECUTE IMMEDIATE vblSQL; 
      Dbms_Output.PUT_LINE(vblSQL);
      EXCEPTION WHEN OTHERS THEN NULL;
     END;
     --;
  END LOOP;
END;
/
*/
----TABLES

CREATE TABLE dbmaps (
  newdb VARCHAR2(30)  NULL,
  olddb VARCHAR2(100) NULL
)
  PCTUSED    0
/

CREATE TABLE tbl_clienttemp (
  clientid     VARCHAR2(20)   NOT NULL,
  clientname   VARCHAR2(100) NOT NULL,
  contracttype VARCHAR2(50)  NULL,
  inuse        VARCHAR2(1)   NULL,
  version      VARCHAR2(50)  NOT NULL
)
  PCTUSED    0
/

CREATE TABLE tbl_dts_oam_clientstatus (
  clientid VARCHAR2(10) NULL,
  csmemail VARCHAR2(70) NULL,
  dsmemail VARCHAR2(70) NULL,
  pdemail  VARCHAR2(70) NULL,
  amemail  VARCHAR2(70) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_accessgroups (
  accessgroup CHAR(3)      NOT NULL,
  groupdesc   VARCHAR2(50) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_accessrights (
  usergroup    CHAR(1)     NOT NULL,
  accessgroup  CHAR(3)     NOT NULL,
  allowadd     VARCHAR2(1) DEFAULT ('N') NULL,
  allowedit    VARCHAR2(1) DEFAULT ('N') NULL,
  allowview    VARCHAR2(1) DEFAULT ('N') NULL,
  allowdelete  VARCHAR2(1) DEFAULT ('N') NULL,
  allowapprove VARCHAR2(1) DEFAULT ('N') NULL
  allowqcapprove VARCHAR2(1) DEFAULT ('N') NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_alphabets (
  usergroup CHAR(1) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_attacheddocuments (
  clientid       VARCHAR2(20)  NOT NULL,
  dtsno          NUMBER(10,0)  NOT NULL,
  documentcount  NUMBER(10,0)  NOT NULL,
  documentname   VARCHAR2(255) NULL,
  documentformat VARCHAR2(50)  NULL,
  document       BLOB          NULL,
  creationdate   DATE          DEFAULT (SYSDATE) NULL,
  createdby      VARCHAR2(20)  NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_categories (
  sn           NUMBER(10,0)  NULL,
  category     VARCHAR2(50)  NOT NULL,
  categorydesc VARCHAR2(255) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_clients (
  clientid     VARCHAR2(20)   NOT NULL,
  clientname   VARCHAR2(100) NOT NULL,
  contracttype VARCHAR2(50)  NULL,
  inuse        VARCHAR2(1)   NULL,
  version      VARCHAR2(50)  DEFAULT (2) NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_clients_old (
  clientid     VARCHAR2(20)   NOT NULL,
  clientname   VARCHAR2(100) NOT NULL,
  contracttype VARCHAR2(50)  NULL,
  inuse        VARCHAR2(1)   NULL,
  version      VARCHAR2(50)  NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_databases (
  databaseid   NUMBER(18,0) NOT NULL,
  clientid     VARCHAR2(20)  NOT NULL,
  serverid     NUMBER(18,0) NOT NULL,
  databasename VARCHAR2(50) NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_dts_mast (
  clientid     VARCHAR2(20)  NOT NULL,
  dtsno        NUMBER(10,0) NOT NULL,
  creationdate DATE         DEFAULT (SYSDATE) NOT NULL,
  createdby    VARCHAR2(20) NULL,
  remarks      CLOB         NULL,
  status       VARCHAR2(1)  NULL,
  approvedby   VARCHAR2(20) NULL,
  lastupdated  DATE         NULL,
  version      VARCHAR2(50) DEFAULT (2) NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_dts_set (
  clientid VARCHAR2(20)  NOT NULL,
  dtsno    NUMBER(10,0) NOT NULL,
  setno    NUMBER(10,0) NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_highlights (
  clientid VARCHAR2(20)   NOT NULL,
  dtsno    NUMBER(10,0)  NOT NULL,
  category VARCHAR2(50)  NOT NULL,
  keyfield VARCHAR2(255) NOT NULL,
  version  VARCHAR2(50)  NOT NULL,
  priority VARCHAR2(1)   NULL,
  setno    NUMBER(10,0)  DEFAULT (1) NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_hist (
  transactionid NUMBER(10,0)  NOT NULL,
  clientid      VARCHAR2(20)   NOT NULL,
  dtsno         NUMBER(10,0)  NOT NULL,
  category      VARCHAR2(50)  NOT NULL,
  keyfield      VARCHAR2(255) NOT NULL,
  userid        VARCHAR2(20)  NOT NULL,
  modifiedon    DATE          DEFAULT (SYSDATE) NOT NULL,
  setno         NUMBER(10,0)  NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_mast (
  sn          NUMBER(10,0)  NOT NULL,
  category    VARCHAR2(50)  NOT NULL,
  keyfield    VARCHAR2(255) NOT NULL,
  version     VARCHAR2(50)  NOT NULL,
  fieldformat VARCHAR2(20)  NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_rule (
  clientid       VARCHAR2(20)    NOT NULL,
  dtsno          NUMBER(10,0)   NOT NULL,
  setno          NUMBER(10,0)   NOT NULL,
  category       VARCHAR2(50)   NOT NULL,
  keyfield       VARCHAR2(255)  NOT NULL,
  version        VARCHAR2(50)   NOT NULL,
  businessrule   CLOB           NULL,
  example        VARCHAR2(1000) NULL,
  translatedrule VARCHAR2(200)  NULL
)
  PCTUSED    0
/


CREATE TABLE ztbl_dts_mapping_rule_hist (
  transactionid NUMBER(10,0) NOT NULL,
  businessrule  CLOB         NULL,
  version       VARCHAR2(50) NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_source (
  clientid    VARCHAR2(20)   NOT NULL,
  dtsno       NUMBER(10,0)  NOT NULL,
  setno       NUMBER(10,0)  NOT NULL,
  category    VARCHAR2(50)  NOT NULL,
  keyfield    VARCHAR2(255) NOT NULL,
  version     VARCHAR2(50)  NOT NULL,
  tablename   VARCHAR2(255) NOT NULL,
  fieldname   VARCHAR2(255) NOT NULL,
  fieldformat VARCHAR2(20)  NULL,
  databaseid  NUMBER(18,0)  NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_source_hist (
  transactionid NUMBER(10,0)  NOT NULL,
  tablename     VARCHAR2(255) NOT NULL,
  fieldname     VARCHAR2(255) NOT NULL,
  fieldformat   VARCHAR2(20)  NULL,
  version       VARCHAR2(50)  NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mapping_target (
  category      VARCHAR2(50)  NOT NULL,
  keyfield      VARCHAR2(255) NOT NULL,
  version       VARCHAR2(50)  NOT NULL,
  tablename     VARCHAR2(255) NOT NULL,
  fieldname     VARCHAR2(255) NOT NULL,
  tablename_old VARCHAR2(255) NULL,
  fieldname_old VARCHAR2(255) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_mast_hist (
  transactionid NUMBER(10,0) NOT NULL,
  clientid      VARCHAR2(20)  NOT NULL,
  dtsno         NUMBER(10,0) NOT NULL,
  status        VARCHAR2(1)  NULL,
  userid        VARCHAR2(20) NOT NULL,
  modifiedon    DATE         DEFAULT (SYSDATE) NOT NULL,
  remarks       CLOB         NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_remarks (
  remarksid       NUMBER(10,0) NULL,
  clientid        VARCHAR2(20) NULL,
  dtsno           NUMBER(10,0) NULL,
  remarks         CLOB         NULL,
  postedby        VARCHAR2(20) NULL,
  postedon        DATE         NULL,
  updatedby       VARCHAR2(20) NULL,
  updatedon       DATE         NULL,
  droppedby       VARCHAR2(20) NULL,
  droppedon       DATE         NULL,
  parentremarksid NUMBER(10,0) NULL,
  status          CHAR(1)      NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_servers (
  serverid     NUMBER(18,0) NOT NULL,
  servername   VARCHAR2(50) NOT NULL,
  username     VARCHAR2(50) NOT NULL,
  userpassword VARCHAR2(50) NOT NULL
)
  PCTUSED    0
/


CREATE TABLE ztbl_dts_sourcetablespace (
  clientid    VARCHAR2(20)   NOT NULL,
  dtsno       NUMBER(10,0)  NOT NULL,
  tablename   VARCHAR2(255) NOT NULL,
  fieldname   VARCHAR2(255) NOT NULL,
  fieldformat VARCHAR2(20)  NULL,
  databaseid  NUMBER(18,0)  NULL
)
  PCTUSED    0
/


CREATE TABLE ztbl_dts_targettableinfo (
  tableid     NUMBER(18,0) NOT NULL,
  tablename   VARCHAR2(50) NULL,
  code        VARCHAR2(20) NULL,
  description VARCHAR2(50) NULL,
  category    VARCHAR2(50) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_targettablespace (
  tablename   VARCHAR2(255) NOT NULL,
  fieldname   VARCHAR2(255) NOT NULL,
  version     VARCHAR2(50)  NOT NULL,
  fieldformat VARCHAR2(20)  NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_usergroups (
  usergroup CHAR(1)      NOT NULL,
  groupdesc VARCHAR2(50) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_usermessages_hist (
  clientid    VARCHAR2(20)  NOT NULL,
  dtsno       NUMBER(10,0) NOT NULL,
  messagedate DATE         DEFAULT (SYSDATE) NOT NULL,
  userid      VARCHAR2(20) NULL,
  username    VARCHAR2(50) NULL,
  message     CLOB         NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_users (
  userid       VARCHAR2(20)  NOT NULL,
  username     VARCHAR2(50)  NULL,
  userpassword VARCHAR2(100) NULL,
  creationdate DATE          NULL,
  expirydate   DATE          NULL,
  email        VARCHAR2(255) NULL
)
  PCTUSED    0
/

CREATE TABLE ztbl_dts_usersandclients (
  userid   VARCHAR2(20) NOT NULL,
  clientid VARCHAR2(20)  NOT NULL,
  notifyon VARCHAR2(1)  NULL
)
  PCTUSED    0
/


CREATE TABLE ztbl_dts_usersandgroups (
  userid    VARCHAR2(20) NOT NULL,
  usergroup CHAR(1)      NOT NULL
)
  PCTUSED    0
/

CREATE TABLE ZTBL_DTS_SETNAMES (
  CLIENTID       VARCHAR2(20) NOT NULL,
  DTSNO          NUMBER(10,0) NOT NULL,
  CATEGORY       VARCHAR2(50) NOT NULL,
  SETNO          NUMBER(10,0) NOT NULL,  
  SETNAME	 VARCHAR2(100)
)
  PCTUSED    0
/

CREATE TABLE ZTBL_DTS_HISTORY
(
  HISTID NUMBER(10) NOT NULL,
  CLIENTID VARCHAR2(20) NOT NULL,
  DTSNO NUMBER(10) NOT NULL,
  SETNO NUMBER(10) NOT NULL,
  CATEGORY VARCHAR2(50) NOT NULL,
  KEYFIELD VARCHAR2(50) NOT NULL,
  VERSION VARCHAR2(50),
  HISTDATE DATE,
  SRCFLDTXT VARCHAR2(4000),
  MAPRLETXT VARCHAR2(4000),
  UPDATEDBY VARCHAR2(20)
)
/

CREATE SEQUENCE SEQ_DTS_DB
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE SEQ_DTS_REMARKID
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE SEQ_DTS_MAPPING_HIST
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/


CREATE SEQUENCE SEQ_DTS_MAST_HIST
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE SEQ_DTS_MAST_SERVERS
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE SEQ_DTS_TARGETTBLSPC
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE SEQ_DTS_ATCHDOCUMENT
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/

CREATE SEQUENCE SEQ_DTS_HISTORY
  MINVALUE 1
  MAXVALUE 99999999999999
  INCREMENT BY 1
  NOCYCLE
  NOORDER
  CACHE 20
/



CREATE OR REPLACE TRIGGER tr_SEQ_DTS_DB
 BEFORE INSERT ON ztbl_dts_databases
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_DB.nextval INTO :new.DATABASEID FROM dual;
 END;
/

CREATE OR REPLACE TRIGGER tr_SEQ_DTS_MAPPING_HIST
 BEFORE INSERT ON ztbl_dts_mapping_hist
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_MAPPING_HIST.nextval INTO :new.TRANSACTIONID FROM dual;
 END;
/

CREATE OR REPLACE TRIGGER tr_SEQ_DTS_MAST_HIST
 BEFORE INSERT ON ztbl_dts_mast_hist
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_MAST_HIST.NEXTVAL INTO :new.TRANSACTIONID FROM dual;
 END;
/

CREATE OR REPLACE TRIGGER tr_SEQ_DTS_MAST_SERVERS
 BEFORE INSERT ON ztbl_dts_servers
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_MAST_SERVERS.nextval INTO :new.SERVERID FROM dual;
 END;
/


CREATE OR REPLACE TRIGGER tr_SEQ_DTS_TARGETTBLSPC
 BEFORE INSERT ON ztbl_dts_targettableinfo
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_TARGETTBLSPC.nextval INTO :new.TABLEID FROM dual;
 END;
/

CREATE OR REPLACE TRIGGER tr_SEQ_DTS_ATCHDOCUMENT
 BEFORE INSERT ON ztbl_DTS_AttachedDocuments
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_TARGETTBLSPC.nextval INTO :new.DOCUMENTCOUNT FROM dual;
 END;
/


CREATE OR REPLACE TRIGGER tr_SEQ_DTS_REMARKID
 BEFORE INSERT ON ztbl_DTS_Remarks
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_REMARKID.nextval INTO :new.REMARKSID FROM dual;
 END;
/

CREATE OR REPLACE TRIGGER tr_SEQ_DTS_HISTORY
 BEFORE INSERT ON ZTBL_DTS_HISTORY
 FOR EACH ROW

BEGIN
 SELECT SEQ_DTS_DB.NEXTVAL INTO :NEW.HISTID FROM DUAL;
 END;
/