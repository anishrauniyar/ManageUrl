/*
JIRA#            :  N/A
PURPOSE          :  To Backup Tables M_CLIENTS of HAWKEYMASTER5
CREATED BY       :  BINAY SHAKYA
CREATED DATE     :  03/04/2015
REVIEWED BY      :  RAJU KC
SCHEMA           :  HAWKEYEMASTER5
SERVER           :  RAC 
*/

--Backup script for M_CLIENTS table
BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE BACKUP.M_CLIENTS_20150304 AS SELECT * FROM HAWKEYEMASTER5.M_CLIENTS';
    Dbms_Output.PUT_LINE('BACKUP CREATED');
EXCEPTION WHEN OTHERS THEN
    IF SQLCODE = -955 THEN
      DBMS_OUTPUT.PUT_LINE('BACKUP AREADY EXISTS');
    ELSE
      DBMS_OUTPUT.PUT_LINE('ERROR OCCURED'||SQLERRM);
    END IF;
END;
/

-- Verification Script --
/*
--For M_CLIENTS
SELECT Count(1)
FROM   dba_objects
WHERE  object_type = 'TABLE'
       AND owner = 'BACKUP'
       AND object_name = 'M_CLIENTS_20150304'; 

Count(1)
--------
1

*/