/*
JIRA#            :  N/A
PURPOSE          :  To Grant SELECT,INSERT,UPDATE,DELETE on HELOG.DATAOPS_LOG table for HAWKEYEMASTER5
CREATED BY       :  BINAY SHAKYA
CREATED DATE     :  03/04/2015
REVIEWED BY      :  RAJU KC
SCHEMA           :  HELOG
SERVER           :  RAC 
*/

--Grant script
GRANT SELECT, INSERT, UPDATE, DELETE ON HELOG.DATAOPS_LOG TO HAWKEYEMASTER5;

-- Verification Script --
/*
Will be tested by application.
*/