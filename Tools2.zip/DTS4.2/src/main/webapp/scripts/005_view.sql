CREATE OR REPLACE VIEW ztbl_DTS_ClientView AS
SELECT 
  a.ClientID, a.ClientName, a.ContractType, b.DatabaseName, c.UserName, c.ServerName, c.UserPassword, a.InUse, a.Version
From
  ztbl_DTS_Clients a
LEFT JOIN
  ztbl_DTS_Databases b 
ON 
  a.ClientID=b.ClientID
LEFT JOIN
  ztbl_DTS_servers c
ON 
  b.serverid=c.serverID
