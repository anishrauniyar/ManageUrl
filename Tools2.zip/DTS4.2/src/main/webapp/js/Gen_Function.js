
var old=1;
var Temp=new Array();
var Temp2=new Array();
var Temp3=new Array();
var Selection=0;
var RecordCount=0;
var Offset=0;
var noOfImgProw=0;
var IE = (document.all) ? 1 : 0;
var NS = (document.layers) ? 1 : 0;

// WINDOW STATUS FUNCTIONS
window.defaultStatus = "";
function winStatus( msg )
{
	window.status = msg;
}

//http://www.aspdev.org/articles/javascript-trim/
function trimAll(sString)
{
    while (sString.substring(0, 1) == ' ')
    {
        sString = sString.substring(1, sString.length);
    }
    while (sString.substring(sString.length - 1, sString.length) == ' ')
    {
        sString = sString.substring(0, sString.length - 1);
    }
    return sString;
}

function popUp( loc, w, h, menubar ) {
	if( w == null ) { w = 500; }
	if( h == null ) { h = 350; }
	if( menubar == null || menubar == false ) {
		menubar = "";
	} else {
		menubar = "menubar,";
	}

	//if( NS ) { w += 50; }
	// Need the var or else IE4 blows up not recognizing editorWin
	var editorWin = window.open(loc,'editWin', menubar + 'resizable,scrollbars,width=' + w + ',height=' + h);
	//if( !newWin.opener )
		//newWin.opener = window;
	editorWin.focus(); //causing intermittent errors
}

function popUpnWin( loc, w, h, menubar ) {
	if( w == null ) { w = 500; }
	if( h == null ) { h = 350; }
	if( menubar == null || menubar == false ) {
		menubar = "";
	} else {
		menubar = "menubar,";
	}

	//if( NS ) { w += 50; }
	// Need the var or else IE4 blows up not recognizing editorWin
	var editorWin = window.open(loc,'editWin', menubar + 'left=0,top=0,resizable=false,scrollbars,width=' + w + ',height=' + h);
	//if( !newWin.opener )
		//newWin.opener = window;
	editorWin.focus(); //causing intermittent errors
}

function popUpMax( loc ) {
	w = window.screen.width;
	h =window.screen.height;
	if( menubar == null || menubar == false ) {
		menubar = "";
	} else {
		menubar = "menubar,";
	}

	// Need the var or else IE4 blows up not recognizing editorWin
	var editorWin = window.open(loc,'editWin', menubar + 'left=0,top=0,resizable=false,scrollbars,width=' + w + ',height=' + h);
	//if( !newWin.opener )
		//newWin.opener = window;
	editorWin.focus(); //causing intermittent errors
}

function setNoImg(val)
{
	noOfImgProw=val;
}

function setOffset(val)
{
	Offset=val;
}

function setSelection(val)
{
	Selection=val;
}

function initialize()
{
	old=1;
	Temp=new Array();
	Temp2=new Array();
	Temp3=new Array();
	Selection=0;
	RecordCount=0;
}

function setValue(value)
{
	alert(value);
	RecordCount=RecordCount+1;
	Temp[RecordCount]=value;


}

function setValue(value1,value2)
{
	RecordCount=RecordCount+1;
	Temp[RecordCount]=value1;
	Temp2[RecordCount]=value2;

}

function setValue(value1,value2,value3)
{
	RecordCount=RecordCount+1;
	Temp[RecordCount]=value1;
	Temp2[RecordCount]=value2;
	Temp3[RecordCount]=value3;

}

function substitute(index,itemID)
{
	document.SubmissionForm.elements[itemID].value=Temp[parseInt(index)];
	document.images[old+Offset+(old-1)*noOfImgProw].src="/images/SmlSquare_Button_01.gif";
	document.images[index+Offset+(index-1)*noOfImgProw].src="/images/SmlSquare_ButtonInd_01.gif";
	old=index;
	//alert(Temp[parseInt(index)]);
}

function substitute2(index,itemID1,itemID2)
{
	document.SubmissionForm.elements[itemID1].value=Temp[parseInt(index)];
	document.SubmissionForm.elements[itemID2].value=Temp2[parseInt(index)];
	document.images[old+Offset+(old-1)*noOfImgProw].src="/images/SmlSquare_Button_01.gif";
	document.images[index+Offset+(index-1)*noOfImgProw].src="/images/SmlSquare_ButtonInd_01.gif";
	old=index;
}

function substitute3(index,itemID1,itemID2,itemID3)
{
	document.SubmissionForm.elements[itemID1].value=Temp[parseInt(index)];
	document.SubmissionForm.elements[itemID2].value=Temp2[parseInt(index)];
	document.SubmissionForm.elements[itemID3].value=Temp3[parseInt(index)];
	document.images[old+Offset+(old-1)*noOfImgProw].src="/images/SmlSquare_Button_01.gif";
	document.images[index+Offset+(index-1)*noOfImgProw].src="/images/SmlSquare_ButtonInd_01.gif";
	old=index;
}

function nextLevel(SubmitTo,f)
{
	document.SubmissionForm.action=SubmitTo;
	document.SubmissionForm.Selection.value=parseInt(Selection)*10+parseInt(f);
	document.SubmissionForm.PageNo.value=1;
	reset();
	document.SubmissionForm.submit();
}

function getDetail(target)
{
	document.SubmissionForm.action=target;
	document.SubmissionForm.PageNo.value=1;
	document.SubmissionForm.submit();
}

function prevLevel(target)
{
	document.SubmissionForm.action=target;
	document.SubmissionForm.Selection.value=parseInt(parseInt(Selection)/10);
	document.SubmissionForm.PageNo.value=1;
	reset();
	document.SubmissionForm.submit();
}

function zoomback()
{
	document.SubmissionForm.action="HE_Explorer.jsp";
	document.SubmissionForm.submit();
}


function sendToExcel(target)
{
	document.SubmissionForm.action=target;
	reset();
	document.SubmissionForm.submit();
}

function changeClass(f,s)
{
	f.className=s;
}

function getMorePages(target,pageno)
{
	document.SubmissionForm.action=target;
	document.SubmissionForm.PageNo.value=pageno;
	document.SubmissionForm.submit();
}


function reset(){
	document.SubmissionForm.orderField.value="";
	document.SubmissionForm.order.value="";
	document.SubmissionForm.PageNo.value=1;
}

function setOrder(orderField,order){
	document.SubmissionForm.orderField.value=orderField;
	document.SubmissionForm.order.value=order;
	document.SubmissionForm.submit();
	return true;
}


function dispValue(itemID,value)
{
	//ie
	if(document.all)
	{
		document.all[itemID].innerHTML=value;
	}
	//else if NS 4
	else if(document.layers)
	{
		document.layers[itemID].document.text.document.write("<p class='ParamDataCell'><FONT SIZE=1 FACE=Verdana >"+value+"</FONT></P>");
		document.layers[itemID].document.text.document.close();

	}
}


function ret(){
	return;
}
var stltxtcolor = 0;
var stltxtover = 1;
var stltxtcolorblue = 2;
var stltxtcolorBlack = 3;
function chStyle(link,i){
	switch(i){
	case 0 : link.className = "tbltxtcolor"; break;
	case 1 : link.className = "tbltxtover"; break;
	case 2 : link.className = "tbltxtcolorblue"; break;
	case 3 :
	default:
	link.className = "tbltxtcolorBlack";
	}
	return;
}

function getStdDate(t){
//input format is dd/mm/yy;
if(t==0)return t;
var dd="";
var mm="";
var yy="";
var index1=t.indexOf("/");
var index2=t.lastIndexOf("/");
mm=t.substring(0,index1);
dd=t.substring(index1+1,index2);
yyyy=t.substring(index2+1);
//alert(t);
//alert(yy+"/"+mm+"/"+dd);
var theDate=new Date(yyyy,mm,dd,0,0,0,0);
//alert(theDate.toGMTString());
return theDate.toGMTString();
}


var imgIndexOld=0
var imgOn = new Image()
var imgOff = new Image()
var imgName="selectImg"
imgOff.src = "/images/SmlSquare_Button_01.gif"
imgOn.src  = "/images/SmlSquare_ButtonInd_01.gif"



function setSelector(selectIndex){
	document.images[imgName+imgIndexOld].src = imgOff.src
	document.images[imgName+selectIndex].src = imgOn.src
	imgIndexOld = selectIndex
}


//row selection
var previousTR;
function SelectForDrill()
{
	var mTR =arguments[0]
	SelectTR(mTR,"#eeeecc","#aaaaaa");
	if(previousTR!=null)
	{
		if(previousTR!=mTR)
		{
			SelectTR(previousTR,"#f7f7f7","#cccccc");
		}
	}
	previousTR=mTR;
	setSelector(arguments[1]);
}
function SelectTR()
{
	var mTR = arguments[0];
	var col = arguments[1];
	var col1 = arguments[2];
	for(var i = 0 ; i < mTR.childNodes.length; i++ )
	{
		if(mTR.childNodes[i].tagname="TD")
		if(mTR.childNodes[i].className!="Leveltab" && mTR.childNodes[i].className!="LevelTab")
		{
			SelectTD(mTR.childNodes[i],col);
		}
		else
		{
			SelectTD(mTR.childNodes[i],col1);
		}
	}
}
function SelectTD()
{
	var mTD = arguments[0];
	mTD.style.backgroundColor=arguments[1];
}
//end row selection