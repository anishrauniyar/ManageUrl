function tdButtonize(tdObj,Class,status)
	{
	tdObj.childNodes.item(0).className=Class;
	if(status!=null)
		{
		window.status=status;
		return true;
		}
	}


function tdButtonizeNew(tdObj,Class,status)
	{
	tdObj.className=Class;
	if(status!=null)
		{
		window.status=status;
		return true;
		}
	}
