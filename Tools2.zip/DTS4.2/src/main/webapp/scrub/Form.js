/*---------- CONSTANTS ----------*/
var ORDER = "ORDER";
var XL = "XL";
var RESET_FILTER = "RESET_FILTER";
var FILTER = "FILTER";


/************************************************************
 frm reference to form
 command string specifying value for process object if exist
************************************************************/
function goToProcess( frm, command){
  if( frm && frm.process ){
	frm.process.value = command;
	target = arguments[2] || '_self';
	frm.submit();
  }else{
	alert(" script error : frm " + frm + " and command : " + command );
  }
}

/*************************************************************
	* REGULAR EXPRESSIONS FOR DATE-FILTERING *
************************************************************/

var SML_DATE = "(\\d{1,2}[ ]*/[ ]*\\d{1,2}[ ]*/[ ]*\\d{4})";		/* YYYY-MM-DD */
var LRG_DATE = "(\\d{1,2}[ ]*/[ ]*\\d{1,2}[ ]*/[ ]*\\d{4}[ ]+\\d{1,2}:\\d{1,2}:\\d{1,2})([.]\\d{1,3})?";
									/* YYYY-MM-DD */
var regSmallDate = new RegExp( "^[ ]*"+SML_DATE+"[ ]*$","i");		/* YYYY-MM-DD HH:MM:SS(.DS)? */
var regDate = new RegExp( "^[ ]*" + LRG_DATE + "[ ]*$", "i");		

var regNum = new RegExp("^[ ]*[\+\-]?[ ]*\\d*([.]\\d*)?[ ]*$" );

var notSmallDate = new RegExp( "^[ ]*(not |<>|!=)[ ]*" +SML_DATE+ "[ ]*$", "i"); //not or <> or !=

var notDate = new RegExp( "^[ ]*(not |<>|!=)[ ]*" +LRG_DATE+ "[ ]*$", "i");	// not or <> or !=

var gtleeqSmallDate = new RegExp( "^[ ]*[><]?[=]?[ ]*" +SML_DATE+ "[ ]*$", "i"); // <= >= = < >

var gtleeqDate = new RegExp( "^[ ]*[><]?[=]?[ ]*" +LRG_DATE+ "[ ]*$", "i");	// <= >= = < >

var btnSmallDate = new RegExp("^[ ]*between[ ]+" + SML_DATE + "[ ]+and[ ]+" + SML_DATE + "[ ]*$", "i"); // between date1 and date2

var btnDate = new RegExp("^[ ]*between[ ]+" + LRG_DATE + "[ ]+and[ ]+" + SML_DATE + "[ ]*$", "i"); //between date1 and date2

/*--- DATE FILTER ARRAY --*/
var dateFilters = new Array();
dateFilters[0] = regDate;
dateFilters[1] = regSmallDate;
dateFilters[2] = notSmallDate;
dateFilters[3] = notDate;
dateFilters[4] = gtleeqSmallDate;
dateFilters[5] = gtleeqDate;
dateFilters[6] = btnSmallDate;
dateFilters[7] = btnDate;

function checkDate( toCheck, fname){
 var isValid = false;
 var index = 0;
 var fl_name = fname; //field Name 
 var fLen = dateFilters.length;
 var _matches ;
 var i = 1;
 WH: while( index<fLen && !isValid){
	isValid = dateFilters[ index].test( toCheck);
	if( isValid){
	   _matches = dateFilters[ index].exec( toCheck);
	   for( i=1; _matches != undefined && _matches.length>=1 && i<_matches.length; i++){
		isValid = isValid && verifyDateLarge( _matches[i], fname);
		if( !isValid) {
			//break from while loop
			break WH;
		}
	   }
	}
	index++;
   }
   return isValid;
 }

 /*-------------------- REGEX TO VERIFY DATE VALUE ---------------*/
 // regular exp. small date check **** 3 back refs.

 var regSmallDateCheck = new RegExp( "(\\d{1,2})[ ]*/[ ]*(\\d{1,2})[ ]*/[ ]*(\\d{2,4})","i" );
 //regulrar exp. large date check *** at least 6 back refs
 var regLargeDateCheck = new RegExp( "(\\d{1,2})[ ]*/[ ]*(\\d{1,2})[ ]*/[ ]*(\\d{2,4})[ ]+(\\d{2}):(\\d{2}):(\\d{2})([.]\\d)?", "i");
 // format yyyy-mm-dd


 /*----------MONTH ARRAY----------*/
 var months = new Array(13);		//actual months value from 1 ( 1 based).
 months[0] = -1 ; // undefined
 months[1] = 31;
 months[2] = 28;
 months[3] = 31;
 months[4] = 30;
 months[5] = 31;
 months[6] = 30;
 months[7] = 31;
 months[8] = 31;
 months[9] = 30;
 months[10] = 31;
 months[11] = 30;
 months[12] = 31;

 var mNames = new Array(13);		//month name from 1 ( 1 based).
 mNames[0] = -1 ; // undefined
 mNames[1] = "January";
 mNames[2] = "February";
 mNames[3] = "March";
 mNames[4] = "April";
 mNames[5] = "May";
 mNames[6] = "June";
 mNames[7] = "July";
 mNames[8] = "August";
 mNames[9] = "September";
 mNames[10] = "October";
 mNames[11] = "November";
 mNames[12] = "December";
 /*--------------- MONTH DEFINITION ENDS ---------------*/

 function verifyDateSmall( toCheck, fieldName ){
   var m = regSmallDateCheck.exec( toCheck );
   var retVal = true;
   if( m && m.length > 3){
	var yr = m[3];
	var mn = m[1];
	var dy = m[2];
	if ( mn < 1 || mn > 12 ){
		retVal = false;
		alert("Month should be between 1 and 12 in " + fieldName);
	}
	if( retVal && dy < 1){
		retVal = false;
		alert("Value for days should not be less than 1 in " + fieldName);
	}
	var isLeapYr = (yr % 4 == 0);
	if( retVal && mn == 2){ //Feb
		if( dy > 29 && isLeapYr){
			retVal = false;
			alert("February in leap year should not exceed 29 days for " + fieldName );
		}else if( dy > 28 && !isLeapYr){
			retVal = false;
			alert("February should not exceed 28 days for " + fieldName);
		}
	}
	if( retVal && mn !=2 ){
		if( dy > months[ mn ]){
			retVal = false;
			alert( "Number of days in " + mNames[ mn ] + " exceeded " + months[mn] + " in " + fieldName);
		}
	}
   }
   return retVal;
 }

 //format of date yyyy-mm-dd hh:mm:ss.s assumed
 function verifyDateLarge( toCheck, fieldName){
 var retVal = true;
 retVal = verifyDateSmall( toCheck, fieldName);
	if( retVal){
	var m = regLargeDateCheck.exec( toCheck, fieldName);
		if( m && m.length > 6 ){
			var hr = m[4];
			var min = m[5];
			var sec = m[6];
			if( hr > 23 ){
				retVal = false;
				alert( "Hour exceeded 23 in " + fieldName + hr );
			}
			if( retVal && min > 59 ){
				retVal = false;
				alert( "Minutes exceeded 59 in " + fieldName );
			}
			if( retVal && sec > 59 ){
				retVal = false;
				alert( "Seconds exceeded 59 in " + fieldName );
			}
		}
	}
 return retVal;
 }