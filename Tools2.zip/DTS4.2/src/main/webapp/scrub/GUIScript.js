/* changing the style */

function chStyle( stObj, cssName){
  if( stObj && stObj.className && cssName ){
      stObj.className = cssName;
  }
}
/************************************************************
	* DECLARATION FOR ARROW *
************************************************************/
var currentIndex = 0;
var imgIndexOld=0
var imgOn = new Image()
var imgOff = new Image()
var imgName="selectImg"
imgOff.src = "images/SmlSquare_Button_01.gif"
imgOn.src  = "images/SmlSquare_ButtonInd_01.gif"


/*************************************************************
	* SWAP INDICATOR ARROW *
************************************************************/
function setSelector(selectIndex){
    currentIndex = selectIndex;
    if(document.images[imgName+imgIndexOld] && document.images[imgName+selectIndex])	{
	document.images[imgName+imgIndexOld].src = imgOff.src;
	document.images[imgName+selectIndex].src = imgOn.src;
	imgIndexOld = selectIndex;
    }  else  {
	imgIndexOld = selectIndex;
    }
}

/************************************************************
	* ROW HIGHLIGHTING *
************************************************************/
var prevRow ;		/* PREVIOUSLY CLICKED ROW (TR) */
			/* rowObj TR */
			/* class_name class name for default if class_name then highlighted */
			/* class_name for highlighting */
function highlight( rowObj, class_name, class_name_over ){
  if( typeof(prevRow)!='undefined' ) {
	//revert prev
	ChangeStyle( prevRow, class_name_over, class_name);
	prevRow.style.backgroundColor = '';
  }
  ChangeStyle( rowObj, class_name, class_name_over);
  prevRow = rowObj;
}

/************************************************************
	* HELPER FUNCTION FOR HIGHLIGHTING *
	* elements of ro has style of cl   *
	* change to cl_next		   *
************************************************************/
function ChangeStyle( ro, cl, cl_next){
 if( typeof( ro) == 'undefinde')
   return;
 var i=0;
 var child;
 with( ro ){
   for( i=0; i< childNodes.length; i++){
    child = childNodes[i];
    if( child.className){
      if( child.className == cl){
	   child.className = cl_next;
      }
    }
   }
 }
}
