package d2Hawkeye.common.connectionPool;

/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * @author Raj K Gaire
 * @version 3.2
 *
 * Object that corresponds to
 * <Alias
 *   name="test-server->MDHawkeye_FMH2"
 *   driver="com.microsoft.jdbc.sqlserver.SQLServerDriver"
 *   url="jdbc:microsoft:sqlserver://test-server:1433;DatabaseName=MDHawkeye_FMH2"
 *   username="sa"
 *   password="adm"
 *   maxConn="20"
 *   idleTimeout="60"
 *   checkoutTimeout="60"
 *   maxCheckout="10"
 * >
 */
public class ConnectionParameters {
  private String name;
  private String driver;
  private String url;
  private String userName;
  private String password;
  private int maxConnection = -1;
  private int idleTimeOut = -1;
  private int checkOutTimeOut = -1;
  private int maxCheckOutTime = -1;
  public ConnectionParameters() {
  }

  public ConnectionParameters(String name, String driver, String url,
                              String userName, String pass, int maxcon,
                              int idleTimeout, int checkout, int maxCheckout) {
    this.name = name;
    this.driver = driver;
    this.url = url;
    this.userName = userName;
    this.password = pass;
    this.maxConnection = maxcon;
    this.idleTimeOut = idleTimeout;
    this.checkOutTimeOut = checkout;
    this.maxCheckOutTime = maxCheckout;
  }

  public int getCheckOutTimeOut() {
    return checkOutTimeOut;
  }

  public void setCheckOutTimeOut(int checkOutTimeOut) {
    this.checkOutTimeOut = checkOutTimeOut;
  }

  public void setCheckOutTimeOut(String checkOutTimeOut) {
    try {
      this.checkOutTimeOut = Integer.parseInt(checkOutTimeOut);
    }
    catch (NumberFormatException e) {
      this.checkOutTimeOut = -1;
    }
  }

  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public int getIdleTimeOut() {
    return idleTimeOut;
  }

  public void setIdleTimeOut(int idleTimeOut) {
    this.idleTimeOut = idleTimeOut;
  }

  public void setIdleTimeOut(String idleTimeOut) {
    try {
      this.idleTimeOut = Integer.parseInt(idleTimeOut);
    }
    catch (NumberFormatException e) {
      this.idleTimeOut = -1;
    }
  }

  public int getMaxCheckOutTime() {
    return maxCheckOutTime;
  }

  public void setMaxCheckOutTime(int maxCheckOutTime) {
    this.maxCheckOutTime = maxCheckOutTime;
  }

  public void setMaxCheckOutTime(String maxCheckOutTime) {
    try {
      this.maxCheckOutTime = Integer.parseInt(maxCheckOutTime);
    }
    catch (NumberFormatException e) {
      this.maxCheckOutTime = -1;
    }
  }

  public int getMaxConnection() {
    return maxConnection;
  }

  public void setMaxConnection(int maxConnection) {
    this.maxConnection = maxConnection;
  }

  public void setMaxConnection(String maxConnection) {
    try {
      this.maxConnection = Integer.parseInt(maxConnection);
    }
    catch (NumberFormatException e) {
      this.maxConnection = -1;
    }
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

}