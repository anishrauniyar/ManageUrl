/**
 * File: ConnectionPoolManager.java
 * @author Raj K Gaire
 * @version 3.2
 * @since April 19, 2004
 * Description:
 *  A connection pool manager for dbcp
 *  Modified:
 *  Sn:			Date:					By:				Comments:
 *
 * */
package d2Hawkeye.common.connectionPool.dbcp;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.Transaction;
import javax.transaction.xa.XAResource;

import oracle.jdbc.xa.client.OracleXADataSource;

import org.apache.commons.dbcp.BasicDataSource;

import com.vh.dataOps.util.DataOpsUtil;

import d2Hawkeye.common.connectionPool.ConnectionParameters;

/**
 * This class is created as singleton class. So, this class cannot be
 * instanciated, however the instance can be obtained using static getInstance()
 * method.<br>
 * It requires a hash map containing connection pool alias names as keys and
 * connection parameters as the corresponding values. It stores the connections
 * in hash map with keys as alias names. It the datasource having the alias name
 * already present in the hash map it simply return it, otherwise it creates new
 * data source, adds to the hasmap and returns.
 * */
final public class ConnectionPoolManager {
    /**
     * stores its own instance, created when the class is loaded by class
     * loader.
     * */
    private static ConnectionPoolManager cpm = null;

    /**
     * stores the connection parameters.
     * */
    public HashMap connectionProperties = null;

    /***
     * store the created data sources
     */
    private HashMap dataSources = new HashMap();

    /***
     * store the created XA data sources
     */
    private Map<String, OracleXADataSource> dataSourcesXA = new HashMap<String, OracleXADataSource>();
    private Map<String, XAConnection> xaConnMap = new HashMap<String, XAConnection>();
    private Map<String, String> xaConnMap1 = new TreeMap<String, String>();;

   
    private ConnectionPoolManager() {
    }

    /**
     * @return instance of ConnectionPoolManager
     */
    public static synchronized ConnectionPoolManager getInstance() {
		
    	if(cpm==null){
    		System.out.println("creating new CPM");
    		cpm=new ConnectionPoolManager ();
    	}
	    
    	return cpm;
    }

    /**
     * @param alias
     *            hashmap containing the aliasname and connection parameters
     *            pairs
     */
    public void setAlias(HashMap alias) {
	this.connectionProperties = alias;
    }

    /**
     * 
     * @return true if alias is not null
     */
    public boolean isAliasSet() {
	return (this.connectionProperties != null);
    }

    /**
     * 
     * @param aliasName
     *            it should be present in connectionProperties hashmap
     * @return datasource if it is not aleady created, creates and returns it
     */
    public synchronized Connection getConnection(String aliasName) {
	// System.out.println("getting connetion");
	String strAlias = aliasName.toUpperCase();
	Connection con = null;
	/* checking if datasource is already created */
	if (this.dataSources.containsKey(strAlias)) {
	    // System.out.println("getting connection");
	    try {
	    	//System.out.println("getting connection:"+strAlias);
		DataSource ds = (DataSource) this.dataSources.get(strAlias);
		return ds.getConnection();
	    } catch (Exception e) {
		System.out.println("Error while getting connection :" + e);
		return null;
	    }
	}
	/* checking if connection properties hashmap is set or not */
	if (this.connectionProperties == null) {
	    System.out
		    .println("Connection properties not set. It must be present to create the connection.");
	    return null;
	}
	/*
	 * checking if connection properties hashmap has the alias name as key
	 * or not
	 */
	if (!this.connectionProperties.containsKey(strAlias)) {
	    System.out.println("no such alias key: " + strAlias);
	    return null;
	}
	/* datasource is not created, so creating it */
	ConnectionParameters cps = (ConnectionParameters) this.connectionProperties
		.get(strAlias);
	try {
	     	String patternString = "^(MDHawkeye->HawkeyeMaster)[0-9]{1,2}$";
		    Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
		    Matcher matcher = pattern.matcher(strAlias);
		  
	    if (!(matcher.matches() || strAlias
		    .contains("HAWKEYELOG"))) {
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName(cps.getDriver());
		bds.setUrl(cps.getUrl());
		bds.setUsername(cps.getUserName());
		bds.setPassword(cps.getPassword());
		if (cps.getIdleTimeOut() > -1) {
		    bds.setMaxIdle(cps.getIdleTimeOut());
		}
		if (cps.getMaxCheckOutTime() > -1) {
		    bds.setMaxWait(cps.getMaxCheckOutTime());
		}
		//bds.setMaxActive(0);
		bds.setRemoveAbandoned(true);
        bds.setRemoveAbandonedTimeout(60*10*1); 
        this.dataSources.put(strAlias, bds);
		con = bds.getConnection();
		System.out.println("getting new connection()->" + strAlias);

	    } else {

		OracleXADataSource ds = new oracle.jdbc.xa.client.OracleXADataSource();
		ds.setUser(cps.getUserName());
		ds.setPassword(cps.getPassword());
		ds.setURL(cps.getUrl());
		this.dataSources.put(strAlias, ds);
		con = ds.getConnection();
		System.out.println("getting new xaconnection()->" + strAlias);
	    }

	} catch (Exception e) {
	    e.printStackTrace();
	    con = null;
	}
	return con;
    }
    
    public Connection getConnection(String driver, String url, String userName,
    	    String passwd) throws Exception {
    	/* checking if datasource is already created */

    	// System.out.println("Connection for "+url);
    	if (this.dataSources.containsKey(url)) {
    	    // System.out.println("getting connection");
    	    DataSource ds = (DataSource) this.dataSources
    		    .get(url.toUpperCase());
    	    return ds.getConnection();
    	}
    	// System.out.println("creating datasource");
    	BasicDataSource bds = new BasicDataSource();
    	bds.setDriverClassName(driver);
    	bds.setUrl(url);
    	bds.setUsername(userName);
    	bds.setPassword(passwd);
    	this.dataSources.put(url.toUpperCase(), bds);
    	// System.out.println("getting new connection");
    	return bds.getConnection();
        }

  

    /**
     * 
     * @param aliasName
     *            it should be present in connectionProperties hashmap
     * @return XAdatasource if it is not aleady created, creates and returns it
     * @throws SQLException 
     */
    public XADataSource initXADataSource(String aliasName) throws SQLException {
	// System.out.println("getting connetion");
	String strAlias = aliasName.toUpperCase();

	/* checking if connection properties hashmap is set or not */
	if (this.connectionProperties == null) {
	    System.out
		    .println("Connection properties not set. It must be present to create the connection.");
	    return null;
	}
	/*
	 * checking if connection properties hashmap has the alias name as key
	 * or not
	 */
	if (!this.connectionProperties.containsKey(strAlias)) {
	    System.out.println("no such alias key: " + strAlias);
	    return null;
	}

	ConnectionParameters cps = (ConnectionParameters) this.connectionProperties
		.get(strAlias);
	OracleXADataSource ds = null;
	

	    if (this.dataSourcesXA.containsKey(strAlias)) {

		System.out
			.println("XA datasource already exist()->" + strAlias);
		ds = (OracleXADataSource) this.dataSourcesXA.get(strAlias);
		xaConnMap.put(strAlias, ds.getXAConnection());
		xaConnMap1.put(strAlias, cps.getUrl());

	    } else {
		System.out.println("new XA datasource created()->" + strAlias);
		ds = new oracle.jdbc.xa.client.OracleXADataSource();
		ds.setUser(cps.getUserName());
		ds.setPassword(cps.getPassword());
		ds.setURL(cps.getUrl());
		this.dataSourcesXA.put(strAlias, ds);
		xaConnMap.put(strAlias, ds.getXAConnection());
		xaConnMap1.put(strAlias, cps.getUrl());
	    }

	return ds;
    }

    /**
     * UnRegister the XAResource with the composite transaction
     * 
     * @param tx
     * @throws Exception
     */
    public synchronized void delistAllMasterResource(Transaction tx) throws Exception {

    	int i = 1;
    	String alias;
    	
    	 Iterator iter = xaConnMap1.entrySet().iterator();
    	    
    		while (iter.hasNext()) {
    			Map.Entry mEntry = (Map.Entry) iter.next();
    			System.out.println(mEntry.getKey() + " : " + mEntry.getValue());
    			
    			tx.delistResource(this.getXAConnection((String) mEntry.getKey()).getXAResource(),XAResource.TMSUCCESS);
    			
    			
    		}    
    	
    	

        }

    /**
     * closes all XAConnections enlisted in the composite transaction
     * 
     * @throws Exception
     */
    public void closeXAConnections() throws Exception {

	for (Map.Entry<String, XAConnection> entry : xaConnMap.entrySet()) {
	    entry.getValue().close();
	}

	xaConnMap.clear();
    }

    /**
     * closes all Connections enlisted in the composite transaction
     * 
     * @throws Exception
     */
    public synchronized void closeConnections() throws Exception {

	for (Map.Entry<String, XAConnection> entry : xaConnMap.entrySet()) {
	    entry.getValue().getConnection().close();
	}

    }

    /**
     * returns the XAConnection for the datasource alias
     * 
     * @param alias
     * @return
     */
    public XAConnection getXAConnection(String alias) {

	String strAlias = alias.toUpperCase();

	return this.xaConnMap.get(strAlias);
    }

    /**
     * initialise datasources for all HawkeyeMaster schemas
     * @throws SQLException 
     */
    public synchronized void initMasterSchemaDS() throws SQLException {
	int i = 1;
	String alias;
	while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + "" + i) != null) {

	    alias = DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + "" + i)
		    .toUpperCase();

	    initXADataSource(alias);

	    i = i + 1;
	}

    }

    /**
     * enlists all servers hosting HawkeyeMaster schema to the composite
     * transaction
     * 
     * @param tx
     * @throws Exception
     */
    public synchronized void enlistMasterResources(Transaction tx) throws Exception {

    	int i = 1;
    	String alias;
    	
    	//System.out.println("--------------start-------------------------");
    	//System.out.println(xaConnMap1);
    	//System.out.println("---------------end------------------------");
    	
    	Set<String> mySet = new HashSet<String>();

        for (Iterator itr = this.xaConnMap1.entrySet().iterator(); itr.hasNext();)
        {
            Map.Entry<String, String> entrySet = (Map.Entry) itr.next();

            String value = entrySet.getValue();
            String key = entrySet.getKey();
           // if(!key.contains("HAWKEYELOG"))
            if (!mySet.add(value))
            {
                itr.remove();               
            }
        }
        
        
        System.out.println("--------------tstart-------------------------");
    	//System.out.println(xaConnMap1);
    	
        
        Iterator iter = xaConnMap1.entrySet().iterator();
        
    	while (iter.hasNext()) {
    		Map.Entry mEntry = (Map.Entry) iter.next();
    		System.out.println(mEntry.getKey() + " :: " + mEntry.getValue());
    		
    		tx.enlistResource(this.getXAConnection((String) mEntry.getKey()).getXAResource());
    		
    		
    	}
    	
    	System.out.println("---------------tend------------------------");
    	
    	
      /*  
        
    	while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + "" + i) != null) {
    	    alias = DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + "" + i)
    		    .toUpperCase();
    	    if (this.getXAConnection(alias) != null) {
    	    	System.out.println("enlisting......."+alias);
    	    	
    	     	
    		tx.enlistResource(this.getXAConnection(alias).getXAResource());
    	    }
    	    
    	    

    	    i = i + 1;
    	    
    	    System.out.println("enlisting>>>>>"+i);

    	}*/
    	
    	
    	
    	
        }
    
    /**
     * returns Connection properties map
     * @return
     */
    public Map<String, List<String>> getConnectionProperties() {
	// TODO Auto-generated method stub
	return this.connectionProperties;
    }
    
/**
 * @param args
 */
/**
 * @param args
 */
public static void main(String[] args) {
		
    System.out.println("tesint.............");    	
    String text="MDHawkeye->HawkeyeMasteR";
    String patternString = "^(MDHawkeye->HawkeyeMaster)[0-9]{1,2}$";
    Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
    Matcher matcher = pattern.matcher(text);  
    System.out.println("matches   = " + matcher.matches());
	}

}
