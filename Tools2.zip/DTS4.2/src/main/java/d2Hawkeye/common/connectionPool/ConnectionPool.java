/**
 * File: ConnectionPool.java
 * @author Raj K Gaire
 * @version 3.2
 * @since April 19, 2004
 * Description:
 *  A servlet for connection pool with dbcp
 *  Modified:
 *  Sn:			Date:					By:				Comments:
 *
 * */
package d2Hawkeye.common.connectionPool;

import javax.servlet.*;
import javax.servlet.http.*;

import d2Hawkeye.common.connectionPool.dbcp.*;

/**
 * <p>Title: Connection Pool servlet</p>
 * <p>Description: The servlet load the xml file, creates the aliases and assigns to ConnectionPoolManager.</p>
 * @author Raj K Gaire
 * @version 1.0
 */
public class ConnectionPool
    extends HttpServlet {

  public ConnectionPool() {
  }

  public void init(ServletConfig conf) {
    try {
      String xmlFileName = conf.getInitParameter("XMLFileName");
      String isEncrypted = conf.getInitParameter("Encryption").equals("1") ?
          "1" : "0";
      conf.getServletContext().setAttribute("Encryption", isEncrypted);
      xmlFileName = conf.getServletContext().getRealPath(xmlFileName);
      ConnectionPoolXMLParser parser = new ConnectionPoolXMLParser();
      parser.setPassEncryption(isEncrypted);
      parser.loadDocument(xmlFileName);
      ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
      System.out.println("[ConnectionPool] XML Connection Pool Managere Loaded");
      System.out.println("[ConnectionPool] XML File=" + xmlFileName);
      pool.setAlias(parser.getAllAlias());
    }
    catch (Exception e) {}
  }
}
