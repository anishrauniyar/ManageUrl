/**
 * File: ConnectionPoolXMLParser.java
 * @author Raj K Gaire
 * @version 3.2
 * @since April 19, 2004
 * Description:
 *  A new XML parser for parsing ConnectionPoolManager.xml
 *  Modified:
 *  Sn:			Date:					By:				Comments:
 *
 * */
package d2Hawkeye.common.connectionPool;

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;

import org.w3c.dom.*;
import d2Hawkeye.common.*;

/**
 * <p>Title: Connection Pool XML Parser</p>
 * <p>Description: A new XML parser for parsing ConnectionPoolManager.xml</p>
 * @author Raj K Gaire
 * @version 3.2
 */
public class ConnectionPoolXMLParser {
  private File xmlFile;
  private Document doc = null;
  private HashMap alias = null;
  private String passEnc = "false";

  /**
   * default constructor
   */
  public ConnectionPoolXMLParser() {}

  /**
   * Constructor
   * @param fileName the xml fileName
   */
  public ConnectionPoolXMLParser(String fileName) {
    this.xmlFile = new File(fileName);
    this.loadDocument(this.xmlFile);
  }

  /**
   * Constructor
   * @param file xml file instance of ConnectionPoolManager.xml
   */
  public ConnectionPoolXMLParser(File file) {
    this.xmlFile = file;
    this.loadDocument(this.xmlFile);
  }

  /**
   * to be used as bean
   * @return XML File
   */
  public File getXmlFile() {
    return xmlFile;
  }

  /**
   * to be used as method, added for generic use
   * @return XML file
   */
  public File getXMLFile() {
    return xmlFile;
  }

  /**
   * to be used as bean
   * @param xmlFileName file name
   */
  public void setXmlFile(String xmlFileName) {
    this.xmlFile = new File(xmlFileName);
  }

  /**
   * to be used as instance method
   * @param xmlFileName file name
   */
  public void setXMLFileName(String xmlFileName) {
    this.xmlFile = new File(xmlFileName);
  }

  /**
   * loading xml document for parsing
   * @param fileName file name
   * @return true if loaded successfully
   */
  public boolean loadDocument(String fileName) {
    return this.loadDocument(new File(fileName));
  }

  /**
   * Overloaded method
   * @param file the file object
   * @return true if doc is loaded successfully
   */

  public void setPassEncryption(String enc) {
    this.passEnc = enc;
  }

  public boolean loadDocument(File file) {
    boolean loaded = false;
    this.xmlFile = file;
    if (!file.exists()) {
      System.out.println("File:" + file + " Not Found");
      return false;
    }
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    try {
      DocumentBuilder db = dbf.newDocumentBuilder();
      this.doc = db.parse(file);
      this.createAlias();
      loaded = true;
    }
    catch (Exception e) {
      this.doc = null;
      return false;
    }
    return loaded;
  }

  public HashMap getAllAlias() throws Exception {
    if (this.alias == null) {
      this.createAlias();
    }
    return this.alias;
  }

  public boolean isDocumentLoaded() {
    if (this.doc == null) {
      return false;
    }
    return true;
  }

  private void createAlias() throws Exception {
    if (!isDocumentLoaded()) {
      return;
    }
    this.alias = new HashMap();
    String encValue = "0";
    NodeList nl1 = null;
    try {
      nl1 = doc.getElementsByTagName("Encryption");
      if (nl1 != null) {
        encValue = doc.getElementsByTagName("Encryption").item(0).getFirstChild().
            getNodeValue();
      }
    }
    catch (Exception e) {

    }
    NodeList nl = doc.getElementsByTagName("Alias");
    int len = nl.getLength();
    for (int i = 0; i < len; i++) {
      ConnectionParameters params = new ConnectionParameters();
      Node node = nl.item(i);
//      System.out.println("Node: " + node);
      NamedNodeMap map = node.getAttributes();
      Node name, driver, user, pass, url, idleTime, maxCon, maxChk, chkTime;
      name = map.getNamedItem("name");
      if (name == null) {
        continue;
      }
      params.setName(name.getNodeValue());
      driver = map.getNamedItem("driver");
      if (driver != null) {
        params.setDriver(driver.getNodeValue());
      }
      user = map.getNamedItem("username");
      if (user != null) {
        params.setUserName(user.getNodeValue());
      }
      pass = map.getNamedItem("password");
      if (pass != null) {
        if (!encValue.trim().equals("0")) {
          params.setPassword(Base64Encoder.decode(pass.getNodeValue()));
        }
        else {
          params.setPassword(pass.getNodeValue());
        }
      }
      url = map.getNamedItem("url");
      if (url != null) {
        params.setUrl(url.getNodeValue());
      }
      idleTime = map.getNamedItem("idleTimeout");
      if (idleTime != null) {
        params.setIdleTimeOut(idleTime.getNodeValue());
      }
      maxCon = map.getNamedItem("maxConn");
      if (maxCon != null) {
        params.setMaxConnection(maxCon.getNodeValue());
      }
      chkTime = map.getNamedItem("checkoutTimeout");
      if (chkTime != null) {
        params.setCheckOutTimeOut(chkTime.getNodeValue());
      }
      maxChk = map.getNamedItem("maxCheckout");
      if (maxChk != null) {
        params.setMaxCheckOutTime(maxChk.getNodeValue());
      }
      this.alias.put(name.getNodeValue().toUpperCase().trim(), params);
    }

  }

  public ConnectionParameters getConnectionParametersByAliasName(String
      aliasName) {
    String alName = aliasName.toUpperCase().trim();
    if (!this.alias.containsKey(alName)) {
      return null;
    }
    ConnectionParameters params = (ConnectionParameters)this.alias.get(alName);
    return params;
  }
}