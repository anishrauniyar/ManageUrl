package d2Hawkeye.common;

import java.io.*;
import java.util.*;
public class Base64Encoder
{
	public static final String base64table="ABCDEFGHIJKLMNOPQRSTUVWXYZ"+
											"abcdefghijklmnopqrstuvwxyz"+
											"0123456789+/";


	public static String encode(byte[] buffer)
	{
System.out.println("------------>input"+new String(buffer));
        StringBuffer result=new StringBuffer();
		int state=0;
		int n=buffer.length;
		int index=0;
		for(int i=0;i<n;i++)
		{
			int c=buffer[i] & 0xff;
			switch(state)
			{
				case 0: 
					index=(c>>2) & 0x3F;
					result.append(base64table.charAt(index));
					index=(c<<4) & 0x30;
					break;

				case 1:
					index |= (c>>4) & 0x0F;
					result.append(base64table.charAt(index));
					index=(c<<2) & 0x3c;
					break;
				case 2:
					index |=(c>>6) & 0x03;
					result.append(base64table.charAt(index));
					index=c & 0x3F;
					result.append(base64table.charAt(index));
					break;

			}
			state=(state+1)%3;
		}
		switch(state)
		{
			case 0:
				break;
			case 1:
				result.append(base64table.charAt(index));
				result.append('=');
				result.append('=');
				break;
			case 2:
				result.append(base64table.charAt(index));
				result.append('=');
				break;
		}
System.out.println("-----output"+result.toString());
		return result.toString();
	}

	public static String decode(String buffer) throws IOException
	{
		if((buffer.length()%4)!=0)
			throw new IOException("Buffer length not multiple of four");
		int state=0;
		int ch=0;
		Vector result=new Vector();
		for(int i=0;i<buffer.length();i++)
		{
			int b=buffer.charAt(i);
			int p=base64table.indexOf(b);
			if(p==-1)
				if(b=='=')
					p=0;
				else
					throw new IOException("Invalid Character in input");
			switch(state)
			{
				case 0:
					ch=(p<<2) & 0xFC;
					break;
				
				case 1:
					ch |=((p>>4)& 0x03);
					result.addElement(new Integer(ch));
					ch=(p<<4) & 0xF0;
					break;
				case 2:
					ch|=(p>>2)& 0x0F;
					result.addElement(new Integer(ch));
					ch=(p<<6) & 0xc0;
					break;
				case 3:
					ch |= (p & 0x3F);
					result.addElement(new Integer(ch));
					break;

			}
			state=(state+1)%4;
		}

		int nPad=0;
		for(int i=buffer.length()-1;i>=0;i--)
		{
			char c=buffer.charAt(i);
			if(c=='=')
				nPad++;
			else 
				break;

		}
		int n=result.size()-nPad;
		if(n<0)
			n=0;
		byte[] bytes=new byte[n];
		for(int i=0;i<n;i++)
			bytes[i]=((Integer)result.elementAt(i)).byteValue();

		return new String(bytes);
	}

/*	public static void main(String[]args)throws IOException
	{
		
		byte[] input=new String("adm").getBytes();
		String encodedValue=encode(input);
System.out.println("Encoded Value= \t "+encodedValue);
		String output=decode(encodedValue);
System.out.println("Decoded Value= \t "+output);
		
	}
*/
}