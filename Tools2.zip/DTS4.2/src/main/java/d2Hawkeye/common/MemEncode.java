package d2Hawkeye.common;


import java.io.*;
import java.util.*;


public class MemEncode
{
  private static final char c5 = 0x35;
  private static final char c0 = 0x30;
  private static final char c9 = 0x39; 


  public static final String encode(String input)
  {
  StringBuffer sb = new StringBuffer();
    for(int i=0;i<input.length();i++)
    {
      char c=input.charAt(i);
      if(c >= c5 && c <= c9)
        c-=5;
      else if(c < c5 && c >= c0)
        c+=5;
      sb.append(c);
   }
     return sb.toString();
  }


/*  public static void main(String []args)
  {
   String input="31122987";
   System.out.println("original String"+"\t"+input);
   String sbb=encode(input);
   System.out.println("encoded String"+"\t"+sbb);
   String s=encode(sbb);
   System.out.println("decoded String"+"\t"+s);

  }
*/
}
