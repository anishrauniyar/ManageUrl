package d2Hawkeye.dts;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DownloadFile extends HttpServlet {
	
	public void init(ServletConfig config) throws ServletException {
	    super.init(config);
	}
	
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
     throws IOException, ServletException {
		String filename = (request.getParameter("filename") == null) ? "" :request.getParameter("filename");
		if(!filename.equals(""))	{
			try	{
				String filePath = new File(new File(".").getCanonicalPath()).toString()+System.getProperty("file.separator")+"Excel"+System.getProperty("file.separator")+filename;
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment; filename=" + filename);
				BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
                File file = new File(filePath);
                FileInputStream fis = new FileInputStream(file);
				byte[] contents = new byte[1024];
				int bytesRead = 0;
				while((bytesRead = fis.read(contents, 0, 1024)) != -1)	{
					bos.write(contents, 0, bytesRead);
				}
                fis.close();
                file.delete();
                bos.close();
            }
			catch(Exception ex)	{
				System.out.println("..exception at processRequest(request, response) in DownloadFileCommand : " + ex.getMessage());
			}
		}
	}
}
