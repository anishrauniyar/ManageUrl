/**
 * Source Tables are<br>
 * ztbl_DTS_Mapping_Source [tablename, fieldName, databaseId, fieldformat]
 * depends upon
 * ztbl_DTS_Mapping_Mast FKs=[category, keyfield],
 * ztbl_DTS_DTS_Set FKs=[clientId, dtsno, setno]
 * ztbl_DTS_Databases FKs=[databaseid, clientid]
 * */
package d2Hawkeye.dts;

public class DTSSources
    extends sqlBean {

  public DTSSources() {
  }

  public void cleanup() {}

  public void insertMappingMaster() { // depends upon Categories

  }

  public void getInfo() {}

  public void getInfo(String clientId) { // return source info based on parameter

  }

  public void getInfo(String clientId, String DTSNo) { // return source info based on parameter

  }

  public void getInfo(String clientId, String DTSNo, String setNo) { // return source info based on parameter

  }

  public void addMappingSource() {
  }
}
