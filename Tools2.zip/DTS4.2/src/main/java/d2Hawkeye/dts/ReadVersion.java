/**
 * Title:
 * Description:  Read data from text file
 * Copyright:    Copyright (c) 2004
 * Company:      ITEG
 * @author Niraj
 * @version 1.0
 */
package d2Hawkeye.dts;
import java.io.*;
public class ReadVersion {


  public String data;
  public String filename;
  public ReadVersion() {
  }

  /**
   * Reads version data from file specified
   * @param String filename
   * @return boolean
   */

  public boolean readFromFile()
  {
    try{
    DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(this.getFileName())));
    BufferedReader br=new BufferedReader(new InputStreamReader(in));
      data="";
      String s="";
      int linenumber=0;
      while((s=br.readLine())!=null)
      {
       if(linenumber>1)
        {
    	   	data+=s+"\n";
	    }
       linenumber++;
      }
      return true;
    }
    catch(Exception e){
      e.printStackTrace();
      return false;
    }

  }

  // Set version file name
  public void setFileName(String filename){
		this.filename=filename;
  }

  //get version file name
  public String getFileName(){
	  	return filename;
  }

 public static void main(String[] args)
 {
	ReadVersion rv=new ReadVersion();
	rv.setFileName("c:\\release.txt");
	if(rv.readFromFile())
	{
		System.out.println(rv.data);
	}
 }

}