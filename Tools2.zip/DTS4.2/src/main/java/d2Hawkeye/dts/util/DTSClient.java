/**
*DTSClient.java
*@author Ramesh Raj Baral
*@since Sep 21, 2011
*/
package d2Hawkeye.dts.util;

/**
 * @ClassName: DTSClient.java
 * @author: Ramesh Raj Baral
 * @since: Sep 21, 2011
 */
public class DTSClient {
	private String clientID;
	private String clientName;
	
	public DTSClient(String clientID,String clientName){
		this.clientID =clientID;
		this.clientName=clientName;
	}
	/**
	 * @return the clientID
	 */
	public String getClientID() {
		return clientID;
	}
	/**
	 * @param clientID the clientID to set
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	/**
	 * @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	
}
