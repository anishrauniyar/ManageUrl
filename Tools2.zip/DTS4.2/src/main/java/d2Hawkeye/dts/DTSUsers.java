/**********************************************************************************************
 * Author	: Pawan K Shrestha
 * Date		: Feb 24 2002
 * Purpose	:
 *
 *  Modifications
 *  S.N.		Date			By					Comments
 *    1.		03/05/2003		Pawan K Shrestha	Methods added
 *												a)getListOfClients
 *												b)getListOfCategories
 *
 *	 2.		03/14/2003		Pawan K Shrestha	Methods added
 *												a)removeUser
 *												b)getAccessRightsOfUser
 * 												c)getListOfUsers
 * 												d)checkValid
 *
 *   3.		04/21/2003		Pawan K Shrestha	All table names prefixed with "ztbl_DTS_"
 *   4.    06/06/2003    upendra pradhan   edited update query in method - addUpdateUser
 ***********************************************************************************************/
package d2Hawkeye.dts;

import java.sql.CallableStatement;
import java.util.*;

public class DTSUsers
    extends sqlBean {
  String strSQL;
  public DTSUsers() {

  }

  public void cleanup() throws Exception {}

  public boolean getListOfUserGroups() {
    strSQL = "SELECT * FROM ztbl_DTS_UserGroups ORDER BY GroupDesc";
    return getList(strSQL, "User Groups List");
  }


  public boolean getListOfClients(String clientID, String orderBy) {
    if (orderBy.equals("")) {
      orderBy = " ClientName";
    }
    strSQL = "SELECT * FROM ztbl_DTS_Clients ";
    String strWhere = " WHERE InUse = 'Y' ";
    if (!clientID.equals("")) {
      strWhere += " AND ClientID='" + clientID + "'";
    }
    strSQL = strSQL + strWhere + " ORDER BY " + orderBy;
    return getList(strSQL, "Clients List");
  }

  public boolean getListOfUsers(String userID) {
    strSQL = "select a.UserID,a.UserPassword,a.UserName,a.email,a.CreationDate, a.ExpiryDate";
    if (!userID.equals("")) {
      strSQL += ",b.UserGroup";
    }
    strSQL += " from ztbl_DTS_Users a ";
    if (!userID.equals("")) {
      strSQL += " LEFT JOIN ztbl_DTS_UsersAndGroups b ON UPPER(a.UserID)=UPPER(b.UserID) ";
    }
    strSQL += "WHERE a.UserID<>'sa' ";
    if (!userID.equals("")) {
      strSQL += " AND a.UserID='" + userID.trim().replaceAll("'","''") + "'";
    }
    strSQL += " ORDER BY a.UserName";
    return getList(strSQL, "Users list");
  }

  public boolean getAccessRightsOfUser(String userID) {
    strSQL = "SELECT c.UserGroup,c.AccessGroup,c.AllowAdd,c.AllowEdit,c.AllowView,c.AllowDelete,c.AllowApprove,c.AllowQcApprove,a.UserName " +
        " FROM ztbl_DTS_users a, ztbl_DTS_usersandgroups b, ztbl_DTS_AccessRights c WHERE a.UserID=b.UserID " +
        " AND b.UserGroup=c.UserGroup AND UPPER(a.userID)=UPPER('" + userID.replaceAll("'","''") + "')";
    return getList(strSQL, "Access rights of user");
  }

  public String checkValid(String loginName, String loginPassword) {
    String result = "n";
      /*
    String sql = "SELECT " +
              "CASE " +
              "WHEN b.USERID IS NULL THEN 'n' " +
              "WHEN (ExpiryDate>SYSDATE or ExpiryDate is NULL) THEN 'y' " +
              "ELSE 'e' " +
              "END MEMRESULT FROM " +
              "(SELECT '" + loginName.replaceAll("'", "''") + "' USERID FROM DUAL) a " +
              "LEFT JOIN " +
              "(SELECT x.USERID, x.EXPIRYDATE FROM ztbl_DTS_Users x, HEUSER.USR_USERS y WHERE "+
              "UPPER(x.USERID) = UPPER(y.LOGINNAME) AND " +
              "UPPER(y.LOGINNAME) = UPPER('" + loginName.replaceAll("'", "''") + "') AND " +
              "y.PWD = ora_hash('" + loginPassword.replaceAll("'", "''") + "')) b " +
              "ON a.USERID = b.USERID";
       */
    String sql = "SELECT " +
              "CASE " +
              "WHEN b.USERID IS NULL THEN 'n' " +
              "WHEN (ExpiryDate>SYSDATE or ExpiryDate is NULL) THEN 'y' " +
              "ELSE 'e' " +
              "END MEMRESULT FROM " +
              "(SELECT '" + loginName.replaceAll("'", "''") + "' USERID FROM DUAL) a " +
              "LEFT JOIN " +
              "(SELECT x.USERID, x.EXPIRYDATE FROM ztbl_DTS_Users x, HEUSER.USR_USERS y WHERE "+
              "UPPER(x.USERID) = UPPER(y.LOGINNAME) AND " +
              "D2PWD  = HEUSER.return_hash('" + loginName.replaceAll("'", "''") + "'||'" +
               loginPassword.replaceAll("'", "''") + "',D2KEY) ) b " +
              "ON a.USERID = b.USERID";

    //System.out.println("SQL: " + sql);
    this.executeQuery(sql);

    int rec = 0;
    if (this.moveNext()) {
      result = this.getData("MEMRESULT");
    }
    return result;
  }

    /**
     * This function is the same as above, just that it checks for just the user name. This is called when the application is called from OAM.
     * Date: Dec 2006
     * Author: Anjana Shrestha
     * @param loginName
     * @return
     */
    public String checkValidity(String loginName) {
        String result = "n";
        String sql =
            "select count(*) RecCount from ztbl_DTS_Users where UPPER(UserID) = UPPER('" + loginName.replaceAll("'","''") + "')";
        //System.out.println("SQL: " + sql);
        this.executeQuery(sql);

        int rec = 0;
        if (this.moveNext()) {
          rec = Integer.parseInt(this.getData("RecCount"));
            System.out.println("rec is " + rec);
          if (rec > 0) {
            result = "e";
            sql = "Select count(*) RecCount from ztbl_DTS_Users where UPPER(UserID) =UPPER('" + loginName.replaceAll("'","''") +
                "') AND  (ExpiryDate>SYSDATE or ExpiryDate is NULL) ";
              //System.out.println("SQL: " + sql);
            this.executeQuery(sql);
            if (this.moveNext()) {
              System.out.println("reccount next =" + this.getData("RecCount"));
              if (Integer.parseInt(this.getData("RecCount")) > 0) {
                result = "y";
              }
            }
          }
        }
        return result;
  }

  public boolean removeUser(String userID) {
    strSQL = "DELETE ztbl_DTS_UsersAndGroups WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
    this.execute(strSQL);
    strSQL = "DELETE ztbl_DTS_UsersAndClients WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
    this.execute(strSQL);
    strSQL = "DELETE ztbl_DTS_Users WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
    return this.execute(strSQL);
  }

  public String addUpdateUser(String userID, String userName, String password,
                              String email, String userGroups,
                              String expiryDate, String forEdit, String clients,
                              String incClients) {
    String retValue = "";
    String sql = ""; 
    //FOR ADDING NEW USER .. CHECK IF THE LOGIN NAME EXISTS - not required for editing
    if (forEdit.equals("")) {
      sql = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Users WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
      strSQL += "<BR>" + sql;
      this.executeQuery(sql);
      while (this.moveNext()) {
        if (this.getInt("RecCount") > 0) {
          retValue = "Login name already exists";
        }
      }
    }

    if (retValue.equals("")) {

      if (expiryDate.trim().equals("")) {
        expiryDate = "NULL";
      }
      else {
        expiryDate = "'" + expiryDate + "'";
      }

      if (forEdit.equals("")) {
        sql = "INSERT INTO ztbl_DTS_Users (UserID,UserPassword,UserName,CreationDate,ExpiryDate,eMail) " +
            " VALUES ('" +
            userID.trim().replaceAll("'","''") + "', pwdencrypt('" +
            password.trim().replaceAll("'","''") + "'),'" +
            userName.trim().replaceAll("'","''") +
            "',SYSDATE," +
            expiryDate + ",'" +
            email.trim().replaceAll("'","''") + "')";
        strSQL += "<BR>" + sql;
        this.execute(sql);
      }
      else {
        sql = "UPDATE ztbl_DTS_USERS SET";
        if (!password.equals("")) {
          sql += " UserPassword = pwdencrypt('" +
              password.trim().replaceAll("'","''") + "'),";
        }
        sql += " UserName = '" + userName.trim().replaceAll("'","''") + "',";
        sql += " eMail = '" + email.trim().replaceAll("'","''") + "',";
        sql += " ExpiryDate=" + expiryDate + " WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
        strSQL += "<BR>" + sql;
        this.execute(sql);
      }

      if (!forEdit.equals("")) {
        sql = "DELETE ztbl_DTS_UsersAndGroups WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
        strSQL += "<BR>" + sql;
        this.execute(sql);

        if (!incClients.equals("")) {
          sql = "DELETE ztbl_DTS_UsersAndClients WHERE UserID=UPPER('" + userID.trim() + "') AND ClientID NOT IN (" + incClients + ")";
          strSQL += "<BR>" + sql;
          this.execute(sql);
        }
      }

      if (!userGroups.trim().equals("")) {
    	 String sqldel = " DELETE FROM ztbl_DTS_UsersAndGroups  WHERE usergroup NOT IN ('D')  AND  USERID='" + userID.trim().replaceAll("'","''") +"' ";
        this.execute(sqldel);        
    	 StringTokenizer ug = new StringTokenizer(userGroups, ",");
        ug.nextToken();
        while (ug.hasMoreTokens()) {
          sql = "INSERT INTO ztbl_DTS_UsersAndGroups VALUES ('" +
              userID.trim().replaceAll("'","''") +
              "','" + ug.nextToken().toString().trim().replaceAll("'","''") +
              "')";
          strSQL += "<BR>" + sql;
          this.execute(sql);

        }
      }

      if (!clients.trim().equals("")) {
        StringTokenizer uc = new StringTokenizer(clients, ",");
        uc.nextToken();
         String clientID = "";

    	//try{
                while (uc.hasMoreTokens()) {
                    clientID = uc.nextToken().toString().trim();
                    sql = "MERGE INTO ztbl_DTS_UsersAndClients a USING (SELECT '" + userID.trim() + "'  USERID, '" +
                            clientID + "' CLIENTID FROM dual) b ON (a.USERID = b.USERID AND a.CLIENTID = b.CLIENTID) " +
                            " WHEN NOT MATCHED THEN INSERT VALUES (b.USERID, b.CLIENTID, NULL)";
                    strSQL += "<BR>" + sql;
                    this.execute(sql);


                   // sql = "sp_AddClientsToUser '" + clientID + "','" + userID.trim() + "'";

                    //strSQL += "<BR>" + sql;
                        //CallableStatement stmt = myConn.prepareCall("{call sp_AddClientsToUser (?,?)}");
                        //stmt.setString(1,clientID);
                        //stmt.setString(2,userID.trim());
                        //stmt.executeUpdate();
                       // stmt.close();
                }
        /*
        }catch(Exception e){
                System.out.println("ERROR calling sp_AddClientsToUser " + e.toString()+strSQL);
                this.addMessage("ERROR calling sp_AddClientsToUser " + e.toString());
            }
          */
            /***************************************************************************************/
      }

    }
    return retValue;
  }

  /*****************April 18 **************/
  public boolean changePassword(String userID, String oldPassword,
                                String newPassword) {
    boolean retValue = false;
    strSQL = "UPDATE ztbl_DTS_Users SET UserPassword=pwdencrypt('" +
        newPassword.trim().replaceAll("'","''") + "') WHERE UserID=UPPER('" + userID.trim().replaceAll("'","''") + "')";
    return this.execute(strSQL);
  }

  /*************** April 23 *******************/
  public boolean getDetailOfUserGroups(String userGroup) {
    strSQL =
        " SELECT a.UserGroup,a.GroupDesc,b.AccessGroup,b.AllowAdd,b.AllowEdit,"
        +
        " b.AllowView,b.AllowDelete,b.AllowApprove FROM ztbl_DTS_UserGroups a"
        + " INNER JOIN ztbl_DTS_AccessRights b ON a.UserGroup=b.UserGroup";
    if (!userGroup.equals("")) {
      strSQL += " WHERE a.UserGroup='" + userGroup + "'";
    }
    return getList(strSQL, "User Groups Detail");
  }

  public boolean getListOfAvailableUserGroupCodes(String userGroup) {
    strSQL = " SELECT UserGroup FROM ztbl_DTS_Alphabets WHERE UserGroup " +
        " NOT IN (SELECT UserGroup FROM ztbl_DTS_UserGroups) ORDER BY UserGroup";
    return getList(strSQL, "User Group Codes List");
  }

  public String getMaxGroupCode() {
    getListOfAvailableUserGroupCodes("");
    String gCode = "";
    try {
      if (moveNext()) {
        gCode = getData("UserGroup");
      }
    }
    catch (Exception e) {
      this.addMessage("[Error] " + e);
    }
    return gCode;
  }

  public boolean deleteGroup(String userGroup) {
    boolean retValue = false;
    strSQL = " DELETE ztbl_DTS_AccessRights WHERE UserGroup='" + userGroup +
        "'";
    if (this.execute(strSQL)) {
      strSQL = " DELETE ztbl_DTS_UserGroups WHERE UserGroup='" + userGroup +
          "'";
      retValue = this.execute(strSQL);
    }
    return retValue;
  }

  public boolean addUpdateUserGroup(String userGroup, String accessGroup,
                                    String groupDesc,
                                    String allowAdd, String allowEdit,
                                    String allowView,
                                    String allowDelete, String allowApprove,
                                    String addOrUpdate) {
      
      
    boolean retValue = false;
    if (addOrUpdate.equals("I")) {
      userGroup = getMaxGroupCode();
      if (!userGroup.equals("")) {
        strSQL = "INSERT INTO ztbl_DTS_UserGroups VALUES('" + userGroup
            + "','" + replaceString(groupDesc, "'", "''") + "')";
        if (this.execute(strSQL)) {

          strSQL = "INSERT INTO ztbl_DTS_AccessRights  (USERGROUP,ACCESSGROUP,ALLOWADD,ALLOWEDIT,ALLOWVIEW,ALLOWDELETE,ALLOWAPPROVE)  VALUES('" + userGroup
              + "','" + accessGroup + "','" + allowAdd + "','" + allowEdit
              + "','" + allowView + "','" + allowDelete + "','" + allowApprove +
              "')";
          
          System.out.println("sql="+strSQL);
          retValue = this.execute(strSQL);
          
        }
      }
      else {
        errorStr = "Cannot add group";
      }
    }
    else {
      strSQL = "UPDATE ztbl_DTS_UserGroups SET GroupDesc='" +
          replaceString(groupDesc, "'", "''") + "' WHERE UserGroup='" +
          userGroup + "'";
      if (this.execute(strSQL)) {

        strSQL = "UPDATE ztbl_DTS_AccessRights SET AccessGroup='" +
            accessGroup + "', AllowAdd='" + allowAdd + "', AllowEdit='" +
            allowEdit + "', AllowView='" + allowView + "', AllowDelete='" +
            allowDelete + "',AllowApprove='" + allowApprove +
            "' WHERE UserGroup='" + userGroup + "'";
        retValue = this.execute(strSQL);
      }
    }
    return retValue;
  }

  public boolean getListOfSelectedClients(String userID) {
    strSQL =
        "SELECT a.ClientID,b.ClientName,a.NotifyOn FROM ztbl_DTS_UsersAndClients a," +
        "ztbl_DTS_Clients b WHERE a.ClientID=b.ClientID AND a.UserID='" +
        userID +
        "' ORDER BY b.ClientName ";
    return getList(strSQL, "Selected clients of a user");
  }

  public boolean setNotifyOn(String userID, String clients, String notifyon) {
    boolean retVal = false;
    String sql = "";
    if (! (clients.trim().equals("") || notifyon.trim().equals(""))) {
      StringTokenizer c = new StringTokenizer(clients, ",");
      StringTokenizer n = new StringTokenizer(notifyon, ",");
      while (c.hasMoreTokens()) {
        sql = "UPDATE ztbl_DTS_UsersAndClients SET NotifyOn=" +
            n.nextToken().toString() + " WHERE UserID='" + userID +
            "' AND ClientID='" + c.nextToken().toString() + "'";

        strSQL += "<BR>" + sql;
        retVal &= this.execute(sql);
      }
    }
    return retVal;
  }
    /**
     * Desc: Returns all users belonging to Group group
     * Date: Dec 20, 2006
     * Author: Anjana Shrestha
     * @param group
     * @return
     */
    public boolean getUsersOfGroup(String group)
    {
        String str = "SELECT DISTINCT UserID from ztbl_DTS_UsersAndGroups a, ztbl_DTS_UserGroups b" +
                " where GroupDesc = '" +group+ "' and a.UserGroup = b.UserGroup";
        return getList(str, "Users of Group");
    }

    /**
     * Assigns a new client to user
     * Date: Dec 20, 2006
     * Author: Anjana Shrestha 
     * @param cid
     * @param uid
     */
    public void addClientToUser(String cid, String uid)
    {
      
    	/*String sql = "sp_AddClientsToUser '" + cid.trim() +
              "','" + uid.trim() + "'";
          
    	this.execute(sql);
        */  
          /**
           * Changes for migrating to oracle
           */
        	/***************************************************************************************/
          try{
                if(myConn==null){
                     this.makeConnection();
                }
                CallableStatement stmt = myConn.prepareCall("{call sp_AddClientsToUser (?,?)}");
                stmt.setString(1,cid.trim());
                stmt.setString(2,uid.trim());
                
                stmt.executeUpdate();
                stmt.close();
        	}catch(Exception e){
                System.out.println("ERROR calling sp_AddClientsToUser " + e.toString());
                this.addMessage("ERROR calling sp_AddClientsToUser " + e.toString());
            }
            /***************************************************************************************/
                	
    }
}
