package d2Hawkeye.dts;

/*******************************************************************************
 * Filename      : wordCOMWrapper.java
 * Description   : This class utilizes Java COM Wrappers to dispatch calls to MSWord(97/2000)
 *                 application to create a new Word document, mailmerge data from a text
 *                 datasource and save the merged file to disk.
 *                 Requires: jacob.jar, jacob.dll
 * Author        : Raj B.Thakuri (ITEG/KTM)
 * Created       : 12/02/2002
 /******************************************************************************/

import java.util.*;

import com.jacob.activeX.*;
import com.jacob.com.*;

public class wordCOMWrapper {
  private static String docsWordPath = ".\\"; //base path for Word documents
  private static String baseExcelPath = ".\\"; //base path for Text datasource

  static ActiveXComponent applicationWord;
  static Dispatch systemTasks;
  static Dispatch myDocuments;
  static Dispatch currentDocument;
  static boolean appWordOpen; // boolean var to flag open Word application

  public wordCOMWrapper(String docsPath, String xlsPath) {
    //set base documents and datasource paths
    docsWordPath = docsPath;
    baseExcelPath = xlsPath;
  }

  /** If a Word Application is open, return it's handle else open a new Word Application. */
  public static void openApplicationWord() {
    try {
      applicationWord = new ActiveXComponent("Word.Application");
      appWordOpen = false;
      systemTasks = Dispatch.get(applicationWord, "Tasks").toDispatch();
      int countOpenApps = Dispatch.get(systemTasks, "Count").toInt();
      Vector indexApplicationWord = new Vector();

      for (int i = countOpenApps; i >= 1; i--) {
        Dispatch taskTemp = Dispatch.call(systemTasks, "Item", new Variant(i)).
            toDispatch();
        String applicationName = Dispatch.get(taskTemp, "Name").toString();
        if (applicationName.equals( (String) "Microsoft Word")) {
          indexApplicationWord.add(new Integer(i));
        }
      }

      int countWordApps = indexApplicationWord.size();
      appWordOpen = countWordApps >= 2; //more than one Word App open?
      int[] tableIndexApplicationWord = new int[countWordApps];
      for (int j = 0; j < countWordApps; j++) {
        tableIndexApplicationWord[j] = ( (Integer) indexApplicationWord.
                                        elementAt(j)).intValue();
      }

      System.out.println("Word Application open? " + appWordOpen);
      if (appWordOpen) {
        System.out.println("A Word Application is already open.");
      }
      else {
        System.out.println("A new Word Application has been opened.");
      }
    }
    catch (Exception e) {
      System.out.println("Could not create new Word Application :");
      e.printStackTrace();
    }

    try {
      myDocuments = Dispatch.get(applicationWord, "Documents").toDispatch();
      String nameDoc;
      System.out.println("Documents already open in the application :");
      int numOpenDocs = Dispatch.get(myDocuments, "Count").toInt();
      for (int i = 1; i <= numOpenDocs; i++) {
        Dispatch documentTemp = Dispatch.call(systemTasks, "Item",
                                              new Variant(i)).toDispatch();
        nameDoc = Dispatch.get(documentTemp, "Name").toString();
        System.out.println("	document " + i + " -> " + nameDoc);
      }
    }
    catch (Exception e) {
      System.out.println("Error getting active documents: ");
      e.printStackTrace();
    }
  }

  /** Initialize Word Application:  visibility */
  public static void initializeApp() {
    try {
      Dispatch.put(applicationWord, "Visible", new Variant(false));
    }
    catch (Exception e) {
      System.out.println("Could not open Word application  ->");
      e.printStackTrace();
    }
  }

  /** Open Word document.*/
  public static Dispatch openDocument(String documentPath, String nameDocument) {
    Dispatch myDocument = new Dispatch();
    boolean docAlreadyOpen = false;
    String cheminDocument = documentPath + nameDocument;
    if (documentPath == "" | nameDocument == "") {
      try {
        myDocument = Dispatch.call(myDocuments, "Add").toDispatch();
      }
      catch (Exception e) {
        System.out.println("Error opening new document.");
        e.printStackTrace();
      }
    }
    else {
      try {
        String nameDoc;
        int numOpenDocs = Dispatch.call(myDocuments, "Count").toInt();
        if (numOpenDocs == 0) {
          System.out.print(" No open documents.");
        }
        else {
          for (int i = 1; i <= numOpenDocs; i++) {
            nameDoc = Dispatch.call(myDocuments, "Item", new Variant(i)).
                toString();
            System.out.println("	document " + i + " -> " + nameDoc);
            if (nameDoc.equals(nameDocument)) {
              System.out.println("         Document open :" + nameDoc);
              docAlreadyOpen = true;
            }
          }
        }
        if (docAlreadyOpen) {
          myDocument = Dispatch.call(myDocuments, "Item",
                                     new Variant(nameDocument)).toDispatch();
          Dispatch.call(myDocument, "Activate");
        }
        else {
          myDocument = Dispatch.call(myDocuments, "Open",
                                     new Variant(cheminDocument)).toDispatch();
        }
      }
      catch (Exception e) {
        e.printStackTrace();
        System.out.println("Error opening document : " + cheminDocument);
      }
    }

    return myDocument;
  }

  public static void saveAsText(Dispatch monDocument, String documentSavePath) {
    try {
      Variant True = new Variant(true);
      Variant False = new Variant(false);
      Variant OutFileName = new Variant(documentSavePath);
      final int wdFormatDocument = 4;
      Variant FileFormat = new Variant(wdFormatDocument);
      Variant LockComments = False;
      Variant Password = new Variant("");
      Variant AddToRecentFiles = True;
      Variant WritePassword = new Variant("");
      Variant ReadOnlyRecommended = False;
      Variant EmbedTrueTypeFonts = False;
      Variant SaveNativePictureFormat = False;
      Variant SaveFormsData = False;
      Variant SaveAsAOCELetter = False;

      Dispatch.callN(monDocument, "SaveAs", new Variant[] {OutFileName,
                     FileFormat, LockComments, Password, AddToRecentFiles,
                     WritePassword, ReadOnlyRecommended, EmbedTrueTypeFonts,
                     SaveNativePictureFormat, SaveFormsData, SaveAsAOCELetter});

    }
    catch (Exception e) {
      System.out.println("Error saving document : " + monDocument.toString() +
                         " in " + documentSavePath + "!");
      e.printStackTrace();
    }

  }

  /** Save Word document */
  public static String saveDocument(Dispatch monDocument,
                                    String documentSavePath) {
    String savedDocument = "";
    if (documentSavePath == "") {
      try {
        savedDocument = new String(docsWordPath + "DocSaved_" +
                                   (new Date()).getTime() + ".doc");
        Dispatch.call(monDocument, "SaveAs", new Variant(savedDocument));
        System.out.println("Document saved : " + savedDocument);
      }
      catch (Exception e) {
        System.out.println("Error saving document : " + monDocument.toString() +
                           " in c:");
        e.printStackTrace();
      }
    }
    else {
      try {
        Dispatch.call(monDocument, "SaveAs", documentSavePath);
        System.out.println("Document saved  : " + documentSavePath);
      }
      catch (Exception e) {
        System.out.println("Error saving document : " + monDocument.toString() +
                           " in " + documentSavePath + "!");
        e.printStackTrace();
      }
    }
    return savedDocument;
  }

  /** create mailmerged document using datasource */
  public static Dispatch mergeDocument(Dispatch monDocument, String tablePath,
                                       String tableName) {
    Dispatch documentMerged = new Dispatch();
    try {
      Dispatch docForMerge = Dispatch.get(monDocument, "MailMerge").toDispatch();
      Variant[] mergeArgsXls = new Variant[] {
          new Variant(tablePath + tableName), //Filename
          new Variant(0), //Format
          new Variant(false), //ConfirmConversions
          new Variant(false), //ReadOnly
          new Variant(true), //LinkToSource
          new Variant(false), //AddToRecentFiles
          new Variant(""), //PasswordDocument
          new Variant(""), //PasswordTemplate
          new Variant(false), //Revert
          new Variant(""), //WritePasswordDocument
          new Variant(""), //WritePasswordTemplate
          new Variant(""), //Connection
          new Variant(""), //SQLStatement1
          new Variant(""), //SQLStatement2
      };

      Dispatch.callN(docForMerge, "OpenDataSource", mergeArgsXls);
      Dispatch.put(docForMerge, "Destination", new Variant(0));
      Dispatch.call(docForMerge, "Execute");
      documentMerged = Dispatch.get(applicationWord, "ActiveDocument").
          toDispatch();
    }
    catch (Exception e) {
      System.out.println("Error merging document! ");
      e.printStackTrace();
    }

    return documentMerged;
  }

  /** Closes an open document */
  public static void closeDocument(Dispatch monDocument) {
    int wdDoNotSaveChanges = 0; //set to 1 to save changes before closing
    try {
      Dispatch.call(monDocument, "Close", new Variant(wdDoNotSaveChanges));
    }
    catch (Exception e) {
      System.out.println("Error closing document!");
      e.printStackTrace();
    }
  }

  /** Closes the Word Application */
  public static void quitWordApplication() {
    int wdDoNotSaveChanges = 0;
    try {
      Dispatch.call(applicationWord, "Quit", new Variant(wdDoNotSaveChanges));
    }
    catch (Exception e) {
      System.out.println("Error closing Word Application.");
      e.printStackTrace();
    }
  }

  /** Merge document with specified datasource and return the merged document path + name */
  public static String mergeToNewDocument(String documentPath,
                                          String nameDocument, String tablePath,
                                          String tableName) {
    String mergedDocument = "";
    ComThread.InitSTA();
    openApplicationWord();
    initializeApp();
    Dispatch documentMerged = new Dispatch();
    currentDocument = openDocument(documentPath, nameDocument);
    documentMerged = mergeDocument(currentDocument, tablePath, tableName);
    mergedDocument = saveDocument(documentMerged, "");
    saveAsText(documentMerged, "C:\\testLetter.txt");
    closeDocument(currentDocument);
    closeDocument(documentMerged);
    quitWordApplication();
    ComThread.Release();
    return mergedDocument;
  }

  public static String mergeToNewDocument(String documentPath,
                                          String nameDocument, String tablePath,
                                          String tableName, String textName) {
    String mergedDocument = "";
    ComThread.InitSTA();
    openApplicationWord();
    initializeApp();
    Dispatch documentMerged = new Dispatch();
    currentDocument = openDocument(documentPath, nameDocument);
    documentMerged = mergeDocument(currentDocument, tablePath, tableName);
    mergedDocument = saveDocument(documentMerged, "");
    saveAsText(documentMerged, documentPath + textName);
    closeDocument(currentDocument);
    closeDocument(documentMerged);
    quitWordApplication();
    ComThread.Release();
    return mergedDocument;
  }

  /** Merge document with specified datasource and return the merged document path + name */
  public static void mergeToText(String documentPath, String nameDocument,
                                 String tablePath, String tableName,
                                 String textName) {
    String mergedDocument = "";
    Dispatch documentMerged = new Dispatch();
    System.out.println(documentPath);
    System.out.println(nameDocument);
    currentDocument = openDocument(documentPath, nameDocument);
    documentMerged = mergeDocument(currentDocument, tablePath, tableName);
//        mergedDocument          = saveDocument(documentMerged,"");
    saveAsText(documentMerged, documentPath + textName);
    closeDocument(currentDocument);
    closeDocument(documentMerged);
  }

  public static void startWordApp() {
    ComThread.InitSTA();
    openApplicationWord();
    initializeApp();
  }

  public static void stopWordApp() {
    quitWordApplication();
    ComThread.Release();
  }
}
