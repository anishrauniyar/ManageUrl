package d2Hawkeye.dts;

import java.util.ArrayList;
import java.util.List;
/**
 * 
 * @author rsah
 * @since Sep 27,2011
 *
 */
public class DTSSet {

	private int setID;
	private String setName;
	private List<String> categoryList;
	
	public int getSetID() {
		return setID;
	}
	public void setSetID(int setID) {
		this.setID = setID;
	}
	public String getSetName() {
		return setName;
	}
	public void setSetName(String setName) {
		this.setName = setName;
	}
	
	public List<String> getCategoryList() {
		if(categoryList==null)
			return new ArrayList<String>();
		return categoryList;
	}
	public void setCategoryList(List<String> categoryList) {
		this.categoryList = categoryList;
	}
}
