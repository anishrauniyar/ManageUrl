package d2Hawkeye.dts;

public class DTSSourceTableSpace
    extends sqlBean {

  public DTSSourceTableSpace() {

  }

  public void cleanup() {}

  public boolean getListOfAllTableAndFields() {
    this.addMessage("get List Of All Table And Fields");
    strSQL = "SELECT o.name TableName, c.name FieldName, t.name + '(' + CAST(c.prec AS VARCHAR(5)) + ')' "
        + " fieldFormat FROM sysobjects o JOIN syscolumns c ON c.id = o.id "
        + " JOIN systypes t ON t.xusertype = c.xusertype WHERE o.type = 'U' "
        + " AND o.name <> 'dtproperties'";
    return this.executeQuery(strSQL)!= null;
  }

  public boolean getListOfAllTargetTableAndFields() {
    this.addMessage("get List Of All Target Table And Fields");
    strSQL = "SELECT o.name TableName, c.name FieldName, t.name + '(' + CAST(c.prec AS VARCHAR(5)) + ')' "
        + " fieldFormat FROM sysobjects o JOIN syscolumns c ON c.id = o.id "
        + " JOIN systypes t ON t.xusertype = c.xusertype WHERE o.type = 'U' "
        + " AND o.name <> 'dtproperties' AND o.name LIKE 'ztbl_%' ";
    return this.executeQuery(strSQL)!= null;
  }

 public boolean getListOfAllTableAndFields(String databaseID) {
    this.addMessage("get List Of All Table And Fields");
     strSQL = "SELECT TABLE_NAME TableName, COLUMN_NAME FieldName, " +
              "CASE WHEN DATA_TYPE LIKE '%NUMBER%' AND DATA_PRECISION IS NOT NULL THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ',' || CAST((DATA_LENGTH-DATA_PRECISION) AS VARCHAR(5)) || ')' " +
              "WHEN DATA_TYPE LIKE '%CHAR%' OR DATA_TYPE LIKE '%NUMBER%'  THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ')' " +
              "ELSE DATA_TYPE END FROM ALL_TAB_COLS a, " +
             "(SELECT DATABASENAME FROM ztbl_DTS_Databases WHERE DATABASEID=" + databaseID + ") b " +
             "WHERE a.owner = b.DATABASENAME AND TABLE_NAME NOT LIKE '%$%'";
    return this.executeQuery(strSQL)!= null;
  }
}
