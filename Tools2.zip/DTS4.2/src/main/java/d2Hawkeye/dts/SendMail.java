/***************************************************************************************
 Filename: SendMail.java
 Creator : Pawan Shrestha
 Date    :

 Description:
 Methods in this class are called to create message object, fill required and optional parameters,
 fill mail server information and send.

 Modifications:
 Date:					Changed by:					Description

 ************************************************************************************************/
package d2Hawkeye.dts;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class SendMail {
  public SendMail() {

  }

  private boolean hasCCAddr = false;
  private InternetAddress[] ccAddrList;
  private InternetAddress[] toAddrList;
  private String errString = "";
  private String host = "smtpnj.d2hawkeye.net"; //hard-coded

  public String getError() {
    return errString;
  }

  public void setSMTPHost(String smtp) {
    host = smtp;
  }

  public String getSMTPHost() {
    return host;
  }

  public void setToAddresses(Vector toAddr) {
    try {

      toAddrList = new InternetAddress[toAddr.size()];
      for (int i = 0; i < toAddrList.length; i++) {
        toAddrList[i] = new InternetAddress(toAddr.elementAt(i).toString());
      }
    }
    catch (Exception e) {
      errString = e.toString();
    }

  }

  public void setCCAddresses(Vector ccAddr) {
    try {
      hasCCAddr = true;
      ccAddrList = new InternetAddress[ccAddr.size()];
      for (int i = 0; i < ccAddrList.length; i++) {
        ccAddrList[i] = new InternetAddress(ccAddr.elementAt(i).toString());
      }
    }
    catch (Exception e) {
      errString = e.toString();
    }

  }

  public boolean send(String from, String msgSubject, String msgText) {
    boolean msgSend = false;

    Properties props = new Properties();
    props.put("mail.smtp.host", host);
    props.put("mail.transport.protocol", "smtp");

    Session session = Session.getDefaultInstance(props, null);
    //Session session = Session.getDefaultInstance(System.getProperties(),null);

    //session.setDebug(debug);

    try {
      // create message object, fill required and optional parameters and send.
      Message msg = new MimeMessage(session);
      msg.setFrom(new InternetAddress(from));
      msg.setRecipients(Message.RecipientType.TO, toAddrList);

      //add cc addresses
      if (hasCCAddr) {
        msg.setRecipients(Message.RecipientType.CC, ccAddrList);
      }

      msg.setSubject(msgSubject);
      msg.setSentDate(new Date());
      msg.setText(msgText);
      msg.setHeader("Content-Type", "text/html");
      Transport.send(msg);
      msgSend = true;
      hasCCAddr = false;
    }
    catch (Exception e) {
      errString = e.toString();
    }

    return msgSend;
  }
}
