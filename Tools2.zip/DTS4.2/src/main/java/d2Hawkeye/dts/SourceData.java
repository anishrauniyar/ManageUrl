package d2Hawkeye.dts;

import java.util.*;

public class SourceData {
  public String clientID;
  public String fieldName;
  public String tableName;
  public Vector fieldNames = new Vector();
  public String businessRule;

  public SourceData(String id, String fn, String tn, Vector fns, String br) {
    clientID = id;
    fieldName = fn;
    tableName = tn;
    fieldNames = fns;
    businessRule = br;
  }
}
