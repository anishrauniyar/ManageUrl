package d2Hawkeye.dts.fileUpload;

import uk.ltd.getahead.dwr.WebContext;
import uk.ltd.getahead.dwr.WebContextFactory;

import javax.servlet.http.HttpSession;

import d2Hawkeye.dts.apTable.DatabaseOperator;
import d2Hawkeye.dts.apTable.TableValidator;

/**
 * Handles DWR progress requests. Progress requests should start after the upload request occurs. If
 * a request for progress is still made, this proxy should return an UploadStatus.STATUS_RETRY. If
 * the upload finished, the servlet should mark the finished upload by setting an UploadStatus object
 * on the session, in which case, the next progress request to this proxy should send that very same object.
 *
 * @author Marius Hanganu
 * @see ro.tremend.upload.UploadStatus
 * @see ro.tremend.upload.UploadServlet
 */
public class UploadProxy {

    public UploadStatus getStatus() {
        WebContext webCtx = WebContextFactory.get();
        HttpSession session = webCtx.getSession();

        // if status has been set by the UploadServlet, then return that status
        // this occurs when upload has finished and UploadServlet specify itself a termination status
        UploadStatus status = (UploadStatus) session.getAttribute(UploadServlet.UPLOAD_STATUS);
        if (status != null) {
            session.setAttribute(UploadServlet.UPLOAD_STATUS, null);
            return status;
        }

        // otherwise continue gathering info
        FileUploadListener.FileUploadStats fileUploadStats = (FileUploadListener.FileUploadStats) session.getAttribute(UploadServlet.FILE_UPLOAD_STATS);

        status = new UploadStatus();
        if (fileUploadStats != null) {
            long bytesProcessed = fileUploadStats.getBytesRead();
            long sizeTotal = fileUploadStats.getTotalSize();
            long percentComplete = (long) Math.floor(((double) bytesProcessed / (double) sizeTotal) * 100.0);
            long timeInSeconds = fileUploadStats.getElapsedTimeInSeconds();
            double uploadRate = bytesProcessed / (timeInSeconds + 0.00001);
            double estimatedRuntime = sizeTotal / (uploadRate + 0.00001);

            if (fileUploadStats.getBytesRead() < fileUploadStats.getTotalSize()) {
                status.setStatus(UploadStatus.STATUS_IN_PROGRESS);
                status.setBytesProcessed(bytesProcessed);
                status.setEstimatedRuntime(estimatedRuntime);
                status.setPercentComplete(percentComplete);
                status.setSizeTotal(sizeTotal);
                status.setTimeInSeconds(timeInSeconds);
                status.setUploadRate(uploadRate);
            } else {
                status.setStatus(UploadStatus.STATUS_OK);
            }

            if (fileUploadStats != null && fileUploadStats.getBytesRead() == fileUploadStats.getTotalSize()) {
                status.setStatus(UploadStatus.STATUS_OK);
            }
        } else {
            status.setStatus(UploadStatus.STATUS_RETRY);
        }
        return status;
    }
    
    
  
	
	/**
	 * Call table validator method of to check if table alreay exists and if the table name and column names are valid.
	 * This method is called by javascript while validating table parameters through DWR. 
	 * @param tblNCols  String array with TablePrefix at [0], tableName at [1] and then column names. 
	 * @param tempTblNKeyCols String array containing TempTableName at [0] and then list of primary key column numbers . 
	 * @return Strign array containing validation summary at index[0] and complete message at index [1].
	 */
	public String[] checkTableAndColumns(String[] tblNCols, String[] tempTblNKeyCols){
		return new TableValidator().checkTableAndColumns(tblNCols, tempTblNKeyCols);
	}
	
	/**
	 * Delete Hawkeyerule table
	 * @author Subash Devkota
	 * @param tableName
	 * @return
	 */
	public String deleteHRTable(String tableName){
		String result="";
		DatabaseOperator dbOper= new DatabaseOperator();
		dbOper.connectHawkeyRule();
		try{
			dbOper.dropTable(tableName);
			result="Table dropped successfully.";
		}catch(Exception e){
			result="Error dropping table: "+e.getMessage();
		}finally{
			dbOper.takeDown();
		}
		return result;
	}
	
}
