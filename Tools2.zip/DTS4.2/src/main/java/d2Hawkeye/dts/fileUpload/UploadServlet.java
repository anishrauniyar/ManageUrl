package d2Hawkeye.dts.fileUpload;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.missiondata.fileupload.MonitoredDiskFileItem;
import com.missiondata.fileupload.MonitoredDiskFileItemFactory;

import d2Hawkeye.dts.apTable.APTable;
import d2Hawkeye.dts.fileParser.*;

/**
 * This servlet is called only once when upload button is pressed. The actual progress requests are made
 * in UploadProxy.
 * UploadServlet starts monitoring the upload by setting some objects on the HTTP session so that
 * they'll be available to further periodic requests to UploadProxy. When finishing, it sets the status
 * of the upload on the session again, so that the very next progress request will know it has to stop.
 * <p/>
 * To ease the usage of this class as a decoupled module, unique identifiers can be associated to the
 * uploaded files. When finishing up, this servlet will make available on the session in a map, the FileItem
 * object under the key specified (the unique identifier passed)
 * <p/>
 * Originally from carsonm: http://blogs.missiondata.com/java/28/file-upload-progress-with-ajax-and-java-and-prototype/
 *
 * 
 */
public class UploadServlet extends HttpServlet {
    public static final String UPLOAD_STATUS = "uploadStatus";
    public static final String FILE_UPLOAD_STATS = "fileUploadStats";
    public static final String FILES_UPLOADED = "FILES_UPLOADED";
    public static final String UNIQUE_IDENTIFIER = "uniqueFileIdentifier";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        UploadStatus status = new UploadStatus();
        session.setAttribute(UploadServlet.UPLOAD_STATUS, null);
        
      //  System.out.println("Its here at the start of uploadServelet doPost method");
        try {
            FileUploadListener listener = new FileUploadListener(request.getContentLength());
            session.setAttribute(FILE_UPLOAD_STATS, listener.getFileUploadStats());
            FileItemFactory factory = new MonitoredDiskFileItemFactory(listener);
            ServletFileUpload upload = new ServletFileUpload(factory);
            
            List items = upload.parseRequest(request);
            boolean hasError = false;
            
            // process the files
            storeFileToDatabase(request, items);

            // one can retrieve the FileItem objects in a different servlet, using
            // List filesUploaded = (List) session.getAttribute(UploadServlet.FILES_UPLOADED);

            if (!hasError) {
                status.setStatus(UploadStatus.STATUS_OK);
            } else {
                status.setStatus(UploadStatus.STATUS_ERROR);
                status.setMessage("Could not process uploaded file. Please see log for details.");
            }
        }
        catch (Exception e) {
            status.setStatus(UploadStatus.STATUS_ERROR);
            status.setMessage(e.getMessage());
            e.printStackTrace();
        }
        session.setAttribute(UPLOAD_STATUS, status);
    }

    private void storeFileToDatabase(HttpServletRequest request, List items) {
        HttpSession session=request.getSession();
        
    	String quote=(String)session.getAttribute("quote");
        char quot='\'';
        if(quote!=null){
        	if(quote.equalsIgnoreCase("singleQuote"))
        		quot='\'';
        	if(quote.equalsIgnoreCase("doubleQuote"))
        		quot='\"';
        }
        
        	for(int i=0;i<items.size()-1;i++){
        	//	System.out.println("Items>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");	
                MonitoredDiskFileItem fileItem=(MonitoredDiskFileItem)items.get(i);
        		try{
        			
        			String fileName=fileItem.getName();
        			
        			// remove the path of the file in case of windows client. In linux client, path is automatically excluded.
        			if(fileName.indexOf("\\")>-1){
            			fileName=fileName.substring(fileName.lastIndexOf("\\")+1,fileName.length()-1);
        			}
        			fileName=fileName.substring(0,fileName.indexOf(".")); // remove the extension of the file.
        		//	System.out.println("fileName is"+fileName);
        			FileParser parser= new FileParser();
        			parser.setQUOTE(quot);
        			parser.setStartLine(0);
        			session.setAttribute("APTable", null);
        			
        			APTable apTable=parser.parseFileToTable(fileItem, getServletConfig());
        			String importLog=parser.getImportLog();
        			apTable.setTableName(fileName);
        			String clientId=(String)session.getAttribute("clientID");
        			apTable.setTablePrefix("HR_"+clientId+"_");
        			session.setAttribute("APTable", apTable);
        			System.out.println("APTable:"+apTable+" written to session");
        			session.setAttribute("ImportLog",importLog);
        			System.out.println("ImportLog  written to session");
        			
        			
        		}
        		catch(Exception e){
        			e.printStackTrace();
        		}
        	}
      
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
    
    /**
     * Write the content of the inputstream into the file specified
     * @param is
     * @param fileName
     */
    protected  void saveToFile(InputStream is, String fileName){
    	try{
    		BufferedReader in= new BufferedReader(new InputStreamReader(is));
    		System.out.println(in);
    		char[] cbuf= null;
    		int cnt=in.read(cbuf);
    		if(cnt!=-1){
    			File file = new File("filename");
    		    // Create file if it does not exist
    	        boolean success = file.createNewFile();
    			BufferedWriter out= new BufferedWriter(new FileWriter(fileName));
	    		System.out.println(out);
	    		out.write(cbuf);
	    		out.close();
    		}
    		in.close();
    		
    	}catch (Exception e){
    		e.printStackTrace();
    	}
    	
    }
    
    
    
    
    
    
    
}
