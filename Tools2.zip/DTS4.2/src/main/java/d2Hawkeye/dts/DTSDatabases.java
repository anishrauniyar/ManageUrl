package d2Hawkeye.dts;

import java.util.*;
import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

public class DTSDatabases
    extends sqlBean {

  public static String DATABASE_TABLE = "ztbl_DTS_Databases";
  public static String DATABASE_ID_FIELD = "DatabaseID";
  public static String DATABASE_FIELD = "DatabaseName";

  public static boolean DB_SELECT_BY_ID = false;
  public static boolean DB_SELECT_BY_VALUE = true;

  public DTSDatabases() {
  }

  public void cleanup() {}

  public HashMap getDatabaseInfo(String databaseName) {
    HashMap hm = null;
    String sql = "";
    sql += "select DatabaseId, ClientName, DatabaseName ";
    sql += "        from ztbl_DTS_Clients c,";
    sql += "        ztbl_DTS_Databases d";
    sql += " where c.clientId=d.clientid ";
    sql += " and d.databaseName='" + databaseName + "'";
//    sql += " order by ClientName";

      if (this.executeQuery(sql)!=null) {
        this.addMessage("[DTSDatabases] Info: Server Infomation obtained");
        if (this.moveNext()) {
          hm = new HashMap();
          hm.put(DTSDatabases.DATABASE_ID_FIELD, this.getData("DatabaseId"));
          hm.put(DTSClients.CLIENT_FIELD, this.getData("ClientName"));
          hm.put(DTSDatabases.DATABASE_FIELD, this.getData("DatabaseName"));
          hm.put(DTSServers.SERVER_FIELD, this.getData("ServerName"));
        }
        else {
          System.out.println("no next data");
          this.addMessage("[DTSDatabases] Info: no next data");
        }
      }
      else {
        System.out.println("no info obtained");
        this.addMessage("[DTSDatabases] Info: no info obtained");
      }
    return hm;
  }

  public HashMap getDatabaseInfo(int databaseId) {
    HashMap hm = null;
    String sql = "";
    sql += "select DatabaseId, ClientName, DatabaseName, '' ServerName ";
    sql += "        from ztbl_DTS_Clients c,";
    sql += "        ztbl_DTS_Databases d ";
    sql += " where c.clientId=d.clientid ";
    sql += " and d.databaseId=" + databaseId;
//    sql += " order by ClientName";
      //this.executeQuery(sql);

      if (this.executeQuery(sql)!=null) {
        //System.out.println("Server Infomation obtained >> " + sql);
        if (this.moveNext()) {
          hm = new HashMap();
          hm.put(DTSDatabases.DATABASE_ID_FIELD, this.getData("DatabaseId"));
          hm.put(DTSClients.CLIENT_FIELD, this.getData("ClientName"));
          hm.put(DTSDatabases.DATABASE_FIELD, this.getData("DatabaseName"));
          hm.put(DTSServers.SERVER_FIELD, this.getData("ServerName"));
        }
        else {
          System.out.println("no next data");
          this.addMessage("[DTSDatabases] Info: no next data");
        }
      }
      else {
        System.out.println("no info obtained");
        this.addMessage("[DTSDatabases] Info: no info obtained");
      }
    return hm;
  }

  public HashMap getDatabaseInfoByServerID(int serverId) {
    HashMap hm = null;
    String sql = "";
    sql += "select DatabaseId, ClientName, DatabaseName, ServerName ";
    sql += "        from ztbl_DTS_Clients c, ";
    sql += "        ztbl_DTS_Databases d, ";
    sql += "        ztbl_DTS_Servers s ";
    sql += "where c.clientId=d.clientid and ";
    sql += "        d.serverId=s.serverId ";
    sql += " and s.serverId=" + serverId;
//    sql += " order by ClientName";
    if (this.executeQuery(sql)!=null) {
      this.addMessage("[DTSDatabases] Server Infomation obtained");
      //System.out.println("Server Infomation obtained");
      while (this.moveNext()) {
        if (hm == null) {
          hm = new HashMap();
        }
        HashMap hmm = new HashMap();
        hmm.put(DTSDatabases.DATABASE_ID_FIELD, this.getData("DatabaseId"));
        hmm.put(DTSClients.CLIENT_FIELD, this.getData("ClientName"));
        hmm.put(DTSDatabases.DATABASE_FIELD, this.getData("DatabaseName"));
        hmm.put(DTSServers.SERVER_FIELD, this.getData("ServerName"));
        hm.put(this.getData("ClientName") + this.getData("DatabaseId"),
               hmm);
      }
      if (hm == null) {
        System.out.println("no next data");
        this.addMessage("[DTSDatabases] Info: no next data");
      }
    }
    else {
      System.out.println("no info obtained");
      this.addMessage("[DTSDatabases] Info: no info obtained");
    }
    return hm;
  }

  public HashMap getDatabaseInfoByClientID(int clientId) {
    HashMap hm = null;
    String sql = "";
    sql += "select DatabaseId, ClientName, DatabaseName \n";
    sql += "        from ztbl_DTS_Clients c, \n";
    sql += "        ztbl_DTS_Databases d \n";
    sql += "where c.clientId=d.clientid \n";
    sql += " and c.clientId=" + clientId;
//    sql += " order by ClientName";
    if (this.executeQuery(sql)!=null) {
      this.addMessage("[DTSDatabases] Database Infomation obtained");
      System.out.println("Database Infomation obtained");
      while (this.moveNext()) {
        if (hm == null) {
          hm = new HashMap();
        }
        HashMap hmm = new HashMap();
        hmm.put(DTSDatabases.DATABASE_ID_FIELD, this.getData("DatabaseId"));
        hmm.put(DTSClients.CLIENT_FIELD, this.getData("ClientName"));
        hmm.put(DTSDatabases.DATABASE_FIELD, this.getData("DatabaseName"));
        hmm.put(DTSServers.SERVER_FIELD, this.getData("ServerName"));
        hm.put(this.getData("ClientName") + this.getData("DatabaseId"),
               hmm);
      }
      if (hm == null) {
        System.out.println("no next data");
        this.addMessage("[DTSDatabases] Info: no next data");
      }
    }
    else {
      System.out.println("no info obtained");
      this.addMessage("[DTSDatabases] Info: no info obtained");
    }
    return hm;
  }

  public HashMap getDatabaseInfo() {
    HashMap hm = null;
    String sql = "";
    sql += "select DatabaseId, c.ClientID, ClientName, DatabaseName ";
    sql += "        from ztbl_DTS_Clients c,";
    sql += "        ztbl_DTS_Databases d ";
    sql += "where c.clientId=d.clientid ";
//    sql += " order by ClientName";
   // System.out.println("SQL:" + sql);
    if (this.executeQuery(sql)!=null) {
      System.out.println("Server Infomation obtained");
      while (this.moveNext()) {
        if (hm == null) {
          hm = new HashMap();
        }
        HashMap hmm = new HashMap();
        hmm.put(DTSDatabases.DATABASE_ID_FIELD, this.getData("DatabaseId"));
          hmm.put(DTSClients.CLIENT_ID_FIELD, this.getData("ClientID"));
        hmm.put(DTSClients.CLIENT_FIELD, this.getData("ClientName"));
        hmm.put(DTSDatabases.DATABASE_FIELD, this.getData("DatabaseName"));
        hmm.put(DTSServers.SERVER_FIELD, this.getData("ServerName"));
        hm.put(this.getData("ClientName") + this.getData("DatabaseId"),
               hmm);
      }
      if (hm == null) {
        System.out.println("no next data");
        this.addMessage("[DTSDatabases] Info: no next data");
      }
    }
    else {
      System.out.println("no info obtained");
      this.addMessage("[DTSDatabases] Info: no info obtained");
    }
    return hm;
  }

  public boolean insertDatabase(int serverId, String clientId,
                                String databaseName) {
    if (this.getDatabaseInfo(databaseName) != null) {
      System.out.println("Database Already Exist");
      this.addMessage("[DTSDatabases] Info: Database Already Exist");
      return false;
    }
    String sql =
        "insert into ztbl_DTS_Databases (ClientId, ServerId, DatabaseName) values ";
    sql += "('" + clientId + "',0, '" + databaseName.replaceAll("'","''") + "')";
    return this.execute(sql);
  }

  public boolean updateDatabase(int databaseId, String databaseName) {
    HashMap serverinfo = this.getDatabaseInfo(databaseId);
    if (serverinfo == null) {
      this.addMessage("[DTSDatabases] Info: database does not exist");
    }
    else {
      if (databaseName.equals(serverinfo.get(DTSDatabases.DATABASE_FIELD))) {
        this.addMessage("[DTSDatabases] Info: No change in values");
      }
      else {
        String sql = "update " + DTSDatabases.DATABASE_TABLE + " set " +
            DTSDatabases.DATABASE_FIELD + "='" + databaseName + "'" +
            " where " + DTSDatabases.DATABASE_ID_FIELD + "=" + databaseId + "";
        return this.execute(sql);
      }
    }
    return false;
  }

  public boolean deleteDatabase(int databaseId) {
    String sql = "Delete from " + DTSDatabases.DATABASE_TABLE + " where " +
        DTSDatabases.DATABASE_ID_FIELD +
        "=" + databaseId;
    return this.execute(sql);
  }

  public boolean deleteDatabaseByClientId(int clientId) {
    String sql = "Delete from " + DTSDatabases.DATABASE_TABLE + " where " +
        DTSClients.CLIENT_ID_FIELD +
        "=" + clientId;
    return this.execute(sql);
  }

  public boolean deleteDatabaseByServerId(int serverId) {
    String sql = "Delete from " + DTSDatabases.DATABASE_TABLE + " where " +
        DTSServers.ID_FIELD +
        "=" + serverId;
    return this.execute(sql);
  }

  public String getDatabasesInSelect() {
    return this.getDatabasesInSelect(false);
  }
  public String getDatabasesInSelect(boolean byValue) {
    String str2ret = "";
    DTSDatabases dbs = new DTSDatabases();
    HashMap hm = dbs.getDatabaseInfo();
    HashMap hmm;
    String keys[] = new String[hm.size()];
    hm.keySet().toArray(keys);
    for (int i = 0; i < keys.length; i++) {
      hmm = (HashMap) hm.get(keys[i]);
      if(byValue){
        str2ret += "<option value='" + hmm.get(DTSDatabases.DATABASE_FIELD) +
            "'>";
      }else{
        str2ret += "<option value='" + hmm.get(DTSDatabases.DATABASE_ID_FIELD) +
            "'>";
      }
      str2ret += hmm.get(DTSDatabases.DATABASE_FIELD);
      str2ret += "</option>\n";
    }
    return str2ret;
  }
// test the module - ramining

  public String getDatabaseInfoInJScript(String varName){
    String toRet = "";
    HashMap dbinfo = this.getDatabaseInfo();
    HashMap theMap = new HashMap();
    Vector mapKeys = new Vector();
    String [] keys = new String[dbinfo.size()];
    dbinfo.keySet().toArray(keys);
    for(int i=0; i<keys.length; ++i){
      HashMap hmm = (HashMap)dbinfo.get(keys[i]);
      String database = hmm.get(this.DATABASE_FIELD)+"";
      String server = hmm .get(DTSServers.SERVER_FIELD)+"";
      Vector v;
      if(theMap.containsKey(server)){
        v = (Vector)theMap.get(server);
      }else{
        v = new Vector();
        mapKeys.add(server);
        theMap.put(server, v);
      }
      v.add(database);
    }
    for(int i=0; i<mapKeys.size(); i++){
      String server = mapKeys.get(i).toString();
      toRet += varName+"['"+server+"']= new Array();\n";
      toRet += varName+"['"+server+"']=[";
      Vector databases = (Vector)theMap.get(server);
      String [] dbs = new String[databases.size()];
      databases.toArray(dbs);
      Arrays.sort(dbs);
      for(int j=0; j<dbs.length; j++){
        toRet +="'"+dbs[j]+"'";
        if(j<dbs.length-1){
          toRet+=", ";
        }else{
          toRet += "]; \n";
        }
      }
    }
    return toRet;
  }

  public Vector getDatabaseList(String server, String user, String pass){
    Vector result = new Vector();
    this.setDatabaseName("master");
    this.setDBServerName(server); //sets special connection
    try{
 	   if(this.makeConnection(this.DRIVER, this.makeURL(server, "master"), user, pass)){
    	    this.executeQuery("select Name from master..sysdatabases order by Name");
        	while(this.moveNext()){
	          result.add(this.getData("Name"));
    	    }
    	}
    }catch(Exception e){}
    Object O[] = result.toArray();
    Arrays.sort(O);
//    Vector v = new Vector(
    return result;
  }

  public Vector getTableList(String server, String user, String pass, String databaseName){
    Vector result = new Vector();
    this.setDatabaseName(databaseName);
    this.setDBServerName(server);// sets the special connection
    try{
	    if(this.makeConnection(this.DRIVER, this.makeURL(server, databaseName), user, pass)){
	        this.executeQuery("SELECT o.name TableName FROM sysobjects o WHERE o.type = 'U' ");
	        while(this.moveNext()){
	          result.add(this.getData("TableName"));
	        }
	    }
    }catch(Exception e){
      System.out.println("[DTSDatabase] Error: "+e);
      this.addMessage("[DTSDatabase] Error: "+e);
    }
    return result;
  }

  public Vector getTableList(String clientId){
    SortedSet result = new TreeSet();
    String sql = "SELECT o.name TableName FROM sysobjects o WHERE o.type = 'U'";
    if(clientId!=null && !"".equals(clientId))
      sql += " AND o.name like '%"+clientId+"%'";
    this.executeQuery(sql, ConnectionPoolManager.getInstance().
                      getConnection("MDHawkeye->HawkeyeRule".toUpperCase()));
    while(this.moveNext()){
      result.add(this.getData("TableName"));
    }
    Vector v = new Vector();
    v.addAll(result);
    return v;
  }

  public Vector getTableList(){
    return this.getTableList(null);
  }

  public void updateRules(String DatabaseName,
                          String ServerName, String User, String Password,
                          javax.servlet.http.HttpServletRequest req){
    this.debug(true);
    ConnectionPoolManager con = ConnectionPoolManager.getInstance();
//    this.makeConnection(this.DRIVER, this.makeURL("", ""), );
    DTSDatabases src = new DTSDatabases();
    try{
      src.myConn = con.getConnection(this.DRIVER,
                                     this.makeURL(ServerName, DatabaseName),
                                     User, Password);
    }catch(Exception e){

    }
    this.myConn = con.getConnection("MDHawkeye->HawkeyeRule".toUpperCase());

    Map map = req.getParameterMap();
    Object[] keys = map.keySet().toArray();
    Vector sources = new Vector();
    Map targets = new HashMap();
    Map actions = new HashMap();
    for(int i=0; i<keys.length; i++){
      String key = keys[i]+"";
      int index=-1;
      if(key.indexOf("table")!=-1){
        index = Integer.parseInt(key.substring(key.indexOf("[")+1, key.indexOf("]")));
      }else{
        continue;
      }
      if(index>-1){
        String theKey = req.getParameter("table["+index+"]");
        sources.add(theKey);
        targets.put(theKey, req.getParameter("rule["+index+"]"));
        actions.put(theKey, req.getParameter("action["+index+"]"));
      }
    }
    this.addMessage("Sources = "+sources);
    this.addMessage("Targets = "+targets);
    this.addMessage("Actions = "+actions);

// request finished
// getting structure of table from source
    for(int ijk=0; ijk<sources.size(); ijk++){ // for each source
      String theKey = sources.get(ijk).toString(), sql="";
      int act = Integer.parseInt(actions.get(theKey).toString());
      this.addMessage("Processing Source: "+theKey);
      this.addMessage("Action: "+act);
      sql = "SELECT distinct c.name FieldName, t.name Format, CAST(c.prec AS VARCHAR(5)) "+
          "AS FieldSize FROM sysobjects o "+
          "JOIN syscolumns c ON c.id = o.id "+
          "JOIN systypes t ON "+
          "t.xusertype = c.xusertype WHERE o.type = 'U' "+
          "AND o.name = '"+theKey.toString()+"'";
      src.executeQuery(sql, src.myConn);
      Vector fields = new Vector();
      Vector ffields = new Vector();
      while(src.moveNext()){
        fields.add(src.getData("FieldName"));
        if(src.getData("Format").indexOf("char")>-1){
          ffields.add(src.getData("Format") + "(" + src.getData("FieldSize") +
                       ")");
        }else{
          ffields.add(src.getData("Format"));
        }
      }
      // create new
      if(act==0){
        sql = "Create table ["+theKey+"](\n";
        for(int j=0; j<fields.size(); j++){
          sql += "["+fields.get(j).toString() + "] "+ffields.get(j).toString();
          if(j<fields.size()-1)
            sql += ", ";
          sql += "\n";
        }
        sql += ");";
        this.execute(sql, con.getConnection("MDHawkeye->HawkeyeRule".toUpperCase()));
      }
      // overwrite
      if(act==2){
        sql = "Delete from ["+targets.get(theKey)+"]";
        this.execute(sql, con.getConnection("MDHawkeye->HawkeyeRule".toUpperCase()));
      }
      // insert anyway
      // create linked server
      sql = "sp_addlinkedserver 'S1_instance1', '', 'MSDASQL', NULL, NULL, 'DRIVER={SQL Server};SERVER="+
          ServerName+";UID="+User+";PWD="+Password+"'";
      this.execute(sql, con.getConnection("MDHawkeye->HawkeyeMaster".toUpperCase()));
      sql = "sp_addlinkedsrvlogin 'S1_instance1', 'false', 'sa', '"+User+"', '"+Password+"'";
      this.execute(sql, con.getConnection("MDHawkeye->HawkeyeMaster".toUpperCase()));
      // completed creating linked server
      // insert data
      sql = "Insert into [" + (act==0?theKey:targets.get(theKey)) +"] "+
          "      Select * from S1_instance1.["+DatabaseName+"].dbo.["+theKey.toString() + "];";
      this.execute(sql, con.getConnection("MDHawkeye->HawkeyeRule".toUpperCase()));
      // insert data completed
      // drop linked server
      sql = "sp_droplinkedsrvlogin 'S1_instance1', 'sa'";
      this.execute(sql, con.getConnection("MDHawkeye->HawkeyeMaster".toUpperCase()));
      sql = "sp_dropserver 'S1_instance1'";
      this.execute(sql, con.getConnection("MDHawkeye->HawkeyeMaster".toUpperCase()));
    }
  }

  private void rough() {
    /***/
    int iClientId = 10;
    String DatabaseName = "", ServerName = "";
    DTSDatabases dtsDB = new DTSDatabases();
    HashMap hm = dtsDB.getDatabaseInfoByClientID(iClientId);

    /*
     http://localhost:7001/dtsSelectDB.jsp?clientID=028&dtsNo=3&clientName=ASR%20%3C028%3E
     */
    if (hm != null && hm.size() > 0) {
      DatabaseName = (String) hm.get(DTSDatabases.DATABASE_FIELD);
      ServerName = (String) hm.get(DTSServers.SERVER_FIELD);

    }
  }
}
