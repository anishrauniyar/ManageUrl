package d2Hawkeye.dts.dsm;

import java.sql.ResultSet;
import java.util.Vector;
import java.sql.ResultSetMetaData;


public abstract class DSMQueries extends d2Hawkeye.dts.sqlBean{
  /**
   * The client ID
   */
  private String clientID="";
  /**
   * Client name
   */
  private String clientName="";
  /**
   * Server Name where AsImported Date resides
   */
  private String server="";
  /**
   * Client database in the server
   */
  private String database="";
  /**
   * query step number
   */
  private String step="0";

  public String getClientID() {
    return clientID;
  }
  public void setClientID(String clientID) {
    this.clientID = clientID;
  }
  public String getClientName() {
    return clientName;
  }
  public String getServer() {
    return this.server;
  }
  public String getDatabase() {
    return this.database;
  }
  public void setClientName(String clientName) {
    this.clientName = clientName;
  }
  public void setServer(String server) {
    super.setDBServerName(server);
    this.server = server;
  }
  public void setDatabase(String database) {
    super.setDatabaseName(database);
    this.database = database;
  }
  public void setStep(String step) {
    this.step = step;
  }
  public String getStep() {
    return step;
  }

  /**
   * Default display result for any query based on the result and metadata
   * @param rs ResultSet
   * @return String
   */
  public String displayResult(ResultSet rs){
    StringBuffer result=new StringBuffer();
    Vector v = new Vector();
    result.append("<table>");
    try{
      ResultSetMetaData rsmd = rs.getMetaData();
      result.append("<tr>");
      for(int i=0; i<rsmd.getColumnCount(); i++){
        result.append("<th>");
        v.add(rsmd.getColumnName(i+1));
        result.append(v.get(i));
        result.append("</th>");
      }
      result.append("</tr>");
      boolean highlight=true;
      while(rs.next()){
        highlight = !highlight;
        if(highlight){
          result.append("<tr bgcolor='lightyellow'>");
        }else{
          result.append("<tr>");
        }
        for(int i=0; i<v.size(); i++){
          result.append("<td class='DataCell'>");
          result.append(rs.getString(v.get(i)+""));
          result.append("</td>");
        }
        result.append("</tr>");
      }
    }catch(Exception e){

    }
    result.append("</table>");
    return result.toString();
  }
  /**
   * Result in HTML table based on the query for current step
   * @return String
   */
  public String displayResult(){
    return this.displayResult(this.executeQuery());
  }
  /**
   * Result in HTML table based on the query for current step
   * @return String
   */
  public String displayResult(int step){
    return this.displayResult(this.executeQuery(this.getQuery(step)));
  }
  /**
   * Query String for current step
   * @return String
   */
  public String getQuery(){
    return this.getQuery(Integer.parseInt(this.step));
  }

  /**
   * Execute query based on current for the query string obtained by calling getQuery()
   * @return ResultSet
   */
  public ResultSet executeQuery(){
    return this.executeQuery(this.getQuery());
  }

  /**
   * Abstract method to be implemented by the extending classes to return appropriate query for given step
   * @param step int
   * @return String
   */
  public abstract String getQuery(int step);

  public void cleanup(){

  }
  /**
   * Finally take down the sql resources
   * @throws Throwable
   */
  public void finalize() throws Throwable{
    this.takeDown();
    super.finalize();
  }
}
