package d2Hawkeye.dts.dsm;

import java.util.*;
public class DSMQueriesClaims
    extends DSMQueries {
  public static final String table = "tbl_AsImported_Claims";
  public static final String AsPreparedServer = "washington";
  public static final String HawkeyeMasterDB = "hawkeyemaster";

  private HashMap reqFields = new HashMap();
  public Map getRequireFields(){return this.reqFields;}

  public String getAsPreparedProcCodeTable(){
    return "tbl_AsPrepared_"+this.getClientID()+"_ProcCodes";
  }
  /**
   * ID sequence for services billed; number can itemize each claim or each line on a claim.
   */
  private String claimID = "";
  /**
   * ID for employee
   */
  private String employeeNumber = "";

  /**
   *  date of birth for member in Mx data
   */
  private String memberDOB = "";
  /**
   * members' gender in Mx data
   */
  private String memberSex = "";

  /**
   * Type of service code for billing
   */
  private String typeOfServiceCode = "";

  /**
   * Location/setting healthcare was administered, HCFA standard
   */
  private String placeOfService = "";
  /**
   * Identifier for renderer of care, DEA, ME#, or homegrown
   */
  private String provID = "";

  /**
   * code for specialty/type provider rendering care
   */
  private String provSpecCode = "";
  /**
   * description for ProvSpecCode
   */
  private String provSpecDesc = "";
  /**
   *  Indicator of contract status between payer and provider
   *
   */
  private String networkInd = "";

  /**
   * Indicates if care rendered was within a patient's geography
   */
  private String oOAInd = "";

  /**
   * Code used to ID what was done in the setting
   */
  private String procedureCD = "";

  /**
   * Code for diagnosis, primary as opPlace_Of_Serviceed to secondary or tertiary
   */
  private String dxPrime = "";

  /**
   * Date care was initiated.
   */
  private String firstServiceDate = "";

  /**
   * Date care was terminated.
   */
  private String lastServiceDate = "";

  /**
   * Money value paid for services: Payer to Provider or payer to patient.
   */
  private String amountPaid = "";

  /**
   * Code identifying Network of contracted providers.
   */
  private String netID = "";

  /**
   * Description for Network of contracted providers.
   */
  private String netName = "";

  /**
   * Money value billed for services.
   */
  private String amountBilledMx = "";

  /**
   * Money value for patient's scheduled payment per benefits.
   */
  private String copayMx = "";

  /**
   * Money value for patient's responsibility per benefits.
   */
  private String deductAmtMx = "";

  /**
   * Money value for portion of bill deducted for payment due; per contract.
   */
  private String pPOSaveAmt;

  /**
   * Money value for patient's scheduled payment per benefits.
   */
  private String coinsAmt = "";

  /**
   * Money value for exlcluded dollars per limits set-up in contracting.
   */
  private String planExclusAmt = "";

  /**
   * Money value for dollars not paid per contract between payer and plan.
   */
  private String notAllowedAmt = "";

  /**
   * Date claim was received by payer.
   */
  private String claimRecvdDate = "";

  /**
   *  Date claims was paid/acted-on by payer.
   */
  private String claimPaidDate = "";

  public DSMQueriesClaims() {
    this.set();
  }

  public String getAmountBilledMx() {
    return amountBilledMx.equals("")?"**amountBilledMx**":this.amountBilledMx;
  }

  public void setAmountBilledMx(String amountBilledMx) {
    this.amountBilledMx = amountBilledMx;
  }

  public String getAmountPaid() {
    return amountPaid.equals("")?"**amountPaid**":this.amountPaid;
  }

  public void setAmountPaid(String amountPaid) {
    this.amountPaid = amountPaid;
  }

  public String getClaimID() {
    return claimID.equals("")?"**claimID**":this.claimID;
  }

  public void setClaimID(String claimID) {
    this.claimID = claimID;
  }

  public String getClaimPaidDate() {
    return claimPaidDate.equals("")?"**claimPaidDate**":this.claimPaidDate;
  }

  public void setClaimPaidDate(String claimPaidDate) {
    this.claimPaidDate = claimPaidDate;
  }

  public String getClaimRecvdDate() {
    return claimRecvdDate.equals("")?"**claimRecvdDate**":this.claimRecvdDate;
  }

  public void setClaimRecvdDate(String claimRecvdDate) {
    this.claimRecvdDate = claimRecvdDate;
  }

  public String getCoinsAmt() {
    return coinsAmt;
  }

  public void setCoinsAmt(String coinsAmt) {
    this.coinsAmt = coinsAmt;
  }

  public String getCopayMx() {
    return copayMx;
  }

  public void setCopayMx(String copayMx) {
    this.copayMx = copayMx;
  }

  public String getDeductAmtMx() {
    return deductAmtMx;
  }

  public void setDeductAmtMx(String deductAmtMx) {
    this.deductAmtMx = deductAmtMx;
  }

  public String getDxPrime() {
    return dxPrime;
  }

  public void setDxPrime(String dxPrime) {
    this.dxPrime = dxPrime;
  }

  public String getEmployeeNumber() {
    return employeeNumber;
  }

  public void setEmployeeNumber(String employeeNumber) {
    this.employeeNumber = employeeNumber;
  }

  public String getFirstServiceDate() {
    return firstServiceDate;
  }

  public void setFirstServiceDate(String firstServiceDate) {
    this.firstServiceDate = firstServiceDate;
  }

  public String getLastServiceDate() {
    return lastServiceDate;
  }

  public void setLastServiceDate(String lastServiceDate) {
    this.lastServiceDate = lastServiceDate;
  }

  public String getMemberDOB() {
    return memberDOB;
  }

  public void setMemberDOB(String memberDOB) {
    this.memberDOB = memberDOB;
  }

  public String getMemberSex() {
    return memberSex;
  }

  public void setMemberSex(String memberSex) {
    this.memberSex = memberSex;
  }

  public String getNetID() {
    return netID;
  }

  public void setNetID(String netID) {
    this.netID = netID;
  }

  public String getNetName() {
    return netName;
  }

  public void setNetName(String netName) {
    this.netName = netName;
  }

  public String getNetworkInd() {
    return networkInd;
  }

  public void setNetworkInd(String networkInd) {
    this.networkInd = networkInd;
  }

  public String getNotAllowedAmt() {
    return notAllowedAmt;
  }

  public void setNotAllowedAmt(String notAllowedAmt) {
    this.notAllowedAmt = notAllowedAmt;
  }

  public String getOOAInd() {
    return oOAInd;
  }

  public void setOOAInd(String oOAInd) {
    this.oOAInd = oOAInd;
  }

  public String getPlaceOfService() {
    return placeOfService;
  }

  public void setPlaceOfService(String placeOfService) {
    this.placeOfService = placeOfService;
  }

  public String getPlanExclusAmt() {
    return planExclusAmt;
  }

  public void setPlanExclusAmt(String planExclusAmt) {
    this.planExclusAmt = planExclusAmt;
  }

  public String getPPOSaveAmt() {
    return pPOSaveAmt;
  }

  public void setPPOSaveAmt(String pPOSaveAmt) {
    this.pPOSaveAmt = pPOSaveAmt;
  }

  public String getProcedureCD() {
    return procedureCD;
  }

  public void setProcedureCD(String procedureCD) {
    this.procedureCD = procedureCD;
  }

  public String getProvID() {
    return provID;
  }

  public void setProvID(String provID) {
    this.provID = provID;
  }

  public String getProvSpecCode() {
    return provSpecCode;
  }

  public void setProvSpecCode(String provSpecCode) {
    this.provSpecCode = provSpecCode;
  }

  public String getProvSpecDesc() {
    return provSpecDesc;
  }

  public void setProvSpecDesc(String provSpecDesc) {
    this.provSpecDesc = provSpecDesc;
  }

  public String getTypeOfServiceCode() {
    return typeOfServiceCode;
  }

  public void setTypeOfServiceCode(String typeOfServiceCode) {
    this.typeOfServiceCode = typeOfServiceCode;
  }

  public String getQuery(int step) {
    switch (step) {
      case 0:
        return "SELECT TOP 100 * FROM " + this.table;
      case 201:

//        --SN.2 ClaimNumber
//        ----Client-internal ID for medical charges billed. Varies largely FROM file to file.
//        ----Count distinct ClaimID_Mx and compare to record count
        return "SELECT count(DISTINCT " + this.getClaimID() + ") FROM " + this.table;
      case 202:

//        ----View SELECTed fields, ORDER BY ClaimID_Mx, analyze
        return "SELECT " + this.getClaimID() + ", left(" + this.getEmployeeNumber() +
            ", 9)+convert(varchar(50), " + this.getMemberDOB() +
            ",12) as memberid, " +
            this.getDxPrime() + ", " + this.getProcedureCD() + ", " + this.getAmountPaid() +
            "FROM " + this.table + " " +
            "ORDER BY " + this.getClaimID();
      case 301:

// --SN.3 MemberID
        return "SELECT DISTINCT TOP 100 " + this.getEmployeeNumber() + " FROM " +
            this.table;
      case 302:

//----Find Length of base member identifier(EmployeeNumber_Mx)
        return "SELECT len(" + this.getEmployeeNumber() + "), count(*) as recs " +
            "FROM " + this.table + " " +
            "GROUP BY len(" + this.getEmployeeNumber() + ") ORDER BY recs desc";
        //--SSNs are 9 in length, SSNs are your best chance for matches with Ex and Rx
      case 303:

//--View Concat
        return "SELECT DISTINCT left(" + this.getEmployeeNumber() +
            ", 9)+convert(varchar(50), " + this.getMemberDOB() +
            ", 12) as memberid " +
            "FROM " + this.table;
      case 304:

//----Count DISTINCT Members
        return "SELECT count(DISTINCT(left(" + this.getEmployeeNumber() +
            ", 9)+convert(varchar(50), " + this.getMemberDOB() +
            ", 12))) as members " +
            "FROM " + this.table;
      case 1601:

//        --SN.16 ServiceTypeCode
//        ----Highly non-standard billing code. Check file lay-out and look for non-medical types of
//        ----service, e.g. Rx or Dental. Count records by length.
        return "SELECT len("+this.getTypeOfServiceCode()+") as ServiceCodeType_Len, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getTypeOfServiceCode()+") " +
            "ORDER BY recs desc";
      case 1602:

//        --Check most common values
        return "SELECT "+this.getTypeOfServiceCode()+" as ServiceCodeType, count(*) as recs " +
            "FROM "+this.getTypeOfServiceCode()+" " +
            "GROUP BY "+this.getTypeOfServiceCode()+" " +
            " ORDER BY recs desc";
      case 1801:

//        --SN.18 PlaceOfServiceCode
//        ----This field must be the HCFA standard. View and then match to D2 master reference table.
        return "SELECT DISTINCT "+this.getPlaceOfService()+" as PlaceOfService " +
            "FROM "+this.table+" " +
            "ORDER BY PlaceOfService";
      case 1802:

//        --Count records by length; look for nulls or blanks.
        return "SELECT "+this.getPlaceOfService()+" as PlaceOfService, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY PlaceOfService " +
            "ORDER BY recs desc";
      case 1803:

//        --Match against master table: Check Sum of AmountPaid
        return "SELECT sum("+this.getAmountPaid()+" as AmountPaid) FROM "+this.table+" " +
            "where "+this.getPlaceOfService()+" in (SELECT HCFAPOSCode " +
            "FROM " + this.getServer() +
            "."+this.HawkeyeMasterDB+".dbo.tbl_Master_HCFAPOSCodes)";
      case 2001:

//        --SN.20 ProviderID
//        ----ID for renderer of care. Stanardized versions include DEA Number(7 characters with
//        ----two leading alphas) and ME Number(10 digits all numeric); TaxID Numbers are 9.
        return "SELECT DISTINCT Prov_ID FROM "+this.table;
      case 2002:

//        --Count recs by length
        return "SELECT len("+this.getProvID()+" as ProvID), count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getProvID()+") " +
            "ORDER BY recs desc";
      case 2003:
//        --Count Recs by Prov_ID, look for default IDs
        return "SELECT "+this.getProvID()+" as ProvID, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY "+this.getProvID()+" " +
            "ORDER BY recs desc";
      case 2201:
//        --SN.22 ProviderTypeCode
//        ----Provider's specialty or type of care rendered grouping.
//        ----Existing master reference table, washington.hawkeyemaster.dbo.tbl_Master_ProviderTypes
//        ----Master table has two columns for code matching: SourceProviderTypeCode(alpha,1-3 chars)
//        ----and ProviderTypeCode(numeric, 3 digits)
        return "SELECT DISTINCT "+this.getProvSpecCode()+" as ProvSpecCode FROM "+this.table;
      case 2202:
//        --Count by length
        return "SELECT len("+this.getProvSpecCode()+") as ProvSpecCode, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getProvSpecCode()+") " +
            "ORDER BY recs desc";
      case 2203:

//        --Match against Master ProviderTypes table:
//        ----First on SourceProviderTypeCode
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid FROM "+this.table+" " +
            "where "+this.getProvSpecCode()+" in (SELECT SourceProviderTypeCode " +
            "FROM "+this.AsPreparedServer+"."+this.HawkeyeMasterDB+".dbo.tbl_Master_ProviderTypes) ";
//        --Matching Ratio
//        --
      case 2204:

//        ----Next on ProviderTypeCode
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid FROM "+this.table+" " +
            "where "+this.getProvSpecCode()+" in (SELECT ProviderTypeCode " +
            "FROM "+this.AsPreparedServer+"."+this.HawkeyeMasterDB+".dbo.tbl_Master_ProviderTypes) ";
//        --Matching Ratio
//        --
      case 2601:
//        --SN.26 InNetwork
//        -----Code describing the contract status of the provider and payer of a claim.
//        --View
        return "SELECT DISTINCT "+this.getNetworkInd()+" as NtwrkIND FROM "+this.table;

      case 2602:
//        --Count recs by Network code
        return "SELECT "+this.getNetworkInd()+" as NtwrkIND, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY "+this.getNetworkInd()+" " +
            "ORDER BY recs desc";
//        --
//        --Business Rule:
//        ----set = 'Y' for claims paid as out-of-network; set = 'N' for claims paid as in-network.
//        ----Must be opPlace_Of_Serviceite InNetwork
      case 2701:

//        --SN.27 OutOfArea
//        ----Indicates that claim was file by a provider not within the geography of the patient's plan
//        --View
        return "SELECT DISTINCT "+this.getOOAInd()+" as OOAInd FROM "+this.table;
//        --
//        --Count recs by OOA_Ind
      case 2702:
        return "SELECT "+this.getOOAInd()+" as OOAInd, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY "+this.getOOAInd()+" " +
            "ORDER BY recs desc ";
//        --
//        --Business Rule:
//        ----set = 'Y' for claims paid as in-area; set = 'N' for claims paid as out-of-area.
      case 2901:
//        --SN.29 ProcCode
//        ----Procedure codes filed on claims. HCPC,CPT4,ICD9,Revenue,DRG and homegrown codes are all
//        ----Place_Of_Servicesible values in this field.
//        --View
        return "SELECT DISTINCT "+this.getProcedureCD()+" as ProcedureCD FROM "+this.table;
      case 2902:

//        --Sum AmountPaid by length
        return "SELECT len("+this.getProcedureCD()+") as ProcedureCD, sum("+this.amountPaid+") as AmountPaid " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getProcedureCD()+") " +
            "ORDER BY AmountPaid desc";
//        --
      case 2903:

//          --Check AmountPaid for matches against washington.hawkeyemaster.dbo.tbl_Master_ProcCodes
//              --and washington.palmercaycarefirst.dbo.tbl_AsPrepared_ICD9ProcCode
//        ----HCPC,CPT4,ICD9,Revenue,DRG and home-grown are all Place_Of_Servicesible values
//        --HCPC,CPT4
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.AsPreparedServer+"."+this.HawkeyeMasterDB+".dbo.tbl_Master_ProcCodes b " +
            "where a."+this.amountPaid+"=b.ProcCode";
//        --Ratio
//        --
      case 2904:

//        --ICD9
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.AsPreparedServer+".palmercaycarefirst.dbo.tbl_AsPrepared_ICD9ProcCode b " +
            "where a."+this.getProcedureCD()+"=b.ICD9ProcCode";
//        --Ratio
//        --
      case 2905:

//        --Homegrown
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.getAsPreparedProcCodeTable()+" b " +
            "where a."+this.getProcedureCD()+"=b.ProcCode ";
//        --Ratio
//        --
      case 2906:

//        --UB92RevenueCode
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.AsPreparedServer+"."+this.HawkeyeMasterDB+".dbo.tbl_Master_RevenueCodes b " +
            "where a."+this.getProcedureCD()+"=b.RevenueCode";
//        --Ratio
//        --
      case 2907:

//        --DRG Codes
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.AsPreparedServer+"."+this.HawkeyeMasterDB+".dbo.tbl_Master_DRGCodes b " +
            "where a."+this.getProcedureCD()+"=b.DRG_Code ";
//        --Ratio
//        --
      case 3301:

//        --SN.33 DiagCode
//        ----ICD9 or Homegrown code. This field should be populated with the primary diagnosis.
//        --View codes, look for decimals
        return "SELECT DISTINCT "+this.getDxPrime()+" as DxPrime FROM "+this.table;
      case 3302:

//        --Sum AmountPaid by length of dx_prime(ICD9 coddes are 2-5 in length without decimals)
        return "SELECT len("+this.getDxPrime()+") as DxPrime, sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getDxPrime()+") " +
            "ORDER BY AmountPaid desc";

//        --Check AmountPaid for matches against washington.hawkeyemaster.dbo.tbl_Master_DiagCodes
//        --and any AsPrepared tables FROM client
//        ----ICD9
      case 3303:
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.AsPreparedServer+"."+this.HawkeyeMasterDB+".dbo.tbl_Master_DiagCodes b " +
            "where a."+this.getDxPrime()+"=b.DiagCode ";
      case 3304:

//        ----Homegrown
        return "SELECT sum("+this.amountPaid+") as AmountPaid " +
            "FROM "+this.table+" a, "+this.getAsPreparedProcCodeTable()+" b " +
            "where a."+this.getDxPrime()+"=b.DiagCode ";

      case 37:

//        --SN.37 ServiceDate
//        ----Date care was provided.
//        ----View a count of records by month compare with cycle/reporting dates.
        return "SELECT convert(varchar,year("+this.getFirstServiceDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getFirstServiceDate()+")),2) as ServiceDate, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY convert(varchar,year("+this.getFirstServiceDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getFirstServiceDate()+")),2) " +
            "ORDER BY ServiceDate DESC";

      case 38:
//        --SN.38 FROMDate
//        ----Date care was started; same as ServiceDate.
//        ----View a count of records by month compare with cycle/reporting dates.
        return "SELECT convert(varchar,year("+this.getFirstServiceDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getFirstServiceDate()+")),2) as ServiceDate, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY convert(varchar,year("+this.getFirstServiceDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getFirstServiceDate()+")),2) " +
            "ORDER BY ServiceDate DESC";

      case 39:
//        --SN.39 ToDate
//        ----Date care was ended; discharge date for inpatient
//        ----View a count of records by month compare with cycle/reporting dates.
        return "SELECT convert(varchar,year("+this.getLastServiceDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getLastServiceDate()+")),2) as ToDate, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY convert(varchar,year("+this.getLastServiceDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getLastServiceDate()+")),2) " +
            "ORDER BY ToDate DESC";
      case 4101:

//        --SN.41 AmountPaid
//        ----Dollar amount paid to provider by payer for services rendered.
//        ----Sum for entire table
        return "SELECT sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table;
      case 4102:

//        ----Check for negative values in data, indicates presence of back-outs.
        return "SELECT count(*) as recs FROM "+this.table+" " +
            "where "+this.amountPaid+" < 0 ";
//        --
      case 47:

//        --SN.47 NetworkName
//        ----Identifies coalition of providers bound by agreement with payers
//        --SELECT and sum by AmountPaid
        return "SELECT "+this.getNetID()+" as NetID, "+this.getNetName()+" as Net_Name, sum("+this.getAmountPaid()+") as AmountPaid " +
            "FROM "+this.table+" " +
            "GROUP BY "+this.getNetID()+", "+this.getNetName()+" " +
            "ORDER BY AmountPaid desc";

      case 4801:

//        --SN.48 ClaimTypeCode
//        ----Uses Type of Service codes to assign one of the four values.
//        ----Highly non-standard billing code. Check file lay-out and look for non-medical types of
//        ----service, e.g. Rx or Dental. Count records by length.
        return "SELECT len("+this.getTypeOfServiceCode()+") as TypeOfServiceCode_Length, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getTypeOfServiceCode()+") " +
            "ORDER BY recs desc";
      case 4802:

//        --
//        --Count Recordds by code, sort desc
        return "SELECT TypeOfServiceCode,count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY TypeOfServiceCode " +
            "ORDER BY recs desc";
//        --Top 5
//        --
//        ----Business Rule:
//        ----Breaks the care renedered into four Place_Of_Servicesible codes: MED,RX,VIS,DEN
      case 64:

//        --SN.64 BilledAmount
//        ----Dollar amount billed by provider for services rendered.
//        ----Sum for entire table
        return "SELECT sum("+this.getAmountBilledMx()+") as Sum_AmountBilledMx " +
            "FROM "+this.table;
      case 65:

//        --SN.65 CopayAmount
//        ----Dollar amount paid by patient, per benefits.
//        ----Sum for entire table
        return "SELECT sum("+this.getCopayMx()+") as Sum_Copay " +
            "FROM "+this.table;

      case 66:

//        --SN.66 DeductibleAmount
//        ----Dollar amount paid by patient, per benefits.
//        ----Sum for entire table
        return "SELECT sum(Deduct_Amt_Mx) as Deduc " +
            "FROM "+this.table;

      case 67:

//        --SN.67 PPlace_Of_Serviceavings
//        ----Dollar amount discounted for payer in accordance with provider contracts.
//        ----Sum for entire table
        return "SELECT sum("+this.getPPOSaveAmt()+") as Sum_PPO_Save " +
            "FROM "+this.table;
      case 68:

//        --SN.68 Coinsurance
//        ----Dollar amount paid by patient, per benefits.
//        ----Sum for entire table
        return "SELECT sum("+this.getCoinsAmt()+") as Sum_Coins FROM "+this.table+"";
      case 69:

//        --SN.69 PlanLimitExclusion
//        ----Dollar amount not paid due to a limit referenced in the contract
//        ----Sum for entire table
        return "SELECT sum("+this.getPlanExclusAmt()+") as SumPlanExAmt " +
            "FROM "+this.table;
      case 70:

//        --SN.70 NotAllowed
//        ----Dollar amount not paid due per the contracting between plan and provider.
//        ----Sum for entire table
        return "SELECT sum("+this.getNotAllowedAmt()+") as Sum_NotAllowedAmt " +
            "FROM "+this.table;
      case 71:

//        --SN.71 ClaimRecDate
//        ----Date claim was received by the payer.
//        --Count recs by year_month and compare with cycle dates.
        return "SELECT convert(varchar,year("+this.getClaimRecvdDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getClaimRecvdDate()+")),2) as ClaimRecvdDate_Mx, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY convert(varchar,year("+this.getClaimRecvdDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getClaimRecvdDate()+")),2) " +
            "ORDER BY ClaimRecvedDate_Mx DESC";

      case 72:

//        --SN.72 ClaimPaidDate
//        ----Date claim was paid by the payer.
//        --Count recs by year_month and compare with cycle dates.
        return "SELECT convert(varchar,year("+this.getClaimPaidDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getClaimPaidDate()+")),2) as ClaimPaidDate, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY convert(varchar,year("+this.getClaimPaidDate()+"))+ " +
            "RIGHT('0'+convert(varchar,month("+this.getClaimPaidDate()+")),2) " +
            "ORDER BY 1";

      case 84:

//        --SN.84 BillType
//        ----Code seperating medical source of claim.
//        ----Type of Service code should lead to answer.
//        ----Highly non-standard billing code. Check file lay-out and look for non-medical types of
//        ----service, e.g. Rx or Dental. Count records by length.
        return "SELECT len("+this.getTypeOfServiceCode()+") as TypeOfServiceCode_Len, count(*) as recs " +
            "FROM "+this.table+" " +
            "GROUP BY len("+this.getTypeOfServiceCode()+")  " +
            "ORDER BY recs desc ";
//        ----Business Rule:
//        ---'P' = Physician; 'F' = Facility; 'A' = Allied Health Provider
      default:
        return null;
    }
  }

  public void cleanup() {

  }

  public void finalize() throws Throwable {
    this.takeDown();
    super.finalize();
  }

  private void set(){
    reqFields.put("employeeNumber", "Employee Number Identifier (SSN)");
    reqFields.put("memberDOB", "Member Date of Birth");
    reqFields.put("memberSex", "Member Sex");
    reqFields.put("typeOfServiceCode", "Type of Service Code");
    reqFields.put("placeOfService", "Place of Service Code");
    reqFields.put("provID", "Provider ID");
    reqFields.put("provSpecCode", "Provider Speciality Code");
    reqFields.put("provSpecDesc", "Provider Speciality Desc");
    reqFields.put("networkInd", "Network Indicator");
    reqFields.put("oOAInd", "OOA Indicator");
    reqFields.put("procedureCD", "Procedure Code");
    reqFields.put("firstServiceDate", "First Service Date");
    reqFields.put("lastServiceDate", "Last Service Date");
    reqFields.put("amountPaid", "Amount Paid");
    reqFields.put("netID", "Network ID");
    reqFields.put("netName", "Network Name");
    reqFields.put("amountBilledMx", "Amount Billed (Claim)");
    reqFields.put("copayMx", "Copay (Claim)");
    reqFields.put("deductAmtMx", "Deduct Amount (Claim)");
    reqFields.put("pPOSaveAmt", "PPO Save Amount");
    reqFields.put("coinsAmt", "Co Ins Amount");
    reqFields.put("planExclusAmt", "Plan Excluded Amount");
    reqFields.put("notAllowedAmt", "Not Allowed Amount");
    reqFields.put("claimPaidDate", "Claim Paid Date");
    reqFields.put("claimRecvdDate", "Claim Received Date");
  }

}
