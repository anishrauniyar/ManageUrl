package d2Hawkeye.dts.dsm;

//import java.sql.ResultSet;

public class DSMQueriesEligibilities extends DSMQueries{
  public static final String table="tbl_AsImported_Eligibilities";

  private String employeeNumber="";
  private String memberDOB="";
  private String effctvDate="";
  private String terminDate="";
  private String memberSex="";
  private String medCovEffDate="";
  private String medCovTermDate="";
  private String medCovInd="";
  private String rxCovEffDate="";
  private String rxCovTermDate="";
  private String rxCovInd="";
  private String denCovEffDate="";
  private String denCovTermDate="";
  private String denCovInd="";
  private String visCovEffDate="";
  private String visCovTermDate="";
  private String visCovInd="";
  private String sTDCovEffDate="";
  private String sTDCovTermDate="";
  private String sTDCovInd="";
  private String groupNumber="";
  private String groupName="";
  private String memberRelation="";
  private String memberNumber="";

  public DSMQueriesEligibilities() {
  }
  public String getDenCovEffDate() {
    return denCovEffDate==""?"(DenCovEffDate)":this.denCovEffDate;
  }
  public String getDenCovInd() {
    return denCovInd==""?"(DenCovInd)":this.denCovInd;
  }
  public String getDenCovTermDate() {
    return denCovTermDate==""?"(DenCovTermDate)":this.denCovTermDate;
  }
  public void setDenCovEffDate(String denCovEffDate) {
    this.denCovEffDate = denCovEffDate;
  }
  public void setDenCovInd(String denCovInd) {
    this.denCovInd = denCovInd;
  }
  public void setDenCovTermDate(String denCovTermDate) {
    this.denCovTermDate = denCovTermDate;
  }
  public String getEffctvDate() {
    return effctvDate==""?"(EffcvtDate)":this.effctvDate;
  }
  public void setEffctvDate(String effctvDate) {
    this.effctvDate = effctvDate;
  }
  public void setEmployeeNumber(String employeeNumber) {
    this.employeeNumber = employeeNumber;
  }
  public String getEmployeeNumber() {
    return employeeNumber==""?"(EmployeeNumber)":this.employeeNumber;
  }
  public String getGroupName() {
    return groupName;
  }
  public void setGroupName(String groupName) {
    this.groupName = groupName;
  }
  public String getGroupNumber() {
    return groupNumber==""?"(GroupNumber)":this.groupNumber;
  }
  public void setGroupNumber(String groupNumber) {
    this.groupNumber = groupNumber;
  }
  public String getMedCovEffDate() {
    return medCovEffDate==""?"(MedCovEffDate)":this.medCovEffDate;
  }
  public void setMedCovEffDate(String medCovEffDate) {
    this.medCovEffDate = medCovEffDate;
  }
  public String getMedCovInd() {
    return medCovInd==""?"(MedCovInd)":this.medCovInd;
  }
  public void setMedCovInd(String medCovInd) {
    this.medCovInd = medCovInd;
  }
  public String getMedCovTermDate() {
    return medCovTermDate==""?"(MedCovTermDate)":this.medCovTermDate;
  }
  public void setMedCovTermDate(String medCovTermDate) {
    this.medCovTermDate = medCovTermDate;
  }
  public String getMemberDOB() {
    return memberDOB==""?"(MemberDOB)":this.memberDOB;
  }
  public void setMemberDOB(String memberDOB) {
    this.memberDOB = memberDOB;
  }
  public String getMemberNumber() {
    return memberNumber==""?"(MemberNumber)":this.memberNumber;
  }
  public void setMemberNumber(String memberNumber) {
    this.memberNumber = memberNumber;
  }
  public String getMemberRelation() {
    return memberRelation==""?"(MemberRelation)":this.memberRelation;
  }
  public void setMemberRelation(String memberRelation) {
    this.memberRelation = memberRelation;
  }
  public String getMemberSex() {
    return memberSex==""?"(MemberSex)":this.memberSex;
  }
  public void setMemberSex(String memberSex) {
    this.memberSex = memberSex;
  }
  public String getRxCovEffDate() {
    return rxCovEffDate ==""?"(RxCovEffDate)":this.rxCovEffDate;
  }
  public String getRxCovInd() {
    return rxCovInd==""?"(RxCovInd)":this.rxCovInd;
  }
  public String getRxCovTermDate() {
    return rxCovTermDate==""?"(RxCovTermDate)":this.rxCovTermDate;
  }
  public String getSTDCovEffDate() {
    return sTDCovEffDate==""?"(STDCovEffDate)":this.sTDCovEffDate;
  }
  public String getSTDCovInd() {
    return sTDCovInd==""?"(STDCovInd)":this.sTDCovInd;
  }
  public String getSTDCovTermDate() {
    return sTDCovTermDate==""?"(STDCovTermDate)":this.sTDCovTermDate;
  }
  public String getTerminDate() {
    return terminDate==""?"(TerminDate)":this.terminDate;
  }
  public String getVisCovEffDate() {
    return visCovEffDate==""?"(VisCovEffDate)":this.visCovEffDate;
  }
  public String getVisCovInd() {
    return visCovInd==""?"(VisCovInd)":this.visCovInd;
  }
  public String getVisCovTermDate() {
    return visCovTermDate==""?"(VisCovTermDate)":this.visCovTermDate;
  }
  public void setVisCovTermDate(String visCovTermDate) {
    this.visCovTermDate = visCovTermDate;
  }
  public void setVisCovEffDate(String visCovEffDate) {
    this.visCovEffDate = visCovEffDate;
  }
  public void setVisCovInd(String visCovInd) {
    this.visCovInd = visCovInd;
  }
  public void setTerminDate(String terminDate) {
    this.terminDate = terminDate;
  }
  public void setSTDCovTermDate(String sTDCovTermDate) {
    this.sTDCovTermDate = sTDCovTermDate;
  }
  public void setSTDCovInd(String sTDCovInd) {
    this.sTDCovInd = sTDCovInd;
  }
  public void setSTDCovEffDate(String sTDCovEffDate) {
    this.sTDCovEffDate = sTDCovEffDate;
  }
  public void setRxCovTermDate(String rxCovTermDate) {
    this.rxCovTermDate = rxCovTermDate;
  }
  public void setRxCovInd(String rxCovInd) {
    this.rxCovInd = rxCovInd;
  }
  public void setRxCovEffDate(String rxCovEffDate) {
    this.rxCovEffDate = rxCovEffDate;
  }

  /**
   * Generate query for given step.
   * @param step int
   * @return String if step does not match to defined steps, returns null
   */
  public String getQuery(int step){
    switch(step){
      case 0:
        return "SELECT TOP 100 * FROM "+this.table;
      case 101:
        //--SN.1 MemberID
        //----View EmployeeNumber as it's the base of MemberID
        return "SELECT DISTINCT TOP 100 "+this.getEmployeeNumber()+" FROM "+this.table+" ";
      case 102:
        //----Find Length of base employee identifier(EmployeeNumber_Ex)
        //--SSNs are 9 in length, SSNs are your best chance for matches with Mx and Rx
        return "SELECT len("+this.getEmployeeNumber()+") AS fldLen, count(*) AS recs FROM "+
            ""+this.table+" GROUP BY len("+this.getEmployeeNumber()+") ORDER BY recs DESC ";
      case 103:
        //--View Concat
        return "SELECT DISTINCT TOP 100 left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12) AS memberid "+
            "FROM "+this.table+"";
      case 104:
        //----Count Distinct Members
        return "SELECT count(DISTINCT(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12))) AS members "+
            "FROM "+this.table+"";
      case 201:
        //--SN.2 EmployeeID
        //----View

        return "SELECT DISTINCT TOP 100 "+this.getEmployeeNumber()+" AS employeeid "+
            "FROM "+this.table+"";
      case 202:
        //----Count Distinct Employees
        return "SELECT count(DISTINCT(left("+this.getEmployeeNumber()+", 9))) AS employees "+
            "FROM "+this.table+"";
      case 3:
        //--SN.3 CurrentFlag
        //----Find # of members with max(TerminDate) after reporting start date
        return "SELECT count(DISTINCT(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12))) "+
            "AS members FROM "+this.table+" "+
            "WHERE (convert(varchar(50), "+getTerminDate()+", 23))>='2002-11-01' "+
            "or ("+getTerminDate()+" is null) "+
            "or ("+getTerminDate()+" = ' ')";
        //--Business Rule:
        //--If result = count of DISTINCT members from above then set CurrentFlag = 'Y'
        //--Else
        //--set CurrentFlag = 'N' for members WHERE max(TerminDate) < reporting_start_date and
        //--set CurrentFlag = 'Y' for members where max(TerminDate) >= reporting_start_date
      case 4:
        //--SN.4 SubscriberFlag
        //----Review file lay-out to ID field which will differentiate between subscriber and
        //--dependent.
        //--Check to make sure field is populated consistently
        return "SELECT "+this.getMemberRelation()+", count(*) AS recs "+
            "FROM "+this.table+" "+
            "GROUP BY "+this.getMemberRelation()+" "+
            "ORDER BY recs DESC";
        //------Business Rule: 'S' for Subscriber, 'D' for anyone getting coverage thru Subscriber
      case 17:
        //--SN.17 Gender
        //-----View Values
        return "SELECT "+this.getMemberSex()+", count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY "+this.getMemberSex()+" "+
            "ORDER BY members DESC ";
        //--If NULL or more than two DISTINCT values for MemberSex then rectify with data contact.
        //--If sum of DISTINCT member count my MemberSex > DISTINCT total members then investigate
        //--Business Rule:
        //----M = Male; F = Female
      case 18:
        //--SN.18 DOB
        //----Ensure that all MemberDOB_Ex are valid: count recs by length
        return "SELECT len(convert(varchar(50), "+this.getMemberDOB()+", 12)) AS length,  count(*) AS recs "+
            "FROM "+this.table+" "+
            "GROUP BY len(convert(varchar(50), "+this.getMemberDOB()+", 12)) "+
            "ORDER BY recs DESC";
      case 19:
        //--SN.19 MaxTermDate
        //--Take a quick count of members by 'yyyymm' termination date and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getTerminDate()+"))+RIGHT('0'+convert(varchar, month("+getTerminDate()+")), 2) AS TerminDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+getTerminDate()+"))+RIGHT('0'+convert(varchar, month("+getTerminDate()+")), 2) "+
            "ORDER BY TerminDate DESC";
        //----Business Rule:
        //------Set = max(TerminDate) for each DISTINCT member,  if null
        //------or blank set = '9999-99-99'
      case 24:
        //--SN.24 EffectiveDate
        //--Take a quick count of members by 'yyyymm' effective date and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getEffctvDate()+"))+RIGHT('0'+convert(varchar, month("+this.getEffctvDate()+")), 2) AS EffctvDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getEffctvDate()+"))+RIGHT('0'+convert(varchar, month("+this.getEffctvDate()+")), 2) "+
            "ORDER BY EffctvDate DESC";
      case 25:
        //        --SN.25 TerminationDate
        //--Take a quick count of members by 'yyyymm' termination date and compare with reporting dates
        return "SELECT convert(varchar, year("+getTerminDate()+"))+RIGHT('0'+convert(varchar, month("+getTerminDate()+")), 2) AS TerminDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+getTerminDate()+"))+RIGHT('0'+convert(varchar, month("+getTerminDate()+")), 2) "+
            "ORDER BY TerminDate DESC";
      case 26:
        //        --SN.26 MedCovEffctiveDate
        // --Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getMedCovEffDate()+"))+RIGHT('0'+convert(varchar, month("+this.getMedCovEffDate()+")), 2) AS MedCovEffDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getMedCovEffDate()+"))+RIGHT('0'+convert(varchar, month("+this.getMedCovEffDate()+")), 2) "+
            "ORDER BY MedCovEffDate DESC";
      case 27:
        //--SN.27 MedCovTerminationDate
        // --Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getMedCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getMedCovTermDate()+")), 2) AS MedCovTermDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getMedCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getMedCovTermDate()+")), 2) "+
            "ORDER BY MedCovTermDate DESC";
      case 28:
        //--SN.28 MedCovType
        //----View MedCovInd by count of members
        return "SELECT "+this.getMedCovInd()+",  count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY "+this.getMedCovInd()+" "+
            "ORDER BY members DESC ";
        //------Business Rule:
        //---------'S' = member has benefit; 'F' = member does not have benefit
      case 29:
        //--SN.29 RxCovEffctiveDate
        //--Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getRxCovEffDate()+"))+ RIGHT('0'+convert(varchar, month("+this.getRxCovEffDate()+")), 2) AS RxCovEffDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getRxCovEffDate()+"))+RIGHT('0'+convert(varchar, month("+this.getRxCovEffDate()+")), 2) "+
            "ORDER BY RxCovEffDate DESC";
      case 30:
        // --SN.30 RxCovTerminationDate
        // --Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getRxCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getRxCovTermDate()+")), 2) AS RxCovTermDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getRxCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getRxCovTermDate()+")), 2) "+
            "ORDER BY RxCovTermDate DESC";
      case 31:
        //--SN.31 RxCovType
        //----View RxCovInd by count of members
        return "SELECT "+this.getRxCovInd()+", count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY "+this.getRxCovInd()+" "+
            "ORDER BY members DESC";
        //------Business Rule:
        //---------'S' = member has benefit; 'F' = member does not have benefit
      case 32:
        //--SN.32 DentalCovEffctiveDate
        //--Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getDenCovEffDate()+"))+ RIGHT('0'+convert(varchar, month("+this.getDenCovEffDate()+")), 2) AS DenCovEffDate, "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getDenCovEffDate()+"))+RIGHT('0'+convert(varchar, month("+this.getDenCovEffDate()+")), 2) "+
            "ORDER BY DenCovEffDate DESC";
      case 33:
        //--SN.33 DentalCovTerminationDate
        //--Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getDenCovTermDate()+"))+ RIGHT('0'+convert(varchar, month("+this.getDenCovTermDate()+")), 2) AS DenCovTermDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getDenCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getDenCovTermDate()+")), 2) "+
            "ORDER BY DenCovTermDate DESC";
      case 34:
        //--SN.34 DentalCovType
        //----View DentalCovInd by count of members
        return "SELECT "+this.getDenCovInd()+", count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY "+this.getDenCovInd()+" "+
            "ORDER BY members DESC ";
        //------Business Rule:
        //---------'S' = member has benefit; 'F' = member does not have benefit
      case 35:
        //--SN.35 VisionCovEffectiveDate
        //--Take a quick count of members by 'yyyymm'and compare with reporting dates
        return " SELECT convert(varchar, year("+this.getVisCovEffDate()+"))+RIGHT('0'+convert(varchar, month("+this.getVisCovEffDate()+")), 2) AS VisCovEffDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getVisCovEffDate()+"))+ RIGHT('0'+convert(varchar, month("+this.getVisCovEffDate()+")), 2) "+
            "ORDER BY VisCovEffDate DESC";
      case 36:
        //--SN.36 VisionCovTerminationDate
        //--Take a quick count of members by 'yyyymm'and compare with reporting dates
        return "SELECT convert(varchar, year("+this.getVisCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getVisCovTermDate()+")), 2) AS VisCovTermDate,  "+
            "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY convert(varchar, year("+this.getVisCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getVisCovTermDate()+")), 2) "+
            "ORDER BY VisCovTermDate DESC";
      case 37:
        //--SN.37 VisionCovType
        //----View DentalCovInd by count of members
        return "SELECT "+this.getVisCovInd()+", count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
            "FROM "+this.table+" "+
            "GROUP BY "+this.getVisCovInd()+
            " ORDER BY members DESC ";
        //------Business Rule:
        //---------'S' = member has benefit; 'F' = member does not have benefit
    case 38:
      //--SN.38 STDCovEffctiveDate
      //--Take a quick count of members by 'yyyymm'and compare with reporting dates
      return "SELECT convert(varchar, year("+this.getSTDCovEffDate()+"))+RIGHT('0'+convert(varchar, month("+this.getSTDCovEffDate()+")), 2) AS STDCovEffDate,  "+
          "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
          "FROM "+this.table+" "+
          "GROUP BY convert(varchar, year("+this.getSTDCovEffDate()+"))+ RIGHT('0'+convert(varchar, month("+this.getSTDCovEffDate()+")), 2) "+
          "ORDER BY STDCovEffDate DESC";
    case 39:
      //--SN.39 STDCovTerminationDate
      //--Take a quick count of members by 'yyyymm'and compare with reporting dates
      return "SELECT convert(varchar, year("+this.getSTDCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getSTDCovTermDate()+")), 2) AS STDCovTermDate,  "+
          "count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
          "FROM "+this.table+" "+
          "GROUP BY convert(varchar, year("+this.getSTDCovTermDate()+"))+RIGHT('0'+convert(varchar, month("+this.getSTDCovTermDate()+")), 2) "+
          "ORDER BY STDCovTermDate DESC";
    case 40:
      //--SN.40 STDCovType
      //----View DentalCovInd by count of members
      return "SELECT "+this.getSTDCovInd()+", count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
          "FROM "+this.table+" "+
          "GROUP BY "+this.getSTDCovInd()+
          " ORDER BY members DESC ";
      //------Business Rule:
      //---------'S' = member has benefit; 'F' = member does not have benefit
    case 71:
      //--SN.71 RelationshipFlag
      //----Indicates member's relationship with employee/subscriber
      //------Count members by MemberRelation
      return "SELECT "+this.getMemberRelation()+", "+this.getMemberNumber()+", count(left("+this.getEmployeeNumber()+", 9)+convert(varchar(50), "+this.getMemberDOB()+", 12)) AS members "+
          "FROM "+this.table+" "+
          "GROUP BY "+this.getMemberRelation()+", "+this.getMemberNumber()+
          " ORDER BY members DESC";
      //--Business Rule:
      //----set = 'E' for employee or subscriber; set = 'S' for spouse; set = 'D' for dependent
    default:
      return null;
    }
  }
}
