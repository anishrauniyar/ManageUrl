package d2Hawkeye.dts;

import java.util.Hashtable;
import java.util.Vector;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;

/**
 * Created by IntelliJ IDEA.
 * User: pshrestha
 * Date: Apr 26, 2007
 * Time: 4:35:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class test
    extends sqlBean {
  public Hashtable listFieldNames = new Hashtable();
  public Hashtable listFieldFormats = new Hashtable();
  public String listFieldNames_1 = "";
  public String listFieldFormats_1 = "";

  public String listDatabaseNames = "";
  public String listTableNames = "";
  private String userForClient = "";
  public String dbMap = "";

  private Vector dbNames;
  private HashMap tbls;
  private HashMap flds;
  private HashMap ffor;
  public HashMap getInfo() {
    return this.ffor;
  }

  public test() {

  }

  public void cleanup() throws Exception {}

  public boolean executeQuery(String categoryID, String clientID,
                              String targetTableName, String dtsNo,
                              String dtsSetNo) {
    strSQL = "SELECT m.Category, m.SN, db.DatabaseId as SourceDBID, " +
        " db.DatabaseName as SourceDatabase, s.TableName AS SourceTable, " +
        " s.FieldName AS SourceField, s.FieldFormat AS SourceFieldFormat, " +
        " t.TableName AS TargetTable, t.KeyField AS TargetField, m.FieldFormat, " +
        " t.FieldName AS TargetField2Display, " +
        " r.BusinessRule, r.TranslatedRule, r.Example, x.FieldName as Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m " +
        " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND " +
        " t.KeyField = m.KeyField and m.version=t.version " +
//        " INNER JOIN ztbl_DTS_Clients c on t.version=c.version and c.clientid='" +
//        clientID + "'" +
        " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='" + clientID +
        "' " +
        " and mast.DTSNo='" + dtsNo + "' and t.Version=mast.Version " +
        " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND " +
        " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' " +
        " AND s.DTSno=" + dtsNo;

    if (!dtsSetNo.equals("0")) {
      strSQL += " AND s.SetNo=" + dtsSetNo;
    }

    strSQL +=
        " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId " +
        " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND " +
        " r.KeyField = m.KeyField AND r.ClientID='" + clientID + "' and r.Version=mast.Version " +
        " AND r.DTSno=" + dtsNo;

    if (!dtsSetNo.equals("0")) {
      strSQL += " AND r.SetNo=" + dtsSetNo;
    }

    strSQL +=
        " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName " +
        " AND x.FieldName=s.FieldName AND x.DTSNo=" + dtsNo +
        " AND x.ClientID='" + clientID + "' " +
        " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category " +
        " AND y.KeyField=m.KeyField AND y.DTSNo=" + dtsNo + " AND y.SetNo=" + dtsSetNo +
        " AND y.ClientID='" + clientID + "' WHERE m.Category='" + categoryID +
        "' ";

    strCountSQL = "SELECT COUNT(*) As RecCount FROM ztbl_DTS_Mapping_Mast m " +
        " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND " +
        " t.KeyField = m.KeyField and m.version=t.version " +
//        " INNER JOIN ztbl_DTS_Clients c on t.version=c.version and c.clientid='" +
//        clientID + "'" +
        " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='" + clientID +
        "' " +
        " and mast.DTSNo='" + dtsNo + "' and t.Version=mast.Version " +
        " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND " +
        " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' " +
        " AND s.DTSno=" + dtsNo;

    if (!dtsSetNo.equals("0")) {
      strCountSQL += " AND s.SetNo=" + dtsSetNo;
    }

    strCountSQL +=
        " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId " +
        " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND " +
        " r.KeyField = m.KeyField AND r.ClientID='" + clientID + "' and r.Version=mast.Version " +
        " AND r.DTSno=" + dtsNo;

    if (!dtsSetNo.equals("0")) {
      strCountSQL += " AND r.SetNo=" + dtsSetNo;
    }

    strCountSQL +=
        " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName " +
        " AND x.FieldName=s.FieldName AND x.DTSNo=" + dtsNo +
        " AND x.ClientID='" + clientID + "' WHERE m.Category='" + categoryID +
        "' ";

    if (!targetTableName.equals("")) {
      strSQL += " AND t.TableName='" + replaceString(targetTableName, "'", "''") +
          "'";
      strCountSQL += " AND t.TableName='" +
          replaceString(targetTableName, "'", "''") + "'";
    }
    strSQL += " ORDER BY m.Category,m.SN";

    return getList(strSQL, "DTS");
  }

  public void getSourceFields(String clientID, String tableName, String dtsNo) {
    strSQL = "SELECT DISTINCT TableName, FieldName, FieldFormat from ztbl_DTS_SourceTableSpace " +
        " WHERE ClientID='" + clientID + "'  AND DTSNo=" + dtsNo;
    if (!tableName.equals("")) {
      strSQL += " AND TableName IN ('" + tableName + "')";
    }
    strSQL += " ORDER BY TableName,FieldName ";
    getList(strSQL, "Source fields");
  }

  public void getSourceTables(String clientID, String dtsNo) {
    strSQL = "SELECT DISTINCT TableName from ztbl_DTS_SourceTableSpace " +
        " WHERE ClientID='" + clientID + "' AND DTSNo=" + dtsNo +
        " ORDER BY TableName";
    getList(strSQL, "Source tables");
  }

  public void getDTSOfClient(String clientID) {
    getDTSOfClient(clientID, "");
  }

  public void getDTSOfClient(String clientID, String status) {
    String statusQuery = " Status='" + status + "'";
    if (status.equals("")) {
      statusQuery = " (Status<>'D' or Status is null)";
    }

    strSQL = "SELECT a.DTSNo," +
        "  to_char( a.CreationDate,'MM') || '-' ||  " +
        "  to_char( a.CreationDate,'DD') || '-' ||  " +
        "  to_number(to_char( a.CreationDate,'YYYY')) AS CreationDate, " +
        " a.Status,a.ApprovedBy,b.UserName, " +
        "  to_char( a.LastUpdated,'MM') || '-' ||  " +
        "  to_char( a.LastUpdated,'DD') || '-' ||  " +
        "  to_number(to_char( a.LastUpdated,'YYYY')) AS LastUpdated " +
        " FROM ztbl_DTS_DTS_Mast a LEFT JOIN ztbl_DTS_Users b on a.ApprovedBy=b.UserID " +
        " WHERE a.ClientID='" + clientID + "' AND " + statusQuery +
        " ORDER By a.DTSNo desc";
    getList(strSQL, "DTS List of a client");
  }

  public String updateDTS(String clientID, String category, String keyField,
                          String version, String businessRule,
                          String sourceTable,
                          String sourceField, String sourceFieldFormat) {
    String retValue = "";
    String sql = "";
    sql = "DELETE ztbl_DTS_MAPPING_SOURCE WHERE ClientID='" + clientID +
        "' AND KeyField='" +
        keyField + "' AND Category='" + category + "' AND Version='" + version +
        "'";
    this.execute(sql);

    sql = "DELETE ztbl_DTS_MAPPING_RULE WHERE ClientID='" + clientID +
        "' AND KeyField='" +
        keyField + "' AND Category='" + category + "' AND Version='" + version +
        "'";
    this.execute(sql);

    if (!sourceTable.equals("[]")) { //source fields are selected
      StringTokenizer st = new StringTokenizer(sourceTable, ",");
      StringTokenizer sf = new StringTokenizer(sourceField, ",");
      StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");
      while (st.hasMoreTokens()) {
        sql =
            "INSERT INTO ztbl_DTS_MAPPING_SOURCE (ClientID, Category, KeyField, Version, TableName," +
            "FieldName, FieldFormat) VALUES ('" +
            clientID + "','" + category + "','" + keyField + "', '" + version +
            "', '" +
            st.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "','" +
            sf.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "','" +
            fm.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "')";
        retValue += "<BR>" + sql;
        this.execute(sql);
      }
    }

    sql =
        "INSERT INTO ztbl_DTS_MAPPING_RULE (ClientID, Category, KeyField, Version, BusinessRule) " +
        " VALUES ('" + clientID + "','" + category + "','" + keyField + "', '" +
        version + "','" +
        replaceString(businessRule, "'", "''") + "')";
    retValue += "<BR>" + sql;
    this.execute(sql);
    return retValue;
  }

  //****************** ADD ENTRY IN DTS_Mast ******
   public boolean addNewDTSEntry(String clientID, int dtsNo, String createdBy,
                                 String version) {
     String sql = "";
     sql =
         "INSERT INTO ztbl_DTS_DTS_Mast (ClientID,DTSNo,CreationDate,CreatedBy, version)" +
         " VALUES ('" + clientID + "'," + dtsNo + ",sysdate ,'" +
         createdBy + "', '" + version + "')";
     this.execute(sql);

     //**nov 12 - add creation history to ztbl_DTS_Mast_Hist
      sql =
          "INSERT INTO ztbl_DTS_Mast_Hist (ClientID, DTSNo, Status, ModifiedOn, UserID)" +
          " VALUES ('" + clientID + "'," + dtsNo + ",'C',sysdate ,'" +
          createdBy + "')";
     return this.execute(sql);
   }

  //****************** ADD ENTRY IN DTS_Set ******
   public boolean addNewDTSSet(String clientID, int dtsNo, int setNo) {
     String sql = "";
     sql = "INSERT INTO ztbl_DTS_DTS_Set (ClientID,DTSNo,SetNo)" +
         " VALUES ('" + clientID + "'," + dtsNo + "," + setNo + ")";
     return this.execute(sql);
   }

  public boolean deleteDTSSet(String clientID, int dtsNo, int setNo) {
    String sql = "";
    sql = "DELETE ztbl_DTS_MAPPING_SOURCE WHERE ClientID='" + clientID +
        "' AND dtsNo=" +
        dtsNo + " AND setNo=" + setNo;
    this.execute(sql);

    sql = "DELETE ztbl_DTS_MAPPING_RULE WHERE ClientID='" + clientID +
        "' AND dtsNo=" +
        dtsNo + " AND setNo=" + setNo;
    return this.execute(sql);
  }

  public String addBusinessRuleAndSource(String clientID, String category,
                                         String keyField, String version,
                                         String businessRule,
                                         String sourceTable, String sourceField,
                                         String sourceFieldFormat,
                                         int dtsNo, int setNo) {
    String retValue = "";
    String sql = "";
    if (!sourceTable.equals("[]")) { //source fields are selected
      StringTokenizer st = new StringTokenizer(sourceTable, ",");
      StringTokenizer sf = new StringTokenizer(sourceField, ",");
      StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");
      while (st.hasMoreTokens()) {
        sql =
            "INSERT INTO ztbl_DTS_MAPPING_SOURCE (ClientID,DTSNo,SetNo,Category," +
            "KeyField, Version, TableName,FieldName,FieldFormat) VALUES ('" +
            clientID + "'," + dtsNo + "," + setNo + ",'" +
            category + "','" + keyField + "', '" + version + "', '" +
            st.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "','" +
            sf.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "','" +
            fm.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "')";
        retValue += "<BR>" + sql;
        this.execute(sql);
      }
    }

    sql = "INSERT INTO ztbl_DTS_MAPPING_RULE (ClientID,DTSNo,SetNo,Category,KeyField, Version, BusinessRule)" +
        " VALUES ('" + clientID + "'," + dtsNo + "," + setNo + ",'" +
        category + "','" + keyField + "', '" + version + "', '" +
        replaceString(businessRule, "'", "''") + "')";
    retValue += "<BR>" + sql;
    this.execute(sql);
    return retValue;
  }

  //**** mar 31 **********
   public String addUpdateSourceFields(String clientID, String category,
                                       String keyField,
                                       String dtsNo, String setNo,
                                       String sourceDatabase,
                                       String sourceTable, String sourceField,
                                       String sourceFieldFormat
                                       ) {
     String retValue = "";
     String sql = "";
     sql = "DELETE ztbl_DTS_MAPPING_SOURCE WHERE ClientID='" + clientID +
         "' AND dtsNo=" +
         dtsNo + " AND setNo=" + setNo + " AND Category='" + category +
         "' AND KeyField='" + keyField + "'";
     this.execute(sql);
     String version = this.getVersion(clientID, dtsNo);
     if (!sourceTable.equals("[]")) { //source fields are selected
       StringTokenizer sdb = new StringTokenizer(sourceDatabase, ",");
       StringTokenizer st = new StringTokenizer(sourceTable, ",");
       StringTokenizer sf = new StringTokenizer(sourceField, ",");
       StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");
       while (st.hasMoreTokens()) {
         sql =
             "INSERT INTO ztbl_DTS_MAPPING_SOURCE (ClientID,DTSNo,SetNo,Category," +
             "KeyField, Version, DatabaseId, TableName,FieldName, FieldFormat) VALUES ('" +
             clientID + "'," + dtsNo + "," + setNo + ",'" +
             category + "','" + keyField + "', '" + version + "', " +
             sdb.nextToken().toString().replace('[', ' ').replace(']', ' ').
             trim() + " ,'" +
             st.nextToken().toString().replace('[', ' ').replace(']', ' ').
             trim() + "','" +
             sf.nextToken().toString().replace('[', ' ').replace(']', ' ').
             trim() + "','" +
             fm.nextToken().toString().replace('[', ' ').replace(']', ' ').
             trim() + "')";
         retValue += "<BR>" + sql;
         this.execute(sql);
       }
     }
     updateHighlights(clientID, dtsNo, setNo, category, keyField, version, "1");
     return retValue;
   }

  public String getVersion(String clientId, String dtsNo) {
    String sql = "select version from ztbl_dts_dts_mast where clientId='" +
        clientId + "' and dtsNo=" + dtsNo;
    this.executeQuery(sql);
    if (this.moveNext()) {
      return this.getData("Version");
    }
    return "";
  }

  //******** mar 31
   // changed - May 11, 2003 by Raj
   public String addUpdateBusinessRule(String clientID, String category,
                                       String keyField, String version,
                                       String dtsNo,
                                       String setNo, String businessRule) {
     String retValue = "";
     String sql = "";
     businessRule = businessRule.trim();
     sql = "DELETE ztbl_DTS_Mapping_Rule WHERE ClientID='" + clientID +
         "' AND dtsNo=" +
         dtsNo + " AND setNo=" + setNo + " AND Category='" + category +
         "' AND KeyField='" + keyField + "' AND Version='" + version + "'";

     retValue += "<BR>" + sql;
     this.execute(sql);

     if (businessRule.compareTo("") != 0) {
       sql = "INSERT INTO ztbl_DTS_MAPPING_RULE (ClientID, DTSNo, SetNo, " +
           "Category, KeyField, Version, BusinessRule)" +
           " VALUES ('" + clientID + "'," + dtsNo + "," + setNo + ",'" +
           category + "','" + keyField + "', '" + version + "', '" +
           replaceString(businessRule, "'", "''") + "')";
     }
     retValue += "<BR>" + sql;
     this.execute(sql);

     this.updateHighlights(clientID, dtsNo, setNo, category, keyField, version, "1");
     return retValue;
   }

  public String addUpdateTranslatedRule(String clientID, String category,
                                        String keyField, String version,
                                        String dtsNo,
                                        String setNo, String translatedRule) {
    String sql = "";
    translatedRule = translatedRule.trim();
    if (translatedRule.compareTo("") != 0) {
      sql = "UPDATE ztbl_DTS_MAPPING_RULE SET TranslatedRule='" +
          translatedRule + "' " +
          "WHERE clientID='" + clientID + "' and category='" + category +
          "' and keyField='" + keyField +
          "' and version='" + version + "' and dtsNo='" + dtsNo + "'" +
          "and setno='" + setNo + "'";
    }
    this.execute(sql);
    return "<BR>" + sql;
  }

  public String updateExample(String clientID, String category,
                              String keyField, String version,
                              String dtsNo,
                              String setNo, String example) {
    String sql = "";
    example = example.trim();
    if (example.compareTo("") != 0) {
      sql = "UPDATE ztbl_DTS_MAPPING_RULE SET Example='" + example + "' " +
          "WHERE clientID='" + clientID + "' and category='" + category +
          "' and keyField='" + keyField +
          "' and version='" + version + "' and dtsNo='" + dtsNo + "'" +
          "and setno='" + setNo + "'";
    }
    this.execute(sql);
    return "<BR>" + sql;
  }

  //********* april 1
   public String addUpdateSourceTableSpace(String clientID, String dtsNo,
                                           String sourceTable,
                                           String sourceField,
                                           String sourceFieldFormat
                                           ) {
     String retValue = "";
     String sql = "";
     sql = "DELETE ztbl_DTS_Mapping_Source WHERE ClientID='" + clientID
         + "' AND dtsNo=" + dtsNo;
     retValue += "<BR>" + sql;
     this.execute(sql);

     sql = "DELETE ztbl_DTS_SourceTableSpace WHERE ClientID='" + clientID
         + "' AND dtsNo=" + dtsNo;
     retValue += "<BR>" + sql;
     this.execute(sql);

     if (!sourceTable.equals("[]")) { //source fields are selected
       StringTokenizer st = new StringTokenizer(sourceTable, ",");
       StringTokenizer sf = new StringTokenizer(sourceField, ",");
       StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");
       while (st.hasMoreTokens()) {
         sql = "INSERT INTO ztbl_DTS_SourceTableSpace (ClientID,DTSNo," +
             "TableName,FieldName,FieldFormat) VALUES ('" +
             clientID + "'," + dtsNo + ",'" +
             st.nextToken().toString().trim() + "','" +
             sf.nextToken().toString().trim() + "','" +
             fm.nextToken().toString().trim() + "')";
         retValue += "<BR>" + sql;
         this.execute(sql);
       }
     }
     return retValue;
   }

  //******** april 2
   public boolean uploadDocument(String clientID, String dtsNo,
                                 String uploadedDocName, byte[] uploadedDoc,
                                 String createdBy) throws Exception {
     int countDoc = prepareDocumentUpload(clientID, dtsNo);
     if (countDoc > 0) {
/*       strSQL = "UPDATE ztbl_DTS_AttachedDocuments set "+
           "DocumentName='"+ uploadedDocName+"', Document='"+uploadedDoc+"', "+
           "CreatedBy='"+createdBy+"' WHERE ClientID='"+clientID+"'" +
           " AND DTSNo="+dtsNo+" AND DocumentCount="+countDoc;
*/
         strSQL = "SELECT * FROM ztbl_DTS_AttachedDocuments WHERE "
           + " ClientID='" + clientID + "' AND DTSNo=" + dtsNo
           + " AND DocumentCount=" + countDoc;
		   try{
		   this.makeConnection();
	       Statement stmt = myConn.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
           ResultSet rsupd = stmt.executeQuery(strSQL);
               if (rsupd.next()) {
	        	 rsupd.updateString("DocumentName", uploadedDocName);
    		     rsupd.updateBytes("Document", uploadedDoc);
    	    	 rsupd.updateString("CreatedBy", createdBy);
		         rsupd.updateRow();
               }
               rsupd.close();
		}catch (Exception e){
System.out.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->1<-"+e);
			this.addMessage(e.toString());
			System.out.println(e);
		}
     }
     return this.execute(strSQL);
   }

  public int prepareDocumentUpload(String clientID, String dtsNo) {
    int documentCount = 0;
    String count = "";
    strSQL =
        "SELECT MAX(DocumentCount) AS DocumentCount FROM ztbl_DTS_AttachedDocuments"
        + " WHERE ClientID='" + clientID + "' AND DTSNo=" + dtsNo;
    this.executeQuery(strSQL);
    while (this.moveNext()) {
      count = this.getData("DocumentCount");
    }
    if (count == null) {
      count = "0";
    }
    try{
      documentCount = new Integer(count).intValue();
    }catch (NumberFormatException e){
System.out.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->0<-"+e);
      documentCount = 0;
    }
    documentCount++;
    strSQL =
        "INSERT INTO ztbl_DTS_AttachedDocuments ( ClientID,DTSNo,DocumentCount)"
        + " VALUES ('" + clientID + "'," + dtsNo + ","
        + documentCount + ")";
    this.execute(strSQL);
    return documentCount;
  }

  public boolean getListOfDocuments(String clientID, String dtsNo) {
    strSQL = "SELECT a.DocumentCount, a.DocumentName, b.UserName, dtsNo,"
        + "to_char(a.CreationDate,'MM') || '-' || "
        + "to_char(a.CreationDate,'DD') || '-' || "
        + "to_number(to_char(a.CreationDate,'YYYY')) AS CreationDate"
        +
        " FROM ztbl_DTS_AttachedDocuments a,ztbl_DTS_Users b WHERE a.ClientID='"
        + clientID + "' AND a.CreatedBy=b.UserID "; // no need to change
//    + clientID + "' AND dtsNo='" + dtsNo + "' AND a.CreatedBy=b.UserID "; //changed by upendra
    //+ clientID + "' AND a.CreatedBy=b.UserID ";
    return getList(strSQL, "List of documents");
  }

  public boolean getDocument(String clientID, String dtsNo) {
    strSQL =
        "SELECT DocumentName,Document FROM ztbl_DTS_AttachedDocuments WHERE ClientID='"
        + clientID + "' AND dtsNo=" + dtsNo;
    return getList(strSQL, "List of documents");
  }

//   public boolean getListOfUsers(String User
// added by upendra
  public int getDocumentCount(String clientID, String dtsNo) {
    strCountSQL =
        "SELECT count(*) as docCount FROM ztbl_DTS_AttachedDocuments WHERE ClientID='"
        + clientID + "' AND dtsNo=" + dtsNo;
    this.executeQuery(strCountSQL);
    if (this.moveNext()) {
      return this.getInt("docCount");
    }
    return 0;
  }

  public boolean addDTSRemark(String clientID, String remarks) {
    strSQL = "UPDATE ztbl_DTS_DTS_Mast SET Remarks='" +
        replaceString(remarks, "'", "''")
        + "' WHERE ClientID='" + clientID + "'";
    return this.execute(strSQL);
  }

  public boolean getDTSRemark(String clientID, String dtsNo) {
    strSQL = "SELECT Remarks FROM ztbl_DTS_DTS_Mast WHERE ClientID='"
        + clientID + "' AND dtsNo=" + dtsNo;
    return getList(strSQL, "List of remarks");
  }

// added by upendra
  public boolean remarkExist(String clientID, String dtsNo) {
    strSQL = "SELECT Remarks FROM ztbl_DTS_DTS_Mast WHERE ClientID='"
        + clientID + "' AND dtsNo=" + dtsNo;
    this.executeQuery(strSQL);
    if (this.moveNext()) {
      if (this.checkNull(this.getData("Remarks")).equals("")) {
        return true;
      }
    }
    return false;
  }

  //********** april 08 *****************************************************
   //********** april 09 *****************************************************
    public String updateHighlights(String clientID, String dtsNo, String setNo,
                                   String category, String keyfields,
                                   String version, String highlightMode) {
      String retValue = "";
      String sql = "";
      StringTokenizer st = new StringTokenizer(keyfields, ",");

      // Highlight a field or fields
      if (highlightMode.equals("1")) {
        while (st.hasMoreTokens()) {
          String kf = st.nextToken().toString().trim();
          // Clean the table first
          sql = "DELETE ztbl_DTS_Mapping_Highlights WHERE" +
                " ClientID='" + clientID + "'" +
                " AND DTSNo=" + dtsNo +
                " AND SetNo=" + setNo +
                " AND Category='" + category + "'" +
                " AND KeyField='" + kf + "'" +
                " AND Version='" + version + "'";
          this.execute(sql);
          sql = "INSERT INTO ztbl_DTS_Mapping_Highlights" +
                " (ClientID, DTSNo, SetNo, Category, KeyField, Version, Priority)" +
                " VALUES ('" + clientID + "'," + dtsNo + "," + setNo + ",'" +
                category + "','" + kf + "', '" + version + "', 'y')";
          retValue += "<BR>" + sql;
          this.execute(sql);
        }
      }
      // Unhighlight a field or fields
      else if (highlightMode.equals("0")) {
        while (st.hasMoreTokens()) {
          String kf = st.nextToken().toString().trim();
          sql = "DELETE ztbl_DTS_Mapping_Highlights WHERE" +
                " ClientID='" + clientID + "'" +
                " AND DTSNo=" + dtsNo +
                " AND SetNo=" + setNo +
                " AND Category='" + category + "'" +
                " AND KeyField='" + kf + "'" +
                " AND Version='" + version + "'";
          retValue += "<BR>" + sql;
          this.execute(sql);
        }
      }
      // Delete all highlights from a set (same as "0" but for all keyfields)
      else if (highlightMode.equals("2")) {
          sql = "DELETE ztbl_DTS_Mapping_Highlights WHERE" +
                " ClientID='" + clientID + "'" +
                " AND DTSNo=" + dtsNo +
                " AND SetNo=" + setNo +
                " AND Category='" + category + "'" +
                " AND Version='" + version + "'";
          retValue += "<BR>" + sql;
          this.execute(sql);
      }
      return retValue;
    }

  public boolean deleteDocument(String clientID, String dtsNo,
                                String documentCount) {
    strSQL = "DELETE ztbl_DTS_AttachedDocuments WHERE ClientID='" + clientID
        + "' AND DTSNo=" + dtsNo + " AND DocumentCount=" + documentCount;
    return this.execute(strSQL);
  }

  //********** Apr 10 ***********************************************
   public boolean deleteSourceTableSpace(String clientID, String dtsNo,
                                         String database) {
     strSQL = "DELETE ztbl_DTS_SourceTableSpace WHERE ClientID='" + clientID
         + "' AND DTSNo=" + dtsNo + " AND DatabaseId=" + database + "";
     return this.execute(strSQL);
   }

  public boolean insertSourceTableSpace(String clientID, String dtsNo,
                                        String TableName, String FieldName,
                                        String FieldFormat, String databaseId) throws
      Exception {
    strSQL = "INSERT INTO ztbl_DTS_SourceTableSpace "
        + " (ClientID, DTSNo, TableName, FieldName, DatabaseId, FieldFormat) "
        + " VALUES('" + clientID + "'," + dtsNo + ",'" + TableName
        + "','" + FieldName + "'," + databaseId + ",'" + FieldFormat + "')";
    return this.execute(strSQL);
  }

    public boolean addSourceTableSpace(String clientID, String dtsNo,
                                         String databaseID) {
     strSQL = "INSERT INTO ztbl_DTS_SourceTableSpace " +
              "(CLIENTID, DTSNO, TABLENAME, FIELDNAME, FIELDFORMAT, DATABASEID) SELECT " +
               "'" + clientID + "'," + dtsNo + ", TABLE_NAME, COLUMN_NAME, " +
                "CASE WHEN DATA_TYPE LIKE '%NUMBER%' AND DATA_PRECISION IS NOT NULL THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ',' || CAST((DATA_LENGTH-DATA_PRECISION) AS VARCHAR(5)) || ')' " +
                "WHEN DATA_TYPE LIKE '%CHAR%' OR DATA_TYPE LIKE '%NUMBER%'  THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ')' " +
                "ELSE DATA_TYPE END, " + databaseID + " FROM ALL_TAB_COLS a, (SELECT DATABASENAME FROM ztbl_DTS_Databases WHERE DATABASEID=" + databaseID + ") b WHERE owner = b.DATABASENAME ";
        return this.execute(strSQL);
   }

  /*  public boolean copyDTS(String clientID, String prevDTSNo, String currentDTSNo) {
      strSQL = "INSERT INTO ztbl_DTS_Mapping_Highlights "
          + " (ClientID, DTSNo, Category, KeyField, Priority, Version)"
          + " (SELECT '" + clientID + "' as ClientID," + currentDTSNo +
          " as DTSNo , Category, KeyField, Priority, Version"
          + " FROM ztbl_DTS_Mapping_Highlights WHERE ClientID='" + clientID +
          "' AND "
          + " DTSNo=" + prevDTSNo + ")";
      this.execute(strSQL);

      strSQL = "INSERT INTO ztbl_DTS_Mapping_Rule "
          +
   " (ClientID, DTSNo, SetNo, Category, KeyField, Version, BusinessRule)"
          + " (SELECT '" + clientID + "'," + currentDTSNo +
          ", SetNo, Category, KeyField, Version, BusinessRule"
          + " FROM ztbl_DTS_Mapping_Rule WHERE ClientID='" + clientID +
          "' AND "
          + " DTSNo=" + prevDTSNo + ")";
      this.execute(strSQL);

      strSQL = "INSERT INTO ztbl_DTS_Mapping_Source "
   + " (ClientID, DTSNo, SetNo, Category, KeyField, Version, TableName, "
          + " FieldName, FieldFormat)"
          + " (SELECT '" + clientID + "'," + currentDTSNo
          +
   ", SetNo, Category, KeyField, Version, TableName, FieldName, FieldFormat"
          + " FROM ztbl_DTS_Mapping_Source WHERE ClientID='" + clientID +
          "' AND "
          + " DTSNo=" + prevDTSNo + ")";
      return this.execute(strSQL);
    }
   */
  //********** Apr 18 ***********************************************
   public boolean deleteDTS(String clientID, String dtsNo, String TorP) {
     //strSQL = "EXEC sp_DeleteDTS('" + clientID + "'," + dtsNo + ",'" + TorP + "');";
      boolean retVal=false;
      try{
          if(myConn==null){
            this.makeConnection();
          }
          CallableStatement stmt = myConn.prepareCall("{call sp_DeleteDTS(?,?,?)}");
          stmt.setString(1,clientID);
          stmt.setInt(2,Integer.parseInt(dtsNo));
          stmt.setString(3,TorP);
          stmt.executeUpdate();
          stmt.close();
          retVal = true;
      }catch(Exception e){
          System.out.println("ERROR calling sp_DeleteDTS " + e.toString());
          this.addMessage("ERROR calling sp_DeleteDTS" + e.toString());
      }

     return retVal;
   }

  public void setUserForClient(String user) {
    userForClient = user;
  }

  public boolean getListOfClients(String clientID, String orderBy) {
    if (orderBy.equals("")) {
      orderBy = " a.ClientName";
    }
    strSQL =
        "SELECT distinct a.ClientID, a.ClientName, a.ContractType, a.DatabaseName," +
        "a.UserName, a.ServerName, a.UserPassword, a.InUse, a.Version FROM ztbl_DTS_ClientView a ";
    String strWhere = " WHERE InUse = 'Y' ";

    if (!userForClient.equals("")) {
      strSQL +=
          " INNER JOIN ztbl_DTS_UsersAndClients b ON a.ClientID=b.ClientID ";
      strWhere += " AND b.UserID='" + userForClient + "'";
    }

    if (!clientID.equals("")) {
      strWhere += " AND a.ClientID='" + clientID + "'";
    }
    strSQL = strSQL + strWhere + " ORDER BY " + orderBy;
    return getList(strSQL, "Clients List");
  }

  public boolean getListOfCategories() {
    return this.getListOfCategories("");
  }

  public boolean getListOfCategories(String orderBy) {
    if (orderBy.equals("")) {
      orderBy = " Category";
    }
    strSQL = "SELECT * FROM ztbl_DTS_Categories ORDER BY " + orderBy;
    strCountSQL = "SELECT COUNT(*) AS RecCount FROM ztbl_DTS_Categories";

    return getList(strSQL, "Categories List");
  }

  public boolean getListOfVersions() {
    strSQL = "select distinct version from ztbl_dts_mapping_mast";
    return getList(strSQL, "Version List");
  }

  public boolean getListOfTargetTables() {
    strSQL =
        "SELECT DISTINCT TableName FROM ztbl_DTS_TargetTableSpace ORDER BY TableName";
    return getList(strSQL, "List of target tables");
  }

  public boolean getListOfTargetTables(String version) {
    strSQL =
        "SELECT DISTINCT TableName FROM ztbl_DTS_TargetTableSpace" +
        " WHERE Version='" + version + "'" +
        " ORDER BY TableName";
    return getList(strSQL, "List of target tables");
  }

  public boolean getListOfTargetTables(String clientID, String category,
                                       String version) {
    strSQL =
        " SELECT DISTINCT TableName from ztbl_DTS_Mapping_Target mt, " +
        " ztbl_DTS_Clients c where Category='" +
        category + "' and mt.version=c.version and c.clientId='" +
        clientID + "' and mt.version='" + version + "' ORDER BY TableName";
    return getList(strSQL, "Target tables list");
  }

  public boolean getListOfTargetTables(String clientID, String category) {
    strSQL =
        " SELECT DISTINCT TableName from ztbl_DTS_Mapping_Target mt, " +
        " ztbl_DTS_Clients c where Category='" +
        category + "' and mt.version=c.version and c.clientId='" +
        clientID + "' ORDER BY TableName";
    return getList(strSQL, "Target tables list");
  }

  public int getMaxDTSSetNo(String clientID, String DTSNo) {
    strSQL = "SELECT MAX(SetNo) AS MaxSetNo FROM ztbl_DTS_DTS_Set WHERE DTSNo=" +
        DTSNo + " AND ClientID='" + clientID + "'";
    getList(strSQL, "");
    if (this.moveNext()) {
      return this.getInt("MaxSetNo");
    }
    return 0;
  }

  public int getMaxDTSSetNoInCategory(String clientID, String DTSNo, String category) {
    strSQL = "SELECT MAX(a.SetNo) AS MaxSetNo FROM ztbl_DTS_DTS_Set a" +
        " INNER JOIN" +
            " (SELECT c.ClientID, c.DTSNo, c.SetNo, c.Category " +
            " FROM ztbl_DTS_Mapping_Source c UNION ALL" +
            " SELECT d.ClientID, d.DTSNo, d.SetNo, d.Category FROM ztbl_DTS_Mapping_Rule d" +
            " ) b" +
        " ON a.ClientID=b.ClientID AND a.DTSNo=b.DTSNo AND a.SetNo=b.SetNo" +
        " WHERE b.DTSNo=" + DTSNo + " AND b.ClientID='" + clientID + "'" +
        " AND b.Category='" + category + "'";

    getList(strSQL, "");
    if (this.moveNext()) {
      return this.getInt("MaxSetNo");
    }
    return 0;
  }

  public int getMaxDTSNo(String clientID) {
    strSQL =
        "SELECT MAX(DTSNo) AS MaxDTSNo FROM ztbl_DTS_DTS_Mast WHERE ClientID='" +
        clientID + "'";
    getList(strSQL, "");
    while (this.moveNext()) {
      return this.getInt("MaxDTSNo");
    }
    return 0;
  }

  public String synchronizeClientsStatus() {
    String retValue = "";
    String sql = "";
    sql = "Insert into ztbl_DTS_Clients (ClientID, ClientName, InUse)" +
        " Select ClientID, ClientName, InUse " +
        " from HawkeyeMaster.tbl_Master_Clients  where ClientID not in " +
        " (select ClientID from ztbl_DTS_Clients)";
    this.execute(sql);

    sql = " update a set ClientName = b.ClientName, " +
        " ContractType=b.ContractType, InUse = b.InUse " +
        " from ztbl_DTS_Clients a, HawkeyeMaster.tbl_Master_Clients  b " +
        " where a.ClientID = b.ClientID ";
    this.execute(sql);
    return retValue;
  }

  //********** Apr 24 ***********************************************
   public boolean getListOfCategory(String sn) {
     strSQL = "SELECT * FROM ztbl_DTS_Categories ";
     if (!sn.equals("")) {
       strSQL += " WHERE SN=" + sn;
     }
     strSQL += " ORDER BY Category";
     return getList(strSQL, "Category List");
   }

  public boolean manageCategory(String sn, String category, String categoryDesc,
                                String spMode) {
    strSQL = "sp_ManageCategory " + sn + ",'" +
        replaceString(category, "'", "''") +
        "','" + replaceString(categoryDesc, "'", "''") + "','" + spMode + "'";
    return this.execute(strSQL);
  }

  //******************* Apr 25 *************************/
  public boolean getKeyfieldList(String category, String version) {
    return this.getKeyfieldList(category, version, "");
  }

  public boolean getKeyfieldList(String category, String version,
                                 String orderBy) {
    strSQL =
        "SELECT a.SN,a.Category,a.KeyField,a.FieldFormat, b.TableName,b.FieldName "
        + " FROM ztbl_DTS_Mapping_Mast a "
        + " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
        +
        " AND a.KeyField=b.KeyField AND a.Version=b.Version WHERE a.Category='"
        + replaceString(category, "'", "''") + "' and a.version='" + version +
        "'";

    strCountSQL = "SELECT COUNT(*) AS RecCount FROM ztbl_DTS_Mapping_Mast a "
        + " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
        +
        " AND a.KeyField=b.KeyField AND a.Version=b.Version WHERE a.Category='"
        + replaceString(category, "'", "''") + "' and a.version='" + version +
        "'";

    //strSQL	= "SELECT * FROM ztbl_DTS_Mapping_Mast WHERE Category='" + replaceString(category,"'","''") + "'";
    if (!orderBy.equals("")) {
      strSQL += " ORDER BY " + orderBy;
    }
    return getList(strSQL, "List of keyfields");
  }

  public boolean getKeyfieldList(String category, String version,
                                 String orderBy,
                                 String clientId) {
    strSQL =
        "SELECT a.SN,a.Category,a.KeyField,a.FieldFormat,b.TableName,b.FieldName "
        + " FROM ztbl_DTS_Mapping_Mast a "
        + " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
        + " AND a.KeyField=b.KeyField "
        +
        " INNER JOIN ztbl_DTS_Clients c on b.version=c.version and c.clientid='" +
        clientId + "' "
        + " WHERE a.Category='"
        + replaceString(category, "'", "''") + "' and a.version='" + version +
        "'";

    strCountSQL = "SELECT COUNT(*) AS RecCount FROM ztbl_DTS_Mapping_Mast a "
        + " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
        + " AND a.KeyField=b.KeyField "
        +
        " INNER JOIN ztbl_DTS_Clients c on b.version=c.version and c.clientid='" +
        clientId + "' "
        + " WHERE a.Category='"
        + replaceString(category, "'", "''") + "' and a.version='" + version +
        "'";

    //strSQL	= "SELECT * FROM ztbl_DTS_Mapping_Mast WHERE Category='" + replaceString(category,"'","''") + "'";
    if (!orderBy.equals("")) {
      strSQL += " ORDER BY " + orderBy;
    }
    return getList(strSQL, "List of keyfields");
  }

  public boolean getDistinctKeyfieldList(String category, String version,
                                         String orderBy) {
    strSQL = "SELECT *  FROM ztbl_DTS_Mapping_Mast WHERE Category='"
        + replaceString(category, "'", "''") + "' and version='" + version +
        "'";

    if (!orderBy.equals("")) {
      strSQL += " ORDER BY " + orderBy;
    }
    return getList(strSQL, "List of keyfields");
  }

  public void getListOfTargetFields(String tableName) {
    strSQL =
        "SELECT DISTINCT TableName, FieldName, FieldFormat, Version" +
        " FROM ztbl_DTS_TargetTableSpace" +
        " WHERE 1=1";   // so we don't need WHERE for each condition

    if (!tableName.equals("")) {
      strSQL += " AND TableName IN ('" + tableName + "')";
    }

    strSQL += " ORDER BY TableName, FieldName";
    getList(strSQL, "Target fields");
  }

  public String addUpdateTargetFields(String category, String keyField,
                                      String version,
                                      String tableName, String fieldName) {
    String retValue = "";
    String sql = "";
    sql = "DELETE ztbl_DTS_Mapping_Target WHERE Category='" + category +
        "' AND KeyField='" + keyField + "' AND Version='" + version + "'";
    this.execute(sql);

    if (!tableName.equals("[]")) { //source fields are selected
      StringTokenizer st = new StringTokenizer(tableName, ",");
      StringTokenizer sf = new StringTokenizer(fieldName, ",");
      while (st.hasMoreTokens()) {
        sql = "INSERT INTO ztbl_DTS_Mapping_Target (Category," +
            "KeyField, TableName, FieldName, Version) VALUES ('" +
            category + "','" + keyField + "','" +
            st.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "','" +
            sf.nextToken().toString().replace('[', ' ').replace(']', ' ').
            trim() + "','" + version.trim() +
            "')";
        retValue += "<BR>" + sql;
        this.execute(sql);
      }
    }
    return retValue;
  }

  public boolean manageKeyfield(String sn, String category, String keyfield,
                                String version, String fieldFormat,
                                String spMode) {
    strSQL = "sp_ManageKeyfield " + sn + ",'" +
        replaceString(category, "'", "''") +
        "','" + replaceString(keyfield, "'", "''") +
        "','" + replaceString(version, "'", "''") +
        "','" + replaceString(fieldFormat, "'", "''") + "','" + spMode + "'";
    return this.execute(strSQL);
  }

  public boolean deleteTargetTableSpace(String version) {
    strSQL = "DELETE ztbl_DTS_TargetTableSpace where version='" + version + "'";
    return this.execute(strSQL);
  }

  public boolean insertTargetTableSpace(String TableName, String FieldName,
                                        String FieldFormat, String version) {
    strSQL = "INSERT INTO ztbl_DTS_TargetTableSpace "
        + " (TableName, FieldName, FieldFormat, Version) "
        + " VALUES('" + TableName
        + "','" + FieldName + "','" + FieldFormat + "', '" + version + "')";
    return this.execute(strSQL);
  }

  public boolean insertTargetTableSpace(String TableName, String FieldName,
                                        String FieldFormat) {
    return this.insertTargetTableSpace(TableName, FieldName, FieldFormat,
                                       this.latestVersion);
  }

  //September 08, 2003
  public boolean saveKeyfieldsOrder(String category, String sortedKeyFields) {
    StringTokenizer keyfield = new StringTokenizer(sortedKeyFields, ",");
    boolean retValue = false;
    int counter = 0;
    String kf = "";
    try {
      PreparedStatement pstmt = myConn.prepareStatement(
          "UPDATE ztbl_DTS_Mapping_Mast SET SN = ? WHERE KeyField=? AND Category=?");
      while (keyfield.hasMoreTokens()) {
        counter++;
        kf = keyfield.nextElement().toString().trim();
        pstmt.setInt(1, counter);
        pstmt.setString(2, kf);
        pstmt.setString(3, category);
        pstmt.executeUpdate();

      }
      retValue = true;

    }
    catch (Exception e){
System.out.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->2<-"+e);
      errorStr = e.toString();
    }
    return retValue;
  }

  public int getSourceCount(int ClientID, int DTSNo, int SetNo) {
    return getCount("ztbl_DTS_Mapping_Source", ClientID, DTSNo, SetNo);
  }

  public int getRuleCount(int ClientID, int DTSNo, int SetNo) {
    return getCount("ztbl_DTS_Mapping_Rule", ClientID, DTSNo, SetNo);
  }

  public int getCount(String TableName, int ClientID, int DTSNo, int SetNo) {
    strCountSQL = "";
    strCountSQL += " select count(*) as RecCount ";
    strCountSQL += " from " + TableName + " as tbl1";
    strCountSQL += " where tbl1.SetNo = " + SetNo + " and tbl1.ClientId= " +
        ClientID + " and tbl1.DTSNo = " + DTSNo;
    return getRecordCount();
  }

  public boolean deleteSet(int ClientID, int DTSNo, int SetNo) {
    strSQL = "";
    strSQL += " Delete From ztbl_DTS_DTS_Set where ";
    strSQL += " ClientID = " + ClientID + " and ";
    strSQL += " DTSNo = " + DTSNo + " and ";
    strSQL += " SetNo = " + SetNo;
    return this.execute(strSQL);
  }

  public boolean getAllSource(String clientId, String dtsNo) {
    this.dbNames = new Vector();
    this.tbls = new HashMap();
    this.flds = new HashMap();
    this.ffor = new HashMap();
    HashMap dbIdMap = new HashMap();
    String databaseName = "", tableName = "", fieldName = "", fieldFormat = "";
    String sql = "";
    sql +=
        " SELECT DISTINCT d.DatabaseId, DatabaseName, TableName , FieldName, FieldFormat " +
        " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d " +
        " where s.databaseid = d.databaseid and ((d.ClientID='" + clientId +
        "' AND DTSNo=" + dtsNo + ") or (d.ClientID='999' " +
        " and (TableName like '%" + clientId +
        "%' or TableName like '%global%' ))) " +
        " order by tableName ";
    /*
            "SELECT DISTINCT d.DatabaseId, DatabaseName, TableName, FieldName, FieldFormat" +
            " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d" +
            " where s.databaseid = d.databaseid and " +
            " d.ClientID='" + clientId + "' AND DTSNo=" + dtsNo +
            " union " +
            " SELECT DISTINCT d.DatabaseId, DatabaseName, TableName, FieldName, FieldFormat " +
            " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d " +
            " where s.databaseid = d.databaseid and " +
            " d.ClientID='999' and " +
     " (TableName like '%" + clientId + "%' or TableName like '%global%' )";
     */
    ResultSet rs = this.executeQuery(sql);
    try {
      while (rs.next()) {
        databaseName = rs.getString("DatabaseName");
        tableName = rs.getString("TableName");
        fieldName = rs.getString("FieldName");
        fieldFormat = rs.getString("FieldFormat");
//        this.addMessage("[getting data - ]"+databaseName+"; "+tableName+"; "+fieldName+"; "+ fieldFormat);
        Vector t = null, f1 = null;
        HashMap f = null, ff = null, ff1 = null;
        if (!dbNames.contains(databaseName)) {
          dbIdMap.put(databaseName, rs.getString("DatabaseId"));
//          this.addMessage("[new database]" + databaseName);
          // new database
          dbNames.add(databaseName);
          t = new Vector(); /// new table list
          tbls.put(databaseName, t);
          f = new HashMap(); // new fields
          flds.put(databaseName, f);
          ff = new HashMap(); // new field formats
          ffor.put(databaseName, ff);
        }
        else {
//          this.addMessage("[old database]" + databaseName);
          t = (Vector) tbls.get(databaseName);
          f = (HashMap) flds.get(databaseName);
          ff = (HashMap) ffor.get(databaseName);
        }

        if (!t.contains(tableName)) {
          // working on new table
//          this.addMessage("[new table]" + tableName);
          t.add(tableName);
          // new table needs new fields
          f1 = new Vector();
          f.put(tableName, f1);
          // and new field formats
          ff1 = new HashMap();
          ff.put(tableName, ff1);
        }
        else {
//          this.addMessage("[old table]" + tableName);
          // field maped by tablename is already present in f
          f1 = (Vector) f.get(tableName);
          ff1 = (HashMap) ff.get(tableName);
        }

        if (!f1.contains(fieldName)) {
//          this.addMessage("[new field]" + fieldName);
          f1.add(fieldName);
          ff1.put(fieldName, fieldFormat);
        }
      }
      this.dbMap = this.createDBMap(dbIdMap);
      this.listDatabaseNames = this.createDatabaseString(dbNames);
      this.listTableNames = this.createTableString(dbNames, tbls);
      this.listFieldNames_1 = this.createFieldString(dbNames, tbls, flds);
      this.listFieldFormats_1 = this.createFFormatString(dbNames, tbls, ffor);
    }
    catch (Exception e){
System.out.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->3<-"+e);
      this.addMessage("Error " + e);
      System.out.print("Error " + e);
    }
    return true;
  }

  public boolean getAllSourceOptimized(String clientId, String dtsNo) {
      // Don't risk breaking something else, so create these empty objects
      this.dbNames = new Vector();
      this.tbls = new HashMap();
      this.flds = new HashMap();
      this.ffor = new HashMap();

      String databaseName = "", tableName = "", fieldName = "", fieldFormat = "";
      String sql = "";
      // The ORDER BY is critical here.  To optimize this function, the result set
      // is parsed and the strings are built *concurrently*.  Since we need to have
      // 'new Array()' in strategic locations, we rely on the fact that the result set
      // is ordered by DatabaseName first, and TableName second.
      // We do this because it is MUCH FASTER to let SQL do the sorting, rather than
      // throwing everything in various collections and parsing them later.
      sql +=
      " SELECT DISTINCT d.DatabaseId, DatabaseName, TableName , FieldName, FieldFormat " +
      " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d " +
      " WHERE s.databaseid = d.databaseid AND ((d.ClientID='" + clientId +
      "' AND DTSNo=" + dtsNo + ") OR (d.ClientID='999' " +
      " AND (TableName LIKE '%" + clientId +
      "%' OR TableName LIKE '%global%' ))) " +
      " ORDER BY DatabaseName, TableName ";
      ResultSet rs = this.executeQuery(sql);

      String dbIdMapStr      = "var dbIdMap = new Array(); \n";
      String dbNamesStr      = "var dbList = new Array(); \n" + "dbList = [";
      String tableListStr    = "var tableList = new Array();\n";
      // These two string get VERY long, so don't use an immutable object for them.
      // Using StringBuffer instead of String speeds up load time by over 1000%!
      StringBuffer fieldListStr  = new StringBuffer("var fieldList = new Array();\n");
      StringBuffer formatListStr = new StringBuffer("var fieldFormatList = new Array();\n");

      int dbNamesCount       = 0;
      int tableListCount     = 0;
      int fieldListCount     = 0;

      String oldDatabaseName = "";
      String oldTableName    = "";

      boolean isNewDb        = false;
      boolean isNewTable     = false;

      try {
          while (rs.next()) {
              databaseName = rs.getString("DatabaseName");
              tableName    = rs.getString("TableName");
              fieldName    = rs.getString("FieldName");
              fieldFormat  = rs.getString("FieldFormat");

              isNewDb = !databaseName.equals(oldDatabaseName);
              isNewTable = !tableName.equals(oldTableName);

              // For each new database
              if (isNewDb) {
                  dbIdMapStr += "dbIdMap['" + databaseName + "']='" + rs.getString("DatabaseId") + "'; \n";

                  if (dbNamesCount > 0) {
                      dbNamesStr += ", ";
                  }
                  dbNamesStr += "'" + databaseName + "'";
                  dbNamesCount++;

                  if (dbNamesCount > 1) {
                      tableListStr  += "];\n";
                      fieldListStr.append("];\n");
                      formatListStr.append("\n");
                  }
                  tableListStr += "tableList['" + databaseName + "'] = new Array();\n";
                  tableListStr += "tableList['" + databaseName + "'] = [";
                  tableListCount = 0;

                  fieldListStr.append("fieldList['" + databaseName + "'] = new Array();\n");
                  formatListStr.append("fieldFormatList['" + databaseName + "'] = new Array();\n");
              }

              // For each new table
              if (isNewTable) {
                  if (tableListCount > 0) {
                      tableListStr += ", ";
                  }
                  tableListStr += "'" + tableName + "'";
                  tableListCount++;

                  if (tableListCount > 1) {
                      fieldListStr.append("];\n");
                      formatListStr.append("\n");
                  }
                  fieldListStr.append("fieldList['" + databaseName + "']['" + tableName + "'] = new Array();\n");
                  fieldListStr.append("fieldList['" + databaseName + "']['" + tableName + "'] = [");
                  fieldListCount = 0;
                  formatListStr.append("fieldFormatList['" + databaseName + "']['" + tableName + "'] = new Array();\n");
              }

              // For each field
              if (fieldListCount > 0) {
                  fieldListStr.append(", ");
              }
              fieldListStr.append("'" + fieldName + "'");
              fieldListCount++;

              formatListStr.append("fieldFormatList['" + databaseName + "']['" + tableName + "']['" + fieldName + "'] = '" + fieldFormat + "'; ");

              oldDatabaseName = databaseName;
              oldTableName = tableName;

          }

          dbNamesStr += "];\n";
          tableListStr += "];\n";
          fieldListStr.append("];\n");

          this.dbMap = dbIdMapStr;
          this.listDatabaseNames = dbNamesStr;
          this.listTableNames = tableListStr;
          this.listFieldNames_1 = fieldListStr.toString();
          this.listFieldFormats_1 = formatListStr.toString();
      }
      catch (Exception e){
System.out.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->4<-"+e);
          this.addMessage("Error " + e);
          System.out.print("Error " + e);
      }
      return true;
  }

  private String createDBMap(HashMap dbMap) {
    String str2ret = "";
    str2ret += "var dbIdMap = new Array(); \n";
    String[] keys = new String[dbMap.size()];
    dbMap.keySet().toArray(keys);
    for (int i = 0; i < keys.length; i++) {
      str2ret += "dbIdMap['" + keys[i] + "']='" + dbMap.get(keys[i]) + "'; \n";
    }
    return str2ret;
  }

  private String createDatabaseString(Vector db) {
    String str = "";
    this.addMessage("[creating dblist]");
    str += "var dbList = new Array(); \n";
    str += "dbList = [";
    for (int i = 0; i < db.size(); i++) {
      str += "'" + db.get(i) + "'";
      if (i < db.size() - 1) {
        str += ", ";
      }
    }
    str += "];";
    this.addMessage("[created dblist]");
    return str;
  }

  private String createTableString(Vector db, HashMap tbl) {
    this.addMessage("[creating tableList]");
    String str = "";
    str += "var tableList = new Array();\n";
    for (int i = 0; i < db.size(); i++) {
      String dbName = db.get(i).toString();
      Vector v = (Vector) tbl.get(dbName);
      str += " tableList['" + dbName + "'] = new Array(); \n";
      String subStr = "[";
      for (int j = 0; j < v.size(); j++) {
        subStr += "'" + v.get(j) + "'";
        if (j < v.size() - 1) {
          subStr += ", ";
        }
      }
      subStr += "];";
      str += "tableList['" + dbName + "']=" + subStr + "\n";
    }
    this.addMessage("[created tableList]");
    return str;
  }

  private String createFieldString(Vector db, HashMap tbl, HashMap fld) {
    this.addMessage("[creating fieldList]");
    String str = "";
    str += "var fieldList = new Array();\n";
    for (int i = 0; i < db.size(); i++) { // looping in database
      String dbName = db.get(i) + "";
      this.addMessage("database" + dbName);
      Vector v = (Vector) tbl.get(dbName); // geting tables
      str += " fieldList['" + dbName + "'] = new Array(); \n";
      for (int j = 0; j < v.size(); j++) {
        String tblName = v.get(j) + "";
        this.addMessage("table" + tblName);
        Vector vv = (Vector) ( (HashMap) fld.get(dbName)).get(tblName); // geting fields
        str += " fieldList['" + dbName + "']['" + tblName +
            "'] = new Array(); \n";
        String subStr = "[";
        for (int k = 0; k < vv.size(); k++) {
//          this.addMessage("field" + vv.get(k));
          subStr += "'" + vv.get(k) + "'";
          if (k < vv.size() - 1) {
            subStr += ", ";
          }
//          this.addMessage("[strValue i="+i+"; j="+j+"; k="+k+"]"+str);
        }
        subStr += "];\n";
        str += "fieldList['" + dbName + "']['" + tblName + "']=" + subStr;
      }
    }
    this.addMessage("[created fieldList]");
    return str;
  }

  private String createFFormatString(Vector db, HashMap tbl, HashMap fform) {
    this.addMessage("[creating fieldFormat List]");
    String str = "";
    str += "var fieldFormatList = new Array();\n";
    for (int i = 0; i < db.size(); i++) { //looping in database
      String dbName = db.get(i).toString();
      Vector v = (Vector) tbl.get(dbName); // geting tables
      str += " fieldFormatList['" + dbName + "'] = new Array();\n";
      for (int j = 0; j < v.size(); j++) {
        String tblName = v.get(j) + "";
        HashMap vv = (HashMap) ( (HashMap) fform.get(dbName)).get(tblName); // geting fields
//        HashMap vv = (HashMap)fform.get(tblName); // getting fields
        str += " fieldFormatList['" + dbName + "']['" + tblName +
            "'] = new Array(); \n";
        String fields[] = new String[vv.size()];
        vv.keySet().toArray(fields);
        for (int k = 0; k < fields.length; k++) {
          str += "fieldFormatList['" + dbName + "']['" + tblName + "']['" +
              fields[k] + "']='" + vv.get(fields[k]) + "'; ";
        }
      }
    }
    this.addMessage("[created fieldFormat List]");
    return str;
  }

  //*** nov 13 ***
   public boolean approveDTS(String dtsNo, String clientID, String ap,
                             String userID, String remarks) {
     boolean retVal = false;
     if (ap.equals("U")) {
       updateDTSStatus(dtsNo, clientID, "U", "", remarks);
       retVal = true;
     }
     else if (ap.equals("A")) {
       updateDTSStatus(dtsNo, clientID, "A", userID, remarks);
       retVal = true;
     }
     return retVal;
   }

  public String updateDTSStatus(String dtsNo, String clientID, String status,
                                String userID, String remarks) {
    String errString = "";
    strSQL = " sp_UpdateDTSStatus " +
        "'" + clientID + "'," +
        "" + dtsNo + "," +
        "'" + status + "'," +
        "'" + userID + "'," +
        "'" + remarks.replace('\'', '`') + "'," +
        "NULL";
    this.execute(strSQL);
    return errString;
  }

  public String updateDTSMappingHistory(String dtsNo, String dtsSetNo,
                                        String clientID, String category,
                                        String keyField, String userID) {
    strSQL = " sp_AddMappingHistory " +
        "'" + clientID + "'," +
        "" + dtsNo + "," +
        "" + dtsSetNo + "," +
        "'" + category + "'," +
        "'" + keyField + "'," +
        "'" + userID + "'," +
        "NULL";
    this.execute(strSQL);
    return this.getLastMessage();
  }

  //nov 14
  public void getListOfRecentChanges(String clientID, String dtsNo,
                                     String category) {
    //strSQL = "sp_ListRecentChanges '" + clientID + "'," + dtsNo + ",'" +category + "'";

    strSQL = "SELECT a.KeyField, a.UserID, a.ModifiedOn  FROM  ztbl_DTS_Mapping_Hist a, " +
          "(SELECT MAX(ModifiedOn) LastApproved FROM ztbl_DTS_Mast_Hist b1, " +
          "(SELECT MAX(ModifiedOn) LastUpdated FROM ztbl_DTS_Mast_Hist WHERE " +
          "ClientID = '" + clientID + "' AND DTSNo = " + dtsNo +" ) b2 WHERE  " +
          "ClientID = '" + clientID + "' AND DTSNo = " + dtsNo +" AND Status = 'A' AND ModifiedOn < b2.LastUpdated)b " +
          "WHERE a.ModifiedOn > b.LastApproved AND a.ClientID = '" + clientID + "' AND DTSNo = " + dtsNo + " AND " +
          "a.Category = '" + category + "'";

    getList(strSQL, "Source fields");
  }

  //nov 17
  public boolean getListOfUsers(String clientID) {
    if (!clientID.equals("")) {
      strSQL = "SELECT a.UserID,UserName,eMail FROM ztbl_DTS_Users a,ztbl_DTS_UsersAndClients b " +
          " WHERE a.UserID=b.UserID AND b.ClientID='" + clientID +
          "' ORDER BY UserName";
    }
    else {
      strSQL =
          "SELECT UserID,UserName,eMail FROM ztbl_DTS_Users ORDER BY UserName";
    }
    return getList(strSQL, "List of users");
  }

  public boolean getListOfUsers(String clientID, String notifyOn) {
    strSQL = "SELECT a.UserID,UserName,eMail FROM ztbl_DTS_Users a,ztbl_DTS_UsersAndClients b " +
        " WHERE a.UserID=b.UserID AND b.ClientID='" + clientID + "' AND " +
        " b.NotifyOn IN ('*','" + notifyOn + "') ORDER BY UserName";
    return getList(strSQL, "List of users");
  }

  //nov21
  public boolean retrieveDTS(String clientID, String dtsNo) {
    strSQL = "UPDATE ztbl_DTS_DTS_Mast SET status=" +
        "(SELECT Status FROM ztbl_DTS_Mast_Hist " +
        " WHERE ModifiedOn=(SELECT MAX(ModifiedOn) FROM ztbl_DTS_Mast_Hist " +
        " WHERE DTSNo=" + dtsNo + " AND ClientID='" + clientID + "')) " +
        " WHERE DTSNo=" + dtsNo + " AND ClientID='" + clientID + "'";
    return this.execute(strSQL);
  }

  public void getListOfDeletedDTS() {

    strSQL = "SELECT a.ClientID, b.ClientName, a.DTSNo, a.Version, " +
        "  to_char( a.CreationDate,'MM') || '-' ||  " +
        "  to_char( a.CreationDate,'DD') || '-' ||  " +
        "  to_number(to_char( a.CreationDate,'YYYY')) AS CreationDate " +
        " FROM ztbl_DTS_DTS_Mast a, ztbl_DTS_Clients b " +
        " WHERE a.Status='D' AND a.ClientID=b.ClientID " +
        " ORDER BY b.ClientName";

    getList(strSQL, "List of deleted DTS");
  }

  public String setSQLData(String s, int t) {
    if (s.equals("")) {
      return "NULL";
    }
    else {
      if (t == 1) {
        return s;
      }
      else {
        return "'" + s.replace('\'', '`') + "'";
      }
    }
  }

  public boolean getReportTrackOfChanges(String userID, String clientID,
                                         String dtsNo,
                                         String fromDate, String toDate) {
   /*
    strSQL = "sp_RptMappingChanges " +
        setSQLData(userID, 2) + "," +
        setSQLData(clientID, 2) + "," +
        setSQLData(dtsNo, 1) + "," +
        setSQLData(fromDate, 3) + "," +
        setSQLData(toDate, 3);
    */
    strSQL = "SELECT m.UserID,m.ClientID,m.DTSNo,m.Category,m.KeyField,m.ModifiedOn,r.BusinessRule OldRule," +
            "r1.BusinessRule RecentRule,u.UserName,c.ClientName FROM ztbl_DTS_Mapping_Hist m INNER JOIN " +
            "ztbl_DTS_Mapping_Rule_Hist rON r.TransactionID = m.TransactionID LEFT JOIN ztbl_DTS_Mapping_Rule r1 " +
	        "ON r1.ClientID = m.ClientID AND r1.DTSNo = m.DTSNo AND r1.SetNo = m.SetNo AND r1.Category = m.Category " +
            " AND r1.KeyField = m.KeyField LEFT JOIN ztbl_DTS_Users u ON u.UserID = m.UserID INNER JOIN " +
            "ztbl_DTS_Clients c ON c.ClientID = m.ClientID " +
            "WHERE m.ClientID = NVL('" + setSQLData(clientID, 2) + "', m.ClientID) " +
            "AND m.DTSNo = NVL('" + setSQLData(dtsNo, 1) + "', m.DTSNo) " +
            "AND m.UserID = NVL('" + setSQLData(userID, 2) + "', m.UserID) " +
            "AND DATEDIFF('DD', '" + setSQLData(fromDate, 3) + "', m.ModifiedOn) >= 0 " +
            "AND DATEDIFF('DD', '" + setSQLData(toDate, 3) + "', m.ModifiedOn) <= 0 ";
   return getList(strSQL, "Track Changes Report");
  }

  public boolean getUserDetail(String userID) {
    strSQL = "SELECT * FROM ztbl_DTS_Users WHERE userID='" + userID + "'";
    return getList(strSQL, "User Detail");
  }

  public boolean logMessage(String clientID, String DTSNo, String userID,
                            String userName,
                            String message) {

    strSQL = "INSERT INTO ztbl_DTS_UserMessages_Hist" +
        " (ClientID,DTSNo,MessageDate,UserID,UserName,Message) VALUES (" +
        "'" + clientID + "'," +
        DTSNo + "," +
        "sysdate ," +
        "'" + userID + "'," +
        "'" + userName + "'," +
        "'" + message + "')";

    return this.execute(strSQL);
  }

  public boolean getDTSCurrentStatus() {
    strSQL =
        "SELECT m.ClientID, c.ClientName, m.DTSNo, CASE  NVL( m.Status,  'C' ) " +
        "  WHEN 'C' THEN 'CREATED' " +
        "  WHEN 'A' THEN 'APPROVED' " +
        "  WHEN 'M' THEN 'MODIFIED' " +
        "  WHEN 'U' THEN 'UNAPPROVED' " +
        " END AS Status, " +
        "  NVL( 	to_char(m.LastUpdated,'MM') || '/' || to_char(m.LastUpdated,'DD') || '/' || to_char(m.LastUpdated,'YYYY') ,  " +
        " to_char(m.CreationDate,'MM') || '/' || to_char(m.CreationDate,'DD') || '/' || to_char(m.CreationDate,'YYYY')  ) AS Date, " +
        "  CASE  NVL( m.Status,  'C' ) " +
        "    WHEN 'C' THEN m.CreatedBy " +
        "    WHEN 'A' THEN m.ApprovedBy " +
        "    ELSE h.UserID " +
        "  END AS UserID " +
        " FROM ztbl_DTS_DTS_Mast m " +
        " JOIN ztbl_DTS_Clients c " +
        " ON c.ClientID = m.ClientID " +
        " LEFT JOIN ztbl_DTS_Mast_Hist h " +
        " ON h.ClientID = m.ClientID " +
        " AND h.DTSNo = m.DTSNo " +
        " AND h.ModifiedOn =  NVL( m.LastUpdated,  m.CreationDate ) " +
        " WHERE  NVL( m.Status,  'C' ) <> 'D'  ";
    return getList(strSQL, "DTS Current Status");
  }

  public String getClientDTSMap(String varName) {
    String sql =
        "select distinct ClientID, DTSNo, Version from ztbl_DTS_DTS_Mast";
    String toRet = "";
    String ver = "";
    ver += varName + "_version = new Array();";
    HashMap map = new HashMap();
    HashMap verMap = new HashMap();
    this.executeQuery(sql);
    while (this.moveNext()) {
      String forClient = this.getData("ClientID");
      if (map.containsKey(forClient)) {
        Vector v = (Vector) map.get(forClient);
        v.add(this.getData("DTSNo"));

        Vector vers = (Vector) verMap.get(forClient);
        vers.add(this.getData("Version"));
      }
      else {
        Vector v = new Vector();
        v.add(this.getData("DTSNo"));
        map.put(forClient, v);

        Vector vers = new Vector();
        vers.add(this.getData("Version"));
        verMap.put(forClient, vers);
      }
    }
    String[] keys = new String[map.size()];
    map.keySet().toArray(keys);
    for (int i = 0; i < keys.length; i++) {
      toRet += varName + "['" + keys[i] + "'] = new Array(); \n";
      ver += varName + "_version['" + keys[i] + "'] = new Array(); \n";
      toRet += varName + "['" + keys[i] + "'] = [";
      ver += varName + "_version['" + keys[i] + "'] = [";
      Vector v = (Vector) map.get(keys[i]);
      Vector vers = (Vector) verMap.get(keys[i]);
      for (int j = 0; j < v.size(); j++) {
        toRet += "'" + v.get(j) + "'";
        ver += "'" + vers.get(j) + "'";
        if (j < v.size() - 1) {
          toRet += ", ";
          ver += ", ";
        }
      }
      toRet += "]; \n";
      ver += "]; \n";
    }
    return toRet + "\n" + ver;
  }

  public boolean getClientsWithDTS() {
    String sql = " select distinct m.ClientID, c.ClientName from ztbl_DTS_DTS_Mast m, ztbl_DTS_Clients c" +
        " where m.ClientID=c.ClientID and c.ClientID not in ('999', '998')" +
        " order by c.ClientName";
    this.executeQuery(sql);
    if (this.myRS != null) {
      return true;
    }
    return false;
  }

  public boolean copyDTS2NewDTS(String sourceClientID, String sourceDTS,
                                String targetClient, String user) {
    strSQL = "sp_CopyDTS '" + sourceClientID + "'," + sourceDTS + ",'" +
        targetClient + "', '" + user + "'";
    return this.execute(strSQL);
  }

  public boolean copyDTSSelectedSetsPrep(String sourceClientID, String sourceDTS,
                                         String targetClient,   String user) {
    strSQL = "sp_CopyDTSSelectedSetsPrep '" + sourceClientID + "'," + sourceDTS + ",'" +
        targetClient + "', '" + user + "'";
    return this.execute(strSQL);
  }

  public boolean copyDTSSelectedSets(String sourceClientID, String sourceDTS,
                                     String targetClient,   String category, String sets) {
    strSQL = "sp_CopyDTSSelectedSets '" + sourceClientID + "'," + sourceDTS + ",'" +
        targetClient + "', '" + category + "', '" + sets + "'";
    return this.execute(strSQL);
  }

  public boolean renumberDTSSet(String clientID, String DTSno, String category,
                                String oldSetNo, String newSetNo) {
    strSQL = "sp_RenumberDTSSet '" + clientID + "'," + DTSno + ",'" +
             category + "'," + oldSetNo + "," + newSetNo;
    return this.execute(strSQL);
  }

  public boolean repairDTSSetNumbers(String clientID, String DTSno) {
    strSQL = "sp_RepairDTSSetNumbers '" + clientID + "'," + DTSno;
    return this.execute(strSQL);
  }

  public boolean switchVersion(String clientID, String DTSNo, String version) {
      strSQL = "sp_SwitchVersion '" + clientID + "', '" + DTSNo +
        "', '" + version + "'";
      return this.execute(strSQL);
  }

 public boolean getListOfAllTableAndFields(String databaseID) {
    this.addMessage("get List Of All Table And Fields");
     strSQL = "SELECT TABLE_NAME TableName, COLUMN_NAME FieldName, " +
              "CASE WHEN DATA_TYPE LIKE '%NUMBER%' AND DATA_PRECISION IS NOT NULL THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ',' || CAST((DATA_LENGTH-DATA_PRECISION) AS VARCHAR(5)) || ')' " +
              "WHEN DATA_TYPE LIKE '%CHAR%' OR DATA_TYPE LIKE '%NUMBER%'  THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ')' " +
              "ELSE DATA_TYPE END FROM ALL_TAB_COLS a, " +
             "(SELECT DATABASENAME FROM ztbl_DTS_Databases WHERE DATABASEID=" + databaseID + ") b " +
             "WHERE a.owner = b.DATABASENAME ";
    return this.executeQuery(strSQL)!= null;
  }

}


