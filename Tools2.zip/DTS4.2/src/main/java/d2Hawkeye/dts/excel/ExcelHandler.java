package d2Hawkeye.dts.excel;

import java.util.*;

import com.jacob.com.*;

/**
 * <br><b>Prepared By:</b>	Raj K Gaire
 * <br><b>Purpose:</b>		To Import data that is available in Excel Format
 * <br><b>Description:</b>	This is the important abstract class that is made as an interface to
 handles the communication part between the excel file and other java classes.
    It uses the ExcelComWrapper - prepared by Mr Raj Bhushan Thakuri, that in deep uses
    JACOB, a JNI application to handle the COM objects.

 * <br><b>Date:</b>			May 18, 2003
 * <br><b>Modified:</b>
 */
public abstract class ExcelHandler {
  protected boolean debug = true;
  protected boolean application = false;
  ExcelComWrapper xlsObj;
  public Object workBook, workSheet, cell;
  public int sheetCount = 0;

  public Vector display;
  public String error = "";

//  private int mergeRowLimit = 5;
//  private int mergeColumnLimit = 15;

  public ExcelHandler() {
    display = new Vector();
  }

  /**
   * open excel application
   */
  public boolean openApplication() {
    try {
      xlsObj = new ExcelComWrapper("c\\", "c\\");
      xlsObj.openApplicationExcel();
      //xlsObj.initExcelApp(true); // make the excel file visible
      xlsObj.initExcelApp(); // make excel file invisible , run in background process
      System.out.println("Application opened");
      application = true;
    }
    catch (Exception e) {
      application = false;
      System.out.println("Application open failure");
    }
    return application;
  }

  /** sets debug mode. if true all the messages will be stored in display vector. */
  public void setDebug(boolean a) {
    debug = a;
  }

  /** returns active sheet of an opened excel file where workbook is default. also stores it in itself for default use. */
  public Object getActiveSheet() {
    if (workBook != null) {
      workSheet = getActiveSheet(workBook);
      return workSheet;
    }
    System.out.println("Error: no workbook present");
    return null;
  }

  /** return active sheet for given work boook */
  public Object getActiveSheet(Object WorkBook) {
    try {
      workSheet = Dispatch.get((Dispatch)WorkBook, "ActiveSheet").toDispatch();
      System.out.println("active sheet obtained");
    }
    catch (Exception e) {
      System.out.println("Error: on active sheet obtaining " + e);
      workSheet = null;
    }
    return workSheet;
  }

  /** return the number of sheets in the default work book*/
  public int getSheetCount() {
    return getSheetCount(workBook);
  }

  /** return the number of sheets in the specified work book*/
  public int getSheetCount(Object WorkBook) {
    int sheetNo = 0;
    try {
      Object sheets = Dispatch.call((Dispatch)WorkBook, "WorkSheets").toDispatch();
      sheetNo = Dispatch.call((Dispatch)sheets, "Count").toInt();
      if (debug) {
        display.add("Sheet count is = " + sheetNo);
      }
    }
    catch (Exception e) {
      sheetNo = 0;
      if (debug) {
        display.add("Sheet count Exception " + e);
      }
    }
    return sheetNo;
  }

  /** return first sheet */
  public Object getFirstSheet() {
    workSheet = getFirstSheet(workBook);
    return workSheet;
  }

  /** return first sheet of specified work book*/
  public Object getFirstSheet(Object WorkBook) {
    if (debug) {
      display.add("Display: get first sheet called!");

    }
    Object ActiveSheet = getActiveSheet(WorkBook);
    if (debug) {
      display.add("Display: active sheet is = " + getSheetName(ActiveSheet));

    }
    Object sheet = new Object();
    Object sheetPrev = new Object();
    sheet = ActiveSheet;
    sheetPrev = sheet;
    while (sheet != null && !getSheetName(sheet).trim().equals("")) { // is needed !getSheetName(sheet).trim().equals("")
      sheetPrev = sheet;
      sheet = getPreviousSheet(sheet);
    }
    if (debug) {
      display.add("First Sheet found. Name is " + getSheetName(sheetPrev));
    }
    return sheetPrev;
  }

  /** return previous sheet of the current sheet*/
  public Object getPreviousSheet() {
    workSheet = getPreviousSheet(workSheet);
    return workSheet;
  }

  /** return previous sheet of the provided sheet */
  public Object getPreviousSheet(Object WorkSheet) {
    if (WorkSheet == null) {
      error = "Error: Work Sheet is null!!";
      return null;
    }
    Object sheet;
    try {
      sheet = Dispatch.call((Dispatch)WorkSheet, "Previous").toDispatch();
      if (getSheetName(sheet).trim().equals("")) {
        return null;
      }
      if (debug) {
        display.add("Previous Sheet is : " + getSheetName(sheet));
      }
    }
    catch (Exception e) {
      sheet = null;
      if (debug) {
        display.add("No Previous Sheet is there " + e);
      }
    }
    return sheet;
  }

  /** return next sheet of the current sheet*/
  public Object getNextSheet() {
    workSheet = getNextSheet(workSheet);
    return workSheet;
  }

  /** return next sheet of the provided sheet */
  public Object getNextSheet(Object WorkSheet) {
    if (WorkSheet == null) {
      error = "Error: Work Sheet is null!!";
      return null;
    }
    Object sheet;
    try {
      sheet = Dispatch.call((Dispatch)WorkSheet, "Next").toDispatch();
      if (getSheetName(sheet).trim().equals("")) {
        return null;
      }
      if (debug) {
        display.add("Next Sheet is : " + getSheetName(sheet));
      }
    }
    catch (Exception e) {
      sheet = null;
      if (debug) {
        display.add("No Next Sheet is there " + e);
      }
    }
    return sheet;
  }

  /** return last sheet of the current sheet*/
  public Object getLastSheet() {
    workSheet = getLastSheet(workBook);
    return workSheet;
  }

  /** return last sheet of the provided work book*/
  public Object getLastSheet(Object WorkBook) {
    if (WorkBook == null) {
      error = "Error: Work Sheet is null!!";
      return null;
    }
    Object ActiveSheet = getActiveSheet(WorkBook);
    Object sheet, sheetNext;
    sheet = ActiveSheet;
    sheetNext = sheet;
    while (sheet != null) {
      sheetNext = sheet;
      sheet = getNextSheet(sheet);
    }
    if (debug) {
      display.add("Last Sheet is : " + getSheetName(sheetNext));
    }
    return sheetNext;
  }

  /** return sheet at index i */
  public Object getSheet(int i) {
    if (i < 1) {
      error = "Error: Improper worksheet no - less than 1 !!! -> " + i;
      return null;
    }

    workSheet = getSheet(workBook, i);
    return workSheet;
  }

  /** return sheet index */
  public int getIndex(Object WorkSheet) {
    int i = Dispatch.call((Dispatch)WorkSheet, "Index").toInt();
    return i;
  }

  public Object getSheet(Object WorkBook, int i) {
    if (i < 1 || WorkBook == null) {
      error = "Error: Improper worksheet no - less than 1!!! -> " + i;
      return null;
    }
    int max = getSheetCount(WorkBook);
    if (debug) {
      display.add("Display: sheetCount = " + max);
    }
    if (i > max) {
      error = "Error: Index out of range. Max Sheet = " + max +
          ". Indexed Requested to " + 1;
      return null;
    }

    Object activeSheet = getActiveSheet(WorkBook);
    int indx = getIndex(activeSheet);
    if (indx == i) {
      return activeSheet;
    }
    if (indx < i) {
      for (; indx < i; indx++) {
        activeSheet = getNextSheet(activeSheet);
        if (debug) {
          display.add("Display: active next sheet = " +
                      getSheetName(activeSheet));
        }
      }
      return activeSheet;
      // move forward
    }
    if (indx > i) {
      for (; indx > i; indx--) {
        activeSheet = getNextSheet(activeSheet);
        if (debug) {
          display.add("Display: active next sheet = " +
                      getSheetName(activeSheet));
        }
      }
      return activeSheet;
    }
    return null;
  }

  public String getSheetName() {
    return getSheetName(workSheet);
  }

  public String getSheetName(Object WorkSheet) {
    String name = "";
    try {
      name = Dispatch.call((Dispatch)WorkSheet, "Name").toString();
    }
    catch (Exception e) {
      error = "Error: " + e.toString();
    }
    return name;
  }

  /** return sheet of specified name*/
  public Object getSheet(String SheetName) {
    workSheet = getSheet(workBook, SheetName);
    return workSheet;
  }

  public Object getSheet(Object WorkBook, String SheetName) {
    System.out.println("getSheet called for sheet = " + SheetName);
    if (WorkBook == null) {
      if (debug) {
        display.add("Display: No Workbook present");

      }
    }
    int sheetCount = getSheetCount(WorkBook);
    if (debug) {
      display.add("Sheet Count is : " + sheetCount);

    }
    SheetName = SheetName.toLowerCase().trim();
    if (debug) {
      display.add("Display: sheet to be found is = " + SheetName);

    }
    if (SheetName.equals("")) {
      error = "Error: Sheet Name not specified!!";
      return null;
    }

    if (sheetCount == 0) {
      error = "Error: No sheet present in the work book!!";
      return null;
    }

    Object sheet = getFirstSheet(WorkBook);
    if (debug) {
      display.add("Display: First Sheet is " + getSheetName(sheet));

    }
    String sheetName = "";
    //---edited by upendra
    for (int i = 1; i <= sheetCount; i++) {
      sheetName = getSheetName(sheet).toLowerCase();
      if (debug) {
        display.add("Sheet names :" + sheetName);
      }
      if (sheetName.equals(SheetName)) {
        return sheet;
      }
      sheet = getNextSheet(sheet);
    }
    return null;
  }

  /** check if the cell is mearged with other cells */
  private boolean isMerged(Object cell) {
    return Dispatch.call((Dispatch)cell, "MergeCells").toBoolean();
  }

  public Object getSheet(Object WorkBook) {
    return getActiveSheet(WorkBook);
  }

  public Object getSheet() {
    workSheet = getSheet(workBook);
    return workSheet;
  }

  /** read data from the specified cell */
  public String getCellData(int row, int col) {
    return getCellData(workSheet, row, col);
  }

  public String getCellData(Object WorkSheet, int row, int col) {
    String data = "";
    /**
       Dispatch.invoke(sheet, "Range", Dispatch.Get,
                                    new Object[] {"A1"},
                                    new int[1]).toDispatch();
     */

    Object cell = getCell(WorkSheet, row, col);
    data = Dispatch.call((Dispatch)cell, "Value").toString();
    return data;
  }

  public Object getCell(int row, int col) {
    return getCell(workSheet, row, col);
  }

  public Object getCell(Object WorkSheet, int row, int col) {
    Object cell = Dispatch.invoke((Dispatch)WorkSheet, "Range", Dispatch.Get,
                                  new Object[] {translateToColumnFormat(col) +
                                  row}
                                  , new int[2]).toDispatch();
    return cell;
  }

  public String translateToColumnFormat(int row) {
    if (row == 0) {
      return "";
    }                 
    row--;
    int i, j;
    String a, b;
    String code = "";
    i = row / 26; // integer division
    j = row % 26;
    if (i > 0) {
      i = i + 'A';
      i--; //added by upendra
      a = (char) i + "";
    }
    else {
      a = "";
    }
    j = j + 'A';
    b = (char) j + "";
    code = a + "" + b;
    return code;
  }

  public String getData(int row, int col) {
    return getCellData(row, col);
  }

  public String getData(Object WorkSheet, int row, int col) {
    return getCellData(WorkSheet, row, col);
  }

  public abstract void open(String fileName, int saveMode);

  public void close() {
    close( (Dispatch) workBook);
  }

  public void close(Dispatch WorkBook) {
    xlsObj.closeExcelFile(WorkBook);
  }

  public void quit() {
    xlsObj.quitExcelApplication(true);
    ComThread.Release();
  }

  /*
    public void test() {
      ActiveXComponent xl = new ActiveXComponent("Excel.Application");
      Object xlo = xl.getObject();
      try {
        display.add("version=" + xl.getProperty("Version"));
        display.add("version=" + Dispatch.get(xlo, "Version"));
        xl.setProperty("Visible", new Variant(true));
        Object workbooks = xl.getProperty("Workbooks").toDispatch();
        Object workbook = Dispatch.get(workbooks, "Add").toDispatch();
        Object sheet = Dispatch.get(workbook, "ActiveSheet").toDispatch();
        Object a1 = Dispatch.invoke(sheet, "Range", Dispatch.Get,
                                    new Object[] {"A1"}
                                    ,
                                    new int[1]).toDispatch();
        Object a2 = Dispatch.invoke(sheet, "Range", Dispatch.Get,
                                    new Object[] {"A2"}
                                    ,
                                    new int[1]).toDispatch();
        Dispatch.put(a1, "Value", "123.456");
        Dispatch.put(a2, "Formula", "=A1*2");
        display.add("a1 from excel:" + Dispatch.get(a1, "Value"));
        display.add("a2 from excel:" + Dispatch.get(a2, "Value"));
        Variant f = new Variant(false);
        Dispatch.call(workbook, "Close", f);
      }
      catch (Exception e) {
        e.printStackTrace();
      }
      finally {
        xl.invoke("Quit", new Variant[] {});
      }
    }
   */
}
