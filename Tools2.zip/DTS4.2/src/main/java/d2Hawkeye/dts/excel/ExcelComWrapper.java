package d2Hawkeye.dts.excel;

import java.sql.*;

import com.jacob.activeX.*;
import com.jacob.com.*;

/**
 * <br><b>Filename      : </b>ExcelComWrapper.java
 * <br><b>Modified from	: </b>ExcelCom.java
 * <br><b>Description   : </b>This class utilizes Java COM Wrappers to dispatch calls to MsExcel(97/2000)
 *                 Requires: jacob.jar, jacob.dll
 * <br><b>Author        : </b>Raj B.Thakuri (ITEG/KTM)
 * <br><b>Created       : </b>03/03/2003
 */
public class ExcelComWrapper {
  public static String baseExcelPath = "C:\\";
  public static String baseTxtPath = "C:\\";
  static ActiveXComponent applicationExcel;
  static Dispatch systemTasks;
  static Dispatch myWorkBooks;
  static Dispatch myWorkSheets;
  static Dispatch currentWorkSheet;
  static boolean appExcelAlreadyOpen;

  /** Takes the path for excel and file. */
  public ExcelComWrapper(String xlsPath, String txtPath) {
    //set base documents and datasource paths
    baseExcelPath = xlsPath;
    baseTxtPath = txtPath;
  }

  /** Open Excel Application. If Excel already open return handle to the open application. */
  public void openApplicationExcel() {
    try {
      applicationExcel = new ActiveXComponent("Excel.Application");
      /* fetch handle to default Workbook */
      //myWorkBooks = Dispatch.get(applicationExcel,"WorkBooks").toDispatch();
      //---changed by upendra
      myWorkBooks = applicationExcel.getProperty("Workbooks").toDispatch();
      System.out.println("Success: Opened new Excel Application");
    }
    catch (Exception e) {
      System.out.println("Error: Could not open new Excel Application ->");
      e.printStackTrace();
    }

  }

  /*** Initialize Excel Application */
  public void initExcelApp() {
    initExcelApp(false);
  }

  public void initExcelApp(boolean visible) {
    try {
      //applicationExcel.setProperty("Visible",new Variant(true)); or
      //Dispatch.put(applicationExcel,"Visible",new Variant(visible));
      //---changed by upendra
      applicationExcel.setProperty("Visible", new Variant(visible));
      System.out.println("Success: initalized excel application");
    }
    catch (Exception e) {
      System.out.println("Error: could not initialize MS Excel  ->");
//            e.printStackTrace();
    }
  }

  /** Open a workbook: if not opened, open new else if opened and valid return handle */
  public Dispatch openExcelFile(String pathToFile, String fileName) {

    Dispatch myWorkBook = new Dispatch();
    boolean fileAlreadyOpen = false;
    String fileVar = pathToFile + fileName;
    if (pathToFile == "" | fileName == "") {
      /* open a new document */
      try {
        myWorkBook = Dispatch.call(myWorkBooks, "Add").toDispatch();
      }
      catch (Exception e) {
        e.printStackTrace();
        System.out.println("Error: could not open new excel document.");
      }
    }
    else {
      /* open existing document */
      try {
        /* check if the document is already open */
        System.out.println("Excel documents currently open: ");
        //String workBookName;
        int numOpenDocs = Dispatch.call(myWorkBooks, "Count").toInt();
        if (numOpenDocs == 0) {
          System.out.println("0 - No documents open.");
        }

        if (fileAlreadyOpen) {
          myWorkBook = Dispatch.call(myWorkBooks, "Item", new Variant(fileName)).
              toDispatch();
          Dispatch.call(myWorkBook, "Activate");
        }
        else {
          myWorkBook = Dispatch.call(myWorkBooks, "Open", new Variant(fileVar)).
              toDispatch();
          fileAlreadyOpen = true; //--added by upendra
        }
      }
      catch (Exception e) {
        e.printStackTrace();
        System.out.println("Error opening excel file : " + fileVar);
      }
    }
    return myWorkBook;
  }

  /*** Close opened Excel File */
  public void closeExcelFile(Dispatch myFile) {
    try {
      Dispatch.call(myFile, "Close", new Variant(true));
    }
    catch (Exception e) {
      e.printStackTrace();
      System.out.println("Error closing Excel file : " + myFile.toString());
    }
  }

  /*** Close Excel Application */
  public void quitExcelApplication() {
    quitExcelApplication(false);
  }

  public void quitExcelApplication(boolean alert) {
    try {
      Dispatch.put(applicationExcel, "DisplayAlerts", new Variant(alert));
      applicationExcel.invoke("Quit", new Variant[] {});
      System.out.println("Excel Application Closed.");
    }
    catch (Exception e) {
      e.printStackTrace();
      System.out.println("Error closing Excel Application.");
    }
  }

  /** Save Excel File */
  public void saveWorkBook(Dispatch myFile, String fileSavePath) {
    if (fileSavePath == "") {
      /* if filename empty, save to c:\ with date as filename */
      try {
        String savedFileName = new String(baseExcelPath + "XlsSaved_" +
                                          (new java.util.Date()).getTime() +
                                          ".xls");
        Dispatch.call(myFile, "SaveAs", new Variant(savedFileName));
        System.out.println("File saved to default location(c:) as: " +
                           savedFileName);
      }
      catch (Exception e) {
        e.printStackTrace();
        System.out.println("Error saving file to default location (c:): " +
                           myFile.toString());
      }
    }
    else {
      try {
        Dispatch.call(myFile, "SaveAs", fileSavePath);
        System.out.println("Fie successfully saved as : " + fileSavePath);
      }
      catch (Exception e) {
        e.printStackTrace();
        System.out.println("Error saving file: " + myFile.toString() + " to " +
                           fileSavePath);
      }
    }
  }

  /** function to open text file in Excel */
  public void openTextFile(String textFile) {
    try {
      Variant[] openArgs = new Variant[] {
          new Variant(textFile), //Filename
          //new Variant(1"), 			//Origin
          //new Variant(1), 			//StartRow
          //new Variant(1), 			//DataType
          //new Variant(-4142), 			//TextQualifier
          //new Variant(false), 			//ConsecutiveDelimiter
          //new Variant(true), 			//tab
          //new Variant(false), 			//semicolon
          //new Variant(false), 			//comma
          //new Variant(false), 			//space
          //new Variant(false),			//others
          //new Variant(false), 			//otherChar
          //new Variant("Array(Array(1, 1), Array(2, 1), Array(3, 1), Array(4, 1), Array(5, 1), Array(6, 1), Array(7, 1), Array(8, 1), Array(9, 1), Array(10, 1))")
          //FieldInfo
      };
      Dispatch.callSub(myWorkBooks, "OpenText", new Variant(textFile));
    }
    catch (Exception e) {
      System.out.println("Error opening text file: " + textFile.toString());
      e.printStackTrace();
    }
  }

  /** function to call macro in an excel file */
  public Variant runMacro(Dispatch myFile, String macroName) {
    Variant result = new Variant();
    try {
      String command = new String();
      String myFileName = Dispatch.call(myFile, "Name").toString();
      //format macro name
      command = myFileName + "!" + macroName;
      //Calling macro without parameters
      //Dispatch.call(applicationExcel,"Run",new Variant(command));
      //with parameters
      result = Dispatch.call(applicationExcel, "Run", new Variant(command),
                             new Variant(baseTxtPath + "dxcgapp.txt"));
    }
    catch (Exception e) {
      System.out.println("Error executing macro :" + macroName);
      e.printStackTrace();
    }
    return result;
  }

  /** private method for calculating the number of cells defining a zone for use in inserting data */
  private String specifiedZone(int row, int column) {
    String zoneData = new String();
    if (column <= 26) {
      //values in A-Z cols of excel sheet
      char letterAlpha = java.lang.Character.toUpperCase(java.lang.Character.
          forDigit(9 + column, 36));
      zoneData = new String("A1:" + letterAlpha + row);
    }
    else {
      //values in AA-ZZ of excel sheet
      char letterAlpha1 = java.lang.Character.toUpperCase(java.lang.Character.
          forDigit(9 + (int) (column / 26), 36));
      char letterAlpha2 = java.lang.Character.toUpperCase(java.lang.Character.
          forDigit(9 + column - 26 * ( (int) (column / 26)), 36));
      zoneData = new String("A1:" + letterAlpha1 + letterAlpha2 + row);
    }
    return zoneData;
  }

  /** function for retrieving data from a database and inserting in a worksheet using J-ODBC*/
  public Dispatch fillWorkSheet(Dispatch myFile, String baseODBC,
                                String dbTableName) {
    Dispatch myWorkBook = new Dispatch();
    String[][] obj;
    try {
      //Connect to the database
      String dbUrl = "jdbc:odbc:" + baseODBC;
      String user = "";
      String password = "";

      // Load database drivers
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      Connection c = DriverManager.getConnection(dbUrl, user, password);
      Statement s = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                                      ResultSet.CONCUR_UPDATABLE);
      //execute query
      ResultSet r = s.executeQuery("SELECT * FROM " + dbTableName);
      //get number of rows and columns
      ResultSetMetaData rsmd = r.getMetaData();
      int numberOfColumns = rsmd.getColumnCount();
      r.last();
      int numberOfRows = r.getRow();
      //create array to store data + column names
      obj = new String[numberOfRows + 1][numberOfColumns];
      //get column names
      for (int j = 1; j <= numberOfColumns; j++) {
        obj[0][j - 1] = rsmd.getColumnName(j);
      }
      r.first();
      //get data
      int i = 1;
      do {
        for (int j = 0; j < numberOfColumns; j++) {
          obj[i][j] = r.getString(j + 1);
        }
        i++;
      }
      while (r.next());

      //insert data to Worksheet
      myWorkBook = insertData(myFile, obj);

      //close resultset
      s.close();
    }
    catch (SQLException e1) {
      System.out.println("Error executing SQL query");
      e1.printStackTrace();
    }
    catch (ClassNotFoundException e2) {
      System.out.println("Error importing data to worksheet.");
      e2.printStackTrace();
    }
    return myWorkBook;
  }

  /** function to insert data in a worksheet form a String table array */
  public Dispatch insertData(Dispatch myFile, String[][] obj) {
    try {
      int row = obj.length;
      int column = obj[0].length;
      String zoneData = specifiedZone(row, column);
      Object sheet = Dispatch.get(myFile, "ActiveSheet").toDispatch();
      Object range = Dispatch.invoke((Dispatch)sheet,
                                     "Range",
                                     Dispatch.Get,
                                     new Object[] {zoneData}
                                     ,
                                     new int[1]
                                     ).toDispatch();
      //create corresponding table compatible with Excel
      SafeArray sa = new SafeArray(Variant.VariantVariant, row, column);
      Variant v = new Variant();
      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          v.putString(obj[i][j]);
          sa.setVariant(i, j, v);
        }
      }
      //assign the values to Excel range
      v.putSafeArray(sa);
      Dispatch.put((Dispatch)range, "Value", v);
    }
    catch (Exception e) {
      System.out.println("Error inserting values to worksheet: " +
                         myFile.toString());
      e.printStackTrace();
    }
    return myFile;
  }

}
