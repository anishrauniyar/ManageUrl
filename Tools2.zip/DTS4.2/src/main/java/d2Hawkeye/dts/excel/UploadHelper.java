package d2Hawkeye.dts.excel;

import java.io.*;

/**
 * <br><b>NO MORE NEED NOW</b>

 * <br><b>Prepared By:</b>	Raj K Gaire
 * <br><b>Purpose:</b>		To Import data that is available in Excel Format
 * <br><b>Description:</b>	This class handles importing part of the excel file.
    With the help of ExcelHandler class, it parses data from the excel files.
    It uses DBHandler class to store the imported data to the database.

 * <br><b>Date:</b>			May 28, 2003
 * <br><b>Modified:</b>
 */
public class UploadHelper {
  private String path = DTSImporter.basePath + "\\";
  private String fileName = "";
  private File f;
  private FileOutputStream fos;

  public UploadHelper() {
    f = new File(path + fileName);
    openStream();
  }

  private void openStream() {
    try {
      fos = new FileOutputStream(f);
    }
    catch (Exception e) {
      System.out.println("[UploadHelper] Error at openStream: " + e);
    }
  }

  public String getFilePath() {
    return path;
  }

  public void setFilePath(String s) {
    path = s;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String s) {
    fileName = s;
  }

  public void setFile(File f) {
    this.f = f;
    openStream();
  }

  public File getFile() {
    return f;
  }

  public void reset() {
    f = new File(path + fileName);
    openStream();
  }

  public void saveFile(String fname, byte[] data) {
    fileName = fname;
    reset();
    try {
      fos.write(data);
    }
    catch (Exception e) {
      System.out.println("[UploadHelper] Error at saveFile: " + e);
      deleteFile(fname);
    }
  }

  public boolean deleteFile(String fileName) {
    this.fileName = fileName;
    reset();
    return f.delete();
  }
}
