package d2Hawkeye.dts.excel;

import java.io.*;
import java.util.*;

/**
 * <br><b>Prepared By:</b>	Raj K Gaire
 * <br><b>Purpose:</b>		To provide file display in c:\ImportExcel\log\ folder
 * <br><b>Description:</b>	the logs are created each time the excel files are Imported....
 * 				This class is used to retrieve the logs in that case.
 *
 * <br><b>Date:</b>			May 20, 2003
 * <br><b>Modified:</b>
 */
public class DTSLogView {
  public static String basePath = "c:\\ImportExcel\\logs"; //C:\ImportExcel\logs
  File f;
  FileInputStream is;
  /**
   * Used for viewing of log as a bean from jsp files
   * */
  public String s = "";

  /**
   * A constructor<br>
   * It does not do anything more than just initalizing the object as default.
   */
  public DTSLogView() {
    File bPath = new File(this.basePath);
    if (!bPath.exists()) {
      bPath.mkdirs();
    }
  }

  /**
   * <b>param</b> fileName. Note that the file name should not contain any extension, it will add .xls.html as extension of the file.<br>
   * It takes the filename as a parameter to retrieve the logs of the file.
   * This file should be the one that is imported.
   * If the file is not found or any exception is resulted, it will return a list of all files in the c:\ImportExcel\logs folder
   */
  public Vector getLog(String file) {
    Vector log = new Vector();
    if (file != null && !file.equals("null")) {
      try {
        f = new File(basePath + "\\" + d2Hawkeye.dts.TextEncoder.encode(file) + ".xls.html");
        is = new FileInputStream(f);
        String s = "";
        int c = is.available();
        while (c > 0) {
          s += "" + (char) is.read();
          c--;
        }
        is.close();
        log.add(s);
//				log.append(getLogFileList());
      }
      catch (Exception e) {
        System.out.println("[DTSLogView] Error at getLog: " + e);
        // file not found
        return getLogFileList();
      }
    }
    else {
      return getLogFileList();
    }
    return log;
  }

  /**
   * <b>returns:</b> a vector containing names of all files having extensions '.xls.html'.
   * <br> Here too the reference folder is c:\ImportExcel\logs by default
   */
  public Vector getLogFileList() {
    Vector v = new Vector();
    int i, indx;
    String fname;
    try {
      File fl = new File(basePath);
      File[] child = fl.listFiles();
      for (i = 0; i<child.length; i++) {
        if (child[i].isDirectory()) {
          continue;
        }
        fname = child[i].getName();
        indx = fname.indexOf(".xls.html");
        if (indx > 0) {
          v.add( d2Hawkeye.dts.TextEncoder.encode(fname));
        }
      }
    }
    catch (Exception e) {
      System.out.println("[DTSLogView] Error at getLogFileList: " + e);
    }
    v = format(v);
    return v;
  }

  /**
   * <b>returns:</b> a vector containing formated names of all files having extensions '.xls.html'
   * <br><b>param:</b> a vector containing the list of files.
   * <br> It forms the linkes for the files. It is actually used by the getLogFileList() function.
   * However it can be used separately too.
   */
  public Vector format(Vector v) {
    Vector temp = new Vector();
    String s = "";
    for (int i = 0; i < v.size(); i++) {
      s = v.elementAt(i).toString();
      s = s.substring(0, s.indexOf(".xls.html"));
      s = "<a href='?fileName=" + d2Hawkeye.dts.TextEncoder.encode(s) + "'>" + s + ".log</a>";
      temp.add(s);
    }
    return temp;
  }
}
