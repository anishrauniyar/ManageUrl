package d2Hawkeye.dts.excel;

import java.io.*;

/**
 * <br><b>Purpose:</b>		To delete the log file summary.
 * <br><b>Prepared By:</b>	Raj K Gaire.
 * <br><b>Date:</b>			May 20, 2003.
 * <br><b>Modified:</b>.
 * <br> log field summary is a text file (logsummary.txt) that contains the summary of all the updates.
 * It appends the logs summary for each update, but not showing success or failure!
 * The base path of this file is c:\ImportExcel.
 */
public class DTSDelLog {
//	String basePath = "c:\\ImportExcel"; // using basepath from DTSImporter
  public DTSDelLog() {}

  /**
   * Removes all the logs. Reinitializes the file for fresh logs.
   */
  public void delLog() {
    try {
      File f = new File(DTSImporter.basePath + "\\logsummary.txt");
      FileOutputStream of = new FileOutputStream(f);
      of.write( ("Log File Summary:").getBytes());
      of.close();
    }
    catch (Exception e) {
      System.out.println("[DTSDelLog] Error at delLog: " + e);
    }
  }
}
