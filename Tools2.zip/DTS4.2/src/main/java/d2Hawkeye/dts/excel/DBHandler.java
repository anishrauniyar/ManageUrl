package d2Hawkeye.dts.excel;

import java.util.*;

import d2Hawkeye.dts.*;

/**
 * <b>Prepared By:</b>	Raj K Gaire
 * <br><b>Purpose:</b>		To Import data that is available in Excel Format
 * <br><b>Description:</b>	This class handles import of data to the database.
 It uses sqlBean class that is the basic class for this purpose. It is as an
    interface between database and the imported data in the form of SourceData

 * <br><b>Date:</b>			May 18, 2003
 * <br><b>Modified:	</b>
 */
public class DBHandler
    extends sqlBean {
  /**
   * To Store error logs
   */
//  public Vector dbErrorLog = new Vector();
  private int databaseId;
  private HashMap theMap = null;
  private String version = null;

  /**
   * Calls makeConnection of the super class sqlBean and instantiates the statement (stmt)
   *
   */
  public DBHandler() {
    super();
    this.addMessage("<b>Success Log: </b><br>");
  }

  /**
   */
  public void cleanup() throws Exception {}

  /**
   * <b>param:</b>tableName, fields, respective values and their types (int=true, nonInt=false).
   * Creates and executes INSERT statement of SQL, with tablename, fields and values.<br>
   * Vector fieldType contains true if it is integer type and false for string type so that a value
   * can be inserted into quotes ('') or not.
   * <br> All the function requiring to perform inserting operation use this function. Like addDts, addSet etc
   */
  public void insert(String table, Vector fields, Vector values,
                     Vector fieldTypes) {
    String sql = "INSERT INTO " + table;
    String fieldStr = " ( ";
    String valueStr = " VALUES ( ";
    for (int i = 0; i < fields.size(); i++) {
      fieldStr += fields.elementAt(i).toString().trim() + ", ";
      Boolean b = new Boolean(fieldTypes.elementAt(i).toString());
      if (b.booleanValue()) { // true if integer type
        valueStr += values.elementAt(i) + ", ";
      }
      else {
        valueStr += "'" +
            replaceString(values.elementAt(i).toString().trim(), "'", "''") +
            "', ";
      }
    }
    sql += fieldStr.substring(0, fieldStr.length() - 2) + " ) ";
    sql += valueStr.substring(0, valueStr.length() - 2) + " ) ";

    this.execute(sql);
  }

  /**
   * To get the maximum set number inserted for the given client and DtsNo.
   */
  public int getMaxSetNo(String clientID, int DTSNo) {
    return getMaxSetNo(clientID, DTSNo + "");
  }

  public int getDatabaseId(String clientID) {
    if (this.databaseId > 0) {
      return this.databaseId;
    }
    String sql = "Select databaseId from ztbl_DTS_Databases where clientId='" +
        clientID + "'";
    this.executeQuery(sql);
    if (this.moveNext()) {
      return this.getInt("databaseId");
    }
    return 0;
  }

  public String getVersion(String clientID) {
    if (this.version!=null) {
      return this.version;
    }
    String sql = "Select version from ztbl_DTS_Clients where clientId='" +
        clientID + "'";
    this.executeQuery(sql);
    if (this.moveNext()) {
      this.version=this.getData("version");
      return this.version;
    }
    return "No Version";
  }

  /**
   * To get the maximum set number inserted for the given client and DtsNo.
   * <br>It creates the SQL statement, executes and returns the value.
   */
  public int getMaxSetNo(String clientID, String DTSNo) {
    String maxSetNo = "0";
    strSQL = "SELECT MAX(SetNo) AS MaxSetNo FROM ztbl_DTS_DTS_Set WHERE DTSNo=" +
        DTSNo + " AND ClientID='" + clientID + "'";
    this.executeQuery(strSQL);
    if (this.moveNext()) {
      maxSetNo = this.getData("MaxSetNo");
      if (maxSetNo == null || "".equals(maxSetNo.trim())) {
        maxSetNo = "0";
      }
    }
    try {
      return new Integer(maxSetNo).intValue();
    }
    catch (Exception e) {
      return 0;
    }
  }

  /**
   * To get the maximum dts number for the given client.
   * <br>It creates the SQL statement, executes and returns the value.
   */
  public int getMaxDTSNo(String clientID) {
    String maxDTSNo = "0";
    strSQL =
        "SELECT MAX(DTSNo) AS MaxDTSNo FROM ztbl_DTS_DTS_Mast WHERE ClientID='" +
        clientID + "'";
    this.executeQuery(strSQL);
    if (this.moveNext()) {
      maxDTSNo = this.getData("MaxDTSNo");
      if (maxDTSNo == null || "".equals(maxDTSNo.trim())) {
        maxDTSNo = "0";
      }
    }
    try {
      return new Integer(maxDTSNo).intValue();
    }
    catch (Exception e) {
      return 0;
    }
  }

  /**
   * To add a new dtsNumber.
   * <br>It add a new dts number by first finding the max dts number and incrementing it by one.
   */

  //---changed by upendra
  public void addDTS(String clientID, String createdBy, String remarks) {
    System.out.println("adding dts");
    this.addMessage("addDTS called : clientID = " + clientID +
                      ", createdBy =" + createdBy + "Remarks" + remarks);
    int maxDTS = this.getMaxDTSNo(clientID);
    maxDTS++;
    this.addMessage("Max DTS No = " + maxDTS);
    Vector f = new Vector(); //fields
    Vector v = new Vector(); //values
    Vector t = new Vector(); //type
    f.add("ClientID");
    v.add(clientID);
    t.add("" + false);
    f.add("DTSNo");
    v.add(maxDTS + "");
    t.add("" + true);
    f.add("Version");
    v.add(this.getVersion(clientID));
    t.add(false +"");
    f.add("CreatedBy");
    v.add(createdBy);
    t.add(false +"");
    f.add("Remarks");
    v.add(remarks);
    t.add(false +"");
    insert("ztbl_DTS_DTS_Mast", f, v, t);
  }

  /**
   * To add a new dtsNumber.
   * <br>It add a new dts number by first finding the max dts number and incrementing it by one.
   */
  public void addDTS(String clientID, String createdBy) {
    this.addMessage("<br>addDTS called : clientID = " + clientID +
                      ", createdBy =" + createdBy);
    int maxDTS = getMaxDTSNo(clientID);
    maxDTS++;
    this.addMessage("<br>Max DTS No = " + maxDTS);
    Vector f = new Vector(); //fields
    Vector v = new Vector(); //values
    Vector t = new Vector(); //type
    f.add("ClientID");
    f.add("DTSNo"); /*f.add("CreationDate");*/
    f.add("Version"); /*f.add("CreationDate");*/
    f.add("CreatedBy");
    v.add(clientID);
    v.add(maxDTS + ""); /*v.add("getDate()");*/
    v.add(this.getVersion(clientID));
    v.add(createdBy);
    t.add("" + false);
    t.add("" + true); /*t.add(true+"");*/
    t.add(false +"");
    t.add(false +"");
    insert("ztbl_DTS_DTS_Mast", f, v, t);
  }

  /**
   * To add a new set.
   * <br>It add a new set number by first finding the max set number for given client+dtsNo and incrementing it by one.
   */
  public void addSet(String clientID, int DTS) {
    this.addMessage("<br>addSet called : clientID = " + clientID +
                      ", DTSNo =" + DTS);
    int maxSet = getMaxSetNo(clientID, DTS + "");
    maxSet++;
    this.addMessage("<br>Max Set No = " + maxSet);
    Vector f = new Vector(); //fields
    Vector v = new Vector(); //values
    Vector t = new Vector(); //type
    f.add("ClientID");
    f.add("DTSNo");
    f.add("SetNo");
    v.add(clientID);
    v.add(DTS + "");
    v.add(maxSet + "");
    t.add("false");
    t.add("true");
    t.add("true");
    insert("ztbl_DTS_DTS_Set", f, v, t);
  }

  public HashMap getCatFieldKeyFieldMap(String clientId) {
    if (theMap == null) {
      theMap = new HashMap();
      String sql = "Select Distinct Category, FieldName, KeyField, Version " +
          " from ztbl_DTS_Mapping_Target where Version='" +
          this.getVersion(clientId) + "'";
      this.executeQuery(sql);
      while (this.moveNext()) {
        String key = this.getData("Category")+"."+this.getData("FieldName");
        theMap.put(key.toUpperCase(), this.getData("KeyField"));
      }
    }
    return theMap;
  }

  /**
   * It adds the actual data in the database.
   * <br> Note that all the data in SourceData are public and it is used for wrapping of data only.
   */
  public void importData(SourceData d, String Category, int DTS, int Set) {
    String ClientID = d.clientID;
    Vector TableNames = d.tableName;
    Vector FieldNames = d.fieldNames;
    String businessRule = d.businessRule;
    String MapTableName;
    String MapFieldName;
    String KeyField = this.getCatFieldKeyFieldMap(ClientID).get((Category+"."+d.fieldName).toUpperCase())+"";
    Vector f = new Vector();
    Vector v = new Vector();
    Vector t = new Vector();
    String dbTableName = "";
    // for source
    dbTableName = "ztbl_DTS_Mapping_Source";
    for (int i = 0; i < TableNames.size(); i++) {
      MapTableName = TableNames.elementAt(i).toString();
      if (!MapTableName.trim().toLowerCase().equals("null")) {
        for (int j = 0; j < FieldNames.size(); j++) {
          f.clear();
          v.clear();
          t.clear();

          MapFieldName = FieldNames.elementAt(j).toString();
          /////////////////////////////////////////////////////////
          f.add("ClientID");
          v.add(ClientID);
          t.add("false");
          f.add("DTSNo");
          v.add(DTS + "");
          t.add("true");
          f.add("SetNo");
          v.add(Set + "");
          t.add("true");
          f.add("Category");
          v.add(Category);
          t.add("false");
          f.add("KeyField");
          v.add(KeyField);
          t.add("false");
          f.add("Version");
          v.add(this.getVersion(ClientID));
          t.add("false");
          f.add("DatabaseId");
          v.add(this.getDatabaseId(ClientID) + "");
          t.add("false");
          f.add("TableName");
          v.add(MapTableName);
          t.add("false");
          f.add("FieldName");
          v.add(MapFieldName);
          t.add("false");
          f.add("FieldFormat");
          v.add("null");
          t.add("false");

          insert(dbTableName, f, v, t);
          /////////////////////////////////////////////////////////
        }
      }
    }

    // for business rule
    f.clear();
    v.clear();
    t.clear();
    if (!businessRule.trim().toLowerCase().equals("null")) {
      dbTableName = "ztbl_DTS_Mapping_Rule";
      f.add("ClientID");
      v.add(ClientID);
      t.add("false");

      f.add("DTSNo");
      v.add(DTS + "");
      t.add("true");

      f.add("SetNo");
      v.add(Set + "");
      t.add("true");

      f.add("Category");
      v.add(Category);
      t.add("false");

      f.add("KeyField");
      v.add(KeyField);
      t.add("false");

      f.add("BusinessRule");
      v.add(businessRule);
      t.add("false");

      f.add("Version");
      v.add(this.getVersion(ClientID));
      t.add("false");

      insert(dbTableName, f, v, t);
    }
  }

  /**
   * Copies the distinct data added form mapping source to source table space.
   * <br>After adding of data, it is necessary to update the dts source table space.
   * It perform this task.
   */
  public void addTableSpace(String ClientID, int DTS) {
    String sql =
        "SELECT DISTINCT clientID, DTSNo, TableName, FieldName, DatabaseId, FieldFormat ";
    sql += " FROM ztbl_DTS_Mapping_Source ";
    sql += " WHERE ClientID='" + ClientID + "' and DTSNo=" + DTS;

    sql = "INSERT INTO ztbl_DTS_SourceTableSpace (clientID, DTSNo, TableName, FieldName, DatabaseId, FieldFormat) " + sql + "";
    this.execute(sql);
  }

  /**
   * It imports the general category of data, that needs to be added in mapping rule only.
   */
  public void importGeneral(SourceData dt, String Category, int DTSNo, int set) {
    Vector f = new Vector();
    Vector v = new Vector();
    Vector t = new Vector();
    f.add("ClientID");
    f.add("DTSNo");
    f.add("SetNo");
    f.add("Category");
    f.add("KeyField");
    f.add("BusinessRule");
    f.add("Version");

    v.add(dt.clientID);
    v.add(DTSNo + "");
    v.add(set + "");
    v.add(Category);
    v.add(this.getCatFieldKeyFieldMap(dt.clientID).get((Category+"."+dt.fieldName).toUpperCase()));
    v.add(dt.businessRule);
    v.add(this.getVersion(dt.clientID));

    t.add(false +"");
    t.add(true +"");
    t.add(true +"");
    t.add(false +"");
    t.add(false +"");
    t.add(false +"");
    t.add(false +"");

    insert("ztbl_DTS_Mapping_Rule", f, v, t);
  }
}
