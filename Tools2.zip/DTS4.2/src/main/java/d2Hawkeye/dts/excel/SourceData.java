package d2Hawkeye.dts.excel;

import java.util.*;

/**
 * <br><b>Prepared By:</b>	Raj K Gaire
 * <br><b>Purpose:</b>		To provide the encapsulation of data required to import in source and rule tables
 * <br><b>Description:</b>	This class is used to store all the data extracted from excel files.

 * <br><b>Date:</b>			May 18, 2003
 * <br><b>Modified:</b>
 */
public class SourceData {
  public String clientID;
  public String fieldName;
  public Vector tableName = new Vector();
  public Vector fieldNames = new Vector();
  public String businessRule;

  /**
   * It just stores data in relevent form. It filters out the unformated data like
   * [] in tableNames. It may also be extended for further filteration if required.
   */
  public SourceData(String id, String fn, Vector tn, Vector fns, String br) {
    clientID = id;
    fieldName = fn;
    tableName = tn;
    fieldNames = fns;
    businessRule = br;
    int indx = fieldName.indexOf('(');

    if (indx > -1) {
      fieldName = fieldName.substring(0, indx);
    }

    // remove [
    indx = fieldName.indexOf('[');
    if (indx > -1) {
      fieldName = fieldName.substring(indx + 1, fieldName.length());
    }
    // remove ]
    indx = fieldName.indexOf(']');
    if (indx > -1) {
      fieldName = fieldName.substring(0, indx);
    }
    if (fieldName.trim().equalsIgnoreCase("UMCCompanyCode")) {
      fieldName = "UMCompanyCode";
    }
    else if (fieldName.trim().equalsIgnoreCase("UMCCompanyDesc")) {
      fieldName = "UMCompanyDesc";

    }
    clientID = clientID.trim();
    fieldName = fieldName.trim();
    businessRule = businessRule.trim();
  }
}
