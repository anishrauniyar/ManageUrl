package d2Hawkeye.dts.excel;

/*************************************************************************************
 Prepared By:	Raj K Gaire
 Purpose:		To Import data that is available in Excel Format
 Description:	This class handles importing part of the excel file.
    With the help of ExcelHandler class, it parses data from the excel files.
    It uses DBHandler class to store the imported data to the database.

 Date:			May 18, 2003
 Modified:

 **********************************************************************************/

//import com.jacob.activeX.*;
import java.io.*;
import java.util.*;

import com.jacob.com.*;

public class DTSImporter
    extends ExcelHandler {
  String fileName;
  String user;
  public static String basePath = "c:\\ImportExcel";
  public static int SAVE = 1;
  public static int SAVE_AND_DELETE = 2;

  public Vector eligibilities; // = new Vector();
  public Vector medicals; // = new Vector();
  public Vector TPAs; // = new Vector();
  public Vector pharmacies; // = new Vector();
  public Vector generals; // = new Vector();

  public String fieldName;
  public Vector tableName;
  public Vector fieldNames; // = new Vector();
  public String businessRule;

  public Vector log; // = new Vector();
  private int maxNullRows = 5;

  private int SNColumn = 1;
  private int SourceTableNameColumn = 2;
  private int SourceTableFieldColumn = 3;
  private int TargetTableNameColumn = 5;
  private int TargetTabelFieldColumn = 6;
  private int TargetTableFieldFormat = 7;
  private int BusinessColumn = 8;

  private int Eligibility = 0;
  private int Medical = 1;
  private int TPA = 2;
  private int Pharmacy = 3;

  private int currentRowIndex = 0;
  public String clientID; //="";
  private String remarks = "";

  private DBHandler uploader = new DBHandler();
  private String message = "";

  public String getRemarks() {
    return remarks;
  }

  public DTSImporter() {
    log = new Vector();
    if (debug) {
      log.add("DTSImporter instentiated");
    }
    File f = new File(this.basePath);
    if (!f.exists()) {
      f.mkdirs();
    }
    f = new File(DTSLogView.basePath);
    if (!f.exists()) {
      f.mkdirs();
    }
  }

  public void setUser(String user) {
    this.user = user;
  }

  public void open(String fileName, int save) {
    log.clear();
    eligibilities = new Vector();
    medicals = new Vector();
    TPAs = new Vector();
    pharmacies = new Vector();
    generals = new Vector();

    fieldNames = new Vector();
    log = new Vector();
    //uploader = new DBHandler();

    currentRowIndex = 0;
    clientID = "";
    fileName = fileName.trim();
    //--edited by upendra
    try {
      //ComThread.InitMTA();
      workBook = xlsObj.openExcelFile(basePath + "\\", fileName); //AsImportedInfo
      System.out.println("Excel file " + fileName + " opened");
      this.fileName = fileName;
      getActiveSheet();
      System.out.println("Excel file active sheet opened");
      init(); // import medical claims, TPAs, pharmacy claims and eligibilities
      System.out.println("Excel file initalized");
      System.out.println("Importing to database");
      importAll(user);
      close();
      if (save == SAVE_AND_DELETE) {
        deleteFile(fileName);
      }
    }
    catch (Exception e) {
      close();
      ComThread.InitMTA();
      System.out.println("Exception while opening file " + e);
    }

  }

  public void open(Vector files, int mode) {
    openApplication();
    for (int i = 0; i < files.size(); i++) {
      open(files.elementAt(i).toString(), mode);
    }
    quit();
  }

  public void init() {
    System.out.println("INIT called");
    try {
      workSheet = getSheet("AsImportedInfo");
      clientID = getClientID().trim();
      if (debug) {
        if (workSheet == null) {
          log.add("Sheet could not be opened");
        }
        else {
          log.add("Sheet AsImportedInfo is opened");
        }
      }
    }
    catch (Exception e) {
      error = "cannot open the 'AsImportedInfo' sheet";
      if (debug) {
        log.add("Error: Sheet AsImportedInfo could not be opened");
      }
    }

    if (workSheet != null) {

      currentRowIndex = 1;
      int xOEligibility;
      int xOMedical;
      int xOTPA;
      int xOPharmacy;

      String text = getData(1, 1);
      text = text.toLowerCase();
      // get the location of sn or s.n.
      int counter = 0;
      while (!text.equals("sn") && counter < 15) {
        text = getData(currentRowIndex++, 1).toLowerCase();
        counter++;
      }
      if (debug) {
        log.add("counter for sn = " + counter);
        // add this index to log
        log.add("SN: col No -" + (currentRowIndex - 1));
        // next to sn row
      }
      text = getData(currentRowIndex, 1).toLowerCase();
      // initialize indices
      try {
        xOEligibility = text.indexOf("eligibility");
        xOMedical = text.indexOf("medical");
        xOTPA = text.indexOf("tpa");
        xOPharmacy = text.indexOf("pharmacy");
      }
      catch (Exception e) {
        xOEligibility = -1;
        xOMedical = -1;
        xOTPA = -1;
        xOPharmacy = -1;
        if (debug) {
          log.add("Null pointer Exception at: index inits");
        }
      }
      counter = 0;
      // search untill index is not found after "sn"
      while (counter < maxNullRows) {
        if (text == null) {
          counter++;
          continue;
        }
        text = getData(currentRowIndex++, 1).toLowerCase();
        if (debug) {
          log.add("text while search = " + text);
        }
        counter++;
        xOEligibility = text.indexOf("eligibility"); //Eligibility
        xOMedical = text.indexOf("medical");
        xOTPA = text.indexOf("tpa");
        xOPharmacy = text.indexOf("pharmacy");
        if (debug) {
          log.add("e: " + xOEligibility + "  m: " + xOMedical + "   tp: " +
                  xOTPA + "  P:" + xOPharmacy);
        }
        if (xOEligibility > -1 || xOMedical > -1 ||
            xOTPA > -1 && xOPharmacy > -1) {
          break;
        }
      }
      if (debug) {
        log.add("Counter after search indexs = " + counter);
        log.add("xOEligibility =" + xOEligibility);
        log.add("xOMedical =" + xOMedical);
        log.add("xOTPA =" + xOTPA);
        log.add("xOPharmacy =" + xOPharmacy);
      }

      int next = -1;
      counter = 0;
      do {
        if (xOEligibility > -1 || next == Eligibility) {
          xOEligibility = -1;
          next = initEligibilies(); // will know where to start using the currentRowIndex
        }
        else if (xOMedical > -1 || next == Medical) {
          xOMedical = -1;
          next = initMedicals();
        }
        else if (xOTPA > -1 || next == TPA) {
          xOTPA = -1;
          next = initTPAs();
        }
        else if (xOPharmacy > -1 || next == Pharmacy) {
          xOPharmacy = -1;
          next = initPharmacies();
        }
        else {
          next = -1;

        }
        if (debug) {
          log.add("Next = " + next);
        }
        counter++;
      }
      while (next > -1);
      if (debug) {
        log.add("counter at last " + counter);
      }
    }
    System.out.println("INIT completed for first part");
    initGeneral();
  }

  /**
   store all the eligibilities data in vector in the form of SourceData
   */
  public int initEligibilies() {
    if (debug) {
      log.add("Eligibility called");
      log.add("Eligibility Index:" + currentRowIndex);
    }
    int next = -1;
    int sn = -1;
    String col1, col2, col3, col4, col5, col6, col7;
    do {
      col1 = getData(currentRowIndex, SNColumn);
      col2 = getData(currentRowIndex, SourceTableNameColumn);
      col3 = getData(currentRowIndex, SourceTableFieldColumn);
      col4 = getData(currentRowIndex, TargetTableNameColumn);
      col5 = getData(currentRowIndex, TargetTabelFieldColumn);
      col6 = getData(currentRowIndex, TargetTableFieldFormat);
      col7 = getData(currentRowIndex, BusinessColumn);
      currentRowIndex++;
      try {
        sn = Integer.parseInt(col1);
      }
      catch (Exception e) {
        if (debug) {
          log.add("col1 value:" + col1);
        }
        if (col1 != null) {
          col1 = col1.toLowerCase();
          if (debug) {
            log.add("col1 value lowered:" + col1);
          }
          sn = -1;
          sn = col1.indexOf("eligibility");
          if (sn > -1) {
            return 0;
          }
          sn = col1.indexOf("medical");
          if (sn > -1) {
            return 1;
          }
          sn = col1.indexOf("tpa");
          if (sn > -1) {
            return 2;
          }
          sn = col1.indexOf("pharmacy");
          if (sn > -1) {
            return 3;
          }
          return -1;
        }
      }

      if (debug) {
        log.add("SN = " + sn);
      }
      if (sn > 0) {
        Vector f = new Vector(); // field list
        Vector t = new Vector(); //table list
        // for field list
        int indx = col3.indexOf(",");
        if (debug) {
          log.add("val = " + col3);
          log.add("index of , =" + indx);
        }
        while (indx > -1 && col3.length() > 0) {
          f.add(col3.substring(0, indx));
          col3 = col3.substring(indx + 1, col3.length());
          indx = col3.indexOf(",");
          if (debug) {
            log.add("val f = " + col3);
            log.add("index of , =" + indx);
          }
        }
        f.add(col3);
        //for table list
        indx = col2.indexOf(",");
        while (indx > -1 && col2.length() > 0) {
          t.add(col2.substring(0, indx));
          col2 = col2.substring(indx + 1, col2.length());
          indx = col2.indexOf(",");
          if (debug) {
            log.add("val t = " + col2);
            log.add("index of , =" + indx);
          }
        }
        t.add(col2);
        SourceData d = new SourceData(clientID, col5, t, f, col7);
        eligibilities.add(d);
      }
    }
    while (sn > 0);
    return -1;
  }

  /**
   store all the medicals data in vector in the form of SourceData
   */
  public int initMedicals() {
    int next = -1;
    int sn = -1;
    String col1, col2, col3, col4, col5, col6, col7;
    do {
      col1 = getData(currentRowIndex, SNColumn);
      col2 = getData(currentRowIndex, SourceTableNameColumn);
      col3 = getData(currentRowIndex, SourceTableFieldColumn);
      col4 = getData(currentRowIndex, TargetTableNameColumn);
      col5 = getData(currentRowIndex, TargetTabelFieldColumn);
      col6 = getData(currentRowIndex, TargetTableFieldFormat);
      col7 = getData(currentRowIndex, BusinessColumn);
      currentRowIndex++;
      try {
        sn = Integer.parseInt(col1);
      }
      catch (Exception e) {
        col1 = col1.toLowerCase();
        sn = -1;
        sn = col1.indexOf("eligibility");
        if (sn > -1) {
          return 0;
        }
        sn = col1.indexOf("medical");
        if (sn > -1) {
          return 1;
        }
        sn = col1.indexOf("tpa");
        if (sn > -1) {
          return 2;
        }
        sn = col1.indexOf("pharmacy");
        if (sn > -1) {
          return 3;
        }
        return -1;
      }
      if (sn > 0) {
        Vector f = new Vector(); // field list
        Vector t = new Vector(); //table list
        // for field list
        int indx = col3.indexOf(",");
        if (debug) {
          log.add("val = " + col3);
          log.add("index of , =" + indx);
        }
        while (indx > -1 && col3.length() > 0) {
          f.add(col3.substring(0, indx));
          col3 = col3.substring(indx + 1, col3.length());
          indx = col3.indexOf(",");
          if (debug) {
            log.add("val f = " + col3);
            log.add("index of , =" + indx);
          }
        }
        f.add(col3);
        //for table list
        indx = col2.indexOf(",");
        while (indx > -1 && col2.length() > 0) {
          t.add(col2.substring(0, indx));
          col2 = col2.substring(indx + 1, col2.length());
          indx = col2.indexOf(",");
          if (debug) {
            log.add("val t = " + col2);
            log.add("index of , =" + indx);
          }
        }
        t.add(col2);
        SourceData d = new SourceData(clientID, col5, t, f, col7);
        medicals.add(d);
      }
    }
    while (sn > 0);
    return sn;
  }

  /**
   store all the TPAs data in vector in the form of SourceData
   */
  public int initTPAs() {
//		int next = -1;
    int sn = 1;
    String col1, col2, col3, col5, col7;
    String col4, col6;
    do {
      col1 = getData(currentRowIndex, SNColumn);
      col2 = getData(currentRowIndex, SourceTableNameColumn);
      col3 = getData(currentRowIndex, SourceTableFieldColumn);
      col4 = getData(currentRowIndex, TargetTableNameColumn);
      col5 = getData(currentRowIndex, TargetTabelFieldColumn);
      col6 = getData(currentRowIndex, TargetTableFieldFormat);
      col7 = getData(currentRowIndex, BusinessColumn);
      currentRowIndex++;
      try {
        sn = Integer.parseInt(col1);
      }
      catch (Exception e) {
        col1 = col1.toLowerCase();
        sn = -1;
        sn = col1.indexOf("eligibility");
        if (sn > -1) {
          return 0;
        }
        sn = col1.indexOf("medical");
        if (sn > -1) {
          return 1;
        }
        sn = col1.indexOf("tpa");
        if (sn > -1) {
          return 2;
        }
        sn = col1.indexOf("pharmacy");
        if (sn > -1) {
          return 3;
        }
        return -1;
      }
      if (sn > 0) {
        Vector f = new Vector(); // field list
        Vector t = new Vector(); //table list
        // for field list
        int indx = col3.indexOf(",");
        if (debug) {
          log.add("val = " + col3);
          log.add("index of , =" + indx);
        }
        while (indx > -1 && col3.length() > 0) {
          f.add(col3.substring(0, indx));
          col3 = col3.substring(indx + 1, col3.length());
          indx = col3.indexOf(",");
          if (debug) {
            log.add("val f = " + col3);
            log.add("index of , =" + indx);
          }
        }
        f.add(col3);
        //for table list
        indx = col2.indexOf(",");
        while (indx > -1 && col2.length() > 0) {
          t.add(col2.substring(0, indx));
          col2 = col2.substring(indx + 1, col2.length());
          indx = col2.indexOf(",");
          if (debug) {
            log.add("val t = " + col2);
            log.add("index of , =" + indx);
          }
        }
        t.add(col2);
        SourceData d = new SourceData(clientID, col5, t, f, col7);
        TPAs.add(d);
      }
    }
    while (sn > 0);
    return sn;
  }

  /**
   store all the pharmacy data in vector in the form of SourceData
   */
  public int initPharmacies() {
//		int next = -1;
    int sn = -1;
    String col1, col2, col3, col5, col7;
    String col4, col6;
    do {
      col1 = getData(currentRowIndex, SNColumn);
      col2 = getData(currentRowIndex, SourceTableNameColumn);
      col3 = getData(currentRowIndex, SourceTableFieldColumn);
      col4 = getData(currentRowIndex, TargetTableNameColumn);
      col5 = getData(currentRowIndex, TargetTabelFieldColumn);
      col6 = getData(currentRowIndex, TargetTableFieldFormat);
      col7 = getData(currentRowIndex, BusinessColumn);
      currentRowIndex++;
      try {
        sn = Integer.parseInt(col1);
      }
      catch (Exception e) {
        col1 = col1.toLowerCase();
        sn = -1;
        sn = col1.indexOf("eligibility");
        if (sn > -1) {
          return 0;
        }
        sn = col1.indexOf("medical");
        if (sn > -1) {
          return 1;
        }
        sn = col1.indexOf("tpa");
        if (sn > -1) {
          return 2;
        }
        sn = col1.indexOf("pharmacy");
        if (sn > -1) {
          return 3;
        }
        return -1;
      }
      if (sn > 0) {
        Vector f = new Vector(); // field list
        Vector t = new Vector(); //table list
        // for field list
        int indx = col3.indexOf(",");
        if (debug) {
          log.add("val = " + col3);
          log.add("index of , =" + indx);
        }
        while (indx > -1 && col3.length() > 0) {
          f.add(col3.substring(0, indx));
          col3 = col3.substring(indx + 1, col3.length());
          indx = col3.indexOf(",");
          if (debug) {
            log.add("val f = " + col3);
            log.add("index of , =" + indx);
          }
        }
        f.add(col3);
        //for table list
        indx = col2.indexOf(",");
        while (indx > -1 && col2.length() > 0) {
          t.add(col2.substring(0, indx));
          col2 = col2.substring(indx + 1, col2.length());
          indx = col2.indexOf(",");
          if (debug) {
            log.add("val t = " + col2);
            log.add("index of , =" + indx);
          }
        }
        t.add(col2);
        SourceData d = new SourceData(clientID, col5, t, f, col7);
        pharmacies.add(d);
      }
    }
    while (sn > 0);
    return sn;
  }

  /**
   When used as bean, used to store data in global variables
   */
  public void gotoEligibility(int i) {
    SourceData a = (SourceData) eligibilities.elementAt(i);
    clientID = a.clientID;
    fieldName = a.fieldName;
    tableName = a.tableName;
    fieldNames = a.fieldNames;
    businessRule = a.businessRule;
  }

  /**
   When used as bean, used to store data in global variables
   */
  public void gotoMedical(int i) {
    SourceData a = (SourceData) medicals.elementAt(i);
    clientID = a.clientID;
    fieldName = a.fieldName;
    tableName = a.tableName;
    fieldNames = a.fieldNames;
    businessRule = a.businessRule;
  }

  /**
   When used as bean, used to store data in global variables
   */
  public void gotoTPA(int i) {
    SourceData a = (SourceData) TPAs.elementAt(i);
    clientID = a.clientID;
    fieldName = a.fieldName;
    tableName = a.tableName;
    fieldNames = a.fieldNames;
    businessRule = a.businessRule;
  }

  /**
   When used as bean, used to store data in global variables
   */
  public void gotoPharmacy(int i) {
    SourceData a = (SourceData) pharmacies.elementAt(i);
    clientID = a.clientID;
    fieldName = a.fieldName;
    tableName = a.tableName;
    fieldNames = a.fieldNames;
    businessRule = a.businessRule;
  }

  /**
   To parse the clientId from the worksheet
   */
  public String getClientID() {
    String text = "";
    for (int i = 1; i < 10; i++) {
      text = getData(i, 1).toLowerCase();
      if (text.indexOf("client") > -1) {
        break;
      }
    }
    int index = text.indexOf(":");
    display.add("text = " + text);
    text = text.substring(index + 1, text.length());

    display.add("text = " + text);
    index = text.indexOf(",");
    text = text.substring(0, index).trim();

    index = text.indexOf("'");
    if (index == 0) {
      text = text.substring(1, text.length());
    }
    index = text.indexOf("'");
    if (index == text.length() - 1) {
      text = text.substring(0, text.length() - 1);

    }
    return text;
  }

  public void finalizer() {
    close();
  }

  /**
   after setting all the data in SourceData, it is uploaded in respective tables
   */
  public void importAll(String importer) {
    // to add new dts no
    System.out.println("import all called - " + importer);
    uploader.addDTS(clientID, importer, remarks); //--chavged by upendra
    //uploader.addDTS(clientID, importer);
    int DTSNo = uploader.getMaxDTSNo(clientID);

    uploader.addSet(clientID, DTSNo); // to add new set
    int setno = uploader.getMaxSetNo(clientID, DTSNo + "");

    int i;
    for (i = 0; i < eligibilities.size(); i++) {
      uploader.importData( (SourceData) eligibilities.elementAt(i),
                          "Eligibilities", DTSNo, setno);
    }
    for (i = 0; i < medicals.size(); i++) {
      uploader.importData( (SourceData) medicals.elementAt(i), "Claims", DTSNo,
                          setno);
    }
    for (i = 0; i < TPAs.size(); i++) {
      uploader.importData( (SourceData) TPAs.elementAt(i), "TPA Data", DTSNo,
                          setno);
    }
    for (i = 0; i < pharmacies.size(); i++) {
      uploader.importData( (SourceData) pharmacies.elementAt(i), "Rx Claims",
                          DTSNo, setno);
    }
    uploader.addTableSpace(clientID, DTSNo);
    for (i = 0; i < generals.size(); i++) {
      uploader.importData( (SourceData) generals.elementAt(i), "General Info",
                          DTSNo, setno);
    }
    boolean mode = uploader.isDebugMode();
    uploader.debug(true);
    this.saveLog(uploader.getMessage());
    this.message = uploader.getMessage();
    if (!debug) {
      display = new Vector();
//		display = uploader.dbSuccessSqlLog;
    }
    uploader.debug(mode);
  }

  public String getMessage() {
    return this.message;
  }

  public void initGeneral() {
    display.add("INIT general called");
    workSheet = getSheet("GeneralInfo");
    String col1, col2, col3, col4, col5;
    int counter = 0;
    int indx = indexOf("sn", 1); // index of sn in col 1 find the row.
    display.add("general: index of sn is = " + indx);
    if (indx > 0) {
      indx++;
      indx++; // move cursur to next row - SN is merged, so two times
      SourceData sd;
      int ii;
      int i;
      while (counter < 3) {
        col1 = getData(indx, 1); // sn
        col2 = getData(indx, 2); //
        col3 = getData(indx, 3);
        col4 = getData(indx, 4);
        col5 = getData(indx, 5);
        display.add("Col1:" + col1 + "; Col2:" + col2 + "; Col3:" + col3 +
                    "; Col4:" + col4 + "; Col5:" + col5);
        if (col1.equals("null")) {
          counter++;
          continue;
        }
        indx++;
        try {
          ii = Integer.parseInt(col1);
        }
        catch (Exception e) {
          ii = -1;
        }
        if (ii < 0) {
          break;
        }
        i = col5.indexOf("'");
        if (i == 0) {
          col5 = col5.substring(1, col5.length());
        }
        i = col5.indexOf("'");
        if (i == (col5.length() - 1)) {
          col5 = col5.substring(0, col5.length() - 1);
        }
        col5 = col5.trim();
        Vector vv = new Vector();
        vv.add("null");
        sd = new SourceData(clientID, col3, vv, vv, col5);
        generals.add(sd);
        remarks = getData(workSheet, 23, 1);
      }
    }
    display.add("INIT general completed");
  }

  private int indexOf(String text, int col) {
    int counter = 1;
    String txt;
    text = text.toLowerCase();
    do {
      txt = getData(counter++, col).toLowerCase();
    }
    while (!text.equals(txt) && counter < 15);
    if (debug) {
      log.add("counter for sn = " + counter);
      // add this index to log
      log.add("SN: col No -" + (counter - 1));
      // next to sn row
    }
    if (counter < 15) {
      return (counter - 1);
    }
    return -1;
  }

  public void saveLog(Vector l) {
    log = l;
    try {
      fileName = fileName.replace('&', '_').replace(' ', '_');
      File f = new File(basePath + "\\logs\\" + d2Hawkeye.dts.TextEncoder.encode(fileName) + ".html");
      FileOutputStream fs = new FileOutputStream(f);
      fs.write( ("Log File*/*/*/*/****<br>").getBytes());
      fs.write( ("<br><b>Imported File:</b> " + fileName).getBytes());
      java.util.Date d = new java.util.Date();
      fs.write( ("<br><b>Date: </b>" + d.toString()).getBytes());
      fs.write( ("<br><b>Created By:</b> " + user).getBytes());

      fs.write( ("<table>").getBytes());
      String s = "";
      for (int i = 0; i < l.size(); i++) {
        s = i % 2 == 0 ? "'#ffffcc'" : "'#ccffcc'";
        s = "<tr><td bgcolor=" + s + ">" + l.elementAt(i).toString() +
            "</td></tr>";
        fs.write(s.getBytes());
      }
      fs.write( ("</table>").getBytes());

      fs.close();
      String logSummary = getLogSummary();
      f = new File(basePath + "\\logsummary.txt");
      fs = new FileOutputStream(f);
      fs.write(logSummary.getBytes());
      fs.write( ("\n=>" + fileName + "\t" + d.toString() + "\t" + user + "\n").
               getBytes());
      fs.close();
    }
    catch (Exception e) {
      log.add("<i><b>Log file error:</b></i>" + e.toString());
    }
  }

  public void saveLog(String s) {
    try {
      fileName = fileName.replace('&','_').replace(' ','_');
      File f = new File(basePath + "\\logs\\" + fileName + ".html");
      FileOutputStream fs = new FileOutputStream(f);
      fs.write( ("Log File*/*/*/*/****<br>").getBytes());
      fs.write( ("<br><b>Imported File:</b> " + fileName).getBytes());
      java.util.Date d = new java.util.Date();
      fs.write( ("<br><b>Date: </b>" + d.toString()).getBytes());
      fs.write( ("<br><b>Created By:</b> " + user).getBytes());

      fs.write( ("<table>").getBytes());
      fs.write(s.getBytes());
      fs.write( ("</table>").getBytes());

      fs.close();
      String logSummary = getLogSummary();
      f = new File(basePath + "\\logsummary.txt");
      fs = new FileOutputStream(f);
      fs.write(logSummary.getBytes());
      fs.write( ("\n=>" + fileName + "\t" + d.toString() + "\t" + user + "\n").
               getBytes());
      fs.close();
    }
    catch (Exception e) {
      log.add("<i><b>Log file error:</b></i>" + e.toString());
    }
  }

  public Vector getFile() {
    Vector v = new Vector();
    File f = new File(basePath);
    File[] child = f.listFiles();
    int i, indx;
    String fname;
    try {
      for (i = 0; ; i++) {
        if (child[i].isDirectory()) {
          continue;
        }
        fname = child[i].getName();
        indx = fname.indexOf(".xls");
        if (indx > 0) {
          v.add(fname);
        }
      }
    }
    catch (Exception e) {}
    return v;
  }

  public String getLogSummary() {

    String s = "";
    try {
      File f = new File(basePath + "\\logsummary.txt");
      FileInputStream fs = new FileInputStream(f);
      int c = fs.available();
      while (c > 0) {
        s += "" + (char) fs.read();
        c--;
      }
      fs.close();
    }
    catch (Exception e) {}
    return s;
  }

  public void setDebug(boolean b) {
    debug = b;
  }

  private void deleteFile(String file) {

    File f = new File(basePath + "\\" + file);
    f.delete();

  }

}
