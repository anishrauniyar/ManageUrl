package d2Hawkeye.dts;

import java.util.*;

public class DTSServers
    extends sqlBean {

  public static String SERVER_TABLE = "ztbl_DTS_Servers";
  public static String ID_FIELD = "ServerID";
  public static String SERVER_FIELD = "ServerName";
  public static String USER_FIELD = "UserName";
  public static String PASSWORD_FIELD = "UserPassword";

  public static boolean SERVER_SELECT_BY_ID = false;
  public static boolean SERVER_SELECT_BY_VALUE = true;

  public DTSServers() {
  }

  public void cleanup() {}

  public HashMap getServerInfo(String serverName) {
    HashMap hm = null;
    strSQL = "Select * from " + DTSServers.SERVER_TABLE + " where " +
        DTSServers.SERVER_FIELD + "='" + serverName + "'";
    //System.out.println("SQL:" + strSQL);
    this.addMessage("[DTSServers] SQL: " + strSQL);
    try {
      this.makeConnection();
      if (this.getList(strSQL, "server information ")) {
        System.out.println("Server Infomation obtained");
        if (this.moveNext()) {
          System.out.println("moved next");
          hm = new HashMap();
          hm.put(DTSServers.ID_FIELD, myRS.getString(DTSServers.ID_FIELD));
          hm.put(DTSServers.SERVER_FIELD,
                 myRS.getString(DTSServers.SERVER_FIELD));
          hm.put(DTSServers.USER_FIELD, myRS.getString(DTSServers.USER_FIELD));
          hm.put(DTSServers.PASSWORD_FIELD,
                 myRS.getString(DTSServers.PASSWORD_FIELD));
        }
        else {
          System.out.println("no next data");
          this.addMessage("[DTSServers] Info: no next data");
        }
      }
      else {
        System.out.println("no info obtained");
        this.addMessage("[DTSServers] Info: no info obtained");
      }
    }
    catch (Exception e) {
      System.out.println("Error: " + e);
    }
    return hm;
  }

  public HashMap getServerInfo(int serverId) {
    HashMap hm = null;
    strSQL = "Select * from " + DTSServers.SERVER_TABLE + " where " +
        DTSServers.ID_FIELD + "=" + serverId + "";
    //System.out.println("SQL:" + strSQL);
    this.addMessage("[DTSServers] SQL: " + strSQL);
    try {
      this.makeConnection();
      if (this.getList(strSQL, "server information ")) {
        System.out.println("Server Infomation obtained");
        if (this.moveNext()) {
          System.out.println("moved next");
          hm = new HashMap();
          hm.put(DTSServers.ID_FIELD, myRS.getString(DTSServers.ID_FIELD));
          hm.put(DTSServers.SERVER_FIELD,
                 myRS.getString(DTSServers.SERVER_FIELD));
          hm.put(DTSServers.USER_FIELD, myRS.getString(DTSServers.USER_FIELD));
          hm.put(DTSServers.PASSWORD_FIELD,
                 myRS.getString(DTSServers.PASSWORD_FIELD));
        }
        else {
          System.out.println("no next data");
          this.addMessage("[DTSServers] Info: no next data");
        }
      }
      else {
        System.out.println("no info obtained");
        this.addMessage("[DTSServers] Info: no info obtained");
      }
    }
    catch (Exception e) {
      System.out.println("Error: " + e);
    }
    return hm;
  }

  public HashMap getServerInfo() {
    HashMap hm = null;
    strSQL = "Select * from " + DTSServers.SERVER_TABLE;
    this.addMessage("[DTSServers] SQL: " + strSQL);
    try {
      if (this.executeQuery(strSQL) != null) {
        System.out.println("Server Infomation obtained");
        this.addMessage("[DTSServers] Info: Server Infomation obtained");
        if (!this.moveNext()) {
          System.out.println("no info obtained");
          this.addMessage("[DTSServers] Info: No server present");
          return hm;
        }
        else {
          hm = new HashMap();
        }
        do {
          HashMap hmm = new HashMap();
          hmm.put(DTSServers.ID_FIELD, myRS.getString(DTSServers.ID_FIELD));
          hmm.put(DTSServers.SERVER_FIELD,
                  myRS.getString(DTSServers.SERVER_FIELD));
          hmm.put(DTSServers.USER_FIELD, myRS.getString(DTSServers.USER_FIELD));
          hmm.put(DTSServers.PASSWORD_FIELD,
                  myRS.getString(DTSServers.PASSWORD_FIELD));
          hm.put(myRS.getString(DTSServers.SERVER_FIELD), hmm);
        }
        while (this.moveNext());
      }
    }
    catch (Exception e) {
      System.out.println("Error: " + e);
      this.addMessage("(!) [DTSServers] Error: " + e);
    }
    return hm;
  }

  public boolean insertServer(String serverName, String user, String pass) {
    if (this.getServerInfo(serverName) != null) {
      System.out.println("Server Already Exist");
      this.addMessage("[DTSServers] Info: Server Already Exist");
    }
    String sql = "insert into " + DTSServers.SERVER_TABLE + " (" +
        DTSServers.SERVER_FIELD + ", " + DTSServers.USER_FIELD + ", " +
        DTSServers.PASSWORD_FIELD + ") ";
    sql += " values ('" + serverName + "', '" + user + "', '" + pass + "')";
    return this.execute(sql);
  }

  public boolean updateServer(String serverName, String user, String pass) {
    boolean success = false;
    HashMap serverinfo = this.getServerInfo(serverName);
    if (serverinfo == null) {
      this.addMessage("[DTSServers] Info: Server does not exist");
    }
    else {
      if (user.equals(serverinfo.get(DTSServers.USER_FIELD)) &&
          pass.equals(serverinfo.get(DTSServers.PASSWORD_FIELD))) {
        this.addMessage("[DTSServers] Info: No change in values");
      }
      else {
        String sql = "update " + DTSServers.SERVER_TABLE + " set " +
            DTSServers.USER_FIELD + "='" + user + "', " +
            DTSServers.PASSWORD_FIELD + "='" + pass + "' " +
            "where " + DTSServers.SERVER_FIELD + "='" + serverName + "'";
        return this.execute(sql);
      }
    }
    return success;
  }

  public boolean deleteServer(int serverId) {
    if (! (new DTSDatabases()).deleteDatabaseByServerId(serverId)) {
      return false;
    }
    String sql = "delete from " + DTSServers.SERVER_TABLE +
        " where " + DTSServers.ID_FIELD + "=" + serverId;
    return this.execute(sql);
  }

  public String getServersInSelect() {
    return this.getServersInSelect(false);
  }

  public String getServersInSelect(boolean byValue) {
    String str2ret = "";
    DTSServers dbs = new DTSServers();
    HashMap hm = dbs.getServerInfo();
    HashMap hmm;
    String keys[] = new String[hm.size()];
    hm.keySet().toArray(keys);
    for (int i = 0; i < keys.length; i++) {
      hmm = (HashMap) hm.get(keys[i]);
      if(byValue){
        str2ret += "<option value='" + hmm.get(DTSServers.SERVER_FIELD) + "'>";
      } else{
        str2ret += "<option value='" + hmm.get(DTSServers.ID_FIELD) + "'>";
      }
      str2ret += hmm.get(DTSServers.SERVER_FIELD);
      str2ret += "</option>\n";
    }
    return str2ret;
  }

}
