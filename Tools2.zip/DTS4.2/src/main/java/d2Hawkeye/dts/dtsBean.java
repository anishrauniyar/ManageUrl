/**********************************************************************************************
 * @author Pawan K Shrestha
 * @since Feb 24 2002
 ***********************************************************************************************/
/**************** Modifications *****************************************************************
 * ----------------------------------------------------------------------------------------------
 * S.No.	Date		Name				Remarks
 * ----------------------------------------------------------------------------------------------
 *101	27 Sep, 2007	Subash Devkota		Changes to integrate import schema from other database 
 * 											servers using DBLink
 *102   12 May 2010     rsah                method added to generate excel file and other corrections
 *
 *103   11 Jan 2011     rsah                method getAllSourceOptimized modified.
 *104   17 Feb 2011     rsah                method getSendToExcelData modified.  Desc: html tags are removed
 *
 **************************************************************************************************/

package d2Hawkeye.dts;

import java.io.File;
import java.io.FileOutputStream;
import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
//import org.apache.poi.hssf.util.Region;
//import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;

//import uk.ltd.getahead.dwr.WebContext;
//import uk.ltd.getahead.dwr.WebContextFactory;
import d2Systems.schedule.HEUserSynchronizer;

public class dtsBean extends sqlBean { 

	private HttpServletRequest request;
	private HttpSession session;
	//WebContext ctx = null;

	/**
	 * initializes session and request objects
	 * 
	 */
	/*public void init() {
		ctx = WebContextFactory.get();

		if (this.session == null) {
			this.session = ctx.getSession();

		}
		if (this.request == null) {
			this.request = ctx.getHttpServletRequest();
		}

	}*/

	public Hashtable listFieldNames = new Hashtable();
	public Hashtable listFieldFormats = new Hashtable();
	public String listFieldNames_1 = "";
	public String listFieldFormats_1 = "";

	public String listDatabaseNames = "";
	public String listTableNames = "";
	private String userForClient = "";
	public String dbMap = "";

	private static final String[] days = { "Sunday", "Monday", "Tuesday",
			"Wednesday", "Thursday", "Friday", "Saturday" };

	private static final String[] months = { "January", "February", "March",
			"April", "May", "June", "July", "August", "September", "October",
			"November", "December" };
	private Vector dbNames;
	private HashMap tbls;
	private HashMap flds;
	private HashMap ffor;
	String filePath = "Excel";

	public HashMap getInfo() {
		return this.ffor;
	}

	public dtsBean() {

	}

	public void cleanup() throws Exception {
	}

	public boolean executeQuerywithFilter(String categoryID, String clientID,
			String targetTableName, String dtsNo, String dtsSetNo, String filter) {
		/*
		 * The filter can be of two type id "Nurture Extract filter" and
		 * "Nurture Full DTS filter" The "Nurture Extract Field" passes
		 * "extract" The "Nurture Full DTS filter" passes "full"
		 */

		//System.out.println("The filter is " + filter);   

		strSQL = " SELECT m.Category, m.SN, Nvl(Z.SETNAME,ZZ.SETNAME) SETNAME, db.DatabaseId SourceDBID, "
				+ " db.DatabaseName SourceDatabase, s.TableName SourceTable, ";
		strSQL += " s.FieldName SourceField, "
				+ " s.FieldFormat SourceFieldFormat, "
				+ " t.TableName TargetTable, " + " t.KeyField TargetField, "
				+ " m.FieldFormat, ";
		// " t.FieldName AS TargetField2Display, " ;

		if (filter != null && !"".equals(filter) && "extract".equals(filter)) {
			strSQL += " nvl(sendExl.ExtractField, t.FieldName) TargetField2Display, ";

		} else {
			strSQL += " t.FieldName AS TargetField2Display, ";
		}

		strSQL += " r.BusinessRule, r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority  ";

		if (filter != null && !"".equals(filter) && "full".equals(filter)) {
			strSQL += " , nvl(sendexl.INEXTRACT,' ') inExtract, "
					+ " nvl(sendexl.RM ,' ') rm, "
					+ " nvl(sendexl.API,' ') api, "
					+ " nvl(sendexl.hawkeyeExplorer,' ') hawkeyeExplorer, "
					+ " nvl(sendexl.extractvariables,' ') extractVariableNames, "
					+ " nvl(sendexl.eligibilityOrparticipant,' ') eligibilityOrparticipant ";
		}

		strSQL += " FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+
				// " INNER JOIN ztbl_DTS_Clients c on t.version=c.version and c.clientid='"
				// +
				// clientID + "'" +
				" INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID + "' " + " and mast.DTSNo='" + dtsNo
				+ "' and t.Version=mast.Version " +
				/**
				 * Added for integrating template implementation Subash Devkota
				 * 05/28/2007
				 */
				" INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES "
				+ "    ON MAST.CLIENTID=TEMPLATES.CLIENTID "
				+ " INNER JOIN ZTBL_DTS_TEMPLATE_DEFS TEMPLATE_DEFS"
				+ "    ON TEMPLATES.TEMPLATEID=TEMPLATE_DEFS.TEMPLATEID"
				+ "    AND TEMPLATE_DEFS.CATEGORY=M.CATEGORY"
				+ "    AND TEMPLATE_DEFS.KEYFIELD=M.KEYFIELD" +
				/************************************** End of changes for template integration ***************************************************************************/

				" LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' "
				+ " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category "
				+ " AND y.KeyField=m.KeyField AND y.DTSNo="
				+ dtsNo
				+ " AND y.SetNo="
				+ dtsSetNo
				+ " AND y.ClientID='"
				+ clientID
				+ "' ";

		strSQL += " LEFT JOIN ZTBL_DTS_SETNAMES Z ON Z.CLIENTID='" + clientID
				+ "' AND Z.DTSNO=" + dtsNo + " AND Z.CATEGORY='" + categoryID
				+ "' AND Z.SETNO=" + dtsSetNo;
		strSQL += " LEFT JOIN (SELECT " + dtsSetNo + " SETNAME, '" + categoryID
				+ "' CATEGORY FROM DUAL)" + "ZZ ON ZZ.CATEGORY=m.Category";

		// The following part is added for filter

		if (filter != null && !"".equals(filter) && "extract".equals(filter)) {
			strSQL += " right join  ZTBL_DTS_SENDTOEXCELFILTER sendExl "
					+ " on t.category=sendExl.category "
					+ " and lower(t.fieldname) = lower(sendExl.fieldname) ";
		}

		if (filter != null && !"".equals(filter) && "full".equals(filter)) {
			strSQL += " LEFT JOIN ZTBL_DTS_FILTER_MAPPING sendexl ON t.category = sendexl.category "
					+ " AND LOWER(t.fieldname) = LOWER(sendexl.keyfield) "
					+ " AND sendexl.clientid= '" + clientID + "' ";
		}
		// The above part is added

		strSQL += " WHERE m.Category='" + categoryID + "' ";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+
				// " INNER JOIN ztbl_DTS_Clients c on t.version=c.version and c.clientid='"
				// +
				// clientID + "'" +
				" INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+ " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='" + clientID + "'  ";

		// The following part is added for row count filter, Bhanu
		if (filter != null && !"".equals(filter) && "extract".equals(filter)) {
			strCountSQL += " right join  ZTBL_DTS_SENDTOEXCELFILTER sendExl "
					+ " on t.category=sendExl.category "
					+ " and lower(t.fieldname) = lower(sendExl.fieldname) ";
		}

		if (filter != null && !"".equals(filter) && "full".equals(filter)) {
			strCountSQL += " LEFT JOIN ZTBL_DTS_FILTER_MAPPING sendexl ON t.category = sendexl.category "
					+ " AND LOWER(t.fieldname) = LOWER(sendexl.keyfield) ";
		}
		// The above part is added

		strCountSQL += " WHERE m.Category='" + categoryID + "' ";

		if (!targetTableName.equals("")) {
			strSQL += " AND t.TableName='"
					+ replaceString(targetTableName, "'", "''") + "'";
			strCountSQL += " AND t.TableName='"
					+ replaceString(targetTableName, "'", "''") + "'";
		}
		strSQL += " ORDER BY m.Category,m.SN";		

		return getList(strSQL, "DTS");

	}

	public boolean executeQuery(String categoryID, String clientID,
			String targetTableName, String dtsNo, String dtsSetNo) {
		int primaryTempId = this.getPrimaryTemplateID();
		int assignedTemplate = this.getAssignedTemplateID(clientID);
		strSQL = "SELECT  m.Category, m.SN, Nvl(Z.SETNAME,ZZ.SETNAME) SETNAME, db.DatabaseId SourceDBID, "
				+ " db.DatabaseName SourceDatabase, s.TableName SourceTable, "
				+ " s.FieldName SourceField, s.FieldFormat SourceFieldFormat, "
				+ " t.TableName TargetTable, t.KeyField TargetField, m.FieldFormat, "
				+ " t.FieldName AS TargetField2Display, "
				+ " r.BusinessRule, r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m "
//				+ " to_char(r.BusinessRule), r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+
				// " INNER JOIN ztbl_DTS_Clients c on t.version=c.version and c.clientid='"
				// +
				// clientID + "'" +
				" INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+
				/**
				 * Added for integrating template implementation Subash Devkota
				 * 05/28/2007
				 * CDF implementation, rsah, Oct 12 2011
				 */				
				" INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES "
				+ "    ON MAST.CLIENTID=TEMPLATES.CLIENTID "
				+ " INNER JOIN (SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_TEMPLATE_DEFS WHERE TEMPLATEID IN ('"+primaryTempId+"','"+assignedTemplate+"') UNION " 
				+ "SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_CLIENT_KEYFIELDS WHERE CLIENTID='"+clientID+"' AND CATEGORY='"+categoryID+"'" 
				+		") TEMPLATE_DEFS"
				+ "    ON "
				+ "     TEMPLATE_DEFS.CATEGORY=M.CATEGORY"
				+ "    AND TEMPLATE_DEFS.KEYFIELD=M.KEYFIELD"
				+
				/************************************** End of changes for template integration ***************************************************************************/

				" LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='"
				+ clientID
				+ "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' "
				+ " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category "
				+ " AND y.KeyField=m.KeyField AND y.DTSNo="
				+ dtsNo
				+ " AND y.SetNo="
				+ dtsSetNo
				+ " AND y.ClientID='"
				+ clientID
				+ "' ";

		strSQL += " LEFT JOIN ZTBL_DTS_SETNAMES Z ON Z.CLIENTID='" + clientID
				+ "' AND Z.DTSNO=" + dtsNo + " AND Z.CATEGORY='" + categoryID
				+ "' AND Z.SETNO=" + dtsSetNo;
		strSQL += " LEFT JOIN (SELECT " + dtsSetNo + " SETNAME, '" + categoryID
				+ "' CATEGORY FROM DUAL)" + "ZZ ON ZZ.CATEGORY=m.Category";

		strSQL += " WHERE m.Category='" + categoryID + "' ";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+
				// " INNER JOIN ztbl_DTS_Clients c on t.version=c.version and c.clientid='"
				// +
				// clientID + "'" +
				" INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+ " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' WHERE m.Category='"
				+ categoryID + "' ";

		if (!targetTableName.equals("")) {
			strSQL += " AND t.TableName='"
					+ replaceString(targetTableName, "'", "''") + "'";
			strCountSQL += " AND t.TableName='"
					+ replaceString(targetTableName, "'", "''") + "'";
		}
		strSQL=" SELECT distinct  " +
				 " category,"+
			      " sn,"+
			      " setname,"+
			      " sourcedbid,"+
			      " sourcedatabase,"+
			      " sourcetable,"+
			      " sourcefield,"+
			      " sourcefieldformat,"+
			      " targettable,"+
			      " targetfield,"+
			      " fieldformat,"+
			      " targetfield2display,"+
			      " To_Char(businessrule) businessrule,"+
			      " translatedrule,"+
			      " example,"+
			      " matched,"+
			      " priority  " +
			      " FROM "+

						" ( "+strSQL+" )";
		strSQL += " ORDER BY Category,SN";
		//System.out.println("executeQuery::Strsql::"+ strSQL+"\n");   
		return getList(strSQL, "DTS");
	}

	public void getSourceFields(String clientID, String tableName, String dtsNo) {
		strSQL = "SELECT DISTINCT TableName, FieldName, FieldFormat from ztbl_DTS_SourceTableSpace "
				+ " WHERE ClientID='" + clientID + "'  AND DTSNo=" + dtsNo;
		if (!tableName.equals("")) {
			strSQL += " AND TableName IN ('" + tableName + "')";
		}
		strSQL += " ORDER BY TableName,FieldName ";
		getList(strSQL, "Source fields");
	}

	public void getSourceTables(String clientID, String dtsNo) {
		strSQL = "SELECT DISTINCT TableName from ztbl_DTS_SourceTableSpace "
				+ " WHERE ClientID='" + clientID + "' AND DTSNo=" + dtsNo
				+ " ORDER BY TableName";
		//System.out.println("strSQL::"+strSQL);    
		getList(strSQL, "Source tables");
	}

	public boolean getCLientListWithSameTemplate(String clientID) {
		strSQL = "SELECT   DISTINCT m.clientid, "
				+ "                  c.clientname "
				+ "FROM     ztbl_dts_dts_mast m "
				+ "         INNER JOIN ztbl_dts_clients c "
				+ "           ON m.clientid = c.clientid "
				+ "         INNER JOIN ztbl_dts_client_templates t "
				+ "           ON c.clientid = t.clientid "
				+ "              AND t.templateid = (SELECT templateid "
				+ "                                  FROM   ztbl_dts_client_templates "
				+ "                                  WHERE  clientid = '"
				+ clientID + "') "
				+ "WHERE    c.clientid NOT IN ('999','998') "
				+ "ORDER BY c.clientname";
		return getList(strSQL, "DTS List of a client");
	}

	public void getDTSOfClient(String clientID) {
		getDTSOfClient(clientID, "");
	}

	public void getDTSOfClient(String clientID, String status) {
		String statusQuery = " Status='" + status + "'";
		if (status.equals("")) {
			statusQuery = " (Status<>'D' or Status is null)";
		}

		strSQL = "SELECT a.DTSNo, "
				+ "  to_char( a.CreationDate,'MM') || '-' ||  "
				+ "  to_char( a.CreationDate,'DD') || '-' ||  "
				+ "  to_number(to_char( a.CreationDate,'YYYY')) CreationDate, "
				+ " a.Status,a.ApprovedBy,  "
				+ " (select userName from ztbl_DTS_Users where userid like a.QcApprovedBy) as QcApprovedBy,"
				+ "  b.UserName, "
				+ "  to_char( a.LastUpdated,'MM') || '-' ||  "
				+ "  to_char( a.LastUpdated,'DD') || '-' ||  "
				+ "  to_number(to_char( a.LastUpdated,'YYYY')) LastUpdated "
				+ " FROM ztbl_DTS_DTS_Mast a LEFT JOIN ztbl_DTS_Users b on a.ApprovedBy=b.UserID "
				+ " WHERE a.ClientID='" + clientID + "' AND " + statusQuery
				+ " ORDER By a.DTSNo desc";
		getList(strSQL, "DTS List of a client");
	}

	public String updateDTS(String clientID, String category, String keyField,
			String version, String businessRule, String sourceTable,
			String sourceField, String sourceFieldFormat) {
		String retValue = "";
		String sql = "";
		sql = "DELETE ztbl_DTS_MAPPING_SOURCE WHERE ClientID='" + clientID
				+ "' AND KeyField='" + keyField + "' AND Category='" + category
				+ "' AND Version='" + version + "'";
		this.execute(sql);

		sql = "DELETE ztbl_DTS_MAPPING_RULE WHERE ClientID='" + clientID
				+ "' AND KeyField='" + keyField + "' AND Category='" + category
				+ "' AND Version='" + version + "'";
		this.execute(sql);

		if (!sourceTable.equals("[]")) { // source fields are selected
			StringTokenizer st = new StringTokenizer(sourceTable, ",");
			StringTokenizer sf = new StringTokenizer(sourceField, ",");
			StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");
			while (st.hasMoreTokens()) {
				sql = "INSERT INTO ztbl_DTS_MAPPING_SOURCE (ClientID, Category, KeyField, Version, TableName,"
						+ "FieldName, FieldFormat) VALUES ('"
						+ clientID
						+ "','"
						+ category
						+ "','"
						+ keyField
						+ "', '"
						+ version
						+ "', '"
						+ st.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+ sf.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+ fm.nextToken().toString().replace('[', ' ').replace(
								']', ' ').replace('~', ',').trim() + "')";
				retValue += "<BR>" + sql;
				// System.out.println("sql 2"+ sql);
				this.execute(sql);
			}
		}

		sql = "INSERT INTO ztbl_DTS_MAPPING_RULE (ClientID, Category, KeyField, Version, BusinessRule) "
				+ " VALUES ('"
				+ clientID
				+ "','"
				+ category
				+ "','"
				+ keyField
				+ "', '"
				+ version
				+ "','"
				+ replaceString(businessRule, "'", "''") + "')";
		retValue += "<BR>" + sql;
		this.execute(sql);
		return retValue;
	}

	// ****************** ADD ENTRY IN DTS_Mast ******
	public boolean addNewDTSEntry(String clientID, int dtsNo, String createdBy,
			String version) {
		String sql = "";
		sql = "INSERT INTO ztbl_DTS_DTS_Mast (ClientID,DTSNo,CreationDate,CreatedBy, version)"
				+ " VALUES ('"
				+ clientID
				+ "',"
				+ dtsNo
				+ ",sysdate ,'"
				+ createdBy + "', '" + version + "')";
		this.execute(sql);

		// **nov 12 - add creation history to ztbl_DTS_Mast_Hist
		sql = "INSERT INTO ztbl_DTS_Mast_Hist (ClientID, DTSNo, Status, ModifiedOn, UserID)"
				+ " VALUES ('"
				+ clientID
				+ "',"
				+ dtsNo
				+ ",'C',sysdate ,'"
				+ createdBy + "')";
		return this.execute(sql);
	}

	// ****************** ADD ENTRY IN DTS_Set ******
	public boolean addNewDTSSet(String clientID, int dtsNo, int setNo) {
		String sql = "";
		sql = "INSERT INTO ztbl_DTS_DTS_Set (ClientID,DTSNo,SetNo)"
				+ " VALUES ('" + clientID + "'," + dtsNo + "," + setNo + ")";
		return this.execute(sql);
	}

	public boolean deleteDTSSet(String clientID, int dtsNo, int setNo) {
		String sql = "";
		sql = "DELETE ztbl_DTS_MAPPING_SOURCE WHERE ClientID='" + clientID
				+ "' AND dtsNo=" + dtsNo + " AND setNo=" + setNo;
		this.execute(sql);

		sql = "DELETE ztbl_DTS_MAPPING_RULE WHERE ClientID='" + clientID
				+ "' AND dtsNo=" + dtsNo + " AND setNo=" + setNo;
		return this.execute(sql);

	}

	public String addBusinessRuleAndSource(String clientID, String category,
			String keyField, String version, String businessRule,
			String sourceTable, String sourceField, String sourceFieldFormat,
			int dtsNo, int setNo) {
		String retValue = "";
		String sql = "";
		if (!sourceTable.equals("[]")) { // source fields are selected
			StringTokenizer st = new StringTokenizer(sourceTable, ",");
			StringTokenizer sf = new StringTokenizer(sourceField, ",");
			StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");

			while (st.hasMoreTokens()) {
				sql = "INSERT INTO ztbl_DTS_MAPPING_SOURCE (ClientID,DTSNo,SetNo,Category,"
						+ "KeyField, Version, TableName,FieldName,FieldFormat) VALUES ('"
						+ clientID
						+ "',"
						+ dtsNo
						+ ","
						+ setNo
						+ ",'"
						+ category
						+ "','"
						+ keyField
						+ "', '"
						+ version
						+ "', '"
						+ st.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+ sf.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+ fm.nextToken().toString().replace('[', ' ').replace(
								']', ' ').replace('~', ',').trim() + "')";
				retValue += "<BR>" + sql;
				// System.out.println("sql 3"+ sql);
				this.execute(sql);
			}
		}

		sql = "INSERT INTO ztbl_DTS_MAPPING_RULE (ClientID,DTSNo,SetNo,Category,KeyField, Version, BusinessRule)"
				+ " VALUES ('"
				+ clientID
				+ "',"
				+ dtsNo
				+ ","
				+ setNo
				+ ",'"
				+ category
				+ "','"
				+ keyField
				+ "', '"
				+ version
				+ "', '"
				+ replaceString(businessRule, "'", "''") + "')";
		retValue += "<BR>" + sql;
		this.execute(sql);
		return retValue;
	}

	// **** mar 31 **********
	public String addUpdateSourceFields(String clientID, String category,
			String keyField, String dtsNo, String setNo, String sourceDatabase,
			String sourceTable, String sourceField, String sourceFieldFormat) {

		String retValue = "";
		String sql = "";
		sql = "DELETE ztbl_DTS_MAPPING_SOURCE WHERE ClientID='" + clientID
				+ "' AND dtsNo=" + dtsNo + " AND setNo=" + setNo
				+ " AND Category='" + category + "' AND KeyField='" + keyField
				+ "'";
		this.execute(sql);  
		String version = this.getVersion(clientID, dtsNo);
		if (!sourceTable.equals("[]")) { // source fields are selected
			StringTokenizer sdb = new StringTokenizer(sourceDatabase, ",");
			StringTokenizer st = new StringTokenizer(sourceTable, ",");
			StringTokenizer sf = new StringTokenizer(sourceField, ",");
			StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");

			while (st.hasMoreTokens()) {
				sql = "INSERT INTO ztbl_DTS_MAPPING_SOURCE (ClientID,DTSNo,SetNo,Category,"
						+ "KeyField, Version, DatabaseId, TableName,FieldName, FieldFormat) VALUES ('"
						+ clientID
						+ "',"
						+ dtsNo
						+ ","
						+ setNo
						+ ",'"
						+ category
						+ "','"
						+ keyField
						+ "', '"
						+ version
						+ "', "
						+ sdb.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ " ,'"
						+ st.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+ sf.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+

						fm.nextToken().toString().replace('[', ' ').replace(
								']', ' ').replace('~', ',').trim() + "')";

				// System.out.println("SQL is 4"+ sql);
				retValue += "<BR>" + sql;
				this.execute(sql);
			}
		}
		updateHighlights(clientID, dtsNo, setNo, category, keyField, version,
				"1");
		return retValue;
	}

	public String getVersion(String clientId, String dtsNo) {
		String sql = "select version from ztbl_dts_dts_mast where clientId='"
				+ clientId + "' and dtsNo=" + dtsNo;
		this.executeQuery(sql);
		if (this.moveNext()) {
			return this.getData("Version");
		}
		return "";
	}

	// ******** mar 31
	// changed - May 11, 2003 by Raj
	public String addUpdateBusinessRule(String clientID, String category,
			String keyField, String version, String dtsNo, String setNo,
			String businessRule) {
		String retValue = "";
		String sql = "";
		businessRule = businessRule.trim();
		sql = "DELETE ztbl_DTS_Mapping_Rule WHERE ClientID='" + clientID
				+ "' AND dtsNo=" + dtsNo + " AND setNo=" + setNo
				+ " AND Category='" + category + "' AND KeyField='" + keyField
				+ "' AND Version='" + version + "'";

		retValue += "<BR>" + sql;
		this.execute(sql);

		if (businessRule.compareTo("") != 0) {
			sql = "INSERT INTO ztbl_DTS_MAPPING_RULE (ClientID, DTSNo, SetNo, "
					+ "Category, KeyField, Version, BusinessRule)"
					+ " VALUES ('" + clientID + "'," + dtsNo + "," + setNo
					+ ",'" + category + "','" + keyField + "', '" + version
					+ "', '" + replaceString(businessRule, "'", "''") + "')";
		}
		retValue += "<BR>" + sql;
		this.execute(sql);

		this.updateHighlights(clientID, dtsNo, setNo, category, keyField,
				version, "1");
		return retValue;
	}

	public String addUpdateTranslatedRule(String clientID, String category,
			String keyField, String version, String dtsNo, String setNo,
			String translatedRule) {
		String sql = "";
		translatedRule = translatedRule.trim();
		if (translatedRule.compareTo("") != 0) {
			sql = "UPDATE ztbl_DTS_MAPPING_RULE SET TranslatedRule='"
					+ translatedRule + "' " + "WHERE clientID='" + clientID
					+ "' and category='" + category + "' and keyField='"
					+ keyField + "' and version='" + version + "' and dtsNo='"
					+ dtsNo + "'" + "and setno='" + setNo + "'";
		}
		this.execute(sql);
		return "<BR>" + sql;
	}

	public String updateExample(String clientID, String category,
			String keyField, String version, String dtsNo, String setNo,
			String example) {
		String sql = "";
		example = example.trim();
		if (example.compareTo("") != 0) {
			sql = "UPDATE ztbl_DTS_MAPPING_RULE SET Example='" + example + "' "
					+ "WHERE clientID='" + clientID + "' and category='"
					+ category + "' and keyField='" + keyField
					+ "' and version='" + version + "' and dtsNo='" + dtsNo
					+ "'" + "and setno='" + setNo + "'";
		}
		this.execute(sql);
		return "<BR>" + sql;
	}

	// ********* april 1
	public String addUpdateSourceTableSpace(String clientID, String dtsNo,
			String sourceTable, String sourceField, String sourceFieldFormat) {
		String retValue = "";
		String sql = "";
		sql = "DELETE ztbl_DTS_Mapping_Source WHERE ClientID='" + clientID
				+ "' AND dtsNo=" + dtsNo;
		retValue += "<BR>" + sql;
		this.execute(sql);

		sql = "DELETE ztbl_DTS_SourceTableSpace WHERE ClientID='" + clientID
				+ "' AND dtsNo=" + dtsNo;
		retValue += "<BR>" + sql;
		this.execute(sql);

		if (!sourceTable.equals("[]")) { // source fields are selected
			StringTokenizer st = new StringTokenizer(sourceTable, ",");
			StringTokenizer sf = new StringTokenizer(sourceField, ",");
			StringTokenizer fm = new StringTokenizer(sourceFieldFormat, ",");

			while (st.hasMoreTokens()) {
				sql = "INSERT INTO ztbl_DTS_SourceTableSpace (ClientID,DTSNo,"
						+ "TableName,FieldName,FieldFormat) VALUES ('"
						+ clientID + "'," + dtsNo + ",'"
						+ st.nextToken().toString().trim() + "','"
						+ sf.nextToken().toString().trim() + "','"
						+ fm.nextToken().toString().replace('~', ',').trim()
						+ "')";
				// System.out.println("sql 1"+ sql);
				retValue += "<BR>" + sql;
				this.execute(sql);
			}
		}
		return retValue;
	}

	// ******** april 2
	public boolean uploadDocument(String clientID, String dtsNo,
			String uploadedDocName, byte[] uploadedDoc, String createdBy)
			throws Exception {
		// int countDoc = 1; //prepareDocumentUpload(clientID, dtsNo);
		// if (countDoc > 0) {
		/*
		 * strSQL = "UPDATE ztbl_DTS_AttachedDocuments set "+ "DocumentName='"+
		 * uploadedDocName+"', Document='"+uploadedDoc+"', "+
		 * "CreatedBy='"+createdBy+"' WHERE ClientID='"+clientID+"'" +
		 * " AND DTSNo="+dtsNo+" AND DocumentCount="+countDoc;
		 * 
		 * strSQL =
		 * "SELECT DocumentName, Document, CreatedBy FROM ztbl_DTS_AttachedDocuments WHERE "
		 * + " ClientID='" + clientID + "' AND DTSNo=" + dtsNo +
		 * " AND DocumentCount=" + countDoc;
		 */
		try {
			if (myConn == null) {
				this.makeConnection();
			}

			PreparedStatement stmt = myConn
					.prepareStatement("INSERT INTO ztbl_DTS_AttachedDocuments (ClientID, DTSNo, DocumentName, Document, CreatedBy) VALUES (?, ?, ?, ?, ?)");
			stmt.setString(1, clientID);
			stmt.setInt(2, Integer.parseInt(dtsNo));
			stmt.setString(3, uploadedDocName);
			stmt.setBytes(4, uploadedDoc);
			stmt.setString(5, createdBy);
			stmt.executeUpdate();
			stmt.close();

			/*
			 * Statement stmt =
			 * myConn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
			 * ResultSet.CONCUR_UPDATABLE); ResultSet rsupd =
			 * stmt.executeQuery(strSQL); if (rsupd.next()) {
			 * rsupd.updateString("DocumentName", uploadedDocName);
			 * rsupd.updateBytes("Document", uploadedDoc);
			 * rsupd.updateString("CreatedBy", createdBy); rsupd.updateRow(); }
			 * rsupd.close();
			 */
		} catch (Exception e) {
			System.out
					.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->1<-"
							+ e);
			this.addMessage(e.toString());
			System.out.println(e);
		}
		// }
		return this.execute(strSQL);
	}

	public int prepareDocumentUpload(String clientID, String dtsNo) {
		int documentCount = 0;
		String count = "";
		strSQL = "SELECT MAX(DocumentCount) DocumentCount FROM ztbl_DTS_AttachedDocuments"
				+ " WHERE ClientID='" + clientID + "' AND DTSNo=" + dtsNo;
		this.executeQuery(strSQL);
		while (this.moveNext()) {
			count = this.getData("DocumentCount");
		}
		if (count == null) {
			count = "0";
		}
		try {
			documentCount = new Integer(count).intValue();
		} catch (NumberFormatException e) {
			System.out
					.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->0<-"
							+ e);
			documentCount = 0;
		}
		documentCount++;
		strSQL = "INSERT INTO ztbl_DTS_AttachedDocuments ( ClientID,DTSNo,DocumentCount)"
				+ " VALUES ('"
				+ clientID
				+ "',"
				+ dtsNo
				+ ","
				+ documentCount
				+ ")";
		this.execute(strSQL);
		return documentCount;
	}

	public boolean getListOfDocuments(String clientID, String dtsNo) {
		strSQL = "SELECT a.DocumentCount, a.DocumentName, b.UserName, dtsNo,"
				+ "to_char(a.CreationDate,'MM') || '-' || "
				+ "to_char(a.CreationDate,'DD') || '-' || "
				+ "to_number(to_char(a.CreationDate,'YYYY')) CreationDate"
				+ " FROM ztbl_DTS_AttachedDocuments a,ztbl_DTS_Users b WHERE a.ClientID='"
				+ clientID + "' AND a.CreatedBy=b.UserID "; // no need to change
		// + clientID + "' AND dtsNo='" + dtsNo + "' AND a.CreatedBy=b.UserID ";
		// //changed by upendra
		// + clientID + "' AND a.CreatedBy=b.UserID ";
		return getList(strSQL, "List of documents");
	}

	public boolean getDocument(String clientID, String dtsNo) {
		strSQL = "SELECT DocumentName,Document FROM ztbl_DTS_AttachedDocuments WHERE ClientID='"
				+ clientID + "' AND dtsNo=" + dtsNo;
		return getList(strSQL, "List of documents");
	}

	// public boolean getListOfUsers(String User
	// added by upendra
	public int getDocumentCount(String clientID, String dtsNo) {
		strCountSQL = "SELECT count(*) docCount FROM ztbl_DTS_AttachedDocuments WHERE ClientID='"
				+ clientID + "' AND dtsNo=" + dtsNo;
		this.executeQuery(strCountSQL);
		if (this.moveNext()) {
			return this.getInt("docCount");
		}
		return 0;
	}

	public boolean addDTSRemark(String clientID, String remarks) {
		strSQL = "UPDATE ztbl_DTS_DTS_Mast SET Remarks='"
				+ replaceString(remarks, "'", "''") + "' WHERE ClientID='"
				+ clientID + "'";
		return this.execute(strSQL);
	}

	/************************************************* Modifications for Clob Handling, 05/18/2007 ******************************************************/
	/*
	 * Modified for Clob handling 05/18/2007, Subash Devkota
	 */

	/*
	 * Old method not handling Clob data. Do not work for long string values
	 * public boolean addUpdateDTSRemark(String clientID, String DTSNo, String
	 * postedBy, String remarksID, String status, String remarks){
	 * if(remarksID.equals("")){//INSERT NEW REMARK strSQL =
	 * "INSERT INTO ZTBL_DTS_REMARKS (CLIENTID, DTSNO, REMARKS, POSTEDBY, POSTEDON, STATUS)"
	 * + " VALUES ('" + clientID.replaceAll("'","''") + "'," + DTSNo + ",'" +
	 * remarks.replaceAll("'","''") + "','" + postedBy.replaceAll("'","''") +
	 * "', SYSDATE, 'A') "; } else{//UPDATE EXISTING REMARK strSQL =
	 * "UPDATE ZTBL_DTS_REMARKS SET REMARKS = '" + remarks.replaceAll("'","''")
	 * + "' "; if(status.equals("D")){ //status=D for delete strSQL +=
	 * ", STATUS = 'D' "; strSQL += ", DROPPEDBY = '" +
	 * postedBy.replaceAll("'","''") + "' "; strSQL += ", DROPPEDON = SYSDATE ";
	 * } else{ strSQL += ", UPDATEDBY = '" + postedBy.replaceAll("'","''") +
	 * "' "; strSQL += ", UPDATEDON = SYSDATE "; } } System.out.println(strSQL);
	 * return this.execute(strSQL); }
	 */

	/**
	 * Update or insert the DTS remarks for the passed clientID. Insert new
	 * entry if remarksID is "" else update the record for the passed remarkID
	 * 
	 * @param clientID
	 * @param DTSNo
	 * @param postedBy
	 * @param remarksID
	 * @param status
	 * @param remarks
	 * @return
	 */
	public boolean addUpdateDTSRemark(String clientID, String DTSNo,
			String postedBy, String remarksID, String status, String remarks) {
		boolean success = false;
		if (remarks == null) {
			remarks = "";
		}
		if (clientID == null) {
			clientID = "";
		}
		if (postedBy == null) {
			postedBy = "";
		}

		remarks = remarks.replaceAll("'", "''");
		if (remarksID.equals("")) {// INSERT NEW REMARK
			strSQL = "INSERT INTO ZTBL_DTS_REMARKS (CLIENTID, DTSNO, REMARKS, POSTEDBY, POSTEDON, STATUS)"
					+ " VALUES ('"
					+ clientID.replaceAll("'", "''")
					+ "',"
					+ DTSNo
					+ ",?,'"
					+ postedBy.replaceAll("'", "''")
					+ "', SYSDATE, 'A') ";
		} else {// UPDATE EXISTING REMARK
			strSQL = "UPDATE ZTBL_DTS_REMARKS SET REMARKS = ? ";
			if (status.equals("D")) { // status=D for delete
				strSQL += ", STATUS = 'D' ";
				strSQL += ", DROPPEDBY = '" + postedBy.replaceAll("'", "''")
						+ "' ";
				strSQL += ", DROPPEDON = SYSDATE ";
			} else {
				strSQL += ", UPDATEDBY = '" + postedBy.replaceAll("'", "''")
						+ "' ";
				strSQL += ", UPDATEDON = SYSDATE ";
			}
		}
		try {
			this.makeConnection();
			PreparedStatement pstmt = myConn.prepareStatement(strSQL);
			setClob(pstmt, remarks, 1);
			pstmt.execute();
			success = true;
			pstmt.close();
		} catch (Exception e) {
			this.debug(true);
			this
					.addMessage("<font color='red'>[sqlBean] query execution error "
							+ e + "<BR>Query:" + strSQL + "</font>");
			return false;
		} finally {
			this.takeDown();
		}
		return success;
	}

	/**
	 * Set the Clob value in the statment from string value
	 * 
	 * @param st
	 * @param value
	 * @param index
	 * @throws SQLException
	 */
	public void setClob(PreparedStatement st, String value, int index)
			throws SQLException {
		StringReader r = new StringReader((String) value);
		st.setCharacterStream(index, r, ((String) value).length());
	}

	/************************************************* End of modifications for Clob Handling, 05/18/2007 ***************************************************/

	public boolean getDTSRemark(String clientID, String dtsNo) {
		// strSQL = "SELECT Remarks FROM ztbl_DTS_DTS_Mast WHERE ClientID='" +
		// clientID + "' AND dtsNo=" + dtsNo;

		strSQL = "SELECT A.REMARKSID, A.CLIENTID, A.DTSNO, A.REMARKS, A.POSTEDBY, A.POSTEDON, "
				+ " A.UPDATEDBY, A.UPDATEDON, A.DROPPEDBY, A.DROPPEDON, A.PARENTREMARKSID, A.STATUS, B.USERNAME "
				+ " FROM ZTBL_DTS_REMARKS A, ZTBL_DTS_USERS B WHERE A.POSTEDBY = B.USERID AND "
				+ " UPPER(STATUS)<>'D' AND A.ClientID='"
				+ clientID
				+ "' AND A.DTSNO=" + dtsNo + "" + " ORDER BY A.REMARKSID DESC";
		// System.out.println(strSQL);
		return getList(strSQL, "List of remarks");
	}

	// added by upendra
	public boolean remarkExist(String clientID, String dtsNo) {
		// strSQL = "SELECT Remarks FROM ztbl_DTS_DTS_Mast WHERE ClientID='" +
		// clientID + "' AND dtsNo=" + dtsNo;
           boolean ret = true;
		strSQL = "SELECT COUNT(1) as ct FROM ZTBL_DTS_REMARKS WHERE ClientID='"
				+ clientID + "' AND dtsNo=" + dtsNo;
		this.executeQuery(strSQL);
		if (this.moveNext()) {			
			if (!this.checkNull(this.getData("ct")).equals("0")) {
				ret = false;
			}	
		}		
		return ret;
	}

	// ********** april 08 *****************************************************
	// ********** april 09 *****************************************************
	public String updateHighlights(String clientID, String dtsNo, String setNo,
			String category, String keyfields, String version,
			String highlightMode) {
		String retValue = "";
		String sql = "";
		StringTokenizer st = new StringTokenizer(keyfields, ",");

		// Highlight a field or fields
		if (highlightMode.equals("1")) {
			while (st.hasMoreTokens()) {
				String kf = st.nextToken().toString().trim();
				// Clean the table first
				sql = "DELETE ztbl_DTS_Mapping_Highlights WHERE"
						+ " ClientID='" + clientID + "'" + " AND DTSNo="
						+ dtsNo + " AND SetNo=" + setNo + " AND Category='"
						+ category + "'" + " AND KeyField='" + kf + "'"
						+ " AND Version='" + version + "'";
				this.execute(sql);
				sql = "INSERT INTO ztbl_DTS_Mapping_Highlights"
						+ " (ClientID, DTSNo, SetNo, Category, KeyField, Version, Priority)"
						+ " VALUES ('" + clientID + "'," + dtsNo + "," + setNo
						+ ",'" + category + "','" + kf + "', '" + version
						+ "', 'y')";
				retValue += "<BR>" + sql;
				this.execute(sql);
			}
		}
		// Unhighlight a field or fields
		else if (highlightMode.equals("0")) {
			while (st.hasMoreTokens()) {
				String kf = st.nextToken().toString().trim();
				sql = "DELETE ztbl_DTS_Mapping_Highlights WHERE"
						+ " ClientID='" + clientID + "'" + " AND DTSNo="
						+ dtsNo + " AND SetNo=" + setNo + " AND Category='"
						+ category + "'" + " AND KeyField='" + kf + "'"
						+ " AND Version='" + version + "'";
				retValue += "<BR>" + sql;
				this.execute(sql);
			}
		}
		// Delete all highlights from a set (same "0" but for all keyfields)
		else if (highlightMode.equals("2")) {
			sql = "DELETE ztbl_DTS_Mapping_Highlights WHERE" + " ClientID='"
					+ clientID + "'" + " AND DTSNo=" + dtsNo + " AND SetNo="
					+ setNo + " AND Category='" + category + "'"
					+ " AND Version='" + version + "'";
			retValue += "<BR>" + sql;
			this.execute(sql);
		}
		return retValue;
	}

	public boolean deleteDocument(String clientID, String dtsNo,
			String documentCount) {
		strSQL = "DELETE ztbl_DTS_AttachedDocuments WHERE ClientID='"
				+ clientID + "' AND DTSNo=" + dtsNo + " AND DocumentCount="
				+ documentCount;
		return this.execute(strSQL);
	}

	// ********** Apr 10 ***********************************************
	public boolean deleteSourceTableSpace(String clientID, String dtsNo,
			String database) {
		strSQL = "DELETE ztbl_DTS_SourceTableSpace WHERE ClientID='" + clientID
				+ "' AND DTSNo=" + dtsNo + " AND DatabaseId=" + database + "";
		return this.execute(strSQL);
	}

	public boolean insertSourceTableSpace(String clientID, String dtsNo,
			String TableName, String FieldName, String FieldFormat,
			String databaseId) throws Exception {
		strSQL = "INSERT INTO ztbl_DTS_SourceTableSpace "
				+ " (ClientID, DTSNo, TableName, FieldName, DatabaseId, FieldFormat) "
				+ " VALUES('" + clientID + "'," + dtsNo + ",'" + TableName
				+ "','" + FieldName + "'," + databaseId + ",'" + FieldFormat
				+ "')";
		return this.execute(strSQL);
	}

	public boolean saveSrcTableConf(String srcClient,String srcDTSNo,String srcCategory,String srcSetNo,String[] srcSelectedTableList,String userID) throws Exception {
		boolean result = false;	
		
			strSQL="delete from ztbl_dts_sourcetable_config where ClientId='"+srcClient+"'" +
					"and DtsNo='"+srcDTSNo+"' " +
					"and category='"+srcCategory+"' " +
							"and SetName='"+srcSetNo+"'";
			//System.out.println("method-->saveSrcTableConf::strSQL:"+strSQL);       
		this.execute(strSQL);
		if(srcSelectedTableList.length > 0)
		{
			for(int i=0;i<srcSelectedTableList.length;i++)
			{
		strSQL = "INSERT INTO ztbl_dts_sourcetable_config "
				+ " (ClientID, DTSNo,Category, SetName, TableName, userid) "
				+ " VALUES('" + srcClient + "','" + srcDTSNo + "','"+srcCategory+"'  "
				+ ",'" + srcSetNo + "','" + srcSelectedTableList[i] + "','" + userID
				+ "')";     
		//System.out.println("strSQL:"+strSQL);      
		this.execute(strSQL);
		result=true;   
			}
		}  
		return result;  
	} 
	
	public boolean saveBucketConf(String clientID,String dtsNo,String[] setAndCategory,String bucketId,String bucketName,String userID) throws Exception {
		boolean result = false;	
		boolean duplicateName=false;
		ResultSet rs = null;
		String oldBucketName = "";
		bucketName = bucketName.replaceAll("'", "''").trim();

		//check for duplicate bucket name start
		if(!bucketId.equalsIgnoreCase("-1")){
			strSQL = "SELECT BucketName oldBucketName from  ztbl_dts_bucket where "
				+ "  clientid='" + clientID + "' and dtsno=" + dtsNo
				+ " and bucketid='" + bucketId + "'";			
			rs = this.executeQuery(strSQL);
			try {
				while (rs.next()) {
					oldBucketName = rs.getString("oldBucketName").trim().replaceAll("'", "''");					
				}
			} catch (Exception e) {
				oldBucketName = "";
				System.out.println("Error while pulling the oldsetName" + strSQL
						+ " and oldsetName is " + oldBucketName);
			}
			
			if (!oldBucketName.equalsIgnoreCase(bucketName)){
				duplicateName=checkDuplicateBucketName(clientID, dtsNo, bucketName);	
			}
			
		} else
		{
			duplicateName=checkDuplicateBucketName(clientID, dtsNo, bucketName);	
		}		  
		if (duplicateName) {
			System.out.println( "Duplicate name found, Bucket with name " + bucketName
					+ " already exists, \n Please enter another name");
			return false;
		}	
		//check for duplicate bucket name end
		
		
		if(!bucketId.equalsIgnoreCase("-1")){
			
			strSQL="";
			strSQL = "update ztbl_dts_bucket set bucketname='"+bucketName+"' where bucketid='"+bucketId+"'";
			this.execute(strSQL);  
			strSQL = "delete from ztbl_dts_bucket_details where bucketid='"+bucketId+"'";
			this.execute(strSQL);   
		}
		else
		{
			strSQL = "INSERT INTO ztbl_dts_bucket "
				+ " (BucketId,BucketName,ClientID, DTSNo,UserId, IsDeleted) "
				+ " VALUES(1,'" + bucketName + "','" + clientID + "','"+dtsNo+"'  "
				+ ",'" + userID + "','N')";    
			this.execute(strSQL);  	
		}		
		
		if(setAndCategory.length > 0)
		{
			for(int i=0;i<setAndCategory.length;i++)
			{
					String[] tempSetAndCat = setAndCategory[i].split("::::");					
					String setName="";
					String category="";
						setName=tempSetAndCat[0];
						setName = setName.replaceAll("'", "''").trim();
						category=tempSetAndCat[1];
						if(!bucketId.equalsIgnoreCase("-1")){
							strSQL = "INSERT INTO ztbl_dts_bucket_details "
								+ " (BucketId,Category,SetName)" 
								+ " SELECT '"+bucketId+"','" +category+ "','"+setName+"' from dual";
						}
						else
						{
							strSQL = "INSERT INTO ztbl_dts_bucket_details "
								+ " (BucketId,Category,SetName)" 
								+ " SELECT SEQ_DTS_BUCKET.currval,'" +category+ "','"+setName+"' from dual";
						}
				//System.out.println("saveBucketConf::strSQL-->while update-->"+strSQL);  
		this.execute(strSQL);   
		result=true;     
			}
		}  
		return result;  
	}      

	public boolean addSourceTableSpace(String clientID, String dtsNo,
			String databaseID) {
		/* Modification#101:start */
		String dbLink = getDBLink(clientID);
		/* Modification#101:end */

		strSQL = "INSERT INTO ztbl_DTS_SourceTableSpace "
				+ "(CLIENTID, DTSNO, TABLENAME, FIELDNAME, FIELDFORMAT, DATABASEID) "
				+ "	SELECT " + "'"
				+ clientID
				+ "',"
				+ dtsNo
				+ ","
				+ " TABLE_NAME, "
				+ " COLUMN_NAME, "
				+ " CASE "
				+ "	WHEN DATA_TYPE LIKE '%NUMBER%' AND DATA_PRECISION IS NOT NULL "
				+ "	THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ',' "
				+ "		|| CAST((DATA_LENGTH-DATA_PRECISION) AS VARCHAR(5)) || ')' "
				+ "	WHEN DATA_TYPE LIKE '%CHAR%' OR DATA_TYPE LIKE '%NUMBER%'  "
				+ "	THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ')' "
				+ "	ELSE DATA_TYPE "
				+ " END, "
				+ ""
				+ databaseID
				+ " "
				+ " FROM 	DBA_TAB_COLS"
				+
				/* Modification#101:start */
				dbLink
				/* Modification#101:end */
				+ " a, "
				+ "(SELECT "
				+
				/* Modification#101:start */
				"	CASE "
				+ "		WHEN InStr(DATABASENAME,'@')>0 "
				+ "		THEN SubStr(DATABASENAME,1,instr(DATABASENAME,'@')-1) "
				+ "		ELSE DATABASENAME "
				+ "   END "
				+
				/* Modification#101:end */
				" DATABASENAME "
				+ " FROM ztbl_DTS_Databases "
				+ " WHERE DATABASEID="
				+ databaseID
				+ ") b "
				+ " WHERE 	UPPER(owner) = UPPER(b.DATABASENAME) "
				+ " AND TABLE_NAME NOT LIKE '%$%'";
		return this.execute(strSQL);
	}

	/*
	 * Modification#101:start
	 */
	/**
	 * Return db link string
	 * 
	 * @param clientID
	 * @return
	 */
	public String getDBLink(String clientID) {
		String dblink = "";
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			PreparedStatement stmt = myConn.prepareCall(" SELECT "
					+ "	CASE WHEN InStr(DATABASENAME,'@')>0 "
					+ "		THEN SubStr(DATABASENAME,instr(DATABASENAME,'@')) "
					+ "		ELSE ' ' " + "	END DBLINK "
					+ " FROM ztbl_DTS_Databases " + " WHERE CLIENTID = ?");
			stmt.setString(1, clientID);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				dblink = rs.getString(1);
			}
			stmt.close();

		} catch (Exception e) {
			System.out.println("ERROR getting DBLink string " + e.toString());
			this.addMessage("ERROR getting DBLink string " + e.toString());
		}
		return dblink;
	}

	/*
	 * Modification#101:end
	 */

	/*
	 * public boolean copyDTS(String clientID, String prevDTSNo, String
	 * currentDTSNo) { strSQL = "INSERT INTO ztbl_DTS_Mapping_Highlights " +
	 * " (ClientID, DTSNo, Category, KeyField, Priority, Version)" +
	 * " (SELECT '" + clientID + "' as ClientID," + currentDTSNo +
	 * " as DTSNo , Category, KeyField, Priority, Version" +
	 * " FROM ztbl_DTS_Mapping_Highlights WHERE ClientID='" + clientID +
	 * "' AND " + " DTSNo=" + prevDTSNo + ")"; this.execute(strSQL);
	 * 
	 * strSQL = "INSERT INTO ztbl_DTS_Mapping_Rule " +
	 * " (ClientID, DTSNo, SetNo, Category, KeyField, Version, BusinessRule)" +
	 * " (SELECT '" + clientID + "'," + currentDTSNo +
	 * ", SetNo, Category, KeyField, Version, BusinessRule" +
	 * " FROM ztbl_DTS_Mapping_Rule WHERE ClientID='" + clientID + "' AND " +
	 * " DTSNo=" + prevDTSNo + ")"; this.execute(strSQL);
	 * 
	 * strSQL = "INSERT INTO ztbl_DTS_Mapping_Source " +
	 * " (ClientID, DTSNo, SetNo, Category, KeyField, Version, TableName, " +
	 * " FieldName, FieldFormat)" + " (SELECT '" + clientID + "'," +
	 * currentDTSNo +
	 * ", SetNo, Category, KeyField, Version, TableName, FieldName, FieldFormat"
	 * + " FROM ztbl_DTS_Mapping_Source WHERE ClientID='" + clientID + "' AND "
	 * + " DTSNo=" + prevDTSNo + ")"; return this.execute(strSQL); }
	 */
	// ********** Apr 18 ***********************************************
	public boolean deleteDTS1(String clientID, String dtsNo, String TorP) {
		strSQL = "sp_DeleteDTS '" + clientID + "'," + dtsNo + ",'" + TorP + "'";
		return this.execute(strSQL);
	}

	public boolean deleteDTS(String clientID, String dtsNo, String TorP) {
		// strSQL = "EXEC sp_DeleteDTS('" + clientID + "'," + dtsNo + ",'" +
		// TorP + "');";
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_DeleteDTS(?,?,?)}");
			stmt.setString(1, clientID);
			stmt.setInt(2, Integer.parseInt(dtsNo));
			stmt.setString(3, TorP);
			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_DeleteDTS " + e.toString());
			this.addMessage("ERROR calling sp_DeleteDTS" + e.toString());
		}

		return retVal;
	}

	public void setUserForClient(String user) {
		userForClient = user;
	}

	public boolean getListOfClients(String clientID, String orderBy) {
		if (orderBy.equals("")) {
			orderBy = " a.ClientName";
		}
		strSQL = "SELECT distinct a.ClientID, a.ClientName, a.ContractType, a.DatabaseName,"
				+ "a.UserName, a.ServerName, a.UserPassword, a.InUse, a.Version FROM ztbl_DTS_ClientView a ";
		String strWhere = " WHERE InUse = 'Y' ";

		if (!userForClient.equals("")) {
			strSQL += " INNER JOIN ztbl_DTS_UsersAndClients b ON a.ClientID=b.ClientID ";
			strWhere += " AND b.UserID='" + userForClient + "'";
		}

		if (!clientID.equals("")) {
			strWhere += " AND a.ClientID='" + clientID + "'";
		}
		strSQL = strSQL + strWhere + " ORDER BY " + orderBy;
		return getList(strSQL, "Clients List");
	}

	public boolean getListOfCategories() {
		return this.getListOfCategories("");
	}

	public boolean getListOfCategories(String orderBy) {
		if (orderBy.equals("")) {
			orderBy = " SN";
		}
		strSQL = "SELECT * FROM ztbl_DTS_Categories ORDER BY " + orderBy;
		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Categories";

		return getList(strSQL, "Categories List");
	}
	
	public boolean getUnselectedSourceTables(String srcClient,String srcDTSNo,String srcCategory, String srcSetName) {
		strSQL = "SELECT DISTINCT tablename "
			+ "FROM   ztbl_dts_sourcetablespace s, "
			+ "       ztbl_dts_databases d "
			+ "WHERE  s.databaseid = d.databaseid "
			+ "       AND ( ( d.clientid = '"+srcClient+"' "
			+ "               AND dtsno = '"+srcDTSNo+"') "
			+ "              OR ( d.clientid = '999' "
			+ "                   AND ( tablename LIKE '%"+srcClient+"%' "
			+ "                          OR Upper(tablename) LIKE Upper('HR_GLOBAL%') ) ) ) "
			+ "MINUS "
			+ "SELECT tablename "
			+ "FROM   ztbl_dts_sourcetable_config "
			+ "WHERE  clientid = '"+srcClient+"' "
			+ "       AND dtsno = '"+srcDTSNo+"' "
			+ "       AND category = '"+srcCategory+"' "
			+ "       AND setname = '"+srcSetName+"' ";        

		//System.out.println("Method-->getUnselectedSourceTables():"+strSQL);   
		return getList(strSQL, "Unselected Src Table Name List");    
	}
	/*
	 * created by Ram Gautam,4 Aug,2012
	 * Description: this function is used to get the all HawkeyeRule's table of given client  
	 * 
	 */
	public String getAllClientHawkeyeRuleTables(String client){
		
		 StringBuilder allClientHawkeyRuleTable= new StringBuilder("");
		strSQL = "SELECT DISTINCT tablename "
			+ "FROM   ztbl_dts_sourcetablespace "
			+ "WHERE  tablename LIKE 'HR_"+client+"%' "
			+ "       AND tablename NOT LIKE 'HR_GLOBAL%'";
		
		System.out.println("Method-->getAllClientHawkeyeRuleTables():"+strSQL);   
		 boolean result= getList(strSQL, "All HawkeyeRule Table Name List");
		 if (result) {               
				while (this.moveNext()) {
					 String sourceTable=this.getData("TableName");  
					allClientHawkeyRuleTable.append("<OPTION VALUE='" + sourceTable +"'>"+sourceTable+"</option>"); 
			}
			
		 }
		
		return allClientHawkeyRuleTable.toString();
	}
	/*
	 * created by Ram Gautam,4 Aug,2012
	 * Description: this function is used to get the all HawkeyeRule's table of given client  
	 * 
	 */
	public String getAllClientUnSelectedHawkeyeRuleTables(String selectedClient,String srcClient,
			String srcDTSNo,String srcCategory,String srcSetName){
		
		 StringBuilder allHawkeyeRuleTables=new StringBuilder("");
		
		strSQL = "SELECT DISTINCT tablename "
			+ " FROM   ztbl_dts_sourcetablespace "
			+ " WHERE  tablename LIKE 'HR_"+selectedClient+"%' "
			+ "       AND tablename NOT LIKE 'HR_GLOBAL%'" 
			+ " MINUS "
			+ " SELECT tablename "
			+ " FROM   ztbl_dts_sourcetable_config "
			+ " WHERE  clientid = '"+srcClient+"' "
			+ "       AND dtsno = '"+srcDTSNo+"' "
			+ "       AND category = '"+srcCategory+"' "
			+ "       AND setname = '"+srcSetName+"' ";   
		
		System.out.println("Method-->getAllClientUnSelectedHawkeyeRuleTables:"+strSQL);   
		 boolean result= getList(strSQL, "All selected Src Table Name List");
		 if (result) {               
				while (this.moveNext()) {
					 String sourceTable=this.getData("TableName");  
					allHawkeyeRuleTables.append("<OPTION VALUE='" + sourceTable +"'>"+sourceTable+"</option>"); 
			}
			
		 }
		System.out.println("getAllClientUnSelectedHawkeyeRuleTables"+allHawkeyeRuleTables.toString());
		 return allHawkeyeRuleTables.toString();
	}
	/*
	 * created by Ram Gautam, 30 Aug,2012
	 * Description: this function is used to get the all sourcetable  
	 * 
	 */
	public String getAllSourceTables(String srcClient,String srcDTSNo,String srcCategory, String srcSetName) {
		 StringBuilder allSourceTables=new StringBuilder("");
		
		strSQL = "SELECT DISTINCT tablename "
			+ "FROM   ztbl_dts_sourcetablespace s, "
			+ "       ztbl_dts_databases d "
			+ "WHERE  s.databaseid = d.databaseid "
			+ "       AND ( ( d.clientid = '"+srcClient+"' "
			+ "               AND dtsno = '"+srcDTSNo+"') "
			+ "              OR ( d.clientid = '999' "
			+ "                   AND ( tablename LIKE '%"+srcClient+"%' "
			+ "                          OR Upper(tablename) LIKE Upper('HR_GLOBAL%') ) ) )" 
			+ " order by upper(tablename) ";
			
			/*+ "MINUS "
			+ "SELECT tablename "
			+ "FROM   ztbl_dts_sourcetable_config "
			+ "WHERE  clientid = '"+srcClient+"' "
			+ "       AND dtsno = '"+srcDTSNo+"' "
			+ "       AND category = '"+srcCategory+"' "
			+ "       AND setname = '"+srcSetName+"' "*/        

		System.out.println("Method-->getAllSourceTables():"+strSQL);   
		 boolean result= getList(strSQL, "All selected Src Table Name List");
		 if (result) {               
				while (this.moveNext()) {
					 String sourceTable=this.getData("TableName");  
					allSourceTables.append("<OPTION VALUE='" + sourceTable +"'>"+sourceTable+"</option>"); 
			}
			
		 }
		return allSourceTables.toString();
	}
	
	public boolean getSelectedSourceTables(String srcClient,String srcDTSNo, String srcCategory,String srcSetName) {
		strSQL = "SELECT tablename FROM ztbl_dts_sourcetable_config where ClientId='"+srcClient+"' and DtsNo='"+srcDTSNo+"' " + 
		" and category='"+srcCategory+"'  and SetName='"+srcSetName+"' order by upper(tablename)";       
		//System.out.println("Method-->getSelectedSourceTables():"+strSQL);    
		return getList(strSQL, "Selected Src Table Name List");               
	}
 
	/**
	 * Get the list of categories available to the client defined by template
	 * 
	 * @author Subash Devkota
	 * @param clientID
	 * @param orderBy
	 * @return
	 */
	public boolean getListOfCategories(String clientID, String orderBy) {
		if (orderBy.equals("")) {
			orderBy = " Category";
		}
		int primaryTemplateId = this.getPrimaryTemplateID();
		int assignedTemplateId = this.getAssignedTemplateID(clientID);
		
		/*strSQL = " SELECT distinct a.SN, a.CATEGORY, a.CATEGORYDESC "
				+ " FROM " + "		ztbl_DTS_Categories a,"
				+ "		ztbl_dts_client_templates b, "
				+ "		ztbl_dts_template_defs c" + " where "
				+ "		a.category=c.category" + "	and c.templateid in ('"+primaryTemplateId+"','"+assignedTemplateId+"')"
				+ "		and b.clientId='" + clientID + "' UNION "
				+ "		SELECT DISTINCT X.sn SN,X.category CATEGORY, X.categorydesc CATEGORYDESC "
                + "     FROM   ztbl_dts_categories X  inner join ZTBL_DTS_CLIENT_KEYFIELDS Y" 
                + "		ON X.category=Y.category where clientid='" + clientID + "'"   
                + " ORDER BY "
				+ orderBy;	*/	
		
		strSQL =  "SELECT * "
			+ "FROM   (SELECT DISTINCT a.sn, "
			+ "                        a.category, "
			+ "                        a.categorydesc, "
			+ "                        b.clientid "
			+ "        FROM   ztbl_dts_categories a, "
			+ "               ztbl_dts_client_templates b, "
			+ "               ztbl_dts_template_defs c "
			+ "        WHERE  a.category = c.category "
			+ "               AND c.templateid IN ('"+primaryTemplateId+"','"+assignedTemplateId+"')"
			+ "               AND b.clientid = '" + clientID + "'" 
			+ "        UNION "
			+ "        SELECT DISTINCT X.sn           SN, "
			+ "                        X.category     CATEGORY, "
			+ "                        X.categorydesc CATEGORYDESC, "
			+ "                        clientid "
			+ "        FROM   ztbl_dts_categories X "
			+ "               inner join ztbl_dts_client_keyfields Y "
			+ "                       ON X.category = Y.category "
			+ "        WHERE  clientid = '" + clientID + "'" 
			+ "        ORDER  BY "+ orderBy+")a "
			+ "       inner join ztbl_dts_clients c "
			+ "               ON c.clientid = a.clientid "
			+ "WHERE  Substr(a.category, 1, 2) LIKE CASE "
			+ "                                       WHEN Length(c.clienttype) > 2 THEN '%' "
			+ "                                       ELSE c.clienttype "
			+ "                                     END";


		return getList(strSQL, "Categories List"); 
	}

	public boolean getListOfVersions() {
		strSQL = "select distinct version from ztbl_dts_mapping_mast";
		return getList(strSQL, "Version List");
	}

	public boolean getListOfTargetTables() {
		strSQL = "SELECT DISTINCT TableName FROM ztbl_DTS_TargetTableSpace ORDER BY TableName";
		return getList(strSQL, "List of target tables");
	}

	public boolean getListOfTargetTables(String version) {
		strSQL = "SELECT DISTINCT TableName FROM ztbl_DTS_TargetTableSpace"
				+ " WHERE Version='" + version + "'" + " ORDER BY TableName";
		return getList(strSQL, "List of target tables");
	}

	public boolean getListOfTargetTables(String clientID, String category,
			String version) {
		strSQL = " SELECT DISTINCT TableName from ztbl_DTS_Mapping_Target mt, "
				+ " ztbl_DTS_Clients c where Category='" + category
				+ "' and mt.version=c.version and c.clientId='" + clientID
				+ "' and mt.version='" + version + "' ORDER BY TableName";
		return getList(strSQL, "Target tables list");
	}

	public boolean getListOfTargetTables(String clientID, String category) {
		strSQL = " SELECT DISTINCT TableName from ztbl_DTS_Mapping_Target mt, "
				+ " ztbl_DTS_Clients c where Category='" + category
				+ "' and mt.version=c.version and c.clientId='" + clientID
				+ "' ORDER BY TableName";
		return getList(strSQL, "Target tables list");
	}

	public boolean getListOfSets(String clientID, String setNo) {
		strSQL = " SELECT distinct setname,setno FROM ZTBL_DTS_SETNAMES  WHERE ClientID='"
				+ clientID
				+ "'"
				+ " AND DTSNo='"
				+ setNo
				+ "' ORDER BY setname";
		//System.out.println("strSQL"+strSQL);   
		return getList(strSQL, "DTS set list");
	}
	public boolean getListOfSetsName(String clientID, String setNo) {
		strSQL = " SELECT distinct setname FROM ZTBL_DTS_SETNAMES  WHERE ClientID='"
				+ clientID
				+ "'"
				+ " AND DTSNo='"
				+ setNo
				+ "' ORDER BY upper(setname)";   
		//System.out.println("strSQL"+strSQL);   
		return getList(strSQL, "DTS set list");
	}
	public boolean getListOfBucket(String clientID, String dtsNo) {
		strSQL = " SELECT BucketId,BucketName FROM ZTBL_DTS_bucket  WHERE ClientID='"
				+ clientID
				+ "'"
				+ " AND DTSNo='"
				+ dtsNo 
				+ "' AND IsDeleted='N' ORDER BY upper(BucketName)";   
		//System.out.println("strSQL"+strSQL);   
		return getList(strSQL, "DTS set list");
	}	
	public boolean getListOfBucketCategories(String bucketId) {
		strSQL = " SELECT distinct Category FROM ZTBL_DTS_bucket_details  WHERE bucketid='"+bucketId+"' order by category";
		//System.out.println("strSQL"+strSQL);   
		return getList(strSQL, "Bucket Category list");
	}	
	
	public DTSBucket getBucketConfig(String clientID, String dtsNo, String bucketId) {		
		String categoryName="";		
		String strSql="";
		List<String> categoryNameList=new ArrayList();
		DTSBucket dtsBucket=new DTSBucket("0");
		/* when old bucket is modified */
	if(!bucketId.equalsIgnoreCase("-1"))
		{
		strSql = ""
			+ "SELECT setname,bucketid ";
		if (getListOfCategories(clientID, "")) {  
            while (this.moveNext()) {
            	categoryName = this.getData("Category");
            	categoryNameList.add(categoryName);
            	strSql += ","
			+ "       CASE "
			+ "         WHEN Instr(segment_path, '"+categoryName+"') = 1 "
			+ "              AND Instr(segment_path, '"+categoryName+"') > 0 THEN 1 "
			+ "         WHEN Instr(segment_path, '"+categoryName+"') <> 1 "
			+ "              AND Instr(segment_path, '"+categoryName+"') > 0 THEN 1 "
			+ "         ELSE 0 "
			+ "       END AS \""+categoryName+"\" ";
        }
		}
		strSql += " FROM  (SELECT setname,bucketid, "
			+ "              MAX(Ltrim(Sys_connect_by_path(category, ','), ', ')) keep ( "
			+ "              dense_rank "
			+ "                    last ORDER "
			+ "              BY LEVEL) AS segment_path "
			+ "       FROM   (" 
			+ "SELECT d.setname, "
			+ "       d.category, "
			+ "       c.bucketid, "
			+ "       Row_number() over ( PARTITION BY d.setname ORDER BY ROWNUM) rn "
			+ "FROM   (SELECT setname, "
			+ "               category, "
			+ "               clientid, "
			+ "               dtsno "
			+ "        FROM   ztbl_dts_setnames "
			+ "        WHERE  clientid = '"+clientID+"' "
			+ "               AND dtsno = '"+dtsNo+"') d "
			+ "       left join (SELECT a.setname, "
			+ "                         a.category, "
			+ "                         b.clientid, "
			+ "                         b.dtsno, "
			+ "                         a.bucketid "
			+ "                  FROM   (SELECT setname, "
			+ "                                 category, "
			+ "                                 bucketid "
			+ "                          FROM   ztbl_dts_bucket_details "
			+ "                          WHERE  bucketid = '"+bucketId+"') a "
			+ "                         left join ztbl_dts_bucket b "
			+ "                           ON a.bucketid = b.bucketid) c "
			+ "         ON d.clientid = c.clientid "
			+ "            AND d.dtsno = c.dtsno "
			+ "            AND d.category = c.category "
			+ "            AND d.setname = c.setname "
			+ "ORDER  BY d.setname, "
			+ "          d.category) "
			//+					") where bucketid is not null "
			+ "       START WITH rn = 1 "
			+ "       CONNECT BY PRIOR setname = setname "
			+ "                        AND PRIOR rn = rn - 1 "
			+ "       GROUP  BY setname,bucketid) order by setname ";
		}else{//when new bucket is added
		strSql = ""
			+ "SELECT setname,'-1' as bucketid ";
		if (getListOfCategories(clientID, "")) {  
            while (this.moveNext()) {
            	categoryName = this.getData("Category");
            	categoryNameList.add(categoryName);
            	strSql += ","
			+ "       CASE "
			+ "         WHEN Instr(segment_path, '"+categoryName+"') = 1 "
			+ "              AND Instr(segment_path, '"+categoryName+"') > 0 THEN 1 "
			+ "         WHEN Instr(segment_path, '"+categoryName+"') <> 1 "
			+ "              AND Instr(segment_path, '"+categoryName+"') > 0 THEN 1 "
			+ "         ELSE 0 "
			+ "       END AS \""+categoryName+"\" ";
        }
		}
		strSql += " FROM  (SELECT setname, "
			+ "              MAX(Ltrim(Sys_connect_by_path(category, ','), ', ')) keep ( "
			+ "              dense_rank "
			+ "                    last ORDER "
			+ "              BY LEVEL) AS segment_path "
			+ "       FROM   (" +
					"SELECT setname, "
			+ "                      category, "
			+ "                      Row_number() over ( PARTITION BY setname ORDER BY ROWNUM) "
			+ "                      rn "
			+ "               FROM   ztbl_dts_setnames "
			+ "               WHERE  clientid = '"+clientID+"' "
			+ "                      AND dtsno = '"+dtsNo+"' "
			+ "               ORDER  BY setname, "
			+ "                         category) "
			+ "       START WITH rn = 1 "
			+ "       CONNECT BY PRIOR setname = setname "
			+ "                        AND PRIOR rn = rn - 1 "
			+ "       GROUP  BY setname) ";   
		}

		          
		/**
		 * handle null value in bucketid
		 */
		try{			
			ResultSet rs=this.executeQuery(strSql);
			DTSSet dtsSet;
			String dtsCategory="";
			int index=0;
			String bucketID="";
			String previousDTSSetName="";
			while(rs.next()){				
				bucketID=rs.getString("bucketid")==null?"0":rs.getString("bucketid");
				dtsSet=new DTSSet();
				dtsSet.setSetName(rs.getString("setname"));
				List categoryList=new ArrayList();
				if(bucketID.equalsIgnoreCase("-1")){ // for new bucket
					for(int a=0;a<categoryNameList.size();a++){						
						dtsCategory=rs.getString(categoryNameList.get(a))==null?"0":rs.getString(categoryNameList.get(a));
						categoryList.add(dtsCategory);						
					}
					dtsSet.setCategoryList(categoryList);
					List dtsSetList=dtsBucket.getSetList();
					dtsSetList.add(dtsSet);
					dtsBucket.setSetList(dtsSetList);
					} else {		// for old bucket					
				
				if(index<1 || dtsBucket.getBucketID().equals("0")){
					dtsBucket.setBucketID(bucketID);	
				}
				
				
				for(int a=0;a<categoryNameList.size();a++){					
					dtsCategory=rs.getString(categoryNameList.get(a))==null?"0":rs.getString(categoryNameList.get(a));
					if(bucketID.equalsIgnoreCase("0") && dtsCategory.equalsIgnoreCase("1"))
					{
					categoryList.add("2");
					} else if(!bucketID.equalsIgnoreCase("0") && dtsCategory.equalsIgnoreCase("1")){
						categoryList.add("1");
					} else{
						categoryList.add("0");
					}
						
				}
				dtsSet.setCategoryList(categoryList);
				List dtsSetList=dtsBucket.getSetList();
				dtsSetList.add(dtsSet);
				dtsBucket.setSetList(dtsSetList);
				if(index>0){
					int setsPresent=dtsBucket.getSetList().size();
					//System.out.println("***total sets in bucket so far:"+dtsBucket.getSetList().size());
					DTSSet lastDtsSet=dtsBucket.getSetList().get(setsPresent<=1?setsPresent:(setsPresent-2));
					previousDTSSetName=lastDtsSet.getSetName();
					//System.out.println("***prevDTSName:"+previousDTSSetName+",,currDTSName:"+dtsSet.getSetName());
					if(previousDTSSetName.equalsIgnoreCase(dtsSet.getSetName())){
						List newCategoryList=new ArrayList();
						for(int i=0;i<dtsSet.getCategoryList().size();i++){
							//System.out.println("***adding categories:"+dtsSet.getCategoryList().get(i)+"...."+lastDtsSet.getCategoryList().get(i));
							int sum=Integer.parseInt(dtsSet.getCategoryList().get(i))+Integer.parseInt(lastDtsSet.getCategoryList().get(i));
							if(sum==0){
								newCategoryList.add("0");	
							}
							else if(sum==2){
								//show unchecked checkbox
								newCategoryList.add("2");
							}
							else if(sum==3){
								newCategoryList.add("1");
							}
							
						}
						lastDtsSet.setCategoryList(newCategoryList);
						dtsSet.setCategoryList(newCategoryList);
						//System.out.println("***removing the entry:"+dtsSet.getSetName());
						dtsBucket.getSetList().remove(dtsSet);
					}
				}
				index++;
			}
			}
		}
		catch(SQLException sqlex){
			sqlex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		dtsBucket.setCategoryNameList(categoryNameList);
		return dtsBucket;
	}	
	
	public boolean getBucketConfigView(String bucketId) {
		String categoryName="";		
		String strSql="";
		/* when old bucket is modified */
		if(!bucketId.equalsIgnoreCase("-1"))
		{
		strSql = ""
			+ "SELECT setname ";
		if (getListOfBucketCategories(bucketId)) {  
            while (this.moveNext()) {
            	categoryName = this.getData("Category");
		
            	strSql += ","
			+ "       CASE "
			+ "         WHEN Instr(segment_path, '"+categoryName+"') = 1 "
			+ "              AND Instr(segment_path, '"+categoryName+"') > 0 THEN 1 "
			+ "         WHEN Instr(segment_path, '"+categoryName+"') <> 1 "
			+ "              AND Instr(segment_path, '"+categoryName+"') > 0 THEN 1 "
			+ "         ELSE 0 "
			+ "       END AS "+categoryName+" ";
		}
		}
		strSql += "FROM  (SELECT setname, "
			+ "              MAX(Ltrim(Sys_connect_by_path(category, ','), ', ')) keep ( "
			+ "              dense_rank "
			+ "                    last ORDER "
			+ "              BY LEVEL) AS segment_path "
			+ "       FROM   (SELECT setname, "
			+ "                      category, "
			+ "                      Row_number() over ( PARTITION BY setname ORDER BY ROWNUM) "
			+ "                      rn "
			+ "               FROM   ZTBL_DTS_bucket_details "
			+ "               WHERE  bucketid = '"+bucketId+"' "			
			+ "               ORDER  BY setname, "
			+ "                         category) "
			+ "       START WITH rn = 1 "
			+ "       CONNECT BY PRIOR setname = setname "
			+ "                        AND PRIOR rn = rn - 1 "
			+ "       GROUP  BY setname) ";
		
			
		} 		           
		return getList(strSql, "DTS set list");   
	}	

	public int getMaxDTSSetNo(String clientID, String DTSNo) {
		strSQL = "SELECT MAX(SetNo) MaxSetNo FROM ztbl_DTS_DTS_Set WHERE DTSNo="
				+ DTSNo + " AND ClientID='" + clientID + "'";
		getList(strSQL, "");
		if (this.moveNext()) {
			return this.getInt("MaxSetNo");
		}
		return 0;
	}

	public int getMaxDTSSetNoInCategory(String clientID, String DTSNo,
			String category) {
		strSQL = "SELECT MAX(a.SetNo) MaxSetNo FROM ztbl_DTS_DTS_Set a"
				+ " INNER JOIN"
				+ " (SELECT c.ClientID, c.DTSNo, c.SetNo, c.Category "
				+ " FROM ztbl_DTS_Mapping_Source c UNION ALL"
				+ " SELECT d.ClientID, d.DTSNo, d.SetNo, d.Category FROM ztbl_DTS_Mapping_Rule d"
				+ " ) b"
				+ " ON a.ClientID=b.ClientID AND a.DTSNo=b.DTSNo AND a.SetNo=b.SetNo"
				+ " WHERE b.DTSNo=" + DTSNo + " AND b.ClientID='" + clientID
				+ "'" + " AND b.Category='" + category + "'";
		//System.out.println("getMaxDTSSetNoInCategory::"+strSQL);
		getList(strSQL, "");
		if (this.moveNext()) {
			return this.getInt("MaxSetNo");
		}
		return 0;
	}

	public int getMaxDTSNo(String clientID) {
		strSQL = "SELECT MAX(DTSNo) MaxDTSNo FROM ztbl_DTS_DTS_Mast WHERE ClientID='"
				+ clientID + "'";
		getList(strSQL, "");
		while (this.moveNext()) {
			return this.getInt("MaxDTSNo");
		}
		return 0;
	}

	public String updateDTSSetName(String clientID, String dtsNo,
			String category, String setNo, String setName) {
		String retValue = "";
		String sql = "";
		clientID = clientID.replaceAll("'", "''").trim();
		category = category.replaceAll("'", "''").trim();
		setName = setName.replaceAll("'", "''").trim();
		String oldSetName = "";
		ResultSet rsss = null;
		List lsSetNames = new ArrayList();
		boolean duplicateName=false;
		sql = "";
		sql = "SELECT setName oldSetName from  ZTBL_DTS_SETNAMES where "
				+ "  clientid='" + clientID + "' and dtsno=" + dtsNo
				+ " and category='" + category + "' and setno=" + setNo
				+ " and rownum<2";
		// System.out.println("11. edit set name query::"+sql);
		rsss = this.executeQuery(sql);
		try {
			while (rsss.next()) {
				oldSetName = rsss.getString("oldSetName").trim().replaceAll("'", "''");
			}
		} catch (Exception e) {
			oldSetName = "";
			System.out.println("Error while pulling the oldsetName" + sql
					+ " and oldsetName is " + oldSetName);
		}
		
		//Check names for duplicate setnames
		if (!oldSetName.equalsIgnoreCase(setName)){
			duplicateName=checkDuplicateSetNames(clientID, dtsNo, category, setName);	
		}
		
		if (duplicateName) {
			System.out.println( "Duplicate name found, set with name " + setName
					+ " already exists, \n Please enter another name");
			return "Duplicate name found";
		}		

		String tempTable = "SELECT '" + clientID.replaceAll("'", "''")
				+ "' CLIENTID, " + dtsNo + " DTSNO, " + setNo + " SETNO, '"
				+ category.replaceAll("'", "''") + "' CATEGORY, '"
				+ setName.replaceAll("'", "''") + "' SETNAME FROM DUAL";

		sql = "";
		sql = "MERGE INTO ZTBL_DTS_SETNAMES a USING ("
				+ tempTable
				+ ") b "
				+ " ON (a.CLIENTID = b.CLIENTID AND a.CATEGORY=b.CATEGORY AND a.DTSNO = b.DTSNO AND a.SETNO=b.SETNO) "
				+ " WHEN MATCHED THEN UPDATE SET  a.setName = b.setName"
				+ " WHEN NOT MATCHED THEN INSERT VALUES (b.ClientID, b.DTSNO, b.CATEGORY, b.SETNO, b.SETNAME)";
		// System.out.println("22 edit set name query::"+sql);
		this.execute(sql);

		// Add entry to rules table if not exists
		sql = "";
		sql = "MERGE INTO ztbl_DTS_Mapping_Rule a "
				+ " USING ( "
				+ " SELECT '"
				+ clientID
				+ "' CLIENTID, "
				+ dtsNo
				+ " DTSNO, "
				+ setNo
				+ " SETNO, '"
				+ category
				+ "' category,keyfield,version,businessrule,example,translatedRule  FROM ztbl_DTS_Mapping_Rule where  "
				+ " clientid='"
				+ clientID
				+ "' and dtsno="
				+ dtsNo
				+ " and category='"
				+ category
				+ "' and setno=1  and rownum<2 "
				+ " ) b "
				+ "  ON (a.CLIENTID = b.CLIENTID AND a.CATEGORY=b.CATEGORY AND a.DTSNO = b.DTSNO AND a.SETNO=b.SETNO)  "
				+ "  WHEN NOT MATCHED THEN  "
				+ "  INSERT VALUES (b.ClientID, b.DTSNO,b.SETNO,b.category,b.keyfield,b.version,b.businessrule ,'','') ";
		// System.out.println("33 edit set name query::"+sql);
		this.execute(sql);


		// Add entry to dts_set table if not exists
		sql = " MERGE INTO ztbl_DTS_DTS_Set a "
				+ " USING  "
				+ " (SELECT '"
				+ clientID
				+ "' CLIENTID, "
				+ dtsNo
				+ " DTSNO, "
				+ setNo
				+ " SETNO FROM DUAL) b "
				+ " ON (a.CLIENTID = b.CLIENTID AND a.DTSNO = b.DTSNO AND a.SETNO=b.SETNO) "
				+ " WHEN NOT MATCHED THEN  "
				+ " INSERT VALUES (b.ClientID, b.DTSNO,b.SETNO) ";
		// System.out.println("44 edit set name query::"+sql);
		this.execute(sql);
		sql = "";
		sql = " update ztbl_dts_sourcetable_config set setname='" + setName
				+ "' where " + " clientid= '" + clientID + "' and dtsNo= "
				+ dtsNo + " and category= '" + category + "' and setName='"
				+ oldSetName + "' ";
		if (!"".equals(oldSetName)) {
			this.execute(sql);
		}
		// update bucket detail table
		 sql ="";
		 sql = ""
			+ "UPDATE ztbl_dts_bucket_details d "
			+ "SET    d.setname='"+setName+"' "
			+ "WHERE  ( d.bucketid, d.category, d.setname ) IN (SELECT b.bucketid, "
			+ "                                                        b.category, "
			+ "                                                        b.setname "
			+ "                                                 FROM   (SELECT bucketid "
			+ "                                                         FROM   ztbl_dts_bucket "
			+ "                                                         WHERE  clientid = '" + clientID+ "' "
			+ "                                                                AND dtsno =  "+dtsNo+" "
			+ "                                                                AND isdeleted = "
			+ "                                                                    'N') a "
			+ "              inner join (SELECT bucketid,category,setname "
			+ "                          FROM   ztbl_dts_bucket_details "
			+ "                          WHERE  category = '"+category+"') b "
			+ "                ON a.bucketid = b.bucketid "
			+ "                   AND b.setname = '"+oldSetName+"') ";
		 
		 if(!"".equals(oldSetName) ){
				this.execute(sql);
			}		
		return retValue;
	}
	
	public String renameSrcTable(String clientID, String dtsNo,
			String category, String setNo, String oldSrcTable,String newSrcTable, String setName) {
		String retValue = "";
		boolean retBoolean = false;
		String sql = "";
		String sql1 = "";
		
		sql = "update  ZTBL_DTS_MAPPING_SOURCE  set tablename='"+newSrcTable+"' where "
			+" clientid='"+clientID+"' and dtsno='"+dtsNo+"' and setno='"+setNo+"' "
			+" and category='"+category+"' and lower(tablename) like lower('"+oldSrcTable+"')";   
		
		sql1 = "update  ztbl_dts_sourcetable_config  set tablename='"+newSrcTable+"' where "
		+" clientid='"+clientID+"' and dtsno='"+dtsNo+"' and setname='"+setName+"' "
		+" and category='"+category+"' and lower(tablename) like lower('"+oldSrcTable+"')";
		
		retBoolean=this.execute(sql);
		if(retBoolean)
		{		 
			this.execute(sql1);  
		}
		return retValue;   
	}

	public boolean getDTSSetName(String clientID, String dtsNo,
			String category, String setNo) {
		return getDTSSetName(clientID, dtsNo, category, setNo, 0);
	}
	public String getSetNoFromSetName(String clientID, String dtsNo,
			String category, String setName) {
		setName=setName.replaceAll("'","''");  
		String sql="select min(setno) as returnsetno from ztbl_dts_setnames where clientid='"+clientID+"' and dtsno='"+dtsNo+"'" +
				" and category='"+category+"' and setname='"+setName+"'";  
		//System.out.println("sql::"+sql);
		this.executeQuery(sql);      
		if (this.moveNext()) {
			return this.getData("returnsetno");  
		}
		return "";
	}

	public boolean getDTSSetName(String clientID, String dtsNo,
			String category, String setNo, int maxDTSSet) {
		String setNameTable = "SELECT SETNO, SETNAME FROM ZTBL_DTS_SETNAMES  WHERE ClientID='"
				+ clientID
				+ "' AND DTSNo="
				+ dtsNo
				+ " AND Category='"
				+ category.replaceAll("'", "''") + "'";
		strSQL = "";
		if (maxDTSSet > 0) {
			for (int i = 1; i <= maxDTSSet; i++) {
				strSQL += "SELECT " + i + " SN FROM DUAL";
				if (maxDTSSet > 1 && i < maxDTSSet) {
					strSQL += " UNION ";
				}
			}
			strSQL = "SELECT NVL(b.SETNO,a.SN) SETNO, NVL(b.SETNAME,TO_CHAR(SN)) SETNAME "
					+ " FROM ("
					+ strSQL
					+ ")a LEFT JOIN ("
					+ setNameTable
					+ ") b ON a.SN = b.SETNO WHERE 1=1 ";
		} else {
			strSQL = setNameTable;
		}

		if (!setNo.equals("")) {
			strSQL += " AND SETNO=" + setNo;
		}
		strSQL += " ORDER BY SETNO";
		

		//System.out.println("strSQL for datasetname:" + strSQL);
		return getList(strSQL, "");
	}

	public boolean getSetNameForSrcTabConfig(String clientID, String dtsNo, String srcCategory) {
		strSQL = "SELECT distinct SETNAME FROM ZTBL_DTS_SETNAMES  WHERE ClientID='"
			+ clientID
			+ "' AND DTSNo='"+dtsNo+"" 
			+ "' AND category='"+srcCategory+"'" 
			+		" order by upper(setname)";	 	  

		//System.out.println("strSQL for getSetNameForSrcTabConfig:" + strSQL);      
		return getList(strSQL, "");     
	}   

	public String synchronizeClientsStatus() {
		String retValue = "";
		String sql = "";
		sql = "MERGE INTO ztbl_DTS_Clients a USING HAWKEYEMASTER.M_CLIENTS b "
				+ "ON (a.CLIENTID = b.CLIENTID) "
				+ "WHEN MATCHED THEN UPDATE SET  a.ClientName = b.ClientName, a.ContractType=b.ContractType, a.InUse = b.USE_YN "
				+ "WHEN NOT MATCHED THEN INSERT VALUES (b.ClientID, b.ClientName, b.ContractType, b.USE_YN, 2)";
		this.execute(sql);
		return retValue;
	}

	/**
	 * Synchronize users from production to local
	 * 
	 * @return
	 */
	public String syncUsers() {
		/*
		 * Modified by Subash Devkota to use HEUserSynchronizer Date: 17 Aug
		 * 2007
		 */

		String retValue = "";

		try {
			new HEUserSynchronizer().syncUsersTable();
			retValue = "true";
		} catch (Exception e) {
			retValue = "false";
			System.out
					.println("Error in synchronizing users from production to local:"
							+ e.getMessage());
		}
		/*
		 * String sql = ""; //HEUSER.USR_USERS sql =
		 * "MERGE INTO ztbl_DTS_Users a USING " +
		 * " (SELECT LOGINNAME, USERNAME, PWD,EMAIL, OAMSTATUS FROM HEUSER.USR_USERS WHERE OAMSTATUS=1) b "
		 * + " ON (LOWER(a.USERID) = LOWER(b.LOGINNAME)) " +
		 * " WHEN MATCHED THEN UPDATE SET  a.USERNAME = b.USERNAME, " +
		 * " a.USERPASSWORD = b.PWD, a.EMAIL=b.EMAIL" +
		 * " WHEN NOT MATCHED THEN INSERT VALUES (LOWER(b.LOGINNAME), b.USERNAME, b.PWD, SYSDATE, NULL, b.EMAIL) "
		 * ; this.execute(sql); System.out.println(sql);
		 * 
		 * //-- sql below inserts default group for sql =
		 * "INSERT INTO ZTBL_DTS_USERSANDGROUPS (USERID, USERGROUP)" +
		 * " SELECT a.USERID, c.USERGROUP FROM ztbl_DTS_Users a, " +
		 * " (SELECT USERGROUP FROM ZTBL_DTS_USERGROUPS WHERE UPPER(GROUPDESC) LIKE '%VIEWER%') c"
		 * + " WHERE NOT EXISTS " +
		 * " (SELECT 1 FROM ZTBL_DTS_USERSANDGROUPS b WHERE a.USERID = b.USERID)"
		 * ; this.execute(sql); System.out.println(sql);
		 */

		return retValue;
	}

	// ********** Apr 24 ***********************************************
	public boolean getListOfCategory(String sn) {
		strSQL = "SELECT * FROM ztbl_DTS_Categories ";
		if (!sn.equals("")) {
			strSQL += " WHERE SN=" + sn;
		}
		strSQL += " ORDER BY Category";
		return getList(strSQL, "Category List");
	}

	/**
	 * Populate the list of templates avilable along with the client count
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @return
	 */
	public boolean getListOfTemplate(String templateId) {
		strSQL = " SELECT a.TEMPLATEID, a.TEMPLATENAME, a.TEMPLATEDESC,a.TEMPLATETYPE,  a.TEMPLATEVERSION, count(b.clientid) clientCnt "
				+ " FROM ztbl_DTS_Templates a left join ZTBL_DTS_CLIENT_TEMPLATES b"
				+ " on a.templateid=b.templateid ";
		if (!templateId.equals("")) {
			strSQL += " where a.templateId=" + templateId;
		}
		strSQL += " group by"
				+ "     a.TEMPLATEID, a.TEMPLATENAME, a.TEMPLATEDESC,a.TEMPLATETYPE,  a.TEMPLATEVERSION "
				+ " ORDER BY a.TemplateName";
		return getList(strSQL, "Template List");
	}

	public boolean manageCategory1(String sn, String category,
			String categoryDesc, String spMode) {
		strSQL = "sp_ManageCategory " + sn + ",'"
				+ replaceString(category, "'", "''") + "','"
				+ replaceString(categoryDesc, "'", "''") + "','" + spMode + "'";
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean manageCategory(String sn, String category,
			String categoryDesc, String oldCategoryName,String spMode) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_ManageCategory (?,?,?,?,?)}");
			stmt.setInt(1, Integer.parseInt(sn));
			stmt.setString(2, category);
			stmt.setString(3, categoryDesc);
			stmt.setString(4, oldCategoryName);
			stmt.setString(5, spMode);

			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_ManageCategory "
					+ e.toString());
			this.addMessage("ERROR calling sp_ManageCategory " + e.toString());
		}

		return retVal;
	}

	// ******************* Apr 25 *************************/

	/**
	 * Performs the database operation for template according to the passed
	 * mode: D, U or I
	 * 
	 * @author Subash Devkota
	 * @param id
	 * @param name
	 * @param desc
	 * @param version
	 * @param mode
	 * @return
	 */
	public boolean manageTemplate(String id, String name, String desc,
			String version,String type, String mode) {
		int tempalteId = Integer.parseInt(id);

		if ("D".equalsIgnoreCase(mode)) { // delete the template
			strSQL = " Delete from ZTBL_DTS_TEMPLATES where templateID="
					+ tempalteId;
		}
		if ("U".equalsIgnoreCase(mode)) { // update the template
			strSQL = " update ZTBL_DTS_TEMPLATES set templateName='" + name
					+ "', templateDesc='" + desc + "', templateVersion='"
					+ version + "',templateType='"+type+"' where templateID=" + tempalteId;
		}
		if ("I".equalsIgnoreCase(mode)) { // Insert the template
			strSQL = " insert into ZTBL_DTS_TEMPLATES (TemplateName, TemplateDesc, TemplateVersion,TemplateType) values('"
					+ name + "','" + desc + "','" + version + "','" + type + "')";
		}

		return this.execute(strSQL);
	}

	/**
	 * Get list of clients using the specified template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @return
	 */
	public boolean getTemplateClients(String templateId) {
		int id = Integer.parseInt(templateId);
		strSQL = " select a.clientId, b.clientName from ztbl_dts_client_templates a, ztbl_dts_clients b where a.clientId=b.clientId and a.templateId="
				+ id + " order by b.clientName ";
		return this.getList(strSQL, " Template clients");
	}

	/**
	 * Get list of client and template assigned to the clients
	 * 
	 * @author Subash Devkota
	 * @return
	 */
	public boolean getTemplatesByClients() {
		strSQL = " select a.clientId, b.clientName, c.templateName, c.templateVersion "
				+ " from "
				+ "	ztbl_dts_client_templates a, "
				+ "	ztbl_dts_clients b, "
				+ "	ztbl_dts_templates c "
				+ " where "
				+ "	a.clientId=b.clientId "
				+ "	and a.templateid=c.templateid" + " order by a.clientId ";
		return this.getList(strSQL, " Template by clients");
	}

	/**
	 * Get list of clients not using the specified template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @return
	 */
	public boolean getNonTemplateClients(String templateId) {
		int id = Integer.parseInt(templateId);
		strSQL = " select distinct c.clientID , c.clientName, e.templateName from ztbl_dts_clients c "
				+ "	left join ztbl_dts_client_Templates d on c.clientid=d.clientid"
				+ "	left join ztbl_dts_Templates e  on d.templateid=e.templateid "
				+ " where "
				+ "	 not exists ("
				+ " 		select a.clientId  from ztbl_dts_client_templates a, ztbl_dts_clients b "
				+ " 		where a.clientId=b.clientId and a.templateId="
				+ id
				+ " 		and a.clientId=c.clientID"
				+ "	)"
				+ " order by clientName ";
		return this.getList(strSQL, " Template clients");
	}

	/**
	 * Get the list of categories and keyFields assingned to the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @return
	 */
	public boolean getTemplateDefinition(String templateId) {
		int id = Integer.parseInt(templateId);
		strSQL = " select distinct category, keyfield from ztbl_dts_template_defs where templateid= "
				+ id + " order by category, keyfield ";
		return this.getList(strSQL, "Template definitions");
	}

	/**
	 * Get the list of categories that are not included in the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @return
	 */
	public boolean getNonTemplateCategories(String templateId) {
		int id = Integer.parseInt(templateId);
		strSQL = " select distinct category from ztbl_dts_categories a "
				+ " where not exists "
				+ "(   select distinct category from ztbl_dts_template_defs b where a.category=b.category "
				+ "    and templateid= " + id + ")";
		return this.getList(strSQL, "Non Template categories");
	}

	/**
	 * Add category to template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param category
	 * @return
	 */
	public boolean addCategoryToTemplate(String templateId, String category) {
		int id = Integer.parseInt(templateId);
		strSQL = " insert into  ztbl_dts_template_defs(TEMPLATEID, CATEGORY) values ("
				+ id + ",'" + category + "' )";
		return this.execute(strSQL);
	}

	/**
	 * Remove the category from the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param category
	 * @return
	 */
	public boolean removeCategoryFromTemplate(String templateId, String category) {
		int id = Integer.parseInt(templateId);
		strSQL = " delete from  ztbl_dts_template_defs where templateID=" + id
				+ " and category='" + category + "' ";
		return this.execute(strSQL);
	}

	/**
	 * Add key field to the category of the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param category
	 * @param field
	 * @return
	 */
	public boolean addFieldToTemplateCategory(String templateId,
			String category, String field) {
		int id = Integer.parseInt(templateId);
		int primaryTempId = this.getPrimaryTemplateID();
		if(id == primaryTempId)
		{
			strSQL = " delete from ztbl_dts_template_defs where templateid != "+id+" " +
					"and category='"+category+"' and keyfield='"+field+"'";	
			
		this.execute(strSQL); 
		
			strSQL = " delete from ZTBL_DTS_CLIENT_KEYFIELDS where " +
		"category='"+category+"' and keyfield='"+field+"'";	
			
		this.execute(strSQL);
		}
		if(id != primaryTempId)
		{
			strSQL = " delete from ZTBL_DTS_CLIENT_KEYFIELDS where " +
			"category='"+category+"' and keyfield='"+field+"' and clientid in (select clientid " +
					"from ZTBL_DTS_CLIENT_TEMPLATES where templateid="+id+")";				
			this.execute(strSQL);
		}
		strSQL = " insert into  ztbl_dts_template_defs(TEMPLATEID, CATEGORY, KEYFIELD) values ("
				+ id + ",'" + category + "','" + field + "' )";
		return this.execute(strSQL); 
	}

	/**
	 * Remove the field from the catgory of the template
	 * 
	 * @param templateId
	 * @param category
	 * @param field
	 * @return
	 */
	public boolean removeFieldFromTemplateCategory(String templateId,
			String category, String field) {
		int id = Integer.parseInt(templateId);
		strSQL = " delete from   ztbl_dts_template_defs where templateid=" + id
				+ " and category='" + category + "' and keyfield='" + field
				+ "'";
		return this.execute(strSQL);
	}

	/**
	 * Assign the template to the client. A client can be assigned only one
	 * template. So, the old will be removed
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param clientID
	 * @return
	 */
	public boolean assignTemplateToClient(String templateId, String clientID) {
		int id = Integer.parseInt(templateId);
		strSQL = " merge into ZTBL_DTS_CLIENT_TEMPLATES a"
				+ " using ( select '"
				+ clientID
				+ "' clientId, "
				+ id
				+ " templateid from dual) b"
				+ " on (a.CLIENTID=b.clientID )"
				+ " when matched then update set templateid="
				+ id
				+ " when not matched then insert (clientId, templateId) values ('"
				+ clientID + "'," + id + ")";
		return this.execute(strSQL);
	}

	/**
	 * Gets the list of categories assinged to the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @return
	 */
	public boolean getTemplateCategories(String templateId) {
		int id = Integer.parseInt(templateId);
		strSQL = " select distinct category from ztbl_dts_template_defs where templateid= "
				+ id + " and category is not null order by category  ";
		return this.getList(strSQL, "Template categories");
	}

	/**
	 * Get the list of keyfields assigned to the category of the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param category
	 * @param start
	 *            row number
	 * @param end
	 *            row number
	 * @return
	 */
	public boolean getTemplateCategoryFields(String templateId,
			String category, int start, int end) {
		int id = Integer.parseInt(templateId);
		strSQL = " select keyfield from ( select keyfield, rownum rn from ("
				+ "	select distinct keyfield from ztbl_dts_template_defs where templateid= "
				+ id + " and category='" + category
				+ "' and keyfield is not null order by keyfield) )"
				+ " where rn between " + start + " and " + end
				+ " order by rn ";		
		return this.getList(strSQL, "Template category fields");
	}

	/**
	 * Get count of key fields available in the category of the template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param category
	 * @return
	 */
	public int getTemplateCategoryFieldCount(String templateId, String category) {
		int id = Integer.parseInt(templateId);
		strSQL = " select count(distinct keyfield) cnt from ztbl_dts_template_defs where templateid= "
				+ id + " and category='" + category + "' ";
		this.getList(strSQL, "Template category count");
		int count = 0;
		try {
			if (myRS.next()) {
				count = myRS.getInt("cnt");
			}
			myRS.close();
		} catch (Exception e) {
			this
					.addMessage("<font color='red'>[sqlBean] ERROR: Template category count</font>");
		}
		return count;
	}

	/**
	 * Get the list of fields that are not assinged to the category of the
	 * template
	 * 
	 * @author Subash Devkota
	 * @param templateId
	 * @param category
	 * @return
	 */
	public boolean getNonTemplateCategoryFields(String templateId,
			String category) {
		int id = Integer.parseInt(templateId);
		int primaryTempId = this.getPrimaryTemplateID();
		strSQL = " select distinct keyfield from ztbl_dts_mapping_mast a where category='"
				+ category
				+ "' "
				+ " and not exists ("
				+ " select distinct keyfield from ztbl_dts_template_defs b "
				+ " where a.category=b.category and a.keyfield=b.keyfield and b.category='"
				+ category
				+ "' AND B.TEMPLATEID in ("+id+","+primaryTempId+")) order by keyfield"; 
		//System.out.println("getNonTemplateCategoryFields::SQL::"+strSQL);

		return this.getList(strSQL, "Template category fields");
	}

	/**
	 * Get the list of fields and datatype for the keyfields available in the
	 * category of the template
	 * 
	 * @param templateId
	 * @param category
	 * @return
	 */
	public boolean getTemplateSchemaInfo(String templateId, String category) {
		int primaryTemplateId = this.getPrimaryTemplateID();
		strSQL = "	select   DISTINCT A.SN ,A.KEYFIELD, A.FIELDFORMAT"
				+ "	from " + "    ZTBL_DTS_mapping_MAST a,"
				+ "    ZTBL_DTS_TEMPLATE_DEFS B," + "    ZTBL_DTS_TEMPLATES C"
				+ " where " + "    A.CATEGORY=B.CATEGORY"
				+ "    AND a.category='" + category + "'"
				+ "    AND B.TEMPLATEID=C.TEMPLATEID"
				+ "    AND C.TEMPLATEID in ('"+primaryTemplateId+"','" + templateId + "')"
				+ "	 AND a.version=2 " + " ORDER BY " + "    A.SN ASC";		
		return this.getList(strSQL, "Template Category fields and datatype"); 
	}

	/**
	 * Get list of category and tableName of the template.
	 * 
	 * @author sdevkota
	 * @param templateId
	 * @return
	 */
	public boolean getTemplateCategoryAndTable(String templateId) {
		int primaryTemplateId = this.getPrimaryTemplateID();
		strSQL = " SELECT DISTINCT A.CATEGORY, A.TABLENAME " + " FROM "
				+ "    ZTBL_DTS_MAPPING_TARGET A,"
				+ "    ZTBL_DTS_TEMPLATE_DEFS B," + "    ZTBL_DTS_TEMPLATES C"
				+ " WHERE" + "    A.CATEGORY=B.CATEGORY"
				+ "    AND B.TEMPLATEID=C.TEMPLATEID"
				+ "    AND C.TEMPLATEID in ('"+primaryTemplateId+"','" + templateId + "')"
				+ "    AND TABLENAME NOT LIKE 'ZTBL_SCRUB_%' ";
		/***This part will be enabled if client specific category is to be included with some modification*****
				+ "UNION "
				+ "SELECT DISTINCT a.category,a.tablename FROM   ztbl_dts_mapping_target a inner join" 
				+ " (select category from ZTBL_DTS_CLIENT_KEYFIELDS  where clientid='"+clientid+"') b  ON" 
				+ " a.category=b.category";
		***/
		return this.getList(strSQL, "Template Categories and tables ");
	}

	public boolean getKeyfieldList(String category, String version) {
		return this.getKeyfieldList(category, version, "");
	}

	public boolean getKeyfieldList(String category, String version,
			String orderBy) {
		strSQL = "SELECT a.SN,a.Category,a.KeyField,a.FieldFormat, b.TableName,b.FieldName "
				+ " FROM ztbl_DTS_Mapping_Mast a "
				+ " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
				+ " AND a.KeyField=b.KeyField AND a.Version=b.Version WHERE a.Category='"
				+ replaceString(category, "'", "''")
				+ "' and a.version='"
				+ version + "'";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast a "
				+ " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
				+ " AND a.KeyField=b.KeyField AND a.Version=b.Version WHERE a.Category='"
				+ replaceString(category, "'", "''") + "' and a.version='"
				+ version + "'";

		// strSQL = "SELECT * FROM ztbl_DTS_Mapping_Mast WHERE Category='" +
		// replaceString(category,"'","''") + "'";
		if (!orderBy.equals("")) {
			strSQL += " ORDER BY " + orderBy;
		}
		return getList(strSQL, "List of keyfields");
	}

	public boolean getKeyfieldList(String category, String version,
			String orderBy, String clientId) {
		strSQL = "SELECT a.SN,a.Category,a.KeyField,a.FieldFormat,b.TableName,b.FieldName "
				+ " FROM ztbl_DTS_Mapping_Mast a "
				+ " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
				+ " AND a.KeyField=b.KeyField "
				+ " INNER JOIN ztbl_DTS_Clients c on b.version=c.version and c.clientid='"
				+ clientId
				+ "' "
				+ " WHERE a.Category='"
				+ replaceString(category, "'", "''")
				+ "' and a.version='"
				+ version + "'";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast a "
				+ " LEFT JOIN ztbl_DTS_Mapping_Target b ON a.Category=b.Category "
				+ " AND a.KeyField=b.KeyField "
				+ " INNER JOIN ztbl_DTS_Clients c on b.version=c.version and c.clientid='"
				+ clientId + "' " + " WHERE a.Category='"
				+ replaceString(category, "'", "''") + "' and a.version='"
				+ version + "'";

		// strSQL = "SELECT * FROM ztbl_DTS_Mapping_Mast WHERE Category='" +
		// replaceString(category,"'","''") + "'";
		if (!orderBy.equals("")) {
			strSQL += " ORDER BY " + orderBy;
		}
		return getList(strSQL, "List of keyfields");
	}

	public boolean getDistinctKeyfieldList(String category, String version,
			String orderBy) {
		strSQL = "SELECT *  FROM ztbl_DTS_Mapping_Mast WHERE Category='"
				+ replaceString(category, "'", "''") + "' and version='"
				+ version + "'";

		if (!orderBy.equals("")) {
			strSQL += " ORDER BY " + orderBy;
		}
		return getList(strSQL, "List of keyfields");
	}

	public void getListOfTargetFields(String tableName) {
		strSQL = "SELECT DISTINCT TableName, FieldName, FieldFormat, Version"
				+ " FROM ztbl_DTS_TargetTableSpace" + " WHERE 1=1"; // so we
																	// don't
																	// need
																	// WHERE for
																	// each
																	// condition

		if (!tableName.equals("")) {
			strSQL += " AND TableName IN ('" + tableName + "')";
		}

		strSQL += " ORDER BY TableName, FieldName";
		getList(strSQL, "Target fields");
	}

	public String addUpdateTargetFields(String category, String keyField,
			String version, String tableName, String fieldName) {
		String retValue = "";
		String sql = "";
		sql = "DELETE ztbl_DTS_Mapping_Target WHERE Category='" + category
				+ "' AND KeyField='" + keyField + "' AND Version='" + version
				+ "'";
		this.execute(sql);

		if (!tableName.equals("[]")) { // source fields are selected
			StringTokenizer st = new StringTokenizer(tableName, ",");
			StringTokenizer sf = new StringTokenizer(fieldName, ",");
			while (st.hasMoreTokens()) {
				sql = "INSERT INTO ztbl_DTS_Mapping_Target (Category,"
						+ "KeyField, TableName, FieldName, Version) VALUES ('"
						+ category
						+ "','"
						+ keyField
						+ "','"
						+ st.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim()
						+ "','"
						+ sf.nextToken().toString().replace('[', ' ').replace(
								']', ' ').trim() + "','" + version.trim()
						+ "')";
				retValue += "<BR>" + sql;
				this.execute(sql);
			}
		}
		return retValue;
	}

	// Old manageKeyfield method used for SQL
	public boolean manageKeyfield1(String sn, String category, String keyfield,
			String version, String fieldFormat, String spMode) {
		strSQL = "sp_ManageKeyfield " + sn + ",'"
				+ replaceString(category, "'", "''") + "','"
				+ replaceString(keyfield, "'", "''") + "','"
				+ replaceString(version, "'", "''") + "','"
				+ replaceString(fieldFormat, "'", "''") + "','" + spMode + "'";
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean manageKeyfield(String sn, String category, String keyfield,
			String version, String fieldFormat, String spMode) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			
			//System.out.println("deleted:"+spMode);
			CallableStatement stmt = myConn
					.prepareCall("{call sp_ManageKeyfield (?,?,?,?,?,?,?,?)}");
			stmt.setInt(1, Integer.parseInt(sn));
			stmt.setString(2, category);
			stmt.setString(3, keyfield);
			stmt.setString(4, version);
			stmt.setString(5, fieldFormat);
			stmt.setString(6, null);
			stmt.setString(7, null);
			stmt.setString(8, spMode);
			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_ManageKeyfield "
					+ e.toString());
			this.addMessage("ERROR calling sp_ManageKeyfield " + e.toString());
		}

		return retVal;
	}

	public boolean manageKeyfield(String sn, String category, String keyfield,
			String version, String fieldFormat, String targetTable,
			String targetField, String spMode) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_ManageKeyfield (?,?,?,?,?,?,?,?)}");
			stmt.setInt(1, Integer.parseInt(sn));
			stmt.setString(2, category);
			stmt.setString(3, keyfield);
			stmt.setString(4, version);
			stmt.setString(5, fieldFormat);
			stmt.setString(6, targetTable);
			stmt.setString(7, targetField);
			stmt.setString(8, spMode);
			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_ManageKeyfield "
					+ e.toString());
			this.addMessage("ERROR calling sp_ManageKeyfield " + e.toString());
		}

		return retVal;
	}

	public boolean deleteTargetTableSpace(String version) {
		strSQL = "DELETE ztbl_DTS_TargetTableSpace where version='" + version
				+ "'";
		return this.execute(strSQL);
	}

	public boolean insertTargetTableSpace(String TableName, String FieldName,
			String FieldFormat, String version) {
		strSQL = "INSERT INTO ztbl_DTS_TargetTableSpace "
				+ " (TableName, FieldName, FieldFormat, Version) "
				+ " VALUES('" + TableName + "','" + FieldName + "','"
				+ FieldFormat + "', '" + version + "')";
		return this.execute(strSQL);
	}

	public boolean insertTargetTableSpace(String TableName, String FieldName,
			String FieldFormat) {
		return this.insertTargetTableSpace(TableName, FieldName, FieldFormat,
				this.latestVersion);
	}

	// September 08, 2003
	public boolean saveKeyfieldsOrder(String category, String sortedKeyFields) {
		StringTokenizer keyfield = new StringTokenizer(sortedKeyFields, ",");
		boolean retValue = false;
		int counter = 0;
		String kf = "";
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			PreparedStatement pstmt = myConn
					.prepareStatement("UPDATE ztbl_DTS_Mapping_Mast SET SN = ? WHERE KeyField=? AND Category=?");
			while (keyfield.hasMoreTokens()) {
				counter++;
				kf = keyfield.nextElement().toString().trim();
				pstmt.setInt(1, counter);
				pstmt.setString(2, kf);
				pstmt.setString(3, category);
				pstmt.executeUpdate();

			}
			retValue = true;

		} catch (Exception e) {
			System.out
					.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->2<-"
							+ e);
			errorStr = e.toString();
		}
		return retValue;
	}

	public int getSourceCount(int ClientID, int DTSNo, int SetNo) {
		return getCount("ztbl_DTS_Mapping_Source", ClientID, DTSNo, SetNo);
	}

	public int getRuleCount(int ClientID, int DTSNo, int SetNo) {
		return getCount("ztbl_DTS_Mapping_Rule", ClientID, DTSNo, SetNo);
	}

	public int getCount(String TableName, int ClientID, int DTSNo, int SetNo) {
		strCountSQL = "";
		strCountSQL += " select count(*) RecCount ";
		strCountSQL += " from " + TableName + " tbl1";
		strCountSQL += " where tbl1.SetNo = " + SetNo + " and tbl1.ClientId= "
				+ ClientID + " and tbl1.DTSNo = " + DTSNo;
		return getRecordCount();
	}

	public boolean deleteSet(int ClientID, int DTSNo, int SetNo) {
		strSQL = " Delete From ztbl_DTS_DTS_Set where ClientID = " + ClientID
				+ " and DTSNo = " + DTSNo + " and ";
		strSQL += " SetNo = " + SetNo;
		//System.out.println("I am here");
		this.execute(strSQL);

		strSQL = " Delete From ZTBL_DTS_SETNAMES where ClientID = " + ClientID
				+ " and DTSNo = " + DTSNo + " and ";
		strSQL += " SetNo = " + SetNo;
		return this.execute(strSQL);
	}

	public boolean getAllSource(String clientId, String dtsNo) {
		this.dbNames = new Vector();
		this.tbls = new HashMap();
		this.flds = new HashMap();
		this.ffor = new HashMap();
		HashMap dbIdMap = new HashMap();
		String databaseName = "", tableName = "", fieldName = "", fieldFormat = "";
		String sql = "";
		sql += " SELECT DISTINCT d.DatabaseId, DatabaseName, TableName , FieldName, FieldFormat "
				+ " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d "
				+ " where s.databaseid = d.databaseid and ((d.ClientID='"
				+ clientId
				+ "' AND DTSNo="
				+ dtsNo
				+ ") or (d.ClientID='999' "
				+ " and (TableName like '%"
				+ clientId
				+ "%' or UPPER(TableName) like UPPER('HR_GLOBAL%') ))) "
				+ " order by tableName ";
		/*
		 * "SELECT DISTINCT d.DatabaseId, DatabaseName, TableName, FieldName, FieldFormat"
		 * + " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d" +
		 * " where s.databaseid = d.databaseid and " + " d.ClientID='" +
		 * clientId + "' AND DTSNo=" + dtsNo + " union " +
		 * " SELECT DISTINCT d.DatabaseId, DatabaseName, TableName, FieldName, FieldFormat "
		 * + " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d " +
		 * " where s.databaseid = d.databaseid and " + " d.ClientID='999' and "
		 * + " (TableName like '%" + clientId +
		 * "%' or TableName like '%global%' )";
		 */
		ResultSet rs = this.executeQuery(sql);
		try {
			while (rs.next()) {
				databaseName = rs.getString("DatabaseName");
				tableName = rs.getString("TableName");
				fieldName = rs.getString("FieldName");
				fieldFormat = rs.getString("FieldFormat");
				// this.addMessage("[getting data - ]"+databaseName+"; "+tableName+"; "+fieldName+"; "+
				// fieldFormat);
				Vector t = null, f1 = null;
				HashMap f = null, ff = null, ff1 = null;
				if (!dbNames.contains(databaseName)) {
					dbIdMap.put(databaseName, rs.getString("DatabaseId"));
					// this.addMessage("[new database]" + databaseName);
					// new database
					dbNames.add(databaseName);
					t = new Vector(); // / new table list
					tbls.put(databaseName, t);
					f = new HashMap(); // new fields
					flds.put(databaseName, f);
					ff = new HashMap(); // new field formats
					ffor.put(databaseName, ff);
				} else {
					// this.addMessage("[old database]" + databaseName);
					t = (Vector) tbls.get(databaseName);
					f = (HashMap) flds.get(databaseName);
					ff = (HashMap) ffor.get(databaseName);
				}

				if (!t.contains(tableName)) {
					// working on new table
					// this.addMessage("[new table]" + tableName);
					t.add(tableName);
					// new table needs new fields
					f1 = new Vector();
					f.put(tableName, f1);
					// and new field formats
					ff1 = new HashMap();
					ff.put(tableName, ff1);
				} else {
					// this.addMessage("[old table]" + tableName);
					// field maped by tablename is already present in f
					f1 = (Vector) f.get(tableName);
					ff1 = (HashMap) ff.get(tableName);
				}

				if (!f1.contains(fieldName)) {
					// this.addMessage("[new field]" + fieldName);
					f1.add(fieldName);
					ff1.put(fieldName, fieldFormat);
				}
			}
			this.dbMap = this.createDBMap(dbIdMap);
			this.listDatabaseNames = this.createDatabaseString(dbNames);
			this.listTableNames = this.createTableString(dbNames, tbls);
			this.listFieldNames_1 = this.createFieldString(dbNames, tbls, flds);
			this.listFieldFormats_1 = this.createFFormatString(dbNames, tbls,
					ffor);
		} catch (Exception e) {
			System.out
					.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->3<-"
							+ e);
			this.addMessage("Error " + e);
			System.out.print("Error " + e);
		}
		return true;
	}

	public boolean getAllSourceOptimized(String clientId, String dtsNo,String srcCategory,String srcSetNo) {
		
		//String isCustomized=isConf;		
		// Don't risk breaking something else, so create these empty objects
		this.dbNames = new Vector();
		this.tbls = new HashMap();
		this.flds = new HashMap();
		this.ffor = new HashMap();

		String databaseName = "", tableName = "", fieldName = "", fieldFormat = "";
		String sql = "";
		String sql1 = "";
		String selectedCategory = "";
		String selectedSetName = "";
		// The ORDER BY is critical here. To optimize this function, the result
		// set
		// is parsed and the strings are built *concurrently*. Since we need to
		// have
		// 'new Array()' in strategic locations, we rely on the fact that the
		// result set
		// is ordered by DatabaseName first, and TableName second.
		// We do this because it is MUCH FASTER to let SQL do the sorting,
		// rather than
		// throwing everything in various collections and parsing them later.
		
		//getting first category that will be displayed in front
		if(srcCategory == null || srcCategory.equalsIgnoreCase(""))
		{
		if(this.getListOfCategories(clientId,""))
		{
			if(this.moveNext()) 
			selectedCategory=this.getData("category");	
		
		}
		} else
		{
			selectedCategory=srcCategory;
		}
		//System.out.println("selectedCategory:::"+selectedCategory);   
		
		//get max set no
		int maxSetNo = this.getMaxDTSSetNoInCategory(clientId, dtsNo, selectedCategory);
		
		//getting first set name that will be displayed in front
		if(srcSetNo == null || srcSetNo.equalsIgnoreCase(""))
		{
		if (this.getDTSSetName(clientId, dtsNo, selectedCategory, "", maxSetNo)) {
			if(this.moveNext()) 
				selectedSetName=this.getData("SetName");  
		}
		} else {
			
			if(this.getDTSSetName(clientId, dtsNo, selectedCategory, srcSetNo))
					if(this.moveNext())
						selectedSetName=this.getData("SetName"); 
		}
		//System.out.println("selectedSetName:::"+selectedSetName);   

		sql1 += " SELECT DISTINCT d.DatabaseId, DatabaseName, TableName , FieldName, FieldFormat,d.clientid "
				+ " FROM ztbl_DTS_SourceTableSpace s, ztbl_DTS_Databases d "
				+ " WHERE s.databaseid = d.databaseid AND ((d.ClientID='"
				+ clientId
				+ "' AND DTSNo="
				+ dtsNo
				+ ") OR (d.ClientID='999' "
				+ " AND (TableName LIKE '%"
				+ clientId
				+ "%' OR Upper(TableName) LIKE Upper('HR_GLOBAL%') ))) ";
		
			sql = "select a.* from ("+sql1+") a, " +
					" (select tablename from ztbl_dts_sourcetable_config " +
					" where clientid = '"+clientId+"' " +
					" AND dtsno = "+dtsNo+" " +
					" AND category = '"+selectedCategory+"' " +
					" AND setname = '"+selectedSetName+"'   " +									
					") b  "
			+ "WHERE a.tablename = b.tablename ORDER BY a.DatabaseName, a.TableName  " ;
		
		//System.out.println("method-->getAllSourceOptimized-->SQL->"+sql);       
		ResultSet rs = this.executeQuery(sql);

		String dbIdMapStr = "var dbIdMap = new Array(); \n";
		String dbNamesStr = "var dbList = new Array(); \n" + "dbList = [";
		String tableListStr = "var tableList = new Array();\n";
		// These two string get VERY long, so don't use an immutable object for
		// them.
		// Using StringBuffer instead of String speeds up load time by over
		// 1000%!
		StringBuffer fieldListStr = new StringBuffer(
				"var fieldList = new Array();\n");
		StringBuffer formatListStr = new StringBuffer(
				"var fieldFormatList = new Array();\n");

		int dbNamesCount = 0;
		int tableListCount = 0;
		int fieldListCount = 0;

		String oldDatabaseName = "";
		String oldTableName = "";

		boolean isNewDb = false;
		boolean isNewTable = false;

		try {
			while (rs.next()) {				
				databaseName = rs.getString("DatabaseName");
				tableName = rs.getString("TableName");
				fieldName = rs.getString("FieldName");
				fieldFormat = rs.getString("FieldFormat");

				isNewDb = !databaseName.equals(oldDatabaseName);
				isNewTable = !tableName.equals(oldTableName);
                
				//Two databases can have same table names too, thus when two database changes here 
   			    // table should be rendered new  
				// For each new database
				if (isNewDb) {
					isNewTable=true;
					dbIdMapStr += "dbIdMap['" + databaseName + "']='"
							+ rs.getString("DatabaseId") + "'; \n";

					if (dbNamesCount > 0) {
						dbNamesStr += ", ";
					}
					dbNamesStr += "'" + databaseName + "'";
					dbNamesCount++;

					if (dbNamesCount > 1) {
						tableListStr += "];\n";
						fieldListStr.append("];\n");
						formatListStr.append("\n");
					}
					tableListStr += "tableList['" + databaseName
							+ "'] = new Array();\n";
					tableListStr += "tableList['" + databaseName + "'] = [";
					tableListCount = 0;

					fieldListStr.append("fieldList['" + databaseName
							+ "'] = new Array();\n");
					formatListStr.append("fieldFormatList['" + databaseName
							+ "'] = new Array();\n");
				}

				// For each new table
				if (isNewTable) {
					if (tableListCount > 0) {
						tableListStr += ", ";
					}
					tableListStr += "'" + tableName + "'";
					tableListCount++;

					if (tableListCount > 1) {
						fieldListStr.append("];\n");
						formatListStr.append("\n");
					}
					fieldListStr.append("fieldList['" + databaseName + "']['"
							+ tableName + "'] = new Array();\n");
					fieldListStr.append("fieldList['" + databaseName + "']['"
							+ tableName + "'] = [");
					fieldListCount = 0;
					formatListStr.append("fieldFormatList['" + databaseName
							+ "']['" + tableName + "'] = new Array();\n");
				}

				// For each field
				if (fieldListCount > 0) {
					fieldListStr.append(", ");
				}
				fieldListStr.append("'" + fieldName + "'");
				fieldListCount++;

				formatListStr.append("fieldFormatList['" + databaseName
						+ "']['" + tableName + "']['" + fieldName + "'] = '"
						+ fieldFormat + "'; ");

				oldDatabaseName = databaseName;
				oldTableName = tableName;

			}

			dbNamesStr += "];\n";	   
			if(tableListCount > 0)
			{
			tableListStr += "];\n";
			}

			if(fieldListCount > 0)
			{
			fieldListStr.append("];\n");       
			}


			this.dbMap = dbIdMapStr;
			this.listDatabaseNames = dbNamesStr;			
			this.listTableNames = tableListStr;
			this.listFieldNames_1 = fieldListStr.toString();
			this.listFieldFormats_1 = formatListStr.toString();
		} catch (Exception e) {
			System.out
					.println("\nError:[JavaSource/d2Hawkeye/dts/dtsBean.java]->4<-"
							+ e);
			this.addMessage("Error " + e);
			System.out.print("Error " + e);
		}
		return true;
	}

	private String createDBMap(HashMap dbMap) {
		String str2ret = "";
		str2ret += "var dbIdMap = new Array(); \n";
		String[] keys = new String[dbMap.size()];
		dbMap.keySet().toArray(keys);
		for (int i = 0; i < keys.length; i++) {
			str2ret += "dbIdMap['" + keys[i] + "']='" + dbMap.get(keys[i])
					+ "'; \n";
		}
		return str2ret;
	}

	private String createDatabaseString(Vector db) {
		String str = "";
		this.addMessage("[creating dblist]");
		str += "var dbList = new Array(); \n";
		str += "dbList = [";
		for (int i = 0; i < db.size(); i++) {
			str += "'" + db.get(i) + "'";
			if (i < db.size() - 1) {
				str += ", ";
			}
		}
		str += "];";
		this.addMessage("[created dblist]");
		return str;
	}

	private String createTableString(Vector db, HashMap tbl) {
		this.addMessage("[creating tableList]");
		String str = "";
		str += "var tableList = new Array();\n";
		for (int i = 0; i < db.size(); i++) {
			String dbName = db.get(i).toString();
			Vector v = (Vector) tbl.get(dbName);
			str += " tableList['" + dbName + "'] = new Array(); \n";
			String subStr = "[";
			for (int j = 0; j < v.size(); j++) {
				subStr += "'" + v.get(j) + "'";
				if (j < v.size() - 1) {
					subStr += ", ";
				}
			}
			subStr += "];";
			str += "tableList['" + dbName + "']=" + subStr + "\n";
		}
		this.addMessage("[created tableList]");
		return str;
	}

	private String createFieldString(Vector db, HashMap tbl, HashMap fld) {
		this.addMessage("[creating fieldList]");
		String str = "";
		str += "var fieldList = new Array();\n";
		for (int i = 0; i < db.size(); i++) { // looping in database
			String dbName = db.get(i) + "";
			this.addMessage("database" + dbName);
			Vector v = (Vector) tbl.get(dbName); // geting tables
			str += " fieldList['" + dbName + "'] = new Array(); \n";
			for (int j = 0; j < v.size(); j++) {
				String tblName = v.get(j) + "";
				this.addMessage("table" + tblName);
				Vector vv = (Vector) ((HashMap) fld.get(dbName)).get(tblName); // geting
																				// fields
				str += " fieldList['" + dbName + "']['" + tblName
						+ "'] = new Array(); \n";
				String subStr = "[";
				for (int k = 0; k < vv.size(); k++) {
					// this.addMessage("field" + vv.get(k));
					subStr += "'" + vv.get(k) + "'";
					if (k < vv.size() - 1) {
						subStr += ", ";
					}
					// this.addMessage("[strValue i="+i+"; j="+j+"; k="+k+"]"+str);
				}
				subStr += "];\n";
				str += "fieldList['" + dbName + "']['" + tblName + "']="
						+ subStr;
			}
		}
		this.addMessage("[created fieldList]");
		return str;
	}

	private String createFFormatString(Vector db, HashMap tbl, HashMap fform) {
		this.addMessage("[creating fieldFormat List]");
		String str = "";
		str += "var fieldFormatList = new Array();\n";
		for (int i = 0; i < db.size(); i++) { // looping in database
			String dbName = db.get(i).toString();
			Vector v = (Vector) tbl.get(dbName); // geting tables
			str += " fieldFormatList['" + dbName + "'] = new Array();\n";
			for (int j = 0; j < v.size(); j++) {
				String tblName = v.get(j) + "";
				HashMap vv = (HashMap) ((HashMap) fform.get(dbName))
						.get(tblName); // geting fields
				// HashMap vv = (HashMap)fform.get(tblName); // getting fields
				str += " fieldFormatList['" + dbName + "']['" + tblName
						+ "'] = new Array(); \n";
				String fields[] = new String[vv.size()];
				vv.keySet().toArray(fields);
				for (int k = 0; k < fields.length; k++) {
					str += "fieldFormatList['" + dbName + "']['" + tblName
							+ "']['" + fields[k] + "']='" + vv.get(fields[k])
							+ "'; ";
				}
			}
		}
		this.addMessage("[created fieldFormat List]");
		return str;
	}

	// *** nov 13 ***
	public boolean approveDTS(String dtsNo, String clientID, String ap,
			String userID, String remarks) {
		boolean retVal = false;
		if (ap.equals("U")) {
			updateDTSStatus(dtsNo, clientID, "U", userID, remarks);
			retVal = true;
		} else if (ap.equals("Q")) {
			updateDTSStatus(dtsNo, clientID, "Q", userID, remarks);
			retVal = true;
		} else if (ap.equals("A")) {
			updateDTSStatus(dtsNo, clientID, "A", userID, remarks);
			retVal = true;
		}
		return retVal;
	}

	// Old updateDTSStatus method used for SQL
	/*
	 * public String updateDTSStatus1(String dtsNo, String clientID, String
	 * status, String userID, String remarks) { String errString = ""; strSQL =
	 * " sp_UpdateDTSStatus " + "'" + clientID + "'," + "" + dtsNo + "," + "'" +
	 * status + "'," + "'" + userID + "'," + "'" + remarks.replace('\'', '`') +
	 * "'," + "NULL"; this.execute(strSQL); return errString; }
	 */

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public String updateDTSStatus(String dtsNo, String clientID, String status,
			String userID, String remarks) {
		String errString = "";

		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_UpdateDTSStatus (?,?,?,?,?,?)}");
			stmt.setString(1, clientID);
			stmt.setInt(2, Integer.parseInt(dtsNo));
			stmt.setString(3, status);
			stmt.setString(4, userID);
			stmt.setString(5, remarks);
			java.sql.Date sqlDate = new java.sql.Date(new java.util.Date()
					.getTime());
			stmt.setDate(6, sqlDate);
			stmt.executeUpdate();
			stmt.close();

		} catch (Exception e) {
			System.out.println("ERROR calling sp_UpdateDTSStatus "
					+ e.toString() + "\n");
			System.out
					.println(" sp_UpdateDTSStatus (" + "'" + clientID + "',"
							+ "" + dtsNo + "," + "'" + status + "'," + "'"
							+ userID + "'," + "'" + remarks.replace('\'', '`')
							+ "'," + "NULL )");
			this.addMessage("ERROR calling sp_UpdateDTSStatus " + e.toString());
		}

		return errString;
	}

	// Old updateDTSMappingHistory method used for SQL
	public String updateDTSMappingHistory1(String dtsNo, String dtsSetNo,
			String clientID, String category, String keyField, String userID) {
		strSQL = " sp_AddMappingHistory " + "'" + clientID + "'," + "" + dtsNo
				+ "," + "" + dtsSetNo + "," + "'" + category + "'," + "'"
				+ keyField + "'," + "'" + userID + "'," + "NULL";
		this.execute(strSQL);
		return this.getLastMessage();
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public String updateDTSMappingHistory(String dtsNo, String dtsSetNo,
			String clientID, String category, String keyField, String userID) {
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_AddMappingHistory (?,?,?,?,?,?,?)}");
			stmt.setString(1, clientID);
			stmt.setInt(2, Integer.parseInt(dtsNo));
			stmt.setInt(3, Integer.parseInt(dtsSetNo));
			stmt.setString(4, category);
			stmt.setString(5, keyField);
			stmt.setString(6, userID);
			java.sql.Date sqlDate = new java.sql.Date(new java.util.Date()
					.getTime());

			stmt.setDate(7, sqlDate);

			stmt.executeUpdate();
			stmt.close();
		} catch (Exception e) {
			System.out.println("ERROR calling sp_ManageCategory "
					+ e.toString());
			this.addMessage("ERROR calling sp_ManageCategory " + e.toString());
		}

		return this.getLastMessage();
	}

	// nov 14
	public void getListOfRecentChanges(String clientID, String dtsNo,
			String category) {
		// strSQL = "sp_ListRecentChanges '" + clientID + "'," + dtsNo + ",'"
		// +category + "'";

		strSQL = "SELECT a.KeyField, a.UserID, a.ModifiedOn  FROM  ztbl_DTS_Mapping_Hist a, "
				+ "(SELECT MAX(ModifiedOn) LastApproved FROM ztbl_DTS_Mast_Hist b1, "
				+ "(SELECT MAX(ModifiedOn) LastUpdated FROM ztbl_DTS_Mast_Hist WHERE "
				+ "ClientID = '"
				+ clientID
				+ "' AND DTSNo = "
				+ dtsNo
				+ " ) b2 WHERE  "
				+ "ClientID = '"
				+ clientID
				+ "' AND DTSNo = "
				+ dtsNo
				+ " AND Status = 'A' AND ModifiedOn < b2.LastUpdated)b "
				+ "WHERE a.ModifiedOn > b.LastApproved AND a.ClientID = '"
				+ clientID
				+ "' AND DTSNo = "
				+ dtsNo
				+ " AND "
				+ "a.Category = '" + category + "'";
		
		//System.out.println("List of rcecent change query:::"+strSQL);   

		getList(strSQL, "Source fields");
	}

	// nov 17
	public boolean getListOfUsers(String clientID) {
		if (!clientID.equals("")) {
			strSQL = "SELECT a.UserID,UserName,eMail FROM ztbl_DTS_Users a,ztbl_DTS_UsersAndClients b "
					+ " WHERE a.UserID=b.UserID AND b.ClientID='"
					+ clientID
					+ "' ORDER BY UserName";
		} else {
			strSQL = "SELECT UserID,UserName,eMail FROM ztbl_DTS_Users ORDER BY UserName";
		}
		return getList(strSQL, "List of users");
	}

	public boolean getListOfUsers(String clientID, String notifyOn) {
		strSQL = "SELECT a.UserID,UserName,eMail FROM ztbl_DTS_Users a,ztbl_DTS_UsersAndClients b "
				+ " WHERE a.UserID=b.UserID AND b.ClientID='"
				+ clientID
				+ "' AND "
				+ " b.NotifyOn IN ('*','"
				+ notifyOn
				+ "') ORDER BY UserName";
		return getList(strSQL, "List of users");
	}

	// nov21
	public boolean retrieveDTS(String clientID, String dtsNo) {
		strSQL = "UPDATE ztbl_DTS_DTS_Mast SET status="
				+ "(SELECT STATUS FROM (SELECT Status FROM ztbl_DTS_Mast_Hist "
				+ " WHERE ModifiedOn=(SELECT MAX(ModifiedOn) FROM ztbl_DTS_Mast_Hist "
				+ " WHERE DTSNo=" + dtsNo + " AND ClientID='" + clientID + "')"
				+ " AND DTSNo=" + dtsNo + " AND ClientID='" + clientID
				+ "' ORDER BY ROWNUM DESC) WHERE ROWNUM=1" + ") "
				+ " WHERE DTSNo=" + dtsNo + " AND ClientID='" + clientID + "'";
		return this.execute(strSQL);
	}

	public void getListOfDeletedDTS() {

		strSQL = "SELECT a.ClientID, b.ClientName, a.DTSNo, a.Version, "
				+ "  to_char( a.CreationDate,'MM') || '-' ||  "
				+ "  to_char( a.CreationDate,'DD') || '-' ||  "
				+ "  to_number(to_char( a.CreationDate,'YYYY')) CreationDate "
				+ " FROM ztbl_DTS_DTS_Mast a, ztbl_DTS_Clients b "
				+ " WHERE a.Status='D' AND a.ClientID=b.ClientID "
				+ " ORDER BY b.ClientName";

		getList(strSQL, "List of deleted DTS");
	}

	public String setSQLData(String s, int t) {
		if (s.equals("")) {
			return "NULL";
		} else {
			if (t == 1) {
				return s;
			} else {
				return "'" + s.replace('\'', '`') + "'";
			}
		}
	}

	public boolean getReportTrackOfChanges(String userID, String clientID,
			String dtsNo, String fromDate, String toDate) {
		/*
		 * strSQL = "sp_RptMappingChanges " + setSQLData(userID, 2) + "," +
		 * setSQLData(clientID, 2) + "," + setSQLData(dtsNo, 1) + "," +
		 * setSQLData(fromDate, 3) + "," + setSQLData(toDate, 3);
		 */
		strSQL = "SELECT m.UserID,m.ClientID,m.DTSNo,m.Category,m.KeyField,m.ModifiedOn,r.BusinessRule OldRule,"
				+ "r1.BusinessRule RecentRule,u.UserName,c.ClientName FROM ztbl_DTS_Mapping_Hist m INNER JOIN "
				+ "ztbl_DTS_Mapping_Rule_Hist r ON r.TransactionID = m.TransactionID LEFT JOIN ztbl_DTS_Mapping_Rule r1 "
				+ " ON r1.ClientID = m.ClientID AND r1.DTSNo = m.DTSNo AND r1.SetNo = m.SetNo AND r1.Category = m.Category "
				+ " AND r1.KeyField = m.KeyField LEFT JOIN ztbl_DTS_Users u ON u.UserID = m.UserID INNER JOIN "
				+ "ztbl_DTS_Clients c ON c.ClientID = m.ClientID "
				+ "WHERE m.ClientID = NVL("
				+ setSQLData(clientID, 2)
				+ ", m.ClientID) "
				+ "AND m.DTSNo = NVL("
				+ setSQLData(dtsNo, 1)
				+ ", m.DTSNo) "
				+ "AND m.UserID = NVL("
				+ setSQLData(userID, 2)
				+ ", m.UserID) "
				+ "AND m.ModifiedOn BETWEEN TO_DATE("
				+ setSQLData(fromDate, 3)
				+ ",'mm/dd/yyyy') AND TO_DATE("
				+ setSQLData(toDate, 3)
				+ ",'mm/dd/yyyy')";
		return getList(strSQL, "Track Changes Report");
	}

	public boolean getUserDetail(String userID) {
		strSQL = "SELECT * FROM ztbl_DTS_Users WHERE userID='" + userID + "'";
		return getList(strSQL, "User Detail");
	}

	public boolean logMessage(String clientID, String DTSNo, String userID,
			String userName, String message) {

		strSQL = "INSERT INTO ztbl_DTS_UserMessages_Hist"
				+ " (ClientID,DTSNo,MessageDate,UserID,UserName,Message) VALUES ("
				+ "'" + clientID + "'," + DTSNo + "," + "sysdate ," + "'"
				+ userID + "'," + "'" + userName + "'," + "'" + message + "')";

		return this.execute(strSQL);
	}

	public boolean getDTSCurrentStatus() {
		strSQL = "SELECT m.ClientID, c.ClientName, m.DTSNo, CASE  NVL( m.Status,  'C' ) "
				+ "  WHEN 'C' THEN 'CREATED' "
				+ "  WHEN 'A' THEN 'APPROVED' "
				+ "  WHEN 'M' THEN 'MODIFIED' "
				+ "  WHEN 'Q' THEN 'QCAPPROVED' "
				+ "  WHEN 'U' THEN 'UNAPPROVED' "
				+ " END Status, "
				+ "  NVL( 	to_char(m.LastUpdated,'MM') || '/' || to_char(m.LastUpdated,'DD') || '/' || to_char(m.LastUpdated,'YYYY') ,  "
				+ " to_char(m.CreationDate,'MM') || '/' || to_char(m.CreationDate,'DD') || '/' || to_char(m.CreationDate,'YYYY')  ) Date, "
				+ "  CASE  NVL( m.Status,  'C' ) "
				+ "    WHEN 'C' THEN m.CreatedBy "
				+ "    WHEN 'A' THEN m.ApprovedBy "
				+ "    ELSE h.UserID "
				+ "  END UserID "
				+ " FROM ztbl_DTS_DTS_Mast m "
				+ " JOIN ztbl_DTS_Clients c "
				+ " ON c.ClientID = m.ClientID "
				+ " LEFT JOIN ztbl_DTS_Mast_Hist h "
				+ " ON h.ClientID = m.ClientID "
				+ " AND h.DTSNo = m.DTSNo "
				+ " AND h.ModifiedOn =  NVL( m.LastUpdated,  m.CreationDate ) "
				+ " WHERE  NVL( m.Status,  'C' ) <> 'D'  ";
		return getList(strSQL, "DTS Current Status");
	}

	public String getClientDTSMap(String varName) {
		String sql = "select distinct ClientID, DTSNo, Version from ztbl_DTS_DTS_Mast";
		String toRet = "";
		String ver = "";
		ver += varName + "_version = new Array();";
		HashMap map = new HashMap();
		HashMap verMap = new HashMap();
		this.executeQuery(sql);
		while (this.moveNext()) {
			String forClient = this.getData("ClientID");
			if (map.containsKey(forClient)) {
				Vector v = (Vector) map.get(forClient);
				v.add(this.getData("DTSNo"));

				Vector vers = (Vector) verMap.get(forClient);
				vers.add(this.getData("Version"));
			} else {
				Vector v = new Vector();
				v.add(this.getData("DTSNo"));
				map.put(forClient, v);

				Vector vers = new Vector();
				vers.add(this.getData("Version"));
				verMap.put(forClient, vers);
			}
		}
		String[] keys = new String[map.size()];
		map.keySet().toArray(keys);
		for (int i = 0; i < keys.length; i++) {
			toRet += varName + "['" + keys[i] + "'] = new Array(); \n";
			ver += varName + "_version['" + keys[i] + "'] = new Array(); \n";
			toRet += varName + "['" + keys[i] + "'] = [";
			ver += varName + "_version['" + keys[i] + "'] = [";
			Vector v = (Vector) map.get(keys[i]);
			Vector vers = (Vector) verMap.get(keys[i]);
			for (int j = 0; j < v.size(); j++) {
				toRet += "'" + v.get(j) + "'";
				ver += "'" + vers.get(j) + "'";
				if (j < v.size() - 1) {
					toRet += ", ";
					ver += ", ";
				}
			}
			toRet += "]; \n";
			ver += "]; \n";
		}
		return toRet + "\n" + ver;
	}

	public boolean getClientsWithDTS() {
		String sql = " select distinct m.ClientID, c.ClientName from ztbl_DTS_DTS_Mast m, ztbl_DTS_Clients c"
				+ " where m.ClientID=c.ClientID and c.ClientID not in ('999', '998')"
				+ " order by c.ClientName";
		this.executeQuery(sql);
		if (this.myRS != null) {
			return true;
		}
		return false;
	}

	public boolean copyDTS2NewDTS1(String sourceClientID, String sourceDTS,
			String targetClient, String user) {
		strSQL = "sp_CopyDTS '" + sourceClientID + "'," + sourceDTS + ",'"
				+ targetClient + "', '" + user + "'";
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean copyDTS2NewDTS(String sourceClientID, String sourceDTS,
			String targetClient, String user) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_CopyDTS (?,?,?,?)}");
			stmt.setString(1, sourceClientID);
			stmt.setString(2, sourceDTS);
			stmt.setString(3, targetClient);
			stmt.setString(4, user);

			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_CopyDTS " + e.toString());
			this.addMessage("ERROR calling sp_CopyDTS " + e.toString());
		}

		return retVal;
	}

	public boolean copyDTSSelectedSetsPrep1(String sourceClientID,
			String sourceDTS, String targetClient, String user) {
		strSQL = "sp_CopyDTSSelectedSetsPrep '" + sourceClientID + "',"
				+ sourceDTS + ",'" + targetClient + "', '" + user + "'";
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean copyDTSSelectedSetsPrep(String sourceClientID,
			String sourceDTS, String targetClient, String user) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_CopyDTSSelectedSetsPrep (?,?,?,?)}");
			System.out.println("call sp_CopyDTSSelectedSetsPrep ('"
					+ sourceClientID + "','" + sourceDTS + "','" + targetClient
					+ "','" + user + "')");
			stmt.setString(1, sourceClientID);
			stmt.setString(2, sourceDTS);
			stmt.setString(3, targetClient);
			stmt.setString(4, user);

			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_CopyDTSSelectedSetsPrep "
					+ e.toString());
			this.addMessage("ERROR calling sp_CopyDTSSelectedSetsPrep "
					+ e.toString());
		}

		return retVal;
	}

	public boolean copyDTSSelectedSets1(String sourceClientID,
			String sourceDTS, String targetClient, String category, String sets) {
		strSQL = "sp_CopyDTSSelectedSets '" + sourceClientID + "'," + sourceDTS
				+ ",'" + targetClient + "', '" + category + "', '" + sets + "'";
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean copyDTSSelectedSets(String sourceClientID, String sourceDTS,
			String targetClient, String category, String sets, String user) {
		
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_CopyDTSSelectedSets (?,?,?,?,?,?)}");
			System.out.println("call sp_CopyDTSSelectedSets ('"
					+ sourceClientID + "','" + sourceDTS + "','" + targetClient
					+ "','" + category + "','" + sets + "','"+user+"'");
			stmt.setString(1, sourceClientID);
			stmt.setString(2, sourceDTS);
			stmt.setString(3, targetClient);
			stmt.setString(4, category);
			stmt.setString(5, sets);
			stmt.setString(6, user);

			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_CopyDTSSelectedSets "
					+ e.toString());
			this.addMessage("ERROR calling sp_CopyDTSSelectedSets "
					+ e.toString());
		}

		return retVal;
	}

	public boolean renumberDTSSet1(String clientID, String DTSno,
			String category, String oldSetNo, String newSetNo) {
		strSQL = "sp_RenumberDTSSet '" + clientID + "'," + DTSno + ",'"
				+ category + "'," + oldSetNo + "," + newSetNo;
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean renumberDTSSet(String clientID, String DTSno,
			String category, String oldSetNo, String newSetNo) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_RenumberDTSSet (?,?,?,?,?)}");
			stmt.setString(1, clientID);
			stmt.setString(2, DTSno);
			stmt.setString(3, category);
			stmt.setInt(4, Integer.parseInt(oldSetNo));
			stmt.setInt(5, Integer.parseInt(newSetNo));
			
			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_RenumberDTSSet "
					+ e.toString());
			this.addMessage("ERROR calling sp_RenumberDTSSet " + e.toString());
		}

		return retVal;
	}

	public boolean repairDTSSetNumbers1(String clientID, String DTSno) {
		strSQL = "sp_RepairDTSSetNumbers '" + clientID + "'," + DTSno;
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean repairDTSSetNumbers(String clientID, String DTSno) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_RepairDTSSetNumbers (?,?)}");
			stmt.setString(1, clientID);
			stmt.setString(2, DTSno);

			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling sp_RepairDTSSetNumbers "
					+ e.toString());
			this.addMessage("ERROR calling sp_RepairDTSSetNumbers "
					+ e.toString());
		}

		return retVal;
	}

	public boolean switchVersion1(String clientID, String DTSNo, String version) {
		strSQL = "sp_SwitchVersion '" + clientID + "', '" + DTSNo + "', '"
				+ version + "'";
		return this.execute(strSQL);
	}

	// ******** 27 Apr, 2007 -->changes for oracle migration
	// ********* Subash Devkota
	public boolean switchVersion(String clientID, String DTSNo, String version) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call sp_SwitchVersion (?,?,?)}");
			stmt.setString(1, clientID);
			stmt.setString(2, DTSNo);
			stmt.setString(3, version);

			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out
					.println("ERROR calling sp_SwitchVersion " + e.toString());
			this.addMessage("ERROR calling sp_SwitchVersion " + e.toString());
		}

		return retVal;
	}

	public boolean getListOfAllTableAndFields(String databaseID) {
		this.addMessage("get List Of All Table And Fields");
		strSQL = "SELECT TABLE_NAME TableName, COLUMN_NAME FieldName, "
				+ "CASE WHEN DATA_TYPE LIKE '%NUMBER%' AND DATA_PRECISION IS NOT NULL THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ',' || CAST((DATA_LENGTH-DATA_PRECISION) AS VARCHAR(5)) || ')' "
				+ "WHEN DATA_TYPE LIKE '%CHAR%' OR DATA_TYPE LIKE '%NUMBER%'  THEN DATA_TYPE || '(' || CAST(DATA_LENGTH AS VARCHAR(5)) || ')' "
				+ "ELSE DATA_TYPE END FROM ALL_TAB_COLS a, "
				+ "(SELECT DATABASENAME FROM ztbl_DTS_Databases WHERE DATABASEID="
				+ databaseID + ") b "
				+ "WHERE UPPER(a.owner) = UPPER(b.DATABASENAME) ";
		return this.executeQuery(strSQL) != null;
	}

	/**
	 * Return current date in sql format
	 * 
	 * @return
	 */
	public java.sql.Date getSQLFormatDate() {
		return new java.sql.Date(new java.util.Date().getTime());
	}

	public boolean addDTSHistory(String CLIENTID, String DTSNO, String SETNO,
			String CATEGORY, String KEYFIELD, String VERSION, String SRCFLDTXT,
			String MAPRLETXT, String UPDATEDBY) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			CallableStatement stmt = myConn
					.prepareCall("{call SP_DTS_HISTORY (?,?,?,?,?,?,?,?,?)}");
			stmt.setString(1, CLIENTID);
			stmt.setString(2, DTSNO);
			stmt.setString(3, SETNO);
			stmt.setString(4, CATEGORY);
			stmt.setString(5, KEYFIELD);
			stmt.setString(6, VERSION);
			stmt.setString(7, SRCFLDTXT);
			stmt.setString(8, MAPRLETXT);
			stmt.setString(9, UPDATEDBY);
			stmt.executeUpdate();
			stmt.close();
			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling SP_DTS_HISTORY " + e.toString());
			this.addMessage("ERROR calling SP_DTS_HISTORY " + e.toString());
		}
		return retVal;
	}

	public boolean getDTSHistory(String CLIENTID, String DTSNO, String SETNO,
			String CATEGORY, String KEYFIELD, String VERSION) {
		String TBL = "SELECT HISTID, CLIENTID, DTSNO, SETNO, CATEGORY, KEYFIELD, VERSION, HISTDATE, SRCFLDTXT, MAPRLETXT, "
				+ " UPDATEDBY FROM ZTBL_DTS_HISTORY WHERE CLIENTID ='"
				+ CLIENTID.replaceAll("'", "''")
				+ "' AND DTSNO = "
				+ DTSNO
				+ " AND SETNO="
				+ SETNO
				+ " AND VERSION='"
				+ VERSION.replaceAll("'", "''")
				+ "' AND CATEGORY='"
				+ CATEGORY.replaceAll("'", "''") + "'";
		if (!KEYFIELD.equals("")) {
			TBL += " AND KEYFIELD='" + KEYFIELD + "'";
		}
		TBL += " ORDER BY HISTID DESC";
		strSQL = "SELECT A.HISTID, A.CLIENTID, A.DTSNO, A.SETNO, A.CATEGORY, A.KEYFIELD, A.VERSION, A.HISTDATE, A.SRCFLDTXT, "
				+ "A.MAPRLETXT, C.USERNAME UPDATEDBY from ("
				+ TBL
				+ ") A LEFT JOIN ("
				+ TBL
				+ ") B ON A.HISTID=B.HISTID+1 "
				+ " LEFT JOIN ZTBL_DTS_USERS C ON B.UPDATEDBY = C.USERID ORDER BY A.HISTID DESC";
		// System.out.println(strSQL);
		return this.executeQuery(strSQL) != null;
	}

	/**
	 * Added By: Niranjan Thapa Magar Date : June 02, 2008 Delete a set of DTS
	 * Copied here from dts sql
	 */

	public boolean deleteDTSSetNo(String clientID, String DTSNo, String setNo,
			String userID, String category, String remarks) {
		boolean result = false;
		Statement stmnt = null;
		String sqlString = "{call SP_DELETE_DTS_SET(?, ?, ?, ?, ?, ?)}";		
		strSQL = sqlString;		
		java.sql.CallableStatement mystmt = null;
		try {
			this.makeConnection();

			// System.out.println("Connection is "+myConn+"  \n");
			stmnt = myConn.createStatement(); // Implementation in MSSQl
			mystmt = myConn.prepareCall(strSQL);
			mystmt.setString(1, clientID);
			mystmt.setString(2, DTSNo);
			mystmt.setString(3, setNo);
			mystmt.setString(4, userID);
			mystmt.setString(5, replaceString(category, "'", "''"));
			mystmt.setString(6, replaceString(remarks.trim(), "'", "''"));
			mystmt.executeUpdate();
			result = true;
		} catch (Exception ee) {
			result = false;
			System.out.println("Error in dtsBean while deleting DTS No" + DTSNo
					+ " with setNo " + setNo + " of Client " + "" + clientID
					+ "\n The esception is \n" + ee);
			ee.printStackTrace();
		}
		/* The connection is closed in JSP page calling this method */
		return result;
	}

	public String updateTableName(String clientID, String dtsNo, String setNo,
			String tableName, String oldTableName) {
		String retValue = "";
		String sql = "";
		try {
			sql = "UPDATE ztbl_DTS_MAPPING_SOURCE SET TABLENAME='" + tableName
					+ "' " + " WHERE clientid='" + clientID + "' and dtsno='"
					+ dtsNo + "' and SetNo='" + setNo + "' and tablename='" + oldTableName + "'";
			this.execute(sql);

			sql = "UPDATE ZTBL_DTS_SOURCETABLESPACE SET TABLENAME='"
					+ tableName + "' " + " WHERE clientid='" + clientID
					+ "' and dtsno='" + dtsNo + "' and tablename='"
					+ oldTableName + "'";
			this.execute(sql);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return retValue;
	}

	public String getCategoryName(String dtsCategoryNo) {
		String CategoryName = "";
		try {
			String sql = "SELECT category from ztbl_dts_categories where sn='"
					+ dtsCategoryNo + "'";
			myRS = this.executeQuery(sql);
			while (myRS.next()) {
				CategoryName = myRS.getString("category");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CategoryName;
	}

	public String getDTSSetDesc(String clientID, String dtsNo, String category,
			String setNo) {
		String sql = "SELECT SETNAME FROM ZTBL_DTS_SETNAMES  WHERE ClientID='"
				+ clientID + "' AND DTSNo=" + dtsNo + " AND Category='"
				+ category.replaceAll("'", "''") + "' AND SetNo='" + setNo
				+ "'";
		String SetDesc = setNo;
		try {

			myRS = this.executeQuery(sql);
			while (myRS.next()) {
				SetDesc = myRS.getString("SETNAME");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SetDesc;
	}

	public boolean getAvailableAreaList(String ClientID, String DTSID,
			String CategoryID, String VersionID, String SetID) {
		boolean result = false;
		strSQL = "SELECT DISTINCT TableName from ztbl_DTS_SourceTableSpace "
				+ " WHERE ((ClientID='"
				+ ClientID
				+ "' AND DTSNo='"
				+ DTSID
				+ "') or (ClientID='999' and (TableName like '"
				+ ClientID
				+ "' or UPPER(TableName) like UPPER('HR_GLOBAL%') )))"
				+ " AND TableName NOT IN (SELECT DISTINCT TableName from ztbl_dts_mapping_table "
				+ " WHERE ClientID='" + ClientID + "' AND DTSNo='" + DTSID
				+ "' AND SetName='" + SetID + "' AND Category='" + CategoryID
				+ "' AND Version='" + VersionID + "')" + " ORDER BY TableName";
		try {
			myRS = this.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.print("error" + e.getMessage());
		}
		return result;
	}

	public boolean getSelectedAreaList(String ClientID, String DTSID,
			String CategoryID, String VersionID, String SetID) {
		boolean result = false;
		strSQL = "SELECT DISTINCT TableName from ztbl_DTS_SourceTableSpace "
				+ " WHERE ((ClientID='"
				+ ClientID
				+ "' AND DTSNo='"
				+ DTSID
				+ "') or (ClientID='999' and (TableName like '"
				+ ClientID
				+ "' or UPPER(TableName) like UPPER('HR_GLOBAL%') )))"
				+ " AND TableName IN (SELECT DISTINCT TableName from ztbl_dts_mapping_table "
				+ " WHERE ClientID='" + ClientID + "' AND DTSNo='" + DTSID
				+ "' AND SetName='" + SetID + "' AND Category='" + CategoryID
				+ "' AND Version='" + VersionID + "')" + " ORDER BY TableName";
		try {
			myRS = this.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.print("error" + e.getMessage());
		}
		return result;
	}

	public boolean deleteTables(String ClientID, String DTSID,
			String CategoryID, String VersionID, String SetID) {
		boolean result = false;
		strSQL = "DELETE FROM ztbl_dts_mapping_table WHERE ClientID='"
				+ ClientID + "' AND DTSNo='" + DTSID + "' AND SetName='"
				+ SetID + "' AND Category='" + CategoryID + "' AND Version='"
				+ VersionID + "'";
		try {
			myRS = this.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.print("error" + e.getMessage());
		}
		return result;
	}

	public boolean insertTables(String ClientID, String DTSID,
			String CategoryID, String VersionID, String SetID,
			ArrayList TableList) {
		boolean result = false;
		int i = 0;
		try {
			Iterator it = TableList.iterator();
			while (it.hasNext()) {
				i++;
				if ((i % 200) == 0) {
					this.takeDown();
					try {
						this.makeConnection();
					} catch (Exception ex) {
						System.out.println(ex);
					}
				}

				String Table = it.next().toString();
				strSQL = "insert into ztbl_dts_mapping_table values('"
						+ ClientID + "','" + DTSID + "','" + SetID + "','"
						+ CategoryID + "','" + VersionID + "','" + Table
						+ "' )";
				this.execute(strSQL);

			}
		} catch (Exception e) {
			System.out.print("error" + e.getMessage());
		}
		return result;
	}

	/**
	 * Changed On: 4 Dec, 2009 Changed By: Dinesh Bajracharya Added to copy a
	 * DTS set from a source client configuration to target client into a new
	 * set
	 */
	public boolean copyDTSSetToNewDTS(String srcClientID, String srcDTSNo,
			String srcCategory, String srcSetNo, String destClientID,
			String destDTSNo, String user) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			System.out.println("call sp_copydtssettoanotherset (" + srcClientID
					+ "," + srcDTSNo + "," + srcCategory + "," + srcSetNo + ","
					+ destClientID + "," + destDTSNo + ")");
			/***
			 * commenting the this code for copying the dts set 
			 */
			//CallableStatement stmt = myConn.prepareCall("{call sp_copydtssettoanotherset_ (?,?,?,?,?,?)}");
			CallableStatement stmt = myConn.prepareCall("{call sp_copydtssettoanotherset_new (?,?,?,?,?,?)}");
			stmt.setString(1, srcClientID);
			stmt.setString(2, srcDTSNo);
			stmt.setString(3, srcCategory);
			stmt.setString(4, srcSetNo);
			stmt.setString(5, destClientID);
			stmt.setString(6, destDTSNo);
			stmt.executeUpdate();
			stmt.close();

			System.out.println("call SP_DTS_CHANGELOG (" + user + ","
					+ srcClientID + "," + srcDTSNo + "," + srcCategory + ","
					+ srcSetNo + "," + destClientID + "," + destDTSNo + ")");

			CallableStatement stmt1 = myConn
					.prepareCall("{call SP_DTS_CHANGELOG (?,?,?,?,?,?,?)}");
			stmt1.setString(1, user);
			stmt1.setString(2, srcClientID);
			stmt1.setString(3, srcDTSNo);
			stmt1.setString(4, srcCategory);
			stmt1.setString(5, srcSetNo);
			stmt1.setString(6, destClientID);
			stmt1.setString(7, destDTSNo);
			stmt1.executeUpdate();
			stmt1.close();

			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling copyDTSSetToNewDTS "
					+ e.toString());
			this.addMessage("ERROR calling copyDTSSetToNewDTS " + e.toString());
		}

		return retVal;
	}
	
	/**
	 * Changed On: 4 Dec, 2009 Changed By: Dinesh Bajracharya Added to copy a
	 * DTS set from a source client configuration to target client into a new
	 * set
	 */
	public boolean copyDTSSetToNewDTSHPToVH(String srcClientID, String srcDTSNo,
			String srcCategory, String srcSetNo, String destClientID,
			String destDTSNo, String user, String destCategory) {
		boolean retVal = false;
		try {
			if (myConn == null) {
				this.makeConnection();
			}
			System.out.println("call sp_copydtssettoanotherset_new2 (" + srcClientID
					+ "," + srcDTSNo + "," + srcCategory + "," + srcSetNo + ","
					+ destClientID + "," + destDTSNo + "," + destCategory + ")");
			/***
			 * commenting the this code for copying the dts set 
			 */
			//CallableStatement stmt = myConn.prepareCall("{call sp_copydtssettoanotherset_ (?,?,?,?,?,?)}");
			CallableStatement stmt = myConn.prepareCall("{call sp_copydtssettoanotherset_new2 (?,?,?,?,?,?,?)}");
			stmt.setString(1, srcClientID);
			stmt.setString(2, srcDTSNo);
			stmt.setString(3, srcCategory);
			stmt.setString(4, srcSetNo);
			stmt.setString(5, destClientID);
			stmt.setString(6, destDTSNo);
			stmt.setString(7, destCategory);
			stmt.executeUpdate();
			stmt.close();

			System.out.println("call SP_DTS_CHANGELOG2 (" + user + ","
					+ srcClientID + "," + srcDTSNo + "," + srcCategory + ","
					+ srcSetNo + "," + destClientID + "," + destDTSNo + ")");

			CallableStatement stmt1 = myConn
					.prepareCall("{call SP_DTS_CHANGELOG (?,?,?,?,?,?,?)}");
			stmt1.setString(1, user);
			stmt1.setString(2, srcClientID);
			stmt1.setString(3, srcDTSNo);
			stmt1.setString(4, srcCategory);
			stmt1.setString(5, srcSetNo);
			stmt1.setString(6, destClientID);
			stmt1.setString(7, destDTSNo);
			stmt1.executeUpdate();
			stmt1.close();

			retVal = true;
		} catch (Exception e) {
			System.out.println("ERROR calling copyDTSSetToNewDTS "
					+ e.toString());
			this.addMessage("ERROR calling copyDTSSetToNewDTS " + e.toString());
		}

		return retVal;
	}
	
	public String getSendToExcelData(String bucketId, String viewType, String clientID, String dtsNo, String[] dtsSetName, String[] categoryID, HttpServletRequest request, String Type)
  {
    HSSFWorkbook wb = new HSSFWorkbook();
    String setName = "";
    String returnedSetNo = "";
    for (int p = 0; p < dtsSetName.length; p++)
    {
      HSSFSheet sheet;
      Hashtable<Integer, Integer> colorRow;
      HashMap<Integer, String> priority;
      Boolean alter;
      int prevRowNo;
      CellStyle cStyle;
      for (int j = 0; j < categoryID.length; j++) {
        if (findSetAndCategoryInBucket(bucketId, categoryID[j], dtsSetName[p], viewType))
        {
          returnedSetNo = getSetNoFromSetName(clientID, dtsNo, categoryID[j], dtsSetName[p]);
          setName = dtsSetName[p];
          if (!returnedSetNo.equalsIgnoreCase(""))
          {
            sheet = wb.createSheet(setName + "_" + categoryID[j]);
            HSSFRow headingrow = sheet.createRow(0);
            sheet.addMergedRegion(new CellRangeAddress(0, 1, 0, 0));
            sheet.addMergedRegion(new CellRangeAddress(0, 1, 5, 5));
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 2, 4));
            sheet.setAutobreaks(true);
            sheet.setColumnWidth(0, 1024);
            sheet.setColumnWidth(1, 9000);
            sheet.setColumnWidth(2, 3600);
            sheet.setColumnWidth(3, 3600);
            sheet.setColumnWidth(4, 3600);
            sheet.setColumnWidth(5, 20000);
            Map<String, CellStyle> styles = createStyles(wb);
            HSSFRichTextString dataCell = new HSSFRichTextString("SN");
            HSSFCell cell = headingrow.createCell(0);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            dataCell = new HSSFRichTextString("Source Table Info");
            cell = headingrow.createCell(1);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            dataCell = new HSSFRichTextString("Target Table Info");
            cell = headingrow.createCell(2);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            dataCell = new HSSFRichTextString("Business Rule");
            cell = headingrow.createCell(5);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            headingrow = sheet.createRow(1);
            dataCell = new HSSFRichTextString("Table Name.Field Name");
            
            cell = headingrow.createCell(1);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            dataCell = new HSSFRichTextString("Table Name");
            cell = headingrow.createCell(2);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            dataCell = new HSSFRichTextString("Field Name");
            cell = headingrow.createCell(3);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            
            dataCell = new HSSFRichTextString("Field Format");
            cell = headingrow.createCell(4);
            cell.setCellValue(dataCell);
            cell.setCellStyle((CellStyle)styles.get("header"));
            int rownum = 2;
            List dtsSetDetails = null;
            if (Type.equalsIgnoreCase("HP")) {
              dtsSetDetails = getDTSSetDetailsHP(clientID, dtsNo, returnedSetNo, categoryID[j]);
            } else {
              dtsSetDetails = getDTSSetDetails(clientID, dtsNo, returnedSetNo, categoryID[j]);
            }
            String tempsn = "";
            String tempBusinessRule = "";
            int startfrom = -1;
            int mergeto = -1;
            int tempRow = 0;
            int uniqueCounter = 0;
            colorRow = new Hashtable();
            String tableFieldName = "";
            priority = new HashMap();
            for (int i = 0; i < dtsSetDetails.size(); i++)
            {
              HashMap map1 = (HashMap)dtsSetDetails.get(i);
              colorRow.put(Integer.valueOf(Integer.parseInt(map1.get("sn").toString())), Integer.valueOf(rownum));
              priority.put(Integer.valueOf(Integer.parseInt(map1.get("sn").toString())), map1.get("priority").toString());
              HSSFRow datarow = sheet.createRow(rownum);
              
              String BusinessRule = map1.get("businessrule").toString();
              

              String[] htmltags = { "<b>", "</b>", "<br>", "<br/>", "<font>", "</font>", "<style>", "</style>", "<B>", "</B>", "<BR>", "</BR>", "<BR/>", "<BR />", "<FONT>", "</FONT>", "<STYLE>", "</STYLE>", "<i>", "</i>", "</I>", "<I>", "\r", "<u>", "</u>", "<U>", "</U>", "</BR />", "<BR >", "<br />", "<li>", "</li>", "<LI>", "</LI>", "<Li>", "</Li>", "<li />" };
              for (int inthtmltags = 0; inthtmltags < htmltags.length; inthtmltags++) {
                if (BusinessRule.contains(htmltags[inthtmltags])) {
                  BusinessRule = BusinessRule.replaceAll(htmltags[inthtmltags], "");
                }
              }
              int pointct = BusinessRule.codePointCount(0, BusinessRule.length());
              int lengthinpoint = pointct * 256;
              int widthpoint = lengthinpoint / 20000;
              






              HSSFCell[] cells = new HSSFCell[6];
              for (int m = 0; m < 6; m++)
              {
                cells[m] = datarow.createCell(m);
                if (!map1.get("priority").equals("")) {
                  cells[m].setCellStyle((CellStyle)styles.get("dataStyle1"));
                } else {
                  cells[m].setCellStyle((CellStyle)styles.get("dataStyle"));
                }
              }
              int diff = 1;
              if (!tempsn.equals(map1.get("sn").toString())) {
                startfrom = i + 2;
              }
              if (tempsn.equals(map1.get("sn").toString()))
              {
                mergeto = i + 2;diff = mergeto - startfrom;
              }
              if ((widthpoint > 1) && (!tempsn.equals(map1.get("sn").toString())))
              {
                int wholevalue = (widthpoint + 1) * 255 / diff;
                datarow.setHeight((short)wholevalue);
              }
              if (tempsn.equals(map1.get("sn").toString()))
              {
                sheet.addMergedRegion(new CellRangeAddress(startfrom, mergeto, 0, 0));
                sheet.addMergedRegion(new CellRangeAddress(startfrom, mergeto, 2, 2));
                sheet.addMergedRegion(new CellRangeAddress(startfrom, mergeto, 3, 3));
                sheet.addMergedRegion(new CellRangeAddress(startfrom, mergeto, 4, 4));
                sheet.addMergedRegion(new CellRangeAddress(startfrom, mergeto, 5, 5));
              }
              cells[0].setCellValue(map1.get("sn").toString());
              
              String value = map1.get("sourcetable").toString();
              if (!map1.get("sourcefield").equals("")) {
                value = value + "." + map1.get("sourcefield").toString();
              }
              cells[1].setCellValue(value);
              cells[2].setCellValue(map1.get("targettable").toString());
              cells[3].setCellValue(map1.get("targetfield2display").toString());
              
              cells[4].setCellValue(map1.get("fieldformat").toString());
              if (!tempsn.equals(map1.get("sn").toString()))
              {
                uniqueCounter = 0;
                tempBusinessRule = BusinessRule + "\n";
                cells[5].setCellValue(BusinessRule);
              }
              else
              {
                if (uniqueCounter == 0)
                {
                  uniqueCounter++;
                  tempRow = rownum - 1;
                }
                HSSFRow temprow = sheet.getRow(tempRow);
                HSSFCell tempCell = temprow.getCell(5);
                if (!tempBusinessRule.contains(BusinessRule)) {
                  tempBusinessRule = tempBusinessRule + BusinessRule + "\n";
                }
                tempCell.setCellValue(tempBusinessRule);
              }
              rownum++;
              tempsn = map1.get("sn").toString();
              tableFieldName = map1.get("targettable").toString();
            }
            List<Integer> v = new ArrayList(colorRow.keySet());
            Collections.sort(v);
            alter = Boolean.valueOf(false);
            prevRowNo = 0;
            HSSFRow thirdRow = sheet.getRow(2);
            HSSFCell thirdRowZeroCell = thirdRow.getCell(0);
            CellStyle thirdRowcStyle = thirdRowZeroCell.getCellStyle();
            cStyle = wb.createCellStyle();
            cStyle.cloneStyleFrom(thirdRowcStyle);
            cStyle.setFillForegroundColor((short)49);
            cStyle.setFillPattern((short)1);
            for (Integer key : v) {
              if (!((String)priority.get(key)).equals("y"))
              {
                if (alter.booleanValue())
                {
                  int diff = ((Integer)colorRow.get(key)).intValue() - prevRowNo;
                  for (int row = 0; row < diff; row++)
                  {
                    prevRowNo++;
                    for (int col = 0; col < 6; col++)
                    {
                      HSSFRow temprow = sheet.getRow(prevRowNo);
                      HSSFCell tempCell = temprow.getCell(col);
                      
                      tempCell.setCellStyle(cStyle);
                    }
                  }
                  alter = Boolean.valueOf(false);
                }
                else
                {
                  alter = Boolean.valueOf(true);
                  prevRowNo = ((Integer)colorRow.get(key)).intValue();
                }
              }
              else {
                alter = Boolean.valueOf(false);
              }
            }
          }
        }
      }
    }
    String fileName = "DTS_" + clientID + "_" + dtsNo + ".xls";
    
    String fileLocation = this.filePath + fileName;
    try
    {
      String contextPath = new File(new File(".").getCanonicalPath()).toString() + System.getProperty("file.separator") + "Excel";
      

      File file1 = new File(contextPath);
      boolean exists = file1.exists();
      if (!exists) {
        file1.mkdir();
      }
      fileLocation = new File(new File(".").getCanonicalPath()).toString() + System.getProperty("file.separator") + this.filePath + System.getProperty("file.separator") + fileName;
    }
    catch (Exception e) {}
    try
    {
      FileOutputStream fileOut = new FileOutputStream(fileLocation);
      wb.write(fileOut);
      fileOut.close();
    }
    catch (Exception fe)
    {
      System.out.print("\nError while searching file for excel in DTS \n" + fe);
    }
    return fileName;
  }
  
  public List getDTSSetDetailsHP(String clientID, String dtsNo, String dtsSetNo, String categoryID)
  {
    int primaryTempId = getPrimaryTemplateID();
    int assignedTemplate = getAssignedTemplateID(clientID);
    List dtsSetDetails = new ArrayList();
    

    this.strSQL = ("SELECT m.Category, m.SN, Nvl(Z.SETNAME,ZZ.SETNAME) SETNAME, db.DatabaseId SourceDBID,  db.DatabaseName SourceDatabase, s.TableName SourceTable,  s.FieldName SourceField, s.FieldFormat SourceFieldFormat,  REPLACE(t.TableName,'VH','HP') TargetTable, t.KEYFIELD as TargetField, m.FieldFormat,  REPLACE(t.FieldName, map.VH, map.HP) AS TargetField2Display,  r.BusinessRule BusinessRule , r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m  INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND  t.KeyField = m.KeyField and m.version=t.version  INNER JOIN vh_hp_mapping map ON  Upper(map.VH)=Upper(t.FieldName) AND map.Category = t.Category  INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='" + clientID + "' " + " and mast.DTSNo='" + dtsNo + "' and t.Version=mast.Version " + " INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES " + "    ON MAST.CLIENTID=TEMPLATES.CLIENTID " + " INNER JOIN (SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_TEMPLATE_DEFS WHERE " + "TEMPLATEID IN ('" + primaryTempId + "','" + assignedTemplate + "') UNION " + "SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_CLIENT_KEYFIELDS WHERE CLIENTID='" + clientID + "' " + "AND CATEGORY='" + categoryID + "'" + ") TEMPLATE_DEFS" + "    ON  TEMPLATE_DEFS.CATEGORY=M.CATEGORY" + "    AND TEMPLATE_DEFS.KEYFIELD=M.KEYFIELD" + " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND " + " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' " + " AND s.DTSno=" + dtsNo);
    if (!dtsSetNo.equals("0")) {
      this.strSQL = (this.strSQL + " AND s.SetNo=" + dtsSetNo);
    }
    this.strSQL = (this.strSQL + " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId  LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND  r.KeyField = m.KeyField AND r.ClientID='" + clientID + "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo);
    if (!dtsSetNo.equals("0")) {
      this.strSQL = (this.strSQL + " AND r.SetNo=" + dtsSetNo);
    }
    this.strSQL = (this.strSQL + " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName  AND x.FieldName=s.FieldName AND x.DTSNo=" + dtsNo + " AND x.ClientID='" + clientID + "' " + " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category " + " AND y.KeyField=m.KeyField AND y.DTSNo=" + dtsNo + " AND y.SetNo=" + dtsSetNo + " AND y.ClientID='" + clientID + "' ");
    













    this.strSQL = (this.strSQL + " LEFT JOIN ZTBL_DTS_SETNAMES Z ON Z.CLIENTID='" + clientID + "' AND Z.DTSNO=" + dtsNo + " AND Z.CATEGORY='" + categoryID + "' AND Z.SETNO=" + dtsSetNo);
    

    this.strSQL = (this.strSQL + " LEFT JOIN (SELECT " + dtsSetNo + " SETNAME, '" + categoryID + "' CATEGORY FROM DUAL)" + "ZZ ON ZZ.CATEGORY=m.Category");
    

    this.strSQL = (this.strSQL + " WHERE m.Category='" + categoryID + "' ");
    
    this.strCountSQL = ("SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast m  INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND  t.KeyField = m.KeyField and m.version=t.version  INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='" + clientID + "' " + " and mast.DTSNo='" + dtsNo + "' and t.Version=mast.Version " + " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND " + " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' " + " AND s.DTSno=" + dtsNo);
    if (!dtsSetNo.equals("0")) {
      this.strCountSQL = (this.strCountSQL + " AND s.SetNo=" + dtsSetNo);
    }
    this.strCountSQL = (this.strCountSQL + " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId  LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND  r.KeyField = m.KeyField AND r.ClientID='" + clientID + "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo);
    if (!dtsSetNo.equals("0")) {
      this.strCountSQL = (this.strCountSQL + " AND r.SetNo=" + dtsSetNo);
    }
    this.strCountSQL = (this.strCountSQL + " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName  AND x.FieldName=s.FieldName AND x.DTSNo=" + dtsNo + " AND x.ClientID='" + clientID + "' WHERE m.Category='" + categoryID + "' ");
    












    this.strSQL = ("SELECT  distinct Category, SN,  SETNAME, SourceDBID,  SourceDatabase, SourceTable,  SourceField, SourceFieldFormat,  TargetTable, TargetField, FieldFormat,  TargetField2Display,  to_char(BusinessRule) BusinessRule,  TranslatedRule, Example, Matched, Priority   FROM ( " + this.strSQL + ") ");
    









    this.strSQL += " ORDER BY Category,SN";
    try
    {
      this.myRS = executeQuery(this.strSQL);
      while (this.myRS.next())
      {
        HashMap map = new HashMap();
        map.put("category", checkNull(this.myRS.getString("category")));
        map.put("sn", checkNull(this.myRS.getString("SN")));
        map.put("setname", checkNull(this.myRS.getString("setname")));
        map.put("sourcedbid", checkNull(this.myRS.getString("sourcedbid")));
        map.put("sourcedatabase", checkNull(this.myRS.getString("sourcedatabase")));
        
        map.put("sourcetable", checkNull(this.myRS.getString("sourcetable")));
        

        map.put("sourcefield", checkNull(this.myRS.getString("sourcefield")));
        

        map.put("sourcefieldformat", checkNull(this.myRS.getString("sourcefieldformat")));
        
        map.put("targettable", checkNull(this.myRS.getString("targettable")));
        

        map.put("targetfield", checkNull(this.myRS.getString("targetfield")));
        

        map.put("fieldformat", checkNull(this.myRS.getString("fieldformat")));
        

        map.put("targetfield2display", checkNull(this.myRS.getString("targetfield2display")));
        
        map.put("businessrule", checkNull(this.myRS.getString("businessrule")));
        
        map.put("translatedrule", checkNull(this.myRS.getString("translatedrule")));
        
        map.put("example", checkNull(this.myRS.getString("example")));
        map.put("matched", checkNull(this.myRS.getString("matched")));
        map.put("priority", checkNull(this.myRS.getString("priority")));
        dtsSetDetails.add(map);
      }
      this.myRS.close();
    }
    catch (SQLException e)
    {
      e.printStackTrace();
    }
    return dtsSetDetails;
  }

	public String getSendToExcelData1(String bucketId,String viewType,String clientID, String dtsNo,
			String[] dtsSetName, String[] categoryID, HttpServletRequest request, String Type) {
		HSSFWorkbook wb = new HSSFWorkbook();
		String setName = "";
		String returnedSetNo="";        
		for (int p = 0; p < dtsSetName.length; p++) {			
		for (int j = 0; j < categoryID.length; j++) {	
			if(this.findSetAndCategoryInBucket(bucketId,categoryID[j],dtsSetName[p],viewType)){
			returnedSetNo=this.getSetNoFromSetName(clientID, dtsNo,categoryID[j], dtsSetName[p]);
			setName=dtsSetName[p];
			if(!returnedSetNo.equalsIgnoreCase(""))
		     {			
			HSSFSheet sheet = null;
			if(Type.equalsIgnoreCase("HP"))
				sheet=wb.createSheet(setName + "_" + categoryID[j].replaceFirst("VH", "HP"));
			else if(Type.equalsIgnoreCase("CDF"))
				sheet=wb.createSheet(setName + "_" + categoryID[j].replaceFirst("HP", "VH"));
			else
				sheet=wb.createSheet(setName + "_" + categoryID[j]);
				
			HSSFRow headingrow = sheet.createRow(0);
			sheet.addMergedRegion(new CellRangeAddress(0, 1, 0, 0));
			sheet.addMergedRegion(new CellRangeAddress(0, 1, 5, 5));
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 2, 4));
			sheet.setAutobreaks(true); 
			sheet.setColumnWidth(0,1024);
			sheet.setColumnWidth(1,9000);       
			sheet.setColumnWidth(2,3600); 
			sheet.setColumnWidth(3,3600); 
			sheet.setColumnWidth(4,3600); 
			sheet.setColumnWidth(5,20000);         		
			Map<String, CellStyle> styles = createStyles(wb);
			HSSFRichTextString dataCell = new HSSFRichTextString("SN");
			HSSFCell cell = headingrow.createCell(0);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			dataCell = new HSSFRichTextString("Source Table Info");
			cell = headingrow.createCell(1);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			dataCell = new HSSFRichTextString("Target Table Info");
			cell = headingrow.createCell(2);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			dataCell = new HSSFRichTextString("Business Rule");
			cell = headingrow.createCell(5);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			headingrow = sheet.createRow(1);
			dataCell = new HSSFRichTextString(
					"Table Name.Field Name");  
			cell = headingrow.createCell(1);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			dataCell = new HSSFRichTextString("Table Name");
			cell = headingrow.createCell(2);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			dataCell = new HSSFRichTextString("Field Name");
			cell = headingrow.createCell(3);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));

			dataCell = new HSSFRichTextString("Field Format");
			cell = headingrow.createCell(4);
			cell.setCellValue(dataCell);
			cell.setCellStyle(styles.get("header"));
			int rownum = 2;
			List dtsSetDetails=null;
			if(Type.equalsIgnoreCase("HP")){
				dtsSetDetails = this.getDTSSetDetailsToHP(clientID, dtsNo,
						returnedSetNo, categoryID[j]);	
			}
			else if(Type.equalsIgnoreCase("CDF"))
				dtsSetDetails = this.getDTSSetDetailsToCDF(clientID, dtsNo,
						returnedSetNo, categoryID[j]);
			else{
			 dtsSetDetails = this.getDTSSetDetails(clientID, dtsNo,
					returnedSetNo, categoryID[j]);
			}
			String tempsn="";
			String tempField="";
			String tempBusinessRule="";
			int startfrom=-1;
			int mergeto=-1; 
			int tempRow=0;
			int uniqueCounter=0;
			Hashtable<Integer,Integer> colorRow=new Hashtable<Integer, Integer>();
			String tableFieldName="";
			HashMap<Integer,String>priority=new HashMap<Integer,String>();

			for (int i = 0; i < dtsSetDetails.size(); i++) {   
				HashMap map1 = (HashMap) dtsSetDetails.get(i);
				colorRow.put(Integer.parseInt(map1.get("sn").toString()),rownum);
				priority.put(Integer.parseInt(map1.get("sn").toString()), map1.get("priority").toString());
				HSSFRow datarow = sheet.createRow(rownum);	
				
				String BusinessRule =map1.get("businessrule").toString();// htmlString.replaceAll("\\<.*?\\>", "");
				//BusinessRule=BusinessRule.replaceAll("\\<.*?\\>", ""); 
				//Add any other html tags found in rule
				String[] htmltags={"<b>","</b>","<br>","<br/>","<font>","</font>","<style>","</style>",
						"<B>","</B>","<BR>","</BR>","<BR/>","<BR />","<FONT>","</FONT>","<STYLE>","</STYLE>",
						"<i>","</i>","</I>","<I>","\r","<u>","</u>","<U>","</U>","</BR />","<BR >","<br />","<li>","</li>","<LI>","</LI>","<Li>","</Li>","<li />"}; 

				for (int inthtmltags=0;inthtmltags<htmltags.length;inthtmltags++){
				if (BusinessRule.contains(htmltags[inthtmltags])){
					BusinessRule=BusinessRule.replaceAll(htmltags[inthtmltags],"");
				}}
				
				//BusinessRule=BusinessRule.replaceAll("\r", " ");
				int pointct=BusinessRule.codePointCount(0, BusinessRule.length());
				int lengthinpoint=pointct*256;//20000
				int widthpoint = lengthinpoint/20000;
				
				//System.out.println("length:"+BusinessRule.length());
				//System.out.println("pointct:"+pointct);	 
				//System.out.println("rowheight:"+datarow.getHeight());//255
				//System.out.println("rowheight in point:"+datarow.getHeightInPoints());   //12.75
				
				// HSSFRichTextString dataRowCell=new HSSFRichTextString();
				HSSFCell cells[] = new HSSFCell[6];
				
				for (int m = 0; m < 6; m++) {
					cells[m] = datarow.createCell(m);
					if (!map1.get("priority").equals("")) {
						cells[m].setCellStyle(styles.get("dataStyle1"));
					} else
					{
						cells[m].setCellStyle(styles.get("dataStyle"));	     
					}

				} 
				//Mering rows having same SN
				int diff=1;
				if(!tempsn.equals(map1.get("sn").toString())){startfrom=i+2;}
				if(tempsn.equals(map1.get("sn").toString())){mergeto=i+2; diff=mergeto-startfrom;}
				if(widthpoint > 1 && !tempsn.equals(map1.get("sn").toString()))  
				{ 
					int wholevalue=(widthpoint+1)*255/diff;      
					datarow.setHeight((short)wholevalue);      
				}
				if(tempsn.equals(map1.get("sn").toString())){	
					if(tempField.equalsIgnoreCase(map1.get("targetfield2display").toString()) && 
							(!Type.equalsIgnoreCase("HP") || !Type.equalsIgnoreCase("CDF"))){
					sheet.addMergedRegion(new CellRangeAddress(startfrom,mergeto, 0, 0)); 					
					sheet.addMergedRegion(new CellRangeAddress(startfrom,mergeto, 2, 2));
					sheet.addMergedRegion(new CellRangeAddress(startfrom,mergeto, 3, 3));
					sheet.addMergedRegion(new CellRangeAddress(startfrom,mergeto, 4, 4));
					sheet.addMergedRegion(new CellRangeAddress(startfrom,mergeto, 5, 5)); 
					}
				}
				cells[0].setCellValue(map1.get("sn").toString());

				String value = map1.get("sourcetable").toString();
				if (!map1.get("sourcefield").equals("")) {
					value = value + "." + map1.get("sourcefield").toString();
				}
				/*if (!map1.get("sourcefieldformat").equals("")) {
					value = value + "."
							+ map1.get("sourcefieldformat").toString();
				}*/ 
				
				cells[1].setCellValue(value);
				cells[2].setCellValue(map1.get("targettable").toString());
				cells[3].setCellValue(map1.get("targetfield2display")
						.toString());
				cells[4].setCellValue(map1.get("fieldformat").toString());
				
				//for solving problem of missing multiple Business Rule due to merging cell.
				if(!tempsn.equals(map1.get("sn").toString())){
				
					uniqueCounter=0;
					tempBusinessRule=BusinessRule+"\n";
					cells[5].setCellValue(BusinessRule);
				}
				else{
					if(uniqueCounter==0){
						uniqueCounter++;
						tempRow=rownum-1;
						}
					HSSFRow temprow = sheet.getRow(tempRow);
					HSSFCell tempCell =temprow.getCell(5);
					if(!tempBusinessRule.contains(BusinessRule)){
					tempBusinessRule+=BusinessRule+"\n";
					
					}
					if(Type.equalsIgnoreCase("HP") ||Type.equalsIgnoreCase("CDF"))
						cells[5].setCellValue(BusinessRule);
					else
					   tempCell.setCellValue(tempBusinessRule);
				}
				rownum++;
				tempsn=map1.get("sn").toString();
				tempField=map1.get("targetfield2display").toString();
				tableFieldName=map1.get("targettable").toString();
			}
			//for maintain different color on alter row of excel 
			 List<Integer> v = new ArrayList<Integer>(colorRow.keySet());
			    Collections.sort(v);
			    Boolean alter=false;
			   int prevRowNo=0;
				HSSFRow thirdRow = sheet.getRow(2);
				HSSFCell thirdRowZeroCell  =thirdRow.getCell(0);
				CellStyle thirdRowcStyle=thirdRowZeroCell.getCellStyle();
				CellStyle cStyle=wb.createCellStyle();
				cStyle.cloneStyleFrom(thirdRowcStyle);
				cStyle.setFillForegroundColor(HSSFColor.AQUA.index);  
				cStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
			for(Integer key:v){
				if(!priority.get(key).equals("y")){
				if(alter){
				int diff=colorRow.get(key)-prevRowNo;
				for(int row=0;row<diff;row++){
					prevRowNo++;
					for(int col=0;col<6;col++){
						HSSFRow temprow = sheet.getRow(prevRowNo);
						HSSFCell tempCell  =temprow.getCell(col);
						//cStyle=tempCell.getCellStyle();
						tempCell.setCellStyle(cStyle );
					}
				}
				alter=false;
				}
				else{
					alter=true;
					prevRowNo=colorRow.get(key);	
				}
			}
				else{
					alter=false;
				}
			}
		}}
	}
	}
		// Write the output to a file
		String fileName = "DTS"+"_"+clientID+"_"+dtsNo+".xls";   
		// if(wb instanceof XSSFWorkbook) fileName += "x";
		String fileLocation = filePath + fileName;
		try {
			String contextPath = new File(new File(".").getCanonicalPath())
					.toString()
					+ System.getProperty("file.separator") + "Excel";
			File file1 = new File(contextPath);
			boolean exists = file1.exists();
			if (!exists) {
				file1.mkdir();
			}

			fileLocation = new File(new File(".").getCanonicalPath())
					.toString()
					+ System.getProperty("file.separator")
					+ filePath
					+ System.getProperty("file.separator") + fileName;
		} catch (Exception e) {
		}
		//System.out.println("fileLocation:" + fileLocation);
		try {
			FileOutputStream fileOut = new FileOutputStream(fileLocation);
			wb.write(fileOut);
			fileOut.close();
		} catch (Exception fe) {
			System.out.print("\nError while searching file for excel in DTS \n"
					+ fe);
		}
		//System.out.println("filesize:" + fileName.length());
		return fileName;
	}


	/**
	 * cell styles used for formatting excel sheets
	 */
	private static Map<String, CellStyle> createStyles(Workbook wb) {
		Map<String, CellStyle> styles = new HashMap<String, CellStyle>();

		short borderColor = IndexedColors.GREY_50_PERCENT.getIndex();
       
		CellStyle style;
		Font titleFont = wb.createFont();
		titleFont.setFontHeightInPoints((short) 12);
		titleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		//titleFont.setColor(IndexedColors.DARK_BLUE.getIndex());
		
		style = wb.createCellStyle();
		style.setBorderBottom((short)1);
		style.setBorderLeft((short)1);
		style.setBorderTop((short)1);
		style.setBorderRight((short)1);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		style.setFont(titleFont);		
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());  
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);		  
		styles.put("header", style);

		Font highlightFont = wb.createFont();
		highlightFont.setFontHeightInPoints((short) 10);
		highlightFont.setColor(IndexedColors.BLACK.getIndex());
		// monthFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style = wb.createCellStyle();
		style.setAlignment(CellStyle.ALIGN_LEFT);
		style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		style.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
		// style.setFillBackgroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		style.setFont(highlightFont);
		style.setBorderBottom((short)1);
		style.setBorderLeft((short)1);
		style.setBorderTop((short)1);
		style.setBorderRight((short)1);    
		style.setWrapText(true); 
		styles.put("dataStyle1", style); 
		
		Font normalDataFont = wb.createFont();
		normalDataFont.setFontHeightInPoints((short) 10);
		normalDataFont.setColor(IndexedColors.BLACK.getIndex());	
		style = wb.createCellStyle();
		style.setAlignment(CellStyle.ALIGN_LEFT);   
		style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);			
		style.setFont(normalDataFont);
		style.setBorderBottom((short)1);
		style.setBorderLeft((short)1);
		style.setBorderTop((short)1);
		style.setBorderRight((short)1);   
		style.setWrapText(true);  

		styles.put("dataStyle", style);      
		
		return styles;
	}

	public List getDTSSetDetails(String clientID, String dtsNo,
			String dtsSetNo, String categoryID) {
        int primaryTempId = this.getPrimaryTemplateID();
        int assignedTemplate = this.getAssignedTemplateID(clientID);
		List dtsSetDetails = new ArrayList();


		strSQL = "SELECT m.Category, m.SN, Nvl(Z.SETNAME,ZZ.SETNAME) SETNAME, db.DatabaseId SourceDBID, "

				+ " db.DatabaseName SourceDatabase, s.TableName SourceTable, "
				+ " s.FieldName SourceField, s.FieldFormat SourceFieldFormat, "
				+ " t.TableName TargetTable, t.KeyField TargetField, m.FieldFormat, "
				+ " t.FieldName AS TargetField2Display, "
				+ " r.BusinessRule BusinessRule , r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+ " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+
/*
 * CDF implementation, rsah, Oct 14 2011
 */
				" INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES "
				+ "    ON MAST.CLIENTID=TEMPLATES.CLIENTID "
				+ " INNER JOIN (SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_TEMPLATE_DEFS WHERE " +
						"TEMPLATEID IN ('"+primaryTempId+"','"+assignedTemplate+"') UNION " 
				+ "SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_CLIENT_KEYFIELDS WHERE CLIENTID='"+clientID+"' " +
						"AND CATEGORY='"+categoryID+"'" 
				+		") TEMPLATE_DEFS"
				+ "    ON  TEMPLATE_DEFS.CATEGORY=M.CATEGORY"
				+ "    AND TEMPLATE_DEFS.KEYFIELD=M.KEYFIELD"
				+

				" LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='"
				+ clientID
				+ "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND r.SetNo=" + dtsSetNo;
		}
		strSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' "
				+ " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category "
				+ " AND y.KeyField=m.KeyField AND y.DTSNo="
				+ dtsNo
				+ " AND y.SetNo="
				+ dtsSetNo
				+ " AND y.ClientID='"
				+ clientID
				+ "' ";

		strSQL += " LEFT JOIN ZTBL_DTS_SETNAMES Z ON Z.CLIENTID='" + clientID
				+ "' AND Z.DTSNO=" + dtsNo + " AND Z.CATEGORY='" + categoryID
				+ "' AND Z.SETNO=" + dtsSetNo;
		strSQL += " LEFT JOIN (SELECT " + dtsSetNo + " SETNAME, '" + categoryID
				+ "' CATEGORY FROM DUAL)" + "ZZ ON ZZ.CATEGORY=m.Category";

		strSQL += " WHERE m.Category='" + categoryID + "' ";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+ " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+ " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND s.SetNo=" + dtsSetNo;
		}
		strCountSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' WHERE m.Category='"
				+ categoryID + "' ";

		/*
		 * if (!targetTableName.equals("")) { strSQL += " AND t.TableName='" +
		 * replaceString(targetTableName, "'", "''") + "'"; strCountSQL +=
		 * " AND t.TableName='" + replaceString(targetTableName, "'", "''") +
		 * "'"; }
		 */
		strSQL="SELECT  distinct Category, SN,  SETNAME, SourceDBID, "
				+ " SourceDatabase, SourceTable, "
				+ " SourceField, SourceFieldFormat, "
				+ " TargetTable, TargetField, FieldFormat, "
				+ " TargetField2Display, "
				+ " to_char(BusinessRule) BusinessRule, " 
				+ " TranslatedRule, Example, Matched, Priority  " 
				+" FROM " 
				+"( "+strSQL+") " 
				; 
				
			strSQL += " ORDER BY Category,SN";
		//System.out.println("getDTSSetDetailsExcel::strSQL:" + strSQL);

		try {

			myRS = this.executeQuery(strSQL);
			while (myRS.next()) {
				HashMap map = new HashMap();
				map.put("category", checkNull(myRS.getString("category")));
				map.put("sn", checkNull(myRS.getString("SN")));
				map.put("setname", checkNull(myRS.getString("setname")));
				map.put("sourcedbid", checkNull(myRS.getString("sourcedbid")));
				map.put("sourcedatabase", checkNull(myRS
						.getString("sourcedatabase")));
				map
						.put("sourcetable", checkNull(myRS
								.getString("sourcetable")));
				map
						.put("sourcefield", checkNull(myRS
								.getString("sourcefield")));
				map.put("sourcefieldformat", checkNull(myRS
						.getString("sourcefieldformat")));
				map
						.put("targettable", checkNull(myRS
								.getString("targettable")));
				map
						.put("targetfield", checkNull(myRS
								.getString("targetfield")));
				map
						.put("fieldformat", checkNull(myRS
								.getString("fieldformat")));
				map.put("targetfield2display", checkNull(myRS
						.getString("targetfield2display")));
				map.put("businessrule", checkNull(myRS
						.getString("businessrule")));
				map.put("translatedrule", checkNull(myRS
						.getString("translatedrule")));
				map.put("example", checkNull(myRS.getString("example")));
				map.put("matched", checkNull(myRS.getString("matched")));
				map.put("priority", checkNull(myRS.getString("priority")));
				dtsSetDetails.add(map);
			}
			myRS.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtsSetDetails;
	}
	
	public List getDTSSetDetailsToHP(String clientID, String dtsNo,
			String dtsSetNo, String categoryID) {
        int primaryTempId = this.getPrimaryTemplateID();
        int assignedTemplate = this.getAssignedTemplateID(clientID);
		List dtsSetDetails = new ArrayList();
        
		String sql1="t.TableName";
		String sql2="t.FieldName";
		String sql3="";
		if(categoryID.equalsIgnoreCase("VH CLAIMS")||categoryID.equalsIgnoreCase("VH ELIGIBILITIES")||categoryID.equalsIgnoreCase("VH RX CLAIMS")){
			sql1=" REPLACE(t.TableName,'VH','HP') ";
			sql2=" REPLACE(t.FieldName,map.VH,map.HP) ";
			sql3=" INNER JOIN vh_hp_mapping map ON  Upper(map.VH)=Upper(t.FieldName) AND map.Category = t.Category ";
		}

		strSQL = "SELECT m.Category, m.SN, Nvl(Z.SETNAME,ZZ.SETNAME) SETNAME, db.DatabaseId SourceDBID, "

				+ " db.DatabaseName SourceDatabase, s.TableName SourceTable, "
				+ " s.FieldName SourceField, s.FieldFormat SourceFieldFormat, "
				+  sql1 +"  TargetTable, t.KEYFIELD as TargetField, m.FieldFormat, "
				+  sql2 +" AS TargetField2Display, "
				+ " r.BusinessRule BusinessRule , r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+ sql3
				+ " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+
/*
 * CDF implementation, rsah, Oct 14 2011
 */
				" INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES "
				+ "    ON MAST.CLIENTID=TEMPLATES.CLIENTID "
				+ " INNER JOIN (SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_TEMPLATE_DEFS WHERE " +
						"TEMPLATEID IN ('"+primaryTempId+"','"+assignedTemplate+"') UNION " 
				+ "SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_CLIENT_KEYFIELDS WHERE CLIENTID='"+clientID+"' " +
						"AND CATEGORY='"+categoryID+"'" 
				+		") TEMPLATE_DEFS"
				+ "    ON  TEMPLATE_DEFS.CATEGORY=M.CATEGORY"
				+ "    AND TEMPLATE_DEFS.KEYFIELD=M.KEYFIELD"
				+

				" LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='"
				+ clientID
				+ "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND r.SetNo=" + dtsSetNo;
		}
		strSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' "
				+ " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category "
				+ " AND y.KeyField=m.KeyField AND y.DTSNo="
				+ dtsNo
				+ " AND y.SetNo="
				+ dtsSetNo
				+ " AND y.ClientID='"
				+ clientID
				+ "' ";

		strSQL += " LEFT JOIN ZTBL_DTS_SETNAMES Z ON Z.CLIENTID='" + clientID
				+ "' AND Z.DTSNO=" + dtsNo + " AND Z.CATEGORY='" + categoryID
				+ "' AND Z.SETNO=" + dtsSetNo;
		strSQL += " LEFT JOIN (SELECT " + dtsSetNo + " SETNAME, '" + categoryID
				+ "' CATEGORY FROM DUAL)" + "ZZ ON ZZ.CATEGORY=m.Category";

		strSQL += " WHERE m.Category='" + categoryID + "' ";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+ " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+ " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND s.SetNo=" + dtsSetNo;
		}
		strCountSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' WHERE m.Category='"
				+ categoryID + "' ";

		/*
		 * if (!targetTableName.equals("")) { strSQL += " AND t.TableName='" +
		 * replaceString(targetTableName, "'", "''") + "'"; strCountSQL +=
		 * " AND t.TableName='" + replaceString(targetTableName, "'", "''") +
		 * "'"; }
		 */
		strSQL="SELECT  distinct Category, SN,  SETNAME, SourceDBID, "
				+ " SourceDatabase, SourceTable, "
				+ " SourceField, SourceFieldFormat, "
				+ " TargetTable, TargetField, FieldFormat, "
				+ " TargetField2Display, "
				+ " to_char(BusinessRule) BusinessRule, " 
				+ " TranslatedRule, Example, Matched, Priority  " 
				+" FROM " 
				+"( "+strSQL+") " 
				; 
				
			strSQL += " ORDER BY Category,SN";
		System.out.println("getDTSSetDetailsExcel::strSQL:" + strSQL);

		try {

			myRS = this.executeQuery(strSQL);
			while (myRS.next()) {
				HashMap map = new HashMap();
				map.put("category", checkNull(myRS.getString("category")));
				map.put("sn", checkNull(myRS.getString("SN")));
				map.put("setname", checkNull(myRS.getString("setname")));
				map.put("sourcedbid", checkNull(myRS.getString("sourcedbid")));
				map.put("sourcedatabase", checkNull(myRS
						.getString("sourcedatabase")));
				map
						.put("sourcetable", checkNull(myRS
								.getString("sourcetable")));
				map
						.put("sourcefield", checkNull(myRS
								.getString("sourcefield")));
				map.put("sourcefieldformat", checkNull(myRS
						.getString("sourcefieldformat")));
				map
						.put("targettable", checkNull(myRS
								.getString("targettable")));
				map
						.put("targetfield", checkNull(myRS
								.getString("targetfield")));
				map
						.put("fieldformat", checkNull(myRS
								.getString("fieldformat")));
				map.put("targetfield2display", checkNull(myRS
						.getString("targetfield2display")));
				map.put("businessrule", checkNull(myRS
						.getString("businessrule")));
				map.put("translatedrule", checkNull(myRS
						.getString("translatedrule")));
				map.put("example", checkNull(myRS.getString("example")));
				map.put("matched", checkNull(myRS.getString("matched")));
				map.put("priority", checkNull(myRS.getString("priority")));
				dtsSetDetails.add(map);
			}
			myRS.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtsSetDetails;
	}
	
	
	public List getDTSSetDetailsToCDF(String clientID, String dtsNo,
			String dtsSetNo, String categoryID) {
        int primaryTempId = this.getPrimaryTemplateID();
        int assignedTemplate = this.getAssignedTemplateID(clientID);
		List dtsSetDetails = new ArrayList();

		String sql1="t.TableName";
		String sql2="t.FieldName";
		String sql3="";
		if(categoryID.equalsIgnoreCase("HP_CLAIMS")||categoryID.equalsIgnoreCase("HP_ELIGIBILITIES")||categoryID.equalsIgnoreCase("HP_RXCLAIMS")){
			sql1=" REPLACE(t.TableName,'HP','VH') ";
			sql2=" REPLACE(t.FieldName, map.HP, map.VH) ";
			sql3=" INNER JOIN vh_hp_mapping map ON  Upper(map.HP)=Upper(t.FieldName) " +
					" AND map.HPCategory = t.Category and upper(map.HP) NOT IN (SELECT duplicatehp FROM dulicatemap) ";
				
		}
		

		strSQL = "SELECT m.Category, m.SN, Nvl(Z.SETNAME,ZZ.SETNAME) SETNAME, db.DatabaseId SourceDBID, "

				+ " db.DatabaseName SourceDatabase, s.TableName SourceTable, "
				+ " s.FieldName SourceField, s.FieldFormat SourceFieldFormat, "
				+  sql1 +" TargetTable, t.KEYFIELD as TargetField, m.FieldFormat, "
				+  sql2 + "  AS TargetField2Display, "
				+ " r.BusinessRule BusinessRule , r.TranslatedRule, r.Example, x.FieldName Matched, y.Priority FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+ sql3
				+ " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+
/*
 * CDF implementation, rsah, Oct 14 2011
 */
				" INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES "
				+ "    ON MAST.CLIENTID=TEMPLATES.CLIENTID "
				+ " INNER JOIN (SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_TEMPLATE_DEFS WHERE " +
						"TEMPLATEID IN ('"+primaryTempId+"','"+assignedTemplate+"') UNION " 
				+ "SELECT CATEGORY,KEYFIELD FROM ZTBL_DTS_CLIENT_KEYFIELDS WHERE CLIENTID='"+clientID+"' " +
						"AND CATEGORY='"+categoryID+"'" 
				+		") TEMPLATE_DEFS"
				+ "    ON  TEMPLATE_DEFS.CATEGORY=M.CATEGORY"
				+ "    AND TEMPLATE_DEFS.KEYFIELD=M.KEYFIELD"
				+

				" LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='"
				+ clientID
				+ "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND s.SetNo=" + dtsSetNo;
		}

		strSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strSQL += " AND r.SetNo=" + dtsSetNo;
		}
		strSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' "
				+ " LEFT JOIN ztbl_DTS_Mapping_Highlights y ON y.Category=m.Category "
				+ " AND y.KeyField=m.KeyField AND y.DTSNo="
				+ dtsNo
				+ " AND y.SetNo="
				+ dtsSetNo
				+ " AND y.ClientID='"
				+ clientID
				+ "' ";

		strSQL += " LEFT JOIN ZTBL_DTS_SETNAMES Z ON Z.CLIENTID='" + clientID
				+ "' AND Z.DTSNO=" + dtsNo + " AND Z.CATEGORY='" + categoryID
				+ "' AND Z.SETNO=" + dtsSetNo;
		strSQL += " LEFT JOIN (SELECT " + dtsSetNo + " SETNAME, '" + categoryID
				+ "' CATEGORY FROM DUAL)" + "ZZ ON ZZ.CATEGORY=m.Category";

		strSQL += " WHERE m.Category='" + categoryID + "' ";

		strCountSQL = "SELECT COUNT(*) RecCount FROM ztbl_DTS_Mapping_Mast m "
				+ " INNER JOIN ztbl_DTS_Mapping_Target t ON t.Category = m.Category AND "
				+ " t.KeyField = m.KeyField and m.version=t.version "
				+ " INNER JOIN ztbl_DTS_DTS_Mast mast on mast.ClientID='"
				+ clientID
				+ "' "
				+ " and mast.DTSNo='"
				+ dtsNo
				+ "' and t.Version=mast.Version "
				+ " LEFT JOIN ztbl_DTS_Mapping_Source s ON s.Category = m.Category AND "
				+ " s.KeyField = m.KeyField AND s.ClientID='" + clientID + "' "
				+ " AND s.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND s.SetNo=" + dtsSetNo;
		}
		strCountSQL += " LEFT JOIN ztbl_DTS_Databases db on db.databaseId=s.databaseId "
				+ " LEFT JOIN ztbl_DTS_Mapping_Rule r ON r.Category = m.Category AND "
				+ " r.KeyField = m.KeyField AND r.ClientID='"
				+ clientID
				+ "' and r.Version=mast.Version " + " AND r.DTSno=" + dtsNo;

		if (!dtsSetNo.equals("0")) {
			strCountSQL += " AND r.SetNo=" + dtsSetNo;
		}

		strCountSQL += " LEFT JOIN ztbl_DTS_SourceTableSpace x ON x.TableName=s.TableName "
				+ " AND x.FieldName=s.FieldName AND x.DTSNo="
				+ dtsNo
				+ " AND x.ClientID='"
				+ clientID
				+ "' WHERE m.Category='"
				+ categoryID + "' ";

		/*
		 * if (!targetTableName.equals("")) { strSQL += " AND t.TableName='" +
		 * replaceString(targetTableName, "'", "''") + "'"; strCountSQL +=
		 * " AND t.TableName='" + replaceString(targetTableName, "'", "''") +
		 * "'"; }
		 */
		strSQL="SELECT  distinct Category, SN,  SETNAME, SourceDBID, "
				+ " SourceDatabase, SourceTable, "
				+ " SourceField, SourceFieldFormat, "
				+ " TargetTable, TargetField, FieldFormat, "
				+ " TargetField2Display, "
				+ " to_char(BusinessRule) BusinessRule, " 
				+ " TranslatedRule, Example, Matched, Priority  " 
				+" FROM " 
				+"( "+strSQL+") " 
				; 
				
			strSQL += " ORDER BY Category,SN";
		System.out.println("getDTSSetDetailsExcelCDF::strSQL:" + strSQL);

		try {

			myRS = this.executeQuery(strSQL);
			while (myRS.next()) {
				HashMap map = new HashMap();
				map.put("category", checkNull(myRS.getString("category")));
				map.put("sn", checkNull(myRS.getString("SN")));
				map.put("setname", checkNull(myRS.getString("setname")));
				map.put("sourcedbid", checkNull(myRS.getString("sourcedbid")));
				map.put("sourcedatabase", checkNull(myRS
						.getString("sourcedatabase")));
				map
						.put("sourcetable", checkNull(myRS
								.getString("sourcetable")));
				map
						.put("sourcefield", checkNull(myRS
								.getString("sourcefield")));
				map.put("sourcefieldformat", checkNull(myRS
						.getString("sourcefieldformat")));
				map
						.put("targettable", checkNull(myRS
								.getString("targettable")));
				map
						.put("targetfield", checkNull(myRS
								.getString("targetfield")));
				map
						.put("fieldformat", checkNull(myRS
								.getString("fieldformat")));
				map.put("targetfield2display", checkNull(myRS
						.getString("targetfield2display")));
				map.put("businessrule", checkNull(myRS
						.getString("businessrule")));
				map.put("translatedrule", checkNull(myRS
						.getString("translatedrule")));
				map.put("example", checkNull(myRS.getString("example")));
				map.put("matched", checkNull(myRS.getString("matched")));
				map.put("priority", checkNull(myRS.getString("priority")));
				dtsSetDetails.add(map);
			}
			myRS.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dtsSetDetails;
	}
	
	/**
	 * Method added to check duplicate names in existng dts. 
	 * @param clientID
	 * @param dtsNo
	 * @param category
	 * @param setName
	 * @return
	 */
	public boolean checkDuplicateSetNames (String clientID,String dtsNo,String category,String setName){
		boolean isDuplicate=false;
		String sql = "";
		ResultSet rsss2=null;
		int count1=0;
		sql = "SELECT count(setName) ct from  ZTBL_DTS_SETNAMES where "
				+ "  clientid='" + clientID + "' and dtsno=" + dtsNo
				+ " and category='" + category + "' and lower(trim(setname)) like '"+setName.toLowerCase().trim()+"'";
		rsss2 = this.executeQuery(sql);
		try {
			rsss2.next();
			count1 = rsss2.getInt("ct");
			if(count1>0){
				isDuplicate=true;
			}
			
		} catch (Exception e) {
			isDuplicate=true;
			System.out.println("Error while checking duplicate in dtsBean.checkDuplicateSetNames  >1< " + sql
					+ " and Name is " + setName);
		} finally{
			try{
			rsss2.close();}
			catch (Exception e) {
				System.out.println("Error while closing recordset in checkDuplicateSetNames >2< "+e );
			}
			
		}
		return isDuplicate;
		
	}  
	
	/**
	 * Method added to check duplicate bucket names. 
	 * @param clientID
	 * @param dtsNo
	 * @param BucketName
	 * @return
	 */
	public boolean checkDuplicateBucketName (String clientID,String dtsNo,String BucketName){
		boolean isDuplicate=false;
		String sql = "";
		ResultSet rsss2=null;
		int count1=0;
		sql = "SELECT count(BucketName) ct from  ZTBL_DTS_Bucket where "
				+ "  clientid='" + clientID + "' and dtsno=" + dtsNo
				+ "  and lower(trim(BucketName)) like '"+BucketName.toLowerCase().trim()+"'";
		rsss2 = this.executeQuery(sql);
		try {
			rsss2.next();
			count1 = rsss2.getInt("ct");
			if(count1>0){
				isDuplicate=true;
			}
			
		} catch (Exception e) {
			isDuplicate=true;
			System.out.println("Error while checking duplicate in dtsBean.checkDuplicateBucketName  >1< " + sql
					+ " and Name is " + BucketName);
		} finally{
			try{
			rsss2.close();}
			catch (Exception e) {
				System.out.println("Error while closing recordset in checkDuplicateBucketName >2< "+e );
			}
			
		}
		return isDuplicate;
		
	}   
	public int getPrimaryTemplateID() {
		int primaryTemplateID = 0;
		try {
			String sql = "SELECT templateid from ZTBL_DTS_TEMPLATES where templatetype='P'";
			myRS = this.executeQuery(sql);
			while (myRS.next()) {
				primaryTemplateID = myRS.getInt("templateid");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return primaryTemplateID;
	}
	public int getClientCategoryFieldCount(String clientID, String category) {
		
		strSQL = " select count(distinct keyfield) cnt from ZTBL_DTS_CLIENT_KEYFIELDS where clientid= '"
				+ clientID + "' and category='" + category + "' ";
		this.getList(strSQL, "Client category count");
		int count = 0;
		try {
			if (myRS.next()) {
				count = myRS.getInt("cnt");
			}
			myRS.close();
		} catch (Exception e) {
			this
					.addMessage("<font color='red'>[sqlBean] ERROR: Client Additional category count</font>");
		}
		return count;
	}
	public boolean getNonClientCategoryFields(String clientID,
			String category) {	
		int primaryTempId = this.getPrimaryTemplateID();
		int assignedTemplateId = this.getAssignedTemplateID(clientID);
		
		
		strSQL = " select distinct keyfield from ztbl_dts_mapping_mast a where category='"
			+ category
			+ "' "
			+ " and not exists ("
			+ " select distinct keyfield from ztbl_dts_template_defs b "
			+ " where a.category=b.category and a.keyfield=b.keyfield and b.category='"
			+ category
			+ "' AND B.TEMPLATEID in ("+assignedTemplateId+","+primaryTempId+")" 
			+ " union select distinct keyfield from ZTBL_DTS_CLIENT_KEYFIELDS c where" +
					" a.category=c.category and a.keyfield=c.keyfield and category='"+category+ "' "
				+ " and clientid='"+clientID+"') order by keyfield"; 
		//System.out.println("getNonClientCategoryFields::SQL::"+strSQL);  

		return this.getList(strSQL, "Client Specific category fields");
	}
	public boolean getClientCategoryFields(String clientID,
			String category, int start, int end) {
		strSQL = " select keyfield from ( select keyfield, rownum rn from ("
			+ "	select distinct keyfield from ZTBL_DTS_CLIENT_KEYFIELDS where clientid= "
			+ clientID + " and category='" + category
			+ "' and keyfield is not null order by keyfield) )"
			+ " where rn between " + start + " and " + end
			+ " order by rn ";		 
		//System.out.println("getNonClientCategoryFields::SQL::"+strSQL);   

		return this.getList(strSQL, "Client Specific category fields");
	}	
	public boolean addFieldToClientCategory(String clientID,
			String category, String field) {		
		strSQL = " insert into  ZTBL_DTS_CLIENT_KEYFIELDS(CLIENTID, CATEGORY, KEYFIELD) values ('"
				+ clientID + "','" + category + "','" + field + "' )";
		return this.execute(strSQL);
	}
	public boolean removeFieldFromClientCategory(String clientID,
			String category, String field) {		
		strSQL = " delete from   ZTBL_DTS_CLIENT_KEYFIELDS where clientid='" + clientID
				+ "' and category='" + category + "' and keyfield='" + field
				+ "'";
		return this.execute(strSQL);
	}
	public int getAssignedTemplateID(String clientID) {
		int assignedTemplateID = 0;
		try {
			String sql = "SELECT templateid from ZTBL_DTS_CLIENT_TEMPLATES where clientid='"+clientID+"'";
			myRS = this.executeQuery(sql);
			while (myRS.next()) {
				assignedTemplateID = myRS.getInt("templateid");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return assignedTemplateID;
	}
	/*
	 * Desc: List of clients which have assigned templates
	 */
	public boolean getClientsWithTemplate() {		
		strSQL = " select a.clientId, b.clientName from ztbl_dts_client_templates a, ztbl_dts_clients b where a.clientId=b.clientId order by b.clientName";
		return this.getList(strSQL, "clients with template assigned");
	}

	public boolean getCategoryList(String clientID) {
		 int primaryTempId = this.getPrimaryTemplateID();
		 int assignedTemplateId = this.getAssignedTemplateID(clientID);
		//strSQL = " select distinct category from ztbl_dts_mapping_mast order by category";		
		strSQL =  "SELECT DISTINCT a.sn, "
			+ "                a.category, "
			+ "                a.categorydesc, "
			+ "                b.clientid "
			+ "FROM   ztbl_dts_categories a, "
			+ "       ztbl_dts_client_templates b, "
			+ "       ztbl_dts_template_defs c, "
			+ "       ztbl_dts_clients client "
			+ "WHERE  a.category = c.category "
			+ "       AND client.clientid = b.clientid "
			+ "       AND c.templateid IN (SELECT templateid "
			+ "                            FROM   ztbl_dts_templates "
			+ "                            WHERE  templatetype = 'P' "
			+ "                            UNION "
			+ "                            SELECT templateid "
			+ "                            FROM   ztbl_dts_client_templates "
			+ "                            WHERE  clientid = '"+clientID+"') "
			+ "       AND b.clientid = '"+clientID+"'"
			+ "       AND Substr(a.category, 1, 2) LIKE CASE "
			+ "                                           WHEN Length(client.clienttype) > 2 "
			+ "                                         THEN '%' "
			+ "                                           ELSE client.clienttype "
			+ "                                         END" 
			+ "  order by a.category ";
		return this.getList(strSQL, "All category list"); 
		

	}
	public boolean findSetAndCategoryInBucket(String bucketID,String category,String setName,String viewType){
		boolean returnString = false;
		int cnt = 0;		
		setName=setName.replaceAll("'", "''"); 
		if(viewType.equalsIgnoreCase("Payer"))
		{
			returnString = true;
		} else {
		try {
		strSQL = " select count(*) RecCount from ztbl_dts_bucket_details where bucketid='"+bucketID+"' " +
				"and category='"+category+"'and setname='"+setName+"'";
		//System.out.println("findSetAndCategoryInBucket::strSQL::"+strSQL); 
		if( this.executeQuery(strSQL)!= null )
		{
		myRS = this.executeQuery(strSQL);
		if(myRS.next())
		cnt = myRS.getInt(1);		
		}
		if(cnt > 0)
		{
			returnString = true;
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		//System.out.println(returnString);
		return returnString;
	}
	
	 public boolean garbageCleanupForClient(String clientId){
		 int primaryTemplateId = this.getPrimaryTemplateID();
		 int assignedTemplateId = this.getAssignedTemplateID(clientId);
		 
		return false;
	}

}
