/*	FileName : d2Systems.TextEncoder.java
 @author : Deepak
 @date  :

  MODIFICATIONS
 SN		DATE		BY		COMMENT
 3.4.1.01	12/10/2002	Deepak		Encoding for +,- and / added
 */

package d2Hawkeye.dts;

/** Encodes for asigning value in form components*/
public class TextEncoder {
  public static String encode(String p) {
    if (p == null || "".equals(p.trim())) {
      return "";
    }
    int pLen = p.length();
    int count = 0;
    char c;
    StringBuffer sb = new StringBuffer(pLen + 1);
    for (count = 0; count < pLen; count++) {
      c = p.charAt(count);
      switch (c) {
        case '\'':
          sb.append("&#39;");
          break; //Quote
        case '\"':
          sb.append("&#34;");
          break; //Double Quote
        case '<':
          sb.append("&lt;");
          break; //
        case '>':
          sb.append("&gt;");
          break;
        case '&':
          sb.append("&amp;");
          break;
          //3.4.1.01
        case '+':
          sb.append("&#43;");
          break; //plus
        case '-':
          sb.append("&#45;");
          break;
        case '/':
          sb.append("&#47;");
          break;
        default:
          sb.append(c);
      }
    }
    return sb.toString();
  }

  /*--- Encodes slash, quote and double quote only for JavaScript --*/
  public static String encodeJS(String p) {
    if (p == null || "".equals(p.trim())) {
      return "";
    }
    int pLen = p.length();
    int count = 0;
    char c;
    StringBuffer sb = new StringBuffer(pLen + 1);
    for (count = 0; count < pLen; count++) {
      c = p.charAt(count);
      switch (c) {
        case '\'':
          sb.append("\\\'");
          break; //Quote
        case '\"':
          sb.append("\\\"");
          break; //Double Quote
        case '\r':
          sb.append("");
          break;
        case '\t':
          sb.append("");
          break;
        case '\f':
          sb.append("");
          break;
        case '\n':
          sb.append("");
          break;
        default:
          sb.append(c);
      }
    }
    return sb.toString();
  }
}
