package d2Hawkeye.dts;

import java.util.*;

import d2Hawkeye.dts.structure.*;

public class DTSMap extends sqlBean{
  HashMap destTables = new HashMap();
  HashMap destFields = new HashMap();
  HashMap sourceTables = new HashMap();
  int setCount=0;

  public DTSMap() {
//    super.debug(true);
  }
  public void getTables(String clientId, String dtsNo){
    dtsBean bean = new dtsBean();
    bean.executeQuery("", clientId, "", dtsNo, "");
    while(this.moveNext()){
      // I think this will also work
      // make structure based on this data
    }
  }
  private String formatField(String field, String type) {
    String str2ret;
    if(type==null || type.trim().equals("") || type.trim().equalsIgnoreCase("null") )
      return field;
    str2ret = " CONVERT(" + type + ", " + field + ")";
    return str2ret;
  }

  public void getTargetTables(String clientId, String dtsNo,String category,String setNo){
    String query = "";
    query += " select mm.SN, dm.ClientID, dm.DTSNo, mt.Category, mt.KeyField,"+
        //" mt.TableName, mt.FieldName, mm.FieldFormat, tti.TableId, tti.Code, tti.[Description] "+
			" mt.TableName, mt.FieldName, mm.FieldFormat, " +
			" tti.TableId, tti.Code, tti.Description "+  
			" from " +
			"	ztbl_DTS_Mapping_Target mt " +
			" inner join " +
			"	ztbl_DTS_DTS_Mast dm " +
			" on " +
			"	mt.Version=dm.Version "+
			" inner join " +
			"	ztbl_DTS_Mapping_Mast mm " +
			" on " +
			"	mm.Category=mt.Category " +
			"	AND mm.KeyField=mt.KeyField " +
			"	AND mm.Version=mt.Version "+
		//	" inner join " +     // changed to left join to include those not in tti tables too
			" left join " +
			"	ztbl_DTS_TargetTableInfo tti " +
			" on " +
			"	tti.TableName=mt.TableName "+
		
    /**
     * Added for integrating template implementation
     * Subash Devkota
     * 06/05/2007
     */
		    " INNER JOIN ZTBL_DTS_CLIENT_TEMPLATES TEMPLATES " +
		    "    ON dm.CLIENTID=TEMPLATES.CLIENTID " +
		    " INNER JOIN ZTBL_DTS_TEMPLATE_DEFS TEMPLATE_DEFS" +
		    "    ON TEMPLATES.TEMPLATEID=TEMPLATE_DEFS.TEMPLATEID" +
		    "    AND TEMPLATE_DEFS.CATEGORY=mm.CATEGORY" +
		    "    AND TEMPLATE_DEFS.KEYFIELD=mm.KEYFIELD"+
    /************************************** End of changes for template integration ***************************************************************************/
 
    " where dm.ClientID='"+clientId+"' AND dm.DTSNo="+dtsNo;
   /***
    * Modified by Ram Gautam, Sep 3,2012
    * Added condition for category 
    */
    if(category.equals("")){
    	query+=" and mt.Category='"+category+"'";
    }

    System.out.println("geting target table in draft:"+query);
    
    this.executeQuery(query);
    while(this.moveNext()){
      DestTable dt;
      String atblName = this.getData("TableName");
      String tableId = ""+ this.getInt("TableId");
      if(this.destTables.containsKey(tableId+"."+atblName)){
        dt = (DestTable)this.destTables.get(tableId+"."+atblName);
      }else{
        this.addMessage("[getTargetTables] adding target tables "+atblName);
        dt = new DestTable(this.getData("TableName"));
        dt.setCategory(this.getData("Category"));
        dt.setCode(this.getData("Code"));
        dt.setDesc(this.getData("Description"));
        dt.setId(this.getInt("TableId"));
        dt.setProcessed(false);
        this.destTables.put(tableId+"."+atblName, dt);
      }
      DestField df;
      String dstField = this.getData("FieldName");
      if(this.destFields.containsKey(dt.getName()+"."+dstField)){
        df = (DestField)this.destFields.get(dt.getName()+"."+dstField);
      }else{
        this.addMessage("[getTargetTables] adding target tables field "+dstField);
        df = new DestField(dstField);
        df.setFieldFormat(this.getData("FieldFormat"));
        dt.addField(df);
        df.setSN(this.getInt("SN"));
        this.destFields.put((dt.getName()+"."+dstField), df);
      }
    }
  }
  public void getSourceTables(String clientId, String dtsNo,String category,String setNo){
    String query = "select t.TableName TargetTable, t.FieldName TargetField, "+
        " t.Category, t.KeyField, s.SetNo, s.TableName SourceTable, s.FieldName SourceField, "+
        " s.FieldFormat SourceFieldFormat, s.DatabaseID SourceDatabaseID "+
        " from ztbl_DTS_Mapping_Target t, ztbl_DTS_Mapping_Source s, ztbl_DTS_DTS_Mast m "+
        " where t.Version=m.Version and s.ClientID=m.ClientID and s.DTSNo=m.DTSNo "+
        " and t.Category=s.Category and t.Keyfield=s.Keyfield "+
        " and s.ClientID='"+clientId+"' and s.DTSNo="+dtsNo;
    /***
     * Modified by Ram Gautam, Sep 3,2012
     * Added condition for category 
     */
   if(category.equals("")){
    	query+=" and t.Category='"+category+"'";
    }
     if(setNo.equals("")){
    	query+=" and s.SetNo='"+setNo+"'";
    }
    
    System.out.println("getSourceTables in draft:"+query);
    this.executeQuery(query);
    while(this.moveNext()){
      String stblName = this.getData("SourceTable");
      SourceTable st;
      if(this.sourceTables.containsKey(stblName)){
        st = (SourceTable) this.sourceTables.get(stblName);
      }else{
         st = new SourceTable(stblName);
         this.addMessage("[getTargetTables] adding source tables "+stblName);
      }
      SourceField sf = new SourceField(this.getData("SourceField"));
      this.addMessage("[getTargetTables] adding source table field "+sf.getName());
      sf.setFieldFormat(this.getData("SourceFieldFormat"));
      sf.setSetNo(this.getInt("SetNo"));
      // count sets --
      if(sf.getSetNo()>this.setCount)
        this.setCount = sf.getSetNo();
      // -------------
      sf.setTable(st);
      DestField df = (DestField)this.destFields.get(this.getData("TargetTable")+"."+this.getData("TargetField"));
      this.addMessage("[getTargetTables] adding source field to dest field - "+this.getData("TargetTable")+"."+this.getData("TargetField"));
      if(df!=null){
        df.addSource(sf);
	  }else{
	  	  	this.addMessage("<font color='red'>Anomalous result: source field exists without having target field specified</font>");
	  }
    }
  }
  public void setBusinessRules(String clientId, String dtsNo,String category,String setNo){
    String query = "select t.TableName TargetTable, t.FieldName TargetField, "+
      " t.Category, t.KeyField, mr.SetNo, mr.BusinessRule, mr.Example, mr.TranslatedRule "+
      " from ztbl_DTS_Mapping_Target t, ztbl_dts_mapping_rule mr, ztbl_DTS_DTS_Mast m "+
      " where t.Version=m.Version and mr.ClientID=m.ClientID and mr.DTSNo=m.DTSNo "+
      " and t.Category=mr.Category and t.Keyfield=mr.Keyfield "+
      " and mr.ClientID='"+clientId+"' and mr.DTSNo="+dtsNo;
    /***
     * Modified by Ram Gautam, Sep 3,2012
     * Added condition for category 
     */
    if(category.equals("")){
    	query+=" and t.Category='"+category+"'";
    }
    if(setNo.equals("")){
    	query+=" and mr.SetNo='"+setNo+"'";
    }
    
    System.out.println("setBusinessRules in draft:"+query);
    this.executeQuery(query);
    while(this.moveNext()){
      DestField df = (DestField)this.destFields.get(this.getData("TargetTable") +
          "." + this.getData("TargetField"));
      this.addMessage("[getTargetTables] adding business rules to dest field - "+this.getData("TargetTable") +
          "." + this.getData("TargetField"));
      if(df!=null){
        df.setBusinessRule(this.getData("BusinessRule") + "");
        df.setExample(this.getData("Example") + "");
        df.setTranslatedRule(this.getData("TranslatedRule"));
      }else{
	  	this.addMessage("<font color='red'>Anomalous result: Business rule exists without having target field specified</font>");
	  }
    }
  }

  public String generateDTSDraft(String clientId, String dtsNo,String category,String setNo){
    String draft="", fields="", values="";
//     getting target tables
    this.getTargetTables(clientId, dtsNo,category,setNo);
//     source tables
    this.getSourceTables(clientId, dtsNo,category,setNo);
//     and business rules
    this.setBusinessRules(clientId, dtsNo,category,setNo);
    DestFieldComparator cmp = new DestFieldComparator();
//-------------------------------------------------------------------//
    String [] destTbls = new String [this.destTables.size()];
    this.destTables.keySet().toArray(destTbls);
    Arrays.sort(destTbls);
// ------------------------------------------------------------------//
    this.addMessage("[getTargetTables] destTables length : "+destTbls.length);
    if(this.setCount==0){
	  draft += "\n***** Error: No Set Defined for this DTS ***/ \n";
	}

    for(int curSet=this.setCount; curSet<=this.setCount; curSet++){
      draft += "\n/**************************************************************** \n";
      draft += "\n                    Working for Set Number - "+curSet+"          \n";
      draft += "\n****************************************************************/ \n";
	  if(destTbls.length==0){
		  draft += "\n***** Error: No destination table found ***/ \n";
	  }
      for (int j = 0; j < destTbls.length; j++) {
        fields = "";
        values = "";
        DestTable dt = (DestTable)this.destTables.get(destTbls[j]);
        DestField[] dfs = new DestField[dt.getFields().size()];
        dt.getFields().toArray(dfs);
        Arrays.sort(dfs, cmp);
        // ------------------------------------------------------------------//
        draft += "-- Code: " + dt.getCode() + "\n";
        draft += "-- Description: " + dt.getDesc() + "\n";
        draft += "-- Category: " + dt.getCategory() + "\n";
        // ------------------------------------------------------------------//
        draft += "INSERT INTO " + dt.getName();
        HashMap tableAlias = new HashMap(); // for each fields
        for (int i = 0; i < dfs.length; i++) {
          fields += "\t" + dfs[i].getName();
          // ------------------------------------------------------------------//
          HashSet hs = dfs[i].getSource();
          SourceField[] sfs = new SourceField[hs.size()];
          hs.toArray(sfs);
          // ------------------------------------------------------------------//
          if (sfs.length == 0) {
            values += "\t NULL " + dfs[i].getName();
          }
          else if (sfs.length == 1) {
            if (!tableAlias.containsKey(sfs[0].getTableName())) {
              tableAlias.put(sfs[0].getTableName(),
                             ( (char) ('a' + tableAlias.size())) + "");
            }
            if(sfs[0].getSetNo()==curSet){
              values += "\t ";
              if(sfs[0].getFieldFormat().replaceAll(" ","").equalsIgnoreCase(dfs[0].getFieldFormat().replaceAll(" ",""))){
                values += tableAlias.get(sfs[0].getTableName()) +
                                     "" + "." + sfs[0].getName();
              }else{
                values += this.formatField(tableAlias.get(sfs[0].getTableName()) +
                                     "" + "." + sfs[0].getName(),
                                     dfs[i].getFieldFormat());
              }
              values += " " + dfs[i].getName();

            }else{
              values += "\t NULL " + dfs[i].getName();
            }
          }
          else {
            values += "\t";
            String s = "";
            for (int k = 0; k < sfs.length; k++) {
              if(sfs[k].getSetNo()==curSet){
                if (!tableAlias.containsKey(sfs[k].getTableName())) {
                  tableAlias.put(sfs[k].getTableName(),
                                 ( (char) ('a' + tableAlias.size())) + "");
                }
                s += "<" +
                    tableAlias.get(sfs[k].getTableName()) +
                    "." +sfs[k].getName() +
                    ">";
                if (k < sfs.length - 1) {
                  s += " , ";
                }
              }
              if (k == sfs.length - 1) {
                if(s.endsWith(", ")){
                  s = s.substring(0, s.lastIndexOf(",")-1);
                }
                values += this.formatField("<"+s+">", dfs[i].getFieldFormat())+" " + dfs[i].getName();
              }
            }
          }
          if (i < dfs.length - 1) {
            fields += ", \n";
            values += ", \n";
          }
          else {
            fields += " \n";
            values += " \n";
          }
          if (dfs[i].getBusinessRule() != null || dfs[i].getExample() != null ||
              dfs[i].getTranslatedRule() != null) {
            values += "\t\t/************************************************************* \n";
            values += "\t\t\tBusiness Rule: " + dfs[i].getBusinessRule() + "\n";
            if(dfs[i].getExample()!=null
               && !dfs[i].getExample().equals("")
               && !dfs[i].getExample().equalsIgnoreCase("null")){
              values += "\t\t\tExample: " + dfs[i].getExample() + "\n";
            }
            if(dfs[i].getTranslatedRule()!=null
               && !dfs[i].getTranslatedRule().equals("")
               && !dfs[i].getTranslatedRule().equalsIgnoreCase("null")){
              values += "\t\t\tTranslated Rule: " + dfs[i].getTranslatedRule() +
                  "\n";
            }
            values += "\t\t*************************************************************/ \n";
          }
        }
        draft += "\n (\n" + fields + "\n)\n Select \n" + values + " FROM \n";
        if (tableAlias.size() == 0) {
          draft += "NULL \n";
        }
        else {
          String[] tblNames = new String[tableAlias.size()];
          tableAlias.keySet().toArray(tblNames);
          HashMap hm = new HashMap();
          for (int iii = 0; iii < tblNames.length; iii++) {
            hm.put(tableAlias.get(tblNames[iii]), tblNames[iii]);
          }
          String aliases[] = new String[hm.size()];
          hm.keySet().toArray(aliases);
          Arrays.sort(aliases);
          for (int iii = 0; iii < aliases.length; iii++) {
            draft += hm.get(aliases[iii]) + " " + aliases[iii];
            if (iii < tblNames.length - 1) {
              draft += ", ";
            }
          }
        }
        draft += "\n\n";
      }
    }
    return draft;
  }
  public void cleanup(){}
}
