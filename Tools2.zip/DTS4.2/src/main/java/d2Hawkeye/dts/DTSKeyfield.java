/*******************************************************************************************************
 *
 * File		: DTSKeyfield.java
 * Created by	: Pawan K. Shrestha
 * Date		:
 *
 * Description	:
 *
 * Modifications	:
 *
 * Date:					Changed by:					Description
 * -----------------------------------------------------------------------------------------------
 *
 *******************************************************************************************************/

package d2Hawkeye.dts;

import java.util.*;

public class DTSKeyfield {
  public String SN = "";
  public String category = "";
  public String keyField = "";
  public String version = "";
  public String fieldFormat = "";
  public Vector tableName;
  public Vector fieldName;
  public Vector tableDotField;
  public String targetTable="";
  public String targetField="";

  public DTSKeyfield(String SN, String category, String keyField, String version,
                     String fieldFormat
                     , String tableName, String fieldName) {
    this.tableName = new Vector();
    this.fieldName = new Vector();
    this.tableDotField = new Vector();
    this.addValues(SN, category, keyField, version, fieldFormat, tableName, fieldName);
  }

  public void addValues(String SN, String category, String keyField,
                        String version, String fieldFormat
                        , String tableName, String fieldName) {
    this.SN = SN;
    this.category = category;
    this.keyField = keyField;
    this.version = version;
    this.fieldFormat = fieldFormat;

    this.targetTable = tableName;
     this.targetField = fieldName;

    if (!this.tableDotField.contains(tableName + "." + fieldName)) {
      this.tableName.add(tableName);
      this.fieldName.add(fieldName);
      this.tableDotField.add(tableName + "." + fieldName);
    }

  }

}
