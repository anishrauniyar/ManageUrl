package d2Hawkeye.dts.apTable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SQLLoaderFileCleaner {

	
	
	public static void main(String args[]){
		new SQLLoaderFileCleaner().processFilesForDelete();
	}
	
	public void processFilesForDelete(){	
		List files= new ArrayList();
		long today=new Date().getTime();
		long yesterday=today;//-1000*60*60*1;//24;   // reduce 24 hours from now
		
		String latestFile="SQLLdr"+yesterday;
		Date dt= new Date();
		String[] command = new String[2];
		command[0]= "ls";
		command[1]= "/home/sdevkota/xyz/WebDTSSvn/.deployables/WebDTSSvn/SqlLoaderFiles";
		
		try{
			Process p=Runtime.getRuntime().exec(command);
			try {
				p.waitFor();
			} catch( InterruptedException ie ) {
				ie.printStackTrace();
			}
			
			BufferedReader in = new BufferedReader( new InputStreamReader(p.getInputStream()));
			String line=null;
			while((line=in.readLine() )!=null)
			{
				String file=line.trim();
				file=file.substring(0,file.indexOf(".")); // Remove the extension and dot part
				if((!files.contains(file)) && (file.compareTo(latestFile) < 0)){
					files.add(file);
				}
			}
			
			for(int i=0;i<files.size();i++){
				this.deleteFile((String)files.get(i));
			}
			
		}catch( Exception e){
			e.printStackTrace();
		}
	}
	
	
	public void deleteFile(String fileName){
		String[] command = new String[3];
		command[0]= "rm";
		command[1]= "-f";
		command[2]= "/home/sdevkota/xyz/WebDTSSvn/.deployables/WebDTSSvn/SqlLoaderFiles/"+fileName+"*";
		
		for(int i=0;i<command.length;i++){
			System.out.print(command[i]+" ");
		}
		
		try{
			Process p=Runtime.getRuntime().exec(command);
			try {
				p.waitFor();
			} catch( InterruptedException ie ) {
				ie.printStackTrace();
			}
		
		
			BufferedReader in = new BufferedReader( new InputStreamReader(p.getInputStream()));
			String line=null;
			while((line=in.readLine() )!=null)
			{
				
				System.out.println(line);
			}
		}catch( Exception e){
			e.printStackTrace();
		}
		
	}
	
}
