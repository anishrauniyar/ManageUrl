package d2Hawkeye.dts.apTable;

import javax.servlet.http.HttpServlet;
/**
 * Servlet class for deleting temporary tables
 * @author Subash Devkota
 *
 */
public class TableCleanerServlet  extends HttpServlet{

		static final long serialVersionUID=5123;
		
		public void init(){
			new TempTableCleaner(getServletConfig());
		}

}
