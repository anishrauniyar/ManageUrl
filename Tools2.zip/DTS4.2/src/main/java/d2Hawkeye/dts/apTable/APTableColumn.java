package d2Hawkeye.dts.apTable;

/**
 * Class to represent AP table column
 * @author Subash Devkota
 *
 */
public class APTableColumn {

	private String name;
	private String dataType=null;
	private boolean validName;   // if the column name if valid under oracle convention
	private int maxlength;
	private int colNumber;
	private String dataTypeRepresentation=null; // Data type representation in jsp page 
	
	private boolean isEnclosed=false;
	
	public String getDataTypeRepresentation() {
		return dataTypeRepresentation;
	}

	public void setDataTypeRepresentation(String dataTypeRepresentation) {
		this.dataTypeRepresentation = dataTypeRepresentation;
	}

	public APTableColumn(String name, int num){
		this.name=name;
		this.colNumber=num;
	}
	
	
	public boolean isEnclosed() {
		return isEnclosed;
	}

	public void setEnclosed(boolean isEnclosed) {
		this.isEnclosed = isEnclosed;
	}

	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getName() {
		return name;
	}
	public int getColNumber() {
		return colNumber;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isValidName() {
		validName=this.checkName();
		return validName;
	}
	
	/*public void setValidName(boolean validName) {
		this.validName = validName;
	}
*/
	public int getMaxlength() {
		return maxlength;
	}

	public void setMaxlength(int maxlength) {
		this.maxlength = maxlength;
	}
	
	/**
	 * Check for valid column name
	 * @return
	 */
	private boolean checkName(){
		char[] nameChar=name.toCharArray();
		for(int i=0;i<nameChar.length;i++){
			char c=nameChar[i];
			if((c>='a' && c<='z') || (c>='A' && c<='Z')|| (c>='0' && c<='9') || c=='_'){
				continue;
			}else{
				return false;
			}
		}
		return true;
	}
	
}
