package d2Hawkeye.dts.apTable;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 * Class for validating table parameters
 * @author Subash Devkota
 *
 */
public class TableValidator {

	
	String oracleReservedWords=",ACCESS,ELSE,MODIFY,START," +
						"ADD,EXCLUSIVE,NOAUDIT,SELECT,"+
						"ALL,EXISTS,NOCOMPRESS,SESSION,"+
						"ALTER,FILE,NOT,SET,"+
						"AND,FLOAT,NOTFOUND,SHARE,"+
						"ANY,FOR,NOWAIT,SIZE,"+
						"ARRAYLEN,FROM,NULL,SMALLINT,"+
						"AS,GRANT,NUMBER,SQLBUF,"+
						"ASC,GROUP,OF,SUCCESSFUL,"+
						"AUDIT,HAVING,OFFLINE,SYNONYM,"+
						"BETWEEN,IDENTIFIED,ON,SYSDATE,"+
						"BY,IMMEDIATE,ONLINE,TABLE,"+
						"CHAR,IN,OPTION,THEN,"+
						"CHECK,INCREMENT,OR,TO,"+
						"CLUSTER,INDEX,ORDER,TRIGGER,"+
						"COLUMN,INITIAL,PCTFREE,UID,"+
						"COMMENT,INSERT,PRIOR,UNION,"+
						"COMPRESS,INTEGER,PRIVILEGES,UNIQUE,"+
						"CONNECT,INTERSECT,PUBLIC,UPDATE,"+
						"CREATE,INTO,RAW,USER,"+
						"CURRENT,IS,RENAME,VALIDATE,"+
						"DATE,LEVEL,RESOURCE,VALUES,"+
						"DECIMAL,LIKE,REVOKE,VARCHAR,"+
						"DEFAULT,LOCK,ROW,VARCHAR2,"+
						"DELETE,LONG,ROWID,VIEW,"+
						"DESC,MAXEXTENTS,ROWLABEL,WHENEVER,"+
						"DISTINCT,MINUS,ROWNUM,WHERE,"+
						"DROP,MODE,ROWS,WITH,";
	
	/**
	 * Return comma separated list of objects with oracle reserved words
	 * @param tblNCols
	 * @return
	 */
	 private String getOracleReservedWords(String[] tblNCols){
		 String reservedWords="";
		 for(int i=1;i<tblNCols.length;i++){
			 String objName=tblNCols[i].toUpperCase();
			 if(oracleReservedWords.indexOf(","+objName+",")>-1){
				 reservedWords+=objName+",";
			 }
		 }
		 return reservedWords;
	 }
	 
    
	/**
	 * Check if there are duplicate column names. Return false if column names are duplicate
	 * @param names
	 * @return
	 */
	private boolean checkColumns(String[] names){
		
		for(int i=0;i<names.length-1;i++){
			for(int j=i+1;j<names.length;j++){
				if(names[i].equalsIgnoreCase(names[j])){
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Return the comma separated list of duplicate columns
	 * @param names
	 * @return
	 */
	private String getDuplicateColumns(String[] names){
		String dupNames="";
		for(int i=0;i<names.length-1;i++){
			for(int j=i+1;j<names.length;j++){
				if(names[i].equalsIgnoreCase(names[j])){
					dupNames+=names[i];
				}
			}
		}
		return dupNames;
	}
	
	/**
	 * Check if the tablename is valid. The tableName is invalid if the table name already exists.
	 * @param tableName
	 * @return
	 */
	private boolean checkTableName(String tableName){
		DatabaseOperator dbOperator = new DatabaseOperator();
		dbOperator.connectHawkeyRule();
		try{
			if(dbOperator.doesTableExist(tableName)){
				return false;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			dbOperator.takeDown();
		}
		return true;
	}
	
	/**
	 * Method to check if the passed column numbers in the table are valid as primary key
	 * @param tempTblNKeyCols String array with temporaty tableName at [0] and then the column number for the primary keys.
	 * @return The list of violation cases with violation count.
	 */
	private List checkPrimaryKeys(String[] tempTblNKeyCols){
		String tempTableName=tempTblNKeyCols[0];
		List columnList= new ArrayList();
		
		for(int i=1;i<tempTblNKeyCols.length;i++){
			columnList.add("col"+tempTblNKeyCols[i]);
		}
		
		List violation= new ArrayList();
		
		if(columnList.size()==0){
			return violation;
		}
		
		DatabaseOperator dbOperator = new DatabaseOperator();
		dbOperator.connectHawkeyRule();
		try{
			violation=dbOperator.getPrimaryKeyViolation(tempTableName, columnList);
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			dbOperator.takeDown();
		}
		return violation;
	}
	
	
	/**
	 * Check whole table parameters. Check if table alreay exists and if the table name and column names are valid.
	 * This method is called by javascript while validating table parameters through DWR. 
	 * @param tblNCols  String array with TablePrefix at [0], tableName at [1] and then column names. 
	 * @param tempTblNKeyCols String array containing TempTableName at [0] and then list of primary key column numbers . 
	 * @return Strign array containing validation summary at index[0] and complete message at index [1].
	 */
	public String[] checkTableAndColumns(String[] tblNCols, String[] tempTblNKeyCols) {
		String[] result=new String[2];
		String tablePrefix=tblNCols[0];
		String tableName=tblNCols[1];
		int failCount=0;
		String cols[]= new String[tblNCols.length -2];
		for(int i=2; i<tblNCols.length;i++){
			cols[i-2]=tblNCols[i];
		}
		result[0]="";
		result[1]="";
		
		List violations= new ArrayList();
		
		
		for(int i=0;i<cols.length;i++){
			String colName=cols[i].trim();
			if(colName.length()>30){
				result[0]+="COLUMN_LENGTH_ERROR,";
				failCount++;
				result[1]+=failCount+") Invalid column name:"+colName+". Column name can not be more than 30 characters long <br>";
			}else
			if(!this.checkName(colName)){
				result[0]+="COLUMN_NAME_ERROR,";
				failCount++;
				result[1]+=failCount+") Invalid column name:"+colName+". <br>";
			}
		}
		
		if(!this.checkColumns(cols)){
			String dupNames=this.getDuplicateColumns(cols);
			result[0]+="DUPLICATE_COLUMN_NAME,";
			failCount++;
			result[1]+=failCount+") Duplicate column names: "+dupNames+"  <br>";
		}
		
		String reservedWords=this.getOracleReservedWords(tblNCols);
		
		if(reservedWords.length()>0){
			result[0]+="RESERVED_WORDS_USED,";
			failCount++;
			result[1]+=failCount+") Reserved keywords used: "+reservedWords+"  <br>";
		}
		
		if(tableName.length()>20){
			result[0]+="TABLE_LENGTH_ERROR,";
			failCount++;
			result[1]+=failCount+") Table name "+tableName+" is more than 20 characters long <br>";
		}
		else if(!this.checkName(tableName)){
			result[0]+="TABLE_NAME_ERROR,";
			failCount++;
			result[1]+=failCount+") Table name "+tableName+" is invalid name <br>";
		}
		else if((violations=this.checkPrimaryKeys(tempTblNKeyCols)).size()>0){
			result[0]+="PRIMARY_KEY_VIOLATION,";
			failCount++;
			result[1]+=failCount+") Primary key violation. Top 10 violations:";
			int maxSize=violations.size();
			if(maxSize>10){
				maxSize=10;
			}
			for(int i=0;i<maxSize;i++){
				result[1]+= violations.get(i)+" <br> &nbsp;&nbsp; ";
			}
		}
		else if(!this.checkTableName(tablePrefix+tableName)){
			result[0]+="TABLE_ALREADY_EXISTS,";
			failCount++;
			result[1]+=failCount+") Table name "+tablePrefix+tableName+" already exists <br>";
			DatabaseOperator dbOper= new DatabaseOperator();
			try{
				dbOper.connectHawkeyRule();
				result[1]+=dbOper.getTableColumns(tablePrefix+tableName,"HAWKEYERULES");
			}catch(Exception e){
				result[1]+="Could not get table descripton";
			}
			finally{
				dbOper.takeDown();
			}
			
		}
		
		
		if(failCount==0){
			result[0]="VALID";
			result[1]=" The table parameters are valid.";
		}
		return result;
	}
	
	/**
	 * Check if the name is compatible with oracle naming
	 * @param name
	 * @return
	 */
	private boolean checkName(String name){
		/*******************/
		char[] nameChar=name.toCharArray();
		for(int j=0;j<nameChar.length;j++){
			char c=nameChar[j];
			if((c>='a' && c<='z') || (c>='A' && c<='Z')|| (c>='0' && c<='9') || c=='_'){
				continue;
			}else{
				return false;
			}
		}
		/*******************/
		return true;
	}
	
	
	
					
	
}
