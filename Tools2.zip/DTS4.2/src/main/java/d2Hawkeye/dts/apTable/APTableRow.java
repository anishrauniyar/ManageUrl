package d2Hawkeye.dts.apTable;


import java.util.ArrayList;
import java.util.List;

public class APTableRow{
	List rowData= new ArrayList();
	
	public void addData(String data){
		rowData.add(data);
	}
	
	public List getRowData(){
		return rowData;
	}
}