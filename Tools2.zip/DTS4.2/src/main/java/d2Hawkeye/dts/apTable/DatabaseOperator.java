package d2Hawkeye.dts.apTable;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;
import d2Hawkeye.dts.sqlBean;

/**
 * Class to handle all the database opearation for creating 
 * As_Prepared (AP_.....) tables from uploaded text file. 
 * The name later changed as HR_.......
 * @author Subash Devkota
 *
 */
public class DatabaseOperator extends sqlBean{

	
	/**
	 * Get hawkeyrule connection
	 *
	 */
	public void  connectHawkeyRule(){
		 ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
		 String alias = "MDHawkeye->HawkeyeRule";
		 myConn = pool.getConnection(alias);
	}
	
	/**
	 * Return true if the table exists in the database in the schema else false
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	public boolean doesTableExist(String tableName) throws Exception{
		int cnt=0;
		strSQL=" select count(table_name) as tableCount from tabs where table_name='"+tableName.toUpperCase()+"'";
	//	System.out.println(strSQL);
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		if(myRS.next()){
			cnt=myRS.getInt("tableCount");
		}
		stmt.close();
		return (cnt==0)?false:true;
	}
	
	/**
	 * Check if the columns are valid for primary key for the specified table. Returns the string with violation information.
	 * @param tableName  Name of the table to check for
	 * @param columnNames   List of column names
	 * @return List of violated cases with violation count.
	 * @throws Exception
	 */
	public List getPrimaryKeyViolation(String tableName, List columnNames) throws Exception{
		List violation= new ArrayList();
		String contatenatedCols="' '";
		for(int i=0; i<columnNames.size();i++){
			contatenatedCols+="||' '||"+(String)columnNames.get(i);
		}
		strSQL=" select concatString, cnt from (select count(1) cnt, "+contatenatedCols+" as concatString from "+tableName+" group by "+contatenatedCols+") where cnt >1"; 
	//	System.out.println(strSQL);
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		while(myRS.next()){
			String violatedCols=myRS.getString("concatString");
			int cnt=myRS.getInt("cnt");
			violation.add(violatedCols+"::"+cnt);
		}
		stmt.close();
		return violation;
	}
	
	/**
	 * Create temporary table with table name TMP_AP_<timestamp> and columns as Col1, Col2,... and return the table name
	 * @param cols
	 * @return
	 * @throws Exception
	 */
	public String createTempTable(String[] cols) throws Exception{
		String tableName="TMP_AP_"+new Date().getTime();
		
		strSQL=" create table "+tableName+" " +
	    		"( ";
	    for(int i=0;i<cols.length;i++){
	    	if(i+1==cols.length){
	    		strSQL+= " Col"+i+ " varchar2(1000) ";
	    	}else{
	    		strSQL+= " Col"+i+ " varchar2(1000), ";
	    	}
	    }
	    strSQL+=" ) ";
	    try{ 
	    	stmt= myConn.createStatement();
	    	stmt.executeUpdate(strSQL);
	    	stmt.close();
	    }
	    catch(Exception e){
	    //	e.printStackTrace();
	        System.out.println(strSQL);
	   	 	System.out.println("Exception in creating temp table");
	    	throw e;
	    }
		return tableName;
	}
	
	/**
	 * Create table corresponding to the APTable object
	 * @param table
	 * @throws Exception
	 */
	public void createTable(APTable table) throws Exception{
		String tableName=table.getTablePrefix()+table.getTableName();
		List columns=table.getColumns();
		int cols=columns.size();
		
		// Drop the table if exists and is set to overwrite
		if(table.isOverWrite()&& this.doesTableExist(tableName)){
			this.dropTable(tableName);
		}
			
		strSQL=" create table "+tableName+" " +
	    		"( ";
	    for(int i=0;i<cols;i++){
	    	APTableColumn clm= (APTableColumn)columns.get(i);
	    	String columnName=clm.getName();
	    	String dataType=clm.getDataType();
	    	
	    	if(i+1==cols){
	    		strSQL+= columnName+" "+dataType+" ";
	    	}else{
	    		strSQL+= columnName+" "+dataType+", ";
		    }
	    }
	    if(!"".equals(table.getPrimaryKeys())){
	    	strSQL+=" ,CONSTRAINT pk_"+tableName+" primary key  ("+table.getPrimaryKeys()+") validate";
	    }
	    strSQL+=" ) ";
	    
	    try{ 
	    	stmt= myConn.createStatement();
	   // 	System.out.println(strSQL);
	    	stmt.executeUpdate(strSQL);
	    	stmt.close();
	    }
	    catch(Exception e){
	    //	e.printStackTrace();
	    	throw e;
	    }
		return ;
	}
	
	/**
	 * Copy data from src table to destination table 
	 * @param srcTable
	 * @param destTable
	 * @throws Exception
	 */
	public void copyData(String srcTable, String destTable) throws Exception{
		strSQL=" insert into "+destTable+" select * from "+srcTable;
	//	System.out.println(strSQL);
		try{
			stmt= myConn.createStatement();
	    	stmt.executeQuery(strSQL);
	    	stmt.close();
		}catch(Exception e){
	    //	e.printStackTrace();
	    	throw e;
	    }
		return ;
	}
	
	/**
	 * Copy data from from temporary table to required table for the APTable object
	 * @param srcTable
	 * @param destTable
	 * @throws Exception
	 */
	public void copyData(APTable table) throws Exception{
		String destTable=table.getTablePrefix()+table.getTableName();
		String srcTable=table.getTempTableName();
		strSQL=" insert into "+destTable+" select ";
		List cols=table.getColumns();
		for(int i=0;i<cols.size();i++){
			APTableColumn col=(APTableColumn)cols.get(i);
			String dataType=col.getDataTypeRepresentation();
			if(dataType.indexOf("DateTime")>-1){
				String dateFormat= dataType.substring("DateTime".length()+1);
				strSQL+=" to_date(Col"+i+",'"+dateFormat+"')";
			}else if(dataType.indexOf("String")>-1){
				String dataTypeLengthStr=dataType.substring("String".length()+1);
				int len=Integer.parseInt(dataTypeLengthStr.trim());
				strSQL+=" substr(Col"+i+",1,"+len+")";
			}else{
				strSQL+=" Col"+i;
			}
			if(i<cols.size()-1){
				strSQL+=", ";
			}
		}
		strSQL+=" from "+srcTable;
		
	//	System.out.println(strSQL);
		try{
			stmt= myConn.createStatement();
	    	stmt.executeQuery(strSQL);
	    	stmt.close();
		}catch(Exception e){
	    //	e.printStackTrace();
	    	throw e;
	    }
		return ;
	}
	
	/**
	 * Drop the table
	 * @param tableName
	 * @throws Exception
	 */
	public void dropTable(String tableName) throws Exception{
		strSQL=" drop table "+tableName;
		try{
			stmt= myConn.createStatement();
	    	stmt.executeUpdate(strSQL);
	    	stmt.close();
		}catch(Exception e){
	    //	e.printStackTrace();
	    	throw e;
	    }
		return ;
	}
	
	/**
	 * Add specified data in to the specified temporary table
	 * @param tableName
	 * @param data
	 * @throws Exception
	 */
	public void addRowToTable(String tableName, String[] data) throws Exception{
		strSQL=" insert into "+ tableName+" ( ";
		for(int i=0;i<data.length;i++){
			if(i+1==data.length){
				strSQL+=" Col"+i;
			}else{
				strSQL+=" Col"+i+", ";
			}
		}
		strSQL+=") values ( ";
		for(int i=0;i<data.length;i++){
			if(i+1==data.length){
				strSQL+="'"+data[i].replaceAll("'","''")+"'";
			}else{
				strSQL+="'"+data[i].replaceAll("'","''")+"',";
			}
		}
		strSQL+=")";
		try{
			stmt=myConn.createStatement();
			stmt.executeUpdate(strSQL);
			stmt.close();
		}catch(Exception e){
	//		System.out.println("Query------------->"+strSQL);
	//		System.out.println("Error in inserting data");
			//e.printStackTrace();
			throw e;
		}
	}
	
	
	/**
	 * Load specified top records from table into resultset
	 * @param tableName
	 * @param top
	 * @throws Exception
	 */
	public void getTableData(String tableName, int top) throws Exception{
		strSQL=" select * from "+tableName +" where rownum <="+top;
		System.out.println(strSQL);
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		return ;
	}
	
	/**
	 * Get data from temporary table with specified no of  cols and record start and end pos
	 * @param apTable
	 * @param noOfCols
	 * @param startPos
	 * @param endPos
	 * @throws Exception
	 */
	public void getTempTableData(APTable apTable, int noOfCols, int startPos, int endPos) throws Exception{
		String tempTableName=apTable.getTempTableName();
		String tblName=apTable.getTablePrefix()+apTable.getTableName();
		String cols="";
		
		if(tempTableName.equalsIgnoreCase(tblName)){   // The case when function called to extract data from HR table instead of temporary table.
			List columns=apTable.getColumns();
			for(int i=0;i<columns.size();i++){
				APTableColumn clmn= (APTableColumn)columns.get(i);
				cols+=" "+clmn.getName()+",";
			}
		}else{
			for(int i=0; i<noOfCols; i++){
				cols+=" col"+i+",";
			}
		}
		cols=cols.substring(0,cols.length()-1); // remove the last comma
		
		strSQL=" select "+cols+" from (select "+cols+", rownum rn from "+tempTableName +" order by "+cols+" ) where rn between "+startPos+" and "+endPos;
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		return ;
	}
	
	/**
	 * 
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	public int getTableDataCount(String tableName) throws Exception{
		int count=0;
		strSQL=" select count(1) cnt from "+tableName  ;
	//	System.out.println(strSQL);
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		if(myRS.next()){
			count=myRS.getInt("cnt");
		}
		return count;
	}
	
	/**
	 * Get list to temporary tables that were created before 24 hours
	 * @return
	 * @throws Exception
	 */
	public List getListOfOrphanTempTables() throws Exception{
		List tables= new ArrayList();
		long today=new Date().getTime();
		long yesterday=today-1000*60*60*24;   // reduce 24 hours from now
		String maxTableName="TMP_AP_"+yesterday;
		strSQL="select table_name from tabs where table_name like 'TMP_AP_%' and table_name < '"+maxTableName+"'";
		System.out.println(strSQL);
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		while(myRS.next()){
			String tableName=myRS.getString("table_name");
			tables.add(tableName);
		}
		stmt.close();
		return tables;
	}
	
	/**
	 * Get top data for the specified column of the specified table
	 * @param tableName
	 * @param columnName
	 * @param top
	 * @throws Exception
	 */
	public void getColumnData(String tableName, String columnName, int top) throws Exception{
		strSQL="select distinct("+columnName+") from "+tableName+" where rownum <= "+top;
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		return;	
	}
	
	/**
	 * Get table columns with datatype in string format
	 * @param tableName
	 * @param owner
	 * @return
	 * @throws Exception
	 */
	public String getTableColumns(String tableName, String owner) throws Exception{
		String tableDesc="";
		tableName=tableName.toUpperCase();
		strSQL=	" select COLUMN_NAME,DATA_TYPE, DATA_LENGTH  from all_tab_cols where  OWNER='"+owner+"'"+
				" AND TABLE_NAME='"+tableName+"' order by column_id asc ";
		System.out.println(strSQL);
		stmt=myConn.createStatement();
		myRS=stmt.executeQuery(strSQL);
		while(myRS.next()){
			tableDesc+=myRS.getString(1)+" &nbsp;&nbsp;&nbsp; ";
			tableDesc+=myRS.getString(2)+" &nbsp;&nbsp;&nbsp; ";
			tableDesc+=myRS.getString(3)+"<br> ";
		}
		stmt.close();
		return tableDesc;
	}
	
	public void cleanup(){
		
	}
	
	/**
	 * Populate resultSet with list of client tables
	 * @author Subash Devkota
	 * @param clientID
	 * @return
	 */
	public boolean getClientTables(String clientID){
		clientID=clientID.toUpperCase();
		strSQL=" select distinct table_name from  tabs where table_name like 'HR_"+clientID+"_%' order by table_name ";
		myRS=this.executeQuery(strSQL,myConn);
		if (myRS != null) {
		      return true;
		}
		this.addMessage("<font color='red'>[sqlBean] ERROR: Client hawkeyerules tables</font>");
		return false;
	}
	
	
	/**
	 * Get max column data lenght of the specified column of the table
	 * @author sdevkota
	 * @param tableName
	 * @param columnName
	 * @return
	 * @throws Exception
	 */
	public int getColumnDataMaxLength(String tableName, String columnName) throws Exception{
		strSQL=	" select len from" +
				"	(" +
				"		select length("+columnName+") len from "+tableName+
				" 		order by length("+columnName+") desc" +
				"	)" +
				" where rownum < 2";
	//	System.out.println(strSQL);
		int maxLength=0;
		myRS=this.executeQuery(strSQL,myConn);
		if(myRS.next()){
			maxLength=myRS.getInt(1);
		}
		return maxLength;
		
	}
	
	
}
