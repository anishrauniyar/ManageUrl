package d2Hawkeye.dts.apTable;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletConfig;

/**
 * Thread for deleting temporary tables in every 24 hours.
 * Methods added also to delete the temporary files created for SQLLoader.
 * @author Subash Devkota
 *
 */
public class TempTableCleaner  implements Runnable{

		DatabaseOperator dbOperator= new DatabaseOperator();
		
		ServletConfig config;
		
		public TempTableCleaner(ServletConfig config){
			this.config=config;
			Thread t= new Thread(this);
			t.start();
		
		}
		
		
		public void run(){
			System.out.println("The thread for deleting temporary tables and files is started");
			while(true){
				try{
					dbOperator.connectHawkeyRule();
					List tables=dbOperator.getListOfOrphanTempTables();
					for(int i=0;i<tables.size();i++){
						String tableName=(String)tables.get(i);
						dbOperator.dropTable(tableName);
					}
					dbOperator.takeDown();
					System.out.println("All temporary tables created before 24 hours deleted");
					this.deleteSQLLoaderFiles();
					System.out.println("All temporary files realated to SQLLoader which were created before 24 hours deleted");
					
				}catch(Exception e){
					e.printStackTrace();
				}
				try{
					Thread.sleep(1000*60*60*24);  // Sleep for 24 hours
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
	
		/**
		 * Delete SQLLoader related files created before 24 hours.
		 * @throws Exception
		 */
		private void deleteSQLLoaderFiles() throws Exception{
			
			List files= new ArrayList();
			
			long today= new Date().getTime();
			long yesterday=today- 24*60*60*1000;  // reduce 24 hours
			String latestFile="SQLLdr"+yesterday;
			String path=config.getServletContext().getRealPath("/")+"/SqlLoaderFiles/";
			
			String[] command = new String[2];
			command[0]="ls";
			command[1]=path;
			
			Process p = Runtime.getRuntime().exec(command);
			 
			try {
				p.waitFor();
			} catch( InterruptedException ie ) {
				ie.printStackTrace();
			}
			 
			BufferedReader in = new BufferedReader( new
			InputStreamReader(p.getInputStream()));
			 
			String file=null;
			while((file=in.readLine() )!=null)
			{
				if(file.indexOf(".")>-1){
					file=file.substring(0,file.indexOf("."));
				}
				if((file.compareTo(latestFile)<0) && !files.contains(file)){
					files.add(file);	// Add the files with filename less than the latestFile 
				}
			}
			
			for(int i=0;i<files.size();i++){
				String fileName=path+(String)files.get(i);
				deleteFile(fileName+".txt");
				deleteFile(fileName+".ctl");
				deleteFile(fileName+".log");
				deleteFile(fileName+".bad");
			}
		}
		
		/**
		 * Delete the passed file. File must contain the full path of the file.
		 * @param file
		 * @throws Exception
		 */
		private void deleteFile(String file) throws Exception{
			
			String[] command = new String[3];
			command[0]="rm";
			command[1]="-f";
			command[2]=file;
			
			Process p = Runtime.getRuntime().exec(command);
			try {
				p.waitFor();
			} catch( InterruptedException ie ) {
				ie.printStackTrace();
			}
		}
		
		
}
