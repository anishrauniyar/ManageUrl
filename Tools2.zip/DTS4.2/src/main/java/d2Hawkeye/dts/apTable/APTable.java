package d2Hawkeye.dts.apTable;

import java.util.ArrayList;
import java.util.List;

/**
 * Class to represent As Prepared table information.
 * @author Subash Devkota
 *
 */
public class APTable {

		private List columns= new ArrayList();  // list of table column names
		
		private List tableData= new ArrayList();   // list of APTableRow objects
		
		public static int TOP_RECORD=10;
		
		public static final int DATABASE_CONNECT_ERROR=1;
		public static final int CREATE_TABLE_ERROR=2;
		public static final int DATA_INSERT_ERROR=3;
		public static final int DROP_TABLE_ERROR=4;
		
		public int ERROR;
		
		private String tablePrefix; 
		private String tableName;
		private String tempTableName;
		private String controlFileName;
		private String dataFileName;
		
		private boolean overWrite=false;
		private boolean append=false;
		
		private String primaryKeys="";
		
		private int[] availableSize={1000,500,200,100,50,20};  // size for string
		private String[] dateFormats={"MM-DD-YY","MM-DD-YYYY","DD-MON-YY","DD-MON-YYYY","MM/DD/YY","MM/DD/YYYY","YYYY/MM/DD"};
		
		
		public boolean isAppend() {
			return append;
		}

		public void setAppend(boolean append) {
			this.append = append;
		}

		public String getDataFileName() {
			return dataFileName;
		}

		public void setDataFileName(String dataFileName) {
			this.dataFileName = dataFileName;
		}

		public String getControlFileName() {
			return controlFileName;
		}

		public void setControlFileName(String controlFileName) {
			this.controlFileName = controlFileName;
		}

		public String getPrimaryKeys() {
			return primaryKeys;
		}

		public void setPrimaryKeys(String primaryKeys) {
			this.primaryKeys = primaryKeys;
		}

		public void addColumn(APTableColumn column){
			columns.add(column);
		}
		
		public List getColumns(){
			return columns;
		}
		
		public List getTableData(){
			return tableData;
		}

		public String getTableName() {
			return tableName;
		}

		public void setTableName(String tableName) {
			this.tableName = tableName;
		}
		
		public String getTempTableName() {
			return tempTableName;
		}

		public void setTempTableName(String tempTableName) {
			this.tempTableName = tempTableName;
		}
		
		public String getTablePrefix() {
			return tablePrefix;
		}

		public void setTablePrefix(String tablePrefix) {
			this.tablePrefix = tablePrefix;
		}
		
		public boolean isOverWrite() {
			return overWrite;
		}

		public void setOverWrite(boolean overWrite) {
			this.overWrite = overWrite;
		}

		/**
		 * Get the selection HTML code for datatype combo box
		 * @param colNumber
		 * @param selectedType
		 * @return
		 */
		public  String getColumnDataTypeSelectionHTML(int colNumber, String selectedType, int maxLength){
	    	String columnId="column"+colNumber+"DataType";
	    	int matchingSize=this.getMatchingLength(maxLength);
	    	
	    	if(selectedType==null){
	    		selectedType="String "+matchingSize;
	    	}
	    	String selectString=" <table width=100% border=0 bgcolor=\"#F7F7F7\" ><tr><td>" +
	    						" <select id="+columnId+" name="+columnId+" width="+(maxLength)+" >" ;
	    	selectString+=	" <option value='Integer' "+(selectedType.equals("Integer")? "selected ":" ") +" > Integer </option>";
	    	selectString+=	" <option value='Float' "+(selectedType.equals("Float")? "selected ":" ") +" > Float </option>";
	    	
	    	//selectString+=	" <option value='DateTime' "+(selectedType.equals("DateTime")? "selected ":" ") +" > DateTime </option>";
	    	for(int i=availableSize.length -1;i>=0;i--){
	    		selectString+=	" <option value='String "+availableSize[i]+"' "+(selectedType.equals("String "+availableSize[i])? "selected ":" ") +" >String "+availableSize[i]+"</option>";
	    	}
	    	
	    	for(int i=0;i<dateFormats.length;i++){
	    		selectString+=	" <option value='DateTime "+dateFormats[i]+"' "+(selectedType.equals("DateTime "+dateFormats[i])? "selected ":" ") +" >DateTime "+dateFormats[i]+"</option>";
	    	}
	    	
	    	
	 	
	    	selectString+=" </select></td></tr></table>";
	    	return selectString;
	    }
		
		/**
		 * Return the nearest matching length for the maxLength
		 * @param maxLength
		 * @return
		 */
		public int getMatchingLength(int maxLength){
			int matchingLength=200;
			for(int i=0;i<availableSize.length;i++){
				if (maxLength<availableSize[i]){
					matchingLength=availableSize[i];
				}
			}
			return matchingLength;
		}
		
		
		/**
		 * Set maximum size for each columns
		 * @param colsSize
		 */
		public void setColsMaxSize(int[] colsSize){
			for(int i=0;i<colsSize.length;i++){
				APTableColumn clm=(APTableColumn)columns.get(i);
				clm.setMaxlength(colsSize[i]);
				columns.remove(i);
				columns.add(i,clm);
			}
		}
		
		
		/**
		 * Generate HTML code to display table representation in the jsp page.
		 * @return
		 */
		public String getTableString( int startPos, int endPos ) {
			int cols=columns.size();
			String tableString=" <input type=hidden id=columnNumber name=columnNumber value="+cols+" >";
		    tableString+=" <input type=hidden id='tempTableName' name='tempTableName' value="+tempTableName+" >";
		    tableString+=" <input type=hidden id=tablePrefix name=tablePrefix value="+tablePrefix+" >";
		    
			tableString+="<table cellspacing=\"1\" cellpadding=\"0\" border=\"0\" bgcolor=\"BLUE\" align=\"center\">";
	    	//tableString+="<tr> <td colspan="+cols+"><div id='tableName' name='tableName' onclick=\"javascript:changeText('tableName')\">"+tableName+"</div></td></tr>";
			tableString+="<tr> <td class=\"Titlebar\" align=left colspan="+cols+">"+tablePrefix+"<input type=text id='tableName' name='tableName' value="+tableName+"></td></tr>";
	    	tableString+="<tr>";
	    	/*
	    	 * First column header
	    	 */
	    	for(int i=0;i<cols;i++){
	    		APTableColumn tblColumn=(APTableColumn) columns.get(i);
	    		int size= tblColumn.getMaxlength();
	    		tableString+="<td class=\"DataCell\" width=\""+size+"px\" > <input type=text width="+(size)+" id='col"+i+"' name='col"+i+"' value=\" "+tblColumn.getName()+"\" > </td>";
		   }
	    	
	    	tableString+="</tr><tr>";
	    	
	    	/*
	    	 * The row for selecting primary key column	 
	    	 */
	    	for(int i=0;i<cols;i++){
	    		tableString+="<td class=\"DataCell\" ><input type=checkbox id='col"+i+"PrimaryKey' name='col"+i+"PrimaryKey' > </td>";
	    	}
	    	
	    	tableString+="</tr><tr>";
	    	
	    	/*
	    	 * The row for selecting datatype for each column	 
	    	 */
	    	for(int i=0;i<cols;i++){
	    		APTableColumn tblColumn=(APTableColumn) columns.get(i);
	    		int size= tblColumn.getMaxlength();
	    		String dataType=tblColumn.getDataTypeRepresentation();
	    	//	System.out.println("datatype is:"+dataType);
	    		tableString+="<td width="+size+" >"+this.getColumnDataTypeSelectionHTML(i,dataType, size)+"</td>";
	    	}
	    	
	    	tableString+="</tr><tr>";
	    	
	    	/*
	    	 * The row for showing more column data	 
	    	 */
	    /*	for(int i=0;i<cols;i++){
	    		tableString+="<td  class=\"DataCell\" > <a href=\"javascript:showColumnData("+i+")\"> more </a> </td>";
	    	}
	    */	
	    	tableString+="</tr>";
	    	
			DatabaseOperator dbOperator= new DatabaseOperator();
			try{
				dbOperator.connectHawkeyRule();
				dbOperator.getTempTableData(this,cols,startPos, endPos);
				while(dbOperator.moveNext()){
					tableString+="<tr>";
		    		for(int i=0;i<columns.size();i++){
					//	String data=dbOperator.getData("Col"+i);
		    			String data=dbOperator.getData(i+1);
						tableString+="<td class=\"DataCell\">"+data+"</td>";
			    	}
					tableString+="</tr>";
		    	}
				tableString+="</table>";
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				dbOperator.takeDown();
			}
			return tableString;
			
		}
		
		/**
		 * Update name of the table columns
		 * @param names
		 */
		public void updateColumnNames(String names[]){
			for(int i=0;i<columns.size();i++){
				APTableColumn clm=(APTableColumn)columns.get(i);
				columns.remove(i);
				clm.setName(names[i]);
				columns.add(i,clm);
			}
		}
		
		/**
		 * Update the primarykeys string
		 * @param primaryKeys The list of column numbers for primary key separated by comma
		 */
		public void updatePrimaryKeys(String primaryKeys){
			String[] pkeys=primaryKeys.split(",");
			this.primaryKeys="";
			for(int i=0;i<pkeys.length;i++){
				int colNum= Integer.parseInt(pkeys[i]);
				APTableColumn clmn=(APTableColumn)columns.get(colNum);
				String colName= clmn.getName();
				this.primaryKeys+=colName+",";
			}
			// Remove the last comma
			this.primaryKeys=this.primaryKeys.substring(0,this.primaryKeys.length()-1);
		}
		
		/**
		 * Update datatype for the table columns
		 * @param dataTypes
		 */
		public void updateDataTypes(String dataTypes[]){
			for(int i=0;i<columns.size();i++){
				APTableColumn clm=(APTableColumn)columns.get(i);
				int maxLength=clm.getMaxlength();
				columns.remove(i);
				String type=dataTypes[i];
				clm.setDataTypeRepresentation(type);
				int length=0;
				if(type.indexOf("String")>-1){
					String lenStr=type.substring("String ".length(),type.length());
					lenStr=lenStr.trim();
					length=Integer.parseInt(lenStr);
					type="varchar2("+length+")";
				}else
					if(type.indexOf("DateTime")>-1){
					type="date";
				}else
					if(type.equalsIgnoreCase("Integer")){
						type="number("+(maxLength+1)+",0)";
				}else
					if(type.equalsIgnoreCase("Float")){
						type="number("+(maxLength+1)+",2)";
				}
				clm.setDataType(type);
				columns.add(i,clm);
			}
		}
		
		/**
		 * Create AP table to insert data from temporary table and delete the temporary table
		 * @return
		 */
		public String createTable() {
			ERROR=0;
			DatabaseOperator dbOperator= new DatabaseOperator();
			try{
				dbOperator.connectHawkeyRule();
			}catch(Exception e){
				ERROR=DATABASE_CONNECT_ERROR;
				return e.getMessage();
			}
			try{
				if(!this.isAppend()){
					dbOperator.createTable(this);
				}
			}catch(Exception e){
				ERROR=CREATE_TABLE_ERROR;
				return e.getMessage()+" <br> in the query:"+dbOperator.getSQLQuery();
			}
			try{				
				dbOperator.copyData(this);//this.tempTableName, this.getTablePrefix()+this.tableName);
			}catch(Exception e){
				ERROR=DATA_INSERT_ERROR;
				return e.getMessage()+" <br> in the query:"+dbOperator.getSQLQuery();
			}
			try{
				dbOperator.dropTable(this.tempTableName);
			}catch(Exception e){
				ERROR=DROP_TABLE_ERROR;
				return e.getMessage()+" <br> in the query:"+dbOperator.getSQLQuery();
			}finally{
				dbOperator.takeDown();
			}
			return "";
		}
		
		
		/**
		 * Handle the tasks to do when error occurs.
		 *
		 */
		public void handleError(){
			if(ERROR==DATA_INSERT_ERROR){
				DatabaseOperator dbOperator= new DatabaseOperator();
				try{
					dbOperator.connectHawkeyRule();
					dbOperator.dropTable(tablePrefix+tableName);
				}catch(Exception e){
					e.printStackTrace();
				}finally{
					dbOperator.takeDown();
				}
			}
		}
		
		public String getColumnData(int colNum, String colName){
			String tableString="<table cellspacing=\"1\" cellpadding=\"0\" border=\"0\" bgcolor=\"BLUE\" align=\"center\">";
	    	tableString+="<tr> <td class=\"Titlebar\" align=center >"+colName+"</td></tr>";
	    	//tableString+="<tr>";
	    	
	    	DatabaseOperator dbOperator= new DatabaseOperator();
			try{
				dbOperator.connectHawkeyRule();
				dbOperator.getColumnData(tempTableName,"Col"+colNum, 100);
				while(dbOperator.moveNext()){
					tableString+="<tr>";
					String data=dbOperator.getData("Col"+colNum);
		    		tableString+="<td class=\"DataCell\">"+data+"</td>";
			    	tableString+="</tr>";
		    	}
				tableString+="</table>";
				
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				dbOperator.takeDown();
			}
			return tableString;
		}
		
		
		/**
		 * Set the value of enclosed for the specified column number
		 * @param colNum
		 * @param enclosed
		 */
		public void setColumnEnclosed(int colNum, boolean enclosed){
			java.util.List columns=new java.util.ArrayList();
                        columns= this.getColumns();
			APTableColumn colm= (APTableColumn)columns.get(colNum);
			colm.setEnclosed(enclosed);
			columns.remove(colNum);
			columns.add(colNum,colm);
		}
		
		
		/**
		 * Get the no of records in the temporary tabel 
		 * @param tableName
		 * @return
		 * @throws Exception
		 */
		public int getTempTableDataCount() throws Exception{
			int count=0;
			DatabaseOperator dbOperator= new DatabaseOperator();
			try{
				dbOperator.connectHawkeyRule();
				count=dbOperator.getTableDataCount(tempTableName);
			}catch(Exception e){
				throw e;
			}finally{
				dbOperator.takeDown();
			}
			return count;
		}
		
}

