package d2Hawkeye.dts;

import java.util.*;

public class DTSClients
    extends sqlBean {
  public static String CLIENT_TABLE = "ztbl_DTS_Clients";
  public static String CLIENT_ID_FIELD = "ClientId";
  public static String CLIENT_FIELD = "ClientName";
  public static String CONTRACT_FIELD = "ContractType";
  public static String INUSE_FIELD = "InUse";
  public static String VERSION_FIELD = "Version";
  public static String DATABASENAME_FIELD = "DATABASENAME";
  public static String TEMPLATE_ID = "TemplateId";
  public static String TEMPLATE_NAME = "TemplateName";
  public static String CLIENT_TYPE = "ClientType";

  public String getClientWithoutDatabase = "";
  public DTSClients() {
  }
 dtsBean dtsbean = new dtsBean();
  public void cleanup() {}

  public void setClientWithoutDatabase(){
      getClientWithoutDatabase = " WHERE DATABASENAME IS NULL";
  }
  public HashMap getClientInfo() {
    HashMap hm = null;
    String sql = "";
    sql += "select * from " + DTSClients.CLIENT_TABLE;
    sql = "SELECT a.*, NVL(c.templateid,'') TemplateId,NVL(c.templatename,'') TemplateName, NVL(b.DATABASENAME,'') DATABASENAME FROM ztbl_DTS_Clients a" +
    	  " left join   (select m.clientid ,m.templateid,n.templatename from ZTBL_DTS_CLIENT_TEMPLATES m "+
          " left join ztbl_dts_templates n on m.templateid=n.templateid) c on a.clientid=c.clientid" +
    		" LEFT JOIN ztbl_DTS_Databases b ON a.CLIENTID=b.CLIENTID";
    sql += getClientWithoutDatabase;
    //System.out.println(sql);
    this.executeQuery(sql);
    if (this.moveNext()) {
      this.addMessage("Info: data found");
      hm = new HashMap();
      HashMap hmm;
      try {
        do {
          hmm = new HashMap();
          hmm.put(DTSClients.CLIENT_ID_FIELD,
                  myRS.getString(DTSClients.CLIENT_ID_FIELD));
          
          hmm.put(DTSClients.CLIENT_FIELD,
                  myRS.getString(DTSClients.CLIENT_FIELD));
          hmm.put(DTSClients.CONTRACT_FIELD,
                  myRS.getString(DTSClients.CONTRACT_FIELD));
          hmm.put(DTSClients.INUSE_FIELD,
                  myRS.getString(DTSClients.INUSE_FIELD));
          hmm.put(DTSClients.VERSION_FIELD,
                  myRS.getString(DTSClients.VERSION_FIELD));
          hmm.put(DTSClients.TEMPLATE_ID, 
        		  myRS.getString(DTSClients.TEMPLATE_ID));
          hmm.put(DTSClients.TEMPLATE_NAME, 
        		  myRS.getString(DTSClients.TEMPLATE_NAME));
          hmm.put(DTSClients.DATABASENAME_FIELD,
                  myRS.getString(DTSClients.DATABASENAME_FIELD));
          hmm.put(DTSClients.CLIENT_TYPE,
                  myRS.getString(DTSClients.CLIENT_TYPE));
          hm.put(myRS.getString(DTSClients.CLIENT_FIELD) +
                 myRS.getString(DTSClients.CLIENT_ID_FIELD), hmm);
        }
        while (this.moveNext());
      }
      catch (Exception e) {
        this.addMessage("ERROR: " + e);
      }
    }
    else {
      this.addMessage("Info: no data present");
    }
    return hm;
  }

  public HashMap getClientInfo(String clientName) {
    HashMap hm = null;
    String sql = "";
    sql += "select * from " + DTSClients.CLIENT_TABLE;
    sql  = "SELECT a.*, NVL(b.DATABASENAME,'') DATABASENAME FROM ztbl_DTS_Clients a LEFT JOIN ztbl_DTS_Databases b ON a.CLIENTID=b.CLIENTID  where UPPER(ClientName)=UPPER('" + clientName.replaceAll("'","''") + "')";
    this.executeQuery(sql);
    if (this.moveNext()) {
      this.addMessage("Info: data found");
      hm = new HashMap();
      try {
        hm.put(DTSClients.CLIENT_ID_FIELD,
               myRS.getString(DTSClients.CLIENT_ID_FIELD));
        hm.put(DTSClients.CLIENT_FIELD,
               myRS.getString(DTSClients.CLIENT_FIELD));
        hm.put(DTSClients.CONTRACT_FIELD,
               myRS.getString(DTSClients.CONTRACT_FIELD));
        hm.put(DTSClients.INUSE_FIELD,
               myRS.getString(DTSClients.INUSE_FIELD));
        hm.put(DTSClients.VERSION_FIELD,
               myRS.getString(DTSClients.VERSION_FIELD));
        hm.put(DTSClients.CLIENT_TYPE,
                myRS.getString(DTSClients.CLIENT_TYPE));
      }
      catch (Exception e) {
        this.addMessage("ERROR: " + e);
      }
    }
    else {
      this.addMessage("Info: no data present");
    }
    return hm;
  }

  public HashMap getClientInfo(int clientId) {
    HashMap hm = null;
    String sql = "";
    sql += "select * from " + DTSClients.CLIENT_TABLE;
    sql += " where ClientId=" + clientId + "";

  sql  = "SELECT a.*, NVL(b.DATABASENAME,'') DATABASENAME FROM ztbl_DTS_Clients a LEFT JOIN ztbl_DTS_Databases b ON a.CLIENTID=b.CLIENTID  where a.ClientID = " + clientId ;
  //System.out.println(" getClientQuery>>>>"+sql);
    java.sql.ResultSet rs = this.executeQuery(sql);
    if (rs != null && this.moveNext()) {
      this.addMessage("Info: data found");
      hm = new HashMap();
      try {
        hm.put(DTSClients.CLIENT_ID_FIELD,
               myRS.getString(DTSClients.CLIENT_ID_FIELD));
        hm.put(DTSClients.CLIENT_FIELD,
               myRS.getString(DTSClients.CLIENT_FIELD));
        hm.put(DTSClients.CONTRACT_FIELD,
               myRS.getString(DTSClients.CONTRACT_FIELD));
        hm.put(DTSClients.INUSE_FIELD,
               myRS.getString(DTSClients.INUSE_FIELD));
        hm.put(DTSClients.VERSION_FIELD,
               myRS.getString(DTSClients.VERSION_FIELD));  
        hm.put(DTSClients.CLIENT_TYPE,
                myRS.getString(DTSClients.CLIENT_TYPE));
        hm.put(DTSClients.DATABASENAME_FIELD,
                myRS.getString(DTSClients.DATABASENAME_FIELD));
      }
      catch (Exception e) {
        this.addMessage("ERROR: " + e);
      }
    }
    else {
      this.addMessage("Info: no data present");
    }
    return hm;
  }
  
  /**
   * Return map of avilable tempalteId and tempalteName(Version) 
   * @author Subash Devkota
   * @return
   */
  public HashMap getAvailableTemplates(){
	  HashMap hm = null;
	  String sql = "select TEMPLATEID, TEMPLATENAME||'('||TEMPLATEVERSION||')'||'('||TEMPLATETYPE||')' NAME from ZTBL_DTS_TEMPLATES order by templateName ";
	  java.sql.ResultSet rs = this.executeQuery(sql);
	    if (rs != null) {
	      this.addMessage("Info: data found");
	      hm = new HashMap();
	     try{
	    	 while(rs.next()){
		        String id=rs.getString("TEMPLATEID");
		    	  String name=rs.getString("NAME");
		    	  hm.put(id,name);
		    }
	     }
	     catch (Exception e) {
	        this.addMessage("ERROR: " + e);
	      }
	    }
	    else {
	      this.addMessage("Info: no data present");
	    }
	    
	    return hm;
	}
  
  /**
   * Assign the passed tempalteId to the client.
   * @author sdevkota
   * @param clientId
   * @param templateId
   */
  public boolean assignTemplateToClient(String clientId, String templateId){
	  dtsbean = new dtsBean();
	  String  assignedTemplateId = "";	  
	   assignedTemplateId = ""+dtsbean.getAssignedTemplateID(clientId);  
	   // when template is changed, duplicate keyfields will be deleted from ZTBL_DTS_CLIENT_KEYFIELDS
	  if(!assignedTemplateId.equalsIgnoreCase(templateId))
	  {
		  String sql = "delete from  ZTBL_DTS_CLIENT_KEYFIELDS where (clientid,category,keyfield) in " +
		  		" (select a.clientid,a.category,a.keyfield from   ZTBL_DTS_CLIENT_KEYFIELDS a," +
		  		" ztbl_dts_template_defs b where a.category=b.category and a.keyfield = b.keyfield" +
		  		" and b.templateid='"+templateId+"' and a.clientid='"+clientId+"')"; 
		  this.execute(sql);
		  
	  }
	  String sql=" MERGE INTO  ztbl_dts_client_templates  A" +
	  			 " USING (SELECT '"+clientId+"' clientId,'"+templateId+"' templateid FROM DUAL) B" +
	  			 " ON(A.CLIENTID=B.CLIENTID )" +
	  			 " WHEN MATCHED THEN UPDATE SET TEMPLATEID='"+templateId+"'" +
	  			 " WHEN NOT MATCHED THEN INSERT (clientId, templateId) values('"+clientId+"','"+templateId+"') ";	  
	  
	  
	  dtsbean.garbageCleanupForClient(clientId);
	  
	  return this.execute(sql);
  }
  

  public String[] getAvailableIds() {
    Vector allIds = new Vector();
    String val;
    for (int i = 0; i < 1000; i++) {
      val = "";
      if (i < 10) {
        val += "00";
      }
      else if (i < 100) {
        val += "0";
      }

      val += i + "";

      allIds.add(val);
    }
    String sql = "select " + DTSClients.CLIENT_ID_FIELD + " from " +
        DTSClients.CLIENT_TABLE;
    try {
      java.sql.ResultSet rs = this.executeQuery(sql);
      String anId;
      while (this.moveNext()) {
        anId = rs.getString(DTSClients.CLIENT_ID_FIELD);
        this.addMessage("removing " + anId + ": " + allIds.remove(anId));
      }
    }
    catch (Exception e) {
      this.addMessage("Error: " + e);
    }
    String ids[] = new String[allIds.size()];
    allIds.toArray(ids);
    return ids;
  }

  public boolean insertClient(String clientId, String clientName,
                              String contractType, String inUse, String version) {
    if (this.getClientInfo(Integer.parseInt(clientId)) != null) {
      this.addMessage("Client already exists");
      return false;
    }
    String sql = "insert into " + DTSClients.CLIENT_TABLE +
        " (" + DTSClients.CLIENT_ID_FIELD + ", " + DTSClients.CLIENT_FIELD +
        ", " +
        DTSClients.CONTRACT_FIELD + ", " + DTSClients.INUSE_FIELD + ", " +
        DTSClients.VERSION_FIELD + ") values (" +
        "'" + clientId + "', '" + TextEncoder.encode(clientName) + "', '" +
        TextEncoder.encode(contractType) + "', '" + inUse + "', '" + version +
        "')";
    return this.execute(sql);
  }
  /**
   * 
   * @param clientId
   * @param clientName
   * @param contractType
   * @param inUse
   * @param version
   * @param clientType
   * added by Ram Gautam, this function is made to add extra parameter, clientType, 
   *  @return
   */
  public boolean insertClient(String clientId, String clientName,
          String contractType, String inUse, String version,String clientType) {
	  System.out.println("Insert query");
		if (this.getClientInfo(Integer.parseInt(clientId))!= null) {
			this.addMessage("Client already exists");
			return false;
		}
		System.out.println("Insert query><><><>");
		 String sql = "insert into " + DTSClients.CLIENT_TABLE + " ("
				+ DTSClients.CLIENT_ID_FIELD + ", " + DTSClients.CLIENT_FIELD
				+ ", " + DTSClients.CONTRACT_FIELD + ", "
				+ DTSClients.INUSE_FIELD + ", " + DTSClients.VERSION_FIELD
				+ ", " + DTSClients.CLIENT_TYPE + ") values (" + "'" + clientId
				+ "', '" + TextEncoder.encode(clientName) + "', '"
				+ TextEncoder.encode(contractType) + "', '" + inUse + "', '"
				+ version + "', '" +clientType+ "')";
		System.out.println("Insert query"+sql);
		return this.execute(sql);
}

  public boolean insertClient(String clientId, String clientName,
                              String contractType, String inUse) {
    if (this.getClientInfo(Integer.parseInt(clientId)) != null) {
      this.addMessage("Client already exists");
      return false;
    }
    String sql = "insert into " + DTSClients.CLIENT_TABLE +
        " (" + DTSClients.CLIENT_ID_FIELD + ", " + DTSClients.CLIENT_FIELD +
        ", " +
        DTSClients.CONTRACT_FIELD + ", " + DTSClients.INUSE_FIELD +
        ") values (" +
        "'" + clientId + "', '" + TextEncoder.encode(clientName) + "', '" +
        TextEncoder.encode(contractType) + "', '" + inUse + "')";
    return this.execute(sql);
  }

  public boolean updateClient(String clientId, String clientName,
                              String contractType, String inUse, String version,String clientType) {
    HashMap hm = this.getClientInfo(Integer.parseInt(clientId));
    if (hm == null) {
      this.addMessage("Client does not exists");
      return false;
    }
    String cName, cType, iUse, ver,cliType;
    cName = (String) hm.get(DTSClients.CLIENT_FIELD);
    cType = (String) hm.get(DTSClients.CONTRACT_FIELD);
    iUse = (String) hm.get(DTSClients.INUSE_FIELD);
    ver = (String) hm.get(DTSClients.VERSION_FIELD);
   	cliType=(String) hm.get(DTSClients.CLIENT_TYPE);
	 Vector updates = new Vector();
    if (!cName.equals(clientName)) {
      updates.add(DTSClients.CLIENT_FIELD + "='" +
                  TextEncoder.encode(clientName) + "'");
    }
    if (!cType.equals(contractType)) {
      updates.add(DTSClients.CONTRACT_FIELD + "='" +
                  TextEncoder.encode(contractType) + "'");
    }
    if (!iUse.equalsIgnoreCase(inUse)) {
      updates.add(DTSClients.INUSE_FIELD + "='" + inUse + "'");
    }
    if (!ver.equalsIgnoreCase(version)) {
      updates.add(DTSClients.VERSION_FIELD + "='" + version + "'");
    }
    if (!cliType.equalsIgnoreCase(clientType)) {
        updates.add(DTSClients.CLIENT_TYPE + "='" + clientType + "'");
      }
    if (updates.size() == 0) {
      this.addMessage("[Info] No change in the fields");
      return true;
    }
    String sql = "update " + DTSClients.CLIENT_TABLE + " set ";
    for (int i = 0; i < updates.size(); i++) {
      sql += updates.get(i);
      if (i < updates.size() - 1) {
        sql += ", ";
      }
    }
    sql += " where " + DTSClients.CLIENT_ID_FIELD + "=" + clientId;
    return this.execute(sql);
  }

  public boolean updateClient(String clientId, String clientName,
                              String contractType, String inUse) {
    HashMap hm = this.getClientInfo(Integer.parseInt(clientId));
    if (hm == null) {
      this.addMessage("Client does not exists");
      return false;
    }
    String cName, cType, iUse;
    cName = (String) hm.get(DTSClients.CLIENT_FIELD);
    cType = (String) hm.get(DTSClients.CONTRACT_FIELD);
    iUse = (String) hm.get(DTSClients.INUSE_FIELD);
    Vector updates = new Vector();
    if (!cName.equals(clientName)) {
      updates.add(DTSClients.CLIENT_FIELD + "='" +
                  TextEncoder.encode(clientName) + "'");
    }
    if (!cType.equals(contractType)) {
      updates.add(DTSClients.CONTRACT_FIELD + "='" +
                  TextEncoder.encode(contractType) + "'");
    }
    if (!iUse.equalsIgnoreCase(inUse)) {
      updates.add(DTSClients.INUSE_FIELD + "='" + inUse + "'");
    }
    if (updates.size() == 0) {
      this.addMessage("[Info] No change in the fields");
      return true;
    }
    String sql = "update " + DTSClients.CLIENT_TABLE + " set ";
    for (int i = 0; i < updates.size(); i++) {
      sql += updates.get(i);
      if (i < updates.size() - 1) {
        sql += ", ";
      }
    }
    sql += " where " + DTSClients.CLIENT_ID_FIELD + "=" + clientId;
    return this.execute(sql);
  }

  public boolean deleteClient(int clientId) {
    if (! (new DTSDatabases()).deleteDatabaseByClientId(clientId)) {
      return false;
    }
    //Delete dts template assigned to the client
    String sql=" delete from ztbl_dts_client_templates where clientId="+clientId;
    this.execute(sql);
    
    // delete from other dependencies is remaining
    sql = "delete from " + DTSClients.CLIENT_TABLE;
    sql += " where " + DTSClients.CLIENT_ID_FIELD + "=" + clientId;
    return this.execute(sql);
  }
}
