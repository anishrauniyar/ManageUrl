package d2Hawkeye.dts;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author rsah
 * @since Sep 27,2011
 *
 */
public class DTSBucket {

	private String bucketID;
	private List<DTSSet> setList;
	private List categoryNameList;
	
	public DTSBucket(String bucketID){
		this.bucketID=bucketID;
	}
	
	public List<DTSSet> getSetList() {
		if(setList==null){
			return new ArrayList();
		}
		return setList;
	}
	public void setSetList(List<DTSSet> setList) {
		this.setList = setList;
	}

	public String getBucketID() {
		return bucketID;
	}

	public void setBucketID(String bucketID) {
		this.bucketID = bucketID;
	}

	public List getCategoryNameList() {
		return categoryNameList;
	}

	public void setCategoryNameList(List categoryNameList) {
		this.categoryNameList = categoryNameList;
	}
	
}
