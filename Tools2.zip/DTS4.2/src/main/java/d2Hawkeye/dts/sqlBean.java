/*************************************************************************************
 File       : sqlBean.java
 Created by : Pawan K. Shrestha

 Functionality:

 Modifications:


 *************************************************************************************/

package d2Hawkeye.dts;

import java.sql.*;
import java.util.*;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;

import d2Hawkeye.common.connectionPool.dbcp.*;

public abstract class sqlBean {
  protected volatile Connection myConn = null;
  protected volatile ResultSet myRS = null;
  protected volatile Statement stmt = null;

  protected String strSQL = "";
  protected String strCountSQL = "";
  protected String errorStr = "";
  private Vector messages = new Vector();

  public static String DRIVER = "com.inet.tds.TdsDriver";
  public static int PORT = 1433;
  private String database = null;
  private String server = null;
  private String user = null;
  private String password = null;
  private boolean specialConnection = false;
  private boolean debug = false;
  //private boolean debug = true;

  protected String latestVersion = "";
  protected Vector versions;

  public sqlBean() {

  }
  public String getLatestVersionNum(){
    if(!this.latestVersion.equals(""))
      return this.latestVersion;
    strSQL = "select distinct Version from ztbl_DTS_Mapping_Mast order by Version";
    this.executeQuery(strSQL);
    while(this.moveNext()){
      this.latestVersion = this.getData("Version");
    }
    return this.latestVersion;
  }
  public void debug(boolean debug){
    this.debug = debug;
  }
  public boolean isDebugMode(){
    return this.debug;
  }

  public static String makeURL(String server, String database) {
    return sqlBean.makeURL(server, sqlBean.PORT, database);
  }

  public static String makeURL(String server, int port, String database) {
    String url = "jdbc:inetdae7:" + server + ":" + port + "?database=" +
        database;
    return url;
  }

  public void setDatabaseName(String dbName) {
    this.database = dbName;
    this.specialConnection = (this.server != null);
  }

  public void setDBServerName(String dbs) {
    this.server = dbs;
    this.specialConnection = (this.database != null);
  }
  protected void addMessage(String m){
    if(this.isDebugMode()){
      this.messages.add(m);
    }
  }
  public String getLastMessage(){
    if(this.isDebugMode())
      return this.messages.lastElement()+"";
    else
      return "";
  }
  public boolean makeOracleConnection() throws Exception{
    String alias = "Oracle->Acordia";
    this.addMessage("connection for " + alias + " ......");
    ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
    myConn = pool.getConnection(alias);
	return myConn!=null;
  }
  public boolean makeConnection() throws Exception {
    String alias = "";
    if (myConn != null) {
      this.takeDown();
    }
    if (this.database != null && this.server != null && this.specialConnection) {
      ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
      alias = this.makeURL(this.server, this.database);
      myConn = pool.getConnection(alias);
      if (myConn == null) {
        if(this.makeConnection(this.server, this.database)){
          this.addMessage("Special connection for " + alias + " ......");
          return true;
        }
      }else{
        this.addMessage("Special connection for " + alias + " ......");
      }
    }
    else {
      alias = "MDHawkeye->HawkeyeUser";
      this.addMessage("connection for " + alias + " ......");
//      System.out.println(">>>connection pool - DBCP >>>" + alias);

      ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
      myConn = pool.getConnection(alias);

    }

    if (myConn == null || myConn.isClosed()) {
      this.debug(true);
      this.addMessage("<font color='red'>[ERROR] Connection is null or closed</font>");
//      System.out.println(">>>>>------------" + (myConn == null) + " or closed");
      return false;
    }else{
      if(this.latestVersion.equals("") && !this.specialConnection){
        String sql =
            "select distinct Version from ztbl_DTS_Clients order by Version";
        stmt = myConn.createStatement();
        myRS = stmt.executeQuery(sql);
        this.versions = new Vector();
        while(this.moveNext()){
          String ver = this.getData("Version");
          this.versions.add(ver);
          this.latestVersion = ver;
        }
      }
    }
    this.addMessage("connection for " + alias + " ......");
    return true;
  }

  private boolean makeConnection(String dbServer, String database)  throws Exception {
    String sql = "";
    sql += "select * from " + DTSDatabases.DATABASE_TABLE + " db, " +
        DTSServers.SERVER_TABLE + " s where " +
        " db." + DTSServers.ID_FIELD + "=s." + DTSServers.ID_FIELD + " and " +
        DTSServers.SERVER_FIELD + "='" + dbServer + "' and " +
        DTSDatabases.DATABASE_FIELD +
        "='" + database + "'";
    this.specialConnection = false;
    ResultSet rs = this.executeQuery(sql);
      if (rs.next()) {
        this.addMessage("<font color='green'>[Info] username password found in database</font>");
        this.user = rs.getString(DTSServers.USER_FIELD);
        this.password = rs.getString(DTSServers.PASSWORD_FIELD);
      }
      else {
        this.addMessage("<font color='orange'>[Info] username password not found in Databases</font>");
        return this.makeConnection(dbServer);
      }
    this.specialConnection = this.makeConnection(sqlBean.DRIVER,
                                                 sqlBean.
                                                 makeURL(dbServer, database),
                                                 this.user, this.password);
    return this.specialConnection;
  }
  private boolean makeConnection(String dbServer)  throws Exception {
    String sql = "";
    sql += "select * from "+DTSServers.SERVER_TABLE + " s where " +
        DTSServers.SERVER_FIELD + "='" + dbServer + "'";
    this.specialConnection = false;
    ResultSet rs = this.executeQuery(sql);
      if (rs.next()) {
        this.addMessage("<font color='green'>[Info] username password found in servers</font>");
        this.user = rs.getString(DTSServers.USER_FIELD);
        this.password = rs.getString(DTSServers.PASSWORD_FIELD);
      }
      else {
        this.addMessage("<font color='orange'>[Info] username password not found even in servers</font>");
        return false;
      }
    this.specialConnection = this.makeConnection(sqlBean.DRIVER,
                                                 sqlBean.
                                                 makeURL(dbServer, database),
                                                 this.user, this.password);
    return this.specialConnection;
  }

  public boolean makeConnection(String driver, String url, String userName,
                                 String passwd)  throws Exception {
    ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
      this.addMessage("[driver] " + driver);
      this.addMessage("[url] " + url);
      this.addMessage("[userName] " + userName);
      this.addMessage("[passwd] ********" );
      myConn = pool.getConnection(driver, url, userName, passwd);
      this.specialConnection = true;
    if (myConn == null) {
      this.addMessage("<font color='orange'>[Error] Connection is " + myConn + "</font>");
      return false;
    }
    return true;
  }

  public Vector getVersions(){
    if(this.versions==null){
      try{
        this.makeConnection();
      }catch(Exception e){ System.out.println("[Error]"+e);}
    }
    return this.versions;
  }
  public int getRecordCount() {
    String sqlCount = getSQLCountQuery();
    try{
      if(myConn==null || myConn.isClosed())
        this.makeConnection();
      Statement st = this.myConn.createStatement();
      ResultSet rs = st.executeQuery(sqlCount);
      if(rs.next()){
        return rs.getInt("RecCount");
      }
    }catch(Exception e){
      this.addMessage("<font color='red'>[Error] Rec Count "+e+"</font>");
    }
    return 0;
  }

  public String getSQLQuery() {
    return strSQL;
  }

  public String getError() {
    return errorStr;
  }

  public String getSQLCountQuery() {
    return strCountSQL;
  }

  public String getData(String s) {
    String s1 = "";
    try {
      s1 = myRS.getString(s);
      if (s1 != null) {
        s1 = s1.replace('`', '\'');
      }
      else {
        s1 = "";
      }
    }
    catch (Exception sqlexception) {
      errorStr = "Resultset error : " + sqlexception;
      this.addMessage("<font color='red'>[Error] Resultset error : " + sqlexception +"</font>");
    }
//    this.addMessage("My Connection :"+this.myConn);
//    this.addMessage("My Resultset :"+this.myRS);
//    this.addMessage(s+" :"+s1);
    return s1;
  }

  /**
   * Get table data by column number
   * @param colNum
   * @return
   */
  public String getData(int colNum) {
	    String s1 = "";
	    try {
	      s1 = myRS.getString(colNum);
	      if (s1 != null) {
	        s1 = s1.replace('`', '\'');
	      }
	      else {
	        s1 = "";
	      }
	    }
	    catch (Exception sqlexception) {
	      errorStr = "Resultset error : " + sqlexception;
	      this.addMessage("<font color='red'>[Error] Resultset error : " + sqlexception +"</font>");
	    }
//	    this.addMessage("My Connection :"+this.myConn);
//	    this.addMessage("My Resultset :"+this.myRS);
//	    this.addMessage(s+" :"+s1);
	    return s1;
	  }
  
  public int getInt(String field) {
    int s1 = 0;
    try {
      s1 = Integer.parseInt(myRS.getString(field));
    }
    catch (Exception e) {
      errorStr = "Resultset error : " + e;
      this.addMessage("<font color='red'>[Error] Resultset error : " + e +"</font>");
    }
    return s1;
  }

  public byte[] getBytes(String s) throws Exception {
    return myRS.getBytes(s);
  }

  public Blob getBlob(String s)throws Exception{
      return myRS.getBlob(s);
  }

    public InputStream getBinaryStream(String s)throws Exception{
        return myRS.getBinaryStream(s);
    }

    protected byte[] readValueStream(InputStream in, int streamSize, int bufSize)
            throws Exception {

        byte[] buf = new byte[bufSize];
        int read;
        ByteArrayOutputStream out = (streamSize > 0) ? new ByteArrayOutputStream(
                streamSize) : new ByteArrayOutputStream();

        try {
            while ((read = in.read(buf, 0, bufSize)) >= 0) {
                out.write(buf, 0, read);
            }
            return out.toByteArray();
        }
        finally {
            in.close();
        }
    }

public byte[] readBlob(Blob blob) throws Exception {
        if (blob == null) {
            return null;
        }

        int BUF_SIZE = 8 * 1024;
        // sanity check on size
        if (blob.length() > Integer.MAX_VALUE) {
            throw new IllegalArgumentException(
                    "BLOB is too big to be read as byte[] in memory: " + blob.length());
        }

        int size = (int) blob.length();
        if (size == 0) {
            return new byte[0];
        }

        int bufSize = (size < BUF_SIZE) ? size : BUF_SIZE;
        InputStream in = blob.getBinaryStream();
        return (in != null) ? readValueStream(
                new BufferedInputStream(in, bufSize),
                size,
                bufSize) : null;
    }


  public boolean moveNext() {
    boolean tmp = false;
    try {
      tmp = myRS.next();
    }
    catch (Exception e) {
      this.addMessage("<font color='red'>[Error] move next : " + e+"</font>");
    }
    return tmp;
  }

  public boolean moveFirst() {
    boolean tmp = false;
    try {
      tmp = myRS.first();
    }
    catch (Exception e) {
      this.addMessage("<font color='red'>[Error] move first : " + e + "</font>");
    }
    return tmp;
  }

  public boolean getList(String sqlStr, String whatToList) {
	  //System.out.println("getList  "+sqlStr);
    if (this.executeQuery(sqlStr) != null) {
      return true;
    }
    this.addMessage("<font color='red'>[sqlBean] ERROR: " + whatToList + "</font>");
    return false;
  }

  public ResultSet executeQuery(String query, Connection con) {
    try {
      this.strSQL = query;
      this.addMessage("SQL: " + query);
      stmt = con.createStatement();
      myRS = stmt.executeQuery(query);
      this.addMessage("<font color='green'>[sqlBean] Info: Success</font>");
    }
    catch (Exception e) {
      this.debug(true);
      this.addMessage("<font color='red'>[sqlBean] query execution error " + e + "</font>");
    }
    return myRS;
  }
  public ResultSet executeQuery(String query){
    try{
      this.makeConnection();
    }catch(Exception e){
      this.debug(true);
      this.addMessage("<font color='red'>[sqlBean] query execution error " + e + "</font>");
      return null;
    }
    return this.executeQuery(query, myConn);
  }
  public boolean execute(String query, Connection con){
    boolean success = false;
    try {
      this.strSQL = query;
      this.addMessage("[sqlBean] query : " + query );
      stmt = con.createStatement();
      stmt.execute(query);
      success = true;
      this.addMessage("<font color='green'>[sqlBean]Info: Success= " + success + "<font>");
      this.takeDown();
    }
    catch (Exception e) {
    	e.printStackTrace();
      this.debug(true);
      this.addMessage("<font color='red'>[sqlBean] query execution error " + e + "<HR>Query:" + query + "</font>");
    }
    return success;
  }
  public boolean execute(String query) {
    try{
      this.makeConnection();
    }catch(Exception e){
      this.debug(true);
      this.addMessage("<font color='red'>[sqlBean] query execution error " + e + "<BR>Query:" + query + "</font>");
      return false;
    }
    return this.execute(query, myConn);
  }

  public boolean closeRecordSet() {
    boolean flag = false;
    try {
      if (myRS != null) {
        myRS.close();
        myRS = null;
      }
      flag = true;
    }
    catch (SQLException sqlexception) {
      this.addMessage("<font color='red'>[sqlBean] Recordset close error : " + sqlexception + "</font>");
      errorStr = "Recordset close error : " + sqlexception;
    }
    return flag;
  }

  public abstract void cleanup() throws Exception;

  public void takeDown() {
    try {
      cleanup();
    }
    catch (Exception e) {
      this.addMessage("<font color='orange'>[cleanup:Error] " + e+"</font>");
    }

      try {
        if(this.myRS!=null){
          myRS.close();
          myRS = null;
        }
        if(this.stmt!=null){
          stmt.close();
          stmt = null;
        }
        if(this.myConn!=null){
          myConn.close();
          myConn = null;
        }
      }
      catch (Exception e) {
        this.addMessage("<font color='orange'>[takeDown: Error] " + e+ "</font>");
      }
  }

  //**********************************************************
   //replaces a "pattern" string in a "str" String by "replace" string
   public String replaceString(String str, String pattern, String replace) {
     int s = 0;
     int e = 0;
     StringBuffer result = new StringBuffer();

     while ( (e = str.indexOf(pattern, s)) >= 0) {
       result.append(str.substring(s, e));
       result.append(replace);
       s = e + pattern.length();
     }
     result.append(str.substring(s));
     return result.toString();
   }

//added by upendra
  protected String checkNull(String str) {
    if (str == null || str.trim().equals("")) {
      return "";
    }
    else {
      return str;
    }
  }

  public String getMessage() {
    if (!this.debug) {
      return "";
    }
    String str2ret = "";
    java.util.Iterator itr = this.messages.iterator();
    while (itr.hasNext()) {
      str2ret += itr.next() + "<br>\n";
    }
    return str2ret;
  }
}
