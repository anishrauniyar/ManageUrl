package d2Hawkeye.dts.structure;

import java.util.*;

public class DestField {
  DestTable table;
  String name;
  HashSet sources = new HashSet();
  String businessRule;
  String example;
  String translatedRule;
  String fieldFormat;
  String SN;

  public DestField(String name) {
    this.name = name;
//    System.out.println("[DestField] created with name = "+name);
  }

  public void setDestTable(DestTable t) {
///    System.out.println("[DestField] setting table");
    this.table = t;
  }

  public void addSource(SourceField s) {
//    System.out.println("[DestField] adding source");
    if (this.sources.contains(s)) {
//      System.out.println("[DestField] source aleady added");
      return;
    }
    this.sources.add(s);
  }

  public void setBusinessRule(String rule) {
//    System.out.println("[DestField] setting business rules");
    this.businessRule = rule;
  }

  public String getBusinessRule() {
//    System.out.println("[DestField] getting business rules");
    return this.businessRule;
  }


  public void setExample(String example) {
//    System.out.println("[DestField] setting business rules");
    this.example = example;
  }

  public String getExample() {
//    System.out.println("[DestField] getting business rules");
    return this.example;
  }

  public void setTranslatedRule(String rule) {
//    System.out.println("[DestField] setting business rules");
    this.translatedRule = rule;
  }

  public String getTranslatedRule() {
//    System.out.println("[DestField] getting business rules");
    return this.translatedRule;
  }

  public void setName(String name) {
//    System.out.println("[DestField] setting names");
    this.name = name;
  }

  public String getName() {
//    System.out.println("[DestField] getting names");
    return name;
  }

  public String getTableName() {
//    System.out.println("[DestField] getting table name");
    return this.table.getName();
  }

  public void setFieldFormat(String format) {
//    System.out.println("[DestField] setting field format");
    this.fieldFormat = format;
  }

  public String getFieldFormat() {
//    System.out.println("[DestField] getting field format");
    return this.fieldFormat;
  }

  public HashSet getSource() {
//    System.out.println("[DestField] getting resources");
    return this.sources;
  }

  public String getCategory() {
    if (this.table != null) {
      return this.table.getCategory();
    }
    return "Undefined !!!! Check the data";
  }

  public DestTable getTable() {
    return this.table;
  }

  public void setSN(int sn){
    this.SN = (sn<10?"00"+sn:(sn<100?"0"+sn:""+sn));
  }
  public String getSN(){
    return this.SN;
  }
}
