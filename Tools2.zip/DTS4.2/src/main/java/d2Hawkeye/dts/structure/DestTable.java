package d2Hawkeye.dts.structure;

import java.util.*;

public class DestTable {
  String id;
  String code;
  String desc;
  String name;
  String category;
  boolean processed = false;
  HashSet columns = new HashSet();
  public DestTable(String name) {
//    System.out.println("[DestTable] creating DestTable with name="+name);
    this.name = name;
  }

  public void setId(int id) {
    if (id < 10) {
      this.id = "0" + id;
    }
    else {
      this.id = "" + id;
    }
  }

  public String getId() {
    return this.id;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getCode() {
    return this.code;
  }

  public void setDesc(String desc) {
    this.desc = desc;
  }

  public String getDesc() {
    return this.desc;
  }

  public void setCategory(String category) {
//    System.out.println("[DestTable] setting destination category : "+category);
    this.category = category;
  }

  public String getCategory() {
//    System.out.println("[DestTable] geting category");
    return this.category;
  }

  public void addField(DestField df) {
//    System.out.println("[DestTable] adding destField "+df + " to table "+this.name);
    if (columns.contains(df)) {
//      System.out.println("[DestTable] column already exist");
      return;
    }
    df.setDestTable(this);
    columns.add(df);
  }

  public HashSet getFields() {
    return this.columns;
  }

  public void setName(String name) {
//    System.out.println("[DestTable] setting name");
    this.name = name;
  }

  public String getName() {
//    System.out.println("[DestTable] getting name");
    return this.name;
  }

  public boolean isProcessed() {
    return this.processed;
  }

  public void setProcessed(boolean b) {
    this.processed = b;
  }
}
