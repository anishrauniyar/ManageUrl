package d2Hawkeye.dts.structure;

public class SourceField {
  String name;
  SourceTable table;
  String fieldFormat;
  int setNo;
  public SourceField(String name) {
//    System.out.println("[SourceField] creating source field - "+name);
    this.name = name;
  }

  public void setName(String name) {
///    System.out.println("[SourceField] setting name");
    this.name = name;
  }
  public void setSetNo(int i) {
    //  System.out.println("[DestField] setting set no = "+i);
    this.setNo = i;
  }

  public int getSetNo() {
//    System.out.println("[DestField] getting set no");
    return this.setNo;
  }

  public String getName() {
//    System.out.println("[SourceField] getting name");
    return this.name;
  }

  public void setTable(SourceTable st) {
//    System.out.println("[SourceField] setting source table");
    this.table = st;
  }

  public String getTableName() {
//    System.out.println("[SourceField] getting table name");
    return this.table.getName();
  }

  public void setFieldFormat(String format) {
//    System.out.println("[SourceField] setting field format");
    this.fieldFormat = format;
  }

  public String getFieldFormat() {
//    System.out.println("[SourceField] getting field format");
    return this.fieldFormat;
  }
}
