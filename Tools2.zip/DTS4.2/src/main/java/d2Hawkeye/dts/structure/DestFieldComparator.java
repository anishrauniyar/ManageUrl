package d2Hawkeye.dts.structure;

import java.util.*;

public class DestFieldComparator
    implements Comparator {
  Comparator cmp;
  public DestFieldComparator() {
//    cmp.
  }

  public int compare(Object obj1, Object obj2) {
    String str1, str2;
    if (obj1 instanceof DestField) {
      DestField df1 = (DestField) obj1;
      DestField df2 = (DestField) obj2;
      str1 = df1.getSN()+df1.getName(); // + "." + df1.getSetNo();
      str2 = df2.getSN()+df2.getName(); // + "." + df2.getSetNo();
    }
    else if (obj1 instanceof DestTable) {
      DestTable dt1 = (DestTable) obj1;
      DestTable dt2 = (DestTable) obj2;
      str1 = dt1.getCode() + "." + dt1.getName();
      str2 = dt2.getCode() + "." + dt2.getName();
    }
    else {
      str1 = obj1.toString();
      str2 = obj2.toString();
    }
    return str1.compareTo(str2);
  }

  public boolean compareName(DestField df1, DestField df2) {
    return df2.getName().equalsIgnoreCase(df1.getName());
  }

  /*  public boolean equals(Object obj){
      return true;
    }*/
}
