package d2Hawkeye.dts.structure;

import java.util.*;

public class SourceTable {
  String name;
  HashSet fields = new HashSet();
  public SourceTable(String name) {
//    System.out.println("[SourceTable] creating source table "+name);
    this.name = name;
  }

  public void addField(SourceField sf) {
//    System.out.println("[SourceTable] adding field "+sf);
    if (this.fields.contains(sf)) {
//      System.out.println("[SourceTable] already contains the field");
      return;
    }
    sf.setTable(this);
    this.fields.add(sf);
  }

  public void setName(String name) {
//    System.out.println("[SourceTable] seting name "+name);
    this.name = name;
  }

  public String getName() {
//    System.out.println("[SourceTable] getting name");
    return this.name;
  }
}
