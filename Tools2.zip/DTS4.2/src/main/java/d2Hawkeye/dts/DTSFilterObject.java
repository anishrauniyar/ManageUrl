/*******************************************************************************************************
 *
 * File			: DTSFilterObject.java
 * Created by	: Copied from Pawan K. Shrestha's DTSObject.java
 * Date			:
 *
 * Description	:
 *
 * Modifications	:
 *
 * Date:					Changed by:					Description
 * -----------------------------------------------------------------------------------------------
 *
 *******************************************************************************************************/

package d2Hawkeye.dts;

import java.util.*;

public class DTSFilterObject {
  public String category = "";
  public String SN = "";
  public String setName = "";
  public Vector sourceTable = new Vector();
  public Vector sourceDatabase = new Vector();
  public Vector sourceField = new Vector();
  public Vector sourceFieldFormat = new Vector();
  public Vector sourceDBDotTableDotField = new Vector();
  public Vector targetTable = new Vector();
  public Vector allBusinessRules = new Vector();
  public Vector allTranslatedRules = new Vector();
  public Vector allExamples = new Vector();
  public Vector vectFieldMatched = new Vector();
  public String inExtract="";
  public String rm="";
  public String api="";  
  //public String total="";
  public String hawkeyeExplorer="";
  public String extractVariableNames="";
  public String eligibilityOrparticipant="";

  public String targetField = "";
  public String targetField2Display = "";
  public String fieldFormat = "";
  public String businessRule = "";
  public String translatedRule = "";
  public String example="";
  public String fieldMatched = ""; //w.r.t SourceTableSpace
  public String highlight = "";

  public DTSFilterObject(String strCategory, String strSN, String strSetName,
                   String strSourceDatabase, String strSourceTable,
                   String strSourceField
                   , String strSourceFieldFormat, String strTargetTable,
                   String strTargetField, String strTargetField2Display,
                   String strFieldFormat
                   , String strBusinessRule, String fieldMatched,
                   String highlight,String inExtract,String rm, String api,String hawkeyeExplorer, String extractVariableNames, String eligibilityOrparticipant) 
  {
              
    this.addValues(strCategory, strSN, strSetName, strSourceDatabase, strSourceTable,
              strSourceField,
              strSourceFieldFormat, strTargetTable, strTargetField,
              strTargetField2Display,
              strFieldFormat, strBusinessRule, fieldMatched, highlight,inExtract,rm,api,hawkeyeExplorer,extractVariableNames,eligibilityOrparticipant);
              
              
              
  }

  

  public void addTranslatedRule(String translatedRule){
    this.translatedRule = translatedRule;
    if (!this.allTranslatedRules.contains(translatedRule) &&
        !translatedRule.trim().equals("")) {
      this.allTranslatedRules.add(translatedRule);
    }
  }
  public void addExample(String example){
    this.example = example;
    if (!this.allExamples.contains(example) &&
        !example.trim().equals("")) {
      this.allExamples.add(example);
    }
  }

  public void addValues(String strCategory, String strSN, String strSetName,
          String strSourceDatabase, String strSourceTable,
          String strSourceField, String strSourceFieldFormat
          , String strTargetTable, String strTargetField,
          String strTargetField2Display,
          String strFieldFormat
          , String strBusinessRule, String strFieldMatched,
          String strHighlight,String strInExtract, String strRm, String strApi,String strHawkeyeExplorer, String strExtractVariableNames,String strEligibilityOrparticipant ) {
String fMatched = "y";
category = strCategory;
SN = strSN;
setName = strSetName;
fieldMatched = strFieldMatched;
highlight = strHighlight;
inExtract=strInExtract;  
rm=strRm;
api=strApi;
//total=strTotal;
hawkeyeExplorer=strHawkeyeExplorer; 
extractVariableNames=strExtractVariableNames;
eligibilityOrparticipant=strEligibilityOrparticipant;



if (!sourceDBDotTableDotField.contains("[" + strSourceDatabase + "]." +
                             strSourceTable + "." +
                             strSourceField +
                             " " + strSourceFieldFormat)) {

sourceTable.add(strSourceTable);
sourceDatabase.add(strSourceDatabase);
sourceField.add(strSourceField);
sourceFieldFormat.add(strSourceFieldFormat);
sourceDBDotTableDotField.add("[" + strSourceDatabase + "]." +
                     strSourceTable + "." + strSourceField + " " +
                     strSourceFieldFormat);
if ( (strFieldMatched.trim().equals("")) &&
(!strSourceField.trim().equals(""))) {
fMatched = "n";
}
vectFieldMatched.add(fMatched);
}


if (!targetTable.contains(strTargetTable)) {
targetTable.add(strTargetTable);
}
targetField = strTargetField;
this.targetField2Display = strTargetField2Display;
fieldFormat = strFieldFormat;
businessRule = strBusinessRule;
if (!allBusinessRules.contains(strBusinessRule) &&
!strBusinessRule.trim().equals("")) {
allBusinessRules.add(strBusinessRule);
}
}

}
