package d2Hawkeye.dts.fileParser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpSession;

import scrub.util.web.ColumnWidth;

import au.com.bytecode.opencsv.CSVReader;

import com.missiondata.fileupload.MonitoredDiskFileItem;

import d2Hawkeye.common.connectionPool.ConnectionParameters;
import d2Hawkeye.common.connectionPool.ConnectionPoolXMLParser;
import d2Hawkeye.dts.apTable.APTable;
import d2Hawkeye.dts.apTable.APTableColumn;
import d2Hawkeye.dts.apTable.APTableRow;
import d2Hawkeye.dts.apTable.DatabaseOperator;

/**
 * Parser for a text file separated with delimiter character
 * @author Subash Devkota
 *
 */
public class FileParser {

	private char DELIMITER=',';
	private char QUOTE='\"';
	private int startLine=0;

	private String importLog="";

	private ServletConfig config;

	private DatabaseOperator dbOperator= new DatabaseOperator();


	public String getImportLog() {
		return importLog;
	}

	public char getDELIMITER() {
		return DELIMITER;
	}

	public void setDELIMITER(char delimiter) {
		DELIMITER = delimiter;
	}

	public char getQUOTE() {
		return QUOTE;
	}

	public void setQUOTE(char quote) {
		QUOTE = quote;
	}

	public int getStartLine() {
		return startLine;
	}

	public void setStartLine(int startLine) {
		this.startLine = startLine;
	}

	/**
	 * Parse the fileItem. Create temporary table and populate file data into the table.
	 * @param fileItem
	 * @return
	 */
	public APTable parseFileToTable(MonitoredDiskFileItem fileItem, ServletConfig config) throws Exception{
		this.config=config;
		System.out.println(">>>>>>>>>>>>>>>>>>Config"+this.config);
		InputStream is=fileItem.getInputStream();
		APTable apTable=this.createTempTable(is);
		// Get the new inputstream again from the fileItem.
		this.copyData(apTable, fileItem);
		return apTable;
	}

	/**
	 * Parse the inputstream and create temporary table according to the first line.
	 * @param is
	 * @return
	 */
	private APTable createTempTable(InputStream is ){
    	APTable table= new APTable();
    	try{
	    	CSVReader reader= new CSVReader(new InputStreamReader(is),DELIMITER,QUOTE,startLine);
	    	String[] headerRow=reader.readNext();

	    	if(headerRow!=null){
	    //		String[] firstDataRow= reader.readNext();
		    	dbOperator.connectHawkeyRule();
	    		String tempTableName=dbOperator.createTempTable(headerRow);
	    		table.setTempTableName(tempTableName);
	    		for(int i=0;i<headerRow.length;i++){
		    		String columnName=headerRow[i].replaceAll(" ","_");
		    		APTableColumn column= new APTableColumn(columnName,i);
		    /*
		    		if(firstDataRow!=null){
			    		String colData=firstDataRow[i];
			    		if(colData.startsWith(""+QUOTE)){
			    			column.setEnclosed(true);
			    		}
		    		}
		    	*/
	    			table.addColumn(column);
	    		}
	    	}

    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	finally{
    		dbOperator.takeDown();
    	}
    	return table;
    }


	/**
	 * Copy data from file to table.
	 * Tries to copy using SQLLoader. If gets Exception in SQLLoader, copies using java.
	 * @param apTable
	 * @param fileItem  MonitoredDiskFileItem of the uploaded file
	 * @throws Exception
	 */
	public void copyData(APTable apTable, MonitoredDiskFileItem fileItem) throws Exception{
		try{
			InputStream is=fileItem.getInputStream();
			this.copyDataUsingSQLLoader(apTable,is);
			int count=this.getTableDataCount(apTable.getTempTableName());
			if(count==0){
				throw  new Exception("SQLLoader could not load data from file or file has no data");
			}
		}catch(Exception sqlLoaderExcep){
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+sqlLoaderExcep.getMessage());
			//sqlLoaderExcep.printStackTrace();
			System.out.println("Trying to copy data using java ");
			this.importLog=" SQLLoader could not load data from file \n "+sqlLoaderExcep.getMessage()+" \n Copying data using java";
			InputStream is=fileItem.getInputStream();
			this.copyDataUsingJava(apTable,is);
		}
	}

	/**
	 * Generate unique file name to use for data file, control file and log file .
	 * File name will be same but differenciated by extension.
	 * @return
	 */
	private synchronized String generateFileName(){
		long thisTime=new Date().getTime();
		long sleepTime=1;
		try{
			Thread.sleep(sleepTime); // To make sure the file name is unique
		}catch(Exception e){
			e.printStackTrace();
		}
		String fileName="SQLLdr"+thisTime;
		return fileName;
	}

	/**
	 * Copy data from file to table using SQLLoader.
	 * @param table
	 * @param is
	 * @throws Exception
	 */
	private void copyDataUsingSQLLoader(APTable table, InputStream is) throws Exception{
		String fileName=this.generateFileName();
		String contextPath=config.getServletContext().getRealPath("/");
		fileName=contextPath+"/SqlLoaderFiles/"+fileName;
		String dataFileName=fileName+".txt";
		table.setDataFileName(dataFileName);
    	table.setControlFileName(fileName);  // Do not include the extention .ctl here. As this name will be used by log file too

    	this.writeISToFile(dataFileName,is, table); // write datafile to a file
        this.createControlFileForSQLLoader(table);
    	this.invokeSQLLoaderCommand(table);
    	importLog=this.getFileString(table.getControlFileName()+".log");
    	
    	// set data type size according to length of data in the column
    	dbOperator.connectHawkeyRule();
    	List colmns=table.getColumns();
    	int[] colsSize= new int[colmns.size()];  // array to keep track of max lenght for the columns
    	for(int i=0;i<colsSize.length;i++){
    		colsSize[i]=100;
    	}
		for(int i=0;i<colmns.size();i++){
			String colName="col"+i;
    		String tableName=table.getTempTableName();
    		colsSize[i]=dbOperator.getColumnDataMaxLength(tableName,colName);
    	}
    	dbOperator.takeDown();
		table.setColsMaxSize(colsSize);
    	
    	return ;
	}



	/**
	 * Copy data from file to table using java. This method is to be used only when the SQLLoder can not work.
	 * @param table
	 * @param is
	 * @throws Exception
	 */
	private void copyDataUsingJava(APTable table, InputStream is) throws Exception{

		CSVReader reader= new CSVReader(new InputStreamReader(is),DELIMITER,QUOTE,startLine);
    	dbOperator.connectHawkeyRule();
		String[] row=reader.readNext();
		
		row=reader.readNext();  // To skip the header line data
    	while(row !=null){
    		dbOperator.addRowToTable(table.getTempTableName(),row);
    		row=reader.readNext();
    	}
    	
		
    	List colmns=table.getColumns();
    	int[] colsSize= new int[colmns.size()];  // array to keep track of max lenght for the columns
    	for(int i=0;i<colsSize.length;i++){
    		colsSize[i]=100;
    	}
		for(int i=0;i<colmns.size();i++){
    		String colName="col"+i;
    		String tableName=table.getTempTableName();
    		colsSize[i]=dbOperator.getColumnDataMaxLength(tableName,colName);
    	}
    	
    	dbOperator.takeDown();
    	table.setColsMaxSize(colsSize);
	}

	/**
	 * Display table data in console
	 * @param table
	 */
	public void showTable(APTable table){
    	List columns=table.getColumns();
    	int cols=columns.size();
    	for(int i=0;i<cols;i++){
    		APTableColumn tblColumn=(APTableColumn) columns.get(i);
    		System.out.print("\t"+tblColumn.getName());
    	}
    	System.out.println();
    	List tableData=table.getTableData();
    	int rows=tableData.size();
    	for(int i=0;i<rows;i++){
    		APTableRow row=(APTableRow)tableData.get(i);
    		List rowData=row.getRowData();
    		int cells=rowData.size();
    		for(int j=0;j<cells;j++){
    			System.out.print("\t"+rowData.get(j));
    		}
    		System.out.println();
    	}
    }

	/**
	 * Invoke SQLLoader system command to data from file to table.
	 * @param table
	 * @throws Exception
	 */
	private void invokeSQLLoaderCommand(APTable table) throws Exception{
		String[] command = new String[5];
		command[0]= "sqlldr";
		command[1]= this.getHawkeyRuleConnectionStringForSQLLoader();
		command[2]= "control="+table.getControlFileName();
		command[3]= "log="+table.getControlFileName();
		command[4]= "data="+table.getDataFileName();//+".";   // This name ends with an explicit period, because the file name has no extension. Without the period on the end, SQL*Loader would assume the default extension of .dat.
        System.out.print("SQLLOADER: ");
		for(int i=0;i<command.length;i++){
			System.out.print(command[i]+" ");
		}

		try{
            System.out.println("execution start " );
			Process p=Runtime.getRuntime().exec(command);
            System.out.println("execution end " );
			try {
                System.out.println("WAITING STARTED" );
                InputStream stderr = p.getErrorStream();
                InputStreamReader isr = new InputStreamReader(stderr);
                BufferedReader br = new BufferedReader(isr);

                InputStream stdIn = p.getInputStream();
                InputStreamReader inStdIn = new InputStreamReader(stdIn);
                BufferedReader brStdIn = new BufferedReader(inStdIn);
                String line = null;

                String scrMessage = "";
                while ( (line = brStdIn.readLine()) != null){
                    scrMessage += "\n" + line;
                }
                System.out.println("<SCREEN MESSAGE>" + scrMessage + "\n</SCREEN MESSAGE>");

                line = null;
                scrMessage = "";
                while ( (line = br.readLine()) != null)  {
                    scrMessage += "\n" + line;
                }
                if(!scrMessage.equals("")){
                    System.out.println("<ERR MESSAGE>" + scrMessage + "</ERR MESSAGE>");
                }
				int exitval = p.waitFor();
                System.out.println("WAITING COMPLETE" );
			}

            //catch( InterruptedException ie ) {
                catch( Throwable ie ) {
                System.out.println("ERROR PROCESSING HERE" );
				ie.printStackTrace();
			}
		/*
			BufferedReader in = new BufferedReader( new InputStreamReader(p.getInputStream()));
			String line=null;
			while((line=in.readLine() )!=null)
			{
				System.out.println(line);
			}
			*/
		}catch( Exception e){
			//e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Prepare control file for the table to use in SQLLoader
	 * @param table
	 */
	private synchronized void createControlFileForSQLLoader(APTable table){
		String fileString=	" LOAD DATA \n "+
							"  APPEND INTO TABLE "+table.getTempTableName()+" " +
							" TRAILING NULLCOLS" +  // To handle cases of no data for some cols in some rows
							" ( ";
		List columns=table.getColumns();
		int colsize=columns.size();
		String removeColString=" FILLER ";   // This is to be included for not including particular column. Needed if need to bypass any columns
		removeColString=" ";
		for(int i=0;i<colsize;i++){
			String enclosedString="";
			APTableColumn tableColm=(APTableColumn)columns.get(i);
		//	if(tableColm.isEnclosed()){
				enclosedString=" OPTIONALLY ENCLOSED BY '"+QUOTE+"'";
		//	}
			String colName="col"+i;
			String colString="\n"+ colName+" "+removeColString+" CHAR TERMINATED BY \""+DELIMITER+"\" "+enclosedString;
			//String colString="\n"+ colName+" "+removeColString+" CHAR TERMINATED BY \""+DELIMITER+"\" ";

			if(i+1==colsize){  // The last entry
				fileString+=colString;
			}else{
				fileString+=colString+",";
			}
		}
		fileString+=" )";
		this.writeStringToFile(table.getControlFileName()+".ctl",fileString);  // write the control file

	}

	/**
	 * Write the passed string to the passed file
	 * @param fileName
	 * @param fileString
	 */
	private void writeStringToFile(String fileName, String fileString){
		try {
			File file= new File(fileName);
			file.createNewFile();
	        BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
	        out.write(fileString);
	        out.close();
	    } catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

	/**
	 * Writes the InputStream into the given fileName.
	 * @param fileName
	 * @param is
	 */
	public void writeISToFile(String fileName, InputStream is, APTable table){
		try {
			File file= new File(fileName);
			try{
				file.createNewFile();
			}catch(Exception e){
				e.printStackTrace();
			}
	        BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
	        BufferedReader in = new BufferedReader(new InputStreamReader(is));
	        String str;
	        str=in.readLine();  // escape the first line that contains header

	        str=in.readLine();  // Get the first data line
	      //  System.out.println("First data line of the file is :"+ str);
	        /*
	         * Check whether the data for each column is inclosed in quote or not
	         */
	        String[] colsData=str.split(""+DELIMITER);
	        for(int i=0;i<colsData.length;i++){
	        	String colData=colsData[i];
	        	if(colData.startsWith(""+QUOTE)){
	    			table.setColumnEnclosed(i,true);
	    		}
	        }

	        out.write(str+"\n");

	        while ((str = in.readLine()) != null) {
	           out.write(str+"\n");
	      //     System.out.print(str+"\n");
	        }
	        in.close();
	        out.close();
	    } catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

	/**
	 * Shows the content of the file
	 * @param fileName
	 */
	public void showFile(String fileName){
		try {
	        BufferedReader in = new BufferedReader(new FileReader("fileName"));
	        String str;
	        while ((str = in.readLine()) != null) {
	            System.out.println(str);
	        }
	        in.close();
	    } catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

	public String getFileString(String fileName){
		String fileStr="";
		try {
	        BufferedReader in = new BufferedReader(new FileReader(fileName));
	        String str;
	        while ((str = in.readLine()) != null) {
	        	fileStr+=str+"\n";
	        }
	        in.close();
	    } catch (IOException e) {
	    	e.printStackTrace();
	    }
	    return fileStr;
	}


	/**
	 * Get the no of records in the tabelName in hawkeyerules database
	 * @param tableName
	 * @return
	 * @throws Exception
	 */
	public int getTableDataCount(String tableName) throws Exception{
		int count=0;
		try{
			dbOperator.connectHawkeyRule();
			count=dbOperator.getTableDataCount(tableName);
		}catch(Exception e){
			throw e;
		}finally{
			dbOperator.takeDown();
		}

		return count;
	}

	/**
	 * Get connection string for hawkeyerule database in the format
	 * hawkeyerules/oracle@surya.datacenter.d2hawkeye.net
	 * @author Subash Devkota
	 * @return
	 */
	public String getHawkeyRuleConnectionStringForSQLLoader(){
		String connectionString=config.getInitParameter("SQLLoaderConnection");

		return connectionString;
		/*
		//hawkeyerules/oracle@surya.datacenter.d2hawkeye.net
		ConnectionParameters parms=this.getHawkeyeRuleParameters();
		String userName=parms.getUserName();
		String password=parms.getPassword();
		String url=parms.getUrl();
		url=url.substring(url.indexOf("@")-1);
		String connString=userName+"/"+password+"@"+url;
		System.out.println("Hawkeyrule connection string is:"+connString);
		return  connString;
		*/
	}


	/**
	 * Get connectionParameters for HawkeyeRule database connection
	 * @author Subash Devkota
	 * @return
	 */
/*	private ConnectionParameters getHawkeyeRuleParameters(){
		//String xmlFileName = session.getServletContext().getInitParameter("XMLFileName");
		String xmlFileName = config.getInitParameter("XMLFileName");
		xmlFileName="WEB-INF/classes/dbpool.xml";
		System.out.println("xmlfileName is "+xmlFileName);
	    xmlFileName = config.getServletContext().getRealPath(xmlFileName);
	    ConnectionPoolXMLParser parser = new ConnectionPoolXMLParser();
	    parser.loadDocument(xmlFileName);
	    ConnectionParameters params=parser.getConnectionParametersByAliasName("MDHawkeye->HawkeyeRule");

	    return params;
	}
	*/




}
