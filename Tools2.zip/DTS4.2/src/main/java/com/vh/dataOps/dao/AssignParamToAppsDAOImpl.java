package com.vh.dataOps.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.transaction.Transaction;

import com.vh.dataOps.dto.App;
import com.vh.dataOps.dto.Client;
import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.email.EmailUtility;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;
import com.vh.dataOps.util.ResourceRelease;

import d2Hawkeye.common.connectionPool.ConnectionParameters;
import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

/**
 * 
 * Description: Implementation class of Assign Applications to the Parameter
 * Form, implements AssignParamToAppsDAO.It handles all DB connectivity along
 * with query building for Assign Applications to the Parameter.
 * 
 * @author sjain
 * 
 */

public class AssignParamToAppsDAOImpl implements AssignParamToAppsDAO {

    protected AssignParamToAppsDAOImpl() throws SQLException {
	super();
    }

    @Override
    public List<Client> getAllClients(String userId) throws SQLException {

	List<Client> clientList = new ArrayList<Client>();

	String sql = "SELECT DISTINCT CLIENTID, CLIENTNAME  FROM OAM_CLIENTS "
		+ "  ORDER BY CLIENTID ";

	Client client = null;
	Collections.sort(new ArrayList<String>());
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.OAM_PROD_DB.toUpperCase());

	    stmt = conn.createStatement();

	    rs = stmt.executeQuery(sql);
	    while (rs.next()) {
		client = new Client();
		client.setClientId(rs.getString(1));
		client.setClientName(rs.getString(2));
		clientList.add(client);

	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);
	}

	return clientList;

    }

    @Override
    public List<App> getAllAppList(String paramName, String clientID)
	    throws SQLException {
	List<App> appObjList = new ArrayList<App>();
	App appObj = null;
	List<String> paramValueList = new ArrayList<String>();
	Connection conn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Connection oamConn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.OAM_PROD_DB.toUpperCase());

	ResultSet rs = null;
	ResultSet rs1 = null;

	Statement stmt = null;
	Statement stmt1 = null;

	String sql = "SELECT DISTINCT APPLICATIONID, APPLICATIONNAME  FROM OAM_CLIENTAPPS WHERE CLIENTID = '"
		+ clientID + "'";

	String appSql = " SELECT PARAMVAL FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ clientID + "' AND paramname = '" + paramName + "'  ";
	String paramValSql = " ";

	String allParamValuesSQL = "SELECT A.PARAM_VALUE FROM M_PARAM_VALUES A, M_PARAM_PROPS B WHERE A.PARAMID = B.PARAMID  AND B.PARAM_NAME = '"
		+ paramName + "'";

	try {
	    stmt = oamConn.createStatement();
	    stmt1 = conn.createStatement();

	    rs1 = stmt1.executeQuery(allParamValuesSQL);
	    while (rs1.next()) {
		paramValueList.add(rs1.getString(1));
	    }

	    rs = stmt.executeQuery(sql);
	    while (rs.next()) {
		appObj = new App();
		appObj.setAppId(rs.getString(1));
		appObj.setAppName(rs.getString(2));

		paramValSql = appSql + " AND APPID = '" + rs.getString(1)
			+ "' ";

		rs1 = stmt1.executeQuery(paramValSql);
		if (rs1.next()) {
		    appObj.setAppParamCurrValue(rs1.getString(1));
		} else {
		    appObj.setAppParamCurrValue("UNASSIGNED");
		}

		appObj.setAppParamAllValue(paramValueList);

		appObjList.add(appObj);

	    }
	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);
	    ResourceRelease.releaseResources(oamConn, stmt1, rs1);
	}

	return appObjList;
    }

    @Override
    public List<DataOpsParam> getAllMClientParamsList() throws SQLException {

	List<DataOpsParam> dataOpsParamObjList = new ArrayList<DataOpsParam>();
	String paramSql = " ";

	paramSql = " SELECT PARAMID, PARAM_NAME, " + "       IS_ACTIVE, "
		+ "       PARAM_DESC " + "FROM   M_PARAM_PROPS A "
		+ " WHERE TABLE_TYPE = 'M_CLIENTPARAMS' "
		+ "  ORDER BY A.PARAM_NAME ";

	String valSql = " SELECT A.PARAM_NAME, " + "       B.PARAM_VALUE "
		+ "FROM   M_PARAM_PROPS A, " + "       M_PARAM_VALUES B "
		+ "WHERE   " + "       A.PARAMID = B.PARAMID "
		+ "       AND UPPER(A.PARAM_NAME) = ";

	String valSqlOrderBy = " ORDER BY    B.PARAM_VALUE ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	Statement stmt1 = null;
	DataOpsParam dataOpsParamObj = null;
	List<String> paramValueList = null;

	try {
	    stmt = cnn.createStatement();
	    stmt1 = cnn.createStatement();

	    rs = stmt.executeQuery(paramSql);
	    while (rs.next()) {

		dataOpsParamObj = new DataOpsParam();
		paramValueList = new ArrayList<String>();

		dataOpsParamObj.setParamId(rs.getString(1));
		dataOpsParamObj.setParamName(rs.getString(2));
		dataOpsParamObj.setActiveFlag(rs.getString(3));
		dataOpsParamObj.setParamDesc(rs.getString(4));

		rs1 = stmt1.executeQuery(valSql + " UPPER('" + rs.getString(2)
			+ "') " + valSqlOrderBy);

		while (rs1.next()) {
		    paramValueList.add(rs1.getString(2));
		}

		dataOpsParamObj.setAllParamList(paramValueList);

		dataOpsParamObjList.add(dataOpsParamObj);

	    }

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(null, null, rs1);
	}

	return dataOpsParamObjList;

    }

    @Override
    public String getParamId(String paramName) throws SQLException {

	String paramId = null;

	String valSql = " SELECT PARAMID " + "FROM   M_PARAM_PROPS "
		+ "                   WHERE  UPPER(PARAM_NAME) = UPPER('"
		+ paramName + "') ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;

	try {
	    stmt = cnn.createStatement();

	    rs = stmt.executeQuery(valSql);

	    if (rs.next()) {
		paramId = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	}

	return paramId;

    }

    @Override
    public String getParamDescription(String paramName) throws SQLException {

	String paramDesc = null;

	String valSql = " SELECT PARAM_DESC " + "FROM   M_PARAM_PROPS "
		+ "                   WHERE  UPPER(PARAM_NAME) = UPPER('"
		+ paramName + "') ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;

	try {
	    stmt = cnn.createStatement();

	    rs = stmt.executeQuery(valSql);

	    if (rs.next()) {
		paramDesc = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	}

	return paramDesc;

    }

    @Override
    public void assingAppsToParam(String clientId, List<App> appListObj,
	    String paramId, String paramName, String paramDescription,
	    String userId) throws SQLException, DataOpsException {

	Statement masterstmt = null;
	String helogSchemaName = null;
	Long transactionId = null;
	String errorMessage = null;

	String sql = " ";
	com.atomikos.icatch.jta.UserTransactionManager tm = new com.atomikos.icatch.jta.UserTransactionManager();
	String alias = null;
	ConnectionPoolManager poolMgr = ConnectionPoolManager.getInstance();
	Connection heLogConn = null;

	try {

	    poolMgr.initMasterSchemaDS();

	    poolMgr.initXADataSource(DataOpsUtil.LOG_DB);

	    tm.begin();
	    Transaction tx = tm.getTransaction();

	    poolMgr.enlistMasterResources(tx);

	    heLogConn = poolMgr.getXAConnection(DataOpsUtil.LOG_DB)
		    .getConnection();
	    transactionId = DataOpsUtil.getTransactionId(heLogConn);	    
	    helogSchemaName = ((ConnectionParameters) poolMgr.getConnectionProperties().get(DataOpsUtil.LOG_DB.toUpperCase())).getUserName();
	    App appObj = null;
	    String paramOldValue = null;
	    String paramNewValue = null;
	    String appId = null;
	    int masterCounter = 1;
	    while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + ""
		    + masterCounter) != null) {
		alias = DataOpsUtil.getProperty(
			DataOpsUtil.HAWKEYEMASTER + "" + masterCounter)
			.toUpperCase();

		System.out.println("aliasName====" + alias);

		masterstmt = poolMgr.getXAConnection(alias).getConnection()
			.createStatement();

		for (int i = 0; i < appListObj.size(); i++) {
		    appObj = appListObj.get(i);

		    appId = appObj.getAppId();
		    paramOldValue = appObj.getAppParamOldValue();
		    paramNewValue = appObj.getAppParamNewValue();
		    if (paramNewValue != null && paramNewValue.length() > 0) {
			if ("UNASSIGNED".equalsIgnoreCase(paramOldValue)) {
			    if (paramDescription.length() > 50) {
				paramDescription = paramDescription.substring(
					0, 50);
			    }
			    // insert
			    sql = " INSERT INTO M_CLIENTPARAMS ( CLIENTID , PARAMID, PARAMNAME, PARAMVAL,PARAMTYPE,APPID)	"
				    + " values( '"
				    + clientId
				    + "', '"
				    + paramId
				    + "', '"
				    + paramName
				    + "','"
				    + (paramNewValue!=null ? paramNewValue.replace("'", "''") : paramNewValue) 
				    + "','"
				    + (paramDescription!=null ? paramDescription.replace("'", "''") : paramDescription)
				    + "','" + appId + "')";

			} else {
			    // update
			    sql = "UPDATE M_CLIENTPARAMS A SET A.PARAMVAL = '"
				    + paramNewValue
				    + "'  WHERE A.PARAMNAME = '" + paramName
				    + "'      AND A.CLIENTID = '" + clientId
				    + "'      AND A.PARAMVAL = '"
				    + paramOldValue + "'	  AND A.APPID = '"
				    + appId + "'";

			}

			if (masterstmt.executeUpdate(sql) > 0
				&& masterCounter == 1) {
			    DataOpsUtil
				    .logIntoDatabase(
					    masterstmt, helogSchemaName,
					    clientId,
					    appId,
					    userId,
					    paramName,
					    "UNASSIGNED"
						    .equalsIgnoreCase(paramOldValue) ? null
						    : paramOldValue,
					    paramNewValue,
					    DataOpsUtil.ACTION_ASSIGN_PARAMETER,
					    DataOpsUtil.TABLE_M_CLIENTPARAMS,
					    transactionId);
			}
		    }
		}
		masterCounter += 1;
	    }

	    masterstmt.close();
	    poolMgr.closeConnections();

	    poolMgr.delistAllMasterResource(tx);
	    tm.commit();

	} catch (Exception e) {

	    errorMessage = e.getMessage();
	    try {
		tm.rollback();
	    } catch (Exception e1) {
		e1.printStackTrace();
	    }
	    throw new DataOpsException("Assign Parameter FAILED !!", e);

	} finally {

	    try {

		String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
			DataOpsUtil.TX_ASSIGN_PARAMETER);
		String emailContent = EmailUtility.getAssignParameterContent(
			DataOpsUtil.TX_ASSIGN_PARAMETER, transactionId, userId,
			clientId, appListObj, paramName, errorMessage);

		String emailSendStatus = EmailUtility.sendEmail(userId,
			emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
			: DataOpsUtil.EMAIL_SEND_FAILED;

		DataOpsUtil
			.logEmailTXStatus(transactionId,
				EmailUtility.getSendToAddr(userId),
				EmailUtility.sendFromAddr, emailSubject,
				DataOpsUtil.getEmailLogMessage(errorMessage,
					DataOpsUtil.TX_ASSIGN_PARAMETER,
					transactionId, userId), emailSendStatus);

	    } catch (Exception e) {
		e.printStackTrace();
	    } finally {

		try {
		    poolMgr.closeXAConnections();
		} catch (Exception e) {
		    e.printStackTrace();
		}

	    }
	}

    }

}
