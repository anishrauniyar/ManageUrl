package com.vh.dataOps.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: interface for manage Parameter Form
 * 
 * @author sjain
 * 
 */

public interface ParamManagementDAO {

    /** Returns all the parameter and its values from
     *             M_CLIENTPARAMS table
     * 
     * @return
     * @throws SQLException
     */
    List<DataOpsParam> getAllMClientParamsList() throws SQLException;

    /**
     * Returns all the parameter and its values from M_CLIENTPARAMS table for
     * the input parameter
     * 
     * @return
     * @throws SQLException
     */
    List<DataOpsParam> getMClientParamsList(String paramName)
	    throws SQLException;

    /**
     * Deletes the parameter value against paramName from M_PARAM_VALUES
     * 
     * @param paramName
     * @param paramValue
     * @param userId
     * @throws SQLException
     * @throws DataOpsException
     */
    int deleteParamValue(String paramName, String paramValue, String userId)
	    throws SQLException, DataOpsException;

    /**
     * Deletes the whole parameter from M_PARAM_PROPS and its respective values
     * from M_PARAM_VALUES
     * 
     * @param paramId
     * @param userId
     * @throws SQLException
     * @throws DataOpsException
     */
    int deleteParamAndValue(String paramName, String userId)
	    throws SQLException, DataOpsException;

    /**
     * Insert new parameter values into the M_PARAM_VALUES table Update Existing
     * parameter values into the M_PARAM_VALUES table Update Existing parameter
     * description into the M_PARAM_PROPS table
     * 
     * @param paramName
     * @param oldParamDesc
     * @param newParamDesc
     * @param toUpdateMap
     * @param pValue
     * @param dataOpsUserId
     * @throws SQLException
     * @throws DataOpsException
     */
    void updateParameter(String paramName, String oldParamDesc,
	    String newParamDesc, Map<String, String> toUpdateMap,
	    String[] pValue, String dataOpsUserId) throws SQLException,
	    DataOpsException;

}
