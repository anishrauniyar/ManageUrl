package com.vh.dataOps.dao;

import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: DAO factory for ViewUpdate Parameter.
 * 
 * @author sjain
 * 
 */
public class ViewParamDAOFactory {
    private ViewParamDAOFactory() {

    }

    public static ViewParamDAO getViewParamDAO() throws Exception {
	try {
	    return new ViewParamDAOImpl();
	} catch (Exception e) {
	    throw new DataOpsException(
		    "ViewParamDAOFactory.getViewParamDAO: DataOpsException while getting ViewParamDAO");

	}
    }
}
