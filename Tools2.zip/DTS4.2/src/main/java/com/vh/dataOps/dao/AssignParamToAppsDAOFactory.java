package com.vh.dataOps.dao;

import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: DAO factory for Assign Applications to the Parameter Form.
 * 
 * @author sjain
 * 
 */

public class AssignParamToAppsDAOFactory {
    private AssignParamToAppsDAOFactory() {

    }

    public static AssignParamToAppsDAO getAssignParamToAppsDAO()
	    throws Exception {
	try {
	    return new AssignParamToAppsDAOImpl();
	} catch (Exception e) {
	    throw new DataOpsException(
		    "AssignParamToAppsDAOFactory.getAssignParamToAppsDAO: DataOpsException while getting AssignParamToAppsDAO");

	}
    }
}
