package com.vh.dataOps.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Client DTO
 * 
 * @author sjain
 * 
 */

public class Client implements Serializable {

    private String clientId = null;
    private String clientName = null;
    private List<App> allAppList = null;

    public String getClientId() {
	return clientId;
    }

    public void setClientId(String clientId) {
	this.clientId = clientId;
    }

    public String getClientName() {
	return clientName;
    }

    public void setClientName(String clientName) {
	this.clientName = clientName;
    }

    public List<App> getAllAppList() {
	return allAppList;
    }

    public void setAllAppList(List<App> allAppList) {
	this.allAppList = allAppList;
    }

}
