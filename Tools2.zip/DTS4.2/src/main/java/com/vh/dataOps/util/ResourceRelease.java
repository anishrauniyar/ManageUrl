package com.vh.dataOps.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ResourceRelease {

    /**
     * Release resource for performance improvement
     * 
     * @param conn
     * @param stmt
     * @param rs
     * @throws SQLException
     */
    private ResourceRelease() {
	
    }
    public static void releaseResources(Connection conn, Statement stmt,
	    ResultSet rs) throws SQLException {

	if (conn != null) {
	    conn.close();
	    conn = null;
	}

	if (stmt != null) {
	    stmt.close();
	    stmt = null;
	}

	if (rs != null) {
	    rs.close();
	    rs = null;
	}

    }
}
