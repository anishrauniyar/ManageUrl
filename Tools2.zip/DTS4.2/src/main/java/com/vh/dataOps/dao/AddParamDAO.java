package com.vh.dataOps.dao;

import java.sql.SQLException;

import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: interface for Add Parameter Form
 * 
 * @author sjain
 * 
 */

public interface AddParamDAO {

    /**
     * Insert the parameter and its values into the M_PARAM_PROPS and M_PARAM_VALUES
     * tables
     * 
     * @param dataOpsUserId
     * @param paramName
     * @param paramDisplayName
     * @param paramDesc
     * @param paramValues
     * @throws SQLException
     */
    int addDataOpsParam(String dataOpsUserId, String paramName,
	    String paramDesc, String[] paramValues) throws SQLException,
	    DataOpsException;

}
