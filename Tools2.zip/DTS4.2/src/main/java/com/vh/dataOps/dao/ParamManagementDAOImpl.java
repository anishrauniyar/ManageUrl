package com.vh.dataOps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.email.EmailUtility;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;
import com.vh.dataOps.util.ResourceRelease;

import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

/**
 * 
 * Description: Implementation class of Manage Parameter form, implements
 * ParamManageDAO.It handles all DB connectivity along with query building for
 * Manage parameter Form to retrieve the applications.
 * 
 * @author sjain
 * 
 */

public class ParamManagementDAOImpl implements ParamManagementDAO {

    protected ParamManagementDAOImpl() {
	super();
    }

    /**
     * Returns the list of all DataOpsParam DTO objects from M_CLIENTS and
     * M_CLIENTPARAMS table
     * 
     * @return
     * @throws SQLException
     */

    @Override
    public List<DataOpsParam> getAllMClientParamsList() throws SQLException {

	List<DataOpsParam> dataOpsParamObjList = new ArrayList<DataOpsParam>();
	String paramSql = " ";

	paramSql = " SELECT PARAMID, PARAM_NAME, " + "       IS_ACTIVE, "
		+ "       PARAM_DESC " + "FROM   M_PARAM_PROPS A "
		+ "  ORDER BY PARAM_NAME ";

	String valSql = " SELECT A.PARAM_NAME, " + "       B.PARAM_VALUE "
		+ "FROM   M_PARAM_PROPS A, " + "       M_PARAM_VALUES B "
		+ "WHERE   " + "       A.PARAMID = B.PARAMID "
		+ "       AND UPPER(A.PARAM_NAME) = ";

	String valSqlOrderBy = " ORDER BY    B.PARAM_VALUE ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	Statement stmt1 = null;
	DataOpsParam dataOpsParamObj = null;
	List<String> paramValueList = null;

	try {
	    stmt = cnn.createStatement();
	    stmt1 = cnn.createStatement();

	    rs = stmt.executeQuery(paramSql);
	    while (rs.next()) {

		dataOpsParamObj = new DataOpsParam();
		paramValueList = new ArrayList<String>();

		dataOpsParamObj.setParamId(rs.getString(1));
		dataOpsParamObj.setParamName(rs.getString(2));
		dataOpsParamObj.setActiveFlag(rs.getString(3));
		dataOpsParamObj.setParamDesc(rs.getString(4));

		rs1 = stmt1.executeQuery(valSql + " UPPER('" + rs.getString(2)
			+ "') " + valSqlOrderBy);

		while (rs1.next()) {
		    paramValueList.add(rs1.getString(2));
		}

		dataOpsParamObj.setAllParamList(paramValueList);

		dataOpsParamObjList.add(dataOpsParamObj);

	    }

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(null, null, rs1);
	}

	return dataOpsParamObjList;

    }

    /**
     * Deletes the parameter value against paramName from M_PARAM_VALUES
     * 
     * @param paramName
     * @param paramValue
     * @param userId
     * @throws SQLException
     * @throws DataOpsException
     */
    @Override
    public int deleteParamValue(String paramName, String paramValue,
	    String userId) throws SQLException, DataOpsException {

	int successCnt = 0;
	String errorMessage = null;
	String valSql = " DELETE FROM M_PARAM_VALUES "
		+ "WHERE  PARAMID IN (SELECT PARAMID "
		+ "                   FROM   M_PARAM_PROPS "
		+ "                   WHERE  UPPER(PARAM_NAME) = UPPER('"
		+ paramName + "')) ";

	if (paramValue != null) {
	    valSql += "        AND PARAM_VALUE = '" + paramValue + "'   ";
	} else {
	    valSql += "       AND PARAM_VALUE IS NULL  ";

	}
	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Connection heLogConn = ConnectionPoolManager.getInstance()
		.getConnection(DataOpsUtil.LOG_DB.toUpperCase());

	Statement stmt = null;
	ResultSet rs = null;

	Long transactionId = DataOpsUtil.getTransactionId(heLogConn);

	String paramDesc = null;
	List<String> paramValList = null;

	try {
	    cnn.setAutoCommit(false);
	    heLogConn.setAutoCommit(false);

	    paramDesc = getParamDescription(paramName);
	    paramValList = getParamValueList(paramName);

	    stmt = cnn.createStatement();

	    successCnt = stmt.executeUpdate(valSql);

	    if (successCnt > 0) {
		DataOpsUtil.logIntoDatabase(heLogConn, null, null, userId,
			paramName, paramValue, null,
			DataOpsUtil.ACTION_DELETE_PARAMETER_VALUE,
			DataOpsUtil.TABLE_M_PARAM_VALUES, transactionId);
	    }
	    cnn.commit();
	    heLogConn.commit();

	} catch (SQLException e) {
	    successCnt = 0;
	    errorMessage = e.getMessage();
	    cnn.rollback();
	    heLogConn.rollback();

	    throw new DataOpsException("Parameter value deletion FAILED !!", e);

	} finally {

	    String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
		    DataOpsUtil.TX_DELETE_PARAMETER_VALUE);
	    String emailContent = EmailUtility.getParamMangementContent(
		    DataOpsUtil.TX_DELETE_PARAMETER_VALUE, transactionId,
		    userId, paramName, paramDesc, paramDesc,
		    paramValList.toArray(new String[paramValList.size()]),
		    null, errorMessage, paramValue);

	    String emailSendStatus = EmailUtility.sendEmail(userId,
		    emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
		    : DataOpsUtil.EMAIL_SEND_FAILED;

	    DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
		    .getSendToAddr(userId), EmailUtility.sendFromAddr,
		    emailSubject, DataOpsUtil.getEmailLogMessage(errorMessage,
			    DataOpsUtil.TX_DELETE_PARAMETER_VALUE,
			    transactionId, userId), emailSendStatus);

	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(heLogConn, null, null);

	}

	return successCnt;

    }

    /**
     * Deletes the whole parameter from M_PARAM_PROPS and its respective values
     * from M_PARAM_VALUES
     * 
     * @param paramId
     * @param userId
     * @throws SQLException
     * @throws DataOpsException
     */
    @Override
    public int deleteParamAndValue(String paramName, String userId)
	    throws SQLException, DataOpsException {

	int successCnt = 0;

	

	String paramValSql = " DELETE FROM M_PARAM_VALUES "
		+ "WHERE  PARAMID IN (SELECT PARAMID "
		+ "                   FROM   M_PARAM_PROPS "
		+ "                   WHERE  UPPER(PARAM_NAME) = UPPER('"
		+ paramName + "')) ";

	String paramSql = " DELETE FROM M_PARAM_PROPS "
		+ "                   WHERE  UPPER(PARAM_NAME) = UPPER('"
		+ paramName + "')  ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Connection heLogConn = ConnectionPoolManager.getInstance()
		.getConnection(DataOpsUtil.LOG_DB.toUpperCase());
	Long transactionId = DataOpsUtil.getTransactionId(heLogConn);
	Statement stmt = null;
	ResultSet rs = null;

	List<String> paramValList = null;
	String paramDesc = null;
	String errorMessage = null;
	try {
	    cnn.setAutoCommit(false);
	    heLogConn.setAutoCommit(false);
	    
	    paramDesc = getParamDescription(paramName);
	    stmt = cnn.createStatement();

	    if (stmt.executeUpdate(paramValSql) > 0) {
		paramValList = getParamValueList(paramName);
		for (int i = 0; i < paramValList.size(); i++) {
		    DataOpsUtil.logIntoDatabase(heLogConn, null, null, userId,
			    paramName, paramValList.get(i), null,
			    DataOpsUtil.ACTION_DELETE_PARAMETER_VALUE,
			    DataOpsUtil.TABLE_M_PARAM_VALUES, transactionId);
		}

		successCnt = stmt.executeUpdate(paramSql);
		DataOpsUtil.logIntoDatabase(heLogConn, null, null, userId,
			paramName, null, null,
			DataOpsUtil.ACTION_DELETE_PARAMETER_NAME,
			DataOpsUtil.TABLE_M_PARAM_PROPS, transactionId);
	    }
	    cnn.commit();
	    heLogConn.commit();

	} catch (SQLException e) {
	    successCnt = 0;
	    errorMessage = e.getMessage();
	    cnn.rollback();
	    heLogConn.rollback();

	    throw new DataOpsException(
		    "Parameter and its values deletion FAILED !!", e);

	} finally {
	    String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
		    DataOpsUtil.TX_DELETE_PARAMETER);
	    String emailContent = EmailUtility.getParamMangementContent(
		    DataOpsUtil.TX_DELETE_PARAMETER,
		    transactionId,
		    userId,
		    paramName,
		    paramDesc,
		    paramDesc,
		    (paramValList != null) ? paramValList
			    .toArray(new String[paramValList.size()]) : null,
		    null, errorMessage, null);

	    String emailSendStatus = EmailUtility.sendEmail(userId,
		    emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
		    : DataOpsUtil.EMAIL_SEND_FAILED;

	    DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
		    .getSendToAddr(userId), EmailUtility.sendFromAddr,
		    emailSubject, DataOpsUtil.getEmailLogMessage(errorMessage,
			    DataOpsUtil.TX_DELETE_PARAMETER, transactionId,
			    userId), emailSendStatus);

	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(heLogConn, null, null);

	}

	return successCnt;

    }

    @Override
    public List<DataOpsParam> getMClientParamsList(String paramName)
	    throws SQLException {

	List<DataOpsParam> dataOpsParamObjList = new ArrayList<DataOpsParam>();

	String valSql = " SELECT A.PARAM_NAME,  "
		+ "       A.PARAM_DESC,  "
		+ "       B.PARAM_VALUE,  "
		+ "       CASE WHEN A.TABLE_TYPE = 'M_CLIENTS' THEN  "
		+ "          'Y'  "
		+ "          WHEN A.TABLE_TYPE = 'M_CLIENTPARAMS' THEN  "
		+ "           (SELECT CASE WHEN  COUNT(1) > 0 THEN  "
		+ "                    'Y'  "
		+ "                    ELSE  "
		+ "                    'N'  "
		+ "                END  "
		+ "         FROM M_CLIENTPARAMS C  "
		+ "         WHERE C.PARAMID = A.PARAMID  "
		+ "           AND C.PARAMVAL = B.PARAM_VALUE )  "
		+ "       END AS VAL  "
		+ "FROM M_PARAM_PROPS A, M_PARAM_VALUES B                                                               "
		+ "WHERE A.PARAMID = B.PARAMID  "
		+ "AND UPPER(A.PARAM_NAME) NOT IN (UPPER('CLIENTNAME'),UPPER('CLIENTID'),UPPER('SN'))  "
		+ "AND  UPPER(A.PARAM_NAME) = UPPER('" + paramName + "')  "
		+ "ORDER BY B.PARAM_VALUE ASC ";

	System.out.println("master_db:"+DataOpsUtil.MASTER_DB.toUpperCase());
	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;
	DataOpsParam dataOpsParamObj = new DataOpsParam();
	List<String> assginedParamValueList = new ArrayList<String>();
	List<String> unAssginedParamValueList = new ArrayList<String>();

	try {
	    stmt = cnn.createStatement();

	    rs = stmt.executeQuery(valSql);

	    while (rs.next()) {
		dataOpsParamObj.setParamName(rs.getString(1));
		dataOpsParamObj.setParamDesc(rs.getString(2));
		if ("Y".equalsIgnoreCase(rs.getString(4))) {
		    assginedParamValueList.add(rs.getString(3));
		} else {
		    unAssginedParamValueList.add(rs.getString(3));
		}
	    }

	    dataOpsParamObj.setAssignedParamValList(assginedParamValueList);
	    dataOpsParamObj.setUnAssignedParamValList(unAssginedParamValueList);

	    dataOpsParamObjList.add(dataOpsParamObj);

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	}

	return dataOpsParamObjList;

    }

    private List<String> getParamValueList(String paramName)
	    throws SQLException {

	List<String> paramValueList = new ArrayList<String>();

	String valSql = " SELECT PARAM_VALUE " + "FROM   M_PARAM_VALUES "
		+ "WHERE  PARAMID IN (SELECT PARAMID "
		+ "                   FROM   M_PARAM_PROPS "
		+ "                   WHERE  upper(PARAM_NAME) = upper('"
		+ paramName + "'))  ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;

	try {
	    stmt = cnn.createStatement();

	    rs = stmt.executeQuery(valSql);

	    while (rs.next()) {
		paramValueList.add(rs.getString(1));
	    }

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	}

	return paramValueList;

    }

    private String getParamDescription(String paramName) throws SQLException {

	String paramDesc = null;

	String valSql = " SELECT PARAM_DESC " + "FROM   M_PARAM_PROPS "
		+ "                   WHERE  UPPER(PARAM_NAME) = UPPER('"
		+ paramName + "') ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;

	try {
	    stmt = cnn.createStatement();

	    rs = stmt.executeQuery(valSql);

	    if (rs.next()) {
		paramDesc = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(cnn, stmt, rs);
	}

	return paramDesc;

    }

    @Override
    public void updateParameter(String paramName, String oldParamDesc,
	    String newParamDesc, Map<String, String> modifiedMap,
	    String[] newValues, String userId) throws SQLException,
	    DataOpsException {

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Connection heLogConn = ConnectionPoolManager.getInstance()
		.getConnection(DataOpsUtil.LOG_DB.toUpperCase());

	cnn.setAutoCommit(false);
	heLogConn.setAutoCommit(false);

	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement preparedStatement = null;

	Long transactionId = DataOpsUtil.getTransactionId(heLogConn);

	String errorMessage = null;
	try {
	    
	    // update parameter description
	    String paramDescSql = " UPDATE M_PARAM_PROPS "
		    + "SET    PARAM_DESC = '" + (newParamDesc!=null ? newParamDesc.replace("'", "''") : newParamDesc) + "' "
		    + "WHERE  UPPER(PARAM_NAME) = UPPER('" + paramName + "')  ";

	    if (oldParamDesc.equalsIgnoreCase(newParamDesc)) {
		// do nothing
	    } else {
		stmt = cnn.createStatement();
		if (stmt.executeUpdate(paramDescSql) > 0) {
		    DataOpsUtil.logIntoDatabase(heLogConn, null, null, userId,
			    paramName, oldParamDesc, newParamDesc,
			    DataOpsUtil.ACTION_UPDATE_PARAMETER_DESC,
			    DataOpsUtil.TABLE_M_PARAM_PROPS, transactionId);
		}
	    }

	    // update existing param values

	    int[] recordsCnt;
	    String oldParamVal = null;
	    String newParamVal = null;

	    String existingParamValueSql = " UPDATE M_PARAM_VALUES "
		    + "SET    PARAM_VALUE = ? "
		    + "WHERE  PARAMID = (SELECT PARAMID "
		    + "                  FROM   M_PARAM_PROPS "
		    + "                  WHERE  UPPER(PARAM_NAME) = UPPER('"
		    + paramName + "')) " + "       AND PARAM_VALUE = ?  ";

	    if (modifiedMap != null && modifiedMap.size() > 0) {
		preparedStatement = cnn.prepareStatement(existingParamValueSql);

		for (Map.Entry<String, String> entry : modifiedMap.entrySet()) {
		    oldParamVal = entry.getKey();
		    newParamVal = entry.getValue();

		    preparedStatement.setString(1, newParamVal);
		    preparedStatement.setString(2, oldParamVal);
		    preparedStatement.addBatch();
		}

		recordsCnt = preparedStatement.executeBatch();

		if (recordsCnt.length > 0) {
		    for (Map.Entry<String, String> entry : modifiedMap
			    .entrySet()) {
			oldParamVal = entry.getKey();
			newParamVal = entry.getValue();
			DataOpsUtil
				.logIntoDatabase(
					heLogConn,
					null,
					null,
					userId,
					paramName,
					oldParamVal,
					newParamVal,
					DataOpsUtil.ACTION_INSERT_UPDATE_PARAMETER_VALUE,
					DataOpsUtil.TABLE_M_PARAM_VALUES,
					transactionId);
		    }
		}
	    }

	    // insert new param values

	    String paramIdSql = "SELECT PARAMID FROM M_PARAM_PROPS where upper(PARAM_NAME) = upper('"
		    + paramName + "') ";

	    String insertParamValuesSql = " INSERT INTO M_PARAM_VALUES (PARAMID , PARAM_VALUE) VALUES ";
	    String sql = " ";
	    String paramId = null;

	    if (newValues != null && newValues.length > 0) {
		stmt = cnn.createStatement();

		rs = stmt.executeQuery(paramIdSql);
		if (rs.next()) {
		    paramId = rs.getString(1);
		}

		for (int i = 0; i < newValues.length; i++) {
		    sql = insertParamValuesSql + "( '" + paramId + "' , '"
			    + newValues[i] + "' )";

		    stmt.executeUpdate(sql);
		    DataOpsUtil.logIntoDatabase(heLogConn, null, null, userId,
			    paramName, null, newValues[i],
			    DataOpsUtil.ACTION_ADD_PARAMETER_VALUE,
			    DataOpsUtil.TABLE_M_PARAM_VALUES, transactionId);
		}

	    }

	    cnn.commit();
	    heLogConn.commit();

	} catch (SQLException e) {
	    errorMessage = e.getMessage();
	    cnn.rollback();
	    heLogConn.rollback();

	    throw new DataOpsException(
		    "Parameter Description update FAILED !!", e);

	} finally {

	    String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
		    DataOpsUtil.TX_EDIT_PARAMETER);
	    String emailContent = EmailUtility.getParamMangementContent(
		    DataOpsUtil.TX_EDIT_PARAMETER, transactionId, userId,
		    paramName, oldParamDesc, newParamDesc, newValues,
		    modifiedMap, errorMessage, null);

	    String emailSendStatus = EmailUtility.sendEmail(userId,
		    emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
		    : DataOpsUtil.EMAIL_SEND_FAILED;

	    DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
		    .getSendToAddr(userId), EmailUtility.sendFromAddr,
		    emailSubject, DataOpsUtil.getEmailLogMessage(errorMessage,
			    DataOpsUtil.TX_EDIT_PARAMETER, transactionId,
			    userId), emailSendStatus);

	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease
		    .releaseResources(heLogConn, preparedStatement, null);

	}

    }

}
