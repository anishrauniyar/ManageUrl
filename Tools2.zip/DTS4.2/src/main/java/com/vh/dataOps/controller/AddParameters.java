package com.vh.dataOps.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vh.dataOps.dao.AddParamDAO;
import com.vh.dataOps.dao.AddParamDAOFactory;
import com.vh.dataOps.exception.DataOpsException;

/**
 * Controller for Add Parameter Form.
 * 
 * @author sjain
 * 
 */
public class AddParameters extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String ADD_PARAM = "dataOps/addParam.jsp";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddParameters() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {

	try {
	    response.setContentType("text/html");

	    String dataOpsUserId = (String) request.getSession().getAttribute(
		    "userID");

	    AddParamDAO addParamDAO = AddParamDAOFactory.getAddParamDAO();

	    String paramName = request.getParameter("paramName");

	    String paramDesc = request.getParameter("paramDesc");
	    String[] paramValues = request.getParameterValues("paramValue");

	    addParamDAO.addDataOpsParam(dataOpsUserId, paramName, paramDesc,
		    paramValues);
	    response.sendRedirect(ADD_PARAM + "?successFlag=Record/s saved successfully&addParamDone=1");

	} catch (SQLException e) {
	    response.sendRedirect(ADD_PARAM + "?Err=100&ErrorMessage="
		    + e.getMessage());
	    e.printStackTrace();
	} catch (DataOpsException e) {
	    response.sendRedirect(ADD_PARAM + "?Err=200&ErrorMessage="
		    + e.getMessage() + " ->> " + e.getCause());
	    e.printStackTrace();
	} catch (Exception e) {
	    response.sendRedirect(ADD_PARAM + "?Err=300&ErrorMessage="
		    + e.getMessage());
	    e.printStackTrace();
	}

    }

}
