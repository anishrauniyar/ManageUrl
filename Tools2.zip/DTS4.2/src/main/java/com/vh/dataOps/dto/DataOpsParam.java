package com.vh.dataOps.dto;

import java.io.Serializable;
import java.util.List;

/**
 * DataOpsParam DTO
 * 
 * @author sjain
 * 
 */

public class DataOpsParam implements Serializable {

    private String client = null;
    private String app = null;
    private String paramName = null;
    private String paramCurrValue = null;
    private String paramOldValue = null;

    private String paramDesc = null;
    private List<String> allParamList = null;
    private String activeFlag = null;
    private String paramId = null;

    private List<String> assignedParamValList = null;
    private List<String> unAssignedParamValList = null;

    private String paramTableType = null;

    public List<String> getAssignedParamValList() {
	return assignedParamValList;
    }

    public void setAssignedParamValList(List<String> assignedParamValList) {
	this.assignedParamValList = assignedParamValList;
    }

    public List<String> getUnAssignedParamValList() {
	return unAssignedParamValList;
    }

    public void setUnAssignedParamValList(List<String> unAssignedParamValList) {
	this.unAssignedParamValList = unAssignedParamValList;
    }

    public String getParamId() {
	return paramId;
    }

    public void setParamId(String paramId) {
	this.paramId = paramId;
    }

    public String getActiveFlag() {
	return activeFlag;
    }

    public void setActiveFlag(String activeFlag) {
	this.activeFlag = activeFlag;
    }

    public String getClient() {
	return client;
    }

    public void setClient(String client) {
	this.client = client;
    }

    public String getApp() {
	return app;
    }

    public void setApp(String app) {
	this.app = app;
    }

    public String getParamName() {
	return paramName;
    }

    public void setParamName(String paramName) {
	this.paramName = paramName;
    }

    public String getParamCurrValue() {
	return paramCurrValue;
    }

    public void setParamCurrValue(String paramCurrValue) {
	this.paramCurrValue = paramCurrValue;
    }

    public String getParamDesc() {
	return paramDesc;
    }

    public void setParamDesc(String paramDesc) {
	this.paramDesc = paramDesc;
    }

    public List<String> getAllParamList() {
	return allParamList;
    }

    public void setAllParamList(List<String> allParamList) {
	this.allParamList = allParamList;
    }

    public String getParamOldValue() {
	return paramOldValue;
    }

    public void setParamOldValue(String paramOldValue) {
	this.paramOldValue = paramOldValue;
    }

    public String getParamTableType() {
	return paramTableType;
    }

    public void setParamTableType(String paramTableType) {
	this.paramTableType = paramTableType;
    }

}
