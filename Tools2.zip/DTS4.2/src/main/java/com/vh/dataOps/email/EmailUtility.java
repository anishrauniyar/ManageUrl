package com.vh.dataOps.email;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.vh.dataOps.dto.App;
import com.vh.dataOps.util.DataOpsUtil;
import com.vh.dataOps.util.ResourceRelease;
import com.vh.dataOps.util.TextEncoder;

import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

public class EmailUtility {

    private EmailUtility() {

    }

    public static final String sendFromAddr = "DataOpsAdmin@verscend.com";

    public static boolean sendEmail(String userId, String emailSubject,
	    String emailText) {
	System.out.println("In sendEmail = " + userId);
	boolean msgSent = false;

	String ccAdr = null;

	try {
	    ccAdr = getSend_CC_EmailAddress();
	    Properties props = System.getProperties();
	    String hostFromFixedParam = getSMTPServerDetails("smtphost");

	    // check server status
	    boolean serverStatus = checkServerStatus(hostFromFixedParam, 25);
	    System.out.println("serverStatus = " + serverStatus);
	    // setting properties

	    if (serverStatus) {
		props.setProperty("mail.smtp.host", hostFromFixedParam);
		props.setProperty("mail.smtp.port", "25");
		props.put("mail.transport.protocol", "smtp");

		Session session = Session.getDefaultInstance(props, null);

		Message message = new MimeMessage(session);

		message.setFrom(new InternetAddress(sendFromAddr));// set
		// fromMailer
		InternetAddress[] Addr = { new InternetAddress(
			getSendToAddr(userId)) }; // set
		// toMailer
		message.setRecipients(Message.RecipientType.TO, Addr);
		if (ccAdr != null && !"".equals(ccAdr)) {
		    InternetAddress[] ccaddress = InternetAddress.parse(ccAdr);
		    message.setRecipients(Message.RecipientType.CC, ccaddress);
		}
		// set subject
		message.setSubject(emailSubject);
		// set sent Date
		message.setSentDate(new Date());
		// set Content
		message.setText(emailText);
		// headers type
		message.setHeader("Content-Type", "text/html");

		// smtp auth required or not.
		Transport.send(message);

		msgSent = true;
	    } else {
		msgSent = false;
	    }

	} catch (AddressException e) {
	    msgSent = false;
	    e.printStackTrace();
	} catch (SQLException e) {
	    msgSent = false;
	    e.printStackTrace();
	} catch (MessagingException e) {
	    msgSent = false;
	    e.printStackTrace();
	} catch (Exception e) {
	    msgSent = false;
	    e.printStackTrace();
	}

	System.out.println("Out sendEmail msgSent = " + msgSent);
	return msgSent;

    }

    private static boolean checkServerStatus(String host, int port) {

	boolean serverStatus = false;
	try {

	    Socket socket = null;
	    socket = new Socket(host, port);
	    serverStatus = socket.isConnected();
	    if (socket != null) {
		socket.close();
	    }
	} catch (UnknownHostException e) {
	    serverStatus = false;
	    e.printStackTrace();
	} catch (IOException e) {
	    serverStatus = false;
	    e.printStackTrace();
	}

	return serverStatus;
    }

    public static String getSendToAddr(String userId) throws SQLException {

	String userEmailAddr = null;
	String sql = "SELECT EMAIL FROM ZTBL_DTS_USERS WHERE USERID = '"
		+ userId + "'";

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.DTS_HEUSER_DB.toUpperCase());

	    stmt = conn.createStatement();
	    rs = stmt.executeQuery(sql);
	    if (rs.next()) {
		userEmailAddr = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);

	}
	System.out.println("Userid = " + userId + "  userEmailAddr = "
		+ userEmailAddr);
	return userEmailAddr;

    }

    private static String getSMTPServerDetails(String paramName)
	    throws SQLException {

	String smtpHost = null;
	String sql = "SELECT PARAMVAL FROM   USR_FIXEDPARAMS WHERE PARAMNAME = '"
		+ paramName + "'";

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.LOCAL_HEUSER_DB.toUpperCase());

	    stmt = conn.createStatement();
	    rs = stmt.executeQuery(sql);
	    if (rs.next()) {
		smtpHost = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);
	}

	return smtpHost;

    }

    private static String getSend_CC_EmailAddress() throws SQLException {

	String emailStr = " SELECT LISTAGG(EMAIL, ' , ') "
		+ "         WITHIN GROUP (ORDER BY EMAIL) AS EMAIL_LIST "
		+ "         FROM  ( SELECT  DISTINCT A.EMAIL AS EMAIL FROM  ZTBL_DTS_USERS A "
		+ "        JOIN ZTBL_DTS_USERSANDGROUPS B "
		+ "         ON A.USERID = B.USERID "
		+ "        JOIN ZTBL_DTS_ACCESSRIGHTS C "
		+ "         ON B.USERGROUP = C.USERGROUP "
		+ " WHERE  C.ACCESSGROUP = 'DOP')   ";

	String sendCCEmailAddress = null;

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.DTS_HEUSER_DB.toUpperCase());

	    stmt = conn.createStatement();
	    rs = stmt.executeQuery(emailStr);
	    if (rs.next()) {
		sendCCEmailAddress = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);

	}

	return sendCCEmailAddress;

    }

    public static String getParamMangementContent(String transactionName,
	    Long transactionId, String userId, String parameterName,
	    String parameterOldDesc, String parameterNewDesc,
	    String[] newValues, Map<String, String> modifiedValuesMap,
	    String errorMessage, String paramValueDeleted) {

	String msg = "";
	String successMessageFont = "<font color=\"green\">Successful</font>";
	String failureMessageFont = "<font color=\"red\">Failed</font>";
	String paramValueStr = "";

	if (newValues != null && newValues.length > 0) {
	    for (int i = 0; i < newValues.length; i++) {
		if (DataOpsUtil.TX_DELETE_PARAMETER_VALUE.equalsIgnoreCase(transactionName)) {
		    if (!paramValueDeleted.equalsIgnoreCase(newValues[i])) {
			paramValueStr += " [" + newValues[i] + "]";
		    }
		} else {
		    paramValueStr += " [" + newValues[i] + "]";
		}

	    }
	}

	String paramValueRec = "";
	String oldParamVal = null;
	String newParamVal = null;

	if (parameterOldDesc != null
		&& !parameterOldDesc.equalsIgnoreCase(parameterNewDesc)) {
	    paramValueRec += "                  <tr> "
		    + "                     <td  > Description </td> "
		    + "                     <td  > " + TextEncoder.encode(parameterOldDesc)
		    + " </td> " + "                     <td  > "
		    + TextEncoder.encode(parameterNewDesc) + " </td> " + "                  </tr> ";
	}

	if (modifiedValuesMap != null && modifiedValuesMap.size() > 0) {
	    for (Map.Entry<String, String> entry : modifiedValuesMap.entrySet()) {
		oldParamVal = entry.getKey();
		newParamVal = entry.getValue();

		paramValueStr += " [" + newParamVal + "]";

		paramValueRec += "                  <tr> "
			+ "                     <td  > Value </td> "
			+ "                     <td  > " + TextEncoder.encode(oldParamVal)
			+ " </td> " + "                     <td  > "
			+ TextEncoder.encode(newParamVal) + " </td> " + "                  </tr> ";

	    }
	}

	if (newValues != null && newValues.length > 0) {
	    for (int i = 0; i < newValues.length; i++) {
		paramValueRec += "                  <tr> "
			+ "                     <td  > Value </td> "
			+ "                     <td  > " + TextEncoder.encode(oldParamVal)
			+ " </td> " + "                     <td  > "
			+ TextEncoder.encode(newValues[i]) + " </td> " + "                  </tr> ";
	    }
	}

	String paramDescription = "";
	if (parameterNewDesc != null && errorMessage == null) {
	    paramDescription = parameterNewDesc;
	} else {
	    paramDescription = parameterOldDesc;
	}

	String htmlTxName = errorMessage == null ? successMessageFont
		: failureMessageFont;
	String htmlTxStatus = errorMessage == null ? "SUCCESS" : errorMessage;
	msg = " <html> "
		+ "   <head> "
		+ "      <style type=\"text/css\"> "
		+ "         td { "
		+ "         padding-left: 10px; "
		+ "         font-family: calibri; "
		+ "         } "
		+ "      </style> "
		+ "   </head> "
		+ "   <body> "
		+ "      <table align=\"center\" cellspacing=\"0\" border=\"5\" width=\"500\" height=\"500\" style=\"border-color: aqua; margin-top: 50px; border: solid #0099FF; \" > "
		+ "         <tr height=\"100\" > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               Hello DataOpsUser, "
		+ "               <br><br> " + "               "
		+ transactionName
		+ " is "
		+ htmlTxName
		+ "            </td> "
		+ "         </tr> "
		+ "         <tr > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               <br> "
		+ "               Transaction Details are below : "
		+ "               <br><br> "
		+ "               Transaction Id: <b>"
		+ transactionId
		+ "</b> "
		+ "               <br>User Id: <b>"
		+ userId
		+ "</b> "
		+ "               <br>Transaction Type: <b>"
		+ transactionName
		+ "</b> "
		+ "               <br>Transaction Status: <b>"
		+ htmlTxStatus
		+ "</b> "
		+ "               <br> "
		+ "               <br>Parameter Name: <b>"
		+ parameterName
		+ "</b> "
		+ "               <br>Parameter Description: <b>"
		+ TextEncoder.encode(paramDescription)
		+ "</b> "
		+ "               <br>Parameter Values: <b>"
		+ TextEncoder.encode(paramValueStr)
		+ "</b>  ";
	if (DataOpsUtil.TX_DELETE_PARAMETER_VALUE.equalsIgnoreCase(transactionName)) {
	    msg += "               <br><br>Parameter Value [DELETED]: <b>"
		    + paramValueDeleted + "</b>  ";
	}

	if (DataOpsUtil.TX_EDIT_PARAMETER.equalsIgnoreCase(transactionName)) {
	    msg += "               <table cellspacing=\"0\" border=\"10\" width=\"300\" height=\"20\" style=\"border: black ; border-color: black;\" > "
		    + "                  <tr> "
		    + "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Property </td> "
		    + "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Old value  </td> "
		    + "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > New Value </td> "
		    + "                  </tr> "
		    + paramValueRec
		    + "               </table> " + "               <br> ";
	}
	msg += "               <br> " + "               <br> ";
	msg += "               Thanks,<br> "
		+ "               Data Operation Admin "
		+ "               <br><br> "
		+ "               ** Please do NOT reply to this email. "
		+ "            </td> " + "         </tr> "
		+ "         <tr></tr> " + "      </table> " + "   </body> "
		+ "</html> ";

	return msg;

    }

    public static String getClientParameterContent(String transactionName,
	    Long transactionId, String userId, String clientId, String appId,
	    Map<String, String> mClientOldValueMap,
	    Map<String, String> updatetValMap_MClients,
	    Map<String, String> mClientParamsOldValueMap,
	    Map<String, String> updatetValmap_MClientParams, String errorMessage) {

	String msg = "";
	String successMessageFont = "<font color=\"green\">Successful</font>";
	String failureMessageFont = "<font color=\"red\">Failed</font>";
	String paramValueRec = "";

	String paramName = "";
	String newVal = null;
	String oldVal = null;
	if (updatetValMap_MClients != null && updatetValMap_MClients.size() > 0) {
	    for (Map.Entry<String, String> entry : updatetValMap_MClients
		    .entrySet()) {
		paramName = entry.getKey();
		newVal = entry.getValue();
		oldVal = "UNASSIGNED".equalsIgnoreCase(mClientOldValueMap
			.get(paramName)) ? null : mClientOldValueMap
			.get(paramName);

		paramValueRec += "   <tr> " + "                     <td  > "
			+ clientId + " </td> " + "                     <td  > "
			+ appId + " </td> " + "                     <td  > "
			+ paramName + " </td> "
			+ "                     <td  > " + TextEncoder.encode(oldVal) + " </td> "
			+ "                     <td  > " + TextEncoder.encode(newVal) + " </td> "
			+ "                  </tr> ";

	    }
	}

	if (updatetValmap_MClientParams != null
		&& updatetValmap_MClientParams.size() > 0) {
	    for (Map.Entry<String, String> entry : updatetValmap_MClientParams
		    .entrySet()) {

		paramName = entry.getKey();
		newVal = entry.getValue();
		oldVal = mClientParamsOldValueMap.get(paramName);

		paramValueRec += "   <tr> " + "                     <td  > "
			+ clientId + " </td> " + "                     <td  > "
			+ appId + " </td> " + "                     <td  > "
			+ paramName + " </td> "
			+ "                     <td  > " + TextEncoder.encode(oldVal) + " </td> "
			+ "                     <td  > " + TextEncoder.encode(newVal) + " </td> "
			+ "                  </tr> ";

	    }
	}

	String htmlTxName = errorMessage == null ? successMessageFont
		: failureMessageFont;
	String htmlTxStatus = errorMessage == null ? "SUCCESS" : errorMessage;
	msg = " <html> "
		+ "   <head> "
		+ "      <style type=\"text/css\"> "
		+ "         td { "
		+ "         padding-left: 10px; "
		+ "         font-family: calibri; "
		+ "         } "
		+ "      </style> "
		+ "   </head> "
		+ "   <body> "
		+ "      <table align=\"center\" cellspacing=\"0\" border=\"5\" width=\"500\" height=\"500\" style=\"border-color: aqua; margin-top: 50px; border: solid #0099FF; \" > "
		+ "         <tr height=\"100\" > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               Hello DataOpsUser, "
		+ "               <br><br> " + "               "
		+ transactionName
		+ " is "
		+ htmlTxName
		+ "            </td> "
		+ "         </tr> "
		+ "         <tr > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               <br> "
		+ "               Transaction Details are below : "
		+ "               <br><br> "
		+ "               Transaction Id: <b>"
		+ transactionId
		+ "</b> "
		+ "               <br>User Id: <b>"
		+ userId
		+ "</b> "
		+ "               <br>Transaction Type: <b>"
		+ transactionName
		+ "</b> "
		+ "               <br>Transaction Status: <b>"
		+ htmlTxStatus
		+ "</b> "
		+ "               <br> "
		+ "               <br> "
		+ "               <br> ";

	msg += "               <table cellspacing=\"0\" border=\"10\" width=\"300\" height=\"20\" style=\"border: black ; border-color: black;\" > "
		+ "                  <tr> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > ClientId </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > AppId </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Parameter Name </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Old value  </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > New Value </td> "
		+ "                  </tr> "

		+ paramValueRec
		+ "               </table> "
		+ "               <br> ";
	msg += "               <br> " + "               <br> ";
	msg += "               Thanks,<br> "
		+ "               Data Operation Admin "
		+ "               <br><br> "
		+ "               ** Please do NOT reply to this email. "
		+ "            </td> " + "         </tr> "
		+ "         <tr></tr> " + "      </table> " + "   </body> "
		+ "</html> ";

	return msg;

    }

    public static String getCopyToParameterContent(String transactionName,
	    Long transactionId, String userId, String destinationClientID,
	    String destinationAppID, String sourceClientID, String sourceAppID,
	    String errorMessage) {

	String msg = "";
	String successMessageFont = "<font color=\"green\">Successful</font>";
	String failureMessageFont = "<font color=\"red\">Failed</font>";
	String paramValueRec = "";

	paramValueRec += "   <tr> " + "                     <td  > "
		+ sourceClientID + " </td> " + "                     <td  > "
		+ sourceAppID + " </td> " + "                     <td  > "
		+ "ALL PARAMETERS" + " </td> " + "                     <td  > "
		+ destinationClientID + " </td> "
		+ "                     <td  > " + destinationAppID + " </td> "
		+ "                  </tr> ";

	String htmlTxName = errorMessage == null ? successMessageFont
		: failureMessageFont;
	String htmlTxStatus = errorMessage == null ? "SUCCESS" : errorMessage;
	msg = " <html> "
		+ "   <head> "
		+ "      <style type=\"text/css\"> "
		+ "         td { "
		+ "         padding-left: 10px; "
		+ "         font-family: calibri; "
		+ "         } "
		+ "      </style> "
		+ "   </head> "
		+ "   <body> "
		+ "      <table align=\"center\" cellspacing=\"0\" border=\"5\" width=\"500\" height=\"500\" style=\"border-color: aqua; margin-top: 50px; border: solid #0099FF; \" > "
		+ "         <tr height=\"100\" > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               Hello DataOpsUser, "
		+ "               <br><br> " + "               "
		+ transactionName
		+ " is "
		+ htmlTxName
		+ "            </td> "
		+ "         </tr> "
		+ "         <tr > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               <br> "
		+ "               Transaction Details are below : "
		+ "               <br><br> "
		+ "               Transaction Id: <b>"
		+ transactionId
		+ "</b> "
		+ "               <br>User Id: <b>"
		+ userId
		+ "</b> "
		+ "               <br>Transaction Type: <b>"
		+ transactionName
		+ "</b> "
		+ "               <br>Transaction Status: <b>"
		+ htmlTxStatus
		+ "</b> "
		+ "               <br> "
		+ "               <br> "
		+ "               <br> ";

	msg += "               <table cellspacing=\"0\" border=\"10\" width=\"300\" height=\"20\" style=\"border: black ; border-color: black;\" > "
		+ "                  <tr> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Source ClientId </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Source AppId </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Parameter Name </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Destination ClientId  </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Destination AppId </td> "
		+ "                  </tr> "

		+ paramValueRec
		+ "               </table> "
		+ "               <br> ";
	msg += "               <br> " + "               <br> ";
	msg += "               Thanks,<br> "
		+ "               Data Operation Admin "
		+ "               <br><br> "
		+ "               ** Please do NOT reply to this email. "
		+ "            </td> " + "         </tr> "
		+ "         <tr></tr> " + "      </table> " + "   </body> "
		+ "</html> ";

	return msg;

    }

    public static String getAssignParameterContent(String transactionName,
	    Long transactionId, String userId, String clientId,
	    List<App> appListObj, String paramName, String errorMessage) {

	String msg = "";
	String successMessageFont = "<font color=\"green\">Successful</font>";
	String failureMessageFont = "<font color=\"red\">Failed</font>";
	String paramValueRec = "";

	String newVal = null;
	String oldVal = null;

	App appObj = null;

	String appId = null;
	if (appListObj != null && appListObj.size() > 0) {

	    for (int i = 0; i < appListObj.size(); i++) {
		appObj = appListObj.get(i);

		appId = appObj.getAppId();
		oldVal = appObj.getAppParamOldValue();
		newVal = appObj.getAppParamNewValue();
		if (newVal != null && newVal.length() > 0) {

		    paramValueRec += "   <tr> "
			    + "                     <td  > " + clientId
			    + " </td> " + "                     <td  > "
			    + appId + " </td> "
			    + "                     <td  > " + paramName
			    + " </td> " + "                     <td  > "
			    + TextEncoder.encode(oldVal) + " </td> "
			    + "                     <td  > " + TextEncoder.encode(newVal)
			    + " </td> " + "                  </tr> ";
		}

	    }

	}

	String htmlTxName = errorMessage == null ? successMessageFont
		: failureMessageFont;
	String htmlTxStatus = errorMessage == null ? "SUCCESS" : errorMessage;
	msg = " <html> "
		+ "   <head> "
		+ "      <style type=\"text/css\"> "
		+ "         td { "
		+ "         padding-left: 10px; "
		+ "         font-family: calibri; "
		+ "         } "
		+ "      </style> "
		+ "   </head> "
		+ "   <body> "
		+ "      <table align=\"center\" cellspacing=\"0\" border=\"5\" width=\"500\" height=\"500\" style=\"border-color: aqua; margin-top: 50px; border: solid #0099FF; \" > "
		+ "         <tr height=\"100\" > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               Hello DataOpsUser, "
		+ "               <br><br> " + "               "
		+ transactionName
		+ " is "
		+ htmlTxName
		+ "            </td> "
		+ "         </tr> "
		+ "         <tr > "
		+ "            <td style=\"border: 6px solid rgb(0, 51, 102);\"> "
		+ "               <br> "
		+ "               Transaction Details are below : "
		+ "               <br><br> "
		+ "               Transaction Id: <b>"
		+ transactionId
		+ "</b> "
		+ "               <br>User Id: <b>"
		+ userId
		+ "</b> "
		+ "               <br>Transaction Type: <b>"
		+ transactionName
		+ "</b> "
		+ "               <br>Transaction Status: <b>"
		+ htmlTxStatus
		+ "</b> "
		+ "               <br> "
		+ "               <br> "
		+ "               <br> ";

	msg += "               <table cellspacing=\"0\" border=\"10\" width=\"300\" height=\"20\" style=\"border: black ; border-color: black;\" > "
		+ "                  <tr> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > ClientId </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > AppId </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Parameter Name </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > Old value  </td> "
		+ "                     <td style=\"background-color: rgb(0, 51, 102); color: white;\" > New Value </td> "
		+ "                  </tr> "

		+ paramValueRec
		+ "               </table> "
		+ "               <br> ";
	msg += "               <br> " + "               <br> ";
	msg += "               Thanks,<br> "
		+ "               Data Operation Admin "
		+ "               <br><br> "
		+ "               ** Please do NOT reply to this email. "
		+ "            </td> " + "         </tr> "
		+ "         <tr></tr> " + "      </table> " + "   </body> "
		+ "</html> ";

	return msg;

    }

}
