package com.vh.dataOps.dao;

import java.sql.SQLException;
import java.util.List;

import com.vh.dataOps.dto.App;
import com.vh.dataOps.dto.Client;
import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: interface for Assign Parameter to Applications Form
 * 
 * @author sjain
 * 
 */

public interface AssignParamToAppsDAO {

    /**
     * Returns the list of all the clients
     * 
     * @param userId
     * @return
     * @throws SQLException
     */
    List<Client> getAllClients(String userId) throws SQLException;

    /**
     * Returns App List of all applications against client Id and parameter
     * Name.
     * 
     * @param paramName
     * @param clientID
     * @return
     * @throws SQLException
     */
    List<App> getAllAppList(String paramName, String clientID)
	    throws SQLException;

    List<DataOpsParam> getAllMClientParamsList() throws SQLException;

    String getParamDescription(String paramName) throws SQLException;

    String getParamId(String paramName) throws SQLException;

    void assingAppsToParam(String clientId, List<App> appListObj,
	    String parameterId, String paramName, String parameterDescription,
	    String dataOpsUserId) throws SQLException, DataOpsException;
}
