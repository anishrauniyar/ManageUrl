package com.vh.dataOps.dto;

import java.io.Serializable;
import java.util.List;

/**
 * App DTO
 * 
 * @author sjain
 * 
 */

public class App implements Serializable {

    public App(String applicationId) {
	appId = applicationId;
    }

    public App() {
	// TODO Auto-generated constructor stub
    }

    private String appId = null;
    private String appName = null;
    private String appParamName = null;
    private String appParamCurrValue = null;
    private List<String> appParamAllValueList = null;
    
    private String appParamOldValue = null;
    private String appParamNewValue = null;

    public String getAppParamOldValue() {
        return appParamOldValue;
    }

    public void setAppParamOldValue(String appParamOldValue) {
        this.appParamOldValue = appParamOldValue;
    }

    public String getAppParamNewValue() {
        return appParamNewValue;
    }

    public void setAppParamNewValue(String appParamNewValue) {
        this.appParamNewValue = appParamNewValue;
    }

    public String getAppParamName() {
	return appParamName;
    }

    public void setAppParamName(String appParamName) {
	this.appParamName = appParamName;
    }

    public String getAppParamCurrValue() {
	return appParamCurrValue;
    }

    public void setAppParamCurrValue(String appParamCurrValue) {
	this.appParamCurrValue = appParamCurrValue;
    }

    public List<String> getAppParamAllValue() {
	return appParamAllValueList;
    }

    public void setAppParamAllValue(List<String> appParamAllValue) {
	this.appParamAllValueList = appParamAllValue;
    }

    public String getAppId() {
	return appId;
    }

    public void setAppId(String appId) {
	this.appId = appId;
    }

    public String getAppName() {
	return appName;
    }

    public void setAppName(String appName) {
	this.appName = appName;
    }

}
