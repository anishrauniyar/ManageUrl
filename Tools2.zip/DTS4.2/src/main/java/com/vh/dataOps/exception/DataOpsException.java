package com.vh.dataOps.exception;

/**
 * DataOpsException class
 * 
 * @author sjain
 * 
 */

public class DataOpsException extends Exception {

    private static final long serialVersionUID = 1L;

    public DataOpsException(String msg) {
	super(msg);
    }

    /**
     * supported only in 1.4
     */
    public DataOpsException(Throwable t) {
	super(t);
    }

    /**
     * supported only in 1.4
     */
    public DataOpsException(String msg, Throwable t) {
	super(msg, t);
    }

}
