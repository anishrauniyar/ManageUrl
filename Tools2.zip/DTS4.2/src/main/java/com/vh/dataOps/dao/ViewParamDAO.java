package com.vh.dataOps.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.vh.dataOps.dto.App;
import com.vh.dataOps.dto.Client;
import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: interface for ViewUpdate Parameter Form
 * 
 * @author sjain
 * 
 */

public interface ViewParamDAO {

    /**
     * Get the list of all application App DTO objects against client Id.
     * 
     * @param clientId
     * @return
     * @throws SQLException
     */
    List<App> getAllApps(String clientId) throws SQLException;

    /**
     * Returns the list of DataOpsParam DTO from M_CLIENTS & M_CLIENTPARAM table
     * 
     * @param clientId
     * @param appId
     * @param tableName
     * @return
     * @throws SQLException
     */
    List<DataOpsParam> getDataOpsParam(String clientId, String appId,
	    String tableName) throws SQLException;

    /**
     * Returns the list of DataOpsParam DTO from M_CLIENTS & M_CLIENTPARAM table
     * 
     * @param clientId
     * @param appId
     * @param tableName
     * @return
     * @throws SQLException
     */
    List<DataOpsParam> getNotAssignedDataOpsParam(String clientId,
	    String appId, String tableName) throws SQLException;

    /**
     * Returns the list of all the clients
     * 
     * @param userId
     * @return
     * @throws SQLException
     */
    List<Client> getAllClients(String userId) throws SQLException;
    
    /**
     * Returns the list of all the clients from OAM schema
     * 
     * @param userId
     * @return
     * @throws SQLException
     */
    List<Client> getAllOAMClients(String userId) throws SQLException;

    /**
     * Updates the M_CLIENTS & M_CLIENTPARAM tables with the new parameter
     * values
     * 
     * @param client
     * @param appId
     * @param updateMap
     * @param paramMergedMap
     * @param mClientParamValueMap
     * @param dataOpsUserId
     * @param mClientValueMap
     * @return
     * @throws SQLException
     * @throws DataOpsException
     */
    int updateDataOpsParam(String client, String appId,
	    Map<String, String> updateMap, Map<String, String> paramMergedMap,
	    Map<String, String> mClientParamValueMap, String dataOpsUserId,
	    Map<String, String> mClientValueMap) throws SQLException,
	    DataOpsException;

   
    /**
     * @param sourceClientID
     * @param sourceAppID
     * @param destinationClientID
     * @param destinationAppID
     * @param dataOpsUserId
     * @throws SQLException
     * @throws DataOpsException
     */
    
    void copyMClientParameters(String sourceClientID, String sourceAppID,
    	    String destinationClientID,String destinationAppID,
    	    String dataOpsUserId)throws SQLException,
    	    DataOpsException;
    
    void copyMClientParamParameters(String sourceClientID, String sourceAppID,
    	    String destinationClientID,String destinationAppID,
    	    String dataOpsUserId)throws SQLException,
    	    DataOpsException;
    
    void copyAllParameters(String sourceClientID, String sourceAppID,
	    String destinationClientID,String destinationAppID,
	    String dataOpsUserId)throws SQLException,
	    DataOpsException;

}
