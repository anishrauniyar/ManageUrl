package com.vh.dataOps.util;

/** Encodes for assigning value in form components*/
public class TextEncoder{
	public static String encode( String p){
		if ( p== null || "".equals(p.trim())) return "";
		int pLen = p.length();
		int count = 0;
		char c;
		StringBuffer sb = new StringBuffer( pLen+1);
		for(count=0; count < pLen; count++){
			c = p.charAt( count);
			switch(c){
				case '\'' : sb.append("&#39;"); break;	//Quote
				case '\"' : sb.append("&#34;"); break;	//Double Quote
				case '<'  : sb.append("&lt;");  break;	//
				case '>'  : sb.append("&gt;");  break;
				case '&'  : sb.append("&amp;"); break;
				    //3.4.1.01
				case '+': sb.append("&#43;"); break;	//plus
				case '-'  : sb.append("&#45;"); break;
				case '/'  : sb.append("&#47;"); break;
				default: sb.append( c);
			}
		}
	return sb.toString();
	}
	
	/**
	 * 
	 * @param appName
	 * @return
	 */
	public static String replaceSpecialChars(String appName) {

		if (appName != null && !"".equals(appName)) {

		    appName = appName.replace("\\", "\\\\");
		    appName = appName.replace("\'", "\\\'");
		    appName = appName.replace("\"", "\\\"");
		  
		}

		return appName;
	    }
	
	/*--- Encodes slash, quote and double quote only for JavaScript --*/
	public static String encodeJS_Old( String p){
		if ( p== null || "".equals(p.trim())) return "";
		int pLen = p.length();
		int count = 0;
		char c;
		StringBuffer sb = new StringBuffer( pLen+1);
		for(count=0; count < pLen; count++){
			c = p.charAt( count);
			switch(c){
                case '\\' : sb.append("\\\\");
					break;	//Quote
				case '\'' : sb.append("\\\'");
					break;	//Quote
				case '\"' : sb.append("\\\"");
					break;	//Double Quote
				case '\r' : sb.append("");
					break;
				case '\t' : sb.append("");
					break;
				case '\f' : sb.append("");
					break;
				case '\n' : sb.append("");
					break;
				default: sb.append( c);
			}
		}
	return sb.toString();
	}

	public static String encodeJS(String p){
		if ( p== null || "".equals(p.trim())) return "";
		String t=p.trim();
		String replacePattern1	= "[^a-zA-Z0-9_:;'`~!@&#/?.,><%\\^\\$*()\\-+=|\"\\{\\}\\[\\]\\\\]";
		String replacePattern2	= "\"";
		String replacePattern3	= "'";
		String replacePattern4	= "[\\\\]";        
        t = t.replaceAll(replacePattern1," ");
		t = t.replaceAll(replacePattern4,"\\\\\\\\");    
		t = t.replaceAll(replacePattern3,"\\\\'");
		t = t.replaceAll(replacePattern2,"\\\\'");
        return t;
	}

    public static String formatThisText(String p)
    {
        // This function is used to break the string longer than 40 characters in length into a string of lines, each of  40 characters long.
        // This function is written to keep uniform the size of buttons in the d2Hawkeye4/BrowseKnowledge/LevelK02.jsp page.
        String knlgVal=p;
	    String formattedKnlgVal="";
	    int x=40;
    	int breakCounter=0;
	    int dashCounter=0;
	    for(x=40;knlgVal.length()/x>=1;x=x+40)
	    {
		    if(knlgVal.charAt(x)==' ')
            {
                formattedKnlgVal+=knlgVal.substring(x-40,x)+"<br>";
            }
	    	else
		    {
			    formattedKnlgVal+=knlgVal.substring(x-40,x)+"-<br>";
			    dashCounter++;
		    }
		    breakCounter++;
	    }
		if(formattedKnlgVal.length()-breakCounter-dashCounter<knlgVal.length())
        {
            formattedKnlgVal+=knlgVal.substring(formattedKnlgVal.length()-4*(breakCounter+dashCounter),knlgVal.length());
        }
        return formattedKnlgVal;
    }

    public static String encodeHTML( String param){
		if (param == null) return "";
        while(param.indexOf("<")!=-1 || param.indexOf(">")!= -1 || param.indexOf(" ")!= -1){
            param=param.replaceAll("<", "&lt;");
            param=param.replaceAll(">", "&gt;");
            param=param.replaceAll(" ", "&nbsp;");
        }
        return param;
    }
}
