package com.vh.dataOps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transaction;

import com.vh.dataOps.dto.App;
import com.vh.dataOps.dto.Client;
import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.email.EmailUtility;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;
import com.vh.dataOps.util.ResourceRelease;

import d2Hawkeye.common.connectionPool.ConnectionParameters;
import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

/**
 * 
 * Description: Implementation class of ViewUpdate Parameter form, implements
 * ViewParamDAO.It handles all DB connectivity along with query building for
 * ViewUpdate Form to retrieve all the clients objects.
 * 
 * @author sjain
 * 
 */

public class ViewParamDAOImpl implements ViewParamDAO {

    protected ViewParamDAOImpl() {
	super();
    }

    private Map<String, List<String>> masterClientMap = null;
    private Map<String, List<String>> masterClientParamMap = null;

    public Map<String, List<String>> getMasterClientMap() {
	return masterClientMap;
    }

    public void setMasterClientMap(Map<String, List<String>> masterClientMap) {
	this.masterClientMap = masterClientMap;
    }

    public Map<String, List<String>> getMasterClientParamMap() {
	return masterClientParamMap;
    }

    public void setMasterClientParamMap(
	    Map<String, List<String>> masterClientParamMap) {
	this.masterClientParamMap = masterClientParamMap;
    }

    /**
     * Returns list of App DTO objects
     * 
     * @param clientId
     * @return
     * @throws SQLException
     */
    @Override
    public List<App> getAllApps(String clientId) throws SQLException {
	if (clientId == null)
	    return null;
	List<App> appList = new ArrayList<App>();

	if (clientId == null || "".equals(clientId))
	    throw new NullPointerException(
		    "Null or blank clientId id not allowed");

	String sql = "SELECT DISTINCT APPLICATIONID, APPLICATIONNAME  FROM OAM_CLIENTAPPS WHERE CLIENTID = '"
		+ clientId + "'";

	App app = null;

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.OAM_PROD_DB.toUpperCase());

	    stmt = conn.createStatement();

	    rs = stmt.executeQuery(sql);
	    while (rs.next()) {
		app = new App(rs.getString(1));
		app.setAppName(rs.getString(2));
		appList.add(app);

	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);
	}

	return appList;

    }

    /**
     * Returns the list of DataOpsParam DTO objects from M_CLIENTS and
     * M_CLIENTPARAMS tables
     * 
     * @param clientId
     * @param appId
     * @param tableName
     * @return
     * @throws SQLException
     */
    @Override
    public List<DataOpsParam> getDataOpsParam(String clientId, String appId,
	    String tableName) throws SQLException {
	if (clientId == null || "".equals(clientId))
	    return null;

	List<DataOpsParam> dataOpsParamObjList = new ArrayList<DataOpsParam>();
	String paramSql = " ";

	if (DataOpsUtil.TABLE_M_CLIENTS.equalsIgnoreCase(tableName)) {

	    paramSql = " SELECT PARAM_NAME  , "
		    + "CASE  WHEN PARAM_NAME = 'CLIENTNAME'  THEN  "
		    + "TO_CHAR(A.CLIENTNAME) "
		    + " WHEN PARAM_NAME = 'CONTRACTTYPE'  THEN  "
		    + "TO_CHAR(A.CONTRACTTYPE) "
		    + " WHEN PARAM_NAME = 'CLIENTTYPE'  THEN  "
		    + "TO_CHAR(A.CLIENTTYPE) "
		    + " WHEN PARAM_NAME = 'STAGE'  THEN  "
		    + "TO_CHAR(A.STAGE) "
		    + " WHEN PARAM_NAME = 'USE_YN'  THEN  "
		    + "TO_CHAR(A.USE_YN) "
		    + " WHEN PARAM_NAME = 'EXCLUDEINELIGMEMS'  THEN  "
		    + "TO_CHAR(A.EXCLUDEINELIGMEMS) "
		    + " WHEN PARAM_NAME = 'EXCLUDEINELIGCLMS'  THEN  "
		    + "TO_CHAR(A.EXCLUDEINELIGCLMS) "
		    + " WHEN PARAM_NAME = 'ELIGSTARTREFDAY'  THEN  "
		    + "TO_CHAR(A.ELIGSTARTREFDAY) "
		    + " WHEN PARAM_NAME = 'ELIGENDREFDAY'  THEN  "
		    + "TO_CHAR(A.ELIGENDREFDAY) "
		    + " WHEN PARAM_NAME = 'MMTYPEFLOAT'  THEN  "
		    + "TO_CHAR(A.MMTYPEFLOAT) "
		    + " WHEN PARAM_NAME = 'RCODE_YN'  THEN  "
		    + "TO_CHAR(A.RCODE_YN) "
		    + " WHEN PARAM_NAME = 'IPDAYSCALLOGIC'  THEN  "
		    + "TO_CHAR(A.IPDAYSCALLOGIC) "
		    + " WHEN PARAM_NAME = 'ROLLUPRXCLM_YN'  THEN  "
		    + "TO_CHAR(A.ROLLUPRXCLM_YN) "
		    + " WHEN PARAM_NAME = 'CHECKDISCHRG_YN'  THEN  "
		    + "TO_CHAR(A.CHECKDISCHRG_YN) "
		    + " WHEN PARAM_NAME = 'CHECKPOSFORADMISSION_YN'  THEN  "
		    + "TO_CHAR(A.CHECKPOSFORADMISSION_YN) "
		    + " WHEN PARAM_NAME = 'CHECKSUPPLYDAYSFORMOI'  THEN  "
		    + "TO_CHAR(A.CHECKSUPPLYDAYSFORMOI) "
		    + " WHEN PARAM_NAME = 'USESTICKY'  THEN  "
		    + "TO_CHAR(A.USESTICKY) "
		    + " WHEN PARAM_NAME = 'CUSTOMSTDRPT'  THEN  "
		    + "TO_CHAR(A.CUSTOMSTDRPT) "
		    + " WHEN PARAM_NAME = 'INCLUDEDUALCOV'  THEN  "
		    + "TO_CHAR(A.INCLUDEDUALCOV) "
		    + " WHEN PARAM_NAME = 'ISIMPLCLIENT'  THEN  "
		    + "TO_CHAR(A.ISIMPLCLIENT) "
		    + " WHEN PARAM_NAME = 'USESTDRPT'  THEN  "
		    + "TO_CHAR(A.USESTDRPT) "
		    + " WHEN PARAM_NAME = 'CHECKMMFOR4KEYS'  THEN  "
		    + "TO_CHAR(A.CHECKMMFOR4KEYS) "
		    + " WHEN PARAM_NAME = 'USEQRM'  THEN  "
		    + "TO_CHAR(A.USEQRM) "
		    + " WHEN PARAM_NAME = 'USEARI'  THEN  "
		    + "TO_CHAR(A.USEARI) "
		    + " WHEN PARAM_NAME = 'KEYLVL'  THEN  "
		    + "TO_CHAR(A.KEYLVL) "
		    + " WHEN PARAM_NAME = 'CS_QUERY_TIMEOUT'  THEN  "
		    + "TO_CHAR(A.CS_QUERY_TIMEOUT) "
		    + " WHEN PARAM_NAME = 'ALLOWED_FRONT_CONNECTION_COUNT'  THEN  "
		    + "TO_CHAR(A.ALLOWED_FRONT_CONNECTION_COUNT) "
		    + " WHEN PARAM_NAME = 'CS_ALLOWED_REPORTS'  THEN  "
		    + "TO_CHAR(A.CS_ALLOWED_REPORTS) "
		    + " WHEN PARAM_NAME = 'ROW_COUNT'  THEN  "
		    + "TO_CHAR(A.ROW_COUNT) "
		    + " WHEN PARAM_NAME = 'MEMCENTRIC_YN'  THEN  "
		    + "TO_CHAR(A.MEMCENTRIC_YN) "
		    + " WHEN PARAM_NAME = 'USEGOLDRPT'  THEN  "
		    + "TO_CHAR(A.USEGOLDRPT) "
		    + " WHEN PARAM_NAME = 'USEGOLDPLUS4RPT'  THEN  "
		    + "TO_CHAR(A.USEGOLDPLUS4RPT) "
		    + " WHEN PARAM_NAME = 'CLIENTPROCESSTYPE'  THEN  "
		    + "TO_CHAR(A.CLIENTPROCESSTYPE) "
		    + " WHEN PARAM_NAME = 'PARTKEY'  THEN  "
		    + "TO_CHAR(A.PARTKEY) "
		    + " WHEN PARAM_NAME = 'ALLOWMULTIDIAGS'  THEN  "
		    + "TO_CHAR(A.ALLOWMULTIDIAGS) "
		    + " WHEN PARAM_NAME = 'USEPARTITION'  THEN  "
		    + "TO_CHAR(A.USEPARTITION) "
		    + " WHEN PARAM_NAME = 'USECOMPRESSION'  THEN  "
		    + "TO_CHAR(A.USECOMPRESSION) "
		    + "END AS CURRENT_VALUE, PARAM_DESC "
		    + "FROM M_PARAM_PROPS LEFT OUTER JOIN  "
		    + "( SELECT * FROM M_CLIENTS WHERE CLIENTID = '"
		    + clientId
		    + "') A ON 1=1 "
		    + "WHERE TABLE_TYPE = 'M_CLIENTS' "
		    + " AND PARAM_NAME NOT IN ('SN', 'CLIENTID','CLIENTNAME')  "
		    + " AND IS_ACTIVE <> 'N'  " + "ORDER BY 1 ";

	    
	    System.out.println("master_db:"+DataOpsUtil.MASTER_DB.toUpperCase());
	    setMasterClientMap(getMClientMap());

	    Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.MASTER_DB.toUpperCase());
	    Statement stmt = null;
	    ResultSet rs = null;
	    DataOpsParam dataOpsParamObj = null;
	    List<String> allParamList = null;
	    try {
		stmt = cnn.createStatement();

		rs = stmt.executeQuery(paramSql);
		while (rs.next()) {
		    dataOpsParamObj = new DataOpsParam();

		    dataOpsParamObj.setClient(clientId);
		    dataOpsParamObj.setApp(appId);
		    dataOpsParamObj.setParamName(rs.getString(1));
		    if (rs.getString(2) != null) {
			dataOpsParamObj.setParamCurrValue(rs.getString(2));
		    } else {
			dataOpsParamObj.setParamCurrValue("UNASSIGNED");
		    }

		    dataOpsParamObj.setParamDesc(rs.getString(3));

		    allParamList = getMasterClientMap().get(rs.getString(1));

		    dataOpsParamObj.setAllParamList(allParamList);
		    dataOpsParamObjList.add(dataOpsParamObj);
		}
	    } finally {
		ResourceRelease.releaseResources(cnn, stmt, rs);
	    }

	} else if (DataOpsUtil.TABLE_M_CLIENTPARAMS.equalsIgnoreCase(tableName)) {

	    List<String> paramValueList = null;

	    paramSql = " SELECT " + "         DISTINCT PARAMNAME , "
		    + "         PARAMVAL  , "
		    + "         B.PARAM_DESC           " + "      FROM "
		    + "         M_CLIENTPARAMS A,  M_PARAM_PROPS B        "
		    + "      WHERE " + "         APPID = '" + appId
		    + "'                 " + "         AND CLIENTID = '"
		    + clientId
		    + "' AND A.PARAMID = B.PARAMID ORDER BY  PARAMNAME ";

	    String valSql = " SELECT " + "   B.PARAMNAME, "
		    + "   A.PARAM_VALUE  " + " " + "FROM "
		    + "   M_PARAM_VALUES A, " + "   ( SELECT "
		    + "         DISTINCT PARAMID , "
		    + "         PARAMNAME           " + "      FROM "
		    + "         M_CLIENTPARAMS          " + "      WHERE "
		    + "         APPID = '" + appId + "'                 "
		    + "         AND CLIENTID = '" + clientId + "' "
		    + "   ) B  " + "WHERE "
		    + "   A.PARAMID = B.PARAMID AND  UPPER(B.PARAMNAME) =   ";

	    String valSqlOrderBy = " ORDER BY    A.PARAM_VALUE ";

	    Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.MASTER_DB.toUpperCase());
	    Statement stmt = null;
	    ResultSet rs = null;
	    ResultSet rs1 = null;
	    Statement stmt1 = null;
	    DataOpsParam dataOpsParamObj = null;

	    try {
		stmt = cnn.createStatement();
		stmt1 = cnn.createStatement();

		rs = stmt.executeQuery(paramSql);

		while (rs.next()) {

		    dataOpsParamObj = new DataOpsParam();
		    paramValueList = new ArrayList<String>();

		    dataOpsParamObj.setClient(clientId);
		    dataOpsParamObj.setApp(appId);

		    dataOpsParamObj.setParamName(rs.getString(1));
		    dataOpsParamObj.setParamCurrValue(rs.getString(2));
		    dataOpsParamObj.setParamDesc(rs.getString(3));

		    rs1 = stmt1.executeQuery(valSql + " Upper('"
			    + rs.getString(1) + "') " + valSqlOrderBy);

		    while (rs1.next()) {
			paramValueList.add(rs1.getString(2));
		    }

		    dataOpsParamObj.setAllParamList(paramValueList);

		    dataOpsParamObjList.add(dataOpsParamObj);

		}

	    } finally {
		ResourceRelease.releaseResources(cnn, stmt, rs);
		ResourceRelease.releaseResources(null, null, rs1);

	    }
	} else {
	    // Client or AppID doesn't exist - No action will be performed
	}

	return dataOpsParamObjList;

    }

    /**
     * Returns the list Client DTO objects
     * 
     * @param userId
     * @return
     * @throws SQLException
     */
    @Override
    public List<Client> getAllClients(String userId) throws SQLException {
	List<Client> clientList = new ArrayList<Client>();

	if (userId == null || "".equals(userId))
	    throw new NullPointerException(
		    "Null or blank userId id not allowed");

	String sql = "SELECT DISTINCT CLIENTID, CLIENTNAME  FROM OAM_CLIENTS ORDER BY CLIENTID ";

	Client client = null;

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.OAM_PROD_DB.toUpperCase());

	    stmt = conn.createStatement();

	    rs = stmt.executeQuery(sql);
	    while (rs.next()) {
		client = new Client();
		client.setClientId(rs.getString(1));
		client.setClientName(rs.getString(2));
		clientList.add(client);

	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);

	}

	return clientList;

    }

    /**
     * Returns the list Client DTO objects from OAM
     * 
     * @param userId
     * @return
     * @throws SQLException
     */
    @Override
    public List<Client> getAllOAMClients(String userId) throws SQLException {
	List<Client> clientList = new ArrayList<Client>();

	if (userId == null || "".equals(userId))
	    throw new NullPointerException(
		    "Null or blank userId id not allowed");

	String sql = "SELECT DISTINCT CLIENTID, CLIENTNAME  FROM OAM_CLIENTS ORDER BY CLIENTID ";

	Client client = null;

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.OAM_PROD_DB.toUpperCase());

	    stmt = conn.createStatement();

	    rs = stmt.executeQuery(sql);
	    while (rs.next()) {
		client = new Client();
		client.setClientId(rs.getString(1));
		client.setClientName(rs.getString(2));
		clientList.add(client);

	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);

	}

	return clientList;

    }

    /**
     * Returns the map holding all active parameters and their possible values
     * from M_PARAM_PROPS for M_CLIENTS parameters
     * 
     * @return
     * @throws SQLException
     */
    private Map<String, List<String>> getMClientMap() throws SQLException {

	Map<String, List<String>> mClientMap = new HashMap<String, List<String>>();
	List<String> paramList = new ArrayList<String>();

	List<String> paramValueList = null;

	String paramSql = "SELECT DISTINCT A.PARAM_NAME "
		+ "FROM M_PARAM_PROPS A "
		+ "WHERE A.TABLE_TYPE = 'M_CLIENTS' AND UPPER(A.PARAM_NAME) <> 'CLIENTNAME' "
		+ "  AND UPPER(A.PARAM_NAME) <> 'SN' AND A.IS_ACTIVE <> 'N' "
		+ "  ORDER BY A.PARAM_NAME ";

	String sql = " SELECT A.PARAM_NAME,B.PARAM_VALUE  "
		+ "FROM M_PARAM_PROPS A, "
		+ "     M_PARAM_VALUES B "
		+ "WHERE A.PARAMID = B.PARAMID "
		+ "  AND A.TABLE_TYPE = 'M_CLIENTS' AND UPPER(A.PARAM_NAME) <> 'CLIENTNAME' "
		+ "  AND UPPER(A.PARAM_NAME) <> 'SN' AND A.IS_ACTIVE <> 'N' ";

	String pValSql = " ";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	try {

	    stmt = cnn.createStatement();

	    rs = stmt.executeQuery(paramSql);
	    while (rs.next()) {
		paramList.add(rs.getString(1));
	    }

	    String paramName = "";

	    for (int i = 0; i < paramList.size(); i++) {
		paramValueList = new ArrayList<String>();
		pValSql = sql;
		paramName = paramList.get(i);

		pValSql += " AND UPPER(A.PARAM_NAME) = UPPER('" + paramName
			+ "') " + "  ORDER BY A.PARAM_NAME ";

		rs1 = stmt.executeQuery(pValSql);

		while (rs1.next()) {
		    if (rs1.getString(2) != null) {
			paramValueList.add(rs1.getString(2));
		    }
		}

		mClientMap.put(paramName, paramValueList);
	    }
	} finally {

	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(null, null, rs1);

	}

	return mClientMap;

    }

    /**
     * Returns the list of DataOpsParam DTO objects from M_CLIENTS and
     * M_CLIENTPARAMS tables
     * 
     * @param clientId
     * @param appId
     * @param tableName
     * @return
     * @throws SQLException
     */
    @Override
    public List<DataOpsParam> getNotAssignedDataOpsParam(String clientId,
	    String appId, String tableName) throws SQLException {
	if (clientId == null || "".equals(clientId))
	    return null;

	List<DataOpsParam> dataOpsParamObjList = new ArrayList<DataOpsParam>();
	String paramSql = " ";

	List<String> paramValueList = null;

	// added now

	paramSql = " SELECT A.PARAM_NAME,B.PARAM_DESC FROM (  "
		+ "SELECT DISTINCT PARAM_NAME "
		+ "                 "
		+ "FROM   M_PARAM_PROPS "
		+ "WHERE  TABLE_TYPE = 'M_CLIENTPARAMS' "
		+ "MINUS "
		+ "SELECT DISTINCT PARAMNAME "
		+ "FROM   M_CLIENTPARAMS "
		+ "WHERE  APPID = '"
		+ appId
		+ "' "
		+ "       AND CLIENTID = '"
		+ clientId
		+ "')  A, M_PARAM_PROPS B        WHERE A.PARAM_NAME = B.PARAM_NAME   ORDER BY A.PARAM_NAME ";

	String valSql = "  SELECT B.PARAM_NAME, " + "       A.PARAM_VALUE "
		+ "FROM   M_PARAM_VALUES A, "
		+ "       (SELECT DISTINCT PARAMID, "
		+ "                        PARAM_NAME "
		+ "        FROM   M_PARAM_PROPS "
		+ "        WHERE  TABLE_TYPE = 'M_CLIENTPARAMS' "
		+ "        MINUS " + "        SELECT DISTINCT PARAMID, "
		+ "                        PARAMNAME "
		+ "        FROM   M_CLIENTPARAMS " + "        WHERE  APPID = '"
		+ appId + "' " + "               AND CLIENTID = '" + clientId
		+ "') B " + "WHERE  A.PARAMID = B.PARAMID "
		+ "       AND UPPER(B.PARAM_NAME) = ";

	String valSqlOrderBy = " ORDER BY    A.param_value";

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	Statement stmt1 = null;
	DataOpsParam dataOpsParamObj = null;

	try {
	    stmt = cnn.createStatement();
	    stmt1 = cnn.createStatement();

	    rs = stmt.executeQuery(paramSql);
	    while (rs.next()) {

		dataOpsParamObj = new DataOpsParam();
		paramValueList = new ArrayList<String>();

		dataOpsParamObj.setClient(clientId);
		dataOpsParamObj.setApp(appId);

		dataOpsParamObj.setParamName(rs.getString(1));
		dataOpsParamObj.setParamCurrValue("UNASSIGNED");
		dataOpsParamObj.setParamDesc(rs.getString(2));

		rs1 = stmt1.executeQuery(valSql + " Upper('" + rs.getString(1)
			+ "') " + valSqlOrderBy);

		while (rs1.next()) {
		    paramValueList.add(rs1.getString(2));
		}

		dataOpsParamObj.setAllParamList(paramValueList);

		dataOpsParamObjList.add(dataOpsParamObj);

	    }

	} finally {

	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(null, null, rs1);
	}

	return dataOpsParamObjList;

    }

    /**
     * Updates the M_CLIENTS & M_CLIENTPARAM tables with the new parameter
     * values
     * 
     * @param clientId
     * @param appId
     * @param updateMap
     * @param paramMergedMap
     * @param mClientParamsOldValueMap
     * @param userId
     * @param mClientOldValueMap
     * @return
     * @throws SQLException
     * @throws DataOpsException
     */
    @Override
    public int updateDataOpsParam(String clientId, String appId,
	    Map<String, String> updateMap, Map<String, String> paramMergedMap,
	    Map<String, String> mClientParamsOldValueMap, String userId,
	    Map<String, String> mClientOldValueMap) throws SQLException,
	    DataOpsException {

	Map<String, String> updatetValMap_MClients = DataOpsUtil
		.compareKeysAndValues(updateMap, mClientOldValueMap);

	Map<String, String> updatetValmap_MClientParams = null;
	if (appId != null) {
	    updatetValmap_MClientParams = DataOpsUtil.compareKeysAndValues(
		    updateMap, paramMergedMap);
	}

	String sql = " ";
	String paramName = "";
	String newVal = "";
	String oldVal = "";

	Statement masterstmt = null;

	ResultSet rs = null;
	Long transactionId = null;

	int mClientsRecCnt = -1;
	int mClientParamsRecCnt = -1;

	int recordUpdatedCnt = -1;

	String errorMessage = null;
	String clientName = getOAMClientName(clientId);
	String clientExistSql = " SELECT COUNT(1) FROM M_CLIENTS WHERE  CLIENTID = '"
		+ clientId + "' ";
	int clientCnt = 0;
	com.atomikos.icatch.jta.UserTransactionManager tm = new com.atomikos.icatch.jta.UserTransactionManager();

	String alias = null;
	ConnectionPoolManager poolMgr = ConnectionPoolManager.getInstance();
	String helogSchemaName = null;
	Connection heLogConn = null;
	DataOpsParam propsParam = null;
	List<DataOpsParam> propsParamList = new ArrayList<DataOpsParam>();

	try {

	    poolMgr.initMasterSchemaDS();

	    poolMgr.initXADataSource(DataOpsUtil.LOG_DB);

	    tm.begin();
	    Transaction tx = tm.getTransaction();

	    poolMgr.enlistMasterResources(tx);

	    heLogConn = poolMgr.getXAConnection(DataOpsUtil.LOG_DB)
		    .getConnection();
	    transactionId = DataOpsUtil.getTransactionId(heLogConn);
	    helogSchemaName = ((ConnectionParameters) poolMgr.getConnectionProperties().get(DataOpsUtil.LOG_DB.toUpperCase())).getUserName();
	    int masterCounter = 1;
	    if (updatetValMap_MClients != null
		    && updatetValMap_MClients.size() > 0) {

		while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + ""
			+ masterCounter) != null) {
		    alias = DataOpsUtil.getProperty(
			    DataOpsUtil.HAWKEYEMASTER + "" + masterCounter)
			    .toUpperCase();

		    System.out.println("aliasName====" + alias);

		    masterstmt = poolMgr.getXAConnection(alias).getConnection()
			    .createStatement();

		    rs = masterstmt.executeQuery(clientExistSql);

		    if (rs.next()) {
			clientCnt = rs.getInt(1);
		    }

		    if (clientCnt == 0) {
			sql = " INSERT INTO   M_clients (CLIENTID, CLIENTNAME) VALUES ('"
				+ clientId + "', '" + clientName.replaceAll("'", "''") + "') ";
            System.out.println("SQL:"+sql);
			masterstmt.executeUpdate(sql);
		    }

		    // update

		    sql = " UPDATE M_CLIENTS SET ";

		    for (Map.Entry<String, String> entry : updatetValMap_MClients
			    .entrySet()) {
			sql += " , " + entry.getKey() + " = '"
				+ entry.getValue() + "' ";
		    }

		    sql += " WHERE CLIENTID = '" + clientId + "' ";

		    sql = sql.replaceFirst(",", " ");

		    mClientsRecCnt = masterstmt.executeUpdate(sql);

		    if (mClientsRecCnt > 0 && masterCounter == 1) {
			for (Map.Entry<String, String> entry : updatetValMap_MClients
				.entrySet()) {
			    paramName = entry.getKey();
			    newVal = entry.getValue();
			    oldVal = mClientOldValueMap.get(paramName);

			    DataOpsUtil
				    .logIntoDatabase(
					    masterstmt,
					    helogSchemaName,
					    clientId,
					    appId,
					    userId,
					    paramName,
					    "UNASSIGNED"
						    .equalsIgnoreCase(oldVal) ? null
						    : oldVal,
					    newVal,
					    DataOpsUtil.ACTION_INSERT_UPDATE_PARAMETER_VALUE,
					    DataOpsUtil.TABLE_M_CLIENTS,
					    transactionId);
			}
		    }

		    masterCounter += 1;
		}
		// logging into database

	    }
	    masterCounter = 1;
	    if (appId != null && updatetValmap_MClientParams != null
		    && updatetValmap_MClientParams.size() > 0) {

		while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + ""
			+ masterCounter) != null) {
		    alias = DataOpsUtil.getProperty(
			    DataOpsUtil.HAWKEYEMASTER + "" + masterCounter)
			    .toUpperCase();
		    System.out.println("aliasNameApp====" + alias);

		    masterstmt = poolMgr.getXAConnection(alias).getConnection()
			    .createStatement();
		    if (masterCounter == 1) {
			propsParamList = getPropsParamList(
				updatetValmap_MClientParams, masterstmt);
		    }

		    String parametersql = " ";
		    for (int i = 0; i < propsParamList.size(); i++) {

			propsParam = propsParamList.get(i);

			parametersql = " MERGE INTO M_CLIENTPARAMS A "
				+ "  USING ( " + "         SELECT '"
				+ propsParam.getParamId()
				+ "' AS PARAMID, '"
				+ propsParam.getParamName()
				+ "' AS PARAM_NAME , '"
				+ propsParam.getParamCurrValue()
				+ "' AS PARAM_VALUE  , '"
				+ (propsParam.getParamDesc()!=null ? propsParam.getParamDesc().replace("'", "''") : propsParam.getParamDesc())
				+ "' AS PARAM_DESC "
				+ "         FROM dual "
				+ "        ) B "
				+ "     ON (A.PARAMID = B.PARAMID AND A.CLIENTID = '"
				+ clientId
				+ "' AND A.APPID = '"
				+ appId
				+ "') "
				+ "  WHEN MATCHED THEN "
				+ "      UPDATE SET A.PARAMVAL = B.PARAM_VALUE "
				+ "      WHERE A.PARAMID = B.PARAMID  "
				+ "       AND A.CLIENTID = '"
				+ clientId
				+ "' "
				+ "       AND A.APPID = '"
				+ appId
				+ "'  "
				+ "  WHEN NOT MATCHED THEN "
				+ "    INSERT (CLIENTID,PARAMID,PARAMNAME,PARAMVAL,PARAMTYPE,APPID)    "
				+ "    VALUES ( '"
				+ clientId
				+ "', B.PARAMID , B.PARAM_NAME , B.PARAM_VALUE, SubStr(B.PARAM_DESC, 1,50),'"
				+ appId + "') ";

			mClientParamsRecCnt = masterstmt
				.executeUpdate(parametersql);

			// logging into Database
			paramName = propsParam.getParamName();
			newVal = propsParam.getParamCurrValue();
			oldVal = mClientParamsOldValueMap.get(paramName);
			if (oldVal != null) {
			    // the parameter is already assigned to the
			    // application
			} else {
			    // Update the IS_ACTIVE Flag in M_PARAM_PROPS table
			    if (masterCounter == 1) {
				String paramPropUpdateSql = " UPDATE  M_PARAM_PROPS SET IS_ACTIVE = 'Y' WHERE UPPER(PARAM_NAME) = UPPER('"
					+ paramName + "') ";
				masterstmt.executeUpdate(paramPropUpdateSql);
			    }
			}

			if (mClientParamsRecCnt > 0 && masterCounter == 1) {
			    DataOpsUtil
				    .logIntoDatabase(
					    masterstmt,
					    helogSchemaName,
					    clientId,
					    appId,
					    userId,
					    paramName,
					    oldVal,
					    newVal,
					    DataOpsUtil.ACTION_INSERT_UPDATE_PARAMETER_VALUE,
					    DataOpsUtil.TABLE_M_CLIENTPARAMS,
					    transactionId);
			}

		    }
		    masterCounter += 1;

		}
	    }
	    recordUpdatedCnt = mClientsRecCnt + mClientParamsRecCnt;
	    masterstmt.close();
	    poolMgr.closeConnections();

	    poolMgr.delistAllMasterResource(tx);
	    tm.commit();

	} catch (Exception e) {
	    e.printStackTrace();
	    errorMessage = e.getMessage();
	    try {
		tm.rollback();
	    } catch (Exception e1) {
		e1.printStackTrace();
	    }
	    /*if (updatetValMap_MClients != null
		    && updatetValMap_MClients.size() > 0 && mClientsRecCnt < 0) {
		throw new DataOpsException(
			"M_CLIENTS Parameters Update Failed", e);
	    } else if (updatetValmap_MClientParams != null
		    && updatetValmap_MClientParams.size() > 0
		    && mClientParamsRecCnt < 0) {
		throw new DataOpsException(
			"M_CLIENTPARAMS Parameters Update Failed", e);
	    }*/
	    throw new DataOpsException(
			"Client Parameters Update Failed", e);

	} finally {

	    try {

		String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
			DataOpsUtil.TX_CLIENT_PARAMETER_UPDATE);
		String emailContent = EmailUtility.getClientParameterContent(
			DataOpsUtil.TX_CLIENT_PARAMETER_UPDATE, transactionId,
			userId, clientId, appId, mClientOldValueMap,
			updatetValMap_MClients, mClientParamsOldValueMap,
			updatetValmap_MClientParams, errorMessage);

		String emailSendStatus = EmailUtility.sendEmail(userId,
			emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
			: DataOpsUtil.EMAIL_SEND_FAILED;

		DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
			.getSendToAddr(userId), EmailUtility.sendFromAddr,
			emailSubject, DataOpsUtil.getEmailLogMessage(
				errorMessage,
				DataOpsUtil.TX_CLIENT_PARAMETER_UPDATE,
				transactionId, userId), emailSendStatus);

	    } catch (Exception e) {
		e.printStackTrace();
	    } finally {

		try {
		    poolMgr.closeXAConnections();
		} catch (Exception e) {
		    e.printStackTrace();
		}

	    }

	}

	return recordUpdatedCnt;

    }

    private List<DataOpsParam> getPropsParamList(
	    Map<String, String> updatetValmap_MClientParams, Statement statement)
	    throws SQLException {

	DataOpsParam propsParam = null;

	ResultSet rs = null;

	String key = null;
	String value = null;
	List<DataOpsParam> propsParamList = new ArrayList<DataOpsParam>();

	for (Map.Entry<String, String> entry : updatetValmap_MClientParams
		.entrySet()) {
	    key = entry.getKey();
	    value = entry.getValue();
	    propsParam = new DataOpsParam();

	    String sql = " SELECT PARAMID, PARAM_NAME , '" + value
		    + "' AS PARAM_VALUE  , PARAM_DESC "
		    + "				         FROM M_PARAM_PROPS  " + "	"
		    + "			         WHERE PARAM_NAME = '" + key + "' ";
	    rs = statement.executeQuery(sql);
	    if (rs.next()) {
		propsParam.setParamId(rs.getString(1));
		propsParam.setParamName(rs.getString(2));
		propsParam.setParamCurrValue(rs.getString(3));
		propsParam.setParamDesc(rs.getString(4));
	    }
	    propsParamList.add(propsParam);
	}

	return propsParamList;

    }

    /**
     * Returns the list Client Name from OAM
     * 
     * @param clientId
     * @return
     * @throws SQLException
     */

    private String getOAMClientName(String clientId) throws SQLException {

	if (clientId == null || "".equals(clientId))
	    throw new NullPointerException(
		    "Null or blank clientId id not allowed");

	String sql = "SELECT CLIENTNAME  FROM OAM_CLIENTS "
		+ " WHERE CLIENTID= '" + clientId + "' ";

	String clientName = null;

	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	try {

	    conn = ConnectionPoolManager.getInstance().getConnection(
		    DataOpsUtil.OAM_PROD_DB.toUpperCase());

	    stmt = conn.createStatement();

	    rs = stmt.executeQuery(sql);
	    if (rs.next()) {
		clientName = rs.getString(1);
	    }

	} finally {
	    ResourceRelease.releaseResources(conn, stmt, rs);
	}

	return clientName;

    }
    
    @Override
    public void copyMClientParameters(String sourceClientID, String sourceAppID,
	    String destinationClientID, String destinationAppID,
	    String dataOpsUserId) throws SQLException, DataOpsException {

	String destinationClientName = getOAMClientName(destinationClientID);

	String M_CLIENTS_SQL = " MERGE INTO M_CLIENTS A " + "USING (  SELECT  "
		+ "'"
		+ destinationClientID
		+ "'    AS CLIENTID         , "
		+ "'"
		+ destinationClientName
		+ "'    AS CLIENTNAME         , "
		+ "CONTRACTTYPE                    ,                                                                                                                                                                                  "
		+ "CLIENTTYPE                      ,                                                                                                                                                                                  "
		+ "STAGE                           ,                                                                                                                                                                                        "
		+ "(SELECT MAX( SN ) + 1  FROM M_CLIENTS WHERE SN IS NOT NULL)  AS SN              ,                                                                                                                                                                                     "
		+ "USE_YN                          ,                                                                                                                                                                                       "
		+ "EXCLUDEINELIGMEMS               ,                                                                                                                                                                                     "
		+ "EXCLUDEINELIGCLMS               ,                                                                                                                                                                                        "
		+ "ELIGSTARTREFDAY                 ,                                                                                                                                                                                   "
		+ "ELIGENDREFDAY                   ,                                                                                                                                                                                    "
		+ "MMTYPEFLOAT                     ,                                                                                                                                                                                      "
		+ "RCODE_YN                        ,                                                                                                                                                                                     "
		+ "IPDAYSCALLOGIC                  ,                                                                                                                                                                                "
		+ "ROLLUPRXCLM_YN                  ,                                                                                                                                                                                 "
		+ "CHECKDISCHRG_YN                 ,                                                                                                                                                                                 "
		+ "CHECKPOSFORADMISSION_YN         ,                                                                                                                                                                                 "
		+ "CHECKSUPPLYDAYSFORMOI           ,                                                                                                                                                                                    "
		+ "USESTICKY                       ,                                                                                                                                                                                    "
		+ "CUSTOMSTDRPT                    ,                                                                                                                                                                                   "
		+ "INCLUDEDUALCOV                  ,                                                                                                                                                                                    "
		+ "ISIMPLCLIENT                    ,                                                                                                                                                                                  "
		+ "USESTDRPT                       ,                                                                                                                                                                                    "
		+ "CHECKMMFOR4KEYS                 ,                                                                                                                                                                                 "
		+ "USEQRM                          ,                                                                                                                                                                                    "
		+ "USEARI                          ,                                                                                                                                                                                       "
		+ "KEYLVL                          ,                                                                                                                                                                                   "
		+ "CS_QUERY_TIMEOUT                ,                                                                                                                                                                                        "
		+ "ALLOWED_FRONT_CONNECTION_COUNT  ,                                                                                                                                                                                       "
		+ "CS_ALLOWED_REPORTS              ,                                                                                                                                                                                       "
		+ "ROW_COUNT                       ,                                                                                                                                                                                   "
		+ "MEMCENTRIC_YN                   ,                                                                                                                                                                                    "
		+ "USEGOLDRPT                      ,                                                                                                                                                                                    "
		+ "USEGOLDPLUS4RPT                 ,                                                                                                                                                                               "
		+ "CLIENTPROCESSTYPE               ,                                                                                                                                                                                    "
		+ "PARTKEY                         ,                                                                                                                                                                                     "
		+ "ALLOWMULTIDIAGS                 ,                                                                                                                                                                                        "
		+ "USEPARTITION                    ,                                                                                                                                                                                        "
		+ "USECOMPRESSION                    "
		+ "FROM M_CLIENTS  "
		+ "WHERE CLIENTID = '"
		+ sourceClientID
		+ "' ) B "
		+ "ON (A.CLIENTID = B. CLIENTID) "
		+ "WHEN MATCHED THEN  "
		+ "UPDATE SET "
		+ "CONTRACTTYPE              = ( SELECT CONTRACTTYPE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                               "
		+ "CLIENTTYPE                = ( SELECT CLIENTTYPE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                    "
		+ "STAGE                     = ( SELECT STAGE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "USE_YN                    = ( SELECT USE_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "EXCLUDEINELIGMEMS         = ( SELECT EXCLUDEINELIGMEMS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "EXCLUDEINELIGCLMS         = ( SELECT EXCLUDEINELIGCLMS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                       "
		+ "ELIGSTARTREFDAY           = ( SELECT ELIGSTARTREFDAY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                      "
		+ "ELIGENDREFDAY             = ( SELECT ELIGENDREFDAY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "MMTYPEFLOAT               = ( SELECT MMTYPEFLOAT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                        "
		+ "RCODE_YN                  = ( SELECT RCODE_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "IPDAYSCALLOGIC            = ( SELECT IPDAYSCALLOGIC FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                    "
		+ "ROLLUPRXCLM_YN            = ( SELECT ROLLUPRXCLM_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "CHECKDISCHRG_YN           = ( SELECT CHECKDISCHRG_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                              "
		+ "CHECKPOSFORADMISSION_YN   = ( SELECT CHECKPOSFORADMISSION_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                               "
		+ "CHECKSUPPLYDAYSFORMOI     = ( SELECT CHECKSUPPLYDAYSFORMOI FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "USESTICKY                 = ( SELECT USESTICKY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "CUSTOMSTDRPT              = ( SELECT CUSTOMSTDRPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "INCLUDEDUALCOV            = ( SELECT INCLUDEDUALCOV FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                 "
		+ "ISIMPLCLIENT              = ( SELECT ISIMPLCLIENT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                "
		+ "USESTDRPT                 = ( SELECT USESTDRPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "CHECKMMFOR4KEYS           = ( SELECT CHECKMMFOR4KEYS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                        "
		+ "USEQRM                    = ( SELECT USEQRM FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "USEARI                    = ( SELECT USEARI FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                "
		+ "KEYLVL                    = ( SELECT KEYLVL FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "CS_QUERY_TIMEOUT          = ( SELECT CS_QUERY_TIMEOUT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                "
		+ "ALLOWED_FRONT_CONNECTION_COUNT   = ( SELECT ALLOWED_FRONT_CONNECTION_COUNT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                               "
		+ "CS_ALLOWED_REPORTS        = ( SELECT CS_ALLOWED_REPORTS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "ROW_COUNT                 = ( SELECT ROW_COUNT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                 "
		+ "MEMCENTRIC_YN             = ( SELECT MEMCENTRIC_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "USEGOLDRPT                = ( SELECT USEGOLDRPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "USEGOLDPLUS4RPT           = ( SELECT USEGOLDPLUS4RPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "CLIENTPROCESSTYPE         = ( SELECT CLIENTPROCESSTYPE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "PARTKEY                   = ( SELECT PARTKEY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "ALLOWMULTIDIAGS           = ( SELECT ALLOWMULTIDIAGS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "USEPARTITION              = ( SELECT USEPARTITION FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                      "
		+ "USECOMPRESSION            = ( SELECT USECOMPRESSION FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' )     "
		+ "WHERE A.CLIENTID = B. CLIENTID "
		+ "WHEN NOT MATCHED THEN "
		+ "INSERT "
		+ "( "
		+ "CLIENTID                       ,                                                                                                                                                                                "
		+ "CLIENTNAME                      ,                                                                                                                                                                                  "
		+ "CONTRACTTYPE                    ,                                                                                                                                                                                  "
		+ "CLIENTTYPE                      ,                                                                                                                                                                                  "
		+ "STAGE                           ,                                                                                                                                                                                        "
		+ "SN                              ,                                                                                                                                                                                     "
		+ "USE_YN                          ,                                                                                                                                                                                       "
		+ "EXCLUDEINELIGMEMS               ,                                                                                                                                                                                     "
		+ "EXCLUDEINELIGCLMS               ,                                                                                                                                                                                        "
		+ "ELIGSTARTREFDAY                 ,                                                                                                                                                                                   "
		+ "ELIGENDREFDAY                   ,                                                                                                                                                                                    "
		+ "MMTYPEFLOAT                     ,                                                                                                                                                                                      "
		+ "RCODE_YN                        ,                                                                                                                                                                                     "
		+ "IPDAYSCALLOGIC                  ,                                                                                                                                                                                "
		+ "ROLLUPRXCLM_YN                  ,                                                                                                                                                                                 "
		+ "CHECKDISCHRG_YN                 ,                                                                                                                                                                                 "
		+ "CHECKPOSFORADMISSION_YN         ,                                                                                                                                                                                 "
		+ "CHECKSUPPLYDAYSFORMOI           ,                                                                                                                                                                                    "
		+ "USESTICKY                      ,                                                                                                                                                                                    "
		+ "CUSTOMSTDRPT                   ,                                                                                                                                                                                   "
		+ "INCLUDEDUALCOV                 ,                                                                                                                                                                                    "
		+ "ISIMPLCLIENT                   ,                                                                                                                                                                                  "
		+ "USESTDRPT                       ,                                                                                                                                                                                    "
		+ "CHECKMMFOR4KEYS                 ,                                                                                                                                                                                 "
		+ "USEQRM                          ,                                                                                                                                                                                    "
		+ "USEARI                          ,                                                                                                                                                                                       "
		+ "KEYLVL                          ,                                                                                                                                                                                   "
		+ "CS_QUERY_TIMEOUT                ,                                                                                                                                                                                        "
		+ "ALLOWED_FRONT_CONNECTION_COUNT  ,                                                                                                                                                                                       "
		+ "CS_ALLOWED_REPORTS              ,                                                                                                                                                                                       "
		+ "ROW_COUNT                       ,                                                                                                                                                                                   "
		+ "MEMCENTRIC_YN                   ,                                                                                                                                                                                    "
		+ "USEGOLDRPT                      ,                                                                                                                                                                                    "
		+ "USEGOLDPLUS4RPT                 ,                                                                                                                                                                               "
		+ "CLIENTPROCESSTYPE               ,                                                                                                                                                                                    "
		+ "PARTKEY                         ,                                                                                                                                                                                     "
		+ "ALLOWMULTIDIAGS                 ,                                                                                                                                                                                        "
		+ "USEPARTITION                    ,                                                                                                                                                                                        "
		+ "USECOMPRESSION  "
		+ " ) "
		+ "VALUES (  "
		+ "B. CLIENTID             ,                                                                                                                                                                                "
		+ "B.CLIENTNAME                   ,                                                                                                                                                                                  "
		+ "B.CONTRACTTYPE                    ,                                                                                                                                                                                  "
		+ "B.CLIENTTYPE                      ,                                                                                                                                                                                  "
		+ "B.STAGE                           ,                                                                                                                                                                                        "
		+ "B.SN                     ,                                                                                                                                                                                     "
		+ "B.USE_YN                          ,                                                                                                                                                                                       "
		+ "B.EXCLUDEINELIGMEMS               ,                                                                                                                                                                                     "
		+ "B.EXCLUDEINELIGCLMS               ,                                                                                                                                                                                        "
		+ "B.ELIGSTARTREFDAY                 ,                                                                                                                                                                                   "
		+ "B.ELIGENDREFDAY                   ,                                                                                                                                                                                    "
		+ "B.MMTYPEFLOAT                     ,                                                                                                                                                                                      "
		+ "B.RCODE_YN                        ,                                                                                                                                                                                     "
		+ "B.IPDAYSCALLOGIC                  ,                                                                                                                                                                                "
		+ "B.ROLLUPRXCLM_YN                  ,                                                                                                                                                                                 "
		+ "B.CHECKDISCHRG_YN                 ,                                                                                                                                                                                 "
		+ "B.CHECKPOSFORADMISSION_YN         ,                                                                                                                                                                                 "
		+ "B.CHECKSUPPLYDAYSFORMOI           ,                                                                                                                                                                                    "
		+ "B.USESTICKY                      ,                                                                                                                                                                                    "
		+ "B.CUSTOMSTDRPT                   ,                                                                                                                                                                                   "
		+ "B.INCLUDEDUALCOV                 ,                                                                                                                                                                                    "
		+ "B.ISIMPLCLIENT                   ,                                                                                                                                                                                  "
		+ "B.USESTDRPT                       ,                                                                                                                                                                                    "
		+ "B.CHECKMMFOR4KEYS                 ,                                                                                                                                                                                 "
		+ "B.USEQRM                          ,                                                                                                                                                                                    "
		+ "B.USEARI                          ,                                                                                                                                                                                       "
		+ "B.KEYLVL                          ,                                                                                                                                                                                   "
		+ "B.CS_QUERY_TIMEOUT                ,                                                                                                                                                                                        "
		+ "B.ALLOWED_FRONT_CONNECTION_COUNT  ,                                                                                                                                                                                       "
		+ "B.CS_ALLOWED_REPORTS              ,                                                                                                                                                                                       "
		+ "B.ROW_COUNT                       ,                                                                                                                                                                                   "
		+ "B.MEMCENTRIC_YN                   ,                                                                                                                                                                                    "
		+ "B.USEGOLDRPT                      ,                                                                                                                                                                                    "
		+ "B.USEGOLDPLUS4RPT                 ,                                                                                                                                                                               "
		+ "B.CLIENTPROCESSTYPE               ,                                                                                                                                                                                    "
		+ "B.PARTKEY                         ,                                                                                                                                                                                     "
		+ "B.ALLOWMULTIDIAGS                 ,                                                                                                                                                                                        "
		+ "B.USEPARTITION                    ,                                                                                                                                                                                        "
		+ "B.USECOMPRESSION                    " + ") ";

	
	// logging queries
	String logSql = "SELECT 'M_CLIENTS' AS TABLE_TYPE , "
		+ "  A.PARAM_NAME ,  " + "CASE   "
		+ " WHEN PARAM_NAME = 'CONTRACTTYPE'  THEN  "
		+ "TO_CHAR(C.CONTRACTTYPE) "
		+ "WHEN PARAM_NAME = 'CLIENTTYPE'  THEN  "
		+ "TO_CHAR(C.CLIENTTYPE) "
		+ "WHEN PARAM_NAME = 'STAGE'  THEN  " + "TO_CHAR(C.STAGE) "
		+ "WHEN PARAM_NAME = 'USE_YN'  THEN  " + "TO_CHAR(C.USE_YN) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGMEMS'  THEN  "
		+ "TO_CHAR(C.EXCLUDEINELIGMEMS) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGCLMS'  THEN  "
		+ "TO_CHAR(C.EXCLUDEINELIGCLMS) "
		+ "WHEN PARAM_NAME = 'ELIGSTARTREFDAY'  THEN  "
		+ "TO_CHAR(C.ELIGSTARTREFDAY) "
		+ "WHEN PARAM_NAME = 'ELIGENDREFDAY'  THEN  "
		+ "TO_CHAR(C.ELIGENDREFDAY) "
		+ "WHEN PARAM_NAME = 'MMTYPEFLOAT'  THEN  "
		+ "TO_CHAR(C.MMTYPEFLOAT) "
		+ "WHEN PARAM_NAME = 'RCODE_YN'  THEN  "
		+ "TO_CHAR(C.RCODE_YN) "
		+ "WHEN PARAM_NAME = 'IPDAYSCALLOGIC'  THEN  "
		+ "TO_CHAR(C.IPDAYSCALLOGIC) "
		+ "WHEN PARAM_NAME = 'ROLLUPRXCLM_YN'  THEN  "
		+ "TO_CHAR(C.ROLLUPRXCLM_YN) "
		+ "WHEN PARAM_NAME = 'CHECKDISCHRG_YN'  THEN  "
		+ "TO_CHAR(C.CHECKDISCHRG_YN) "
		+ "WHEN PARAM_NAME = 'CHECKPOSFORADMISSION_YN'  THEN  "
		+ "TO_CHAR(C.CHECKPOSFORADMISSION_YN) "
		+ "WHEN PARAM_NAME = 'CHECKSUPPLYDAYSFORMOI'  THEN  "
		+ "TO_CHAR(C.CHECKSUPPLYDAYSFORMOI) "
		+ "WHEN PARAM_NAME = 'USESTICKY'  THEN  "
		+ "TO_CHAR(C.USESTICKY) "
		+ "WHEN PARAM_NAME = 'CUSTOMSTDRPT'  THEN  "
		+ "TO_CHAR(C.CUSTOMSTDRPT) "
		+ "WHEN PARAM_NAME = 'INCLUDEDUALCOV'  THEN  "
		+ "TO_CHAR(C.INCLUDEDUALCOV) "
		+ "WHEN PARAM_NAME = 'ISIMPLCLIENT'  THEN  "
		+ "TO_CHAR(C.ISIMPLCLIENT) "
		+ "WHEN PARAM_NAME = 'USESTDRPT'  THEN  "
		+ "TO_CHAR(C.USESTDRPT) "
		+ "WHEN PARAM_NAME = 'CHECKMMFOR4KEYS'  THEN  "
		+ "TO_CHAR(C.CHECKMMFOR4KEYS) "
		+ "WHEN PARAM_NAME = 'USEQRM'  THEN  " + "TO_CHAR(C.USEQRM) "
		+ "WHEN PARAM_NAME = 'USEARI'  THEN  " + "TO_CHAR(C.USEARI) "
		+ "WHEN PARAM_NAME = 'KEYLVL'  THEN  " + "TO_CHAR(C.KEYLVL) "
		+ "WHEN PARAM_NAME = 'CS_QUERY_TIMEOUT'  THEN  "
		+ "TO_CHAR(C.CS_QUERY_TIMEOUT) "
		+ "WHEN PARAM_NAME = 'ALLOWED_FRONT_CONNECTION_COUNT'  THEN  "
		+ "TO_CHAR(C.ALLOWED_FRONT_CONNECTION_COUNT) "
		+ "WHEN PARAM_NAME = 'CS_ALLOWED_REPORTS'  THEN  "
		+ "TO_CHAR(C.CS_ALLOWED_REPORTS) "
		+ "WHEN PARAM_NAME = 'ROW_COUNT'  THEN  "
		+ "TO_CHAR(C.ROW_COUNT) "
		+ "WHEN PARAM_NAME = 'MEMCENTRIC_YN'  THEN  "
		+ "TO_CHAR(C.MEMCENTRIC_YN) "
		+ "WHEN PARAM_NAME = 'USEGOLDRPT'  THEN  "
		+ "TO_CHAR(C.USEGOLDRPT) "
		+ "WHEN PARAM_NAME = 'USEGOLDPLUS4RPT'  THEN  "
		+ "TO_CHAR(C.USEGOLDPLUS4RPT) "
		+ "WHEN PARAM_NAME = 'CLIENTPROCESSTYPE'  THEN  "
		+ "TO_CHAR(C.CLIENTPROCESSTYPE) "
		+ "WHEN PARAM_NAME = 'PARTKEY'  THEN  " + "TO_CHAR(C.PARTKEY) "
		+ "WHEN PARAM_NAME = 'ALLOWMULTIDIAGS'  THEN  "
		+ "TO_CHAR(C.ALLOWMULTIDIAGS) "
		+ "WHEN PARAM_NAME = 'USEPARTITION'  THEN  "
		+ "TO_CHAR(C.USEPARTITION) "
		+ "WHEN PARAM_NAME = 'USECOMPRESSION'  THEN  "
		+ "TO_CHAR(C.USECOMPRESSION) " + "END AS NEW_VALUE " + ", "
		+ "CASE   " + " WHEN PARAM_NAME = 'CONTRACTTYPE'  THEN  "
		+ "TO_CHAR(B.CONTRACTTYPE) "
		+ "WHEN PARAM_NAME = 'CLIENTTYPE'  THEN  "
		+ "TO_CHAR(B.CLIENTTYPE) "
		+ "WHEN PARAM_NAME = 'STAGE'  THEN  " + "TO_CHAR(B.STAGE) "
		+ "WHEN PARAM_NAME = 'USE_YN'  THEN  " + "TO_CHAR(B.USE_YN) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGMEMS'  THEN  "
		+ "TO_CHAR(B.EXCLUDEINELIGMEMS) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGCLMS'  THEN  "
		+ "TO_CHAR(B.EXCLUDEINELIGCLMS) "
		+ "WHEN PARAM_NAME = 'ELIGSTARTREFDAY'  THEN  "
		+ "TO_CHAR(B.ELIGSTARTREFDAY) "
		+ "WHEN PARAM_NAME = 'ELIGENDREFDAY'  THEN  "
		+ "TO_CHAR(B.ELIGENDREFDAY) "
		+ "WHEN PARAM_NAME = 'MMTYPEFLOAT'  THEN  "
		+ "TO_CHAR(B.MMTYPEFLOAT) "
		+ "WHEN PARAM_NAME = 'RCODE_YN'  THEN  "
		+ "TO_CHAR(B.RCODE_YN) "
		+ "WHEN PARAM_NAME = 'IPDAYSCALLOGIC'  THEN  "
		+ "TO_CHAR(B.IPDAYSCALLOGIC) "
		+ "WHEN PARAM_NAME = 'ROLLUPRXCLM_YN'  THEN  "
		+ "TO_CHAR(B.ROLLUPRXCLM_YN) "
		+ "WHEN PARAM_NAME = 'CHECKDISCHRG_YN'  THEN  "
		+ "TO_CHAR(B.CHECKDISCHRG_YN) "
		+ "WHEN PARAM_NAME = 'CHECKPOSFORADMISSION_YN'  THEN  "
		+ "TO_CHAR(B.CHECKPOSFORADMISSION_YN) "
		+ "WHEN PARAM_NAME = 'CHECKSUPPLYDAYSFORMOI'  THEN  "
		+ "TO_CHAR(B.CHECKSUPPLYDAYSFORMOI) "
		+ "WHEN PARAM_NAME = 'USESTICKY'  THEN  "
		+ "TO_CHAR(B.USESTICKY) "
		+ "WHEN PARAM_NAME = 'CUSTOMSTDRPT'  THEN  "
		+ "TO_CHAR(B.CUSTOMSTDRPT) "
		+ "WHEN PARAM_NAME = 'INCLUDEDUALCOV'  THEN  "
		+ "TO_CHAR(B.INCLUDEDUALCOV) "
		+ "WHEN PARAM_NAME = 'ISIMPLCLIENT'  THEN  "
		+ "TO_CHAR(B.ISIMPLCLIENT) "
		+ "WHEN PARAM_NAME = 'USESTDRPT'  THEN  "
		+ "TO_CHAR(B.USESTDRPT) "
		+ "WHEN PARAM_NAME = 'CHECKMMFOR4KEYS'  THEN  "
		+ "TO_CHAR(B.CHECKMMFOR4KEYS) "
		+ "WHEN PARAM_NAME = 'USEQRM'  THEN  " + "TO_CHAR(B.USEQRM) "
		+ "WHEN PARAM_NAME = 'USEARI'  THEN  " + "TO_CHAR(B.USEARI) "
		+ "WHEN PARAM_NAME = 'KEYLVL'  THEN  " + "TO_CHAR(B.KEYLVL) "
		+ "WHEN PARAM_NAME = 'CS_QUERY_TIMEOUT'  THEN  "
		+ "TO_CHAR(B.CS_QUERY_TIMEOUT) "
		+ "WHEN PARAM_NAME = 'ALLOWED_FRONT_CONNECTION_COUNT'  THEN  "
		+ "TO_CHAR(B.ALLOWED_FRONT_CONNECTION_COUNT) "
		+ "WHEN PARAM_NAME = 'CS_ALLOWED_REPORTS'  THEN  "
		+ "TO_CHAR(B.CS_ALLOWED_REPORTS) "
		+ "WHEN PARAM_NAME = 'ROW_COUNT'  THEN  "
		+ "TO_CHAR(B.ROW_COUNT) "
		+ "WHEN PARAM_NAME = 'MEMCENTRIC_YN'  THEN  "
		+ "TO_CHAR(B.MEMCENTRIC_YN) "
		+ "WHEN PARAM_NAME = 'USEGOLDRPT'  THEN  "
		+ "TO_CHAR(B.USEGOLDRPT) "
		+ "WHEN PARAM_NAME = 'USEGOLDPLUS4RPT'  THEN  "
		+ "TO_CHAR(B.USEGOLDPLUS4RPT) "
		+ "WHEN PARAM_NAME = 'CLIENTPROCESSTYPE'  THEN  "
		+ "TO_CHAR(B.CLIENTPROCESSTYPE) "
		+ "WHEN PARAM_NAME = 'PARTKEY'  THEN  " + "TO_CHAR(B.PARTKEY) "
		+ "WHEN PARAM_NAME = 'ALLOWMULTIDIAGS'  THEN  "
		+ "TO_CHAR(B.ALLOWMULTIDIAGS) "
		+ "WHEN PARAM_NAME = 'USEPARTITION'  THEN  "
		+ "TO_CHAR(B.USEPARTITION) "
		+ "WHEN PARAM_NAME = 'USECOMPRESSION'  THEN  "
		+ "TO_CHAR(B.USECOMPRESSION) " + "END AS OLD_VALUE "
		+ "FROM M_PARAM_PROPS A " + "  LEFT OUTER JOIN "
		+ "    ( SELECT * FROM M_CLIENTS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' ) B "
		+ "    ON 1=1 , "
		+ "    ( SELECT * FROM M_CLIENTS WHERE CLIENTID = '"
		+ sourceClientID
		+ "' ) C "
		+ "WHERE A.TABLE_TYPE = 'M_CLIENTS' ";

	
	System.out.println("MClientLog:"+logSql);
	Long transactionId = null;

	Statement masterstmt = null;
	PreparedStatement preparedStatement = null;
	String helogSchemaName = null;

	int mClientsRecCnt = -1;	

	ResultSet rs = null;

	String errorMessage = null;

	String insertLogSql = "";
	DataOpsParam dataOpsParam = null;
	List<DataOpsParam> dataOpsParamList = new ArrayList<DataOpsParam>();

	com.atomikos.icatch.jta.UserTransactionManager tm = new com.atomikos.icatch.jta.UserTransactionManager();

	String alias = null;
	ConnectionPoolManager poolMgr = ConnectionPoolManager.getInstance();
	Connection heLogConn = null;
	try {
	    if (sourceClientID != null && destinationClientID != null
		    && destinationAppID != null && sourceAppID != null) {

		poolMgr.initMasterSchemaDS();

		poolMgr.initXADataSource(DataOpsUtil.LOG_DB);

		tm.begin();
		Transaction tx = tm.getTransaction();

		poolMgr.enlistMasterResources(tx);

		heLogConn = poolMgr.getXAConnection(DataOpsUtil.LOG_DB)
			.getConnection();
		transactionId = DataOpsUtil.getTransactionId(heLogConn);
		
		helogSchemaName = ((ConnectionParameters) poolMgr.getConnectionProperties().get(DataOpsUtil.LOG_DB.toUpperCase())).getUserName();

		insertLogSql = " INSERT INTO " + helogSchemaName + ".DATAOPS_LOG  (CLIENTID, APPID, USERID, ACTIONDATE, PARAMETERNAME, OLDVALUE, "
			+ " NEWVALUE, ACTIONDESC, TABLE_TYPE, TRANSACTION_ID ) VALUES";
		insertLogSql += " ( ";
		insertLogSql += " '" + destinationClientID + "', '"
			+ destinationAppID + "', '" + dataOpsUserId
			+ "', sysdate " + " , ? , ? ,  ? , '"
			+ DataOpsUtil.ACTION_COPY_PARAMETERS + " from "
			+ sourceAppID + " to " + destinationAppID + "', ? , "
			+ transactionId;
		insertLogSql += " ) ";


		masterstmt = poolMgr
			.getXAConnection(DataOpsUtil.MASTER_DB.toUpperCase())
			.getConnection().createStatement();
		rs = masterstmt.executeQuery(logSql);
		while (rs.next()) {
		    dataOpsParam = new DataOpsParam();
		    dataOpsParam.setParamName(rs.getString(2));
		    dataOpsParam.setParamCurrValue(rs.getString(3));
		    dataOpsParam.setParamOldValue(rs.getString(4));
		    dataOpsParam.setParamTableType(rs.getString(1));

		    dataOpsParamList.add(dataOpsParam);

		}

		if (dataOpsParamList != null && dataOpsParamList.size() > 0) {
		    
		    preparedStatement = poolMgr
				.getXAConnection(DataOpsUtil.MASTER_DB.toUpperCase())
				.getConnection().prepareStatement(insertLogSql);
		   /* preparedStatement = heLogConn
			    .prepareStatement(insertLogSql);*/

		    for (int i = 0; i < dataOpsParamList.size(); i++) {
			dataOpsParam = dataOpsParamList.get(i);

			preparedStatement.setString(1,
				dataOpsParam.getParamName());
			preparedStatement.setString(2,
				(dataOpsParam.getParamOldValue()!=null ? dataOpsParam.getParamOldValue().replace("'", "''") : dataOpsParam.getParamOldValue()));
			preparedStatement.setString(3,
				(dataOpsParam.getParamCurrValue()!=null ? dataOpsParam.getParamCurrValue().replace("'", "''") : dataOpsParam.getParamCurrValue()));
			preparedStatement.setString(4,
				dataOpsParam.getParamTableType());
			preparedStatement.addBatch();

		    }

		    preparedStatement.executeBatch();

		}

		int masterCounter = 1;
		while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + ""
			+ masterCounter) != null) {
		    alias = DataOpsUtil.getProperty(
			    DataOpsUtil.HAWKEYEMASTER + "" + masterCounter)
			    .toUpperCase();

		    System.out.println("aliasName====" + alias);

		    masterstmt = poolMgr.getXAConnection(alias).getConnection()
			    .createStatement();

		    // execute M_CLIENTS_SQL
		    mClientsRecCnt = masterstmt.executeUpdate(M_CLIENTS_SQL);

		    // set the IS_ACTIVE Flag = N for the parameters not
		    // assigned to any app.
		    if (masterCounter == 1) {
			String paramPropUpdateSql = " UPDATE M_PARAM_PROPS SET IS_ACTIVE = 'N' WHERE TABLE_TYPE = 'M_CLIENTPARAMS' AND "
				+ "PARAM_NAME NOT IN ( SELECT DISTINCT PARAMNAME FROM  M_CLIENTPARAMS )   ";
			masterstmt.executeUpdate(paramPropUpdateSql);
		    }

		    masterCounter += 1;

		}

		masterstmt.close();
		if (dataOpsParamList != null && dataOpsParamList.size() > 0) 
				preparedStatement.close();
		
		poolMgr.closeConnections();
		poolMgr.delistAllMasterResource(tx);
		tm.commit();

	    }

	} catch (Exception e) {
	    errorMessage = e.getMessage();
	    try {
		tm.rollback();
	    } catch (Exception e1) {
		e1.printStackTrace();
	    }

	    if (mClientsRecCnt < 0) {
		throw new SQLException("Copy Failed on M_CLIENTS Parameters", e);
	    } else {
		throw new SQLException("Copy Failed", e);
	    }

	} finally {

	    try {

		String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
			DataOpsUtil.TX_COPY_PARAMETERS);
		String emailContent = EmailUtility.getCopyToParameterContent(
			DataOpsUtil.TX_COPY_PARAMETERS, transactionId,
			dataOpsUserId, destinationClientID, destinationAppID,
			sourceClientID, sourceAppID, errorMessage);

		String emailSendStatus = EmailUtility.sendEmail(dataOpsUserId,
			emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
			: DataOpsUtil.EMAIL_SEND_FAILED;

		DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
			.getSendToAddr(dataOpsUserId),
			EmailUtility.sendFromAddr, emailSubject, DataOpsUtil
				.getEmailLogMessage(errorMessage,
					DataOpsUtil.TX_COPY_PARAMETERS,
					transactionId, dataOpsUserId),
			emailSendStatus);

	    } catch (Exception e) {
		e.printStackTrace();
	    } finally {

		try {
		    poolMgr.closeXAConnections();
		} catch (Exception e) {
		    e.printStackTrace();
		}

	    }

	}

    }
    
    @Override
    public void copyMClientParamParameters(String sourceClientID, String sourceAppID,
	    String destinationClientID, String destinationAppID,
	    String dataOpsUserId) throws SQLException, DataOpsException {

	String destinationClientName = getOAMClientName(destinationClientID);
	

	String M_CLIENTPARAMS_DEL_SQL = " DELETE FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' AND APPID = '"
		+ destinationAppID
		+ "' ";

	String M_CLIENTPARAMS_INSERT_SQL = " INSERT INTO M_CLIENTPARAMS SELECT '"
		+ destinationClientID
		+ "', "
		+ "       PARAMID, "
		+ "       PARAMNAME, "
		+ "       PARAMVAL, "
		+ "       PARAMTYPE, "
		+ "       '"
		+ destinationAppID
		+ "' "
		+ "FROM   M_CLIENTPARAMS "
		+ "WHERE  CLIENTID = '"
		+ sourceClientID
		+ "' "
		+ "       AND APPID = '"
		+ sourceAppID
		+ "'  ";

	// logging queries
	String logSql = " SELECT 'M_CLIENTPARAMS' AS TABLE_TYPE ,"
		+ " A.PARAM_NAME ,C.PARAMVAL NEW_VAL,B.PARAMVAL OLD_VAL "
		+ "FROM M_PARAM_PROPS A LEFT OUTER JOIN ( SELECT * FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' AND APPID = '"
		+ destinationAppID
		+ "' ) B "
		+ "   ON A.PARAM_NAME = B.PARAMNAME "
		+ "   LEFT OUTER JOIN ( SELECT * FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ sourceClientID
		+ "' AND APPID = '"
		+ sourceAppID
		+ "' ) C  "
		+ "   ON A.PARAM_NAME = C.PARAMNAME "
		+ "WHERE A.PARAM_NAME IN ( SELECT PARAMNAME FROM ( SELECT PARAMNAME FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' AND APPID = '"
		+ destinationAppID
		+ "' "
		+ "                                                UNION "
		+ "                                                SELECT PARAMNAME FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ sourceClientID
		+ "' AND APPID = '"
		+ sourceAppID
		+ "'  "
		+ "                                              ) "
		+ "                        ) ";

	
	System.out.println("MClientParamLog:"+logSql);
	Long transactionId = null;

	Statement masterstmt = null;
	PreparedStatement preparedStatement = null;
	String helogSchemaName = null;
	
	int mClientParamsRecCnt = -1;

	ResultSet rs = null;

	String errorMessage = null;

	String insertLogSql = "";
	DataOpsParam dataOpsParam = null;
	List<DataOpsParam> dataOpsParamList = new ArrayList<DataOpsParam>();

	com.atomikos.icatch.jta.UserTransactionManager tm = new com.atomikos.icatch.jta.UserTransactionManager();

	String alias = null;
	ConnectionPoolManager poolMgr = ConnectionPoolManager.getInstance();
	Connection heLogConn = null;
	try {
	    if (sourceClientID != null && destinationClientID != null
		    && destinationAppID != null && sourceAppID != null) {

		poolMgr.initMasterSchemaDS();

		poolMgr.initXADataSource(DataOpsUtil.LOG_DB);

		tm.begin();
		Transaction tx = tm.getTransaction();

		poolMgr.enlistMasterResources(tx);

		heLogConn = poolMgr.getXAConnection(DataOpsUtil.LOG_DB)
			.getConnection();
		transactionId = DataOpsUtil.getTransactionId(heLogConn);
		
		helogSchemaName = ((ConnectionParameters) poolMgr.getConnectionProperties().get(DataOpsUtil.LOG_DB.toUpperCase())).getUserName();

		insertLogSql = " INSERT INTO " + helogSchemaName + ".DATAOPS_LOG  (CLIENTID, APPID, USERID, ACTIONDATE, PARAMETERNAME, OLDVALUE, "
			+ " NEWVALUE, ACTIONDESC, TABLE_TYPE, TRANSACTION_ID ) VALUES";
		insertLogSql += " ( ";
		insertLogSql += " '" + destinationClientID + "', '"
			+ destinationAppID + "', '" + dataOpsUserId
			+ "', sysdate " + " , ? , ? ,  ? , '"
			+ DataOpsUtil.ACTION_COPY_PARAMETERS + " from "
			+ sourceAppID + " to " + destinationAppID + "', ? , "
			+ transactionId;
		insertLogSql += " ) ";


		masterstmt = poolMgr
			.getXAConnection(DataOpsUtil.MASTER_DB.toUpperCase())
			.getConnection().createStatement();
		rs = masterstmt.executeQuery(logSql);
		while (rs.next()) {
		    dataOpsParam = new DataOpsParam();
		    dataOpsParam.setParamName(rs.getString(2));
		    dataOpsParam.setParamCurrValue(rs.getString(3));
		    dataOpsParam.setParamOldValue(rs.getString(4));
		    dataOpsParam.setParamTableType(rs.getString(1));

		    dataOpsParamList.add(dataOpsParam);

		}

		if (dataOpsParamList != null && dataOpsParamList.size() > 0) {
		    
		    preparedStatement = poolMgr
				.getXAConnection(DataOpsUtil.MASTER_DB.toUpperCase())
				.getConnection().prepareStatement(insertLogSql);
		   /* preparedStatement = heLogConn
			    .prepareStatement(insertLogSql);*/

		    for (int i = 0; i < dataOpsParamList.size(); i++) {
			dataOpsParam = dataOpsParamList.get(i);

			preparedStatement.setString(1,
				dataOpsParam.getParamName());
			preparedStatement.setString(2,
				(dataOpsParam.getParamOldValue()!=null ? dataOpsParam.getParamOldValue().replace("'", "''") : dataOpsParam.getParamOldValue()));
			preparedStatement.setString(3,
				(dataOpsParam.getParamCurrValue()!=null ? dataOpsParam.getParamCurrValue().replace("'", "''") : dataOpsParam.getParamCurrValue()));
			preparedStatement.setString(4,
				dataOpsParam.getParamTableType());
			preparedStatement.addBatch();

		    }

		    preparedStatement.executeBatch();

		}

		int masterCounter = 1;
		while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + ""
			+ masterCounter) != null) {
		    alias = DataOpsUtil.getProperty(
			    DataOpsUtil.HAWKEYEMASTER + "" + masterCounter)
			    .toUpperCase();

		    System.out.println("aliasName====" + alias);

		    masterstmt = poolMgr.getXAConnection(alias).getConnection()
			    .createStatement();
		    
		    // execute M_CLIENTPARAMS_DEL_SQL
		    masterstmt.executeUpdate(M_CLIENTPARAMS_DEL_SQL);

		    // execute M_CLIENTPARAMS_INSERT_SQL
		    mClientParamsRecCnt = masterstmt
			    .executeUpdate(M_CLIENTPARAMS_INSERT_SQL);

		    // set the IS_ACTIVE Flag = N for the parameters not
		    // assigned to any app.
		    if (masterCounter == 1) {
			String paramPropUpdateSql = " UPDATE M_PARAM_PROPS SET IS_ACTIVE = 'N' WHERE TABLE_TYPE = 'M_CLIENTPARAMS' AND "
				+ "PARAM_NAME NOT IN ( SELECT DISTINCT PARAMNAME FROM  M_CLIENTPARAMS )   ";
			masterstmt.executeUpdate(paramPropUpdateSql);
		    }

		    masterCounter += 1;

		}

		masterstmt.close();
		if (dataOpsParamList != null && dataOpsParamList.size() > 0) 
			preparedStatement.close();
		
		poolMgr.closeConnections();
		poolMgr.delistAllMasterResource(tx);
		tm.commit();

	    }

	} catch (Exception e) {
	    errorMessage = e.getMessage();
	    try {
		tm.rollback();
	    } catch (Exception e1) {
		e1.printStackTrace();
	    }
	    
	    if (mClientParamsRecCnt < 0) {
		throw new SQLException(
			"Copy Failed on M_CLIENTPARAMS Parameters", e);
	    } else {
		throw new SQLException("Copy Failed", e);
	    }

	} finally {

	    try {

		String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
			DataOpsUtil.TX_COPY_PARAMETERS);
		String emailContent = EmailUtility.getCopyToParameterContent(
			DataOpsUtil.TX_COPY_PARAMETERS, transactionId,
			dataOpsUserId, destinationClientID, destinationAppID,
			sourceClientID, sourceAppID, errorMessage);

		String emailSendStatus = EmailUtility.sendEmail(dataOpsUserId,
			emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
			: DataOpsUtil.EMAIL_SEND_FAILED;

		DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
			.getSendToAddr(dataOpsUserId),
			EmailUtility.sendFromAddr, emailSubject, DataOpsUtil
				.getEmailLogMessage(errorMessage,
					DataOpsUtil.TX_COPY_PARAMETERS,
					transactionId, dataOpsUserId),
			emailSendStatus);

	    } catch (Exception e) {
		e.printStackTrace();
	    } finally {

		try {
		    poolMgr.closeXAConnections();
		} catch (Exception e) {
		    e.printStackTrace();
		}

	    }

	}

    }

    @Override
    public void copyAllParameters(String sourceClientID, String sourceAppID,
	    String destinationClientID, String destinationAppID,
	    String dataOpsUserId) throws SQLException, DataOpsException {

	String destinationClientName = getOAMClientName(destinationClientID);

	String M_CLIENTS_SQL = " MERGE INTO M_CLIENTS A " + "USING (  SELECT  "
		+ "'"
		+ destinationClientID
		+ "'    AS CLIENTID         , "
		+ "'"
		+ destinationClientName
		+ "'    AS CLIENTNAME         , "
		+ "CONTRACTTYPE                    ,                                                                                                                                                                                  "
		+ "CLIENTTYPE                      ,                                                                                                                                                                                  "
		+ "STAGE                           ,                                                                                                                                                                                        "
		+ "(SELECT MAX( SN ) + 1  FROM M_CLIENTS WHERE SN IS NOT NULL)  AS SN              ,                                                                                                                                                                                     "
		+ "USE_YN                          ,                                                                                                                                                                                       "
		+ "EXCLUDEINELIGMEMS               ,                                                                                                                                                                                     "
		+ "EXCLUDEINELIGCLMS               ,                                                                                                                                                                                        "
		+ "ELIGSTARTREFDAY                 ,                                                                                                                                                                                   "
		+ "ELIGENDREFDAY                   ,                                                                                                                                                                                    "
		+ "MMTYPEFLOAT                     ,                                                                                                                                                                                      "
		+ "RCODE_YN                        ,                                                                                                                                                                                     "
		+ "IPDAYSCALLOGIC                  ,                                                                                                                                                                                "
		+ "ROLLUPRXCLM_YN                  ,                                                                                                                                                                                 "
		+ "CHECKDISCHRG_YN                 ,                                                                                                                                                                                 "
		+ "CHECKPOSFORADMISSION_YN         ,                                                                                                                                                                                 "
		+ "CHECKSUPPLYDAYSFORMOI           ,                                                                                                                                                                                    "
		+ "USESTICKY                       ,                                                                                                                                                                                    "
		+ "CUSTOMSTDRPT                    ,                                                                                                                                                                                   "
		+ "INCLUDEDUALCOV                  ,                                                                                                                                                                                    "
		+ "ISIMPLCLIENT                    ,                                                                                                                                                                                  "
		+ "USESTDRPT                       ,                                                                                                                                                                                    "
		+ "CHECKMMFOR4KEYS                 ,                                                                                                                                                                                 "
		+ "USEQRM                          ,                                                                                                                                                                                    "
		+ "USEARI                          ,                                                                                                                                                                                       "
		+ "KEYLVL                          ,                                                                                                                                                                                   "
		+ "CS_QUERY_TIMEOUT                ,                                                                                                                                                                                        "
		+ "ALLOWED_FRONT_CONNECTION_COUNT  ,                                                                                                                                                                                       "
		+ "CS_ALLOWED_REPORTS              ,                                                                                                                                                                                       "
		+ "ROW_COUNT                       ,                                                                                                                                                                                   "
		+ "MEMCENTRIC_YN                   ,                                                                                                                                                                                    "
		+ "USEGOLDRPT                      ,                                                                                                                                                                                    "
		+ "USEGOLDPLUS4RPT                 ,                                                                                                                                                                               "
		+ "CLIENTPROCESSTYPE               ,                                                                                                                                                                                    "
		+ "PARTKEY                         ,                                                                                                                                                                                     "
		+ "ALLOWMULTIDIAGS                 ,                                                                                                                                                                                        "
		+ "USEPARTITION                    ,                                                                                                                                                                                        "
		+ "USECOMPRESSION                    "
		+ "FROM M_CLIENTS  "
		+ "WHERE CLIENTID = '"
		+ sourceClientID
		+ "' ) B "
		+ "ON (A.CLIENTID = B. CLIENTID) "
		+ "WHEN MATCHED THEN  "
		+ "UPDATE SET "
		+ "CONTRACTTYPE              = ( SELECT CONTRACTTYPE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                               "
		+ "CLIENTTYPE                = ( SELECT CLIENTTYPE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                    "
		+ "STAGE                     = ( SELECT STAGE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "USE_YN                    = ( SELECT USE_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "EXCLUDEINELIGMEMS         = ( SELECT EXCLUDEINELIGMEMS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "EXCLUDEINELIGCLMS         = ( SELECT EXCLUDEINELIGCLMS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                       "
		+ "ELIGSTARTREFDAY           = ( SELECT ELIGSTARTREFDAY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                      "
		+ "ELIGENDREFDAY             = ( SELECT ELIGENDREFDAY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "MMTYPEFLOAT               = ( SELECT MMTYPEFLOAT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                        "
		+ "RCODE_YN                  = ( SELECT RCODE_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "IPDAYSCALLOGIC            = ( SELECT IPDAYSCALLOGIC FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                    "
		+ "ROLLUPRXCLM_YN            = ( SELECT ROLLUPRXCLM_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "CHECKDISCHRG_YN           = ( SELECT CHECKDISCHRG_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                              "
		+ "CHECKPOSFORADMISSION_YN   = ( SELECT CHECKPOSFORADMISSION_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                               "
		+ "CHECKSUPPLYDAYSFORMOI     = ( SELECT CHECKSUPPLYDAYSFORMOI FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "USESTICKY                 = ( SELECT USESTICKY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "CUSTOMSTDRPT              = ( SELECT CUSTOMSTDRPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "INCLUDEDUALCOV            = ( SELECT INCLUDEDUALCOV FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                 "
		+ "ISIMPLCLIENT              = ( SELECT ISIMPLCLIENT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                "
		+ "USESTDRPT                 = ( SELECT USESTDRPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "CHECKMMFOR4KEYS           = ( SELECT CHECKMMFOR4KEYS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                        "
		+ "USEQRM                    = ( SELECT USEQRM FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "USEARI                    = ( SELECT USEARI FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                "
		+ "KEYLVL                    = ( SELECT KEYLVL FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "CS_QUERY_TIMEOUT          = ( SELECT CS_QUERY_TIMEOUT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                "
		+ "ALLOWED_FRONT_CONNECTION_COUNT   = ( SELECT ALLOWED_FRONT_CONNECTION_COUNT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                               "
		+ "CS_ALLOWED_REPORTS        = ( SELECT CS_ALLOWED_REPORTS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "ROW_COUNT                 = ( SELECT ROW_COUNT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                 "
		+ "MEMCENTRIC_YN             = ( SELECT MEMCENTRIC_YN FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                         "
		+ "USEGOLDRPT                = ( SELECT USEGOLDRPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "USEGOLDPLUS4RPT           = ( SELECT USEGOLDPLUS4RPT FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                  "
		+ "CLIENTPROCESSTYPE         = ( SELECT CLIENTPROCESSTYPE FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                   "
		+ "PARTKEY                   = ( SELECT PARTKEY FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "ALLOWMULTIDIAGS           = ( SELECT ALLOWMULTIDIAGS FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                     "
		+ "USEPARTITION              = ( SELECT USEPARTITION FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' ) ,                                                                                                                                                                                      "
		+ "USECOMPRESSION            = ( SELECT USECOMPRESSION FROM  M_CLIENTS B WHERE B.CLIENTID = '"
		+ sourceClientID
		+ "' )     "
		+ "WHERE A.CLIENTID = B. CLIENTID "
		+ "WHEN NOT MATCHED THEN "
		+ "INSERT "
		+ "( "
		+ "CLIENTID                       ,                                                                                                                                                                                "
		+ "CLIENTNAME                      ,                                                                                                                                                                                  "
		+ "CONTRACTTYPE                    ,                                                                                                                                                                                  "
		+ "CLIENTTYPE                      ,                                                                                                                                                                                  "
		+ "STAGE                           ,                                                                                                                                                                                        "
		+ "SN                              ,                                                                                                                                                                                     "
		+ "USE_YN                          ,                                                                                                                                                                                       "
		+ "EXCLUDEINELIGMEMS               ,                                                                                                                                                                                     "
		+ "EXCLUDEINELIGCLMS               ,                                                                                                                                                                                        "
		+ "ELIGSTARTREFDAY                 ,                                                                                                                                                                                   "
		+ "ELIGENDREFDAY                   ,                                                                                                                                                                                    "
		+ "MMTYPEFLOAT                     ,                                                                                                                                                                                      "
		+ "RCODE_YN                        ,                                                                                                                                                                                     "
		+ "IPDAYSCALLOGIC                  ,                                                                                                                                                                                "
		+ "ROLLUPRXCLM_YN                  ,                                                                                                                                                                                 "
		+ "CHECKDISCHRG_YN                 ,                                                                                                                                                                                 "
		+ "CHECKPOSFORADMISSION_YN         ,                                                                                                                                                                                 "
		+ "CHECKSUPPLYDAYSFORMOI           ,                                                                                                                                                                                    "
		+ "USESTICKY                      ,                                                                                                                                                                                    "
		+ "CUSTOMSTDRPT                   ,                                                                                                                                                                                   "
		+ "INCLUDEDUALCOV                 ,                                                                                                                                                                                    "
		+ "ISIMPLCLIENT                   ,                                                                                                                                                                                  "
		+ "USESTDRPT                       ,                                                                                                                                                                                    "
		+ "CHECKMMFOR4KEYS                 ,                                                                                                                                                                                 "
		+ "USEQRM                          ,                                                                                                                                                                                    "
		+ "USEARI                          ,                                                                                                                                                                                       "
		+ "KEYLVL                          ,                                                                                                                                                                                   "
		+ "CS_QUERY_TIMEOUT                ,                                                                                                                                                                                        "
		+ "ALLOWED_FRONT_CONNECTION_COUNT  ,                                                                                                                                                                                       "
		+ "CS_ALLOWED_REPORTS              ,                                                                                                                                                                                       "
		+ "ROW_COUNT                       ,                                                                                                                                                                                   "
		+ "MEMCENTRIC_YN                   ,                                                                                                                                                                                    "
		+ "USEGOLDRPT                      ,                                                                                                                                                                                    "
		+ "USEGOLDPLUS4RPT                 ,                                                                                                                                                                               "
		+ "CLIENTPROCESSTYPE               ,                                                                                                                                                                                    "
		+ "PARTKEY                         ,                                                                                                                                                                                     "
		+ "ALLOWMULTIDIAGS                 ,                                                                                                                                                                                        "
		+ "USEPARTITION                    ,                                                                                                                                                                                        "
		+ "USECOMPRESSION  "
		+ " ) "
		+ "VALUES (  "
		+ "B. CLIENTID             ,                                                                                                                                                                                "
		+ "B.CLIENTNAME                   ,                                                                                                                                                                                  "
		+ "B.CONTRACTTYPE                    ,                                                                                                                                                                                  "
		+ "B.CLIENTTYPE                      ,                                                                                                                                                                                  "
		+ "B.STAGE                           ,                                                                                                                                                                                        "
		+ "B.SN                     ,                                                                                                                                                                                     "
		+ "B.USE_YN                          ,                                                                                                                                                                                       "
		+ "B.EXCLUDEINELIGMEMS               ,                                                                                                                                                                                     "
		+ "B.EXCLUDEINELIGCLMS               ,                                                                                                                                                                                        "
		+ "B.ELIGSTARTREFDAY                 ,                                                                                                                                                                                   "
		+ "B.ELIGENDREFDAY                   ,                                                                                                                                                                                    "
		+ "B.MMTYPEFLOAT                     ,                                                                                                                                                                                      "
		+ "B.RCODE_YN                        ,                                                                                                                                                                                     "
		+ "B.IPDAYSCALLOGIC                  ,                                                                                                                                                                                "
		+ "B.ROLLUPRXCLM_YN                  ,                                                                                                                                                                                 "
		+ "B.CHECKDISCHRG_YN                 ,                                                                                                                                                                                 "
		+ "B.CHECKPOSFORADMISSION_YN         ,                                                                                                                                                                                 "
		+ "B.CHECKSUPPLYDAYSFORMOI           ,                                                                                                                                                                                    "
		+ "B.USESTICKY                      ,                                                                                                                                                                                    "
		+ "B.CUSTOMSTDRPT                   ,                                                                                                                                                                                   "
		+ "B.INCLUDEDUALCOV                 ,                                                                                                                                                                                    "
		+ "B.ISIMPLCLIENT                   ,                                                                                                                                                                                  "
		+ "B.USESTDRPT                       ,                                                                                                                                                                                    "
		+ "B.CHECKMMFOR4KEYS                 ,                                                                                                                                                                                 "
		+ "B.USEQRM                          ,                                                                                                                                                                                    "
		+ "B.USEARI                          ,                                                                                                                                                                                       "
		+ "B.KEYLVL                          ,                                                                                                                                                                                   "
		+ "B.CS_QUERY_TIMEOUT                ,                                                                                                                                                                                        "
		+ "B.ALLOWED_FRONT_CONNECTION_COUNT  ,                                                                                                                                                                                       "
		+ "B.CS_ALLOWED_REPORTS              ,                                                                                                                                                                                       "
		+ "B.ROW_COUNT                       ,                                                                                                                                                                                   "
		+ "B.MEMCENTRIC_YN                   ,                                                                                                                                                                                    "
		+ "B.USEGOLDRPT                      ,                                                                                                                                                                                    "
		+ "B.USEGOLDPLUS4RPT                 ,                                                                                                                                                                               "
		+ "B.CLIENTPROCESSTYPE               ,                                                                                                                                                                                    "
		+ "B.PARTKEY                         ,                                                                                                                                                                                     "
		+ "B.ALLOWMULTIDIAGS                 ,                                                                                                                                                                                        "
		+ "B.USEPARTITION                    ,                                                                                                                                                                                        "
		+ "B.USECOMPRESSION                    " + ") ";

	String M_CLIENTPARAMS_DEL_SQL = " DELETE FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' AND APPID = '"
		+ destinationAppID
		+ "' ";

	String M_CLIENTPARAMS_INSERT_SQL = " INSERT INTO M_CLIENTPARAMS SELECT '"
		+ destinationClientID
		+ "', "
		+ "       PARAMID, "
		+ "       PARAMNAME, "
		+ "       PARAMVAL, "
		+ "       PARAMTYPE, "
		+ "       '"
		+ destinationAppID
		+ "' "
		+ "FROM   M_CLIENTPARAMS "
		+ "WHERE  CLIENTID = '"
		+ sourceClientID
		+ "' "
		+ "       AND APPID = '"
		+ sourceAppID
		+ "'  ";

	// logging queries
	String logSql = "SELECT 'M_CLIENTS' AS TABLE_TYPE , "
		+ "  A.PARAM_NAME ,  " + "CASE   "
		+ " WHEN PARAM_NAME = 'CONTRACTTYPE'  THEN  "
		+ "TO_CHAR(C.CONTRACTTYPE) "
		+ "WHEN PARAM_NAME = 'CLIENTTYPE'  THEN  "
		+ "TO_CHAR(C.CLIENTTYPE) "
		+ "WHEN PARAM_NAME = 'STAGE'  THEN  " + "TO_CHAR(C.STAGE) "
		+ "WHEN PARAM_NAME = 'USE_YN'  THEN  " + "TO_CHAR(C.USE_YN) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGMEMS'  THEN  "
		+ "TO_CHAR(C.EXCLUDEINELIGMEMS) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGCLMS'  THEN  "
		+ "TO_CHAR(C.EXCLUDEINELIGCLMS) "
		+ "WHEN PARAM_NAME = 'ELIGSTARTREFDAY'  THEN  "
		+ "TO_CHAR(C.ELIGSTARTREFDAY) "
		+ "WHEN PARAM_NAME = 'ELIGENDREFDAY'  THEN  "
		+ "TO_CHAR(C.ELIGENDREFDAY) "
		+ "WHEN PARAM_NAME = 'MMTYPEFLOAT'  THEN  "
		+ "TO_CHAR(C.MMTYPEFLOAT) "
		+ "WHEN PARAM_NAME = 'RCODE_YN'  THEN  "
		+ "TO_CHAR(C.RCODE_YN) "
		+ "WHEN PARAM_NAME = 'IPDAYSCALLOGIC'  THEN  "
		+ "TO_CHAR(C.IPDAYSCALLOGIC) "
		+ "WHEN PARAM_NAME = 'ROLLUPRXCLM_YN'  THEN  "
		+ "TO_CHAR(C.ROLLUPRXCLM_YN) "
		+ "WHEN PARAM_NAME = 'CHECKDISCHRG_YN'  THEN  "
		+ "TO_CHAR(C.CHECKDISCHRG_YN) "
		+ "WHEN PARAM_NAME = 'CHECKPOSFORADMISSION_YN'  THEN  "
		+ "TO_CHAR(C.CHECKPOSFORADMISSION_YN) "
		+ "WHEN PARAM_NAME = 'CHECKSUPPLYDAYSFORMOI'  THEN  "
		+ "TO_CHAR(C.CHECKSUPPLYDAYSFORMOI) "
		+ "WHEN PARAM_NAME = 'USESTICKY'  THEN  "
		+ "TO_CHAR(C.USESTICKY) "
		+ "WHEN PARAM_NAME = 'CUSTOMSTDRPT'  THEN  "
		+ "TO_CHAR(C.CUSTOMSTDRPT) "
		+ "WHEN PARAM_NAME = 'INCLUDEDUALCOV'  THEN  "
		+ "TO_CHAR(C.INCLUDEDUALCOV) "
		+ "WHEN PARAM_NAME = 'ISIMPLCLIENT'  THEN  "
		+ "TO_CHAR(C.ISIMPLCLIENT) "
		+ "WHEN PARAM_NAME = 'USESTDRPT'  THEN  "
		+ "TO_CHAR(C.USESTDRPT) "
		+ "WHEN PARAM_NAME = 'CHECKMMFOR4KEYS'  THEN  "
		+ "TO_CHAR(C.CHECKMMFOR4KEYS) "
		+ "WHEN PARAM_NAME = 'USEQRM'  THEN  " + "TO_CHAR(C.USEQRM) "
		+ "WHEN PARAM_NAME = 'USEARI'  THEN  " + "TO_CHAR(C.USEARI) "
		+ "WHEN PARAM_NAME = 'KEYLVL'  THEN  " + "TO_CHAR(C.KEYLVL) "
		+ "WHEN PARAM_NAME = 'CS_QUERY_TIMEOUT'  THEN  "
		+ "TO_CHAR(C.CS_QUERY_TIMEOUT) "
		+ "WHEN PARAM_NAME = 'ALLOWED_FRONT_CONNECTION_COUNT'  THEN  "
		+ "TO_CHAR(C.ALLOWED_FRONT_CONNECTION_COUNT) "
		+ "WHEN PARAM_NAME = 'CS_ALLOWED_REPORTS'  THEN  "
		+ "TO_CHAR(C.CS_ALLOWED_REPORTS) "
		+ "WHEN PARAM_NAME = 'ROW_COUNT'  THEN  "
		+ "TO_CHAR(C.ROW_COUNT) "
		+ "WHEN PARAM_NAME = 'MEMCENTRIC_YN'  THEN  "
		+ "TO_CHAR(C.MEMCENTRIC_YN) "
		+ "WHEN PARAM_NAME = 'USEGOLDRPT'  THEN  "
		+ "TO_CHAR(C.USEGOLDRPT) "
		+ "WHEN PARAM_NAME = 'USEGOLDPLUS4RPT'  THEN  "
		+ "TO_CHAR(C.USEGOLDPLUS4RPT) "
		+ "WHEN PARAM_NAME = 'CLIENTPROCESSTYPE'  THEN  "
		+ "TO_CHAR(C.CLIENTPROCESSTYPE) "
		+ "WHEN PARAM_NAME = 'PARTKEY'  THEN  " + "TO_CHAR(C.PARTKEY) "
		+ "WHEN PARAM_NAME = 'ALLOWMULTIDIAGS'  THEN  "
		+ "TO_CHAR(C.ALLOWMULTIDIAGS) "
		+ "WHEN PARAM_NAME = 'USEPARTITION'  THEN  "
		+ "TO_CHAR(C.USEPARTITION) "
		+ "WHEN PARAM_NAME = 'USECOMPRESSION'  THEN  "
		+ "TO_CHAR(C.USECOMPRESSION) " + "END AS NEW_VALUE " + ", "
		+ "CASE   " + " WHEN PARAM_NAME = 'CONTRACTTYPE'  THEN  "
		+ "TO_CHAR(B.CONTRACTTYPE) "
		+ "WHEN PARAM_NAME = 'CLIENTTYPE'  THEN  "
		+ "TO_CHAR(B.CLIENTTYPE) "
		+ "WHEN PARAM_NAME = 'STAGE'  THEN  " + "TO_CHAR(B.STAGE) "
		+ "WHEN PARAM_NAME = 'USE_YN'  THEN  " + "TO_CHAR(B.USE_YN) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGMEMS'  THEN  "
		+ "TO_CHAR(B.EXCLUDEINELIGMEMS) "
		+ "WHEN PARAM_NAME = 'EXCLUDEINELIGCLMS'  THEN  "
		+ "TO_CHAR(B.EXCLUDEINELIGCLMS) "
		+ "WHEN PARAM_NAME = 'ELIGSTARTREFDAY'  THEN  "
		+ "TO_CHAR(B.ELIGSTARTREFDAY) "
		+ "WHEN PARAM_NAME = 'ELIGENDREFDAY'  THEN  "
		+ "TO_CHAR(B.ELIGENDREFDAY) "
		+ "WHEN PARAM_NAME = 'MMTYPEFLOAT'  THEN  "
		+ "TO_CHAR(B.MMTYPEFLOAT) "
		+ "WHEN PARAM_NAME = 'RCODE_YN'  THEN  "
		+ "TO_CHAR(B.RCODE_YN) "
		+ "WHEN PARAM_NAME = 'IPDAYSCALLOGIC'  THEN  "
		+ "TO_CHAR(B.IPDAYSCALLOGIC) "
		+ "WHEN PARAM_NAME = 'ROLLUPRXCLM_YN'  THEN  "
		+ "TO_CHAR(B.ROLLUPRXCLM_YN) "
		+ "WHEN PARAM_NAME = 'CHECKDISCHRG_YN'  THEN  "
		+ "TO_CHAR(B.CHECKDISCHRG_YN) "
		+ "WHEN PARAM_NAME = 'CHECKPOSFORADMISSION_YN'  THEN  "
		+ "TO_CHAR(B.CHECKPOSFORADMISSION_YN) "
		+ "WHEN PARAM_NAME = 'CHECKSUPPLYDAYSFORMOI'  THEN  "
		+ "TO_CHAR(B.CHECKSUPPLYDAYSFORMOI) "
		+ "WHEN PARAM_NAME = 'USESTICKY'  THEN  "
		+ "TO_CHAR(B.USESTICKY) "
		+ "WHEN PARAM_NAME = 'CUSTOMSTDRPT'  THEN  "
		+ "TO_CHAR(B.CUSTOMSTDRPT) "
		+ "WHEN PARAM_NAME = 'INCLUDEDUALCOV'  THEN  "
		+ "TO_CHAR(B.INCLUDEDUALCOV) "
		+ "WHEN PARAM_NAME = 'ISIMPLCLIENT'  THEN  "
		+ "TO_CHAR(B.ISIMPLCLIENT) "
		+ "WHEN PARAM_NAME = 'USESTDRPT'  THEN  "
		+ "TO_CHAR(B.USESTDRPT) "
		+ "WHEN PARAM_NAME = 'CHECKMMFOR4KEYS'  THEN  "
		+ "TO_CHAR(B.CHECKMMFOR4KEYS) "
		+ "WHEN PARAM_NAME = 'USEQRM'  THEN  " + "TO_CHAR(B.USEQRM) "
		+ "WHEN PARAM_NAME = 'USEARI'  THEN  " + "TO_CHAR(B.USEARI) "
		+ "WHEN PARAM_NAME = 'KEYLVL'  THEN  " + "TO_CHAR(B.KEYLVL) "
		+ "WHEN PARAM_NAME = 'CS_QUERY_TIMEOUT'  THEN  "
		+ "TO_CHAR(B.CS_QUERY_TIMEOUT) "
		+ "WHEN PARAM_NAME = 'ALLOWED_FRONT_CONNECTION_COUNT'  THEN  "
		+ "TO_CHAR(B.ALLOWED_FRONT_CONNECTION_COUNT) "
		+ "WHEN PARAM_NAME = 'CS_ALLOWED_REPORTS'  THEN  "
		+ "TO_CHAR(B.CS_ALLOWED_REPORTS) "
		+ "WHEN PARAM_NAME = 'ROW_COUNT'  THEN  "
		+ "TO_CHAR(B.ROW_COUNT) "
		+ "WHEN PARAM_NAME = 'MEMCENTRIC_YN'  THEN  "
		+ "TO_CHAR(B.MEMCENTRIC_YN) "
		+ "WHEN PARAM_NAME = 'USEGOLDRPT'  THEN  "
		+ "TO_CHAR(B.USEGOLDRPT) "
		+ "WHEN PARAM_NAME = 'USEGOLDPLUS4RPT'  THEN  "
		+ "TO_CHAR(B.USEGOLDPLUS4RPT) "
		+ "WHEN PARAM_NAME = 'CLIENTPROCESSTYPE'  THEN  "
		+ "TO_CHAR(B.CLIENTPROCESSTYPE) "
		+ "WHEN PARAM_NAME = 'PARTKEY'  THEN  " + "TO_CHAR(B.PARTKEY) "
		+ "WHEN PARAM_NAME = 'ALLOWMULTIDIAGS'  THEN  "
		+ "TO_CHAR(B.ALLOWMULTIDIAGS) "
		+ "WHEN PARAM_NAME = 'USEPARTITION'  THEN  "
		+ "TO_CHAR(B.USEPARTITION) "
		+ "WHEN PARAM_NAME = 'USECOMPRESSION'  THEN  "
		+ "TO_CHAR(B.USECOMPRESSION) " + "END AS OLD_VALUE "
		+ "FROM M_PARAM_PROPS A " + "  LEFT OUTER JOIN "
		+ "    ( SELECT * FROM M_CLIENTS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' ) B "
		+ "    ON 1=1 , "
		+ "    ( SELECT * FROM M_CLIENTS WHERE CLIENTID = '"
		+ sourceClientID
		+ "' ) C "
		+ "WHERE A.TABLE_TYPE = 'M_CLIENTS' "
		+ " UNION ALL "
		+ "SELECT 'M_CLIENTPARAMS' AS TABLE_TYPE ,"
		+ " A.PARAM_NAME ,C.PARAMVAL NEW_VAL,B.PARAMVAL OLD_VAL "
		+ "FROM M_PARAM_PROPS A LEFT OUTER JOIN ( SELECT * FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' AND APPID = '"
		+ destinationAppID
		+ "' ) B "
		+ "   ON A.PARAM_NAME = B.PARAMNAME "
		+ "   LEFT OUTER JOIN ( SELECT * FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ sourceClientID
		+ "' AND APPID = '"
		+ sourceAppID
		+ "' ) C  "
		+ "   ON A.PARAM_NAME = C.PARAMNAME "
		+ "WHERE A.PARAM_NAME IN ( SELECT PARAMNAME FROM ( SELECT PARAMNAME FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ destinationClientID
		+ "' AND APPID = '"
		+ destinationAppID
		+ "' "
		+ "                                                UNION "
		+ "                                                SELECT PARAMNAME FROM M_CLIENTPARAMS WHERE CLIENTID = '"
		+ sourceClientID
		+ "' AND APPID = '"
		+ sourceAppID
		+ "'  "
		+ "                                              ) "
		+ "                        ) ";

	
	System.out.println("Log:"+logSql);
	Long transactionId = null;

	Statement masterstmt = null;
	PreparedStatement preparedStatement = null;
	String helogSchemaName = null;

	int mClientsRecCnt = -1;
	int mClientParamsRecCnt = -1;

	ResultSet rs = null;

	String errorMessage = null;

	String insertLogSql = "";
	DataOpsParam dataOpsParam = null;
	List<DataOpsParam> dataOpsParamList = new ArrayList<DataOpsParam>();

	com.atomikos.icatch.jta.UserTransactionManager tm = new com.atomikos.icatch.jta.UserTransactionManager();

	String alias = null;
	ConnectionPoolManager poolMgr = ConnectionPoolManager.getInstance();
	Connection heLogConn = null;
	try {
	    if (sourceClientID != null && destinationClientID != null
		    && destinationAppID != null && sourceAppID != null) {

		poolMgr.initMasterSchemaDS();

		poolMgr.initXADataSource(DataOpsUtil.LOG_DB);

		tm.begin();
		Transaction tx = tm.getTransaction();

		poolMgr.enlistMasterResources(tx);

		heLogConn = poolMgr.getXAConnection(DataOpsUtil.LOG_DB)
			.getConnection();
		transactionId = DataOpsUtil.getTransactionId(heLogConn);
		
		helogSchemaName = ((ConnectionParameters) poolMgr.getConnectionProperties().get(DataOpsUtil.LOG_DB.toUpperCase())).getUserName();

		insertLogSql = " INSERT INTO " + helogSchemaName + ".DATAOPS_LOG  (CLIENTID, APPID, USERID, ACTIONDATE, PARAMETERNAME, OLDVALUE, "
			+ " NEWVALUE, ACTIONDESC, TABLE_TYPE, TRANSACTION_ID ) VALUES";
		insertLogSql += " ( ";
		insertLogSql += " '" + destinationClientID + "', '"
			+ destinationAppID + "', '" + dataOpsUserId
			+ "', sysdate " + " , ? , ? ,  ? , '"
			+ DataOpsUtil.ACTION_COPY_PARAMETERS + " from "
			+ sourceAppID + " to " + destinationAppID + "', ? , "
			+ transactionId;
		insertLogSql += " ) ";


		masterstmt = poolMgr
			.getXAConnection(DataOpsUtil.MASTER_DB.toUpperCase())
			.getConnection().createStatement();
		rs = masterstmt.executeQuery(logSql);
		while (rs.next()) {
		    dataOpsParam = new DataOpsParam();
		    dataOpsParam.setParamName(rs.getString(2));
		    dataOpsParam.setParamCurrValue(rs.getString(3));
		    dataOpsParam.setParamOldValue(rs.getString(4));
		    dataOpsParam.setParamTableType(rs.getString(1));

		    dataOpsParamList.add(dataOpsParam);

		}

		if (dataOpsParamList != null && dataOpsParamList.size() > 0) {
		    
		    preparedStatement = poolMgr
				.getXAConnection(DataOpsUtil.MASTER_DB.toUpperCase())
				.getConnection().prepareStatement(insertLogSql);
		   /* preparedStatement = heLogConn
			    .prepareStatement(insertLogSql);*/

		    for (int i = 0; i < dataOpsParamList.size(); i++) {
			dataOpsParam = dataOpsParamList.get(i);

			preparedStatement.setString(1,
				dataOpsParam.getParamName());
			preparedStatement.setString(2,
				(dataOpsParam.getParamOldValue()!=null ? dataOpsParam.getParamOldValue().replace("'", "''") : dataOpsParam.getParamOldValue()));
			preparedStatement.setString(3,
				(dataOpsParam.getParamCurrValue()!=null ? dataOpsParam.getParamCurrValue().replace("'", "''") : dataOpsParam.getParamCurrValue()));
			preparedStatement.setString(4,
				dataOpsParam.getParamTableType());
			preparedStatement.addBatch();

		    }

		    preparedStatement.executeBatch();

		}

		int masterCounter = 1;
		while (DataOpsUtil.getProperty(DataOpsUtil.HAWKEYEMASTER + ""
			+ masterCounter) != null) {
		    alias = DataOpsUtil.getProperty(
			    DataOpsUtil.HAWKEYEMASTER + "" + masterCounter)
			    .toUpperCase();

		    System.out.println("aliasName====" + alias);

		    masterstmt = poolMgr.getXAConnection(alias).getConnection()
			    .createStatement();

		    // execute M_CLIENTS_SQL
		    mClientsRecCnt = masterstmt.executeUpdate(M_CLIENTS_SQL);

		    // execute M_CLIENTPARAMS_DEL_SQL
		    masterstmt.executeUpdate(M_CLIENTPARAMS_DEL_SQL);

		    // execute M_CLIENTPARAMS_INSERT_SQL
		    mClientParamsRecCnt = masterstmt
			    .executeUpdate(M_CLIENTPARAMS_INSERT_SQL);

		    // set the IS_ACTIVE Flag = N for the parameters not
		    // assigned to any app.
		    if (masterCounter == 1) {
			String paramPropUpdateSql = " UPDATE M_PARAM_PROPS SET IS_ACTIVE = 'N' WHERE TABLE_TYPE = 'M_CLIENTPARAMS' AND "
				+ "PARAM_NAME NOT IN ( SELECT DISTINCT PARAMNAME FROM  M_CLIENTPARAMS )   ";
			masterstmt.executeUpdate(paramPropUpdateSql);
		    }

		    masterCounter += 1;

		}

		masterstmt.close();
		preparedStatement.close();
		poolMgr.closeConnections();

		poolMgr.delistAllMasterResource(tx);
		tm.commit();

	    }

	} catch (Exception e) {
	    errorMessage = e.getMessage();
	    try {
		tm.rollback();
	    } catch (Exception e1) {
		e1.printStackTrace();
	    }

	    if (mClientsRecCnt < 0) {
		throw new SQLException("Copy Failed on M_CLIENTS Parameters", e);
	    } else if (mClientParamsRecCnt < 0) {
		throw new SQLException(
			"Copy Failed on M_CLIENTPARAMS Parameters", e);
	    } else {
		throw new SQLException("Copy Failed", e);
	    }

	} finally {

	    try {

		String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
			DataOpsUtil.TX_COPY_PARAMETERS);
		String emailContent = EmailUtility.getCopyToParameterContent(
			DataOpsUtil.TX_COPY_PARAMETERS, transactionId,
			dataOpsUserId, destinationClientID, destinationAppID,
			sourceClientID, sourceAppID, errorMessage);

		String emailSendStatus = EmailUtility.sendEmail(dataOpsUserId,
			emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
			: DataOpsUtil.EMAIL_SEND_FAILED;

		DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
			.getSendToAddr(dataOpsUserId),
			EmailUtility.sendFromAddr, emailSubject, DataOpsUtil
				.getEmailLogMessage(errorMessage,
					DataOpsUtil.TX_COPY_PARAMETERS,
					transactionId, dataOpsUserId),
			emailSendStatus);

	    } catch (Exception e) {
		e.printStackTrace();
	    } finally {

		try {
		    poolMgr.closeXAConnections();
		} catch (Exception e) {
		    e.printStackTrace();
		}

	    }

	}

    }

}
