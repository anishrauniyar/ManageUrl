package com.vh.dataOps.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vh.dataOps.dao.ViewParamDAO;
import com.vh.dataOps.dao.ViewParamDAOFactory;
import com.vh.dataOps.dto.App;
import com.vh.dataOps.dto.DataOpsParam;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;

/**
 * Controller for ViewUpdate Parameter Form.
 * 
 * @author sjain
 * 
 */
public class ViewParameters extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final String VIEW_PARAM = "dataOps/ViewUpdateParams.jsp";
    private static final String COPY_PARAM = "dataOps/copyParameters.jsp";

    public void doGet(HttpServletRequest request, HttpServletResponse response)
	    throws ServletException, IOException {
	doPost(request, response);

    }

    public void processReq(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {

	try {
	    response.setContentType("text/html");

	    String dataOpsUserId = (String) request.getSession().getAttribute(
		    "userID");

	    String client = request.getParameter("dataClientId");

	    if (client == null) {
		client = (String) request.getSession().getAttribute(
			"dataClientId");
	    }

	    String appId = request.getParameter("appID");

	    ViewParamDAO viewParamDAO = ViewParamDAOFactory.getViewParamDAO();

	    if ("copyRequest".equalsIgnoreCase(request
		    .getParameter("requestType"))) {

		try {
		    String sourceClientID = request
			    .getParameter("sourceClientID");
		    String sourceAppID = request.getParameter("sourceAppID");
		    String destinationClientID = request
			    .getParameter("destinationClientID");
		    String destinationAppID = request
			    .getParameter("destinationAppID");
		    String copyHTable = request.getParameter("copyHTable");
		   
		    if(copyHTable != null){
		     if (copyHTable.equalsIgnoreCase("MCLIENTS"))	{
		    	 viewParamDAO.copyMClientParameters(sourceClientID, sourceAppID,
		 			    destinationClientID, destinationAppID,
		 			    dataOpsUserId);
		     }
		   
		    else if (copyHTable.equalsIgnoreCase("MCLIENTPARAMS")){
		    	
		    	viewParamDAO.copyMClientParamParameters(sourceClientID, sourceAppID,
		 			    destinationClientID, destinationAppID,
		 			    dataOpsUserId);	
		    }
		    
		    else {
		    	viewParamDAO.copyAllParameters(sourceClientID, sourceAppID,
			    destinationClientID, destinationAppID,
			    dataOpsUserId);
		    }
		     
		     request.setAttribute("successFlag",
					    DataOpsUtil.SUCCESS_MESSAGE);
				    DataOpsUtil.forward(request, response, COPY_PARAM);
		    } 
		 
		} catch (SQLException e) {
		    response.sendRedirect(COPY_PARAM + "?Err=100&ErrorMessage="
			    + e.getMessage());
		    e.printStackTrace();
		} catch (DataOpsException e) {
		    response.sendRedirect(COPY_PARAM + "?Err=200&ErrorMessage="
			    + e.getMessage() + " ->> " + e.getCause());
		    e.printStackTrace();
		}
		// Copy Operation
	    } else {
		try {
		    if (client != null
			    && appId == null
			    && !"updateRequest".equalsIgnoreCase(request
				    .getParameter("updateReq"))) {
			// When client is selected to populate associated AppIds
			// and
			// parameters

			List<DataOpsParam> dataOps_MClient_List = viewParamDAO
				.getDataOpsParam(client, appId,
					DataOpsUtil.TABLE_M_CLIENTS);
			request.setAttribute("dataOps_MClient_List",
				dataOps_MClient_List);
			List<App> dataOps_AppList = viewParamDAO
				.getAllApps(client);
			request.setAttribute("dataOps_AppList", dataOps_AppList);
			request.setAttribute("dataOps_ClientList", request
				.getSession()
				.getAttribute("dataOps_ClientList"));

			DataOpsUtil.forward(request, response, VIEW_PARAM);

		    } else if (client != null
			    && appId != null
			    && !"updateRequest".equalsIgnoreCase(request
				    .getParameter("updateReq"))) {
			// When client and appId are both selected - to populate
			// parameters

			// populate clientList from session
			request.setAttribute("dataOps_ClientList", request
				.getSession()
				.getAttribute("dataOps_ClientList"));

			// populate appList from session
			request.setAttribute("dataOps_AppList", request
				.getSession().getAttribute("dataOps_AppList"));

			List<DataOpsParam> dataOps_MClient_List = null;
			if ("afterUpdate".equalsIgnoreCase(request
				.getParameter("updateReq"))) {
			    // hit database to get M_CIENTS Parameter List

			    dataOps_MClient_List = viewParamDAO
				    .getDataOpsParam(client, appId,
					    DataOpsUtil.TABLE_M_CLIENTS);
			    request.setAttribute("dataOps_MClient_List",
				    dataOps_MClient_List);

			    request.setAttribute("successFlag",
				    DataOpsUtil.SUCCESS_MESSAGE);

			} else {
			    // populate M_CIENTS Parameter List from session
			    request.setAttribute(
				    "dataOps_MClient_List",
				    request.getSession().getAttribute(
					    "dataOps_MClient_List"));
			}

			request.setAttribute("dataClientId", client);
			request.setAttribute("appID", appId);

			if (!"appid".equalsIgnoreCase(appId)
				&& !"null".equalsIgnoreCase(appId)) {
			    // asigned
			    List<DataOpsParam> dataOps_MClientParam_List = viewParamDAO
				    .getDataOpsParam(client, appId,
					    DataOpsUtil.TABLE_M_CLIENTPARAMS);

			    request.setAttribute("dataOps_MClientParam_List",
				    dataOps_MClientParam_List);

			    // Unassigned
			    List<DataOpsParam> dataOps_MClientParam_NotAssigned_List = viewParamDAO
				    .getNotAssignedDataOpsParam(client, appId,
					    DataOpsUtil.TABLE_M_CLIENTPARAMS);

			    request.setAttribute(
				    "dataOps_MClientParam_NotAssigned_List",
				    dataOps_MClientParam_NotAssigned_List);
			}

			DataOpsUtil.forward(request, response, VIEW_PARAM);
		    } else if (client != null

			    && "updateRequest".equalsIgnoreCase(request
				    .getParameter("updateReq"))) {
			// Update request - When client and appId or client are
			// both
			// selected and
			// UPDATE button is clicked to update & then populate
			// parameters
			Map<String, String> paramMergedMap = null;
			Map<String, String> mClientParamValueMap = null;

			if (appId == null) {
			    appId = (String) request.getSession().getAttribute(
				    "appID");
			}
			Map<String, String> updateMap = new HashMap<String, String>();

			Map m = request.getParameterMap();
			Set s = m.entrySet();
			Iterator it = s.iterator();
			while (it.hasNext()) {
			    Map.Entry<String, String[]> entry = (Map.Entry<String, String[]>) it
				    .next();
			    updateMap.put(entry.getKey(), entry.getValue()[0]);

			}

			@SuppressWarnings("unchecked")
			Map<String, String> mClientValueMap = getcurrValueMap((List<DataOpsParam>) request
				.getSession().getAttribute(
					"dataOps_MClient_List"));

			if (appId != null) {

			    paramMergedMap = new HashMap<String, String>();

			    // mClientParamValueMap has values from database
			    mClientParamValueMap = getcurrValueMap((List<DataOpsParam>) request
				    .getSession().getAttribute(
					    "dataOps_MClientParam_List"));

			    // unassigned
			    @SuppressWarnings("unchecked")
			    Map<String, String> mClientParamNotAssignedValueMap = getcurrValueMap((List<DataOpsParam>) request
				    .getSession()
				    .getAttribute(
					    "dataOps_MClientParam_NotAssigned_List"));

			    paramMergedMap.putAll(mClientParamValueMap);
			    paramMergedMap
				    .putAll(mClientParamNotAssignedValueMap);

			}

			// new

			viewParamDAO.updateDataOpsParam(client, appId,
				updateMap, paramMergedMap,
				mClientParamValueMap, dataOpsUserId,
				mClientValueMap);

			// end

			response.sendRedirect("ViewParameters?updateReq=afterUpdate&dataClientId="
				+ client + "&appID=" + appId);

		    }
		} catch (SQLException e) {
		    response.sendRedirect(VIEW_PARAM + "?Err=100&ErrorMessage="
			    + e.getMessage());
		    e.printStackTrace();
		} catch (DataOpsException e) {
		    response.sendRedirect(VIEW_PARAM + "?Err=200&ErrorMessage="
			    + e.getMessage() + " ->> " + e.getCause());
		    e.printStackTrace();
		}
	    }

	} catch (Exception e) {
	    response.sendRedirect(VIEW_PARAM + "?Err=300&ErrorMessage="
		    + e.getMessage());
	    e.printStackTrace();
	}

    }

    public void destroy() {
	// do nothing.
    }

    /**
     * Returns HashMap from the passed list object holding current param values.
     * 
     * @param paramList
     * @return
     */
    private HashMap<String, String> getcurrValueMap(List<DataOpsParam> paramList) {

	Map<String, String> currentParams = new HashMap<String, String>();
	if(paramList!= null && paramList.size() > 0){
	    for (int i = 0; i < paramList.size(); i++) {
		    String mcStr = paramList.get(i).getParamCurrValue();
		    currentParams.put(paramList.get(i).getParamName(), mcStr);

		} 
	}
	return (HashMap<String, String>) currentParams;
    }

}