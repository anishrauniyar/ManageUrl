package com.vh.dataOps.dao;

import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: DAO factory for Add Parameter.
 * 
 * @author sjain
 * 
 */

public class AddParamDAOFactory {
    private AddParamDAOFactory() {

    }

    public static AddParamDAO getAddParamDAO() throws Exception {
	try {
	    return new AddParamDAOImpl();
	} catch (Exception e) {
	    throw new DataOpsException(
		    "AddParamDAOFactory.getAddParamDAO: DataOpsException while getting AddParamDAO");

	}
    }
}
