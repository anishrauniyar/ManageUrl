package com.vh.dataOps.dto;

import java.io.Serializable;

/**
 * Client DTO
 * 
 * @author sjain
 * 
 */

public class ParamValue implements Serializable {

    private String currValue = null;
    private String newValue = null;
    private String valAssignedFlag = null;
    
    
    public String getCurrValue() {
        return currValue;
    }
    public void setCurrValue(String currValue) {
        this.currValue = currValue;
    }
    public String getNewValue() {
        return newValue;
    }
    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }
    public String getValAssignedFlag() {
        return valAssignedFlag;
    }
    public void setValAssignedFlag(String valAssignedFlag) {
        this.valAssignedFlag = valAssignedFlag;
    }

}
