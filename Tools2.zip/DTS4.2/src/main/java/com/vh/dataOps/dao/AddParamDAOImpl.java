package com.vh.dataOps.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.vh.dataOps.email.EmailUtility;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;
import com.vh.dataOps.util.ResourceRelease;

import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

/**
 * 
 * Description: Implementation class of Add Parameter form, implements
 * AddParamDAO.It handles all DB connectivity along with query building for
 * ViewUpdate Form to retrieve the applications.
 * 
 * @author sjain
 * 
 */

public class AddParamDAOImpl implements AddParamDAO {

    protected AddParamDAOImpl() {
	super();
    }

    /**
     * Add/Insert the parameter and its values into the M_PARAM_PROPS and
     * M_PARAM_VALUES tables
     * 
     * @param dataOpsUserId
     * @param paramName
     * @param paramDisplayName
     * @param paramDesc
     * @param paramValues
     * @throws SQLException
     * @throws DataOpsException
     */
    @Override
    public int addDataOpsParam(String dataOpsUserId, String paramName,
	    String paramDesc, String[] paramValues) throws SQLException,
	    DataOpsException {

	Connection cnn = ConnectionPoolManager.getInstance().getConnection(
		DataOpsUtil.MASTER_DB.toUpperCase());
	Connection heLogConn = ConnectionPoolManager.getInstance()
		.getConnection(DataOpsUtil.LOG_DB.toUpperCase());
	Statement stmt = null;
	ResultSet rs = null;
	int maxId = 0;
	int paramPropCnt = 0;
	Long transactionId = DataOpsUtil.getTransactionId(heLogConn);

	String maxIdSql = "SELECT MAX(PARAMID) FROM M_PARAM_PROPS";

	String insertParamPropSql = " INSERT INTO M_PARAM_PROPS ( PARAMID,PARAM_NAME,TABLE_TYPE,IS_ACTIVE,PARAM_DESC ) "
		+ "VALUES ";

	String insertParamValuesSql = " INSERT INTO M_PARAM_VALUES (PARAMID , PARAM_VALUE) VALUES ";
	String sql = " ";

	String errorMessage = null;

	try {
	    cnn.setAutoCommit(false);
	    heLogConn.setAutoCommit(false);
	    
	    if (paramValues != null && paramValues.length > 0) {
		stmt = cnn.createStatement();

		rs = stmt.executeQuery(maxIdSql);
		if (rs.next()) {
		    maxId = rs.getInt(1);
		}
		maxId = maxId + 1;

		// insert into PARAM_PROP
		insertParamPropSql += " ( '" + maxId + "' , '" + paramName
			+ "' , 'M_CLIENTPARAMS' , 'N' ," + " '" + (paramDesc!=null ? paramDesc.replace("'", "''") : paramDesc)
			+ "' )";

		paramPropCnt = stmt.executeUpdate(insertParamPropSql);
		DataOpsUtil.logIntoDatabase(heLogConn, null, null,
			dataOpsUserId, paramName, null, null,
			DataOpsUtil.ACTION_ADD_PARAMETER_NAME,
			DataOpsUtil.TABLE_M_PARAM_PROPS, transactionId);
		if (paramPropCnt > 0) {
		    for (int i = 0; i < paramValues.length; i++) {
			sql = insertParamValuesSql + "( '" + maxId + "' , '"
				+ paramValues[i] + "' )";

			stmt.executeUpdate(sql);
			DataOpsUtil
				.logIntoDatabase(heLogConn, null, null,
					dataOpsUserId, paramName, null,
					paramValues[i],
					DataOpsUtil.ACTION_ADD_PARAMETER_VALUE,
					DataOpsUtil.TABLE_M_PARAM_VALUES,
					transactionId);
		    }

		}

	    }
	    cnn.commit();
	    heLogConn.commit();

	} catch (SQLException e) {
	    paramPropCnt = 0;
	    errorMessage = e.getMessage();
	    cnn.rollback();
	    heLogConn.rollback();

	    throw new DataOpsException(
		    "Adding Parameters into M_PARAM_PROPS and M_PARAM_VALUES FAILED !! ",
		    e);

	} finally {

	    String emailSubject = DataOpsUtil.getEmailSubject(errorMessage,
		    DataOpsUtil.TX_ADD_PARAMETER);
	    String emailContent = EmailUtility.getParamMangementContent(
		    DataOpsUtil.TX_ADD_PARAMETER, transactionId, dataOpsUserId,
		    paramName, paramDesc, paramDesc, paramValues, null,
		    errorMessage, null);

	    String emailSendStatus = EmailUtility.sendEmail(dataOpsUserId,
		    emailSubject, emailContent) ? DataOpsUtil.EMAIL_SEND_SUCCESS
		    : DataOpsUtil.EMAIL_SEND_FAILED;

	    DataOpsUtil.logEmailTXStatus(transactionId, EmailUtility
		    .getSendToAddr(dataOpsUserId), EmailUtility.sendFromAddr,
		    emailSubject, DataOpsUtil.getEmailLogMessage(errorMessage,
			    DataOpsUtil.TX_ADD_PARAMETER, transactionId,
			    dataOpsUserId), emailSendStatus);

	    ResourceRelease.releaseResources(cnn, stmt, rs);
	    ResourceRelease.releaseResources(heLogConn, null, null);

	}
	return paramPropCnt;

    }

}
