package com.vh.dataOps.dao;

import com.vh.dataOps.exception.DataOpsException;

/**
 * 
 * Description: DAO factory for Add Parameter.
 * 
 * @author sjain
 * 
 */

public class ParamManagementDAOFactory {
    private ParamManagementDAOFactory() {

    }

    public static ParamManagementDAO getParamManagementDAO() throws Exception {
	try {
	    return new ParamManagementDAOImpl();
	} catch (Exception e) {
	    throw new DataOpsException(
		    "ParamManagementDAOFactory.getParamManagementDAO: DataOpsException while getting ParamManagementDAO");

	}
    }
}
