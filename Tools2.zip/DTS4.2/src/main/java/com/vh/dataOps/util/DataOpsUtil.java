package com.vh.dataOps.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.TreeMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;

/**
 * DataOpsUtil Class
 * 
 * @author sjain
 * 
 */

public class DataOpsUtil {

    public static final String TABLE_M_CLIENTS = "M_CLIENTS";
    public static final String TABLE_M_CLIENTPARAMS = "M_CLIENTPARAMS";
    public static final String TABLE_M_PARAM_PROPS = "M_PARAM_PROPS";
    public static final String TABLE_M_PARAM_VALUES = "M_PARAM_VALUES";

    public static final String ACTION_ADD_PARAMETER_NAME = "Add Parameter Name";
    public static final String ACTION_COPY_PARAMETERS = "Copy Parameters";
    public static final String ACTION_UPDATE_PARAMETER_DESC = "Update Parameter Description";
    public static final String ACTION_DELETE_PARAMETER_NAME = "Delete Parameter Name";
    public static final String ACTION_ADD_PARAMETER_VALUE = "Add Parameter Value";
    public static final String ACTION_DELETE_PARAMETER_VALUE = "Delete Parameter Value";
    public static final String ACTION_INSERT_UPDATE_PARAMETER_VALUE = "Insert/Update Parameter Value";
    public static final String ACTION_ASSIGN_PARAMETER = "Assign Parameter";
    public static final String ACTION_UPDATE_PARAMETER_FLAG = "Update Parameter Flag";

    public static final String MASTER_DB = "MDHawkeye->HawkeyeMaster1";
    public static final String LOG_DB = "MDHawkeye->HawkeyeLog";
    public static final String OAM_PROD_DB = "MDHawkeye->HawkeyeOAMProd";
    public static final String LOCAL_HEUSER_DB = "MDHawkeye->LocalHEUser";
    public static final String DTS_HEUSER_DB = "MDHawkeye->HawkeyeUser";

    public static final String DATAOPS_ERROR_PAGE = "dataOps/errorPage.jsp";
    public static final String ERROR_PAGE = "dataOps/errorPage.jsp";

    public static final String SUCCESS_MESSAGE = "Record/s saved successfully";

    // transaction name
    public static final String TX_COPY_PARAMETERS = " Copy To Parameter ";
    public static final String TX_CLIENT_PARAMETER_UPDATE = " Client Parameter Update ";
    public static final String TX_ADD_PARAMETER = " Add Parameter ";
    public static final String TX_ASSIGN_PARAMETER = " Assign Parameter ";
    public static final String TX_DELETE_PARAMETER_VALUE = " Delete Parameter Value ";
    public static final String TX_DELETE_PARAMETER = " Delete Parameter ";
    public static final String TX_EDIT_PARAMETER = " Edit Parameter ";

    public static final String EMAIL_SEND_SUCCESS = "SEND_SUCCESS";
    public static final String EMAIL_SEND_FAILED = "SEND_FAILED";

    
    public static final String HAWKEYEMASTER = "HAWKEYEMASTER";

    public static final String DATAOPS_PROP_PATH = "dataops.properties";

    public static Properties prop = new Properties();

    public static void forward(HttpServletRequest request,
	    HttpServletResponse response, String url) throws Exception {
	RequestDispatcher rd = request.getRequestDispatcher(url);
	rd.forward(request, response);
    }

    public static <K extends Comparable<? super K>, V> Map<K, V> compareKeysAndValues(
	    final Map<K, V> map1, final Map<K, V> map2) {
	final Collection<K> allKeys = new HashSet<K>();
	allKeys.addAll(map1.keySet());
	allKeys.addAll(map2.keySet());
	final Map<K, V> result = new TreeMap<K, V>();
	K newKey;
	V newvalue;
	for (final K key : allKeys) {
	    if ((map1.containsKey(key) == map2.containsKey(key))
		    && !Boolean.valueOf(equal(map1.get(key), map2.get(key)))) {
		newKey = key;
		newvalue = map1.get(key);
		result.put(newKey, newvalue);
	    }
	}
	return result;
    }

    private static boolean equal(final Object obj1, final Object obj2) {
	if (obj1 instanceof String && ("NULL").equalsIgnoreCase((String) obj1)
		&& obj2 == null) {
	    return true;
	} else {
	    return obj1 == obj2 || (obj1 != null && obj1.equals(obj2));
	}

    }

    /**
     * It logs the record into the HELOG.DATAOPS_LOG table on any type of action
     * (insert/update/delete) on M_CLIENTS, MCLIENTPARAMS, M_PARAM_PROPS and
     * M_PARAM_VALUES tables
     * 
     * @param clientId
     * @param appId
     * @param userId
     * @param parmaName
     * @param oldVal
     * @param newval
     * @param actionDesc
     * @param tableType
     * @throws SQLException
     */
    public static void logIntoDatabase(Connection cnn, String clientId,
	    String appId, String userId, String parmaName, String oldVal,
	    String newval, String actionDesc, String tableType,
	    Long transactionId) throws SQLException {

	String insertSql = " INSERT INTO  DATAOPS_LOG  (CLIENTID, APPID, USERID, ACTIONDATE, PARAMETERNAME, OLDVALUE, NEWVALUE, ACTIONDESC, TABLE_TYPE, TRANSACTION_ID ) VALUES";
	insertSql += " ( ";
	insertSql += " '" + clientId + "', '" + appId + "', '" + userId
		+ "', sysdate " + " , '" + parmaName + "', '" + (oldVal!=null ? oldVal.replace("'", "''") : oldVal) + "', '"
		+ (newval!=null ? newval.replace("'", "''") : newval) + "', '" + actionDesc + "', '" + tableType + "' , "
		+ transactionId;
	insertSql += " ) ";

	Statement stmt = null;
	stmt = cnn.createStatement();
	stmt.executeUpdate(insertSql);
    }

    /**
     * It logs the record into the HELOG.DATAOPS_LOG table on any type of action
     * (insert/update/delete) on M_CLIENTS, MCLIENTPARAMS, M_PARAM_PROPS and
     * M_PARAM_VALUES tables
     * 
     * @param stmt
     * @param helogSchemaName
     * @param clientId
     * @param appId
     * @param userId
     * @param parmaName
     * @param oldVal
     * @param newval
     * @param actionDesc
     * @param tableType
     * @param transactionId
     * @throws SQLException
     */
    public static void logIntoDatabase(Statement stmt, String helogSchemaName,
	    String clientId, String appId, String userId, String parmaName,
	    String oldVal, String newval, String actionDesc, String tableType,
	    Long transactionId) throws SQLException {

	String insertSql = " INSERT INTO  "
		+ helogSchemaName
		+ ".DATAOPS_LOG  (CLIENTID, APPID, USERID, ACTIONDATE, PARAMETERNAME, OLDVALUE, NEWVALUE, ACTIONDESC, TABLE_TYPE, TRANSACTION_ID ) VALUES";
	insertSql += " ( ";
	insertSql += " '" + clientId + "', '" + appId + "', '" + userId
		+ "', sysdate " + " , '" + parmaName + "', '" + (oldVal!=null ? oldVal.replace("'", "''") : oldVal) + "', '"
		+ (newval!=null ? newval.replace("'", "''") : newval) + "', '" + actionDesc + "', '" + tableType + "' , "
		+ transactionId;
	insertSql += " ) ";

	stmt.executeUpdate(insertSql);
    }

    /**
      * @param clientId
     * @param appId
     * @param userId
     * @param parmaName
     * @param oldVal
     * @param newval
     * @param actionDesc
     * @param tableType
     * @throws SQLException
     */
    public static void logEmailTXStatus(Long transactionId, String emailSendTo,
	    String emailSendFrom, String emailSubject, String emailMessage,
	    String emailSendStatus) throws SQLException {

	Connection heLogConn = ConnectionPoolManager.getInstance()
		.getConnection(DataOpsUtil.LOG_DB.toUpperCase());
	String insertSql = " INSERT INTO  EMAIL_LOG  (TRANSACTION_ID, SEND_TO, SEND_FROM, SUBJECT, MESSAGE, SEND_STATUS, LOG_DATE ) VALUES";
	insertSql += " ( ";
	insertSql += " " + transactionId + ", '" + emailSendTo + "', '"
		+ emailSendFrom + "', '" + emailSubject + "', '" + (emailMessage!=null ? emailMessage.replace("'", "''") : emailMessage)
		+ "', '" + emailSendStatus + "', sysdate ";
	insertSql += " ) ";

	Statement stmt = null;

	try {
	    heLogConn.setAutoCommit(false);
	    stmt = heLogConn.createStatement();
	    stmt.executeUpdate(insertSql);
	    heLogConn.commit();

	} finally {
	    ResourceRelease.releaseResources(heLogConn, stmt, null);
	}
    }

    public static Long getTransactionId(Connection heLogConn)
	    throws SQLException {

	ResultSet rs = null;
	Long transactionId = null;

	try {
	    rs = heLogConn.createStatement().executeQuery(
		    " SELECT NVL(MAX(TRANSACTION_ID), 0) + 1 FROM EMAIL_LOG ");
	    if (rs.next()) {
		transactionId = rs.getLong(1);

	    }

	} finally {
	     ResourceRelease.releaseResources(null, null, rs);
	}
	return transactionId;
    }

    public static String getEmailSubject(String errorMessage, String txName) {
	String emailSubject = null;
	if (errorMessage != null) {
	    emailSubject = "Failure Notification -" + txName;
	} else {
	    emailSubject = "Success Notification -" + txName;

	}
	return emailSubject;

    }

    public static String getEmailLogMessage(String errorMessage, String txName,
	    Long transactionId, String dataOpsUserId) {
	String emailLogMessage = null;
	String transactionStatus = null;
	if (errorMessage != null) {
	    emailLogMessage = txName + " is FAILED \n";
	    transactionStatus = "Transaction Status : " + errorMessage + "\n";
	} else {
	    emailLogMessage = txName + " is SUCCESS \n";
	    transactionStatus = "Transaction Status : " + "SUCCESS " + "\n";
	}
	emailLogMessage += "Transaction Details are as below: \n";
	emailLogMessage += "Transaction Id : " + transactionId + "\n";
	emailLogMessage += "UserId : " + dataOpsUserId + "\n";
	emailLogMessage += "Transaction Type : " + txName + "\n";
	emailLogMessage += transactionStatus;

	return emailLogMessage;

    }

    static {
	try {

	    ResourceBundle rb = PropertyResourceBundle.getBundle("dataops");
	    Enumeration keys = rb.getKeys();

	    String k;
	    String kv;
	    for (; keys.hasMoreElements(); prop.setProperty(k, kv)) {
		k = (String) keys.nextElement();
		kv = rb.getString(k);
	    }

	} catch (Exception e) {

	    e.printStackTrace();

	}

    }

    public static String getProperty(String property) {

	return prop.getProperty(property);

    }

}


