package com.vh.dataOps.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vh.dataOps.dao.AssignParamToAppsDAO;
import com.vh.dataOps.dao.AssignParamToAppsDAOFactory;
import com.vh.dataOps.dto.App;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;

/**
 * Controller for Assign Parameter to Applications Form.
 * 
 * @author sjain
 * 
 */
public class AssignParamToApps extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String ASSIGN_APPS_TO_PARAM = "dataOps/AssignParameter.jsp";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignParamToApps() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {

	response.setContentType("text/html");
	String dataOpsUserId = (String) request.getSession().getAttribute(
		"userID");
	String requestType = request.getParameter("requestType");
	try {

	    if ("assignAppRequest".equalsIgnoreCase(requestType)) {
		// Assign Button CLick ...
		// selected param Name
		// selected param value
		// selected client id
		// selected application Ids

		String paramName = request.getParameter("paramName");

		String clientId = request.getParameter("clientID");

		AssignParamToAppsDAO assignParamToAppsDAO = AssignParamToAppsDAOFactory
			.getAssignParamToAppsDAO();

		String parameterDescription = assignParamToAppsDAO
			.getParamDescription(paramName);
		String parameterId = assignParamToAppsDAO.getParamId(paramName);
		Integer updateCount = request.getParameter("updateCount") != null ? Integer
			.parseInt((String) request.getParameter("updateCount"))
			: 0;
		Integer countApps = request.getParameter("countApps") != null ? Integer
			.parseInt((String) request.getParameter("countApps"))
			: 0;
		List<App> appListObj = new ArrayList<App>();
		App appObj = null;

		if (updateCount > 0) {
		    for (int i = 0; i < countApps; i++) {
			appObj = new App();

			appObj.setAppId(request.getParameter("appid" + i));
			appObj.setAppParamOldValue(request
				.getParameter("oldPValue" + i));
			appObj.setAppParamNewValue(request
				.getParameter("newPValue" + i));

			appListObj.add(appObj);

		    }
		}

		if (appListObj != null && appListObj.size() > 0) {
		    assignParamToAppsDAO.assingAppsToParam(clientId,
			    appListObj, parameterId, paramName,
			    parameterDescription, dataOpsUserId);
		}

		List<App> allApps = assignParamToAppsDAO.getAllAppList(
			paramName, clientId);

		request.setAttribute("Assign_AllApps", allApps);
		request.getSession().setAttribute("Assign_AllApps", allApps);
		request.setAttribute("sucessManageParam",
			DataOpsUtil.SUCCESS_MESSAGE);
		DataOpsUtil.forward(request, response, ASSIGN_APPS_TO_PARAM);

	    } else if ("fetchAppsRequest".equalsIgnoreCase(requestType)) {
		String pSelected = request.getParameter("pSelected");
		AssignParamToAppsDAO assignParamToAppsDAO = AssignParamToAppsDAOFactory
			.getAssignParamToAppsDAO();
		// when client is in context - to display respective AppIDs

		request.getSession().setAttribute("selectedPName", pSelected);
		List<App> allApps = null;
		String selectedParamName = null;
		if (pSelected != null) {
		    selectedParamName = pSelected;
		}
		String selectedClientId = null;
		if (!"ChooseClient".equalsIgnoreCase(
			request.getParameter("clientList"))) {

		    selectedClientId = request.getParameter("clientList");
		    allApps = assignParamToAppsDAO.getAllAppList(
			    selectedParamName, selectedClientId);

		}

		request.setAttribute("Assign_AllApps", allApps);
		request.getSession().setAttribute("Assign_AllApps", allApps);
		DataOpsUtil.forward(request, response, ASSIGN_APPS_TO_PARAM);

	    }

	} catch (SQLException e) {
	    response.sendRedirect(ASSIGN_APPS_TO_PARAM
		    + "?Err=100&ErrorMessage=" + e.getMessage());
	    e.printStackTrace();
	} catch (DataOpsException e) {
	    response.sendRedirect(ASSIGN_APPS_TO_PARAM
		    + "?Err=200&ErrorMessage=" + e.getMessage() + " ->> "
		    + e.getCause());
	    e.printStackTrace();
	} catch (Exception e) {
	    response.sendRedirect(ASSIGN_APPS_TO_PARAM
		    + "?Err=300&ErrorMessage=" + e.getMessage());
	    e.printStackTrace();
	}
    }

}
