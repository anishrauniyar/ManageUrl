package com.vh.dataOps.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vh.dataOps.dao.ParamManagementDAO;
import com.vh.dataOps.dao.ParamManagementDAOFactory;
import com.vh.dataOps.exception.DataOpsException;
import com.vh.dataOps.util.DataOpsUtil;

/**
 * Servlet implementation class ParamManagement
 */
public class ParamManagement extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String EDIT_MANAGE = "dataOps/EditParam.jsp";
    private static final String DELETE_PARAMETER = "deleteParameter";
    private static final String UPDATE_PARAMVALUE = "updateRequest";
    private static final String DELETE_PARAMVALUE = "deleteValue";
    private static final String PARAM_MANAGE = "dataOps/ParamManage.jsp";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParamManagement() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {

	try {
	    response.setContentType("text/html");

	    String dataOpsUserId = (String) request.getSession().getAttribute(
		    "userID");

	    // Request type can be for Delete parameter Value,update ParamValue
	    // and
	    // Delete Parameter.
	    String requestType = (String) request.getParameter("requestType");

	    ParamManagementDAO paramManageDAO = ParamManagementDAOFactory
		    .getParamManagementDAO();

	    if (requestType.equalsIgnoreCase(DELETE_PARAMVALUE)) {
		// Handled Parameter value Delete Request
		// Parameter Value to be deleted
		String pValueToDel = (String) request
			.getParameter("paramValueToDel");
		String pName = (String) request.getSession().getAttribute(
			"paramNameToSubmit");

		if ("null".equalsIgnoreCase(pValueToDel)) {
		    pValueToDel = null;
		}
		try {
		    paramManageDAO.deleteParamValue(pName, pValueToDel,
			    dataOpsUserId);
		} catch (SQLException e) {
		    response.sendRedirect(EDIT_MANAGE
			    + "?Err=100&ErrorMessage=" + e.getMessage());
		    e.printStackTrace();
		} catch (DataOpsException e) {
		    response.sendRedirect(EDIT_MANAGE
			    + "?Err=200&ErrorMessage=" + e.getMessage()
			    + " ->> " + e.getCause());
		    e.printStackTrace();
		}

	    } else if (requestType.equalsIgnoreCase(UPDATE_PARAMVALUE)) {
		try {
		    // Handled Parameter value update Request

		    // Parameter Name from EditParam.jsp
		    String paramName = (String) request.getSession()
			    .getAttribute("PARAM_NAME");

		    // update parameter description
		    String newParamDesc = (String) request
			    .getParameter("paramDesc"); // from
		    // Screen
		    String oldParamDesc = (String) request.getSession()
			    .getAttribute("PARAM_DESC");

		    // update existing parameter values
		    Map<String, String> toUpdateMap = new HashMap<String, String>();
		    String paramOldVal = null;
		    String paramNewval = null;

		    Integer paramValuesToUpdate = request
			    .getParameter("checkBoxCount") != null ? Integer
			    .parseInt((String) request
				    .getParameter("checkBoxCount")) : 0;
		    if (paramValuesToUpdate != null) {
			for (int i = 0; i < paramValuesToUpdate; i++) {
			    paramOldVal = request.getParameter("paramValueOld"
				    + i);
			    paramNewval = request.getParameter("paramValueNew"
				    + i);
			    if (paramNewval != null) {
				if (paramOldVal.equalsIgnoreCase(paramNewval)) {
				    // no update
				} else {
				    toUpdateMap.put(paramOldVal, paramNewval);
				}
			    }

			}
		    }

		    // insert new parameter values
		    String[] pValue = request.getParameterValues("paramValue");

		    // new

		    paramManageDAO.updateParameter(paramName, oldParamDesc,
			    newParamDesc, toUpdateMap, pValue, dataOpsUserId);
		    // end

		    // Redirect to caller jsp with respons Text
		    request.setAttribute("sucessManageParam",
			    DataOpsUtil.SUCCESS_MESSAGE);
		    request.setAttribute("updateParamDone", 1);

		    request.getRequestDispatcher(EDIT_MANAGE).forward(request,
			    response);

		} catch (SQLException e) {
		    response.sendRedirect(EDIT_MANAGE
			    + "?Err=100&ErrorMessage=" + e.getMessage());
		    e.printStackTrace();
		} catch (DataOpsException e) {
		    response.sendRedirect(EDIT_MANAGE
			    + "?Err=300&ErrorMessage=" + e.getMessage()
			    + " ->> " + e.getCause());
		    e.printStackTrace();
		}

	    } else if (requestType.equalsIgnoreCase(DELETE_PARAMETER)) {
		String pNameToDel = (String) request
			.getParameter("paramNameToDelete");

		// Delete the parameter Operation.

		// call the delete query to DELELTE the parameter and its all
		// values
		// from the database.

		try {
		    paramManageDAO.deleteParamAndValue(pNameToDel,
			    dataOpsUserId);

		    // Redirect to caller jsp with respons Text
		    request.setAttribute("sucessManageParam",
			    DataOpsUtil.SUCCESS_MESSAGE);
		    request.getRequestDispatcher(PARAM_MANAGE).forward(request,
			    response);

		} catch (SQLException e) {
		    response.sendRedirect(PARAM_MANAGE
			    + "?Err=100&ErrorMessage=" + e.getMessage());
		    e.printStackTrace();
		} catch (DataOpsException e) {
		    response.sendRedirect(PARAM_MANAGE
			    + "?Err=200&ErrorMessage=" + e.getMessage()
			    + " ->> " + e.getCause());
		    e.printStackTrace();
		}

	    } else {

		// Handled onLoad or Reset EditParam.jsp Form request

		// Redirect to caller jsp with respons Text
		request.getRequestDispatcher(EDIT_MANAGE).forward(request,
			response);

	    }

	} catch (Exception e) {
	    response.sendRedirect(PARAM_MANAGE + "?Err=1000&ErrorMessage="
		    + e.getMessage());
	}

    }

}
