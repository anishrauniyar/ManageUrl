package com.vh.dataOps.controller;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vh.dataOps.dto.DataOpsParam;

/**
 * Servlet implementation class ExportToXLS
 */
public class ExportToXLS extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExportToXLS() {
	super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request,
	    HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("application/vnd.ms-excel");
	// Seting fileName dynamically on the basis of client and App. If file
	// exist then overwrite.
	HttpSession httpSession = request.getSession();

	String requestType = request.getParameter("requestType");
	String htmlStr = "";
	response.setHeader("Content-disposition", "inline;fileName="
		+ requestType + ".xls");
	if ("ViewEditParameterExcel".equalsIgnoreCase(requestType)) {

	    String clienID = request.getParameter("expClientID");
	    String appID = request.getParameter("expAppID");
	    // Mclient List
	    List<DataOpsParam> mcliList = (List<DataOpsParam>) httpSession
		    .getAttribute("dataOps_MClient_List");
	    // MclientParams List

	    List<DataOpsParam> mcliParamList = (List<DataOpsParam>) httpSession
		    .getAttribute("dataOps_MClientParam_List");

	    DataOpsParam dataOpsObj = null;
	    String mParamName = null;
	    String mParamCurVal = null;

	    htmlStr = "<HTML>"
		    + "<HEAD>"
		    + "<title>Data Operations Config Application</title>"
		    + "</HEAD>"
		    + "<BODY>"
		    + " <TABLE"
		    + "  style=\"width: 1000; position: fixed; right: 500px; border-width: thick;\""
		    + "  border=\"1\">"
		    + "  <tr>"
		    + "   <th align=\"center\" colspan=2"
		    + "    style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white; border-width: 0;\">"
		    + "    Update Existing Parameter"
		    + "   </th>"
		    + "  </tr>"
		    + "  <tr>"
		    + "   <th colspan=1 align=\"center\""
		    + "    style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">"
		    + "    Client ID - "
		    + clienID
		    + "</th>"
		    + "   <th colspan=1 align=\"center\""
		    + "    style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">"
		    + "    Appid ID - "
		    + appID
		    + "</th>"
		    + "  </tr>"
		    + "  <TR>"
		    + "   <TH width=\"500\" height=\"30\" align=\"center\""
		    + "    style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">MClients</TH>"
		    + "   <TH width=\"500\" height=\"30\" align=\"center\""
		    + "    style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">MClientParams</TH>"
		    + "  </TR>"
		    + "  <TR>"
		    + "   <!-- Mclient table -->"
		    + "   <td width=\"500\">"
		    + "    <TABLE border=\"1\" style=\"width: 500; position: fixed;\">"
		    + "     <TR>"
		    + "      <TH width=\"250\" align=\"center\""
		    + "       style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">Parameter"
		    + "       Name</TH>"
		    + "      <TH width=\"250\" align=\"center\""
		    + "       style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">Parameter"
		    + "       Values</TH>" + "     </TR>";

	    for (Iterator<DataOpsParam> iterator = mcliList.iterator(); iterator
		    .hasNext();) {
		dataOpsObj = (DataOpsParam) iterator.next();
		mParamName = dataOpsObj.getParamName();
		mParamCurVal = "UNASSIGNED".equalsIgnoreCase(dataOpsObj
			.getParamCurrValue()) ? null : dataOpsObj
			.getParamCurrValue();

		htmlStr += "     <tr style=\"height: 23px;\">"
			+ "      <td"
			+ "       style=\"border-width: 1px; font: 9pt Verdana, Arial, Helvetica, sans-serif, bold; color: blue;\""
			+ "       align=\"left\">"
			+ mParamName
			+ "</td>"
			+ "      <td"
			+ "       style=\"border-width: 1px; font: 9pt Verdana, Arial, Helvetica, sans-serif, bold; color: blue;\""
			+ "       align=\"left\">" + mParamCurVal + "</td>"
			+ "" + "     </tr>";

	    }

	    htmlStr += "    </TABLE>"
		    + "   </td>"
		    + "   <!-- MclientParams table -->"
		    + "   <td width=\"500\">"
		    + "    <TABLE border=\"1\" style=\"width: 500; position: fixed;\">"
		    + ""
		    + "     <TR>"
		    + "      <TH width=\"250\" align=\"center\""
		    + "       style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">Parameter"
		    + "       Name</TH>"
		    + "      <TH width=\"250\" align=\"center\""
		    + "       style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white;\">Parameter"
		    + "       Values</TH>" + "     </TR>";

	    if (mcliParamList != null && mcliParamList.size() > 0) {
		for (Iterator<DataOpsParam> iterator = mcliParamList.iterator(); iterator
			.hasNext();) {
		    dataOpsObj = (DataOpsParam) iterator.next();
		    mParamName = dataOpsObj.getParamName();
		    mParamCurVal = dataOpsObj.getParamCurrValue();

		    htmlStr += "     <tr style=\"height: 23px;\">"
			    + "      <td"
			    + "       style=\"border-width: 1px; font: 9pt Verdana, Arial, Helvetica, sans-serif, bold; color: blue;\""
			    + "       align=\"left\">"
			    + mParamName
			    + "</td>"
			    + "      <td"
			    + "       style=\"border-width: 1px; font: 9pt Verdana, Arial, Helvetica, sans-serif, bold; color: blue;\""
			    + "       align=\"left\">" + mParamCurVal + "</td>"
			    + "     </tr> ";

		}

	    }

	    htmlStr += "   </TABLE></td>" + "  </TR>" + " </TABLE>" + "</BODY>"
		    + "</HTML>" + "";
	} else {
	    List<DataOpsParam> mcliParamList = (List<DataOpsParam>) httpSession
		    .getAttribute("dataOps_MClientParam_List");

	    DataOpsParam dataOpsObj = null;
	    String mParamName = null;
	    String mParamDesc = null;
	   
	    List<String> allParamList = null;
	    String paramValues = null;

	    htmlStr = "<html>"
		    + "<head>"
		    + "<title>Data Operations Config Application</title>"
		    + "<body leftmargin=\"0\" topmargin=\"0\" marginheight=\"0\" marginwidth=\"0\">"
		    + "<table style=\"width: 1200\">"
		    + "<tr>"
		    + "<th align=\"center\" colspan=2 height=\"30\""
		    + "style=\"font: bold 12px MS Sans Serif, Geneva, sans-serif; background-color: #03C; color: white; border-width: 0;\">"
		    + "Manage Parameters</th>"
		    + "</tr>"
		    + "<tr>"
		    + "<td>"
		    + "<table style=\"width: 100%;\" border=\"\">"
		    + "<tr>"
		    + "<td "
		    + " style=\"color: white; text-align: center; background-color: #03C; border-width: 1px; border-style: solid; border-color: #DEE #555 #555 #DEE; font: bold 12px MS Sans Serif, Geneva, sans-serif;\""
		    + " width=\"20%\">Parameter Name</td>"
		    + "<td "
		    + " style=\"color: white; text-align: center; background-color: #03C; border-width: 1px; border-style: solid; border-color: #DEE #555 #555 #DEE; font: bold 12px MS Sans Serif, Geneva, sans-serif;\""
		    + " width=\"30%\">Parameter Description</td>"
		    + "<td "
		    + "style=\"color: white; text-align: center; background-color: #03C; border-width: 1px; border-style: solid; border-color: #DEE #555 #555 #DEE; font: bold 12px MS Sans Serif, Geneva, sans-serif;\""
		    + " width=\"15%\">Parameter Values</td>" + " </tr> ";
	    for (Iterator<DataOpsParam> iterator = mcliParamList.iterator(); iterator
		    .hasNext();) {

		dataOpsObj = (DataOpsParam) iterator.next();
		mParamName = dataOpsObj.getParamName();
		mParamDesc = dataOpsObj.getParamDesc();
		allParamList = dataOpsObj.getAllParamList();

		htmlStr += "<tr> "
			+ "<td "
			+ " style=\"border-width: 1px;border-style: solid;border-color: white #BCBFC2 #BCBFC2 white;width: auto;background-color: #F7F7F7;font-family: Arial,Helvetica,sans-serif;font-size: 11px;color: blue;height: 20px;text-decoration: none;\""
			+ " width=\"20%\">"
			+ mParamName
			+ " </td> "
			+ " <td "
			+ " style=\"border-width: 1px;border-style: solid;border-color: white #BCBFC2 #BCBFC2 white;width: auto;background-color: #F7F7F7;font-family: Arial,Helvetica,sans-serif;font-size: 11px;color: blue;height: 20px;text-decoration: none;\""
			+ " width=\"30%\">"
			+ mParamDesc
			+ " </td> "
			+ " <td "
			+ " style=\"border-width: 1px;border-style: solid;border-color: white #BCBFC2 #BCBFC2 white;width: auto;background-color: #F7F7F7;font-family: Arial,Helvetica,sans-serif;font-size: 11px;color: blue;height: 20px;text-decoration: none;\">"
			+ "<select name=\"paramValuess\""
			+ " style=\"width: 100%; margin: 0px 5px 0px 0px; border: 1px solid #E3E3E3; font: 10px Verdana, Arial, Helvetica, sans-serif; color: #333; ext-decoration: none; width: 250px; max-width: 90%; padding: 2px; box-sizing: border-box;\">";

		for (int i = 0; i < allParamList.size(); i++) {
		    paramValues = allParamList.get(i);
		    if (i == 0) {
			htmlStr += " <option value=\"" + paramValues
				+ "\" selected> " + paramValues + " </option> ";
		    } else {
			htmlStr += "<option value=\"" + paramValues + "\" > "
				+ paramValues + " </option> ";
		    }
		}
		htmlStr += " "

		+ "</select>" + "</td>" + "</tr>";

	    }
	    htmlStr += "</table>" + "</td>" + "</tr>" + "" + "" + ""
		    + "</table>" + "</body>" + "</html>";

	}
	System.out.println(htmlStr);
	response.getWriter().write(htmlStr);
    }
}
