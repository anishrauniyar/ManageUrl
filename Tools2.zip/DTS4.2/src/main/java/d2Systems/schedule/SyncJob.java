package d2Systems.schedule;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.util.Date;

import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.StatefulJob;


/**
 * This class execute the RulesDB Synchronization
 * @author suprety
 *
 */

public class SyncJob  implements StatefulJob{
	 private static final String COUNT = "count";
	 /**
    * Quartz requires a public empty constructor so that the
    * scheduler can instantiate the class whenever it needs.
    */
   public SyncJob() {
   	
	   
   }
   /**
    * <p>
    * Called by the <code>{@link org.quartz.Scheduler}</code> when a
    * <code>{@link org.quartz.Trigger}</code> fires that is associated with
    * the <code>Job</code>.
    * </p>
    * 
    * @throws JobExecutionException
    *             if there is an exception while executing the job.
    */
   public void execute(JobExecutionContext context)
       throws JobExecutionException {
       String jobName = context.getJobDetail().getFullName();
       // if the job is recovering print a message
       if (context.isRecovering()) {
           System.out.println("HEUser Synchronization: " + jobName + " RECOVERING at " + new Date());
       } else {
           System.out.println("HEUser Synchronization: " + jobName + " starting at " + new Date());
       }
             //Now Lets run DM Report Job
       boolean hasException=false;
       Exception exception=null;
       HEUserSynchronizer heUserSync = new HEUserSynchronizer();
       try {
    	   heUserSync.syncUsersTable();
       } catch (Exception e) {
    	     ByteArrayOutputStream bout=new ByteArrayOutputStream();
    	     e.printStackTrace(new PrintWriter(bout));
       		 exception=e;
       		 e.printStackTrace();
       		 hasException=true;
       }
       
       JobDataMap data = context.getJobDetail().getJobDataMap();
       int count;
       if (data.containsKey(COUNT)) {
           count = data.getInt(COUNT);
       } else {
           count = 0;
       }
       count++;
       data.put(COUNT, count);
       
     
       
       System.out.println("HEUser users table synchronization: " + jobName + 
               " done at " + new Date() + 
               "\n Execution #" + count);
       if(hasException){
       	  System.out.println("Rules DB Synchronization: " + jobName + 
                     " Exception at " + new Date() + 
                     "\n Execution #" + count);
       	throw new JobExecutionException(exception);
       }
      
       System.out.println("HEUser users table synchronization: " + jobName + 
               " done at " + new Date() + 
               "\n Execution #" + count);
   }
}