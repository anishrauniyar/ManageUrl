package d2Systems.schedule;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import d2Hawkeye.common.connectionPool.dbcp.ConnectionPoolManager;
import d2Hawkeye.dts.sqlBean;

/**
 * Class to synchronize users from production HEUser to local hawekeydts.
 * It uses production HawkeyeOAM user's connection to pull production HEUSER 
 * users and copy it to local HEUSER.
 * From local HEUSER, the users are synchronized to local hawkeyedts
 * @version 	1.0.0 	17 Aug 2007
 * @author 		Subash 		Devkota
 *
 */
public class HEUserSynchronizer extends sqlBean {

	private Connection prodConn=null;
	private Connection localConn=null;
	private Connection dtsConn=null;
	private ResultSet users=null;
	private Statement userStmt=null;
	
	private String stagingTable="usr_users1"; 		// Table to store everything obtained from production 
	private String userTable="usr_users";			// Duplicate table for testing purpose
	//private String userTable="usr_users";	// Real table
	
	private String userBackUpTable="usr_users_bck"; 		// Backup table for the userTable to dump before transferring data from production.
	
	private ConnectionPoolManager pool = ConnectionPoolManager.getInstance();
	 
	/**
	 * Synchronize users from production HEUser to hawkeyeDTS 
	 * @throws Exception
	 */
	public void syncUsersTable() throws Exception{
		System.out.println("Synchronizing users from production");
		try{
		      this.connectProdHawkeyOAM();
		      this.loadUsersFromProduction();
		      
		      this.connectLocalHEUser();
		      this.takeLocalBackUp();
		      this.copyUsersToLocal();
		      this.synchronizeLocalUser();
		      
		      this.connectDTSUser();
		      this.syncHEUserToDTS();
		     System.out.println("Users synchronization complete"); 
	    }catch(Exception e){
			throw e;
		}finally{
			this.closeProdConnection();
			this.closeLocalConnection();
			this.closeDTSConnection();
		}
	
		
	}
	
	/**
	 * make connection to production hawkeyeOAM
	 *
	 */
	private void  connectProdHawkeyOAM(){
		 String alias = "MDHawkeye->HawkeyeOAMProd";
		 prodConn = pool.getConnection(alias);
	}
	
	/**
	 * Make connection to local heuser
	 *
	 */
	private void  connectLocalHEUser(){
		 String alias = "MDHawkeye->LocalHEUser";
		 localConn = pool.getConnection(alias);
	}
	
	/**
	 * Make connection to hawkeyedts 
	 *
	 */
	private void  connectDTSUser(){
		 String alias = "MDHawkeye->HawkeyeUser";
		 dtsConn = pool.getConnection(alias);
	}
	
	/**
	 * Close local heuser connection
	 *
	 */
	private void closeLocalConnection() throws SQLException{
		try{
			if(localConn!=null){
				localConn.close();
			}
		}catch(SQLException e){
			System.out.println("Cannot close local heuser connection: "+e.getMessage());
			throw e;
		}
	}
	
	/**
	 * Close hawkeyedts connection
	 *
	 */
	private void closeDTSConnection()throws SQLException{
		try{
			if(dtsConn!=null){
				dtsConn.close();
			}
		}catch(SQLException e){
			System.out.println("Cannot close hawkeyedts connection: "+e.getMessage());
			throw e;
		}
	}
	
	private void closeProdConnection() throws SQLException{
		if(users!=null){
			users.close();
		}
		
		if(prodConn!=null){
				prodConn.close();
			}
	}
	
	/**
	 * Copy local heuser.usr_users records to backup table heuser.usr_users_bck 
	 *
	 */
	private void takeLocalBackUp(){
		String sql = " delete from heuser."+this.userBackUpTable+" where 1=1 ";
		this.execute(sql, localConn);
		System.out.println("delete:"+sql);
		sql = " insert into heuser."+this.userBackUpTable+" select * from heuser."+this.userTable;
		this.execute(sql,localConn);
		System.out.println("insert:"+sql);
		
	}
	
	/**
	 * Load users from production heuser.usr_users
	 *
	 */
	private void loadUsersFromProduction() throws SQLException{
		String sql = " SELECT USERID,"+
					 "        SEEDUSERID,"+
					 "        USERNAME,"+
					 "        STARTUPPAGE,"+
					 "        LOGINNAME,"+
					 "        EMAIL,"+
					 "        LVL,"+
					 "        CHANGEPWD,"+
					 "        OAMUSERTYPECODE,"+
					 "        OAMSTATUS,"+
					 "        USERTYPECODE,"+
					 "        CSMADM_YN,"+
					 "        EMPRID,"+
					 "        USERSTATUS,"+
					 "        SECRETQUESTIONCODE,"+
					 "        SECQUESANS,"+
					 "        AUTHMANAGER,"+
					 "        D2PWD,"+
					 "        D2KEY,"+
					 "        EMPLOYER,"+
					 "        JOBTITLE,"+
					 "        SECQUESANSKEY,"+
					 "        SECQUESDATESTAMP"+
					 " FROM   HEUSER.USR_USERS where oamstatus=1";
		
		  userStmt = prodConn.createStatement();
		  
		  System.out.println("sql from OAM:"+sql);
		  users=userStmt.executeQuery(sql);
	}
	
	/**
	 * Copy users from production heuser to local staging table
	 *
	 */
	private void copyUsersToLocal() throws SQLException{
		int count=0;
		String sql="";
		try{
			sql=" delete from heuser."+this.stagingTable+" where 1=1  ";
			 System.out.println("copyTOLocal:"+sql);
			this.executeQuery(sql, localConn);
			
			while(users.next() ){
				
			    sql=	 " Insert into heuser."+this.stagingTable+" ( " +
						 " 		  USERID,"+
						 "        SEEDUSERID,"+
						 "        USERNAME,"+
						 "        STARTUPPAGE,"+
						 "        LOGINNAME,"+
						 "        EMAIL,"+
						 "        LVL,"+
						 "        CHANGEPWD,"+
						 "        OAMUSERTYPECODE,"+
						 "        OAMSTATUS,"+
						 "        USERTYPECODE,"+
						 "        CSMADM_YN,"+
						 "        EMPRID,"+
						 "        USERSTATUS,"+
						 "        SECRETQUESTIONCODE,"+
						 "        SECQUESANS,"+
						 "        AUTHMANAGER,"+
						 "        D2PWD,"+
						 "        D2KEY,"+
						 "        EMPLOYER,"+
						 "        JOBTITLE,"+
						 "        SECQUESANSKEY,"+
						 "        SECQUESDATESTAMP"+")" +
						 " values (" +
						 "		  "+((users.getString("USERID")==null)? "null": "'"+this.handleOneQuote(users.getString("USERID"))+"'")+","+
						 "		  "+((users.getString("SEEDUSERID")==null)? "null": ""+users.getLong("SEEDUSERID")+"")+","+
						 "		  "+((users.getString("USERNAME")==null)? "null": "'"+this.handleOneQuote(users.getString("USERNAME"))+"'")+","+
						 "		  "+((users.getString("STARTUPPAGE")==null)? "null": "'"+this.handleOneQuote(users.getString("STARTUPPAGE"))+"'")+","+
						 "		  "+((users.getString("LOGINNAME")==null)? "null": "'"+this.handleOneQuote(users.getString("LOGINNAME"))+"'")+","+
						 "		  "+((users.getString("EMAIL")==null)? "null": "'"+this.handleOneQuote(users.getString("EMAIL"))+"'")+","+
						 "		  "+((users.getString("LVL")==null)? "null": "'"+this.handleOneQuote(users.getString("LVL"))+"'")+","+
						 "		  "+((users.getString("CHANGEPWD")==null)? "null": "'"+this.handleOneQuote(users.getString("CHANGEPWD"))+"'")+","+
						 "		  "+((users.getString("OAMUSERTYPECODE")==null)? "null": "'"+this.handleOneQuote(users.getString("OAMUSERTYPECODE"))+"'")+","+
						 "		  "+((users.getString("OAMSTATUS")==null)? "null": ""+users.getLong("OAMSTATUS")+"")+","+
						 "		  "+((users.getString("USERTYPECODE")==null)? "null": "'"+this.handleOneQuote(users.getString("USERTYPECODE"))+"'")+","+
						 "		  "+((users.getString("CSMADM_YN")==null)? "null": "'"+this.handleOneQuote(users.getString("CSMADM_YN"))+"'")+","+
						 "		  "+((users.getString("EMPRID")==null)? "null": ""+users.getLong("EMPRID")+"")+","+
						 "		  "+((users.getString("USERSTATUS")==null)? "null": ""+users.getLong("USERSTATUS")+"")+","+
						 "		  "+((users.getString("SECRETQUESTIONCODE")==null)? "null": ""+users.getLong("SECRETQUESTIONCODE")+"")+","+
						 "		  "+((users.getString("SECQUESANS")==null)? "null": "'"+this.handleOneQuote(users.getString("SECQUESANS"))+"'")+","+
						 "		  "+((users.getString("AUTHMANAGER")==null)? "null": "'"+this.handleOneQuote(users.getString("AUTHMANAGER"))+"'")+","+
						 "		  "+((users.getString("D2PWD")==null)? "null": "'"+this.handleOneQuote(users.getString("D2PWD"))+"'")+","+
						 "		  "+((users.getString("D2KEY")==null)? "null": "'"+this.handleOneQuote(users.getString("D2KEY"))+"'")+","+
						 "		  "+((users.getString("EMPLOYER")==null)? "null": "'"+this.handleOneQuote(users.getString("EMPLOYER"))+"'")+","+
						 "		  "+((users.getString("JOBTITLE")==null)? "null": "'"+this.handleOneQuote(users.getString("JOBTITLE"))+"'")+","+
						 "		  "+((users.getString("SECQUESANSKEY")==null)? "null": "'"+this.handleOneQuote(users.getString("SECQUESANSKEY"))+"'")+","+
						 "		  "+((users.getDate("SECQUESDATESTAMP")==null)? "null": " to_date('"+users.getDate("SECQUESDATESTAMP")+"', 'yyyy-mm-dd')")+
						 "		  )";
			    //this.executeQuery(sql, localConn);
			    Statement stmt=localConn.createStatement();
			    stmt.executeUpdate(sql);
			    stmt.close();
			    count++;
			}
			 System.out.println(count);
		}catch(SQLException e){
			System.out.println("Error copying users from production to local stating User table : "+e.getMessage());
			System.out.println(sql);
			System.out.println(this.getMessage());
			throw e;
		}catch(Exception e){
			e.printStackTrace();
			//throw e;
		}
		
	}
	
	private void synchronizeLocalUser(){
		String sql = "";
	    sql = 	" MERGE INTO " +
	    		"	heuser."+this.userTable+" a " +
	    		" USING " +
	    		"	(SELECT *  FROM HEUSER."+this.stagingTable+" where oamstatus=1 ) b " +
	    		" ON (A.LOGINNAME=B.LOGINNAME ) "+
	    		" WHEN MATCHED THEN UPDATE " +
	    		"					SET   " +
	    		"                        a.D2PWD = b.D2PWD, " +
	    		"                        a.D2KEY = b.D2KEY, " +
	    		"                        a.EMAIL = b.EMAIL, " +
	    		"                        a.CHANGEPWD=b.CHANGEPWD" +
	    		" WHEN NOT MATCHED THEN INSERT VALUES " +
	    		"	( b.USERID, b.SEEDUSERID, b.USERNAME, b.STARTUPPAGE, b.LOGINNAME, b.EMAIL, b.LVL, b.CHANGEPWD, b.OAMUSERTYPECODE, b.OAMSTATUS," +
	    		"     b.USERTYPECODE, b.CSMADM_YN, b.EMPRID, b.USERSTATUS, b.SECRETQUESTIONCODE, b.SECQUESANS," +
	    		"     b.AUTHMANAGER, b.D2PWD, b.D2KEY, b.EMPLOYER, b.JOBTITLE, b.SECQUESANSKEY, b.SECQUESDATESTAMP " +
	    		"   ) ";
	    System.out.println("synchLocalUser:"+sql);
	    this.execute(sql,localConn);
	}
	/**
	 * Copy users from heuser to hawkeyedts
	 *
	 */
	private void syncHEUserToDTS(){
		 
		String sql = "";
	    sql = "MERGE INTO ztbl_DTS_Users a USING " +
	            " (SELECT LOGINNAME, USERNAME, D2PWD,EMAIL, OAMSTATUS FROM HEUSER.USR_USERS WHERE OAMSTATUS=1) b " +
	          //  " ON (LOWER(a.USERID) = LOWER(b.LOGINNAME)) " +
	            " ON (a.USERID = b.LOGINNAME) " +
	            " WHEN MATCHED THEN UPDATE SET  a.USERNAME = b.USERNAME, " +
	            " a.USERPASSWORD = b.D2PWD, a.EMAIL=b.EMAIL" +
	            " WHEN NOT MATCHED THEN INSERT VALUES (b.LOGINNAME, b.USERNAME, b.D2PWD, SYSDATE, NULL, b.EMAIL) ";
	    System.out.println("synchDTS:"+sql);
		  
	    this.execute(sql,dtsConn);
	  
	    //-- sql below inserts default group for
	    sql = "INSERT INTO ZTBL_DTS_USERSANDGROUPS (USERID, USERGROUP)" +
	          " SELECT a.USERID, c.USERGROUP FROM ztbl_DTS_Users a, " +
	            " (SELECT USERGROUP FROM ZTBL_DTS_USERGROUPS WHERE UPPER(GROUPDESC) LIKE '%DTS VIEWER%') c" +
	            " WHERE NOT EXISTS " +
	           " (SELECT 1 FROM ZTBL_DTS_USERSANDGROUPS b WHERE a.USERID = b.USERID)";
	    this.execute(sql,dtsConn);
	}
	
	
	private String handleOneQuote(String str){
		return str.replaceAll("'","''");
	}
	public void cleanup() throws Exception {}
	
	
}
