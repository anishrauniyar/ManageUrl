package d2Systems.schedule;

import java.util.Date;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.StdSchedulerFactory;

public class DTSScheduler {

	private String cronExpression="0 0/2 * * * ?";
 	
	public void setCronExpression(String cronExpression) {
		this.cronExpression = cronExpression;
	}


	/**
	   * This method will start the OAM Schedules.
	   * @throws Exception
	   */
	  public void run() throws Exception {
		  
		  //	    	First we must get a reference to a scheduler
	      SchedulerFactory sf= new StdSchedulerFactory();
	      Scheduler sched  = sf.getScheduler();
	      
	   /*   try{
	      sched.addJobListener(new ScheduleLogger());
	      }catch(Exception e){
	    	  e.printStackTrace();
	      }*/
	      
	      try{
		      System.out.println("------- Scheduling DTS jobs ------------------");
	          String schedId = sched.getSchedulerInstanceId();
	       
	        
	        JobDetail syncJob = new JobDetail("HEUserSyncJob", schedId,  SyncJob.class);
	        // ask scheduler to re-execute this job if it was in progress when
	        // the scheduler went down...
	        syncJob.setRequestsRecovery(true);
	      //  syncJob.addJobListener("ScheduleLogger");
	        
	        sched.addJob(syncJob, true);
	        
	        // job  will run every other minute 
	        CronTrigger trigger = new CronTrigger("trigger1", schedId, "HEUserSyncJob", schedId,this.cronExpression
			  );
		      
	        Date ft = sched.scheduleJob(trigger);
	        
        
        }catch(Exception e){
      	  e.printStackTrace();
        }
        // jobs don't start firing until start() has been called...
        System.out.println("------- Starting Scheduler ---------------");
        sched.start();
	  }
}
