package d2Systems.schedule;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class DefaultSchedularServlet extends HttpServlet {
	
	 public DefaultSchedularServlet(){
	 }
	 
	 public void init(ServletConfig conf)throws ServletException {
		 super.init(conf);
	        DTSScheduler dtsSch = new DTSScheduler();
	        String cronExpression = conf.getInitParameter("HEUserSyncCronExpression");
	        if(cronExpression!=null && !"".equals(cronExpression.trim())){
	        	dtsSch.setCronExpression(cronExpression);
	        }
	        
	        try{
	        	dtsSch.run();
	        }catch(Exception e){
	        	e.printStackTrace();
	        }
	 }
}