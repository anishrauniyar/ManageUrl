package scrub.security;

import java.util.List;
import scrub.mgmt.Client;

/**
 * defines interface for Security related issues
 */
public interface Security{

    /** check the authentication of user
     * @param user represents user
     * @returns true only if user is a valid user
     */
    boolean isValidUser( User user) throws Exception;

    /** find user
     * @param user represent user to find
     * @returns user found or null
     * @throws Exception on problem accessing the data source
     */
    User getUserByID( String userID) throws Exception;
    /**
     * get the clients by user which includes the clients specified in the list
     * if the specified list is null or empty, all the clients for the user are proveded.
     * @param user User for which client list is to be found.
     * @param restrictClientList list of clients from which to choose. if null ignored.
     * @returns list of clients allowed for the given user.
     */
    List getClientsForUser( User user, List restrictClientList) throws Exception;

}

    
