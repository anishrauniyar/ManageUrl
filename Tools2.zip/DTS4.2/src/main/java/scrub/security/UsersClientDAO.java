package scrub.security;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import scrub.mgmt.Client;
import scrub.util.ReleaseDB;
/**
 * access to clients by users
 */
public class UsersClientDAO extends SecurityDB{
    
    /** protected constructor */
    protected UsersClientDAO(){
	super();
    }


    /**
     * get the clients by user which includes the clients specified in the list
     * if the specified list is null or empty, all the clients for the user are proveded.
     * @param user User for which client list is to be found.
     * @param restrictClientList list of clients from which to choose. if null ignored.
     * @returns list of clients allowed for the given user.
     * @throws Exception if user is null or its id is blank; connection problem.
     */
    public List getClientsForUser( User user, List restrictClientList) throws Exception{
	if( user==null || "".equals( user.getUserID() ) )
	    throw new NullPointerException("null user or user with blank userid is not accepted.. UsersClientDAO.getClientsForUser(..)");
	StringBuffer sb = new StringBuffer(300);
        /*
	sb.append( " select c.ClientID, c.ClientName, c.ContractType from ztbl_DTS_Clients c,");
	sb.append( "  ztbl_DTS_UsersAndClients uc  where uc.ClientID=c.ClientID and uc.UserID='");
	sb.append( user.getUserID() );
	sb.append( "'  order by ClientName ");
          */
    sb.append( " select c.ClientID, c.ClientName, c.ContractType from ztbl_DTS_ClientView  c ");
    sb.append( "   WHERE InUse = 'Y' ");
    sb.append( " order by ClientName ");


	System.out.println("SQL Query: ........" + sb.toString());
	Connection cnn = null;
	Statement stmt = null;
	ResultSet rs = null;
	Client cl = null;
	List ls = new ArrayList( 30);	
	try{
	   cnn = getConnection();
	   stmt = cnn.createStatement(); //System.out.println( sb.toString() );
	   rs = stmt.executeQuery( sb.toString() );
	   while( rs.next() ){
	       cl = new Client( rs.getString(1), rs.getString(2), rs.getString(3) );
	       ls.add( cl);
	   }
	}finally{
	   ReleaseDB.releaseDBResources( cnn, stmt, rs);
	}
	if( restrictClientList != null && !restrictClientList.isEmpty() ){
	    ls.retainAll( restrictClientList );
	}
	return ls;
    }
}
