package scrub.security;

/**
 * provide appropriate object with security interface implemented
 */
public class SecurityFactory{

    /** restrict default constructor to control object creation */
    private SecurityFactory(){}

    private static SecurityFactory _self = null;

    /** initialize itself if not already done so and return pointer to itself */
    public static final synchronized SecurityFactory getInstance(){
	if( _self == null )
	    _self = new SecurityFactory();
	return _self;
    }
    /** return Security */
    public Security getSecurity(){
	return new SecurityImpl();
    }

}
