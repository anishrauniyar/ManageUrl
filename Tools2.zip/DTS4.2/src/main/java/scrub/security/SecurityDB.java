package scrub.security;

import scrub.data.MasterDB;

public class SecurityDB extends MasterDB{

    protected static final String SECURITY_DB = "MDHawkeye->SecurityDB";

    public SecurityDB(){
	setSourceAlias( SECURITY_DB);
    }

}
