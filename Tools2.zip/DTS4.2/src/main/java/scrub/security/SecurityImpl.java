package scrub.security;

import java.util.List;

/**
 * implementation of Security interface
 * delegates most of the responsibilities isolating from the clients ( Facade )
 */

public class SecurityImpl implements Security{

    /** package protected constructor
     *  restrict creation outside the package
     */
    protected SecurityImpl(){}

    /**
     * @param user User to varify
     * @returns true only if valid user, false otherwise
     */
    public boolean isValidUser( User user) throws Exception{
	if( user == null ) return false;
	return ( new UserDAO()).isValidUser( user);
    }
    /**
     * @param userid represents user to find
     * @param returns user found . returns null if not found
     * @throws Exception on problem accessing the datasource
     */
    public User getUserByID( String userid) throws Exception{
	if( userid == null ) return null;
	return ( new UserDAO() ).getUserByID( userid);
    }
    
    /**
     * get the clients by user which includes the clients specified in the list
     * if the specified list is null or empty, all the clients for the user are proveded.
     * @param user User for which client list is to be found.
     * @param restrictClientList list of clients from which to choose. if null ignored.
     * @returns list of clients allowed for the given user.
     */
    public List getClientsForUser( User user, List restrictClientList) throws Exception{
	if( user == null || "".equals( user.getUserID()) )
	    return null;
	return (new UsersClientDAO()).getClientsForUser( user, restrictClientList) ;
    }


}

