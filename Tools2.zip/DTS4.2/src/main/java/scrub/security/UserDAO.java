package scrub.security;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import scrub.util.text.SQLQuoteEncoder;
import scrub.util.ReleaseDB;    
/**
 * validate user
 */
public class UserDAO extends SecurityDB{

    protected UserDAO(){
	super();
    }
    /**
     * @param user User to varify
     * @returns true only if valid user, false otherwise
     */
   public boolean isValidUser( User user) throws Exception{
       if( user==null || "".equals( user.getUserID() ) )
	   return false;
       boolean isValid = false;
       StringBuffer checkQuery = new StringBuffer(300);
       checkQuery.append( "select count(*) AS RecCount from ztbl_DTS_Users where UserID ='");
       checkQuery.append(  user.getUserID()   + "' " );
      // checkQuery.append( " and pwdcompare('" + user.getPassword() + "',convert(nvarchar,UserPassword))=1 " );
       checkQuery.append( " and ora_hash('" + user.getPassword() + "')=UserPassword  " );
       checkQuery.append( " AND  (ExpiryDate>getDate() or ExpiryDate is NULL) ");

       Connection cnn = null;
       Statement stmt = null;
       ResultSet rs = null;

       try{
	   cnn = getConnection();
	   System.out.println("Connection Object is:->"+cnn);
	   stmt = cnn.createStatement();
	   rs = stmt.executeQuery( checkQuery.toString() );
	   if( rs.next() ){
	       isValid = (rs.getInt(1) > 0);
	   }
       }finally{
	   ReleaseDB.releaseDBResources( cnn, stmt, rs);
       }
       return isValid;
    }
    /**
     * @param userID user to find
     * @returns user if found else null
     * @throws Exception on problem
     */
    public User getUserByID( String userID) throws Exception{
	if( userID == null || "".equals( userID) )
	    throw new NullPointerException("Null or blank user id not allowed");
	String sql = "select UserID, UserName from ztbl_DTS_Users where userID='"+userID+"' ";

       Connection cnn = null;
       Statement stmt = null;
       ResultSet rs = null;
       User user = null;
       try{
	   cnn = getConnection();
	   stmt = cnn.createStatement();
	   rs = stmt.executeQuery( sql);
	   if( rs.next() ){
	       user = new User( rs.getString(1), rs.getString(2), null );
	   }
       }finally{
	   ReleaseDB.releaseDBResources( cnn, stmt, rs);
       }
       return user;
    }

}
