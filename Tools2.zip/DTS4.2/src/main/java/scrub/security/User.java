package scrub.security;

/**
 * represents user of the system
 */
public class User{

    String userID = null,
	userName  = null,
	password  = null;

    public User( String uid, String uname, String pwd){
	userID = uid;
	userName = uname;
	password = pwd;
    }

    public String getUserID(){
	return userID;
    }

    public String getUserName(){
	return userName;
    }
    public String getPassword(){
	return password;
    }

}
