package scrub.mgmt;

import java.util.List;

import scrub.util.RequestData;

import scrub.datatransfer.Record;
import scrub.datatransfer.ScrubTable;
import scrub.util.RequestTransfer;
import scrub.rules.RulesConfig;

/**
 * represents the operations specific to Scrub
 */
public interface Scrub{
    /**
     * set clientID
     */
    void setClientID( String clientID);

    /**
     * set DSMRules to apply
     * @param cfg RulesConfig which contains name of DSMRules modules array by table name.
     */
    void setRulesConfig( RulesConfig cfg);
    
    /**
     * @returns list containing name of global AsPrepared table names
     * @throws Exception specific implementation may throw Exception on operation failure
     */
    List getGlobalAsPreaparedTableNameList() throws Exception;

    /**
     * @returns list containing name of HR_DATA_XXXX table names
     * @throws Exception specific implementation may throw Exception on operation failure
     */
    List getHrDataTableNameList() throws Exception;
    
    /**
     * @returns list of client specific AsPrepared table names
     * @throws Exception specific implementation may throw Exception on operation failure
     */
    
    List getClientsAsPreparedTableNameList( String clientID ) throws Exception;

    /**
     * @param tableName
     * @returns true if global table else false
     * @throws NullPointerException if tableName is null
     */
    boolean isGlobal( String tableName);

    /**
     * insert record into specified table
     * @param tblName table name into which data is to be added
     * @param rec Recode to be inserted
     * @returns no. of records inserted
     * @throws Exception in failure to insert record
     */
    int insertRecord( String tblName, Record rec) throws Exception;

    /**
     * update record into specified table
     * @param tblName table name in which data is to be updated
     * @param oldRec record representing old record
     * @param newRec record representing new record with which to update
     * @returns no. of records updated.
     * @throws Exception on failre to update
     */
    int updateRecord( String tblName, Record oldRec, Record newRec) throws Exception;

    /**
     * delete record into specified table
     * @param tblName table name from which data is to delete data
     * @param rec Recode to be deleted
     * @returns no. of records deleted
     * @throws Exception in failure to delete the data
     */
    int deleteRecord( String tblName, Record rec) throws Exception;

    /**
     * browse specified table
     * @param tableName table to browse (not a query)
     * @param afilter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @returns ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */
    public ScrubTable browse( String tableName, RequestData [] afilter,
			      String orderField, String order,
			      ScrubTable scrubTable ) throws Exception;

    /**
     * @param tableName name of the table for which record has to be counted
     * @param fieldValues of Record type containg fields and correspondig values for search criteria
     * @returns number of records satisfying the criteria, inapplicable fields are ignored
     * @throws Exception on backend problem
     */
    int getRecordCount( String tableName, Record fieldValues) throws Exception;

    /**
     * @param tableName name of the table for which primary key fields are to be found
     * @returns string array containing field names for primary key
     * @throws Exception on backend problem
     */
    String [] getPKFields( String tableName) throws Exception;
    
    /**
     * Desc: Renews the contract dates by one additional year
     * Author: Anjana
     * Date: March 28, 2007
     * @param tblName
     * @param newRec
     * @return
     * @throws Exception
     */
    public int renewContractDate(String tblName, Record newRec)throws Exception;

    /**
     * Desc: Query to get expired contract dates with their corresponding P Analysis year if available.
         * This is similar to browse function as above just that it shows expired contract dates only.
     * Author: Anjana
     * DateL May 18, 2007
     * @param tableName table to browse (not a query)
     * @param afilter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @return ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */

    ScrubTable showExpiredContracts ( String tableName, RequestData [] afilter,
		       String orderField, String order,
		       ScrubTable scrubTable ) throws Exception;


}


