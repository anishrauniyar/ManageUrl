package scrub.mgmt;

import scrub.data.ScrubDAOFactoryBuilder;
import scrub.data.ScrubDAOFactory;

/**
 * Manage access to scrub related modules irrespective of implementation
 */
public class ScrubBuilder{
    private static ScrubDAOFactoryBuilder scrubDAOFactoryBuilder = ScrubDAOFactoryBuilder.getInstance();
    private ScrubDAOFactory scrubDAOFactory = null;
    /**
     * block default constructor so that
     * object creation is restricted
     */
    private ScrubBuilder() throws Exception{
	//scrubDAOFactory = scrubDAOFactoryBuilder.getScrubDAOFactory( "SQLServer" );
    scrubDAOFactory = scrubDAOFactoryBuilder.getScrubDAOFactory( "ORCL" );
    }

    private static ScrubBuilder _self = null;
    /**
     * create an instance of itself if not created already
     */
    public static final synchronized ScrubBuilder getInstance() throws Exception{
	if( _self == null ){
	    _self = new ScrubBuilder();
	}
	return _self;
    }
    
    /**
     * @returns Scrub which will interact with the actual Scrub (should return new instance of Scrub)
     */
    public Scrub getScrub(){
	return new ScrubImpl( scrubDAOFactory );
    }
}








