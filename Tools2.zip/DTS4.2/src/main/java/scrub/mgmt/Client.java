package scrub.mgmt;

/**
 * represents client related info.
 * no modification of client data
 */
public class Client{
    private static final String _ = "";
    String clientID = _,
	clientName = _,
	contractType = _;

    public Client(){}
    
    public Client( String clID, String clName, String cntType ){
	setClientID( clID);
	setClientName( clName);
	setContractType( cntType);
    }
	
    protected void set(){}

    public void setClientID( String param ){
	clientID = ifNullBlank( param );
    }

    public void setClientName( String param){
	clientName = ifNullBlank( param );
    }

    public void setContractType( String param){
	contractType = ifNullBlank( param);
    }


    public String getClientID(  ){
	return clientID;
    }

    public String getClientName( ){
	return clientName;
    }

    public String getContractType( ){
	return contractType;
    }

    private static final String ifNullBlank( String param){
	return (param==null)? _: param;
    }
    public boolean equals( Object o){
	if( o instanceof Client ){
	    Client c = (Client) o;
	    if( this.getClientID().equals( c.getClientID() ) ){
		return true;
	    }
	}
	return false;
    }
    public int hashCode(){
	return this.getClientID().hashCode();
    }
}
