package scrub.mgmt;

import java.util.List;

import scrub.data.DBTables;
import scrub.data.TableDAO;
import scrub.data.ScrubDAOFactoryBuilder;
import scrub.data.ScrubDAOFactory;

import scrub.datatransfer.Record;
import scrub.datatransfer.ScrubTable;
import scrub.util.RequestData;
import scrub.exception.ScrubException;

import scrub.rules.RulesConfig;
import scrub.rules.DSMRules;
import scrub.rules.PrimaryKeyRule;

/**
 * implementation of Scrub for performing
 * Scrub related tasks
 */
public class ScrubImpl implements  Scrub {

    private ScrubDAOFactory scrubDAOFactory = null;
    private static String GLOBAL_AS_PREPARED = "HR_Global";
    private static String HR_DATA = "HR_Data";
    private static String AS_PREPARED = "HR_";
    private static final String CLIENT_ID = "ClientID";
    
    
    /** default access restricted*/
    private ScrubImpl(){
    }

    protected ScrubImpl( ScrubDAOFactory df){
	scrubDAOFactory = df;
    }
    private String clientID = null;
    /** set clientID
     * @param clID clientID
     */
    public void setClientID( String clID){
	clientID = clID;
    }
    RulesConfig rulesConfig = null;
    /**
     * set class names array for applying rules
     * @param cfg RulesConfig which contains array of DSMRules module by table name.
     */
    public void setRulesConfig( RulesConfig cfg ){
	rulesConfig = cfg;
    }
    /******************************************************************************************




    ******************************************************************************************/
    /**
     * @returns list containing name of global AsPrepared table names
     */
    public List getGlobalAsPreaparedTableNameList()  throws Exception {
	return getTableNames( GLOBAL_AS_PREPARED );
    }
    
    /**
     * @returns list containing name HR_Data_XXXX tables
    */
    public List getHrDataTableNameList()  throws Exception {
	return getTableNames( HR_DATA );
    }
    
    
    /**
     * @returns list of client specific AsPrepared table names
     */
    public List getClientsAsPreparedTableNameList( String clID ) throws Exception {
	return getTableNames( AS_PREPARED + clID + "_" );
    }
    /**
     * @param prefix prefix for table name
     * @returns array of table names with specified prefix
     * @throws Exception on operation failure
     */
    private  List getTableNames( String prefix ) throws Exception{
	DBTables dbTables = scrubDAOFactory.getDBTables();
	List asPreparedTableNames = dbTables.getTableNameList( prefix );
	return asPreparedTableNames;
    }
    /******************************************************************************************




    ******************************************************************************************/
    /**
     * @param tableName
     * @returns true if global table else false
     * @throws NullPointerException if tableName is null
     */
    public boolean isGlobal( String tableName){
	if( tableName == null){
	    throw new NullPointerException("table name must not be null.");
	}
	boolean isGlobal = false;
	if( tableName.startsWith( "HR_GLOBAL_") ){
	    isGlobal = true;
	}
	return isGlobal;
    }
    /******************************************************************************************




    ******************************************************************************************/
    /**
     * insert record into specified table
     * @param tblName table name into which data is to be added
     * @param rec Recode to be inserted
     * @throws Exception in failure to insert record
     * @returns no. of records inserted
     */
    public int insertRecord( String tblName, Record rec) throws Exception{
	//assertString( clientID, "client id not set before insert in Scrub");
	if( clientID != null){
	    rec.put( CLIENT_ID, clientID);
	}

	if( rulesConfig != null && rulesConfig.isRuleDefined( tblName) ){
	    DSMRules rule = null;
	    String [] ruleModules  = rulesConfig.getRules( tblName);
	    for( int i=0; ruleModules!=null && i< ruleModules.length; i++){
		rule = (DSMRules) Class.forName( ruleModules[ i] ).newInstance();
		rule.setScrub( this);
		rule.validateInsert(  tblName, rec);
	    }
	}

	DSMRules pkRule = new PrimaryKeyRule();
	pkRule.setScrub( this);
	pkRule.validateInsert( tblName, rec);
	
	TableDAO tblDAO = scrubDAOFactory.getTableDAO();
	return tblDAO.insertRecord( tblName, rec);
    }

    /**
     * update record into specified table
     * @param tblName table name in which data is to be updated
     * @param oldRec record representing old record
     * @param newRec record representing new record with which to update
     * @returns no. of records updated
     * @throws Exception on failre to update
     */
    public int updateRecord( String tblName, Record oldRec, Record newRec) throws Exception{
	//assertString( clientID, "client id not set before update in Scrub");
	if( clientID != null){
	    oldRec.put( CLIENT_ID, clientID);
	    newRec.put( CLIENT_ID, clientID);
	}
	if( rulesConfig != null && rulesConfig.isRuleDefined( tblName) ){
	    DSMRules rule = null;
	    String [] ruleModules  = rulesConfig.getRules( tblName);
	    for( int i=0; ruleModules!=null && i< ruleModules.length; i++){
		rule = (DSMRules) Class.forName( ruleModules[ i] ).newInstance();
		rule.setScrub( this);
		rule.validateUpdate(  tblName, oldRec, newRec);
	    }
	}

	DSMRules pkRule = new PrimaryKeyRule();
	pkRule.setScrub( this);
	pkRule.validateUpdate( tblName, oldRec, newRec);
		
	TableDAO tblDAO = scrubDAOFactory.getTableDAO();
	return tblDAO.updateRecord( tblName, oldRec, newRec);
    }
    /******************************************************************************************

	/**
     * Renews the contract date for the client by one additional year.
      * Author: Anjana Shrestha
      * Date: April 2007
     * @param tblName
     * @param newRec
     * @return
     */
    public int renewContractDate(String tblName, Record newRec)throws Exception
    {
        if(clientID != null){
	    newRec.put(CLIENT_ID, clientID);}

        TableDAO tblDAO = scrubDAOFactory.getTableDAO();
        return tblDAO.renewContractDate(tblName, newRec);
    }

    /**
     * Desc: Query to get expired contract dates with their corresponding P Analysis year if available.
         * This is similar to browse function as above just that it shows expired contract dates only.
     * Author: Anjana
     * DateL May 18, 2007
     * @param tableName table to browse (not a query)
     * @param afilter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @return ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */
    public ScrubTable showExpiredContracts( String tableName, RequestData [] afilter,
		       String orderField, String order,
		       ScrubTable scrubTable ) throws Exception{
        TableDAO tableDAO = scrubDAOFactory.getTableDAO();
	    return tableDAO.showExpiredContracts(tableName, afilter, orderField, order, scrubTable );
    }



    /******************************************************************************************/
    /**
     * delete record into specified table
     * @param tblName table name from which data is to delete data
     * @param rec Recode to be deleted
     * @returns no. of records deleted.
     * @throws Exception in failure to delete the data
     */
    public int deleteRecord( String tblName, Record rec) throws Exception{
	//assertString( clientID, "client id not set before delete in Scrub");
	if( clientID != null ){
	    rec.put( CLIENT_ID, clientID);
	}

	if( rulesConfig != null && rulesConfig.isRuleDefined( tblName) ){
	    DSMRules rule = null;
	    String [] ruleModules  = rulesConfig.getRules( tblName);
	    for( int i=0; ruleModules!=null && i< ruleModules.length; i++){
		rule = (DSMRules) Class.forName( ruleModules[ i] ).newInstance();
		rule.setScrub( this);
		rule.validateDelete( tblName, rec);
	    }
	}
	
	TableDAO tblDAO = scrubDAOFactory.getTableDAO();
	return tblDAO.deleteRecord( tblName, rec );
    }
    /******************************************************************************************




    ******************************************************************************************/
    /**
     * browse specified table
     * @param tableName table to browse (not a query)
     * @param afilter array of  RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @returns ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */
    public ScrubTable browse( String tableName, RequestData [] afilter,
		       String orderField, String order,
		       ScrubTable scrubTable ) throws Exception{
	//assertString( clientID, "client id not set before browse in Scrub");
	TableDAO tableDAO = scrubDAOFactory.getTableDAO();
	return tableDAO.browse( tableName, afilter, orderField, order, scrubTable );
    }

    /**
     * verify that clID is set
     * throw IllegalStateException otherwise
     * @param clID clientID to verify
     * @msg message  to throw as part of exception
     */
    private void assertString( String clID, String msg) throws IllegalStateException{
	//System.out.println( " client di " + clID);
	if( clID == null || "".equals( clientID) ){
	    throw new IllegalStateException( msg);
	}
    }
    /******************************************************************************************




    ******************************************************************************************/
    /**
     * @param tableName name of the table for which record has to be counted
     * @param fieldValues of Record type containg fields and correspondig values for search criteria
     * @returns number of records satisfying the criteria, inapplicable fields are ignored
     * @throws Exception on backend problem
     */
    public int getRecordCount( String tableName, Record fieldValues) throws Exception{
	TableDAO tableDAO = scrubDAOFactory.getTableDAO();
	return tableDAO.getRecordCount( tableName, fieldValues);
    }
    /******************************************************************************************




    ******************************************************************************************/
    /**
     * @param tableName name of the table for which primary key fields are to be found
     * @returns string array containing field names for primary key
     * @throws Exception on backend problem
     */
    public String [] getPKFields( String tableName) throws Exception{
	DBTables dbTables = scrubDAOFactory.getDBTables();
	return dbTables.getPKFields( tableName);
    }
}
