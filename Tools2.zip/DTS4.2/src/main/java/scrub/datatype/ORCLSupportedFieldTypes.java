package scrub.datatype;

/**
 * Created by IntelliJ IDEA.
 * User: pshrestha
 * Date: Apr 30, 2007
 * Time: 5:01:42 PM
 * To change this template use File | Settings | File Templates.
 */


import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * represents SQL Server supported field types
 * implements DBMSSupportedFieldTypes
 */
class ORCLSupportedFieldTypes implements DBMSSupportedFieldTypes{
    /** constructor accesseble only from the same package*/
    protected ORCLSupportedFieldTypes(){
    }
    /**
     * @param typeName name of field type e.g. "bigint"
     * @returns true if specified field type name is supporte otherwise false. case sensitive.
     */
    public boolean isSupportedFieldType( String typeName){
	return datatype.containsKey( typeName.trim().toLowerCase() );
    }

    /**
     * @param typeName name of field type
     * type name may have space followed by other describtion in case of SQL Server. e.g int identity
     * only the text before space are considered so that values extracted using ResultSetMetaData can be
     * used directly. The case is specific to SQL Server. Implementation for other DBMS may differ.
     * @returns FieldType represented by specified typeName
     * @throws NullPointerException if specified typeName is not supported
     */
    public FieldType getFieldTypeByTypeName( String  typeName) throws FieldTypeException{
	String tName = typeName.trim().toUpperCase();
	int spaceIndex = tName.indexOf( ' ' );
	if( spaceIndex > 0 ){
	    tName = tName.substring(0, spaceIndex );
	}
	FieldType ft = (FieldType) datatype.get( tName );
	if( ft == null ) {
	    throw new FieldTypeException("dont understatnd " + typeName );
	}
	return ft;
    }

    /**
     * @returns array containing supported field types
     */
    public String [] getSupportedFieldTypeNames(){
	return dataTypeNames;
    }

    /*--------------------------------------------------*/
    /*---------- SQL SERVER TYPE DEFINITIONS -----------*/
    /*--------------------------------------------------*/


    /*--------------------1     ** bigint **     --------------------*/
    /** bigint field type
     * fixed size, precision predefined, size 8 bytes, aotoincrement(identity) allowed
     * sign supported, not a currency
     */
    private static final FieldType bigint
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) bigint ).setFixedSize( true );
	( (FieldTypeImpl) bigint ).setPrecisionSupported( false );
	( (FieldTypeImpl) bigint ).setDefaultSize( 14 );
	( (FieldTypeImpl) bigint ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) bigint ).setSignSupported( true );
	( (FieldTypeImpl) bigint ).setCurrency( false );
	( (FieldTypeImpl) bigint ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------2     ** binary **     --------------------*/
    /** binary field type
     * variable size, precision not applicable, default size 50 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType binary
	= new FieldTypeImpl("RAW");
    static{
	( (FieldTypeImpl) binary ).setFixedSize( false );
	( (FieldTypeImpl) binary ).setPrecisionSupported( false );
	( (FieldTypeImpl) binary ).setDefaultSize( 255 );
	( (FieldTypeImpl) binary ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) binary ).setSignSupported( false );
	( (FieldTypeImpl) binary ).setCurrency( false );
	( (FieldTypeImpl) binary ).setMaxAllowedSize( 4000 );
	( (FieldTypeImpl) binary ).setFieldType( FieldType.TYPE_BINARY );
    }
    /*------------------------------------------------------------*/

    /*--------------------3     ** bit **     --------------------*/
    /** bit field type
     * fixed size, precision not applicable, default size 1 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType bit
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) bit ).setFixedSize( true );
	( (FieldTypeImpl) bit ).setPrecisionSupported( false );
	( (FieldTypeImpl) bit ).setDefaultSize( 1 );
	( (FieldTypeImpl) bit ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) bit ).setSignSupported( false );
	( (FieldTypeImpl) bit ).setCurrency( false );
	( (FieldTypeImpl) bit ).setFieldType( FieldType.TYPE_BINARY );
    }
    /*------------------------------------------------------------*/

    /*--------------------4     ** char **     --------------------*/
    /** char field type
     * variable size, precision not applicable, default size 10 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType schar
	= new FieldTypeImpl("CHAR");
    static{
	( (FieldTypeImpl) schar ).setFixedSize( false );
	( (FieldTypeImpl) schar ).setPrecisionSupported( false );
	( (FieldTypeImpl) schar ).setDefaultSize( 1 );
	( (FieldTypeImpl) schar ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) schar ).setSignSupported( false );
	( (FieldTypeImpl) schar ).setCurrency( false );
	( (FieldTypeImpl) schar ).setMaxAllowedSize( 4000 );
	( (FieldTypeImpl) schar ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------5     ** datetime **     --------------------*/
    /** datetime field type
     * fixed size, precision not applicable, default size 8 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType datetime
	= new FieldTypeImpl("DATE");
    static{
	( (FieldTypeImpl) datetime ).setFixedSize( true );
	( (FieldTypeImpl) datetime ).setPrecisionSupported( false );
	( (FieldTypeImpl) datetime ).setDefaultSize( 8 );
	( (FieldTypeImpl) datetime ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) datetime ).setSignSupported( false );
	( (FieldTypeImpl) datetime ).setCurrency( false );
	( (FieldTypeImpl) datetime ).setFieldType( FieldType.TYPE_DATE );
    }
    /*------------------------------------------------------------*/

    /*--------------------6     ** decimal **     --------------------*/
    /** decimal field type
     * fixed size, precision applicable, default size 8 bytes, aotoincrement(identity) not allowed
     * sign supported, not a currency
     * identity is supported by decimal datatype only if scale is 0. not supported by this module.
     */
    private static final FieldType decimal
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) decimal ).setFixedSize( true );
	( (FieldTypeImpl) decimal ).setPrecisionSupported( true );
	( (FieldTypeImpl) decimal ).setDefaultSize( 12 );
	( (FieldTypeImpl) decimal ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) decimal ).setSignSupported( true );
	( (FieldTypeImpl) decimal ).setCurrency( false );
	( (FieldTypeImpl) decimal ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------7     ** float **     --------------------*/
    /** float field type
     * fixed size, precision not applicable, default size 8 bytes, aotoincrement(identity) not allowed
     * sign supported, not a currency
     */
    private static final FieldType sqlfloat
	= new FieldTypeImpl("FLOAT");
    static{
	( (FieldTypeImpl) sqlfloat ).setFixedSize( true );
	( (FieldTypeImpl) sqlfloat ).setPrecisionSupported( false );
	( (FieldTypeImpl) sqlfloat ).setDefaultSize( 20 );
	( (FieldTypeImpl) sqlfloat ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) sqlfloat ).setSignSupported( true );
	( (FieldTypeImpl) sqlfloat ).setCurrency( false );
	( (FieldTypeImpl) sqlfloat ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------8     ** image **     --------------------*/
    /** image field type
     * predefined size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType image
	= new FieldTypeImpl("BLOB");
    static{
	( (FieldTypeImpl) image ).setFixedSize( true );
	( (FieldTypeImpl) image ).setPrecisionSupported( false );
	( (FieldTypeImpl) image ).setDefaultSize( 16 );
	( (FieldTypeImpl) image ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) image ).setSignSupported( false );
	( (FieldTypeImpl) image ).setCurrency( false );
	( (FieldTypeImpl) image ).setFieldType( FieldType.TYPE_BINARY );
    }
    /*------------------------------------------------------------*/

    /*--------------------9     ** int **     --------------------*/
    /** int field type
     * predefined size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType integer
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) integer ).setFixedSize( true );
	( (FieldTypeImpl) integer ).setPrecisionSupported( false );
	( (FieldTypeImpl) integer ).setDefaultSize( 4 );
	( (FieldTypeImpl) integer ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) integer ).setSignSupported( false );
	( (FieldTypeImpl) integer ).setCurrency( false );
	( (FieldTypeImpl) integer ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------10     ** money **     --------------------*/
    /** money field type
     * predefined size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * sign support, a currency
     */
    private static final FieldType money
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) money ).setFixedSize( true );
	( (FieldTypeImpl) money ).setPrecisionSupported( false );
	( (FieldTypeImpl) money ).setDefaultSize( 14 );
	( (FieldTypeImpl) money ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) money ).setSignSupported( true );
	( (FieldTypeImpl) money ).setCurrency( false );
	( (FieldTypeImpl) money ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------11     ** nchar **     --------------------*/
    /** nchar field type
     * variable size, precision not applicable, default size 10 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType nchar
	= new FieldTypeImpl("CHAR");
    static{
	( (FieldTypeImpl) nchar ).setFixedSize( false );
	( (FieldTypeImpl) nchar ).setPrecisionSupported( false );
	( (FieldTypeImpl) nchar ).setDefaultSize( 1 );
	( (FieldTypeImpl) nchar ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) nchar ).setSignSupported( false );
	( (FieldTypeImpl) nchar ).setCurrency( false );
	( (FieldTypeImpl) nchar ).setMaxAllowedSize( 4000 );
	( (FieldTypeImpl) nchar ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------12     ** ntext **     --------------------*/
    /** ntext field type
     * fixed size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType ntext
	= new FieldTypeImpl("CLOB");
    static{
	( (FieldTypeImpl) ntext ).setFixedSize( true );
	( (FieldTypeImpl) ntext ).setPrecisionSupported( false );
	( (FieldTypeImpl) ntext ).setDefaultSize( 16 );
	( (FieldTypeImpl) ntext ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) ntext ).setSignSupported( false );
	( (FieldTypeImpl) ntext ).setCurrency( false );
	( (FieldTypeImpl) ntext ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------13     ** numeric **     --------------------*/
    /** numeric field type
     * fixed size, precision applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * sign supported, not a currency
     * identity is supported by numeric datatype only if scale is 0. not supported by this module.
     * comparable to decimal except the size is double.
     */
    private static final FieldType numeric
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) numeric ).setFixedSize( true );
	( (FieldTypeImpl) numeric ).setPrecisionSupported( true );
	( (FieldTypeImpl) numeric ).setDefaultSize( 16 );
	( (FieldTypeImpl) numeric ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) numeric ).setSignSupported( true );
	( (FieldTypeImpl) numeric ).setCurrency( false );
	( (FieldTypeImpl) numeric ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------14     ** nvarchar **     --------------------*/
    /** nvarchar field type
     * variable size, precision not applicable, default size 50 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType nvarchar
	= new FieldTypeImpl("VARCHAR2");
    static{
	( (FieldTypeImpl) nvarchar ).setFixedSize( false );
	( (FieldTypeImpl) nvarchar ).setPrecisionSupported( false );
	( (FieldTypeImpl) nvarchar ).setDefaultSize( 50 );
	( (FieldTypeImpl) nvarchar ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) nvarchar ).setSignSupported( false );
	( (FieldTypeImpl) nvarchar ).setCurrency( false );
	( (FieldTypeImpl) nvarchar ).setMaxAllowedSize( 4000 );
	( (FieldTypeImpl) nvarchar ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------15     ** real **     --------------------*/
    /** real field type
     * fixed size, precision not applicable, default size 4 bytes, aotoincrement(identity) not allowed
     * sign supported, not a currency
     * size is half of float
     */
    private static final FieldType sqlreal
	= new FieldTypeImpl("FLOAT");
    static{
	( (FieldTypeImpl) sqlreal ).setFixedSize( true );
	( (FieldTypeImpl) sqlreal ).setPrecisionSupported( false );
	( (FieldTypeImpl) sqlreal ).setDefaultSize( 4 );
	( (FieldTypeImpl) sqlreal ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) sqlreal ).setSignSupported( true );
	( (FieldTypeImpl) sqlreal ).setCurrency( false );
	( (FieldTypeImpl) sqlreal ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------16     ** smalldatetime **     --------------------*/
    /** smalldatetime field type
     * fixed size, precision not applicable, default size 4 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType smalldatetime
	= new FieldTypeImpl("DATE");
    static{
	( (FieldTypeImpl) smalldatetime ).setFixedSize( true );
	( (FieldTypeImpl) smalldatetime ).setPrecisionSupported( false );
	( (FieldTypeImpl) smalldatetime ).setDefaultSize( 8 );
	( (FieldTypeImpl) smalldatetime ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) smalldatetime ).setSignSupported( false );
	( (FieldTypeImpl) smalldatetime ).setCurrency( false );
	( (FieldTypeImpl) smalldatetime ).setFieldType( FieldType.TYPE_DATE );
    }
    /*------------------------------------------------------------*/


    /*--------------------17     ** smallint **     --------------------*/
    /** smallint field type
     * fixed size, precision predefined, size 2 bytes, aotoincrement(identity) allowed
     * sign supported, not a currency
     */
    private static final FieldType smallint
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) bigint ).setFixedSize( true );
	( (FieldTypeImpl) bigint ).setPrecisionSupported( false );
	( (FieldTypeImpl) bigint ).setDefaultSize( 2 );
	( (FieldTypeImpl) bigint ).setAutoIncrementApplicable( true );
	( (FieldTypeImpl) bigint ).setSignSupported( true );
	( (FieldTypeImpl) bigint ).setCurrency( false );
	( (FieldTypeImpl) smallint ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/


    /*--------------------18     ** smallmoney **     --------------------*/
    /** smallmoney field type
     * predefined size, precision not applicable, default size 4 bytes, aotoincrement(identity) not allowed
     * sign support, a currency
     */
    private static final FieldType smallmoney
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) smallmoney ).setFixedSize( true );
	( (FieldTypeImpl) smallmoney ).setPrecisionSupported( false );
	( (FieldTypeImpl) smallmoney ).setDefaultSize( 4 );
	( (FieldTypeImpl) smallmoney ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) smallmoney ).setSignSupported( true );
	( (FieldTypeImpl) smallmoney ).setCurrency( false );
	( (FieldTypeImpl) smallmoney ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------19     ** sql_variant **     --------------------*/
    /** sql_variant field type
     * undefined size, precision not applicable, undefined default size 4 bytes, aotoincrement(identity) not allowed
     * sign support, a currency
     */
    private static final FieldType sql_variant
	= new FieldTypeImpl("LONG RAW");
    static{
	( (FieldTypeImpl) sql_variant ).setFixedSize( true );
	( (FieldTypeImpl) sql_variant ).setPrecisionSupported( false );
	( (FieldTypeImpl) sql_variant ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) sql_variant ).setSignSupported( false );
	( (FieldTypeImpl) sql_variant ).setCurrency( false );
	( (FieldTypeImpl) sql_variant ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------20     ** text **     --------------------*/
    /** text field type
     * fixed size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType text
	= new FieldTypeImpl("CLOB");
    static{
	( (FieldTypeImpl) text ).setFixedSize( true );
	( (FieldTypeImpl) text ).setPrecisionSupported( false );
	( (FieldTypeImpl) text ).setDefaultSize( 16 );
	( (FieldTypeImpl) text ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) text ).setSignSupported( false );
	( (FieldTypeImpl) text ).setCurrency( false );
	( (FieldTypeImpl) text ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------21     ** timestamp **     --------------------*/
    /** timestamp field type
     * fixed size, precision not applicable, default size 8 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     * similar to datetime.
     */
    private static final FieldType timestamp
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) timestamp ).setFixedSize( true );
	( (FieldTypeImpl) timestamp ).setPrecisionSupported( false );
	( (FieldTypeImpl) timestamp ).setDefaultSize( 8 );
	( (FieldTypeImpl) timestamp ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) timestamp ).setSignSupported( false );
	( (FieldTypeImpl) timestamp ).setCurrency( false );
	( (FieldTypeImpl) timestamp ).setFieldType( FieldType.TYPE_DATE );
    }
    /*------------------------------------------------------------*/

    /*--------------------22     ** tinyint **     --------------------*/
    /** tinyint field type
     * predefined size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType tinyint
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) tinyint ).setFixedSize( true );
	( (FieldTypeImpl) tinyint ).setPrecisionSupported( false );
	( (FieldTypeImpl) tinyint ).setDefaultSize( 1 );
	( (FieldTypeImpl) tinyint ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) tinyint ).setSignSupported( false );
	( (FieldTypeImpl) tinyint ).setCurrency( false );
	( (FieldTypeImpl) tinyint ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------23     ** uniqueidentifier **     --------------------*/
    /** uniqueidentifier field type
     * fixed size, precision not applicable, default size 16 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType uniqueidentifier
	= new FieldTypeImpl("NUMBER");
    static{
	( (FieldTypeImpl) uniqueidentifier ).setFixedSize( true );
	( (FieldTypeImpl) uniqueidentifier ).setPrecisionSupported( false );
	( (FieldTypeImpl) uniqueidentifier ).setDefaultSize( 16 );
	( (FieldTypeImpl) uniqueidentifier ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) uniqueidentifier ).setSignSupported( false );
	( (FieldTypeImpl) uniqueidentifier ).setCurrency( false );
	( (FieldTypeImpl) uniqueidentifier ).setFieldType( FieldType.TYPE_NUMERIC );
    }
    /*------------------------------------------------------------*/

    /*--------------------24     ** varbinary **     --------------------*/
    /** varbinary field type
     * variable size, precision not applicable, default size 50 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType varbinary
	= new FieldTypeImpl("RAW");
    static{
	( (FieldTypeImpl) varbinary ).setFixedSize( false );
	( (FieldTypeImpl) varbinary ).setPrecisionSupported( false );
	( (FieldTypeImpl) varbinary ).setDefaultSize( 255 );
	( (FieldTypeImpl) varbinary ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) varbinary ).setSignSupported( false );
	( (FieldTypeImpl) varbinary ).setCurrency( false );
	( (FieldTypeImpl) varbinary ).setMaxAllowedSize( 4000 );
	( (FieldTypeImpl) varbinary ).setFieldType( FieldType.TYPE_TEXT );
    }
    /*------------------------------------------------------------*/

    /*--------------------25     ** varchar **     --------------------*/
    /** varchar field type
     * variable size, precision not applicable, default size 50 bytes, aotoincrement(identity) not allowed
     * no sign support, not a currency
     */
    private static final FieldType varchar
	= new FieldTypeImpl("VARCHAR2");
    static{
	( (FieldTypeImpl) varchar ).setFixedSize( false );
	( (FieldTypeImpl) varchar ).setPrecisionSupported( false );
	( (FieldTypeImpl) varchar ).setDefaultSize( 50 );
	( (FieldTypeImpl) varchar ).setAutoIncrementApplicable( false );
	( (FieldTypeImpl) varchar ).setSignSupported( false );
	( (FieldTypeImpl) varchar ).setCurrency( false );
	( (FieldTypeImpl) varchar ).setMaxAllowedSize( 4000 );
	( (FieldTypeImpl) varchar ).setFieldType( FieldType.TYPE_TEXT );
    }


    /*------------------------------------------------------------*/

    /**
     * no. of field types currently supported by the module
     */
    private static final int SUPPORTED_TYPES  = 25;
    /**
     * datatype is a Map which holds name to FieldType mapping
     */
    private static final Map datatype = new HashMap( SUPPORTED_TYPES );

    /**
     * datypes name in string as supported by MS SQL Server
     * and corresponding FieldType mapping
     * Twenty-five of the datatypes are listed in datatypes array
     * which is supported by SQL Server 2000
     */
    static {

	datatype.put( bigint.getName(),		bigint );		// 1. big integer
	datatype.put( binary.getName(),		binary );		// 2. binary
	datatype.put( bit.getName(),		bit );			// 3. bit
	datatype.put( schar.getName(),		schar );		// 4. character
	datatype.put( datetime.getName(),	datetime );		// 5. date
	datatype.put( decimal.getName(),	decimal );		// 6. decimal
	datatype.put( sqlfloat.getName(),	sqlfloat );		// 7. float
	datatype.put( image.getName(),		image );		// 8. image
	datatype.put( integer.getName(),	integer );		// 9. integer
	datatype.put( money.getName(),		money );		//10. money
	datatype.put( nchar.getName(),		nchar );		//11. character unicode
	datatype.put( ntext.getName(),		ntext );		//12. text unicode
	datatype.put( numeric.getName(),	numeric );		//13. numeric
	datatype.put( nvarchar.getName(),	nvarchar );		//14.
	datatype.put( sqlreal.getName(),        sqlreal );	        //15.
	datatype.put( smalldatetime.getName(),	smalldatetime );	//16.
	datatype.put( smallint.getName(),	smallint );		//17.
	datatype.put( smallmoney.getName(),	smallmoney );		//18.
	datatype.put( sql_variant.getName(),	sql_variant );		//19.
	datatype.put( text.getName(),		text );			//20.
	datatype.put( timestamp.getName(),	timestamp );		//21
	datatype.put( tinyint.getName(),	tinyint );		//22.
	datatype.put( uniqueidentifier.getName(), uniqueidentifier );	//23.
	datatype.put( varbinary.getName(),	varbinary );		//24.
	datatype.put( varchar.getName(),	varchar );		//25.
    };

    /**
     * array of SQL Server specific data type names
     */
    private static String [] dataTypeNames = new String[ SUPPORTED_TYPES ];
    static{
	datatype.keySet().toArray( dataTypeNames );
    }
}


