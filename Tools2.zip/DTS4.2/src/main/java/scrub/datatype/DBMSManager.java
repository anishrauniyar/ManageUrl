package  scrub.datatype;

/**
 * Represented interface to interacat with specific DBMS
 */
public interface DBMSManager{

    /**
     * @returns DBMSSupportedFieldTypes represented by this DBMSManager.
     */
    DBMSSupportedFieldTypes getDBMSSupportedFieldTypes();
}
