package scrub.datatype;

import java.util.Map;
import java.util.HashMap;

/**
 * Factory class to create DBMS specific DBMSManager
 * Currently supports DBMSManager for SQL server only.
 * Parameter name or server name for SQL Server = "SQLServer" case insensitive.
 * Singelton
 */
public class DBMSManagerFactory{

    /** name DBMSManager map */
    private Map dbmsMap = null;

    private static final String SQL_SERVER = "SQLServer";
    private static final String ORCL_SERVER = "ORCL";

    /**
     * deny default object creation
     */
    private DBMSManagerFactory(){
	dbmsMap = new HashMap();
	dbmsMap.put( SQL_SERVER.toUpperCase(), (DBMSManager) new SQLServerDBMSManager() );
    dbmsMap.put( ORCL_SERVER.toUpperCase(), (DBMSManager) new ORCLDBMSManager() );
    }

    private static DBMSManagerFactory _self = null;
    public static final synchronized DBMSManagerFactory getInstance(){
	if( _self == null ){
	    _self = new DBMSManagerFactory();
	}
	return _self;
    }


    public DBMSManager getDBMSManager( String managerName)
    throws NullPointerException{
	DBMSManager dm = (DBMSManager) dbmsMap.get( managerName.toUpperCase());
	if( dm==null ) {
	    throw new NullPointerException("cannot identify DBMSManager " + managerName);
	}
	return dm;
    }
}
