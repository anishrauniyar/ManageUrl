package scrub.datatype;

/**
 * Exception to be thrown if field type related errors occur.
 */
public class FieldTypeException extends Exception{

    /** default constructor */
    public FieldTypeException(){
	super();
    }
    
    /** constructor
     * @param message error definition or message
     */
    public FieldTypeException( String message ){
	super( message );
    }

    /**
     * @param message error message
     * @param cause throwable objec
     */
    public FieldTypeException( String message, Throwable cause){
	super( message, cause );
    }

    public FieldTypeException( Throwable cause){
	super( cause );
    }
}
