package scrub.datatype;

/**
 * Created by IntelliJ IDEA.
 * User: pshrestha
 * Date: Apr 30, 2007
 * Time: 5:00:42 PM
 * To change this template use File | Settings | File Templates.
 */

/**
 * DBMS Manager specific to SQL Server.
 */
public class ORCLDBMSManager implements DBMSManager{

    /** SQL server supported field types */
    ORCLSupportedFieldTypes ssFieldTypes = null;

    /**
     * constructor
     */
    protected ORCLDBMSManager(){
	ssFieldTypes = new ORCLSupportedFieldTypes();
    }

    /**
     * @returns sqlserver supported field Types
     */
    public DBMSSupportedFieldTypes getDBMSSupportedFieldTypes(){
	return ssFieldTypes;
    }

}

