package scrub.datatype;
/*
 *
 */


/**
 * interface which represents Field Type in any RDBMS
 */
public interface FieldType{

    /*-------------------- CONSTANTS FOR FIELD TYPES --------------------*/
    /** text type */
    public static final int TYPE_TEXT = 0;
    /** numeric type */
    public static final int TYPE_NUMERIC = 1;
    /** date type */
    public static final int TYPE_DATE = 2;
    /** binary type */
    public static final int TYPE_BINARY = 3;
    /** invalid data type */
    public static final int TYPE_INVALID = -1;
    
    /*--------------------                    ---------------------------*/

    /**
     * @returns field name as usually represented by the corresponding DBMS
     */
    String getName();

    /**
     * @returns true if size of field is predefined by the database
     */
    boolean isFixedSize();

    /**
     * @returns true if precision supported
     */
    boolean isPrecisionSupported();

    /**
     * @returns default size as will be assigned by the DBMS if not fixed size
     * else fixed size. -1 in case length is not applicable.
     */
    int getDefaultSize();

    /**
     * @returns true if auto increment applicable for the field type else false
     */
    boolean isAutoIncrementApplicable();

    /**
     * @returns true is sign supported otherwise false
     */
    boolean isSignSupported();

    /**
     * @returns ture if currency else false
     */

    boolean isCurrency();
    /**
     * @returns maximum allowed size for the data type
     */
    int getMaxAllowedSize();


    /**
     * @returns field type value
     */
    int getFieldType();

    /**
     * @returns true if numeric type
     */
    boolean isNumeric();

    /**
     * @returns true if date type
     */
    boolean isDate();
}






