package scrub.datatype;

/**
 * the classes which need to implement FieldType interface will
 * usually do by extending this class so that if a group of classes
 * need to be modified due to interface change, interface compliance can be
 * achieved by modifying this class
 */
public abstract class FieldTypeAdapter implements FieldType{
    
    /** no sign support by default */
    
    private boolean signSupported = false;
    /**
     * Dummy method for ensuring sign support
     * (adapter method for future change)
     * no effect unless subclass overrides the method
     * @param signSupport true for sign support
     */
    protected void setSignSupported( boolean signSupport) {
	signSupported = signSupport;
    }

    /**
     * @returns false no sign support by default
     */
    public boolean isSignSupported(){
	return signSupported;
    }

    /*----------------------------------------------------------------------*/
    
    /** not a currency by default   */
    private boolean currency = false;

    /**
     * set whether its a currency or not
     * @param cur for currency flag setting
     */
    protected void setCurrency( boolean cur){
	currency = cur;
    }

    /**
     * @returns true if currency, false otherwise
     */
    public boolean isCurrency(){
	return currency;
    }    

    /*----------------------------------------------------------------------*/

    /** max. allowed size */
    private int maxAllowedSize = -1;

    /**
     * set max. allowed size
     * @param msize max allowed size > 0
     */
    protected void setMaxAllowedSize( int msize){
	maxAllowedSize = (msize>0)? msize: maxAllowedSize;
    }

    /**
     * @returns max. allowed size for the data type. -1 if not applicable or not set.
     */
    public int getMaxAllowedSize(){
	return maxAllowedSize;
    }    

    /** fieldType value, text by default */
    private int fieldType = TYPE_TEXT;
    
    /**
     * set field type
     * @param ftype field type
     */
    protected void setFieldType( int ftype){
	fieldType = ftype;
    }

    /**
     * @returns field type value
     */
    public int getFieldType(){
	return fieldType;
    }

    /**
     * @returns true if numeric
     */
    public boolean isNumeric(){
	return fieldType == TYPE_NUMERIC;
    }

    /**
     * @returns true if date
     */
    public boolean isDate(){
	return fieldType == TYPE_DATE;
    }
}







