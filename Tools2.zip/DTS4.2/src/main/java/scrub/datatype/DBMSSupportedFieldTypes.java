package scrub.datatype;

import java.util.List;

/**
 * interface for accessing information regarding DBMS specific supported field types
 */
public interface  DBMSSupportedFieldTypes{
    /**
     * @param typeName name of field type e.g. "bigint"
     * @returns true if specified field type name is supporte otherwise false. case sensitive.
     */
    public boolean isSupportedFieldType( String typeName);

    /**
     * @param typeName name of field type
     * @returns FieldType represented by specified typeName
     * @throws NullPointerException if specified typeName is not supported
     */
    public FieldType getFieldTypeByTypeName( String  typeName) throws FieldTypeException;

    /**
     * @returns array containing name of supported field types
     */
    String [] getSupportedFieldTypeNames();
}
