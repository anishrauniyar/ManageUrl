package scrub.datatype;

/**
 * DBMS Manager specific to SQL Server.
 */
public class SQLServerDBMSManager implements DBMSManager{

    /** SQL server supported field types */
    SQLServerSupportedFieldTypes ssFieldTypes = null;
	
    /**
     * constructor
     */
    protected SQLServerDBMSManager(){
	ssFieldTypes = new SQLServerSupportedFieldTypes();
    }

    /**
     * @returns sqlserver supported field Types
     */
    public DBMSSupportedFieldTypes getDBMSSupportedFieldTypes(){
	return ssFieldTypes;
    }

}
