package scrub.datatype;

/**
 * implementation of FieldType
 * all the setter methods are protected.
 */
public class FieldTypeImpl extends FieldTypeAdapter {

    /** name of field type */
    private String name = null;

    /** prevent default constructor */
    private FieldTypeImpl(){}

    /**
     * constructor for FieldTypeImpl
     * @param fldName represents field type name as used by specific DBMS
     */
    protected FieldTypeImpl( String fldName ) throws IllegalArgumentException{
	if ( fldName == null || fldName.trim().equals("") ){
	    throw new IllegalArgumentException( "Blank or null value specified for field type value!!");
	}
	name = fldName;
    }

    /** return type name */
    public String getName(){
	return name;
    }

    /*--------------------------------------------------*/

    /** bigint size is predefined */
    private boolean fixedSize = true;

    /** @returns true */
    public boolean isFixedSize(){
	return fixedSize;
    }

    /** set fixed size */
    protected void setFixedSize( boolean fxSize ){
	fixedSize = fxSize;
    }

    /*--------------------------------------------------*/

    /** precision is predefined, so can't be changed */
    private  boolean precisionSupported = false;

    /** @returns false */
    public boolean isPrecisionSupported(){
	return precisionSupported;
    }

    /** set precision supported */
    protected void setPrecisionSupported( boolean presSupport){
	precisionSupported = presSupport;
    }
    
    /*--------------------------------------------------*/

    /** default size  */
    private int defaultSize = -1;

    /** @returns default size for bigint */
    public int getDefaultSize(){
	return defaultSize;
    }

    /** set defaultSize */
    protected void setDefaultSize( int defSize){
	defaultSize = (defSize>0)? defSize : defaultSize;
    }

    /*--------------------------------------------------*/

    /** auto increment or identity applicability */
    private boolean autoIncrementApplicable = false;

    /** @returns true as identity is supported for bigint */
    public boolean isAutoIncrementApplicable(){
	return autoIncrementApplicable;
    }

    protected void setAutoIncrementApplicable( boolean autoInc){
	autoIncrementApplicable = autoInc;
    }
}
