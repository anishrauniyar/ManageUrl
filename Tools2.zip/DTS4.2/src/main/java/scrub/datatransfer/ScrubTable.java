package scrub.datatransfer;

import java.sql.SQLException;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import scrub.datatype.DBMSSupportedFieldTypes;
import scrub.datatype.FieldTypeException;
import scrub.util.RequestData;

/**
 * represents the tablular data structure
 * requires scrollable cursor for ResultSet
 */
public interface ScrubTable{

    /** default table size */
    int PAGE_SIZE = 100;

    /**
     * represents disconnected with fraction of data only.
     */
    int TABLE_PAGED = 0;

    /**
     * represents disconnected but with all data
     */
    int TABLE_NOT_PAGED = 1;

    /**
     * represents unpaged but live connection to the source during data access
     */
    int TABLE_NOT_PAGED_LIVE = 2;

    /**
     * represents last page
     */
    int PAGE_LAST = -1;
    /** 
     * @param pSize sets pSize if pSize > 0
     */
    void setPageSize( int pSize);
    
    /** @returns page size */
    int getPageSize();

    /** @param currentPage sets the currentPage 0 based */
    void setCurrentPage( int currentPage );

    /** @returns current page represented by the set of contained data */
    int getCurrentPage();

    /** @param ordField order Field name by which the data set is ordered */
    void setOrderField( String ordField);
    /** @returns Order Field  by which the data set is ordered */
    String getOrderField();

    /** @param ord order direction in which the data set is oredered. possible values are "ASC" and "DESC" */
    void setOrder( String ord);
    /** @returns order direction "ASC" if Ascending, "DESC" if descending else null or blank */
    String getOrder();

    /** @param setSize set actual set size of query or table */
    void setSetSize( int setSize);
    /** @returns actual setSize  */
    int getSetSize();

    /** 
    /**
     * initialize the table
     * @param supportedFieldTypes field types supported by the database pointed by the connection
     * @param cnn Connection
     * @param stmt Statement associated with the source
     * @param rs ResultSet accociated with the underlying data.
     * @throws SQLException on problem accessing data
     * @throws scrub.datatype.FieldTypeException if supportedFieldTypes can't map the column type generally by field type
     * name as provided by the database which means the implementation doesn't know about the particular type or
     * wrong supportedFieldTypes has been supplied which does n't know about the type of dbms connection points to.
     * Once connection is assigned to scrub table, it must not be used elsewhere as
     * it would be the responsibility of ScrubTable to close connection and release other resources.
     * ScrubTableNormal, one of the implementation, closes every database resources provided as prameter after executing
     * this method. As the components are technically interchangeable, using this component and the decendents in any
     * transactional processing is dangerous as the components will generally be geared towards readonly access to the
     * data source and may execute in a manner not appropriate for transaction processing.
     */
    public void init( DBMSSupportedFieldTypes supportedFieldTypes, Connection cnn,
	       Statement stmt, ResultSet rs) throws SQLException, FieldTypeException;

    /** moves cursor before the first record of the contained set of records */
    void beforeFirst() throws SQLException;

    /** moves cursor beyond the last  record of the contained set of records */
    void  afterLast() throws SQLException;

    /** @returns true only if cursor is before first record */
    boolean isBeforeFirst() throws SQLException;

    /** @returns true only if cursor is beyond the last record. */
    boolean isAfterLast() throws SQLException;

    /** @returns true if other records are available*/
     boolean hasNext() throws SQLException;

    /**
     * @param sf ScrubRecord in which current record may be stored after cursor moved to next position.
     * implementation may alter sf, the ScrubRecord. Hence, null value should not be passed as  if amount of data to be
     * accessed is going to be huge and live connection is being maintained,
     * then sf may be reinitialized by the implementation
     * @returns ScrubRecord with data stored
     * @throws SQLException if problem accessing the actual datastore.
     * @throws NullPointerException if null data.
     */
    public ScrubRecord next( ScrubRecord sf) throws SQLException, NullPointerException;
    
    /**
     * close release all resources as required.
     */
    public void close()  throws SQLException;

    /** @returns true only if empty */
    public boolean isEmpty()  throws SQLException;

   /**
     * @param fldName field name to check for existence
     * @returns true if fldName exists else false
     */
    boolean containsField( String fldName);

    /**
     * @param fldName field name for which index is to be found
     * @returns index of fldName
     * @throws NoSuchFieldException if specified field name does not exist
     */
    int getIndex( String fldName) throws NoSuchFieldException;

    /**
     * @returns array of fields in the table in the form of ScrubFields if properly initialized
     */
    ScrubField [] getScrubFields();


}











































