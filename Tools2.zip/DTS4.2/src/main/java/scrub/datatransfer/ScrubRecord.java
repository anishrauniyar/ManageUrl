package scrub.datatransfer;

/**
 * Represents records in scrub datbase tables.
 * (snapshot only)
 */
public class ScrubRecord{

    /**
     * Scrub field values in the specified records
     */
    protected String [] scrubValues = null;

    /**
     * references the table source
     */
    private ScrubTable scrubTable = null;
    
    /** constructor default */
    public ScrubRecord(){   }

    /** constructor
     * @param scTable ScrubTable to which this ScrubRecord belongs to.
     * @param scFValues array of scrub field values.
     */
    public ScrubRecord( ScrubTable scTable,String [] scFValues ){
	scrubTable = scTable;
	scrubValues = scFValues;
    }

    /** initializer: sets ScrubTable and ScrubFields 
     * @param scTable ScrubTable to which this ScrubRecord belongs to.
     * @param scFValues array of scrub field values.
     */
    public void init( ScrubTable scTable,String [] scFValues ){
	this.scrubTable = scTable;
	this.scrubValues = scFValues;
    }


    /**
     * @returns scrubTable
     */
    public ScrubTable getScrubTable(){
	return scrubTable;
    }

    /** get scrub fields by index
     * @param index index of field 0 base
     * @returns ScrubField at specified index
     * @throws IndexOutOfBoundsException
     */
    public String getValue( int index) throws IndexOutOfBoundsException, NoSuchFieldException{
        if (scrubValues[index] == null){
            return "";
        }
        return scrubValues[ index ];
    }

    /** get scrub field by name
     * @param fldName fieldName
     * @returns ScrubField identified by the given fldName
     * @throws NoSuchFieldException
     */
    public String getValue( String fldName ) throws NoSuchFieldException {
	return getValue( scrubTable.getIndex( fldName ) );
    }
}
