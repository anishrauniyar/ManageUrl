package scrub.datatransfer;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * sets scrub field states for nullable and auto increment
 */
public class ScrubSetter{

    /**
     * @param sf ScrubField whose parameters are to be set
     * @param rsmd ResultSetMetaData from which property values are known
     * @param index specify the column of rsmd
     * @throws SQLException on problme accessing the database
     */
    public static void setScrubField( ScrubField sf, ResultSetMetaData rsmd, int index)
	throws SQLException{
	sf.setAutoIncrement( rsmd.isAutoIncrement( index) );
	sf.setNullable( rsmd.columnNullable==rsmd.isNullable( index)  );
	sf.setDisplaySize( rsmd.getColumnDisplaySize( index) );
    }

}
