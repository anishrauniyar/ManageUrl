package scrub.datatransfer;

import scrub.datatype.FieldType;

/**
 * represents field properties present in tabular data
 */
public class ScrubField{

    /** field name */
    protected String fieldName;

    /** field type */
    protected FieldType fieldType;
    
    /** constructor */
    private ScrubField(){}

    /** constructor */
    public ScrubField( String fName, FieldType fType) {
	this.fieldName = fName;
	this.fieldType = fType;
    }

    /** @returns field name */
    public String getFieldName(){
	return fieldName;
    }

    /** @returns field type */
    public FieldType getFieldType(){
	return fieldType;
    }
    boolean isAutoIncrement=false;

    /** @returns true if auto increment */
    public boolean isAutoIncrement(){
	return isAutoIncrement;
    }

    /** @param autoIncr sets isAutoIncrement */
    public void setAutoIncrement( boolean autoIncr){
	isAutoIncrement = autoIncr;
    }

    boolean nullable = false;
    /** @returns true if nullable */
    public boolean isNullable(){
	return nullable;
    }
    /** set nullable */
    public void setNullable( boolean nb){
	nullable = nb;
    }

    /** @returns true if numeric */
    public boolean isNumeric(){
	return fieldType.isNumeric();
    }

    /** @returns true if date */
    public boolean isDate(){
	return fieldType.getFieldType()==FieldType.TYPE_DATE;
    }
    /** display size in no. of characters */
    int displaySize = 10;

    /**
     * @param s display size to set , accepted only if >0
     */
    public void setDisplaySize( int s){
	if( s>0){
	    displaySize = s;
	}
    }
    /**
     * @returns displaySize
     */
    public int getDisplaySize(){
	return displaySize;
    }

}
