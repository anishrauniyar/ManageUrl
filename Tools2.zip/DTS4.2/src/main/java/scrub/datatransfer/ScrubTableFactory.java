package scrub.datatransfer;

import java.util.HashMap;

/**
 * responsible for creating ScrubTable of appropriate type and/or setting
 */
public class ScrubTableFactory{

    private static ScrubTableFactory _self = null;
    /**
     * block default constructor
     */
    private ScrubTableFactory(){
    }
    /**
     * singleton method
     */
    public static final synchronized ScrubTableFactory getInstance(){
	if( _self == null ){
	    _self = new ScrubTableFactory();
	}
	return _self;
    }
    /**
     * @param tableType specifies the type of ScrubTable
     * @returns ScrubTable of specified type if possible else paged scrub table is returned.
     */
    public ScrubTable getScrubTable( int tableType ){
	ScrubTable st ;
	switch( tableType ){
	case ScrubTable.TABLE_NOT_PAGED :
	case ScrubTable.TABLE_NOT_PAGED_LIVE :
	    st = new ScrubTableAll();
	    break;
	case ScrubTable.TABLE_PAGED :

	default :
	    st = new ScrubTableNormal();
	    st.setPageSize( ScrubTable.PAGE_SIZE);
	}
	return st;
    }

    /**
     * @param tableType type of the ScrubTable
     * @param pageSize no. of max. records possible in the specified table
     * implementation of ScrubTable may ignore pageSize
     */
    public ScrubTable getScrubTable( int tableType, int pageSize ){
	ScrubTable sc = getScrubTable( tableType );
	sc.setPageSize( pageSize );
	return sc;
    }
}
