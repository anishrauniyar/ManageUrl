package scrub.datatransfer;

import java.util.Map;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import scrub.datatype.DBMSSupportedFieldTypes;
import scrub.datatype.FieldTypeException;
import scrub.util.RequestData;

/**
 * implementation of ScrubTable
 * pulls the data and release database resources
 */
public class ScrubTableAll extends ScrubTableRoot{
    private Connection cnn = null;
    private Statement stmt = null;
    private ResultSet rs = null;
    private DBMSSupportedFieldTypes supportedFieldTypes = null;
    private HashMap map = null;
    
    private ScrubField [] scrubFields = null;
    private String [] fieldNames = null;

    public ScrubTableAll(){
	super();
    }
	
    /** @param pSize ignore     */
    public void setPageSize( int pSize){    }
    /** @returns page size */
    public int getPageSize(){
	return  -1;
    }
    
    private static final int CURRENT_PG = 0;
    /** @param curPage ignore */
    public void setCurrentPage( int curPage ){    }
    /** @returns current page represented by the set of contained data */
    public int getCurrentPage(){
	return CURRENT_PG;
    }

    /**
     * initialize the table
     * @param supportedFTypes field types supported by the database pointed by the connection
     * @param cn Connection
     * @param st Statement associated with the source
     * @param rst ResultSet accociated with the underlying data.
     * @throws SQLException on problem accessing data
     * Once connection is assigned to scrub table, it must not be used elsewhere as
     * it would be the responsibility of ScrubTable to close connection and release other resources.
     * This implementation closes every resources related to the dbms once data has been accessed.
     * If used in the middle of atomic transaction and the same connection as used for the transaction is used,
     * the transaction is guranteed to fail!!!! (Beware).
     */
    public void init( DBMSSupportedFieldTypes supportedFTypes, Connection cn,
		      Statement st, ResultSet rst) throws SQLException, FieldTypeException{
	supportedFieldTypes = supportedFTypes;
	cnn = cn;
	stmt = st;
	rs = rst;
	ResultSetMetaData rsmd = rs.getMetaData();
	rs.beforeFirst();
	int fieldCount = 0;

	fieldCount = rsmd.getColumnCount();
	map = new HashMap( fieldCount );
	scrubFields = new ScrubField[ fieldCount ];
	fieldNames = new String[ fieldCount ];

	int fldNdx;
	/** initialize  field related metat data */
	int fldNdx1 = 0;
	for( fldNdx=0; fldNdx<fieldCount; fldNdx++ ){
	    fldNdx1 = fldNdx + 1;
	    fieldNames[ fldNdx ] = rsmd.getColumnName( fldNdx1 );
	    scrubFields[ fldNdx ]
		= new ScrubField( fieldNames[ fldNdx ],
				  supportedFieldTypes.getFieldTypeByTypeName( rsmd.getColumnTypeName( fldNdx1 ) )
				  );
	    ScrubSetter.setScrubField( scrubFields[ fldNdx], rsmd, (fldNdx1) );
	    map.put( fieldNames[ fldNdx ], new Integer( fldNdx  ) );
	}
	
    }

    /** moves cursor before the first record of the contained set of records */
    public void beforeFirst() throws SQLException{
	rs.beforeFirst();
    }

    /** moves cursor beyond the last  record of the contained set of records */
    public void  afterLast() throws SQLException{
	rs.afterLast();
    }

    /** @returns true only if cursor is before first record */
    public boolean isBeforeFirst() throws SQLException{
	return rs.isBeforeFirst();
    }

    /** @returns true only if cursor is beyond the last record. */
    public boolean isAfterLast() throws SQLException{
	return rs.isAfterLast();
    }

    /** @returns true if other records are available*/
    public boolean hasNext() throws SQLException{
	return !rs.isLast() && ( rs.getRow() != 0 
		|| rs.isBeforeFirst());
    }
    int cnt = 0;
    /**
     * moves the cursor to next record and fetch the record if available.
     * @param sf ScrubRecord in which current record will be stored and cursor will be moved to next position.
     * @returns ScrubRecord with data stored
     * @throws SQLException if problem accessing the actual datastore.
     * @throws NullPointerException if null data
     */
    public ScrubRecord next( ScrubRecord sr) throws SQLException, NullPointerException{
	if( rs.next() ){
	    String [] fValues = new String[ scrubFields.length ];
	    for( cnt=0; cnt<scrubFields.length; cnt++){
		fValues[ cnt ] = rs.getString( cnt + 1 );
	    }
	    sr.init( this, fValues);
	}else{
	    throw new NullPointerException("No valid data at the current position");
	}
	return sr;
    }
    
    /**
     * close release all resources as required.
     */
    public void close()  throws SQLException{
	if (rs != null ) try{ rs.close(); }catch( Exception rsEx){ rs = null ;}
	if( stmt != null)try{ stmt.close(); }catch( Exception stmtEx){ stmt = null ;}
	if( cnn != null) try{ cnn.close(); }catch( Exception cnnEx){ cnn = null ;}
    }

    /** @returns true only if empty */
    public boolean isEmpty()  throws SQLException{
	return !rs.isBeforeFirst() && !rs.isAfterLast() 
		&& rs.getRow() == 0;
    }

   /**
     * @param fldName field name to check for existence
     * @returns true if fldName exists else false
     */
    public boolean containsField( String fldName){
	return map.containsKey( fldName );
    }

    /**
     * @param fldName field name for which index is to be found
     * @returns index of fldName
     * @throws NoSuchFieldException if specified field name does not exist
     */
    public int getIndex( String fldName) throws NoSuchFieldException{
	int ndx = -1;
	try{
	    ndx = ((Integer) map.get( fldName )).intValue();
	}catch(Exception anyEx){
	    throw new NoSuchFieldException("" + fldName + " not found.");
	}
	return ndx;
    }


    /**
     * @returns array of fields in the table in the form of ScrubFields if properly initialized
     */
    public ScrubField [] getScrubFields(){
	return scrubFields;
    }

    
}









