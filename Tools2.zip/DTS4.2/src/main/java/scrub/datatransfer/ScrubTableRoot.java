package scrub.datatransfer;

import scrub.util.RequestData;


abstract class ScrubTableRoot implements ScrubTable{

    private String  orderField = "";
    /** @param ordField order Field name by which the data set is ordered */
    public void setOrderField( String ordField){
	if( ordField!= null ){
	    orderField = ordField;
	}
    }
    /** @returns Order Field  by which the data set is ordered */
    public String getOrderField(){
	return orderField;
    }
    /*--------------------------------------------------*/

    private String order = "";
    /** @param ord order direction in which the data set is oredered. possible values are "ASC" and "DESC" */
    public void setOrder( String ord){
	if( ord!=null && ( "ASC".equalsIgnoreCase( ord) || "DESC".equalsIgnoreCase( ord) ) ){
	    order = ord;
	}
    }
    /** @returns order direction "ASC" if Ascending, "DESC" if descending else null or blank */
    public String getOrder(){
	return order;
    }
    /*--------------------------------------------------*/

    private int setSize=0;
    /** @param setsize set actual set size of query or table */
    public void setSetSize( int setsize){
	if( setSize > - 1) {
	    setSize = setsize;
	}
    }
    /** @returns actual setSize  */
    public int getSetSize(){
	return setSize;
    }

    
    

}

