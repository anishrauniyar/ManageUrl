package scrub.datatransfer;

import java.util.ArrayList;
import java.util.HashMap;
import scrub.util.text.KeyString;
/**
 * represents name value pair
 * not thread safe.
 */
public class Record{
    protected ArrayList fldList = null;
    protected HashMap map = null;
    protected static final int SIZE = 5;
    /**
     * constructor
     */
    public Record(){
	fldList = new ArrayList( SIZE );
	map = new HashMap( SIZE );
    }

    /** copy constructor*/
    public Record( Record rec){
	this();
	if( rec !=null){
	    fldList.addAll( rec.fldList );
	    map.putAll( rec.map );
	}
    }
    /** add name value pair */
    public void put( String fieldName, String fieldValue ){
	if( fieldName != null ){
	    KeyString fn = new KeyString( fieldName);
	    if( !containsField( fn ) ){
		fldList.add( fn );
	    }
	    if( fieldValue != null ){
		map.put( fn, fieldValue );
	    }else{
		map.remove( fn );
	    }
	}
    }

    /**
     * @param fieldName name of the field of which the value is to be found
     * @returns value for fieldName
     */       
    public String get( String fieldName ){
	if( fieldName == null ) return null;
	KeyString fn = new KeyString( fieldName);
	if( containsField( fn ) ){
	    return (String) map.get( fn );
	}
	return null;
    }
    /**
     * @param fieldName field name to check for existence
     * @returns true only if fieldName exists
     */
    public boolean containsField( String fieldName ){
	if( fieldName==null) return false;
	return containsField( new KeyString( fieldName) );
    }
    /**
     * @parma fieldName of KeyString type
     * @returns true if exists
     */
    private boolean containsField( KeyString fieldName){
	return fldList.contains( fieldName);
    }
    /**
     * @param fieldName name of the field to remove.
     */
    public void remove( String fieldName ){
	if( fieldName==null) return;
	KeyString fn = new KeyString(fieldName);
	fldList.remove( fn );
	map.remove( fn );
    }

    /**
     * @returns String array containing all the field names.
     */
    public String [] getFieldNames(){
	String [] fieldNames = new String[ fldList.size() ];
	int len= fldList.size();
	for( int i=0; i<len; i++ ){
	    fieldNames[i] = ((KeyString) fldList.get(i)).getActualKey();
	}
	return  fieldNames;
    }
    /** string representation */
    public String toString(){
	StringBuffer sb = new StringBuffer();
	String flName = null;
	String flValue = null;
	for( int i=0; i<fldList.size(); i++){
	    flName = (( KeyString ) fldList.get( i ) ).getActualKey();
	    flValue = get( flName );
	    sb.append( flName );
	    sb.append( "=");
	    if( flValue!=null ) sb.append(flValue);
	    sb.append(";");
	}
	return sb.toString();
    }
    /** @returns size of the record*/
    public int size(){
	return fldList.size();
    }
    /*
     * Tested OK *----------*
     */

    /** @returns true if empty */
    public boolean isEmpty(){
	return fldList==null || fldList.isEmpty();
    }
    
    public static void main( String [] args ){
	String [] fl = null;
	Record rec = new Record();
	rec.put("a", "v a");
	rec.put("b", "v b");
	fl = rec.getFieldNames();
	for(int i=0; i<fl.length; i++){
	    System.out.println( fl[i] + "\t" + rec.get( fl[i] ) );
	}
	rec.put("c", null );
	fl = rec.getFieldNames();
	System.out.println("\ta----------");
	for(int i=0; i<fl.length; i++){
	    System.out.println( fl[i] + "\t" + rec.get( fl[i] ) );
	}

	rec.remove("a" );
	fl = rec.getFieldNames();
	System.out.println("\tb----------");
	for(int i=0; i<fl.length; i++){
	    System.out.println( fl[i] + "\t" + rec.get( fl[i] ) );
	}
	rec.remove( null );
	fl = rec.getFieldNames();
	System.out.println("\tc----------" + rec.toString() );
	for(int i=0; i<fl.length; i++){
	    System.out.println( fl[i] + "\t" + rec.get( fl[i] ) );
	}
    }

}
