package scrub.datatransfer;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import scrub.datatype.DBMSSupportedFieldTypes;
import scrub.datatype.FieldTypeException;

/**
 * implementation of ScrubTable
 * pulls the data and release database resources
 */
public class ScrubTableNormal extends ScrubTableRoot{
     
    private int pageSize = PAGE_SIZE;
    private ArrayList ls = null;
    private int cursor = -1;
    private HashMap map = null;
    
    private ScrubField [] scrubFields = null;
    private String [] fieldNames = null;
    
    public ScrubTableNormal(){
	ls = new ArrayList( pageSize );
    }
	
    /** 
     * @param pSize sets pSize if pSize > 0
     */
    public void setPageSize( int pSize){
	if( pSize > 0 ){
	    pageSize = pSize;
	    ls.ensureCapacity( pSize );
	}
    }

    /** @returns page size */
    public int getPageSize(){
	return  pageSize;
    }
    
    private int currentPage = 0;
    /** @param curPage sets the currentPage 0 based */
    public void setCurrentPage( int curPage ){
	currentPage = (curPage>-1)?curPage : currentPage;
	if( curPage== ScrubTable.PAGE_LAST)
	    currentPage = curPage;
    }

    /** @returns current page represented by the set of contained data */
    public int getCurrentPage(){
	return currentPage;
    }

    /**
     * initialize the table
     * @param supportedFieldTypes field types supported by the database pointed by the connection
     * @param cnn Connection
     * @param stmt Statement associated with the source
     * @param rs ResultSet accociated with the underlying data.
     * @throws SQLException on problem accessing data
     * Once connection is assigned to scrub table, it must not be used elsewhere as
     * it would be the responsibility of ScrubTable to close connection and release other resources.
     * This implementation closes every resources related to the dbms once data has been accessed.
     * If used in the middle of atomic transaction and the same connection as used for the transaction is used,
     * the transaction is guranteed to fail!!!! (Beware).
     */
    public void init( DBMSSupportedFieldTypes supportedFieldTypes, Connection cnn,
		      Statement stmt, ResultSet rs) throws SQLException, FieldTypeException{
	ls.clear();
	beforeFirst();
	try{
	    /* initialize the cursor position base on current page and page size */
	    int pos = this.getCurrentPage() * this.getPageSize();

	    if( pos <= 1 ){
		if( this.getSetSize() > 0 && this.getCurrentPage() == ScrubTable.PAGE_LAST && this.getPageSize() > 0 ){
		    // move to the last page
		    int pageCount = (int) Math.floor ( this.getSetSize() / this.getPageSize()  );

		    if( pageCount<0) pageCount=0;
		    pos = pageCount * this.getPageSize();
		    this.setCurrentPage( pageCount);		    
		    if( pos>0){
			rs.absolute( pos);
		    }else{
			rs.beforeFirst();
		    }
		    //System.out.println( "PageCoutn:"+pageCount );
		    //System.out.println( "Setsize:"+this.getSetSize() );
		    //System.out.println( "Pos : "+pos);
		}else{
		    rs.beforeFirst();
		}
	    }else{
		rs.absolute( pos );
	    }
	    if( rs.isAfterLast() ) {
		rs.beforeFirst();
		this.setCurrentPage( 0) ;
	    }
	    ls.clear();
	    ScrubRecord rec = null;
	    ResultSetMetaData rsmd = rs.getMetaData();
	    int fieldCount = 0;
	    fieldCount = rsmd.getColumnCount();
	    map = new HashMap( fieldCount );
	    scrubFields = new ScrubField[ fieldCount ];
	    fieldNames = new String[ fieldCount ];

	    int fldNdx;
	    /** initialize  field related metat data */
	    int fldNdx1 = 0;
	    for( fldNdx=0; fldNdx<fieldCount; fldNdx++ ){
		fldNdx1 = fldNdx + 1;
		fieldNames[ fldNdx ] = rsmd.getColumnName( fldNdx1 );
		scrubFields[ fldNdx ]
		    = new ScrubField( fieldNames[ fldNdx ],
				      supportedFieldTypes.getFieldTypeByTypeName( rsmd.getColumnTypeName( fldNdx1 ) )
				      );
		ScrubSetter.setScrubField( scrubFields[ fldNdx], rsmd, (fldNdx1) );
		map.put( fieldNames[ fldNdx ], new Integer( fldNdx  ) );
	    }
	    /** load the data */
	    int recCount = 0;
	    while( rs.next() && (recCount<pageSize ) ){
		String [] fValues = new String[ fieldCount ];
		for( fldNdx=0; fldNdx<fieldCount; fldNdx++ ){
		    fValues[ fldNdx ] = rs.getString( fldNdx + 1 );
		}
		rec = new ScrubRecord( this, fValues );
		ls.add( rec );
		recCount++;
	    }
	}finally{
	    try{ rs.close();}catch(Exception ers){ rs = null;}
	    try{ stmt.close();}catch(Exception estmt){ stmt = null;}
	    try{ cnn.close();}catch(Exception cstmt){ stmt = null;}
	}
    }

    /** moves cursor before the first record of the contained set of records */
    public void beforeFirst(){
	cursor = -1;
    }

    /** moves cursor beyond the last  record of the contained set of records */
    public void  afterLast(){
	cursor = ls.size();
    }

    /** @returns true only if cursor is before first record */
    public boolean isBeforeFirst(){
	return cursor == -1;
    }

    /** @returns true only if cursor is beyond the last record. */
    public boolean isAfterLast(){
	return cursor >= ls.size();
    }

    /** @returns true if other records are available*/
    public boolean hasNext(){
	return cursor+1 < ls.size();
    }

    /**
     * moves the cursor to next record and fetch the record if available.
     * @param sf ScrubRecord in which current record will be stored and cursor will be moved to next position.
     * @returns ScrubRecord with data stored
     * @throws SQLException if problem accessing the actual datastore.
     * @throws NullPointerException if null data
     */
    public ScrubRecord next( ScrubRecord sf) throws SQLException, NullPointerException{
	ScrubRecord sr = null;
	cursor++;
	if( !ls.isEmpty() && cursor < ls.size()  ){
	    sr = ( ScrubRecord) ls.get( cursor);
	}
	if( sr == null )
	    throw new NullPointerException("No valid data at the current position");
	return sr;
    }
    
    /**
     * close release all resources as required.
     */
    public void close()  throws SQLException{
    }

    /** @returns true only if empty */
    public boolean isEmpty()  throws SQLException{
	return ls.isEmpty();
    }

   /**
     * @param fldName field name to check for existence
     * @returns true if fldName exists else false
     */
    public boolean containsField( String fldName){
	return map.containsKey( fldName );
    }

    /**
     * @param fldName field name for which index is to be found
     * @returns index of fldName
     * @throws NoSuchFieldException if specified field name does not exist
     */
    public int getIndex( String fldName) throws NoSuchFieldException{
	int ndx = -1;
	try{
	    ndx = ((Integer) map.get( fldName )).intValue();
	}catch(Exception anyEx){
	    throw new NoSuchFieldException("" + fldName + " not found.");
	}
	return ndx;
    }


    /**
     * @returns array of fields in the table in the form of ScrubFields if properly initialized
     */
    public ScrubField [] getScrubFields(){
	return scrubFields;
    }

}





