package scrub.exception;

/**
 * represents the root class for scrub or dsm rules violation
 * overwrites the method in Exception
 * helps to identify exception in dsm rule violation from other exceptions.
 * compatible with 1.4 Java API
 */
public class ScrubException extends Exception{
    
    public ScrubException( String msg){
	super( msg);
    }

    /**
     * supported only in 1.4
     */
    public ScrubException( Throwable t){
	super( t);
    }

    /**
     * supported only in 1.4
     */
    public ScrubException( String msg, Throwable t){
	super( msg, t);
    }

}
