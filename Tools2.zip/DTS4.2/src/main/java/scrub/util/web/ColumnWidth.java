package scrub.util.web;


import scrub.datatransfer.ScrubField;

/**
 * calculates with for scrub fields
 */


public class ColumnWidth{

    public ColumnWidth(){}
    private static int DATE_PAD = 13;//5;
    private static int MAX_SIZE = 15;
    /**
     * @param sf ScrubField for which to get the width
     * @returns calculated display size for scrub field. adds DATE_PAD for date type
     */
    public int getFieldSize( ScrubField sf) throws NullPointerException{
	if( sf == null ) throw new NullPointerException( "Null scrub field not allowed."); 
	int dispSize = sf.getDisplaySize();
	if( sf.isDate() ) dispSize += DATE_PAD;
	return dispSize;
    }

    /**
     * @param sf ScrubField for which to calculate display size
     * @returns calculated max. size for text
     */
    public int getDisplaySize( ScrubField sf) throws NullPointerException{
	if( sf == null ) throw new NullPointerException( "Null scrub field not allowed.");
	int dispSize = sf.getDisplaySize();
	if( dispSize > MAX_SIZE) dispSize = MAX_SIZE;
	return dispSize;
    }

}
 
