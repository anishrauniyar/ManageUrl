package scrub.util.web;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Helps in forwarding control to jsp pages or servlets.
 */

public class DispatchHelper{

    /**
     * forward to the specified page
     */
    public static void forward( HttpServletRequest request, HttpServletResponse response, String url )
	throws Exception{
	RequestDispatcher rd = request.getRequestDispatcher( url );
	rd.forward( request, response );
    }
}
