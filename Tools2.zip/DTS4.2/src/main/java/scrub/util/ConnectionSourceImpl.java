package scrub.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.d2.sql.D2ConnectionPoolFactory;
import com.d2.sql.D2ConnectionPool;

/**
 * implementation of ConnectionSource
 * provides connection base on alias
 */
public class ConnectionSourceImpl implements ConnectionSource{

    static D2ConnectionPoolFactory f = D2ConnectionPoolFactory.getInstance();
    /** restric default constructor from other packages */
    protected ConnectionSourceImpl(){
    }
    /**
     * @param alias refers logically to the DBMS
     * @returns Connection connected to the specified DBMS
     * @throws Exception if fails to provide the connection due to connection problem
     * or undefined alias
     */
    public Connection getConnection( String alias ) throws Exception{
	Connection cnn = null;
	D2ConnectionPool pool = f.getConnectionPool( alias);
	if( pool == null ){
	    throw new IllegalArgumentException( "Unable to resolve connection for " + alias );
	}
	return pool.getConnection();
    }
}
