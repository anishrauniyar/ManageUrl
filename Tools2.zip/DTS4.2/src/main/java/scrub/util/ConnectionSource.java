package scrub.util;

import java.sql.Connection;

/**
 * defines interface for obtaining database based on alias
 */

public interface ConnectionSource{
    /**
     * @param alias refers logically to the DBMS
     * @returns Connection connected to the specified DBMS
     * @throws Exception if fails to provide the connection due to connection problem
     * or undefined alias
     */
    Connection getConnection( String alias ) throws Exception;
}
