package scrub.util.text;

import java.util.HashMap;
import scrub.datatype.FieldType;

/**
 * Maps type constant in scrub.datatype.FieldType constants to those defined for Parser
 */
public class FieldTypeMap{
    protected static HashMap map = new HashMap();
    static{
	map.put( new Integer( FieldType.TYPE_NUMERIC ),
		 new Integer( Parser.TYPE_NUMERIC ) );
	map.put( new Integer( FieldType.TYPE_TEXT ),
		 new Integer( Parser.TYPE_TEXT ) );
	map.put( new Integer( FieldType.TYPE_DATE ),
		 new Integer( Parser.TYPE_DATE ) );
	map.put( new Integer( FieldType.TYPE_INVALID ),
		 new Integer( Parser.TYPE_INVALID ) );
    }
    /**
     * base on fieldType value as defined in scrub.datatype.FieldType
     * corresponding value as defined in Parser is returned
     * @param fieldType integer value defining data type as defined in scrub.datatype.FieldType
     * @returns corresponding value as defined in Parser,
     *		if fieldType is undefined, returns Parser.TYPE_INVALID
     */
    public static int getParserType( int fieldType ){
	Integer ft = new Integer( fieldType );
	Integer parserType = null;
	parserType = (Integer) map.get( ft );
	return (parserType == null )? Parser.TYPE_INVALID : parserType.intValue();
    }
}
