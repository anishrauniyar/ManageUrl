package scrub.util.text;

/**
 * Case insensitive string representation
 */
public class KeyString{
    String actualKey = "";
    String key = "";
    /**
     * constructor
     * @param key String to be represented
     */
    public KeyString( String key){
	if( key != null ){
	    actualKey = key.trim();
	    this.key = actualKey.toUpperCase();
	}
    }
    /**
     * @returns actual value
     */
    public String getActualKey(){
	return actualKey;
    }

    /** overwriting equals */
    public boolean equals( Object obj){
	if( obj instanceof KeyString
	    && this.key.equalsIgnoreCase( ((KeyString) obj).getActualKey()) ){
	    return true;
	}
	return false;
    }

    /** overwriting hashCode */
    public int hashCode(){
	return key.hashCode();
    }
    /** get actual string value if not null on toString */
    public String toString(){
	return actualKey;
    }
}
