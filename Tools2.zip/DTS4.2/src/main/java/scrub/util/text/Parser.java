package scrub.util.text;

/**
 * defines interface for parsing as will be required for generating clause for queries
 */
public interface Parser{

    /** text type */
    public static final int TYPE_TEXT = 0;

    /** numeric type */
    public static final int TYPE_NUMERIC = 1;

    /** date type */
    public static final int TYPE_DATE = 2;

    /** invalid type */
    public static final int TYPE_INVALID = -1;
    
    /**
     * @param alias alias to use in formula being gernerated
     * @param sToParse string to parse
     * @return string transormed with alias used, should be string of zero
     * length if process fails
     */
    String parse( String alias, String sToParse );
}
