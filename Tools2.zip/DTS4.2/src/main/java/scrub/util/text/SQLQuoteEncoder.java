package scrub.util.text;
/**
 * converts single quote into two single quotes
 */
public class SQLQuoteEncoder{
    /** encode single with two single quotes
     * @param param string to encode
     * @returns encoded string or blank string if param is null
     */
    public static String encode( String param ){
	if( param == null ) return null;
	StringBuffer sb = new StringBuffer( param.length() * 2 );
	int i = 0;
	int len = param.length();
	char c;
	for( ; i<len; i++ ){
	    c = param.charAt( i );
	    if( c == '\'' )
		sb.append( "\'\'");
	    else
		sb.append( c);
	}
	return sb.toString();
    }
}

