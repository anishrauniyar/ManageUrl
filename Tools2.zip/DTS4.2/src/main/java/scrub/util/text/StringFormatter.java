package scrub.util.text;

/**
 * Created by IntelliJ IDEA.
 * User: pshrestha
 * Date: May 1, 2007
 * Time: 9:49:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class StringFormatter {
    public static String getDate(String str){
        String formattedString = str;
        if(! (str==null || str.equals("")) && str.indexOf(" ")>0){
             String splittedString[] = str.split(" ");
             formattedString = splittedString[0];
        }
        return formattedString;
    }
}
