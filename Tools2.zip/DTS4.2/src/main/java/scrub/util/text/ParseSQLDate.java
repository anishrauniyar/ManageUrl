package scrub.util.text;

/**
 * Prarse param as date operation in SQL
 */
public class ParseSQLDate implements Parser{
    
    /**	Patterns
     *	 1. operator expression  operators->  not,<>,!=,<=,>=,,<,=,>
     *	 2. like	(Text only)
     *	 3. between exp and exp	 
     *	 4. exp - exp 
     *   5. single expression	 
     */

    public ParseSQLDate(){}

    public String parse( String fldAlias, String strToParse){
	return translate( strToParse, fldAlias);
    }

    public static String translate( String strToParse, String strSQLField){
	    String strP = strToParse.trim();		
	    if(strP.equals(""))return "";		
	    String retString = "";
	    int strLen = strP.length();
	    String strPLower = strP.toLowerCase();
	    //not like
	    if ( "not like ".regionMatches(0, strPLower,0,9) && strLen > 9){
		    strP = strP.substring(9);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField 
			    + " not like \'" 
			    + EncodeSQLCharacterMatch.encode( retString) + "%\' ";		
	    }//not exp
	    else if ( "not ".regionMatches(0, strPLower ,0,4) && strLen > 4){
		    strP = strP.substring(4);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " <> \'" + retString + "\' ";
	    }//<> exp
	    else if ( "<>".regionMatches(0, strP,0,2) && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " <> \'" + retString + "\' ";		
	    }//!= exp
	    else if ( "!=".regionMatches(0, strP,0,2) && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " <> \'" + retString + "\' ";		
	    }//<= exp
	    else if ( "<=".regionMatches(0, strP,0,2) && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " <= \'" + retString + "\' ";			
	    }//>= exp
	    else if ( ">=".regionMatches(0,strP,0,2) && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " >= \'" + retString + "\' ";			
	    }//< exp
	    else if (  ">".regionMatches(0, strP,0,1) && strLen > 1){
		    strP = strP.substring(1);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " > \'" + retString + "\' ";			
	    }//= exp
	    else if ( "=".regionMatches(0, strP,0,1) & strLen > 1){
		    strP = strP.substring(1);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " = \'" + retString + "\' ";			
	    }//> exp
	    else if ( "<".regionMatches(0, strP,0,1) & strLen > 1){
		    strP = strP.substring(1);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField + " < \'" + retString + "\' ";			
	    }//like exp 
	    else if ( "like ".regionMatches(0, strPLower,0,5) && strLen > 5){
		    strP = strP.substring(5);
		    retString = EndQuoteRemover.remove( strP);
		    retString =  " " + strSQLField 
			    + " like \'" 
			    + EncodeSQLCharacterMatch.encode( retString) + "%\' ";		
	    }//between exp and exp
	    else if ( "between ".regionMatches(0, strPLower,0,8)  && strLen > 14
		    && " and ".regionMatches(0, strPLower ,strPLower.indexOf(" and "),5) ){
		    int andPos = strPLower.indexOf(" and ",9);
		    String firstParam = strP.substring(8,andPos);

		    if( andPos > 8 && (andPos + 5) < strLen){
			    String secondParam = strP.substring(andPos+5);
		    retString = strSQLField + " between '" 
			    + EndQuoteRemover.remove(strP.substring(8,andPos) )+ "' and "
			    + " '" + EndQuoteRemover.remove( strP.substring(andPos+5) )+ "' ";
		    }		
	    }else{
		retString = EndQuoteRemover.remove( strP);
		if( !"".equals( retString.trim() ) ){
		    retString =  " " + strSQLField + " = \'" + retString + "\' ";
		}
	    }

	    return retString;	
    }

    public static void main( String	args[]){
	Parser p = new ParseSQLDate();
	String str = "< alsdflkasd";
	System.out.println(str);
	System.out.println("-->"+p.parse( str, "<[]>"));
	str = ">=ooo0u";
	System.out.println(str);
	System.out.println("-->"+p.parse( str, "<[]>"));
	str = ">=ooo0u<";
	System.out.println(str);
	System.out.println("-->"+p.parse( str, "<[]>"));
	str = "like ooo0u";
	System.out.println(str);
	System.out.println("-->"+p.parse( str, "<[]>"));
	str = "2w3raq-ooo0u";
	System.out.println(str);
	System.out.println("-->"+p.parse( str, "<[]>"));
	str = "between one and 3";
	System.out.println(str);
	System.out.println("-->"+p.parse( str, "<[]>"));
	System.out.println("-->"+"between ".regionMatches(0,str,0,8));
	System.out.println(str);
	System.out.println("-->"+str.indexOf("and"));
	System.out.println("-->"+" and ".regionMatches(0,str,str.indexOf("xand "),5));
    }

}
