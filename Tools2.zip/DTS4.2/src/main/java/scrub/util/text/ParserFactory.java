package scrub.util.text;

/**
 * defines interface for accessing ParserFactory
 */
public interface ParserFactory{

    /**
     * provides parser based on type
     * @param type type of parser (numeric Parser.TYPE_NUMERIC, text Parser.TYPE_TEXT
     * or date Parser.TYPE_DATE )
     * @returns parser. if type is not understood, text type will be returned
     */
    public Parser getParser( int type);
}
