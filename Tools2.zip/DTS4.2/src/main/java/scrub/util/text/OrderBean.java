package scrub.util.text;

/**
 * represents ordering parameters
 */
public class OrderBean{

    private String strOrderField = "";
    private String strOrder = "";

    private String ascString = " Asc ";
    private String descString = " Desc ";
    private String defaultString = " ";

    public static final String ASC = "ASC";
    public static final String DESC = "DESC";

    public OrderBean(){}
    
    public OrderBean( String orderField, String order){
	setOrderField( orderField);
	setOrder( order);
    }
    public void setOrderField( String orderField){
	this.strOrderField = (orderField == null
			      || orderField.trim().equals("") ) ? ""  :orderField.trim();
    }
    public void setOrder( String order){
	this.strOrder = (DESC.equalsIgnoreCase( order) ) ?
	    DESC : ASC;
    }
    public void setAscending(String asc){
	if( asc != null ) ascString = asc;
    }
    public void setDescending(String dsc){
	if( dsc != null) descString = dsc;
    }
    public void setDefault( String n){
	if( n != null ){
	    defaultString = n;
	}
    }

    public String getOrderField() { return strOrderField;}
    public String getOrder(){ return strOrder; }
    public String getAscending(){ return ascString;}
    public String getDescending() { return descString; }
    public String getDefault(){ return defaultString; }
    
    /*
     * @param comField field to compare with the order field
     * @returns if orderField = compField ASC if DESC and DESC if ESC else default
     */
    public String getOrderString(String comField){
	if( comField == null ) return defaultString;
	String cf = comField.trim();
	if( cf.equalsIgnoreCase( strOrderField) ) {
	    if( strOrder.equalsIgnoreCase(  DESC) )
		return descString;
	    if( strOrder.equalsIgnoreCase(  ASC) )
		return ascString;
	}
	return defaultString;
    }
    /**
     * @param comField field to compare
     * @returns next ordering ASC or DESC default ASC
     */
    public String getNextOrder( String comField){
	if( comField == null ) return ASC;

	String cf = comField.trim();
	if( cf.equalsIgnoreCase( strOrderField) ){
	    if ( strOrder.equalsIgnoreCase( ASC) )
		return DESC;
	    else
		return ASC;
	}
	return ASC;
    }
}
