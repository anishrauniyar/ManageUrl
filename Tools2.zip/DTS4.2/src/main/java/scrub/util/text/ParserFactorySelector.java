package scrub.util.text;

import java.util.Map;
import java.util.HashMap;

/**
 * provides appropriate parser factory
 * based on the server type
 * current version provides parser factory for sqlserver only
 * requires modification for loading modules externally
 * this should not require code modification on other modules except for server type 
 */
public class ParserFactorySelector{

    private static ParserFactorySelector _self = null;
    //private Map parserMap = null;
    private static boolean isInitialized = false;

    /** restrict default object creation */
    private ParserFactorySelector(){
	//parserMap = new HashMap();
    }	

    /** create self if not created already */
    public static final synchronized ParserFactorySelector getInstance(){
	if( _self == null ){
	    _self = new ParserFactorySelector();
	}
	return _self;
    }

    /** for sql server only. requires modification when supporting through configuration */
    private static ParserFactory pf = new SQLParserFactory();
    /**
     * if serverType equals SQLServer ( case insensitive ) returns parser factory for sql server
     * @param serverType type of DBMS server
     * @returns ParserFactory for the specified
     * @throws IllegalArgumentException if serverType couldn't be identified
     */     
    public ParserFactory getParserFactory( String serverType ){

	if( ! ("SQLServer".equalsIgnoreCase( serverType ) || "ORCL".equalsIgnoreCase( serverType )) ){
	    throw new IllegalArgumentException("servers other than SQLServer/ORCL is currently not supported ");
	}
	return pf;
    }
}
