package scrub.util.text;
/**
 * Parse parameter as numeric operation in SQL
 */
public class ParseSQLNumeric implements Parser{

    /* Patterns
     * 1. operator expression  operators->  not,<>,!=,<=,>=,,<,=,>
     * 2. like	(Text only) not supported
     * 3. between exp and exp	 
     * 4. exp - exp 
     * 5. single expression	 
     */
    ParseSQLNumeric(){}

    public String parse( String fldAlias, String strToParse){
	return translate( strToParse, fldAlias);
    }

    public static String translate( String strToParse, String strSQLField){
	    String strP = strToParse.trim();		
	    if(strP.equals(""))return "";		
	    String retString = "";
	    int strLen = strP.length();
	    String strPLower = strP.toLowerCase();
	    //not exp
	    if ( "not ".regionMatches(0, strPLower ,0,4) && strLen > 4){
		    strP = strP.substring(4);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " <> " + retString + " ";
	    }//<> exp or != exp
	    else if ( ("<>".regionMatches(0, strP,0,2) || "!=".regionMatches(0, strP,0,2))
		    && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " <> " + retString + " ";		
	    }//<= exp
	    else if ( "<=".regionMatches(0, strP,0,2) && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " <= " + retString + " ";
	    }//>= exp
	    else if ( ">=".regionMatches(0,strP,0,2) && strLen > 2){
		    strP = strP.substring(2);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " >= " + retString + " ";
	    }//> exp
	    else if (  ">".regionMatches(0, strP,0,1) && strLen > 1){
		    strP = strP.substring(1);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " > " + retString + " ";
	    }//= exp
	    else if ( "=".regionMatches(0, strP,0,1) & strLen > 1){
		    strP = strP.substring(1);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " = " + retString + " ";
	    }//< exp
	    else if ( "<".regionMatches(0, strP,0,1) & strLen > 1){
		    strP = strP.substring(1);
		    retString = EndQuoteRemover.remove( strP);
		    retString = NumericStringRetriever.retrieve( retString);
		    if ( !retString.equals(""))
			    retString =  " " + strSQLField + " < " + retString + " ";			
	    }//between exp and exp
	    else if ( "between ".regionMatches(0, strPLower,0,8)  && strLen > 14
		    && " and ".regionMatches(0, strPLower ,strPLower.indexOf(" and "),5) ){
		    int andPos = strPLower.indexOf(" and ",9);
		    String firstParam = NumericStringRetriever.retrieve( 
						    strP.substring(8,andPos));

		    if( andPos > 8 && (andPos + 5) < strLen){
			    String secondParam = NumericStringRetriever.retrieve(
					    strP.substring(andPos+5));
		    if( !firstParam.equals("") && !secondParam.equals(""))
		    retString = strSQLField + " between " 
			    + firstParam+ " and "
			    + " " + secondParam+ " ";
		    }		
	    }//exp - exp
	    else{
		    int minIndex = strP.lastIndexOf('-');
		    if (minIndex > 0 && minIndex < strLen-1){
		    String firstParam = NumericStringRetriever.retrieve(
		    strP.substring(0,minIndex));
		    String secondParam = NumericStringRetriever.retrieve(
		    strP.substring(minIndex+1));
		    if( !firstParam.equals("") & !secondParam.equals(""))
		    retString = strSQLField + " between " 
			    + firstParam+ " and "
			    + " " + secondParam+ " ";
		    }//exp
		    else{
			    String numParam = NumericStringRetriever.retrieve(strP);
			    if( !numParam.equals(""))
			    retString = strSQLField + " = " + numParam;
		    }
	    }

	    return retString;	
    }



    /*
    public static void main ( String [] args){
	    String str = " -121 *^&^345.8Q39.84 908opu";
	    System.out.println(str+"-->"+getNumericString( str));
    }*/
}
