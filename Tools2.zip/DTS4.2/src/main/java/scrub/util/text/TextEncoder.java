package scrub.util.text;
/** Encoding for asigning value in form components*/
public class TextEncoder{
    /**
     * encoding of form elements 
     * @param p String to encode
     * @returns encoded string, if null ""
     */
    public static String encodeHTP( String p){
	if ( p== null || "".equals(p.trim())) return "";
	int pLen = p.length();
	int count = 0;
	char c;
	StringBuffer sb = new StringBuffer( pLen+1);
	for(count=0; count < pLen; count++){
		c = p.charAt( count);
		switch(c){
			case '\'' : sb.append("&#39;"); break;	//Quote
			case '\"' : sb.append("&#34;"); break;	//Double Quote
			case '<'  : sb.append("&lt;");  break;	//
			case '>'  : sb.append("&gt;");  break;
			case '&'  : sb.append("&amp;"); break;
			case '+'  : sb.append("&#43;"); break;	//plus
			case '-'  : sb.append("&#45;"); break;
			case '/'  : sb.append("&#47;"); break;    
			default: sb.append( c);			
		}
	}
    return sb.toString();
    }
    /**
     * Encodes slash, quote and double quote only for JavaScript
     * @param p string to encode ' and "
     * @returns encoded string or "" if null
     */
    public static String encodeJS( String p){
	if ( p== null || "".equals(p.trim())) return "";
	int pLen = p.length();
	int count = 0;
	char c;
	StringBuffer sb = new StringBuffer( pLen+1);
	    for(count=0; count < pLen; count++){
		    c = p.charAt( count);
		    switch(c){
			    case '\'' : sb.append("\\\'"); break;	//Quote
			    case '\"' : sb.append("\\\""); break;	//Double Quote
			    default: sb.append( c);			
		    }
	    }
       return sb.toString();
    }
}
