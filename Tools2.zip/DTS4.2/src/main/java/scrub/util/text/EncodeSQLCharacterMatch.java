package scrub.util.text;
/**
 * replacing ? , *, '  with _ , % , ''  respectively from param as used in client-server DBMS
 */
public class EncodeSQLCharacterMatch{
    
    public static String encode( String param){
	param = param.trim();
	if( param.equals("")) return "";

	StringBuffer sb = new StringBuffer();
	char c;
	int len = param.length();

	for ( int i=0; i<len; i++){
	    c = param.charAt(i);
	    switch(c){
	    case '?' : sb.append('_'); break;
	    case '*' : sb.append('%'); break;
	    case '\'' : sb.append( "\'\'"); break;
	    default  : sb.append(c);
	    }
	}
	return sb.toString();
    }

    /*public static void main( String [] args){
      String str = "alsdfj?quest a;sdf_ asdlk% per";
      System.out.println( encode( str));
      }*/
}
