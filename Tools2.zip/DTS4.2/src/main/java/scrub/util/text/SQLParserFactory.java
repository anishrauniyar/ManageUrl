package scrub.util.text;

import java.util.HashMap;

public class SQLParserFactory implements ParserFactory{

    /** Parser stores */
    private static HashMap map = new HashMap();

    static {
	map.put( new Integer( Parser.TYPE_NUMERIC), new ParseSQLNumeric() );
	map.put( new Integer( Parser.TYPE_TEXT), new ParseSQLText() );
	map.put( new Integer( Parser.TYPE_DATE), new ParseSQLDate() );
    }

    
    public Parser getParser( int type){
	Parser p = null;
	p = (Parser) map.get( new Integer( type) );
	if ( p == null)
	    p = (Parser) map.get( new Integer( Parser.TYPE_TEXT) );
	return p;
    }
}
