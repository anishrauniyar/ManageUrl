package scrub.util.text;
/**
 * eliminates preceeding and trailing quotes and double coutes
 */
public class EndQuoteRemover{
	public static String remove( String strP){

		if (strP == null) return "";
		String retStr = strP.trim();
		int len = retStr.length();
		if ( retStr.equals("")) return "";
		
		StringBuffer sb = new StringBuffer( retStr);
		int i=0;
		while( i < len && ( sb.charAt(i) == '\'' || sb.charAt(i) == '\"'
			|| sb.charAt(i) == ' ')){
			sb.setCharAt(i,' ');
			i++;			
		}
		i = len -1;
		while( i >= 0 && ( sb.charAt(i) =='\'' || sb.charAt(i) == '\"'
			|| sb.charAt(i) == ' ')){
			sb.setCharAt(i,' ');
			i--;			
		}
		retStr = sb.toString().trim();

		return retStr;
	}
	//stub testing
	/**
	<code>
	public static void main ( String args[]){
	String  str1 = " \"this is a test \'";
	String str2 = "\"23456\"";
	String str3 = "\'23456'";
	String str4 =  "\"\'23456\'\"";
	String str5 = "\'\"23456\"\'";
	
	System.out.println("Before "+str1);
	System.out.println("After "+remove(str1));
	System.out.println("Before "+str2);
	System.out.println("After "+remove(str2));
	System.out.println("Before "+str3);
	System.out.println("After "+remove(str3));
	System.out.println("Before "+str4);
	System.out.println("After "+remove(str4));
	System.out.println("Before "+str5);
	System.out.println("After "+remove(str5));
	}
	</code>
	*/
}
