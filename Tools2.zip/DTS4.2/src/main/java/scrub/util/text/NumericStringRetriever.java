package scrub.util.text;
/**
 * Returns numeric string form param
 */
public class NumericStringRetriever{
    public static String retrieve( String strP, int startIndex,int endIndex)    {
	return retrieve( strP.substring( startIndex, endIndex));
    }

    public static String retrieve( String strP, int startIndex)	{
	return retrieve( strP.substring( startIndex));
    }

    public static String retrieve( String strP)	{

	if(strP == null || strP.equals("") ) return "";

	int iPos, len;
	char c;
	boolean dotMatched=false;
	String strPN = strP.trim();
	len = strPN.length();

	StringBuffer sb = new StringBuffer();

	if( len > 1 &&  strPN.charAt(0) == '-') sb.append('-');
	for( iPos=0; iPos < len; iPos++){
	    c = strPN.charAt(iPos);
	    switch(c){
	    case '0':
	    case '1':
	    case '2':
	    case '3':
	    case '4':
	    case '5':
	    case '6':
	    case '7':
	    case '8':
	    case '9': sb.append(c);break;
	    case '.': if ( dotMatched == false)
		sb.append(c);
		dotMatched = true;
		break;
	    }
	}
	return sb.toString();
    }
}
