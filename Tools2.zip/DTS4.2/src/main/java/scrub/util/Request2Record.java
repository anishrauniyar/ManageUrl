package scrub.util;


import scrub.datatransfer.Record;
import scrub.util.RequestData;

/**
 * extract Record structure from RequestData.
 * prefix is eliminated for the name in the request name
 */
public class Request2Record{

    /**
     * @param req represet the name-value(s) pair
     * @param prefix the prefix in name to eliminat
     * @returns new Reocrd with name from which prefix are eliminated.
     */
    public static Record getRecord( RequestData req, String prefix ){
	Record rec = new Record();
	String [] paramNames = req.getParameterNames();
	int i=0;
	int len = paramNames.length;
	String fName = null;
	String fValue = null;
	int pflen = prefix.length();
	
	for(i=0; i<len; i++){
	    if( paramNames[i].startsWith( prefix) ){
		fName = paramNames[i].substring( pflen );
		fValue = req.getParameter( paramNames[i] );
		//System.out.println( prefix + fName+"\t"+fValue);
		if( "".equals( fValue) ){
		    fValue = null;
		}
		rec.put( fName, fValue);
		
	    }
	}
	return rec;
    }

}
