package scrub.util;

import scrub.util.RequestData;

public class RequestTransfer {
    /**
     * @param source RequestData form which to copy 
     * @param prefixes array of strings consisting of  names for which prefix has to be dropped (null not allowed)
     * @param equalPF array of names for which equal condition has to be added if does n't starts with equal
     *  ( null allowed)
     * @returns new RequestData
     */

    public static RequestData transfer( RequestData source, String[] prefixes, String equalPF [] ){
	if( prefixes == null && equalPF == null )
	    return new RequestData( source);
	
	RequestData dest = new RequestData();
	String [] names = source.getParameterNames();
	int i=0;
	int len = names.length ;
	
	String [] pfUC = getUC( prefixes);		//prefix uppercase
	String [] equalsUC = getUC( equalPF );		//equals uppercase

	String [] values = null;
	String [] newValues = null;
	String newName = null;

	for( i=0; i<len; i++){
	    newName = names[ i];
	    if( prefixes != null ){
		newName = getNewName( names[i], pfUC );
	    }
	    values = source.getParameters( names[i] );
	    newValues = new String[ values.length ];
	    
	    System.arraycopy( values, 0, newValues, 0, values.length);

	    if( isEqualRequired(  names[i], equalsUC ) ){
		for( int j=0; j<newValues.length; j++){
		    if( !newValues[j].startsWith("=") ){
			newValues[j] = "=" + newValues[j];
		    }
		}
	    }
	    dest.addParameters( newName, newValues);
	}
	return dest;

    }
    
    private static String getNewName( String oname, String[] pf){
	String newName = null;
	if( pf == null )
	    return oname;
	newName = oname; //default set to the param passed
	String onameUC = null;
	
	for( int i=0; i<pf.length; i++){
	    onameUC = oname.toUpperCase();	//uppercase param
	    if( onameUC.startsWith( pf[i] ) ){
		newName = oname.substring( pf[i].length() );
		i=pf.length;

	    }
	}
	return newName;	
    }

    private static String [] getUC( String [] toUC){
	if( toUC == null )
	    return null;
	String uc [] = new String[ toUC.length ];
	for( int i=0; i<uc.length; i++){
	    if( toUC[i] != null ){
		uc[i] = toUC[i].toUpperCase();
	    }
	}
	return uc;
    }
    private static boolean isEqualRequired( String oname, String [] eqUC ){
	if( eqUC == null || oname==null )
	    return false;
	boolean retValue = false;
	String onameUC = oname.toUpperCase();
	for( int i=0; retValue==false && i<eqUC.length; i++){
	    if( onameUC.startsWith( eqUC[ i] ) ){
		retValue = true;
		i= eqUC.length;
	    }
	}
	return retValue;
    }

    public static void main( String [] args){
	RequestData src = new RequestData();
	src.addParameters("cbo_name",new String[] {"ab","bc","=ca"} );
	System.out.println( src.toSerialString() );

	RequestData src1 = RequestTransfer.transfer( src, null, null );
	System.out.println( src1.toSerialString() );
	
	src1 = RequestTransfer.transfer( src, new String[] {"cbo" }, null );
	System.out.println( src1.toSerialString() );

	
	src1 = RequestTransfer.transfer( src, new String[] {"cbo" }, new String[] {"cbo_n"} );
	System.out.println( src1.toSerialString() );
    }
}






