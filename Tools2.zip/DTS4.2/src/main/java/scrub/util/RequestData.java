package scrub.util;

/**
 * represents name-value(s) pair
 */
import java.util.*;
import scrub.util.text.KeyString;

public class RequestData {

    protected Hashtable ht;

    private static final char SEP_PAIR = '&';
    private static final char SEP_NAME_VALUE = '=';
    private static final char ESCAPE_CHAR = '\\';
    
    public static final String BLANK = "";

    public RequestData(){
	ht = new Hashtable();
    }

    public RequestData( RequestData r){
	this();
	if( r != null){
	    String [] paramNames = r.getParameterNames();
	    for( int ndx = 0; ndx < paramNames.length; ndx++){
		setParameters( paramNames[ ndx], r.getParameters( paramNames[ ndx] ) );
	    }
	}
    }
    public void setParameter( String key, String value){
	if( key != null && !key.trim().equals( BLANK ) && value != null && !BLANK.equals( value.trim()) ){
	    ArrayList al = new ArrayList();
	    al.add( value.trim() );
	    ht.put( new KeyString( key ), al );
	}
    }

    public void setParameters( String key, String [] value){
	if( key != null && !key.trim().equals( BLANK ) && value != null && value.length > 0 ){
	    int len = value.length;
	    ArrayList al = new ArrayList( len);
	    for( int i =0; i< len; i++){
		if( value[i] != null && !BLANK.equals( value[i].trim() ) ){
		    al.add( value[i].trim() );
		}
	    }
	    if( !al.isEmpty()){
		ht.put( new KeyString( key ), al);
	    }
	}
    }

    public boolean containsKey( String key){
	if( key != null ){
	    return ht.containsKey( new KeyString( key ));
	}
	return false;
    }

    public String getParameter( String key){
	if( key != null && containsKey(  key  ) ){
	    ArrayList al = (ArrayList) ht.get( new KeyString( key ) );
	    return (String) al.get( 0);
	}
	return BLANK;
    }
    public String [] getParameters( String key){
	if( key != null && containsKey(  key  ) ){
	    ArrayList al = (ArrayList) ht.get( new KeyString( key ) );
	    String [] strArray  = new String[ al.size() ];
	    int i=0;
	    int len = al.size();
	    for(; i< len; i++){
		strArray[ i] =  (String) al.get(i);
	    }
	    return strArray;
	}
	return null;
    }

    public String[] getParameterNames(){
	if( ht.size() < 1 ) return null;
	String [] names = new String[ ht.size()];
	Enumeration enum1 = ht.keys();
	int i = 0;
	while( enum1.hasMoreElements()){
	    names[i] = ( (KeyString) enum1.nextElement()).getActualKey();
	    i++;
	}
	return names;
    }
    public String toSerialString(){
	boolean isFirst = true;
	StringBuffer sb = new StringBuffer();
	String [] names = getParameterNames();
	if( names != null){
	    int ncount = 0;
	    int len = names.length;
	    for(; ncount<len; ncount++){
		String key = names[ ncount];
		String escapedKey = escape( key);
		String [] values = getParameters( key);
		if( values == null || values.length == 0 ){
		    //sb.append( escapedKey + SEP_NAME_VALUE + SEP_PAIR );
		}else{
		    for( int i = 0; i < values.length; i++){
			//sb.append( escapedKey + SEP_NAME_VALUE + escape( values[i] ) + SEP_PAIR );
			if( values[i] != null ){
			    sb.append( escapedKey + SEP_NAME_VALUE + escape( values[i] ) + SEP_PAIR );
			    //System.out.println("APP : " + escapedKey + "\t" + escape( values[i]) );
			}
		    }
		}
	    }
	}
	if( sb.length() > 0 ) sb.deleteCharAt( sb.length() - 1 );
	return sb.toString();
    }

    private static String escape( String param){
	if( param == null || param.trim().equals( BLANK ) ) return BLANK;
	String work = param.trim();

	StringBuffer sb = new StringBuffer(300);
	int i = 0;
	char c;
	int len = work.length();
	for(; i<len; i++){
	    c = work.charAt(i);
	    switch( c){
	    case SEP_PAIR :
	    case SEP_NAME_VALUE :
	    case ESCAPE_CHAR :
		sb.append( ESCAPE_CHAR);
		sb.append( c);
		break;
	    default:
		sb.append( c);
	    }
	}
	return sb.toString();
    }
    public void addParameter( String key, String value){
        if( key == null || key.trim().equals( BLANK ) || value == null || BLANK.equals( value.trim() )) return;
        KeyString keyString = new KeyString( key );
        ArrayList al = (ArrayList)( ht.containsKey( keyString ) ? ht.get(  keyString ) : new ArrayList());
        al.add(value.trim());
        ht.put( keyString, al);
    }

    
    public void addParameters( String key, String [] value){
        if( key == null || key.trim().equals( BLANK ) || value == null) return;
        KeyString keyString = new KeyString( key );
        ArrayList al = (ArrayList)( ht.containsKey( keyString ) ? ht.get(  keyString ) : new ArrayList());

	int len = value.length;
	for( int i=0; i< len; i++){
	    if( value[i] != null && !BLANK.equals( value[i].trim()) )
		al.add( value[i].trim() );
	}
	if( !al.isEmpty() )
	    ht.put( keyString, al);
    }

    public void removeParameter( String key){
	ht.remove( new KeyString( key) );
    }
    public static RequestData fromSerialString( String asciiApp){
	RequestData tst = new RequestData();
	String name = BLANK;
	String value = BLANK;

	StringBuffer sb = new StringBuffer(300);
	int i = 0;
	int len = asciiApp.length();
	for(; i< len; i++){
	    char c = asciiApp.charAt(i);
	    switch( c){
	    case ESCAPE_CHAR :
		if( len > i + 1){
		    i++;
		    sb.append( asciiApp.charAt(i) );
		}
		break;
	    case SEP_PAIR :
		value = sb.toString();
		sb.delete(0, sb.length());
		tst.addParameter( name, value );
		//System.out.println( "GET SER: " + name+"\t"+value );;
		break;
	    case SEP_NAME_VALUE :
		name = sb.toString();
		sb.delete(0, sb.length());
		break;
	    default :
		sb.append( c);		    
	    }
	}
	value = sb.toString();
	tst.addParameter( name, value );
	return tst;
    }

    public boolean equals( Object o){
	boolean isEQ = true;
	RequestData row = null;
	if( o == null) isEQ = false;
	if( o instanceof RequestData){
	    row = (RequestData) o;
	}else{
	    isEQ = false;
	}
	if( this.ht.keySet().equals( row.ht.keySet()) && isEQ ){
	    Enumeration enum1 = this.ht.keys();
	    KeyString commonKey = null;
	    ArrayList myList = null, rowList = null;
	    int lsCount=0;
	    while( enum1.hasMoreElements() && isEQ ){
		commonKey = (KeyString) enum1.nextElement();
		myList = (ArrayList) ht.get( commonKey);
		rowList = (ArrayList) row.ht.get( commonKey);
		if( myList.size() == rowList.size() ){
		    for( lsCount=0; lsCount<myList.size() && isEQ; lsCount++){
			if( !rowList.contains( myList.get( lsCount) ) ){
			    isEQ = false;
			}
		    }
		}else{
		    isEQ = false;
		}
	    }
	}else{
	    isEQ  = false;
	}
	return isEQ;
    }
    /*--------------    TESTING --------------------------------- */
    /*    
    // <code>
    public static void main( String [] args){
	System.out.println( escape( "asdlf&a;lskdf=alks\\dutqa") );
	RequestData t = new RequestData();
	t.setParameter("","");
	t.setParameter("asdly&lkasj","al;uerqpow=sdlay");
	String [] mPram = {"a", "b", "c"};
	t.setParameters("mm", mPram);
	t.addParameter("mm", "&z=");
	System.out.println( t.toSerialString());
	RequestData t1 = fromSerialString( t.toSerialString());
	System.out.println("clone " +  t1.toSerialString());
	RequestData t2 = new RequestData();
	t2.setParameter( "first serial ", t1.toSerialString() );
	RequestData t3 = new RequestData();
	t3.setParameter( "second!= serial ", t2.toSerialString() );
	t3.setParameter("first&serial& from serial ", t1.toSerialString() );
	System.out.println( " t3 = \n"+ t3.toSerialString() );
    }
    //</code>
    */
}
