package scrub.util;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 * release database resources
 */
public class ReleaseDB{
    /**
     * static method for performance
     * @param cnn Connection
     * @param stmt Statement
     * @rs ResultSet
     */
    public static void releaseDBResources( Connection cnn, Statement stmt, ResultSet rs){
	if( rs != null ){
	    try{
		rs.close();
	    }catch( Exception rsEx){
	    }
	}
	if( stmt != null ){
	    try{
		stmt.close();
	    }catch( Exception stmtEx){
	    }
	}
	if( cnn != null ){
	    try{
		cnn.close();
	    }catch( Exception cnnEx){
	    }
	}
	rs = null;
	stmt = null;
	cnn = null;
    }
}
