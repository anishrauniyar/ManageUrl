package scrub.util;

/**
 * Loads appropriate ConnectionSource and provides to the client
 * isolates other parts of application from change in connection pooling
 */
public class ConnectionSourceFactory{

    private ConnectionSource cnnSrc = null;
    /** default constructor access restricted */
    private ConnectionSourceFactory(){
	cnnSrc = new ConnectionSourceImpl();
    }

    private static ConnectionSourceFactory _self = null;
    /**
     * Create itself if not created already
     * @returns _self which represents itself
     */
    public static final synchronized ConnectionSourceFactory getInstance(){
	if( _self == null ){
	    _self = new ConnectionSourceFactory() ;
	}
	return _self;
    }

    /**
     * @returns ConnectionSource from which connection can be obtained
     */
    public ConnectionSource getConnectionSource(){
	return cnnSrc;
    }
}



