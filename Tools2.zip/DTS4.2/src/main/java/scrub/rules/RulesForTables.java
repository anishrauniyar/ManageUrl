package scrub.rules;

import java.util.HashMap;

public class RulesForTables implements RulesConfig {
    private HashMap map = null;
    
    /** private constructor */
    private RulesForTables(){
	map = new HashMap();
    }

    /**
     * set module names for table
     * @param tableName name of the table
     * @param rules array of string specifying module names for applying rules
     */
    protected void setRules( String tableName, String [] rules){
	if( rules != null && rules.length > 0 && ! isRuleDefined( tableName) ){
	    map.put( tableName, rules);
	}
    }
    /**
     * @param tableName name of the table for which rules are to be obtained
     * @returns String array containg name of the modules which specify the rule.
     */
    public String []  getRules( String tableName){
	return (String [] ) map.get( tableName) ;
    }

    /**
     * @param tableName for which existence of rules is to be checked
     * @returns true if rules defined
     */
    public boolean isRuleDefined( String tableName ){
	return map.containsKey( tableName) ;
    }
    
    private static RulesForTables _self = null;
    /**
     * create an instance of RulesForTables
     */
    public static synchronized RulesForTables getInstance(){
	if( _self == null ){
	    _self =  new RulesForTables();
	}
	return _self;
    }
}
