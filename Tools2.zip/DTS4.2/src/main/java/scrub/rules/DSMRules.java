package scrub.rules;

import scrub.mgmt.Scrub;
import scrub.exception.ScrubException;

import scrub.datatransfer.Record;

/**
 * defines interface to hook dsm rules for data validation during
 * data modification
 */
public interface DSMRules{

    /**
     * @param scrub Refers to scrub to which it will call back if required
     */
    void setScrub( Scrub sc);

    /**
     * validate data based on rule before insertion
     * @param tblName name of the table to which rule is to be applied
     * @param rec Record data to be inserted
     */
    void validateInsert( String tblname, Record rec) throws Exception;

    /**
     * validate data based on rule before update
     * @param tblName name of the table to which rule is to be applied
     * @param oldRec Record data/recorded to be updated
     * @param newRec Record with new values
     */
    void validateUpdate( String tblname, Record oldRec, Record newRec) throws Exception;

    /**
     * validate data based on rule before deletion
     * @param tblName name of the table to which rule is to be applied
     * @param rec Record data to be inserted
     */
    void validateDelete( String tblname, Record rec) throws Exception;

    /**
     * @returns String specifying summary of rules implemented.
     */
    String getInfo();

}
