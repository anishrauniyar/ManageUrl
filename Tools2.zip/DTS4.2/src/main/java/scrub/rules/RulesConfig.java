package scrub.rules;

public interface RulesConfig{
    /**
     * @param tableName name of the table for which rules are to be obtained
     * @returns String array containg name of the modules which specify the rule.
     */
    String []  getRules( String tableName);

    /**
     * @param tableName for which existence of rules is to be checked
     * @returns true if rules defined
     */
    boolean isRuleDefined( String tableName ); 
}
