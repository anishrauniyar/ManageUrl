package scrub.rules;


import scrub.mgmt.Scrub;
import scrub.exception.ScrubException;

import scrub.datatransfer.Record;

/**
 * Adapter for DSMRules
 * does n't overwrite getInfo() method so that sub-classes are forced to implement
 * the method.
 */

public abstract class DSMRulesAdapter implements DSMRules{
    protected Scrub scrub = null;
    /**
     * @param sc Scrub scrub used for call back and access to backend system
     */
    public void setScrub( Scrub sc){
	scrub = sc;
    }
    /**
     * @returns reference to scrub
     */
    protected Scrub getScrub(){
	return scrub;
    }
    /** empty method for insert */
    public void validateInsert( String tblname, Record rec) throws Exception{
    }

    /** empty update method */
    public void validateUpdate( String tblname, Record oldRec, Record newRec) throws Exception {
    }

    /** empty delete validate */
    public void validateDelete( String tblname, Record rec) throws  Exception{
    }
}
