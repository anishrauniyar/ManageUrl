package scrub.rules;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import scrub.datatransfer.Record;
import scrub.exception.ScrubException;

import java.text.DateFormat;
import java.util.Date;

/**
 * Implementation rules for tbl_AsPrepared_Global_TPA
 */
public class TPARules extends DSMRulesAdapter{


    /**
     * validate data based on rule before insertion
     * @param tableName ignored
     * @param rec Record data to be inserted
     */
    public void validateInsert( String tableName, Record rec) throws Exception{
	validateCurrent( rec);
    }
    /********************************************************************************



    ********************************************************************************/
    /**
     * validate data based on rule before update
     * @param tableName ignored
     * @param oldRec Record data/recorded to be updated
     * @param newRec Record with new values
     */
    public void validateUpdate( String tableName, Record oldRec, Record newRec) throws Exception{
	validateCurrent( newRec);
    }
    /********************************************************************************



    ********************************************************************************/
    /**
     * rec Record to validate
     * ANALYSIS_YEAR must be C or P
     * POLICY_NUMBER must be five digit integer
     * RE_INSURER_CODE must be two digit integer starting with 0
     * SPECIFIC_AMOUNT = 0
     *		--> SPEC_CLAIMS_BASIS = N/A, MED_COVERAGE = N/A, RX_COVERAGE = N/A
     * SPEC_CLAIMS_BASIS = Paid | N/A
     *		--> SPEC_RUN_IN_PERIOD = 0, SPEC_RUN_OUT_PERIOD = 0
     * AGG_CLAIMS_BASIS = Paid | N/A
     *		--> AGG_RUN_IN_PERIOD = 0, AGG_RUN_OUT_PERIOD = 0
     */
    private static void validateCurrent( Record rec) throws Exception{
	boolean isError = false;
	StringBuffer sb = new StringBuffer(300);
	String analysisYear = rec.get( ANALYSIS_YEAR );

	/********** C OR P ANALYSIS YEAR **********/
	if( analysisYear == null ||  ( !"C".equalsIgnoreCase( analysisYear) && !"P".equalsIgnoreCase( analysisYear) )  ){
	    isError = true;
	    sb.append( EX_ANALYSIS_YEAR ); sb.append( "\n" );
	}else{
	    rec.put( ANALYSIS_YEAR, analysisYear.toUpperCase() );
	}
	/********************* 5 DIGIT SunlifePolicyNumber ***************/
	if( !isValidPolicyNo( rec.get( POLICY_NUMBER ) ) ){
	    isError = true;
	    sb.append( EX_POLICY_NUMBER ); sb.append( "\n" );
	}
	/*************** 2 DIGIT ReInsurerCode starting with 0 ***************/
	if( !isValidReInsurerCode( rec.get( RE_INSURER_CODE) ) ){
	    isError = true;
	    sb.append( EX_RE_INSURER_CODE ); sb.append( "\n" );
	}

	/********************************************************************/
	/*
	if( !isError){
	    String specificAmount = rec.get( SPECIFIC_AMOUNT );
	    if( isZero( specificAmount) ){
		rec.put( SPECIFIC_AMOUNT, "0" );
	    }
	    if( "0".equals( rec.get( SPECIFIC_AMOUNT ) ) ){
		rec.put( SPEC_CLAIMS_BASIS, N_A );
		rec.put( MED_COVERAGE, N_A );
		rec.put( RX_COVERAGE, N_A );
	    }

	    String specClaimsBasis = rec.get( SPEC_CLAIMS_BASIS );
	    if( PAID.equalsIgnoreCase( specClaimsBasis) || N_A.equalsIgnoreCase( specClaimsBasis) ){
		rec.put( SPEC_CLAIMS_BASIS, specClaimsBasis.toUpperCase() );
		rec.put( SPEC_RUN_IN_PERIOD, "0");
		rec.put( SPEC_RUN_OUT_PERIOD, "0");
	    }

	    String aggClaimsBasis = rec.get( AGG_CLAIMS_BASIS );
	    if( PAID.equalsIgnoreCase( aggClaimsBasis) || N_A.equalsIgnoreCase( aggClaimsBasis) ){
		rec.put( AGG_CLAIMS_BASIS, aggClaimsBasis.toUpperCase() );
		rec.put( AGG_RUN_IN_PERIOD, "0");
		rec.put( AGG_RUN_OUT_PERIOD, "0");
	    }
	}
	*/
    
    
	/***************************************************************************/
	if (isError){
	    throw new ScrubException( sb.toString() );
	}
    }
    /********************************************************************************



    ********************************************************************************/
    private static final String ANALYSIS_YEAR = "AnalysisYear";
    private static final String AGG_CLAIMS_BASIS = "AggClaimsBasis";
    private static final String AGG_RUN_IN_PERIOD = "AggRunInPeriod";
    private static final String AGG_RUN_OUT_PERIOD = "AggRunOutPeriod";
    private static final String SPECIFIC_AMOUNT = "SpecificAmount";
    private static final String SPEC_CLAIMS_BASIS = "SpecClaimsBasis";
    private static final String SPEC_RUN_IN_PERIOD = "SpecRunInPeriod";
    private static final String SPEC_RUN_OUT_PERIOD = "SpecRunOutPeriod";
    private static final String POLICY_NUMBER = "SunlifePolicyNumber";
    private static final String RE_INSURER_CODE = "ReinsurerCode";
    private static final String MIN_ADF_PER = "MinimumADFPer";
    private static final String MED_COVERAGE = "MedCoverage";
    private static final String RX_COVERAGE  = "RxCoverage";
    private static final String PAID  = "Paid";
    private static final String NA    = "NA";
    private static final String N_A   = "N/A";

    private static final String EX_ANALYSIS_YEAR =
	"AnalysisYear must be C or P. ";
    private static final String EX_POLICY_NUMBER =
	"SunlifePolicyNumber must be 5 digit numberic code. ";
    private static final String EX_RE_INSURER_CODE =
	"ReInsurerCode must be 2 digits starting with 0.";
    /********************************************************************************



    ********************************************************************************/
    private static final String INFO = "Represent rules for data validation in tbl_AsPrepared_Global_TPA.";
    /** @returns info about the bean's purpose */
    public String getInfo(){
	return INFO;
    }
    /********************************************************************************



    ********************************************************************************/
    private static final String zeroPat = "[\\+\\-]?\\s*0+(\\.0+)?";
    private static final boolean isZero( String sval) throws Exception{
	if( sval == null || "".equals( sval.trim() ) )
	    return true;
	
	Pattern patZero =  Pattern.compile( zeroPat );
	Matcher matcher = patZero.matcher( sval );
	return matcher.matches();
	
    }
    private static final String policyNoPat = "\\d{5}";
    private static final boolean isValidPolicyNo( String pno) throws Exception{
	if( pno == null || pno.length() != 5){
	    return false;
	}
	Pattern pat = Pattern.compile( policyNoPat );
	Matcher mat = pat.matcher( pno);
	return mat.matches();
    }

    private static final String reinsCodePat = "^0\\d";
    private static final boolean isValidReInsurerCode( String ricode) throws Exception{
	if( ricode == null || ricode.length() != 2){
	    return false;
	}
	Pattern pat = Pattern.compile( reinsCodePat );
	Matcher mat = pat.matcher( ricode);
	return mat.matches();

    }
    public static void main( String [] args) throws Exception{
	/*
	System.out.println(" 0.00 " + isZero( "0.00") ); 
	System.out.println(" 0. " + isZero( "0.") ); 
	System.out.println(" .00 " + isZero( ".00") ); 
	System.out.println(" 000 " + isZero( "000") );
	*/
	/*
	System.out.println(" 00.00 " + isValidPolicyNo( "00.00") ); 
	System.out.println(" 01122 " + isValidPolicyNo( "01122") ); 
	System.out.println(" 1  90 " + isValidPolicyNo( "1  90") ); 
	System.out.println(" 000a " + isValidPolicyNo( "000a") );
	*/
	/*
	DateFormat df = DateFormat.getInstance();
	Date date = df.parse("2002-02-28 30:30:30.0");
	*/
    }
}

