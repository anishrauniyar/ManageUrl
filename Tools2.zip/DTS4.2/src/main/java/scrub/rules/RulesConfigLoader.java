package scrub.rules;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.IOException;

import java.util.ArrayList;

import org.xml.sax.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;




/**
 * loads RulesForTable from xml file
 */
public class RulesConfigLoader{
    private static final String CONFIG = "config";
    private static final String TABLE  = "table";
    private static final String RULE   = "rule";

    private ArrayList al = null;
    
    public RulesConfigLoader(){
	al = new ArrayList( 6 );
    }
    /********************************************************************************


    ********************************************************************************/
    public RulesConfig loadRulesConfig( String xmlFileName) throws Exception{
	InputStream in = new FileInputStream( xmlFileName);
	if (in==null) {
	    throw new IOException("Cannot find the  file.. " + xmlFileName );
	}

	DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
	Document doc  =  (fact.newDocumentBuilder()).parse(in);
	
	return buildRulesConfig( doc) ;
    }
    /********************************************************************************


    ********************************************************************************/
    private RulesConfig buildRulesConfig( Document doc ){
	
	NodeList configList = doc.getElementsByTagName( CONFIG  );
	RulesForTables rulesTable = RulesForTables.getInstance();
	
	for (int i=0; configList != null && i < configList.getLength(); i++ ){
	    
	    Element config = (Element) configList.item(i);
	    
	    NodeList tableList = config.getElementsByTagName( TABLE );
	    Element table = (Element) tableList.item(0);
	    String tableName = table.getFirstChild().getNodeValue();
	    
	    NodeList ruleList = config.getElementsByTagName( RULE );
	    for( int j=0; ruleList !=null && j<ruleList.getLength(); j++){
		al.add(  (ruleList.item(j)).getFirstChild().getNodeValue()  );
	    }
	    if( !al.isEmpty() ){
		String [] rules  = new String[ al.size() ];
		rules = (String [] ) al.toArray( rules );
		rulesTable.setRules( tableName, rules );
	    }
	    al.clear();

	}
	return rulesTable;
    }
    /********************************************************************************


    ********************************************************************************/
    public static void main( String [] args) throws Exception{
	RulesConfigLoader ld = new RulesConfigLoader();
	RulesConfig rlconf = ld.loadRulesConfig( "e:/DSMFront/rules.xml");
	
	if( rlconf.isRuleDefined( "tbl_AsPrepared_Global_TPA" ) ){
	    String [] rls = rlconf.getRules( "tbl_AsPrepared_Global_TPA" );
	    for(int i=0; i<rls.length; i++){
		System.out.println( rls[ i] );
	    }
	}
    }

}
