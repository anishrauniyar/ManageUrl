package scrub.rules;


import scrub.mgmt.Scrub;
import scrub.exception.ScrubException;

import scrub.datatransfer.Record;

/**
 * DSM rule to verify primary key if exists
 */

public class PrimaryKeyRule extends DSMRulesAdapter{

    /**
     * validate data based on rule before insertion
     * @param tableName name of the table to which rule is to be applied
     * @param rec Record data to be inserted
     */
    public void validateInsert( String tableName, Record rec) throws Exception{
	Scrub sc = getScrub();
	assertScrub( sc);
	assertPrimaryKeySingle( sc, tableName, rec );
    }
    /********************************************************************************



    ********************************************************************************/
    /**
     * validate data based on rule before update
     * @param tblName name of the table to which rule is to be applied
     * @param oldRec Record data/recorded to be updated
     * @param newRec Record with new values
     */
    public void validateUpdate( String tblName, Record oldRec, Record newRec) throws Exception{
	Scrub sc = getScrub();
	assertScrub( sc);

	boolean isKeyModified = false;
	String [] pkFields = sc.getPKFields( tblName );
	String oldValue = null;
	String newValue = null;
	int i=0;
	if( pkFields != null && pkFields.length != 0 ){
	    //primary key exists.
	    for( i=0; i<pkFields.length && (isKeyModified==false) ; i++){
		oldValue = oldRec.get( pkFields[ i]);
		newValue = newRec.get( pkFields[ i]);
		if( newValue == null || "".equals( newValue) ){
		    throw new ScrubException( "Undefined value or blank value for "
					      + pkFields[i] + " is not allowed in " + tblName);
		}
		if( oldValue == null || "".equals( oldValue ) ) {
		    throw new ScrubException( "Previous value of " + pkFields[i]
					      + " is null or blank which is not possible");
		}
		
		if( !newValue.equalsIgnoreCase( oldValue) ){
		    //System.out.println("**>"+ pkFields[i]+" " +newValue+"  "+oldValue);
		    isKeyModified = true;
		}

	    }
	}
	if( isKeyModified ){
	    assertPrimaryKeySingle( sc, tblName, newRec);
	}

    }
    /********************************************************************************



    ********************************************************************************/
    /**
     * validate data based on rule before deletion
     * prevent deletion if fields used in defining primary key
     * are null or blank
     * @param tblName name of the table to which rule is to be applied
     * @param rec Record data to be inserted
     */
    public void validateDelete( String tblName, Record rec) throws Exception {
	Scrub sc = getScrub();
	assertScrub( sc);

	String [] pkFields = sc.getPKFields( tblName );
	String fValue = null;
	boolean isNull = false;
	
	if( pkFields != null && pkFields.length != 0 ){
	    //primary key exists.
	    for( int i=0; i<pkFields.length && (isNull==false) ; i++) {
		fValue = rec.get( pkFields[ i]);

		if( fValue == null || "".equals( fValue) ){
		    isNull = true;
		    throw new ScrubException( "During deletion, Undefined value or blank value specified for "
					      + pkFields[i] + " in " + tblName + " ");
		}
	    }
	}	

    }
    /********************************************************************************



    ********************************************************************************/
    /** info representing purpose */
    private static String info = "Verifies that primary key is not validated during insert/update.";
    /**
     * @returns info
     */
    public String getInfo(){
	return info;
    }
    /********************************************************************************



    ********************************************************************************/
    /**
     * @param s Scrub
     * @throws IllegalStateException if scrub is not already set.
     */
    private void assertScrub( Scrub s) throws IllegalStateException{
	if( s == null ){
	    throw new IllegalStateException( "Scrub not set. Call back not possible");
	}
    }
    /********************************************************************************



    ********************************************************************************/
    /**
     * raise exception ( ScrubException ) on primary key violation
     * @param tableName name of the table on which to verify pk violation
     * @param rec record for which pk violation is to be checked
     * @throws ScrubException
     */
    private void assertPrimaryKeySingle( Scrub sc, String tableName, Record rec) throws Exception{
	String [] pkFields = sc.getPKFields( tableName);
	if( pkFields == null || pkFields.length == 0 ){
	    return;
	}
	Record pkRec = new Record();
	String fieldValue = null;
	int i = 0;
	for( ; i< pkFields.length; i++ ){
	    if( rec.containsField( pkFields[ i] ) ){
		fieldValue = rec.get( pkFields[ i] );
		pkRec.put( pkFields[ i], fieldValue );
	    }else{
		throw new ScrubException( "Value must be specified for " + pkFields[ i] + " in " + tableName );
	    }
	}
	int count = sc.getRecordCount( tableName, pkRec);
	if( count > 0 ){
	    StringBuffer sb = new StringBuffer(300);
	    for( i = 0; i< pkFields.length; i++){
		sb.append( pkFields[i]);
		sb.append( " = " );
		sb.append( rec.get( pkFields[i] ) );
		sb.append( "   ");
	    }
	    sb.append( " already exists in ");
	    sb.append( tableName );
	    sb.append( ".  Duplication/Repetition of these values are not allowed. ");
	    throw new ScrubException( sb.toString() );
	}
    }
}
