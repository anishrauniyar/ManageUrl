package scrub.log;

import scrub.data.MasterDB;
/**
 * log database
 */
public class LogDB extends MasterDB{

    /*--------------------------------------------------*/
    protected static final String LOG_DB = "MDHawkeye->LogDB";
    /*--------------------------------------------------*/

    public LogDB(){
	setSourceAlias( LOG_DB);
    }
}
