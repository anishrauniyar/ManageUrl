package scrub.log;

import java.sql.Timestamp;
import scrub.datatransfer.Record;

/**
 * represents the log record
 */
class LogRecord{
    String loginName=null, clientID=null, clientName=null, tableName=null, operation=null;
    Timestamp changeTimestamp=null;
    Record oldRecord=null, newRecord=null;
    private LogRecord(){}
    public LogRecord( String lName, String clID, String clName, String tblName, String optn,
		      Record oRec, Record nRec, Timestamp chTimestamp){
	loginName = lName;
	clientID = clID;
	clientName = clName;
	tableName = tblName;
	operation = optn;
	oldRecord = new Record( oRec);
	newRecord = new Record( nRec);
	changeTimestamp = chTimestamp;
    }

    public String getLoginName(){ return loginName;}
    public String getClientID(){ return clientID; }
    public String getClientName(){ return clientName;}
    public String getTableName(){ return tableName; }
    public String getOperation(){ return operation; }
    public Record getOldRecord(){ return oldRecord;}
    public Record getNewRecord(){ return newRecord; }
    public Timestamp   getChangeTimestamp(){ return changeTimestamp; }
}
