package scrub.log;

import java.util.Properties;
import java.util.HashMap;

import scrub.datatransfer.Record;

/**
 * log scrub as prepared modifications
 */
public  class Logger {

    private static Logger _self = null;

    LogWriter lg = null;
    
    /** constructor */
    private Logger(){
	lg = new LogDBWriter();
    }

    /** create itself */
    public static synchronized Logger getInstance(){
	if( _self == null ){
	    _self = new Logger();
	}
	return _self;
    }

    /** log insertion */
    public void inserted( String loginName, String clientID, String clientName, String tblName, Record rec)
	throws Exception{
	lg.inserted( loginName, clientID, clientName, tblName, rec);
    }
    /** log deletion */
    public void deleted( String loginName, String clientID, String clientName, String tblName, Record rec)
    throws Exception{
	lg.deleted( loginName, clientID, clientName, tblName, rec);
    }
    /** log update */
    public void updated( String loginName, String clientID, String clientName, String tblName, Record oldRec,
			 Record newRec) throws Exception{
	lg.updated( loginName, clientID,  clientName, tblName, oldRec, newRec);
    }

    /** @parm enable if true enable logging else disable*/
    public void setEnabled( boolean enable){
	lg.setEnabled( enable );
    }

    /** @returns true if logging enabled */
    public boolean isEnabled(){
	return lg.isEnabled();
    }
}
