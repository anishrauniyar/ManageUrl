package scrub.log;

import java.util.Calendar;
import scrub.datatransfer.Record;
import scrub.util.ReleaseDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

import java.util.ArrayList;

public  class LogDBWriter extends LogDB implements LogWriter, Runnable{

    private static final String OP_INSERT = "insert";
    private static final String OP_DELETE = "delete";
    private static final String OP_UPDATE = "update";

    private static final int WORK_SIZE = 300;
    private static ArrayList logList = new ArrayList ( WORK_SIZE );
    private static ArrayList workList = new ArrayList( WORK_SIZE );

    private static final int REFRESH_RATE = 30000;//180000;  //millisecond (refresh

    Thread t = null;

    /** protected constructor
     * start the thread for logging
     */
    protected LogDBWriter(){
	super();
	restart();
    }

    /** @returns true if the thread is running */
    public boolean isRunning(){
	if( t!=null && t.isAlive() )
	    return true;
	return false;
    }
    /** restart the thread if dead or null */
    public void restart(){
	if( !isRunning() ){
	    t = new Thread( this);
	    t.start();
	}
    }

    /** @returns true if the thread is running */
    public boolean isEnabled(){
	return isRunning();
    }

    /** @param enb enable the thread if ture else stop */
    public void setEnabled( boolean enb){
	if( enb){
	    if( !isRunning() ){
		restart();
	    }
	}else{
	    stop();
	    try{
		insertLogRecord( workList);//log all if any
	    }catch(Exception exp){
		System.out.println("modification log failure");
		exp.printStackTrace();
	    }
	}
    }
    /** stop the thread */
    public void stop(){
	t=null;
    }

    /** run method used by the thread */
    public void run(){
	while( t!=null ){
	    copyToWork();
	    try{
		insertLogRecord( workList);
		Thread.sleep( REFRESH_RATE );
	    }catch(Exception thEx){
		t = null; //stop
		System.out.println("Exception logging : LogDBWriter");
		thEx.printStackTrace();
	    }
	}
    }
    /** log insertion */
    public void inserted( String loginName, String clientID, String clientName, String tableName, Record rec )
	throws Exception{
	LogRecord lrec = new LogRecord( loginName, clientID, clientName, tableName, OP_INSERT,
					null, rec, getTimestamp() );
	addLogRecord( lrec );
    }
    
    /** log deletion */
    public void deleted( String loginName, String clientID, String clientName, String tableName, Record rec )
	throws Exception{
	LogRecord lrec = new LogRecord( loginName, clientID, clientName, tableName, OP_DELETE,
					null, rec, getTimestamp() );
	addLogRecord( lrec);

    }


    /** log update */
    public void updated( String loginName, String clientID, String clientName, String tableName, Record oldRec,
			 Record newRec ) throws Exception{
	LogRecord lrec = new LogRecord( loginName, clientID, clientName, tableName, OP_UPDATE,
					oldRec, newRec, getTimestamp() );
	addLogRecord( lrec );
    }

    private static synchronized void addLogRecord( LogRecord rec){
	logList.add( rec);
    }
    private static synchronized  void copyToWork(){
	workList.addAll( logList);
	logList.clear();
    }

    public  static java.sql.Timestamp getTimestamp(){
	return new java.sql.Timestamp( (Calendar.getInstance() ).getTimeInMillis() );
    }

    /*-------------------- SQL FOR STATEMENTS TO EXECUTE ------------------------------*/
    //insert into tbl_Log_Change
    private static final String INS_LOG
	= "insert into tbl_Log_Change(loginName, clientID, clientName,tableName,operation, changeDate) "
	+" values(?, ?, ?, ?, ?, ?)"; //6 parameters
    
    //find id
    private static final String LOG_ID
	= "select ID from tbl_Log_Change where loginName = ? and clientID = ? and clientName = ? "
	+ " and tableName = ? and operation =? and changeDate = ?"; //6parameters
    
    //log the record change
    private static final String LOG_RECORD
	="insert into tbl_Log_Change_Record( ID, FieldName, OldValue, NewValue) values( ?, ?, ?, ?)";//4-parameters 1st int
												//rest string 
    /*--------------------------------------------------------------------------------*/
    private static final Record blankRec = new Record();
    private void insertLogRecord( ArrayList lgList ) throws Exception{
	if( lgList.isEmpty() ) return;
	LogRecord [] logRec = null;
	synchronized( lgList){
	    logRec = new LogRecord[ lgList.size() ];
	    logRec = (LogRecord [] ) lgList.toArray( logRec);
	    lgList.clear();

	}
	//System.out.println(">> log rec size : " + logRec.length);
	Connection cnn = null;
	PreparedStatement psLogOp = null;
	PreparedStatement psLogID = null;
	PreparedStatement psLogRec = null;

	int index = 0;
	int lgSize = logRec.length;
	
	int i=0;
	int len =0;
	int id =0; //id values;

	try{
	    cnn = getConnection();
	    psLogOp = cnn.prepareStatement( INS_LOG);  //JDBC 3.0 not supported by the current drivers yet !!!
	    psLogID = cnn.prepareStatement( LOG_ID );
	    psLogRec = cnn.prepareStatement( LOG_RECORD );

	    for( index=0; index<lgSize; index++){
		//System.out.print(">>INDEX:"+index);
		// variables
		String loginName=null, clientID=null, clientName=null, tableName=null, operation=null;
		Record oldRec=null, newRec=null;
		String fieldName = null, oldValue = null, newValue=null;
		Timestamp changeTimestamp = null;

		loginName = logRec[ index ].getLoginName();
		//System.out.println(">>logRec: index accepted.");
		clientID = logRec[ index ].getClientID();
		clientName = logRec[ index ].getClientName();
		tableName = logRec[ index ].getTableName();
		operation = logRec[ index ].getOperation();
		oldRec = (logRec[ index ].getOldRecord()==null)? blankRec : logRec[ index ].getOldRecord();
		newRec = (logRec[ index ].getNewRecord()==null)? blankRec : logRec[ index ].getNewRecord();
		
		changeTimestamp = logRec[ index ].getChangeTimestamp();
		

		psLogOp.clearParameters();
		psLogOp.setString( 1, loginName);
		psLogOp.setString( 2, clientID );
		psLogOp.setString( 3, clientName );
		psLogOp.setString( 4, tableName  );
		psLogOp.setString( 5, operation  );
		psLogOp.setTimestamp( 6, changeTimestamp );
		psLogOp.executeUpdate();

		psLogID.clearParameters();
		psLogID.setString( 1, loginName);
		psLogID.setString( 2, clientID );
		psLogID.setString( 3, clientName );
		psLogID.setString( 4, tableName  );
		psLogID.setString( 5, operation  );
		psLogID.setTimestamp( 6, changeTimestamp );
		ResultSet rsID = psLogID.executeQuery();
		//System.out.println(">>OPERATION>>-----------"+operation);
		if( rsID.next() ){
		    id = rsID.getInt(1);

		    //from old Record
		    len = 0;
		    String [] oldFields = oldRec.getFieldNames();
		    if( oldFields != null && oldFields.length>0) len = oldFields.length;
		    //System.out.println(">>Ols Len: "+len);
		    for(i=0; i<len;i++){

			psLogRec.clearParameters();
			psLogRec.setInt(1, id);

			psLogRec.setString( 2, oldFields[i] ); //field name
			psLogRec.setString( 3, oldRec.get( oldFields[i]) );// old value
			psLogRec.setString( 4, newRec.get( oldFields[i]) );//oldvalue then new value!!!
			psLogRec.executeUpdate(); 
			oldRec.remove( oldFields[i]);
			newRec.remove( oldFields[i]);

			//System.out.println(">>Exp First:: "+i + " old " + oldRec.isEmpty() + oldRec.size()
			//	       + " new "+newRec.isEmpty() + newRec.size() );

		    }
		    //add from new Record
		    len=0;//reset len
		    String [] newFields = newRec.getFieldNames();
		    if( newFields != null && newFields.length>0) len = newFields.length;
		    //System.out.println( " new Len:" + len);

		    for(i=0; i<len;i++){

			psLogRec.clearParameters();
			psLogRec.setInt(1, id);
			psLogRec.setString( 2, newFields[i] ); //field name
			psLogRec.setString( 3, oldRec.get( newFields[i]) );// old value
			psLogRec.setString( 4, newRec.get( newFields[i]) );//oldvalue then new value!!!
			psLogRec.executeUpdate(); 
			oldRec.remove( newFields[i]);
			newRec.remove( newFields[i]);

			//System.out.println(">>Exp 2nd:: "+i + " old " + oldRec.isEmpty() + oldRec.size()
			//	       + " new "+newRec.isEmpty() + newRec.size() );  

		    }	    
		}
		ReleaseDB.releaseDBResources( null, null, rsID);	    
	    }
	}finally{
	    ReleaseDB.releaseDBResources( null, psLogRec, null);
	    ReleaseDB.releaseDBResources( null, psLogID, null);
	    ReleaseDB.releaseDBResources( cnn, psLogOp, null);
	}
    }
}
