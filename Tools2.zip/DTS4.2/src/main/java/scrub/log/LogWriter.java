package scrub.log;

import scrub.datatransfer.Record;

public interface LogWriter{
    /** log insertion */
    void inserted( String loginName, String clientID, String clientName, String tableName, Record rec)
	throws Exception;
    
    /** log deletion */
    void deleted( String loginName, String clientID, String clientName, String tableName, Record rec)
	throws Exception;

    /** log update */
    void updated( String loginName, String clientID, String clientName, String tableName, Record oldRec,
			 Record newRec ) throws Exception;
    /** set enabled */
    void setEnabled( boolean enb);

    /** get enabled */
    boolean isEnabled();
}
