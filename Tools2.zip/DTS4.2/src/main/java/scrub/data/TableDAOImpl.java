package scrub.data;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import scrub.util.RequestData;
import scrub.datatransfer.Record;
import scrub.datatransfer.ScrubTable;
import scrub.datatransfer.ScrubField;
import scrub.datatype.FieldType;

import scrub.util.text.*;

/**
 * implementation of TableDAO for accessing tables
 * sequence of query generation are represented by commented sql fragments on the right side of code.
 */
public class TableDAOImpl implements TableDAO{



    /******************************************************************************************/
    /** length of query string */
    private static final int QSIZE = 300;

    /** default constructor restricted */
    private TableDAOImpl(){}

    /** ScrubDAOFactory */
    protected ScrubDAOFactory daoF = null;

    /** constructor which initializes ScrubDAOFactory
     * @param f ScrubDAOFactory to use
     */
    protected TableDAOImpl( ScrubDAOFactory f){
	daoF = f;
    }
    /******************************************************************************************/



    /******************************************************************************************/
    /**
     * insert record into a table
     * @param tableName name of the table in which to append record
     * @param rec record to insert
     * @returns number of records inserted
     * @throws Exception on failure to connect to the database or failed to insert record
     */
    public int insertRecord( String tableName, Record rec) throws Exception{
	if( tableName == null || rec == null || rec.size() <=0)
	    return 0;
	DBTables dbTables = daoF.getDBTables();
	ScrubField [] tblFields = dbTables.getScrubFields( tableName );
	StringBuffer insertSQL = new StringBuffer( QSIZE );
	insertSQL.append( "insert into \"" + tableName + "\" ( " );			//insert into "tableName" (
	int fieldCount = tblFields.length;
	boolean isFirst = true;
	int i = 0;
	String fieldName = null;
	for( i=0; i<fieldCount; i++ ){
	    fieldName = tblFields[ i ].getFieldName();

	    if( rec.containsField( fieldName ) ){
		if( isFirst ){
		    insertSQL.append( "\"" + fieldName + "\"" );		// "fieldNameI"
		    isFirst = false;
		}else{
		    insertSQL.append( ", \"" + fieldName + "\"" );		//,"fieldNameII"
		}		    
	    }
	}
	insertSQL.append( ") values ( ");					// ) values (
	String fieldValue = null;
	isFirst = true;
	FieldType ft = null;
	for( i=0; i<fieldCount; i++ ){
	    ft = tblFields[ i ].getFieldType();
	    fieldName = tblFields[ i].getFieldName();
	    fieldValue = rec.get( fieldName );

	    if( rec.containsField( fieldName ) ){
		if( isFirst ){
		    if( fieldValue == null ){
			insertSQL.append( "null" );				// null
		    }else{
			if( ft.isNumeric() ){
			    insertSQL.append( fieldValue );			// value1
			}else if(ft.isDate()){
			    insertSQL.append( "TO_DATE(\'"+ StringFormatter.getDate(SQLQuoteEncoder.encode( fieldValue )) + "\',\'mm/dd/yyyy\')" );	// 'value1'
			}else{
			    insertSQL.append( "\'"+ SQLQuoteEncoder.encode( fieldValue ) + "\'" );	// 'value1'
			}

		    }
		    isFirst = false;
		}else{
		    if( fieldValue == null ){
			insertSQL.append( ",null" );				// null
		    }else{
			if( ft.isNumeric() ){
			    insertSQL.append( ", " + fieldValue );		//, value2
			}else if(ft.isDate()){
			    insertSQL.append( ", TO_DATE(\'"+  StringFormatter.getDate(SQLQuoteEncoder.encode( fieldValue )) + "\',\'mm/dd/yyyy\')" );	//, 'value2'
			}else{
			    insertSQL.append( ", \'"+  SQLQuoteEncoder.encode( fieldValue ) + "\'" );	//, 'value2'
			}
		    }
		}
	    }
	}
	insertSQL.append( ")" );						// ) query build ends
	
	return executeUpdate( insertSQL.toString() );
    }
    /******************************************************************************************/



    /******************************************************************************************/
    /**
     * update record in specified record
     * @param tableName name of the table to update
     * @param oldRec old record which is to be updated
     * @param newRec new record which holds the new value
     * @returns number of records updated
     * @throws Exception on failure.
     */ 
    public int updateRecord( String tableName, Record oldRec, Record newRec) throws Exception{
	
	if( tableName == null || oldRec==null || newRec==null || oldRec.size() <=0 || newRec.size() <=0 )
	    return 0;
	DBTables dbTables = daoF.getDBTables();
	ScrubField [] tblFields = dbTables.getScrubFields( tableName );
	StringBuffer updateSQL = new StringBuffer( QSIZE );

	String [] oldRecFields = oldRec.getFieldNames();
	String [] newRecFields = newRec.getFieldNames();
	boolean isFirst = true;
	int i = 0;
	int fieldCount = tblFields.length;

	String oldFieldValue = null, newFieldValue = null;
	String fieldName = null;
	FieldType ft = null;
	int fieldAdded = 0;
	//update only if there are data
	if( oldRecFields.length > 0 && newRecFields.length > 0 ){
	    updateSQL.append( "update \"" + tableName + "\" " );			// update "tableName"
	    for( i=0; i<fieldCount; i++){
		fieldName = tblFields[ i].getFieldName();
		ft = tblFields[ i].getFieldType();
		oldFieldValue = oldRec.get( fieldName );
		newFieldValue = newRec.get( fieldName );
		
		if( newRec.containsField( fieldName )  && newFieldValue != null
		    && !newFieldValue.equals( oldFieldValue) ){
		    if( isFirst ){
			updateSQL.append(" set \"" + fieldName + "\" = " );		// set "fieldName" =
			if( ft.isNumeric() ) updateSQL.append( newFieldValue );		// newFieldValue
            else if(ft.isDate()) updateSQL.append( "TO_DATE(\'" +  StringFormatter.getDate(SQLQuoteEncoder.encode( newFieldValue )) + "\',\'mm/dd/yyyy\')");
			else updateSQL.append( "\'" +  SQLQuoteEncoder.encode( newFieldValue ) + "\'");// "newFieldValue"
			isFirst = false;
		    }else{
			updateSQL.append(", \"" + fieldName + "\" = " );		//, "fieldName" =
			if( ft.isNumeric() ) updateSQL.append( newFieldValue );		// newFieldValue
            else if(ft.isDate()) updateSQL.append( "TO_DATE(\'" +  StringFormatter.getDate(SQLQuoteEncoder.encode( newFieldValue ))+ "\',\'mm/dd/yyyy\')");					// "newFieldValue"
			else updateSQL.append( "\'" +  SQLQuoteEncoder.encode( newFieldValue )+ "\'");					// "newFieldValue"
		    }
		    fieldAdded++;
		}
	    }		
	}
	// where clause
	updateSQL.append( " where 1=1 ");						//where 1=1
	
	ScrubField [] pkScrubFields= dbTables.getPKScrubFields( tableName );
	if ( pkScrubFields != null && pkScrubFields.length > 0 ) {
	    //update based on primary key
	    //blank and null value for primary key are not checked
	    //as they are always checked by primary key rule.

	    for( i=0; i<pkScrubFields.length; i++){
		fieldName = pkScrubFields[i].getFieldName();
		ft = pkScrubFields[i].getFieldType();
		oldFieldValue = oldRec.get( fieldName );
		if( ft.isNumeric() ){
		    updateSQL.append( " and \"" + fieldName + "\" = " + oldFieldValue  );
		    //and "fieldName" = oldFieldValue
		}
       	else if( ft.isDate() ){
		    updateSQL.append( " and \"" + fieldName + "\" = TO_DATE(\'" +
                        StringFormatter.getDate(SQLQuoteEncoder.encode(oldFieldValue)) + "\',\'mm/dd/yyyy\')");
		    //and "fieldName" = oldFieldValue
		}
        else{
		    updateSQL.append( " and \"" + fieldName + "\" = \'"
				      +  SQLQuoteEncoder.encode( oldFieldValue ) + "\' ");
		    // and "fieldName"='oldFieldValue'
		}
	    }
	} else {
	    for( i=0; fieldAdded>0 && i<fieldCount; i++) {
		fieldName = tblFields[ i].getFieldName();
		ft = tblFields[ i].getFieldType();
		if( oldRec.containsField( fieldName ) ){
		    oldFieldValue = oldRec.get( fieldName );
		    if( oldFieldValue == null ){
			if( ft.isNumeric() ){
			    updateSQL.append( " and \"" + fieldName + "\" is null ");	// and "fieldName" is null
			}else{
			    updateSQL.append( " and (\"" + fieldName + "\" is null  ");	// and ( "fieldName" is null
			    updateSQL.append( " or \"" + fieldName + "\" = '' )" );		//	or fieldName = '' )
			}
		    }else{
			if( ft.isNumeric() ){
			    updateSQL.append( " and \"" + fieldName + "\" = " + oldFieldValue  );
			    //and "fieldName" = oldFieldValue
			}else if( ft.isDate() ){
			    updateSQL.append( " and \"" + fieldName + "\" = TO_DATE(\'"
					      +   StringFormatter.getDate(SQLQuoteEncoder.encode( oldFieldValue )) + "\','mm/dd/yyyy') ");
			    // and "fieldName"='oldFieldValue'
			}else{
			    updateSQL.append( " and \"" + fieldName + "\" = \'"
					      +  SQLQuoteEncoder.encode( oldFieldValue ) + "\' ");
			    // and "fieldName"='oldFieldValue'
			}
		    }
		}
	    }
	}
	//System.out.println( updateSQL.toString() );
	if( fieldAdded < 1)
	    return 0;
	return executeUpdate( updateSQL.toString() );
    }
    /******************************************************************************************/


    /**
     * Desc: Query to get expired contract dates with their corresponding P Analysis year if available.
     * This is similar to browse function as above just that it shows expired contract dates only.
     * Author: Anjana
     * DateL May 18, 2007
     * @param tableName table to browse (not a query)
     * @param afilter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @return ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */
    public ScrubTable showExpiredContracts(String tableName, RequestData [] afilter,
			      String orderField, String order,
			      ScrubTable scrubTable ) throws Exception{
        if( tableName == null ){
	        throw new IllegalArgumentException("Null table name is not allowed at TableDAOImpl");
	    }
        if( scrubTable == null ){
            throw new NullPointerException("Uninitialized ScrubTable at TableDAOImpl");
        }

	    StringBuffer browseSQL = new StringBuffer( QSIZE );

        if (tableName.equalsIgnoreCase("HR_Global_TPA") || tableName.equalsIgnoreCase("HR_Global_TPA_ContractDates"))
        {
            browseSQL.append("Select a.* from " +tableName+ " a, " +
                        tableName+ " b, HR_Global_RunDates c where" +
                        " a.CaseID = b.CaseID and a.TPAID = b.TPAID and a.ClientID = b.ClientID and b.AnalysisYear = 'C'" +
                        " and b.contractyearenddate < c.CycleEndDate" +
                        " and b.clientid = c.clientid");
           System.out.println("TabledaoImple.showExpiredContracts >1<  "+browseSQL); 

        }
        DBTables dbTables = daoF.getDBTables();
        ScrubField [] tblFields = dbTables.getScrubFields( tableName );
        String fieldName = null;
        String [] fieldValues = null;
        String filterCriteria = null;
        boolean isValidOrderField = false;
        RequestData filter = null;

        /* APPLY FILTER CRITERIA FROM EVERY REQUEST DATA AS FAR AS APPLICABLE */
        if( afilter != null && afilter.length>0){
	    //System.out.println(">>filter not null" + filter.toString() );
            ParserFactory pf = daoF.getParserFactory();
            FieldType ft = null;
            int fieldCount = tblFields.length;
            int i=0;
            int parserType, fieldType;
            Parser parser = null;
            //System.out.println("The filter lenth is: "+afilter.length);
            for( int fndx=0; fndx < afilter.length; fndx++){
            filter = afilter[ fndx];

		    for( i=0; filter!=null && i<fieldCount; i++ ){
                fieldName = tblFields[i].getFieldName();
                System.out.println(">>=fieldname :"+fieldName);
                if( !isValidOrderField && fieldName.equals(orderField ) ){
                    isValidOrderField = true;
                }
                //System.out.println("::::check"+filter.containsKey( fieldName ) );
                if( filter.containsKey( fieldName )){
                //System.out.println(" contains "+fieldName);
                    ft = tblFields[i].getFieldType();
                    fieldType = ft.getFieldType();
                    fieldValues = filter.getParameters(fieldName);
                    parserType = FieldTypeMap.getParserType(fieldType);
                    parser = pf.getParser( parserType );

                    boolean isFirstValue = true;
                    boolean isFilterApplied = false;

                //fieldName is the one used for comparision. double quote is not added by parser
                // as alias may be any formula for parser.
                    for( int ndxValue = 0; ndxValue<fieldValues.length; ndxValue++){

                        filterCriteria = parser.parse(  "\"" + fieldName + "\"", fieldValues[ ndxValue]  );

                        if( !"".equals( filterCriteria ) ){
                        if( isFirstValue ){
                            browseSQL.append( " and ( " + filterCriteria );
                            isFirstValue = false;
                        }else{
                            browseSQL.append( " or " + filterCriteria );
                        }
                        isFilterApplied = true;
                        }
                    }
                        if( isFilterApplied){
                        browseSQL.append( " ) ");
                        }
		            }
		        }
	        }
	    }
        System.out.println("TabledaoImple.showExpiredContracts >2<  " +browseSQL );
        scrubTable.setSetSize( getSetSize( browseSQL.toString() ) );

        if( isValidOrderField ){
            browseSQL.append(" order by \"" + orderField + "\" ");
            if( "DESC".equalsIgnoreCase( order ) ){
            browseSQL.append( " DESC " );
            }else{
            browseSQL.append( " ASC ");
            }
        }
         System.out.println(browseSQL);
        /*------------------------------------------------------*/
        /*	load scrubTable with data			*/
        Connection cnn = null;
        Statement stmt = null;
        ResultSet rs = null;
        //resources will be released as required by scrubTable itself on its close() method call.
        cnn = daoF.getConnection();
        stmt = cnn.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY );
        System.out.println("TabledaoImple.showExpiredContracts >3<  " +browseSQL.toString()+"\n***");     
        rs = stmt.executeQuery( browseSQL.toString() );
        
        scrubTable.init( daoF.getDBMSSupportedFieldTypes(), cnn, stmt, rs );
        return scrubTable;
    }


    /******************************************************************************************/
    /**
     * Desc: Renews contract date by 1 year, sets the original C to P
     * Author: Anjana
     * Date: Apr 2007
     * @param tableName
     * @param rec
     * @return
     * @throws Exception
     */
    public int renewContractDate(String tableName, Record rec) throws Exception
    {
        if(tableName==null || rec==null || rec.size() <=0 )
    	    return 0;
            DBTables dbTables = daoF.getDBTables();
            ScrubField [] tblFields = dbTables.getScrubFields(tableName);
            String fieldName = null;

            int fieldCount = tblFields.length;
            int i=0;
            String fieldValue = null;
            FieldType ft = null;
            int fieldAdded = 0;
            boolean isFirst = true;
            String thisCaseID = rec.get("CaseID");
            String thisClientID = rec.get("ClientID");
            System.out.println("\nCLIENT ID IS...." + thisClientID);
            /**thisClientID = rec.get("a.ClientID");
            System.out.println("\na.CLIENT ID IS...." + thisClientID);**/
            String thisTPAID = rec.get("TPAID");
            StringBuffer renewSQL = new StringBuffer(QSIZE ); //to renew the current contract
            
           
            
            
            String deletePreviousRecord=" Delete from "+tableName +
            							" where ClientID = '" +thisClientID+ "' and TPAID = '" +thisTPAID+ "' and CaseID = '" +thisCaseID+ "' and AnalysisYear = 'P'";
            String updateCurrentAsPrevious= " Update "+tableName+" set AnalysisYear='P' " +
            								" where ClientID = '" +thisClientID+ "' and TPAID = '" +thisTPAID+ "' and CaseID = '" +thisCaseID+ "' and AnalysisYear = 'C'";
            
            String columns="";
            for(i=0; i<fieldCount; i++){
                fieldName = tblFields[i].getFieldName();
    		    if(fieldName.equals("CONTRACTYEARBEGINDATE")){
    		    	columns+="CONTRACTYEARENDDATE+1 ";
    		    }else
    		    if(fieldName.equals("CONTRACTYEARENDDATE")){
	                columns+="add_months(CONTRACTYEARENDDATE,12) ";
	    	    }else
    		    if(fieldName.equals("ANALYSISYEAR")){
	                columns+="'C'";
	    	    }else{
	    	    	columns+=fieldName;
	    	    }
    		    
    		    if(i+1<fieldCount){
    		    	columns+=",";
    		    }
    	    }
            
            String insertCurrent=	" Insert into "+tableName+
            						" select  " + columns+
            						" from " +tableName+
            						" where ClientID = '" +thisClientID+ "' and TPAID = '" +thisTPAID+ "' and CaseID = '" +thisCaseID+ "' and AnalysisYear = 'P'";
            
            renewSQL.append(" BEGIN ");
            renewSQL.append(" EXECUTE IMMEDIATE '"+SQLQuoteEncoder.encode(deletePreviousRecord)+"'; ");
            renewSQL.append(" EXECUTE IMMEDIATE '"+SQLQuoteEncoder.encode(updateCurrentAsPrevious)+"'; ");
            renewSQL.append(" EXECUTE IMMEDIATE '"+SQLQuoteEncoder.encode(insertCurrent)+"'; ");
            renewSQL.append(" END; ");
            
            
            System.out.println("BEFORE LAST EXECUTE UPDATE - renewSQL"+renewSQL.toString());
    	    return executeUpdate(renewSQL.toString());
        }


    /******************************************************************************************/    
    /**
     * delete specified record
     * @param tableName name of the table
     * @param rec record to delete
     * @returns number of records deleted
     * @throws Exception on failure
     * warning for null record no operation is performed
     * but non null record with no fields can wipe out data from the specified table !!!
     */
    public int deleteRecord( String tableName, Record rec) throws Exception{
	if( tableName==null || rec==null || rec.size() <=0 )
	    return 0;
	DBTables dbTables = daoF.getDBTables();
	ScrubField [] tblFields = dbTables.getScrubFields( tableName );
	String fieldName = null;
	
	int fieldCount = tblFields.length;
	int i=0;
	String fieldValue = null;
	FieldType ft = null;
	int fieldAdded = 0;
	
	StringBuffer delSQL = new StringBuffer( QSIZE );
	delSQL.append("delete \"" + tableName + "\" where 1=1 " );	// delete tableName where 1=1

	ScrubField [] pkScrubFields= dbTables.getPKScrubFields( tableName );

	if ( pkScrubFields != null && pkScrubFields.length > 0 ) {
	    //update based on primary key
	    //blank and null value for primary key are not checked
	    //as they are always checked by primary key rule.
	    for( i=0; i<pkScrubFields.length; i++){
		fieldName = pkScrubFields[i].getFieldName();
		ft = pkScrubFields[i].getFieldType();
		fieldValue = rec.get( fieldName );

		if( ft.isNumeric() ){
		    delSQL.append( " and \"" + fieldName + "\" = " + fieldValue  );
		    //and "fieldName" = fieldValue
		}else if( ft.isDate() ){
		    delSQL.append( " and \"" + fieldName + "\" = TO_DATE(\'"
				   +  StringFormatter.getDate(SQLQuoteEncoder.encode( fieldValue )) + "\',\'mm/dd/yyyy\') ");
		    // and "fieldName"='fieldValue'
		}else{
		    delSQL.append( " and \"" + fieldName + "\" = \'"
				   +  SQLQuoteEncoder.encode( fieldValue ) + "\' ");
		    // and "fieldName"='fieldValue'
		}
		fieldAdded++;
	    }
	} else {
	    for( i=0; i<fieldCount; i++){
		fieldName = tblFields[ i].getFieldName();
		if( rec.containsField( fieldName ) ){
		    ft = tblFields[ i].getFieldType();
		    fieldValue = rec.get( fieldName );
		    if( fieldValue == null ){
			if( ft.isNumeric() ){
			    delSQL.append( " and \"" + fieldName + "\" is null "); // and "fieldName" is null
			}else{
			    delSQL.append( " and ( \"" + fieldName + "\" is null " ); // and ( "fieldName" is null
			    delSQL.append( " or \"" + fieldName + "\" = '' ) " );	// or "fieldName = '' )
			}
		    }else{
			if( ft.isNumeric() ){
			    delSQL.append( " and \"" + fieldName + "\" = "
					   + fieldValue );			// and "fieldName" = fieldValue
			}else if( ft.isDate() ){
			    delSQL.append( " and \"" + fieldName + "\" = TO_DATE(\'"
					   + StringFormatter.getDate(SQLQuoteEncoder.encode(fieldValue)) + "\',\'mm/dd/yyyy\') ");
			    // and "fieldName" = fieldValue
			}else{
			    delSQL.append( " and \"" + fieldName + "\" = \'"
					   + SQLQuoteEncoder.encode(fieldValue) + "\' ");
			    // and "fieldName" = fieldValue
			}
		    }
		    fieldAdded++;
		}
	    }
	}
	if( fieldAdded < 1)
	    return 0;
	return executeUpdate( delSQL.toString() );
    }
    /******************************************************************************************/




    /******************************************************************************************/
    /**
     * browse specified table
     * strict warning !!! NOT FOR QUERY !!!
     * @param tableName table to browse (not a query)
     * @param filter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @returns ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */
    public ScrubTable browse( String tableName, RequestData [] afilter,
			      String orderField, String order,
			      ScrubTable scrubTable ) throws Exception{

	if( tableName == null ){
	    throw new IllegalArgumentException("Null table name is not allowed at TableDAOImpl");
	}
	if( scrubTable == null ){
	    throw new NullPointerException("Uninitialized ScrubTable at TableDAOImpl");
	}

	StringBuffer browseSQL = new StringBuffer( QSIZE );
	
/********************************************************************************************************************************************************8
	 * Added for renewing contractdate
	 * Subash Devkota
	 * 05/24/2007
	 */
	if (tableName.equalsIgnoreCase("HR_Global_TPA") || tableName.equalsIgnoreCase("HR_Global_TPA_ContractDates"))
        //Adding one more column that returns values EXP or FINE based on whether the contract date for the client case is expired.
        {
            browseSQL.append("select a.*, \n" +
                    "CASE\n" +
                    "WHEN a.contractyearenddate < b.CycleEndDate AND a.AnalysisYear = 'C' THEN 'EXP'\n" +
                    "ELSE 'FINE'\n" +
                    "END AS EXPIRED\n" +
                    "\n" +
                    "from "+tableName+" a, HR_Global_RunDates b \n" +
                    "where \n" +
                    "a.clientid = b.clientid\n");
        }
        else
        {
            browseSQL.append( "select * from \"" + tableName + "\"  where 1=1 ");
        }
    
	//browseSQL.append( "select * from \"" + tableName + "\"  where 1=1 ");
    
/************************************ End of addition for expired contract date renew********************************************************************/
	
	DBTables dbTables = daoF.getDBTables();
	ScrubField [] tblFields = dbTables.getScrubFields( tableName );
	String fieldName = null;
	String [] fieldValues = null;
	String filterCriteria = null;
	boolean isValidOrderField = false;
	RequestData filter = null;

	/* APPLY FILTER CRITERIA FROM EVERY REQUEST DATA AS FAR AS APPLICABLE */
	if( afilter != null && afilter.length>0){
	    //System.out.println(">>filter not null" + filter.toString() );
	    ParserFactory pf = daoF.getParserFactory();
	    FieldType ft = null;
	    int fieldCount = tblFields.length;
	    int i=0;
	    int parserType, fieldType;
	    Parser parser = null;
	    
	    /**
         * Following code added by Anjana - May 21, 2007
         * in order to check if only EXPIRED contract dates are to be shown.
         */
        String expired = "";
        for(int fndx=0; fndx < afilter.length; fndx++){
		    filter = afilter[fndx];
			 System.out.println("Expired is y.......................");
                         System.out.println("Filter is "+ filter);
	         if (filter!= null)
	         {
	             if (filter.containsKey("Expired") && (tableName.equalsIgnoreCase("HR_Global_TPA") || tableName.equalsIgnoreCase("HR_Global_TPA_ContractDates")))
	             {
	                 System.out.println("Filter contains Expired.......................");
	                 expired = filter.getParameter("Expired");
	                 System.out.println("Value of Expired is " +expired);
	                 if (expired.equalsIgnoreCase("y"))
	                 {
	                     System.out.println("Inside if condition");
	                     browseSQL = new StringBuffer("");
	                     browseSQL.append("Select a.* from " +tableName+ " a, " +
	                     tableName+ " b, HR_Global_RunDates c where" +
	                     " a.CaseID = b.CaseID and a.TPAID = b.TPAID and a.ClientID = b.ClientID and b.AnalysisYear = 'C'" +
	                     " and b.contractyearenddate < c.CycleEndDate" +
	                     " and b.clientid = c.clientid");
	                     System.out.println("TableDAOImple >10< " +browseSQL.toString());
	                 }
	             }
	         }
	    }// End of code added by Anjana
		
        for( int fndx=0; fndx < afilter.length; fndx++){
            filter = afilter[ fndx];
	        for( i=0; filter!=null && i<fieldCount; i++ ){
                fieldName = tblFields[ i].getFieldName();
                //System.out.println(">>=fieldname :"+fieldName);
                if( !isValidOrderField && fieldName.equals(orderField ) ){
                    isValidOrderField = true;
                }
                //System.out.println("::::check"+filter.containsKey( fieldName ) );
                //if( filter.containsKey( fieldName ) || fieldName.equalsIgnoreCase("a.ClientID")){
                //if( filter.containsKey( fieldName ) || fieldName.equalsIgnoreCase("a.ClientID")){
                if( filter.containsKey( fieldName )){
                //System.out.println(" contains "+fieldName);
                    ft = tblFields[i].getFieldType();
                    fieldType = ft.getFieldType();
                        /*if (fieldName.equalsIgnoreCase("a.ClientID"))
                        {
                            System.out.println("####################################################");
                            fieldValues = filter.getParameters("ClientID");
                        } */
                        //else
                        {
                            fieldValues = filter.getParameters(fieldName);
                        }
                    parserType = FieldTypeMap.getParserType(fieldType);
                    parser = pf.getParser( parserType );

                    boolean isFirstValue = true;
                    boolean isFilterApplied = false;

                    //fieldName is the one used for comparision. double quote is not added by parser
                    // as alias may be any formula for parser.

                    if ((tableName.equalsIgnoreCase("HR_Global_TPA") || tableName.equalsIgnoreCase("HR_Global_TPA_ContractDates")) && !fieldName.equalsIgnoreCase("EXPIRED"))
                        fieldName = "a."+fieldName;
                        for( int ndxValue = 0; ndxValue<fieldValues.length; ndxValue++){

                            if (fieldName.equalsIgnoreCase("EXPIRED"))
                            {
                                filterCriteria = "";
                            }
                            else
                            {
                                filterCriteria = parser.parse(fieldName, fieldValues[ ndxValue]  );
                            }
                            /*else
                            {
                                filterCriteria = parser.parse(  "\"" + fieldName + "\"", fieldValues[ ndxValue]  );
                            }*/
                            if( !"".equals( filterCriteria ) ){

                                if( isFirstValue ){
                                    browseSQL.append( " and ( " + filterCriteria );
                                    isFirstValue = false;
                                }else{
                                    browseSQL.append( " or " + filterCriteria );
                                }
                                isFilterApplied = true;

                            }
                        }
                        if( isFilterApplied){
                            browseSQL.append( " ) ");
                        }
                    }
                }
	    }
	}
	System.out.println("TableDAOImple >9< " + browseSQL.toString() );
	scrubTable.setSetSize( getSetSize( browseSQL.toString() ) );
	 
	if (tableName.equalsIgnoreCase("HR_Global_TPA") || tableName.equalsIgnoreCase("HR_Global_TPA_ContractDates"))
         orderField = "a." + orderField;
	 
	if( isValidOrderField ){
	    browseSQL.append(" order by " + orderField + " ");
	    if( "DESC".equalsIgnoreCase( order ) ){
		browseSQL.append( " DESC " );
	    }else{
		browseSQL.append( " ASC ");
	    }
	}else{   /// Default sort in case of these two tables
		if (tableName.equalsIgnoreCase("HR_Global_TPA") || tableName.equalsIgnoreCase("HR_Global_TPA_ContractDates")){
			browseSQL.append(" order by a.clientid ");
		}
	}
	/*------------------------------------------------------*/
	/*	load scrubTable with data			*/
        System.out.println("\n**I am inside TableDAOImpl >>11<<**\n"+browseSQL.toString()+"\n***");
        
	Connection cnn = null;
	Statement stmt = null;
	ResultSet rs = null;
	//resources will be released as required by scrubTable itself on its close() method call.
	cnn = daoF.getConnection();
	stmt = cnn.createStatement( ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY );
	
        rs = stmt.executeQuery( browseSQL.toString() );
	scrubTable.init( daoF.getDBMSSupportedFieldTypes(), cnn, stmt, rs );	    
	return scrubTable;
    }
    /******************************************************************************************/




    /******************************************************************************************/
    /**
     * @param unOrderedQuery sql query without ordering clause
     */
    private int getSetSize( String unOrderedQuery ) throws Exception{
	Connection cnn = null;
	Statement stmt = null;
	ResultSet rs = null;
	int recCount = -1;
	String countSQL = "select count(*) from (" + unOrderedQuery + ") cntSet ";

	try{
	    cnn = daoF.getConnection();
	    stmt= cnn.createStatement();
	    rs  = stmt.executeQuery( countSQL);

	    if( rs.next() ){
		recCount = rs.getInt( 1);
	    }
	}finally{
	    daoF.release( cnn, stmt, rs );
	}
	return recCount;
    }
    /******************************************************************************************/




    /******************************************************************************************/
    /**
     * execute insert, update, and delete queries
     * @param query sql query to execute ( insert,update or delete )
     * @returns number of rows affected
     * @throws Exception on query execution failure
     */
    protected int executeUpdate( String query ) throws Exception{
	System.out.println("\n***\nQuery----------\n"+query );
	Connection cnn = null;
	Statement stmt = null;
	int affectedRows = 0;
	try{	    
	    cnn = daoF.getConnection();
	    stmt = cnn.createStatement();
	    affectedRows = stmt.executeUpdate( query );
	}finally{
	    daoF.release( cnn, stmt, null );
	}
	return affectedRows;
    }
    /******************************************************************************************/




    /******************************************************************************************/
    /**
     * @param tableName name of the table for which record has to be counted
     * @param fieldValues of Record type containg fields and correspondig values for search criteria
     * @returns number of records satisfying the criteria, inapplicable fields are ignored
     * @throws Exception on backend problem
     */
    public int getRecordCount( String tableName, Record fieldValues) throws Exception{
	if( tableName == null ){
	    throw new NullPointerException("Record count on null table");
	}
	Connection cnn = null;
	Statement stmt = null;
	ResultSet rs = null;
	int rowCount = 0;
	StringBuffer sb = new StringBuffer( 100 );
		
	sb.append( "select count(*) from \"");
	sb.append( tableName );
	sb.append( "\" where 1=1 ");					/* SELECT count(*) FROM "tableName" WHERE 1=1 */
	
	try{
	    if( fieldValues != null && !fieldValues.isEmpty() ){
		DBTables db = daoF.getDBTables();
		ScrubField [] sfs  = db.getScrubFields( tableName );
		for( int i=0; sfs != null && i<sfs.length; i++){
		    if( fieldValues.containsField( sfs[ i].getFieldName() ) ){
			sb.append( " and ( "   );			// AND (
			sb.append( " \"" + sfs[ i].getFieldName() + "\" " );
			String fldValue = fieldValues.get( sfs[ i].getFieldName() ) ;
			if( sfs[ i ].isNumeric() ){
			     /********** NUMERIC **********/
			    if( fldValue == null){
				sb.append( " is null " );		// fld IS NULL
			    }else{
				sb.append( " = " + fldValue );		// fld = fldValue
			    }
			}
            else if( sfs[ i ].isDate ()){
			    /*********** DATE **********/
			    if ( fldValue == null ){			// fld IS NULL OR LTRIM(RTRIM (fld) ) =''
				sb.append( " is null" );
			    }else{					// fld = 'fldValue'
				sb.append( " = TO_DATE(\'" + StringFormatter.getDate(SQLQuoteEncoder.encode( fldValue )) + "\',\'mm/dd/yyyy\') " );
			    }
			}
            else {
			    /*********** NON NUMERIC **********/
			    if ( fldValue == null ){			// fld IS NULL OR LTRIM(RTRIM (fld) ) =''
				sb.append( " is null or ltrim(rtrim(\"" + sfs[ i].getFieldName() + "\")) = '' " );
			    }else{					// fld = 'fldValue'
				sb.append( " = '" + SQLQuoteEncoder.encode( fldValue ) + "' " );
			    }
			}
			sb.append( " ) " );
		    }
		}
	    }
	    cnn = daoF.getConnection();
	    stmt = cnn.createStatement();
	    
	    rs = stmt.executeQuery( sb.toString() );
	    rs.next();
	    rowCount = rs.getInt( 1);
	}finally{
	    daoF.release( cnn, stmt, rs);
	}
	
	return rowCount;
    }
    /******************************************************************************************/




    /******************************************************************************************/
}
