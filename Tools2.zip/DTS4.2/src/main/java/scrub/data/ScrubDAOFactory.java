package scrub.data;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import scrub.datatype.DBMSManager;
import scrub.datatype.DBMSSupportedFieldTypes;

import scrub.util.text.ParserFactory;

/**
 * interface for accessing DBMS specific access classes
 */
public interface ScrubDAOFactory{

    /**
     * @param sourceAlias alias refering to some data source.
     */
    void setSourceAlias( String sourceAlias);

    /** @returns source alias */
    String getSourceAlias();

    /**
     * @returns Connection which will be used by the components created by this type of component
     * @throws Exception if failed to connect with the server.
     */
    Connection getConnection() throws Exception;
    
    /**
     * @returns DBMSManager which provides DBMS specific info.
     */
    DBMSManager getDBMSManager();

    /**
     * @returns DBMSSupportedFieldTypes
     */
    DBMSSupportedFieldTypes getDBMSSupportedFieldTypes();

    /**
     * @returns DBTables used for accessing database tables info (fields, field types etc. )
     */
    DBTables getDBTables();

    /**
     * @returns TableDAO used for accessing database tables
     */
    TableDAO getTableDAO();

    /**
     * @returns ParserFactory depending upon the type of DBMS.
     * ParserFactory is generally used for filtering operation during data access.
     */
    ParserFactory getParserFactory();

    /**
     * release database resources
     * @param cnn Connection to close
     * @param stmt Statement to close
     * @param rs ResultSet to close
     */
    void release( Connection cnn, Statement stmt, ResultSet rs);
    
}
