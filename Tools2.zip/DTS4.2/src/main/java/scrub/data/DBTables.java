package scrub.data;

import java.util.List;

import scrub.datatransfer.ScrubField;

/**
 * defines interface for accessing table related data from database
 */
public interface DBTables{
    /**
     * @param prefix prefix used for table name
     * @returns list of table names with the specified prefix
     * returns name of all tables if prefix is null
     * @throws Exception if fails to fetch table names due to technical reason.
     */
    List getTableNameList( String prefix ) throws Exception;

    /**
     * @param tableName name of table or query from which ScrubField (fields info) has to be accessed.
     * @returns array containing ScrubField s. (field names and field types)
     * @throws Exception on failure to access the DBMS
     */
    ScrubField [] getScrubFields( String tableName) throws Exception;

    /**
     * @param tableName name of the table for which primary key fields are to be found
     * @returns string array containing field names for primary key
     * @throws Exception on backend problem
     */
    String [] getPKFields( String tableName) throws Exception;

    /**
     * @param tableName name of the table for which primary key fields are to be found
     * @returns array containing field names encapsulated as ScrubField for primary key
     * @throws Exception on backend problem
     */
    ScrubField [] getPKScrubFields( String tableName) throws Exception;

}
