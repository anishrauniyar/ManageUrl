package scrub.data;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;


import scrub.util.ConnectionSource;
import scrub.util.ConnectionSourceFactory;


/**
 * refers master database
 */


public abstract class MasterDB{

    /** server name */
   // protected static  String SERVER = "SQLServer";
     protected static  String SERVER = "ORCL";

    /*--------------------------------------------------*/
    protected static ConnectionSourceFactory cnnSrcF = ConnectionSourceFactory.getInstance();
    protected static final String MASTER_DB = "MDHawkeye->HawkeyeMaster";
    /*--------------------------------------------------*/

    /** alias refering to data source */
    protected String sourceAlias = MASTER_DB;
    public String getSourceAlias(){
	return sourceAlias;
    }
    public void setSourceAlias( String s) {
	sourceAlias = s;
    }

   /**
     * @returns Connection to the DBMS
     * @throws SQLException on problem with DBMS
     */
    public Connection getConnection() throws Exception{
	    return ( cnnSrcF.getConnectionSource() ).getConnection( sourceAlias ) ;
    }
 

}











