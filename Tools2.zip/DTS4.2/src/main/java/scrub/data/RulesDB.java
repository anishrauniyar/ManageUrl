package scrub.data;

/**
 * refers master database
 */


public class RulesDB extends MasterDB{

    /*--------------------------------------------------*/
    protected static final String RULES_DB = "MDHawkeye->HawkeyeRule";
    /*--------------------------------------------------*/

    public RulesDB(){
	setSourceAlias( RULES_DB);
    }
}











