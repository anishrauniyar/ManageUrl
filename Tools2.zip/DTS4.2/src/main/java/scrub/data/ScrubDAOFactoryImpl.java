package scrub.data;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;

import scrub.datatype.DBMSManagerFactory;
import scrub.datatype.DBMSManager;
import scrub.datatype.DBMSSupportedFieldTypes;

import scrub.util.text.ParserFactory;
import scrub.util.text.ParserFactorySelector;
import scrub.util.ReleaseDB;

/**
 * implementation of ScrubDAOFactory
 */
public class ScrubDAOFactoryImpl  extends RulesDB implements ScrubDAOFactory {

    
    /* Accessing DBMSManagerFactory */
    private static DBMSManagerFactory dbmsFactory = DBMSManagerFactory.getInstance();

    /** DBMSManager for SQL Server*/
    protected static DBMSManager dbmsManager = dbmsFactory.getDBMSManager( SERVER );

    /** DBMS Supported FieldTypes for SQL Server */
    protected static DBMSSupportedFieldTypes supportedFieldTypes = dbmsManager.getDBMSSupportedFieldTypes();


    /** default constructor */
    protected ScrubDAOFactoryImpl(){
    }

    /** @returns DBMSManager for SQL server */
    public  DBMSManager getDBMSManager(){
	return dbmsManager;
    }

    /** @returns DBMSSupportedFieldTypes */
    public DBMSSupportedFieldTypes getDBMSSupportedFieldTypes(){
	return supportedFieldTypes;
    }


    /** @returns DBTables for accessing tables and their field types. */
    public DBTables getDBTables(){
	return new DBTablesImpl( this );
    }

    /**
     * @returns TableDAO for accessing database tables
     */
    public TableDAO getTableDAO(){
	return new TableDAOImpl( this );
    }

    /**
     * release database resources
     * @param cnn Connection to close
     * @param stmt Statement to close
     * @param rs ResultSet to close
     */
    public void release( Connection cnn, Statement stmt, ResultSet rs){
	ReleaseDB.releaseDBResources( cnn, stmt, rs);
    }
    /*------------------------------------------------------------*/
    public ParserFactory getParserFactory() {
	ParserFactorySelector pf = ParserFactorySelector.getInstance();
	return pf.getParserFactory( SERVER );
    }
}
