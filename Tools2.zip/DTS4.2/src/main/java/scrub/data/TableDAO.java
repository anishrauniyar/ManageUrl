package scrub.data;

import scrub.datatransfer.Record;
import scrub.datatransfer.ScrubTable;
import scrub.util.RequestData;

/**
 * interface for accessing tables and modifying data
 */
public interface TableDAO{

    /**
     * insert record into a table
     * @param tableName name of the table in which to append record
     * @param rec record to insert
     * @returns number of records inserted
     * @throws Exception on failure to connect to the database or failed to insert record
     */
    int insertRecord( String tableName, Record rec) throws Exception;

    /**
     * update record in specified record
     * @param tableName name of the table to update
     * @param oldRec old record which is to be updated
     * @param newRec new record which holds the new value
     * @returns number of records updated
     * @throws Exception on failure.
     */ 
    int updateRecord( String tableName, Record oldRec, Record newRec) throws Exception;

    /**
     * delete specified record
     * @param tableName name of the table
     * @param rec record to delete
     * @returns number of records deleted
     * @throws Exception on failure
     */
    int deleteRecord( String tableName, Record rec) throws Exception;

    /**
     * @param tableName name of the table for which record has to be counted
     * @param fieldValues of Record type containg fields and correspondig values for search criteria
     * @returns number of records satisfying the criteria, inapplicable fields are ignored
     * @throws Exception on backend problem
     */
    int getRecordCount( String tableName, Record fieldValues) throws Exception;
    
    /**
     * browse specified table
     * @param tableName table to browse (not a query)
     * @param afilter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @returns ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */
    ScrubTable browse( String tableName, RequestData [] afilter,
		       String orderField, String order,
		       ScrubTable scrubTable ) throws Exception;
    
    
    
    /**
     * New implementatin - Anjana
     * Date: Mar 27, 2007
     * Desc: Renews the contract date by 1 year.
     * @param tableName 
     * @param fieldValues
     * @return
     * @throws Exception
     */
    int renewContractDate(String tableName, Record fieldValues) throws Exception;


     /**
     * Desc: Query to get expired contract dates with their corresponding P Analysis year if available.
         * This is similar to browse function as above just that it shows expired contract dates only.
     * Author: Anjana
     * DateL May 18, 2007
     * @param tableName table to browse (not a query)
     * @param afilter array of RequestData which specifies the filter criteria
     * @param orderField field by which to order
     * @param order ordering direction "ASC" if ascending , "DESC" if descending else ignored.
     * valid only if valid orderField is specified
     * @param scrubTable properly initialized ScrubTable to hold data
     * @return ScrubTable from which data for the table can be accessed
     * @throws Exception if problem with data access or scrubTable is not initialized
     */

    ScrubTable showExpiredContracts ( String tableName, RequestData [] afilter,
		       String orderField, String order,
		       ScrubTable scrubTable ) throws Exception;


}
