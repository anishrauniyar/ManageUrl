package scrub.data;

/**
 * builds ScrubDAOFactory based on DBMS or other resource type.
 */
public class ScrubDAOFactoryBuilder{
    
    /** default constructor */
    private ScrubDAOFactoryBuilder(){
    }

    private static ScrubDAOFactoryBuilder _self = null;
    private static ScrubDAOFactory daoF = null; 
    /**
     * create self if already not created
     * @returns ScrubDAOFactoryBuilder self
     */
    public static final synchronized ScrubDAOFactoryBuilder getInstance(){
	if( _self == null ){
	    daoF = new ScrubDAOFactoryImpl();
	    _self = new ScrubDAOFactoryBuilder();
	}
	return _self;
    }

    /**
     * @param serverType type of the server
     * @returns ScrubDAOFactory of appropriate type
     */
    public ScrubDAOFactory getScrubDAOFactory( String serverType   ) throws Exception{
	if( ! ("SQLServer".equalsIgnoreCase( serverType ) || "ORCL".equalsIgnoreCase( serverType ))){
	    throw new IllegalArgumentException("Unknow server type: " + serverType );
	}
	return daoF;
    }

    /**
     * @param alias alias refering to the datasource generally alias refering to database
     * @param serverTyep type of the server
     * @returns ScrubDAOFactory with datasoure set to the specified alias
     */
    public ScrubDAOFactory getScrubDAOFactory( String serverType, String sourceAlias) throws Exception{
	if(  !("SQLServer".equalsIgnoreCase( serverType ) || "ORCL".equalsIgnoreCase( serverType )) ){
	     throw new IllegalArgumentException("Unknow server type: " + serverType );
	}
	ScrubDAOFactory accessFactory = new ScrubDAOFactoryImpl();
	accessFactory.setSourceAlias( sourceAlias);
	return accessFactory;
    }
}


