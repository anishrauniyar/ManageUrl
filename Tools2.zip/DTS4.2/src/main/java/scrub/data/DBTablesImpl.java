package scrub.data;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import scrub.datatransfer.ScrubField;
import scrub.datatype.FieldType;
import scrub.datatype.DBMSSupportedFieldTypes;

/**
 * implementation of DBTables for accessing table info.
 */
public class DBTablesImpl implements DBTables{

    /** types of table names accessed, can be one of or all of SYNONYM, TABLE,VIEW : 
     * To pull views add "VIEW" in types array.
     * Added Change here to pull the view types of table, info Bhanu 
     * */
	
    protected static final String [] types
	= { "TABLE", "VIEW" };
    
    /** size for array creation etc. */
    protected static final int SIZE = 20;

    protected ScrubDAOFactory daoF = null;
    
    /** java related parameter for accessing table name */
    private static final String TABLE_NAME = "TABLE_NAME";
    
    /** restrict default constructor */
    private DBTablesImpl(){}

    /** @param f ScrubDAOFactory required for  accessing other modules */
    public DBTablesImpl( ScrubDAOFactory f){
	daoF = f;
    }
    /******************************************************************************************/



    /******************************************************************************************/
    /**
     * @param prefix prefix used for table name
     * @returns list of table names with the specified prefix
     * returns name of all tables if prefix is null
     * @throws Exception if failed to access datasource.
     */
    public List getTableNameList( String prefix ) throws Exception{
	Connection cnn = null;
	DatabaseMetaData dbmd = null;
	ResultSet rsTableNames = null;
	ArrayList tblList = new ArrayList( SIZE );
	String table_name = null;
	String prefixLC = null;
	
	/* lower case prefix is compared for case insensitivity */
	if( prefix != null ){
	    prefixLC = prefix.toLowerCase();
	}
	
	try{
	    cnn = daoF.getConnection();
	    dbmd = cnn.getMetaData();
	    rsTableNames = dbmd.getTables( null, "HAWKEYERULES", null, types );
	    while( rsTableNames.next() ){
		table_name = rsTableNames.getString( TABLE_NAME ) ;
		if( table_name != null ){
			System.out.println(">>>>>>>>>\n "+table_name);
		    if( prefix == null ){
			tblList.add( table_name );
		    }else{
			/* table name converted to lower case before matching prefix */
			if( table_name.toLowerCase().startsWith( prefixLC ) ){
			    tblList.add( table_name );
			}
		    }
		}
	    }
	}finally{
	    daoF.release( cnn, null, rsTableNames );
	}
	return tblList;
    }
    /******************************************************************************************/



    /******************************************************************************************/
    /**
     * @param tableName name of table or query
     * if tableName starts with "select ", it will be treated as query else it would be treated as a table.
     * @returns array containing ScrubField s. (field names and field types)
     * @throws Exception on failure to access the DBMS
     */
    public ScrubField [] getScrubFields( String tableName) throws Exception{
	if( tableName == null ) {
	    throw new NullPointerException("Null parameter not allowed for getFields()");
	}
	String query = null;
	if( isQuery( tableName ) ){
	    query = tableName;
	}else{
	    //query which doesn't match any record
	    query = "select * from \"" + tableName + "\" where 1=0";
	}
	Connection cnn = null;
	Statement stmt = null;
	ResultSet rs = null;
	ResultSetMetaData rsmd = null;
	int fieldCount = 0,
	    index = 0;
	ScrubField [] fields = null;
	DBMSSupportedFieldTypes supportedFieldTypes = daoF.getDBMSSupportedFieldTypes();
	
	try{
	    cnn = daoF.getConnection();
	    stmt = cnn.createStatement();
	    rs = stmt.executeQuery( query );
	    rsmd = rs.getMetaData();
	    fieldCount = rsmd.getColumnCount();
	    fields = new ScrubField[ fieldCount ];
	    String fieldName = null;
	    for( index = 0; index<fieldCount; index++ ){
		fields[ index ] = new ScrubField( rsmd.getColumnName( index + 1),
						  supportedFieldTypes.getFieldTypeByTypeName( rsmd.getColumnTypeName( index + 1 ) )
						  );
	    }
	}finally{
	    daoF.release( cnn, stmt, rs );
	}
	if( fields == null ){
	    throw new NullPointerException("Failed to access fields. ");
	}
	return fields;
    }
    /******************************************************************************************/



    /******************************************************************************************/    
    /** starting of select query (lowercase) */
    private static final String SELECT = "select ";
    
    /** check whether the parameter is query or table
     * @param tblQuery parameter which has to be identified as table or query
     * @returns true only if starts with "select " (case insensitive)
     */
    private static final boolean isQuery( String tblQuery ){
	String lcQuery = tblQuery.trim().toLowerCase(); //lowercase case of SELECT
	if( lcQuery.startsWith( SELECT ) ){
	    return true;
	}
	return false;
    }
    /******************************************************************************************/




    /******************************************************************************************/
    /**
     * @param tableName name of the table for which primary key fields are to be found
     * @returns string array containing field names for primary key
     * @throws Exception on backend problem
     */
    public String [] getPKFields( String tableName) throws Exception{
	ArrayList ar = getMyPKFields( tableName );
	String [] pkFields = new String[ ar.size() ];
	pkFields = (String [] ) ar.toArray( pkFields);
	return pkFields;
    }

    private ArrayList getMyPKFields( String tableName ) throws Exception {
	if( tableName == null ){
	    throw new NullPointerException("Null table name specified.");
	}
	Connection cnn = null;
	ResultSet pk = null;
	ArrayList ar = new ArrayList(3);
	try{
	    cnn = daoF.getConnection();
	    DatabaseMetaData dbmd = cnn.getMetaData();
	    pk = dbmd.getPrimaryKeys( null, null, tableName );
	    while( pk.next() ){
		ar.add( pk.getString( "COLUMN_NAME" ) );
	    }
	}finally{
	    daoF.release( cnn, null, pk);
	}
	return ar;
    }
    /******************************************************************************************/




    /******************************************************************************************/
    /**
     * @param tableName name of the table for which primary key fields are to be found
     * @returns ScrubField array containing ScrubFields representing primary key
     * @throws Exception on backend problem
     */
    public ScrubField [] getPKScrubFields( String tableName) throws Exception{
	if( tableName == null ){
	    throw new NullPointerException("Null table name specified.");
	}
	ArrayList ar = getMyPKFields( tableName);
	ScrubField [] scFields = getScrubFields ( tableName );
	
	
	ArrayList pkScFields = new ArrayList( ar.size() );

	for( int i=0; !ar.isEmpty() && i<scFields.length; i++ ) {
	    //System.out.println( scFields[i].getFieldName()  + " -> " + ar.contains( scFields[i].getFieldName() ) );
	    if( ar.contains( scFields[i].getFieldName() ) ){
		pkScFields.add( scFields[i] );
	    }
	}

	ScrubField [] arPKScFields = new ScrubField[ pkScFields.size() ];
	if( arPKScFields.length > 0) {
	    arPKScFields = (ScrubField [] ) pkScFields.toArray( arPKScFields );
	}
	return arPKScFields;
    }

}
