package scrub.web;


import java.util.HashMap;

/**
 * defines variables for using with web-applications
 */

public class WebVar{

    private static WebVar _self = null;
    /** disable default constructor as may require dynamic naming in future */
    private WebVar(){}

    public static synchronized WebVar getInstance(){
	if( _self != null){
	    _self =  new WebVar();
	}
	return _self;
    }

    private static HashMap vars = new HashMap();

    public static final String
	PROCESS = "webapp_PROCESS",
	CLIENT_ID = "webapp_clientid",
	TABLE_NAME = "webapp_table_name";

    static{
	vars.put( "process", PROCESS );
    }
}
