package scrub.web;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import scrub.util.web.DispatchHelper;
import scrub.util.RequestData;

import scrub.security.User;
import scrub.security.SecurityFactory;
import scrub.security.Security;

/**
 * If a user has not already logged in, then forces to login
 * If its a proper and valid login, then check for setting of appropriate variables
 * sets the variable if not already done so. then transfers control for "SelectClient" operation
 */

public class Login implements Processor{

    /**
     * verifies that user has properly logged in.
     * checks where userID and userName are set or not. ( May be set from OAM)
     * if not set forces login
     * if set check User object. if its not set then set it.
     * sets "user" with user object (session)
     * sets "isLoggedIn" with Boolean True object is valid login
     * @param request represents the current HttpServletRequest
     * @param response the HttpServletResponse to respond to web-server client
     * @param context ServletContext
     * @throws Exception
     */
    public void execute( HttpServletRequest request, HttpServletResponse response, ServletContext context)
	throws Exception{

	HttpSession session = request.getSession();
	
	ProcessorMap procMap = (ProcessorMap) request.getAttribute( "procMap");
	RequestData requestData = (RequestData) request.getAttribute( "requestData" );
	SecurityFactory securityFactory = (SecurityFactory) context.getAttribute( "securityFactory" );
	Security security = securityFactory.getSecurity();
	
	String userName = (String) session.getAttribute( "userName" );
	String userID = (String) session.getAttribute( "userID" );
	User user = null;
	String password = null;
	
	boolean isValidUser = false;
	Boolean isLoggedIn = null;


	if( requestData.containsKey( "loginName") || requestData.containsKey( "password" )
	    || "login".equalsIgnoreCase( requestData.getParameter("process") )
	    ){	    //login
	    userID = requestData.getParameter( "loginName");
	    password = requestData.getParameter( "password");
	    user = new User(userID, null, password);

	    if( security.isValidUser( user) ){
		user = security.getUserByID( user.getUserID() );
		session.setAttribute( "user", user);
		isLoggedIn = Boolean.valueOf( true) ;
		session.setAttribute( "isLoggedIn", isLoggedIn );
		isValidUser = true;
	    }
	}
	if( !isValidUser && userID != null && userName != null ){
	    //UserID and UserName is already set may be throug oam
	    isValidUser = DTSLogin.isValidLogin( session, context);
	}
	if( isValidUser){
	    procMap.getProcessor( "SelectClient").execute( request, response, context);
	}else{
	    DispatchHelper.forward( request, response, "index.jsp");
	}
    }
}
