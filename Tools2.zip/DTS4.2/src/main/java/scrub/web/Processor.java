package scrub.web;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * defines interface for calling from the servlet consistently
 */
public interface Processor{

    /**
     * @param request represents the current HttpServletRequest
     * @param response the HttpServletResponse to respond to web-server client
     * @param context ServletContext
     * @throws Exception
     */
    public void execute( HttpServletRequest request, HttpServletResponse response, ServletContext context)
	throws Exception;

}
