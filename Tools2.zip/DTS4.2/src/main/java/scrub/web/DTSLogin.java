package scrub.web;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import scrub.security.User;
import scrub.security.SecurityFactory;
import scrub.security.Security;

public class DTSLogin{

    /**
     * when accessed directly from WebDts
     * verifies that proper login was used in web dts
     * and sets required session variables
     * @param session
     * @param context
     * @throws Exception
     */
    public static boolean isValidLogin(
					  HttpSession session,
					  ServletContext context)
	throws Exception{
	boolean isValidUser = false;
	
	SecurityFactory securityFactory = (SecurityFactory) context.getAttribute( "securityFactory" );
	Security security = securityFactory.getSecurity();

	String userID = (String) session.getAttribute("userID");// set from OAM

	if( userID != null){
	    User user = security.getUserByID( userID );
	    if( user != null ){//valid user
		List clientList = security.getClientsForUser( user, null);	//no selection list hence null.
		session.setAttribute( "clientList", clientList );

		session.setAttribute( "user", user);
		session.setAttribute( "isLoggedIn", Boolean.valueOf( true) );
		isValidUser =  true;
	    }
	}
	return isValidUser;
    }

}
