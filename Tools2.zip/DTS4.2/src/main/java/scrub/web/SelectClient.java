package scrub.web;


import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;

import scrub.security.SecurityFactory;
import scrub.security.Security;
import scrub.security.User;

import scrub.util.web.DispatchHelper;

/**
 * Page Controller
 * Provides list of clients
 */
public class SelectClient implements Processor{

    private static final String SELECT_CLIENT = "scrub/select_client.jsp";
    /**
     * refreshes the client list in session every time this module is executed.
     * refresh of client list may be minimized by loading only once in the session
     * @param request represents the current HttpServletRequest
     * @param response the HttpServletResponse to respond to web-server client
     * @param context ServletContext
     * @throws Exception
     */
    public void execute( HttpServletRequest request, HttpServletResponse response, ServletContext context)
	throws Exception{

	SecurityFactory securityFactory = (SecurityFactory) context.getAttribute( "securityFactory" );
	Security security = securityFactory.getSecurity();

	HttpSession session = request.getSession(  false );
	User user = (User) session.getAttribute( "user" );
	List clientList = security.getClientsForUser( user, null);	//no selection list hence null.

    //System.out.println ("\nUser id is: -------" + user + "\n");
    //System.out.println ("\nClient List is: -------" + clientList.toArray() + "\n");
	session.setAttribute( "clientList", clientList );
	request.setAttribute( "clientList", clientList );

	DispatchHelper.forward( request, response, SELECT_CLIENT );
	
    }
}
