package scrub.web;


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.List;

import scrub.data.ScrubDAOFactoryBuilder;
import scrub.data.ScrubDAOFactory;
import scrub.mgmt.ScrubBuilder;
import scrub.mgmt.Client;

import scrub.exception.ScrubException;

import scrub.util.text.OrderBean;
import scrub.util.web.ColumnWidth;
import scrub.util.RequestData;
import scrub.util.web.DispatchHelper;

import scrub.security.SecurityFactory;

import scrub.log.Logger;
import scrub.rules.RulesConfigLoader;
import scrub.rules.RulesConfig;

/* ---------- Connection Pool ----------*/
import com.d2.sql.D2ConnectionPool;
import com.d2.sql.D2ConnectionPoolFactory;
import com.d2.sql.ConnectionXMLReader;
import com.d2.exception.ConnectionXMLException;
import com.d2.exception.DriverLoadFailureException;
/*--------------------------------------*/

/**
 * Front Controller servlet for Scrub managemet
 * initializes required objects, security control, delegation to related modules based on
 * mapping
 */
public class ScrubServlet
    extends HttpServlet{
    ProcessorMap procMap = null;
    ServletContext sc = null;

    ScrubDAOFactory scrubDAOFactory = null;
    ScrubDAOFactoryBuilder scrubDAOFactoryBuilder = null;
    ScrubBuilder scrubBuilder = null;

    ColumnWidth colWidth = null;

    Logger logger = null;
    
    private static boolean isInitOK = false;
    private String initStatus = "";


    //private static final String def_server_type = "SQLServer";
    private static final String def_server_type = "ORCL";
    private static final String CNX_XML_FILE = "CnxXMLFile";
    private static final String DEF_CNX_XML_FILE = "./WEB-INF/classes/dbpool.xml";
    private static final String RULES_XML_FILE = "RulesXMLFile";
    private static final String DEF_RULES_XML_FILE = "./WEB-INF/classes/rules.xml";
    
    D2ConnectionPoolFactory poolFactory = null;
    RulesConfig rulesConfig = null;
    
    /** url of error page */
    final String ERROR_PAGE = "scrub/errorPage.jsp";

    /* url of user defined error page */
    final String UDF_ERROR_PAGE = "scrub/udfException.jsp";


    /********************************************************************************





    ********************************************************************************/
    /** initialize the resources
     *  Application scope objects
     * POOL_FACTORY  =>connection pool factory
     * procMap =>ProcessorMap which loads the processor
     * securityFactory  => SecurityFactory for user verification
     * logger	=> Logger for logging modification
     */    
    public void init( ServletConfig config) throws ServletException{
	colWidth = new ColumnWidth();
        System.out.println("From init method of the scrub servlets---->"+ initStatus);
	try{
	    sc = config.getServletContext();
	    initConnection( config );			//first step --> init connection
	    initRules( config);
	    procMap = ProcessorMap.getInstance();

	    //sc.setAttribute( "procMap", procMap);
	    initStatus += "Processor Map loaded...\n";
	    SecurityFactory sf = SecurityFactory.getInstance();
	    sc.setAttribute( "securityFactory", sf);
	    initStatus += "SecurityFactory loaded...\n";
	    
	    logger = Logger.getInstance();
	    logger.setEnabled( true);
	    sc.setAttribute( "logger", logger);
	    initStatus += "Logging initialized ";
	    
	    // initializing ScrubDAOFactoryBuilder
	    scrubDAOFactoryBuilder = ScrubDAOFactoryBuilder.getInstance();
	    initStatus += "ScrubDAOFactoryBuilder loaded...\n";

	    // initializing and loading default scrubDAOFactoryBuilder
	    scrubDAOFactory = scrubDAOFactoryBuilder.getScrubDAOFactory( def_server_type );
	    initStatus += "ScrubDAOFactory for SQL Server loaded....\n";
		
	    //initializing ScrubBuilder
	    scrubBuilder = ScrubBuilder.getInstance();
	    initStatus += "ScrubBuilder loaded...\n";
	    
	    isInitOK = true;
	    System.out.println("---->"+ initStatus);
	}catch(Exception e){
	    initStatus += "\n**************\nError: " + e.toString() +"\n";
	    StringWriter sout = new StringWriter();
	    PrintWriter pout = new PrintWriter( sout );
	    e.printStackTrace( pout);
	    initStatus += sout.toString();
	    System.out.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n" + initStatus);
	}
    }
    /********************************************************************************





    ********************************************************************************/
    /** standard servlet method called by container */
    public void service ( HttpServletRequest request, HttpServletResponse response )
	throws ServletException, IOException {
	//Not loaded propely
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$From service method of scrub servlets... is InitOK="+isInitOK);
	if( !isInitOK ){
	    reportError( request, response );
	    return;
	}
	HttpSession session = request.getSession( );


	RequestData rData = copyRequest( request );	//copy request to our RequestData
	request.setAttribute( "requestData", rData );
	request.setAttribute( "procMap", procMap);
	request.setAttribute( "rulesConfig", rulesConfig );
	    
	try{
        System.out.println("The value of PROCESS is: " + rData.getParameter("process"));
	    if( "logout".equalsIgnoreCase( rData.getParameter( "process" ) ) ){
		session.invalidate();

		DispatchHelper.forward( request, response, "index.jsp");
	    }else if( isLoggedIn( session ) ){

		setAttributes(request);
		List clientList = (List) session.getAttribute( "clientList");

		String process = rData.getParameter( "process");
		Processor p = null;

		if( !"".equalsIgnoreCase( process ) && clientList != null && !clientList.isEmpty() ){
		    //don't allow all the clients except assigned ones.
		    Client c = new Client();
		    c.setClientID(rData.getParameter("clientID") );
		    if( clientList.contains( c) ){
			c = (Client) clientList.get( clientList.indexOf(c));
		    }
		    request.setAttribute("client", c);
		    p = procMap.getProcessor( process );
		}else{
		    p = procMap.getProcessor( "SelectClient" );
            System.out.println("Processor has come where client List is NULL\n");
		}
		p.execute(request, response, sc );
	    }else{
		( procMap.getProcessor( "login" ) ).execute( request, response, sc);//verify / login
	    }
	}catch( ScrubException udfException){
	    request.setAttribute("udfException", udfException);
	    forward( request, response, UDF_ERROR_PAGE );
	}catch( Exception webEx){
	    System.out.println("\n***********ERROR");
	    request.setAttribute("controlException", webEx );
	    webEx.printStackTrace();
	    System.out.println("\n***********ERROR");
	    forward( request, response, ERROR_PAGE );	    
	}
    }
    /********************************************************************************





    ********************************************************************************/
    /**
     * forward to the specified page
     */
    private void forward( HttpServletRequest request, HttpServletResponse response, String page){
	try{
	    DispatchHelper.forward( request, response, page );
	}catch(Exception dispEx){
	    System.out.println("\n\n\n***********error forwarding ???\n******************************\n");
	    dispEx.printStackTrace();
	}
    }
    /********************************************************************************





    ********************************************************************************/
    /**
     * @param request the source of request data
     * @return RequestData with parameters and the values copied into it.
     */
    private static RequestData copyRequest( HttpServletRequest request){
	RequestData rt = new RequestData();
	java.util.Enumeration paramNames = request.getParameterNames();
	while( paramNames.hasMoreElements() ){
	    String param = (String) paramNames.nextElement();
	    if( param != null ){
            System.out.println(param + "\n");
		rt.addParameters( param, request.getParameterValues( param ));
	    }
	}
	return rt;
    }
    /********************************************************************************





    ********************************************************************************/
    /** add ScrubBuilder to request */
    private void setAttributes( HttpServletRequest request){
	request.setAttribute( "scrubBuilder", scrubBuilder );
	request.setAttribute( "scrubDAOFactory", scrubDAOFactory );
	request.setAttribute( "colWidth" , colWidth );
    }
    /** error report to browser */
    void reportError ( HttpServletRequest request, HttpServletResponse response )
	throws IOException{
	PrintWriter out = response.getWriter();
	out.print("<pre>");
	out.println("Sorry the system failed to load properly..");
	out.println( initStatus );
	out.println("</pre>");
	out.close();
    }
    /********************************************************************************





    ********************************************************************************/
    private void initConnection( ServletConfig cfg ) throws Exception{
	String connectionXMLFile = null;
	try{
        System.out.println("jfsldfjsdjf........................");
	    connectionXMLFile = cfg.getInitParameter(CNX_XML_FILE );
	    if( connectionXMLFile  == null || connectionXMLFile.equals(""))
		connectionXMLFile = DEF_CNX_XML_FILE;

	    connectionXMLFile = (cfg.getServletContext()).getRealPath( connectionXMLFile);

	    ( new ConnectionXMLReader()).loadConnectionIDsFromXMLFile( connectionXMLFile);
	    initStatus += "\n*********\nConnection XML File: "+ connectionXMLFile + " loaded...";
	    poolFactory = D2ConnectionPoolFactory.getInstance();
	    initStatus += "\nPoolFactory ........";
	    ( cfg.getServletContext() ).setAttribute( "POOL_FACTORY", poolFactory );
        System.out.println("\nThe XML file is: " + connectionXMLFile + "\n");
	}catch(ConnectionXMLException xmlEx){
	    initStatus += "\n********************\n error in " + connectionXMLFile
		+ "\n" + xmlEx.toString();
	    throw xmlEx;
	}catch( DriverLoadFailureException drvEx){
	    initStatus += "\n****************\n  error loading driver  "
		+ "\n" + drvEx.toString();
	    throw drvEx;

	}
    }
    /********************************************************************************





    ********************************************************************************/
    private void initRules( ServletConfig cfg) throws Exception{
	String rulesXMLFile = cfg.getInitParameter( RULES_XML_FILE);
	if( rulesXMLFile == null || rulesXMLFile.equals("") )
	    rulesXMLFile = DEF_RULES_XML_FILE;
	rulesXMLFile     = (cfg.getServletContext()).getRealPath( rulesXMLFile);
        System.out.println("\nRules XML file is: " + rulesXMLFile + "\n");
	rulesConfig      =  (new RulesConfigLoader()).loadRulesConfig( rulesXMLFile);
	initStatus      += "\nRules File loaded:" + rulesXMLFile + "\n";
    }
    /********************************************************************************





    ********************************************************************************/
    //verify that user has logged in 
    boolean isLoggedIn(HttpSession session) throws Exception{
	Boolean isLoggedIn = (Boolean) session.getAttribute( "isLoggedIn" );
        System.out.println("isLoggedIn is ....." + isLoggedIn);
	if( isLoggedIn != null ){
	    return isLoggedIn.booleanValue();
	}else{
	    return DTSLogin.isValidLogin( session, sc);
	}
    }
}
