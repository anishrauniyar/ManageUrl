package scrub.web;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import scrub.util.web.DispatchHelper;
import scrub.util.RequestData;

import scrub.mgmt.ScrubBuilder;
import scrub.mgmt.Scrub;


/**
 * Provides List of AsPrepared global tables
 * and client specific AsPrepared tables
 */
public class SelectTable implements Processor{

    private static final String SELECT_TABLE = "scrub/select_table.jsp";    
    /**
     * provides list of tables 
     * @param request represents the current HttpServletRequest
     * @param response the HttpServletResponse to respond to web-server client
     * @param context ServletContext
     * @throws Exception
     */
    public void execute( HttpServletRequest request, HttpServletResponse response, ServletContext context)
	throws Exception{
	RequestData requestData = (RequestData) request.getAttribute( "requestData" );
	String clientID = requestData.getParameter( "clientID" );
	if( clientID != null
	    && !"".equals( clientID) 
	    ){

	    ScrubBuilder scrubBuilder = (ScrubBuilder) request.getAttribute( "scrubBuilder" );
	    Scrub scrub = scrubBuilder.getScrub();
	    scrub.setClientID( clientID);
	    
	    HttpSession session = request.getSession( false ) ;
	    List  globalAsPreparedTableNameList =  null;
	    globalAsPreparedTableNameList = (List) session.getAttribute( "globalAsPreparedTableNameList" );

	    if( globalAsPreparedTableNameList == null ){
		globalAsPreparedTableNameList = scrub.getGlobalAsPreaparedTableNameList();
	    }

	    session.setAttribute( "globalAsPreparedTableNameList", globalAsPreparedTableNameList);
	    request.setAttribute( "globalAsPreparedTableNameList", globalAsPreparedTableNameList);
            
            // Added the below lines for HR_DATA_XXXX tables, bhanu March4 2009
             List  hrDataTableNameList =  null;
	    hrDataTableNameList = (List) session.getAttribute( "hrDataTableNameList" );

	    if( hrDataTableNameList == null ){
		hrDataTableNameList = scrub.getHrDataTableNameList();
	    }
	    session.setAttribute( "hrDataTableNameList", hrDataTableNameList);
	    request.setAttribute( "hrDataTableNameList", hrDataTableNameList);
            // Added the above lines for HR_DATA_XXXX tables

	    List clientsAsPreparedTableNameList = scrub.getClientsAsPreparedTableNameList( clientID );
	    request.setAttribute( "clientsAsPreparedTableNameList", clientsAsPreparedTableNameList );

	    DispatchHelper.forward( request, response, SELECT_TABLE );
	}else{
	    ProcessorMap procMap = (ProcessorMap) request.getAttribute( "procMap" );
	    Processor p = procMap.getProcessor( "SelectClient" );
	    p.execute( request, response, context );
	}
    }
}
