package scrub.web;

import java.util.HashMap;

public class ProcessorMap{

    private static HashMap procMap = new HashMap();

    static{
	procMap.put( "SelectClient"  .toLowerCase(),  "scrub.web.SelectClient" );
	procMap.put( "SelectTable"   .toLowerCase(),  "scrub.web.SelectTable" );
	procMap.put( "TableOperation".toLowerCase(),  "scrub.web.TableOperation" );
	procMap.put( "QueryOperation".toLowerCase(),  "scrub.web.QueryOperation" );
	procMap.put( "login"	     .toLowerCase(),  "scrub.web.Login" );
    }

    protected Processor getProcessor( String processorName ) throws Exception{
	String className = ( String ) procMap.get( processorName.toLowerCase() );
	//System.out.println(">>PROCESSOR: " + processorName + " >>clasName: " + className);
	return (Processor) Class.forName( className ).newInstance();
    }

    private ProcessorMap(){
	System.out.println(" proc map ");
    }
    private static ProcessorMap _self = null;
    
    protected static final synchronized ProcessorMap getInstance(){
	System.out.println(" getInst proc map");
	if( _self == null ){
	    _self = new ProcessorMap();
	}
	return _self;
    }

    /**
     * for dynamic loading
     */
    protected void put( String processorAlias, String processorClassName){
	String alias = processorAlias.toLowerCase();
	if( !procMap.containsKey( alias) ){
	    procMap.put( processorAlias, processorClassName);
	}
    }
}
