package scrub.web;

import java.util.HashMap;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import scrub.datatransfer.ScrubTableFactory;
import scrub.datatransfer.ScrubTable;
import scrub.datatransfer.ScrubRecord;
import scrub.datatransfer.ScrubField;
import scrub.datatransfer.Record;

import scrub.mgmt.ScrubBuilder;
import scrub.mgmt.Scrub;
import scrub.mgmt.Client;

import scrub.util.Request2Record;
import scrub.util.web.DispatchHelper;
import scrub.util.RequestData;
import scrub.util.text.OrderBean;
import scrub.util.RequestTransfer;

import scrub.rules.RulesConfig;

import scrub.log.Logger;
import scrub.security.User;

/**
 * interacting with master tables
 */
public class TableOperation implements Processor{

    private static ScrubTableFactory scTableFactory = ScrubTableFactory.getInstance();

    private static final String SELECT_4_UPDATE = "select4Update";
    private static final String INSERT = "insert";
    private static final String DELETE = "delete";
    private static final String UPDATE = "update";
    private static final String RESET  = "reset";
    private static final String FILTER = "filter";
    private static final String ORDER  = "order";
    private static final String PAGE   = "page";
    private static final String XL     = "excel";
    private static final String COPY   = "copy";
    
    //Added by Anjana. All RENEW related variables/codes added by her.
    private static final String RENEW   = "renew";

    //Added by Anjana. All EXPIRED related variables/codes added by her.
    private static final String EXPIRED   = "expired";
    private static final String XLEXP   = "xlexp";
    private static final String RENEWEXP   = "renewexp";
    
    private static final String UPDATE_ROW = "updateRow";
    
    private static final int K_SELECT_4_UPDATE = 1;
    private static final int K_INSERT = 2;
    private static final int K_DELETE = 3;
    private static final int K_UPDATE = 4;
    private static final int K_RESET  = 5;
    private static final int K_FILTER = 6;
    private static final int K_ORDER  = 7;
    private static final int K_PAGE   = 8;
    private static final int K_XL     = 9;
    private static final int K_COPY    = 10;
    private static final int K_RENEW    = 11;
    private static final int K_EXPIRED   = 12;
    private static final int K_XLEXP   = 13;
    private static final int K_RENEWEXP   = 14;
    
    private static final String pfOLD = "old_";
    private static final String pfNEW = "new_";
    private static final String pfFILTER = "filter_";
    private static final String [] pfx2REMOVE = new String[] { pfFILTER };
    private static final String [] eq2ADD = new String[] {"ClientID"};

    private static final String ASC_STRING = "<font face=\'Wingdings\'>�</font>";
    private static final String DESC_STRING = "<font face=\'Wingdings\'>�</font>";
    
    private static HashMap codeMap = new HashMap();

    static{
	codeMap.put( SELECT_4_UPDATE, new Integer( K_SELECT_4_UPDATE) );
	codeMap.put( INSERT, new Integer( K_INSERT) );
	codeMap.put( DELETE, new Integer( K_DELETE) );
	codeMap.put( UPDATE, new Integer( K_UPDATE) );
	codeMap.put( RESET, new Integer( K_RESET) );
	codeMap.put( FILTER, new Integer( K_FILTER) );
	codeMap.put( ORDER, new Integer( K_ORDER) );
	codeMap.put( PAGE, new Integer( K_PAGE ) );
	codeMap.put( XL, new Integer( K_XL ) );
	codeMap.put( COPY, new Integer( K_COPY ) );
	codeMap.put( RENEW, new Integer( K_RENEW ) );
	codeMap.put( EXPIRED, new Integer( K_EXPIRED ) );
	codeMap.put( XLEXP, new Integer( K_XLEXP ) );
	codeMap.put( RENEWEXP, new Integer( K_RENEWEXP ) );
    }

    /**
     * interacts with client for insert,update, delete and browse operation
     * @param request represents the current HttpServletRequest
     * @param response the HttpServletResponse to respond to web-server client
     * @param context ServletContext
     * @throws Exception
     */
    public void execute( HttpServletRequest request, HttpServletResponse response, ServletContext context)
	throws Exception{

	RequestData updateRow = null;
	String exp = (request.getParameter("Expired")==null?"":request.getParameter("Expired"));

	RequestData requestData = (RequestData) request.getAttribute( "requestData");
	String tableName = requestData.getParameter( "tableName" );
	String clientID = requestData.getParameter( "clientID");
	HttpSession session = request.getSession();
	User user = (User) session.getAttribute( "user" );
	List clientList = (List) session.getAttribute( "clientList");
	Client client = (Client) request.getAttribute( "client" );
	RulesConfig rulesConfig = (RulesConfig) request.getAttribute( "rulesConfig" );
	
	if( client==null ){
	    client = new Client();
	    request.setAttribute( "client", client );
	}



	
	ScrubBuilder scrubBuilder = (ScrubBuilder) request.getAttribute( "scrubBuilder" );
	Scrub scrub = scrubBuilder.getScrub();
	scrub.setRulesConfig( rulesConfig);
	Logger logger = (Logger) context.getAttribute( "logger" );

	boolean isGlobal = scrub.isGlobal( tableName);
	request.setAttribute( "isGlobal", Boolean.valueOf( isGlobal) );

	//opcode resolution
	String opcode = requestData.getParameter( "opcode" );
	Integer iOpCode = (Integer) codeMap.get( opcode);
	int operation  = -1;

	if( iOpCode != null){
	    operation = iOpCode.intValue();
	}
	// iterator creation
	ScrubTable scrubTable = null;
	boolean isXL = (operation==K_XL);
	 boolean isExp = (operation == K_EXPIRED);
     boolean isExpXL = (operation==K_XLEXP);
     boolean isExpRenew = (operation == K_RENEWEXP);
	if( isXL ){
	    scrubTable = scTableFactory.getScrubTable( ScrubTable.TABLE_NOT_PAGED );
	}else{
	    scrubTable = scTableFactory.getScrubTable( ScrubTable.TABLE_PAGED );
	}

	Boolean isSelect4Update = Boolean.valueOf( false);
	Record newRecord=null, oldRecord=null;
	//------------------------------------------------------------------------------------------
	//holds parameters in web filtering only
	Record filter = Request2Record.getRecord( requestData, pfFILTER );
	//RequestData filter = new RequestData( requestData);

	String orderField = requestData.getParameter( "orderField" );
	String order = requestData.getParameter( "order");
	OrderBean orderBean = new OrderBean( orderField, order );

	orderBean.setAscending( ASC_STRING );
	orderBean.setDescending( DESC_STRING );
	
	String pageNo = requestData.getParameter("pageNo");
	scrubTable.setCurrentPage( getNum( pageNo) );

	//operation control goes here

	if( tableName != null && !"".equals( tableName )  && !"".equals(clientID) 
	    && clientList != null && clientList.contains( client) ){
	    
	    int affectedRows = 0;
	    /*---------- SET ClientID if global----------*/
	    if( isGlobal ){
		scrub.setClientID( client.getClientID() );
	    }

	    switch( operation){ 
	    case K_INSERT:	//reset after insert operation.
		newRecord = Request2Record.getRecord(  requestData, pfNEW);
		affectedRows = scrub.insertRecord( tableName, newRecord);
		if( affectedRows>0) {
		    logger.inserted( user.getUserID(), client.getClientID(),
				     client.getClientName(),
				     tableName, newRecord);
		}						     
		scrubTable.setCurrentPage( ScrubTable.PAGE_LAST );	
		filter = new Record();//RequestData(); //remove new_ and old_ params
		orderBean.setOrderField("");
		orderBean.setOrder("");
		removePrefixed( requestData, pfFILTER );  //remove filter 
		break;
	    case K_DELETE:
		newRecord = Request2Record.getRecord(  RequestData.fromSerialString( requestData.getParameter( UPDATE_ROW )), "");
		affectedRows = scrub.deleteRecord( tableName, newRecord);
		if( affectedRows>0) {
		    logger.deleted( user.getUserID(), client.getClientID(),
				    client.getClientName(),
				    tableName, newRecord);
		}
		break;
	    case K_UPDATE:
		oldRecord = Request2Record.getRecord(  requestData, pfOLD );
		newRecord = Request2Record.getRecord(  requestData, pfNEW );
		//System.out.println("\n---old\n"+oldRecord.toString());
		//System.out.println("\n---new\n"+newRecord.toString());
		affectedRows = scrub.updateRecord( tableName, oldRecord, newRecord);
		if( affectedRows>0) logger.updated( user.getUserID(), client.getClientID(), client.getClientName(),
						     tableName, oldRecord, newRecord);
		break;	
	    case K_RENEW:  // Added by Anjana, April 2007 to renew expired contracts by 1 year.
            newRecord = Request2Record.getRecord(RequestData.fromSerialString(requestData.getParameter(UPDATE_ROW )), "");
            scrub.renewContractDate(tableName, newRecord);
            break;

            case K_RENEWEXP:  // Added by Anjana, May 21, 2007 to renew multiple contracts/records by 1 year
            System.out.println ("Reached the CASE statement.....");
            String recs[] = request.getParameterValues("_renew");
            for (int i=0; i<recs.length; i++)
            {
                System.out.println ("Inside FOR condition.....");
                newRecord = Request2Record.getRecord(RequestData.fromSerialString(recs[i]), "");
                scrub.renewContractDate(tableName, newRecord);
            }
            System.out.println ("AFTER FOR condition.....");
            break;
	    }
	    

	}

	switch(operation){
	case K_COPY:
	    RequestData tmp = new RequestData( requestData);
	    tmp.removeParameter("ClientID");
	    updateRow = RequestTransfer.transfer( tmp, new String[]{ pfNEW }, null);
	    break;
	case K_SELECT_4_UPDATE: //preserve page, filter.
	    isSelect4Update = Boolean.valueOf( true);
	    updateRow = RequestData.fromSerialString( requestData.getParameter( "updateRow" ) );
	    //update client id if global
	    if( isGlobal){
		String uuClientID = updateRow.getParameter( "clientID" );
		if( !"".equals( uuClientID) ){
		    Client uuClient = new Client();
		    uuClient.setClientID( uuClientID);
		    if( clientList.contains( uuClient) ){
			client = (Client) clientList.get( clientList.indexOf( uuClient) );
			scrub.setClientID( client.getClientID() );  //change for scrub as well to pull selected client
			request.setAttribute( "client", client);
		    }
		}
	    }
	    break;
	case K_RESET:
	    filter = new Record();//RequestData();		//no filtering info.
	    removePrefixed( requestData, pfFILTER );
	    orderField = "";
	    order = "";
	    orderBean.setOrderField("");
	    orderBean.setOrder("");
	    scrubTable.setCurrentPage( 0);
	    break;
	case K_FILTER:
	    orderBean = new OrderBean();
	    scrubTable.setCurrentPage( 0);
	    break;
	case K_ORDER:
	    scrubTable.setCurrentPage( 0);
	case K_PAGE:
	default:
	}
	if( updateRow == null ) {
	    updateRow = new RequestData();
	}
	request.setAttribute( "updateRow", updateRow);
	
	RequestData processFilter = new RequestData( requestData);
	RequestData filterData = null;

	if( !isGlobal ){  //remove clientID to prevent conflict with clientID in client's table
	    processFilter.removeParameter( "clientID");
	}
	//remove web specific parameters to prevent conflict if matching fieldname exists in client's table
	processFilter.removeParameter( "orderField" );
	processFilter.removeParameter( "order" );
	processFilter.removeParameter( "process" );
	processFilter.removeParameter( "tableName" );
	processFilter.removeParameter( "pageNo" );
	processFilter.removeParameter( "opcode" );
	
	filterData = RequestTransfer.transfer( processFilter, pfx2REMOVE, eq2ADD );
	RequestData securityFilter = null;
	//Apply filter criteria to restrict clients if global table is being used.
	if( isGlobal && clientList != null && !clientList.isEmpty() && (clientID==null || "".equals(clientID) ) ){
	    securityFilter = new RequestData();
	    Client allowedClient = null;
	    for( int n=0; n<clientList.size(); n++){
		allowedClient = (Client) clientList.get( n);
		securityFilter.addParameter( "ClientID", "=" + allowedClient.getClientID() );
	    }
	}else{
	    //remove filtering criteria
	    if( isGlobal){
		filter.remove("ClientID"); //Don't display client id in filter
		filterData.setParameter("ClientID","="+clientID); //force selection by particular clientid.
	    }
	}

	Boolean isFullAccessMode = Boolean.valueOf( true);
	if( clientID == null || "".equals( clientID) ){
	    isFullAccessMode = Boolean.valueOf( false);
	}
	request.setAttribute( "isFullAccessMode", isFullAccessMode );
	request.setAttribute( "isSelect4Update", isSelect4Update);
	request.setAttribute( "filter", filter);

	
	scrubTable = scrub.browse( tableName, new RequestData[] { filterData, securityFilter },
				   orderBean.getOrderField(), orderBean.getOrder(), scrubTable );
	request.setAttribute(  "scrubTable", scrubTable);
	request.setAttribute( "count", ""+scrubTable.getSetSize() );
	request.setAttribute( "pageSize", ""+scrubTable.getPageSize() );
	request.setAttribute( "frameSize", "10" );
	request.setAttribute( "currentPage", ""+scrubTable.getCurrentPage() );
	request.setAttribute( "orderBean", orderBean );
	 //if (isExp || isExpRenew)
    if (exp.equalsIgnoreCase("y") && !(isXL || isExpXL))
    {
        DispatchHelper.forward( request, response, "scrub/expired_Contracts.jsp");
    }
    
	if(isXL){
	    DispatchHelper.forward( request, response, "scrub/xl_table_operation.jsp" );
	}else{
	    DispatchHelper.forward( request, response, "scrub/table_operation.jsp" );
	}
    }
    private static int getNum( String param){
	int retValue = 0;
	try{ retValue = Integer.parseInt( param); }catch(Exception nfe){}
	return retValue;
    }
    private static void removePrefixed( RequestData rdata, String pfx){
	String [] paramNames = rdata.getParameterNames();
	if( pfx == null) return;
	String pfxUC = pfx.toUpperCase();
	for( int i=0; i<paramNames.length; i++){
	    if( (paramNames[ i].toUpperCase()).startsWith( pfxUC) ){
		rdata.removeParameter( paramNames[i] );
	    }
	}
    }
}
