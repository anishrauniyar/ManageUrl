package dashboard.security;

public class UserRole {

	private ProcessingRole roleId;
	private ProcessingRole roleName;

	public ProcessingRole getRoleId() {
		return roleId;
	}

	public UserRole setRoleId(ProcessingRole roleId) {
		this.roleId = roleId;
		return this;
	}

	public ProcessingRole getRoleName() {
		return roleName;
	}

	public UserRole setRoleName(ProcessingRole roleName) {
		this.roleName = roleName;
		return this;
	}

}
