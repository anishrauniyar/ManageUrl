package dashboard.security;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

public class ProcessingRole implements Serializable {

    private String role;
    private ProcessingRole () {}

    private ProcessingRole(String rlName) {
        role = rlName;
    }

    public int hashCode() {
        return role.hashCode();
    }

    public boolean equals(Object obj) {
        if( null != obj && obj instanceof ProcessingRole) {
            ProcessingRole rlToComp = (ProcessingRole) obj;
            if (this.getRole().equals(rlToComp.getRole())) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        return role;
    }
    public String getRole() {
        return role;
    }

    public static final ProcessingRole PROCESS_SUPERADMIN = new ProcessingRole("PROCESS_SUPERADMIN");
    public static final ProcessingRole PROCESS_ADMIN = new ProcessingRole("PROCESS_ADMIN");
    public static final ProcessingRole PROCESS_MANAGER = new ProcessingRole("PROCESS_MANAGER");
    public static final ProcessingRole PROCESS_USER = new ProcessingRole("PROCESS_USER");
    public static final ProcessingRole PROCESS_SCRUB_N_VERSION_CONTROL = new ProcessingRole("PROCESS_SCRUB_N_VERSION_CONTROL");
    public static final ProcessingRole PROCESS_SCRUB = new ProcessingRole("PROCESS_SCRUB");
    public static final ProcessingRole PROCESS_SCRUB_VERSION_CONTROL = new ProcessingRole("PROCESS_SCRUB_VERSION_CONTROL");
    public static final ProcessingRole QE_USER = new ProcessingRole("QE_USER");
    
    private static HashMap roleCache = new HashMap(5);
    static {
    	roleCache.put(PROCESS_SUPERADMIN.getRole(), PROCESS_SUPERADMIN);
    	roleCache.put(PROCESS_ADMIN.getRole(), PROCESS_ADMIN);
        roleCache.put(PROCESS_MANAGER.getRole(), PROCESS_MANAGER);
        roleCache.put(PROCESS_USER.getRole(), PROCESS_USER);
        roleCache.put(PROCESS_SCRUB_N_VERSION_CONTROL.getRole(), PROCESS_SCRUB_N_VERSION_CONTROL);
        roleCache.put(PROCESS_SCRUB.getRole(), PROCESS_SCRUB);
        roleCache.put(PROCESS_SCRUB_VERSION_CONTROL.getRole(), PROCESS_SCRUB_VERSION_CONTROL);
        roleCache.put(QE_USER.getRole(), QE_USER);
    }

    private static Set allRoles = Collections.unmodifiableSet( new HashSet(roleCache.values()));

    public static final ProcessingRole createRole( String roleName) {
        if (!roleCache.containsKey(roleName)) {
            throw new IllegalArgumentException("Unknow role name specified: " + roleName);
        }
        return (ProcessingRole) roleCache.get(roleName);
    }
    public static final Set getAllRoles() {
        return allRoles;
    }
    public static final boolean isDefined(String roleName) {
        return roleCache.containsKey(roleName);
    }
}
