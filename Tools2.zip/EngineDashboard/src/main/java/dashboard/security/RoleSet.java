package dashboard.security;

import java.io.Serializable;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

public class RoleSet implements Serializable {
    private Set roleSet;
    public RoleSet() {
        roleSet = new HashSet();
    }

    private RoleSet(Set s) {
        roleSet = s;
    }
    public RoleSet addRole(ProcessingRole pr) {
        if( null != pr) {
            roleSet.add(pr);
        }
        return this;
    }

    public RoleSet removeRole(ProcessingRole pr) {
        roleSet.remove(pr);
        return this;
    }
    public boolean hasRole(ProcessingRole pr) {
        return roleSet.contains(pr);
    }

    private Set getRoleSet() {
        return roleSet;
    }
    public Set getSet() {
        return Collections.unmodifiableSet(roleSet);
    }

    public boolean equals(Object obj) {
        if (null != obj && obj instanceof RoleSet) {
            Set s = ((RoleSet) obj).getRoleSet();
            if (roleSet.equals(s)) {
                return true;
            } 
        }
        return false;
    }
    public RoleSet substract(RoleSet rs) {
        Set s = new HashSet();
        s.addAll( roleSet);
        s.removeAll( rs.getRoleSet());
        return new RoleSet(s);
    }
    public RoleSet union(RoleSet rs) {
        Set s = new HashSet();
        s.addAll( roleSet);
        s.addAll( rs.getRoleSet());
        return new RoleSet(s);
    }
    public RoleSet intersect(RoleSet rs) {
        Set s = new HashSet();
        s.addAll( roleSet);
        s.retainAll( rs.getRoleSet());
        return new RoleSet(s);
    }
    
}
