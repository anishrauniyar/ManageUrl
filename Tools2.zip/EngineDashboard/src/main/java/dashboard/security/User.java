package dashboard.security;

import java.io.Serializable;

public class User implements Serializable{
    private String userId;
    private String loginName = "";
    private String userName;
    private String actDirName="";
   
	public User(){}
    public User(String userId, String loginName, String userName,String actDirName) {
        this.userId = (userId==null)? "": userId.trim();
        this.loginName = (loginName==null)? "": loginName.trim();
        this.userName = (userName==null)? "": userName.trim();
        this.actDirName=(actDirName==null)?"":actDirName.trim();
    }
	public User(String userId, String loginName, String userName) {
        this.userId = (userId==null)? "": userId.trim();
        this.loginName = (loginName==null)? "": loginName.trim();
        this.userName = (userName==null)? "": userName.trim();
        
    }
    public String getUserId() {
        return userId;
    }
    public String getLoginName() {
        return loginName;
    }
    public String getUserName() {
        return userName;
    }
    public String getActDirName() {
		return actDirName;
	}

    public String toString() {
        return loginName;
    }
	public User setUserId(String userId) {
		this.userId = userId;
		return this;
	}
	public User setLoginName(String loginName) {
		this.loginName = loginName;
		return this;
	}
	public User setUserName(String userName) {
		this.userName = userName;
		return this;
	}
}
