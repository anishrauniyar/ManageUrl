package dashboard.db;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import dashboard.data.Schema;

public class PingHost {
	private static Object[] HOST_REACHABLE = new Object[] { Boolean.TRUE,
			"Host is reachable." };

	public Object[] ping(String host) throws UnknownHostException, IOException {
		Object[] retVal = HOST_REACHABLE; 
		InetAddress inet = InetAddress.getByName(host);

		if (!inet.isReachable(5000)) {
			retVal = new Object[] {Boolean.FALSE,host};
		}
		/*
		 * System.out.println("Sending Ping Request to " + ipAddress);
		 * System.out.println(inet.isReachable(5000) ? "Host is reachable" :
		 * "Host is NOT reachable");
		 */
		return retVal;
	}
}
