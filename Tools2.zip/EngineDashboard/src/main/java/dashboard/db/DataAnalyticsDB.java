package dashboard.db;

import java.io.File;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import dashboard.data.ClientInfo;
import dashboard.data.ImportFolder;
import dashboard.engine.ImportDataControl;
import dashboard.util.EDBUtil;
import dashboard.util.FileUtil;

public class DataAnalyticsDB {

    protected Log logger = LogFactory.getLog(getClass());
    
    private static final String CLIENTS_LIST_QRY =  
    	" SELECT a.ClientId, ClientName, a.ClientId||' - '||ClientName, Prescrub_Platform, Prescrub_Server, VSSScrubFolder, " +
    	"		 VSSImportFolder, CLIENTTYPE, b.CLIENTDATAFOLDER "+
    	" FROM EDB_OAMCLIENTS a LEFT JOIN EDB_DATATRANSFERCLIENT b  ON a.clientid = b.clientid " +
		" ORDER BY 1";
    
    public List getDataClientList(DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CLIENTS_LIST_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                ClientInfo cInfo = new ClientInfo();
    			cInfo.setClientId(rs.getString(1));
				cInfo.setClientName(rs.getString(2));
				cInfo.setClientId_Name(rs.getString(3));
				cInfo.setPrescrubPlatfrom(rs.getString(4));
				cInfo.setPrescrubServer(rs.getString(5));
				cInfo.setVssScrubFolder(rs.getString(6));
				cInfo.setVssImportFolder(rs.getString(7));
				cInfo.setClientType(rs.getString(8));
				cInfo.setClientDataFolder(rs.getString(9));
                ls.add(cInfo);
            }
        } catch(Exception ex) {
        	logger.info("[Error: DataAnalyticsDB.java: 1] " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }  
  
    
    private static final String DEFAULT_FOLDER_BY_SCRIPT = 
    	" Select DATAFOLDER from EDB_IMPORTFOLDERINFO  where clientid = ? and upper(scriptname) = ? and upper(IMPORTSERVER)=?"; 
    
    private String getDefaultFolderbyScriptName(DataSource ds, String clientId, String scriptname, String prescrubServer) throws Exception {    	
    	String foldername = "";     	
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DEFAULT_FOLDER_BY_SCRIPT);
            ps.setString(1, clientId);
            ps.setString(2, scriptname.toUpperCase());
            ps.setString(3, prescrubServer.toUpperCase());
            
            rs = ps.executeQuery();
            while (rs.next()) {
            	foldername = rs.getString(1);
	        }
	    } catch(Exception ex) {
	        logger.info("[Error: DataAnalyticsDB.java: 2] " + ex.getMessage());
	        throw ex;
	    }finally {
	        DBUtil.release(cnn, ps, rs);
	    }	    
	    return foldername;
	}
    

    public List getScriptsWithDataLoc(DataSource ds, String clientId, String payer, String dataMonth, String[] scriptsname, String prescrubServer, String dataFilePath) throws Exception {    	
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();  
        
        String TRANSFER_FILE_DIR  = 
        	"SELECT DataFolder FROM EDB_DATATRANSFERFOLDER where clientid='"+clientId+ 
        				"' and upper(datamonth)='"+dataMonth.toUpperCase()+"'"+
        				"  and upper(ImportServer)='"+prescrubServer.toUpperCase()+"'"; 
        	   
        TRANSFER_FILE_DIR += "".equals(payer) ? "" : " and payer = '" +payer+"'" ;  
        	   
        List folderlst = new ArrayList();  
        cnn = ds.getConnection();
        ps = cnn.prepareStatement(TRANSFER_FILE_DIR);            
        rs = ps.executeQuery();
        
        try{
	        while (rs.next()) {  
	        	folderlst.add(rs.getString(1));  
	        }
	      
	    } catch(Exception ex) {
	    	logger.info("[Error: DataAnalyticsDB.java: 3] " + ex.getMessage());
	        throw ex;
	    }finally {
	        DBUtil.release(cnn, ps, rs);
	    }
	    
    	for(int i= 0; i<scriptsname.length; i++){   
    		List dataFileList = new LinkedList();
    		  		
    		String defaultFolder = getDefaultFolderbyScriptName(ds,clientId,scriptsname[i],prescrubServer);     		
    		
    		if(!"".equals(EDBUtil.ifNullBlank(defaultFolder))) {    			
    			if("".equals(payer)){
    				dataFileList = ImportDataControl.getDataFileList(new File(dataFilePath+EDBUtil.fileseperator+defaultFolder));
    			}else {
    				dataFileList = ImportDataControl.getDataFileList(new File(dataFilePath+EDBUtil.fileseperator+payer+EDBUtil.fileseperator+defaultFolder));
    			}     			
    		}    		
    		
    		ImportFolder importFolder = new ImportFolder();  
            importFolder.setClientId(clientId);
            importFolder.setScriptName(scriptsname[i]);
            importFolder.setPayer(payer);
            importFolder.setDefaultDataFolder(defaultFolder);
            importFolder.setDataFolderList(folderlst);    
            importFolder.setFolderContainsData(!dataFileList.isEmpty()); 
            importFolder.setDataFileList(dataFileList); 
            
            ls.add(importFolder);
    	}    	
        return ls;
    }    
    
    private static final String SAVE_DEFAULT_FOLDER_BY_SCRIPT = 
    	" Insert into EDB_IMPORTFOLDERINFO (CLIENTID, PAYER, SCRIPTNAME, DATAFOLDER, IMPORTSERVER) values (?,?,?,?,?)";

    private static final String COUNT_DEFAULT_FOLDER_BY_SCRIPT = 
    	"SELECT Count(*) from EDB_IMPORTFOLDERINFO WHERE Upper(ScriptName) = ? and Upper(IMPORTSERVER)=?";
    
    private static final String UPDATE_DEFAULT_FOLDER_BY_SCRIPT = 
    	" UPDATE EDB_IMPORTFOLDERINFO SET CLIENTID = ?, PAYER = ?, DATAFOLDER = ? WHERE Upper(ScriptName) = ? and Upper(IMPORTSERVER)=?";
    
    public boolean saveDefaultFolderbyScriptName(DataSource ds, String clientId, String payer, String scriptname, String foldername, String datamonth, String importserver) throws Exception {    	
    	Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;        
        int retval = 0;
        int count=0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(COUNT_DEFAULT_FOLDER_BY_SCRIPT);
            ps.setString(1, scriptname.toUpperCase());
            ps.setString(2, importserver.toUpperCase());
            
            rs = ps.executeQuery();
        	
        	if (rs.next()){
        		count = rs.getInt(1);
        	} 
            
            if(count > 0){
            	 ps = cnn.prepareStatement(UPDATE_DEFAULT_FOLDER_BY_SCRIPT);
            	 ps.setString(1, clientId);
            	 ps.setString(2, payer);
            	 ps.setString(3, foldername);
            	 ps.setString(4, scriptname.toUpperCase());
            	 ps.setString(5, importserver.toUpperCase());
            	 retval = ps.executeUpdate();
            }else{
            	ps = cnn.prepareStatement(SAVE_DEFAULT_FOLDER_BY_SCRIPT);
            	ps.setString(1, clientId);
            	ps.setString(2, payer);
            	ps.setString(3, scriptname);
            	ps.setString(4, foldername);
            	ps.setString(5,importserver);
            	retval = ps.executeUpdate();
            }
	    } catch(Exception ex) {
	    	logger.info("[Error: DataAnalyticsDB.java: 4] " + ex.getMessage());
	        throw ex;
	    }finally {
	        DBUtil.release(cnn, ps, rs);
	    }	
	    return retval>0;
	}
        
    
    private static final String DATA_TRANSFER_MONTHS_BY_CLIENT =     	
    	" SELECT distinct(DataMonth) from EDB_DATATRANSFERFOLDER where clientid =? ";
    
    public List getDataTransferMonth(DataSource ds, String clientId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DATA_TRANSFER_MONTHS_BY_CLIENT);
            ps.setString(1, clientId);
            rs = ps.executeQuery();
            while (rs.next()) {
                ls.add(rs.getString(1));
            }
        } catch(Exception ex) {
        	logger.info("[Error: DataAnalyticsDB.java: 5] " + ex.getMessage());
            throw ex;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
   
    private static final String INSERT_DATA_TRANSFER_IMPORT_LOG =
        " INSERT INTO EDB_DATATRANSFERCLIENT (clientid, importserver, clientdatafolder) values (?,?,?)";    
    private static final String UPDATE_DATA_TRANSFER_IMPORT_LOG =
    	" UPDATE EDB_DATATRANSFERCLIENT  SET importserver = ?, clientdatafolder   =? WHERE clientid = ?";        
    private static final String COUNT_DATA_TRANSFER_IMPORT_LOG =
    	" SELECT count(*) from EDB_DATATRANSFERCLIENT  where clientid = ?";   
    
    public void logDataTransferClients(DataSource ds, String destMachine,String basepath, String[] copyfiles, String selectedclient) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count=0;
       
        try {
            cnn = ds.getConnection();   
        	String clientid = selectedclient.substring(3,6);
            
            for (int i = 0; i < copyfiles.length; i++) { 
	            	/**
	            	 * Resolve last import data date.
	            	 */  	            	
	            	String absfile = basepath + URLDecoder.decode(copyfiles[i]);			
	    			String temppath1 = absfile.substring(0,absfile.lastIndexOf(selectedclient));
	    			String temppath2 = absfile.substring(absfile.lastIndexOf(selectedclient),absfile.length());
	    			
	    			String[] temparr = temppath2.split(EDBUtil.fileseperator);
	    			String lastimport = "";
	    			String datamonth = "";
	    			
	    			if (temparr.length>2){
	    				lastimport =temppath1 + temparr[0] + EDBUtil.fileseperator+ temparr[1] + EDBUtil.fileseperator;//+temparr[2];	
	    				datamonth = temparr[2].trim();
	    			}
            	
	            	ps = cnn.prepareStatement(COUNT_DATA_TRANSFER_IMPORT_LOG);	
	            	ps.setString(1, clientid);
	            	rs = ps.executeQuery();
	            	
	            	if (rs.next()){
	            		count = rs.getInt(1);
	            	} 

	    			if (!"".equals(lastimport)){	            	
		                if ( count > 0 ){ 	               
		                	ps = cnn.prepareStatement(UPDATE_DATA_TRANSFER_IMPORT_LOG);	     
		    	            ps.setString(1, destMachine);
		    	            ps.setString(2, lastimport);
		    	            ps.setString(3, clientid);
		                	ps.executeUpdate();			                	
		                }else {         	
		                	ps = cnn.prepareStatement(INSERT_DATA_TRANSFER_IMPORT_LOG);	        
		    	            ps.setString(1, clientid);
		    	            ps.setString(2, destMachine);
		    	            ps.setString(3, lastimport );
		    	            ps.executeUpdate();	
		                }	 
	    			}	    			
            }	            

        } catch(Exception ex) {
        	logger.info("[Error:DataAnalyticsDB.java: 6] " + ex.getMessage()); 
        	throw ex;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
    }    
    
    private static final String GET_DEFAULT_SCRUBS_SCRIPTS =     	
    	"SELECT SCRIPTNAME, SVNURL FROM EDB_EXTRASCRUBSCRIPT WHERE Upper(EXEGROUP) = ? ORDER BY EXEORDER ASC ";
    
    public List getDefaultScrubScripts(DataSource ds, String exeGroup) throws Exception{
    	List lst = new LinkedList();
    	Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;        
        	cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_DEFAULT_SCRUBS_SCRIPTS);
            ps.setString(1, exeGroup.toUpperCase());
            rs = ps.executeQuery();      
            
        try {
            while (rs.next()) {
            	String[] tempArr= new String[2];
            	tempArr[0] = rs.getString(1);
            	tempArr[1] = rs.getString(2);
                lst.add(tempArr);
            }
        } catch(Exception ex) {
        	logger.info("[Error: DataAnalyticsDB.java: 7] " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return lst;
    }
    
    private static final String INSERT_DATA_TRANSFER_IMPORT_INFO_LOG =
        " INSERT INTO EDB_DATATRANSFERFOLDER (clientid, DATAMONTH, DATAFOLDER, PAYER, TRANSFERDATE, IMPORTSERVER) values (?,?,?,Nvl(?, 'NULL'), SysDate,?)";
    
    private static final String DELETE_DATA_TRANSFER_IMPORT_INFO_LOG =
        " DELETE FROM EDB_DATATRANSFERFOLDER WHERE clientid = ? AND Upper(DATAMONTH) = ? AND DATAFOLDER = ? AND trim(PAYER) = trim(?) AND IMPORTSERVER = ?";
    
    public void logDataTransferFolders(DataSource ds, String destMachine, String xmlfilename, String selectedclient, String clientType) throws Exception {
    	Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
    	String clientid = selectedclient.substring(3,6);     	
    	
    	Set folderset = new HashSet(); 
    	folderset = getDataTransferFolderListfromXMLFile(xmlfilename);
    	
        
        try {
            cnn = ds.getConnection();              	
	        Iterator it = folderset.iterator();
	        while (it.hasNext()) {
	            String str= it.next().toString();
	            String[] temparr = str.split("/[a-zA-Z]{3}[0-9]{2}/");
	            
	            if (temparr.length < 2) continue; 
	            
	            String beforemonthdir = temparr[0];
	            String month="";
	            String payer = "";
	            String aftermonthdir = temparr[1]; 
	            	            
	            month = str.substring(beforemonthdir.length()+1, str.indexOf(aftermonthdir)-1);  
	            
	            if ("P".equalsIgnoreCase(clientType)){
	    			String[] temparray = aftermonthdir.split(EDBUtil.fileseperator);
	            	if (temparray.length < 2) continue; 	            	
	            	payer = temparray[0];
	            	aftermonthdir = temparray[1]; 
	            }
	            
	            if(aftermonthdir.endsWith((EDBUtil.fileseperator))){
	            	aftermonthdir = aftermonthdir.substring(0,aftermonthdir.length()-1); 	            	
	            }
	            	            
	            /*System.out.println("str::"+str);
	            System.out.println("beforemonthdir::"+beforemonthdir);  
	            System.out.println("Month::"+month); 
	            System.out.println("payer::"+payer);
	            System.out.println("aftermonthdir::"+aftermonthdir);	            
	            System.out.println("\n");*/
	            
	            ps = cnn.prepareStatement(DELETE_DATA_TRANSFER_IMPORT_INFO_LOG);
	            ps.setString(1, clientid.trim());
	            ps.setString(2, month.toUpperCase().trim());
	            ps.setString(3, aftermonthdir.trim() );
	            ps.setString(4, "".equals(EDBUtil.ifNullBlank(payer))?"NULL":payer);
	            ps.setString(5, destMachine);
	            ps.executeUpdate();        	
	        	
	            ps = cnn.prepareStatement(INSERT_DATA_TRANSFER_IMPORT_INFO_LOG);
	            ps.setString(1, clientid.trim());
	            ps.setString(2, month.trim());
	            ps.setString(3, aftermonthdir.trim() );
	            ps.setString(4, payer);
	            ps.setString(5, destMachine);
	            ps.executeUpdate();
	            
	        }
        } catch(Exception ex) {
        	logger.info("[Error:DataAnalyticsDB.java: 8] " + ex.getMessage()); 
        	throw ex;
        } finally {
            DBUtil.release(cnn, ps, rs);
        } 
    } 
    
    /**
     * Reads XML file that is generated after the data file transfer
     * and returns a distinct set of data transferred folder names.
     * @param scriptfilename
     * @return
     * @throws Exception
     */
    private Set getDataTransferFolderListfromXMLFile(String xmlfilename) throws Exception{
    	Set folderset = new HashSet();    
    	try {
    		
	    	replaceSpcecialCharFromXMLFile(xmlfilename); 
	    	
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document document = db.parse(xmlfilename);
	        NodeList nl = document.getElementsByTagName("Loop");
	        int len = nl.getLength();        
	        Element rootElement = document.getDocumentElement();    
	        
	        for (int i = 0; i < len; i++) {        	
	        	//String source = rootElement.getElementsByTagName("source").item(i).getFirstChild().getNodeValue();
	        	String destination = rootElement.getElementsByTagName("destination").item(i).getFirstChild().getNodeValue();
	        	String copiedfile = rootElement.getElementsByTagName("copiedfile").item(i).getFirstChild().getNodeValue(); 
	       	
	        	String[] tempstr = copiedfile.trim().split("\n\n")[0].split("\n");   
	    		
	        	for (int j=0 ;j<tempstr.length; j++){
	        		String filestr= tempstr[j];
	        		if ("building file list ... done".equalsIgnoreCase(filestr)){
	        			continue;
	        		} 
	        		        		
	        		if (filestr.indexOf(EDBUtil.fileseperator)>-1){
	        			folderset.add(destination+filestr.substring(0,filestr.lastIndexOf(EDBUtil.fileseperator)).trim());
	        		}else{
	        			folderset.add(destination);
	        		}
	        	}        	    
	        }
    	} catch(Exception ex) {
        	logger.info("[Error:DataAnalyticsDB.java: 9] " + ex.getMessage()); 
        	throw ex;
        } 
        return folderset;
    }    
    
    /**
	 * Replace special characters in the xml file that gives parsing exception
	 * while reading the source xml file
	 * 
	 * @param sourcefile
	 * @throws Exception
	 */
    private void replaceSpcecialCharFromXMLFile(String xmlfilename) throws Exception {
 	    String modifiedString = FileUtil.readText(new File(xmlfilename)).toString();
 	    	   modifiedString = modifiedString.replaceAll("&","&amp;");
 	    	   modifiedString = modifiedString.replaceAll("'", "&apos;"); 	    
 	    	   //modifiedString = modifiedString.replaceAll("<", "&lt;");
 	    	   //modifiedString = modifiedString.replaceAll(">", "&gt;");
 	    	   //modifiedString = modifiedString.replaceAll("\"", "&quot;");
 	    FileUtil.writeToTextFile(modifiedString, new File(xmlfilename));
    }
    															
}