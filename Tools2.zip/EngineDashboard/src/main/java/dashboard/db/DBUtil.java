package dashboard.db;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Calendar;

public class DBUtil {

    public static void release(Connection cnn, Statement stmt, ResultSet rs ) {
        if (rs != null ) {
            try {
                rs.close();
            }catch(Exception ex) { }
        }
        if (stmt != null ) {
            try {
                stmt.close();
            }catch(Exception ex) { }
        }
        if (cnn != null ) {
            try {
                cnn.close();
            }catch(Exception ex) { }
        }
    }
    
	public static void close(Statement stmt) {
		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception ex) {
			}
		}
	}

	public static void close(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (Exception ex) {
			}
		}
	}

    private static final int MAX_ID_LEN = 6;
    public static String generateSuffixForId() {
        String retStr = null;
        long sinceEpoch = Calendar.getInstance().getTime().getTime();
        String str = Long.toString(sinceEpoch);
        StringBuffer sb  = new StringBuffer(str);
        sb = sb.reverse();
        if (sb.length() > MAX_ID_LEN) {
            retStr = sb.substring(0, MAX_ID_LEN);
        } else {
            retStr = sb.toString();
        }
        return retStr;
    }

    public static void rollbackIfConnected(Connection cnn) {
        if (cnn != null) {
            try {
                cnn.rollback();
            } catch(Exception ex) {}
        }
        cnn = null;
    }
}
