package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.Schema;
import dashboard.engine.SQLProcessStatus;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;

public class DRTransferDB {

	protected Log logger = LogFactory.getLog(getClass());
	protected DataSource dataSource;

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	private static final String PROCESS_KILLED_MESSAGE = "Kill operation initiated by: ";
/*	private static final String DR_RUNNING_STATUS_QUERY = ""
			+ "SELECT servergroupid AS SERVERGROUPNAME, "
			+ "       host          AS serverName, " + "       port, "
			+ "       service, " + "       'CLIENTNAME' as CLIENTNAME, "
			+ "       schemaname, " + "       engineversion, "
			+ "       eventname     AS taskLabel, " + "       threadcount, "
			+ "       'STATUS' as STATUS , " + "       loginname,"+" executionnumber, "
			+ "       starttime,   "
			+ "       eventdesc   "
			+ "FROM   processeventlog "
			+ "WHERE  eventname LIKE '"+TaskType.DR_DATA_TRANSFER.getTaskLabel()+"' "
			+ "       AND endtime IS NULL ";*/
	private static final String DR_RUNNING_STATUS_QUERY = ""
			+ "SELECT a.servergroupid AS SERVERGROUPNAME, "
			+ "       a.host          AS serverName, "
			+ "       a.port, "
			+ "       a.service, "
			+ "       a.schemaname, "
			+ "       a.eventname     AS taskLabel, "
			+ "       b.statusid      AS STATUS, "
			+ "       b.frontsize, "
			+ "       b.loginname, "
			+ "       b.mounted, "
			+ "       b.destschemaname, "
			+ "       b.curjobid AS executionnumber, "
			+ "       b.refjobid, "
			+ "       a.starttime, "
			+ "       a.eventdesc "
			+ "FROM   processing.processeventlog a "
			+ "       join processing.tbl_drsync_transfer_status b "
			+ "         ON ( a.executionnumber = b.refjobid )"
			+ "       AND a.endtime IS NULL";

	/**
	 * method to get all the running DR Transfer Status
	 * @return list of TaskKey
	 */
	public List<TaskKey> getRunningDRTransfer() {
		List<TaskKey> allRunningStatus = new ArrayList<TaskKey>();
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(DR_RUNNING_STATUS_QUERY);
			rs = ps.executeQuery();
			while (rs.next()) {
				Schema schema = new Schema();
				schema.setServerGroupName(rs.getString("SERVERGROUPNAME"));
				schema.setServerName(rs.getString("serverName"));
				schema.setPort(rs.getString("port"));
				schema.setService(rs.getString("service"));
				//schema.setClientName(rs.getString("CLIENTNAME"));
				//schema.setEngineVersion(rs.getString("engineversion"));
				schema.setSchemaSize(rs.getString("frontsize") ,true);
				schema.setSchemaName(rs.getString("destschemaname"));
				schema.setMountedOn(rs.getString("mounted"));

				TaskKey key = new TaskKey();
				key.setThreadCount(4);
				key.setSQLProcessStatus(SQLProcessStatus.RUNNING);
				key.setUserName(rs.getString("loginname"));
				key.setSchemaName(rs.getString("schemaname"));
				key.setExecutionNumber(rs.getLong("executionnumber"));
				key.setStartDate(rs.getTimestamp("starttime"));
				key.setEventDesc(rs.getString("eventdesc"));
				key.setRefjobId(rs.getString("refjobid"));

				key.setSchema(schema);
				key.setTaskType(TaskType.DR_DATA_TRANSFER);
				allRunningStatus.add(key);
			}
		} catch (SQLException e) {
			System.out.println(DR_RUNNING_STATUS_QUERY);
			logger.error("Error while getting Running data Transfer >>"
					+ DR_RUNNING_STATUS_QUERY);
			e.printStackTrace();
		}
		finally
		{
			 DBUtil.release(cnn, ps, rs);
		}
		return allRunningStatus;

	}
	
	
	private static final String KILL_DRTRANSFER = "UPDATE PROCESSEVENTLOG SET ENDTIME = SYSDATE WHERE EXECUTIONNUMBER = ?";
	
	/*
	 * method to kill dr transfer by updating end time for the given execution number
	 * @return row updated or 0
	 */
	public int killDRTransfer(Long execno){
		Connection cnn = null;
		PreparedStatement ps = null;
		try{
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(KILL_DRTRANSFER);
			ps.setLong(1, execno);
			return ps.executeUpdate();
		}catch(SQLException e){
			System.out.println(KILL_DRTRANSFER);
			logger.error("Error while killing dr transfer for execution number "+execno);
			e.printStackTrace();
			return 0;
		}
		finally
		{
			 DBUtil.release(cnn, ps, null);
		}
	}
	
	private static final String IS_DR_TRANSFER_ONGOING = "SELECT COUNT(ENDTIME) AS ISRUNNING FROM PROCESSEVENTLOG WHERE EXECUTIONNUMBER = ?";
	
	/**
	 * 
	 * method checking whether dr transfer is ongoing or not
	 * @param execno
	 * @return true/false
	 */
	public boolean isDRTransferOngoing(Long execno){
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;
		boolean isRunning = false;
		try{
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(IS_DR_TRANSFER_ONGOING);
			ps.setLong(1,execno);
			rs = ps.executeQuery();
			while(rs.next()){
				count = rs.getInt("ISRUNNING");
			}
			if(count == 0){
				isRunning = true;
			}
			return isRunning;
		}catch(SQLException e){
			System.out.println(IS_DR_TRANSFER_ONGOING);
			logger.error("Error while checking  dr transfer is ongoing for execution number "+execno);
			e.printStackTrace();
			return isRunning;
		}
		finally
		{
			 DBUtil.release(cnn, ps, rs);
		}
	}
}
