package dashboard.db;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

import dashboard.ComponentFactory;
import dashboard.util.*;


import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class checkFrontSchema{
	protected Log logger = LogFactory.getLog(getClass());
    private DataSource dataSource = null;
    
    public void setDataSource(DataSource ds) {
        dataSource = ds;
    }
   

    public int check_status(String schemaname)
    {
    	 
         Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rset = null;
         int count=0;
                     
         
         ComponentFactory compFactory = ComponentFactory.getInstance();
         EnvInfo envinf = compFactory.getEnvInfo();
         String heuser= envinf.getHeuser();
         String heuserqc=envinf.getHeuserqc();
         
         
         schemaname=schemaname.trim();    
         String query = "select count(1) cnt from" +
         				"(select appid from "+heuser+".usr_apps where DBUSERID ='"+ schemaname +
         				"' union "+
         				"select appid from "+heuserqc+".usr_apps where DBUSERID ='"+ schemaname +
         				"')";
         System.out.println(query);
         try 
         {
             cnn = dataSource.getConnection();
             ps = cnn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             rset = ps.executeQuery();        	   		
             while (rset.next ())
	     	 	{ 
	             count=rset.getInt(1);
	     	 	}
         } 
         catch (SQLException ex)
         { 
        	 System.out.println(ex);
        	 System.out.println("Could not connect to database");
         }
         
         finally {
             DBUtil.release(cnn, ps, rset);
         }
         return (count);
    }

    
}

