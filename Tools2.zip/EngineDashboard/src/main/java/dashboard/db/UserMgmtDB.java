package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.security.User;

public class UserMgmtDB {

	private Log logger = LogFactory.getLog(getClass());

	public static final String GET_MAPPED_USERS_BY_ROLE = ""
			+ "SELECT a.userid,a.username,a.loginname FROM usr_users a inner join db_usersroles b ON a.userid=b.userid AND Upper(B.userrole)=Upper(?) and a.oamstatus=1 "
			+ "ORDER BY A.USERNAME";

	public static final String GET_UNMAPPED_USERS_BY_ROLE = ""
			+ "SELECT X.USERID,X.USERNAME,X.LOGINNAME FROM USR_USERS X WHERE X.USERID NOT IN ( "
			+ "SELECT a.userid FROM usr_users a inner join db_usersroles b ON a.userid=b.userid WHERE Upper(B.userrole)=Upper(?) and a.oamstatus=1) and x.oamstatus=1 ORDER BY X.USERNAME";

	/**
	 * @Description: Returns Users for a given userRole. Note:If
	 *               flag=UNMAPPED_USER_LIST then returns users that doesn't
	 *               have this role
	 * @param userRole
	 * @param flag
	 * @param ds
	 * @return
	 * @throws SQLException
	 */
	public List<User> getUserListByUserRole(String userRole, String flag,
			DataSource ds) throws SQLException {
		List<User> users = new ArrayList<User>();
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String query = GET_MAPPED_USERS_BY_ROLE;
		if (flag != null && flag.equalsIgnoreCase("UNMAPPED_USER_LIST")) {
			query = GET_UNMAPPED_USERS_BY_ROLE;
		}
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(query);
			ps.setString(1, userRole);
			rs = ps.executeQuery();
			while (rs.next()) {
				users.add(new User().setUserId(rs.getString("userid"))
						.setUserName(rs.getString("username"))
						.setLoginName(rs.getString("loginname")));
			}
		} catch (SQLException e) {
			logger.error("Error on UserMgmtDB->getUserListByUserRole("
					+ userRole + "," + flag + ")", e);
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return users;
	}

	/**
	 * @Description: Generate Insert Query for inserting userroles
	 * @param users
	 * @param userRole
	 * @param s
	 * @return
	 * @throws SQLException
	 */
	public Statement generateBatchQry_changeUserRole(String[] users,
			String userRole, Statement s) throws SQLException {
		String query = "";
		for (int i = 0; i < users.length; i++) {
			query = "INSERT INTO DB_USERSROLES (USERID,USERROLE) "
					+ "VALUES ('" + users[i] + "','" + userRole + "')";
			s.addBatch(query);
		}
		return s;
	}

	/**
	 * @Description: Generates delete query for given users.
	 * @param users
	 * @return
	 */
	public static String generateQry_deleteUsersEntryFromRole(String[] users) {
		int i = 0;
		int length = users.length;
		System.out.println("Length :" + length);
		String deleteQry = "";
		String subQry = "";
		if (length == 1) {
			subQry = users[i];
		} else {
			for (int j = 0; j < users.length; j++) {
				subQry += users[j];
				if (i == j) {
					subQry += ",";
				}
				if (i < users.length - 2) {
					i++;
				}
			}

		}
		deleteQry = "DELETE FROM DB_USERSROLES WHERE USERID IN (" + subQry
				+ ")";
		return deleteQry;
	}

	public static void main(String[] args) {
		String[] users = { "binay" };
		System.out.println(generateQry_deleteUsersEntryFromRole(users));
	}

	/**
	 * @Description:Deletes all users from db_usersroles table and assigns then
	 *                      new role userRole
	 * @param userRole
	 * @param users
	 * @param ds
	 * @return
	 * @throws SQLException
	 */
	public int changeUserRole(String userRole, String[] users, DataSource ds)
			throws SQLException {
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Statement s = null;
		int count[] = {};
		try {
			cnn = ds.getConnection();
			cnn.setAutoCommit(false);
			ps = cnn.prepareStatement(DELETE_ALL_USERS_FOR_A_ROLE);
			ps.setString(1, userRole);
			ps.executeUpdate();
			if (ps != null) {
				ps.close();
			}
			ps = cnn.prepareStatement(generateQry_deleteUsersEntryFromRole(users));
			ps.executeUpdate();

			s = cnn.createStatement();
			s = generateBatchQry_changeUserRole(users, userRole, s);
			count = s.executeBatch();
			cnn.commit();
		} catch (Exception e) {
			logger.error("Error on UserMgmtDB->updateUserRole(" + userRole
					+ ")", e);
			if (cnn != null) {
				cnn.rollback();
			}
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
			if (s != null) {
				s.close();
			}
		}
		return count.length;
	}

	private static final String DELETE_ALL_USERS_FOR_A_ROLE = "DELETE FROM db_usersroles WHERE upper(userrole) = upper(?)";

	public int deleteAllUsersForUserRole(String userRole, DataSource ds)
			throws SQLException {
		Connection cnn = null;
		PreparedStatement ps = null;
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(DELETE_ALL_USERS_FOR_A_ROLE);
			ps.setString(1, userRole.toUpperCase());
			return ps.executeUpdate();
		} catch (SQLException e) {
			logger.error("Error on UserMgmtDB->deleteAllUsersForUserRole("
					+ userRole + ")", e);
			throw e;
		} finally {
			DBUtil.release(cnn, ps, null);
		}
	}
}
