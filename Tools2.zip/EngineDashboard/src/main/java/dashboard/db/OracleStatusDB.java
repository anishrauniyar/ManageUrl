package dashboard.db;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


import java.util.List;
import java.util.LinkedList;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLWarning;

import dashboard.data.Schema;
import dashboard.data.OracleSystemData;

public class OracleStatusDB {


    public OracleSystemData getOracleSystemData(Schema schema) throws Exception {
        OracleSystemData sysData = new OracleSystemData();
        Connection cnn = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            
            sysData.setMemoryDistribution( getMemoryDistribution (cnn) );
            sysData.setStorageMetrics( getStorageMetrics (cnn) );
            sysData.setOSMetrics( getOSMetrics (cnn) );
        } finally {
            DBUtil.release(cnn, null, null);
        }
        return sysData;
    }

    private static final String MEM_DIST_QRY =
        "SELECT sganame,sgasize FROM SYSMAN.MGMT$DB_SGA " +
        " WHERE sganame IN " +
        "       ('Java Pool (MB)','Fixed SGA (KB)','Shared Pool (MB)','Buffered Cache (MB)','Large Pool (KB)') " +
        "   AND host_name=(SELECT host_name FROM v$instance) ";

    private static List getMemoryDistribution(Connection cnn) throws Exception {
        PreparedStatement ps = null;
        ResultSet rs = null;
        LinkedList ls = new LinkedList();
        try {
            ps = cnn.prepareStatement( MEM_DIST_QRY);
            rs = ps.executeQuery();
            while(rs.next()) {
                String sgaName = rs.getString(1);
                Double sgaSize = new Double(rs.getDouble(2));
                ls.add( new Object[] { sgaName, sgaSize});
            }
        }finally {
            DBUtil.release(null, ps, rs);
        }
        return ls;
    }

    private static final String STORAGE_MET_QRY =
        "select  max(decode(column_label,'Filesystem',key_value,null)) \"File System\", " +
        "        max(decode(column_label,'Filesystem Size (MB)',value,null)) \"File System Size (MB)\", " +
        "        max(decode(column_label,'Filesystem Space Available (%)',value,null)) " +
        "        \"Filesystem Space Available (%)\" " +
        "  from " +
        "      (SELECT column_label, key_value, value " +
        "         FROM SYSMAN.MGMT$METRIC_CURRENT " +
        "        WHERE target_type='host' and metric_name='Filesystems' " +
        "          AND target_name=(SELECT host_name FROM v$instance)) a " +
        " group by  key_value ";
    private static List getStorageMetrics (Connection cnn) throws Exception {
        PreparedStatement ps = null;
        ResultSet rs = null;
        LinkedList ls = new LinkedList();
        try {
            ps = cnn.prepareStatement( STORAGE_MET_QRY);
            rs = ps.executeQuery();
            while(rs.next()) {
                String fileSystem = rs.getString(1);
                Double fileSystemSize = new Double(rs.getDouble(2));
                Double available = new Double( rs.getDouble(3));
                ls.add( new Object[] { fileSystem, fileSystemSize, available});
            }
        }finally {
            DBUtil.release(null, ps, rs);
        }
        return ls;
    }


    private static final String OS_MET_QRY =
        "SELECT  column_label, value " +
        "  FROM  SYSMAN.MGMT$METRIC_CURRENT " +
        " WHERE target_type='host' and metric_name='Load' " +
        "   AND target_name=(SELECT host_name FROM v$instance) " +
        "   AND column_label IN ( " +
        "   'CPU in IO-Wait (%)', " +
        "   'CPU in System Mode (%)', " +
        "   'CPU in User Mode (%)', " +
        "   'CPU Utilization (%)', " +
        "   'Memory Utilization (%)', " +
        "   'Free Memory (%)', " +
        "   'Total Processes', " +
        "   'Total Users', " +
        "   'Swap Utilization (%)', " +
        "   'Total I/O (per second)') ";

    private static List getOSMetrics(Connection cnn) throws Exception {
        PreparedStatement ps = null;
        ResultSet rs = null;
        LinkedList ls = new LinkedList();
        try {
            ps = cnn.prepareStatement( OS_MET_QRY);
            rs = ps.executeQuery();
            while(rs.next()) {
                String colName = rs.getString(1);
                Double val = new Double(rs.getDouble(2));
                ls.add( new Object[] { colName, val});
            }
        }finally {
            DBUtil.release(null, ps, rs);
        }
        return ls;
    }

    private static final String INDX_STATUS_SQL = "SELECT Count(*) FROM user_indexes";
    public int getIndexCount(Schema schema) throws Exception {
        return getCountFromSQL( schema, INDX_STATUS_SQL);
    }

    private static final String TAB_PROC_COUNT_SQL =
        "SELECT count(*) FROM user_objects WHERE object_type IN ('TABLE', 'PROCEDURE', 'PACKAGE', 'FUNCTION')";
    public int getProcNTableCount(Schema schema) throws Exception {
        return getCountFromSQL( schema, TAB_PROC_COUNT_SQL);
    }

    private static final String HRHP_COUNT_SQL
        = "SELECT Count(*) FROM user_tables WHERE (table_name LIKE 'HP%' OR table_name LIKE 'HR%')";
    public int getHRHPCount(Schema schema) throws Exception {
        return getCountFromSQL( schema, HRHP_COUNT_SQL);
    }

    private static final String ALL_OBJECT_QRY
        ="SELECT Count(*) FROM user_objects ";
    public int getAllObjectCount(Schema schema) throws Exception {
        return getCountFromSQL( schema, ALL_OBJECT_QRY);
    }
    private static int getCountFromSQL(Schema schema, String query) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int objectCount = -1;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement( query);
            rs = ps.executeQuery();
            if (rs.next()) {
                objectCount = rs.getInt(1);
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return objectCount;
    }

}
