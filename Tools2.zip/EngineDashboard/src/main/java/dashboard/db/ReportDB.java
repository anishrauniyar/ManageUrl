package dashboard.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Chart;
import dashboard.data.Report;
import dashboard.data.Schema;
import dashboard.util.Constants;
import dashboard.util.KeyValue;

public class ReportDB {

    protected Log logger = LogFactory.getLog(getClass());

    public ReportDB() {
    }
    
    private static final String REPORT_QRY =
        "select AppVersion, ReportName, ReportDesc, SourceDir, ReportId " +
        " from   "+Constants.REPORT_CONFIG_TBL+"   " +
        "where AppVersion = ? " +
        "order by ReportName ";

    private static final String REPORT_QRY_BYTYPE = 
    	"select AppVersion, ReportName, ReportDesc, SourceDir " +
        " from   "+Constants.REPORT_CONFIG_TBL+"   " +
        "where AppVersion = ? " +
        "and reportType = ? " +
        "order by ReportName ";

    private String appVersion = null;
    private String getAppVersion() {
        if (null != appVersion)
            return appVersion;
        appVersion = ComponentFactory.getInstance().getEnvInfo().getAppVersion();
        return appVersion;
    }

    private static final String REPORT_BY_NAME_QRY =
        "select ReportName, ReportDesc, SourceDir, ReportId " +
        " from   "+Constants.REPORT_CONFIG_TBL+"   " +
        "where AppVersion = ? " +
        //"  and ReportName = ? ";
        "  and ReportId = ? ";
    

    public Report getReportByName(DataSource dataSource, String reportId) throws Exception {
        Report rpt = null;

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( REPORT_BY_NAME_QRY);
            
            ps.setString(1, getAppVersion());
            ps.setInt(2, Integer.parseInt(reportId));
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                rpt = (new Report()).setReportName( rs.getString(1))
                    .setReportDesc( rs.getString(2)).setSourceDir( rs.getString(3))
                    .setReportId( rs.getInt(4));
            }    
            
        } finally {
            DBUtil.release(cnn, ps, rs);
        }       
        
        return rpt;
    }
    

    public List listReportModules(DataSource dataSource) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            

            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( REPORT_QRY);
            ps.setString(1, getAppVersion());
            rs = ps.executeQuery();
            
            while(rs.next()) {
                Report r = (new Report()).setReportName( rs.getString(2))
                    .setReportDesc( rs.getString(3)).setSourceDir( rs.getString(4))
                    .setReportId(rs.getInt(5));
                ls.add( r);
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    public List listReportModules(DataSource dataSource, String reportType) throws Exception {
    	
    	Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            

            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( REPORT_QRY_BYTYPE);
            ps.setString(1, getAppVersion());
            ps.setString(2, reportType);
            rs = ps.executeQuery();
            
            while(rs.next()) {
                Report r = (new Report()).setReportName( rs.getString(2))
                    .setReportDesc( rs.getString(3)).setSourceDir( rs.getString(4));
                ls.add( r);
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    private static final String INSERT_QRY =
        "INSERT INTO   "+Constants.REPORT_CONFIG_TBL+"  (AppVersion, ReportName, ReportDesc, SourceDir, ReportId) " +
        " values(?,?,?,?,?)";
    
    public int addReport(DataSource dataSource, Report report) throws Exception {
        int retVal = 0;

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( INSERT_QRY);
            ps.setString(1, getAppVersion());
            ps.setString(2, report.getReportName());
            ps.setString(3, report.getReportDesc());
            ps.setString(4, report.getSourceDir());     
            ps.setInt(5, report.getReportId());       

            retVal = ps.executeUpdate();
        } finally {
            DBUtil.release(cnn, ps, null);
        }

        return retVal;
    }

    private static final String DELETE_QRY =
        "delete   "+Constants.REPORT_CONFIG_TBL+"   where AppVersion = ? and ReportName = ? and ReportDesc = ? and SourceDir = ? and ReportId = ?";

    public int deleteReport(DataSource dataSource, Report report) throws Exception {
        int retVal = 0;

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( DELETE_QRY);
            ps.setString(1, getAppVersion());
            ps.setString(2, report.getReportName());
            ps.setString(3, report.getReportDesc());
            ps.setString(4, report.getSourceDir());            
            ps.setInt(5, report.getReportId());
            
            retVal = ps.executeUpdate();

            if (retVal > 0) {
                logger.info("Delete report: version: " + getAppVersion() + " :" + report );
            }

        } finally {
            DBUtil.release(cnn, ps, null);
        }

        return retVal;
    }

    private static final String UPDATE_QRY =
        "update   "+Constants.REPORT_CONFIG_TBL+"   set " +
        " ReportName = ? , ReportDesc = ? , SourceDir = ? , ReportId = ?" +
        " where AppVersion = ? " +
        "   and ReportName = ? and ReportDesc = ? and SourceDir = ? and ReportId = ?" ;

    public int updateReport(DataSource dataSource, Report oldReport, Report newReport) throws Exception {
        int retVal = 0;

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( UPDATE_QRY);
            ps.setString(1, newReport.getReportName());
            ps.setString(2, newReport.getReportDesc());
            ps.setString(3, newReport.getSourceDir());
            ps.setInt(4, newReport.getReportId());
            ps.setString(5, getAppVersion());
            ps.setString(6, oldReport.getReportName());
            ps.setString(7, oldReport.getReportDesc());
            ps.setString(8, oldReport.getSourceDir());
            ps.setInt(9, oldReport.getReportId());
            
            retVal = ps.executeUpdate();

            logger.info("Update report: version: " + getAppVersion() + " old:" + oldReport + " new:" + newReport);

        } finally {
            DBUtil.release(cnn, ps, null);
        }

        return retVal;
    }
    
    
    private static final String REPORT_QRY_BY_SCHEMA_OAM =    	
    	" SELECT reportid, reportname, execorder, execgroup, count(1) over (PARTITION BY execgroup) reportngrpcount from reportsbyclient" +
    	"        where clientid = CASE "+
		"                            WHEN Substr(?,1,2) = 'S0' THEN Substr(?,3,3) "+
		"                            ELSE Substr(?,4,3) "+
		"                          END ORDER BY execgroup, execorder ASC"; 
    
    
    
    public List listReportModulesOAM(DataSource dataSource, Schema schema) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( REPORT_QRY_BY_SCHEMA_OAM);
            ps.setString(1, schema.getSchemaName());
            ps.setString(2, schema.getSchemaName());
            ps.setString(3, schema.getSchemaName());
            rs = ps.executeQuery();
           
            while(rs.next()) {           
            	 Report r = (new Report()).setReportId(rs.getInt(1)).setReportName( rs.getString(2)).setExecOrder(rs.getInt(3)).setExecGroup(rs.getInt(4)).setReportnGrpCount(rs.getInt(5));         	 
            	 ls.add( r);       
            }
            
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    private static final String REPORT_QRY_FOR_OTHERS=    	
    	" SELECT distinct(reportid), reportname from reportsbyclient a " +
    	"        where not exists ( "+
        "              select * from reportsbyclient b where a.reportid = b.reportid and "+        
        " 					      clientid = CASE "+
		"                            WHEN Substr(?,1,2) = 'S0' THEN Substr(?,3,3) "+
		"                            ELSE Substr(?,4,3) "+
		"                          END )ORDER BY 2";
    
    public List listOtherReportModulesOAM(DataSource dataSource, Schema schema) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( REPORT_QRY_FOR_OTHERS);
            ps.setString(1, schema.getSchemaName());
            ps.setString(2, schema.getSchemaName());
            ps.setString(3, schema.getSchemaName());
            rs = ps.executeQuery();
            
            while(rs.next()) {           
            	 Report r = (new Report()).setReportId(rs.getInt(1)).setReportName( rs.getString(2));         	 
            	 ls.add( r);                
            }
            
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    private static final String REPORT_QRY_OAM=
        " SELECT   distinct(a.reportid), a.reportname, b.reportdesc, b.sourceDir "+
		" FROM     reportsbyclient a "+
		"		   left join   "+Constants.REPORT_CONFIG_TBL+"   b on a.reportid=b.reportid ORDER BY 2";	
    	
    public List listReportModulesOAM(DataSource dataSource) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {     
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement( REPORT_QRY_OAM);            
            rs = ps.executeQuery();
            
            while(rs.next()) {           
	           	 Report r = (new Report()).setReportId(rs.getInt(1)).setReportName( rs.getString(2))
	           	 						  .setReportDesc( rs.getString(3)).setSourceDir( rs.getString(4));         	 
	           	 ls.add( r);                
            }
            
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    public void syncReportsByOAM(DataSource dataSource) throws Exception{
    	Connection cnn = null;
    	CallableStatement cs = null;   
    	
        try {
        	cnn = dataSource.getConnection();
        	cs = cnn.prepareCall("{CALL SP_SYNCREPORTSWITHOAM()}");
        	cs.execute();
        }catch(Exception ex){
            logger.error("Call SP_SYNCREPORTSWITHOAM FAILURE : " + ex);
        } finally {
            DBUtil.release(cnn, cs, null);
        }
    	
    }

    public void syncEngVersionWithOAM(DataSource dataSource) throws Exception {
        Connection cnn = null;
    	CallableStatement cs = null;

        try {
        	cnn = dataSource.getConnection();
        	cs = cnn.prepareCall("{CALL SP_SYNCVERSIONWITHOAM()}");
        	cs.execute();
        }catch(Exception ex){
            logger.error("Call SP_SYNCVERSIONWITHOAM FAILURE : " + ex);
        } finally {
            DBUtil.release(cnn, cs, null);
        }
    }
    
    public List getDxCGHostList(DataSource dataSource) throws Exception {
    	Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
    	List ls = new LinkedList();

        try {
        	cnn = dataSource.getConnection();
            ps = cnn.prepareStatement("SELECT HOSTNAME, URL FROM EDB_DXCGHOST");            
            rs = ps.executeQuery();    
            
            while(rs.next()){
            	ls.add(new KeyValue().setKey(rs.getString(1)).setValue(rs.getString(2)));            	
            }
            
        }catch(Exception ex){
            logger.error("getDxCGHostList() : " + ex);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        
        return ls;
    }
    
    public List<String> callDxCGReport(Schema schema){
    	String targetURL =	"";
    	String jobId =	"";
    	List<String> list = new ArrayList<String>();
    	String sql = "";
    	sql +=  "	SELECT jobId, serviceURL	" +
    			"	FROM	" +
    			"	dx_ArmsjobId";
    	
    	Connection cnn = null;
    	PreparedStatement ps = null;
    	ResultSet rs = null;
    	try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(sql);
    		rs = ps.executeQuery();
    		
    		while(rs.next()){
				targetURL = rs.getString("serviceURL");
				jobId = rs.getString("jobId");
				list.add(targetURL);
				list.add(jobId);
			}
    		/*list.add("http://192.168.72.174:8888/dxcg/rest/processdxcg");
    		list.add("207793");*/
    	} catch(Exception ex) {
        	logger.error("No table or no jobid exists at this moment ...");
        }finally {
    		DBUtil.release(cnn, ps, rs);
    	}
    	return list;
    }
    
    
    /**
     * @Description : Gets dxcg status for Mini Engine Execution
     * @param schema
     * @return
     */
    public List<String> callDxCGReportForMiniEngine(Schema schema){
    	String targetURL =	"";
    	String jobId =	"";
    	List<String> list = new ArrayList<String>();
    	String sql = "";
    	sql +=  "	SELECT jobId, serviceURL	" +
    			"	FROM	" +
    			"	vh_dx_ArmsjobId";
    	Connection cnn = null;
    	PreparedStatement ps = null;
    	ResultSet rs = null;
    	try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(sql);
    		rs = ps.executeQuery();
    		
    		while(rs.next()){
				targetURL = rs.getString("serviceURL");
				jobId = rs.getString("jobId");
				list.add(targetURL);
				list.add(jobId);
			}
    		/*list.add("http://192.168.72.174:8888/dxcg/rest/processdxcg");
    		list.add("207793");*/
    	} catch(Exception ex) {
        	logger.error("No table or no jobid exists at this moment ...");
        }finally {
    		DBUtil.release(cnn, ps, rs);
    	}
    	return list;
    }
    
    private static final String GET_CHART_DATA = ""
    		+ "SELECT * FROM "
    		+ "(SELECT extract(YEAR FROM starttime),eventname "
    		+ " FROM processing.processeventlog,dual WHERE endtime IS NOT NULL "
    		+ "AND extract(YEAR FROM starttime)>extract(YEAR FROM SYSDATE)-3) "
    		+ " pivot "
    		+ "( "
    		+ "  Count(eventname) "
    		+ "  FOR eventname IN ('Execute Engine','Execute Mini Engine') "
    		+ ")"; 
    
    public List<Chart> getChartData(DataSource ds){
    	Connection cnn = null;
    	Statement s = null;
    	ResultSet rs = null;
    	List<Chart> lsChart = new ArrayList<>();
    	try{
    		cnn = ds.getConnection();
    		s = cnn.createStatement();
    		rs = s.executeQuery(GET_CHART_DATA);
    		while(rs.next()){
    			Chart chart = new Chart();
    			chart.setYear(rs.getString(1));
    			chart.setExecuteEngineCount(rs.getString(2));
    			chart.setExecuteMiniEngineCount(rs.getString(3));
    			lsChart.add(chart);
    		}
    	}catch(SQLException e){
    		logger.error("Could not get chart data",e);
    	}finally{
    		DBUtil.release(cnn, s, rs);
    	}
    	return lsChart;
    }
    
    public static void main11(String[] args) {
		String schemaname = "11";
		/*if(schemaname.startsWith("VC")){
			System.out.println("hahahah");
		};*/
		//System.out.println(schemaname.length());
		if(schemaname.length()>=2){
			String schemaPrefix = schemaname.substring(0, 2);
			System.out.println(schemaPrefix);
		}
		
	}
}