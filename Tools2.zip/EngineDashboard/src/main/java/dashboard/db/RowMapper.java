package dashboard.db;

import java.sql.ResultSet;

public interface RowMapper {
    Object mapRow(ResultSet rs) throws Exception ;        
}
