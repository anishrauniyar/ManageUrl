package dashboard.db.scrubbing;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.Schema;
import dashboard.db.DBUtil;
import dashboard.web.util.CustomException;

public class ScrubbingDB {

	private static final Log logger = LogFactory.getLog(ScrubbingDB.class);

	private static final String GET_CLIENT_SPECIFIC_SCRIPTS = "SELECT SP_NAME||'.SQL' SQL_FILE FROM HR_GLOBAL_CLIENT_LAYOUT@HAWKEYERULES WHERE CLIENTID IN (?,'999')";

	/**
	 * @PreRequisite: DBlink HAWKEYERULES
	 * @Description: Returns list of SQL files according to clientid [999 is
	 *               being global for any client]
	 * @param schema
	 * @return
	 * @throws SQLException
	 * @throws CustomException
	 */
	public Map<String, Boolean> getClientSpecificSQLScripts(Schema schema,
			DataSource ds) throws SQLException, CustomException {
		Map<String, Boolean> sqlFileMap = new TreeMap<String, Boolean>();
		String clientId = schema.getSchemaName().substring(3, 6);
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(GET_CLIENT_SPECIFIC_SCRIPTS);
			ps.setString(1, clientId);
			rs = ps.executeQuery();
			while (rs.next()) {
				sqlFileMap.put(rs.getString("SQL_FILE"), Boolean.FALSE);
			}
			CustomException.assertEmptyMap(sqlFileMap,
					"No Client Specific SQL files were found for clientid "
							+ clientId);
		} catch (SQLException e) {
			logger.error("ScrubbingDB->getClientSpecificSQLFiles(schema) "
					+ schema, e);
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return sqlFileMap;
	}

	private static final String GET_DASHBOARD_PARAMS = "SELECT ParameterValue FROM  ZEDB_PARAMS where upper(ParameterName)=upper(?)";

	/**
	 * @Description: Returns CDF Object Script for HP Scrubbing
	 * @param schema
	 * @param CDF_OBJ_SCRIPTS_FOR_HP
	 * @return
	 * @throws Exception
	 */
	public Map<String, Boolean> getCDFObjScriptsForHP(String CDF_OBJ_SCRIPTS_FOR_HP, DataSource ds) throws Exception {
		Map<String, Boolean> sqlFileMap = new TreeMap<String, Boolean>();
		String CDFObjScriptsForHP = "";
		String objScriptsArray[] = null;
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(GET_DASHBOARD_PARAMS);
			ps.setString(1, CDF_OBJ_SCRIPTS_FOR_HP);
			rs = ps.executeQuery();
			while (rs.next()) {
				CDFObjScriptsForHP = rs.getString(1);
			}
			if (CDFObjScriptsForHP != null && CDFObjScriptsForHP != "") {
				objScriptsArray = CDFObjScriptsForHP.split(",");
				for (String scriptName : objScriptsArray) {
					sqlFileMap.put(scriptName, false);
				}
			}
			CustomException.assertEmptyMap(sqlFileMap,
					"No CDF Object Scripts found for Compiling HP!!! Please insert CDF Object Script in DataBase" );
		} catch (Exception e) {
			logger.error("ScrubbingDB->getCDFObjScriptsForHP()", e);
			throw e;
		} finally{
			DBUtil.release(cnn, ps, rs);
		}
		return sqlFileMap;
	}
}
