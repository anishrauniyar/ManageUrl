package dashboard.db;

import java.sql.DriverManager;
import java.sql.Connection;
import java.util.Properties;

import dashboard.data.Schema;

/**
 * Connects to the oracle database.
 */
public class OracleDBConnector {
    /**
     * @param s Schema info with credential info.
     * @return Connection to the specified schema
     * @throws Exception on failure to connect.
     */
    public Connection getConnectionForSchema(Schema s) throws Exception {
        Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
        Properties prop = new Properties();
        prop.put("user", s.getSchemaName());
        prop.put("password", s.getSchemaPwd());

        if ("sys".equalsIgnoreCase( s.getSchemaName())) {
            prop.put("internal_logon", "sysdba");
        }
        return DriverManager.getConnection( getUrl(s), prop);
    }
    
    private static String getUrl(Schema s) {
        String url;
        if (s.isSid()) {
            url="jdbc:oracle:thin:@" +
                s.getServerName() + ":" + s.getPort() +  ":" +  s.getService(); 
        } else {
            url="jdbc:oracle:thin:@//" +
                s.getServerName() + ":" + s.getPort() + "/" +  s.getService();
        }        
        return url;
    }
    
    
    public static String getTnsStyleUrl(Schema s) {
        String url = null;
       // if (s.isSid()) {
            url = " "+
                s.getSchemaName()
                + "/"
                + s.getSchemaPwd() + "@"
                + "(DESCRIPTION="
                +  "(ADDRESS=(PROTOCOL=TCP)"
                +   "(HOST=" + s.getServerName() + ")"
                +   "(PORT=" + s.getPort() +  ")"
                +  ")"
                + "(CONNECT_DATA="
                +  "(SERVER=DEDICATED)"
                +  "(SERVICE_NAME=" + s.getService() +  ")"
                //+  "(SID=" + s.getService() +  ")"
                +  ")"
                + ") "
                + ( "sys".equalsIgnoreCase(s.getSchemaName())? " as sysdba " : " " )
                + " ";
       /* } else {
            url = s.getSchemaName() + "/" + s.getSchemaPwd()
                + "@//"+s.getServerName() + ":" +s.getPort()+"/" + s.getService()
                + ( "sys".equalsIgnoreCase(s.getSchemaName())? " as sysdba " : " " );
        }*/

        return url;
    }
    
    public static void main(String args[])
    {
    	Schema s = new Schema();
    	s.setSchemaName("a");
    	s.setSchemaPwd("2");
    	s.setServerName("b");
    	s.setPort("1521");
    	
    	System.out.println(getTnsStyleUrl(s));
    }

}