package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.LDAP;

public class LDAPDB {

	protected Log logger = LogFactory.getLog(getClass());
	
    /*----------------------------------------------------------------------*/
    /* GET  LADP */
    /*----------------------------------------------------------------------*/

    private static final String GET_LDAP_QRY= "SELECT ldap_name, "
									    		+ "       ldap_url, "
									    		+ "       authentication_type, "
									    		+ "       principal, "
									    		+ "       ldap_detail, "
									    		+ "       ldap_location "
									    		+ " FROM   edb_ldap_configuration ";

    public List getLDAP(DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_LDAP_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                LDAP ldap=new LDAP();
                ldap.setLdap_name(rs.getString(1));
                ldap.setLdap_url(rs.getString(2));
                ldap.setAuthentication_type(rs.getString(3));
                ldap.setPrincipal(rs.getString(4));
                ldap.setLdap_detail(rs.getString(5));
                ldap.setLdap_location(rs.getString(6));
                ls.add( ldap);
            }
        } catch(Exception ex) {
            logger.info("Error.. getLDAP LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
}
