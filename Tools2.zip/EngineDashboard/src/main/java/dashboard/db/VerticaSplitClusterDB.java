package dashboard.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.engine.vertica.VerticaManager;
import dashboard.web.util.CustomException;
import dashboard.web.util.VerticaException;

public class VerticaSplitClusterDB {

    protected Log logger = LogFactory.getLog(getClass());

    private static final String LIST_PROD_VERTICA_CLUSTER = "SELECT CLUSTERGROUPID,GROUPNAME,CATEGORY FROM CLUSTERGROUP WHERE UPPER(CATEGORY) LIKE 'PROD_VERTICA_CLUSTER'";
    private static final String LIST_DR_VERTICA_CLUSTER = "SELECT CLUSTERGROUPID,GROUPNAME,CATEGORY FROM CLUSTERGROUP WHERE UPPER(CATEGORY) LIKE 'DR_VERTICA_CLUSTER'";

    /**
     * @Description : List all the cluster groups
     * @param ds
     * @param category
     * @return
     * @throws Exception
     */
    public List<ClusterGroup> listVerticaClusterGrp(DataSource ds, String category) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<ClusterGroup> clusterGrps = new ArrayList<ClusterGroup>();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(LIST_PROD_VERTICA_CLUSTER);
            if (category.equalsIgnoreCase("DR")) {
                ps = cnn.prepareStatement(LIST_DR_VERTICA_CLUSTER);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                ClusterGroup clusterGrp = new ClusterGroup().setClusterGroupId(rs.getString("CLUSTERGROUPID"))
                        .setGroupName(rs.getString("GROUPNAME")).setCategory(rs.getString("CATEGORY"));
                clusterGrps.add(clusterGrp);
            }
        } catch (Exception e) {
            logger.error("Error on SplitCluster(1)->listVerticaClusterGrp(category) " + category, e);
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return clusterGrps;

    }

    private static final String GET_CLUSTER_GRP_DETAILS_FOR_SCHEMA = "SELECT D.clustergroupid, "
            + "       D.groupname, "
            + "       D.category "
            + "FROM   platform_schema_info A "
            + "       join servers B "
            + "         ON A.databaseid = B.databaseid "
            + "       join clustergrp_servergrp_map C "
            + "         ON C.server_grpid = B.servergroupid "
            + "       join clustergroup D "
            + "         ON D.clustergroupid = c.cluster_grpid "
            + "       join platform_database_info E "
            + "         ON E.dbid = B.databaseid "
            + "WHERE "
            + "       D.category = (SELECT category FROM clustergroup WHERE clustergroupid = ?) "
            + "       AND Upper(A.dbuserid) = ? " + "       AND vipflag <> 'Y' "
            + "       AND A.isdeleted = 'N' " + "       AND ROWNUM = 1";

    /**
     * @Description: Gets the cluster group details for the given schema
     * @param schema
     * @return
     * @throws Exception
     */
    public ClusterGroup getClusterGrpDetailsForSchema(DataSource ds, String clusterGrpId, String schemaName) throws Exception {
        CustomException.assertEmptyString(clusterGrpId, " cluster group id while getting cluster group details for schema");
        CustomException.assertEmptyString(schemaName, " schema name while getting cluster group details for schema");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ClusterGroup clusterGrp = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_CLUSTER_GRP_DETAILS_FOR_SCHEMA, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, clusterGrpId);
            ps.setString(2, schemaName);
            rs = ps.executeQuery();
            rs.last();
            if (rs.getRow() > 0) {
                rs.beforeFirst();
                while (rs.next()) {
                    clusterGrp = new ClusterGroup().setClusterGroupId(rs.getString("clustergroupid")).setGroupName(rs.getString("groupname"))
                            .setCategory(rs.getString("category"));
                }
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return clusterGrp;
    }

    private static final String CHECK_SCHEMA_EXISTS_IN_CLUSTER_GRP = "SELECT C.server_grpid, " + "       A.databaseid, " + "       B.host, "
            + "       B.port, " + "       B.DATABASE "
            + "FROM   platform_schema_info A " + "       join servers B "
            + "         ON A.databaseid = B.databaseid "
            + "       join clustergrp_servergrp_map C "
            + "         ON C.server_grpid = B.servergroupid "
            + "       join platform_database_info D "
            + "         ON D.dbid = B.databaseid "
            + "WHERE  Upper(C.cluster_grpid) = ? "
            + "       AND Upper(A.dbuserid) = ? "
            + "       AND vipflag <> 'Y' AND A.isdeleted ='N' ";

    /**
     * @param ds
     * @param clusterGroup
     * @param destVtkaSchema
     * @return Object Array Case: 1. Returns Object Array with server details if
     * schemacount>0 , else 2. Returns Object Array with a message
     * @throws Exception
     */
    public Object[] checkSchemaInClusterGrp(DataSource ds, ClusterGroup clusterGroup, Schema destVtkaSchema, String event)
            throws VerticaException {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        Object[] obj = new Object[]{Boolean.FALSE, "Schema " + destVtkaSchema.getSchemaName() + " does not exists in " + clusterGroup.getGroupName()};

        try {
            CustomException.assertEmptyString(destVtkaSchema.getSchemaName(),
                    "Destination Vertica Schema while checking schema existence in cluster grp " + clusterGroup.getGroupName() + " !!!!!");
            CustomException.assertEmptyString(
                    clusterGroup.getClusterGroupId(),
                    "Cluster Grp Id while checking schema " + destVtkaSchema.getSchemaName() + " exists or not in cluster group "
                    + clusterGroup.getGroupName() + " !!!!");
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_SCHEMA_EXISTS_IN_CLUSTER_GRP, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            // ps = cnn.prepareStatement(CHECK_SCHEMA_EXISTS_IN_CLUSTER_GRP);
            ps.setString(1, clusterGroup.getClusterGroupId());
            ps.setString(2, destVtkaSchema.getSchemaName());
            rs = ps.executeQuery();
            rs.last();// moving result set to last row
            int total = rs.getRow();
            if (total > 0) {
                rs.beforeFirst();
                while (rs.next()) {
                    Server server = (new Server()).setServerGroupId(rs.getString("SERVER_GRPID")).setDatabaseId(rs.getString("DATABASEID"))
                            .setHost(rs.getString("HOST")).setPort(rs.getInt("PORT")).setDatabase(rs.getString("DATABASE"));
                    obj = new Object[]{Boolean.TRUE, server};
                    break;
                }
            }
        } catch (Exception e) {
            VerticaException.assertError(event, e.getMessage());

        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return obj;
    }

    /*
     * Lists all servergroups with server list along with vip nodes private
     * static final String GET_ALL_SERVER_DETAIL =
     * "SELECT C.GROUPNAME AS SERVERGROUPNAME,C.CATEGORY,A.SERVERGROUPID,A.DATABASEID,A.HOST,A.PORT,A.DATABASE "
     * + "  FROM   SERVERS A          JOIN CLUSTERGRP_SERVERGRP_MAP B " +
     * "   ON A.SERVERGROUPID = B.SERVER_GRPID          JOIN SERVERGROUP C " +
     * "   ON C.SERVERGROUPID = B.SERVER_GRPID          JOIN CLUSTERGROUP D " +
     * "   ON D.CLUSTERGROUPID = B.CLUSTER_GRPID " +
     * "       WHERE  UPPER(D.CLUSTERGROUPID) = ?   ORDER BY C.GROUPNAME";
     */
 /*
     * Lists all servergroups with server list excluding vip nodes private
     * static final String GET_ALL_SERVER_DETAIL =
     * "SELECT C.groupname AS SERVERGROUPNAME, " + "       C.category, " +
     * "       A.servergroupid, " + "       A.databaseid, " + "       A.host, "
     * + "       A.port, " + "       A.DATABASE " + "FROM   servers A " +
     * "       join clustergrp_servergrp_map B " +
     * "         ON A.servergroupid = B.server_grpid " +
     * "       join servergroup C " +
     * "         ON C.servergroupid = B.server_grpid " +
     * "       join clustergroup D " +
     * "         ON D.clustergroupid = B.cluster_grpid " +
     * "       left join platform_database_info E " +
     * "       ON e.dbid=a.databaseid " + "WHERE  Upper(D.clustergroupid) = ? "
     * + "AND e.isvip <> 'Y' " + "ORDER  BY C.groupname";
     */
 /*
     * List all server grps with server list along with vip flag
     */
    private static final String GET_ALL_SERVER_DETAIL = "" + "SELECT C.groupname AS SERVERGROUPNAME, " + "       C.category, "
            + "       A.servergroupid, " + "       A.databaseid, " + "       A.host, "
            + "       A.port, " + "       A.DATABASE, " + "       e.vipflag " + "FROM   servers A "
            + "       join clustergrp_servergrp_map B "
            + "         ON A.servergroupid = B.server_grpid " + "       join servergroup C "
            + "         ON C.servergroupid = B.server_grpid " + "       join clustergroup D "
            + "         ON D.clustergroupid = B.cluster_grpid "
            + "       join platform_database_info E " + "       ON e.dbid=a.databaseid "
            + "WHERE  Upper(D.clustergroupid) = ? " + "ORDER  BY C.groupname";

    /**
     * @param ds
     * @param clusterGroup
     * @return List of all servers with serverGroup as key [excluds VIP nodes]
     * @throws Exception
     */
    public List<Map<ServerGroup, List<Server>>> getAllServerGrpWithServers(DataSource ds, ClusterGroup clusterGroup, String event)
            throws VerticaException {
        List<Map<ServerGroup, List<Server>>> finalList = new ArrayList<Map<ServerGroup, List<Server>>>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_ALL_SERVER_DETAIL, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, clusterGroup.getClusterGroupId());
            rs = ps.executeQuery();
            rs.last();
            int count = rs.getRow();
            if (count == 0) {
                CustomException.assertEqualsZero(count, "No Server Groups found in Cluster Group " + clusterGroup.getGroupName());
            } else {
                rs.beforeFirst();
                while (rs.next()) {
                    ServerGroup serverGroup = new ServerGroup().setServerGroupId(rs.getString("servergroupid"))
                            .setGroupName(rs.getString("servergroupname")).setCategory(rs.getString("category"));
                    Server server = new Server().setDatabaseId(rs.getString("databaseid")).setHost(rs.getString("host")).setPort(rs.getInt("port"))
                            .setDatabase(rs.getString("database")).setIsVip(rs.getString("vipflag"));
                    finalList = add(serverGroup, server, finalList);
                }
            }
        } catch (Exception e) {
            VerticaException.assertError(event, e.getMessage());
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return finalList;
    }

    /**
     * @Description: Adding servers based on server group to finalList
     * @param serverGrp
     * @param s
     * @param finalList
     * @return
     */
    public List<Map<ServerGroup, List<Server>>> add(ServerGroup serverGrp, Server s, List<Map<ServerGroup, List<Server>>> finalList) {
        System.out.println("Inside add.....");
        if (finalList.isEmpty()) {
            List<Server> serverList = new ArrayList<Server>();
            serverList.add(s);
            Map<ServerGroup, List<Server>> map = new HashMap<ServerGroup, List<Server>>();
            map.put(serverGrp, serverList);
            finalList.add(map);
        } else {
            boolean flag = false;
            for (int i = 0; i < finalList.size(); i++) {
                Map<ServerGroup, List<Server>> maps = finalList.get(i);
                for (ServerGroup sg : maps.keySet()) {
                    if (serverGrp.equals(sg)) {
                        flag = true;
                        List<Server> serverList = maps.get(sg);
                        serverList.add(s);
                        break;

                    }
                }
            }
            if (!flag) {
                Map<ServerGroup, List<Server>> map = new HashMap<ServerGroup, List<Server>>();
                List<Server> serverList = new ArrayList<Server>();
                serverList.add(s);
                map.put(serverGrp, serverList);
                finalList.add(map);
            }
        }

        return finalList;
    }

    private static final String GET_SERVER_FOR_SERVER_GRP = "SELECT a.servergroupid,a.databaseid,a.host,a.port,a.DATABASE,b.vipflag FROM servers a "
            + "join platform_database_info b " + "ON a.databaseid = b.dbid "
            + "WHERE a.servergroupid = ?";

    /**
     * @Description : Returns list of servers for a server group
     * @param serverGroup
     * @return List<Server>
     * @throws Exception
     */
    public List<Server> getServersForAServerGrp(DataSource ds, String serverGrpId) throws Exception {
        List<Server> serverList = new ArrayList<Server>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_SERVER_FOR_SERVER_GRP, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, serverGrpId);
            rs = ps.executeQuery();
            rs.last();
            int count = rs.getRow();
            if (count == 0) {
                CustomException.assertEqualsZero(count, "No servers in server group " + serverGrpId);
            } else {
                rs.beforeFirst();
                while (rs.next()) {
                    Server server = new Server().setServerGroupId(rs.getString("servergroupid")).setDatabaseId(rs.getString("databaseid"))
                            .setHost(rs.getString("host")).setPort(rs.getInt("port")).setDatabase(rs.getString("database"))
                            .setIsVip(rs.getString("vipflag"));
                    serverList.add(server);
                }
            }
        } catch (Exception e) {
            logger.error("Error on SplitClusterDB(4)->getServersForAServerGrp(serverGroup) " + serverGrpId, e);
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return serverList;
    }

    /**
     * @Descrition : To test if the vertica node is UP [Vertica check]
     * @param vtkaSchema
     * @return
     */
    public boolean isValidVerticaNode(Schema vtkaSchema) {
        Connection cnn = null;
        try {
            cnn = new VerticaDBConnector().getConnectionForSchema(vtkaSchema);
            return true;
        } catch (Exception e) {
            logger.error(
                    "Error on SplitClusterDB(5)->isValidVerticaNode(schema) "
                    + vtkaSchema, e);
            return false;
        } finally {
            DBUtil.release(cnn, null, null);
        }
    }

    private static final String GET_VIP_SERVER = "SELECT a.servergroupid, " + "       a.host, " + "       a.databaseid, " + "       a.port, "
            + "       a.DATABASE " + "FROM   servers a " + "       join platform_database_info b "
            + "         ON a.databaseid = b.dbid " + "       join servergroup c "
            + "         ON c.servergroupid = a.servergroupid " + "WHERE  a.servergroupid = ? "
            + "       AND b.isvip = 'Y'";

    /**
     * @Description: Method to get the vip node for a servergroup
     * @param ds
     * @param serverGrp
     * @return
     * @throws Exception
     */
    public Server getVIPServer(DataSource ds, ServerGroup serverGrp) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Server vipServer = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_VIP_SERVER, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, serverGrp.getServerGroupId());
            rs = ps.executeQuery();
            rs.last();
            int total = rs.getRow();
            CustomException.assertEqualsZero(total, "Could not get Vip nodes for server group " + serverGrp.getGroupName());
            rs.beforeFirst();
            while (rs.next()) {
                vipServer = new Server().setServerGroupId(rs.getString("servergroupid")).setHost(rs.getString("host")).setPort(rs.getInt("port"))
                        .setDatabaseId(rs.getString("databaseid")).setDatabase(rs.getString("database"));
            }

        } catch (Exception e) {
            logger.error("Error on SplitClusterDB(6)->getVIPServer(serverGroup) " + serverGrp, e);
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return vipServer;

    }

    private static final String GET_SERVERGRP_FREE_SPACE_PERCENTAGE_STRING = "SELECT (SUM(DISK_SPACE_FREE_MB))/(SUM(DISK_SPACE_FREE_MB + DISK_SPACE_USED_MB)) AS FREE_SPACE_PERCENT "
            + "FROM   V_MONITOR.DISK_STORAGE "
            + "WHERE  STORAGE_USAGE ILIKE 'DATA%'";
    private static final String GET_SERVERGRP_TOTAL_SPACE_MB = "SELECT SUM(DISK_SPACE_FREE_MB + DISK_SPACE_USED_MB) AS TOTAL_FREE_SPACE_MB "
            + "FROM   V_MONITOR.DISK_STORAGE "
            + "WHERE  STORAGE_USAGE ILIKE 'DATA%'";
    /*
     * private static final String GET_SERVERGRP_PROJECTION_COUNT =
     * "SELECT ( SEGMENTED_PROJECTIONS_COUNT " +
     * "         + UNSEGMENTED_PROJECTIONS_COUNT ) AS PROJECTIONS_COUNT " +
     * "FROM   DBMONITOR.DB_SUMMARY_BY_DAY " + "ORDER  BY START_TIMESTAMP";
     */
    // old query to get the projection count
    /*private static final String GET_SERVERGRP_PROJECTION_COUNT             = ""
                                                                                   + "SELECT ( segmented_projections_count "
                                                                                   + "         + unsegmented_projections_count ) AS projections_count "
                                                                                   + "FROM   dbmonitor.db_summary_by_day "
                                                                                   + "WHERE  start_timestamp = (SELECT Max(start_timestamp) "
                                                                                   + "                          FROM   dbmonitor.db_summary_by_day) "
                                                                                   + "ORDER  BY start_timestamp";*/
    private static final String GET_SERVERGRP_PROJECTION_COUNT = "SELECT projection_count as projections_count FROM dbmonitor.db_projection_summary ORDER BY sample_timestamp DESC LIMIT 1";

    /**
     * @Description : Returns Map containing serverGrp Parameters
     * @param vtkaSchema
     * @return
     * @throws Exception
     */
    public Map<String, Double> getServerGrpParams(Schema vtkaSchema, String event) throws VerticaException {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Map<String, Double> serverGrpParams = new HashMap<String, Double>();
        try {
            cnn = new VerticaDBConnector().getConnectionForSchema(vtkaSchema);
            ps = cnn.prepareStatement(GET_SERVERGRP_FREE_SPACE_PERCENTAGE_STRING);
            rs = ps.executeQuery();
            while (rs.next()) {
                serverGrpParams.put(VerticaManager.SERVERGRP_FREE_SPACE_PERCENT, rs.getDouble("FREE_SPACE_PERCENT"));
            }
            DBUtil.close(ps);
            DBUtil.close(rs);
            ps = cnn.prepareStatement(GET_SERVERGRP_TOTAL_SPACE_MB);
            rs = ps.executeQuery();
            while (rs.next()) {
                serverGrpParams.put(VerticaManager.SERVERGRP_TOTAL_SPACE_MB, rs.getDouble("TOTAL_FREE_SPACE_MB"));
            }
            ps = cnn.prepareStatement(GET_SERVERGRP_PROJECTION_COUNT);
            rs = ps.executeQuery();
            while (rs.next()) {
                serverGrpParams.put(VerticaManager.SERVERGRP_PROJECTION_COUNT, rs.getDouble("PROJECTIONS_COUNT"));
            }
        } catch (Exception e) {
            VerticaException.assertError(event, e.getMessage());
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return serverGrpParams;
    }

    private static final String GET_SCHEMA_SIZE = "SELECT (SUM(BYTES))/(1024*1024) AS SCHEMA_SIZE_MB " + "  FROM DBA_SEGMENTS " + " WHERE OWNER = ?";

    /**
     * @Description: Returns the size of schema
     * @param schema
     * @return
     * @throws Exception
     */
    public double getSchemaSize(Schema schema, String event) throws VerticaException {
        Connection cnn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        double schemaSize = 0;
        try {
            cnn = new OracleDBConnector().getConnectionForSchema(schema);
            stmt = cnn.prepareStatement(GET_SCHEMA_SIZE);
            stmt.setString(1, schema.getSchemaName());
            rs = stmt.executeQuery();
            while (rs.next()) {
                schemaSize = rs.getDouble("SCHEMA_SIZE_MB");
            }
        } catch (Exception e) {
            VerticaException.assertError(event, e.getMessage());
        } finally {
            DBUtil.release(cnn, stmt, rs);
        }
        return schemaSize;
    }

    private static final String CHECK_VIP = "SELECT Count(1) as count FROM servers a " + "join platform_database_info b "
            + "ON a.databaseid =b.DBID " + "WHERE Upper(a.host) = ? " + "AND B.VIPFLAG = 'Y'";

    /**
     * @Description: Checks if the given host is VIP or NOT
     * @param schema
     * @return
     * @throws Exception
     */
    public boolean checkVIP(DataSource ds, String host) throws Exception {
        CustomException.assertEmptyString(host, "Host while checking VIP or NOT for BA transfer");
        Connection cnn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean isVip = false;
        try {
            cnn = ds.getConnection();
            stmt = cnn.prepareStatement(CHECK_VIP);
            stmt.setString(1, host);
            rs = stmt.executeQuery();
            while (rs.next()) {
                if (rs.getInt("count") > 0) {
                    isVip = true;
                }
            }
        } catch (Exception e) {
            logger.error("Error on SplitClusterDB(9)->checkVIP(host) " + host, e);
            throw e;
        } finally {
            DBUtil.release(cnn, stmt, rs);
        }
        if (!isVip) {
            CustomException.assertFalse(isVip, "Host " + host + " is not VIP Server ");
        }
        return isVip;
    }

    /*
     * FOR AUTO DR TRANSFER
     */
    private static final String GET_MAPPED_CLUSTERGRP = "SELECT a.dr_cluster_grpid ,b.groupname FROM vtka_prod_dr_clustermap a "
            + "join clustergroup b " + "ON a.dr_cluster_grpid = b.clustergroupid "
            + "WHERE prod_cluster_grpid  = ?";

    /**
     * @Description : Returns the mapped Clustergroup from the given
     * clusterGroup
     * @param prodClusterGroup
     * @return
     * @throws Exception
     */
    public ClusterGroup getDRClusterGroup(DataSource ds, ClusterGroup prodClusterGroup) throws Exception {
        CustomException.assertEmptyString(prodClusterGroup.getClusterGroupId(), "Prod Cluster Group id will checking for mapping!!!!");

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ClusterGroup drClusterGroup = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_MAPPED_CLUSTERGRP, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, prodClusterGroup.getClusterGroupId());
            rs = ps.executeQuery();
            rs.last();
            int rowCount = rs.getRow();
            CustomException.assertEqualsZero(rowCount, "No Mapping found for production cluster group " + prodClusterGroup.getGroupName());
            rs.beforeFirst();
            while (rs.next()) {
                drClusterGroup = new ClusterGroup().setClusterGroupId(rs.getString("dr_cluster_grpid")).setGroupName(rs.getString("groupname"));
            }
        } catch (Exception e) {
            logger.error("Error on SplitClusterDB(10)->getDRClusterGroup(prodClusterGrp) " + prodClusterGroup, e);
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return drClusterGroup;
    }

    /**
     * @Description: To check is schema pwd is already inserted for the mapped
     * clusters [VITTOOLS-358]
     * @param ds
     * @param schema
     * @return
     * @throws SQLException
     */
    public String getSchemaPwdFromMappedClusters(DataSource ds, Schema schema) throws SQLException {
        Connection cnn = null;
        CallableStatement cs = null;
        String pwd = "";

        String sql = "{CALL getSchemaPwdFromMappedClusters(?,?,?)}";
        try {
            cnn = ds.getConnection();
            cs = cnn.prepareCall(sql);
            cs.setString(1, schema.getSchemaName());
            cs.setString(2, schema.getClusterGroupId());
            cs.registerOutParameter(3, java.sql.Types.VARCHAR);
            cs.executeUpdate();
            pwd = cs.getString(3);

        } catch (SQLException e) {
            logger.error("Error on VerticaSplitClusterDB(11)->getSchemaPwdFromMappedClusters() " + schema, e);
            throw e;
        } finally {
            DBUtil.release(cnn, cs, null);
        }
        return pwd;
    }
}
