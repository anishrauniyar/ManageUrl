package dashboard.db;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


import java.util.List;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLWarning;

import dashboard.engine.EngineUtil;
import dashboard.data.Schema;

public class ErrorDB {

    protected Log logger = LogFactory.getLog(getClass());

    private static final int MAX_LIST_SIZE = 3000;
    
    public Object [] getTableAsFieldNamesNRowList(Schema schema, String tableName) throws Exception {
        String table_sql = "select * from " + tableName;
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ResultSetMetaData rsMd = null;
        int colCount = -1;
        String [] fieldNames = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(table_sql);
            rs = ps.executeQuery();
            rsMd = rs.getMetaData();
            colCount = rsMd.getColumnCount();
            fieldNames = new String [colCount];
            for(int i=0; i<colCount; i++) {
                fieldNames[i] = rsMd.getColumnName(i+1);
            }

            int rowPos = 0;
            while(rs.next() && rowPos < MAX_LIST_SIZE) {
                rowPos++;
                String [] rows = new String[colCount];
                for(int i=0; i<colCount; i++) {
                    fieldNames[i] = rs.getString(i+1);
                    if ( rs.wasNull() ) {
                        fieldNames[i] = "";
                    }
                }
                ls.add(rows);
            }
            
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return new Object [] {fieldNames, ls};
    }

    private static final String INVALID_PROCS =
        "SELECT /*+ RULE */ OBJECT_NAME FROM user_objects " +
        " WHERE object_type IN ('PROCEDURE', 'PACKAGE', 'PACKAGE BODY') AND status = 'INVALID'";
    
    public List getInvalidProcList(Schema schema) throws Exception {
        List ls = new LinkedList();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(INVALID_PROCS);
            rs = ps.executeQuery();
            while(rs.next()) {
                ls.add(rs.getString(1));
            }            
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    public int getRowCountFromTable(Schema schema, String tableName) {
        int count = 0;
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            String countSQL = "select count(*) from " + tableName;
            //logger.info("Row count SQL: " + countSQL);
            ps = cnn.prepareStatement(countSQL);
            rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
                //logger.info("Count val: " + count);
            }
        } catch (Exception ex) {
            /////ignore
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }


    private static final String KILL_CALL = "{call D2ENGINE.sp_RemoveJobs(?)}";
    public void kill(Schema schema) throws Exception {
        Connection cnn = null;
        CallableStatement cs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            cs = cnn.prepareCall(KILL_CALL);
            cs.setString(1, schema.getSchemaName().toUpperCase());
            cs.execute();
            logger.info("Jobs Killed on : " + schema.toString());
        } catch(Exception ex) {
            logger.error("Call REMOVE JOB FAILURE for: " + schema.toString(), ex);
        } finally {
            DBUtil.release(cnn, cs, null);
        }
    }
}
