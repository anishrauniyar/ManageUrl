package dashboard.db;

import java.io.File;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Chart;
import dashboard.data.ClusterGroup;
import dashboard.data.DataFileDir;
import dashboard.data.MREPreCheck;
import dashboard.data.OracleSystemData;
import dashboard.data.Report;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.data.Status;
import dashboard.data.TempTablespace;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.db.scrubbing.ScrubbingDB;
import dashboard.engine.EngineConverter;
import dashboard.engine.oracle.NamingUtil;
import dashboard.security.RoleSet;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;
import dashboard.web.util.CustomException;
import dashboard.web.util.VerticaException;

public class EngineMonitorDB {

    protected DataSource dataSource;
    protected DataSource loginDataSource;

    protected Log logger = LogFactory.getLog(getClass());

    UserDB userDB;
    ServerDB serverDB;
    ErrorDB errorDB;
    OracleStatusDB oraStatusDB;
    ReportDB reportDB;
    SchemaInfoDB schemaInfoDB;
    DataAnalyticsDB dataAnalyticsDB;
    LDAPDB ldapDB;
    VerticaDB verticaDB;
    VerticaSplitClusterDB verticaSplitClusterDB;
    ScrubbingDB scrubbingDB;
    UserMgmtDB userMgmtDB;
    MiniEngineDB miniEngineDB;
    VerticaStaticMapDB verticaStaticMapDB;

    public EngineMonitorDB() {
        userDB = new UserDB();
        serverDB = new ServerDB();
        errorDB = new ErrorDB();
        oraStatusDB = new OracleStatusDB();
        reportDB = new ReportDB();
        schemaInfoDB = new SchemaInfoDB();
        dataAnalyticsDB = new DataAnalyticsDB();
        ldapDB = new LDAPDB();
        verticaDB = new VerticaDB();
        verticaSplitClusterDB = new VerticaSplitClusterDB();
        userMgmtDB = new UserMgmtDB();
        scrubbingDB = new ScrubbingDB();
        miniEngineDB = new MiniEngineDB();
        verticaStaticMapDB = new VerticaStaticMapDB();
    }

    public void setDataSource(DataSource ds) {
        dataSource = ds;
    }

    public void setLoginDataSource(DataSource ds) {
        loginDataSource = ds;
    }

    private static Object[] SCHEMA_OK = new Object[]{Boolean.TRUE,
        "Connection successful with the specified user."};

    public Object[] isValid(Schema schema) throws Exception {
        Connection cnn = null;
        Object[] retVal = SCHEMA_OK;
        String hostingServer = schema.getHostingServer();
        try {
            if (hostingServer == null || hostingServer == ""
                    || hostingServer.equalsIgnoreCase("ORACLE")
                    || hostingServer.equalsIgnoreCase("ORACLE_BA")
                    || hostingServer.equalsIgnoreCase("ORACLE_BA_CMA")) {
                cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            } else if (hostingServer.equalsIgnoreCase(Constants.VERTICA)) {
                cnn = (new VerticaDBConnector()).getConnectionForSchema(schema);
            }
            /*
			 * else if(hostingServer.equalsIgnoreCase("DMEXPRESS")) { cnn = (new
			 * OracleDBConnector()).getConnectionForSchema(schema); }
             */
        } catch (Exception ex) {
            retVal = new Object[]{Boolean.FALSE, ex.getMessage()};
        } finally {
            DBUtil.release(cnn, null, null);
        }
        return retVal;
    }

    public Object[] isHostReachable(String host) throws Exception {
        Object[] retVal;
        try {
            PingHost pingHost = new PingHost();
            retVal = pingHost.ping(host);
        } catch (Exception ex) {
            retVal = new Object[]{Boolean.FALSE, ex.getMessage()};
        }
        return retVal;
    }

    private static final String CHECK_STATUS_SQL = "  SELECT /*+RULE*/  a.job,  b.sid,  a.failures,  a.broken,  "
            + " regexp_substr(a.what,'([sS][pP]_[_[:alpha:][:digit:]]+)') What_Str ,"
            + " event,  p1text,  p1,  p2text,  p2,"
            + "        p3text,  p3,  wait_class,  wait_time,  seconds_in_wait,  state "
            + "  FROM  user_jobs a,  dba_jobs_running b,  v$session_wait c "
            + " WHERE  a.job=b.job AND  b.sid=c.sid ";

    public List getStatusList(Schema schema) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(CHECK_STATUS_SQL);
            rs = ps.executeQuery();
            while (rs.next()) {
                addToList(ls, rs, new RowMapper() {
                    public Object mapRow(ResultSet r) throws Exception {
                        Status status = new Status();
                        status.setJob(r.getString(1)).setSid(r.getString(2))
                                .setFailures(r.getString(3))
                                .setBroken(r.getString(4))
                                .setWhat(r.getString(5))
                                .setEvent(r.getString(6))
                                .setP1text(r.getString(7))
                                .setP1(r.getString(8))
                                .setP2text(r.getString(9))
                                .setP2(r.getString(10))
                                .setP3text(r.getString(11))
                                .setP3(r.getString(12))
                                .setWaitClass(r.getString(13))
                                .setWaitTime(r.getString(14))
                                .setSecondsInWait(r.getString(15))
                                .setState(r.getString(16));
                        return status;
                    }
                });
            }
        } catch (Exception ex) {
            System.out.println("Error..STATUS LIST: " + ex.getMessage() + " "
                    + schema);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    private static final String DATA_TRANSFER_STATUS = ""
            + "SELECT Decode(statusid, 0, 'Not Started', "
            + "                        1, 'In Progress', "
            + "                        2, 'Completed') Status, "
            + "       Count(1)                         No_count "
            + "FROM   processing.tbl_tts_transfer_status "
            + "WHERE  ttsjobid = ?"// '20130621171419' "
            + "GROUP  BY statusid ";

    public List getDataTransferStatusList(String uniqueJobId) throws Exception {
        // System.out.println("getDataTransferStatusList");
        RunningStatus runningStatus = new RunningStatus();
        List statusList = new LinkedList();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ResultSet modRs = null;
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(DATA_TRANSFER_STATUS);
            ps.setString(1, uniqueJobId);
            rs = ps.executeQuery();
            while (rs.next()) {
                addToList(statusList, rs, new RowMapper() {
                    public Object mapRow(ResultSet r) throws Exception {
                        Status status = new Status();
                        status.setDataTransferStatus(r.getString(1))
                                .setNoOfModules(r.getString(2));
                        // System.out.println("Status<><>?<"+status.getDataTransferStatus());
                        return status;
                    }
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return statusList;
    }

    private static final String DATA_TRANSFR_RUNNING_STATUS = " SELECT mod_count, "
            + "       mod_comp, "
            + "       mod_run "
            + "FROM   (SELECT Count(*) Mod_Count "
            + "        FROM   processing.tbl_tts_transfer_status "
            + "        WHERE  ttsjobid = ?) A "
            + "       left join (SELECT Count(*) Mod_Comp "
            + "                  FROM   processing.tbl_tts_transfer_status "
            + "                  WHERE  ttsjobid = ? "
            + "                         AND statusid = 2 "
            + "                         AND starttm IS NOT NULL "
            + "                         AND endtm IS NOT NULL) B "
            + "              ON 1 = 1 "
            + "       left join (SELECT Count(*) Mod_Run "
            + "                  FROM   processing.tbl_tts_transfer_status "
            + "                  WHERE  ttsjobid = ? "
            + "                         AND statusid = 1) C "
            + "              ON 1 = 1";
    private static final String DATA_TRANSFR_COMPLETED_MODULES = " SELECT filename "
            + " FROM   processing.tbl_tts_transfer_status "
            + " WHERE  ttsjobid = ? "
            + "       AND statusid = 2 "
            + "       AND starttm IS NOT NULL "
            + "       AND endtm IS NOT NULL ";

    public RunningStatus getRunningStatusDataTransfer(String uniqueJobId) {
        RunningStatus runningStatus = new RunningStatus();
        Connection cnn = null;
        PreparedStatement ps = null;
        PreparedStatement modPs = null;
        ResultSet rs = null;
        ResultSet modRs = null;
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(DATA_TRANSFR_RUNNING_STATUS);
            ps.setString(1, uniqueJobId);
            ps.setString(2, uniqueJobId);
            ps.setString(3, uniqueJobId);
            rs = ps.executeQuery();
            if (rs.next()) {
                runningStatus.setNoOfModules(rs.getInt(1))
                        .setCompletedModules(rs.getInt(2))
                        .setRunningModules(rs.getInt(3));
            }
            // System.out.println("RunningStatus<><>noModule:"+runningStatus.getNoOfModules());
            modPs = cnn.prepareStatement(DATA_TRANSFR_COMPLETED_MODULES);
            modPs.setString(1, uniqueJobId);
            modRs = modPs.executeQuery();
            List ls = new LinkedList();
            while (modRs.next()) {
                ls.add(modRs.getString(1));
            }
            runningStatus.setCompletedList(ls);
        } catch (Exception ex) {
            logger.error("Error in method getRunningStatusDataTransfer with execution number :" + uniqueJobId);
            ex.printStackTrace();
        } finally {
            DBUtil.release(null, modPs, modRs);
            DBUtil.release(cnn, ps, rs);
        }
        return runningStatus;
    }

    private static final String RUNNING_STATUS = " SELECT Mod_Count, Mod_Comp, Mod_Run "
            + "   FROM (SELECT Count(*) Mod_Count FROM d2_engine_main) A "
            + "   left join "
            + "        (SELECT Count(*) Mod_Comp FROM  d2_engine_status WHERE status_id=0) B  ON 1=1 "
            + "   left join (SELECT Count(*) Mod_Run FROM  d2_engine_status WHERE status_id=1) C    ON 1=1 ";
    private static final String COMPLETED_MODULES = " select MODULE_NAME from D2_ENGINE_MAIN a inner join D2_ENGINE_STATUS b "
            + " on a.MODULE_ID = b.MODULE_ID and b.ENDTM is not null "
            + " order by b.ENDTM desc ";

    public RunningStatus getRunningStatus(Schema schema) throws Exception {
        RunningStatus runningStatus = new RunningStatus();
        Connection cnn = null;
        PreparedStatement ps = null;
        PreparedStatement modPs = null;
        ResultSet rs = null;
        ResultSet modRs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(RUNNING_STATUS);
            rs = ps.executeQuery();
            if (rs.next()) {
                runningStatus.setNoOfModules(rs.getInt(1))
                        .setCompletedModules(rs.getInt(2))
                        .setRunningModules(rs.getInt(3));
            }
            modPs = cnn.prepareStatement(COMPLETED_MODULES);
            modRs = modPs.executeQuery();
            List ls = new LinkedList();
            while (modRs.next()) {
                ls.add(modRs.getString(1));
            }
            runningStatus.setCompletedList(ls);
        } catch (Exception ex) {
        } finally {
            DBUtil.release(null, modPs, modRs);
            DBUtil.release(cnn, ps, rs);
        }
        return runningStatus;
    }

    private static final String RUNNING_STATUS_MINI_ENGINE = " SELECT Mod_Count, Mod_Comp, Mod_Run "
            + "   FROM (SELECT Count(*) Mod_Count FROM vh_engine_main) A "
            + "   left join "
            + "        (SELECT Count(*) Mod_Comp FROM  vh_engine_status WHERE status_id=0) B  ON 1=1 "
            + "   left join (SELECT Count(*) Mod_Run FROM  vh_engine_status WHERE status_id=1) C    ON 1=1 ";
    private static final String COMPLETED_MODULES_MINI_ENGINE = " select MODULE_NAME from VH_ENGINE_MAIN a inner join VH_ENGINE_STATUS b "
            + " on a.MODULE_ID = b.MODULE_ID and b.ENDTM is not null "
            + " order by b.ENDTM desc ";

    /**
     * @Description: Returns Status for Mini Engine [vh_engine_main &
     * vh_engine_status]
     * @param VCSchema
     * @return RunningStatus
     * @throws Exception
     */
    public RunningStatus getRunningStatusMiniEngine(Schema VCSchema)
            throws Exception {
        RunningStatus runningStatus = new RunningStatus();
        Connection cnn = null;
        PreparedStatement ps = null;
        PreparedStatement modPs = null;
        ResultSet rs = null;
        ResultSet modRs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(VCSchema);
            ps = cnn.prepareStatement(RUNNING_STATUS_MINI_ENGINE);
            rs = ps.executeQuery();
            if (rs.next()) {
                runningStatus.setNoOfModules(rs.getInt(1))
                        .setCompletedModules(rs.getInt(2))
                        .setRunningModules(rs.getInt(3));
            }
            modPs = cnn.prepareStatement(COMPLETED_MODULES_MINI_ENGINE);
            modRs = modPs.executeQuery();
            List ls = new LinkedList();
            while (modRs.next()) {
                ls.add(modRs.getString(1));
            }
            runningStatus.setCompletedList(ls);
        } catch (Exception ex) {
        } finally {
            DBUtil.release(null, modPs, modRs);
            DBUtil.release(cnn, ps, rs);
        }
        return runningStatus;
    }

    private static final String VH_TRANSFER_LOG_QRY = ""
            + "SELECT SRC_SCHEMA_NAME,DEST_SCHEMA_NAME,SERVER,table_name,SOURCE_COUNT,DEST_COUNT,QUERY_STATUS,QUERY_TIME "
            + "FROM TBL_VH_TRASFER_LOG";

    /**
     * @Description : Returns Mini Engine Output transfer status
     * @param destSchema
     * @return VHTransferLog
     */
    public List<VHTransferLog> getMiniEngineOutputTransferLog(Schema destSchema) {
        List<VHTransferLog> transferLogList = new ArrayList<VHTransferLog>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(destSchema);
            ps = cnn.prepareStatement(VH_TRANSFER_LOG_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                VHTransferLog transferLog = new VHTransferLog();
                transferLog.setSrc_schema_name(rs.getString("SRC_SCHEMA_NAME"));
                transferLog.setDest_schema_name(rs.getString("DEST_SCHEMA_NAME"));
                transferLog.setServer(rs.getString("SERVER"));
                transferLog.setTable_name(rs.getString("table_name"));
                transferLog.setSource_count(rs.getString("SOURCE_COUNT"));
                transferLog.setDest_count(rs.getString("DEST_COUNT"));
                transferLog.setQuery_status(rs.getString("QUERY_STATUS"));
                transferLog.setQuery_time(rs.getString("QUERY_TIME"));
                transferLogList.add(transferLog);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return transferLogList;
    }

    public RunningStatus getAllObjectStatus(Schema schema) throws Exception {
        RunningStatus runningStatus = new RunningStatus();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int modCount = oraStatusDB.getAllObjectCount(schema);
        runningStatus.setNoOfModules(modCount);
        return runningStatus;
    }

    protected static void addToList(List ls, ResultSet rs, RowMapper mapper)
            throws Exception {
        ls.add(mapper.mapRow(rs));
    }

    public Object[] isValidLogin(String loginName, String pwd) throws Exception {
        Object[] isValidUser = new Object[]{Boolean.FALSE, Boolean.FALSE};
        isValidUser[0] = userDB.isValidLogin(loginDataSource, loginName, pwd);
        /*if (!Boolean.TRUE.equals(isValidUser[0])) {
         */
        /**
         * modified for login authentication through multiple LDAP
         *//*
			List ldapList = ldapDB.getLDAP(dataSource);
			isValidUser[1] = LDAPLogin
					.checkvalidlogin(ldapList, loginName, pwd);
		}*/
        return isValidUser;
    }

    public Object[] isValidSSOLogin(String loginName) throws SQLException {
        Object[] isValidUser = new Object[]{Boolean.FALSE, Boolean.FALSE};
        isValidUser[0] = userDB.isValidSSOLogin(loginDataSource, loginName);
        return isValidUser;
    }

    public RoleSet getUsersRoles(String userId) throws Exception {
        return userDB.getUsersRoles(loginDataSource, userId);
    }

    public User getUser(String loginName, String pwd) throws Exception {
        return userDB.getUser(loginDataSource, loginName, pwd);
    }

    public User getUserForLDAPUser(String actDirName) throws Exception {
        return userDB.getUserForLDAPUser(loginDataSource, actDirName);
    }

    public User getUserWithoutPwd(String loginName) throws SQLException {
        return userDB.getUserWithoutPwd(loginDataSource, loginName);
    }

    public List getServerGroupList() throws Exception {
        return serverDB.getServerGroupList(dataSource);
    }

    public List getServerGroupList(String hostingServer) throws Exception {
        return serverDB.getServerGroupList(dataSource, hostingServer);
    }

    public List getVerticaRACServerGroupList() throws Exception {
        return serverDB.getVerticaRACServerGroupList(dataSource);
    }

    public List getVerticaDRServerGroupList() throws Exception {
        return serverDB.getVerticaDRServerGroupList(dataSource);
    }

    public List getServerGroupListForProcessing() throws Exception {
        return serverDB.getServerGroupListForProcessing(dataSource);
    }

    public List getServerGroupListForOracleDR() throws Exception {
        return serverDB.getServerGroupListForOracleDR(dataSource);
    }

    public List getHistServerGroupListForProcessing() throws Exception {
        return serverDB.getHistServerGroupListForProcessing(dataSource);
    }

    public List<ServerGroup> getServerGrpsByCategory(List<String> categoryList) throws Exception {
        return serverDB.getServerGrpsByCategory(dataSource, categoryList);
    }

    public int addServerGroup(String serverGroup, String serverType,
            String hostingServer) throws Exception {
        return serverDB.addServerGroup(dataSource, serverGroup, serverType,
                hostingServer);
    }

    public int deleteServerGroup(String serverGroupId) throws Exception {
        return serverDB.deleteServerGroup(dataSource, serverGroupId);
    }

    public ServerGroup getServerGroup(String sa_serverGroupId) throws Exception {
        return serverDB.getServerGroup(dataSource, sa_serverGroupId);
    }

    public Server getServer(Schema schema) throws Exception {
        return serverDB.getServer(dataSource, schema);
    }

    public List getServersForServerGroup(String serverGroupId) throws Exception {
        return serverDB.getServersForServerGroup(dataSource, serverGroupId);
    }

    public List getVIPServersForServerGrp(String serverGrpId) throws Exception {
        return serverDB.getVIPServersForServerGrp(dataSource, serverGrpId);
    }

    public List getServersForHistServerGroup(String serverGroupId)
            throws Exception {
        return serverDB.getServersForHistServerGroup(dataSource, serverGroupId);
    }

    public int addServer(Server server) throws SQLException {
        return serverDB.addServer(dataSource, server);
    }

    public int editRemoteLinkofServer(Server server) throws Exception {
        return serverDB.editRemoteLinkofServer(dataSource, server);
    }

    public int deleteServer(Server server) throws Exception {
        return serverDB.deleteServer(dataSource, server);
    }

    public boolean hasValidServerGroup(Schema schema) throws Exception {
        return serverDB.hasValidServerGroup(dataSource, schema);
    }

    public boolean isProcessingOracleServer(String serverGroupId)
            throws Exception {
        return serverDB.isProcessingOracleServer(dataSource, serverGroupId);
    }

    public List getDataFileDirsForServerGroup(String serverGroupId)
            throws Exception {
        return serverDB
                .getDataFileDirsForServerGroup(dataSource, serverGroupId);
    }

    public int addDataFileDir(DataFileDir dataFileDir) throws Exception {
        return serverDB.addDataFileDir(dataSource, dataFileDir);
    }

    public int deleteDataFileDir(DataFileDir dataFileDir) throws Exception {
        return serverDB.deleteDataFileDir(dataSource, dataFileDir);
    }

    public List listAllGroupNServers(boolean showDmexpress) throws Exception {
        return serverDB.listAllGroupNServers(dataSource, showDmexpress);
    }

    public List getTempTablespacesForServerGroup(String serverGroupId)
            throws Exception {
        return serverDB.getTempTablespacesForServerGroup(dataSource,
                serverGroupId);
    }

    public int addTempTablespace(TempTablespace tempTablespace)
            throws Exception {
        return serverDB.addTempTablespace(dataSource, tempTablespace);
    }

    public int deleteTempTablespace(TempTablespace tempTablespace)
            throws Exception {
        return serverDB.deleteTempTablespace(dataSource, tempTablespace);
    }

    public Object[] getTableAsFieldNamesNRowList(Schema schema, String tableName)
            throws Exception {
        return errorDB.getTableAsFieldNamesNRowList(schema, tableName);
    }

    public int getRowCountFromTable(Schema schema, String tableName) {
        return errorDB.getRowCountFromTable(schema, tableName);
    }

    public List getInvalidProcList(Schema schema) throws Exception {
        return errorDB.getInvalidProcList(schema);
    }

    public void kill(Schema schema) throws Exception {
        errorDB.kill(schema);
    }

    public OracleSystemData getOracleSystemData(Schema schema) throws Exception {
        return oraStatusDB.getOracleSystemData(schema);
    }

    public List listReportModulesOAM(Schema schema) throws Exception {
        return reportDB.listReportModulesOAM(dataSource, schema);
    }

    public List listOtherReportModulesOAM(Schema schema) throws Exception {
        return reportDB.listOtherReportModulesOAM(dataSource, schema);
    }

    public List listReportModulesOAM() throws Exception {
        return reportDB.listReportModulesOAM(dataSource);
    }

    public void syncReportsByOAM() throws Exception {
        reportDB.syncReportsByOAM(dataSource);
    }

    public void syncEngVersionWithOAM() throws Exception {
        reportDB.syncEngVersionWithOAM(dataSource);
    }

    public List<String> callDxCGReport(Schema schema) {
        return reportDB.callDxCGReport(schema);
    }

    public List<String> callDxCGReportForMiniEngine(Schema schema) {
        return reportDB.callDxCGReportForMiniEngine(schema);
    }

    public List<Chart> getChartData() {
        return reportDB.getChartData(dataSource);
    }

    public List listReportModules() throws Exception {
        return reportDB.listReportModules(dataSource);
    }

    public List listReportModules(String reportType) throws Exception {
        return reportDB.listReportModules(dataSource, reportType);
    }

    public int addReport(Report report) throws Exception {
        return reportDB.addReport(dataSource, report);
    }

    public int deleteReport(Report report) throws Exception {
        return reportDB.deleteReport(dataSource, report);
    }

    public int updateReport(Report oldReport, Report newReport)
            throws Exception {
        return reportDB.updateReport(dataSource, oldReport, newReport);
    }

    public Report getReportByName(String name) throws Exception {
        return reportDB.getReportByName(dataSource, name);
    }

    public int getIndexCount(Schema s) throws Exception {
        return oraStatusDB.getIndexCount(s);
    }

    public int getProcNTableCount(Schema s) throws Exception {
        return oraStatusDB.getProcNTableCount(s);
    }

    public int getHRHPCount(Schema s) throws Exception {
        return oraStatusDB.getHRHPCount(s);
    }

    public String getClientID(Schema s) throws Exception {
        return schemaInfoDB.getClientID(s);
    }

    public boolean oracleSchemaExists(Schema schemaCreator, String schemaName) throws Exception {
        return schemaInfoDB.oracleSchemaExists(dataSource, schemaCreator, schemaName);
    }

    public Schema generateSchemaPassword(Schema schema) throws Exception {
        return schemaInfoDB.generateSchemaPassword(dataSource, schema);
    }

    public void insertSchemaInfo(Schema schema) throws Exception {
        schemaInfoDB.insertSchemaInfo(dataSource, schema);
    }
    
    public void insertNotInSchemaInfo(Schema schema) throws Exception {
        schemaInfoDB.insertNotInSchemaInfo(dataSource, schema);
    }

    public Schema setSchemaPassword(Schema schema) throws Exception {
        return schemaInfoDB.setSchemaPassword(dataSource, schema);
    }

    public Schema setSchemaCreatorUserNPwd(Schema schema) throws Exception {
        return schemaInfoDB.setSchemaCreatorUserNPwd(dataSource, schema);
    }

    public boolean isSchemaInfoAlreadyInserted(Schema schema) throws Exception {
        return schemaInfoDB.isSchemaInfoAlreadyInserted(dataSource, schema);
    }

    public void insertSchemaInfoForVertica(String serverGroupId, String schemaName, String schemaPwd) throws Exception {
        schemaInfoDB.insertSchemaInfoForVertica(dataSource, serverGroupId, schemaName, schemaPwd);
    }

    public boolean dbaObjExists(Schema schema, String objectName, String objectType) throws Exception {
        return schemaInfoDB.dbaObjExists(schema, objectName, objectType);
    }

    public String getEngineVersion(Schema s) throws Exception {
        return serverDB
                .getEngineVersionForSchema(dataSource, s.getSchemaName());
    }

    public List getEngineVersionList() throws Exception {
        return serverDB.getEngineVersionList(dataSource);
    }

    public String getEngineVersionForSchema(String schemaName) throws Exception {
        return serverDB.getEngineVersionForSchema(dataSource, schemaName);
    }

    public String getClientName(String clientid) throws Exception {
        return serverDB.getClientName(dataSource, clientid);
    }

    /**
     * Data Analytics Data Transfer/Import/Scrub
     */
    public List getDataClientList() throws Exception {
        return dataAnalyticsDB.getDataClientList(dataSource);
    }

    public List getDataTransferMonth(String clientId) throws Exception {
        return dataAnalyticsDB.getDataTransferMonth(dataSource, clientId);
    }

    public void logDataTransferClients(String destMachine, String basepath,
            String[] copyfiles, String selectedclient) throws Exception {
        dataAnalyticsDB.logDataTransferClients(dataSource, destMachine,
                basepath, copyfiles, selectedclient);
    }

    public void logDataTransferFolders(String destMachine,
            String scriptfilename, String selectedclient, String clientType)
            throws Exception {
        dataAnalyticsDB.logDataTransferFolders(dataSource, destMachine,
                scriptfilename, selectedclient, clientType);
    }

    public String getEdbParameters(String paramname) throws Exception {
        return serverDB.getEdbParameters(dataSource, paramname);
    }

    public List getScriptsWithDataLoc(String clientId, String payer,
            String dataMonth, String[] scriptsname, String prescrubServer,
            String dataFilePath) throws Exception {
        return dataAnalyticsDB.getScriptsWithDataLoc(dataSource, clientId,
                payer, dataMonth, scriptsname, prescrubServer, dataFilePath);
    }

    public boolean saveDefaultFolderbyScriptName(String clientId, String payer,
            String scriptname, String foldername, String datamonth,
            String importserver) throws Exception {
        return dataAnalyticsDB.saveDefaultFolderbyScriptName(dataSource,
                clientId, payer, scriptname, foldername, datamonth,
                importserver);
    }

    public List getDefaultScrubScripts(String exeGroup) throws Exception {
        return dataAnalyticsDB.getDefaultScrubScripts(dataSource, exeGroup);
    }

    public List getDxCGHostList() throws Exception {
        return reportDB.getDxCGHostList(dataSource);
    }

    /**
     * Vertica Transfer Details
     */
    // error details for dmexpress
    public List getErrorDetails(Schema schema, Long execNo) {
        return verticaDB.getErrorDetails(schema, execNo);
    }

    // error details for cma
    public List getErrorDetails_CMA(Schema schema, Long execNo) {
        return verticaDB.getErrorDetails_CMA(schema, execNo);
    }

    // event Details for cma/dmexpress
    public List getEventDetails(Schema schema, Long execNo) {
        return verticaDB.getEventDetails(schema, execNo);
    }

    // transfer summary for dmexpress
    public List getTransferSummary(Schema schema, Long execNo) {
        return verticaDB.getTransferSummary(schema, execNo);
    }

    // transfer summary for cma
    public List getTransferSummary_CMA(Schema schema, Long execNo) {
        return verticaDB.getTransferSummary_CMA(schema, execNo);
    }

    // transfer details for DMexpress
    public List getTransferDetails(Schema schema, Long execNo, String is_Transferred) {
        return verticaDB.getTransferDetails(schema, execNo, is_Transferred);
    }

    // transfer details for CMA
    public List getTransferDetails_CMA(Schema schema, Long execNo, String is_Transferred) {
        return verticaDB.getTransferDetails_CMA(schema, execNo, is_Transferred);
    }

    public List getVwTransferDetails_CMA(Schema schema, Long execNo, String is_Transferred) {
        return verticaDB.getVwTransferDetails_CMA(schema, execNo, is_Transferred);
    }

    // getting total table count from source server
    public int getTotalTableCountFromSource(Schema schema) {
        return verticaDB.getTotalTableCountFromSource(schema);
    }

    public int getTotalViewCountFromSource(Schema schema) {
        return verticaDB.getTotalViewCountFromSource(schema);
    }

    // checking if the event is "Execute DMX task" for oracl to vertica data transfer using DMXpresss
    public boolean isExecuteDMXTask(Schema schema, Long execNo) {
        return verticaDB.isExecuteDMXTask(schema, execNo);
    }

    // checking if the event is "Copy Data from oracle to vertica" for oracl to vertica data transfer using CMA
    public boolean isCopyDataFromO2V(Schema schema, Long execNo) {
        return verticaDB.isCopyDataFromO2V(schema, execNo);
    }

    // count the success and error table from central server for oracle to vertica data transfer using DMXpress
    public int getCount(Schema schema, Long execNo, String isTransfered) {
        return verticaDB.getCount(schema, execNo, isTransfered);
    }

    // count the success and error table from central server for oracle to vertica data transfer using CMA
    public int getCount_CMA(Schema schema, Long execNo, String isTransferred) {
        return verticaDB.getCount_CMA(schema, execNo, isTransferred);
    }

    public int getViewCount_CMA(Schema schema, Long execNo, String isTransferred) {
        return verticaDB.getViewCount_CMA(schema, execNo, isTransferred);
    }

    public long getExecutionNumber() throws Exception {
        return serverDB.getExecutionNumber(dataSource);
    }

    public String getDBLink(Schema schema) throws SQLException, CustomException {
        return serverDB.getDBLink(schema, dataSource);
    }

    public InputStream getLogFile(Long execNo, String hostingServer) throws Exception {
        return verticaDB.getLogFile(execNo, hostingServer, dataSource);
    }

    /**
     * @param execNo
     * @return shell script output from server of given execNo
     * @throws Exception
     */
    public String getShellScriptOutput(Long execNo, String hostingServer) throws Exception {
        return verticaDB.getShellScriptOutput(execNo, hostingServer, dataSource);
    }

    /**
     * @param schema
     * @return output(log) for oracle BA module transfer
     * @throws Exception
     */
    public InputStream getOracleBALogFile(Schema schema) throws Exception {
        return verticaDB.getOracleBALogFile(schema);
    }

    /**
     * @param execNo
     * @param process_Id
     * @param srcServer
     * @return boolean
     * @Description To kill the oracle to vertica data transfer process on the
     * processing server
     */
    public boolean killOracleToVerticaProcess(String execNo, String process_Id, String srcServer, String hostingServer) {
        return verticaDB.killOracleToVerticaProcess(execNo, process_Id, srcServer, hostingServer);
    }

    /**
     * @param input
     * @return Object[]
     * @Description Matches the dashboard.util.Constants.PROCESS_ID_PATTERN on
     * the given input
     */
    public Object[] getOracle2VerticaProcessId(String input) {
        return verticaDB.getOracle2VerticaProcessId(input);
    }

    /**
     * @param executionNo
     * @return hostname i.e server name
     * @Description Returns the hostname for the given execution ID
     */
    public String getHostName(Long executionNo) {
        return verticaDB.getHostName(executionNo, dataSource);
    }

    public String getO2VProcessId(String execNo, String srcServer, String hostingServer) throws Exception {
        return verticaDB.getO2VProcessId(execNo, srcServer, hostingServer);
    }

    public String getCMABatchID(String execNo, String srcServer, String hostingServer) throws Exception {
        return verticaDB.getCMABatchID(execNo, srcServer, hostingServer);
    }

    public String getCMABatchId(long execNo, Schema schema) {
        return verticaDB.getCMABatchId(execNo, schema);
    }

    /**
     * *******VERTICA DR COPY & AUTO DR**********
     */
    public boolean verticaSchemaExists(Schema schema, String newSchemaName) throws Exception {
        return verticaDB.verticaSchemaExists(schema, newSchemaName);
    }

    public Object[] getTableSpaceAndItsStatus(Schema srcSchema) throws Exception {
        return verticaDB.getTableSpaceAndItsStatus(srcSchema);
    }

    public boolean reTransferTableExists(Schema srcSchema, String reTransferTblName) throws Exception {
        return verticaDB.reTransferTableExists(srcSchema, reTransferTblName);
    }

    public boolean isReTransferTblEmpty(Schema srcSchema, String reTransferTblName) throws Exception {
        return verticaDB.isReTransferTblEmpty(srcSchema, reTransferTblName);
    }

    public int checkForReTransfer(Schema srcOrclSchema, Schema destVtkaSchema, Schema centralSchema) throws Exception {
        return verticaDB.checkForReTransfer(srcOrclSchema, destVtkaSchema, centralSchema);
    }

    public boolean mapOracleServerGroup(String oracleRACServerGroupId, String oracleDRServerGroupId) throws Exception {
        return verticaDB.mapOracleServerGroup(oracleRACServerGroupId, oracleDRServerGroupId, dataSource);
    }

    public boolean mapVerticaServerGroup(String verticaRACServerGroupId, String verticaDRServerGroupId) throws Exception {
        return verticaDB.mapVerticaServerGroup(verticaRACServerGroupId, verticaDRServerGroupId, dataSource);
    }

    public ServerGroup getOrclDRServerGroup(Schema orclSchema) throws Exception {
        return verticaDB.getOrclDRServerGroup(dataSource, orclSchema);
    }

    public List<Schema> getOracleDRSchemaList(Schema oracleRacSchema) throws CustomException, SQLException {
        return verticaDB.getOracleDRSchemaList(oracleRacSchema, dataSource);
    }

    /*public List<Schema> getVerticaDRSchemaList(Schema verticaRacSchema) throws Exception{
		return verticaDB.getVerticaDRSchemaList(verticaRacSchema, dataSource);
	}*/
    public List<Schema> getVerticaSchemaList(Schema vtkaSchema) throws Exception {
        return verticaDB.getVerticaSchemaList(vtkaSchema, dataSource);
    }

    public boolean checkTableCount(Schema srcOrclSchema, Schema centralSchema, Long execNo) throws Exception {
        return verticaDB.checkTableCount(srcOrclSchema, centralSchema, execNo);
    }

    public TreeMap<ServerGroup, ServerGroup> getOracleMappedServerGroupList() throws Exception {
        return verticaDB.getOracleMappedServerGroupList(dataSource);
    }

    public TreeMap<String, String> getVerticaMappedServerGroupList() throws Exception {
        return verticaDB.getVerticaMappedServerGroupList(dataSource);
    }

    public boolean isSchemaStaticallyMapped(Schema orclSchema, Schema vtkaSchema) {
        return verticaStaticMapDB.isSchemaStaticallyMapped(dataSource, orclSchema, vtkaSchema);
    }

    /**
     * *******CLUSTER GRP MGMT**********
     */
    public List getClusterGroupList() throws Exception {
        return serverDB.getClusterGroupList(dataSource);
    }

    public int addClusterGroup(String clusterGroup, String clusterType) throws Exception {
        return serverDB.addClusterGroup(dataSource, clusterGroup, clusterType);
    }

    public int deleteClusterGroup(String clusterGroupId) throws Exception {
        return serverDB.deleteClusterGroup(dataSource, clusterGroupId);
    }

    public List getServerGroupListByCluster(String clusterGrpId) throws Exception {
        return serverDB.getServerGroupListByCluster(dataSource, clusterGrpId);
    }

    public List getAvailableServerGps(String category) throws Exception {
        return serverDB.getAvailableServerGps(dataSource, category);
    }

    public int assignServerGrpToCluster(String clusterGrpId, String[] serverGrps) throws Exception {
        return serverDB.assignServerGrpToCluster(dataSource, clusterGrpId, serverGrps);
    }

    public int deleteServerGrpFromCluster(String clusterGrpId, String serverGrpId) throws Exception {
        return serverDB.deleteServerGrpFromCluster(dataSource, clusterGrpId, serverGrpId);
    }

    public boolean mapVerticaClusterGroup(String prodVerticaClusterGrpId, String drVerticaClusterGrpId) throws Exception {
        return verticaDB.mapVerticaClusterGroup(prodVerticaClusterGrpId, drVerticaClusterGrpId, dataSource);
    }

    public TreeMap<ClusterGroup, ClusterGroup> getVerticaMappedClusterGroupList() throws Exception {
        return verticaDB.getVerticaMappedClusterGroupList(dataSource);
    }

    public int deleteOrclServerGrpMapping(String orclRACServerGrpId, String orclDRServerGrpId) throws Exception {
        return verticaDB.deleteOrclServerGrpMapping(dataSource, orclRACServerGrpId, orclDRServerGrpId);
    }

    public int deleteVtkaClusterGrpMapping(String prodVtkaClusterGrpId, String drVtkaClusterGrpId) throws Exception {
        return verticaDB.deleteVtkaClusterGrpMapping(dataSource, prodVtkaClusterGrpId, drVtkaClusterGrpId);
    }

    public int updateIsDeletedFlag(Schema schema, String isDeleted) {
        return verticaDB.updateIsDeletedFlag(dataSource, schema, isDeleted);
    }

    public int deletePwdEntry(Schema schema) {
        return verticaDB.deletePwdEntry(dataSource, schema);
    }

    /**
     * *******SPLIT CLUSTER DESIGN**********
     */
    public ClusterGroup getClusterGrpDetailsForSchema(String clusterGrpId, String schemaName) throws Exception {
        return verticaSplitClusterDB.getClusterGrpDetailsForSchema(dataSource, clusterGrpId, schemaName);
    }

    public List<ClusterGroup> listVerticaClusterGrp(String category) throws Exception {
        return verticaSplitClusterDB.listVerticaClusterGrp(dataSource, category);
    }

    public Object[] checkSchemaInClusterGrp(ClusterGroup clusterGroup, Schema destVtkaSchema, String event) throws VerticaException {
        return verticaSplitClusterDB.checkSchemaInClusterGrp(dataSource, clusterGroup, destVtkaSchema, event);
    }

    public List<Map<ServerGroup, List<Server>>> getAllServerGrpWithServers(ClusterGroup clusterGroup, String event) throws VerticaException {
        return verticaSplitClusterDB.getAllServerGrpWithServers(dataSource, clusterGroup, event);
    }

    public List<Server> getServersForAServerGrp(String serverGrpId) throws Exception {
        return verticaSplitClusterDB.getServersForAServerGrp(dataSource, serverGrpId);
    }

    public boolean isValidVerticaNode(Schema vtkaSchema) {
        return verticaSplitClusterDB.isValidVerticaNode(vtkaSchema);
    }

    public Server getVIPServer(ServerGroup serverGrp) throws Exception {
        return verticaSplitClusterDB.getVIPServer(dataSource, serverGrp);
    }

    public Map<String, Double> getServerGrpParams(Schema vtkaSchema, String event) throws VerticaException {
        return verticaSplitClusterDB.getServerGrpParams(vtkaSchema, event);
    }

    public double getSchemaSize(Schema schema, String event) throws VerticaException {
        return verticaSplitClusterDB.getSchemaSize(schema, event);
    }

    public boolean checkVIP(String host) throws Exception {
        return verticaSplitClusterDB.checkVIP(dataSource, host);
    }

    public ClusterGroup getDRClusterGroup(ClusterGroup prodClusterGroup) throws Exception {
        return verticaSplitClusterDB.getDRClusterGroup(dataSource, prodClusterGroup);
    }

    public String getSchemaPwdFromMappedClusters(Schema schema) throws SQLException {
        return verticaSplitClusterDB.getSchemaPwdFromMappedClusters(dataSource, schema);
    }

    /**
     * USER MANAGEMENT
     */
    public List<User> getUserListByUserRole(String userRole, String flag) throws SQLException {
        return userMgmtDB.getUserListByUserRole(userRole, flag, loginDataSource);
    }

    public int changeUserRole(String userRole, String[] users) throws SQLException {
        return userMgmtDB.changeUserRole(userRole, users, loginDataSource);
    }

    public int deleteAllUsersForUserRole(String userRole) throws SQLException {
        return userMgmtDB.deleteAllUsersForUserRole(userRole, loginDataSource);
    }

    /**
     * SCRUBBING DB
     */
    public Map<String, Boolean> getClientSpecificSQLScripts(Schema schema) throws SQLException, CustomException {
        return scrubbingDB.getClientSpecificSQLScripts(schema, dataSource);
    }

    public Map<String, Boolean> getCDFObjScriptsForHP(String CDF_OBJ_SCRIPTS_FOR_HP) throws Exception {
        return scrubbingDB.getCDFObjScriptsForHP(CDF_OBJ_SCRIPTS_FOR_HP, dataSource);
    }

    /**
     * Mini Engine DB
     */
    public List<String> getInvalidMREPreChecks(Schema vcSchema) throws Exception {
        return miniEngineDB.getInvalidMREPreChecks(dataSource, vcSchema);
    }

    public List<MREPreCheck> getMrePreCheckForSchema(Schema vcSchema) throws Exception {
        return miniEngineDB.getMrePreCheckForSchema(vcSchema);
    }

    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(Schema orclSchema, Schema vtkaSchema, boolean isTransferToProd, String event) throws VerticaException {
        return verticaStaticMapDB.getServerGroupMapListBasedOnSchema(dataSource, orclSchema, vtkaSchema, isTransferToProd, event);
    }
    
    public Object[] isValidReportCount(Schema schema) throws Exception {
        Object[] retVal = SCHEMA_OK;
        
       /* if(!checkDXCGVerification()){
        	retVal = new Object[]{Boolean.FALSE, "Report Verification is currently disabled."};
        	return retVal;
        	
        }*/
        
        Map<String, String> stagingServer = getStagingServerDetails();
        
        Schema schemaStg = new Schema().setSchemaName(stagingServer.get("STAGING_SERVER_SCHEMA"))
		.setSchemaPwd(stagingServer.get("STAGING_SERVER_SCHEMA_PWD"))
		.setServerName(stagingServer.get("STAGING_SERVER_HOST")).setPort(stagingServer.get("STAGING_SERVER_PORT"))
		.setService(stagingServer.get("STAGING_SERVER_SERVICE")).setSidFlag("Y");

        ComponentFactory compFactory = null;
        compFactory = ComponentFactory.getInstance();
        EnvInfo env = compFactory.getEnvInfo();
        String SQL_PLUS = env.getSqlPlusPath();
        String sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(schemaStg);
        
        String dblink="";
        try{
             dblink = serverDB.getDBLink(schema,dataSource);
        }catch (Exception ex){
        	 dblink = schema.getServerName().replaceAll("(?i).D2hawkeye.net", "");
        }
        
        StringBuffer sber = EngineConverter.initStringBuffer();
		sber.append("---------Report Count Execution -----\n").append("BEGIN\n")
				.append(schemaStg.getSchemaName() + ".pkg_validation1.sp_execute(")
				.append("'" + schema.getSchemaName() + "'").append(",'" + dblink + "'")
				.append(");").append("\n").append("END;\n/\n");
		sber = EngineConverter.addExit(sber);
		
		File reportCount = (new NamingUtil()).getReportCheckFile(schema);
		FileUtil.writeToTextFile(sber.toString(), reportCount);
		
		
		 Runtime rt = null;
    	 InputStream is = null;
		 rt = Runtime.getRuntime();
        String execString = SQL_PLUS + " -L " + sqlPlusUrl + " @"
                +reportCount.getAbsolutePath() ;
        logger.info("exec String:"+execString);
        try {
            
        	Process ps = rt.exec(execString);
            is = ps.getInputStream();
            int c = 0;
            StringBuffer sb=new StringBuffer(5000);
            while ((c = is.read()) != -1) {
                 //System.out.print((char)c);
                sb.append((char) c);
            }

            is.close();
            is = null;
            
            int ret = ps.waitFor();
            
            retVal = new Object[]{Boolean.TRUE,
            		reportResult(schemaStg)};
           
               
          } catch (Exception ex) {
             ex.printStackTrace();
            retVal = new Object[]{Boolean.FALSE, ex.getMessage()};
        } finally {
        	System.out.println(" Inside Finally Block....");
        	logger.info("isValidReportCount:"+retVal[1]);
        	
        }
        
        return retVal;
    }
    
	public String reportResult(Schema s) {
		
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//int count = 0;
		//StringBuilder sb = new StringBuilder();
		String result="\nREPORT  VERIFICATION \n\n";
        boolean flag = false;
		try {
			cnn = (new OracleDBConnector()).getConnectionForSchema(s);
			ps = cnn.prepareStatement("SELECT APPID, SCHEMANAME,REPORTNAME,NVL(REPROCESS_COUNT,0) as REPROCESS_COUNT,PROCESSED_YN FROM REPORT_COMPARISION ORDER BY REPORTNAME ASC");
			rs = ps.executeQuery();
			while (rs.next()) {
				if(!flag){
					flag=true;
					result+="Appid: "+rs.getString("appid")+"\n";
					result+="Schema: "+rs.getString("SCHEMANAME")+"\n\n";
					//result+="------------------------------------------------------------\n";
					result+="REPROCESS_CNT          PROCESSED_YN            REPORT_NAME\n";
					//result+="<th><td>Report</td><td><reprocess_cnt</td></th>";
				}
				//result+=""+rs.getString("REPROCESS_COUNT")+"----------------------------"+rs.getString("PROCESSED_YN")+"------------------------"+rs.getString("REPORTNAME")+"\n";
				  result+=""+rs.getString("REPROCESS_COUNT")+"                                    "+rs.getString("PROCESSED_YN")+"                               "+rs.getString("REPORTNAME")+"\n";
				
				
			}
			if(flag)
				result+="";
			else
				result+=" No Data Found ";
				
		} catch (SQLException e) {
			logger.error("Error on reportResult", e);
			//throw e;
		} catch (Exception e) {
			logger.error("Error on reportResult", e);
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.release(cnn, ps, rs);
			//logger.info("reportResult:"+result);
			
		}
		
		return result;
	}

	public boolean checkDXCGVerification() {
		
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int count = 0;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement("SELECT COUNT(1) FROM ZEDB_PARAMS WHERE UPPER(PARAMETERNAME)='ENABLEDXCGVERIFICATION' AND UPPER(PARAMETERVALUE)='TRUE'");
			rs = ps.executeQuery();
			if(rs.next())
			{
				count=rs.getInt(1);
				
			}
				
		} catch (SQLException e) {
			logger.error("Error on checkDXCGVerification", e);
			//throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
			logger.info("DxcgVerification:"+count);
			if(count>0)
				return true;
		}
		
		return false;
	}
	
	private static final String GET_STAGING_SERVER = "SELECT parametername,parametervalue FROM zedb_params WHERE Upper(parametername) LIKE 'STAGING%'";
	public Map<String, String> getStagingServerDetails() throws SQLException{
		Map<String, String> stagingServer = new HashMap<String, String>();
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(GET_STAGING_SERVER);
			rs = ps.executeQuery();
			while (rs.next()) {
				stagingServer.put(rs.getString("parametername").toUpperCase(), rs.getString("parametervalue"));
			}
		} catch (SQLException ex) {
			logger.error("Error getting staging server details", ex);
			throw ex;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return stagingServer;
	}
  
}
