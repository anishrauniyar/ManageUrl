package dashboard.db;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLWarning;
import java.sql.SQLException;

import java.util.LinkedList;
import java.util.List;

public class OracleServerInfo{
	protected Log logger = LogFactory.getLog(getClass());
    private DataSource dataSource = null;
    private DataSource oamDataSource = null;

    public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public void setOamDataSource(DataSource oamDataSource) {
		this.oamDataSource = oamDataSource;
	}

	public String serverinfo(String schema)
    {
    	
         Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rset = null;
         
         String client_id = null;
         String servername = null;
         
         String initial = null;
         String temp = "null";
         String initial1 ="s"; 
       
         schema=schema.trim();
         schema=schema.toLowerCase();
         initial=schema.substring(0,1);
        
         if (initial.equalsIgnoreCase(initial1))
	         {
	        	 client_id=schema.substring(1,5);
	        	// System.out.println(client_id);
	         }
         else
	         {
	        	 client_id=schema.substring(2,6);
	        	// System.out.println(client_id);
	         }
         client_id=client_id.substring(1,4);
         //System.out.println("Client_id from function:"+client_id);
        
        String query1="select nvl(PROCESS_SERVER,'ORACLE1') ProcessingServer from hawkeyeoam.oam_clients where clientid='"+client_id+"'";
        //System.out.println(query1);
         try {
            
        	 cnn = oamDataSource.getConnection();
             ps = cnn.prepareStatement(query1, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             rset = ps.executeQuery();        	 
        	    
        	     while (rset.next ())
        	 	{ 		
        	   		temp=rset.getString(1);
        	   		servername=temp.trim();
        	          
        	   	}
         } 
         catch (SQLException ex)
         { 
        	 System.out.println(ex);
        	
         }
         
         finally {
             DBUtil.release(cnn, ps, rset);
         }
         return(servername);
        
    }
	
	public String serverGroupId(String servername)
    {
    	 
         Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rset = null;
         
         String serverGroup_id = null;
                 
         
         String query2 = "select SERVERGROUPID from processing.SERVERS a  where a.host='"+servername+"'";
         //String query2 = "select SERVERGROUPID from processing.SERVERGROUP a  where a.Groupname='"+servername+"'";
         
         try {
             cnn = dataSource.getConnection();
             ps = cnn.prepareStatement(query2, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             rset = ps.executeQuery();        	 
        	    
        	     while (rset.next ())
        	 	{ 		
        	   		String temp=rset.getString(1);
        	   		serverGroup_id=temp.trim();
        	   		//System.out.println("ServerGROUP FETCHED FROM DATABASE:"+serverGroup_id);  
        	   	}
         } 
         catch (SQLException ex)
         { 
        	 System.out.println(ex);
        	
         }
         
         finally {
             DBUtil.release(cnn, ps, rset);
         }
         return (serverGroup_id);
    }
}

