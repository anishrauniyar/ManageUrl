package dashboard.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.MREPreCheck;
import dashboard.data.Schema;

public class MiniEngineDB {
	protected Log logger = LogFactory.getLog(getClass());

	private static final String TABLE_PREFIX = "mre";
	private static final String MRE_PRE_CHECK_QRY = "SELECT field,requiredoutput FROM MRE_PRECHECK";

	public List<String> getInvalidMREPreChecks(DataSource dataSource, Schema vcSchema) throws Exception {
		Connection cnn = null;
		Statement s = null;
		ResultSet rs = null;
		List<MREPreCheck> mrePreCheckList = new ArrayList<>();
		List<MREPreCheck> mrePreCheckList_VC = new ArrayList<>();
		List<String> invalidFieldNames = new ArrayList<>();
		try {
			cnn = dataSource.getConnection();
			s = cnn.createStatement();
			rs = s.executeQuery(MRE_PRE_CHECK_QRY);
			while (rs.next()) {
				MREPreCheck mrePreCheck = new MREPreCheck();
				mrePreCheck.setFieldName(rs.getString("field"));
				mrePreCheck.setRequiredOutput(rs.getString("requiredOutput"));
				mrePreCheckList.add(mrePreCheck);
			}
			DBUtil.release(cnn, s, rs);

			cnn = (new OracleDBConnector()).getConnectionForSchema(vcSchema);
			s = cnn.createStatement();
			rs = s.executeQuery(
					"select field,requiredoutput,results from " + TABLE_PREFIX + "_" + vcSchema.getSchemaName());
			while (rs.next()) {
				MREPreCheck mrePreCheck_VC = new MREPreCheck();
				mrePreCheck_VC.setFieldName(rs.getString("field"));
				mrePreCheck_VC.setRequiredOutput(rs.getString("requiredOutput"));
				mrePreCheck_VC.setResult(rs.getString("results"));
				mrePreCheckList_VC.add(mrePreCheck_VC);
			}

			for (MREPreCheck m1 : mrePreCheckList) {
				for (MREPreCheck m2 : mrePreCheckList_VC) {
					if (m1.equals(m2)) {
						/*
						 * System.out.println("---------------");
						 * System.out.println("m1Fieldname:"+m1.getFieldName());
						 * System.out.println("m2Fieldname:"+m2.getFieldName());
						 */
						if (!m1.getRequiredOutput().equalsIgnoreCase(m2.getResult())) {
							invalidFieldNames.add(m1.getFieldName());
						}
						break;
					}

				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, s, rs);
		}
		return invalidFieldNames;
	}

	/**
	 * Querys MRE PRECHECK table for the given schema
	 * 
	 * @param vcSchema
	 * @return
	 * @throws Exception
	 */
	public List<MREPreCheck> getMrePreCheckForSchema(Schema vcSchema) throws Exception {
		List<MREPreCheck> mrePreCheckList = new ArrayList<>();
		Connection cnn = null;
		Statement s = null;
		ResultSet rs = null;
		try {
			cnn = (new OracleDBConnector()).getConnectionForSchema(vcSchema);
			s = cnn.createStatement();
			rs = s.executeQuery(
					"select field,requiredoutput,results from " + TABLE_PREFIX + "_" + vcSchema.getSchemaName());
			while (rs.next()) {
				MREPreCheck mrePreCheck = new MREPreCheck();
				mrePreCheck.setFieldName(rs.getString("field"));
				mrePreCheck.setRequiredOutput(rs.getString("requiredOutput"));
				mrePreCheck.setResult(rs.getString("results"));
				mrePreCheckList.add(mrePreCheck);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, s, rs);
		}
		return mrePreCheckList;
	}
}
