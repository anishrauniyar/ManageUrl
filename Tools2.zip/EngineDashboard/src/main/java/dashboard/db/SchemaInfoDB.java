package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.Schema;
import dashboard.util.Constants;
import dashboard.web.util.CustomException;

public class SchemaInfoDB {

    protected Log logger = LogFactory.getLog(getClass());

    private static final String CLIENTID_QRY =
        " select CLIENTID from CO_CLIENTS ";
    
    public String getClientID( Schema schema)
        throws Exception {
        String clientId = null;
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            logger.info("connected to .." + schema );
            ps = cnn.prepareStatement( CLIENTID_QRY);
            rs = ps.executeQuery();

            if(rs.next()) {
                clientId = rs.getString(1);
            } 
            if ( null == clientId || "".equals(clientId.trim()) || rs.wasNull()) {
                throw new IllegalStateException("Undefined clientid in the co_client for:" + schema);
            }
        } catch(Exception ex) {
            logger.info("error on getclientid:" + ex);
            throw ex;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return clientId.trim();
    }
    
    private static final String ENGINE_VERSION_QRY = 
    	" select 'V'||To_Number(SubStr(enginever, 1,2)) ENGINEVERSION from CO_CLIENTS ";
    public String getEngineVersion( Schema schema)
    throws Exception {
    String engineVersion = null;
    Connection cnn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    try {
        cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
        logger.info("connected to .." + schema );
        ps = cnn.prepareStatement( ENGINE_VERSION_QRY);
        rs = ps.executeQuery();

        if(rs.next()) {
            engineVersion = rs.getString(1);
        } 
        if ( null == engineVersion || "".equals(engineVersion.trim()) || rs.wasNull()) {
            throw new IllegalStateException("Undefined engineVersion in the co_client for:" + schema);
        }
    } catch(Exception ex) {
        logger.info("error on getEngineVersion:" + ex);
        throw ex;
    } finally {
        DBUtil.release(cnn, ps, rs);
    }
    return engineVersion.trim();
}
    
	private static final String CHECK_SCHEMA_EXISTS = "SELECT COUNT(1) FROM DBA_USERS WHERE UPPER(USERNAME) LIKE ?";

	/**
	 * @param ds -->DataSource
	 * @param schemaCreator --> Schema that is used to create other schemas
	 * @param schemaName--> New oracle schema name
	 * @return true if schema already exists, else false
	 * @throws Exception
	 */
	public boolean oracleSchemaExists(DataSource ds, Schema schemaCreator,
			String schemaName) throws Exception {

		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = new OracleDBConnector().getConnectionForSchema(schemaCreator);
			ps = cnn.prepareStatement(CHECK_SCHEMA_EXISTS);
			ps.setString(1, schemaName.toUpperCase());
			rs = ps.executeQuery();
			while (rs.next()) {
				if ((rs.getInt(1) > 0)) {
					return true;
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return false;
	}
    
	private static final String FN_GETPASSWORD = "SELECT FN_GETPASSWORD() AS PASSWORD FROM DUAL";

	/**
	 * @param ds
	 * @return schema with password 
	 * Description: calls a function FN_GETPASSWORD() to
	 *         generate password , before that it checks for database id of given host
	 * @throws Exception
	 */
	public Schema generateSchemaPassword(DataSource ds,Schema schema) throws Exception {
		
		CustomException.assertEmptyString(schema.getDatabaseId(),
				"Database Id for server " + schema.getServerName());
		
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String schemaPrefix = schema.getSchemaName().substring(0, 2);
		if(schemaPrefix.equalsIgnoreCase(Constants.HF) || schemaPrefix.equalsIgnoreCase(Constants.VC) || schemaPrefix.equalsIgnoreCase(Constants.HP)){
			logger.info("Schema prefix is "+schemaPrefix+" so pwd is "+Constants.DEFAULT_SCHEMA_PWD);
			schema.setSchemaPwd(Constants.DEFAULT_SCHEMA_PWD);
		}//note deafult pwd for HP is also oracle, but this is handled in script
		else{
			try {
				cnn = ds.getConnection();
				ps = cnn.prepareStatement(FN_GETPASSWORD);
				rs = ps.executeQuery();
				while (rs.next()) {
					schema.setSchemaPwd(rs.getString("password"));
				}
				//System.out.println("GENERATED PASSWORD>>>>>>>>>>"+schema.getSchemaPwd());
			} catch (Exception e) {
				throw e;
			} finally {
				DBUtil.release(cnn, ps, rs);
			}
			CustomException.assertEmptyString(schema.getSchemaPwd(), "schema password!!! Generating schema password failed!!!!!");
		}
		
		return schema;
	}

	private static final String GET_SCHEMA_TYPE = "SELECT SCHEMATYPE FROM PLATFORM_SCHEMA_TYPE WHERE SCHEMA_DESCRIPTION = ?";
	private static final String INSERT_SCHEMA_INFO = ""
			+ "INSERT INTO platform_schema_info " + "            (sn, "
			+ "             databaseid, " + "             dbuserid, "
			+ "             dbpwd, " + "             ts, "
			+ "             schematype, " + "             isdeleted) "
			+ "VALUES      ((SELECT Max(sn)+1 FROM platform_schema_info), "
			+ "             ?, " + "             ?, " + "             ?, "
			+ "             SYSDATE, " + "             ?, "
			+ "             'N') ";
	
	/**
	 * @param schema
	 * @param ds
	 *Description: Gets schema type from
	 *			  PLATFORM_SCHEMA_TYPE and inserts schema details in
	 *            platform_schema_info table of processing schema
	 * @return number of rows inserted
	 * @throws Exception
	 */
	
	
	public void insertNotInSchemaInfo(DataSource ds, Schema schema) throws Exception {

		CustomException.assertEmptyString(schema.getDatabaseId(),
				"Database Id for server " + schema.getServerName());
		CustomException.assertEmptyString(schema.getSchemaName(),
				"Schema Name");
		CustomException.assertEmptyString(schema.getSchemaPwd(),
				"Password for Schema " + schema.getSchemaPwd());

		Connection cnn = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		ResultSet rs = null;
		PreparedStatement ps2 = null;
		ResultSet rs2 = null;
		PreparedStatement ps3 = null;
		ResultSet rs3 = null;
		String schemaType = "";
		String schemaPrefix = "";
		try {
			cnn = ds.getConnection();
			schemaPrefix = schema.getSchemaName().substring(0,2);
			if(schemaPrefix.startsWith("S")){
				schemaType = "1";
			}
			else{
				//System.out.println("Getting schema type from db");
				ps = cnn.prepareStatement(GET_SCHEMA_TYPE);
				ps.setString(1, schemaPrefix);
				rs = ps.executeQuery();
				while (rs.next()) {
					schemaType = rs.getString("SCHEMATYPE") == null ? "" : rs
							.getString("SCHEMATYPE");
					//System.out.println("SchemaType>>>>>>>>>>>>>"+schemaType);
				}
			}
			
			CustomException.assertEmptyString(schemaType,
					"Schema Type for Schema " + schema.getSchemaName());
			
			if(schemaPrefix.equals(Constants.HF)){
			ps2 = cnn.prepareStatement("SELECT databaseid FROM servers WHERE SERVERGROUPID IN ( SELECT SERVERGROUPID FROM  servers WHERE databaseid=?)");
			ps2.setString(1, schema.getDatabaseId());
			rs2 = ps2.executeQuery();
			while (rs2.next()) {
		   
				ps3 = cnn.prepareStatement(SCHEMA_EXISTS);
				ps3.setString(1, rs2.getString("databaseid"));
				ps3.setString(2, schema.getSchemaName());
				rs3 = ps3.executeQuery();
				while (rs3.next()) {
					if (rs3.getInt("schemaexists") > 0) {
						;
					}
					else{
						ps1 = cnn.prepareStatement(INSERT_SCHEMA_INFO);
						ps1.setString(1, rs2.getString("databaseid"));
						ps1.setString(2, schema.getSchemaName());
						//setting default password is schema is HF or VC[VITTOOLS-357] 
						//if(schemaPrefix.equals(Constants.HF) || schemaPrefix.equals(Constants.VC) || schemaPrefix.equals(Constants.HP)){
							ps1.setString(3, Constants.DEFAULT_SCHEMA_PWD);
						//}
						//else{
						//	ps1.setString(3, schema.getSchemaPwd());
						//}
						ps1.setString(4, schemaType);
						
						CustomException.assertEqualsZero(ps1.executeUpdate(), "Could not insert schema details!!!!!!");
						
					}
						
				}
				
			
			
			}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
			DBUtil.release(cnn, ps1, null);
			DBUtil.release(cnn, ps2, rs2);
			DBUtil.release(cnn, ps3, rs3);
			
		}
	}
	
	public void insertSchemaInfo(DataSource ds, Schema schema) throws Exception {

		CustomException.assertEmptyString(schema.getDatabaseId(),
				"Database Id for server " + schema.getServerName());
		CustomException.assertEmptyString(schema.getSchemaName(),
				"Schema Name");
		CustomException.assertEmptyString(schema.getSchemaPwd(),
				"Password for Schema " + schema.getSchemaPwd());

		Connection cnn = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		ResultSet rs = null;
		PreparedStatement ps2 = null;
		ResultSet rs2 = null;
		String schemaType = "";
		String schemaPrefix = "";
		try {
			cnn = ds.getConnection();
			schemaPrefix = schema.getSchemaName().substring(0,2);
			if(schemaPrefix.startsWith("S")){
				schemaType = "1";
			}
			else{
				//System.out.println("Getting schema type from db");
				ps = cnn.prepareStatement(GET_SCHEMA_TYPE);
				ps.setString(1, schemaPrefix);
				rs = ps.executeQuery();
				while (rs.next()) {
					schemaType = rs.getString("SCHEMATYPE") == null ? "" : rs
							.getString("SCHEMATYPE");
					//System.out.println("SchemaType>>>>>>>>>>>>>"+schemaType);
				}
			}
			
			CustomException.assertEmptyString(schemaType,
					"Schema Type for Schema " + schema.getSchemaName());
			
			if(schemaPrefix.equals(Constants.HF)){
			ps2 = cnn.prepareStatement("SELECT databaseid FROM servers WHERE SERVERGROUPID IN ( SELECT SERVERGROUPID FROM  servers WHERE databaseid=?)");
			ps2.setString(1, schema.getDatabaseId());
			rs2 = ps2.executeQuery();
			while (rs2.next()) {
			ps1 = cnn.prepareStatement(INSERT_SCHEMA_INFO);
			ps1.setString(1, rs2.getString("databaseid"));
			ps1.setString(2, schema.getSchemaName());
			//setting default password is schema is HF or VC[VITTOOLS-357] 
			if(schemaPrefix.equals(Constants.HF) || schemaPrefix.equals(Constants.VC) || schemaPrefix.equals(Constants.HP)){
				ps1.setString(3, Constants.DEFAULT_SCHEMA_PWD);
			}
			else{
				ps1.setString(3, schema.getSchemaPwd());
			}
			ps1.setString(4, schemaType);
			
			CustomException.assertEqualsZero(ps1.executeUpdate(), "Could not insert schema details!!!!!!");
			
			}
			}else
			{
				
				ps1 = cnn.prepareStatement(INSERT_SCHEMA_INFO);
				ps1.setString(1, schema.getDatabaseId());
				ps1.setString(2, schema.getSchemaName());
				//setting default password is schema is HF or VC[VITTOOLS-357] 
				if(schemaPrefix.equals(Constants.HF) || schemaPrefix.equals(Constants.VC) || schemaPrefix.equals(Constants.HP)){
					ps1.setString(3, Constants.DEFAULT_SCHEMA_PWD);
				}
				else{
					ps1.setString(3, schema.getSchemaPwd());
				}
				ps1.setString(4, schemaType);
				
				CustomException.assertEqualsZero(ps1.executeUpdate(), "Could not insert schema details!!!!!!");
			}
			//System.out.println("No Error!!!!!!");
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
			DBUtil.release(cnn, ps1, null);
			DBUtil.release(cnn, ps2, rs2);
			
		}
	}
	
	
/*	private static final String GET_SCHEMA_PASSWORD = "" + "SELECT * "
			+ "FROM   (SELECT dbpwd "
			+ "        FROM   platform_schema_info a "
			+ "               join platform_database_info b "
			+ "                 ON a.databaseid = b.dbid "
			+ "        WHERE  Upper(a.dbuserid) = ? "
			+ "               AND b.dbid = ? "
			+ "               AND Upper(b.dbservername) = ? "
			+ "               AND Upper(b.service_name) = ? "
			+ "               AND b.port = ? "
			+ "               AND Upper(a.isdeleted) = 'N' "
			+ "        ORDER  BY a.ts DESC) " + "WHERE  ROWNUM < 2 ";*/
	
	private static final String GET_SCHEMA_PASSWORD_START = "" + "SELECT * "
			+ "FROM   (SELECT dbpwd "
			+ "        FROM   platform_schema_info a "
			+ "               join platform_database_info b "
			+ "                 ON a.databaseid = b.dbid "
			+ "        WHERE  Upper(a.dbuserid) = ? "
			+ "               AND b.dbid = ? "
			+ "               AND Upper(b.dbservername) = ? "
			//+ "               AND Upper(b.service_name) = ? "
			+ "               AND b.port = ? "
			+ "               AND Upper(a.isdeleted) = 'N' ";
	
	private static final String ADD_SERVICE_NAME = "               AND Upper(b.service_name) = ? ";
	
	private static final String GET_SCHEMA_PASSWORD_END = "        ORDER  BY a.ts DESC) " + "WHERE  ROWNUM < 2 ";
	
	
	
	
	/**
	 * @param ds-> DataSource
	 * @param schema-> schema whose password is to be set
	 * @return schema -> schema containing password
	 * @throws Exception
	 * Description: Gets password from database and returns schema with that password
	 */
	public Schema setSchemaPassword(DataSource ds, Schema schema)
			throws Exception {

		// checking for empty string
		CustomException
				.assertEmptyString(schema.getSchemaName(), "Schema Name");
		
		String schemaPrefix = "";
		try {
			schemaPrefix = schema.getSchemaName().substring(0, 2);
			if (schemaPrefix.equalsIgnoreCase(Constants.HP) || schemaPrefix.equalsIgnoreCase(Constants.VC) || schemaPrefix.equalsIgnoreCase(Constants.HF)) {
				schema.setSchemaPwd(Constants.DEFAULT_SCHEMA_PWD);
				return schema;
			}
		} catch (Exception e) {
			throw e;
		}
		
		CustomException.assertEmptyString(schema.getDatabaseId(),
				"Database Id for server " + schema.getServerName());
		CustomException
				.assertEmptyString(schema.getServerName(), "Server Name");
//		CustomException.assertEmptyString(schema.getService(), "Service");
		CustomException.assertEmptyString(schema.getPort(), "Port");

		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String finalQuery = "";
		if(schema.getService()!=null && schema.getService().equals("")){
			//System.out.println("Custom query");
			finalQuery = GET_SCHEMA_PASSWORD_START + GET_SCHEMA_PASSWORD_END;
		}
		else{
			//System.out.println("All query");
			CustomException.assertEmptyString(schema.getService(), "Service");
			finalQuery = GET_SCHEMA_PASSWORD_START + ADD_SERVICE_NAME + GET_SCHEMA_PASSWORD_END;
		}
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(finalQuery);
			ps.setString(1, schema.getSchemaName());
			ps.setString(2, schema.getDatabaseId());
			ps.setString(3, schema.getServerName());
			//ps.setString(4, schema.getService());
			ps.setString(4, schema.getPort());
			if(schema.getService()!=null && !schema.getService().equals("")){
				//System.out.println("setting service >>>>>>>>>>>>>>");
				ps.setString(5,schema.getService());
			}
			rs = ps.executeQuery();
			while (rs.next()) {
				schema.setSchemaPwd(rs.getString("dbpwd"));
			}
			//System.out.println("Password for schema "+schema.getSchemaName()+" is "+schema.getSchemaPwd());
			// checking if schema password id empty
			CustomException.assertEmptyString(schema.getSchemaPwd(),
					"Password for schema " + schema.getSchemaName());
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}

		return schema;
	}
	
	private static final String GET_SCHEMA_CREATOR_USER_N_PWD = ""
			+ "SELECT schemacreater_user, " + "       schemacreater_pass "
			+ "FROM   servers " + "WHERE  servergroupid = ? "
			+ "       AND Upper(host) = ? " + "       AND port = ? "
			+ "       AND Upper(service) = ? ";
	
	/**
	 * @param ds
	 * @param schema
	 * @return schema by setting schemacreate_user in schema.schemaName(default:utility) and schemacreater_pass in schema.schemaPwd
	 * Description:Sets schema username and password to schemacreators username and password. Default values are utility/oracle
	 * @throws Exception
	 */
	public Schema setSchemaCreatorUserNPwd(DataSource ds, Schema schema)
			throws Exception {

		CustomException.assertEmptyString(schema.getServerGroupId(),
				"Server Group Id");
		CustomException
				.assertEmptyString(schema.getServerName(), "Host Name");
		CustomException.assertEmptyString(schema.getPort(), "Port");
		CustomException.assertEmptyString(schema.getService(), "Service");

		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(GET_SCHEMA_CREATOR_USER_N_PWD);
			ps.setString(1, schema.getServerGroupId());
			ps.setString(2, schema.getServerName());
			ps.setString(3, schema.getPort());
			ps.setString(4, schema.getService());
			rs = ps.executeQuery();
			while (rs.next()) {
				schema.setSchemaName((rs.getString("schemacreater_user") == null || rs
						.getString("schemacreater_user") == "") ? "utility"
						: rs.getString("schemacreater_user"));
				schema.setSchemaPwd((rs.getString("schemacreater_pass") == null || rs
						.getString("schemacreater_pass") == "") ? "oracle"
						: rs.getString("schemacreater_pass"));
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}

		return schema;
	}
	
	private static final String SCHEMA_EXISTS = ""
										+ "SELECT Count(1) AS schemaexists "
										+ "FROM   processing.platform_schema_info "
										+ "WHERE  databaseid = ? "
										+ "       AND Upper(dbuserid) = ? "
										+ "       AND isdeleted = 'N' ";

	public boolean isSchemaInfoAlreadyInserted(DataSource ds, Schema schema)
			throws Exception {

		// checking for empty string
		CustomException
				.assertEmptyString(schema.getSchemaName(), "Schema Name");
		CustomException.assertEmptyString(schema.getDatabaseId(),
				"Database Id for server " + schema.getServerName());

		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		String schemaPrefix="";
		try {
			cnn = ds.getConnection();
			schemaPrefix = schema.getSchemaName().substring(0,2);
			System.out.println("schemaPrefix:"+schemaPrefix);
			logger.info("isSchemaInfoAlreadyInserted:" + schemaPrefix);
			if(schemaPrefix.equals(Constants.HF)){
				logger.info("isSchemaInfoAlreadyInserted inside HF:" + schemaPrefix);
				ps1 = cnn.prepareStatement("SELECT databaseid FROM servers WHERE SERVERGROUPID IN ( SELECT SERVERGROUPID FROM  servers WHERE databaseid=?)");
				ps1.setString(1, schema.getDatabaseId());
				rs1 = ps1.executeQuery();
				while (rs1.next()) {
					logger.info("isSchemaInfoAlreadyInserted inside inside HF:" + rs1.getString("databaseid"));
					ps = cnn.prepareStatement(SCHEMA_EXISTS);
					ps.setString(1, rs1.getString("databaseid"));
					ps.setString(2, schema.getSchemaName());
					rs = ps.executeQuery();
					while (rs.next()) {
						if (rs.getInt("schemaexists") > 0) {
							return true;
						}
					}
				
				}
				}
			else{
			ps = cnn.prepareStatement(SCHEMA_EXISTS);
			ps.setString(1, schema.getDatabaseId());
			ps.setString(2, schema.getSchemaName());
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getInt("schemaexists") > 0) {
					return true;
				}
			}
			}
		} catch (Exception e) {
			// e.printStackTrace();
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}

		return false;

	}
	
	private static final String GET_DBID = "SELECT DATABASEID FROM SERVERS WHERE SERVERGROUPID = ?";

	/**
	 * @param ds
	 * @param serverGroupId
	 * @param schemaName
	 * @param schemaPwd
	 * @throws Exception
	 * @description first gets the database id for the given server groupid , then inserts details into
	 * platform_schema_info table for vertica
	 */
	public void insertSchemaInfoForVertica(DataSource ds, String serverGroupId,
			String schemaName, String schemaPwd) throws Exception {
		CustomException.assertEmptyString(serverGroupId,
				"Servergroupid for getting vertica server lists!!!!!");
		CustomException.assertEmptyString(schemaName,
				"Schema Name for getting vertica server lists!!!!!");
		CustomException.assertEmptyString(schemaPwd,
				"Schema Password for getting vertica server lists!!!!!");

		List<String> databaseIdLs = new ArrayList<String>();
		Connection cnn = null;
		PreparedStatement ps1 = null;
		Statement ps2 = null;
		ResultSet rs = null;

		String queryToInsertSchemaInfo = "";

		try {
			cnn = ds.getConnection();
			/**
			 * First getting database-ids
			 */
			ps1 = cnn.prepareStatement(GET_DBID);
			ps1.setString(1, serverGroupId);
			rs = ps1.executeQuery();
			while (rs.next()) {
				CustomException.assertNull(rs.getString("DATABASEID"),
						"Database id is null for some nodes of vertica!!");
				databaseIdLs.add(rs.getString("DATABASEID"));
			}
			/**
			 * Inserting schema infos
			 */
			ps2 = cnn.createStatement();
			ps2 = generateQueryForInsertingSchemaInfoForVertica(databaseIdLs,
					schemaName, schemaPwd, ps2);
			ps2.executeBatch();
		} catch (Exception e) {
			logger.error("SchemaInfoDB.java>>>>Error insertSchemaInfoForVertica!!!!!!!");
			System.out.println("Getting vertica server database ids : "
					+ GET_DBID);
			System.out.println("Inserting schema info for vertica: "
					+ queryToInsertSchemaInfo);
			throw e;
		} finally {
			DBUtil.release(cnn, ps1, rs);
			if(ps2!=null){
				try {
					ps2.close();
				} catch (Exception e) {}
			}
		}
	}

/*	public String generateQueryForInsertingSchemaInfoForVertica(
			List<String> ls, String schemaName, String schemaPwd) {
		String s = "";
		if (ls == null || ls.isEmpty()) {
			return s;
		}
		for (int i = 0; i < ls.size(); i++) {
			s += "INSERT INTO PLATFORM_SCHEMA_INFO (SN, DATABASEID, DBUSERID, DBPWD, TS, SCHEMATYPE, ISDELETED) "
					+ "VALUES(S_PLATFORM_SCHEMA_INFO.NEXTVAL,"
					+ ls.get(i)
					+ ",'"
					+ schemaName
					+ "','"
					+ schemaPwd
					+ "',sysdate,1,'N')";
		}
		return s;
	}*/
	
	/**
	 * @param ls
	 * @param schemaName
	 * @param schemaPwd
	 * @param s
	 * @return
	 * @throws SQLException
	 * @description generates query for inserting schema into in table processing.platform_schema_info for vertica
	 * Here schema type is set to 1 by default
	 */
	public Statement generateQueryForInsertingSchemaInfoForVertica(
			List<String> ls, String schemaName, String schemaPwd ,Statement s) throws SQLException {
		String query = "";
		for (int i = 0; i < ls.size(); i++) {
			query = "INSERT INTO PLATFORM_SCHEMA_INFO (SN, DATABASEID, DBUSERID, DBPWD, TS, SCHEMATYPE, ISDELETED) "
					+ "VALUES((SELECT Max(sn)+1 FROM platform_schema_info),"
					+ ls.get(i)
					+ ",'"
					+ schemaName
					+ "','"
					+ schemaPwd
					+ "',sysdate,1,'N')";
			s.addBatch(query);
		}
		return s;
	}
	
	private static final String DBA_OBJECT_EXISTS_QRY = ""
			+ "SELECT Count(1) as count " + "FROM   dba_objects "
			+ "WHERE  object_name = Upper(?) "
			+ "       AND object_type = Upper(?) "
			+ "       AND owner = Upper(?)";

	public boolean dbaObjExists(Schema schema, String objectName,
			String objectType) throws Exception {
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean objExists = false;
		try {
			cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
			ps = cnn.prepareStatement(DBA_OBJECT_EXISTS_QRY);
			ps.setString(1, objectName);
			ps.setString(2, objectType);
			ps.setString(3, schema.getSchemaName());
			rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getInt("count") > 0) {
					objExists = true;
				}
			}
		} catch (Exception e) {
			logger.error(
					"Error on SchemaInfoDB.dbaObjExists()->Checking DBA Object Type "
							+ objectType + " of Name " + objectName
							+ " in schema " + schema, e);
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return objExists;
	}
	
	public static void main(String[] args) {
		for(int i =0;i<3;i++){
			try {
				CustomException.assertNull(null, "testing");
				System.out.println("aaaaa");
			} catch (CustomException e) {
				e.printStackTrace();
			}
			System.out.println("bbbbbb");
		}
	}
}
