package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.util.Constants;
import dashboard.util.QCConstants;
import dashboard.web.util.CustomException;

public class FixedParameter {

	public FixedParameter() {
	}
	
	private DataSource dataSource = null;
    
    public void setDataSource(DataSource ds) {
        dataSource = ds;
    }
    
    protected Log logger = LogFactory.getLog(getClass());
	
	public String getValue(String key,String hostingServer) throws RuntimeException{
		String strSQL = "SELECT VALUE FROM FIXEDPARAMETERS WHERE KEY = ?";//default is fixedparamters
		
		//checking hosting server 
		if((hostingServer!=null) &&(!hostingServer.equals(""))){
			
			if(hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA)){
				strSQL = "SELECT VALUE FROM FIXEDPARAMETERS_CMA WHERE KEY = ? AND UPPER(SERVER) = 'RAC'";
			}
			if(hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)){
				strSQL = "SELECT VALUE FROM FIXEDPARAMETERS_CMA WHERE KEY = ? AND UPPER(SERVER) ='DR'";
			}
		}
		
		//System.out.println("Query is >>>>>>>>>>>>>>>>>>>>>>>"+strSQL);
		
		String value ="";
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(strSQL);
			ps.setString(1, key);
			rs = ps.executeQuery();
			while (rs.next()) {
				value = rs.getString(1);
			}
		} catch (Exception ex) {
			logger.debug("FixedParameters.java->Error..Getting value for key :"+key+" "
					+ ex.getMessage());
			System.out.println("Error getting value for key: "+key);
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		if(value == null || value.equals("")){
			throw new RuntimeException("Value for key: "+key+" not found");
		}
		return value;
		
	}
	
    private static final String GET_PARAMETERS_QRY = "SELECT ParameterValue FROM  ZEDB_PARAMS where upper(ParameterName)=upper(?)";
    
    /**
     * @Description: Gets the parameter value based on the parameter name for
     *               sending mail
     * @param parameterName
     * @return
     * @throws Exception 
     */
    public String getDashboardParams(String parameterName) throws Exception
    {
        String parameterValue = "";
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try
        {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(GET_PARAMETERS_QRY);
            ps.setString(1, parameterName);
            rs = ps.executeQuery();
            while (rs.next())
            {
                parameterValue = rs.getString(1);
            }
            CustomException.assertNull(parameterValue, "Value not found in processing.zedbparams for  "+parameterName);
            CustomException.assertEmptyString(parameterValue, " value for "+parameterName);
        } catch (Exception ex)
        {
            //logger.error("Error on FixedParameter(1)->getSendMailParam(parameterName) " + parameterName, ex);
            throw ex;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        return parameterValue;
    }
	
	public String getWHParam(String key){
		String strSQL = "SELECT VALUE FROM WAREHOUSEPARAMS WHERE KEY = ?";//default is fixedparamters
		
		String value ="";
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(strSQL);
			ps.setString(1, key);
			rs = ps.executeQuery();
			while (rs.next()) {
				value = rs.getString(1);
			}
		} catch (Exception ex) {
			logger.debug("FixedParameters.getWHParam()->Error..Getting value for key :"+key+" "
					+ ex.getMessage());
			System.out.println("Error getting value for key: "+key);
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		if(value == null || value.equals("")){
			throw new RuntimeException("Value for key: "+key+" not found");
		}
		return value;
		
	}
	
	private static final String FN_GETPASSWORD = "SELECT FN_GETPASSWORD() AS PASSWORD FROM DUAL";

	public String getSchemaPassword() throws Exception {
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(FN_GETPASSWORD);
			rs = ps.executeQuery();
			while (rs.next()) {
				return (rs.getString("password") == null) ? "" : rs
						.getString("password");
			}
		} catch (Exception e) {
			throw e;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return "";
	}
	
	private static final String GET_FQC_PARAMS = "select parametername,parametervalue from qc_reports where UPPER(reportname)='"+QCConstants.FQC_EXTRACT+"'";
	public Map<String, String> getFQCExtractParams() throws SQLException {
		Map<String, String> fqcParams = new HashMap<String, String>();
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(GET_FQC_PARAMS);
			rs = ps.executeQuery();
			while (rs.next()) {
				fqcParams.put(rs.getString("parametername").toUpperCase(), rs.getString("parametervalue"));
			}
		} catch (SQLException ex) {
			logger.error("Error getting fqc params ", ex);
			throw ex;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return fqcParams;
	}
	
	private static final String GET_STAGING_SERVER = "SELECT parametername,parametervalue FROM zedb_params WHERE Upper(parametername) LIKE 'STAGING%'";
	public Map<String, String> getStagingServerDetails() throws SQLException{
		Map<String, String> stagingServer = new HashMap<String, String>();
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(GET_STAGING_SERVER);
			rs = ps.executeQuery();
			while (rs.next()) {
				stagingServer.put(rs.getString("parametername").toUpperCase(), rs.getString("parametervalue"));
			}
		} catch (SQLException ex) {
			logger.error("Error getting staging server details", ex);
			throw ex;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return stagingServer;
	}
}
