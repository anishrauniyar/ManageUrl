package dashboard.db;

import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.web.util.VerticaException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class VerticaStaticMapDB {

    private final Log logger = LogFactory.getLog(getClass());

    //private static final String CHECK_SCHEMA_FOR_STATIC_MAPPING = "select count(*) from vertica_static_schema_mapping where upper(schem_name)=? or appid=?";
    private static final String CHECK_SCHEMA_FOR_STATIC_MAPPING = ""
            + "SELECT Count(*) FROM vertica_static_schema_mapping WHERE appid=? OR (appid=? AND Upper(processing_server)=Upper(?))";

    public boolean isSchemaStaticallyMapped(DataSource ds, Schema orclSchema, Schema vtkaSchema) {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean mapped = false;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_SCHEMA_FOR_STATIC_MAPPING);
            ps.setString(1, vtkaSchema.getSchemaName().substring(2, 8));
            ps.setString(2, vtkaSchema.getSchemaName().substring(2, 8));
            ps.setString(3, orclSchema.getServerName());
            rs = ps.executeQuery();
            if (rs.next()) {
                mapped = rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            logger.error("[Error while checking statically mapped condition for schema " + vtkaSchema + " with processing server "
                    + orclSchema.getServerName() + "] " + e);
            return mapped;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return mapped;
    }

//    private static final String SCHEMA_NAME_N_APPID_MAPPED = "SELECT Count(1) FROM vertica_static_schema_mapping WHERE upper(schema_name)=? AND appid=?";
//    private static final String APPID_ONLY_MAPPED = "SELECT Count(1) FROM vertica_static_schema_mapping WHERE schema_name is null AND appid=?";
    private static final String PROCESSING_SERVER_N_APPID_MAPPED = "SELECT Count(1) FROM vertica_static_schema_mapping WHERE upper(processing_server)=Upper(?) AND appid=?";
    private static final String APPID_ONLY_MAPPED = "SELECT Count(1) FROM vertica_static_schema_mapping WHERE processing_server is null AND appid=?";

    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(DataSource ds, Schema orclSchema, Schema vtkaSchema,
            boolean isTransferToProd, String event) throws VerticaException {
        VerticaSplitClusterDB db = new VerticaSplitClusterDB();
        List<Map<ServerGroup, List<Server>>> finalList = new ArrayList<>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        boolean processingServerNAppIdMapped = Boolean.FALSE;
        boolean appIdOnlyMapped = Boolean.FALSE;
        String cluster_a = (isTransferToProd) ? "Upper(d.prod_cluster_a)" : "Upper(d.dr_cluster_a)";
        String cluster_b = (isTransferToProd) ? "Upper(d.prod_cluster_b)" : "Upper(d.dr_cluster_b)";
        String cluster_c = (isTransferToProd) ? "Upper(d.prod_cluster_c)" : "Upper(d.dr_cluster_c)";
        String whereCond = "";
        try {
            cnn = ds.getConnection();
            // check if schema_name and appid both statically mapped
            ps = cnn.prepareCall(PROCESSING_SERVER_N_APPID_MAPPED);
            ps.setString(1, orclSchema.getServerName());
            ps.setString(2, vtkaSchema.getSchemaName().substring(2, 8));
            rs = ps.executeQuery();
            if (rs.next()) {
                processingServerNAppIdMapped = rs.getInt(1) > 0;
            }

            // check if appId is statically mapped [here schema_name must be null]
            ps = cnn.prepareCall(APPID_ONLY_MAPPED);
            ps.setString(1, vtkaSchema.getSchemaName().substring(2, 8));
            rs = ps.executeQuery();
            if (rs.next()) {
                appIdOnlyMapped = rs.getInt(1) > 0;
            }
            logger.info("Statical Mapping Result for schema:" + vtkaSchema + " in processing server:" + orclSchema.getServerName());
            logger.info("SchemaAndAppIdMapped:" + processingServerNAppIdMapped);
            logger.info("AppIdOnlyMapped:" + appIdOnlyMapped);

            if (!processingServerNAppIdMapped && !appIdOnlyMapped) {
                // must not entry here as static mapping case is already checked
                VerticaException.assertError(event, "Vertica Static Mapping could not found any mapped clusters!!!!");
            }
            // first go with both case mapping
            if (processingServerNAppIdMapped) {
                whereCond = " where Upper(d.processing_server)=Upper('" + orclSchema.getServerName() + "') and d.appid='" + vtkaSchema.getSchemaName().substring(2, 8) + "' ";
            } else if (appIdOnlyMapped) {
                whereCond = " where Upper(d.processing_server) is NULL and d.appid='" + vtkaSchema.getSchemaName().substring(2, 8) + "' ";
            }

            String query = ""
                    + "SELECT a.groupname AS servergroupname, "
                    + "       a.category, "
                    + "       b.servergroupid, "
                    + "       b.databaseid, "
                    + "       b.host, "
                    + "       b.port, "
                    + "       b.DATABASE, "
                    + "       c.vipflag "
                    + "FROM   servergroup a "
                    + "       join servers b "
                    + "         ON a.servergroupid = b.servergroupid "
                    + "       join platform_database_info c "
                    + "         ON b.databaseid = c.dbid "
                    + "       join vertica_static_schema_mapping d "
                    + "         ON upper(a.servergroupid) = " + cluster_a + " "
                    + whereCond + " "
                    + "UNION ALL "
                    + "SELECT a.groupname AS servergroupname, "
                    + "       a.category, "
                    + "       b.servergroupid, "
                    + "       b.databaseid, "
                    + "       b.host, "
                    + "       b.port, "
                    + "       b.DATABASE, "
                    + "       c.vipflag "
                    + "FROM   servergroup a "
                    + "       join servers b "
                    + "         ON a.servergroupid = b.servergroupid "
                    + "       join platform_database_info c "
                    + "         ON b.databaseid = c.dbid "
                    + "       join vertica_static_schema_mapping d "
                    + "         ON upper(a.servergroupid) =" + cluster_b + " "
                    + whereCond + " "
                    + "UNION ALL "
                    + "SELECT a.groupname AS servergroupname, "
                    + "       a.category, "
                    + "       b.servergroupid, "
                    + "       b.databaseid, "
                    + "       b.host, "
                    + "       b.port, "
                    + "       b.DATABASE, "
                    + "       c.vipflag "
                    + "FROM   servergroup a "
                    + "       join servers b "
                    + "         ON a.servergroupid = b.servergroupid "
                    + "       join platform_database_info c "
                    + "         ON b.databaseid = c.dbid "
                    + "       join vertica_static_schema_mapping d "
                    + "         ON upper(a.servergroupid) = " + cluster_c + " "
                    + whereCond;

            logger.info("Query to get static maped server groups:" + query);
            ps = cnn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = ps.executeQuery();
            rs.last();
            if (rs.getRow() > 0) {
                rs.beforeFirst();
                while (rs.next()) {
                    ServerGroup serverGroup = new ServerGroup().setServerGroupId(rs.getString("servergroupid"))
                            .setGroupName(rs.getString("servergroupname")).setCategory(rs.getString("category"));
                    Server server = new Server().setServerGroupId(rs.getString("servergroupid"))
                            .setDatabaseId(rs.getString("databaseid")).setHost(rs.getString("host"))
                            .setPort(rs.getInt("port")).setDatabase(rs.getString("database"))
                            .setIsVip(rs.getString("vipflag"));
                    finalList = db.add(serverGroup, server, finalList);
                }
            } else {
                VerticaException.assertError(event, "No Mapped Server Groups Found for Schema " + vtkaSchema + " Please insert schema/servergroup mapping");
            }

        } catch (SQLException | VerticaException e) {
            VerticaException.assertError(event, e.getMessage());
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return finalList;
    }

//    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(DataSource ds, Schema schema,
//            boolean isTransferToProd, String event) throws VerticaException {
//        VerticaSplitClusterDB db = new VerticaSplitClusterDB();
//        List<Map<ServerGroup, List<Server>>> finalList = new ArrayList<>();
//        Connection cnn = null;
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//
//        boolean schemaNAppIdMapped = Boolean.FALSE;
//        boolean appIdOnlyMapped = Boolean.FALSE;
//        String cluster_a = (isTransferToProd) ? "Upper(d.prod_cluster_a)" : "Upper(d.dr_cluster_a)";
//        String cluster_b = (isTransferToProd) ? "Upper(d.prod_cluster_b)" : "Upper(d.dr_cluster_b)";
//        String cluster_c = (isTransferToProd) ? "Upper(d.prod_cluster_c)" : "Upper(d.dr_cluster_c)";
//        String whereCond = "";
//        try {
//            cnn = ds.getConnection();
//            // check if schema_name and appid both statically mapped
//            ps = cnn.prepareCall(SCHEMA_NAME_N_APPID_MAPPED);
//            ps.setString(1, schema.getSchemaName().toUpperCase());
//            ps.setString(2, schema.getSchemaName().substring(2, 8));
//            rs = ps.executeQuery();
//            if (rs.next()) {
//                schemaNAppIdMapped = rs.getInt(1) > 0;
//            }
//
//            // check if appId is statically mapped [here schema_name must be null]
//            ps = cnn.prepareCall(APPID_ONLY_MAPPED);
//            ps.setString(1, schema.getSchemaName().substring(2, 8));
//            rs = ps.executeQuery();
//            if (rs.next()) {
//                appIdOnlyMapped = rs.getInt(1) > 0;
//            }
//            logger.info("Statical Mapping Result for schema:" + schema);
//            logger.info("SchemaAndAppIdMapped:" + schemaNAppIdMapped);
//            logger.info("AppIdOnlyMapped:" + appIdOnlyMapped);
//
//            if (!schemaNAppIdMapped && !appIdOnlyMapped) {
//                // must not entry here as static mapping case is already checked
//                VerticaException.assertError(event, "Vertica Static Mapping could not found any mapped clusters!!!!");
//            }
//            // first go with both case mapping
//            if (schemaNAppIdMapped) {
//                whereCond = " where Upper(d.schema_name)='" + schema.getSchemaName().toUpperCase() + "' and d.appid='" + schema.getSchemaName().substring(2, 8) + "' ";
//            } else if (appIdOnlyMapped) {
//                whereCond = " where Upper(d.schema_name) is NULL and d.appid='" + schema.getSchemaName().substring(2, 8) + "' ";
//            }
//
//            String query = ""
//                    + "SELECT a.groupname AS servergroupname, "
//                    + "       a.category, "
//                    + "       b.servergroupid, "
//                    + "       b.databaseid, "
//                    + "       b.host, "
//                    + "       b.port, "
//                    + "       b.DATABASE, "
//                    + "       c.vipflag "
//                    + "FROM   servergroup a "
//                    + "       join servers b "
//                    + "         ON a.servergroupid = b.servergroupid "
//                    + "       join platform_database_info c "
//                    + "         ON b.databaseid = c.dbid "
//                    + "       join vertica_static_schema_mapping d "
//                    + "         ON upper(a.servergroupid) = " + cluster_a + " "
//                    + whereCond + " "
//                    + "UNION ALL "
//                    + "SELECT a.groupname AS servergroupname, "
//                    + "       a.category, "
//                    + "       b.servergroupid, "
//                    + "       b.databaseid, "
//                    + "       b.host, "
//                    + "       b.port, "
//                    + "       b.DATABASE, "
//                    + "       c.vipflag "
//                    + "FROM   servergroup a "
//                    + "       join servers b "
//                    + "         ON a.servergroupid = b.servergroupid "
//                    + "       join platform_database_info c "
//                    + "         ON b.databaseid = c.dbid "
//                    + "       join vertica_static_schema_mapping d "
//                    + "         ON upper(a.servergroupid) =" + cluster_b + " "
//                    + whereCond + " "
//                    + "UNION ALL "
//                    + "SELECT a.groupname AS servergroupname, "
//                    + "       a.category, "
//                    + "       b.servergroupid, "
//                    + "       b.databaseid, "
//                    + "       b.host, "
//                    + "       b.port, "
//                    + "       b.DATABASE, "
//                    + "       c.vipflag "
//                    + "FROM   servergroup a "
//                    + "       join servers b "
//                    + "         ON a.servergroupid = b.servergroupid "
//                    + "       join platform_database_info c "
//                    + "         ON b.databaseid = c.dbid "
//                    + "       join vertica_static_schema_mapping d "
//                    + "         ON upper(a.servergroupid) = " + cluster_c + " "
//                    + whereCond;
//
//            logger.info("Query to get static maped server groups:" + query);
//            ps = cnn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
//            rs = ps.executeQuery();
//            rs.last();
//            if (rs.getRow() > 0) {
//                rs.beforeFirst();
//                while (rs.next()) {
//                    ServerGroup serverGroup = new ServerGroup().setServerGroupId(rs.getString("servergroupid"))
//                            .setGroupName(rs.getString("servergroupname")).setCategory(rs.getString("category"));
//                    Server server = new Server().setServerGroupId(rs.getString("servergroupid"))
//                            .setDatabaseId(rs.getString("databaseid")).setHost(rs.getString("host"))
//                            .setPort(rs.getInt("port")).setDatabase(rs.getString("database"))
//                            .setIsVip(rs.getString("vipflag"));
//                    finalList = db.add(serverGroup, server, finalList);
//                }
//            } else {
//                VerticaException.assertError(event, "No Mapped Server Groups Found for Schema " + schema + " Please insert schema/servergroup mapping");
//            }
//
//        } catch (SQLException | VerticaException e) {
//            VerticaException.assertError(event, e.getMessage());
//        } finally {
//            DBUtil.release(cnn, ps, rs);
//        }
//        return finalList;
//    }
//    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(DataSource ds, Schema schema,
//            boolean isTransferToProd, String event) throws VerticaException {
//        VerticaSplitClusterDB db = new VerticaSplitClusterDB();
//        List<Map<ServerGroup, List<Server>>> finalList = new ArrayList<>();
//        Connection cnn = null;
//        PreparedStatement ps = null;
//        ResultSet rs = null;
//
//        String cluster_a = (isTransferToProd) ? "Upper(d.prod_cluster_a)" : "Upper(d.dr_cluster_a)";
//        String cluster_b = (isTransferToProd) ? "Upper(d.prod_cluster_b)" : "Upper(d.dr_cluster_b)";
//        String cluster_c = (isTransferToProd) ? "Upper(d.prod_cluster_c)" : "Upper(d.dr_cluster_c)";
//
//        String query = ""
//                + "SELECT a.groupname AS servergroupname, "
//                + "       a.category, "
//                + "       b.servergroupid, "
//                + "       b.databaseid, "
//                + "       b.host, "
//                + "       b.port, "
//                + "       b.DATABASE, "
//                + "       c.vipflag "
//                + "FROM   servergroup a "
//                + "       join servers b "
//                + "         ON a.servergroupid = b.servergroupid "
//                + "       join platform_database_info c "
//                + "         ON b.databaseid = c.dbid "
//                + "       join vertica_static_schema_mapping d "
//                + "         ON upper(a.servergroupid) = " + cluster_a + " "
//                + "WHERE  d.appid = '" + schema.getSchemaName().substring(2, 8) + "' "
//                + "UNION ALL "
//                + "SELECT a.groupname AS servergroupname, "
//                + "       a.category, "
//                + "       b.servergroupid, "
//                + "       b.databaseid, "
//                + "       b.host, "
//                + "       b.port, "
//                + "       b.DATABASE, "
//                + "       c.vipflag "
//                + "FROM   servergroup a "
//                + "       join servers b "
//                + "         ON a.servergroupid = b.servergroupid "
//                + "       join platform_database_info c "
//                + "         ON b.databaseid = c.dbid "
//                + "       join vertica_static_schema_mapping d "
//                + "         ON upper(a.servergroupid) =" + cluster_b + " "
//                + "WHERE  d.appid  = '" + schema.getSchemaName().substring(2, 8) + "' "
//                + "UNION ALL "
//                + "SELECT a.groupname AS servergroupname, "
//                + "       a.category, "
//                + "       b.servergroupid, "
//                + "       b.databaseid, "
//                + "       b.host, "
//                + "       b.port, "
//                + "       b.DATABASE, "
//                + "       c.vipflag "
//                + "FROM   servergroup a "
//                + "       join servers b "
//                + "         ON a.servergroupid = b.servergroupid "
//                + "       join platform_database_info c "
//                + "         ON b.databaseid = c.dbid "
//                + "       join vertica_static_schema_mapping d "
//                + "         ON upper(a.servergroupid) = " + cluster_c + " "
//                + "WHERE  d.appid  = '" + schema.getSchemaName().substring(2, 8) + "' ";
//        try {
//            logger.info("Query to get static maped server groups:" + query);
//            cnn = ds.getConnection();
//            ps = cnn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
//            rs = ps.executeQuery();
//            rs.last();
//            if (rs.getRow() > 0) {
//                rs.beforeFirst();
//                while (rs.next()) {
//                    ServerGroup serverGroup = new ServerGroup().setServerGroupId(rs.getString("servergroupid"))
//                            .setGroupName(rs.getString("servergroupname")).setCategory(rs.getString("category"));
//                    Server server = new Server().setServerGroupId(rs.getString("servergroupid"))
//                            .setDatabaseId(rs.getString("databaseid")).setHost(rs.getString("host"))
//                            .setPort(rs.getInt("port")).setDatabase(rs.getString("database"))
//                            .setIsVip(rs.getString("vipflag"));
//                    finalList = db.add(serverGroup, server, finalList);
//                }
//            } else {
//                VerticaException.assertError(event, "No Mapped Server Groups Found for Schema " + schema + " Please insert schema/servergroup mapping");
//            }
//        } catch (SQLException | VerticaException e) {
//            VerticaException.assertError(event, e.getMessage());
//        } finally {
//            DBUtil.release(cnn, ps, rs);
//        }
//        return finalList;
//    }
}
