package dashboard.db;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLWarning;
import java.sql.SQLException;

import java.util.LinkedList;
import java.util.List;

public class OracleClientName{
	protected Log logger = LogFactory.getLog(getClass());
    private DataSource dataSource = null;
    
    
    public void setDataSource(DataSource ds1) {
        dataSource = ds1;
     
    }
    
    
   

    public String client_name(String schema)
    {
    	 
         Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rset = null;
        
         
         String client_id = null;
         String client_name = null;
         String initial = null;
         String temp = "null";
         String initial1 ="s"; 
       
         schema=schema.trim();
         schema=schema.toLowerCase();
         initial=schema.substring(0,1);
        
         if (initial.equalsIgnoreCase(initial1))
	         {
	        	 client_id=schema.substring(1,5);
	        	// System.out.println(client_id);
	         }
         else
	         {
	        	 client_id=schema.substring(2,6);
	        	// System.out.println(client_id);
	        	 
	         }
	         client_id=client_id.substring(1,4);
	         
	         
	         String query = "select clientname from usr_clients where clientid="+client_id;
	         
	         try {
	             cnn = dataSource.getConnection();
	             ps = cnn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
	             rset = ps.executeQuery();        	 
	        	    
	        	     while (rset.next ())
	        	 	{ 		
	        	   		temp=rset.getString(1);
	        	   		client_name=temp.trim();
	        	          
	        	   	}
	         } 
	         catch (SQLException ex)
	         { 
	        	 System.out.println(ex);
	        	 System.out.println("Could not connect to database");
	         }
	         
	         finally {
	             DBUtil.release(cnn, ps, rset);
	         }
	         return (client_name);
    }
    
  
}

