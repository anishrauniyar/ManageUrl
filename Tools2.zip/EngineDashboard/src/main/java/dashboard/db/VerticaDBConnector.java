package dashboard.db;

import java.sql.DriverManager;
import java.sql.Connection;
import java.util.Properties;

import dashboard.data.Schema;

/**
 * Connects to the vertica database.
 */
public class VerticaDBConnector {
    /**
     * @param s Schema info with credential info.
     * @return Connection to the specified schema
     * @throws Exception on failure to connect.
     */
    public Connection getConnectionForSchema(Schema s) throws Exception {
        Class.forName("com.vertica.Driver").newInstance();
        Properties prop = new Properties();
        prop.put("user", s.getSchemaName());
        prop.put("password", s.getSchemaPwd());

        return DriverManager.getConnection( getUrl(s), prop);
    }
    
    private static String getUrl(Schema s) {
        String url;
        url = "jdbc:vertica://" +
        		s.getServerName() + ":" + s.getPort() + "/" + s.getDatabase();
        return url;
    }
}