package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.security.ProcessingRole;
import dashboard.security.RoleSet;
import dashboard.security.User;

public class UserDB {

    protected Log logger = LogFactory.getLog(getClass());

    private static final String LOGIN_QRY =
        " select userId, loginName, userName from Usr_Users " +
        "  where lower(loginName) = lower(?) and d2pwd = return_hash(loginname || ?, d2key) ";
    
    private static final String SSO_QRY = "select userId,loginName,userName from usr_users where lower(loginName)=lower(?)";
    
    private String LDAP_USER_QRY = ""
    	+ "SELECT users.userid, "
    	+ "       loginname, "
    	+ "       username, "
    	+ "       db_role.actdirname "
    	+ "FROM   usr_users users "
    	+ "       join db_usersroles db_role "
    	+ "         ON users.userid = db_role.userid "
    	+ "WHERE  lower(db_role.actdirname) = lower(?) ";
    public boolean isValidLogin(DataSource ds, String loginName, String pwd) throws Exception {
        boolean retVal = false;
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement( LOGIN_QRY);
            ps.setString(1, loginName.trim());
            ps.setString(2, pwd.trim());
            rs = ps.executeQuery();

            if(rs.next()) {
                retVal = true;
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return retVal;
    }
    /**
     * @Description: Checks if the loginName is valid or not
     * @param ds
     * @param loginName
     * @return true if user exists
     * @throws SQLException
     */
    public boolean isValidSSOLogin(DataSource ds,String loginName) throws SQLException{
    	 boolean retVal = false;
         Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rs = null;
         try {
             cnn = ds.getConnection();
             ps = cnn.prepareStatement( SSO_QRY);
             ps.setString(1, loginName.trim());
             rs = ps.executeQuery();

             if(rs.next()) {
                 retVal = true;
             }
         } finally {
             DBUtil.release(cnn, ps, rs);
         }
         return retVal;
    }
    public User getUser(DataSource ds, String loginName, String pwd) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        User user = null;

        try {
            cnn = ds.getConnection();
            ps  = cnn.prepareStatement(LOGIN_QRY);
            ps.setString(1, loginName.trim());
            ps.setString(2, pwd.trim());
            rs = ps.executeQuery();
            if(rs.next()) {
                user = new User(rs.getString(1), rs.getString(2), rs.getString(3));
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return user;
    }

    public User getUserForLDAPUser(DataSource ds,String actDirName) throws Exception{
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User user = null;
        try {
            cnn = ds.getConnection();
            ps  = cnn.prepareStatement(LDAP_USER_QRY);
            ps.setString(1, actDirName.trim());
            rs = ps.executeQuery();
            
            if(rs.next()) {
                user = new User(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4));
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return user;
    }
    /**
     * @Description : Gets user details without password
     * @param ds
     * @param loginName
     * @return
     * @throws SQLException
     */
    public User getUserWithoutPwd(DataSource ds,String loginName) throws SQLException{
    	Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        User user = null;
        try {
            cnn = ds.getConnection();
            ps  = cnn.prepareStatement(SSO_QRY);
            ps.setString(1, loginName.trim());
            rs = ps.executeQuery();
            
            if(rs.next()) {
                user = new User(rs.getString(1), rs.getString(2), rs.getString(3));
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return user;
    }

    private static final String USERS_ROLE =
        "select UserRole from DB_USERSROLES where userId = ? ";
    public RoleSet getUsersRoles(DataSource dataSource, String userId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        RoleSet roleSet = new RoleSet();
        try {
            cnn = dataSource.getConnection();
            ps  = cnn.prepareStatement(USERS_ROLE);
            ps.setString(1, userId);
            rs = ps.executeQuery();
            int i=0;
            while(rs.next()) {
                roleSet.addRole(ProcessingRole.createRole(rs.getString(1)));
            }
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return roleSet;
    }

}
