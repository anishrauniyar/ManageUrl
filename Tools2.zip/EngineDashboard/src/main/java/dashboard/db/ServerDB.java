package dashboard.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.ClusterGroup;
import dashboard.data.DataFileDir;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.data.TempTablespace;
import dashboard.util.Constants;
import dashboard.util.KeyValue;
import dashboard.web.util.CustomException;

public class ServerDB {

	protected Log logger = LogFactory.getLog(getClass());
    /*----------------------------------------------------------------------*/
    /* SERVER GROUP CHECK */
    /*----------------------------------------------------------------------*/

    private static final String SERVER_GROUP_CHECK_QRY =
        "select 1 from  Servers " +
        " where ServerGroupId = ? and  " +
        "  upper(Host) = upper(?)  and Port = ?  and upper(Service) = upper(?) and upper(SIDFlag) = upper(?) ";

    
    private static final String VERTICA_SERVER_GROUP_CHECK_QRY =
    	"select 1 from  Servers " +
        " where ServerGroupId = ? and  " +
        "  upper(Host) = upper(?)  and Port = ?  and upper(Database) = upper(?) and upper(Connection) = upper(?)";
    
    private static final String VERTICA_CMA_SERVER_GROUP_CHECK_QRY =
        	"select 1 from  Servers " +
            " where ServerGroupId = ? and  " +
            "  upper(Host) = upper(?)  and Port = ?  and upper(Database) = upper(?)";
    
    private static final String DMEXPRESS_SERVER_GROUP_CHECK_QRY =
    	"select 1 from  Servers " +
        " where ServerGroupId = ? and  " +
        "  upper(Host) = upper(?)  and Port = ?  and upper(Instance) = upper(?) ";

    public boolean hasValidServerGroup(DataSource ds, Schema schema) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean validServerGroup = false;
        String hostingServer = schema.getHostingServer();
        //for oracle
        if(hostingServer == null||
           hostingServer == "" ||
           hostingServer.equalsIgnoreCase(Constants.ORACLE_BA)||
           hostingServer.equalsIgnoreCase(Constants.ORACLE) ||
           hostingServer.equalsIgnoreCase(Constants.ORACLE_BA_CMA) ||
           hostingServer.equalsIgnoreCase(Constants.ORACLE_DR_BA_CMA)
          )
        {
        	try {
                cnn = ds.getConnection();
                ps = cnn.prepareStatement(SERVER_GROUP_CHECK_QRY);
                ps.setString(1, schema.getServerGroupId());
                ps.setString(2, schema.getServerName());
                ps.setInt(3, Integer.parseInt(schema.getPort()) );
                ps.setString(4, schema.getService());
                ps.setString(5, schema.getSidFlag());
                rs = ps.executeQuery();
                if (rs.next()) {
                    validServerGroup = true;
                }else {
                    logger.info("invalid server: " + schema);
                }            
            } catch(Exception ex) {
                logger.info("Error..Verifying server group: " + ex.getMessage());
                throw ex;
            }finally {
                DBUtil.release(cnn, ps, rs);
            }
        }
        //for vertica 
        else if((hostingServer.equalsIgnoreCase(Constants.VERTICA)) || 
                (hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA)) ||
                (hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)))
        {
        	validServerGroup = hasValidVerticaServerGroup(ds,schema);
        }
        //for dmexpress
        else
        {
        	validServerGroup = hasValidDMExpressServerGroup(ds, schema);
        }
        return validServerGroup;
    }
    
    public boolean hasValidVerticaServerGroup(DataSource ds,Schema schema) throws Exception{
    	 Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rs = null;
         boolean validVerticaServerGroup = false;
         
         String query = VERTICA_CMA_SERVER_GROUP_CHECK_QRY;
         if(schema.getHostingServer().equalsIgnoreCase(Constants.VERTICA) ||
                 schema.getHostingServer().equalsIgnoreCase(Constants.VERTICA_CMA) ||
            schema.getHostingServer().equalsIgnoreCase(Constants.VERTICA_DR_CMA)){
        	 query = VERTICA_CMA_SERVER_GROUP_CHECK_QRY;
         }
         
         try {
             cnn = ds.getConnection();
             ps = cnn.prepareStatement(query);
             ps.setString(1, schema.getServerGroupId());
             ps.setString(2, schema.getServerName());
             ps.setInt(3, Integer.parseInt(schema.getPort()) );
             ps.setString(4, schema.getDatabase());
             /*if(schema.getHostingServer().equalsIgnoreCase(Constants.VERTICA)){
            	 ps.setString(5, schema.getConnection());
             }*/
             rs = ps.executeQuery();
             if (rs.next()) {
            	 validVerticaServerGroup = true;
             }else {
                 logger.info("invalid vertica server: " + schema);
             }            
         } catch(Exception ex) {
             logger.info("Error..Verifying vertica server group: " + ex.getMessage());
             throw ex;
         }finally {
             DBUtil.release(cnn, ps, rs);
         }
         
         return validVerticaServerGroup;
    	
    }
    
    public boolean hasValidDMExpressServerGroup(DataSource ds,Schema schema) throws Exception{
    	 Connection cnn = null;
         PreparedStatement ps = null;
         ResultSet rs = null;
         boolean validDMExpressServerGroup = false;
         
         try {
             cnn = ds.getConnection();
             ps = cnn.prepareStatement(DMEXPRESS_SERVER_GROUP_CHECK_QRY);
             ps.setString(1, schema.getServerGroupId());
             ps.setString(2, schema.getServerName());
             ps.setInt(3, Integer.parseInt(schema.getPort()) );
             ps.setString(4, schema.getInstance());
             rs = ps.executeQuery();
             if (rs.next()) {
            	 validDMExpressServerGroup = true;
             }else {
                 logger.info("invalid dmexpress server: " + schema);
             }            
         } catch(Exception ex) {
             logger.info("Error..Verifying dmexpress server group: " + ex.getMessage());
             throw ex;
         }finally {
             DBUtil.release(cnn, ps, rs);
         }
         
         return validDMExpressServerGroup;
    }
    
    /*----------------------------------------------------------------------*/
    /* CHECKING PROCESSING ORACLE SERVER  */
    /*----------------------------------------------------------------------*/
    
    private static final String PROCESSING_ORACLE_SERVER_QRY=
    	"SELECT CATEGORY FROM SERVERGROUP WHERE SERVERGROUPID LIKE ?";
    public Boolean isProcessingOracleServer(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String processingServer="ProcessingServer";
        Boolean isProcessingServer = false;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(PROCESSING_ORACLE_SERVER_QRY);
            ps.setString(1, serverGroupId);
            rs = ps.executeQuery();
           	while(rs.next())
           	{
           	 if(rs.getString("CATEGORY").equalsIgnoreCase(processingServer))
	         	{
	         		isProcessingServer = true;
	         	}
           	}
            
        } catch(Exception ex) {
            logger.info("Error..IS Processing Oracle Server: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return isProcessingServer;
    }
    
    /*----------------------------------------------------------------------*/
    /* CLUSTER GROUP MGMT */
    /*----------------------------------------------------------------------*/
    private static final String CLUSTER_GROUPS_QRY = "select clustergroupid, GroupName, Category from clustergroup order by category desc";
    
    /**
     * @Description : List all cluster groups from table processing.clustergroup
     * @param ds
     * @return
     * @throws Exception
     */
    public List getClusterGroupList(DataSource ds) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CLUSTER_GROUPS_QRY);
            rs = ps.executeQuery();
            while (rs.next())
            {
                ClusterGroup cg = new ClusterGroup();
                ls.add(cg.setClusterGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(rs.getString(3)));
            }
        } catch (Exception ex)
        {
            logger.info("Error..CLUSTER GROUP LIST: " + ex.getMessage());
            throw ex;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    private static final String ADD_CLUSTER_GROUP = "insert into clustergroup(clustergroupid, GroupName,Category) " + "select ?, ?,? from dual "
                                                          + " where not exists (select 1 from clustergroup where GroupName = ? )";
    
    /**
     * @Description: Add a cluster group in table processing.clustergroup
     * @param ds
     * @param _groupName
     * @param _clusterType
     * @return: No of clusters added
     * @throws Exception
     */
    public int addClusterGroup(DataSource ds, String _groupName, String _clusterType) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        String groupName = _groupName.trim();
        String clusterType = _clusterType.trim();
        String clusterGroupId = groupName.replaceAll("\\W", "_") + DBUtil.generateSuffixForId();
        
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(ADD_CLUSTER_GROUP);
            ps.setString(1, clusterGroupId.toUpperCase());
            ps.setString(2, groupName.toUpperCase());
            ps.setString(3, clusterType.toUpperCase());
            ps.setString(4, groupName);
            count = ps.executeUpdate();
        } catch (Exception ex)
        {
            logger.info("Error..ADD CLUSTER GROUP: " + ex.getMessage());
            throw ex;
        } finally
        {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    
    private static final String DELETE_CLUSTER_GROUP = "delete clusterGroup where upper(clusterGroupId) = ?";
    
    /**
     * @Description: Deletes a cluster group from table processing.clustergroup
     * @param ds
     * @param clusterGroupId
     * @return : Returns number of clusters deleted
     * @throws Exception
     */
    public int deleteClusterGroup(DataSource ds, String clusterGroupId) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_CLUSTER_GROUP);
            ps.setString(1, clusterGroupId);
            count = ps.executeUpdate();
        } catch (Exception ex)
        {
            logger.info("Error..DELETE CLUSTER GROUP: " + ex.getMessage());
            throw ex;
        } finally
        {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    
    private static final String SERVER_GROUP_BY_CLUSTER_QRY =   "SELECT a.servergroupid,a.groupname,a.category FROM servergroup a "
                                                                + "join "
                                                                + "  clustergrp_servergrp_map b "
                                                                + "ON "
                                                                + "  a.servergroupid = b.server_grpid "
                                                                + "WHERE "
                                                                + "  b.cluster_grpid = ?"; ;
    
    /**
     * @Description: Lists all the Server Groups for a Cluster using tables
     *               processing.servergroup and
     *               processing.clustergrp_servergrp_map
     * @param ds
     * @param clusterGrpId
     * @return
     * @throws Exception
     */
    public List getServerGroupListByCluster(DataSource ds, String clusterGrpId) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVER_GROUP_BY_CLUSTER_QRY);
            ps.setString(1, clusterGrpId);
            rs = ps.executeQuery();
            while (rs.next())
            {
                ServerGroup sg = new ServerGroup();
                ls.add(sg.setServerGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(rs.getString(3)));
            }
        } catch (Exception ex)
        {
            logger.info("Error..SERVER GROUP LIST BY CLUSTER: " + ex.getMessage());
            throw ex;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    private static final String GET_AVAILABLE_SERVER_GRPS = "SELECT a.servergroupid, "
                                                            + "       a.groupname,a.category "
                                                            + "FROM   servergroup a "
                                                            + "WHERE  a.servergroupid NOT IN (SELECT b.server_grpid "
                                                            + "                               FROM   clustergrp_servergrp_map b) "
                                                            + "       AND Upper(a.category) = ?";
    
    /**
     * @Description: List all the server groups which are not in assigned to any
     *               clusters using tables processing.servergroup and
     *               clustergrp_servergrp_map
     * @throws Exception
     * 
     */
    public List getAvailableServerGps(DataSource ds, String category) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        if (category.equalsIgnoreCase("PROD_VERTICA_CLUSTER"))
        {
            category = "VERTICASERVER";
        } else
        {
            category = "VERTICADRSERVER";
        }
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_AVAILABLE_SERVER_GRPS);
            ps.setString(1, category);
            rs = ps.executeQuery();
            while (rs.next())
            {
                ServerGroup sg = new ServerGroup();
                ls.add(sg.setServerGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(rs.getString(3)));
            }
        } catch (Exception ex)
        {
            logger.info("Error..SERVER GROUP LIST BY CLUSTER: " + ex.getMessage());
            throw ex;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    private static final String DELETE_ALLSERVERGRP_FROM_CLUSTER = "DELETE FROM clustergrp_servergrp_map WHERE cluster_grpid = ?";
    
    /**
     * @Description : Assigns a server group to a cluster by 1. Deletes all the
     *              server group in a cluster 2. Adds server groups to a cluster
     *              Note: If 2 fails , the their is a rollback.
     * @param ds
     * @param clusterGrpId
     * @param serverGrps
     * @return Total number of server groups assigned to a cluster
     * @throws Exception
     */
    public int assignServerGrpToCluster(DataSource ds, String clusterGrpId, String[] serverGrps) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Statement s = null;
        int count[] = {};
        try
        {
            cnn = ds.getConnection();
            cnn.setAutoCommit(false);
            ps = cnn.prepareStatement(DELETE_ALLSERVERGRP_FROM_CLUSTER);
            ps.setString(1, clusterGrpId);
            rs = ps.executeQuery();
            s = cnn.createStatement();
            s = generateBatchQry_assignServerGrpToCluster(serverGrps, clusterGrpId, s);
            count = s.executeBatch();
            cnn.commit();
        } catch (Exception e)
        {
            if (cnn != null)
            {
                cnn.rollback();
            }
            throw e;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
            if (s != null)
            {
                s.close();
            }
        }
        return count.length;
    }
    
    /**
     * @Description: Returns a statement for batch insert [Adding server groups to a cluster group]
     * @param serverGrps
     * @param clusterGrpId
     * @param s
     * @return
     * @throws SQLException
     */
    public Statement generateBatchQry_assignServerGrpToCluster(String[] serverGrps, String clusterGrpId, Statement s) throws SQLException
    {
        String query = "";
        for (int i = 0; i < serverGrps.length; i++)
        {
            query = "INSERT INTO CLUSTERGRP_SERVERGRP_MAP (CLUSTER_GRPID,SERVER_GRPID) " + "VALUES ('" + clusterGrpId + "','" + serverGrps[i] + "')";
            s.addBatch(query);
        }
        return s;
    }
    
    private static final String DELETE_SERVERGRP_FROM_CLUSTER = "DELETE from CLUSTERGRP_SERVERGRP_MAP where cluster_grpid = ? and server_grpid=? ";
    /**
     * @Description: Deletes a server group from a cluster
     * @param ds
     * @param clusterGrpId
     * @param serverGrpId
     * @return
     * @throws Exception
     */
    public int deleteServerGrpFromCluster(DataSource ds,String clusterGrpId,String serverGrpId) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_SERVERGRP_FROM_CLUSTER);
            ps.setString(1, clusterGrpId);
            ps.setString(2, serverGrpId);
            count = ps.executeUpdate();
        } catch (Exception e)
        {
            logger.error("Could not delete server group "+serverGrpId+" from cluster " + clusterGrpId, e);
            throw e;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }
    
    /*----------------------------------------------------------------------*/
    /* SERVER GROUP MGMT */
    /*----------------------------------------------------------------------*/
    
    private static final String SERVER_GROUPS_QRY =
        "select ServerGroupId, GroupName, Category from ServerGroup order by 2";
    public List getServerGroupList(DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVER_GROUPS_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                ServerGroup sg = new ServerGroup();
                ls.add(  sg.setServerGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(rs.getString(3)) );
            }
        } catch(Exception ex) {
            logger.info("Error..SERVER GROUP LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    private static final String ORACLE_SERVER_GROUPS_QRY =
        "IN ('PROCESSINGSERVER','HISTORYSERVER','ORACLEDRSERVER') ORDER BY 3 DESC";
    
    
    private static final String VERTICA_SERVER_GROUPS_QRY =
    	"IN ('VERTICASERVER','VERTICADRSERVER') ORDER BY 3 DESC";
    
    private static final String DMEXPRESS_SERVER_GROUPS_QRY =
    	"LIKE 'DMEXPRESSSERVER' ORDER BY 2";
    
    public List getServerGroupList(DataSource ds,String hostingServer) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        String SERVER_GROUPS_QRY_HS =
            "SELECT SERVERGROUPID, GROUPNAME, CATEGORY FROM SERVERGROUP WHERE UPPER(CATEGORY)";
        //check hosting Server
        if(hostingServer.equalsIgnoreCase(Constants.ORACLE))
        {
        	SERVER_GROUPS_QRY_HS +=" "+ORACLE_SERVER_GROUPS_QRY;
        	
        }
        else if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
        {
        	SERVER_GROUPS_QRY_HS +=" "+VERTICA_SERVER_GROUPS_QRY;
        }
        else
        {
        	SERVER_GROUPS_QRY_HS +=" "+DMEXPRESS_SERVER_GROUPS_QRY;
        }
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVER_GROUPS_QRY_HS);
            rs = ps.executeQuery();
            while (rs.next()) {
                ServerGroup sg = new ServerGroup();
                ls.add(  sg.setServerGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(rs.getString(3)) );
            }
        } catch(Exception ex) {
            logger.info("Error..SERVER GROUP LIST FOR A HOSTING SERVER: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    /*Change the query if category for vertica rac server is changed*/
    private static String GET_VERTICA_RAC_SERVER_GROUPS 	=	"SELECT servergroupid,groupname,category " +
    															"FROM SERVERGROUP WHERE UPPER(CATEGORY) = 'VERTICASERVER'";
    /**
     * Description : Returns list of vertica rac server groups from processing.servergroup table
     * @param ds
     * @return
     * @throws Exception
     */
    public List getVerticaRACServerGroupList(DataSource ds) throws Exception 
    {
    	Connection cnn			=	null;
    	PreparedStatement ps 	=	null;
    	ResultSet rs			= 	null;
    	List ls 				=	new LinkedList();
    	
    	try
    	{
    		cnn					= 	ds.getConnection();
    		ps					=	cnn.prepareStatement(GET_VERTICA_RAC_SERVER_GROUPS);
    		rs					=	ps.executeQuery();
    		while(rs.next())
    		{
    			ServerGroup sg 	= new ServerGroup();
    			ls.add(sg.setServerGroupId(rs.getString("servergroupid"))
    					 .setGroupName(rs.getString("groupname"))
    					 .setCategory(rs.getString("category")));
    		}
    	}catch(Exception e)
    	{
    		logger.error("Error Getting Vertica RAC Server Group List. Query: "+GET_VERTICA_RAC_SERVER_GROUPS+" Error: "+e.getMessage());
    		throw e;
    		
    	}finally
    	{
    		DBUtil.release(cnn, ps, rs);
    	}
    	
    	return ls;
    }
    
    
    /*Change the query if category for vertica dr server is changed*/
    private static String GET_VERTICA_DR_SERVER_GROUPS 	=	"SELECT servergroupid,groupname,category " +
    														"FROM SERVERGROUP WHERE UPPER(CATEGORY) = 'VERTICADRSERVER'";
    /**
     * Description : Returns list of vertica dr server groups from processing.servergroup table
     * @param ds
     * @return
     * @throws Exception
     */
    public List getVerticaDRServerGroupList(DataSource ds) throws Exception 
    {
    	Connection cnn			=	null;
    	PreparedStatement ps 	=	null;
    	ResultSet rs			= 	null;
    	List ls 				=	new LinkedList();
    	
    	try
    	{
    		cnn					= 	ds.getConnection();
    		ps					=	cnn.prepareStatement(GET_VERTICA_DR_SERVER_GROUPS);
    		rs					=	ps.executeQuery();
    		while(rs.next())
    		{
    			ServerGroup sg 	= new ServerGroup();
    			ls.add(sg.setServerGroupId(rs.getString("servergroupid"))
    					 .setGroupName(rs.getString("groupname"))
    					 .setCategory(rs.getString("category")));
    		}
    	}catch(Exception e)
    	{
    		logger.error("Error Getting Vertica DR Server Group List. Query: "+GET_VERTICA_DR_SERVER_GROUPS+" Error: "+e.getMessage());
    		throw e;
    		
    	}finally
    	{
    		DBUtil.release(cnn, ps, rs);
    	}
    	
    	return ls;
    }
    
    /**
     * returns server groups for processing servers
     */
    /*private static final String SERVER_GROUPS_QRY_PROCESSING =
        "select ServerGroupId, GroupName, Category from ServerGroup where upper (Category) = 'PROCESSINGSERVER' order by 2";*/
    private static final String SERVER_GROUPS_QRY_PROCESSING =""
    		+ "SELECT servergroupid, "
    		+ "       groupname, "
    		+ "       CASE "
    		+ "         WHEN Regexp_like(groupname, '^[0-9]') THEN 1 "
    		+ "         ELSE 0 "
    		+ "       end AS ordering, "
    		+ "       category "
    		+ "FROM   servergroup "
    		+ "WHERE  Upper (category) = 'PROCESSINGSERVER' "
    		+ "ORDER  BY ordering, "
    		+ "          Upper(groupname) ";
            
    public List getServerGroupListForProcessing(DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVER_GROUPS_QRY_PROCESSING);
            rs = ps.executeQuery();
            while (rs.next()) {
                ServerGroup sg = new ServerGroup();
                ls.add(  sg.setServerGroupId(rs.getString("servergroupid")).setGroupName(rs.getString("groupname")).setCategory(rs.getString("category")) );
            }
        } catch(Exception ex) {
            logger.info("Error..SERVER GROUP LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    
    /**
     * returns server groups for oracle dr servers
     */
    /*private static final String SERVER_GROUPS_QRY_PROCESSING =
        "select ServerGroupId, GroupName, Category from ServerGroup where upper (Category) = 'PROCESSINGSERVER' order by 2";*/
    private static final String SERVER_GROUPS_QRY_ORACLE_DR =""
    		+ "SELECT servergroupid, "
    		+ "       groupname, "
    		+ "       CASE "
    		+ "         WHEN Regexp_like(groupname, '^[0-9]') THEN 1 "
    		+ "         ELSE 0 "
    		+ "       end AS ordering, "
    		+ "       category "
    		+ "FROM   servergroup "
    		+ "WHERE  Upper (category) = 'ORACLEDRSERVER' "
    		+ "ORDER  BY ordering, "
    		+ "          Upper(groupname) ";
            
    public List getServerGroupListForOracleDR(DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVER_GROUPS_QRY_ORACLE_DR);
            rs = ps.executeQuery();
            while (rs.next()) {
                ServerGroup sg = new ServerGroup();
                ls.add(  sg.setServerGroupId(rs.getString("servergroupid")).setGroupName(rs.getString("groupname")).setCategory(rs.getString("category")) );
            }
        } catch(Exception ex) {
            logger.info("Error..SERVER GROUP LIST ORACLE DR: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    /**
     * returns history server group list for history servers
     */
    
    private static final String HIST_SERVER_GROUPS_QRY_PROCESSING =
        "select ServerGroupId, GroupName, category from ServerGroup where upper (Category) = 'HISTORYSERVER' order by 2";
    public List getHistServerGroupListForProcessing(DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(HIST_SERVER_GROUPS_QRY_PROCESSING);
            rs = ps.executeQuery();
            while (rs.next()) {
                ServerGroup sg = new ServerGroup();
                ls.add(  sg.setServerGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(rs.getString(3)) );
            }
        } catch(Exception ex) {
            logger.info("Error..SERVER GROUP LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
	/**
	 * @Description: Lists server groups for the given category
	 * @param ds
	 * @param category
	 *            : comma separated server group category
	 *            ('PROCESSINGSERVER','HISTORYSERVER')
	 * @return
	 * @throws Exception
	 */
	public List<ServerGroup> getServerGrpsByCategory(
			DataSource ds,List<String> categoryList) throws Exception {
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<ServerGroup> ls = new ArrayList<>();
		StringBuffer s = new StringBuffer();
		if (!categoryList.isEmpty()) {
			for (int i = 0; i < categoryList.size(); i++) {
				s.append("?");
				if (!(i == (categoryList.size() - 1))) {
					s.append(",");
				}
			}
			//System.out.println("String buffer "+s);
			String LIST_SERVER_GRPS_QRY = "select ServerGroupId, GroupName, category from ServerGroup where upper (Category) IN ("
					+ s + ") order by 2";
			//System.out.println("Query is "+LIST_SERVER_GRPS_QRY);
			try {
				cnn = ds.getConnection();
				ps = cnn.prepareStatement(LIST_SERVER_GRPS_QRY);
				int i =  1;
				for(String category:categoryList){
					//System.out.println(i +" Category "+category);
					ps.setString(i, category);
					i++;
				}
				rs = ps.executeQuery();
				while (rs.next()) {
					ServerGroup sg = new ServerGroup();
					ls.add(sg.setServerGroupId(rs.getString(1))
							.setGroupName(rs.getString(2))
							.setCategory(rs.getString(3)));
				}
			} catch (Exception ex) {
				logger.error("ServerDB->listServerGrpByCategory(" + categoryList
						+ ")", ex);
				throw ex;
			} finally {
				DBUtil.release(cnn, ps, rs);
			}
		}

		return ls;
	}
	
    private static final String ADD_SERVER_GROUP =
        "insert into ServerGroup(ServerGroupId, GroupName,Category) " +
        "select ?, ?,? from dual " +
        " where not exists (select 1 from ServerGroup where GroupName = ? )";
    public int addServerGroup(DataSource ds, String _groupName, String _serverType,String hostingServer) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        String groupName = _groupName.trim();
        String serverType = _serverType.trim();
        String serverGroupId = groupName.replaceAll("\\W","_")  + DBUtil.generateSuffixForId();
        //check for vertica and dmexpress
        /*if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
        {
        	serverType ="VerticaServer";
        }*/
        
        if(hostingServer.equalsIgnoreCase(Constants.DMEXPRESS))
        {
        	serverType ="DMExpressServer";
        }
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(ADD_SERVER_GROUP);
            ps.setString(1, serverGroupId);
            ps.setString(2, groupName);
            ps.setString(3, serverType);
            ps.setString(4, groupName);
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..ADD SERVER GROUP: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }

    private static final String DELETE_SERVER_GROUP =
        "delete ServerGroup where ServerGroupId = ?";
    public int deleteServerGroup(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_SERVER_GROUP);
            ps.setString(1, serverGroupId);
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..DELETE SERVER GROUP: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }

    private static final String SERVER_GROUP_BY_ID =
        "select ServerGroupId, GroupName " + 
        "  from ServerGroup where ServerGroupId = ? ";
    public ServerGroup getServerGroup(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ServerGroup sg = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVER_GROUP_BY_ID);
            ps.setString(1, serverGroupId);
            rs  = ps.executeQuery();
            if (rs.next()) {
                sg = (new ServerGroup()).setServerGroupId(rs.getString(1))
                    .setGroupName(rs.getString(2));
            }
        } catch(Exception ex) {
            logger.info("Error..DELETE SERVER GROUP: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return sg;
    }

    private static final String GET_SERVER =""
    				+ "SELECT servergroupid, "
    				+ "       host, "
    				+ "       port, "
    				+ "       service, "
    				+ "       sidflag, "
    				+ "       tts_dir_dump_ora, "
    				+ "       tts_dir_dump_phys, "
    				+ "       utility_user, "
    				+ "       utility_pass, "
    				+ "       remote_link "
    				+ "FROM   servers "
    				+ "WHERE  Lower(host) = Lower(?) "
    				+ "       AND Lower(service) = Lower(?) "
    				+ "       AND port = ?";
            
	/**
	 * @Description : Returns server information from the given schema
	 * @param ds
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public Server getServer(DataSource ds, Schema schema) throws Exception {
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Server sv = null;
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(GET_SERVER);
			ps.setString(1, schema.getServerName());
			ps.setString(2, schema.getService());
			ps.setString(3, schema.getPort());
			rs = ps.executeQuery();
			if (rs.next()) {
				sv = (new Server()).setServerGroupId(rs.getString(1)).setHost(rs.getString(2)).setPort(rs.getInt(3))
						.setService(rs.getString(4)).setSidFlag(rs.getString(5)).setTTS_DIR_DUMP_ORA(rs.getString(6))
						.setTTS_DIR_DUMP_PHYS(rs.getString(7)).setUTILITY_USER(rs.getString(8))
						.setUTILITY_PASS(rs.getString(9)).setRemote_Link(rs.getString(10));
			}
		} catch (Exception ex) {
			logger.info("Error..Getting SERVER for schema : "+schema + ex.getMessage());
			throw ex;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return sv;
	}
    
    /**
     * returns history server group
     */
   
    
  /*  private static final String SERVERS_FOR_SERVER_GROUP =
        "select ServerGroupId, upper(Host) Host, Port, upper(Service) Service, upper(SIDFlag) SidFlag , remote_link , Connection ,Database, Instance ,DatabaseId" + 
        "  from Servers " +
        " where ServerGroupId = ? " +
        " order by 2 desc, 3, 4 ";*/
    
    
    
    private static final String SERVERS_FOR_SERVER_GROUP = ""
    		+ "SELECT a.servergroupid, "
    		+ "    		        Upper(a.host)    Host, "
    		+ "    		        CASE "
    		+ "    		          WHEN Regexp_like(a.host, '^[0-9]') THEN 1 "
    		+ "    		          ELSE 0 "
    		+ "    		        END            AS ordering, "
    		+ "    		        a.port, "
    		+ "    		        Upper(a.service) Service, "
    		+ "    		        Upper(a.sidflag) SidFlag, "
    		+ "    		        a.remote_link, "
    		+ "    		        a.connection, "
    		+ "    		        a.DATABASE, "
    		+ "    		        a.INSTANCE, "
    		+ "    		        a.databaseid, "
    		+ "                b.vipflag "
    		+ "    		 FROM   servers a "
    		+ "         left join platform_database_info b "
    		+ "         ON a.databaseid = b.dbid "
    		+ "    		 WHERE  servergroupid =? "
    		+ "    		 ORDER  BY ordering, "
    		+ "    		           a.host";

    public List getServersForServerGroup(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVERS_FOR_SERVER_GROUP);
            ps.setString(1, serverGroupId);
            rs = ps.executeQuery();
            while (rs.next()) {
                ls.add(  (new Server()).setServerGroupId(rs.getString("servergroupid"))
                         .setHost(rs.getString("Host"))
                         .setPort(rs.getInt("port"))
                         .setService(rs.getString("Service"))
                         .setSidFlag( rs.getString("SidFlag"))
                         .setRemote_Link(rs.getString("remote_link"))
                         .setConnection(rs.getString("connection"))
                         .setDatabase(rs.getString("DATABASE"))
                         .setInstance(rs.getString("INSTANCE"))
                         .setIsVip(rs.getString("VIPFLAG"))
                         .setDatabaseId(rs.getString("databaseid")));
            }
        } catch(Exception ex) {
            logger.info("Error..SERVERS LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    
    public static final String GET_VIP_SERVERS =  "SELECT a.servergroupid, "
            + "       Upper(a.host)    Host, "
            + "       CASE "
            + "         WHEN Regexp_like(a.host, '^[0-9]') THEN 1 "
            + "         ELSE 0 "
            + "       END              AS ordering, "
            + "       a.port, "
            + "       Upper(a.service) Service, "
            + "       Upper(a.sidflag) SidFlag, "
            + "       a.remote_link, "
            + "       a.connection, "
            + "       a.DATABASE, "
            + "       a.INSTANCE, "
            + "       a.databaseid "
            + "FROM   servers a "
            + "       join platform_database_info b "
            + "         ON a.databaseid = b.dbid "
            + "WHERE  a.servergroupid = ? "
            + "       AND b.vipflag = 'Y' "
            + "ORDER  BY ordering, "
            + "          a.host";
    /**
     * @Description: List the vip servers for a server group
     * @param ds
     * @param serverGrpId
     * @return
     * @throws Exception
     */
    public List getVIPServersForServerGrp(DataSource ds,String serverGrpId) throws Exception
    {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_VIP_SERVERS);
            ps.setString(1, serverGrpId);
            rs = ps.executeQuery();
            while (rs.next()) {
                ls.add(  (new Server()).setServerGroupId(rs.getString("servergroupid"))
                         .setHost(rs.getString("Host"))
                         .setPort(rs.getInt("port"))
                         .setService(rs.getString("Service"))
                         .setSidFlag( rs.getString("SidFlag"))
                         .setRemote_Link(rs.getString("remote_link"))
                         .setConnection(rs.getString("connection"))
                         .setDatabase(rs.getString("DATABASE"))
                         .setInstance(rs.getString("INSTANCE"))
                         .setDatabaseId(rs.getString("databaseid")));
            }
        } catch(Exception ex) {
            logger.info("Error..SERVERS LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    

    private static final String SERVERS_FOR_HIST_SERVER_GROUP =
        "select ServerGroupId, upper(Host) Host, Port, upper(Service) Service, upper(SIDFlag) SidFlag , databaseid" + 
        "  from Servers " +
        " where ServerGroupId = ? " +
        " order by 2, 3, 4 ";
    public List getServersForHistServerGroup(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(SERVERS_FOR_HIST_SERVER_GROUP);
            ps.setString(1, serverGroupId);
            rs = ps.executeQuery();
            while (rs.next()) {
                ls.add((new Server()).setServerGroupId(rs.getString(1))
                         .setHost(rs.getString(2))
                         .setPort(rs.getInt(3))
                         .setService(rs.getString(4))
                         .setSidFlag( rs.getString(5))
                         .setDatabaseId(rs.getString(6)));
            }
        } catch(Exception ex) {
            logger.info("Error..SERVERS LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }
    
    /*----------------------------------------------------------------------*/
    /* SERVERS MGMT */
    /*----------------------------------------------------------------------*/
    private static final String ADD_ORACLE_SERVER_QRY =
    	 "insert into Servers(ServerGroupId, Host, Port, Service, SIDFlag, remote_link,connection,databaseid) " +
         "select trim(?), upper(trim(?)), trim(?) , upper(trim(?)), upper(trim(?)) , trim(?) , trim(?) , trim(?) from dual where not exists " +
         "   (select 1 from Servers where upper(Host) = upper(?) and Port = ? and  " +
         "    upper(Service) = upper(?))";
    
    private static final String ADD_VERTICA_SERVER_QRY =
    	 "insert into Servers(ServerGroupId, Host, Port, Service, Connection, Database , DatabaseId) " +
         "select trim(?), upper(trim(?)), trim(?) , upper(trim(?)), upper(trim(?)) , trim(?) , trim(?)  from dual where not exists " +
         "   (select 1 from Servers where upper(Host) = upper(?) and Port = ? and  " +
         "    upper(Service) = upper(?))";
    
    private static final String ADD_DMEXPRESS_SERVER_QRY =
   	 "insert into Servers(ServerGroupId, Host, Port, Service,Instance) " +
        "select ?, upper(?), ? , upper(?), upper(?) from dual where not exists " +
        "   (select 1 from Servers where upper(Host) = upper(?) and Port = ? and  " +
        "    upper(Service) = upper(?) )";
    
	/**
	 * @Description: Adds server
	 * @param ds
	 * @param server
	 * @return
	 * @throws SQLException
	 */
	public int addServer(DataSource ds, Server server) throws SQLException {
		Connection cnn = null;
		String hostingServer = server.getHostingServer();
		//int platformDatabaseInfoCount = 0;
		Object[] obj = null;
		int count = 0;
		// check hosting server
		if (hostingServer != "") {
			// try inserting in platform_database_info
			try {
				cnn = ds.getConnection();
				cnn.setAutoCommit(false);
				obj = insertIntoPlatformDatabaseInfo(cnn,
						server);
				if ((int)obj[1] > 0) {
					// for ORACLE
					if (hostingServer.equalsIgnoreCase(Constants.ORACLE)) {
						server.setDatabaseId((String)obj[0]);
						count = addORACLEServer(cnn, server);
					}
					// for VERTICA
					else if (hostingServer.equalsIgnoreCase(Constants.VERTICA)) {
						server.setDatabaseId((String)obj[0]);
						count = addVERTICAServer(cnn, server);
					}

					// for DMEXPRESS
					else if (hostingServer
							.equalsIgnoreCase(Constants.DMEXPRESS)) {
						server.setDatabaseId((String)obj[0]);
						count = addDMEXPRESSServer(cnn, server);
					}

					// commit/rollback changes
					if (count > 0) {
						cnn.commit();
					} else {
						cnn.rollback();
					}

				} else {
					throw new SQLException(
							"Server already found in platform_database_info!!!!");
				}
			} catch (SQLException ex) {
				if (cnn != null) {
					cnn.rollback();
				}
				throw ex;
			} finally {
				// closing the connection
				if (cnn != null) {
					cnn.close();
				}
			}
		}
		return count;
	}

	/**
	 * @Description:Method to add an oracle server
	 * @param cnn
	 * @param server
	 * @return
	 * @throws SQLException
	 */
	public int addORACLEServer(Connection cnn, Server server)
			throws SQLException {
		PreparedStatement ps = null;
		int count = 0;
		try {
			ps = cnn.prepareStatement(ADD_ORACLE_SERVER_QRY);
			ps.setString(1, server.getServerGroupId());
			ps.setString(2, server.getHost());
			ps.setInt(3, server.getPort());
			ps.setString(4, server.getService());
			ps.setString(5, server.getSidFlag());
			ps.setString(6, server.getRemote_Link());
			ps.setString(7, server.getConnection());
			ps.setString(8, server.getDatabaseId());
			ps.setString(9, server.getHost());
			ps.setInt(10, server.getPort());
			ps.setString(11, server.getService());
			count = ps.executeUpdate();
		} catch (SQLException ex) {
			logger.info("Error..ADDING ORACLE SERVER: " + ex.getMessage());
			throw ex;
		} finally {
			// Connection is not closed here
			if (ps != null) {
				ps.close();
			}
		}
		return count;
	}

	/**
	 * @Decription: Method to add a vertica server
	 * @param cnn
	 * @param server
	 * @return
	 * @throws SQLException
	 */
	public int addVERTICAServer(Connection cnn, Server server)
			throws SQLException {
		PreparedStatement ps = null;
		int count = 0;
		try {
			ps = cnn.prepareStatement(ADD_VERTICA_SERVER_QRY);
			ps.setString(1, server.getServerGroupId());
			ps.setString(2, server.getHost());
			ps.setInt(3, server.getPort());
			ps.setString(4, server.getService());
			ps.setString(5, server.getConnection());
			ps.setString(6, server.getDatabase());
			ps.setString(7, server.getDatabaseId());
			ps.setString(8, server.getHost());
			ps.setInt(9, server.getPort());
			ps.setString(10, server.getService());
			count = ps.executeUpdate();
		} catch (SQLException ex) {
			logger.info("Error..ADDING VERTICA SERVER: " + ex.getMessage());
			throw ex;
		} finally {
			// Connection is not closed here
			if (ps != null) {
				ps.close();
			}
		}
		return count;
	}

	public int addDMEXPRESSServer(Connection cnn, Server server)
			throws SQLException {
		PreparedStatement ps = null;
		int count = 0;
		try {
			ps = cnn.prepareStatement(ADD_DMEXPRESS_SERVER_QRY);
			ps.setString(1, server.getServerGroupId());
			ps.setString(2, server.getHost());
			ps.setInt(3, server.getPort());
			ps.setString(4, server.getService());
			ps.setString(5, server.getInstance());
			ps.setString(6, server.getHost());
			ps.setInt(7, server.getPort());
			ps.setString(8, server.getService());
			count = ps.executeUpdate();
		} catch (SQLException ex) {
			logger.info("Error..ADDING DMEXPRESS SERVER: " + ex.getMessage());
			throw ex;
		} finally {
			// Connection is not closed here
			if (ps != null) {
				ps.close();
			}
		}
		return count;
	}
	
	
    private static final String GET_NEW_DBID = "select GET_NEW_DBID() from dual ";

	/**
	 * @Description: Returns next databaseid which in not in processing.platform_database_info
	 * @param ds
	 * @return
	 * @throws SQLException
	 */
	public String getNewDatabaseId(Connection cnn) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String dbid = "";
		try {
			ps = cnn.prepareStatement(GET_NEW_DBID);
			rs = ps.executeQuery();
			while (rs.next()) {
				dbid = String.valueOf(rs.getInt(1));
			}
		} catch (SQLException e) {
			throw e;
		} finally {
			DBUtil.release(null, ps, rs);
		}
		return dbid;
	}
	
	private static final String INSERT_INTO_PLATFORM_DATABASE_INFO = ""
			+ "INSERT INTO platform_database_info(dbid,databasetype,dbservername, "
			+ "service_name,port,vipflag) "
			+ "SELECT Trim(?),Upper(Trim(?)),Upper(Trim(?)),Upper(Trim(?)),Trim(?), "
			+ "Upper(Trim(?)) FROM dual WHERE NOT EXISTS "
			+ "(SELECT 1 FROM platform_database_info " + "WHERE dbid =Trim(?) "
			+ "AND Upper(DBSERVERNAME)= Upper(Trim(?)) "
			+ "AND Upper(SERVICE_NAME)= Upper(Trim(?)) " + "AND PORT=Trim(?))";
	/**
	 * @Description: Inserts server details in processing.platform_database_info
	 *               table
	 * @param cnn
	 * @param server
	 * @return
	 * @throws SQLException
	 */
	private Object[] insertIntoPlatformDatabaseInfo(Connection cnn, Server server) throws SQLException {
		Object[] obj = new Object[2];
		PreparedStatement ps = null;
		String serviceName = server.getService();// for ORACLE
		if (server.getHostingServer().equalsIgnoreCase(Constants.VERTICA)) {
			serviceName = server.getDatabase();
		}
		try {
			obj[0] = getNewDatabaseId(cnn);
			ps = cnn.prepareStatement(INSERT_INTO_PLATFORM_DATABASE_INFO);
			ps.setString(1, (String)obj[0]);
			ps.setString(2, server.getHostingServer());
			ps.setString(3, server.getHost());
			ps.setString(4, serviceName);
			ps.setInt(5, server.getPort());
			ps.setString(6, server.getIsVip());
			ps.setString(7, server.getDatabaseId());
			ps.setString(8, server.getHost());
			ps.setString(9, serviceName);
			ps.setInt(10, server.getPort());
			obj[1] = ps.executeUpdate();
		} catch (SQLException ex) {
			throw ex;
		} 
		return obj;
	}
    
    private static final String EDIT_REMOTE_LINK_OF_SERVER_QRY =""
    	+ "UPDATE servers "
    	+ "SET remote_link = ? "
    	+ "WHERE  servergroupid = ? "
    	+ "AND host = ? "
    	+ "AND port = ? "
    	+ "AND service = ? ";
    
    public int editRemoteLinkofServer(DataSource ds, Server server) throws Exception {
    	Connection cnn = null;
    	PreparedStatement ps = null;
    	int count = 0;
    	try
    	{
    		cnn = ds.getConnection();
    		ps = cnn.prepareStatement(EDIT_REMOTE_LINK_OF_SERVER_QRY);
    		
    		ps.setString(1, server.getRemote_Link());
            ps.setString(2, server.getServerGroupId());
            ps.setString(3, server.getHost());
            ps.setInt(4, server.getPort());
            ps.setString(5, server.getService());
                        
            count = ps.executeUpdate();
            
            System.out.println("SUCCESS");
            
    	}catch (Exception e) {
			logger.info("Error while editing remote link of a server:"+e.getMessage());
			throw e;
		}finally {
			DBUtil.release(cnn, ps, null);
		}
		return count;
		
    }
    private static final String DELETE_ORACLE_SERVER_QRY =
        "delete Servers where ServerGroupId = ? and " +
        " upper(Host) = ? and Port = ? and upper(Service) = ?";
    
    private static final String DELETE_HISTORY_ORACLE_SERVER_QRY =
        "delete Servers where ServerGroupId = ? and " +
        " upper(Host) = ? and Port = ? and upper(Service) = ?";
    
    private static final String DELETE_VERTICA_SERVER_QRY =
        "delete Servers where ServerGroupId = ? and " +
        " upper(Host) = ? and Port = ? and upper(Service) = ? and Connection = ? and Database = ? ";
    
    private static final String DELETE_DMEXPRESS_SERVER_QRY =
        "delete Servers where ServerGroupId = ? and " +
        " upper(Host) = ? and Port = ? and upper(Service) = ? and Instance = ? ";
    
    public int deleteServer(DataSource ds, Server server) throws Exception {
    	String hostingServer = server.getHostingServer();
    	int count =0;
    	
    	//check hosting server
    	if(hostingServer != "")
    	{
    		//for ORACLE
    		if(hostingServer.equalsIgnoreCase(Constants.ORACLE))
    		{
    			count = deleteORACLEServer(ds, server);
    		}
    		//for VERTICA
    		else if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
    		{
    			count = deleteVERTICAServer(ds, server);
    		}
    		
    		//for DMEXPRESS
    		else if(hostingServer.equalsIgnoreCase(Constants.DMEXPRESS))
    		{
    			count = deleteDMEXPRESSServer(ds, server);
    		}
    	}
    	return count;
    }
    
    public int deleteORACLEServer(DataSource ds,Server server) throws Exception
    {
    	Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        String query = DELETE_HISTORY_ORACLE_SERVER_QRY;
        if(server.isProcessingOracleServer())
        {
        	query = DELETE_ORACLE_SERVER_QRY;////for processing oracle server (with connection field)
        }
        try {
            cnn = ds.getConnection();
            deleteFromPlatformDataBaseInfo(cnn,server);
            ps = cnn.prepareStatement(query);
            ps.setString(1, server.getServerGroupId());
            ps.setString(2, server.getHost());
            ps.setInt(3, server.getPort());
            ps.setString(4, server.getService());
            /*if(server.isProcessingOracleServer())
            {
            	ps.setString(5, server.getConnection());
            }*/
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..DELETE ORACLE SERVER: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
      
    
    public int deleteVERTICAServer(DataSource ds,Server server) throws Exception
    {
    	Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            deleteFromPlatformDataBaseInfo(cnn,server);
            ps = cnn.prepareStatement(DELETE_VERTICA_SERVER_QRY);
            ps.setString(1, server.getServerGroupId());
            ps.setString(2, server.getHost());
            ps.setInt(3, server.getPort());
            ps.setString(4, server.getService());
            ps.setString(5, server.getConnection());
            ps.setString(6, server.getDatabase());
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..DELETE VERTICA SERVER: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    

    public int deleteDMEXPRESSServer(DataSource ds,Server server) throws Exception
    {
    	Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            deleteFromPlatformDataBaseInfo(cnn,server);
            ps = cnn.prepareStatement(DELETE_DMEXPRESS_SERVER_QRY);
            ps.setString(1, server.getServerGroupId());
            ps.setString(2, server.getHost());
            ps.setInt(3, server.getPort());
            ps.setString(4, server.getService());
            ps.setString(5, server.getInstance());
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..DELETE DMEXPRESS SERVER: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    
	private static final String DELETE_FROM_PLATFORM_DATABASE_INFO = ""
			+ "DELETE platform_database_info WHERE " + "dbid = Trim(?) "
			+ "AND Upper(databasetype)=Upper(Trim(?)) "
			+ "AND Upper(dbservername)=Upper(Trim(?)) "
			+ "AND Upper(service_name)=Upper(Trim(?)) "
			+ "AND port=Trim(?)";
    public int deleteFromPlatformDataBaseInfo(Connection cnn,Server server) throws SQLException{
    	int count = 0;
    	PreparedStatement ps = null;
    	String serviceName = server.getService();//for oracle
    	if(server.getHostingServer().equalsIgnoreCase(Constants.VERTICA)){
    		serviceName = server.getDatabase();
    	}
    	try{
    		ps = cnn.prepareStatement(DELETE_FROM_PLATFORM_DATABASE_INFO);
    		ps.setString(1, server.getDatabaseId());
    		ps.setString(2, server.getHostingServer());
    		ps.setString(3,server.getHost());
    		ps.setString(4, serviceName);
    		ps.setInt(5, server.getPort());
    		count = ps.executeUpdate();
    	}catch(SQLException ex){
    		throw ex;
    	}finally{
    		if(ps!=null){
    			ps.close();
    		}
    	}
    	return count;
    }


    /*----------------------------------------------------------------------*/
    /* DATA FILES MGMT */
    /*----------------------------------------------------------------------*/

    private static final String ADD_DATA_FILE_DIR = 
        "insert into DataFileDirs(ServerGroupId, DataFileDir,DataFileDirName) " +
        "select ?, ?,? from dual where not exists " +
        "   (select 1 from DataFileDirs where ServerGroupId = ? and DataFileDir = ? and DataFileDirName=? )";
    public int addDataFileDir(DataSource ds, DataFileDir dataFileDir) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(ADD_DATA_FILE_DIR);
            ps.setString(1, dataFileDir.getServerGroupId());
            ps.setString(2, dataFileDir.getDataFileDir());
            ps.setString(3, dataFileDir.getDataFileDirName());
            ps.setString(4, dataFileDir.getServerGroupId());
            ps.setString(5, dataFileDir.getDataFileDir());
            ps.setString(6, dataFileDir.getDataFileDirName());
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..ADD DATA FILE: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    private static final String DELETE_DATA_FILE_DIR =
        "delete DataFileDirs where ServerGroupId = ? and DataFileDir = ? and DataFileDirName=? ";
    public int deleteDataFileDir(DataSource ds, DataFileDir dataFileDir) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_DATA_FILE_DIR);
            ps.setString(1, dataFileDir.getServerGroupId());
            ps.setString(2, dataFileDir.getDataFileDir());
            ps.setString(3, dataFileDir.getDataFileDirName());
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..DELETE DATA FILE: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }


    public List listAllGroupNServers(DataSource ds,boolean showDmexpress) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        String ALL_GROUP_N_SERVERS =
                "select a.ServerGroupId, GroupName, Host, Port, Service,a.Category " +
                " from ServerGroup a left join Servers b on a.ServerGroupId = b.ServerGroupId ";
        try {
            cnn = ds.getConnection();
            if(!showDmexpress){
            	ALL_GROUP_N_SERVERS +=" where a.category not like '%DMExpressServer%'";
            }
            
            ALL_GROUP_N_SERVERS += " order by 2";
            //System.out.println("QUERY >>>>>>>>>>>>>>>>"+ALL_GROUP_N_SERVERS);
            ps = cnn.prepareStatement(ALL_GROUP_N_SERVERS);
            rs = ps.executeQuery();
            while (rs.next()) {
                //check for hosting server
            	String category= rs.getString(6);
            	if(category.equalsIgnoreCase("ProcessingServer")
            	   ||category.equalsIgnoreCase("HistoryServer")
            	   ||category.equalsIgnoreCase("OracleDRServer"))
            	{
            		category = "ORACLE";
            	}
            	else if(category.equalsIgnoreCase("VerticaServer")
            	        ||category.equalsIgnoreCase("VerticaDRServer"))
            	{
            		category ="VERTICA";
            	}
            	else
            	{
            		category ="DMEXPRESS";
            	}
            	
            	ServerGroup sg = (new ServerGroup()).setServerGroupId(rs.getString(1)).setGroupName(rs.getString(2)).setCategory(category);
                Server server  = (new Server()).setServerGroupId( sg.getServerGroupId())
                    .setHost(rs.getString(3)).setPort(rs.getInt(4)).setService(rs.getString(5));
                ls.add(  new Object [] { sg, server } );
            }
        } catch(Exception ex) {
            logger.info("Error..SERVER GROUP LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    private static final String LIST_DATA_FILE_DIRS_FOR_SERVER_GROUP =
        "select ServerGroupId, DataFileDir,DataFileDirName from DataFileDirs where serverGroupid = ? order by 2";
    public List getDataFileDirsForServerGroup(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(LIST_DATA_FILE_DIRS_FOR_SERVER_GROUP);
            ps.setString(1, serverGroupId);
            rs = ps.executeQuery();
            while (rs.next()) {
                ls.add(  (new DataFileDir()).setServerGroupId(rs.getString(1))
                         .setDataFileDir(rs.getString(2))
                         .setDataFileDirName(rs.getString(3)));
            }
        } catch(Exception ex) {
            logger.info("Error..DATA FILE DIR LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }


    /*----------------------------------------------------------------------*/
    /* TEMP  TABLESPACE MGMT. */
    /*----------------------------------------------------------------------*/

    private static final String ADD_TEMP_TABLESPACE = 
        "insert into TempTablespaces(ServerGroupId, TempTablespace) " +
        "select ?, ? from dual where not exists " +
        "   (select 1 from TempTablespaces where ServerGroupId = ? and TempTablespace = ?  )";
    public int addTempTablespace(DataSource ds, TempTablespace tempTablespace) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(ADD_TEMP_TABLESPACE);
            ps.setString(1, tempTablespace.getServerGroupId());
            ps.setString(2, tempTablespace.getTempTablespace());
            ps.setString(3, tempTablespace.getServerGroupId());
            ps.setString(4, tempTablespace.getTempTablespace());
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..ADD TEMP TABLESPACE: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    private static final String DELETE_TEMP_TABLESPACE =
        "delete TempTablespaces where ServerGroupId = ? and TempTablespace = ? ";
    public int deleteTempTablespace(DataSource ds, TempTablespace tempTablespace) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_TEMP_TABLESPACE);
            ps.setString(1, tempTablespace.getServerGroupId());
            ps.setString(2, tempTablespace.getTempTablespace());
            count = ps.executeUpdate();
        } catch(Exception ex) {
            logger.info("Error..DELETE TEMP TABLESPACE: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, null);
        }
        return count;
    }
    private static final String LIST_TEMP_TABLESPACES_FOR_SERVER_GROUP =
        "select ServerGroupId, TempTablespace from TempTablespaces where serverGroupid = ? order by 2";
    public List getTempTablespacesForServerGroup(DataSource ds, String serverGroupId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(LIST_TEMP_TABLESPACES_FOR_SERVER_GROUP);
            ps.setString(1, serverGroupId);
            rs = ps.executeQuery();
            while (rs.next()) {
                ls.add(  (new TempTablespace()).setServerGroupId(rs.getString(1))
                         .setTempTablespace(rs.getString(2)));
            }
        } catch(Exception ex) {
            logger.info("Error..TEMP TABLESPACE LIST: " + ex.getMessage());
            throw ex;
        }finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }    
    
    private static final String LIST_ENGINE_VERSION_AVAILABLE =
    	"select distinct EngineVersion from VERSIONBYCLIENT";  
    public List getEngineVersionList(DataSource ds) throws Exception{
		List ls = new LinkedList();	
		//KeyValue obj = new KeyValue();
		Connection cnn = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    try {
	        cnn = ds.getConnection();
	        ps = cnn.prepareStatement(LIST_ENGINE_VERSION_AVAILABLE);
	        rs = ps.executeQuery();
	        while (rs.next()) {
	    		ls.add(new KeyValue().setKey(rs.getString(1)).setValue(rs.getString(1)));
	        }
	    } catch(Exception ex) {
	        logger.info("Error..ENGINE VERSION LIST: " + ex.getMessage());
	        throw ex;
	    }finally {
	        DBUtil.release(cnn, ps, rs);
	    }   
	
        return ls;
    }

    private static final String ENGINE_VERSION_FOR_CLIENT = " select engineversion from VERSIONBYCLIENT where clientid = ?";
    public String getEngineVersionForSchema(DataSource dataSource, String schemaName) throws Exception {
        String engineVersion = "";
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String clientid = "";
        schemaName = schemaName.toUpperCase().trim();

        if( schemaName.indexOf("HF0") == 0 ){ //HF schema
            clientid = schemaName.substring(3,6);
        } else if (schemaName.indexOf("S0") == 0){//S schema
            clientid = schemaName.substring(2,5);
        }

        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(ENGINE_VERSION_FOR_CLIENT);
            ps.setString(1, clientid);
            rs = ps.executeQuery();
            if(rs.next()){
                engineVersion = rs.getString("engineVersion");
            }
        } catch (Exception e){
            logger.info("Error.. ENGINE VERSION for Schema"+ e);
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return engineVersion;
    }
    
    
    private static final String CLIENT_NAME =    	
        "select clientname from Hawkeyemaster5.M_Clients " +
        "where clientID = CASE WHEN substr(?, 1,2) = 'S0' THEN substr(?, 3,3) ELSE substr(?, 4,3) END";  
    
    public String getClientName(DataSource ds, String schemaName) throws Exception{
		String str = "";	
		Connection cnn = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;	
	    
	    try {
	        cnn = ds.getConnection();
	        ps = cnn.prepareStatement(CLIENT_NAME);
	        ps.setString(1, schemaName);
	        ps.setString(2, schemaName);
	        ps.setString(3, schemaName);
	        rs = ps.executeQuery();	        
	        while (rs.next()) {
	        	str = rs.getString(1);
	        }	        
	    } catch(Exception ex) {
	        logger.info("Error..CLIENT NAME: " + ex.getMessage());
	        throw ex;
	    }finally {
	        DBUtil.release(cnn, ps, rs);
	    }  
        return str;
    } 
    
    private static final String EDB_PARAMETERS =    	
        "select paramval from EDB_PARAMS where Upper(paramname) = Upper(?)"; 
    
    public String getEdbParameters(DataSource ds, String paramname) throws Exception{
	    String paramval="";
	    
	    Connection cnn = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;	
	    
	    try {
	    	
	        cnn = ds.getConnection();
	        ps = cnn.prepareStatement(EDB_PARAMETERS);
	        ps.setString(1, paramname);	        
	        rs = ps.executeQuery();
	        while (rs.next()) {
	        	paramval = rs.getString(1);
	        }
	        
	    } catch(Exception ex) {	        
	    	throw ex;
	    }finally {
	        DBUtil.release(cnn, ps, rs);
	    }   
	    	    
	    return paramval;	    	
    }
    
    private static final String GET_EXECNO = "SELECT SEQ_VERTICA_EXECUTIONNO.NEXTVAL FROM DUAL";
    public long getExecutionNumber(DataSource ds) throws Exception{
    	long executionNumber = 0;
    	Connection cnn = null;
 	    PreparedStatement ps = null;
 	    ResultSet rs = null;	
 	    
 	    try {
 	    	
 	        cnn = ds.getConnection();
 	        ps = cnn.prepareStatement(GET_EXECNO);
 	        	        
 	        rs = ps.executeQuery();
 	        while (rs.next()) {
 	        	executionNumber = rs.getLong(1);
 	        }
 	        
 	    } catch(Exception ex) {	        
 	    	System.out.println("Error getting execution number: "+ex);
 	    	throw ex;
 	    }finally {
 	        DBUtil.release(cnn, ps, rs);
 	    }   
    	return executionNumber;
    }
    
    private static final String GET_REMOTE_LINK =""
    		+ "SELECT REMOTE_LINK FROM servers WHERE Upper(HOST) = Upper(?) and Upper(service)=Upper(?) and Upper(port)=Upper(?)";

	/**
	 * @Description: Returns Dblink for the given server from processing.servers
	 *               table
	 * @param schema
	 * @param ds
	 * @return
	 * @throws SQLException
	 * @throws CustomException
	 */
	public String getDBLink(Schema schema, DataSource ds) throws SQLException,
			CustomException {
		Connection cnn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String dbLink = "";
		try {
			cnn = ds.getConnection();
			ps = cnn.prepareStatement(GET_REMOTE_LINK);
			ps.setString(1, schema.getServerName());
			ps.setString(2, schema.getService());
			ps.setString(3, schema.getPort());
			rs = ps.executeQuery();
			while (rs.next()) {
				dbLink = (rs.getString(1) == null) ? "" : rs.getString(1);
			}
			CustomException.assertEmptyString(dbLink,
					"Database link for source server " + schema);
		} catch (SQLException ex) {
			logger.error("Error on ServerDB->getDBLink("+schema+")",ex);
			throw ex;
		} finally {
			DBUtil.release(cnn, ps, rs);
		}
		return dbLink;
	}

}