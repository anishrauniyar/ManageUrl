package dashboard.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import dashboard.ComponentFactory;
import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.data.ServerGroup;
import dashboard.data.VerticaDataTransfer;
import dashboard.engine.oracle.NamingUtil;
import dashboard.util.CmdRunner;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;
import dashboard.web.util.CustomException;

public class VerticaDB {

    protected Log logger = LogFactory.getLog(getClass());

    public static void main1(String args[]) {

        // printing queries for oracle to vertica data transfer using cma
        System.out.println("Getting Error details query: " + ERROR_DETAILS);
        System.out.println("Getting Event details query: " + EVENT_DETAILS);
        System.out.println("Transfer Summary query: " + TRANSFER_SUMMARY);
        System.out.println("Transfer detais query :" + TRANSFER_DETAILS);
        System.out.println("Getting total table count from source schema :" + COUNT_TOTAL_TABLE_FROM_SOURCE_QRY);
        System.out.println("Checking for is execute dmx task" + IS_EXECUTE_DMX_TASK);
        System.out.println("Counting success/error table count :" + COUNT_QRY);

        System.out.println("Getting Error details query: " + ERROR_DETAILS_CMA);
        System.out.println("Getting Event details query: " + EVENT_DETAILS);
        System.out.println("Transfer Summary query: " + TRANSFER_SUMMARY_CMA);
        System.out.println("Transfer detais query :" + TRANSFER_DETAILS_CMA);
        System.out.println("Getting total table count from source schema :" + COUNT_TOTAL_TABLE_FROM_SOURCE_QRY);
        // System.out.println("Checking for is execute dmx task"+IS_EXECUTE_DMX_TASK);
        System.out.println("Checking for is is copy data from oracle to vertica " + IS_COPY_DATA_FROM_ORACLE_TO_VERTICA);
        System.out.println("Counting success/error table count :" + COUNT_QRY_CMA);
    }

    public static void main(String[] args) throws Exception {
        Schema centralSchema = new Schema().setServerName("nvscmdbq1").setPort("1521").setService("d2he").setSchemaName("processing").setSchemaPwd("oracle");
        Schema sourceSchema = new Schema().setServerName("NVMNSDBQ1").setPort("1521").setService("d2he").setSchemaName("HF0974001150708").setSchemaPwd("oracle");
        long execNo = 1111111114201L;
        VerticaDB db = new VerticaDB();
        System.out.println(db.checkTableCount(sourceSchema, centralSchema, execNo));

    }

    /**
     * GETTING ERROR DETAILS FOR O2V DATA TRANSFER USING DMEXPRESS *
     */
    private static final String ERROR_DETAILS = "SELECT EXEC_NO,ERROR_SOURCE,TABLE_NAME,ERROR_TYPE,ERROR_MESSAGE FROM VT_TRANSFER_ERROR_LOG WHERE exec_no = ?";

    public List getErrorDetails(Schema schema, Long execNo) {

        // System.out.println("GETTING ERROR DETAILS  FOR DMEXPRESS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        /*
         * System.out.println(
         * "ERROR DETAILS(CENTRAL LOG)>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
         * ); System.out.println(schema.getServerName());
         * System.out.println(schema.getPort());
         * System.out.println(schema.getSchemaName());
         * System.out.println(schema.getSchemaPwd());
         */
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        VerticaDataTransfer errorDetails = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(ERROR_DETAILS);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                errorDetails = (new VerticaDataTransfer()).setExecNo(rs.getLong("EXEC_NO")).setErrorMessage(rs.getString("ERROR_MESSAGE"))
                        .setErrorSource(rs.getString("ERROR_SOURCE")).setErrorType(rs.getString("ERROR_TYPE"))
                        .setTableName(rs.getString("TABLE_NAME"));
                ls.add(errorDetails);
            }
        } catch (Exception ex) {
            System.out.println("Error.. GETTING VERTICA TRANSFER ERROR DETAILS IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /**
     * GETTING ERROR DETAILS FOR O2V DATA TRANSFER USING CMA *
     */
    private static final String ERROR_DETAILS_CMA = "SELECT EXEC_NO,ERROR_SOURCE,TABLE_NAME,ERROR_TYPE,ERROR_MESSAGE FROM VT_TRANSFER_ERROR_LOG_CMA WHERE exec_no = ?";

    public List getErrorDetails_CMA(Schema schema, Long execNo) {
        // System.out.println("GETTING ERROR DETAILS FOR CMA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List ls = new LinkedList();
        VerticaDataTransfer errorDetails = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(ERROR_DETAILS_CMA);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                errorDetails = (new VerticaDataTransfer()).setExecNo(rs.getLong("EXEC_NO")).setErrorMessage(rs.getString("ERROR_MESSAGE"))
                        .setErrorSource(rs.getString("ERROR_SOURCE")).setErrorType(rs.getString("ERROR_TYPE"))
                        .setTableName(rs.getString("TABLE_NAME"));
                ls.add(errorDetails);
            }
        } catch (Exception ex) {
            System.out.println("Error.. GETTING VERTICA TRANSFER ERROR DETAILS IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /**
     * GETTING EVENT DETAILS FOR O2V USING DMEXPRESS AND CMA
     */
    private static final String EVENT_DETAILS = "SELECT EVENT_DESCRIPTION, START_TIME, END_TIME FROM VT_EVENT_LOG_CMA  WHERE EXEC_NO = ? ORDER BY event_id";

    // event Details
    public List getEventDetails(Schema schema, Long execNo) {
        // System.out.println("GETTING EVENT DETAILS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        VerticaDataTransfer eventDetails = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(EVENT_DETAILS);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                eventDetails = (new VerticaDataTransfer()).setEventDescription(rs.getString("EVENT_DESCRIPTION"))
                        .setStartTime(rs.getTimestamp("START_TIME")).setEndTime(rs.getTimestamp("END_TIME"));
                ls.add(eventDetails);
            }
        } catch (Exception ex) {
            System.out.println("Error..GETTING VERTICA TRANSFER EVENT DETAILS IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /**
     * GETTING TRANSFER SUMMARY FOR O2V DATA TRANSFER USING DMEXPRESS *
     */
    private static final String TRANSFER_SUMMARY = ""
            + "SELECT CASE is_transferred "
            + "         WHEN 'R' THEN 'TABLES IN TRANSFER' "
            + "         WHEN 'E' THEN 'TABLES WITH TRANSFER ERROR' "
            + "         WHEN 'Y' THEN 'TABLES TRANSFERRED' "
            + "       END AS TRANSFER_STATUS, "
            + "       Count(src_obj_name), "
            + "       SUM(src_tbl_size) "
            + "FROM   vt_transfer_log "
            + "WHERE  exec_no = ? "
            + "AND    JOB_ID <> -999 "// job_id
            // <>
            // -999
            + "GROUP  BY CASE is_transferred " + "            WHEN 'R' THEN 'TABLES IN TRANSFER' "
            + "            WHEN 'E' THEN 'TABLES WITH TRANSFER ERROR' "
            + "            WHEN 'Y' THEN 'TABLES TRANSFERRED' " + "          END ";

    // transfer Summary
    public List getTransferSummary(Schema schema, Long execNo) {

        // System.out.println("GETTING TRANSFER SUMMARY FOR DMX>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        VerticaDataTransfer transferSummary = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(TRANSFER_SUMMARY);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            Long tableSize = (long) 0;
            while (rs.next()) {
                transferSummary = (new VerticaDataTransfer()).setTransferStatus(rs.getString(1)).setSrc_obj_name(rs.getLong(2));
                // .setSrcTableSize(rs.getInt(3));

                tableSize = rs.getLong(3);
                // System.out.println("TABLE SIZES>>>>>>>>>>>>>>>>>: "+tableSize);
                if (tableSize != null) {
                    transferSummary.setSrc_table_size(tableSize);
                } else {
                    transferSummary.setSrc_table_size(0);
                }

                ls.add(transferSummary);
            }
        } catch (Exception ex) {
            System.out.println("Error..GETTING VERTICA TRANSFER SUMMARY FOR O2V USING DMEXPRESS IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /**
     * GETTING TRANSFER SUMMARY FOR O2V DATA TRANSFER USING CMA *
     */
    /*private static final String TRANSFER_SUMMARY_CMA = ""
                                                             + "SELECT CASE is_transferred "
                                                             + "         WHEN 'R' THEN 'TABLES IN TRANSFER' "
                                                             + "         WHEN 'E' THEN 'TABLES WITH TRANSFER ERROR' "
                                                             + "         WHEN 'Y' THEN 'TABLES TRANSFERRED' "
                                                             + "       END AS TRANSFER_STATUS, "
                                                             + "       Count(src_obj_name), "
                                                             + "       SUM(src_tbl_size) "
                                                             + "FROM   vt_transfer_log_cma "
                                                             + "WHERE  exec_no = ? "
                                                             // +
                                                             // "AND    JOB_ID <> -999 "//
                                                             // job_id <> -999
                                                             + "GROUP  BY CASE is_transferred " + "            WHEN 'R' THEN 'TABLES IN TRANSFER' "
                                                             + "            WHEN 'E' THEN 'TABLES WITH TRANSFER ERROR' "
                                                             + "            WHEN 'Y' THEN 'TABLES TRANSFERRED' " + "          END ";*/
    private static final String TRANSFER_SUMMARY_CMA = ""
            + "SELECT CASE is_transferred "
            + "         WHEN 'R' THEN 'TABLES IN TRANSFER' "
            + "         WHEN 'E' THEN 'TABLES WITH TRANSFER ERROR' "
            + "         WHEN 'Y' THEN 'TABLES TRANSFERRED' "
            + "       END AS TRANSFER_STATUS, "
            + "       Count(src_obj_name), "
            + "       SUM(src_tbl_size) "
            + "FROM   vt_transfer_log_cma "
            + "WHERE  exec_no = ? AND Upper(obj_type) = 'TABLE' "
            + "GROUP  BY CASE is_transferred "
            + "            WHEN 'R' THEN 'TABLES IN TRANSFER' "
            + "            WHEN 'E' THEN 'TABLES WITH TRANSFER ERROR' "
            + "            WHEN 'Y' THEN 'TABLES TRANSFERRED' "
            + "          END "
            + "UNION ALL "
            + "SELECT CASE is_transferred "
            + "         WHEN 'Y' THEN 'VIEWS CREATED' "
            + "         WHEN 'N' THEN 'FAILED TO CREATE VIEWS' "
            + "       END AS TRANSFER_STATUS, "
            + "       Count(src_obj_name), "
            + "       SUM(src_tbl_size) "
            + "FROM   vt_transfer_log_cma "
            + "WHERE  exec_no = ? AND Upper(obj_type) = 'VIEW' "
            + "GROUP  BY CASE is_transferred "
            + "            WHEN 'Y' THEN 'VIEWS CREATED' "
            + "            WHEN 'N' THEN 'FAILED TO CREATE VIEWS' "
            + "          END  ";

    // transfer Summary
    public List getTransferSummary_CMA(Schema schema, Long execNo) {
        // System.out.println("GETTING TRANSFER SUMMARY FOR CMA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        VerticaDataTransfer transferSummary = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(TRANSFER_SUMMARY_CMA);
            ps.setLong(1, execNo);
            ps.setLong(2, execNo);//added for new query
            rs = ps.executeQuery();
            Long tableSize = (long) 0;
            while (rs.next()) {
                transferSummary = (new VerticaDataTransfer()).setTransferStatus(rs.getString(1)).setSrc_obj_name(rs.getLong(2));
                // .setSrcTableSize(rs.getInt(3));

                tableSize = rs.getLong(3);
                // System.out.println("TABLE SIZES>>>>>>>>>>>>>>>>>: "+tableSize);
                if (tableSize != null) {
                    transferSummary.setSrc_table_size(tableSize);
                } else {
                    transferSummary.setSrc_table_size(0);
                }

                ls.add(transferSummary);
            }
        } catch (Exception ex) {
            System.out.println("Error..GETTING VERTICA TRANSFER SUMMARY FOR O2V USING CMA IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /**
     * GETTING TRANSFER DETAILS FOR O2V DATA TRANSFER USING DMEXPRESS *
     */
    private static final String TRANSFER_DETAILS = "" + "SELECT exec_no, " + "       app_id, " + "       exec_mode, " + "       src_schema_id, "
            + "       src_schema_name, " + "       dst_schema_id, " + "       dst_schema_name, "
            + "       src_obj_name, " + "       dst_obj_name, " + "       obj_type, "
            + "       tsk_name, " + "       src_rec_cnt, " + "       cpy_rec_cnt, "
            + "       dst_rec_cnt, " + "       src_tbl_size, " + "       cpy_tbl_size, "
            + "       dst_tbl_size, " + "       src_rec_length, " + "       dst_rec_length, "
            + "       start_time, " + "       end_time, " + "       exec_time, " + "       cpu_time, "
            + "       is_transferred, " + "       job_id, " + "       dst_ip, " + "       src_ip "
            + "FROM   vt_transfer_log_cma " + "WHERE  exec_no = ? " + "       AND job_id <> -999 "
            + "       AND is_transferred = ? " + "ORDER  BY job_id ";

    public List getTransferDetails(Schema schema, Long execNo, String is_Transferred) {

        // System.out.println("GETTING TRANSFER DETAILS FOR DMX>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        VerticaDataTransfer transferDetails = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(TRANSFER_DETAILS);
            ps.setLong(1, execNo);
            ps.setString(2, is_Transferred);
            rs = ps.executeQuery();
            while (rs.next()) {
                transferDetails = (new VerticaDataTransfer()).setExecNo(rs.getLong("exec_no")).setApp_id(rs.getString("app_id"))
                        .setExecMode(rs.getString("exec_mode")).setSrcSchemaId(rs.getString("src_schema_id"))
                        .setSrcSchemaName(rs.getString("src_schema_name")).setDestSchemaId(rs.getString("dst_schema_id"))
                        .setDestSchemaName(rs.getString("dst_schema_name")).setSrcObjName(rs.getString("src_obj_name"))
                        .setDestObjName(rs.getString("dst_obj_name")).setObjType(rs.getString("obj_type")).setTaskName(rs.getString("tsk_name"))
                        .setSrcRecCount(rs.getString("src_rec_cnt")).setCpyRecCount(rs.getString("cpy_rec_cnt"))
                        .setDestRecCount(rs.getString("dst_rec_cnt")).setSrcTableSize(rs.getString("src_tbl_size"))
                        .setCpyTableSize(rs.getString("cpy_tbl_size")).setDestTableSize(rs.getString("dst_tbl_size"))
                        .setSrcRecLength(rs.getString("src_rec_length")).setDesRecLength(rs.getString("dst_rec_length"))
                        .setStartTime(rs.getTimestamp("start_time")).setEndTime(rs.getTimestamp("end_time")).setExecTime(rs.getString("exec_time"))
                        .setCPUTime(rs.getString("cpu_time")).setIsTransferred(rs.getString("is_transferred")).setJobId(rs.getString("job_id"))
                        .setDest_ip(rs.getString("dst_ip")).setSrc_ip(rs.getString("src_ip"));

                ls.add(transferDetails);

            }
        } catch (Exception ex) {
            System.out.println("Error..VERTICA TRANSFER DETAILS FOR O2V USING DMEXPRESS IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /**
     * GETTING TRANSFER DETAILS FOR O2V DATA TRANSFER USING CMA *
     */
    /*private static final String TRANSFER_DETAILS_CMA = "" + "SELECT exec_no, " + "       app_id, " + "       exec_mode, " + "       src_schema_id, "
                                                             + "       src_schema_name, " + "       dst_schema_id, "
                                                             + "       dst_schema_name, "
                                                             + "       src_obj_name, "
                                                             + "       dst_obj_name, "
                                                             + "       obj_type, "
                                                             + "       src_rec_cnt, "
                                                             + "       dst_rec_cnt, "
                                                             + "       src_tbl_size, "
                                                             + "       dst_tbl_size, "
                                                             // +
                                                             // "       start_time, "//start
                                                             // time removed
                                                             // +
                                                             // "       end_time, "//end_time
                                                             // removed
                                                             + "       exec_time, " + "       is_transferred " + "FROM   vt_transfer_log_cma "
                                                             + "WHERE  exec_no = ? " + "       AND is_transferred = ? ";*/
    private static final String TRANSFER_DETAILS_CMA = ""
            + "SELECT exec_no, "
            + "       app_id, "
            + "       exec_mode, "
            + "       src_schema_id, "
            + "       src_schema_name, "
            + "       dst_schema_id, "
            + "       dst_schema_name, "
            + "       src_obj_name, "
            + "       dst_obj_name, "
            + "       obj_type, "
            + "       src_rec_cnt, "
            + "       dst_rec_cnt, "
            + "       src_tbl_size, "
            + "       dst_tbl_size, "
            + "       exec_time, "
            + "       is_transferred "
            + "FROM   vt_transfer_log_cma "
            + "WHERE  exec_no = ? "
            + "       AND Upper(obj_type) = 'TABLE' "
            + "       AND is_transferred = ?";

    private static final String VW_TRANSFER_DETAILS_CMA = ""
            + "SELECT exec_no, "
            + "       app_id, "
            + "       exec_mode, "
            + "       src_schema_id, "
            + "       src_schema_name, "
            + "       dst_schema_id, "
            + "       dst_schema_name, "
            + "       src_obj_name, "
            + "       dst_obj_name, "
            + "       obj_type, "
            /*	+ "       src_rec_cnt, "
    		+ "       dst_rec_cnt, "
    		+ "       src_tbl_size, "
    		+ "       dst_tbl_size, "
    		+ "       exec_time, "*/
            + "       is_transferred "
            + "FROM   vt_transfer_log_cma "
            + "WHERE  exec_no = ? "
            + "       AND Upper(obj_type) = 'VIEW' "
            + "       AND is_transferred = ?";

    public List getTransferDetails_CMA(Schema schema, Long execNo, String is_Transferred) {

        // System.out.println("GETTING TRANSFER DETAILS FOR CMA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        VerticaDataTransfer transferDetails = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(TRANSFER_DETAILS_CMA);
            ps.setLong(1, execNo);
            ps.setString(2, is_Transferred);
            rs = ps.executeQuery();
            while (rs.next()) {
                transferDetails = (new VerticaDataTransfer()).setExecNo(rs.getLong("exec_no")).setApp_id(rs.getString("app_id"))
                        .setExecMode(rs.getString("exec_mode")).setSrcSchemaId(rs.getString("src_schema_id"))
                        .setSrcSchemaName(rs.getString("src_schema_name")).setDestSchemaId(rs.getString("dst_schema_id"))
                        .setDestSchemaName(rs.getString("dst_schema_name")).setSrcObjName(rs.getString("src_obj_name"))
                        .setDestObjName(rs.getString("dst_obj_name")).setObjType(rs.getString("obj_type"))
                        .setSrcRecCount(rs.getString("src_rec_cnt"))
                        .setDestRecCount(rs.getString("dst_rec_cnt"))
                        .setSrcTableSize(rs.getString("src_tbl_size"))
                        .setDestTableSize(rs.getString("dst_tbl_size"))
                        // .setStartTime(rs.getTimestamp("start_time"))
                        // .setEndTime(rs.getTimestamp("end_time"))
                        .setExecTime(rs.getString("exec_time"))
                        .setIsTransferred(rs.getString("is_transferred"));
                ls.add(transferDetails);

            }
        } catch (Exception ex) {
            System.out.println("Error..VERTICA TRANSFER DETAILS FOR O2V USING CMA IN CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    public List getVwTransferDetails_CMA(Schema schema, Long execNo, String is_Transferred) {

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        VerticaDataTransfer transferDetails = null;
        List ls = new LinkedList();
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(VW_TRANSFER_DETAILS_CMA);
            ps.setLong(1, execNo);
            ps.setString(2, is_Transferred);
            rs = ps.executeQuery();
            while (rs.next()) {
                transferDetails = (new VerticaDataTransfer()).setExecNo(rs.getLong("exec_no")).setApp_id(rs.getString("app_id"))
                        .setExecMode(rs.getString("exec_mode")).setSrcSchemaId(rs.getString("src_schema_id"))
                        .setSrcSchemaName(rs.getString("src_schema_name")).setDestSchemaId(rs.getString("dst_schema_id"))
                        .setDestSchemaName(rs.getString("dst_schema_name")).setSrcObjName(rs.getString("src_obj_name"))
                        .setDestObjName(rs.getString("dst_obj_name")).setObjType(rs.getString("obj_type"))
                        //.setSrcRecCount(rs.getString("src_rec_cnt"))
                        //.setDestRecCount(rs.getString("dst_rec_cnt"))
                        //.setSrcTableSize(rs.getString("src_tbl_size"))
                        //.setDestTableSize(rs.getString("dst_tbl_size"))
                        // .setStartTime(rs.getTimestamp("start_time"))
                        // .setEndTime(rs.getTimestamp("end_time"))
                        //.setExecTime(rs.getString("exec_time"))
                        .setIsTransferred(rs.getString("is_transferred"));
                ls.add(transferDetails);

            }
        } catch (Exception ex) {
            logger.error("Error getting view transfer details with execution number " + execNo + " and is_transferred " + is_Transferred, ex);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return ls;
    }

    /*
     * 
     * TO GET TOTAL TABLE COUNT ("This method is used for DMEXPRESS and CMA")
     */
    private static String COUNT_TOTAL_TABLE_FROM_SOURCE_QRY = "SELECT COUNT(TBL_NAME) FROM VT_DDL WHERE IS_TRANSFERRED in ('N','E')"; // change

    // in
    public int getTotalTableCountFromSource(Schema schema) {
        // System.out.println("GET TOTAL TABLE COUNT FROM SOURCE>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int tableCount = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(COUNT_TOTAL_TABLE_FROM_SOURCE_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                tableCount = rs.getInt(1);
            }
        } catch (Exception ex) {
            System.out.println("Error..COUNTING  TOTAL TABLES FROM SOURCE ORACLE (" + schema.getServerName() + ") " + ": " + ex.getMessage() + " "
                    + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        // System.out.println("TOTAL TABLE COUNT>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:"+tableCount);
        return tableCount;
    }

    private static String COUNT_TOTAL_VIEW_FROM_SOURCE_QRY = "select count(*) FROM "
            + "        VT_COMMONVIEWS M, "
            + "  VT_TRANSFER_OBJLIST L "
            + "WHERE "
            + "     Upper(M.VIEW_NAME) = Upper(L.TBL_NAME)";

    public int getTotalViewCountFromSource(Schema schema) {
        // System.out.println("GET TOTAL TABLE COUNT FROM SOURCE>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int viewCount = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(COUNT_TOTAL_VIEW_FROM_SOURCE_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                viewCount = rs.getInt(1);
            }
        } catch (Exception ex) {
            System.out.println("Error..COUNTING  TOTAL VIEWS FROM SOURCE ORACLE (" + schema.getServerName() + ") " + ": " + ex.getMessage() + " "
                    + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        // System.out.println("TOTAL TABLE COUNT>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:"+tableCount);
        return viewCount;
    }

    /**
     * ****
     * TO CHECK IF THE EVENT IS "Execute DMX Task" FOR O2V DATA TRANSFER USING
     * DMEXPRESS ******
     */
    private static String IS_EXECUTE_DMX_TASK = "select count(1) from VT_EVENT_LOG where event_id = 90  and exec_no =?";

    // here eventid =90 represents the event execute dmx job
    public boolean isExecuteDMXTask(Schema schema, Long execNo) {
        // System.out.println("CHECKING IS EXECUTE DMX TASK>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        boolean isExecuteDMXTask = false;

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(IS_EXECUTE_DMX_TASK);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            if (count == 1) {
                isExecuteDMXTask = true;
            }
        } catch (Exception ex) {
            System.out.println("Error..CHECKING EXECUTE DMX TASK IN CENTRAL SERVER (" + schema.getSchemaName() + "/" + schema.getServerName() + ") "
                    + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return isExecuteDMXTask;
    }

    /**
     * ****
     * TO CHECK IF THE EVENT IS "Copy data from oracle to vertica" FOR O2V DATA
     * TRANSFER USING CMA ******
     */
    private static String IS_COPY_DATA_FROM_ORACLE_TO_VERTICA = "select count(1) from VT_EVENT_LOG_CMA where event_id = 80  and exec_no =?";

    // here eventid =80 represents the event copy data from oracle to vertica
    public boolean isCopyDataFromO2V(Schema schema, Long execNo) {
        // System.out.println("CHECKING IS COPY O2v DATA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        boolean isCopyDataFromO2V = false;

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(IS_COPY_DATA_FROM_ORACLE_TO_VERTICA);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
            if (count == 1) {
                isCopyDataFromO2V = true;
            }
        } catch (Exception ex) {
            System.out.println("Error..CHECKING COPY DATA IN CENTRAL SERVER (" + schema.getSchemaName() + "/" + schema.getServerName() + ") " + ": "
                    + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return isCopyDataFromO2V;
    }

    /*
     * COUNTING SUCCESS AND ERROR TABLE COUNT IN CENTRAL SERVER FOR O2V DATA
     * TRANSFER USING DMEXPRESS
     */
    private static String COUNT_QRY = "SELECT count(exec_no) FROM VT_TRANSFER_LOG WHERE exec_no=? and is_transferred =? AND JOB_ID <> -999";

    public int getCount(Schema schema, Long execNo, String isTransferred) {
        // System.out.println("GETTING COUNT FOR DMX>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(COUNT_QRY);
            ps.setLong(1, execNo);
            ps.setString(2, isTransferred);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception ex) {
            System.out.println("Error..COUNTING VERTICA TABLES FOR O2V(DMEXPRESS) FROM CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }

    /*
     * COUNTING SUCCESS AND ERROR TABLE COUNT IN CENTRAL SERVER FOR O2V DATA
     * TRANSFER USING CMA
     */
    private static String COUNT_QRY_CMA = "SELECT count(exec_no) FROM VT_TRANSFER_LOG_CMA WHERE exec_no=? and upper(obj_type)='TABLE' and is_transferred =? ";

    public int getCount_CMA(Schema schema, Long execNo, String isTransferred) {
        // System.out.println("GETTING TABLE COUNT FOR CMA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(COUNT_QRY_CMA);
            ps.setLong(1, execNo);
            ps.setString(2, isTransferred);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception ex) {
            System.out.println("Error..COUNTING VERTICA TABLES FOR O2V(CMA) FROM CENTRAL SERVER (" + schema.getSchemaName() + "/"
                    + schema.getServerName() + ") " + ": " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }

    private static final String GET_VIEW_COUNT_CMA = "SELECT count(exec_no) FROM VT_TRANSFER_LOG_CMA WHERE exec_no=? and upper(obj_type)='VIEW' and is_transferred =?";

    /**
     * @Description: Gives the view count
     * @param schema
     * @param execNo
     * @param isTransferred
     * @return
     */
    public int getViewCount_CMA(Schema schema, Long execNo, String isTransferred) {
        // System.out.println("GETTING TABLE COUNT FOR CMA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(GET_VIEW_COUNT_CMA);
            ps.setLong(1, execNo);
            ps.setString(2, isTransferred);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception ex) {
            logger.error("Error count view with isTransferred " + isTransferred + " and exec no " + execNo, ex);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }

    private static String GET_OUTPUT_FILEINFORMATION = "Select Host from processeventlog where executionnumber = ? ";

    public String getHostName(Long executionNo, DataSource ds) {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String host = "";
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_OUTPUT_FILEINFORMATION);
            ps.setLong(1, executionNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                host = rs.getString(1);
            }
        } catch (Exception ex) {
            logger.debug("Error..Getting host as per exection number : " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return host;
    }

    private static String IS_PROCESS_COMPLETED = "select case when endtime is null then 'N' else 'Y' END as isProcessCompleted from "
            + "  processeventlog where executionnumber = ? ";

    public boolean isProcessCompleted(Long executionNo, DataSource ds) {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String processCompleted = "N";
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(IS_PROCESS_COMPLETED);
            ps.setLong(1, executionNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                processCompleted = rs.getString(1);
            }
        } catch (Exception ex) {
            logger.debug("Error..Getting isProcessCompleted as per exection number : " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return "Y".equals(processCompleted);
    }

    /**
     * @param executionNo
     * @param ds
     * @return shell script stream for the given execution number (Used for
     * downloading vertica log file)
     * @description gets files from dashboard server if exists...else downloads
     * from remote server(processing server).
     * @throws JSchException
     * @throws SftpException
     * @throws IOException
     */
    public InputStream getLogFile(Long executionNo, String hostingServer, DataSource ds) throws JSchException, SftpException, IOException {
        InputStream inputStream = null;
        EnvInfo envInfo = ComponentFactory.getInstance().getEnvInfo();

        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA : hostingServer;
        // System.out.println("Hosting server for getting log file>>>>>>>>>>>>>>>>>>>>"+hostingServer);
        String fileName = fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX, hostingServer) + "_" + executionNo + ".log";

        File logFile_localServer = new File(envInfo.getTempDir(), fileName);
        if (logFile_localServer.exists()) {
            logger.info("Getting log file from local  >>>> " + logFile_localServer.getAbsolutePath());
            return new FileInputStream(logFile_localServer);
        } else {
            return getVerticaOutputStream(executionNo, getHostName(executionNo, ds), hostingServer);
        }

    }

    /**
     * @param executionNo
     * @param srcHost
     * @return shell script stream from the given srcHost and execution number
     * @throws JSchException
     * @throws SftpException
     */
    public InputStream getVerticaOutputStream(Long executionNo, String srcHost, String hostingServer) throws JSchException, SftpException {
        InputStream inputStream = null;
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA : hostingServer;

        // System.out.println("Hosting server for getting vertica output strem>>>>>>>>>>>>>>>>>>>>>"+hostingServer);
        String fileName = fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX, hostingServer) + "_" + executionNo + ".log";
        String logFile_remoteServer = fixedParam.getValue(Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer) + "/" + fileName;
        String userName = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String password = fixedParam.getValue(Constants.OS_PASSWORD, hostingServer);
        String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        Session session = null;
        Channel channel = null;
        ChannelSftp channelSftp = null;
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
        JSch jsch = new JSch();
        jsch.addIdentity(privateKey);
        session = jsch.getSession(userName, srcHost, 22);
        session.setPassword(password);
        session.setConfig(config);
        session.connect();
        channel = session.openChannel("sftp");
        channel.connect();
        channelSftp = (ChannelSftp) channel;
        logger.info("Getting Log File from Remote server >>>>" + logFile_remoteServer);
        inputStream = channelSftp.get(logFile_remoteServer);
        return inputStream;
    }

    /**
     * @param executionNo
     * @param ds
     * @return shell script output from server of given execNo
     */
    public String getShellScriptOutput(Long executionNo, String hostingServer, DataSource ds) {
        String output = "";
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA : hostingServer;
        // System.out.println("Hosting Server for getting shell script output is >>>>>>>>>>>>>>>>>"+hostingServer);

        String user = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String password = fixedParam.getValue(Constants.OS_PASSWORD, hostingServer);
        String server = getHostName(executionNo, ds);

        String fileName = fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX, hostingServer) + "_" + executionNo + ".log";

        String fileLocation = fixedParam.getValue(Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer);

        String command1 = "cd " + fileLocation;
        String command2 = "tail -20 " + fileName;
        List<String> commands = new ArrayList<String>();
        commands.add(command1);
        commands.add(command2);

        String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        try {
            // List ls
            // =RunShellScript.runShellScript(false,user,password,server,command1,command2,privateKey);
            // output = (String) ls.get(1);
            output = CmdRunner.runCommandsOnShell(false, server, user, password, commands, privateKey);
        } catch (Exception e) {
            logger.error("Error on getting shell script output(tail -20) for execution number " + executionNo + ": " + e.toString());
            e.printStackTrace();
            output = e.toString();
            return output;
        }

        /*
         * To hide logout and exit while showing shell script output
         */
        if (output.contains("logout")) {
            output = output.replace("logout", "");

        }
        if (output.contains("exit")) {
            output = output.replace("exit", "");

        }
        return output;
    }

    /**
     * @param schema
     * @return output(log) for oracle BA module transfer from dashboard server
     * @throws FileNotFoundException
     */
    public InputStream getOracleBALogFile(Schema schema) throws FileNotFoundException {
        InputStream inputStream = null;
        EnvInfo envInfo = ComponentFactory.getInstance().getEnvInfo();
        File oraclBALogFile = new File(envInfo.getTempDir(), NamingUtil.getFilePrefix(schema) + ".tx.sql._out");
        if (oraclBALogFile.exists()) {
            logger.info("Getting oracle ba log file from local  >>>> " + oraclBALogFile.getAbsolutePath());
            return new FileInputStream(oraclBALogFile);
        } else {
            return inputStream;
        }
    }

    private static String processIdPattern = Constants.PROCESS_ID_PATTERN;
    private Pattern pattern = Pattern.compile(processIdPattern, Pattern.MULTILINE);

    public Object[] getOracle2VerticaProcessId(String input) {
        Object[] retObj
                = {Boolean.FALSE, ""};
        Matcher m = pattern.matcher(input);
        while (m.find()) {
            retObj[0] = true;
            String foundPattern = m.group();
            // System.out.println("Found Pattern :"+foundPattern);
            String[] splittedPattern = foundPattern.split(Constants.PROCESS_ID_SPLITTER);
            // System.out.println("Process ID: "+splittedPattern[1]);
            retObj[1] = splittedPattern[1];
        }
        return retObj;
    }

    private static String batchIdPattern = Constants.CMA_BATCH_ID_PATTERN;
    private Pattern pattern1 = Pattern.compile(batchIdPattern, Pattern.MULTILINE);

    public Object[] getCMABatchId(String input) {
        Object[] retObj
                = {Boolean.FALSE, ""};
        Matcher m = pattern1.matcher(input);
        while (m.find()) {
            retObj[0] = true;
            String foundPattern = m.group();
            // System.out.println("Found Pattern :"+foundPattern);
            String[] splittedPattern = foundPattern.split(":");
            // System.out.println("Process ID: "+splittedPattern[1]);
            retObj[1] = splittedPattern[1];
        }
        return retObj;
    }

    public boolean killOracleToVerticaProcess(String execNo, String process_Id, String srcServer, String hostingServer) {
        boolean processKilled = true;
        // List outputList = null;
        String output = "";
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA : hostingServer;

        String OS_UserName = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String OS_Password = fixedParam.getValue(Constants.OS_PASSWORD, hostingServer);
        String private_Key = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        String command1 = "cd ";
        String command2 = "kill -- -" + process_Id;
        List<String> commands = new ArrayList<String>();
        commands.add(command1);
        commands.add(command2);

        try {
            // outputList =
            // RunShellScript.runShellScript(false,OS_UserName,OS_Password,srcServer,command1,command2,private_Key);
            output = CmdRunner.runCommandsOnShell(false, srcServer, OS_UserName, OS_Password, commands, private_Key);
        } catch (Exception e) {
            processKilled = false;
            // adding exception to list
            /*
             * outputList = new LinkedList(); outputList.add(false);
             * outputList.add(e.toString());
             */
            output = e.toString();
            logger.error("Error while killing oracle to vertica data transfer with exec no: " + execNo + " on processing server: " + srcServer + ": "
                    + e.toString());
            e.printStackTrace();
        }

        /**
         * WRITING KILL LOG OUPUT TO FILE *
         */
        EnvInfo envInfo = ComponentFactory.getInstance().getEnvInfo();
        String outputFileName = "KillProcess_" + execNo + "_" + process_Id + ".log";
        File killLogFile = new File(envInfo.getTempDir(), outputFileName);

        try {
            // writing to text file
            // FileUtil.writeToTextFile((String)outputList.get(1), killLogFile);
            FileUtil.writeToTextFile(output, killLogFile);
        } catch (Exception e) {
            // processKilled = false;
            logger.error("Error on writing kill log file for execution number:" + execNo + ": " + e.toString());
            System.out.println("Error in killOracleToVerticaProcess method while writing to log file : " + e);
        }

        return processKilled;
    }

    public String getO2VProcessId(String execNo, String srcServer, String hostingServer) {
        String processid = "0";
        // List outputList = null;
        String output = "";
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA : hostingServer;
        // System.out.println("Hosting server for getting oracle to vertica process id is>>>>>>>>>>>>>>>>>>>>>>>>"+hostingServer);

        String OS_UserName = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String OS_Password = fixedParam.getValue(Constants.OS_PASSWORD, hostingServer);
        String private_Key = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        String fileLocation = fixedParam.getValue(Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer);
        String fileName = fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX, hostingServer) + "_" + execNo + ".log";

        String command1 = "cd " + fileLocation;
        String command2 = "head -10 " + fileName + " | awk '/PROCESS ID/'";
        List<String> commands = new ArrayList<String>();
        commands.add(command1);
        commands.add(command2);

        try {
            // outputList =
            // RunShellScript.runShellScript(false,OS_UserName,OS_Password,srcServer,command1,command2,private_Key);
            output = CmdRunner.runCommandsOnShell(false, srcServer, OS_UserName, OS_Password, commands, private_Key);
        } catch (Exception e) {
            logger.error("Error on getting oracle to vertica process id for execution number " + execNo + ": " + e.toString());
            e.printStackTrace();
            return processid;
        }

        // Object obj[] = getOracle2VerticaProcessId((String)outputList.get(1));
        Object obj[] = getOracle2VerticaProcessId(output);
        if ((Boolean) obj[0]) {
            processid = (String) obj[1];
        }
        return processid;
    }

    /**
     * @param execNo
     * @param srcServer
     * @param hostingServer
     * @return batch id for O2V data transfer using CMA
     * @description gets batch id from the shell script output from the
     * processing server
     * @throws IOException
     */
    public String getCMABatchID(String execNo, String srcServer, String hostingServer) throws Exception {
        String batchid = "0";
        // List outputList = null;
        String output = "";
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA : hostingServer;

        // System.out.println("Hosting Server for getting CMA Batch ID>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+hostingServer);
        String OS_UserName = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String OS_Password = fixedParam.getValue(Constants.OS_PASSWORD, hostingServer);
        String private_Key = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        String fileLocation = fixedParam.getValue(Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer);
        String fileName = fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX, hostingServer) + "_" + execNo + ".log";

        String command1 = "cd " + fileLocation;
        String command2 = "cat " + fileName + " | awk '/Batch ID/'";
        List<String> commands = new ArrayList<String>();
        commands.add(command1);
        commands.add(command2);

        try {
            // outputList =
            // RunShellScript.runShellScript(false,OS_UserName,OS_Password,srcServer,command1,command2,private_Key);
            output = CmdRunner.runCommandsOnShell(false, srcServer, OS_UserName, OS_Password, commands, private_Key);
        } catch (Exception e) {
            logger.error("Error on getting cma batch id for execution number " + execNo + ": " + e.toString());
            e.printStackTrace();
            return batchid;
        }

        // Object obj[] = getCMABatchId((String)outputList.get(1));
        Object obj[] = getCMABatchId(output);
        if ((Boolean) obj[0]) {
            batchid = (String) obj[1];
        }
        return batchid;
    }

    private static final String GET_CMA_BATCH_ID = "select cma_batch_id from vt_transfer_log_cma where exec_no =? and rownum=1";

    public String getCMABatchId(long execNo, Schema schema) {
        String cma_batch_id = "";

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
            ps = cnn.prepareStatement(GET_CMA_BATCH_ID);
            ps.setLong(1, execNo);
            rs = ps.executeQuery();
            while (rs.next()) {
                cma_batch_id = (rs.getString(Constants.CMA_BATCH_ID) == null ? "" : rs.getString(Constants.CMA_BATCH_ID));
            }
        } catch (Exception ex) {
            System.out.println("Error.. GETTING CMA BATCH ID : " + ex.getMessage() + " " + schema);
            ex.printStackTrace();
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return cma_batch_id;
    }

    /*private static final String VERTICA_SCHEMA_EXISTS_QRY = "SELECT COUNT(1) FROM USERS WHERE UPPER(USER_NAME)=UPPER(?)";*/
    private static final String VERTICA_SCHEMA_EXISTS_QRY = "SELECT COUNT(1) FROM SCHEMATA WHERE UPPER(SCHEMA_NAME)=UPPER(?)";

    public boolean verticaSchemaExists(Schema schema, String newSchemaName) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = new VerticaDBConnector().getConnectionForSchema(schema);
            ps = cnn.prepareStatement(VERTICA_SCHEMA_EXISTS_QRY);
            ps.setString(1, newSchemaName);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
                if (count > 0) {
                    return true;
                }
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return false;
    }

    /*
     * private static final String GET_TABLESPACE_STATUS = "" +
     * "SELECT status,tablespace_name FROM dba_tablespaces WHERE tablespace_name = "
     * +
     * "(SELECT DISTINCT tablespace_name FROM dba_segments WHERE upper(owner) = upper(?))"
     * ;
     */
    private static final String GET_TABLESPACE_STATUS = ""
            + "SELECT status,tablespace_name FROM dba_tablespaces WHERE tablespace_name "
            + "= (SELECT DISTINCT tablespace_name FROM dba_segments WHERE upper(owner) = upper(?) AND tablespace_name LIKE 'HF%' AND  tablespace_name NOT LIKE '%_INDEX')";

    public Object[] getTableSpaceAndItsStatus(Schema srcSchema) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Object[] retVal = new Object[2];
        try {
            cnn = new OracleDBConnector().getConnectionForSchema(srcSchema);
            ps = cnn.prepareStatement(GET_TABLESPACE_STATUS);
            ps.setString(1, srcSchema.getSchemaName());
            rs = ps.executeQuery();
            while (rs.next()) {
                retVal[0] = rs.getString("status");
                retVal[1] = rs.getString("tablespace_name");
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return retVal;
    }

    private static final String RETRANSFER_TABLE_EXISTS = "SELECT COUNT(1) FROM  USER_TABLES WHERE UPPER(TABLE_NAME)=UPPER(?) ";

    /**
     * Description : Checks if retransfer tbl exists or not is srcSchema
     *
     * @param srcSchema
     * @param reTransferTblName
     * @return
     * @throws Exception
     */
    public boolean reTransferTableExists(Schema srcSchema, String reTransferTblName) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = new OracleDBConnector().getConnectionForSchema(srcSchema);
            ps = cnn.prepareStatement(RETRANSFER_TABLE_EXISTS);
            ps.setString(1, reTransferTblName);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
                if (count > 0) {
                    return true;
                }
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return false;
    }

    /**
     * Description : Checks if retransfer tbl is empty or not connecting to
     * srcSchema
     *
     * @param srcSchema
     * @param reTransferTblName
     * @return
     * @throws Exception
     */
    public boolean isReTransferTblEmpty(Schema srcSchema, String reTransferTblName) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        String query = "SELECT COUNT(1) FROM " + reTransferTblName;
        try {
            cnn = new OracleDBConnector().getConnectionForSchema(srcSchema);
            ps = cnn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
                if (count == 0) {
                    return true;
                }
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return false;
    }

    private static final String CHECK_FOR_RETRANSFER = ""
            + "SELECT Count (DISTINCT l.SRC_SERVER|| l.SRC_SCHEMA_NAME|| g.SERVERGROUPID ||l.DST_SCHEMA_NAME) "
            + "FROM "
            + "        VT_TRANSFER_LOG_CMA l "
            + "LEFT JOIN "
            + "        SERVERS s "
            + "ON "
            + "        (l.DST_SERVER = s.HOST) "
            + "JOIN "
            + "        SERVERGROUP g "
            + "ON "
            + "        (g.SERVERGROUPID = s.SERVERGROUPID) "
            + "WHERE "
            + "        l.SRC_SERVER = ? AND "
            + "        l.SRC_SCHEMA_NAME = ? AND "
            + "        g.SERVERGROUPID = (SELECT SERVERGROUPID FROM SERVERS WHERE HOST = ?) AND "
            + "        l.DST_SCHEMA_NAME = ?";

    /**
     * Description: Checks for retransfer by quering central schema
     *
     * @param srcOrclSchema
     * @param destVtkaSchema
     * @param centralSchema
     * @return
     * @throws Exception
     */
    public int checkForReTransfer(Schema srcOrclSchema, Schema destVtkaSchema, Schema centralSchema) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;

        CustomException.assertEmptyString(srcOrclSchema.getServerName(), "Source Oracle Server Name is found empty while checking for Retransfer!!!");
        CustomException.assertEmptyString(srcOrclSchema.getSchemaName(), "Source Oracle Schema Name is found empty while checking for Retransfer!!!");
        CustomException.assertEmptyString(destVtkaSchema.getServerName(),
                "Destination Vertica Server Name is found empty while checking for Retransfer!!!");
        CustomException.assertEmptyString(destVtkaSchema.getSchemaName(),
                "Destination Vertica Schema Name is found empty while checking for Retransfer!!!");

        try {
            cnn = new OracleDBConnector().getConnectionForSchema(centralSchema);
            ps = cnn.prepareStatement(CHECK_FOR_RETRANSFER);
            ps.setString(1, srcOrclSchema.getServerName());
            ps.setString(2, srcOrclSchema.getSchemaName());
            ps.setString(3, destVtkaSchema.getServerName());
            ps.setString(4, destVtkaSchema.getSchemaName());
            rs = ps.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }

    private static final String CHECK_ORACLE_MAPPING = "SELECT count(1) as count FROM orcl_prod_dr_servermap WHERE upper(RAC_SERVER_GRPID)	=?";
    private static final String INSERT_ORACLE_MAPPING = "INSERT INTO orcl_prod_dr_servermap (RAC_SERVER_GRPID,DRRAC_SERVER_GRPID) VALUES (?,?)";
    private static final String UPDATE_ORACLE_MAPPING = "UPDATE orcl_prod_dr_servermap SET DRRAC_SERVER_GRPID = ? where RAC_SERVER_GRPID=?";

    /**
     * Description Maps oracle RAC serverGroupId to oracle DR serverGroupId 1.
     * First checks if oracle RAC serverGroupId already exists or not 2. If
     * already exists ,then update the mapping 3. Else inserts new mapping
     *
     * @param oracleRACServerGroupId
     * @param oracleDRServerGroupId
     * @param ds
     * @return
     * @throws Exception
     */
    public boolean mapOracleServerGroup(String oracleRACServerGroupId, String oracleDRServerGroupId, DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int insertUpdate = 0;
        boolean mapped = false;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_ORACLE_MAPPING);
            ps.setString(1, oracleRACServerGroupId.toUpperCase());
            rs = ps.executeQuery();

            while (rs.next()) {
                count = rs.getInt("count");
            }
            if (count > 0) {
                // System.out.println("UPDATING VERTICA MAPPING>>>>>");
                ps = cnn.prepareStatement(UPDATE_ORACLE_MAPPING);
                ps.setString(1, oracleDRServerGroupId);
                ps.setString(2, oracleRACServerGroupId);
                insertUpdate = ps.executeUpdate();
            } else {
                // System.out.println("INSERTING VERTICA MAPPING>>>>>");
                ps = cnn.prepareStatement(INSERT_ORACLE_MAPPING);
                ps.setString(1, oracleRACServerGroupId);
                ps.setString(2, oracleDRServerGroupId);
                insertUpdate = ps.executeUpdate();
            }

            if (insertUpdate > 0) {
                mapped = true;
            }
            return mapped;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
    }

    private static final String CHECK_VERTICA_MAPPING = "SELECT count(1) as count FROM vtka_prod_dr_servermap WHERE upper(PROD_CLUSTER_GRPID)	=?";
    private static final String INSERT_VERTICA_MAPPING = "INSERT INTO vtka_prod_dr_servermap (PROD_CLUSTER_GRPID,DR_CLUSTER_GRPID) VALUES (?,?)";
    private static final String UPDATE_VERTICA_MAPPING = "UPDATE vtka_prod_dr_servermap SET DR_CLUSTER_GRPID = ? where PROD_CLUSTER_GRPID=?";

    /**
     * Description Maps vertica RAC serverGroupId to vertica DR serverGroupId 1.
     * First checks if vertica RAC serverGroupId already exists or not 2. If
     * already exists ,then update the mapping 3. Else inserts new mapping
     *
     * @param verticaRACServerGroupId
     * @param verticaDRServerGroupId
     * @param ds
     * @return
     * @throws Exception
     */
    public boolean mapVerticaServerGroup(String verticaRACServerGroupId, String verticaDRServerGroupId, DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int insertUpdate = 0;
        boolean mapped = false;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_VERTICA_MAPPING);
            ps.setString(1, verticaRACServerGroupId.toUpperCase());
            rs = ps.executeQuery();

            while (rs.next()) {
                count = rs.getInt("count");
            }
            if (count > 0) {
                // System.out.println("UPDATING VERTICA MAPPING>>>>>");
                ps = cnn.prepareStatement(UPDATE_VERTICA_MAPPING);
                ps.setString(1, verticaDRServerGroupId);
                ps.setString(2, verticaRACServerGroupId);
                insertUpdate = ps.executeUpdate();
            } else {
                // System.out.println("INSERTING VERTICA MAPPING>>>>>");
                ps = cnn.prepareStatement(INSERT_VERTICA_MAPPING);
                ps.setString(1, verticaRACServerGroupId);
                ps.setString(2, verticaDRServerGroupId);
                insertUpdate = ps.executeUpdate();
            }

            if (insertUpdate > 0) {
                mapped = true;
            }
            return mapped;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
    }

    private static final String CHECK_VERTICA_CLUSTER_MAPPING = "SELECT count(1) as count FROM vtka_prod_dr_clustermap WHERE upper(PROD_CLUSTER_GRPID)  =?";
    private static final String INSERT_VERTICA_CLUSTER_MAPPING = "INSERT INTO vtka_prod_dr_clustermap (PROD_CLUSTER_GRPID,DR_CLUSTER_GRPID) VALUES (?,?)";
    private static final String UPDATE_VERTICA_CLUSTER_MAPPING = "UPDATE vtka_prod_dr_clustermap SET DR_CLUSTER_GRPID = ? where PROD_CLUSTER_GRPID=?";

    /**
     * @Description: Maps PROD cluster group to DR cluster group
     * @param prodVerticaClusterGrpId
     * @param drVerticaClusterGrpId
     * @param ds
     * @return
     * @throws Exception
     */
    public boolean mapVerticaClusterGroup(String prodVerticaClusterGrpId, String drVerticaClusterGrpId, DataSource ds) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int insertUpdate = 0;
        boolean mapped = false;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_VERTICA_CLUSTER_MAPPING);
            ps.setString(1, prodVerticaClusterGrpId.toUpperCase());
            rs = ps.executeQuery();

            while (rs.next()) {
                count = rs.getInt("count");
            }
            if (count > 0) {
                // System.out.println("UPDATING VERTICA MAPPING>>>>>");
                ps = cnn.prepareStatement(UPDATE_VERTICA_CLUSTER_MAPPING);
                ps.setString(1, drVerticaClusterGrpId);
                ps.setString(2, prodVerticaClusterGrpId);
                insertUpdate = ps.executeUpdate();
            } else {
                // System.out.println("INSERTING VERTICA MAPPING>>>>>");
                ps = cnn.prepareStatement(INSERT_VERTICA_CLUSTER_MAPPING);
                ps.setString(1, prodVerticaClusterGrpId);
                ps.setString(2, drVerticaClusterGrpId);
                insertUpdate = ps.executeUpdate();
            }

            if (insertUpdate > 0) {
                mapped = true;
            }
            return mapped;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
    }

    private static final String GET_ORCL_DR_SERVER_GROUP = "SELECT a.drrac_server_grpid, "
            + "       b.groupname "
            + "FROM   orcl_prod_dr_servermap a "
            + "       join servergroup b "
            + "         ON a.drrac_server_grpid = b.servergroupid "
            + "WHERE  rac_server_grpid = ?";

    /**
     * @Description : Returns the mapped Clustergroup from the given
     * clusterGroup
     * @param prodClusterGroup
     * @return
     * @throws Exception
     */
    public ServerGroup getOrclDRServerGroup(DataSource ds, Schema orclSchema) throws Exception {
        CustomException.assertEmptyString(orclSchema.getServerGroupId(), "Server group id while getting mapped oracle dr server group");

        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ServerGroup drServerGrp = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_ORCL_DR_SERVER_GROUP, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, orclSchema.getServerGroupId());
            rs = ps.executeQuery();
            rs.last();
            int rowCount = rs.getRow();
            CustomException.assertEqualsZero(rowCount, "No Mapping found for RAC Server Group " + orclSchema.getServerGroupName());
            rs.beforeFirst();
            while (rs.next()) {
                drServerGrp = new ServerGroup().setServerGroupId(rs.getString("drrac_server_grpid")).setGroupName(rs.getString("groupname"));
            }
        } catch (Exception e) {
            logger.error("Error on VerticaDB->getOrclDRServerGroup(orclSchema) " + orclSchema, e);
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return drServerGrp;
    }

    //private static final String CHECK_FOR_ORACLE_MAPPING    = "SELECT COUNT(1) AS MAPPED FROM orcl_prod_dr_servermap WHERE UPPER(RAC_SERVER_GRPID) = ?";
    //private static final String GET_ORACLE_DR_SERVERGROUPID = "SELECT DRRAC_SERVER_GRPID FROM orcl_prod_dr_servermap WHERE UPPER(RAC_SERVER_GRPID) = ?";
    private static final String GET_ORACLE_DR_SERVERGROUPID = "SELECT DRRAC_SERVER_GRPID FROM orcl_prod_dr_servermap WHERE UPPER(RAC_SERVER_GRPID) = ?";
    //private static final String CHECK_FOR_ORACLE_DR_SERVER  = "SELECT COUNT(1) AS SERVERCOUNT FROM orcl_prod_dr_servermap WHERE UPPER(DRRAC_SERVER_GRPID) = ?";
    /*private static final String CHECK_FOR_ORACLE_DR_SERVER  = "SELECT COUNT(1) AS SERVERCOUNT FROM SERVERS WHERE UPPER(SERVERGROUPID) = ?";*/
 /*private static final String GET_SERVER_DETAILS          = "SELECT SERVERGROUPID, HOST, PORT, SERVICE , CONNECTION, DATABASE ,DATABASEID "
                                                                    + "FROM SERVERS WHERE UPPER(SERVERGROUPID) = ? AND ROWNUM = 1";*/

    private static final String GET_VIP_SERVER_DETAILS = "SELECT a.servergroupid, "
            + "       a.host, "
            + "       a.port, "
            + "       a.service, "
            + "       a.connection, "
            + "       a.DATABASE, "
            + "       a.databaseid, "
            + "       a.sidflag, "
            + "       b.groupname "
            + "FROM   servers a "
            + "       join servergroup b "
            + "         ON a.servergroupid = b.servergroupid "
            + "       join platform_database_info c "
            + "         ON a.databaseid = c.dbid "
            + "WHERE  upper(b.servergroupid) = ? "
            + "       AND c.vipflag = 'Y'";

    private static final String GET_SERVER_DETAILS = ""
            + "SELECT A.servergroupid, "
            + "       A.host, "
            + "       A.port, "
            + "       A.service, "
            + "       A.connection, "
            + "       A.DATABASE, "
            + "       A.databaseid, "
            + "       A.sidflag, "
            + "       B.groupname FROM SERVERS A "
            + "       LEFT JOIN SERVERGROUP B "
            + "       ON A.SERVERGROUPID=B.SERVERGROUPID "
            + "       WHERE Upper(A.SERVERGROUPID) = ? AND ROWNUM = 1";

    /**
     * Description : Returns lists of oracle dr server details for the given
     * oracle rac schema by 1. Checking if mapping exists from
     * oracleRACServerGroupId 2. If mapping exists then gets the corresponding
     * drServerGroupId 3. Then finds the serverCount for drServerGroupId 4. If
     * serverCount > 0 then gets the server details Note : This Method is Used
     * for AutoDrTransfer
     *
     * @param verticaRacServer
     * @param ds
     * @return
     * @throws CustomException
     * @throws SQLException
     * @throws Exception
     */
    /* public List<Schema> getOracleDRSchemaList(Schema oracleRacSchema, DataSource ds) throws CustomException, SQLException
    {
        // Checking oracleRacServerGroupId
        CustomException.assertEmptyString(oracleRacSchema.getServerGroupId(), "Oracle RAC Server GroupId is found Empty!!!");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int mapped = 0;
        String oracleDRServerGroupId = "";
        int oracleDRServerCount = 0;
        Schema oracleDRSchema = null;
        List<Schema> oracleDRSchemaList = new ArrayList<Schema>();
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_FOR_ORACLE_MAPPING);
            ps.setString(1, oracleRacSchema.getServerGroupId().toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                mapped = rs.getInt("mapped");
            }
            CustomException.assertEqualsZero(mapped, "No Mapping found for oracle rac server group id "
                    + oracleRacSchema.getServerGroupId().toUpperCase());
            CustomException.assertEqualsZero(mapped, "No Mapping found for "+oracleRacSchema.getServerGroupName()+ "!!");
            
            ps = cnn.prepareStatement(GET_ORACLE_DR_SERVERGROUPID);
            ps.setString(1, oracleRacSchema.getServerGroupId().toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                oracleDRServerGroupId = rs.getString("DRRAC_SERVER_GRPID");
            }
            
            ps = cnn.prepareStatement(CHECK_FOR_ORACLE_DR_SERVER);
            ps.setString(1, oracleDRServerGroupId.toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                oracleDRServerCount = rs.getInt("servercount");
            }
            CustomException.assertEqualsZero(oracleDRServerCount,
                    "There is not server under oracle dr server group id " + oracleDRServerGroupId.toUpperCase());
            
            ps = cnn.prepareStatement(GET_SERVER_DETAILS);
            ps.setString(1, oracleDRServerGroupId.toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                oracleDRSchema = (new Schema()).setServerGroupId(rs.getString("servergroupid")).setServerName(rs.getString("host"))
                        .setPort(rs.getString("port")).setService(rs.getString("service")).setConnection(rs.getString("connection"))
                        .setDatabase(rs.getString("database")).setDatabaseId(rs.getString("databaseid")).setServerGroupName(rs.getString("groupname"))
                        .setSidFlag(rs.getString("sidflag"));
                oracleDRSchemaList.add(oracleDRSchema);
            }
        } catch (SQLException e)
        {
            throw e;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        
        return oracleDRSchemaList;
    }*/
    public List<Schema> getOracleDRSchemaList(Schema oracleRacSchema, DataSource ds) throws CustomException, SQLException {
        // Checking oracleRacServerGroupId
        CustomException.assertEmptyString(oracleRacSchema.getServerGroupId(), "Oracle RAC Server GroupId is found Empty!!!");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String oracleDRServerGroupId = "";
        int oracleDRServerCount = 0;
        Schema oracleDRSchema = null;
        List<Schema> oracleDRSchemaList = new ArrayList<Schema>();
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_ORACLE_DR_SERVERGROUPID, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ps.setString(1, oracleRacSchema.getServerGroupId().toUpperCase());
            rs = ps.executeQuery();
            rs.last();
            if (rs.getRow() == 0) {
                CustomException.assertEqualsZero(rs.getRow(), "No Mapping found for " + oracleRacSchema.getServerGroupName() + "!!");
            } else {
                rs.beforeFirst();
                while (rs.next()) {
                    oracleDRServerGroupId = rs.getString("DRRAC_SERVER_GRPID");
                }

                ps = cnn.prepareStatement(GET_VIP_SERVER_DETAILS, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                ps.setString(1, oracleDRServerGroupId.toUpperCase());
                rs = ps.executeQuery();
                rs.last();
                if (rs.getRow() == 0) {
                    CustomException.assertEqualsZero(oracleDRServerCount,
                            "VIP servers not found under mapped Oracle DR Server Group Id " + oracleDRServerGroupId.toUpperCase());
                } else {
                    rs.beforeFirst();
                    while (rs.next()) {
                        oracleDRSchema = (new Schema()).setServerGroupId(rs.getString("servergroupid")).setServerName(rs.getString("host"))
                                .setPort(rs.getString("port")).setService(rs.getString("service")).setConnection(rs.getString("connection"))
                                .setDatabase(rs.getString("database")).setDatabaseId(rs.getString("databaseid")).setServerGroupName(rs.getString("groupname"))
                                .setSidFlag(rs.getString("sidflag"));
                        oracleDRSchemaList.add(oracleDRSchema);
                    }
                }
            }
        } catch (SQLException e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return oracleDRSchemaList;
    }

    private static final String CHECK_FOR_VERTICA_MAPPING = "SELECT COUNT(1) AS MAPPED FROM vtka_prod_dr_servermap WHERE UPPER(PROD_CLUSTER_GRPID) = ?";
    private static final String GET_DR_SERVERGROUPID = "SELECT DR_CLUSTER_GRPID FROM vtka_prod_dr_servermap WHERE UPPER(PROD_CLUSTER_GRPID) = ?";
    //private static final String CHECK_FOR_VERTICA_DR_SERVER = "SELECT COUNT(1) AS SERVERCOUNT FROM vtka_prod_dr_servermap WHERE UPPER(DR_CLUSTER_GRPID) = ?";
    private static final String CHECK_FOR_VERTICA_DR_SERVER = "SELECT COUNT(1) AS SERVERCOUNT FROM SERVERS WHERE UPPER(SERVERGROUPID) = ?";

    /**
     * Description : Returns lists of vertica dr server details for the given
     * vertica rac schema by 1. Checking if mapping exists from
     * verticaRACServerGroupId 2. If mapping exists then gets the corresponding
     * drServerGroupId 3. Then finds the serverCount for drServerGroupId 4. If
     * serverCount > 0 then gets the server details Note : This Method is Used
     * for AutoDrTransfer
     *
     * @param verticaRacServer
     * @param ds
     * @return
     * @throws Exception
     */
    /*public List<Schema> getVerticaDRSchemaList(Schema verticaRacSchema, DataSource ds) throws Exception
    {
        // Checking verticaRacServerGroupId
        CustomException.assertEmptyString(verticaRacSchema.getServerGroupId(), "Vertica RAC Server GroupId is found Empty!!!");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int mapped = 0;
        String verticaDRServerGroupId = "";
        int verticaDRServerCount = 0;
        Schema verticaDRSchema = null;
        List<Schema> verticaDRSchemaList = new ArrayList<Schema>();
        
        try
        {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(CHECK_FOR_VERTICA_MAPPING);
            ps.setString(1, verticaRacSchema.getServerGroupId().toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                mapped = rs.getInt("mapped");
            }
            CustomException.assertEqualsZero(mapped, "No Mapping found for vertica rac server group id "
                    + verticaRacSchema.getServerGroupId().toUpperCase());
            CustomException.assertEqualsZero(mapped, "No Mapping found for "+verticaRacSchema.getServerGroupName()+"!!");
            
            ps = cnn.prepareStatement(GET_DR_SERVERGROUPID);
            ps.setString(1, verticaRacSchema.getServerGroupId().toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                verticaDRServerGroupId = rs.getString("DR_CLUSTER_GRPID");
            }
            
            ps = cnn.prepareStatement(CHECK_FOR_VERTICA_DR_SERVER);
            ps.setString(1, verticaDRServerGroupId.toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                verticaDRServerCount = rs.getInt("servercount");
            }
            CustomException.assertEqualsZero(verticaDRServerCount,
                    "There is not server under vertica dr server group id " + verticaDRServerGroupId.toUpperCase());
            
            CustomException.assertEqualsZero(verticaDRServerCount,"No Servers found under mapped Vertica DR Server Group "+ verticaDRServerGroupId.toUpperCase());
            
            ps = cnn.prepareStatement(GET_SERVER_DETAILS);
            ps.setString(1, verticaDRServerGroupId.toUpperCase());
            rs = ps.executeQuery();
            while (rs.next())
            {
                verticaDRSchema = (new Schema()).setServerGroupId(rs.getString("servergroupid")).setServerName(rs.getString("host"))
                        .setPort(rs.getString("port")).setService(rs.getString("database")).setConnection(rs.getString("connection"))
                        .setDatabase(rs.getString("database")).setDatabaseId(rs.getString("databaseid")).setServerGroupName(rs.getString("groupname"));
                verticaDRSchemaList.add(verticaDRSchema);
            }
        } catch (Exception e)
        {
            throw e;
        } finally
        {
            DBUtil.release(cnn, ps, rs);
        }
        
        return verticaDRSchemaList;
    }*/
    /**
     * Description : Returns verticaSchema List for given verticaDRServerGroupID
     * Note: This method is used for dr only transfer to get the vertica DR
     * schema lists
     *
     * @param verticaDRServerGroupId
     * @param dSource
     * @return
     * @throws Exception
     */
    public List<Schema> getVerticaSchemaList(Schema vtkaSchema, DataSource dSource) throws Exception {
        CustomException.assertEmptyString(vtkaSchema.getServerGroupId(), "Vertica Server GroupId is found Empty!!!");
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Schema> verticaDrSchemaList = new ArrayList<Schema>();
        try {
            cnn = dSource.getConnection();
            ps = cnn.prepareStatement(GET_SERVER_DETAILS);
            ps.setString(1, vtkaSchema.getServerGroupId().toUpperCase());
            rs = ps.executeQuery();
            while (rs.next()) {
                Schema verticaDRSchema = (new Schema()).setServerGroupId(rs.getString("servergroupid")).setServerName(rs.getString("host"))
                        .setPort(rs.getString("port")).setService(rs.getString("database"))// service
                        // is
                        // set
                        // to
                        // database
                        .setConnection(rs.getString("connection")).setDatabase(rs.getString("database")).setDatabaseId(rs.getString("databaseid"))
                        .setServerGroupName(rs.getString("groupname"));
                verticaDrSchemaList.add(verticaDRSchema);
            }

            /*CustomException.assertEmptyList(verticaDrSchemaList,
                    "There are no any servers in vertica server group " + vtkaSchema.getServerGroupId().toUpperCase());*/
            CustomException.assertEmptyList(verticaDrSchemaList, "No Servers found under " + vtkaSchema.getServerGroupName() + "!!");
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

        return verticaDrSchemaList;
    }

    /**
     * Description : Used for auto dr transfer to check wheather the total table
     * count in source schema equals to sucess table count in central schema
     *
     * @param srcOrclSchema
     * @param centralSchema
     * @param execNo
     * @return
     * @throws Exception
     */
    public boolean checkTableCount(Schema srcOrclSchema, Schema centralSchema, Long execNo) throws Exception {
        Connection srcCnn = null;
        Connection centralCnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int tableCountInSrcSchema = 0;
        int tableCountInCentralSchema = 0;
        int viewCountInSrcSchema = 0;
        int viewCountInCentralSchema = 0;
        String is_transferredString = "Y";// success table count

        try {
            /*
             * CHECK TABLE COUNT IN SOURCE SCHEMA AND CENTRAL SCHEMA
             */
            srcCnn = (new OracleDBConnector()).getConnectionForSchema(srcOrclSchema);
            ps = srcCnn.prepareStatement(COUNT_TOTAL_TABLE_FROM_SOURCE_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                tableCountInSrcSchema = rs.getInt(1);
            }
            DBUtil.close(ps);
            DBUtil.close(rs);

            centralCnn = (new OracleDBConnector()).getConnectionForSchema(centralSchema);
            ps = centralCnn.prepareStatement(COUNT_QRY_CMA);
            ps.setLong(1, execNo);
            ps.setString(2, is_transferredString);
            rs = ps.executeQuery();
            while (rs.next()) {
                tableCountInCentralSchema = rs.getInt(1);
            }
            DBUtil.close(ps);
            DBUtil.close(rs);
            /*
             * This case might occur when transfer is killed from dashboard immediately after initiating it.
             * Note: Commented because this will effect retranfer case. eg. If there are no tables while re-transferring, it will not initated DR
             
            if((tableCountInCentralSchema == 0) && (tableCountInSrcSchema==0))
            {
                CustomException.assertFalse(false, "Production Transfer was not completed as a result DR Transfer is not started!!!!!!");
            }
            else*/ if (tableCountInSrcSchema != tableCountInCentralSchema) {
                CustomException.assertFalse(false, "Total table count in source schema " + srcOrclSchema
                        + " does not matches success table count in central schema " + centralSchema);
            }

            /*
             * CHECK VIEW COUNT IN SOURCE SCHEMA AND CENTRAL SCHEMA
             */
            //cnn = (new OracleDBConnector()).getConnectionForSchema(srcOrclSchema);
            ps = srcCnn.prepareStatement(COUNT_TOTAL_VIEW_FROM_SOURCE_QRY);
            rs = ps.executeQuery();
            while (rs.next()) {
                viewCountInSrcSchema = rs.getInt(1);
            }
            DBUtil.close(ps);
            DBUtil.close(rs);

            //cnn = (new OracleDBConnector()).getConnectionForSchema(centralSchema);
            ps = centralCnn.prepareStatement(GET_VIEW_COUNT_CMA);
            ps.setLong(1, execNo);
            ps.setString(2, is_transferredString);
            rs = ps.executeQuery();
            while (rs.next()) {
                viewCountInCentralSchema = rs.getInt(1);
            }
            /*
             * This case might occur when transfer is killed from dashboard immediately after initiating it.
             * NOTE: Commented because this will effect retransfer case. E.G if there are no views while re-transferring, it will not initiated DR
             * 
            if((viewCountInSrcSchema == 0) && (viewCountInCentralSchema==0))
            {
                CustomException.assertFalse(false, "Production Transfer was not completed as a result DR Transfer is not startedv!!!!!!");
            }
            else */
            if (viewCountInSrcSchema != viewCountInCentralSchema) {
                CustomException.assertFalse(false, "Total view count in source schema " + srcOrclSchema
                        + " does not matches success view count in central schema " + centralSchema);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(srcCnn, ps, rs);
            DBUtil.release(centralCnn, ps, rs);
        }
        /*if(srcCnn!=null){
        	ps = srcCnn.prepareStatement("select 1 from dual");
        }
        if(centralCnn!=null){
        	System.out.println("Central Connection not null");
        }*/

        return true;
    }

    //private static final String  GET_MAPPED_ORACLE_LIST = "SELECT RAC_SERVER_GRPID,DRRAC_SERVER_GRPID FROM ORCL_PROD_DR_SERVERMAP ORDER BY RAC_SERVER_GRPID";
    private static final String GET_MAPPED_ORACLE_LIST = ""
            + "SELECT a.rac_server_grpid, "
            + "       (SELECT groupname "
            + "        FROM   servergroup "
            + "        WHERE  servergroupid = a.rac_server_grpid) AS prod_servergroupname, "
            + "         "
            + "       a.drrac_server_grpid, "
            + "       (SELECT groupname "
            + "        FROM   servergroup "
            + "        WHERE  servergroupid = a.drrac_server_grpid) AS dr_servergroupname "
            + " "
            + "FROM   orcl_prod_dr_servermap a order by a.rac_server_grpid";

    public TreeMap<ServerGroup, ServerGroup> getOracleMappedServerGroupList(DataSource ds) throws Exception {
        TreeMap<ServerGroup, ServerGroup> mappedOracleList = new TreeMap<ServerGroup, ServerGroup>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_MAPPED_ORACLE_LIST);
            rs = ps.executeQuery();
            while (rs.next()) {
                ServerGroup orclRACServerGrp = new ServerGroup().setServerGroupId(rs.getString("rac_server_grpid")).setGroupName(
                        rs.getString("prod_servergroupname"));
                ServerGroup orclDRServerGrp = new ServerGroup().setServerGroupId(rs.getString("drrac_server_grpid")).setGroupName(
                        rs.getString("dr_servergroupname"));
                mappedOracleList.put(orclRACServerGrp, orclDRServerGrp);

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return mappedOracleList;
    }

    //private static final String  GET_MAPPED_VERTICA_LIST = "SELECT PROD_CLUSTER_GRPID,DR_CLUSTER_GRPID FROM VTKA_PROD_DR_SERVERMAP ORDER BY PROD_CLUSTER_GRPID";
    private static final String GET_MAPPED_VERTICA_LIST = ""
            + "SELECT a.PROD_CLUSTER_GRPID, "
            + "       (SELECT groupname FROM "
            + "       servergroup WHERE servergroupid = a.PROD_CLUSTER_GRPID) AS prod_servergroupname, "
            + "       a.DR_CLUSTER_GRPID, "
            + "       (SELECT groupname FROM "
            + "       servergroup WHERE servergroupid = a.DR_CLUSTER_GRPID) AS dr_servergroupname "
            + "       FROM  VTKA_PROD_DR_SERVERMAP a ORDER BY a.PROD_CLUSTER_GRPID";

    public TreeMap<String, String> getVerticaMappedServerGroupList(DataSource ds) throws Exception {
        TreeMap<String, String> mappedOracleList = new TreeMap<String, String>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_MAPPED_VERTICA_LIST);
            rs = ps.executeQuery();
            while (rs.next()) {
                mappedOracleList.put(rs.getString("prod_servergroupname"), rs.getString("dr_servergroupname"));

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return mappedOracleList;
    }

    private static final String GET_MAPPED_VERTICA_CLUSTERGRP_LIST = ""
            + "SELECT a.prod_cluster_grpid, "
            + "       (SELECT groupname "
            + "        FROM   clustergroup "
            + "        WHERE  clustergroupid = a.prod_cluster_grpid) AS prod_clustergroupname, "
            + "       a.dr_cluster_grpid, "
            + "       (SELECT groupname "
            + "        FROM   clustergroup "
            + "        WHERE  clustergroupid = a.dr_cluster_grpid)   AS dr_clustergroupname "
            + "FROM   vtka_prod_dr_clustermap a "
            + "ORDER  BY a.prod_cluster_grpid";

    /**
     * @Description: Returns list of mapped PROD/DR cluster Groups
     * @param ds
     * @return
     * @throws Exception
     */
    public TreeMap<ClusterGroup, ClusterGroup> getVerticaMappedClusterGroupList(DataSource ds) throws Exception {
        TreeMap<ClusterGroup, ClusterGroup> mappedVerticaList = new TreeMap<ClusterGroup, ClusterGroup>();
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(GET_MAPPED_VERTICA_CLUSTERGRP_LIST);
            rs = ps.executeQuery();
            while (rs.next()) {
                ClusterGroup prodClusterGroup = new ClusterGroup().setClusterGroupId(rs.getString("prod_cluster_grpid"))
                        .setGroupName(rs.getString("prod_clustergroupname"));
                ClusterGroup drClusterGroup = new ClusterGroup().setClusterGroupId(rs.getString("dr_cluster_grpid"))
                        .setGroupName(rs.getString("dr_clustergroupname"));
                mappedVerticaList.put(prodClusterGroup, drClusterGroup);

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return mappedVerticaList;
    }

    private static final String DELETE_ORCL_SERVERGRP_MAPPING = "" + "DELETE orcl_prod_dr_servermap "
            + "WHERE rac_server_grpid = ? AND drrac_server_grpid = ?";

    /**
     * @Description: Deletes an existing vtka cluster grp mapping
     * @param ds
     * @param prodVtkaClusterGrpId
     * @param drVtkaClusterGrpId
     * @return
     * @throws Exception
     */
    public int deleteOrclServerGrpMapping(DataSource ds, String orclRACServerGrpId, String orclDRServerGrpId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_ORCL_SERVERGRP_MAPPING);
            ps.setString(1, orclRACServerGrpId);
            ps.setString(2, orclDRServerGrpId);
            return ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

    }

    private static final String DELETE_VTKA_CLUSTERGRP_MAPPING = ""
            + "DELETE vtka_prod_dr_clustermap WHERE Upper(prod_cluster_grpid) = ? "
            + "AND Upper(dr_cluster_grpid) = ? ";

    /**
     * @Description: Deletes an existing vtka cluster grp mapping
     * @param ds
     * @param prodVtkaClusterGrpId
     * @param drVtkaClusterGrpId
     * @return
     * @throws Exception
     */
    public int deleteVtkaClusterGrpMapping(DataSource ds, String prodVtkaClusterGrpId, String drVtkaClusterGrpId) throws Exception {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_VTKA_CLUSTERGRP_MAPPING);
            ps.setString(1, prodVtkaClusterGrpId);
            ps.setString(2, drVtkaClusterGrpId);
            return ps.executeUpdate();
        } catch (Exception e) {
            throw e;
        } finally {
            DBUtil.release(cnn, ps, rs);
        }

    }

    private static final String UPDATE_ISDELETED_FLAG = "UPDATE platform_schema_info  SET isdeleted = ? WHERE isdeleted = 'N' and dbuserid = ? and databaseid IN  (SELECT a.databaseid FROM servers a "
            + "  join servergroup b "
            + "  ON a.servergroupid = b.servergroupid "
            + "  WHERE b.servergroupid = ? "
            + ")";

    /**
     * @Description : Updates isdeleted flag for all the servers in a server
     * groupid
     * @param ds
     * @param serverGroupId
     * @return
     */
    public int updateIsDeletedFlag(DataSource ds, Schema schema, String isDeleted) {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(UPDATE_ISDELETED_FLAG);
            ps.setString(1, isDeleted);
            ps.setString(2, schema.getSchemaName());
            ps.setString(3, schema.getServerGroupId());
            count = ps.executeUpdate();
        } catch (Exception e) {
            logger.error("Could not updated isdeleted flag for server group id " + schema + isDeleted, e);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }

    private static final String DELETE_PWD_ENTRY = "DELETE FROM platform_schema_info a "
            + "WHERE a.databaseid IN (SELECT databaseid FROM servers b WHERE b.servergroupid = ?) "
            + "AND a.dbuserid = ? "
            + "AND a.isdeleted = 'N'";

    /**
     * @Description: Deletes the password entry for all the server found in the
     * server group
     * @param ds
     * @param schema
     * @return
     */
    public int deletePwdEntry(DataSource ds, Schema schema) {
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int count = 0;
        try {
            cnn = ds.getConnection();
            ps = cnn.prepareStatement(DELETE_PWD_ENTRY);
            ps.setString(1, schema.getServerGroupId());
            ps.setString(2, schema.getSchemaName());
            count = ps.executeUpdate();
        } catch (Exception e) {
            logger.error("Could not delete pwd entry for schema " + schema, e);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return count;
    }
}
