package dashboard.db;

import java.io.PrintWriter;
import java.io.StringWriter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;
import java.util.LinkedList;
import java.sql.Timestamp;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLWarning;

import dashboard.engine.EventLogger;

import dashboard.data.LogData;
import dashboard.data.Schema;

public class OracleEventLogger implements EventLogger {

    protected Log logger = LogFactory.getLog(getClass());

    
    private DataSource dataSource = null;
    
    public void setDataSource(DataSource ds) {
        dataSource = ds;
    }

    private static final int MAX_DESC_LEN = 300;
    private static final int MAX_ERMSG_LEN = 500;
    private static final String BLANK = "";

    private static final String LOG_START =
        " insert into ProcessEventLog(LoginName,EventName, EventDesc, ThreadCount, StartTime, " +
        " ServerGroupId,Host,Port,Service,SIDFlag, SchemaName,engineversion,executionNumber) " +
        " values(?,?,?,?,?, ?,?,?,?,?, ?,?,?)";
    public void logStart(String user, String event, String desc, int threadCount, Date startDate, Schema schema ,Long executionId) {
        Connection cnn = null;
        PreparedStatement ps = null;
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(LOG_START);
            ps.setString(1, user);
            ps.setString(2, event);
            ps.setString(3, limitStringLength(desc, MAX_DESC_LEN) );
            ps.setInt(4, threadCount);

            ps.setTimestamp(5, getTS(startDate ) );

            ps.setString(6, (schema==null)? BLANK: schema.getServerGroupId());
            ps.setString(7, (schema==null)? BLANK: schema.getServerName());
            ps.setString(8, (schema==null)? BLANK: schema.getPort());
            ps.setString(9, (schema==null)? BLANK: schema.getService());
            ps.setString(10, (schema==null)? BLANK: schema.getSidFlag());
            ps.setString(11, (schema==null)? BLANK: schema.getSchemaName());  
            ps.setString(12, (schema==null)? BLANK: schema.getEngineVersion());
            ps.setLong(13, executionId); 
            ps.executeUpdate();

        } catch(Exception ex) {
            logger.error("Error log start: <user>" + user + " <event> " + event
                         + " <desc> " + desc + " <threadcount> " +  threadCount
                         + " <startDate> " + startDate , ex);
        } finally {
            DBUtil.release(cnn, ps, null);
        }
    }

    private static final String UPDATE_LOG_END =
        "update ProcessEventLog " +
        "   set EndTime = ?, RetStatus = ? " +
        " where LoginName = ?  and EventName = ? and EventDesc = ? and ThreadCount = ? "  +
        "   and StartTime = ? ";
    
    private static final String INSERT_LOG_END = 
        "insert into ProcessEventLog(LoginName,EventName, EventDesc, ThreadCount, StartTime, EndTime, RetStatus, " +
        " ServerGroupId,Host,Port,Service,SIDFlag,SchemaName,engineversion) " +
        " values(?,?,?,?,?,?,?, ?,?,?,?,?,?,? )";

        
    public void logEnd(String user, String event, String desc, int threadCount, Date startDate, Date endDate,
                       int retStatus, Schema schema ) {
        Connection cnn = null;
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;

        PreparedStatement psT = null;
        ResultSet rsT = null;
        
        int retVal = -1;
        try {
            cnn = dataSource.getConnection();

            
            ps = cnn.prepareStatement(UPDATE_LOG_END);
            
            ps.setTimestamp(1,  getTS(endDate));
            ps.setInt(2, retStatus);
            ps.setString(3, user);
            ps.setString(4, event);
            ps.setString(5, limitStringLength(desc, MAX_DESC_LEN));
            ps.setInt(6, threadCount);
            ps.setTimestamp(7,  getTS(startDate ) );

            retVal = ps.executeUpdate();
            
            if (retVal < 1) {
                ps1 = cnn.prepareStatement(INSERT_LOG_END);
                ps1.setString(1, user);
                ps1.setString(2, event);
                ps1.setString(3, desc);
                ps1.setInt(4, threadCount);
                ps1.setTimestamp(5,  getTS(startDate ) );
                ps1.setTimestamp(6,  getTS(endDate ) );
                ps1.setInt(7, retStatus);

                ps1.setString(8, (schema==null)? BLANK: schema.getServerGroupId());
                ps1.setString(9, (schema==null)? BLANK: schema.getServerName());
                ps1.setString(10, (schema==null)? BLANK: schema.getPort());
                ps1.setString(11, (schema==null)? BLANK: schema.getService());
                ps1.setString(12, (schema==null)? BLANK: schema.getSidFlag());
                ps1.setString(13, (schema==null)? BLANK: schema.getSchemaName());
                ps1.setString(14, (schema==null)? BLANK: schema.getEngineVersion());
                logger.info("calling log update.");
                retVal = ps1.executeUpdate();

            }
        } catch(Exception ex) {
            logger.error("Error log end: <user>" + user + " <event> " + event
                         + " <desc> " + desc + " <threadcount> " +  threadCount
                         + " <startDate> " + startDate , ex);
        } finally {
            DBUtil.release(null, psT, rsT);
            DBUtil.release(null, ps1, null);            
            DBUtil.release(cnn, ps, null);
        }
    }
    private static final String UPDATE_LOG_ERROR =
        "update ProcessEventLog " +
        "   set EndTime = ?, SysMessage = ? " +
        " where LoginName = ? and EventName = ? and EventDesc = ? and ThreadCount = ? " +
        "   and StartTime = ? ";
    
    private static final String INSERT_LOG_ERROR = 
        "insert into ProcessEventLog(LoginName,EventName, EventDesc, ThreadCount, StartTime, EndTime, SysMessage, " +
        " ServerGroupId,Host,Port,Service,SIDFlag,SchemaName,engineversion) " +
        " values(?,?,?,?,?,?,?, ?,?,?,?,?,?,? )";

    public void logError(String user, String event, String desc, int threadCount, Date startDate, Date endDate,
                         Exception ex, Schema schema) {
        String exStr = "";
        if (null != ex) {
            StringWriter sw = new StringWriter(1000);
            ex.printStackTrace( new PrintWriter(sw));
            exStr = ex.getMessage() + ": "  + sw.toString();
            exStr = limitStringLength(exStr, MAX_ERMSG_LEN);
        }
        logError( user, event, desc, threadCount, startDate, endDate, exStr, schema);
    }
    public void logError(String user, String event, String desc, int threadCount, Date startDate, Date endDate,
                         String exStr, Schema schema) {
        Connection cnn = null;
        PreparedStatement ps = null;
        PreparedStatement ps1 = null;
        int retVal = -1;
        logger.info("calling log Error. trying update");
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(UPDATE_LOG_ERROR);
            
            ps.setTimestamp(1,  getTS(endDate));
            ps.setString(2, limitStringLength(exStr, MAX_DESC_LEN));
            ps.setString(3, user);
            ps.setString(4, event);
            ps.setString(5, limitStringLength(desc, MAX_ERMSG_LEN));
            ps.setInt(6, threadCount);
            ps.setTimestamp(7,  getTS(startDate ) );
            retVal = ps.executeUpdate();

            if (retVal < 1) {
                ps1 = cnn.prepareStatement(INSERT_LOG_ERROR);
                ps1.setString(1, user);
                ps1.setString(2, event);
                ps1.setString(3, limitStringLength(desc, MAX_DESC_LEN));
                ps1.setInt(4, threadCount);
                ps1.setTimestamp(5,  getTS(startDate ) );
                ps1.setTimestamp(6,  getTS(endDate ) );
                ps1.setString(7, limitStringLength(exStr, MAX_DESC_LEN));

                ps1.setString(8, (schema==null)? BLANK: schema.getServerGroupId());
                ps1.setString(9, (schema==null)? BLANK: schema.getServerName());
                ps1.setString(10, (schema==null)? BLANK: schema.getPort());
                ps1.setString(11, (schema==null)? BLANK: schema.getService());
                ps1.setString(12, (schema==null)? BLANK: schema.getSidFlag());
                ps1.setString(13, (schema==null)? BLANK: schema.getSchemaName());
                ps1.setString(14, (schema==null)? BLANK: schema.getEngineVersion());


                retVal = ps1.executeUpdate();
            }
        } catch(Exception exLogError) {
            logger.error("Error log update: <user>" + user + " <event> " + event
                         + " <desc> " + desc + " <threadcount> " +  threadCount
                         + " <startDate> " + startDate , exLogError);
        } finally {
            DBUtil.release(null, ps1, null);
            DBUtil.release(cnn, ps, null);
        }
    }
    
	private static final String UPDATE_LOG_ERROR_DR_TRANSFER = "update ProcessEventLog "
			+ "   set EndTime = ?, SysMessage = ? "
			+ " where executionnumber = ?";

	/* 
	 * Used in logging error when dr transfer is being killed 
	 */
	public void logErrorForDrTransfer(Date endDate, String exStr,
			String executionNumber) {
		Connection cnn = null;
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		int retVal = -1;
		logger.info("calling log Error for dr transfer. trying update");
		try {
			cnn = dataSource.getConnection();
			ps = cnn.prepareStatement(UPDATE_LOG_ERROR_DR_TRANSFER);

			ps.setTimestamp(1, getTS(endDate));
			ps.setString(2, limitStringLength(exStr, MAX_DESC_LEN));
			ps.setString(3, executionNumber);
			retVal = ps.executeUpdate();
		} catch (Exception exLogError) {
			logger.error("Error while logging error for Dr Transfer for execution number "
					+ executionNumber);
			System.out.println("Error while logging error for Dr Transfer");
			System.out.println(exLogError);
		} finally {
			DBUtil.release(null, ps1, null);
			DBUtil.release(cnn, ps, null);
		}
	}

    private static final int STACK_SIZE = 100;
    public Object []  showLogForUser(String filterString, int _page, DateFormat df)
        throws Exception {
        List ls = new LinkedList();
        int page = 0;
        int rowPos = 1;
        int rowCount = 1;
        Boolean availableMore = Boolean.FALSE;
        if ( _page > 0) {
            page = _page;
            rowPos = page * STACK_SIZE;
        }
        Connection cnn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;       
        String totRec="0";
        
        String qryString = 
        	"select LoginName,EventName, EventDesc, ThreadCount, StartTime, EndTime, RetStatus, SysMessage, " +
	        " ServerGroupId,Host,Port,Service,SIDFlag, SchemaName, engineVersion ,executionNumber" +
	        " from ProcessEventLog where (1=1) " +filterString+
	        " order by StartTime desc,endtime desc ";
        
        try {
            cnn = dataSource.getConnection();
            ps = cnn.prepareStatement(qryString, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = ps.executeQuery();

            if (rowPos > 1) {
                rs.absolute(rowPos);
            }

            while(rs.next() && rowCount <= STACK_SIZE ) {
                LogData lgData = (new LogData())
                    .setLoginName( rs.getString(1))
                    .setEventName( rs.getString(2))
                    .setEventDesc( rs.getString(3))
                    .setThreadCount( rs.getInt(4))
                    .setStartTime( rs.getTimestamp(5))
                    .setEndTime( rs.getTimestamp(6))
                    .setReturnValue( rs.getString(7))
                    .setSysMessage( rs.getString(8))
                    .setDateFormat( df)
                    .setServerGroupId( rs.getString(9))
                    .setHost( rs.getString(10))
                    .setPort( rs.getString(11))
                    .setService( rs.getString(12))
                    .setSidFlag( rs.getString(13))
                    .setSchemaName( rs.getString(14))	
                	.setEngineVersion(rs.getString(15))
                	.setExecutionNumber(rs.getLong(16));
                
                rowCount++;
                ls.add( lgData);
            }            

            if (rowCount >= STACK_SIZE && rs.next() ) {
                availableMore = Boolean.TRUE;
            }
            ps = cnn.prepareStatement("select count(*) from ("+qryString+")", ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = ps.executeQuery();
            
            if(rs.next()){
            	totRec =rs.getString(1);
            }

        } catch (Exception ex) {
            logger.error("showLogForUser filterString: " + filterString + " page "+ _page, ex);
        } finally {
            DBUtil.release(cnn, ps, rs);
        }
        return new Object[] { availableMore, ls, totRec};
    }

    private static Timestamp getTS( Date d) {
        Timestamp ts = new Timestamp(d.getTime());
        ts.setNanos(0);
        return ts;
    }

    private static SimpleDateFormat dateCompareFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private static String dateToString(Date d) {
        return dateCompareFormat.format(d);
    }

    private static String limitStringLength(String s, int len) {
        if ( null == s || len <= 0) {
            return "";
        }
        if (s.length() < len )
            return s;
        return s.substring(0, len);
    }
}
