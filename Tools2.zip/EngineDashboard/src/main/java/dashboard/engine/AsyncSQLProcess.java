package dashboard.engine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.JSchException;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.TaskTypeNFile;
import dashboard.db.FixedParameter;
import dashboard.db.VerticaDB;
import dashboard.engine.oracle.CustomProcedureExecutor;
import dashboard.util.CmdRunner;
import dashboard.util.Constants;
import dashboard.util.EDBUtil;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;
import dashboard.util.InsertExceptionToLogger;
import dashboard.util.Mail;
import dashboard.util.Message;
import dashboard.util.RunShellScript;
import dashboard.web.util.CustomException;

public class AsyncSQLProcess implements Runnable {

    private volatile StringBuffer sb;
    private volatile StringBuffer dxSb;
    private static final int INIT_BUFFER_SIZE = 3000;
    private volatile SQLProcessStatus status = null;
    private String SQL_PLUS = null;
    private ComponentFactory compFactory;
    private EnvInfo env = null;
    private boolean isTargetURLEmpty = true;
    private String targetURL = "";
    private String jobId = "";

    private boolean allowRun = true;

    protected Log logger = LogFactory.getLog(getClass());

    protected static final String ORA_PATTERN = "(ORA-\\d+:.*?\\\\n)";

    private static final String DATE_PATTERN = "MMM d, yyyy HH:mm a, zzzz";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat(
            DATE_PATTERN);
    private EventLogger eventLogger = null;
    private FixedParameter fixedParam = null;
    private Mail mail = null;

    public AsyncSQLProcess() {
        sb = new StringBuffer(INIT_BUFFER_SIZE);
        status = SQLProcessStatus.INIT;
        compFactory = ComponentFactory.getInstance();
        env = compFactory.getEnvInfo();
        SQL_PLUS = env.getSqlPlusPath();
        eventLogger = compFactory.getEventLogger();
        fixedParam = compFactory.getFixedParameters();
        mail = new Mail();
    }

    private AsyncSQLProcessRegistry registry = null;
    private TaskKey taskKey = null;
    private TaskTypeNFile taskTypeNFile = null;

    public AsyncSQLProcess setAsyncSQLProcessRegistry(TaskKey key,
            AsyncSQLProcessRegistry reg) {
        if (null != registry) {
            throw new IllegalArgumentException(
                    "AsyncSQLProcssRegistry already set.");
        }
        if (reg == null || key == null) {
            throw new NullPointerException("Null key or registry.");
        }
        registry = reg;
        taskKey = key;
        Date startDate = new Date(System.currentTimeMillis());
        taskKey.setStartDate(startDate);
        return this;
    }

    private SQLPlusRunnable sqlplusRunnable = null;

    public AsyncSQLProcess setSQLPlusRunnable(SQLPlusRunnable sqlPlusR) {
        sqlplusRunnable = sqlPlusR;
        return this;
    }

    public SQLPlusRunnable getSQLPlusRunnable() {
        return sqlplusRunnable;
    }

    private static final int INIT_SLEEP = 1000;
    Runtime rt = null;
    volatile Process ps = null;
    File scriptFile = null;

    private Date startDate = null;
    private Date endDate = null;

    private boolean isKill = false;
    private boolean isKilled = false;

    public void run() {
        InputStream is = null;
        int retVal = -100;
        status = SQLProcessStatus.STARTED;
        sqlplusRunnable.setStatus(status);
        taskKey.setSQLProcessStatus(status);

        List ls = null;
        List invalidProcList = null;
        startDate = new Date(System.currentTimeMillis());
        boolean isShellScript = false;
        try {
            Thread.sleep(INIT_SLEEP);
            status = SQLProcessStatus.SCRIPT_MODIFY;
            sqlplusRunnable.init();
            status = SQLProcessStatus.RUNNING;

            ls = sqlplusRunnable.getTaskTypeNFileList();
            String sqlPlusUrl = sqlplusRunnable.getSQLPlusUrl();
            Schema srcSchema = sqlplusRunnable.getSrcSchema();
            Schema destSchema = sqlplusRunnable.getSchema();

            if (ls != null && !ls.isEmpty()) {
                Iterator it = ls.iterator();
                while (allowRun && it.hasNext()) {
                    sb.delete(0, sb.length()); // clear error log.

                    taskTypeNFile = (TaskTypeNFile) it.next();
                    taskKey.setTaskType(taskTypeNFile.getTaskType());

                    sqlplusRunnable.setStatus(status);
                    sqlplusRunnable.setTaskType(taskTypeNFile.getTaskType());
                    sqlplusRunnable.setSubTaskType(taskTypeNFile
                            .getSubTaskType());
                    taskKey.setSQLProcessStatus(status);
                    invalidProcList = sqlplusRunnable
                            .getBeforeInvalidProcList();

                    scriptFile = taskTypeNFile.getScriptFile();
                    startDate = new Date(System.currentTimeMillis());

                    taskTypeNFile.setStarted(true);
                    // for both CMA and DMEXPRES
                    if ((destSchema.getHostingServer()
                            .equalsIgnoreCase(Constants.VERTICA))
                            || (destSchema.getHostingServer()
                            .equalsIgnoreCase(Constants.VERTICA_CMA))
                            || (destSchema.getHostingServer()
                            .equalsIgnoreCase(Constants.VERTICA_DR_CMA))) {
                        // logger.info("Inside Vertica from AsyncSQLProcess.java>>>>>>>>>>>>>>>>");
                        /**
                         * start event log for vertica (Source Schema is Passed
                         * here)
                         *
                         */
                        eventLogger.logStart(taskKey.getUserName(),
                                sqlplusRunnable.getTaskType().getTaskLabel(),
                                sqlplusRunnable.getDescription(),
                                sqlplusRunnable.getThreadCount(), startDate,
                                sqlplusRunnable.getSrcSchema(),
                                sqlplusRunnable.getExecutionId());

                        isShellScript = true;
                        retVal = 0;
                        if (sqlplusRunnable.isCreateVerticaSchema()) {
                            List<String> verticaSchemaParams = sqlplusRunnable
                                    .getVerticaSchemaParams();
                            createVerticaSchema(destSchema, taskTypeNFile,
                                    retVal, verticaSchemaParams);
                        } else {
                            // logger.info("Inside else condition for vertica from AsyncSQLProcess.java>>>>>>>>>>>>>");
                            Long executionNumber = sqlplusRunnable
                                    .getExecutionId();

                            // For Oracle To Vertica Data Transfer Using
                            // DMexpress
                            if (destSchema.getHostingServer().equalsIgnoreCase(
                                    Constants.VERTICA)) {
                                Schema dmExpressSchema = sqlplusRunnable
                                        .getDmExpressSchema();
                                int threadCount = sqlplusRunnable
                                        .getThreadCount();
                                oracleToVerticaDataTransferUsingDMExpress(
                                        srcSchema, destSchema, dmExpressSchema,
                                        threadCount, taskTypeNFile, is, retVal,
                                        executionNumber);
                            } // For Oracle To Vertica Data Transfer Using CMA
                            else if (destSchema.getHostingServer()
                                    .equalsIgnoreCase(Constants.VERTICA_CMA)) {
                                oracleToVerticaDataTransferUsingCMA(srcSchema,
                                        destSchema, taskTypeNFile, is, retVal,
                                        executionNumber);
                            } // For Oracle To DR Vertica Data Transfer Using CMA
                            else if (destSchema.getHostingServer()
                                    .equalsIgnoreCase(Constants.VERTICA_DR_CMA)) {
                                // logger.info("Trying to call shellscript for vertica DR from ASyncSQLProcess>>>>>>>>>>>>>");
                                oracleToVerticaDRDataTransferUsingCMA(
                                        srcSchema, destSchema, taskTypeNFile,
                                        is, retVal, executionNumber);
                            }
                        }
                    } else if (invalidProcList.isEmpty()) {
                        // logger.info("Invalid Proc List is Empty from ASyncSQLProcess>>>>>>>>>>>>>");
                        eventLogger.logStart(taskKey.getUserName(),
                                sqlplusRunnable.getTaskType().getTaskLabel(),
                                sqlplusRunnable.getDescription(),
                                sqlplusRunnable.getThreadCount(), startDate,
                                sqlplusRunnable.getSchema(),
                                sqlplusRunnable.getExecutionId());

                        rt = Runtime.getRuntime();
                        String execString = "";

                        logger.debug("taskTypeNFile.isRunAtSource()? "
                                + taskTypeNFile.isRunAtSource());
                        if (taskTypeNFile.isRunAtSource()) {
                            sqlPlusUrl = sqlplusRunnable.getSrcSQLPlusUrl();
                        } else if (taskTypeNFile.isRunAtFQCServer()) {
                            sqlPlusUrl = sqlplusRunnable.getSQLPlusUrlForFQC();
                        } else if (taskTypeNFile.isRunAtStaginServer()) {
                            sqlPlusUrl = sqlplusRunnable.getStagingSQLPlusUrl();
                        } else {
                            sqlPlusUrl = sqlplusRunnable.getSQLPlusUrl();
                        }

                        if (taskTypeNFile.isShellScript()) {
                            isShellScript = true;
                            execString = scriptFile.getAbsolutePath();
                            ps = rt.exec("chmod 775 " + execString);
                            ps.waitFor();
                        } else {
                            execString = SQL_PLUS + " -L " + sqlPlusUrl + " @"
                                    + scriptFile.getAbsolutePath();
                        }

                        System.out.println("[Runtime EXEC STR ::>] "
                                + execString);

                        ps = rt.exec(execString);
                        is = ps.getInputStream();
                        int c = 0;

                        while ((c = is.read()) != -1) {
                            // System.out.print((char)c);
                            sb.append((char) c);
                        }

                        is.close();
                        is = null;

                        retVal = ps.waitFor();
                        ps = null;

                        endDate = new Date(System.currentTimeMillis());
                        logger.info("RUN: start date: " + startDate
                                + " endDate: " + endDate);
                        Object[] isError = new Object[]{Boolean.FALSE, ""};

                        if (taskTypeNFile.isShellScript()) {
                            isError = getShellError(sb.toString());
                        } else if (!taskTypeNFile.isAvoidOraError()) {
                            isError = getOraError(sb.toString());
                        }

                        if (Boolean.TRUE.equals(isError[0])) {
                            String error = (String) isError[1];
                            taskTypeNFile.setFailure(true);
                            // sending Mail
                            if (taskTypeNFile.isSendMail()) {
                                sendMail(taskTypeNFile, srcSchema, destSchema,
                                        error);
                            }
                            // to halt other processes from list when ORA error
                            if (taskTypeNFile.isHaltProcessWhenOraError()) {
                                logger.error("Halt Process for "
                                        + taskTypeNFile.getTaskType()
                                        + " with ORA Error " + error);
                                allowRun = true;
                                throw new CustomException(error);
                            }
                            // event logging
                            eventLogger.logError(taskKey.getUserName(),
                                    sqlplusRunnable.getTaskType()
                                    .getTaskLabel(), sqlplusRunnable
                                    .getDescription(), sqlplusRunnable
                                    .getThreadCount(), startDate,
                                    endDate, (String) isError[1],
                                    sqlplusRunnable.getSchema());
                            /*
							 * // for warehouse tasks
							 * if(taskTypeNFile.isWareHouseTasks()){ // writing
							 * creating synonym output to file
							 * logger.error(error); writeToFile(scriptFile,
							 * isShellScript, sb); allowRun = true; throw new
							 * CustomException(error); }
                             */
                        } else {
                            taskTypeNFile.setCompleted(true);
                            eventLogger.logEnd(taskKey.getUserName(),
                                    sqlplusRunnable.getTaskType()
                                    .getTaskLabel(), sqlplusRunnable
                                    .getDescription(), sqlplusRunnable
                                    .getThreadCount(), startDate,
                                    endDate, retVal, sqlplusRunnable
                                    .getSchema());
                        }
                        sb.append("\n---------------------------")
                                .append("\n--- PROCESS complete: " + retVal)
                                .append("\n-------------------------\n");
                        sb.append("\nCompleted at: "
                                + dateFormat.format(endDate) + "\n");

                        logger.info("PROCESS COMPLETED!!!!!!!!!!!!!!!!!!!!!!"
                                + retVal);

                        invalidProcList = sqlplusRunnable
                                .getAfterInvalidProcList();
                        if (!invalidProcList.isEmpty()) {
                            allowRun = false;
                            sb = appendInvalidProcs(sb, invalidProcList);
                            throw new InvalidProcListException(sqlplusRunnable
                                    .getTaskType().getTaskName(),
                                    invalidProcList);
                        }
                    } else {
                        allowRun = false;
                        sb = appendInvalidProcs(sb, invalidProcList);
                        throw new InvalidProcListException(sqlplusRunnable
                                .getTaskType().getTaskName(), invalidProcList);
                    }

                    // sending Mail
                    if (taskTypeNFile.isSendMail()) {
                        sendMail(taskTypeNFile, srcSchema, destSchema, "");
                    }
                    // Always write ouput file
                    if (taskTypeNFile.isAlwaysWriteOutputFile()) {
                        logger.info("Inside Always write output file for task "
                                + taskTypeNFile.getTaskType());
                        writeToFile(scriptFile, isShellScript, sb);
                    }
                    // logger.info("After Sending mail>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                    /*
					 * // for warehouse tasks
					 * if(taskTypeNFile.isWareHouseTasks()){ // writing creating
					 * synonym output to file writeToFile(scriptFile,
					 * isShellScript, sb); }
                     */
                }
            }
            status = SQLProcessStatus.COMPLETE;
            sqlplusRunnable.setStatus(status);
            taskKey.setSQLProcessStatus(status);

            sb.append("\n------------------------------------------\n")
                    .append("   ***** COMPLETED (NOMORE IN PROCESS) **** ")
                    .append("\n------------------------------------------\n");
            // logger.info("End of AysnSQLProcess.java>>>>>>>>>>>>>>>>>>>");
        } catch (Exception e) {
            // logger.info("Exception at run.", e);
            endDate = new Date(System.currentTimeMillis());
            if (allowRun) {
                status = SQLProcessStatus.FAILED;
                sqlplusRunnable.setStatus(status);
                sb.append("\n----------------------------------")
                        .append("\n-- process failed..")
                        .append("\n---------------------------------");

                sb.append("\n--[STACK TRACE\n");
                StringWriter sw = new StringWriter(1000);
                e.printStackTrace(new PrintWriter(sw));
                sb.append(sw.toString());
                sb.append("\n END STACK]\n");

            }
            sb.append("\nException at: " + dateFormat.format(endDate) + "\n");
            if (!isKill || (isKill && !isKilled)) {
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, e, sqlplusRunnable.getSchema());
            }
            // writing output to file
            if (taskTypeNFile != null && taskTypeNFile.isAlwaysWriteOutputFile()) {
                try {
                    writeToFile(scriptFile, isShellScript, sb);
                } catch (Exception e1) {
                    logger.error("Error while writing file in catch ", e1);
                }
            }
            release();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (Exception ex) {
                }
            }
            if (("N".equalsIgnoreCase(taskKey.getDxCGProcessed()) || ""
                    .equalsIgnoreCase(taskKey.getDxCGProcessed()))
                    && status == SQLProcessStatus.COMPLETE) {
                release();
            }
            // to remove completed thread from taskKey
            if (taskKey.getSQLProcessStatus().equals(SQLProcessStatus.COMPLETE)) {
                release();
            }
            if ("Y".equalsIgnoreCase(taskKey.getDxCGProcessed()) && dxSb != null) {
                String dxString = dxSb.toString();
                if (dxString.contains("DxCG Processing Completed")
                        && status == SQLProcessStatus.COMPLETE) {
                    release();
                }
            }
            try {
                if (scriptFile != null) {

                    String outputFilePath = scriptFile.getAbsolutePath();
                    if (taskKey.getTaskType().getID()
                            .indexOf(TaskType.PROCESS_SCRIPT_OR_REPORT.getID()) != -1) {
                        outputFilePath = outputFilePath.substring(0,
                                outputFilePath.lastIndexOf(".rp"));
                        outputFilePath += ".rp.sql";
                    }
                    if (taskKey.getTaskType().getID()
                            .indexOf(TaskType.EXECUTE_IMPORT.getID()) != -1) {
                        outputFilePath = outputFilePath.substring(0,
                                outputFilePath.lastIndexOf(".imprt"));
                        outputFilePath += ".imprt.sql";
                    }
                    if (taskKey.getTaskType().getID()
                            .indexOf(TaskType.EXECUTE_SCRUB.getID()) != -1) {
                        outputFilePath = outputFilePath.substring(0,
                                outputFilePath.lastIndexOf(".scrb"));
                        outputFilePath += ".scrb.sql";
                    }

                    String outputTitle = isShellScript ? "\n--Last output from Shell Script*\n"
                            : "\n--Last output from sqlPlus*\n";

                    if (sqlplusRunnable.isWriteOutputFile()) {
                        Schema srcSchema = sqlplusRunnable.getSrcSchema();
                        Schema destSchema = sqlplusRunnable.getSchema();

                        // writing shell script output to local file
                        if ((!sqlplusRunnable.isCreateVerticaSchema())
                                && ((destSchema.getHostingServer()
                                .equalsIgnoreCase(Constants.VERTICA))
                                || (destSchema.getHostingServer()
                                .equalsIgnoreCase(Constants.VERTICA_CMA)) || (destSchema
                                .getHostingServer()
                                .equalsIgnoreCase(Constants.VERTICA_DR_CMA)))) {
                            // read shell output from remote server and store it
                            // locally
                            IOUtils.copy(new VerticaDB()
                                    .getVerticaOutputStream(
                                            sqlplusRunnable.getExecutionId(),
                                            srcSchema.getServerName(),
                                            destSchema.getHostingServer()),
                                    new FileOutputStream(outputFilePath));
                        } // if creating vertica schema from schema admin then
                        // store it to local file
                        else if ((sqlplusRunnable.isCreateVerticaSchema())
                                && ((destSchema.getHostingServer()
                                .equalsIgnoreCase(Constants.VERTICA)) || (destSchema
                                .getHostingServer()
                                .equalsIgnoreCase(Constants.VERTICA_CMA)))) {
                            String output = sqlplusRunnable
                                    .hidePasswordsForVertica(sb.toString(),
                                            destSchema.getHostingServer());
                            FileUtil.writeToTextFile(outputTitle + output,
                                    new File(outputFilePath + "._out"));
                        } else {
                            FileUtil.writeToTextFile(
                                    outputTitle + sb.toString(), new File(
                                            outputFilePath + "._out"));
                        }

                    }

                }
            } catch (Exception ex) {
                logger.error("SQLProcess Finally error", ex);
            }
            ps = null;
        }
    }

    public void oracleToVerticaDataTransferUsingDMExpress(Schema srcSchema,
            Schema destSchema, Schema dmExpressSchema, int threadCount,
            TaskTypeNFile taskTypeNFile, InputStream is, int retVal,
            Long executionNumber) throws Exception {

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        String hostingServer = ((destSchema.getHostingServer() == null) || (destSchema
                .getHostingServer() == "")) ? Constants.VERTICA_CMA
                        : destSchema.getHostingServer();

        String user = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String commandLocation = fixedParam.getValue(
                Constants.OS_SHFILELOCATION, hostingServer);
        String commandName = fixedParam.getValue(Constants.OS_SHFILENAME,
                hostingServer);
        String password = fixedParam.getValue(Constants.OS_PASSWORD,
                hostingServer);
        String shellOutLocation = fixedParam.getValue(
                Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer);
        String vs_user = fixedParam.getValue(Constants.VS_USERNAME,
                hostingServer);
        String dme_user = fixedParam.getValue(Constants.DME_USERNAME,
                hostingServer);
        String execMode = fixedParam.getValue(Constants.O2V_EXECUTIONMODE,
                hostingServer);

        String params = srcSchema.getServerName() + " "
                + srcSchema.getSchemaName() + " " + srcSchema.getSchemaPwd()
                + " " + destSchema.getServerName() + " "
                + destSchema.getDatabase() + " " + destSchema.getSchemaName()
                + " " + destSchema.getSchemaPwd() + " "
                + srcSchema.getConnection() + " " + destSchema.getConnection()
                + " " + vs_user + " " + execMode + " " + threadCount + " "
                + dmExpressSchema.getServerName() + " " + dme_user + " "
                + executionNumber;

        String fileName = shellOutLocation
                + "/"
                + fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX,
                        hostingServer) + "_" + executionNumber + ".log";

        /*
		 * System.out.println(">>User: "+user);
		 * System.out.println(">>PasswordUsed: "+password);
		 * System.out.println(">>CommandLocation: "+commandLocation);
		 * System.out.println(">>CommandName: "+commandName);
		 * System.out.println(">>Params: "+params);
         */
        String cdCommand = "cd " + commandLocation;
        String shCommand = "nohup " + "sh " + commandName + " " + params + " "
                + ">" + fileName;
        String command = cdCommand + " && " + shCommand;
        String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY,
                hostingServer);

        System.out
                .println("COMMAND TO BE EXECUTED FOR VERTICA DATA TRANSFER USING DMEXPRESS:"
                        + command);
        logger.info("COMMAND EXECUTED FOR ORACLE TO VERTICA DATA TRANSFER USING DMEXPRESS BY : "
                + taskKey.getUserName() + " IS " + command);

        try {
            List lss = RunShellScript
                    .runShellScript(false, user, password,
                            srcSchema.getServerName(), cdCommand, shCommand,
                            privateKey);
            sb = new StringBuffer((String) lss.get(1));

            endDate = new Date(System.currentTimeMillis());
            Object[] isError = new Object[]{Boolean.FALSE, ""};
            isError = getShellError(sb.toString());
            if (Boolean.TRUE.equals(isError[0])) {
                taskTypeNFile.setFailure(true);
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, (String) isError[1],
                        sqlplusRunnable.getSchema());
            } else {
                taskTypeNFile.setCompleted(true);
                eventLogger
                        .logEnd(taskKey.getUserName(), sqlplusRunnable
                                .getTaskType().getTaskLabel(), sqlplusRunnable
                                .getDescription(), sqlplusRunnable
                                .getThreadCount(), startDate, endDate, retVal,
                                sqlplusRunnable.getSchema());
            }

            System.out
                    .println("DONE EXECUTING COMMAND FOR VERTICA DATA TRANSFER USING DMEXPRESS");
        } catch (Exception e) {
            taskTypeNFile.setFailure(true);
            try {
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, (String) e.getMessage(),
                        sqlplusRunnable.getSchema());
            } catch (Exception e1) {

            } finally {
                logger.error("Error for Oracle to Vertica Data Transfer Using DMExpress with Exceution Number : "
                        + sqlplusRunnable.getExecutionId());
            }
        }
    }

    public void oracleToVerticaDataTransferUsingCMA(Schema srcSchema,
            Schema destSchema, TaskTypeNFile taskTypeNFile, InputStream is,
            int retVal, Long executionNumber) throws JSchException,
            IOException, InterruptedException {

//        CustomProcedureExecutor customProcExec;
//
//        try {
//            customProcExec = new CustomProcedureExecutor(taskKey.getUserName());
//            customProcExec.executeDropTblSpace(srcSchema);
//        } catch (Exception e) {
//            logger.error("Error on Custom ProcedureExecutor",e);
//        }

        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        String hostingServer = ((destSchema.getHostingServer() == null) || (destSchema
                .getHostingServer() == "")) ? Constants.VERTICA_CMA
                        : destSchema.getHostingServer();

        String user = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String commandLocation = fixedParam.getValue(
                Constants.OS_SHFILELOCATION, hostingServer);
        String commandName = fixedParam.getValue(Constants.OS_SHFILENAME,
                hostingServer);
        String password = fixedParam.getValue(Constants.OS_PASSWORD,
                hostingServer);
        String shellOutLocation = fixedParam.getValue(
                Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer);
        String vs_user = fixedParam.getValue(Constants.VS_USERNAME,
                hostingServer);
        // String dme_user = fixedParam.getValue(Constants.DME_USERNAME);
        // String execMode = fixedParam.getValue(Constants.O2V_EXECUTIONMODE);
        String cma_api_schema_pwd = fixedParam.getValue(
                Constants.CMA_API_SCHEMA_PWD, hostingServer);

        String params = srcSchema.getServerName() + " "
                + srcSchema.getService() + " " + srcSchema.getPort() + " "
                + srcSchema.getSchemaName() + " " + srcSchema.getSchemaPwd()
                + " " + destSchema.getServerName() + " "
                + destSchema.getDatabase() + " " + destSchema.getPort() + " "
                + destSchema.getSchemaName() + " " + destSchema.getSchemaPwd()
                + " " + vs_user + " " + cma_api_schema_pwd + " "
                + executionNumber;

        String fileName = shellOutLocation
                + "/"
                + fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX,
                        hostingServer) + "_" + executionNumber + ".log";

        String cdCommand = "cd " + commandLocation;
        String shCommand = "nohup " + "sh " + commandName + " " + params + " "
                + ">" + fileName;
        String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY,
                hostingServer);

        List<String> commands = new ArrayList<String>();
        /**
         * VHTDBA-1820 :Dashboard connection Issue to Multiple Exadata Instance
         * Note:
         */
        String exportOracleSIDCommand = "export ORACLE_SID=" + srcSchema.getService().toLowerCase();
        // adding the exportOracleSIDCommand only if the source service name is different then d2he
        if (!srcSchema.getService().equalsIgnoreCase(Constants.DEFAULT_SERVICE_NAME)) {
            logger.info("<<<<< Different service name [default(d2he)] found for source schema " + srcSchema + " so adding export ORACLE_SID command!!!! >>>>>");
            commands.add(exportOracleSIDCommand);
        }
        commands.add(cdCommand);
        commands.add(shCommand);

        String command = (!srcSchema.getService().equalsIgnoreCase(
                Constants.DEFAULT_SERVICE_NAME)) ? exportOracleSIDCommand
                        + " && " : " " + cdCommand + " && " + shCommand;
        System.out
                .println("COMMAND TO BE EXECUTED FOR VERTICA DATA TRANSFER USING CMA:"
                        + command);
        logger.info("COMMAND EXECUTED FOR ORACLE TO VERTICA DATA TRANSFER USING CMA BY : "
                + taskKey.getUserName() + " IS " + command);

        try {
            String output = CmdRunner.runCommandsOnShell(false,
                    srcSchema.getServerName(), user, password, commands,
                    privateKey);
            sb = new StringBuffer(output);
            endDate = new Date(System.currentTimeMillis());
            String processID = new VerticaDB().getO2VProcessId(sqlplusRunnable
                    .getExecutionId().toString(), srcSchema.getServerName(),
                    destSchema.getHostingServer());
            if (!processID.equals("0")
                    && CmdRunner.isRemoteProcessRunning(
                            srcSchema.getServerName(), user, password,
                            privateKey, processID)) {
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, Message.ERROR_TCP_KEEP_ALIVE,
                        sqlplusRunnable.getSchema());
            } else {
                eventLogger
                        .logEnd(taskKey.getUserName(), sqlplusRunnable
                                .getTaskType().getTaskLabel(), sqlplusRunnable
                                .getDescription(), sqlplusRunnable
                                .getThreadCount(), startDate, endDate, retVal,
                                sqlplusRunnable.getSchema());
            }
            System.out
                    .println("DONE EXECUTING COMMAND FOR VERTICA DATA TRANSFER USING CMA");
        } catch (Exception e) {
            endDate = new Date(System.currentTimeMillis());
            logger.error("Error for Oracle to Vertica Data Transfer Using CMA with Exceution Number : "
                    + sqlplusRunnable.getExecutionId() + ": " + e.toString());
            e.printStackTrace();
            eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                    .getTaskType().getTaskLabel(), sqlplusRunnable
                    .getDescription(), sqlplusRunnable.getThreadCount(),
                    startDate, endDate, (String) e.getMessage(),
                    sqlplusRunnable.getSchema());
        }
    }

    public void oracleToVerticaDRDataTransferUsingCMA(Schema srcSchema,
            Schema destSchema, TaskTypeNFile taskTypeNFile, InputStream is,
            int retVal, Long executionNumber) throws JSchException,
            IOException, InterruptedException {

//        CustomProcedureExecutor customProcExec = new CustomProcedureExecutor(taskKey.getUserName());
//        customProcExec.executeDropTblSpace(srcSchema);
        /**
         ** If hostingServer is VERTICA then processing@fixedparameters table
         * is used If hostingServer is VERTICA_CMA then
         * processing@fixedparameters_cma table is used Default is VERTICA_CMA
         * if hostingServer is null or blank
         *
         */
        String hostingServer = ((destSchema.getHostingServer() == null) || (destSchema
                .getHostingServer() == "")) ? Constants.VERTICA_DR_CMA
                        : destSchema.getHostingServer();

        String user = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        String commandLocation = fixedParam.getValue(
                Constants.OS_SHFILELOCATION, hostingServer);
        String commandName = fixedParam.getValue(Constants.OS_SHFILENAME,
                hostingServer);
        String password = fixedParam.getValue(Constants.OS_PASSWORD,
                hostingServer);
        String shellOutLocation = fixedParam.getValue(
                Constants.SHELLSCRIPT_OUTPUTLOCATION, hostingServer);
        String vs_user = fixedParam.getValue(Constants.VS_USERNAME,
                hostingServer);
        // String dme_user = fixedParam.getValue(Constants.DME_USERNAME);
        // String execMode = fixedParam.getValue(Constants.O2V_EXECUTIONMODE);
        String cma_api_schema_pwd = fixedParam.getValue(
                Constants.CMA_API_SCHEMA_PWD, hostingServer);

        String params = srcSchema.getServerName() + " "
                + srcSchema.getService() + " " + srcSchema.getPort() + " "
                + srcSchema.getSchemaName() + " " + srcSchema.getSchemaPwd()
                + " " + destSchema.getServerName() + " "
                + destSchema.getDatabase() + " " + destSchema.getPort() + " "
                + destSchema.getSchemaName() + " " + destSchema.getSchemaPwd()
                + " " + vs_user + " " + cma_api_schema_pwd + " "
                + executionNumber;

        String fileName = shellOutLocation
                + "/"
                + fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX,
                        hostingServer) + "_" + executionNumber + ".log";

        String cdCommand = "cd " + commandLocation;
        String shCommand = "nohup " + "sh " + commandName + " " + params + " "
                + ">" + fileName;
        String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY,
                hostingServer);

        List<String> commands = new ArrayList<String>();
        /**
         * VHTDBA-1820 :Dashboard connection Issue to Multiple Exadata Instance
         * Note:
         */
        String exportOracleSIDCommand = "export ORACLE_SID=" + srcSchema.getService().toLowerCase();
        // adding the exportOracleSIDCommand only if the source service name is different then d2he
        if (!srcSchema.getService().equalsIgnoreCase(Constants.DEFAULT_SERVICE_NAME)) {
            logger.info("<<<<< Different service name [default(d2he)] found for source schema " + srcSchema + " so adding export ORACLE_SID command!!!! >>>>>");
            commands.add(exportOracleSIDCommand);
        }
        commands.add(cdCommand);
        commands.add(shCommand);

        String command = (!srcSchema.getService().equalsIgnoreCase(
                Constants.DEFAULT_SERVICE_NAME)) ? exportOracleSIDCommand
                        + " && " : " " + cdCommand + " && " + shCommand;
        System.out
                .println("COMMAND TO BE EXECUTED FOR VERTICA DR DATA TRANSFER USING CMA:"
                        + command);
        logger.info("COMMAND EXECUTED FOR ORACLE TO VERTICA DR DATA TRANSFER USING CMA BY : "
                + taskKey.getUserName() + " IS " + command);

        try {
            String output = CmdRunner.runCommandsOnShell(false,
                    srcSchema.getServerName(), user, password, commands,
                    privateKey);
            sb = new StringBuffer(output);
            endDate = new Date(System.currentTimeMillis());
            String processID = new VerticaDB().getO2VProcessId(sqlplusRunnable
                    .getExecutionId().toString(), srcSchema.getServerName(),
                    destSchema.getHostingServer());
            if (!processID.equals("0")
                    && CmdRunner.isRemoteProcessRunning(
                            srcSchema.getServerName(), user, password,
                            privateKey, processID)) {
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, Message.ERROR_TCP_KEEP_ALIVE,
                        sqlplusRunnable.getSchema());
            } else {
                eventLogger
                        .logEnd(taskKey.getUserName(), sqlplusRunnable
                                .getTaskType().getTaskLabel(), sqlplusRunnable
                                .getDescription(), sqlplusRunnable
                                .getThreadCount(), startDate, endDate, retVal,
                                sqlplusRunnable.getSchema());
            }
            System.out
                    .println("DONE EXECUTING COMMAND FOR VERTICA DATA TRANSFER USING CMA");
        } catch (Exception e) {
            endDate = new Date(System.currentTimeMillis());
            logger.error("Error for Oracle to Vertica Data Transfer Using CMA with Exceution Number : "
                    + sqlplusRunnable.getExecutionId() + ": " + e.toString());
            e.printStackTrace();
            eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                    .getTaskType().getTaskLabel(), sqlplusRunnable
                    .getDescription(), sqlplusRunnable.getThreadCount(),
                    startDate, endDate, (String) e.getMessage(),
                    sqlplusRunnable.getSchema());
        }
    }

    public void createVerticaSchema(Schema destSchema,
            TaskTypeNFile taskTypeNFile, int retVal,
            List<String> verticaSchemaParams) throws Exception {

        if (verticaSchemaParams != null) {
            /**
             ** If hostingServer is VERTICA then processing@fixedparameters
             * table is used If hostingServer is VERTICA_CMA then
             * processing@fixedparameters_cma table is used Default is
             * VERTICA_CMA if hostingServer is null or blank
             *
             */
            String hostingServer = ((destSchema.getHostingServer() == null) || (destSchema
                    .getHostingServer() == "")) ? Constants.VERTICA_CMA
                            : destSchema.getHostingServer();

            String user = fixedParam.getValue(Constants.VS_USERNAME,
                    hostingServer);
            String commandLocation = fixedParam.getValue(
                    Constants.VS_SHFILELOCATION, hostingServer);
            String commandName = fixedParam.getValue(Constants.VS_SHFILENAME,
                    hostingServer);
            String password = fixedParam.getValue(Constants.VS_PASSWORD,
                    hostingServer);

            String dbName = verticaSchemaParams.get(0);
            String adminUserName = verticaSchemaParams.get(1);
            String adminPass = verticaSchemaParams.get(2);
            String newSchemaName = verticaSchemaParams.get(3);
            String newUserName = verticaSchemaParams.get(4);
            String newUserPassword = verticaSchemaParams.get(5);

            String params = dbName + " " + adminUserName + " " + adminPass
                    + " " + newSchemaName + " " + newUserName + " "
                    + newUserPassword;

            String cdCommand = "cd " + commandLocation;
            String shCommand = "sh " + commandName + " " + params;
            String command = cdCommand + " && " + shCommand;
            String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY,
                    hostingServer);

            List<String> commands = new ArrayList<String>();
            commands.add(cdCommand);
            commands.add(shCommand);

            System.out
                    .println("COMMAND TO BE EXECUTED FOR VERTICA SCHEMA CREATION:"
                            + command);
            logger.info("COMMAND EXECUTED FOR VERTICA SCHEMA CREATION BY : "
                    + taskKey.getUserName() + " IS " + command);

            try {
                // List lss
                // =RunShellScript.runShellScript(false,user,password,destSchema.getServerName(),cdCommand,shCommand,privateKey);
                // sb = (StringBuffer) lss.get(1);
                String output = CmdRunner.runCommandsOnShell(false,
                        destSchema.getServerName(), user, password, commands,
                        privateKey);

                // hiding passwords
                sb = new StringBuffer(sqlplusRunnable.hidePasswordsForVertica(
                        output, destSchema.getHostingServer()));

                Object[] isError = new Object[]{Boolean.FALSE, ""};
                isError = getShellError(sb.toString());
                if (Boolean.TRUE.equals(isError[0])) {
                    taskTypeNFile.setFailure(true);
                    eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                            .getTaskType().getTaskLabel(), sqlplusRunnable
                            .getDescription(),
                            sqlplusRunnable.getThreadCount(), startDate,
                            endDate, (String) isError[1], sqlplusRunnable
                            .getSchema());
                } else {
                    taskTypeNFile.setCompleted(true);
                    eventLogger.logEnd(taskKey.getUserName(), sqlplusRunnable
                            .getTaskType().getTaskLabel(), sqlplusRunnable
                            .getDescription(),
                            sqlplusRunnable.getThreadCount(), startDate,
                            endDate, retVal, sqlplusRunnable.getSchema());
                }

                System.out
                        .println("DONE EXECUTING COMMAND FOR VERTICA SCHEMA CREATION");
            } catch (Exception e) {
                sb = new StringBuffer(e.toString());// adding exception to
                // string buffer
                taskTypeNFile.setFailure(true);
                try {
                    eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                            .getTaskType().getTaskLabel(), sqlplusRunnable
                            .getDescription(),
                            sqlplusRunnable.getThreadCount(), startDate,
                            endDate, e.toString(), sqlplusRunnable.getSchema());
                } catch (Exception e1) {

                } finally {
                    logger.error("Error while creating vertica schema "
                            + destSchema.getSchemaName() + " on "
                            + destSchema.getServerName() + " using " + user
                            + "/" + password + ": " + e.toString());
                }
            }
        }
    }

    public String getOutput() {
        return sb.toString();
    }

    public String getDxCGStatus() {
        dxSb = new StringBuffer(INIT_BUFFER_SIZE);
        List<String> dxList = new ArrayList<String>();
        String dxUrl = "";
        if (sqlplusRunnable != null && isTargetURLEmpty) {
            dxList = sqlplusRunnable.getDxCGOutput();
            if (dxList.size() > 0 && !"".equalsIgnoreCase(dxList.get(0))
                    && !"".equalsIgnoreCase(dxList.get(1))) {
                targetURL = dxList.get(0);
                if (targetURL != null && targetURL.indexOf("h") > 0) {
                    isTargetURLEmpty = false;
                }
                jobId = dxList.get(1);
            }
        }
        if (!"".equalsIgnoreCase(targetURL) && !"".equalsIgnoreCase(jobId)
                && targetURL != null) {
            dxUrl = targetURL + "/track/" + jobId;
            URL url;
            try {
                url = new URL(dxUrl);
                URLConnection conn = url.openConnection();
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        conn.getInputStream()));
                String line;
                while ((line = in.readLine()) != null) {
                    // sb.append(line);
                    // sb.append("\n");
                    dxSb.append(line);
                    dxSb.append("\n");
                }
            } catch (MalformedURLException e) {
                logger.error("MalformedURLException in getDxCGStatus() "
                        + e.getMessage());
                e.printStackTrace();
            } catch (IOException e) {
                logger.error("IOException in getDxCGStatus() " + e.getMessage());
                // sb.append("URL not available at this moment...");
                dxSb.append("URL not available at this moment...");
                e.printStackTrace();
            }
        } else {
            // sb.append("No table or no jobid exists at this moment ... ");
            dxSb.append("No table or no jobid exists at this moment ... ");
        }
        /*
		 * List ls = null; ls = sqlplusRunnable.getTaskTypeNFileList(); if (ls
		 * != null && !ls.isEmpty()) { Iterator it = ls.iterator(); while
		 * (!it.hasNext()) { if
		 * (dxSb.toString().contains("DxCG Processing Completed") && status ==
		 * SQLProcessStatus.COMPLETE) { release(); } } }
         */
        if (dxSb.toString().contains("DxCG Processing Completed")
                && status == SQLProcessStatus.COMPLETE) {
            release();
        }
        return "\n" + "Executing Since: "
                + EDBUtil.totalTime(taskKey.getStartDate()) + "\n" + "\n"
                + dxSb.toString();
    }

    private static StringBuffer appendInvalidProcs(StringBuffer sb, List invLs) {
        sb.append("\nFollowing modules were found to be invalid.").append(
                "\n----------------------------------------\n");
        Iterator it = invLs.iterator();
        int i = 1;
        while (it.hasNext()) {
            String procName = (String) it.next();
            sb.append("\n").append(i).append(". ").append(procName);
            i++;
        }
        sb.append("\n------------------------\nCurrent process stopped due to invalid modules.\n");
        return sb;
    }

    protected void release() {
        registry.release(taskKey);
    }

    // TaskKey added for killing oracle to vertica process in processing server
    public void killProcess(TaskKey key, String userInfo) throws Exception {
        allowRun = false;
        logger.info("Kill initiated.");
        isKill = true;
        try {
            endDate = new Date(System.currentTimeMillis());
            sb.append("\n-------------------------------")
                    .append("\n KILL OPERATION REQUESTED BY : " + userInfo)
                    .append("\n at: " + dateFormat.format(endDate))
                    .append("\n------------------------------")
                    .append("\n-- START KILL OPERATION ..")
                    .append("\n----------------------------");
            if (ps != null) {
                ps.destroy();
                endDate = new Date(System.currentTimeMillis());
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, "Kill operation initiated by: "
                        + userInfo, sqlplusRunnable.getSchema());
                logger.info("Process killed.");
                isKilled = true;
                if ("Y".equalsIgnoreCase(taskKey.getDxCGProcessed())) {
                    if (!"".equalsIgnoreCase(targetURL)
                            && !"".equalsIgnoreCase(jobId)) {
                        String dxurl = targetURL + "/killProcess/" + jobId;
                        URL url = new URL(dxurl);
                        URLConnection conn = url.openConnection();
                        conn.connect();
                        BufferedReader in = new BufferedReader(
                                new InputStreamReader(conn.getInputStream()));
                        if (in.readLine().equalsIgnoreCase("OK")) {
                            sb.append("Kill DxCG Process Started...");
                            sb.append("The process will take some time...");
                        } else {
                            sb.append("No DxCG Process to Kill...");
                        }
                    }
                }
            } // for vertica data transfer
            else if (key.getExecutionNumber() != 0) {
                endDate = new Date(System.currentTimeMillis());
                eventLogger.logError(taskKey.getUserName(), sqlplusRunnable
                        .getTaskType().getTaskLabel(), sqlplusRunnable
                        .getDescription(), sqlplusRunnable.getThreadCount(),
                        startDate, endDate, "Kill operation initiated by: "
                        + userInfo, sqlplusRunnable.getSchema());
                logger.info("Oracle to Vertica Process killed.");
            }
            sb.append("\n--PROCESS KILLED.\n");
        } catch (Exception ex) {
            sb.append("\n-- Failure during kill operation..").append(
                    "\n [STACK TRACE  \n");

            StringWriter sw = new StringWriter(1000);
            ex.printStackTrace(new PrintWriter(sw));
            sb.append(sw.toString());
            sb.append("\n END STACK]\n");
            logger.info("Exception during kill.", ex);
            throw ex;
        } finally {
            ps = null;
        }
        if (sqlplusRunnable.isAllowKill()) {
            sqlplusRunnable.kill();
        }
        release();
    }

    /**
     * Description : Sends mail by connecting to Schema in SQLPLUSRUNNABLE
     *
     * @param taskTypeNFile
     * @param srcSchema
     * @param destSchema
     * @param error
     *
     */
    public void sendMail(TaskTypeNFile taskTypeNFile, Schema srcSchema,
            Schema destSchema, String error) {
        try {
            logger.info("Trying to send mail for schema >>>>>>>>>>"
                    + sqlplusRunnable.getSchema().getSchemaName()
                    + " with task " + taskTypeNFile.getTaskType().getTaskName());
            mail.sendMail(sqlplusRunnable.getSchema(), taskKey.getUserName(),
                    taskTypeNFile.getEventIdForMail(), startDate, new Date(),
                    error, srcSchema.getSchemaName(),
                    destSchema.getSchemaName());
        } catch (Exception e) {
            logger.error("Could not send mail for schema >>>>>>>>>>>>"
                    + sqlplusRunnable.getSchema().getSchemaName()
                    + " with task " + taskTypeNFile.getTaskType().getTaskName());
            StringWriter sw = InsertExceptionToLogger.insert(e, logger);
            eventLogger.logError(taskKey.getUserName(), "Send Mail ("
                    + taskTypeNFile.getTaskType().getTaskLabel() + " )",
                    sqlplusRunnable.getDescription(), 0, new Date(),
                    new Date(), sw.toString(), sqlplusRunnable.getSchema());
        }
    }

    /**
     * @param scriptFile
     * @param isShellScript
     * @param sb
     * @throws Exception
     * @description Writes output to file
     */
    public void writeToFile(File scriptFile, boolean isShellScript,
            StringBuffer sb) throws Exception {
        logger.info("<<<<<<<<<<<<<<Writing output file from AysncSQLProcess.java>>>>>>>>>>>>>>>>");
        String outputFilePath = scriptFile.getAbsolutePath();
        String outputTitle = isShellScript ? "\n--Last output from Shell Script*\n"
                : "\n--Last output from sqlPlus*\n";
        FileUtil.writeToTextFile(outputTitle + sb.toString(), new File(
                outputFilePath + "._out"));
    }

    public boolean isAllowRun() {
        return allowRun;
    }

    public TaskKey getTaskKey() {
        return taskKey;
    }

    private static final String ORA_ERROR = "(ORA-\\d+:.*)";
    private static final Pattern PAT_ORA_ERROR = Pattern.compile(ORA_ERROR,
            Pattern.MULTILINE);

    private static Object[] getOraError(String s) {
        Object[] ret = new Object[]{Boolean.FALSE, ""};
        if (null == s) {
            return ret;
        }

        StringBuffer sb = new StringBuffer();
        Matcher m = PAT_ORA_ERROR.matcher(s);
        while (m.find()) {
            ret[0] = Boolean.TRUE;
            sb.append(m.group()).append("\n");
        }
        ret[1] = sb.toString();
        return ret;
    }

    private static final String SHELL_ERROR = "(ERROR-\\d+:.*?\\\n)";
    private static final Pattern PAT_SHELL_ERROR = Pattern.compile(SHELL_ERROR,
            Pattern.MULTILINE);

    private static Object[] getShellError(String s) {
        Object[] ret = new Object[]{Boolean.FALSE, ""};
        if (null == s) {
            return ret;
        }

        StringBuffer sb = new StringBuffer();
        Matcher m = PAT_SHELL_ERROR.matcher(s);
        while (m.find()) {
            ret[0] = Boolean.TRUE;
            sb.append(m.group()).append("\n");
        }
        ret[1] = sb.toString();
        return ret;
    }

    public SQLProcessStatus getStatus() {
        return status;
    }

    public void setStatus(SQLProcessStatus status) {
        this.status = status;
    }

}
