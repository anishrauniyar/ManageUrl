package dashboard.engine;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

import java.util.Set;
import java.util.Map;
import java.util.HashMap;

import dashboard.data.Schema;
import dashboard.ComponentFactory;
import dashboard.engine.EngineMonitor;

public class AsyncSQLProcessRegistry {

    private static final int INIT_MAP_SIZE = 12;
    private AsyncSQLProcessRegistry () {}

    protected Log logger = LogFactory.getLog(getClass());
    private Map errorTableMap = null;
    private Map taskLogMap = null;

    private ComponentFactory compFact = null;

    private Map registry = null;
    public AsyncSQLProcessRegistry(ComponentFactory fact) {
        if(null == fact)
            throw new NullPointerException("Initialization with null ComponentFactory.");
        compFact = fact;
        errorTableMap = fact.getErrorTableMap();
        taskLogMap = fact.getTaskLogMap();
        registry = new HashMap(INIT_MAP_SIZE);
    }

    public AsyncSQLProcess register(TaskKey key, SQLPlusRunnable sqlRunnable) {
        AsyncSQLProcess sqlProcess = null;
        if( key == null || sqlRunnable == null)
            throw new NullPointerException("null parameter for registering AsyncSQLProcess: " +
                                           " Key NULL?: " + (key==null) +
                                           " SQLPLUSRunnable Null?:  " + (sqlRunnable==null));
        sqlProcess = (AsyncSQLProcess) registry.get(key);

        if(sqlProcess != null) {
            logger.info("\n-->process found." );            
            return sqlProcess;
        } else {
            synchronized(registry) {
                // check again so that if the thread enters the synchronized block after not finding
                // the object, it does not create a new one if one is already created.
                // this is possible only when more than one thread tries to create the same object simultaneously
                // and both try to enter the sync block.
                // due to the synchronization, only on can enter the sync. block at a time.
                // but only  one of them should be allowed to start the process.
                sqlProcess = (AsyncSQLProcess) registry.get(key);
                if (sqlProcess != null) {
                    logger.info("\n--> process found in sync block.");
                    return sqlProcess;
                } else {
                    //
                    key.setSchema( sqlRunnable.getSchema());
                    key.setThreadCount( sqlRunnable.getThreadCount());
                    sqlProcess
                        = (new AsyncSQLProcess()).setAsyncSQLProcessRegistry(key, this)
                        .setSQLPlusRunnable(sqlRunnable);

                    registry.put(key, sqlProcess);
                    fireProcess(sqlProcess);
                    logger.info("\n-->new process fired." );
                }
            }
        }
        return sqlProcess;
    }

    private  void fireProcess(AsyncSQLProcess sqlProcess) {
        if (sqlProcess.isAllowRun() ) {
            Thread t = new Thread(sqlProcess);
            t.start();
        }
    }
    public AsyncSQLProcessRegistry release(TaskKey key) {
        registry.remove(key);
        logger.info("released for :" + key.getServerGroupId() + ":" + key.getSchemaName());        
        return this;
    }
    public AsyncSQLProcess getAsyncSQLProcess(TaskKey key) {
        return (AsyncSQLProcess) registry.get(key);
    }

    private static final long CACHE_TIME = 3000; //3 sec
    public TaskKey [] getTaskKeys() {
        long currentTime = System.currentTimeMillis();
        //randomize for minimizing modification at the same time.
        long cache_interval = CACHE_TIME + (long) (Math.random() * 3000);
        TaskKey [] taskKeys = null;
        Set s = registry.keySet();
        taskKeys = (TaskKey [] ) s.toArray( new TaskKey[s.size()]);
        for(int i=0; i<taskKeys.length; i++) {
            TaskKey tskKey = taskKeys[i];

            AsyncSQLProcess sqlProcess = getAsyncSQLProcess(tskKey);
            if ( null != sqlProcess) {
                SQLPlusRunnable sqlPlusRunnable = sqlProcess.getSQLPlusRunnable();
                if ( null != sqlPlusRunnable) {
                    TaskType taskType = sqlPlusRunnable.getTaskType();
                    if ( null != taskType && errorTableMap.containsKey(taskType.getID()) ) {
                        if ( !tskKey.isExistsError()) {
                            long delta = currentTime - tskKey.getLastUpdate();
                            if (  delta > cache_interval || delta < 0 ) {
                                Schema schema = sqlPlusRunnable.getSchema();
                                EngineMonitor engine = compFact.getEngineMonitorForSystem();
                                int errTblCount =
                                    engine.getRowCountFromTable(schema, (String) errorTableMap.get(taskType.getID()));
                                tskKey.setExistsError(errTblCount > 0 );
                                tskKey.setLastUpdate( System.currentTimeMillis());
                            }
                        }
                    }
                }
            }
            
        }
        return taskKeys;
    }

    public Boolean killProcess( TaskKey key, String userInfo) throws Exception {
        AsyncSQLProcess sqlProcess = null;
        sqlProcess = (AsyncSQLProcess) registry.get(key);
        if (sqlProcess != null) {
            sqlProcess.killProcess(key,userInfo);
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }    
    
}
