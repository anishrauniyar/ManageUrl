package dashboard.engine;

import java.io.File;
import java.util.List;

import dashboard.data.Schema;
import dashboard.data.RunningStatus;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.security.User;

public interface SQLPlusRunnable {

    public void init() throws Exception ;

    public TaskType getTaskType();
    public SQLPlusRunnable setTaskType(TaskType taskType);
    public void setSubTaskType(String subTaskType);
    public String getSubTaskType();

    public String getDescription() ;

    public List  getTaskTypeNFileList();

    public String getSQLPlusUrl();
    public String getSrcSQLPlusUrl();
    public String getStagingSQLPlusUrl();
    public String getSQLPlusUrlForFQC();
    public void setStatus(SQLProcessStatus status);
    
    public List getStatusList() throws Exception ;

    public RunningStatus getRunningStatus() throws Exception ;
    
    public List<VHTransferLog> getMiniEngineOutputTransferLog() throws Exception;

    public void setRunnerUserName(String rnUser);

    public String getRunnerUserName();
    
    public void setRunnerPassword(String rnUser);

    public String getRunnerPassword() ;
    
    public Schema getSrcSchema();

    public Schema getSchema();

    public Schema getRunnerSchema();
    
    public Schema getDmExpressSchema();
    
    public SQLPlusRunnable setThreadCount(int tc);

    public int getThreadCount();
    
    public SQLPlusRunnable setParallel(String p);
    
    public String getParallel();

    public List getBeforeInvalidProcList() throws Exception ;
    
    public List getAfterInvalidProcList() throws Exception ;

    public boolean isAllowKill();

    public void kill() throws Exception;
    
    public File getScriptFile()throws Exception;
    
    public boolean isWriteOutputFile() throws Exception;

    public SQLPlusRunnable setUser(User user);
    public User getUser()throws Exception;
    
    public List<String> getDxCGOutput();
    
    public boolean isCreateVerticaSchema();
    
    public List<String> getVerticaSchemaParams();
    
    public Long getExecutionId();
    
    public String hidePasswordsForVertica(String input,String hostingServer);
}