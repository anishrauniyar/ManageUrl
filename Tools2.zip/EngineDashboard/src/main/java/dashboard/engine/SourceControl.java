package dashboard.engine;

import dashboard.data.SourceControlUser;

/**
 * Interfaces with source control client
 */
public interface SourceControl {

    /**
     * @param user User to login to the source control system
     * @param directory directory url in SVN for which to lis
     * @return listing as returned by the client in string format.
     */
    public String listDirectory(SourceControlUser user, String directory) throws Exception;

    /**
     * @param user User to login to the source control system
     * @param srcDir directory url in SVN from which to checkout.
     * @param distDir directory in which to checkout.
     * @return output as returned by the client in the string format.
     */

    public String checkOut(SourceControlUser user, String srcDir, String destDir) throws Exception;
    
    public int writeFileFromSVN(SourceControlUser user, String[] srcFiles, String destDir) throws Exception;

}
