package dashboard.engine;

import java.util.List;
import java.io.File;

import dashboard.data.SourceControlUser;
import dashboard.util.EDBUtil;
import dashboard.util.EnvInfo;
import dashboard.util.DirectoryCleaner;
import dashboard.util.CmdRunner;
import dashboard.util.ErrorOnDoubleQuote;
import dashboard.util.ErrorOnQuote;
import dashboard.util.FileUtil;


/**
 * This class is responsible to interact with SVN through SVNClient executed through process.
 */
public class SVNSourceControl  implements SourceControl { 

    public SVNSourceControl() { 
    }

    private EnvInfo envInfo;
    private String  SVN_CLIENT = null;
    public void setEnvInfo(EnvInfo e) {
        envInfo = e;
        SVN_CLIENT = envInfo.getSVN();
    }

    private List protectedDirs = null;
    public void setProtectedDirs(List ls) {
        protectedDirs = ls;
    }

    /**
     * @param user User to login to the source control system
     * @param directory directory url in SVN for which to lis
     * @return listing as returned by the client in string format.
     */
    public String listDirectory(SourceControlUser user, String directory) throws Exception {
        ErrorOnDoubleQuote.checkDoubleQuote( directory);
        ErrorOnQuote.checkQuote( directory);

        String cmd = SVN_CLIENT + " --non-interactive   --no-auth-cache --username " +
            user.getUserName() + "  --password " + user.getPassword() +
            " list " +  replaceBlank(directory)  + " ";
        return CmdRunner.invokeCommand(cmd);
            
    }

    /**
     * @param user User to login to the source control system
     * @param srcDir directory url in SVN from which to checkout.
     * @param distDir directory in which to checkout.
     * @return output as returned by the client in the string format.
     */

    public String checkOut(SourceControlUser user, String srcDir, String destDir) throws Exception {
        ErrorOnDoubleQuote.checkDoubleQuote( srcDir);
        ErrorOnDoubleQuote.checkDoubleQuote( destDir);
        ErrorOnQuote.checkQuote( srcDir);
        ErrorOnQuote.checkQuote( destDir);

        if ( null != protectedDirs  && protectedDirs.contains(destDir.trim())) {
            throw new IllegalArgumentException("Checkout to " + destDir + " denied. [Protected Directory].");
        } 
        String cmd = SVN_CLIENT + " --non-interactive   --no-auth-cache --username " +
            user.getUserName() + "  --password " + user.getPassword() + " " +
            " checkout " +
            replaceBlank(srcDir) + " " + destDir + " ";
        File destF = new File( destDir.trim());
        if (destF.exists()) {
            DirectoryCleaner.remove( destDir.trim() );
        }
        return CmdRunner.invokeCommand(cmd);
    }
    
   /* *//**
     * @param user User to login to the source control system
     * @param srcDir directory url in SVN from which to checkout.
     * @param distDir directory in which to checkout.
     * @return output as returned by the client in the string format.
     *//*

    public String export(SourceControlUser user, String srcDir, String destDir) throws Exception {
        ErrorOnDoubleQuote.checkDoubleQuote( srcDir);
        ErrorOnDoubleQuote.checkDoubleQuote( destDir);
        ErrorOnQuote.checkQuote( srcDir);
        ErrorOnQuote.checkQuote( destDir);

        if ( null != protectedDirs  && protectedDirs.contains(destDir.trim())) {
            throw new IllegalArgumentException("Checkout to " + destDir + " denied. [Protected Directory].");
        }
        
        int lastIndex = srcDir.lastIndexOf("/");
        String fileName = srcDir.substring(lastIndex+1, srcDir.length());
        System.out.println("FileName >>>>>>>>>>>>>>>"+fileName);
        String cmd = SVN_CLIENT + " --non-interactive   --no-auth-cache --username " +
            user.getUserName() + "  --password " + user.getPassword() + " " +
            " export " +
            replaceBlank(srcDir) + " " + destDir +"/"+fileName+ " ";
        
        System.out.println("Command>>>>>>>>>>>>>>"+cmd);
        System.out.println("Source Directory is>>>>>>>>>>>>>>>"+srcDir);
        System.out.println("Destination Directory is >>>>>>>>>>>>>>"+destDir);
        File destF = new File( destDir.trim());
        if (destF.exists()) {
        	System.out.println("Detination Directory "+destDir+" exists!!!");
            DirectoryCleaner.remove( destDir.trim() );
            Thread.sleep(5000);
            DirectoryCleaner.create( destDir.trim() );
        }
        else
        {
        	DirectoryCleaner.create( destDir.trim() );
        }
        return CmdRunner.invokeCommand(cmd);
    }*/
    
    
    /**
     * @param user User to login to the source control system
     * @param filename filename url in SVN for which to read
     * @return file content as returned by the client in string format.
     */
    public int writeFileFromSVN(SourceControlUser user, String[] srcFiles, String destDir) throws Exception {
    	int retval = 0;    	
    	for (int i=0; i<srcFiles.length ; i++){
	        ErrorOnDoubleQuote.checkDoubleQuote( srcFiles[i]);
	        ErrorOnQuote.checkQuote( srcFiles[i]); 
	        
	        CmdRunner.invokeCommand("mkdir -p "+ destDir);	
	        
	        String cmd = SVN_CLIENT + " --non-interactive   --no-auth-cache --username " +user.getUserName() + 
	        			 "  --password " + user.getPassword() +" cat " +  replaceBlank(srcFiles[i])  + " ";	        
	        
	        String filename = srcFiles[i].substring(srcFiles[i].lastIndexOf(EDBUtil.fileseperator), srcFiles[i].length());
	        
	        File file =new File(destDir+EDBUtil.fileseperator+filename);	        
	        FileUtil.writeToTextFile(CmdRunner.invokeCommand(cmd), file);
    	}    	
    	return retval;                
    }
    

    private static String replaceBlank(String p) {
        if (null == p) return p;
        return p.replaceAll(" ", "%20");
    } 

}
