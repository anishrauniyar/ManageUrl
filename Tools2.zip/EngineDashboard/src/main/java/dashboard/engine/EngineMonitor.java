package dashboard.engine;

import java.io.File;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import dashboard.data.Chart;
import dashboard.data.ClusterGroup;
import dashboard.data.DataFileDir;
import dashboard.data.DataScripts;
import dashboard.data.DataTask;
import dashboard.data.EngineTask;
import dashboard.data.MREPreCheck;
import dashboard.data.OracleSystemData;
import dashboard.data.ReplaceSchema;
import dashboard.data.Report;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.ScrubbingTask;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.data.SourceControlUser;
import dashboard.data.TempTablespace;
import dashboard.data.WareHouseTask;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.security.RoleSet;
import dashboard.security.User;
import dashboard.web.util.CustomException;
import dashboard.web.util.VerticaException;

/**
 * This module acts as the facade for processing engine as well as managing the
 * required environmet possible from the application. Client modules depend upon
 * the contract exposed by this interface.
 *
 */
public interface EngineMonitor {

    /**
     * @return User as specified by userId
     */
    public User getUser(String loginName, String pwd) throws Exception;

    /**
     * @return roles for given userid
     */
    public RoleSet getUsersRoles(String userId) throws Exception;

    /**
     * @return User as specified by Active Directory name
     */
    public User getUserForLDAPUser(String loginName) throws Exception;

    /**
     * @return User as specified by loginName
     */
    public User getUserWithoutPwd(String loginName) throws SQLException;

    /**
     * @return if true only if specified loginName and password combination are
     * valid
     */
    public Object[] isValidLogin(String loginName, String pwd) throws Exception;

    /**
     * @return if true only if specified loginName is valid
     */
    public Object[] isValidSSOLogin(String loginName) throws SQLException;

    /**
     * @return List of running job status on the specified schema
     */
    public List getStatusList(Schema schema) throws Exception;

    /**
     * @return List of Data transfer status on the specified uniqueJobId
     */
    public List getDataTransferStatusList(String uniqueJobId) throws Exception;

    /**
     * @return RunningStatus on given uniqueJob id to get the total modules and
     * completed module
     */
    public RunningStatus getRunningStatusDataTransfer(String uniqueJobId) throws Exception;

    /**
     * @return RunningStatus on given schema which shows completed modules for
     * Engine
     */
    public RunningStatus getRunningStatusEngine(Schema schema) throws Exception;

    /**
     * @return RunningStatus on given schema which shows completed modules for
     * Mini Engine
     */
    public RunningStatus getRunningStatusMiniEngine(Schema VCSchema) throws Exception;

    /**
     * @return Transfer log for Mini Engine Output Transfer
     */
    public List<VHTransferLog> getMiniEngineOutputTransferLog(Schema destSchema);

    public RunningStatus getAllObjectStatus(Schema schema) throws Exception;

    /**
     * @return array of [Boolean, message] after checking given schema. on valid
     * -> [Boolean.TRUE, success message] on invalid -> [Boolean.FALSE, error
     * messge]
     */
    public Object[] isValid(Schema schema) throws Exception;

    /**
     * @return array of [Boolean, message] after pinging server from giving
     * schema. on valid -> [Boolean.TRUE, success message] on invalid ->
     * [Boolean.FALSE, error messge]
     */
    public Object[] isHostReachable(String host) throws Exception;

    /*----------------------------------------------------------------------*/
 /* SHOW TABLE */
 /*----------------------------------------------------------------------*/
    /**
     * @param schema to use for rows
     * @param table name in the specified schema
     * @return array with 1.array of field names 2. array of rows which is sting
     * array.
     */
    public Object[] getTableAsFieldNamesNRowList(Schema schema, String tableName) throws Exception;

    public int getRowCountFromTable(Schema schema, String tableName);


    /*----------------------------------------------------------------------*/
 /* SERVER GROUP MGMT */
 /*----------------------------------------------------------------------*/
    /**
     * @return list of server groups
     */
    public List getServerGroupList() throws Exception;

    /**
     * @return list of vertica rac server groups
     */
    public List getVerticaRACServerGroupList() throws Exception;

    /**
     * @return list of vertica dr server groups
     */
    public List getVerticaDRServerGroupList() throws Exception;

    /**
     * @return list of server groups depending on hosting server
     */
    public List getServerGroupList(String hostingServer) throws Exception;

    /**
     * @return list of server groups for Processing
     */
    public List getServerGroupListForProcessing() throws Exception;

    /**
     * @return list of server groups for Oracle DR
     */
    public List getServerGroupListForOracleDR() throws Exception;

    /**
     * @return list of History server groups for Processing
     */
    public List getHistServerGroupListForProcessing() throws Exception;

    /**
     * @return list of Server groups based on categories
     */
    public List<ServerGroup> getServerGrpsByCategory(List<String> categoryList) throws Exception;

    /**
     * @return number of server group added.
     */
    public int addServerGroup(String serverGroup, String serverType, String hostingServer) throws Exception;

    /**
     * @return no. of server group deleted.
     */
    public int deleteServerGroup(String serverGroupId) throws Exception;

    /**
     * @return ServerGroup specifed by serverGroupId.
     */
    public ServerGroup getServerGroup(String sa_serverGroupId) throws Exception;

    /**
     * @return server for given schema [serverName,port and serviceName]
     */
    public Server getServer(Schema schema) throws Exception;

    /**
     * @return list of servers for specified serverGroupId
     */
    public List getServersForServerGroup(String serverGroupId) throws Exception;

    public List getVIPServersForServerGrp(String serverGroupId) throws Exception;

    /**
     * @return number of servers added
     */
    public int addServer(Server server) throws SQLException;

    /**
     * @return number of servers edited Here only remote link of server is
     * edited *
     */
    public int editRemoteLinkofServer(Server server) throws Exception;

    /**
     * @return no. of servers deleted.
     */
    public int deleteServer(Server server) throws Exception;

    /**
     * @return true only if specified schema is registered with its serverGroup
     */
    public boolean hasValidServerGroup(Schema schema) throws Exception;

    /* @return true for a processing oracle server*/
    public boolean isProcessingOracleServer(String serverGroupId) throws Exception;

    /**
     * @return list of DataFileDirs for given serverGroupId.
     */
    public List getDataFileDirsForServerGroup(String serverGroupId) throws Exception;

    public int addDataFileDir(DataFileDir dataFileDir) throws Exception;

    public int deleteDataFileDir(DataFileDir dataFileDir) throws Exception;

    /**
     * @return list of [serverGroup, server] array
     */
    public List listAllGroupNServers(boolean showDmexpress) throws Exception;

    public List getTempTablespacesForServerGroup(String serverGroupId) throws Exception;

    public int addTempTablespace(TempTablespace tempTablespace) throws Exception;

    public int deleteTempTablespace(TempTablespace tempTablespace) throws Exception;

    public List getServersForHistServerGroup(String serverGroupId) throws Exception;

    /*----------------------------------------------------------------------*/
 /* CREATING SCHEMA */
 /*----------------------------------------------------------------------*/
    /**
     * Creates the HF schema when HP processing schema is provided in the server
     * where dbUserCreator connects to.
     *
     * @param procSchema schema to create
     * @param runningUser user which is used for creating schema
     * @param runnerPassword password required for runningUser to connect
     * @param dataFileDir base directory into which data file is created. Inside
     * the base directory, there should be directory matching the client id
     * which is 3rd to 5th character of processing schema.
     * @param tempTablespace temp tablespace for the schema to be created.
     * @param isHistSchema when true , create History Schema
     * @param schemaCreationMode determines the tablespace with single big file
     * or Mixed file
     * @return AsyncSQLProcess which is creates the schema in the background. In
     * case the schema is already being used, the returned AsyncSQLProcess will
     * correspond to already running process instead and the schema won't be
     * created for the request.
     *
     */
    public AsyncSQLProcess createSchema(Schema procSchema, String runingUser, String runnerPassword,
            String dataFileDir, String tempTablespace, boolean isHistSchema, String schemaCreationMode, String schemaType, boolean SP_GrantNewUserScriptExists)
            throws Exception;

    public AsyncSQLProcess createVerticaSchema(Schema verticaSchema, String databaseName, String adminUserName,
            String adminPass, String newSchemaName, String newUserName, String newUserPassword)
            throws Exception;

    /*----------------------------------------------------------------------*/
 /* EXECUTING ENGINE  */
 /*----------------------------------------------------------------------*/
    public File[] getOutputFiles(Schema schema) throws Exception;

    /**
     * @param execNo ,hostingServer
     * @return vertica output file(shell script output) from dashboard server
     * @throws Exception
     */
    public File getVerticaOutputFile(long execNo, String hostingServer) throws Exception;

    /**
     * Execute the engine.
     *
     * @param frontSchema in which engine will be executed.
     * @param runDQE runs DQE only if true
     * @param degOfParallelism process/thread count for engine
     * @param EngineTask which specifies combination of ObjectScript,
     * CompileEngine, RunEngine
     */
    public AsyncSQLProcess executeEngine(Schema frontSchema, ReplaceSchema replSchema, boolean runDQE, int degOfParallelism, String parallel, EngineTask eTask, String[] reportNames, String[] reports, User user, String dxcgHostUrl,
            Schema histSchema, String isDifferentServer, String dxcgParam, String dcxgProcessed)
            throws Exception;

    public AsyncSQLProcess getAsyncSQLProcess(TaskKey key);

    /**
     * Execute the MRE.
     *
     * @param frontSchema in which engine will be executed.
     * @param runDQE runs DQE only if true
     * @param degOfParallelism process/thread count for engine
     * @param EngineTask which specifies combination of ObjectScript,
     * CompileEngine, RunEngine
     */
    public AsyncSQLProcess executeMiniEngine(Schema VCSchema, ReplaceSchema replSchema, int degOfParallelism, String parallel, EngineTask eTask, User user,
            Schema histSchema, String isDifferentServer)
            throws Exception;

    public AsyncSQLProcess executeScrubbing(Schema schema, ScrubbingTask scrubTask, Map<String, Boolean> cdfObjSQLScriptsForHP, Map<String, Boolean> clientSpecificSQLScripts) throws Exception;

    /**
     * @return list of sql files for reports corresponding to report name The
     * reports sql file should be within the directory as configured for the
     * report name for the current application
     */
    public List getReportsByReportName(String engVersionDir, String reportName) throws Exception;

    /*----------------------------------------------------------------------*/
 /* EXECUTING REPORT  */
 /*----------------------------------------------------------------------*/
    /**
     * @return process corresponding to report execution on frontSchema for
     * specified reports unless the schema is in use. In case the schema is
     * already in use by another process, that process will be returned instead.
     */
    public AsyncSQLProcess executeReport(Schema frontSchema, ReplaceSchema replSchema, String reportName[], String[] reports, User user, String dxcgHostUrl, String dxcgParam, String dxcgProcessed)
            throws Exception;

    /*----------------------------------------------------------------------*/
 /* EXECUTING REPORT  */
 /*----------------------------------------------------------------------*/
    /**
     * @return process corresponding to indexing on specified schema with the
     * given thread count provided the scheam is not already in use. If the
     * schema is already used by another process, that process will be returned
     * instead.
     */
    public AsyncSQLProcess executeIndex(Schema frontSchema, int degOfParallelism)
            throws Exception;

    /*----------------------------------------------------------------------*/
 /* Data trannsfer */
 /*----------------------------------------------------------------------*/
    /**
     * @param destSchema in which data will be transferred into. This schema is
     * responsible for getting data using stored proc.
     * @param srcHost source host name.
     * @param srcPort
     * @param srcService
     * @param srcSchema
     * @param srcPwd
     * @param trasnferType [ F -> front transfer, H -> history transfer , S - >
     * Scrub transfer]
     * @param appendFlag -> [ F -> Full transfer , A - > Append] : effective
     * only if history transfer
     * @param isSameServer -> true for transfer within the same server.
     * @param useSidFlag -> if 'Y' then use sid for LINK SERVER.
     * @param degOfParallelism -> numeric value for degree of parallelism
     * @return process corresponding to transfer of data into destSchema. If
     * destSchema already has running process, that process will be returned
     * instead.
     */
    public AsyncSQLProcess executeTransfer(Schema destSchema,
            String srcHost, String srcPort, String srcService,
            String srcSchema, String srcPwd,
            String transferType, String appendFlag, boolean isSameServer,
            String useSidFlag,
            String dataFileDir,
            int degOfParallelism,
            String DataFileDirName,
            String DRTransferEnabled,
            String loginName,
            String sourceDbLink)
            throws Exception;

    //for Oracle to Vertica Data Transfer Using DMexpress
    public AsyncSQLProcess executeTransferForVerticaUsingDMExpress(Schema srcSchema, Schema destSchema, Schema dmExpressSchema,
            int degOfParallelism, long executionNumber)
            throws Exception;

    //for Oracle to Vertica Data Transfer Using CMA
    //runBAModule is used in dr transfer
    public AsyncSQLProcess executeTransferForVerticaUsingCMA(Schema srcSchema, Schema destSchema, long executionNumber, String runBAModule, Schema destOrclSchema)
            throws Exception;

    //for Oracle to Vertica DR Data Transfer Using CMA
    public AsyncSQLProcess executeTransferForVerticaDRUsingCMA(Schema srcSchema, Schema destSchema, long executionNumber)
            throws Exception;

    //for transfer BA module 
    public AsyncSQLProcess executeTransferForBAModules(Schema srcSchema, Schema destSchema, String dataFileDirectoy) throws Exception;

    public AsyncSQLProcess executeTransferForOracleDRBAModules(Schema srcSchema, Schema destSchema, String dataFileDirectoy) throws Exception;

    public TaskKey[] getTaskKeys();

    public TaskKey getActualTaskKey(TaskKey taskKey) throws Exception;

    /**
     * @return Boolean.TRUE if process specified by taskKey killed
     */
    public Boolean killProcess(TaskKey taskKey) throws Exception;

    /**
     * @return List of procedures which are in INVALID state in the specified
     * schema.
     */
    public List getInvalidProcList(Schema schema) throws Exception;

    /**
     * @return status of the oracle database server specified by the schema.
     */
    public OracleSystemData getOracleSystemData(Schema schema) throws Exception;

    /*
     * REPORTING interface
     */
    public List listReportModulesOAM(Schema schema) throws Exception;

    public List listOtherReportModulesOAM(Schema schema) throws Exception;

    public List listReportModulesOAM() throws Exception;

    public void syncReportsByOAM() throws Exception;

    public void syncEngVersionWithOAM() throws Exception;

    public List<Chart> getChartData();

    public List listReportModules() throws Exception;

    public List listReportModules(String reportType) throws Exception;

    public int addReport(Report report) throws Exception;

    public int deleteReport(Report report) throws Exception;

    public int updateReport(Report oldReport, Report newReport) throws Exception;

    public Report getReportByName(String name) throws Exception;

    /*
     * Access SVN
     */
    /**
     * @param user User to login to the source control system
     * @param directory directory url in SVN for which to lis
     * @return listing as returned by the client in string format.
     */
    public String listDirectory(SourceControlUser user, String directory) throws Exception;

    /**
     * @param user User to login to the source control system
     * @param srcDir directory url in SVN from which to checkout.
     * @param distDir directory in which to checkout.
     * @return output as returned by the client in the string format.
     */
    public String checkOut(SourceControlUser user, String srcDir, String destDir) throws Exception;

    public int writeFileFromSVN(SourceControlUser user, String[] srcFiles, String destDir) throws Exception;

    public String[] fetchPreScrub(String clientId) throws Exception;

    public int getIndexCount(Schema s) throws Exception;

    public int getProcNTableCount(Schema s) throws Exception;

    public int getHRHPCount(Schema s) throws Exception;

    public Schema setServerGroupName(Schema s);


    /*----------------------------------------------------------------------*/
 /* Create pre-scrub user */
 /*----------------------------------------------------------------------*/
    /**
     * @param schema pre-scrub schema to create.
     * @param sysUser system user creating the schema
     * @param sysPwd password for user creating the schema
     * @return process corresponding to creating pre-scrub user.
     */
    public AsyncSQLProcess createPreScrubUser(Schema schema, String sysUser, String sysPwd)
            throws Exception;

    public String getClientID(Schema schema) throws Exception;

    public String getEngineVersion(Schema schema) throws Exception;

    public List getEngineVersionList() throws Exception;

    public String getEngineVersionForSchema(String schemaName) throws Exception;

    public String getClientName(String schemaName) throws Exception;

    /**
     * Data Analytics Data Transfer/Import/Scrub
     */
    public AsyncSQLProcess executeImportScrub(Schema importSchema, DataTask dTask, DataScripts dScripts) throws Exception;

    public AsyncSQLProcess importDataTransfer(Schema srcMachineDetail, String srcMachine, String destMachine, String srcLocation, String destLocation, String[] location, String mountDir) throws Exception;

    public List getDataClientList() throws Exception;

    public List getDataTransferMonth(String clientId) throws Exception;

    public void logDataTransferClients(String destMachine, String basepath, String[] copyfiles, String selectedclient) throws Exception;

    public void logDataTransferFolders(String destMachine, String scriptname, String selectedclient, String clientType) throws Exception;

    public String getEdbParameters(String paramname) throws Exception;

    public List getScriptsWithDataLoc(String clientId, String payer, String dataMonth, String[] scriptsname, String prescrubServer, String dataFilePath) throws Exception;

    public boolean saveDefaultFolderbyScriptName(String clientId, String payer, String scriptsname, String foldername, String datamonth, String importserver) throws Exception;

    public List getDefaultScrubScripts(String exeGroup) throws Exception;

    public List getDxCGHostList() throws Exception;

    /**
     * Vertica Data Transfer Details
     */
    public List getErrorDetails(Schema schema, Long execNo);

    public List getErrorDetails_CMA(Schema schema, Long execNo);

    public List getEventDetails(Schema schema, Long execNo);

    public List getTransferSummary(Schema schema, Long execNo);

    public List getTransferSummary_CMA(Schema schema, Long execNo);

    public List getTransferDetails(Schema schema, Long execNo, String is_Transferred);

    public List getTransferDetails_CMA(Schema schema, Long execNo, String is_Transferred);

    public List getVwTransferDetails_CMA(Schema schema, Long execNo, String is_Transferred);

    public int getTotalTableCountFromSource(Schema schema);//counts total table from source oracle server

    public int getTotalViewCountFromSource(Schema schema);

    public boolean isExecuteDMXTask(Schema schema, Long execNo);

    public boolean isCopyDataFromO2V(Schema schema, Long execNo);

    public int getCount(Schema schema, Long execNo, String isTransfered);

    public int getCount_CMA(Schema schema, Long execNo, String isTransferred);

    public int getViewCount_CMA(Schema schema, Long execNo, String isTransferred);

    public long getExecutionNumber() throws Exception;

    public String getDBLink(Schema schema) throws SQLException, CustomException;

    public InputStream getLogFile(Long execNO, String hostingServer) throws Exception;

    public String getShellScriptOutput(Long execNo, String hostingServer) throws Exception;

    public InputStream getOracleBALogFile(Schema schema) throws Exception;

    public Object[] getOracle2VerticaProcessId(String input);

    public boolean killOracleToVerticaProcess(String execNo, String process_Id, String srcServer, String hostingServer);

    public String getHostName(Long executionNo);

    public String getO2VProcessId(String execNo, String srcServer, String hostingServer) throws Exception;//getting oracle to vertica process id from processing server

    public String getCMABatchId(long execNo, Schema schema);

    public String getCMABatchID(String execNo, String srcServer, String hostingServer) throws Exception;//getting oracle to vertica cma batch id from processing server

    public boolean verticaSchemaExists(Schema schema, String newSchemaName) throws Exception;

    public Object[] getTableSpaceAndItsStatus(Schema srcSchema) throws Exception;

    public boolean reTransferTableExists(Schema srcSchema, String reTransferTblName) throws Exception;

    public int checkForReTransfer(Schema srcOrclSchema, Schema destVtkaSchema, Schema centralSchema) throws Exception;

    public boolean isReTransferTblEmpty(Schema srcSchema, String reTransferTblName) throws Exception;

    public boolean oracleSchemaExists(Schema schemaCreator, String schemaName) throws Exception;

    /**
     *
     * Methods for password less design
     */
    public Schema generateSchemaPassword(Schema schema) throws Exception;

    public void insertSchemaInfo(Schema schema) throws Exception;
    
    public void insertNotInSchemaInfo(Schema schema) throws Exception;

    public Schema setSchemaPassword(Schema schema) throws Exception;

    public Schema setSchemaCreatorUserNPwd(Schema schema) throws Exception;

    public boolean isSchemaInfoAlreadyInserted(Schema schema) throws Exception;

    public void insertSchemaInfoForVertica(String serverGroupId, String schemaName, String schemaPwd) throws Exception;

    public boolean dbaObjExists(Schema schema, String objectName, String objectType) throws Exception;

    public String getSchemaPwdFromMappedClusters(Schema schema) throws SQLException;

    /*
	 * Warehouse
     */
    public AsyncSQLProcess executeWareHouse(Schema wareHouseSchema, Schema scrubSchema, Schema frontSchema, WareHouseTask wareHouseTask, String isHRA) throws Exception;

    /*
	 * DR Methods
	 * 1. mapOracleServerGroup ==> Maps oracle rac with oracle dr server group id
	 * 2. mapVerticaServerGroup ==> Maps vertica rac with vertica dr server group id
	 * 3. getVerticaDRSchemaList ==> Returns list for vertica DR schema list for auto DR transfer
	 * 4. getVerticaSchemaList ==> Returns list of vertica  schema list
     * 5. getOrclDRServerGroup ==> Returns mapped oracle dr server group
	 * 6. getOracleDRSchemaList ==> Returns list  of oracle dr schemas
	 * 7. checkTableCount ==> Checks total table count in src and success table count in central server/schema
	 * 8. getOracleMappedServerGroupList ==> Returns map of mapped oracle servergrp ids
	 * 9. getVerticaMappedServerGroupList ==> Returns map of mapped vertica servergrp ids
     */
    public boolean mapOracleServerGroup(String oracleRACServerGroupId, String oracleDRServerGroupId) throws Exception;

    public boolean mapVerticaServerGroup(String verticaRACServerGroupId, String verticaDRServerGroupId) throws Exception;
    //public List<Schema> getVerticaDRSchemaList(Schema verticaRacSchema) throws Exception;

    public List<Schema> getVerticaSchemaList(Schema vtkaSchema) throws Exception;

    public ServerGroup getOrclDRServerGroup(Schema orclSchema) throws Exception;

    public List<Schema> getOracleDRSchemaList(Schema oracleRacSchema) throws CustomException, SQLException;

    public boolean checkTableCount(Schema srcOrclSchema, Schema centralSchema, Long execNo) throws Exception;

    public TreeMap<ServerGroup, ServerGroup> getOracleMappedServerGroupList() throws Exception;

    public TreeMap<String, String> getVerticaMappedServerGroupList() throws Exception;

    public boolean isSchemaStaticallyMapped(Schema orclSchema, Schema vtkaSchema);

    /*
	 * Cluster Group Management methods
	 * 1. getClusterGroupList ==> Lists all the cluster groups
	 * 2. addClusterGroup ==> Adds a cluster group, and returns total no. of cluster added
	 * 3. deleteClusterGroup ==> Deletes a cluster grp and returs total no. of cluster deleted
	 * 4. getServerGroupListByCluster ==> Returns list of server grps in a cluster
	 * 5. getAvailableServerGps ==> Returns list of server grps based on cluster category/type which are not in any clusters. 
	 * 6. assignServerGrpToCluster ==> Assigns/Adds list of server grps to a cluster
	 * 7. deleteServerGrpFromCluster ==> Deletes an mapped server group from a cluster group
	 * 8. mapVerticaClusterGroup ==> Maps Prod Vertica Cluster grp to DR vertica cluster grp
	 * 9. getVerticaMappedClusterGroupList ==> Lists mapped PROD/DR cluster groups
	 * 10. deleteOrclServerGrpMapping ==> Deletes an existing orcl server group mapping.
	 * 11.deleteVtkaClusterGrpMapping ==> Deletes an existing vtka cluster group mapping.
	 * 12.updateIsDeletedFlag ==> Updates isdeleted flag for all the servers in the server groupid
	 * 13.deletePwdEntry ==> Deletes the password entry for all the servers in the server groupid  
     */
    public List getClusterGroupList() throws Exception;

    public int addClusterGroup(String clusterGroup, String clusterType) throws Exception;

    public int deleteClusterGroup(String clusterGroupId) throws Exception;

    public List getServerGroupListByCluster(String clusterGrpId) throws Exception;

    public List getAvailableServerGps(String category) throws Exception;

    public int assignServerGrpToCluster(String clusterGrpId, String[] serverGrps) throws Exception;

    public int deleteServerGrpFromCluster(String clusterGrpId, String serverGrpId) throws Exception;

    public boolean mapVerticaClusterGroup(String prodVerticaClusterGrpId, String drVerticaClusterGrpId) throws Exception;

    public TreeMap<ClusterGroup, ClusterGroup> getVerticaMappedClusterGroupList() throws Exception;

    public int deleteOrclServerGrpMapping(String orclRACServerGrpId, String orclDRServerGrpId) throws Exception;

    public int deleteVtkaClusterGrpMapping(String prodVtkaClusterGrpId, String drVtkaClusterGrpId) throws Exception;

    public int updateIsDeletedFlag(Schema schema, String isDeleted);

    public int deletePwdEntry(Schema schema);

    /*
	 * Split Cluster Design Methods
	 * 1. getClusterGrpDetailsForSchema ==> Gets the cluster groups details for the given schema
	 * 2. listVerticaClusterGrp ==> Lists vertica cluster grps based on cluster type/category
	 * 3. checkSchemaInClusterGrp ==> Checks if a schema exists in a cluster
	 * 4. getAllServerGrpWithServers ==> Lists all the server grps with server lists
	 * 5. getServersForAServerGrp ==> Lists all servers for a server group
	 * 6. isValidVerticaNode ==> Checks if a vertica node is valid by connecting its admin schema 
	 * 7. getVIPServer ==> Gets the VIP server/node for a servergroup
	 * 8. getServerGrpParams ==> Gets %FreeSpace,Total_free_space_mb and minimal_projection_count for a server group
     * 9. checkVIP ==> Checks if the given server is VIP or NOT
	 * 10. getSchemaSize ==> Returns the size of soruce schema in MB
	 * 12. getDRClusterGroup ==> Returns the mapped DR cluster group fro a prod vertica cluster group [Used in autodr transfer]
	 * 
     */
    public ClusterGroup getClusterGrpDetailsForSchema(String clusterGrpId, String schemaName) throws Exception;

    public List<ClusterGroup> listVerticaClusterGrp(String category) throws Exception;

    public Object[] checkSchemaInClusterGrp(ClusterGroup clusterGroup, Schema destVtkaSchema, String event) throws VerticaException;

    public List<Map<ServerGroup, List<Server>>> getAllServerGrpWithServers(ClusterGroup clusterGroup, String event) throws VerticaException;

    public List<Server> getServersForAServerGrp(String serverGroupId) throws Exception;

    public boolean isValidVerticaNode(Schema vtkaSchema);

    public Server getVIPServer(ServerGroup serverGrp) throws Exception;

    public Map<String, Double> getServerGrpParams(Schema vtkaSchema, String event) throws VerticaException;

    public boolean checkVIP(String host) throws Exception;

    public double getSchemaSize(Schema schema, String event) throws VerticaException;

    public ClusterGroup getDRClusterGroup(ClusterGroup prodClusterGroup) throws Exception;

    /*
	 *User Management 
     */
    public List<User> getUserListByUserRole(String userRole, String flag) throws SQLException;

    public int changeUserRole(String userRole, String[] users) throws SQLException;

    public int deleteAllUsersForUserRole(String userRole) throws SQLException;

    /**
     * Scrubbing
     */
    public Map<String, Boolean> getClientSpecificSQLScripts(Schema schema) throws SQLException, CustomException;

    public Map<String, Boolean> getCDFObjScriptsForHP(String CDF_OBJ_SCRIPTS_FOR_HP) throws Exception;

    /**
     * Mini Engine
     */
    public List<String> getInvalidMREPreChecks(Schema vcSchema) throws Exception;

    public List<MREPreCheck> getMrePreCheckForSchema(Schema vcSchema) throws Exception;

    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(Schema orclSchema, Schema vtkaSchema, boolean isTransferToProd, String event) throws VerticaException;
    

    /**
     * @return array of [Boolean, message] after checking given schema. on valid
     * -> [Boolean.TRUE, success message] on invalid -> [Boolean.FALSE, error
     * messge]
     */
    public Object[] isValidReportCount(Schema schema) throws Exception;
    
    public boolean checkDXCGVerification() throws Exception;
}
