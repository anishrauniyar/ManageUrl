package dashboard.engine;

import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

public class TaskType {
    private TaskType() {}

    private String taskName ;
    private String taskLabel;
    private String id;
    private Integer priority;
    public TaskType (String _id, String p, Integer _priority) {
        id = _id;
        taskName = p;
        taskLabel = taskName; 
        priority = _priority;
    }

    public String getTaskLabel(){
        return taskLabel;
    }

    public void setTaskLabel(String taskLabel) {        
        this.taskLabel = taskLabel; 
    }

    public String getTaskName() {
        return taskName;
    }
    public Integer getPriority() {
        return priority;
    }

    public int hashCode() {
        return taskName.hashCode();
    }
    public boolean equals(Object o) {
        if (o instanceof TaskType) {
            TaskType t = (TaskType) o;
            if (t.getTaskName().equals( taskName) &&
                t.getPriority().equals( priority)) {
                return true;
            }
        }
        return false;
    }
    public String getID() {
        return id;
    }
    public String toString() {
        return taskName;
    }

    public static final TaskType NO_TASK = new TaskType("NO_TASK","No Task", new Integer(0));
    public static final TaskType EXECUTE_OBJECT_SCRIPT
        = new TaskType("EXECUTE_OBJECT_SCRIPT",
                       "Execute Object Script", new Integer(1) );
    public static final TaskType COMPILE_ENGINE_SCRIPT = new TaskType("COMPILE_ENGINE_SCRIPT",
                                                                      "Compile Engine Script", new Integer(2));
    public static final TaskType EXECUTE_ENGINE = new TaskType("EXECUTE_ENGINE",
                                                               "Execute Engine", new Integer(3));
    public static final TaskType DXCG_RECORD_COUNT = new TaskType("DXCG Record Count", "DXCG Record Count", new Integer(4));
    public static final TaskType FQC_REPORT = new TaskType("FQC", "FQC Report", new Integer(4));
    public static final TaskType PROCESS_SCRIPT_OR_REPORT = new TaskType("PROCESS_SCRIPT_OR_REPORT",
                                                                         "Process Script/Report", new Integer(4));
    public static final TaskType INDEXING = new TaskType("INDEXING",
                                                         "Indexing", new Integer(6));
    public static final TaskType DATA_TRANSFER = new TaskType("DATA_TRANSFER",
                                                              "Data Transfer", new Integer(7));
    public static final TaskType CREATE_USER = new TaskType("CREATE_USER",
                                                            "Create User", new Integer(0));

    public static final TaskType CREATE_PRESCRUB_USER =  new TaskType("CREATE_PRESCRUB_USER",
                                                            "Create PreScrub User", new Integer(8));

    public static final TaskType SCRUB_TRANSFER = new TaskType("SCRUB_TRANSFER","Scrub Transfer", new Integer(9));
    public static final TaskType FRONT_TRANSFER = new TaskType("FRONT_TRANSFER ","Front Transfer", new Integer(10)); 

    public static final TaskType EXECUTE_IMPORT = new TaskType("EXECUTE_IMPORT","Execute Import",new Integer(11));
	public static final TaskType EXECUTE_SCRUB = new TaskType("EXECUTE_SCRUB","Execute Scrub",new Integer(12));	
	public static final TaskType IMPORT_DATA_TRANSFER =  new TaskType("IMPORT_DATA_TRANSFER","Import Data Transfer", new Integer(13));
	public static final TaskType DR_DATA_TRANSFER = new TaskType("DR_DATA_TRANSFER","DR Data Transfer (ASM)", new Integer(14));
	public static final TaskType CREATE_SYNONYMS_HPNHR = new TaskType("CREATE_SYNONYMS_HPNHR","Create Synonyms (HP&HR)", new Integer(15));
	public static final TaskType CREATE_SYNONYMS_HF = new TaskType("CREATE_SYNONYMS_HF","Create Synonyms (HF)", new Integer(16));
	public static final TaskType COMPLIE_WH_ENGINE_SCRIPT = new TaskType("COMPLIE_WH_ENGINE_SCRIPT","Compile WH Engine Script", new Integer(17));
	public static final TaskType EXECUTE_WH_ENGINE = new TaskType("EXECUTE_WH_ENGINE","Execute WH Engine", new Integer(18));
	public static final TaskType MINI_ENGINE_PRE_CHECK = new TaskType("MINI_ENGINE_PRE_CHECK","Mini Engine Pre-Check", new Integer(19));
	public static final TaskType COMPILE_MINI_ENGINE = new TaskType("COMPILE_MINI_ENGINE","Compile Mini Engine", new Integer(20));
	public static final TaskType EXECUTE_MINI_ENGINE = new TaskType("EXECUTE_MINI_ENGINE","Execute Mini Engine", new Integer(21));
	public static final TaskType EXECUTE_CLIENT_SPEC_SCRIPT = new TaskType("EXECUTE_CLIENT_SPEC_SCRIPT","Execute Client Specfic Script", new Integer(22));
	

    private static HashMap mapTask = new HashMap(15);

    static {
        mapTask.put(NO_TASK.id, NO_TASK);
        mapTask.put(EXECUTE_OBJECT_SCRIPT.id, EXECUTE_OBJECT_SCRIPT);
        mapTask.put(COMPILE_ENGINE_SCRIPT.id, COMPILE_ENGINE_SCRIPT);
        mapTask.put(EXECUTE_ENGINE.id, EXECUTE_ENGINE);
        mapTask.put(PROCESS_SCRIPT_OR_REPORT.id, PROCESS_SCRIPT_OR_REPORT);
        mapTask.put(INDEXING.id, INDEXING);
        mapTask.put(DATA_TRANSFER.id, DATA_TRANSFER);
        mapTask.put(CREATE_USER.id, CREATE_USER);
        mapTask.put(CREATE_PRESCRUB_USER.id, CREATE_PRESCRUB_USER);
        mapTask.put(SCRUB_TRANSFER.id, SCRUB_TRANSFER);
        mapTask.put(FRONT_TRANSFER.id, FRONT_TRANSFER);
        mapTask.put(EXECUTE_IMPORT.id, EXECUTE_IMPORT);
        mapTask.put(EXECUTE_SCRUB.id, EXECUTE_SCRUB);
        mapTask.put(IMPORT_DATA_TRANSFER.id, IMPORT_DATA_TRANSFER);
        mapTask.put(EXECUTE_WH_ENGINE.id, EXECUTE_WH_ENGINE);
        mapTask.put(CREATE_SYNONYMS_HPNHR.id, CREATE_SYNONYMS_HPNHR);
        mapTask.put(CREATE_SYNONYMS_HF.id, CREATE_SYNONYMS_HF);
        mapTask.put(COMPLIE_WH_ENGINE_SCRIPT.id, COMPLIE_WH_ENGINE_SCRIPT);
        mapTask.put(FQC_REPORT.id,FQC_REPORT);
        mapTask.put(COMPILE_MINI_ENGINE.id,COMPILE_MINI_ENGINE);
        mapTask.put(EXECUTE_MINI_ENGINE.id,EXECUTE_MINI_ENGINE);
        mapTask.put(EXECUTE_CLIENT_SPEC_SCRIPT.id,EXECUTE_CLIENT_SPEC_SCRIPT);

    }
    public static final TaskType getTask(String str) {
        if (mapTask.containsKey(str)) {
            return (TaskType) mapTask.get(str);
        } else {
            throw new IllegalArgumentException("Unknow task id:" + str);
        }
    }
    public static final boolean isDefinedTaskId(String tskId) {
        return mapTask.containsKey(tskId);
    }

    public Object clone(){        
        return new TaskType(this.getID(), this.getTaskName(), this.getPriority());
    }

}
