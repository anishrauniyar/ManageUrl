package dashboard.engine;

import java.util.Date;

import dashboard.data.Schema;

public class TaskKey {
    private String
        serverGroupId = "",
        schemaName = "",
        uSgid = "",
        uSname = "",
        dxCGProcessed="";

    private String userName = "";
    
    private Schema schema;

    public TaskKey setServerGroupId(String p) {
        serverGroupId = ifNullBlank(p);
        uSgid = serverGroupId.toUpperCase();
        return this;
    }

    public TaskKey setSchemaName(String p) {
        schemaName = ifNullBlank(p);
        uSname = schemaName.toUpperCase();
        return this;
    }


    public String getServerGroupId() { return serverGroupId; }

    public String getSchemaName() { return schemaName; }
    
    private static final String BLANK = "";
    private static String ifNullBlank(String p) {
        if (p == null) return BLANK;
        return p.trim();
    }

    public int hashCode() {
        return (serverGroupId + uSname).hashCode();
    }
    
    public boolean equals(Object obj) {
        if (obj instanceof TaskKey) {
            TaskKey tskKey = (TaskKey) obj;            
            if (tskKey.uSgid.equalsIgnoreCase( uSgid)
                && tskKey.uSname.equalsIgnoreCase( uSname)) {
                return true;
            }
        }
        return false;
    }

    public TaskKey setSchema(Schema s) {
        schema = s;
        return this;
    }
    public Schema getSchema() {
        return schema;
    }

    private TaskType taskType;
    public TaskKey setTaskType(TaskType t) {
        taskType = t;
        return this;
    }
    public TaskType getTaskType() {
        return taskType;
    }

    private int threadCount = 1;
    public TaskKey setThreadCount(int tc) {
        threadCount = tc;
        return this;
    }
    public int getThreadCount() {
        return threadCount;
    }

    private SQLProcessStatus status = SQLProcessStatus.INIT;
    public TaskKey setSQLProcessStatus(SQLProcessStatus s ) {
        status = s;
        return this;
    }
    public SQLProcessStatus getSQLProcessStatus() {
        return status;
    }

    public TaskKey setUserName(String p) {
        if ( null != p) {
            userName = p.trim();
        }
        return this;
    }

    public String getUserName() {
        return userName;
    }

    private Date stDate = null;
    public TaskKey setStartDate(Date d) {
        if (d != null) {
            stDate = d;
        }
        return this;
    }

    public Date getStartDate() {
        return stDate;
    }

    private boolean existsError = false;
    public void setExistsError( boolean exErr) {
        existsError = exErr;
    }
    public boolean isExistsError() {
        return existsError;
    }

    private long lastUpdate = -1;
    public long getLastUpdate() { return lastUpdate; }
    public void setLastUpdate(long lu) { lastUpdate = lu; }

	public String getDxCGProcessed() {
		return dxCGProcessed;
	}

	public TaskKey setDxCGProcessed(String p) {
		if ( null != p) {
			dxCGProcessed = p.trim();
        }
        return this;
	}
	
	private Long executionNumber= (long) 0;

	public Long getExecutionNumber() {
		return executionNumber;
	}
	public TaskKey setExecutionNumber(Long executionNumber) {
		this.executionNumber = executionNumber;
		return this;
	}
	
	private String destHost = "";
	private String srcHost = "";
	private String srcSchemaName = "";
	
	public String getDestHost() {
		return destHost;
	}

	public TaskKey setDestHost(String destHost) {
		this.destHost = destHost;
		return this;
	}

	public String getSrcHost() {
		return srcHost;
	}

	public TaskKey setSrcHost(String srcHost) {
		this.srcHost = srcHost;
		return this;
	}

	public String getSrcSchemaName() {
		return srcSchemaName;
	}
	public TaskKey setSrcSchemaName(String srcSchemaName) {
		this.srcSchemaName = srcSchemaName;
		return this;
	}
	
	/*
	 * eventDesc and refjobId are used in DrTransfer
	 */
	public String eventDesc = "";

	public String getEventDesc() {
		return eventDesc;
	}

	public TaskKey setEventDesc(String eventDesc) {
		if(this.eventDesc != null){
			this.eventDesc = eventDesc;
		}
		return this;
	}
	
	private String refjobId = "";

	public String getRefjobId() {
		return refjobId;
	}

	public TaskKey setRefjobId(String refjobId) {
		if(null != refjobId){
			this.refjobId = refjobId;
		}
		return this;
	}
	
	/*
	 * For Redirecting async controller
	 */
	private String asyncControllerType = "";

	public String getAsyncControllerType() {
		return asyncControllerType;
	}

	public TaskKey setAsyncControllerType(String asyncControllerType) {
		this.asyncControllerType = asyncControllerType;
		return this;
	}
	
}
