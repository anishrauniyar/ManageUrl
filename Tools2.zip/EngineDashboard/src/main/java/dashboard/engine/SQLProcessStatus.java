package dashboard.engine;

public class SQLProcessStatus {
    private static final String
        N_ERROR = "Error encountered.",
        N_INIT = "Initialized..",
        N_STARTED = "Started",
        N_SCRIPT_MODIFY = "Modifying Script",
        N_RUNNING = "Running",
        N_COMPLETE = "Completed";
    
    private SQLProcessStatus() {}

    String status;
    private SQLProcessStatus(String  st) {
        status = st;
    }
    public int hashCode() {
        return status.hashCode();
    }
    public boolean equals(Object obj) {
        return (obj instanceof SQLProcessStatus) && this.hashCode() == obj.hashCode();
    }

    public static final SQLProcessStatus FAILED = new SQLProcessStatus(N_ERROR);
    public static final SQLProcessStatus INIT = new SQLProcessStatus(N_INIT);
    public static final SQLProcessStatus STARTED = new SQLProcessStatus(N_STARTED);
    public static final SQLProcessStatus SCRIPT_MODIFY = new SQLProcessStatus(N_SCRIPT_MODIFY);
    public static final SQLProcessStatus RUNNING = new SQLProcessStatus(N_RUNNING);
    public static final SQLProcessStatus COMPLETE = new SQLProcessStatus(N_COMPLETE);

    public String toString() {
        return status;
    }
}
