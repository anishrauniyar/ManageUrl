package dashboard.engine.vertica;

import java.util.ArrayList;
import java.util.List;

import dashboard.engine.oracle.NamingUtil;
import dashboard.engine.oracle.OracleUserCreator;
import dashboard.util.CmdRunner;
import dashboard.util.Constants;
import dashboard.util.FileUtil;
import dashboard.web.util.CustomException;

/**
 * This class is used for AutoDRTransfer
 *
 */
public class VerticaSchemaManager extends BaseVerticaManager {

    private boolean schemaInfoInserted = false;

    public VerticaSchemaManager() {
        super();
    }

    public void init() throws Exception {
        logger.info("Inside init method of VerticaSchemaManager");
        setVerticaParams();
        validate();
    }

    public void setVerticaParams() {
        logger.info("Setting Vertica Params >>>>>>>>VerticaSchemaManager.java");
        adminUserName = fixedParam.getValue(Constants.VS_ADMINNAME, hostingServer);
        adminPwd = fixedParam.getValue(Constants.VS_ADMINPWD, hostingServer);
        user = fixedParam.getValue(Constants.VS_USERNAME, hostingServer);
        commandLocation = fixedParam.getValue(Constants.VS_SHFILELOCATION, hostingServer);
        commandName = fixedParam.getValue(Constants.VS_SHFILENAME, hostingServer);
        password = fixedParam.getValue(Constants.VS_PASSWORD, hostingServer);
        privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        vtkaSchema.setHostingServer(hostingServer);// Setting hosting server,if
        // not set then there will be
        // no auto dr transfer

        vtkaSchema.setEngineVersion(orclSchema.getEngineVersion());
        try {
            vtkaSchema.setClientName(engineMonitor.getClientName(vtkaSchema.getSchemaName()));
        } catch (Exception e) {
            logger.error("Error Setting Client Name for Vertica Schema : " + vtkaSchema.getSchemaName(), e);
        }
    }

    public void validate() throws Exception {
        logger.info("Validating >>>>>>>>VerticaSchemaManager.java");
        if (!verticaSchemaExists()) {

            if (schema_info_inserted) {
                logger.info("Vtka Schema " + vtkaSchema.getSchemaName() + " doesnot exists in " + vtkaSchema.getServerName()
                        + " but its info was found in platform_schema_info table");
                reApplyVerticaNodeSelectionAlgo = true;
                /**
                 * Update Records
                 *
                 * int count =
                 * engineMonitor.updateIsDeletedFlag(vtkaSchema,"Y");
                 * logger.info("Updated Is Deleted Flags "+count);
                 */

                /**
                 * Delete pwd records
                 */
                int count = engineMonitor.deletePwdEntry(vtkaSchema);
                logger.info("[VerticaSchemaManager]=>" + count + " pwd entries deleted for server group " + vtkaSchema);

            } else {
                logger.info("Vtka Schema " + vtkaSchema.getSchemaName() + " doesnot exists in " + vtkaSchema.getServerName()
                        + " and its info was not found in platform_schema_info table");
                generateSchemaPwd();
                try {
                    createSchema();
                } catch (Exception e) {
                    int count = engineMonitor.deletePwdEntry(vtkaSchema);
                    logger.info("AUTO DR Transfer Create Schema Error: Total Number of Password entry deleted for "
                            + vtkaSchema.getServerGroupName() + "/" + vtkaSchema.getSchemaName() + ": " + count);
                    throw e;
                }

                checkForError();
                writeToFile();
            }
        } else {
            // simply set vtkaSchema pwd
            logger.info("Vertica vtkaSchema " + vtkaSchema + " already exists. So simply setting pwd in this vtkaSchema>>>>>>>>");
            vtkaSchema = engineMonitor.setSchemaPassword(vtkaSchema);// if could not get password then throws exception, halts the transfer
            // Check connection using this password
            Object[] jbdcResult = engineMonitor.isValid(vtkaSchema.setHostingServer(Constants.VERTICA)); //Confused here need to check
            boolean conn = (Boolean) jbdcResult[0];
            if (!conn) {
                CustomException.assertError("Could not connect vtka schema " + vtkaSchema.getSchemaName() + " using password " + vtkaSchema.getSchemaPwd());
            }
            vtkaSchema.setHostingServer(hostingServer);
        }
    }

    /**
     * Description : Checks if vtkaSchema exists or not
     *
     * @throws Exception
     */
    /*
     * public boolean verticaSchemaExists() throws Exception {
     * logger.info("Checking if vertica vtkaSchema "+vtkaSchema.getSchemaName()+
     * "exists or not >>>>>>>>VerticaSchemaManager.java"); adminSchema =
     * vtkaSchema.getCopy(); adminSchema.setSchemaName(adminUserName);
     * adminSchema.setSchemaPwd(adminPwd); vtkaSchemaExists =
     * engineMonitor.verticaSchemaExists(adminSchema,
     * vtkaSchema.getSchemaName());
     * logger.debug("Vertica Schema "+vtkaSchema.getSchemaName()+
     * " exists on "+vtkaSchema.getServerName()+" : "+schemaCreationOutput);
     * return vtkaSchemaExists; //CustomException.assertTrue(schemaExists,
     * "Vertica Schema "
     * +vtkaSchema.getSchemaName()+" already exists on "+vtkaSchema
     * .getServerName()); }
     */
    /**
     * Description : Generates vtkaSchema pwd if vtkaSchema info not inserted
     *
     * @throws Exception
     */
    public void generateSchemaPwd() throws Exception {
        logger.info("Inside generate vtkaSchema pwd >>> VerticaSchemaManager.java");
        schemaInfoInserted = engineMonitor.isSchemaInfoAlreadyInserted(vtkaSchema);
        if (schemaInfoInserted) {
            logger.info("Schema info already inserted for vtkaSchema " + vtkaSchema + ">>> VerticaSchemaManager.java");
            vtkaSchema = engineMonitor.setSchemaPassword(vtkaSchema);
        } else {
            logger.info("Schema info not inserted for vtkaSchema " + vtkaSchema + ">>> VerticaSchemaManager.java");
            //vtkaSchema = engineMonitor.generateSchemaPassword(vtkaSchema);
            //engineMonitor.insertSchemaInfoForVertica(vtkaSchema.getServerGroupId(), vtkaSchema.getSchemaName(), vtkaSchema.getSchemaPwd());
            /**
             * Using Same Password for Vertica DR Schema
             *
             */
            logger.info("Setting same password >>>>>>>>> ");
            vtkaSchema.setSchemaPwd(getProdVtkaSchemaPwd());
            engineMonitor.insertSchemaInfoForVertica(vtkaSchema.getServerGroupId(), vtkaSchema.getSchemaName(), vtkaSchema.getSchemaPwd());
        }
    }

    public void createSchema() throws Exception {
        logger.info("Creating Vertica Schema  " + vtkaSchema);
        String params = vtkaSchema.getDatabase() + " " + adminUserName + " " + adminPwd + " " + vtkaSchema.getSchemaName() + " "
                + vtkaSchema.getSchemaName() + " " + vtkaSchema.getSchemaPwd();

        String cdCommand = "cd " + commandLocation;
        String shCommand = "sh " + commandName + " " + params;

        List<String> commands = new ArrayList<String>();
        commands.add(cdCommand);
        commands.add(shCommand);

        // logger.info("Command executed for vertica DR vtkaSchema creation " +
        // cdCommand + " " + shCommand);
        schemaCreationOutput = CmdRunner.runCommandsOnShell(false, vtkaSchema.getServerName(), user, password, commands, privateKey);
    }

    public void checkForError() throws CustomException {
        Object[] checkVerticaDbError = getVerticaSchemaCreationError(schemaCreationOutput);
        if (Boolean.TRUE.equals(checkVerticaDbError[0])) {
            String errorMsg = (String) checkVerticaDbError[1];
            /*
             * logger.error("Vertica DR Schema " +
             * destVerticaDRSchema.getSchemaName() + " cannot be created on " +
             * destVerticaDRSchema.getServerName() + ": " + errorMsg);
             */
            CustomException.assertError("Vertica Schema " + vtkaSchema.getSchemaName() + " cannot be created on " + vtkaSchema.getServerName() + ": "
                    + errorMsg);
        }
    }

    public void writeToFile() throws Exception {
        OracleUserCreator oracleUserCreator = new OracleUserCreator();
        oracleUserCreator.setRunnerPassword(vtkaSchema.getSchemaPwd());
        schemaCreationOutput = oracleUserCreator.hidePasswordsForVertica(schemaCreationOutput, hostingServer);

        /* writing vtkaSchema creation shell script output to a file */
        FileUtil.writeToTextFile(schemaCreationOutput, new NamingUtil().getCreateUserFile(vtkaSchema));
    }
}
