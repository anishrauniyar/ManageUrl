package dashboard.engine.vertica;

public class VerticaManagerFactory {

    public static VerticaManager getRequiredManagerBean(boolean isSchemaStaticallyMapped) {
        if (isSchemaStaticallyMapped) {
            return new VerticaStaticMapping();
        }
        return new VerticaSplitCluster();
    }
}
