package dashboard.engine.vertica;

import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.util.Constants;
import dashboard.web.util.CustomException;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class VerticaStaticMapping extends BaseVerticaManager {

    private List<Map<ServerGroup, List<Server>>> sgMapList = null;
    private double srcOrclSchemaSize;

    public VerticaStaticMapping() {
        super();
    }

    @Override
    public void init() throws Exception {
        logger.info("[Initializing Vertica Static Mapping Algorithum for]:" + vtkaSchema);
        setParams();
        try {
            schemaExistResultObj = checkSchemaExistsInClusterGrp();
            boolean schemaExists = (Boolean) schemaExistResultObj[0];
            if (schemaExists) {
                schema_info_inserted = true;
                logger.info("[Inside RETRANSFER case for dest vtka schema " + vtkaSchema.getSchemaName() + " in cluster]:" + clusterGrp);
                Server server = (Server) schemaExistResultObj[1];
                if (checkVerticaNode(server)) {
                    verticaNodeSelecterResult = new Object[]{Boolean.TRUE, server};
                    logger.info("[Vertica node to be used is " + server + " for schema]:" + vtkaSchema.getSchemaName());
                } else {
                    getValidVerticaNode(server.getServerGroupId());
                }
            } else {
                logger.info("[Inside NEW TRANSFER case for dest vtka schema " + vtkaSchema.getSchemaName() + " in cluster]:" + clusterGrp);

                /**
                 * Get Source Oracle Schema Size
                 */
                event = "[NEW-TRANSFER] Getting Source Orace Schema Size";
                logger.info(event);
                srcOrclSchemaSize = engineMonitor.getSchemaSize(orclSchema, event);
                /**
                 * Get mapped server group based on schema
                 */
                sgMapList = getServerGroupMapListBasedOnSchema(orclSchema, vtkaSchema, transferToProduction);
                /**
                 * Check if VIP is DOWN for a server group [Validating Server
                 * Group]
                 */
                sgMapList = validateAvailableServerGrps(sgMapList, VERTICA_STATIC_MAPPING);

                if (sgMapList.size() > 0) {
                    setVerticaNodeSelecterResult(sgMapList, srcOrclSchemaSize);
                } else {
                    logger.error("[Dashboard could not connect to any server groups!! for schema " + this.vtkaSchema + "----Go with Vertica Split Cluster Algorithum]");
                }
            }
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * Method to set necessary parameters
     */
    public void setParams() {
        adminUserName = fixedParam.getValue(Constants.VS_ADMINNAME, hostingServer);
        adminPwd = fixedParam.getValue(Constants.VS_ADMINPWD, hostingServer);
    }

    /**
     *
     * @param vtkaSchema
     * @param transferToProduction
     * @return List of Maps Containing serverGroups With Its Servers
     * @throws Exception
     */
    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(Schema orclSchema, Schema vtkaSchema, boolean transferToProduction) throws Exception {
        event = "[NEW-TRANSFER=> Getting Server Group MapList Based on schema " + vtkaSchema + "]";
        logger.info(event);
        return engineMonitor.getServerGroupMapListBasedOnSchema(orclSchema, vtkaSchema, transferToProduction, event);
    }

    /**
     * Sets result
     *
     * @param sgMapList
     * @param srcOrclSchemaSize
     * @throws Exception
     */
    public void setVerticaNodeSelecterResult(List<Map<ServerGroup, List<Server>>> sgMapList, double srcOrclSchemaSize) throws Exception {
        for (Map<ServerGroup, List<Server>> sgMap : sgMapList) {
            sgMap = setServerGrpParams(sgMap);
            boolean sgSizeLessThanSrcSchema = isServerGrpSizeSmallerThanSrcSchema(sgMap, srcOrclSchemaSize);
            if (!sgSizeLessThanSrcSchema) {
                verticaNodeSelecterResult = getValidVerticaNode(sgMap);
                break;
            }
        }
    }

    public Map<ServerGroup, List<Server>> setServerGrpParams(Map<ServerGroup, List<Server>> sgMap) throws Exception {
        for (Map.Entry<ServerGroup, List<Server>> map : sgMap.entrySet()) {
            ServerGroup serverGroup = map.getKey();
            List<Server> serverList = map.getValue();

            Server vipServer = getVIPNode(serverList);
            if (vipServer != null) {
                Map<String, Double> serverGrpParams = getServerGrpParams(vipServer);
                map.getKey().setPercentFreeSpace(serverGrpParams.get(BaseVerticaManager.SERVERGRP_FREE_SPACE_PERCENT))
                        .setTotal_space_mb(serverGrpParams.get(BaseVerticaManager.SERVERGRP_TOTAL_SPACE_MB))
                        .setProjection_count(serverGrpParams.get(BaseVerticaManager.SERVERGRP_PROJECTION_COUNT));

                // System.out.println("Free Space %" + serverGrpParams.get(BaseVerticaManager.SERVERGRP_FREE_SPACE_PERCENT));
                System.out.println("Total Space (MB)" + serverGrpParams.get(BaseVerticaManager.SERVERGRP_TOTAL_SPACE_MB));
                //System.out.println("Minimal Projection count " + serverGrpParams.get(BaseVerticaManager.SERVERGRP_PROJECTION_COUNT));
            } else {
                // no VIP node
                CustomException.assertNull(vipServer, "Vip node for serverGroup " + serverGroup.getGroupName() + " of cluster group "
                        + clusterGrp.getGroupName() + " not found!!!!!");
            }
        }

        return sgMap;
    }

    /**
     * Checks if servergroup size is less than source schema size
     *
     * @param serverGrpWthServer
     * @return
     * @throws Exception
     */
    public boolean isServerGrpSizeSmallerThanSrcSchema(Map<ServerGroup, List<Server>> serverGrpWthServer, double srcOrclSchemaSize) throws Exception {
        event = "[NEW-TRANSFER=> Comparing server group size with source oracle schema size]";
        for (Map.Entry<ServerGroup, List<Server>> map : serverGrpWthServer.entrySet()) {
            ServerGroup serverGroup = map.getKey();
            if (serverGroup.getTotal_space_mb() < srcOrclSchemaSize) {
                return true;
            }
        }
        return false;
    }

    public Object[] getValidVerticaNode(Map<ServerGroup, List<Server>> sgMap) {
        Object result[] = {Boolean.FALSE, null};
        for (Map.Entry<ServerGroup, List<Server>> map : sgMap.entrySet()) {
            List<Server> servers = map.getValue();
            Random myRandomizer = new Random();
            while (servers.size() > 0) {
                int index = myRandomizer.nextInt(servers.size());
                Server server = servers.get(index);
                if (checkVerticaNode(server)) {
                    // set verticaSplitClusterResult
                    result = new Object[]{Boolean.TRUE, server};
                    break;
                }
                servers.remove(index);
            }
        }
        return result;
    }
}
