package dashboard.engine.vertica;

public class OracleBAManager extends BaseVerticaManager {

    private boolean schemaInfoInserted = false;

    public OracleBAManager() {
        super();
    }

    @Override
    public void init() throws Exception {
        setParams();
        validate();

    }

    public void validate() throws Exception {

        setOrclSchemaPwd();
    }

    public void setParams() {
        //engine version is already set
        orclSchema.setHostingServer(hostingServer);
        try {
            orclSchema.setClientName(engineMonitor.getClientName(orclSchema.getSchemaName()));//setting client name
        } catch (Exception e) {
            logger.error("Error setting client name for destination oracle schema " + orclSchema.getSchemaName(), e);
        }
    }

    public void setOrclSchemaPwd() throws Exception {
        logger.info("Inside generate schema pwd >>> OracleBAManager.java");
        schemaInfoInserted = engineMonitor.isSchemaInfoAlreadyInserted(orclSchema);
        if (schemaInfoInserted) {
            logger.info("Schema info already inserted for schema " + orclSchema + " >>>>>>>OracleBAManager.java");
            orclSchema = engineMonitor.setSchemaPassword(orclSchema);
        } else {
            logger.info("Schema info not inserted for schema " + orclSchema + ">>>>>>>OracleBAManager.java");
            orclSchema.setSchemaPwd(vtkaSchema.getSchemaPwd());// using same pwd
            engineMonitor.insertSchemaInfo(orclSchema);

        }
    }
}
