package dashboard.engine.vertica;

import dashboard.util.Constants;
import dashboard.web.util.CustomException;

public class VerticaTransferValidation extends BaseVerticaManager {

    public VerticaTransferValidation() {
        super();
    }

    @Override
    public void init() throws Exception {
        validate();
    }

    public void validate() throws Exception {
        checkClusterGroup();
        allowTransfer();
        checkTblSpaceStatus();

        //only check for retransfer condition for rac/production transfer
        if (transferToProduction) {
            checkForMapping();
            checkForReTransfer();
        }
    }

    public void allowTransfer() throws CustomException {
        O2VStatus = allowO2VDataTransfer(orclSchema, vtkaSchema);
        if (!O2VStatus.equals("")) {
            logger.info("Oracle to Vertica Data Transfer Process Already Exists (VerticaTransferValidation.java)");
            throw new CustomException(O2VStatus);
        }
    }

    /**
     * Description : Checks orclSchema tablespace status, if it is in read only
     * mode then throws Exception
     *
     * @throws Exception
     */
    public void checkTblSpaceStatus() throws Exception {
        logger.info("Inside Checking tblspaceStatus");
        Object[] obj = null;
        String tableSpaceName = "";
        String tableSpaceStatus = "";
        subDesc = " (Getting password for " + orclSchema.getSchemaName() + " )";
        orclSchema = engineMonitor.setSchemaPassword(orclSchema);

        subDesc = " (Checking tablespace status)";
        obj = engineMonitor.getTableSpaceAndItsStatus(orclSchema);
        tableSpaceStatus = (String) obj[0];
        tableSpaceName = (String) obj[1];
        if (tableSpaceStatus.equalsIgnoreCase(Constants.READ_ONLY)) {
            String msg = "The Vertica Transfer of source schema " + orclSchema.getSchemaName() + " to destination schema " + vtkaSchema.getSchemaName()
                    + " was not done because the tablespace " + tableSpaceName + " of source schema " + orclSchema.getSchemaName() + " is in read only mode."
                    + " Please modify the tablespace " + tableSpaceName
                    + " to read write mode and reinitiate the transfer";
            throw new CustomException(msg);
        }
        subDesc = EMPTY_STRING; //setting empty string, because this value is used in calling method for log.
        logger.info("End of Checking tblspaceStatus");
    }

    /**
     * Method for checking
     *
     * @throws CustomException
     */
    public void checkForMapping() throws CustomException {
        /**
         * VITTOOLS-383 : BA module not in use 
		 *
         */
        /*if(baTransfer)
        {
        	//checkForOrclMapping();
            ServerGroup orclDRServerGroup = null;
            try
            {
                orclDRServerGroup = engineMonitor.getOrclDRServerGroup(destOrclSchema);//here note that destOrclSchema is used
                orclMappingResult[0] = Boolean.TRUE;
                // orclMappingResult[1] = orclSchemaList.get(0).toString();
                orclMappingResult[1] = "Oracle Server Group" + destOrclSchema.getServerGroupName() + " is mapped to " + orclDRServerGroup.getGroupName();
            } catch (Exception e)
            {
                orclMappingResult[0] = Boolean.FALSE;
                orclMappingResult[1] = e.getMessage();
            }
            if(!(Boolean)orclMappingResult[0])
            {
                CustomException.assertError((String)orclMappingResult[1]);
            }
        }*/

        checkForVtkaMapping();
        if (!(Boolean) vtkaMappingResult[0]) {
            CustomException.assertError((String) vtkaMappingResult[1]);
        }
    }

    /**
     * Description: Checks for Retransfer, If retransfer tbl exists and it as no
     * entry then shows message and halts the transfer
     *
     * @throws Exception
     */
    public void checkForReTransferTbl() throws Exception {
        logger.info("Inside checkForReTransferTbl");
        String reTransfer_tblname = fixedParam.getValue(Constants.RETRANSFER_TBLNAME, hostingServer);
        boolean reTransfer_tblExists = false;
        boolean reTransfer_tblEmpty = false;
        subDesc = " (Checking for re-Transfer table)";
        reTransfer_tblExists = engineMonitor.reTransferTableExists(orclSchema, reTransfer_tblname);
        if (reTransfer_tblExists) {
            reTransfer_tblEmpty = engineMonitor.isReTransferTblEmpty(orclSchema, reTransfer_tblname);

            if (reTransfer_tblEmpty) {
                String msg = "This is case of re-transfer!!! Please add necessary tables in " + reTransfer_tblname + " table of source schema "
                        + orclSchema.getSchemaName() + "/" + orclSchema.getServerName();
                logger.info("Re-Transfer case for source schema " + orclSchema.getSchemaName() + " on server " + orclSchema.getServerName()
                        + " initiated by " + "SYSTEM");
                throw new CustomException(msg);
            }
        }
        subDesc = EMPTY_STRING; // if every thing fine, set subDesc to empty
        // string.
        logger.info("End of  checkForReTransfer tbl");
    }

    public void checkForReTransfer() throws Exception {
        logger.info("Checking for retransfer new method!!!!!");
        subDesc = " (Checking for re-Transfer)";
        if (engineMonitor.checkForReTransfer(orclSchema, vtkaSchema, getCentralSchema()) > 0) {
            checkForReTransferTbl();
        }
        subDesc = EMPTY_STRING; // if every thing fine, set subDesc to empty
        // string.
    }
}
