package dashboard.engine.vertica;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.TaskKey;
import dashboard.util.Constants;
import dashboard.util.FileUtil;
import dashboard.web.util.CustomException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public abstract class BaseVerticaManager implements VerticaManager {

    protected ComponentFactory compFactory;
    protected FixedParameter fixedParam;
    protected Schema vtkaSchema;
    protected Schema orclSchema;
    protected Schema adminSchema;
    protected EngineMonitor engineMonitor;

    protected String hostingServer = Constants.VERTICA_CMA;

    // Vertica Fixed Parameters
    protected String adminUserName;
    protected String adminPwd;
    protected String user;
    protected String commandLocation;
    protected String commandName;
    protected String password;
    protected String privateKey;

    protected String schemaCreationOutput;
    protected boolean vtkaSchemaExists;
    protected String O2VStatus;
    protected String subDesc;
    protected Log logger = LogFactory.getLog(getClass());

    protected final String EMPTY_STRING = "";

    // *ConnectionTester Parameters
    protected boolean dataTransferScriptFound = false;
    protected boolean schemaCreationScriptFound = false;
    protected String dataTransferScript_Error = "";
    protected String schemaCreationScript_Error = "";
    protected Object[] orclJdbcResult
            = {Boolean.FALSE, ""};
    protected Object[] vtkJdbcResult
            = {Boolean.FALSE, ""};
    protected String tblSpaceStatus;
    protected boolean tblSpaceStatus_Error = false;
    // protected boolean autoDR = false;
    protected Object[] orclMappingResult
            = {Boolean.FALSE, ""};
    protected Object[] vtkaMappingResult
            = {Boolean.FALSE, ""};

    // VerticaTransferValidation parameter to check transferToProduction
    protected boolean transferToProduction = false;
    // Flag to check if BA is checked
    protected boolean baTransfer = false;

    /*
     * SPLIT CLUSTER
     */
    protected ClusterGroup clusterGrp;
    protected Object[] schemaExistResultObj;
    protected Object[] verticaNodeSelecterResult
            = {Boolean.FALSE, null};
    // flag to check if schema info inserted in processing.platform_schema_info
    protected boolean schema_info_inserted = false;
    // flag to check if the split cluster algo is to re-apply or not
    protected boolean reApplyVerticaNodeSelectionAlgo = false;
    protected String event = "";
    protected Schema destOrclSchema;

    // Production vtka Schema pwd [since pwd must be same for both prod and dr vtka schema: VITTOOLS-358]
    protected String prodVtkaSchemaPwd = "";

    // Vertica Node Selecter
    protected String VERTICA_SPLIT_CLUSTER = "VERTICA_SPLIT_CLUSTER";
    protected String VERTICA_STATIC_MAPPING = "VERTICA_STATIC_MAPPING";
    protected boolean isSchemaStaticallyMapped;
    protected BaseVerticaManager vtkaConnTester;
    protected boolean nodeFound;

    protected BaseVerticaManager() {
        compFactory = ComponentFactory.getInstance();
        fixedParam = compFactory.getFixedParameters();
    }

    /*
     * Description : Checking for error pattern for vertica schema creation
     */
    private static final String VERTICA_DB_ERROR = "FATAL.*";
    private static final Pattern PAT_VERTICA_DB_ERROR = Pattern.compile(VERTICA_DB_ERROR, Pattern.MULTILINE);

    public Object[] getVerticaSchemaCreationError(String input) {
        Object[] ret = new Object[]{Boolean.FALSE, ""};
        if (null == input) {
            return ret;
        }

        StringBuilder sb = new StringBuilder();
        Matcher m = PAT_VERTICA_DB_ERROR.matcher(input);
        while (m.find()) {
            ret[0] = Boolean.TRUE;
            sb.append(m.group()).append("\n");
        }
        ret[1] = sb.toString();
        return ret;
    }

    /**
     * Description : Checks if transfer is ongoing using same source host and
     * schema or in same dest vertica schema
     *
     * @param srcSchema
     * @param destSchema
     * @return
     */
    protected synchronized String allowO2VDataTransfer(Schema srcSchema, Schema destSchema) {
        logger.info("Checking if oracle to vertica data transfer is already running from BaseManager.java");
        TaskKey[] taskKeys = engineMonitor.getTaskKeys();
        String O2VStatus = "";
        if (taskKeys != null) {
            for (TaskKey taskKey : taskKeys) {

                // checking for source server
                if ((taskKey.getSrcHost().equals(srcSchema.getServerName())) && (taskKey.getSrcSchemaName().equals(srcSchema.getSchemaName()))) {
                    logger.info("Data Transfer Process in already taking place in " + srcSchema.getServerName() + "/" + srcSchema.getSchemaName());
                    O2VStatus = "Data Transfer Process in already taking place in " + srcSchema.getServerName() + "/" + srcSchema.getSchemaName();
                    break;
                }

                // checking for destination server
                if ((taskKey.getServerGroupId().equals(destSchema.getServerGroupId()))
                        && (taskKey.getSchemaName().equals(destSchema.getSchemaName()))) {
                    logger.info("Data Transfer Process in already taking place in " + destSchema.getServerGroupName() + "/"
                            + destSchema.getSchemaName());
                    O2VStatus = "Data Transfer Process in already taking place in " + destSchema.getServerGroupName() + "/"
                            + destSchema.getSchemaName();
                    break;
                }
            }
        }

        return O2VStatus;
    }

    /**
     * @Description: To check if vtkaSchema exists in a clusterGrp
     * @return
     * @throws Exception
     */
    public Object[] checkSchemaExistsInClusterGrp() throws Exception {
        event = "[RE-TRANSFER=>Checking Schema " + vtkaSchema.getSchemaName() + " exits in Cluster Group " + clusterGrp.getGroupName() + "]";
        logger.info(event);
        return engineMonitor.checkSchemaInClusterGrp(clusterGrp, vtkaSchema, event);
    }

    /**
     * @Description: Check if server is valid vertica node [Note: Here VIP Node
     * will be avoided]
     * @param server
     * @return
     */
    public boolean checkVerticaNode(Server server) {
        logger.info("Inside checkVerticaNode. Checking vtka node " + server);
        if (server.getIsVip().equals("Y")) {
            logger.info("Avoiding VIP node " + server);
            return false;
        }
        Schema vtkaSchema = new Schema().setServerGroupId(server.getServerGroupId()).setSchemaName(adminUserName).setSchemaPwd(adminPwd)
                .setServerName(server.getHost()).setPort(String.valueOf(server.getPort())).setDatabase(server.getDatabase());
        return engineMonitor.isValidVerticaNode(vtkaSchema);
    }

    /**
     * @Description: Sets a valid vertica node from the tempServerList of
     * serverGroupId randomly
     * @param serverGroupId
     * @throws Exception
     */
    public void getValidVerticaNode(String serverGroupId) throws Exception {
        logger.info("Inside getValidVerticaNode with serverGroupId " + serverGroupId);
        List<Server> tempServerList = engineMonitor.getServersForAServerGrp(serverGroupId);
        // List<Server> tempServerList = new ArrayList<Server>(serverList);
        Random myRandomizer = new Random();
        while (tempServerList.size() > 0) {
            int index = myRandomizer.nextInt(tempServerList.size());
            Server server = tempServerList.get(index);
            if (checkVerticaNode(server)) {
                // set verticaSplitClusterResult
                verticaNodeSelecterResult = new Object[]{Boolean.TRUE, server};
                break;
            }
            tempServerList.remove(index);
        }

    }

    /**
     * @Description : Returns the vip node from the serverlist
     * @param serverList
     * @return VIP node from the serverList if exists, else return a null object
     */
    public Server getVIPNode(List<Server> serverList) {
        for (Server s : serverList) {
            if (s.getIsVip().equals("Y")) {
                return s;
            }
        }
        return null;
    }

    /**
     * @Description : Gets the server group params by connecting to given server
     * using admin schema/pwd
     * @param server
     * @return
     * @throws Exception
     */
    public Map<String, Double> getServerGrpParams(Server server) throws Exception {
        event = "[NEW-TRANSFER=> Getting Server Group Params from Server " + server.getHost() + ":" + server.getPort() + "/" + server.getDatabase()
                + " of Cluster Group " + clusterGrp.getGroupName() + "]";
        logger.info(event);
        Schema vtkaSchema = new Schema().setServerGroupId(server.getServerGroupId()).setSchemaName(adminUserName).setSchemaPwd(adminPwd)
                .setServerName(server.getHost()).setPort(String.valueOf(server.getPort())).setDatabase(server.getDatabase());
        logger.info("Vertica vip schema is " + vtkaSchema);
        return engineMonitor.getServerGrpParams(vtkaSchema, event);
    }

    /**
     *
     * @param sgMapList
     * @return up/running servergroup
     * @throws java.lang.Exception
     */
    public List<Map<ServerGroup, List<Server>>> validateAvailableServerGrps(List<Map<ServerGroup, List<Server>>> sgMapList, String algoName) throws Exception {
        logger.info("[Validating Server Groups for schema]:" + this.vtkaSchema);
        List<Map<ServerGroup, List<Server>>> validSGs = new ArrayList<>();
        for (int i = 0; i < sgMapList.size(); i++) {
            Map<ServerGroup, List<Server>> sgMap = sgMapList.get(i);
            for (Map.Entry<ServerGroup, List<Server>> map : sgMap.entrySet()) {
                ServerGroup serverGroup = map.getKey();
                List<Server> serverList = map.getValue();
                Server vipServer = getVIPNode(serverList);
                if (vipServer != null) {
                    Schema vtkaSchema = new Schema().setServerGroupId(vipServer.getServerGroupId()).setSchemaName(adminUserName).setSchemaPwd(adminPwd)
                            .setServerName(vipServer.getHost()).setPort(String.valueOf(vipServer.getPort())).setDatabase(vipServer.getDatabase());
                    if (engineMonitor.isValidVerticaNode(vtkaSchema)) {
//                       logger.info("VIP node"+vtkaSchema+" is down!!! So removing it!!");
//                        sgMap.remove(map.getKey());
                        validSGs.add(sgMap);
                    } else {
                        logger.info("[" + algoName + " , VIP node " + vipServer + " will be ignored]");
                    }
                } else {
                    // no VIP node
                    CustomException.assertNull(vipServer, "Vip node for serverGroup " + serverGroup.getGroupName() + " of cluster group "
                            + clusterGrp.getGroupName() + " not found!!!!!");
                }
            }
        }
        return validSGs;
    }

    /**
     * Description : Checks if vtkaSchema exists or not * @throws Exception
     */
    public boolean verticaSchemaExists() throws Exception {
        logger.info("Checking if vertica vtkaSchema " + vtkaSchema.getSchemaName() + "exists or not >>>>>>>>BaseManager.java");
        adminSchema = vtkaSchema.getCopy();
        adminSchema.setSchemaName(adminUserName);
        adminSchema.setSchemaPwd(adminPwd);
        vtkaSchemaExists = engineMonitor.verticaSchemaExists(adminSchema, vtkaSchema.getSchemaName());
        logger.debug("Vertica Schema " + vtkaSchema.getSchemaName() + " exists on " + vtkaSchema.getServerName() + " : " + schemaCreationOutput);
        return vtkaSchemaExists;
    }

    /**
     * @param schema
     * @return true if file exists
     * @throws Exception
     */
    public boolean remoteFileExists(Schema schema) throws Exception {
        return FileUtil.isRemoteFileExists(schema.getServerName(), user, password, privateKey, commandLocation, commandName);
    }

    /**
     * @param schema
     * @return Jdbc Connection result for the given schema
     * @throws Exception
     */
    public Object[] testJdbcConn(Schema schema) throws Exception {
        Object jdbcResult[] = null;
        schema = engineMonitor.setSchemaPassword(schema);
        jdbcResult = engineMonitor.isValid(schema);
        return jdbcResult;
    }

    public Schema getCentralSchema() {
        return (new Schema()).setServerName(fixedParam.getValue(Constants.CS_HOST, hostingServer))
                .setPort(fixedParam.getValue(Constants.CS_PORT, hostingServer)).setService(fixedParam.getValue(Constants.CS_SERVICE, hostingServer))
                .setSchemaName(fixedParam.getValue(Constants.CS_SCHEMA, hostingServer))
                .setSchemaPwd(fixedParam.getValue(Constants.CS_SCHEMAPWD, hostingServer));
    }

    /**
     * Description : Checks for mapping for selected destination oracle ba
     * schema Note: Only called for autoDR = true condition i.e oracle to
     * vertica rac transfer
     *
     */
    protected void checkForOrclMapping() {
        ServerGroup orclDRServerGroup = null;
        try {
            orclDRServerGroup = engineMonitor.getOrclDRServerGroup(orclSchema);
            orclMappingResult[0] = Boolean.TRUE;
            // orclMappingResult[1] = orclSchemaList.get(0).toString();
            orclMappingResult[1] = "Oracle Server Group " + orclSchema.getServerGroupName() + " is mapped to " + orclDRServerGroup.getGroupName();
        } catch (Exception e) {
            orclMappingResult[0] = Boolean.FALSE;
            orclMappingResult[1] = e.getMessage();
        }
    }

    /**
     * Description : Checks for mapping for selected destination vertic schema
     * Note: Only called for autoDR = true condition i.e oracle to vertica rac
     * transfer
     *
     */
    protected void checkForVtkaMapping() {
        // List<Schema> vtkaSchemaList = null;
        ClusterGroup prodClusterGroup = new ClusterGroup().setClusterGroupId(vtkaSchema.getClusterGroupId()).setGroupName(
                vtkaSchema.getClusterGroupName());
        ClusterGroup drClusterGrp = null;
        try {
            // vtkaSchemaList =
            // engineMonitor.getVerticaDRSchemaList(vtkaSchema);
            // System.out.println("Size of list is "+vtkaSchemaList.size());
            drClusterGrp = engineMonitor.getDRClusterGroup(prodClusterGroup);
            vtkaMappingResult[0] = Boolean.TRUE;
            // vtkaMappingResult[1] = vtkaSchemaList.get(0).toString();
            vtkaMappingResult[1] = "Production Vertica " + prodClusterGroup.getGroupName() + " is mapped to " + drClusterGrp.getGroupName();
        } catch (Exception e) {
            vtkaMappingResult[0] = Boolean.FALSE;
            vtkaMappingResult[1] = e.getMessage();// error message
        }
    }

    /**
     * @Description: Method used to identify if the schema exists in the cluster
     * group selected by user
     * @throws Exception
     */
    public void checkClusterGroup() throws Exception {
        logger.info("Checking if vertica schema " + vtkaSchema.getSchemaName() + " exists in " + vtkaSchema.getClusterGroupId() + ":"
                + vtkaSchema.getClusterGroupName());
        ClusterGroup clusterGrp = engineMonitor.getClusterGrpDetailsForSchema(vtkaSchema.getClusterGroupId(), vtkaSchema.getSchemaName());
        if (clusterGrp != null) {
            // i.e. schema exits is a cluster group
            // Check if this cluster group matches the cluster group provided by
            // user
            if (!clusterGrp.getClusterGroupId().equalsIgnoreCase(vtkaSchema.getClusterGroupId())) {
                logger.info("Vertica Schema " + vtkaSchema.getSchemaName() + " was found in different cluster " + clusterGrp.getGroupName());
                CustomException.assertError("Schema " + vtkaSchema.getSchemaName() + " was found in different cluster " + clusterGrp.getGroupName()
                        + " Please correct the cluster group selection !!!");
            }
        }
    }

    @Override
    public Schema getVtkaSchema() {
        return vtkaSchema;
    }

    public BaseVerticaManager setVtkaSchema(Schema vtkaSchema) {
        this.vtkaSchema = vtkaSchema;
        return this;
    }

    public Schema getAdminSchema() {
        return adminSchema;
    }

    public void setAdminSchema(Schema adminSchema) {
        this.adminSchema = adminSchema;
    }

    public EngineMonitor getEngineMonitor() {
        return engineMonitor;
    }

    @Override
    public BaseVerticaManager setEngineMonitor(EngineMonitor engineMonitor) {
        this.engineMonitor = engineMonitor;
        return this;
    }

    public String getHostingServer() {
        return hostingServer;
    }

    @Override
    public BaseVerticaManager setHostingServer(String hostingServer) {
        this.hostingServer = hostingServer;
        return this;
    }

    @Override
    public String getSchemaCreationOutput() {
        return schemaCreationOutput;
    }

    public void setSchemaCreationOutput(String schemaCreationOutput) {
        this.schemaCreationOutput = schemaCreationOutput;
    }

    @Override
    public Schema getOrclSchema() {
        return orclSchema;
    }

    public BaseVerticaManager setOrclSchema(Schema orclSchema) {
        this.orclSchema = orclSchema;
        return this;
    }

    @Override
    public boolean isVtkaSchemaExists() {
        return vtkaSchemaExists;
    }

    public void setVtkaSchemaExists(boolean vtkaSchemaExists) {
        this.vtkaSchemaExists = vtkaSchemaExists;
    }

    @Override
    public String getO2VStatus() {
        return O2VStatus;
    }

    public void setO2VStatus(String o2vStatus) {
        O2VStatus = o2vStatus;
    }

    @Override
    public String getSubDesc() {
        if (subDesc == null) {
            return EMPTY_STRING;
        }
        return subDesc;
    }

    public void setSubDesc(String subDesc) {
        this.subDesc = subDesc;
    }

    @Override
    public boolean isDataTransferScriptFound() {
        return dataTransferScriptFound;
    }

    public void setDataTransferScriptFound(boolean dataTransferScriptFound) {
        this.dataTransferScriptFound = dataTransferScriptFound;
    }

    @Override
    public boolean isSchemaCreationScriptFound() {
        return schemaCreationScriptFound;
    }

    public void setSchemaCreationScriptFound(boolean schemaCreationScriptFound) {
        this.schemaCreationScriptFound = schemaCreationScriptFound;
    }

    @Override
    public String getDataTransferScript_Error() {
        return dataTransferScript_Error;
    }

    public void setDataTransferScript_Error(String dataTransferScript_Error) {
        this.dataTransferScript_Error = dataTransferScript_Error;
    }

    @Override
    public String getSchemaCreationScript_Error() {
        return schemaCreationScript_Error;
    }

    public void setSchemaCreationScript_Error(String schemaCreationScript_Error) {
        this.schemaCreationScript_Error = schemaCreationScript_Error;
    }

    @Override
    public Object[] getOrclJdbcResult() {
        return orclJdbcResult;
    }

    public void setOrclJdbcResult(Object[] orclJdbcResult) {
        this.orclJdbcResult = orclJdbcResult;
    }

    @Override
    public Object[] getVtkJdbcResult() {
        return vtkJdbcResult;
    }

    public void setVtkJdbcResult(Object[] vtkJdbcResult) {
        this.vtkJdbcResult = vtkJdbcResult;
    }

    @Override
    public String getTblSpaceStatus() {
        return tblSpaceStatus;
    }

    public void setTblSpaceStatus(String tblSpaceStatus) {
        this.tblSpaceStatus = tblSpaceStatus;
    }

    @Override
    public boolean isTblSpaceStatus_Error() {
        return tblSpaceStatus_Error;
    }

    public void setTblSpaceStatus_Error(boolean tblSpaceStatus_Error) {
        this.tblSpaceStatus_Error = tblSpaceStatus_Error;
    }

    @Override
    public Object[] getOrclMappingResult() {
        return orclMappingResult;
    }

    public void setOrclMappingResult(Object[] orclMappingResult) {
        this.orclMappingResult = orclMappingResult;
    }

    @Override
    public Object[] getVtkaMappingResult() {
        return vtkaMappingResult;
    }

    public void setVtkaMappingResult(Object[] vtkaMappingResult) {
        this.vtkaMappingResult = vtkaMappingResult;
    }

    public boolean isTransferToProduction() {
        return transferToProduction;
    }

    @Override
    public BaseVerticaManager setTransferToProduction(boolean transferToProduction) {
        this.transferToProduction = transferToProduction;
        return this;
    }

    public boolean isBaTransfer() {
        return baTransfer;
    }

    public BaseVerticaManager setBaTransfer(boolean baTransfer) {
        this.baTransfer = baTransfer;
        return this;
    }

    public ClusterGroup getClusterGrp() {
        return clusterGrp;
    }

    @Override
    public BaseVerticaManager setClusterGrp(ClusterGroup clusterGrp) {
        this.clusterGrp = clusterGrp;
        return this;
    }

    @Override
    public Object[] getVtkaNodeSelecterResult() {
        return verticaNodeSelecterResult;
    }

    @Override
    public boolean isSchema_info_inserted() {
        return schema_info_inserted;
    }

    public BaseVerticaManager setSchema_info_inserted(boolean schema_info_inserted) {
        this.schema_info_inserted = schema_info_inserted;
        return this;
    }

    @Override
    public boolean isReApplyVtkaNodeSelectionAlgo() {
        return reApplyVerticaNodeSelectionAlgo;
    }

    public void setReApplyVerticaNodeSelectionAlgo(boolean reApplyVerticaNodeSelectionAlgo) {
        this.reApplyVerticaNodeSelectionAlgo = reApplyVerticaNodeSelectionAlgo;
    }

    public Schema getDestOrclSchema() {
        return destOrclSchema;
    }

    public BaseVerticaManager setDestOrclSchema(Schema destOrclSchema) {
        this.destOrclSchema = destOrclSchema;
        return this;
    }

    public String getProdVtkaSchemaPwd() {
        return prodVtkaSchemaPwd;
    }

    public BaseVerticaManager setProdVtkaSchemaPwd(String prodVtkaSchemaPwd) {
        this.prodVtkaSchemaPwd = prodVtkaSchemaPwd;
        return this;
    }

    @Override
    public boolean isSchemaStaticallyMapped() {
        return this.isSchemaStaticallyMapped;
    }

    public BaseVerticaManager setIsSchemaStaticallyMapped(boolean isSchemaStaticallyMapped) {
        this.isSchemaStaticallyMapped = isSchemaStaticallyMapped;
        return this;
    }

    @Override
    public BaseVerticaManager getVtkaConnTester() {
        return vtkaConnTester;
    }

    @Override
    public boolean isNodeFound() {
        return nodeFound;
    }
}
