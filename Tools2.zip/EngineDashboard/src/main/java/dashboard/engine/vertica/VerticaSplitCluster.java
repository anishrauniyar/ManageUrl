package dashboard.engine.vertica;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.util.Constants;
import dashboard.util.SendMail;
import dashboard.web.util.CustomException;

/**
 * @Description : Class used for vertica split cluster design.
 * @Note: Make sure to set the following parameters of the BaseManager Class 1.
 * hostingServer 2. clusterGrp 3. engineMonitor 4. vtkaSchema 5.orclSchema
 *
 */
public class VerticaSplitCluster extends BaseVerticaManager {

    /**
     * Will contain all the serverGroups with there corresponding serverLists
     * for a cluster
     */
    private List<Map<ServerGroup, List<Server>>> serverGrpsWithServerLists = null;
    /**
     * Will contain ONLY the serverGroups with there corresponding serverLists
     * for a cluster whose free space percent is > 40% [i.e. >0.4]
     */
    private List<Map<ServerGroup, List<Server>>> serverGrpswithServerLists1 = null;
    /**
     * Temporary list containing serverGroups with there corresponding
     * serverLists for a cluster
     */
    private List<Map<ServerGroup, List<Server>>> serverGrpswithServerLists2 = null;

    /**
     * Constructor
     */
    public VerticaSplitCluster() {
        super();
    }

    @Override
    public void init() throws Exception {
        logger.info("Applying vertica split cluster algorithum from schema " + vtkaSchema);
        setParams();

        try {
            /**
             * STEP 1: Check if the Destination Vtka Schema [vtkaSchema] exists
             * in the Cluster Group clusterGrp
             */
            schemaExistResultObj = checkSchemaExistsInClusterGrp();
            boolean schemaExists = (Boolean) schemaExistResultObj[0];
            if (schemaExists) {
                /**
                 * ********************* RETRANSFER CASE **********************
                 */
                /**
                 * Step 1.1: [RETRANSFER CASE] If Destination Vtka Schema
                 * [vtkaSchema] already exists then, get the server [server] in
                 * which it exists
                 */
                schema_info_inserted = true;
                logger.info("Inside RETRANSFER case for dest vtka schema " + vtkaSchema.getSchemaName() + " in cluster " + clusterGrp
                        + " [VerticaSplitCluster.java] ");
                Server server = (Server) schemaExistResultObj[1];
                if (checkVerticaNode(server)) {
                    /**
                     * Step 1.2: [RETRANSFER CASE] a. Check the [server] is up
                     * {This is done by connecting to admin schema} b. If it is
                     * up, set the server in [verticaSplitClusterResult] object
                     *
                     */
                    verticaNodeSelecterResult = new Object[]{Boolean.TRUE, server};
                    logger.info("Vertica node to be used is " + server + "for schema" + vtkaSchema.getSchemaName() + " [VerticaSplitCluster.java] ");
                } else {
                    /**
                     * Step 1.3: [RETRANSFER CASE] Contd..{1.2} Else get a
                     * up/running random vertica node from the servergroup id of
                     * that [server]
                     */
                    getValidVerticaNode(server.getServerGroupId());
                }
            } else {
                /**
                 * ********************* FRESH/NEW TRANSFER CASE
                 * **********************
                 */
                logger.info("Inside NEW TRANSFER case for dest vtka schema " + vtkaSchema.getSchemaName() + " in cluster " + clusterGrp
                        + " [VerticaSplitCluster.java] ");
                /**
                 * Step 2: [NEW TRANSFER CASE] Get all server groups with their
                 * servers [Note: Including VIPs]
                 */
                serverGrpsWithServerLists = getAllServerGrpsWithServer();

                /**
                 * New method, validating server groups
                 */
                serverGrpsWithServerLists = validateAvailableServerGrps(serverGrpsWithServerLists, VERTICA_SPLIT_CLUSTER);

                /**
                 * Step 2.1 [NEW TRANSFER CASE] Set the Server Groups Parameters
                 * for each Server Groups [Server Groups Parameters :
                 * percentFreeSpace,total_space_mb and projection_count]
                 */
                serverGrpsWithServerLists = setServerGrpParams(serverGrpsWithServerLists);

                /**
                 * Step 2.2 [NEW TRANSFER CASE] Checking free space percent for
                 * each server group 2.2.1: Add Server Groups with Free Space <
                 * Manager.SERVERGRP_MINIMUM_FREE_SPACE_PERCENT to
                 * serverGrpswithServerLists2 2.2.2: And that >
                 * Manager.SERVERGRP_MINIMUM_FREE_SPACE_PERCENT to
                 * serverGrpswithServerLists1
                 */
                checkServerGrpFreeSpacePercent(serverGrpsWithServerLists);

                if (!serverGrpswithServerLists2.isEmpty()) {
                    /**
                     * If [serverGrpswithServerLists2] is not empty, send email
                     * , not done for now
                     */
                    logger.info("Some server groups free space is <40%");
                    sendMail(serverGrpswithServerLists2);
                }

                /**
                 * Step 2.3 [NEW TRANSFER CASE] Getting Source schema size
                 */
                serverGrpswithServerLists1 = checkSourceSchemaSize(serverGrpswithServerLists1);
                if (serverGrpswithServerLists1.isEmpty()) {
                    /**
                     * Step 2.4 [NEW TRANSFER CASE] If
                     * [serverGrpswithServerLists1] is empty {i.e. Source schema
                     * size > all the server groups in cluster}
                     */
                    CustomException.assertError("Source schema size is greater than the cluster group !!!");

                } else if (serverGrpswithServerLists2.isEmpty()) {
                    /**
                     * Step 2.5 [NEW TRANSFER CASE] If
                     * [serverGrpswithServerLists2] is empty {i.e. All Server
                     * Group free space is > source schema size}, get server
                     * group with minimal project count and get the valid node
                     * from it
                     */
                    logger.info("Inside serverGrpswithServerLists2 empty condition");
                    ServerGroup serverGrp = checkMinimalProjectionCount(serverGrpswithServerLists1);
                    getValidVerticaNode(serverGrp.getServerGroupId());
                } else {
                    /**
                     * Step 2.5 [NEW TRANSFER CASE] Else, get server group with
                     * maximum free space, and get the valid node from it
                     */
                    logger.info("Inside else condition");
                    ServerGroup serverGrp = checkMaximumFreeSpace(serverGrpswithServerLists1);
                    getValidVerticaNode(serverGrp.getServerGroupId());
                }
            }
        } catch (Exception e) {
            throw e;
        }

    }

    /**
     * @Descrition: Method to set necessary parameters
     */
    public void setParams() {
        adminUserName = fixedParam.getValue(Constants.VS_ADMINNAME, hostingServer);
        adminPwd = fixedParam.getValue(Constants.VS_ADMINPWD, hostingServer);
    }

    /**
     * ********************************** FOR NEW SCHEMA
     * ***********************************
     */
    /**
     * @return ServerGroup with ServerList
     * @throws Exception
     */
    public List<Map<ServerGroup, List<Server>>> getAllServerGrpsWithServer() throws Exception {
        event = "[NEW-TRANSFER=> Getting All ServerGroups/Servers for Cluster Group " + clusterGrp.getGroupName() + "]";
        logger.info(event);
        return engineMonitor.getAllServerGrpWithServers(clusterGrp, event);
    }

    /**
     * @Description: Sets serverGroupParams[i.e. 1.SERVERGRP_PERCENT_FREE_SPACE
     * 2.SERVERGRP_TOTAL_SPACE_MB 3.SERVERGRP_PROJECTION_COUNT] by connecting a
     * random node in that server group
     * @param serverGrpsWithServerLists
     * @return List<Map<ServerGroup, List<Server>>> with serverGrpParams set
     * @throws Exception
     */
    public List<Map<ServerGroup, List<Server>>> setServerGrpParams(List<Map<ServerGroup, List<Server>>> serverGrpsWithServerLists) throws Exception {
        logger.info("Inside setServerGrpParams [VerticaSplitCluster.java] ");
        if (serverGrpsWithServerLists.size() > 0) {
            for (int i = 0; i < serverGrpsWithServerLists.size(); i++) {
                Map<ServerGroup, List<Server>> serverGrpWithServerList = serverGrpsWithServerLists.get(i);
                for (Map.Entry<ServerGroup, List<Server>> map : serverGrpWithServerList.entrySet()) {

                    ServerGroup serverGroup = map.getKey();
                    List<Server> serverList = map.getValue();

                    Server vipServer = getVIPNode(serverList);
                    if (vipServer != null) {
                        Map<String, Double> serverGrpParams = getServerGrpParams(vipServer);
                        map.getKey().setPercentFreeSpace(serverGrpParams.get(BaseVerticaManager.SERVERGRP_FREE_SPACE_PERCENT))
                                .setTotal_space_mb(serverGrpParams.get(BaseVerticaManager.SERVERGRP_TOTAL_SPACE_MB))
                                .setProjection_count(serverGrpParams.get(BaseVerticaManager.SERVERGRP_PROJECTION_COUNT));

                        System.out.println("Free Space %" + serverGrpParams.get(BaseVerticaManager.SERVERGRP_FREE_SPACE_PERCENT));
                        System.out.println("Total Space (MB)" + serverGrpParams.get(BaseVerticaManager.SERVERGRP_TOTAL_SPACE_MB));
                        System.out.println("Minimal Projection count " + serverGrpParams.get(BaseVerticaManager.SERVERGRP_PROJECTION_COUNT));
                    } else {
                        // no VIP node
                        CustomException.assertNull(vipServer, "Vip node for serverGroup " + serverGroup.getGroupName() + " of cluster group "
                                + clusterGrp.getGroupName() + " not found!!!!!");
                    }
                    /*
                 * List<Server> serverList = map.getValue(); Server server =
                 * getValidVerticaNode(serverList);// gets random // server with
                 * // vertica // checked if (server != null) { Map<String,
                 * Double> serverGrpParams = getServerGrpParams(server);
                 * map.getKey
                 * ().setPercentFreeSpace(serverGrpParams.get(BaseManager
                 * .SERVERGRP_FREE_SPACE_PERCENT))
                 * .setTotal_space_mb(serverGrpParams
                 * .get(BaseManager.SERVERGRP_TOTAL_SPACE_MB))
                 * .setProjection_count
                 * (serverGrpParams.get(BaseManager.SERVERGRP_PROJECTION_COUNT
                 * )); } else { // all vtka nodes are down for a servergroup
                 * logger.error("All servers are down for serverGroup " +
                 * map.getKey().getGroupName()); }
                     */
                }
            }
        } else {
            CustomException.assertError("All VIP nodes are down for the selected cluster!!!!");
        }

        return serverGrpsWithServerLists;
    }

    /**
     * @Description: Returns a server with vertica check from the serverList
     * @param serverList
     * @return a valid vertica node from the given serverList
     */
    public Server getValidVerticaNode(List<Server> serverList) {
        Random myRandomizer = new Random();
        while (serverList.size() > 0) {
            int index = myRandomizer.nextInt(serverList.size());
            Server server = serverList.get(index);
            if (checkVerticaNode(server)) {
                return server;
            }
            serverList.remove(index);
        }

        return null;
    }

    /**
     * @Description : Gets the server group params by connecting to given server
     * using admin schema/pwd
     * @param server
     * @return
     * @throws Exception
     */
    public Map<String, Double> getServerGrpParams(Server server) throws Exception {
        event = "[NEW-TRANSFER=> Getting Server Group Params from Server " + server.getHost() + ":" + server.getPort() + "/" + server.getDatabase()
                + " of Cluster Group " + clusterGrp.getGroupName() + "]";
        logger.info(event);
        Schema vtkaSchema = new Schema().setServerGroupId(server.getServerGroupId()).setSchemaName(adminUserName).setSchemaPwd(adminPwd)
                .setServerName(server.getHost()).setPort(String.valueOf(server.getPort())).setDatabase(server.getDatabase());
        logger.info("Vertica vip schema is " + vtkaSchema);
        return engineMonitor.getServerGrpParams(vtkaSchema, event);
    }

    /**
     * @Description: Adds given serverGrpsWithServerLists with free percent <
     *               40% to serverGroupsWithServerLists2 and > 40% to
     * serverGroupsWithServerLists1
     * @param serverGrpsWithServerLists
     */
    public void checkServerGrpFreeSpacePercent(List<Map<ServerGroup, List<Server>>> serverGrpsWithServerLists) {
        serverGrpswithServerLists1 = new ArrayList<Map<ServerGroup, List<Server>>>();
        serverGrpswithServerLists2 = new ArrayList<Map<ServerGroup, List<Server>>>();
        for (int i = 0; i < serverGrpsWithServerLists.size(); i++) {
            Map<ServerGroup, List<Server>> serverGrpWithServerList = serverGrpsWithServerLists.get(i);
            for (Map.Entry<ServerGroup, List<Server>> map : serverGrpWithServerList.entrySet()) {
                //ServerGroup serverGrp = map.getKey();
                //if (serverGrp.getPercentFreeSpace() < BaseVerticaManager.SERVERGRP_MINIMUM_FREE_SPACE_PERCENT) {
                //    serverGrpswithServerLists2.add(serverGrpWithServerList);
                ///} else {
                	
                    serverGrpswithServerLists1.add(serverGrpWithServerList);
               // }
            }
        }
    }

    /**
     * @Description : Compares serverGroup size with the source oracle schema.
     * ServerGroup with total size < srcSchema size is placed in
     * serverGrpswithServerLists2 @param serverGrpsWithServerLists @return
     * @throws Excep t i on
     */
    public List<Map<ServerGroup, List<Server>>> checkSourceSchemaSize(List<Map<ServerGroup, List<Server>>> serverGrpsWithServerLists)
            throws Exception {
        event = "[NEW-TRANSFER=> Getting Source Schema " + orclSchema + " Size]";
        // Emptying the list serverGrpswithServerLists2
        serverGrpswithServerLists2.clear();
        double orclSchemaSize = engineMonitor.getSchemaSize(orclSchema, event);
        for (int i = 0; i < serverGrpsWithServerLists.size(); i++) {
            Map<ServerGroup, List<Server>> serverGrpWithServerList = serverGrpsWithServerLists.get(i);
            for (Map.Entry<ServerGroup, List<Server>> map : serverGrpWithServerList.entrySet()) {
                ServerGroup serverGroup = map.getKey();
                if (serverGroup.getTotal_space_mb() < orclSchemaSize) {
                    serverGrpswithServerLists2.add(serverGrpWithServerList);
                    serverGrpsWithServerLists.remove(i);
                }
            }
        }
        return serverGrpsWithServerLists;
    }

    /**
     * @Description: To find the server group with minimal projection count
     * @param serverGrpsWithServerList
     * @return Server Group with minimal Project count
     */
    public ServerGroup checkMinimalProjectionCount(List<Map<ServerGroup, List<Server>>> serverGrpsWithServerList) {
        logger.info("Checking Minimal Projection Count");
        ServerGroup serverGrpWithMinProjCount = null;
        Map<ServerGroup, Double> testMap = new HashMap<ServerGroup, Double>();
        for (Map<ServerGroup, List<Server>> maps : serverGrpsWithServerList) {
            for (Map.Entry<ServerGroup, List<Server>> map : maps.entrySet()) {
                testMap.put(map.getKey(), map.getKey().getProjection_count());
            }
        }

        Double minValue = Double.MAX_VALUE;
        for (Map.Entry<ServerGroup, Double> entry : testMap.entrySet()) {
            if (entry.getValue() < minValue) {
                minValue = entry.getValue();
                serverGrpWithMinProjCount = entry.getKey();
                System.out.println("Minimum proj count is " + entry.getValue());
            }
        }

        return serverGrpWithMinProjCount;
    }

    /**
     * @Description: To find the server group with maximum free space
     * @param serverGrpsWithServerList
     * @return Server Group with max free space
     */
    public ServerGroup checkMaximumFreeSpace(List<Map<ServerGroup, List<Server>>> serverGrpsWithServerList) {
        logger.info("Checking Max free space");
        ServerGroup serverGrpWithMaxFreeSpace = null;
        Map<ServerGroup, Double> testMap = new HashMap<ServerGroup, Double>();
        for (Map<ServerGroup, List<Server>> maps : serverGrpsWithServerList) {
            for (Map.Entry<ServerGroup, List<Server>> map : maps.entrySet()) {
                testMap.put(map.getKey(), map.getKey().getTotal_space_mb());
            }
        }

        Double maxValue = Double.MIN_VALUE;
        for (Map.Entry<ServerGroup, Double> entry : testMap.entrySet()) {
            if (entry.getValue() > maxValue) {
                maxValue = entry.getValue();
                serverGrpWithMaxFreeSpace = entry.getKey();
                System.out.println("Server Group having maximum free space for a cluster group " + clusterGrp.getGroupName() + " is "
                        + serverGrpWithMaxFreeSpace);
            }
        }

        return serverGrpWithMaxFreeSpace;
    }

    /**
     * @Description: Method used to send mail for the server groups with free
     * space less that 40%
     * @param serverGrpsWithServerList
     * @throws Exception
     */
    public void sendMail(List<Map<ServerGroup, List<Server>>> serverGrpsWithServerList) {
        logger.info("Sending mail from VerticaSplitClusters ");
        String messageSubject = "SERVER GROUPS WITH FREE SPACE LESS THAN 40%";
        String message = "Following server groups have free space percent <40% " + " \n\n<br><br> ";
        message += "<ul>";
        for (Map<ServerGroup, List<Server>> maps : serverGrpsWithServerList) {
            for (Map.Entry<ServerGroup, List<Server>> map : maps.entrySet()) {
                Server server = getVIPNode(map.getValue());
                message += "<li> Server Group: " + map.getKey().getGroupName();
                if (server != null) {
                    message += " [Vip Node : " + server.getHost() + ":" + server.getPort() + "/" + server.getDatabase() + "]";
                } else {
                    message += " [Vip Node : Not Found]";
                }
                message += " </li>";
            }
        }
        message += "</ul>";
        SendMail sendMail;
        try {
            sendMail = new SendMail();
            sendMail.send("EDB@verscend.com", messageSubject, message);
        } catch (Exception e) {
            logger.error("VerticaSplitCluster->sendMail: Could not send email ", e);
            e.printStackTrace();
        }

    }
}
