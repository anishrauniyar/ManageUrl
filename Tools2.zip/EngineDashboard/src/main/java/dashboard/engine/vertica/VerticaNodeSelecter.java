package dashboard.engine.vertica;

import dashboard.data.Server;

public class VerticaNodeSelecter extends BaseVerticaManager {

    @Override
    public void init() throws Exception {
        if (isSchemaStaticallyMapped) {
            getNodeViaVtkaStaticMapping();
        } else {
            getNodeViaVtkaSplitCluster(Boolean.FALSE);
        }
    }

    /**
     * Gettting Node via Static Mapping
     *
     * @throws Exception
     */
    public void getNodeViaVtkaStaticMapping() throws Exception {
        logger.info("[Getting Vtka Node via Static Mapping Algorithum for schema]:" + this.vtkaSchema);
        VerticaManager verticaStaticMapping = new VerticaStaticMapping();
        verticaStaticMapping.setHostingServer(this.hostingServer).setClusterGrp(this.clusterGrp).setEngineMonitor(this.engineMonitor)
                .setVtkaSchema(this.vtkaSchema).setOrclSchema(this.orclSchema).setTransferToProduction(this.transferToProduction);

        verticaStaticMapping.init();
        Object[] result = verticaStaticMapping.getVtkaNodeSelecterResult();
        if ((Boolean) result[0]) {
            nodeFound = Boolean.TRUE;
            setServerInfoInSchema(result);
            vtkaConnTester = (new VerticaConnectionTester()).setHostingServer(this.hostingServer)
                    .setEngineMonitor(this.engineMonitor).setVtkaSchema(this.vtkaSchema)
                    .setTransferToProduction(this.transferToProduction)
                    .setSchema_info_inserted(verticaStaticMapping.isSchema_info_inserted());

            vtkaConnTester.init();
            if (vtkaConnTester.isReApplyVtkaNodeSelectionAlgo()) {
                logger.info("[ReValidating for vtka static mapping case]:" + this.vtkaSchema);
                vtkaConnTester = (new VerticaConnectionTester()).setHostingServer(this.hostingServer)
                        .setEngineMonitor(this.engineMonitor).setVtkaSchema(this.vtkaSchema)
                        .setTransferToProduction(this.transferToProduction)
                        .setSchema_info_inserted(Boolean.FALSE);// because pwd entry will already be deleted
                vtkaConnTester.init();
            }
        } else {
            getNodeViaVtkaSplitCluster(Boolean.TRUE);
        }
    }

    /**
     * Getting Node via Split Cluster
     *
     * @param isPassedFromStaticMapping
     * @throws Exception
     */
    public void getNodeViaVtkaSplitCluster(boolean isPassedFromStaticMapping) throws Exception {
        logger.info("[Getting Vtka Node via Split Cluster Algorithum for schema]:" + this.vtkaSchema
                + "[Is Passed from vtka Static Mapping]:" + isPassedFromStaticMapping);
        VerticaManager verticaSplitCluster = new VerticaSplitCluster();
        verticaSplitCluster.setHostingServer(this.hostingServer).setClusterGrp(this.clusterGrp).setEngineMonitor(this.engineMonitor)
                .setVtkaSchema(this.vtkaSchema).setOrclSchema(this.orclSchema).setTransferToProduction(this.transferToProduction);

        verticaSplitCluster.init();
        Object[] result = verticaSplitCluster.getVtkaNodeSelecterResult();
        if ((Boolean) result[0]) {
            nodeFound = Boolean.TRUE;
            setServerInfoInSchema(result);
            vtkaConnTester = (new VerticaConnectionTester()).setHostingServer(this.hostingServer)
                    .setEngineMonitor(engineMonitor).setVtkaSchema(this.vtkaSchema)
                    .setTransferToProduction(this.transferToProduction)
                    .setSchema_info_inserted(verticaSplitCluster.isSchema_info_inserted());

            vtkaConnTester.init();
            if (vtkaConnTester.isReApplyVtkaNodeSelectionAlgo()) {
                logger.info("[ReApplying Vertica Split Cluster Algorithum for schema]:" + this.vtkaSchema);
                verticaSplitCluster = new VerticaSplitCluster();
                verticaSplitCluster.setHostingServer(this.hostingServer).setClusterGrp(this.clusterGrp).setEngineMonitor(this.engineMonitor)
                        .setVtkaSchema(this.vtkaSchema).setOrclSchema(this.orclSchema).setTransferToProduction(this.transferToProduction);
                verticaSplitCluster.init();
                result = verticaSplitCluster.getVtkaNodeSelecterResult();
                if ((Boolean) result[0]) {
                    nodeFound = Boolean.TRUE;
                    vtkaConnTester = (new VerticaConnectionTester()).setHostingServer(this.hostingServer)
                            .setEngineMonitor(engineMonitor).setVtkaSchema(this.vtkaSchema)
                            .setTransferToProduction(this.isTransferToProduction())
                            .setSchema_info_inserted(verticaSplitCluster.isSchema_info_inserted());
                    vtkaConnTester.init();
                } else {
                    nodeFound = Boolean.FALSE;
                }
            }
        } else {
            nodeFound = Boolean.FALSE;
        }
    }

    public void setServerInfoInSchema(Object[] result) {
        Server destVtkaServer = (Server) result[1];
        this.vtkaSchema.setServerGroupId(destVtkaServer.getServerGroupId());
        this.vtkaSchema.setServerName(destVtkaServer.getHost());
        this.vtkaSchema.setPort(String.valueOf(destVtkaServer.getPort()));
        this.vtkaSchema.setService(destVtkaServer.getDatabase());
        this.vtkaSchema.setDatabase(destVtkaServer.getDatabase());
        this.vtkaSchema.setDatabaseId(destVtkaServer.getDatabaseId());
        engineMonitor.setServerGroupName(this.vtkaSchema);

        logger.info("Final Schema from Vtka Node Selecter is " + this.vtkaSchema);
    }

}
