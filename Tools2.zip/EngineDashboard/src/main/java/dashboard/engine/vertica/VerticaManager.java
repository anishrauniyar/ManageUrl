package dashboard.engine.vertica;

import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.engine.EngineMonitor;

public interface VerticaManager {

    public BaseVerticaManager setEngineMonitor(EngineMonitor engineMonitor);

    public BaseVerticaManager setHostingServer(String hostingServer);

    public void init() throws Exception;

    public String getSchemaCreationOutput();

    public Schema getVtkaSchema();// vertica schema

    public Schema getOrclSchema();// oracle schema

    public boolean isVtkaSchemaExists();// vertica schema exists or not

    public String getSubDesc();// getting sub description

    public String getO2VStatus();

    // Connection tester
    public boolean isDataTransferScriptFound();

    public boolean isSchemaCreationScriptFound();

    public String getDataTransferScript_Error();

    public String getSchemaCreationScript_Error();

    public Object[] getOrclJdbcResult();

    public Object[] getVtkJdbcResult();

    public String getTblSpaceStatus();

    public boolean isTblSpaceStatus_Error();

    //public BaseManager setAutoDR(boolean autoDR);
    public Object[] getOrclMappingResult();

    public Object[] getVtkaMappingResult();

    // Vertica Transfer Validation
    public BaseVerticaManager setTransferToProduction(boolean transferToProduction);

    // VERTICA SPLIT CLUSTER
    public String SERVERGRP_FREE_SPACE_PERCENT = "SERVERGRP_FREE_SPACE_PERCENT";
    public String SERVERGRP_TOTAL_SPACE_MB = "SERVERGRP_TOTAL_SPACE_MB";
    public String SERVERGRP_PROJECTION_COUNT = "SERVERGRP_PROJECTION_COUNT";
    public double SERVERGRP_MINIMUM_FREE_SPACE_PERCENT = 0.01;

    public BaseVerticaManager setClusterGrp(ClusterGroup clusterGrp);

    public Object[] getVtkaNodeSelecterResult();

    public boolean isSchema_info_inserted();

    public boolean isReApplyVtkaNodeSelectionAlgo();

    public boolean isSchemaStaticallyMapped();

    public BaseVerticaManager getVtkaConnTester();

    public boolean isNodeFound();
}
