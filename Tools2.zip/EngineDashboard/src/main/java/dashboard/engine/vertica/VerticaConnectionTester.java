package dashboard.engine.vertica;

import dashboard.util.Constants;

public class VerticaConnectionTester extends BaseVerticaManager {

    public VerticaConnectionTester() {
        super();
    }

    @Override
    public void init() throws Exception {
        setParams();
        validate();

    }

    public void setParams() {
        commandLocation = fixedParam.getValue(Constants.VS_SHFILELOCATION, hostingServer);
        commandName = fixedParam.getValue(Constants.VS_SHFILENAME, hostingServer);
        user = fixedParam.getValue(Constants.VS_USERNAME, hostingServer);
        password = fixedParam.getValue(Constants.VS_PASSWORD, hostingServer);
        adminUserName = fixedParam.getValue(Constants.VS_ADMINNAME, hostingServer);
        adminPwd = fixedParam.getValue(Constants.VS_ADMINPWD, hostingServer);
        privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        //vtkaSchema.setHostingServer(hostingServer);
    }

    public void validate() {
        try {
            checkClusterGroup();
            vtkaSchemaExists = verticaSchemaExists();// physically exists
            if (vtkaSchemaExists) {
                testJdbcConn();
            } else if (!vtkaSchemaExists && schema_info_inserted) {
                logger.info("Vertica Schema doesnot exists in " + vtkaSchema.getServerName()
                        + " BUT its entry was found in platform_schema_info table");
                reApplyVerticaNodeSelectionAlgo = true;
                /*
				 * Update records
				 * 
				 * int count =
				 * engineMonitor.updateIsDeletedFlag(vtkaSchema,"Y");
				 * logger.info("Updated Is Deleted Flags "+count);
                 */
                /**
                 * Delete pwd records
                 */
                int count = engineMonitor.deletePwdEntry(vtkaSchema);
                logger.info("[VerticaConnectionTester]=>" + count + " pwd entries deleted for server group " + vtkaSchema);

            } else {
                logger.info("Vertica Schema " + vtkaSchema.getSchemaName() + " does not exists on " + vtkaSchema.getServerName());
                vtkJdbcResult = new Object[]{Boolean.TRUE, "Schema " + vtkaSchema.getSchemaName() + " doesnot exists on " + vtkaSchema.getServerName()};
            }
        } catch (Exception e) {
            vtkJdbcResult = new Object[]{Boolean.FALSE, e.getMessage()};
            logger.error("Error while checking vertica schema " + vtkaSchema.getSchemaName() + " on  server " + vtkaSchema.getServerName() + ": "
                    + e.toString());
            e.printStackTrace();
        }

        logger.info("Destination Vertica Server: Vertica  Jdbc connection on " + vtkaSchema.getServerName() + " using schema: " + vtkaSchema
                + " ????: " + (Boolean) vtkJdbcResult[0]);

        if (!reApplyVerticaNodeSelectionAlgo) {
            // Checking if schema creation scripts exists
            schemaCreationScriptExists();
            // oracle to vertica rac transfer
            if (transferToProduction) {
                checkForVtkaMapping();
            }

        }
    }

    /**
     * Checking whether vertica schema creation scripts exists on vertica server
     */
    public void schemaCreationScriptExists() {
        try {
            schemaCreationScriptFound = remoteFileExists(vtkaSchema);
        } catch (Exception e) {
            logger.error("Error on checking file " + commandName + " on filepath " + commandLocation + " for server " + vtkaSchema.getServerName()
                    + " using " + user + "/" + password + " :" + e.toString());
            e.printStackTrace();
            schemaCreationScript_Error = e.toString();
        }

        logger.info("Script " + commandName + " in " + commandLocation + " of server " + vtkaSchema.getServerName() + " found??? "
                + schemaCreationScriptFound);
    }

    /**
     * Testing Jdbc Connection
     */
    public void testJdbcConn() {
        try {
            vtkJdbcResult = testJdbcConn(vtkaSchema);
        } catch (Exception e) {
            logger.error("OracleConnectionTester>>>>>> Error getting password for vertica schema " + vtkaSchema.getSchemaName()
                    + " with database id " + vtkaSchema.getDatabaseId());
            e.printStackTrace();
            vtkJdbcResult = new Object[]{Boolean.FALSE, e.getMessage()};

        }
    }
}
