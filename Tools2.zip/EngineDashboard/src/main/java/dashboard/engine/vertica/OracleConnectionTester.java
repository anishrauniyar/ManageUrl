package dashboard.engine.vertica;

import dashboard.util.Constants;

public class OracleConnectionTester extends BaseVerticaManager {

    public OracleConnectionTester() {
        super();
    }

    @Override
    public void init() throws Exception {
        setParams();
        validate();

    }

    /**
     * Setting parameters for Oracle Connection Testing
     */
    public void setParams() {
        commandLocation = fixedParam.getValue(Constants.OS_SHFILELOCATION, hostingServer);
        commandName = fixedParam.getValue(Constants.OS_SHFILENAME, hostingServer);
        user = fixedParam.getValue(Constants.OS_USERNAME, hostingServer);
        password = fixedParam.getValue(Constants.OS_PASSWORD, hostingServer);
        privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

        orclSchema.setHostingServer(hostingServer);
    }

    /**
     * Validations
     */
    public void validate() {
        dataTransferScriptExists();
        testJdbcConn();
        checkTblSpaceStatus();

        logger.info("Source Oracle Server: Oracle Jdbc connection on " + orclSchema.getServerName() + " using schema: " + orclSchema + " ????: "
                + (Boolean) orclJdbcResult[0]);

    }

    /**
     * Checking whether data transfer scripts exists on oracle server
     */
    public void dataTransferScriptExists() {
        try {
            dataTransferScriptFound = remoteFileExists(orclSchema);
        } catch (Exception e) {
            logger.error("Error on checking file " + commandName + " on filepath " + commandLocation + " for server " + orclSchema.getServerName()
                    + " using " + user + "/" + password + " :" + e.toString());
            e.printStackTrace();
            dataTransferScript_Error = e.toString();
        }

        logger.info("Script " + commandName + " in " + commandLocation + " of server " + orclSchema.getServerName() + " found??? "
                + dataTransferScriptFound);
    }

    /**
     * Testing Jdbc Connection Note: orclSchema password is set here
     */
    public void testJdbcConn() {
        try {
            orclJdbcResult = testJdbcConn(orclSchema);
        } catch (Exception e) {
            logger.error("OracleConnectionTester>>>>>> Error getting password for source oracle schema " + orclSchema.getSchemaName()
                    + " with database id " + orclSchema.getDatabaseId());
            e.printStackTrace();
            orclJdbcResult = new Object[]{Boolean.FALSE, e.getMessage()};

        }
    }

    public void checkTblSpaceStatus() {
        Object[] obj = null;
        String tableSpaceName = "";
        String tableSpaceStatus = "";

        try {
            orclSchema = engineMonitor.setSchemaPassword(orclSchema);
            obj = engineMonitor.getTableSpaceAndItsStatus(orclSchema);
            tableSpaceStatus = (String) obj[0];
            tableSpaceName = (String) obj[1];
            //error when tablespace status is in READ ONLY mode
            if (tableSpaceStatus.equalsIgnoreCase(Constants.READ_ONLY)) {
                tblSpaceStatus_Error = true;
            }
            tblSpaceStatus = "Table space " + tableSpaceName + " is in " + tableSpaceStatus + " mode";
        } catch (Exception e) {
            tblSpaceStatus_Error = true;
            tblSpaceStatus = e.getMessage();

        }

    }

}
