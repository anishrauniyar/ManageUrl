package dashboard.engine.vertica;

public class OracleBAConnectionTester extends BaseVerticaManager {

    public OracleBAConnectionTester() {
        super();
    }

    @Override
    public void init() throws Exception {
        setParams();
        validate();

    }

    /**
     * Setting required parameters for oracleBAConnectionTesting
     */
    public void setParams() {
        orclSchema.setHostingServer(hostingServer);
    }

    public void validate() {
        try {
            if (VIPServer()) {
                testJdbcConn();
                // vertica rac transfer condition
                if (transferToProduction) {
                    checkForOrclMapping();
                }
            }
            /*else
            {
                orclJdbcResult = new Object[]
                { Boolean.FALSE, "Host " + orclSchema.getServerName() + " is not VIP server" };
                
                orclMappingResult[0] = Boolean.FALSE;
                orclMappingResult[1] = "Host " + orclSchema.getServerName() + " is not VIP server";
            }*/
        } catch (Exception e) {
            orclJdbcResult = new Object[]{Boolean.FALSE, e.getMessage()};

            orclMappingResult[0] = Boolean.FALSE;
            orclMappingResult[1] = e.getMessage();
        }
    }

    /*
     * Check if server is VIP
     */
    public boolean VIPServer() throws Exception {
        return engineMonitor.checkVIP(orclSchema.getServerName());
    }

    /**
     * Performs jdbc connections for given orcl schema
     */
    public void testJdbcConn() {
        try {
            orclJdbcResult = testJdbcConn(orclSchema);
        } catch (Exception e) {
            logger.error("OracleBAConnectionTester>>>>>> Error getting password for source oracle schema " + orclSchema.getSchemaName()
                    + " with database id " + orclSchema.getDatabaseId());
            e.printStackTrace();
            orclJdbcResult = new Object[]{Boolean.FALSE, e.getMessage()};

        }

        logger.info("Destination Oracle Server: Oracle Jdbc connection on " + orclSchema.getServerName() + " using schema: " + orclSchema + " ????: "
                + orclSchema);
    }
}
