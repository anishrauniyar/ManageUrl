package dashboard.engine;

import java.util.List;
public class InvalidProcListException extends RuntimeException {
    private List procList = null;
    public InvalidProcListException(String msg, List ls) {
        super(msg);
        procList = ls;
    }
    public String getMessage() {
        StringBuffer sb = new StringBuffer();
        sb.append(super.getMessage());
        if (procList != null && !procList.isEmpty()) {
            sb.append(" INVALID Proc List->");

            for(int i=0;  procList != null && i < procList.size(); i++) {
                sb.append(" ").append(i).append(". ").append( procList.get(i).toString());
            }
        }
        return sb.toString();
    }

}
