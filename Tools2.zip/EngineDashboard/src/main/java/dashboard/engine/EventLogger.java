package dashboard.engine;

import java.text.DateFormat;
import java.util.Date;

import dashboard.data.Schema;

public interface EventLogger {
    public void logStart(String user, String event, String desc, int threadCount, Date startDate, Schema schema,Long executionId);
    public void logEnd(String user, String event, String desc, int threadCount, Date startDate, Date endDate,
                       int retStatus, Schema schema);
    public void logError(String user, String event, String desc, int threadCount, Date startDate, Date endDate,
                         Exception ex, Schema schema);
    public void logError(String user, String event, String desc, int threadCount, Date startDate, Date endDate,
                         String errorMessage, Schema schema);
    
    public void logErrorForDrTransfer(Date endDate, String exStr,String executionNumber);

    public Object [] showLogForUser(String user, int page, DateFormat df)
        throws Exception;    
}

