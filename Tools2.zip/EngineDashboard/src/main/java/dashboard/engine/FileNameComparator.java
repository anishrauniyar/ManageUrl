package dashboard.engine;

import java.io.File;

public class FileNameComparator implements java.util.Comparator {
    public FileNameComparator() {}

    public int compare(Object obj1, Object obj2) {
        if ( null == obj1 && null == obj1) return 0;
        if ( null == obj1 && null != obj2) return -1;
        if ( null != obj1 && null == obj2) return 1;
        String val1 = null;
        String val2 = null;

        if ( obj1 instanceof File) {
            File file1 = (File) obj1;
            val1 = file1.getName();
        } else {
            val1 = obj1.toString();
        }
        if ( obj2 instanceof File) {
            File file2 = (File) obj2;
            val2 = file2.getName();
        } else {
            val2 = obj2.toString();
        }


        return val1.compareToIgnoreCase(val2);
    }
    public boolean equals(Object obj) {                                
        return false;
    }
}
