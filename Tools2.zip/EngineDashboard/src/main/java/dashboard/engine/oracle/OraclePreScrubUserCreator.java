package dashboard.engine.oracle;


import java.io.File;
import java.util.List;
import java.util.LinkedList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import dashboard.ComponentFactory;
import dashboard.data.TaskTypeNFile;
import dashboard.data.Schema;
import dashboard.data.EngineReplacementData;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;

import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;

import dashboard.db.OracleDBConnector;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


public class OraclePreScrubUserCreator extends BaseSQLPlusRunnable {
    
    ComponentFactory compFactory;
    EnvInfo env;
    String rootDir;
    String createAndGrandDir;
    List ls;

    protected Log logger = LogFactory.getLog(getClass());

    
    public OraclePreScrubUserCreator() {
        compFactory = ComponentFactory.getInstance();
        env = compFactory.getEnvInfo();
        ls = new LinkedList();
    }


    String desc = "Create PreScrub User";
    public String getDescription() {
        return desc;
    }

    public TaskType getTaskType() {
        return TaskType.CREATE_PRESCRUB_USER;
    }


    private File generateScriptToCreateSchema()
        throws Exception {
        Schema schema = getSchema();
        String createPreScrubUserScript = ComponentFactory.getInstance()
            .getEngineConverter().getCreatePreScrubUserScript( schema);
        File scriptFile = (new NamingUtil()).getCreatePreScrubUserFile(schema);
        FileUtil.writeToTextFile( createPreScrubUserScript, scriptFile);
        return scriptFile;
    }

    public void init() throws Exception {
        File scriptFile = generateScriptToCreateSchema( );
        Schema schema = getSchema();
        sqlPlusUrl = OracleDBConnector.getTnsStyleUrl( getRunnerSchema() );
        desc = "Create PreScrub User: [" +
            schema.getServerGroupName() + "] " +
            schema.getServerName() + ":" + schema.getPort() + "/" +
            schema.getService() + "/"  + schema.getSchemaName();
        logger.info("Init prescrub user create: " + desc);        
        ls.add( new TaskTypeNFile(TaskType.CREATE_PRESCRUB_USER, scriptFile) );
    }
    
    public List  getTaskTypeNFileList(){
        return ls;
    }

    String sqlPlusUrl;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }

    public SQLPlusRunnable setTaskType( TaskType tskType) {
        return this;
    }

}
