package dashboard.engine.oracle;


import java.io.File;
import java.net.URLDecoder;
import java.util.List;

import dashboard.data.RunningStatus;
import dashboard.data.TaskTypeNFile;
import dashboard.db.EngineMonitorDB;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.EDBUtil;
import dashboard.util.FileUtil;

public class ImportDataTransferModifier extends BaseSQLPlusRunnable {
    public ImportDataTransferModifier() {
        super();
    }
    
    private List generateScript() throws Exception {    	
        File importDataScriptFile = (new NamingUtil()).getImportDataScriptFile(getSchema());
       
        StringBuffer sb = new StringBuffer(5000);
        
        String srcFile="";
        String desFile="";    
        
        sb.append("echo \"\" > "+importDataScriptFile+"._out");
        sb.append("\n");
        sb.append("echo \"<SyncResource>\" >> "+importDataScriptFile+"._out");
        sb.append("\n");
        
        sb.append(
        "# ---------------------------------------------------------------------- \n"+
        "# Make destination directory if it does not exist. \n"+
        "# Copy/overwrite file/directory. \n"+
        "# ---------------------------------------------------------------------- \n"
        );
        
        for(int i=0 ; i<this.copyfiles.length; i++){   
        	srcFile = srcMachine+EDBUtil.fileseperator+ URLDecoder.decode(this.srcLocation+this.copyfiles[i]);
        	desFile = destMachine+EDBUtil.fileseperator+ URLDecoder.decode(this.destLocation+this.copyfiles[i]);
	    	
        	sb.append("### Properties:"+i+" ### \n");	        	
        	if (srcFile.endsWith(EDBUtil.fileseperator)){            		
	        	sb.append("SRC_DIR"+i+"=\""+mountDir+srcFile+"\"");
	        	sb.append("\n"); 
		    	sb.append("DES_DIR"+i+"=\""+mountDir+desFile+"\"");
		    	sb.append("\n"); 		    	
	        	sb.append("### Script Action ###");
	        	sb.append("\n"); 
	        	sb.append("if [ ! -d \"$DES_DIR"+i+"\" ] ; then mkdir -p \"$DES_DIR"+i+"\"; fi");
	        	sb.append("\n"); 
	        	
	        	sb.append("echo \"<Loop>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"<source>\"$SRC_DIR"+i+"\"</source>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"<destination>\"$DES_DIR"+i+"\"</destination>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"<copiedfile>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");		    	
		    	
	        	sb.append("rsync -r -v --stats  \"$SRC_DIR"+i+"\" \"$DES_DIR"+i+"\""+" >> "+importDataScriptFile+"._out");
	        	
	        	sb.append("\n");	        	
	        	sb.append("echo \"</copiedfile>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"</Loop>\" >> "+importDataScriptFile+"._out");
		    	
	        	sb.append("\n\n"); 	            
	    	}else{    
	        	sb.append("SRC_DIR"+i+"=\""+mountDir+srcFile+"\"");
	        	sb.append("\n"); 
		    	sb.append("DES_DIR"+i+"=\""+mountDir+desFile.substring(0, desFile.lastIndexOf(EDBUtil.fileseperator))+"\"");
		    	sb.append("\n"); 		    	
	        	sb.append("### Script Action ###");
	        	sb.append("\n"); 
	        	sb.append("if [ ! -d \"$DES_DIR"+i+"\" ] ; then mkdir -p \"$DES_DIR"+i+"\"; fi");
	        	sb.append("\n"); 
	        	
	        	sb.append("echo \"<Loop>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"<source>\"$SRC_DIR"+i+"\"</source>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"<destination>\"$DES_DIR"+i+"\"</destination>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"<copiedfile>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	
	        	sb.append("rsync -v --stats \"$SRC_DIR"+i+"\" \"$DES_DIR"+i+"\""+" >> "+importDataScriptFile+"._out");
	        	
	        	sb.append("\n");
	        	sb.append("echo \"</copiedfile>\" >> "+importDataScriptFile+"._out");
	        	sb.append("\n");
	        	sb.append("echo \"</Loop>\" >> "+importDataScriptFile+"._out");
	        	
	        	sb.append("\n\n");
	    	}
        	
         	
        	/*if (srcFile.endsWith(EDBUtil.fileseperator)){            		
            	StringBuffer desDirectory = new StringBuffer(desFile);
            	desDirectory = desDirectory.deleteCharAt(desDirectory.length()-1);
            	desDirectory = desDirectory.delete(desDirectory.lastIndexOf(EDBUtil.fileseperator), desDirectory.length()); 
            	sb.append("SRC_DIR"+i+"=\""+mountDir+srcFile+"\"");
	        	sb.append("\n"); 
		    	sb.append("DES_DIR"+i+"=\""+mountDir+desDirectory+"\"");
		    	sb.append("\n"); 		    	
	        	sb.append("### Script Action ###");
	        	sb.append("\n"); 
	        	sb.append("if [ ! -d \"$DES_DIR"+i+"\" ] ; then mkdir -p \"$DES_DIR"+i+"\"; fi");
	        	sb.append("\n"); 
	        	sb.append("cp -r \"$SRC_DIR"+i+"\" \"$DES_DIR"+i+"\"");
	        	sb.append("\n\n"); 	        	
        	}else{          		            	
            	sb.append("SRC_DIR"+i+"=\""+mountDir+srcFile+"\"");
	        	sb.append("\n"); 
		    	sb.append("DES_DIR"+i+"=\""+mountDir+desFile.substring(0, desFile.lastIndexOf(EDBUtil.fileseperator))+"\"");
		    	sb.append("\n"); 		    	
	        	sb.append("### Script Action ###");
	        	sb.append("\n"); 
	        	sb.append("if [ ! -d \"$DES_DIR"+i+"\" ] ; then mkdir -p \"$DES_DIR"+i+"\"; fi");
	        	sb.append("\n"); 
	        	sb.append("cp -r \"$SRC_DIR"+i+"\" \"$DES_DIR"+i+"\"");
	        	sb.append("\n\n");             	
        	} */      	
        	        	
        }      
        
        sb.append("echo \"</SyncResource>\" >> "+importDataScriptFile+"._out");
        sb.append("\n");
                
        FileUtil.writeToTextFile(sb.toString(), importDataScriptFile);
        TaskTypeNFile scpScript = new TaskTypeNFile(TaskType.IMPORT_DATA_TRANSFER,importDataScriptFile).setShellScript(true);
        ls.add(scpScript);
        
        return ls;
    }


    
    public void init() throws Exception {    	
        ls = generateScript( );
        desc = this.destMachine+":"+getSchema().getSchemaName()+"-"+getSchema().getClientName();
    }

    private String desc = "Import Data Transfer";
    public String getDescription() {
        return desc;
    }

 
    private String sqlPlusUrl = null;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }

    public TaskType getTaskType() {
        return TaskType.IMPORT_DATA_TRANSFER;

    }

    public SQLPlusRunnable setTaskType( TaskType tskType) {
        return this;
    }

    public List getTaskTypeNFileList() {
        return ls;
    }

 
    public RunningStatus getRunningStatus() throws Exception {
    	return objectStatus;
    }

    public List getAfterInvalidProcList(){
    	List ls=lsEmpty;
    	return ls;
    } 
    
    
    String destLocation;
    String srcLocation;
    String srcMachine;
    String destMachine;
    String[] copyfiles;
    String mountDir;
    
    public String getMountDir() {
		return mountDir;
	}


	public ImportDataTransferModifier setMountDir(String mountDir) {
		this.mountDir = mountDir;
		return this;
	}

	public String getSrcMachine() {
		return srcMachine;
	}


	public ImportDataTransferModifier setSrcMachine(String srcMachine) {
		this.srcMachine = srcMachine;
		return this;
	}


	public String getDestMachine() {
		return destMachine;
	}


	public ImportDataTransferModifier setDestMachine(String destMachine) {
		this.destMachine = destMachine;
		return this;
	}


	public String[] getCopyfiles() {
		return copyfiles;
	}


	public ImportDataTransferModifier setCopyfiles(String[] copyfiles) {
		this.copyfiles = copyfiles;
		return this;
	}


	public String getDestLocation() {
		return destLocation;
	}


	public ImportDataTransferModifier setDestLocation(String destLocation) {
		this.destLocation = destLocation;
		return this;
	}
	

	public String getSrcLocation() {
		return srcLocation;
	}

	public ImportDataTransferModifier setSrcLocation(String srcLocation) {
		this.srcLocation = srcLocation;
		return this;
	}
	
	protected EngineMonitorDB engineMonitorDB = null;
    public ImportDataTransferModifier setEngineMonitorDB( EngineMonitorDB engMDB) {
        engineMonitorDB = engMDB;
        return this;
    }
    protected EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }

    public boolean isAllowKill() {
        return true;
    }

    public void kill() throws Exception {
        //engineMonitorDB.kill(getSchema());
    }
    
    public boolean isWriteOutputFile(){
    	return false;
    }
    
}
