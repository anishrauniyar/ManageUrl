package dashboard.engine.oracle;


import java.io.File;
import java.util.List;
import java.util.LinkedList;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.RunningStatus;
import dashboard.data.EngineReplacementData;
import dashboard.data.TaskTypeNFile;
import dashboard.engine.TaskType;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;

import dashboard.engine.SQLPlusRunnable;
import dashboard.db.OracleDBConnector;
import dashboard.db.EngineMonitorDB;

public class IndexModifier extends BaseSQLPlusRunnable {
    
    public IndexModifier() {
        super();
    }


    private List generateScript()
        throws Exception {

        File scriptFile = (new NamingUtil()).getIndexScriptFile(getSchema());
        String script = engineConverter.getRunIndexScript( getThreadCount() );
            
        FileUtil.writeToTextFile(script, scriptFile);

        ls.add(new TaskTypeNFile( TaskType.INDEXING, scriptFile));
        return ls;
    }

    public void init() throws Exception {
        ls = generateScript( );
        Schema frontSchema = getSchema();
        sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(frontSchema);
        desc = "Index on: " + frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
            frontSchema.getService() + ":" + frontSchema.getSchemaName();
    }

    private String desc = "Run Indexing: ";
    public String getDescription() {
        return desc;
    }


    private String sqlPlusUrl = null;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }

    public TaskType getTaskType() {
        return TaskType.INDEXING;
    }

    public List getTaskTypeNFileList() {
        return ls;
    }
    public List getStatusList() throws Exception {
        return getStatusListCache();
    }
    public SQLPlusRunnable setTaskType( TaskType tskType) {
        return this;
    }

    private volatile long lastIndexUpdate = -1;
    
    public RunningStatus getRunningStatus() throws Exception {
        long currentTime = System.currentTimeMillis();
        if ( currentTime - lastIndexUpdate < CACHE_TIME && lastIndexUpdate > - 1) {
            return objectStatus;
        } else {
            lastIndexUpdate = currentTime;
            int indexCount = ComponentFactory.getInstance().getEngineMonitorForSystem()
                .getIndexCount( getRunnerSchema());
            objectStatus.setCompletedModules(indexCount);
        }
        return objectStatus;
    }

    protected EngineMonitorDB engineMonitorDB = null;
    public IndexModifier setEngineMonitorDB( EngineMonitorDB engMDB) {
        engineMonitorDB = engMDB;
        return this;
    }
    protected EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }

    public boolean isAllowKill() {
        return true;
    }

    public void kill() throws Exception {
        engineMonitorDB.kill(getSchema());
    }

}
