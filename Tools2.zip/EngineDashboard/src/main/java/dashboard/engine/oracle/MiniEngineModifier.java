package dashboard.engine.oracle;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.EngineReplacementData;
import dashboard.data.EngineTask;
import dashboard.data.ReplaceSchema;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.TaskTypeNFile;
import dashboard.db.EngineMonitorDB;
import dashboard.db.OracleDBConnector;
import dashboard.engine.EngineConverter;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.FileUtil;

public class MiniEngineModifier extends BaseSQLPlusRunnable {

	private String diffServer;
	protected Log logger = LogFactory.getLog(getClass());

	public MiniEngineModifier() {
		super();
	}

	private EngineTask engineTask = null;

	public MiniEngineModifier setEngineTask(EngineTask t) {
		engineTask = t;
		if (engineTask != null) {
			// 1st task type by default
			if (engineTask.isRunPreCheck())
				taskType = TaskType.MINI_ENGINE_PRE_CHECK;
			if (engineTask.isCompileEngine())
				taskType = TaskType.COMPILE_MINI_ENGINE;
			if (engineTask.isExecuteEngine())
				taskType = TaskType.EXECUTE_MINI_ENGINE;
			if (engineTask.isRunDXCGRecordCount())
				taskType = TaskType.DXCG_RECORD_COUNT;

		}

		return this;
	}
	
	public List getBeforeInvalidProcList() throws Exception {
		if(engineTask.isRunPreCheck()){
			if(!TaskType.MINI_ENGINE_PRE_CHECK.equals(taskType)){
				logger.info("Checking MRE Pre Check Before "+taskType+" for schema "+getSchema());
				return ComponentFactory.getInstance().getEngineMonitorForSystem().getInvalidMREPreChecks(getSchema());
			}
		}
		return lsEmpty;
	}

	protected TaskType taskType = null;

	public SQLPlusRunnable setTaskType(TaskType tskType) {
		if (null != tskType) {
			taskType = tskType;
		}
		return this;
	}

	public TaskType getTaskType() {
		return taskType;
	}

	private List generateScript() throws Exception {
		ls.clear();
		Schema runnerSchema = getSchema();
		EngineReplacementData replData = NamingUtil
				.replacementDataByFrontSchema(runnerSchema);

		replData.setSchema(this.getHistSchema());
		replData.setDiffServer(this.getDiffServer());
		// replData.setDxcgParam(this.getDxcgParam());

		if (getReplaceSchema().isReplaceHawkeyeMaster()) {
			replData.setHawkeyeMaster(getReplaceSchema().getHawkeyeMaster());
		}
		if (getReplaceSchema().isReplaceHawkeyeQRM()) {
			replData.setHawkeyeQRM(getReplaceSchema().getHawkeyeQRM());
		}

		NamingUtil namingUtil = new NamingUtil();

		if (engineTask.isRunPreCheck()) {
			addMiniEnginePreCheckScript();
		}
		if (engineTask.isCompileEngine()) {
			String script = engineConverter.getModifiedMiniEngineScript(
					replData, getSchema());
			File scriptFile = (new NamingUtil())
					.getMiniEngineScriptFile(runnerSchema);
			FileUtil.writeToTextFile(script, scriptFile);
			ls.add(new TaskTypeNFile(TaskType.COMPILE_MINI_ENGINE, scriptFile));

		}
		if (engineTask.isExecuteEngine()) {
			String script = engineConverter.getRunMiniEngineScript(replData,
					threadCount, parallel, getSchema(), getHistSchema());
			File scriptFile = (new NamingUtil())
					.getRunMiniEngineScriptFile(runnerSchema);
			FileUtil.writeToTextFile(script, scriptFile);
			ls.add(new TaskTypeNFile(TaskType.EXECUTE_MINI_ENGINE, scriptFile));
		}
		if(engineTask.isRunDXCGRecordCount()){
        	SQLPlusRunnable dxcgReportCountModifier = (new DXCGRecordCountModifier()).setSchema(this.getSchema());
        	dxcgReportCountModifier.init();
        	setStagingSQLPlusUrl(dxcgReportCountModifier.getStagingSQLPlusUrl());
        	ls.addAll(dxcgReportCountModifier.getTaskTypeNFileList());
        }

		return ls;
	}

	public void init() throws Exception {
		ls = generateScript();
		Schema VCSchema = getSchema();
		sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(VCSchema);
		desc = "[" + VCSchema.getServerGroupName() + "] "
				+ VCSchema.getServerName() + ":" + VCSchema.getPort() + "/"
				+ VCSchema.getService() + ":" + VCSchema.getSchemaName();
	}

	private String desc = "Execute Mini Engine: ";

	public String getDescription() {
		if (null != taskType) {
			Schema vcSchema = getSchema();

			desc = " [" + vcSchema.getServerGroupName() + "] "
					+ vcSchema.getServerName() + ":" + vcSchema.getPort() + "/"
					+ vcSchema.getService() + ":" + vcSchema.getSchemaName();
			/**
             * VITTOOLS-378: Showing parallel for EXECUTE_MINI_ENGINE
             */
            if(taskType.equals(TaskType.EXECUTE_MINI_ENGINE) && parallel!=null){
            	desc +=" [Parallel:"+parallel+"]";
            }
		}
		return desc;
	}

	private String srcSqlPlusUrl=null;
    public String getSrcSQLPlusUrl(){
    	return this.srcSqlPlusUrl;
    }
	private Server vcServer=null;
	
	/**
	 * JIRA: VITTOOLS-537 Adds Mini Engine Pre Checks Script to ls
	 * 
	 * @throws Exception
	 */
	public void addMiniEnginePreCheckScript() throws Exception {
		Schema vcSchema = getSchema();

		this.vcServer = ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(vcSchema);
		Schema vcUtilSchema = new Schema().setServerName(vcSchema.getServerName()).setPort(vcSchema.getPort())
				.setService(vcSchema.getService()).setSidFlag(vcSchema.getSidFlag())
				.setSchemaName(vcServer.getUTILITY_USER()).setSchemaPwd(vcServer.getUTILITY_PASS());

		srcSqlPlusUrl = OracleDBConnector.getTnsStyleUrl(vcUtilSchema);

		StringBuffer sb = EngineConverter.initStringBuffer();
		sb.append("---------Mini Engine Pre Check -----\n").append("BEGIN\n")
				.append(vcUtilSchema.getSchemaName() + ".sp_mre_check_v1.sp_execute(")
				.append("'" + vcSchema.getSchemaName() + "'").append(");").append("\n").append("END;\n/\n");
		sb = EngineConverter.addExit(sb);

		String script = sb.toString();
		File scriptFile = (new NamingUtil()).getMiniEnginePreCheckScriptFile(runnerSchema);
		FileUtil.writeToTextFile(script, scriptFile);
		TaskTypeNFile miniEnginePreCheck = new TaskTypeNFile(TaskType.MINI_ENGINE_PRE_CHECK, scriptFile);
		miniEnginePreCheck.setRunAtSource(Boolean.TRUE);
		miniEnginePreCheck.setAlwaysWriteOutputFile(Boolean.TRUE);
		miniEnginePreCheck.setHaltProcessWhenOraError(Boolean.TRUE);
		ls.add(miniEnginePreCheck);
	}

	public List<String> getDxCGOutput() {
		return engineMonitorDB.callDxCGReportForMiniEngine(getSchema());
	}

	public List getTaskTypeNFileList() {
		return ls;
	}

	private String sqlPlusUrl = null;

	public String getSQLPlusUrl() {
		return sqlPlusUrl;
	}
	
	private String stagingSQLPlusUrl = null;
    public String getStagingSQLPlusUrl() {
		return stagingSQLPlusUrl;
	}
	public void setStagingSQLPlusUrl(String stagingSQLPlusUrl) {
		this.stagingSQLPlusUrl = stagingSQLPlusUrl;
	}

	public List getStatusList() throws Exception {
		if (TaskType.EXECUTE_MINI_ENGINE.equals(taskType)) {
			return getStatusListCache();
		}
		return getEmptyList();
	}

	private volatile long lastIndexUpdate = -1;

	public RunningStatus getRunningStatus() throws Exception {
		if (TaskType.EXECUTE_MINI_ENGINE.equals(taskType)) {
			return getRunningStatusCacheForMiniEngine();
		}

		return super.getRunningStatus();
	}

	public boolean isAllowKill() {
		return true;
	}

	public void kill() throws Exception {
		if (TaskType.EXECUTE_MINI_ENGINE.equals(taskType)) {
			engineMonitorDB.kill(getSchema());
		}
	}

	protected EngineMonitorDB engineMonitorDB = null;

	public MiniEngineModifier setEngineMonitorDB(EngineMonitorDB engMDB) {
		engineMonitorDB = engMDB;
		return this;
	}

	protected EngineMonitorDB getEngineMonitorDB() {
		return engineMonitorDB;
	}

	protected ReplaceSchema replSchema;

	public MiniEngineModifier setReplaceSchema(ReplaceSchema replSchema) {
		this.replSchema = replSchema;
		return this;
	}

	public ReplaceSchema getReplaceSchema() {
		return replSchema;
	}

	protected Schema schema;

	public MiniEngineModifier setHistSchema(Schema Schema) {
		this.schema = Schema;
		return this;
	}

	public Schema getHistSchema() {
		return schema;
	}

	public String getDiffServer() {
		return diffServer;
	}

	public MiniEngineModifier setDiffServer(String p) {
		diffServer = (p != null) ? p.trim().toUpperCase() : "";
		return this;
	}
}
