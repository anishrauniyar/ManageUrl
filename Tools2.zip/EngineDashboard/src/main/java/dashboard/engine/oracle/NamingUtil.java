package dashboard.engine.oracle;

import java.io.File;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.EngineReplacementData;
import dashboard.db.FixedParameter;

import dashboard.util.Constants;
import dashboard.util.EnvInfo;

public class NamingUtil {
	EnvInfo env;
	FixedParameter fixedParam;
	ComponentFactory compFactory;

	public NamingUtil() {
		compFactory = ComponentFactory.getInstance();
		env = compFactory.getEnvInfo();
		fixedParam = compFactory.getFixedParameters();
	}

	/*private static final Pattern hpNamePattern = Pattern.compile(
			"\\s*HP[0-9]{13}\\s*", Pattern.CASE_INSENSITIVE);*/
	private static final Pattern hpNamePattern = Pattern.compile(
			"^HP[a-zA-Z0-9]{13}$", Pattern.CASE_INSENSITIVE);

	public static boolean isValidPreScrubName(String param) throws Exception {
		return hpNamePattern.matcher(param).find();
	}

	private static final Pattern hfNamePattern = Pattern.compile(
			"\\s*HF[0-9]{13}\\s*", Pattern.CASE_INSENSITIVE);

	public static boolean isHF13(String param) {
		return hfNamePattern.matcher(param).find();
	}

	private static final Pattern histPattern = Pattern.compile(
			"\\s*HH[0-9]{7}\\s*", Pattern.CASE_INSENSITIVE);

	private static boolean isValidHistorySchema(String param) throws Exception {
		return histPattern.matcher(param).find();
	}

	private static final Pattern wareHousePattern = Pattern.compile(
			"\\s*WH[0-9]{13}\\s*", Pattern.CASE_INSENSITIVE);

	public static boolean isValidWareHouseSchema(String param) throws Exception {
		return wareHousePattern.matcher(param).find();
	}

	/*private static final Pattern VCPattern = Pattern.compile(
			"\\s*VC[0-9]{13}\\s*", Pattern.CASE_INSENSITIVE);*/
	private static final Pattern VCPattern = Pattern.compile(
			"^VC[a-zA-Z0-9]{13}$", Pattern.CASE_INSENSITIVE);
	
	/*private static final Pattern TestPattern = Pattern.compile(
			"^VC[a-zA-Z0-9]{13}$", Pattern.CASE_INSENSITIVE);
	
	public static void testTestPattern(String param){
		System.out.println(param+" "+TestPattern.matcher(param).find());
	}
	
	public static void main(String[] args) {
		testTestPattern("VC");
		testTestPattern("VCVC");
		testTestPattern("VCVCVC");
		testTestPattern("VC1234567891234");
		testTestPattern("VC12345678912345");
		testTestPattern("VC1234567891234A");
		testTestPattern("VC1234567891234a");
		testTestPattern("VC123456789456111111");
		testTestPattern("VC1234567a91234");
		testTestPattern("VC1234567894ASD");
		testTestPattern("VC12345XXX91234");
		
	}*/

	public static boolean isValidVCSchema(String param) throws Exception {
		return VCPattern.matcher(param).find();
	}

	private static final Pattern schemaNamePattern = Pattern.compile(
			"\\s*H[CFPS][0-9]{13}\\s*", Pattern.CASE_INSENSITIVE);

	private static boolean isValidSchemaName(String param) throws Exception {
		return schemaNamePattern.matcher(param).find();
	}

	private static final Pattern clientAppPattern = Pattern.compile(
			"\\s*H[CFPS]([0-9]{7})[0-9]*\\s*", Pattern.CASE_INSENSITIVE);

	public static String getClientNAppId(String param) throws Exception {
		Matcher m = clientAppPattern.matcher(param);
		String clientNAppId = null;
		if (m.find()) {
			clientNAppId = m.group(1);
		} else {
			throw new IllegalArgumentException(
					"Not a valid front|code|scrub|prescurb name: " + param);
		}
		return clientNAppId;
	}

	private static final Pattern clientIdPattern = Pattern.compile(
			"\\s*H[CFPSH]([0-9]{4})[0-9]*\\s*", Pattern.CASE_INSENSITIVE);

	private static String getClientId(String param) throws Exception {
		Matcher m = clientIdPattern.matcher(param); // .group();
		m.find();
		return m.group(1);
	}

	private static EngineReplacementData replacementDataByPreScrub(
			EngineReplacementData replData) throws Exception {
		String hp = replData.getHawkeyePreScrub();
		EngineReplacementData engReplData = null;
		if (isValidPreScrubName(hp)) {
			engReplData = createEngineReplacementData(hp.trim().substring(2));
		} else {
			throw new IllegalArgumentException(" illegal PreScrubName: " + hp);
		}
		return engReplData;
	}

	public static EngineReplacementData getReplacementDataBySchemaName(
			String schemaName) throws Exception {
		if (isValidSchemaName(schemaName)) {
			return createEngineReplacementData(schemaName.trim().substring(2));
		} else {
			throw new IllegalArgumentException("Not a valid schema name: "
					+ schemaName);
		}
	}

	private static EngineReplacementData createEngineReplacementData(
			String clAppNProcId) {
		String clAppIdNProcessId = clAppNProcId.trim();
		return (new EngineReplacementData())
				.setHawkeyeCode("HC" + clAppIdNProcessId)
				.setHawkeyeFront("HF" + clAppIdNProcessId)
				.setHawkeyeScrub("HS" + clAppIdNProcessId)
				.setHawkeyePreScrub("HP" + clAppIdNProcessId)
				.setHawkeyeHist(
						"HH" + clAppIdNProcessId.substring(0, 4) + "001");
	}

	private static EngineReplacementData createHistoryReplacementData(
			String histSchema) {
		String hist = histSchema.trim();
		return (new EngineReplacementData()).setHawkeyeCode(hist)
				.setHawkeyeFront(hist).setHawkeyeScrub(hist)
				.setHawkeyePreScrub(hist).setHawkeyeHist(hist);
	}

	public static EngineReplacementData replacementDataByFrontSchema(
			Schema frontSchema) throws Exception {
		String front = frontSchema.getSchemaName();
		EngineReplacementData engReplData = null;
		if (isValidSchemaName(front)) {
			engReplData = createEngineReplacementData(front.trim().substring(2));
		}
		// case for VC schema [i.e MiniEngine Execution]
		else if (isValidVCSchema(front)) {
			engReplData = createEngineReplacementData(front.trim().substring(2));
		} else {
			throw new IllegalArgumentException(
					" Illegal front name for replacing data: " + front);
		}
		return engReplData;
	}

	public static EngineReplacementData getReplacementDataForHistory(
			String schemaName) throws Exception {
		if (isValidHistorySchema(schemaName)) {
			return createHistoryReplacementData(schemaName.trim());
		} else {
			throw new IllegalArgumentException(
					"Not a valid history schema name: " + schemaName);
		}
	}

	public File getCreateUserFile(Schema newSchema) throws Exception {
		String hfUser = newSchema.getSchemaName();
		String fileName = newSchema.getServerGroupId() + '_' + hfUser
				+ ".cr.sql";
		fileName = fileName.replaceAll("\\s", "_s_");
		return new File(env.getTempDir(), fileName);
	}

	public File getCreateSynonymScriptFileForHPNHR(Schema schema)
			throws Exception {
		String hfUser = schema.getSchemaName();
		String fileName = schema.getServerGroupId() + '_' + hfUser
				+ ".HPNHRsyn.sql";
		fileName = fileName.replaceAll("\\s", "_s_");
		return new File(env.getTempDir(), fileName);
	}

	public File getCreateSynonymScriptFileForHF(Schema schema) throws Exception {
		String hfUser = schema.getSchemaName();
		String fileName = schema.getServerGroupId() + '_' + hfUser
				+ ".HFsyn.sql";
		fileName = fileName.replaceAll("\\s", "_s_");
		return new File(env.getTempDir(), fileName);
	}

	public File getIndvDxCGFile(Schema newSchema) throws Exception {
		String fileType = "dxcg";
		String versionstr = "_" + newSchema.getEngineVersion();
		String fileName = getFilePrefix(newSchema) + versionstr + ".rp_"
				+ fileType + ".sql";
		return new File(env.getTempDir(), fileName);
	}

	public static String getFilePrefix(Schema frontSchema) {
		String fileName = frontSchema.getServerGroupId() + "_"
				+ frontSchema.getServerName() + "_"
				+ frontSchema.getSchemaName();
		fileName = fileName.replaceAll("\\s", "_s_");
		return fileName;
	}

	public File getObjectScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".obj.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getClientSpecificScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".css.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getEngineScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".en.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getMiniEnginePreCheckScriptFile(Schema VCSchema) {
		String versionstr = "_" + VCSchema.getEngineVersion();
		String fileName = getFilePrefix(VCSchema) + versionstr + ".MiniEnPreChk.sql";
		return new File(env.getTempDir(), fileName);
	}
	
	public File getMiniEngineScriptFile(Schema VCSchema) {
		String versionstr = "_" + VCSchema.getEngineVersion();
		String fileName = getFilePrefix(VCSchema) + versionstr + ".Minien.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getWHEngineScriptFile(Schema whSchema) {
		String versionstr = "_" + whSchema.getEngineVersion();
		String fileName = getFilePrefix(whSchema) + versionstr + ".WHen.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getRunEngineScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".rnen.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getRunMiniEngineScriptFile(Schema VCSchema) {
		String versionstr = "_" + VCSchema.getEngineVersion();
		String fileName = getFilePrefix(VCSchema) + versionstr
				+ ".rnMinien.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getWHRunEngineScriptFile(Schema whSchema) {
		String versionstr = "_" + whSchema.getEngineVersion();
		String fileName = getFilePrefix(whSchema) + versionstr + ".WHrnen.sql";
		return new File(env.getTempDir(), fileName);
	}

	private static File outputFile(File f) {
		return new File(f.getAbsolutePath() + "._out");
	}

	public File[] getOutputFiles(Schema frontSchema) throws Exception {
		File[] files = new File[26];
		files[0] = outputFile(getCreateUserFile(frontSchema));
		files[1] = outputFile(getObjectScriptFile(frontSchema));
		files[2] = outputFile(getEngineScriptFile(frontSchema));
		files[3] = outputFile(getRunEngineScriptFile(frontSchema));
		files[4] = outputFile(getDataTransferScriptFile(frontSchema));
		files[5] = outputFile(getReportScriptFile(frontSchema));
		files[6] = outputFile(getIndexScriptFile(frontSchema));
		files[7] = outputFile(getCreatePreScrubUserFile(frontSchema));

		files[8] = outputFile(getTTSImportScriptFile(frontSchema));
		files[9] = outputFile(getTTSTransferScriptFile(frontSchema));
		files[10] = outputFile(getTTSExportScriptFile(frontSchema));
		files[11] = outputFile(getImportDataScriptFile(frontSchema));
		files[12] = outputFile(getImportScriptFile(frontSchema));
		files[13] = outputFile(getScrubScriptFile(frontSchema));
		files[14] = outputFile(getIndvDxCGFile(frontSchema));
		// for warehouse
		files[15] = outputFile(getCreateSynonymScriptFileForHPNHR(frontSchema));
		files[16] = outputFile(getCreateSynonymScriptFileForHF(frontSchema));
		files[17] = outputFile(getWHEngineScriptFile(frontSchema));
		files[18] = outputFile(getWHRunEngineScriptFile(frontSchema));
		files[19] = outputFile(getFQCReportScriptFile(frontSchema));
		files[20] = outputFile(getMiniEngineScriptFile(frontSchema));
		files[21] = outputFile(getRunMiniEngineScriptFile(frontSchema));
		files[22] = outputFile(getClientSpecificScriptFile(frontSchema));
		files[23] = outputFile(getDXCGReportCountScriptFile(frontSchema));
		files[24] = outputFile(getMiniEnginePreCheckScriptFile(frontSchema));
		
		files[25] = outputFile(getReportCheckFile(frontSchema));

		return files;
	}

	// ** Output Files for all reports will be the same
	public File getReportScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".rp.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getReportScriptFile(Schema frontSchema, int reportId) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".rp_"
				+ reportId + ".sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getFQCReportScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr
				+ ".rp_FQC.sql";
		return new File(env.getTempDir(), fileName);
	}
	
	public File getReportCheckFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr
				+ ".rp_reportCheck.sql";
		return new File(env.getTempDir(), fileName);
	}
	
	public File getDXCGReportCountScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr
				+ ".dxcgRpCnt.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getIndexScriptFile(Schema frontSchema) {
		String versionstr = "_" + frontSchema.getEngineVersion();
		String fileName = getFilePrefix(frontSchema) + versionstr + ".ndx.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getTTSTransferScriptFile(Schema frontSchema) {
		String fileName = getFilePrefix(frontSchema) + ".ttstx.sh";
		return new File(env.getTempDir(), fileName);
	}

	public File getTTSExportScriptFile(Schema frontSchema) {
		String fileName = getFilePrefix(frontSchema) + ".ttsex.sql";
		return new File(env.getTempDir(), fileName);
	}

	/**
	 * @author Ram Gautam added to create the export file for ASM
	 * @param frontSchema
	 * @return
	 */
	public File getASMExportScriptFile(Schema frontSchema) {
		String fileName = getFilePrefix(frontSchema) + ".asmex.sql";
		return new File(env.getTempDir(), fileName);
	}

	/**
	 * @author Ram Gautam added to create the import file for ASM
	 * @param frontSchema
	 * @return
	 */
	public File getASMImportScriptFile(Schema frontSchema) {
		String fileName = getFilePrefix(frontSchema) + ".asmim.sql";
		return new File(env.getTempDir(), fileName);
	}

	public static String getCurrentTimeStamp() {
		java.util.Date currentDate = new java.util.Date();
		String formattedDate = new java.text.SimpleDateFormat("yyyyMMdHHmmS")
				.format(currentDate);// 201306241743360
		return formattedDate;
	}

	public File getTTSImportScriptFile(Schema frontSchema) {
		String fileName = getFilePrefix(frontSchema) + ".ttsim.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getDataTransferScriptFile(Schema frontSchema) {
		return new File(env.getTempDir(), getFilePrefix(frontSchema)
				+ ".tx.sql");
	}

	/**
	 * @param execNo
	 * @return a new vertica data transfer output file
	 */
	public File getVerticaDataTransferScriptFile(Long execNo,
			String hostingServer) {
		/**
		 ** If hostingServer is VERTICA then processing@fixedparameters table is
		 * used If hostingServer is VERTICA_CMA then
		 * processing@fixedparameters_cma table is used Default is VERTICA_CMA
		 * if hostingServer is null or blank
		 **/
		hostingServer = ((hostingServer == null) || (hostingServer == "")) ? Constants.VERTICA_CMA
				: hostingServer;
		return new File(env.getTempDir(), fixedParam.getValue(
				Constants.SHELLSCRIPT_FILEPREFIX, hostingServer)
				+ "_"
				+ execNo
				+ ".log");
	}

	public File getCreatePreScrubUserFile(Schema schema) {
		String fileName = getFilePrefix(schema) + ".psusr.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getPreScrubOamSourceFile(String schemaName) {
		String fileName = schemaName.replaceAll("\\s", "_s_") + ".ps.oam";
		return new File(env.getTempDir(), fileName);
	}

	public static String getHistSchemaFromClientId(String clientId) {
		if (null == clientId || "".equals(clientId.trim())) {
			throw new IllegalArgumentException("Blank or Null clientID");
		}
		return "HH" + clientId.trim() + "001";
	}

	public File getImportDataScriptFile(Schema frontSchema) {
		String fileName = getFilePrefix(frontSchema) + ".imptx.sh";
		return new File(env.getTempDir(), fileName);
	}

	public File getImportScriptFile(Schema schema, String rFileName) {
		String _filename = (Pattern.compile(".sql", Pattern.CASE_INSENSITIVE)
				.matcher(rFileName).replaceAll(""));
		String fileName = getFilePrefix(schema) + ".imprt_" + _filename
				+ ".sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getImportScriptFile(Schema schema) {
		String fileName = getFilePrefix(schema) + ".imprt.sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getScrubScriptFile(Schema schema, String rFileName) {
		String fileName = getFilePrefix(schema) + ".scrb_" + rFileName + ".sql";
		return new File(env.getTempDir(), fileName);
	}

	public File getScrubScriptFile(Schema schema) {
		String fileName = getFilePrefix(schema) + ".scrb.sql";
		return new File(env.getTempDir(), fileName);
	}

}
