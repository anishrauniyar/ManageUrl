package dashboard.engine.oracle;


import java.io.File;
import java.util.List;

import dashboard.ComponentFactory;
import dashboard.data.ReplaceSchema;
import dashboard.data.Schema;
import dashboard.data.RunningStatus;
import dashboard.data.EngineReplacementData;
import dashboard.data.TaskTypeNFile;
import dashboard.data.Report;

import dashboard.util.FileUtil;

import dashboard.engine.EngineConverter;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;

import dashboard.db.OracleDBConnector;
import dashboard.db.EngineMonitorDB;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


public class ReportModifier extends BaseSQLPlusRunnable {
    
    private String dxcgParam="";
    private int partIDxCG = 1041;
    private int partIIDxCG = 1039;
    private int partIIIDxCG = 1040;
    private Log logger = LogFactory.getLog(getClass());
    
    public ReportModifier() {
        super();
    }
        
    private String dxcgHostUrl = "";
    public ReportModifier setDxcgHostUrl(String p){
    	dxcgHostUrl = p;
    	return this;
    }
    
    private Report[] report = null;
    public ReportModifier setReportInfo(Report[] rp) {
        report = rp;
        return this;
    }
    
    private String [] reportModules;
    public ReportModifier setReportModules(String [] r) {
        reportModules = r;
        return this;
    }

    private List generateScript()
        throws Exception {
    	boolean isDxcGProcessed = false;
    	int count = 0;
    	for(int i= 0; i<report.length ;i++){
    		if(report[i].getReportId() == partIDxCG || report[i].getReportId() == partIIDxCG || report[i].getReportId() == partIIIDxCG){
    			isDxcGProcessed = true;
    		}
    		}
    		
    		String script = "";
	        EngineReplacementData replData = null;
                /**
                 * VITTOOLS-564: Add DxCG Resume compatibility in Engine Dashboard for MRE Processing 
                 */
	        if ( NamingUtil.isHF13(getSchema().getSchemaName()) || NamingUtil.isValidVCSchema(getSchema().getSchemaName())) {
	            logger.info("Valid HF/VC:"+getSchema().getSchemaName());
                    replData = NamingUtil.replacementDataByFrontSchema( getSchema());
	        }
	        else {
	            replData = (new EngineReplacementData()).setHawkeyeFront( getSchema().getSchemaName());
	            replData.setHawkeyeHist( NamingUtil.
	                                     getHistSchemaFromClientId(
	                                                               compFactory.getEngineMonitorForSystem().
	                                                               getClientID( getSchema()) ));
	        }
	        
	        if(getReplaceSchema().isReplaceHawkeyeMaster()){
	        	replData.setHawkeyeMaster(getReplaceSchema().getHawkeyeMaster());
	        }
	        if(getReplaceSchema().isReplaceHawkeyeQRM()){
	        	replData.setHawkeyeQRM(getReplaceSchema().getHawkeyeQRM());
	        }
	        
	        String repmsg="";
	        if(isDxcGProcessed){
	        	Report [] placeHolder = new Report[report.length] ;
	        	for(int i=0; i< report.length; i++){
	        		if(report[i].getReportId() == partIDxCG || report[i].getReportId() == partIIDxCG 
	        					|| report[i].getReportId() == partIIIDxCG){
	        			placeHolder[0] = report[i];
	        		}else{
	        			placeHolder[i+1] = report[i];
	        		}
	        	}
	        	for(int i=0; i < placeHolder.length; i++){
	        		report[i] = placeHolder[i];
	        	}
	        }
	        for(int i=0 ; i<report.length; i++){
	        	if(isDxcGProcessed && count == 0){
	        		StringBuffer sb = EngineConverter.initStringBuffer();
	        		sb = sb.append("\n-- executing indv DxCG Report ")
	        		 		.append("\nBEGIN")
	                        .append("\n  sp_processreport (1,'DXCG',")
	                        .append(getDxcgParam()+");");
	        		 	  sb.append("\nEND;")
	        		 	  	.append("\n/");
	        		 	  sb = EngineConverter.addExit(sb);
	        		 
	        		 File scriptFile = (new NamingUtil()).getIndvDxCGFile(getSchema());
	        	     FileUtil.writeToTextFile( sb.toString(), scriptFile);
	        	     
	        	     ls.add(new TaskTypeNFile(new TaskType("PROCESS_SCRIPT_OR_REPORT_", 
	    	    			    "Process Report ",new Integer(4)), scriptFile));
	        	     count ++;
	        	     
	        	} else{
	        	String rptSourceDir =report[i].getSourceDir()+ "/"+ getSchema().getEngineVersion();
	        	
		// if(report.length >1 ) {
			    	List lsReports = ComponentFactory.getInstance().getEngineConverter().getReportFileNameList(rptSourceDir);
					String[] reportModules = (String[]) lsReports.toArray(new String[lsReports.size()]);
					this.setReportModules(reportModules);
					
						repmsg += (i+1)+". "+report[i].getReportName()+"("+lsReports.size()+" modules)"+
								   " location: "+report[i].getSourceDir() + ",\n";
		// }
			        
			        if ("".equals(repmsg)){
			        	System.out.println("Report :"+report[i]+ " Report Modules:"+ reportModules.length);
			        }
			        
			        /*
					 * Start DxCG RiskSmart Processing Execution Type: Shell
					 * Script
					 */
			        if(report[i].getReportId() == 9999){
						ReportModifierDxCG reportModifierDxCG = new ReportModifierDxCG()
						.setReportInfo(report[i])
						.setSchema(this.getSchema())
						.setEngineMonitorDB(this.getEngineMonitorDB())
						.setUser(getUser())
						.setDxcgHostUrl(dxcgHostUrl);
						reportModifierDxCG.init();
						ls.addAll(reportModifierDxCG.getTaskTypeNFileList());
						continue;
					}
			        /*
					 * End DxCG Processing
					 */
			        
			        
			        // script not modified if the schema is not HF\s{13}
			        script = engineConverter.getModifiedReportScript(rptSourceDir, replData, reportModules,getSchema());
			        
			        File scriptFile = (new NamingUtil()).getReportScriptFile(getSchema(), report[i].getReportId());
			        FileUtil.writeToTextFile(script, scriptFile);
			        
			        ls.add(new TaskTypeNFile(new TaskType("PROCESS_SCRIPT_OR_REPORT_"+ report[i].getReportId(), 
		    			    "Process Report ("+report[i].getReportName()+")",new Integer(4)), scriptFile));
					// ls.add( new TaskTypeNFile(
					// TaskType.PROCESS_SCRIPT_OR_REPORT, scriptFile));
			    }
	        if (!"".equals(repmsg)){
	        	System.out.println(repmsg+"reports and modules will run sequentially.\n\n");	        	
	        }
	        }
	        
	        return ls;
    }

    public void init() throws Exception {  		        
	        ls = generateScript( );
	        Schema frontSchema = getSchema();
	        sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(frontSchema);
	        desc = "Run Report for: [" +
	            frontSchema.getServerGroupName() + "] " +
	            frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
	            frontSchema.getService() + ":" + frontSchema.getSchemaName() ;       
    }

    private String desc = "Run Report: ";
    public String getDescription() {
        if ( null != taskType ) {
            Schema frontSchema = getSchema();

            desc = //taskType.toString() +
                " [" + frontSchema.getServerGroupName() + "] " +
                frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
                frontSchema.getService() + ":" + frontSchema.getSchemaName() ;
        }
        return desc;
    }


    public List getTaskTypeNFileList() {
        return ls;
    }

    private String sqlPlusUrl = null;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }
    
    protected TaskType taskType = TaskType.PROCESS_SCRIPT_OR_REPORT;    
    public SQLPlusRunnable setTaskType( TaskType tskType) {
        if (null != tskType) {
            taskType = tskType;
        }
        return this;
    }
    public TaskType getTaskType() {
        return taskType;
    }

    public RunningStatus getRunningStatus() throws Exception {     	
    	//return getRunningStatusCache();
    	return objectStatus;
    }
    
    public List getStatusList() throws Exception {
        return getStatusListCache();
    }

    protected EngineMonitorDB engineMonitorDB = null;
    public ReportModifier setEngineMonitorDB( EngineMonitorDB engMDB) {
        engineMonitorDB = engMDB;
        return this;
    }
    protected EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }

    public boolean isAllowKill() {
        return true;
    }

    public void kill() throws Exception {
        engineMonitorDB.kill(getSchema());
    }
    
    protected ReplaceSchema replSchema;
	public ReportModifier setReplaceSchema(ReplaceSchema replSchema){
		this.replSchema = replSchema;
		return this ;
	}
	public ReplaceSchema getReplaceSchema(){
		return replSchema ;
	}

	public String getDxcgParam() {
		return dxcgParam;
	}

	public ReportModifier setDxcgParam(String p) {
		dxcgParam = (p!=null)? p.trim().toUpperCase(): "";
	    return this;
	}
}