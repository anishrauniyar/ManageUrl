package dashboard.engine.oracle.scrubbing;

import dashboard.security.User;
import dashboard.validator.BaseValidator;

public class CDFObjectScriptForHPValidator extends BaseValidator {

	public CDFObjectScriptForHPValidator(User user) {
		super(user);
	}

	@Override
	public void validate() throws Exception {
		logger.info("Validating CDF Object Scripts for schema "
				+ getOrclSchema());
		validateScriptsExistence(CDF_OBJ_SCRIPTS_FOR_HP);

	}

}
