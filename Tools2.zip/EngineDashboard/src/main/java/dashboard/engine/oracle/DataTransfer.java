package dashboard.engine.oracle;


import java.io.File;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.TaskTypeNFile;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.db.OracleDBConnector;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.Constants;
import dashboard.util.FileUtil;
import dashboard.util.WareHouseParams;

public class DataTransfer extends BaseSQLPlusRunnable {
    
    private TaskType dataTransferTaskType;
    private static final HashSet validTxTypeSet = new HashSet(3);

    static {
        validTxTypeSet.add("F");
        validTxTypeSet.add("H");
        validTxTypeSet.add("S");
        validTxTypeSet.add("TTS");
        validTxTypeSet.add("ASM");
        validTxTypeSet.add("WH");
        validTxTypeSet.add("VC");
        validTxTypeSet.add("ME");
        validTxTypeSet.add(Constants.VERTICA);
        validTxTypeSet.add(Constants.ORACLE_BA);
        validTxTypeSet.add(Constants.VERTICA_CMA);
        validTxTypeSet.add(Constants.VERTICA_DR_CMA);
        validTxTypeSet.add(Constants.ORACLE_BA_CMA);
        validTxTypeSet.add(Constants.ORACLE_DR_BA_CMA);
    }
    private List TTSFilesTxStatusList=new LinkedList();
    private int TTSFilesTxPercentage=0;
    protected Log logger = LogFactory.getLog(getClass());
    private static final int MAX_PARALLEL = 25;
        
    
	public DataTransfer() {
        super();
        dataTransferTaskType = (TaskType) TaskType.DATA_TRANSFER.clone();
    }
	String uniqueJobId;
	
	public String getUniqueJobId() {
		return uniqueJobId;
	}
	public DataTransfer setUniqueJobId(String uniqueJobId) {
		this.uniqueJobId = uniqueJobId;
		return this;
	}

	String sourceHost;
    public DataTransfer setSourceHost(String host) {
        sourceHost = host;
        return this;
    }
    
    public String getSourceHost() {
        return sourceHost;
    }

    String sourcePort;
    public DataTransfer setSourcePort(String port) {
        sourcePort = port;
        return this;
    }
    public String getSourcePort() {
        return sourcePort;
    }

    String sourceService;
    public DataTransfer setSourceService(String service) {
        sourceService = service;
        return this;
    }
    public String getSourceService() {
        return sourceService;
    }
    private String useSidForLink = "Y";
    public DataTransfer setUseSidForLink(String sidFlag) {
        if ( "N".equalsIgnoreCase(sidFlag)) {
            useSidForLink = "N";
        }
        return this;
    }
    public String getUseSidForLink() {
        return useSidForLink;
    }

    String sourceSchema;
    public DataTransfer setSourceSchema(String schema) {
        sourceSchema = schema;
        return this;
    }
    public String getSourceSchema() {
        return sourceSchema;
    }

    String sourcePassword = null;
    public DataTransfer setSourcePassword(String p) {
        if (null != p) {
            sourcePassword = p.trim();
        }
        return this;
    }
    public String getSourcePassword() {
        return sourcePassword;
    }
    
    String sourceDbLink = "";
    public DataTransfer setSourceDbLink(String sourceDbLink) {
		this.sourceDbLink = sourceDbLink;
		return this;
	}
    
	String txType;
    public DataTransfer setTransferType(String txType) {
        if (null != txType && validTxTypeSet.contains(txType.trim().toUpperCase())) {
            this.txType = txType.trim().toUpperCase();

            //setting label
            String label = TaskType.DATA_TRANSFER.getTaskName();
            if( txType.equals("F") ) {
                label += " (Front) ";
            } else if ( txType.equals("H") ) {
                label += " (History) ";
            } else if ( txType.equals("S") ) {
                label += " (Scrub) ";
            } else if ( txType.equals("TTS") ) {
                label += " (TTS) ";
            } else if ( txType.equals("ASM") ) {
                label += " (ASM) ";
            } else if ( txType.equals("WH") ) {
                label += " (WareHouse) ";
            }else if ( txType.equals("VC") ) {
                label += " (VC Scrub) ";
            }else if ( txType.equals("ME") ) {
                label += " (Mini Engine Output) ";
            }else if ( txType.equals(Constants.VERTICA) ) {
                label += " (VERTICA) ";
            }else if ( txType.equals(Constants.ORACLE_BA) ) {
                label += " (ORACLE_BA) ";
            }
            else if ( txType.equals(Constants.VERTICA_CMA) ) {
                label += " (VERTICA_CMA) ";
            }
            else if ( txType.equals(Constants.VERTICA_DR_CMA) ) {
                label += " (VERTICA_DR_CMA) ";
            }
            else if ( txType.equals(Constants.ORACLE_BA_CMA) ) {
                label += " (ORACLE_BA_CMA) ";
            }
            else if ( txType.equals(Constants.ORACLE_DR_BA_CMA) ) {
                label += " (ORACLE_DR_BA_CMA) ";
            }

            dataTransferTaskType.setTaskLabel(label);
        } else {
            throw new IllegalArgumentException("Unknow transfer type flag: " + txType);
        }
        return this;
    }
    public String getTransferType() {
        return txType;
    }


    String appendFlag = "N";
    public DataTransfer setAppendFlag(String appFlag) {
        if (null != appFlag && !"".equals(appFlag.trim())) {
            this.appendFlag = appFlag.trim();
        }
        return this;
    }
    public String getAppendFlag() {
        return appendFlag;
    }
    String DataFileDirName="";

    public String getDataFileDirName() {
		return DataFileDirName;
	}
	public DataTransfer setDataFileDirName(String dataFileDirName) {
		DataFileDirName = dataFileDirName;
		return this;
	}
	
	String DRTransferEnabled = "N";
	String loginName = "";
	

	public String getDRTransferEnabled() {
		return DRTransferEnabled;
	}
	
	public DataTransfer setDRTransferEnabled(String dRTransferEnabled) {
		this.DRTransferEnabled = dRTransferEnabled;
		return this;
	}
	public String getLoginName() {
		return loginName;
	}

	public DataTransfer setLoginName(String loginName) {
		this.loginName = loginName;
		return this;
	}
	
	private List generateScript()
        throws Exception {
    	if(txType.equals("TTS")) return generateTTSTransferScript();
    	else if(txType.equals("ASM"))return generateASMTransferScript();
    	else if(txType.equals("WH"))return genereateWHTransferScript();
    	else if(txType.equals("VC") /*|| txType.equals("ME")*/)return genereateVCTransferScript(txType);
    	// for testing
    	else if(txType.equals("ME") /*|| txType.equals("ME")*/)return genereateMETransferScript();
        Schema runnerSchema = getSchema();
        File scriptFile = (new NamingUtil()).getDataTransferScriptFile(runnerSchema);
        StringBuffer sb = engineConverter.initStringBuffer();
        sb.append("---------DATA TRANSFER-----\n")
            .append("BEGIN\n")
            .append("   UTILITY.SP_ExecD2DataXfr(")
            .append("'").append(sourceSchema).append("',")
            .append("'").append(runnerSchema.getSchemaName()).append("',")
            .append("'").append(sourceHost).append("',")
            .append("'").append(sourcePort).append("',")
            .append("'").append(sourceService).append("',")
            .append("'").append(txType).append("',")
            .append("'").append(appendFlag).append("',")
            .append("'").append(isSameServer()? "Y":"N").append("'")
            .append((null==sourcePassword || "".equals(sourcePassword.trim()))?
                    "": ",'" + sourcePassword + "'" ).append(",")
            .append("'").append(useSidForLink).append("'")
            .append(");\n")
            .append("\nEND;\n/\n");
        sb = engineConverter.addExit(sb);
        String script =  sb.toString();
            
        FileUtil.writeToTextFile(script, scriptFile);

        ls.add(new TaskTypeNFile( dataTransferTaskType, scriptFile));
        return ls;
    }

    public List generateTTSTransferScript()throws Exception{
        Schema destSchema = getSchema();

        //Export Script
        File exportScriptFile=(new NamingUtil()).getTTSExportScriptFile(destSchema);
        /**
         * VITTOOLS-494 : Change server output size to UNLIMITED for ASM Data Transfer Using Engine Dashboard
         */
        StringBuffer sb1 = engineConverter.initStringBufferWithServerOutSizeUnLimited();
        sb1.append("---------TTS EXPORT-----\n")
            .append("BEGIN\n")
        		.append("TTS.EXPORT_IMPORT(")
        				.append("'"+this.sourceSchema+"'")
        				.append(",'E'")
        				.append(",'"+this.sourceSchema+".dmp'")
        				.append(",'"+this.sourceSchema+".log'")
        				.append(",'DIR_TTS_DUMP'")
        				.append(",'"+destSchema.getSchemaName()+"'")
        				.append(");")
        		.append("\n")
        	.append("END;\n/\n");
        sb1=engineConverter.addExit(sb1);
        		
        FileUtil.writeToTextFile(sb1.toString(), exportScriptFile);



        TaskTypeNFile dmpExp = new TaskTypeNFile(dataTransferTaskType,exportScriptFile);
        dmpExp.setSubTaskType(DMP_EXP);
        ls.add(dmpExp.setRunAtSource(true));
        
        //DMP and DBF File Transfer Script
        File fileTransferScriptFile = (new NamingUtil()).getTTSTransferScriptFile(destSchema);
        StringBuffer sb = new StringBuffer(5000);
        	//sb.append("scp "+sourceHost+":"+srcServer.getTTS_DIR_DUMP_PHYS()+"/"+sourceSchema+".dmp "+destSchema.getServerName()+":"+destServer.getTTS_DIR_DUMP_PHYS()+"/"+runnerSchema.getSchemaName()+".dmp");
        	sb.append("scp "+sourceHost+":"+srcServer.getTTS_DIR_DUMP_PHYS()+"/"+sourceSchema+".dmp "+
        			destSchema.getServerName()+":"+destServer.getTTS_DIR_DUMP_PHYS()+"/"+sourceSchema+".dmp");
        	sb.append("\n");
        	sb.append("scp "+sourceHost+":"+this.srcDataFile+" "+
        			destSchema.getServerName()+":"+destDataFile);
        	sb.append("\n");
        	sb.append("ssh "+destSchema.getServerName()+" ");
        	sb.append("\"");
        	sb.append("chmod 760 "+destServer.getTTS_DIR_DUMP_PHYS()+"/"+sourceSchema+".dmp");
        	sb.append(";");
        	sb.append("chmod 760 "+destDataFile);
        	sb.append("\"");
        FileUtil.writeToTextFile(sb.toString(), fileTransferScriptFile);
        TaskTypeNFile scpDump = new TaskTypeNFile(dataTransferTaskType,fileTransferScriptFile).setShellScript(true);
        scpDump.setSubTaskType(SCP_DMP);
        ls.add(scpDump);
        
        //Import Script
        
        File importScriptFile=(new NamingUtil()).getTTSImportScriptFile(destSchema);
        /**
         * VITTOOLS-494 : Change server output size to UNLIMITED for ASM Data Transfer Using Engine Dashboard
         */
        StringBuffer sb2 = engineConverter.initStringBufferWithServerOutSizeUnLimited();
        sb2.append("---------TTS IMPORT-----\n")
            .append("BEGIN\n")
        		.append("TTS.EXPORT_IMPORT(")
        				.append("'"+this.sourceSchema+"'")
        				.append(",'I'")
        				.append(",'"+this.sourceSchema+".dmp'")
        				.append(",'"+this.sourceSchema+".log'")
        				.append(",'DIR_TTS_DUMP'")
        				.append(",'"+destSchema.getSchemaName()+"'")
        				.append(",'"+destDataFile+"'")
        				.append(");")
        		.append("\n")
        	.append("END;\n/\n");
        sb2=engineConverter.addExit(sb2);
        FileUtil.writeToTextFile(sb2.toString(), importScriptFile);
        TaskTypeNFile restoreDump = new TaskTypeNFile(dataTransferTaskType ,importScriptFile);
        restoreDump.setSubTaskType(RESTORE_DMP);
        ls.add(restoreDump);
        return ls;
    }
    /**
     * @author Ram Gautam
     * added to generate the script for ASM data transfer 
     * @return
     * @throws Exception
     */
    public List generateASMTransferScript()throws Exception{
        Schema destSchema = getSchema();
 /*
begin
  VSOURCESCHEMA:='HF0571001999999';
  VDESTINATIONSCHEMA:='S0571001_Z';
  VDUMPLOCATION:='DUMP_DIR';
  vdop:=8;
  vttsjobid:=to_char(sysdate,'YYYYMMDDHH24MISS'); -----Generated by script or supply manually
  tts_transfer.export_import(vsourceschema,'e',vsourceschema || '.dmp',vsourceschema|| '.log',vdumplocation ,vdestinationschema,vttsjobid);
  tts_transfer.SP_TRANSFER('HF0571001999991','S0571001_Y','DUMP_DIR','HF0571001999991.dmp','REMOTE_RAC',20130710347406,'<<Directory_name>>',8);
end;
       
  */
        //Export Script
        System.out.println("getThreadCount()"+getThreadCount());
        this.setUniqueJobId(NamingUtil.getCurrentTimeStamp());
        File exportScriptFile=(new NamingUtil()).getASMExportScriptFile(destSchema);
        /**
         * VITTOOLS-494 : Change server output size to UNLIMITED for ASM Data Transfer Using Engine Dashboard
         */
        StringBuffer sb1 = engineConverter.initStringBufferWithServerOutSizeUnLimited();
        sb1.append("---------TTS_ASM EXPORT-----\n")
        	.append(" DECLARE ")
        	.append("\n")
	            .append(" BEGIN\n")
	        		.append("tts_transfer.EXPORT_IMPORT(")
	        				.append("'"+this.sourceSchema+"'")
	        				.append(",'E'")
	        				.append(",'"+this.sourceSchema+".dmp'")
	        				.append(",'"+this.sourceSchema+".log'")
	        				.append(",'DIR_TTS_DUMP'")
	        				.append(",'"+destSchema.getSchemaName()+"'")
	        				.append(","+this.getUniqueJobId()+"")//export_import job id
	        				.append(");")
	        		.append("\n")
	        		.append(" tts_transfer.SP_TRANSFER(")
	        				.append("'"+this.sourceSchema+"'")
	        				.append(",'"+destSchema.getSchemaName()+"'")
	        				.append(",'DIR_TTS_DUMP'")
	        				.append(",'"+this.sourceSchema+".dmp'")
	        				.append(",'"+destServer.getRemote_Link()+"'")//---Remote_link value from table.
							.append(","+this.getUniqueJobId()+"")//export_import job id	
        					.append(",'"+this.getDataFileDirName()+"'");
	        				 if( getThreadCount() > 0 && getThreadCount() < MAX_PARALLEL ) {
	        					 System.out.println("in if condtion");
	        				 sb1.append(","+getThreadCount());
	        				 } else {
	        					 System.out.println("in else condtion");
	        				 sb1.append(",4");
	        				 }
	        				sb1.append(");")
		        		.append("\n")
		        	.append("\n")
		        	.append(" dbms_output.put_line('JobID: '||"+this.getUniqueJobId()+");")  
		        	.append("\n")
	        	.append("END;\n/\n");
	        				
        sb1=engineConverter.addExit(sb1);
        FileUtil.writeToTextFile(sb1.toString(), exportScriptFile);
        TaskTypeNFile dmpExp = new TaskTypeNFile(dataTransferTaskType,exportScriptFile);
        dmpExp.setSubTaskType(DMP_EXP);
        ls.add(dmpExp.setRunAtSource(true));
        
        /*    //DMP and DBF File Transfer Script
         * transfer script is not needed for ASM 
		
        */
        //Import Script
        File importScriptFile=(new NamingUtil()).getASMImportScriptFile(destSchema);
        /**
         * VITTOOLS-494 : Change server output size to UNLIMITED for ASM Data Transfer Using Engine Dashboard
         */
        StringBuffer sb2 = engineConverter.initStringBufferWithServerOutSizeUnLimited();
        sb2.append("---------TTS_ASM IMPORT-----\n")
            .append("BEGIN\n")
        		.append(" tts_transfer.EXPORT_IMPORT(")
        				.append("'"+this.sourceSchema+"'")
        				.append(",'I'")
        				.append(",'"+this.sourceSchema+".dmp'")
        				.append(",'"+this.sourceSchema+".log'")
        				.append(",'"+this.getDataFileDirName()+"'")// directory pointing to ASM directory
        				.append(",'"+destSchema.getSchemaName()+"'")
        				.append(","+this.getUniqueJobId())//export_import job id
        				.append(",'"+destSchema.getSchemaPwd()+"'")// Password for destination Schema
        				.append(",'"+this.getDRTransferEnabled()+"'")//DRTranferEnabled //always N
	        			.append(",'"+this.getLoginName()+"'")//loginName
        				/*.append((null == destDataFile || "".equals(destDataFile))?
        	                    "": ",'" + destDataFile + "'")*/
        				.append(");")
        		.append("\n")
        	.append("END;\n/\n");
        sb2=engineConverter.addExit(sb2);
        FileUtil.writeToTextFile(sb2.toString(), importScriptFile);
        TaskTypeNFile restoreDump = new TaskTypeNFile(dataTransferTaskType ,importScriptFile);
        restoreDump.setSubTaskType(RESTORE_DMP);
        ls.add(restoreDump);
        return ls;
    }
    
    
    /**
     * @return
     * @throws Exception
     * 
     * Following two procedures are used for warehouse transfer
     * 1. SP_CREATEWHDBLINK
     * 2. PKG_TXSCRUB.SP_TRANSFER
     * 
     * 
     */
    public List genereateWHTransferScript() throws Exception{
    	Schema destSchema = getSchema();
    	File scriptFile = (new NamingUtil()).getDataTransferScriptFile(destSchema);
        StringBuffer sb = new StringBuffer();
        sb.append("---------WAREHOUSE DATA TRANSFER-----\n")
            .append("BEGIN\n")
            .append("   SP_CREATEWHDBLINK(")
            .append("'").append(sourceSchema).append("',")
            .append("'").append(sourcePassword).append("',")
            .append("'").append(sourceHost).append("',")
            .append("'").append(sourcePort).append("',")
            .append("'").append(sourceService).append("'")
            .append(");\n")
            .append("   PKG_TXSCRUB.SP_TRANSFER(")
            .append("'").append(sourceSchema).append("',")
            .append("'").append(destSchema.getSchemaName()).append("',")
            .append("'").append("DBLINK_"+sourceSchema).append("',");
	        if( getThreadCount() > 0 && getThreadCount() < MAX_PARALLEL ) {
				 System.out.println("in if condtion");
			sb.append(getThreadCount());
			} else {
			   System.out.println("in else condtion");
			sb.append("4");
			}
            sb.append(");\n");
            //to drop database link
            sb.append(" EXECUTE IMMEDIATE(")
            .append("'")
            .append("DROP DATABASE LINK ")
            .append("DBLINK_"+sourceSchema).append("'");
            sb.append(");\n")
            
            .append("\nEND;\n/\n");
        sb = engineConverter.addExit(sb);
        String script =  sb.toString();
            
        FileUtil.writeToTextFile(script, scriptFile);

        TaskTypeNFile taskTypeNFile = new TaskTypeNFile( dataTransferTaskType, scriptFile);
        //taskTypeNFile.setWareHouseTasks(Boolean.TRUE);
        taskTypeNFile.setSendMail(Boolean.TRUE);
        taskTypeNFile.setEventIdForMail(fixedParam.getWHParam(WareHouseParams.WH_DATA_TRANSFER_EVENT));
        ls.add(taskTypeNFile);
        return ls;
    	
    }
    
	/**
	 * @Description: Generates transfer script for VC-VC transfer
	 * @param txType
	 * @return
	 * @throws Exception
	 */
	public List genereateVCTransferScript(String txType) throws Exception {
		Schema destSchema = getSchema();
		File scriptFile = (new NamingUtil())
				.getDataTransferScriptFile(destSchema);
		StringBuffer sb = new StringBuffer();
		sb.append("---------VC Data Transfer-----\n").append("BEGIN\n")
				.append("   migration_test.main(").append("'")
				.append(sourceSchema).append("',").append("'")
				.append(destSchema.getSchemaName()).append("',")//.append("'")
				//.append(sourceService).append("',")
				.append("'").append(sourceDbLink).append("'");
		if (txType.equals("ME")) {
			sb.append(",'").append("").append("'");
		}
		sb.append(");").append("\nEND;\n/\n");
		sb = engineConverter.addExit(sb);
		String script = sb.toString();

		FileUtil.writeToTextFile(script, scriptFile);

		TaskTypeNFile taskTypeNFile = new TaskTypeNFile(dataTransferTaskType,
				scriptFile);
		ls.add(taskTypeNFile);
		return ls;
	}
	
	/**
	 * @Description: Script for Mini Engine Output Transfer
	 * @return
	 * @throws Exception
	 */
	public List genereateMETransferScript() throws Exception {
		Schema destSchema = getSchema();
		File scriptFile = (new NamingUtil())
				.getDataTransferScriptFile(destSchema);
		StringBuffer sb = new StringBuffer();
		sb.append("---------ME Data Transfer-----\n").append("BEGIN\n")
				.append("   sp_table_transfer_prod(").append("'")
				.append(sourceSchema).append("',").append("'")
				.append(destSchema.getSchemaName()).append("',")//.append("'")
				//.append(sourceService).append("',")
				.append("'").append(sourceDbLink).append("'");
		sb.append(");").append("\nEND;\n/\n");
		sb = engineConverter.addExit(sb);
		String script = sb.toString();

		FileUtil.writeToTextFile(script, scriptFile);

		TaskTypeNFile taskTypeNFile = new TaskTypeNFile(dataTransferTaskType,
				scriptFile);
		ls.add(taskTypeNFile);
		return ls;
	}
    
    //private static final String DATA_FILE_DIRECTORY_PATH ="/u01/app/oracle/oradata/d2he/datafiles";
    //private static final String TEMP_TABLE_SPACE="temp";
    public List generateBAModuleTransferScriptFile() throws Exception{
    	   Schema srcSchema = getSrcSchema();
    	   Schema runnerSchema = getSchema();
    	   /*
    	    * JIRA: VITTOOLS-201
    	    * */
    	   String dataFileDirectory = getDataFileDirectoy();
    	   System.out.println("Data File Directory from BA Module Transfer(Dmexpress):"+dataFileDirectory);
    	   /*Schema runnerSchema = new Schema()
    	   						.setSchemaName("HF0279001SPRING")
    	   						.setServerName("192.168.72.117")
    	   						//.setServerGroupId("Testing_Server984474");
    	   						.setServerGroupId("OracleServerForVertica");*/
           File scriptFile = (new NamingUtil()).getDataTransferScriptFile(runnerSchema);
           StringBuffer sb = new StringBuffer();
           sb.append("---------DATA TRANSFER-----\n")
               //.append("BEGIN\n")
               .append("   EXEC PKG_DATATRANSFER.SP_MAIN(")
               .append("'").append(sourceSchema).append("',")
               //.append("'").append("HF0279001SPRING").append("',")
               .append("'").append(sourceHost).append("',")
               //.append("'").append("192.168.72.117").append("',")
               .append("'").append(sourcePort).append("',")
               //.append("'").append("1521").append("',")
               .append("'").append(srcSchema.getService()).append("',")
               //.append("'").append("d2he").append("',")
               .append("'").append(runnerSchema.getSchemaName()).append("',")
               //.append("'").append("S0279001_A").append("',")
               .append("'").append(runnerSchema.getServerName()).append("',")
               //.append("'").append("192.168.72.117").append("',")
               .append("'").append(dataFileDirectory).append("'")
               .append(");\n");
               //.append("\nEND;\n/\n");
           sb = engineConverter.addExit(sb);
           String script =  sb.toString();
               
           FileUtil.writeToTextFile(script, scriptFile);

           ls.add(new TaskTypeNFile( dataTransferTaskType, scriptFile));
           return ls;
    }
    public List generateBAModuleTransferScriptFile_CMA() throws Exception {
    	 Schema srcSchema = getSrcSchema();
  	   	 Schema runnerSchema = getSchema();
  	     String dataFileDirectory = getDataFileDirectoy();
  	     
  	     System.out.println("Data File Directory from BA Module Transfer(Cma):"+dataFileDirectory);
  	     System.out.println("Source schema password (Cma):"+srcSchema.getSchemaPwd());
  	     //System.out.println("Destination schema password (Cma):"+runnerSchema.getSchemaPwd());
  	     
	  	 File scriptFile = (new NamingUtil()).getDataTransferScriptFile(runnerSchema);
	     StringBuffer sb = new StringBuffer();
	     sb.append("---------ORACLE DR BA DATA TRANSFER-----\n")
	         //.append("BEGIN\n")
	         .append("   EXEC PKG_BA_DATA_TRANSFER.SP_MAIN(")
	         .append("'").append(sourceSchema).append("',")
	         //.append("'").append("HF0279001SPRING").append("',")
	         .append("'").append(sourceHost).append("',")
	         //.append("'").append("192.168.72.117").append("',")
	         .append("'").append(sourcePort).append("',")
	         //.append("'").append("1521").append("',")
	         .append("'").append(srcSchema.getService()).append("',")
	         //.append("'").append("d2he").append("',")
	         .append("'").append(srcSchema.getSchemaPwd()).append("',")//added
	         .append("'").append(runnerSchema.getSchemaName()).append("',")
	         //.append("'").append("S0279001_A").append("',")
	         .append("'").append(runnerSchema.getServerName()).append("',")
	         //.append("'").append("192.168.72.117").append("',")
	         .append("'").append(runnerSchema.getSchemaPwd()).append("',")//added
	         .append("'").append(dataFileDirectory).append("'")
	         .append(");\n");
	         //.append("\nEND;\n/\n");
	     sb = engineConverter.addExit(sb);
	     String script =  sb.toString();
	         
	     FileUtil.writeToTextFile(script, scriptFile);
	
	     ls.add(new TaskTypeNFile( dataTransferTaskType, scriptFile));
	     return ls;
    }
    public List generateOracleDRBAModuleTransferScriptFile_CMA() throws Exception {
   	 Schema srcSchema = getSrcSchema();
 	   	 Schema runnerSchema = getSchema();
 	     String dataFileDirectory = getDataFileDirectoy();
 	     
 	     System.out.println("Data File Directory from BA Module Transfer(Cma):"+dataFileDirectory);
 	     System.out.println("Source schema password (Cma):"+srcSchema.getSchemaPwd());
 	     //System.out.println("Destination schema password (Cma):"+runnerSchema.getSchemaPwd());
 	     
	  	 File scriptFile = (new NamingUtil()).getDataTransferScriptFile(runnerSchema);
	     StringBuffer sb = new StringBuffer();
	     sb.append("---------DATA TRANSFER-----\n")
	         //.append("BEGIN\n")
	         .append("   EXEC PKG_BA_DATA_TRANSFER.SP_MAIN(")
	         .append("'").append(sourceSchema).append("',")
	         //.append("'").append("HF0279001SPRING").append("',")
	         .append("'").append(sourceHost).append("',")
	         //.append("'").append("192.168.72.117").append("',")
	         .append("'").append(sourcePort).append("',")
	         //.append("'").append("1521").append("',")
	         .append("'").append(srcSchema.getService()).append("',")
	         //.append("'").append("d2he").append("',")
	         .append("'").append(srcSchema.getSchemaPwd()).append("',")//added
	         .append("'").append(runnerSchema.getSchemaName()).append("',")
	         //.append("'").append("S0279001_A").append("',")
	         .append("'").append(runnerSchema.getServerName()).append("',")
	         //.append("'").append("192.168.72.117").append("',")
	         .append("'").append(runnerSchema.getSchemaPwd()).append("',")//added
	         .append("'").append(dataFileDirectory).append("'")
	         .append(");\n");
	         //.append("\nEND;\n/\n");
	     sb = engineConverter.addExit(sb);
	     String script =  sb.toString();
	         
	     FileUtil.writeToTextFile(script, scriptFile);
	
	     ls.add(new TaskTypeNFile( dataTransferTaskType, scriptFile));
	     return ls;
    }
    
    private Server srcServer;
    private Server destServer;
    private String srcDataFile;
    private String destDataFile;
    private String destDataFileDir;
    private static String RESTORE_DMP = "RESTORE_DMP";
    private static String DMP_EXP = "DMP_EXP";
    private static String SCP_DMP = "SCP_DMP";
    
    public String getDataFileDir() {
		return destDataFileDir;
	}
	public DataTransfer setDataFileDir(String dataFileDir) {
		this.destDataFileDir = dataFileDir;
		return this;
	}
    public String getDataFile(Schema utilSchema,String schemaName){
		String dataFileDir="";

		java.sql.Connection conn=null;
		java.sql.ResultSet rs=null;
		java.sql.PreparedStatement pstmt=null;

		try{
	    	String dataFileSql="select Utility.FN_GETFILEOF_USER(?) from dual";
			OracleDBConnector con=new OracleDBConnector();
	    	conn=con.getConnectionForSchema(utilSchema);
	    	pstmt=conn.prepareStatement(dataFileSql);
	    	pstmt.setString(1,schemaName);
	    	rs=pstmt.executeQuery();
	    	if(rs.next()){
	    		dataFileDir=rs.getString(1);
	    	}
		} catch(Exception e){
		} finally{
			try{
			rs.close();
			pstmt.close();
			conn.close();
			}catch(Exception e){}
		}
    	return dataFileDir;
	}
    
    public void init() throws Exception {
		Schema destSchema = getSchema();
		
		//oracle to oracle data transfer
		if(destSchema.getHostingServer().equalsIgnoreCase(Constants.ORACLE))
		{
			Schema srcSchema = new Schema()
					.setServerName(sourceHost)
	        		.setPort(sourcePort)
	        		.setService(sourceService)
	        		.setSidFlag(this.useSidForLink);
					
			this.srcServer=ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(srcSchema);
	    	this.destServer=ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(destSchema);
	        if(this.txType.equals("TTS")||this.txType.equals("ASM") ) {
	        
	        Schema destUtilSchema = (destSchema.getCopy())
	        							.setSchemaName(destServer.getUTILITY_USER())
	        							.setSchemaPwd(destServer.getUTILITY_PASS());
	        	sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(destUtilSchema);
	        	
	        Schema srcUtilSchema = new Schema()
	        		.setServerName(sourceHost)
	        		.setPort(sourcePort)
	        		.setService(sourceService)
	        		.setSidFlag(this.useSidForLink)
	        		.setSchemaName(srcServer.getUTILITY_USER())
	        		.setSchemaPwd(srcServer.getUTILITY_PASS());
	            
	            srcSqlPlusUrl = OracleDBConnector.getTnsStyleUrl(srcUtilSchema);
	        	srcDataFile=getDataFile(srcUtilSchema,sourceSchema);
	        	String srcDataFileNameOnly=srcDataFile.substring(srcDataFile.lastIndexOf("/")+1);
	        	destDataFile=this.destDataFileDir+"/"+srcDataFileNameOnly;
	        }
	        else if(this.txType.equals("WH") || this.txType.equals("VC") ||  this.txType.equals("ME")){
	            Schema destUtilSchema = (destSchema.getCopy())
						.setSchemaName(destServer.getUTILITY_USER())
						.setSchemaPwd(destServer.getUTILITY_PASS());
	            sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(destUtilSchema);
	        }
	        else{
	        	sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(destSchema);
	        }
	        
	        ls = generateScript( );
	        Schema frontSchema = getSchema();


	        desc = "Data Transfer to " +
	            " [" + frontSchema.getServerGroupName() + "] " +
	            frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
	            frontSchema.getService() + ":" + frontSchema.getSchemaName() + 
	            " from " +
	            sourceHost + ":" + sourcePort + ":" + sourceService + ":" + sourceSchema ;
		}
		
		//oracle to vertica data transfer using dmexpress
		else if(destSchema.getHostingServer().equalsIgnoreCase(Constants.VERTICA))
		{
			Schema dmExpressSchema = getDmExpressSchema();
			
	    	File scriptFile = (new NamingUtil()).getVerticaDataTransferScriptFile(getExecutionId(),destSchema.getHostingServer());
	    	ls.add(new TaskTypeNFile( dataTransferTaskType, scriptFile).setShellScript(true)); 
			
	    	
	    	desc = "Data Transfer to " +
            	" [" + destSchema.getServerGroupName() + "] " +
	            destSchema.getServerName() + ":" + destSchema.getPort() + "/" +
	            destSchema.getDatabase() + ":" + destSchema.getSchemaName() + 
	            " from " +
	            sourceHost + ":" + sourcePort + ":" + sourceSchema + " using " + 
	            dmExpressSchema.getServerName() + ":" + dmExpressSchema.getPort() + "/" + dmExpressSchema.getInstance();
			
		}
		//oracle to vertica data transfer using cma
		else if(destSchema.getHostingServer().equalsIgnoreCase(Constants.VERTICA_CMA) ||destSchema.getHostingServer().equalsIgnoreCase(Constants.VERTICA_DR_CMA))
		{
			//Schema dmExpressSchema = getDmExpressSchema();
			
	    	File scriptFile = (new NamingUtil()).getVerticaDataTransferScriptFile(getExecutionId(),destSchema.getHostingServer());
	    	ls.add(new TaskTypeNFile( dataTransferTaskType, scriptFile).setShellScript(true)); 
			
	    	
	    	desc = "Data Transfer to " +
            	" [" + destSchema.getServerGroupName() + "] " +
	            destSchema.getServerName() + ":" + destSchema.getPort() + "/" +
	            destSchema.getDatabase() + ":" + destSchema.getSchemaName() + 
	            " from " +
	            sourceHost + ":" + sourcePort + ":" + sourceSchema +" with Execution Number :"+getExecutionId();
			
		}
		//oracle to oracle data transfer [BA modules] using dmexpress
		else if(destSchema.getHostingServer().equalsIgnoreCase(Constants.ORACLE_BA))
		{
			//here destSchema is oraDestSchema
			this.destServer=ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(destSchema);
			
			Schema destUtilSchema = (destSchema.getCopy())
								.setSchemaName(destServer.getUTILITY_USER())
								.setSchemaPwd(destServer.getUTILITY_PASS());
			
			sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(destUtilSchema);
			
			//System.out.println("SQLPLUS URL FOR TRANSFERING BA MODULE IS"+sqlPlusUrl);
			
			ls = generateBAModuleTransferScriptFile( );
	        Schema frontSchema = getSchema();


	        desc = "Data Transfer to " +
	            " [" + frontSchema.getServerGroupName() + "] " +
	            frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
	            frontSchema.getService() + ":" + frontSchema.getSchemaName() + 
	            " from " +
	            sourceHost + ":" + sourcePort + ":" + sourceService + ":" + sourceSchema ;
		}
		
		//oracle to oracle data transfer [BA modules] using cma
		else if(destSchema.getHostingServer().equalsIgnoreCase(Constants.ORACLE_BA_CMA))
		{
			//here destSchema is oraDestSchema
			System.out.println("Inside ba module transfer (cma)>>>>>>>>>>>>>>");
			this.destServer=ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(destSchema);
			
			Schema destUtilSchema = (destSchema.getCopy())
								.setSchemaName(destServer.getUTILITY_USER())
								.setSchemaPwd(destServer.getUTILITY_PASS());
			
			sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(destUtilSchema);
			
			//System.out.println("SQLPLUS URL FOR TRANSFERING BA MODULE IS"+sqlPlusUrl);
			
			ls = generateBAModuleTransferScriptFile_CMA( );
	        Schema frontSchema = getSchema();


	        desc = "Data Transfer to " +
	            " [" + frontSchema.getServerGroupName() + "] " +
	            frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
	            frontSchema.getService() + ":" + frontSchema.getSchemaName() + 
	            " from " +
	            sourceHost + ":" + sourcePort + ":" + sourceService + ":" + sourceSchema ;
		}
		
		//oracle to oracle DR data transfer [BA modules] using cma
		else if(destSchema.getHostingServer().equalsIgnoreCase(Constants.ORACLE_DR_BA_CMA))
		{
			//here destSchema is oraDestSchema
			System.out.println("Inside oracle dr ba module transfer (cma)>>>>>>>>>>>>>>");
			this.destServer=ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(destSchema);
			
			Schema destUtilSchema = (destSchema.getCopy())
								.setSchemaName(destServer.getUTILITY_USER())
								.setSchemaPwd(destServer.getUTILITY_PASS());
			
			sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(destUtilSchema);
			
			//System.out.println("SQLPLUS URL FOR TRANSFERING BA MODULE IS"+sqlPlusUrl);
			
			ls = generateOracleDRBAModuleTransferScriptFile_CMA( );
	        Schema frontSchema = getSchema();


	        desc = "Data Transfer to " +
	            " [" + frontSchema.getServerGroupName() + "] " +
	            frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
	            frontSchema.getService() + ":" + frontSchema.getSchemaName() + 
	            " from " +
	            sourceHost + ":" + sourcePort + ":" + sourceService + ":" + sourceSchema ;
		}
    }

    private String desc = "Data Transfer: ";
    public String getDescription() {
        return desc;
    }

    private String srcSqlPlusUrl=null;
    public String getSrcSQLPlusUrl(){
    	return this.srcSqlPlusUrl;
    }
    private String sqlPlusUrl = null;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }

    public TaskType getTaskType() {
        return dataTransferTaskType;

    }


    public SQLPlusRunnable setTaskType( TaskType tskType) {
        return this;
    }


    public List getTaskTypeNFileList() {
        return ls;
    }

    boolean sameServer = false;
    public DataTransfer setSameServer(boolean sameSrvr) {
        sameServer = sameSrvr;
        return this;
    }

    public boolean isSameServer() {
        return sameServer;
    }
    
    volatile long lastUpdate = -1;
    public RunningStatus getRunningStatus() throws Exception {
        long currentTime = System.currentTimeMillis();

        if ( currentTime - lastUpdate > CACHE_TIME ) {

            lastUpdate = currentTime;
            if ( "F".equals(txType)) {
                if ( runningStatus.getNoOfModules() <= 0 ) {
                    Schema dataSourceSchema =
                        (new Schema()).setServerName( sourceHost).setPort( sourcePort).setService( sourceService)
                        .setSidFlag( useSidForLink)
                        .setSchemaName(sourceSchema).setSchemaPwd(sourcePassword);
                    int totalModules = compFactory.getEngineMonitorForSystem().getProcNTableCount( dataSourceSchema);
                    runningStatus.setNoOfModules( totalModules);
                }
                runningStatus
                    .setCompletedModules( compFactory.getEngineMonitorForSystem().getProcNTableCount( getSchema()));

                return runningStatus;
            } else if ( "S".equals(txType)) {
                if ( runningStatus.getNoOfModules() <= 0 ) {
                    Schema dataSourceSchema =
                        (new Schema()).setServerName( sourceHost).setPort( sourcePort).setService( sourceService)
                        .setSidFlag( useSidForLink)
                        .setSchemaName(sourceSchema).setSchemaPwd(sourcePassword);
                    int totalModules = compFactory.getEngineMonitorForSystem().getHRHPCount( dataSourceSchema);
                    runningStatus.setNoOfModules( totalModules);
                }
                runningStatus
                    .setCompletedModules( compFactory.getEngineMonitorForSystem().getHRHPCount( getSchema()));

                return runningStatus;
            }else if ("TTS".equals(txType)) {
	            	TaskTypeNFile fileTx=(TaskTypeNFile)ls.get(1);	            	
		            if(fileTx.isStarted()){	
		            	if (SCP_DMP.equals(subTaskType)) {
			            	if(TTSFilesTxPercentage<100){
				            	String destinationServer=runnerSchema.getServerName();
				            	String sourceServer=sourceHost;
				            	String sourceFilename=sourceSchema;
				            	String destinationFilename=sourceSchema;
				            	
				            	dashboard.util.DataTransferStatus dts=new dashboard.util.DataTransferStatus();
				            	dts.setSourceServer(sourceServer);
				            	dts.setDestServer(destinationServer);
				            	dts.setSourceFileName(new String[]{
				            			this.srcServer.getTTS_DIR_DUMP_PHYS()+"/"+sourceFilename+".dmp",
				            			this.srcDataFile});
				            	dts.setDestFileName(new String[]{
				            			this.destServer.getTTS_DIR_DUMP_PHYS()+"/"+destinationFilename+".dmp",
				            			this.destDataFile});
				            	
				            	TTSFilesTxPercentage=dts.getCompleted();
				            	
				            	TTSFilesTxStatusList  = new LinkedList();
				            	
				            	TTSFilesTxStatusList.add("Total :("+dts.getTotalDestinationSize()+"/"+dts.getTotalSourceSize()+")bytes");
				            	
				            	for(int i=0;i<dts.getSourceFileName().length;i++){
				            		TTSFilesTxStatusList.add(dts.getDestFileName()[i]+" : ("+dts.getDestinationFileSize()[i]+"/"+dts.getSourceFileSize()[i]+")bytes");
				            	}
			            	}
			            	
			            	runningStatus.setNoOfModules(100);
			            	runningStatus.setCompletedModules(TTSFilesTxPercentage);
			            	runningStatus.setCompletedList(TTSFilesTxStatusList);
		            	} else if ( RESTORE_DMP.equals(subTaskType)) {
		            		try{
		            			return getAllObjectStatus();
		            		}catch(Exception destSchemaIsNotYetReady_showOldStatus){
				            	runningStatus.setNoOfModules(100);
				            	runningStatus.setCompletedModules(TTSFilesTxPercentage);
				            	runningStatus.setCompletedList(TTSFilesTxStatusList);
		            		}
		            	}
		            }
		            return runningStatus;
            }
            else if("ASM".equals(txType)){
            	//System.out.println("test <<>< ASM");
            	TaskTypeNFile fileTx=(TaskTypeNFile)ls.get(0);
            	if(fileTx.isStarted()){	
            		if (DMP_EXP.equals(subTaskType)) {
            			//System.out.println("inner dmp_exp type");
            			runningStatus =ComponentFactory.getInstance().getEngineMonitorForSystem().getRunningStatusDataTransfer(uniqueJobId);
            			runningStatus.setUniqueJobId(uniqueJobId);
            			
            			
            		}
            		if(RESTORE_DMP.equals(subTaskType)){
            			//System.out.println("inner dmp_restore type");
            		}
            	}
            	return runningStatus;
            }
        }
        //System.out.println("getting outside of if");
        return new RunningStatus();// getAllObjectStatus();
    }
    public List getStatusList() throws Exception {
        if (getTransferType().equals("ASM")) {
        	//System.out.println("uniqueJobid<><<"+uniqueJobId);
        	List ls =ComponentFactory.getInstance().getEngineMonitorForSystem().getDataTransferStatusList(uniqueJobId);
        	//System.out.println("list size<><<"+ls.size());
        	return ls;
        }
        return getEmptyList();
    }
    
    public List<VHTransferLog> getMiniEngineOutputTransferLog() throws Exception {
    	if (getTransferType().equals("ME")) {
    		List<VHTransferLog> log =ComponentFactory.getInstance().getEngineMonitorForSystem().getMiniEngineOutputTransferLog(getSchema());
    		return log;
    	}
    	return getEmptyList();
    }
    
    public List getAfterInvalidProcList(){
    	List ls=lsEmpty;
    	List newList=new LinkedList();
    	for(int i=0;i<this.getTaskTypeNFileList().size();i++){
    		if(((dashboard.data.TaskTypeNFile)this.getTaskTypeNFileList().get(i)).isFailure()){
    		newList.add(((dashboard.data.TaskTypeNFile)this.getTaskTypeNFileList().get(i)).getScriptFile().getAbsolutePath());
    		ls=newList;
    		}
    	}
    	return ls;
    }
    String subTaskType = "";
    public void setSubTaskType(String _subTaskType) {
    	subTaskType = _subTaskType;
    }
    public String getSubTaskType() { return subTaskType; }
}
