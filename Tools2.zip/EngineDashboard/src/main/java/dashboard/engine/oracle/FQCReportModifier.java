package dashboard.engine.oracle;

import java.io.File;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.TaskTypeNFile;
import dashboard.db.FixedParameter;
import dashboard.db.OracleDBConnector;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.FileUtil;
import dashboard.util.QCConstants;

public class FQCReportModifier extends BaseSQLPlusRunnable {

	private ComponentFactory compFactory;
	private FixedParameter fixedParam;
	private Map<String, String> fqcParams;
	private Schema fqcSchema;

	protected Log logger = LogFactory.getLog(getClass());

	public FQCReportModifier() throws SQLException {
		System.out.println("FQCReportModifier constructer called!!!!");
		compFactory = ComponentFactory.getInstance();
		fixedParam = compFactory.getFixedParameters();
		setFqcParams();
	}

	/**
	 * @Description: Setting necessary fqc report parameters
	 * @throws SQLException
	 */
	public void setFqcParams() throws SQLException {
		fqcParams = fixedParam.getFQCExtractParams();
		fqcSchema = new Schema()
				.setSchemaName(fqcParams.get(QCConstants.FQC_SCHEMA))
				.setSchemaPwd(fqcParams.get(QCConstants.FQC_SCHEMA_PWD))
				.setServerName(fqcParams.get(QCConstants.FQC_SERVER))
				.setPort(fqcParams.get(QCConstants.FQC_PORT))
				.setService(fqcParams.get(QCConstants.FQC_SERVICE));

		System.out.println("FQC SCHEMA DETAILS " + fqcSchema);

	}

	@Override
	public void init() throws Exception {
		ls = generateScript();
		Schema frontSchema = getSchema();
		sqlPlusUrlForFQC = OracleDBConnector.getTnsStyleUrl(fqcSchema);
		desc = "Run Report for: [" + frontSchema.getServerGroupName() + "] "
				+ frontSchema.getServerName() + ":" + frontSchema.getPort()
				+ "/" + frontSchema.getService() + ":"
				+ frontSchema.getSchemaName();
	}

	/**
	 * @Description: Method for creating FQC script
	 * @return list
	 * @throws Exception
	 */
	public List generateScript() throws Exception {
		File fqcReport = (new NamingUtil()).getFQCReportScriptFile(getSchema());
		StringBuffer sb = engineConverter.initStringBuffer();
		sb.append("---------FQC Report Execution -----\n")
				.append("BEGIN\n")
				.append(fqcSchema.getSchemaName()
						+ ".FQC_REPORT.maincallingproc(")
				.append("'" + getSchema().getSchemaName() + "'")
				.append(",'@" + getDbLink(getSchema()) + "'")
				.append(",'" + fqcParams.get(QCConstants.FQC_PROCESSING_MODE)
						+ "'").append(");").append("\n").append("END;\n/\n");
		sb = engineConverter.addExit(sb);

		FileUtil.writeToTextFile(sb.toString(), fqcReport);
		TaskTypeNFile taskTypeNFile = new TaskTypeNFile(TaskType.FQC_REPORT,
				fqcReport);
		taskTypeNFile.setRunAtFQCServer(Boolean.TRUE);
		taskTypeNFile.setAlwaysWriteOutputFile(Boolean.TRUE);
		ls.add(taskTypeNFile);
		return ls;
	}

	protected TaskType taskType = TaskType.FQC_REPORT;

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	public SQLPlusRunnable setTaskType(TaskType taskType) {
		if (null != taskType) {
			this.taskType = taskType;
		}
		return this;
	}

	private String desc = "Run Report: ";

	@Override
	public String getDescription() {
		if (null != taskType) {
			Schema frontSchema = getSchema();

			desc = // taskType.toString() +
			" [" + frontSchema.getServerGroupName() + "] "
					+ frontSchema.getServerName() + ":" + frontSchema.getPort()
					+ "/" + frontSchema.getService() + ":"
					+ frontSchema.getSchemaName();
		}
		return desc;
	}

	@Override
	public List getTaskTypeNFileList() {
		return ls;
	}

	private String sqlPlusUrlForFQC = null;
	private String sqlPlusUrl = null;

	@Override
	public String getSQLPlusUrl() {
		return sqlPlusUrl;
	}

	public String getSQLPlusUrlForFQC() {
		return sqlPlusUrlForFQC;
	}

	public boolean isWriteOutputFile() {
		return false;
	}
}
