package dashboard.engine.oracle;

import java.io.File;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.TaskTypeNFile;
import dashboard.db.FixedParameter;
import dashboard.db.OracleDBConnector;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.FileUtil;

public class DXCGRecordCountModifier extends BaseSQLPlusRunnable {

	private static final String STAGING_SERVER_HOST = "STAGING_SERVER_HOST";
	private static final String STAGING_SERVER_PORT = "STAGING_SERVER_PORT";
	private static final String STAGING_SERVER_SERVICE = "STAGING_SERVER_SERVICE";
	private static final String STAGING_SERVER_SCHEMA = "STAGING_SERVER_SCHEMA";
	private static final String STAGING_SERVER_SCHEMA_PWD = "STAGING_SERVER_SCHEMA_PWD";

	private ComponentFactory compFactory;
	private FixedParameter fixedParam;
	private Map<String, String> stagingServer;
	private Schema stagingSchema;

	protected Log logger = LogFactory.getLog(getClass());

	public DXCGRecordCountModifier() throws SQLException {
		System.out.println("DXCGReportCountModifier constructer called!!!!");
		compFactory = ComponentFactory.getInstance();
		fixedParam = compFactory.getFixedParameters();
		stagingServer = fixedParam.getStagingServerDetails();
		stagingSchema = new Schema().setSchemaName(stagingServer.get(STAGING_SERVER_SCHEMA))
				.setSchemaPwd(stagingServer.get(STAGING_SERVER_SCHEMA_PWD))
				.setServerName(stagingServer.get(STAGING_SERVER_HOST)).setPort(stagingServer.get(STAGING_SERVER_PORT))
				.setService(stagingServer.get(STAGING_SERVER_SERVICE));
	}

	private String stagingSQLPlusUrl = null;
	private String desc = "Run DXCG Report Count: ";

	@Override
	public void init() throws Exception {
		ls = generateScript();
		Schema frontSchema = getSchema();
		stagingSQLPlusUrl = OracleDBConnector.getTnsStyleUrl(stagingSchema);
		desc = "Run Report for: [" + frontSchema.getServerGroupName() + "] " + frontSchema.getServerName() + ":"
				+ frontSchema.getPort() + "/" + frontSchema.getService() + ":" + frontSchema.getSchemaName();

	}

	/**
	 * @Description: Method for creating DXCG Report Count Script
	 * @return list
	 * @throws Exception
	 */
	public List generateScript() throws Exception {
		File dxcgReportCount = (new NamingUtil()).getDXCGReportCountScriptFile(getSchema());
		StringBuffer sb = engineConverter.initStringBuffer();
		sb.append("---------DXCG Report Count Execution -----\n").append("BEGIN\n")
				.append(stagingSchema.getSchemaName() + ".PKG_DXCG.sp_execute(")
				.append("'" + getSchema().getSchemaName() + "'").append(",'" + getDbLink(getSchema()) + "'")
				.append(");").append("\n").append("END;\n/\n");
		sb = engineConverter.addExit(sb);

		FileUtil.writeToTextFile(sb.toString(), dxcgReportCount);
		TaskTypeNFile taskTypeNFile = new TaskTypeNFile(TaskType.DXCG_RECORD_COUNT, dxcgReportCount);
		taskTypeNFile.setRunAtStagingServer(Boolean.TRUE);
		taskTypeNFile.setAvoidOraError(Boolean.TRUE);
		// taskTypeNFile.setAlwaysWriteOutputFile(Boolean.TRUE);
		ls.add(taskTypeNFile);
		return ls;
	}

	private TaskType taskType = TaskType.DXCG_RECORD_COUNT;

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	public SQLPlusRunnable setTaskType(TaskType taskType) {
		if (null != taskType) {
			this.taskType = taskType;
		}
		return this;
	}

	@Override
	public String getDescription() {
		if (null != taskType) {
			Schema frontSchema = getSchema();

			desc = // taskType.toString() +
			" [" + frontSchema.getServerGroupName() + "] " + frontSchema.getServerName() + ":" + frontSchema.getPort()
					+ "/" + frontSchema.getService() + ":" + frontSchema.getSchemaName();
		}
		return desc;
	}

	@Override
	public List getTaskTypeNFileList() {
		return ls;
	}

	@Override
	public String getSQLPlusUrl() {
		return null;
	}

	public String getStagingSQLPlusUrl() {
		return stagingSQLPlusUrl;
	}

	public boolean isWriteOutputFile() {
		return false;
	}
}
