package dashboard.engine.oracle;

import java.io.File;
import java.util.List;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.TaskTypeNFile;
import dashboard.data.WareHouseTask;
import dashboard.db.OracleDBConnector;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.FileUtil;
import dashboard.util.WareHouseParams;

public class WareHouse extends BaseSQLPlusRunnable {

	private Server whServer;

	public WareHouse() {
		super();
	}

	@Override
	public void init() throws Exception {
		ls = generateScript();

		Schema WHSchema = getSchema();
		srcSqlPlusUrl = OracleDBConnector.getTnsStyleUrl(WHSchema);// runs in WH schema

		this.whServer = ComponentFactory.getInstance()
				.getEngineMonitorForSystem()
				.getServer(WHSchema);
		Schema utilSchema = (WHSchema.getCopy()).setSchemaName(
				whServer.getUTILITY_USER()).setSchemaPwd(
				whServer.getUTILITY_PASS());
		sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(utilSchema);// runs in utility schema

		desc = // taskType.toString() +
		" [" + WHSchema.getServerGroupName() + "] " + WHSchema.getServerName()
				+ ":" + WHSchema.getPort() + "/" + WHSchema.getService() + ":"
				+ WHSchema.getSchemaName();

	}

	protected TaskType taskType = null;

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	private WareHouseTask wareHouseTask = null;

	public WareHouse setWareHouseTask(WareHouseTask w) {
		this.wareHouseTask = w;
		if (wareHouseTask != null) {
			if (wareHouseTask.isExecuteWHEngine())
				taskType = TaskType.EXECUTE_WH_ENGINE;
			if (wareHouseTask.isCreateSynonymForHF())
				taskType = TaskType.CREATE_SYNONYMS_HF;
			if (wareHouseTask.isCreateSynonymForHPnHR())
				taskType = TaskType.CREATE_SYNONYMS_HPNHR;
			if (wareHouseTask.isCompileWHEngine())
				taskType = TaskType.COMPLIE_WH_ENGINE_SCRIPT;
		}
		return this;
	}

	public WareHouseTask getWareHouseTask() {
		return wareHouseTask;
	}

	@Override
	public SQLPlusRunnable setTaskType(TaskType taskType) {
		if (null != taskType) {
			this.taskType = taskType;
		}
		return this;
	}

	private String desc = "Execute WareHouse Engine: ";

	@Override
	public String getDescription() {
		if (null != taskType) {
			Schema frontSchema = getSchema();

			desc = // taskType.toString() +
			" [" + frontSchema.getServerGroupName() + "] "
					+ frontSchema.getServerName() + ":" + frontSchema.getPort()
					+ "/" + frontSchema.getService() + ":"
					+ frontSchema.getSchemaName();
		}
		return desc;
	}

	@Override
	public List getTaskTypeNFileList() {
		return ls;
	}

	private String srcSqlPlusUrl = null;

	public String getSrcSQLPlusUrl() {
		return this.srcSqlPlusUrl;
	}

	private String sqlPlusUrl = null;

	@Override
	public String getSQLPlusUrl() {
		return sqlPlusUrl;
	}

	private Schema frontSchema;

	public Schema getFrontSchema() {
		return frontSchema;
	}

	public WareHouse setFrontSchema(Schema frontSchema) {
		this.frontSchema = frontSchema;
		return this;
	}

	private Schema scrubSchema;

	public Schema getScrubSchema() {
		return scrubSchema;
	}

	public WareHouse setScrubSchema(Schema scrubSchema) {
		this.scrubSchema = scrubSchema;
		return this;
	}

	String isHRA = "N";
	
	public String getIsHRA() {
		return isHRA;
	}

	public WareHouse setIsHRA(String isHRA) {
		this.isHRA = isHRA;
		return this;
	}

	private List generateScript() throws Exception {
		Schema wareHouseSchema = getSchema();
		Schema scrubSchema = getScrubSchema();
		Schema frontSchema = getFrontSchema();

		// Creating synonym for HP and HR
		if (wareHouseTask.isCreateSynonymForHPnHR()) {
			File createSynonymForHPnHR = (new NamingUtil())
					.getCreateSynonymScriptFileForHPNHR(wareHouseSchema);
			StringBuffer sb1 = engineConverter.initStringBuffer();
			sb1.append("---------Create WH Synonyms For HP and HR -----\n")
					.append("BEGIN\n").append(" UTILITY.sp_createwhsynonyms(")
					.append("'" + scrubSchema.getSchemaName() + "'")
					.append(",'Y'").append(",'N'")
					.append(",'" + scrubSchema.getSchemaPwd() + "'")
					.append(",'" + scrubSchema.getServerName() + "'")
					.append(",'" + scrubSchema.getPort() + "'")
					.append(",'" + scrubSchema.getService() + "'").append(");")
					.append("\n").append("END;\n/\n");
			sb1 = engineConverter.addExit(sb1);

			FileUtil.writeToTextFile(sb1.toString(), createSynonymForHPnHR);
			TaskTypeNFile taskTypeNFile1 = new TaskTypeNFile(
					TaskType.CREATE_SYNONYMS_HPNHR, createSynonymForHPnHR);
			taskTypeNFile1.setRunAtSource(Boolean.TRUE);
			taskTypeNFile1.setHaltProcessWhenOraError(Boolean.TRUE);
			taskTypeNFile1.setAlwaysWriteOutputFile(Boolean.TRUE);
			ls.add(taskTypeNFile1);
		}
		
		// Creating synonym for HF
		if (wareHouseTask.isCreateSynonymForHF()) {
			File createSynonymForHF = (new NamingUtil())
					.getCreateSynonymScriptFileForHF(wareHouseSchema);
			StringBuffer sb2 = engineConverter.initStringBuffer();
			sb2.append("---------Create WH Synonyms For HF -----\n")
					.append("BEGIN\n").append(" UTILITY.sp_createwhsynonyms(")
					.append("'" + frontSchema.getSchemaName() + "'")
					.append(",'N'").append(",'N'")
					.append(",'" + frontSchema.getSchemaPwd() + "'")
					.append(",'" + frontSchema.getServerName() + "'")
					.append(",'" + frontSchema.getPort() + "'")
					.append(",'" + frontSchema.getService() + "'").append(");")
					.append("\n").append("END;\n/\n");
			sb2 = engineConverter.addExit(sb2);

			FileUtil.writeToTextFile(sb2.toString(), createSynonymForHF);
			TaskTypeNFile taskTypeNFile2 = new TaskTypeNFile(
					TaskType.CREATE_SYNONYMS_HF, createSynonymForHF);
			taskTypeNFile2.setRunAtSource(Boolean.TRUE);
			taskTypeNFile2.setHaltProcessWhenOraError(Boolean.TRUE);
			taskTypeNFile2.setAlwaysWriteOutputFile(Boolean.TRUE);
			ls.add(taskTypeNFile2);

		}

		// Compiling Warehouse Script
		if (wareHouseTask.isCompileWHEngine()) {
			File wareHouseScript = (new NamingUtil())
					.getWHEngineScriptFile(wareHouseSchema);
			String script = engineConverter
					.getModifiedWHScript(wareHouseSchema);
			FileUtil.writeToTextFile(script, wareHouseScript);
			TaskTypeNFile taskTypeNFile = new TaskTypeNFile(
					TaskType.COMPLIE_WH_ENGINE_SCRIPT, wareHouseScript);
			taskTypeNFile.setRunAtSource(Boolean.TRUE);
			taskTypeNFile.setHaltProcessWhenOraError(Boolean.TRUE);
			taskTypeNFile.setAlwaysWriteOutputFile(Boolean.TRUE);
			ls.add(taskTypeNFile);
		}

		// WareHouse Engine Execution
		if (wareHouseTask.isExecuteWHEngine()) {
			File wareHouseScript = (new NamingUtil())
					.getWHRunEngineScriptFile(wareHouseSchema);
			StringBuffer sb4 = engineConverter.initStringBuffer();
			sb4.append("---------Executing Warehouse Engine -----\n")
					.append("BEGIN\n")
					.append(" sp_LoadWareHouseBase(")
					.append("'" + wareHouseSchema.getSchemaName() + "'")
					.append(",'" + wareHouseSchema.getSchemaName() + "'")
					//.append(",'"+ isHRA + "'")
					.append(");").append("\n").append(" sp_LoadWareHousePlus(")
					.append("'" + wareHouseSchema.getSchemaName() + "'")
					.append(",'" + wareHouseSchema.getSchemaName() + "'")
					.append(",'" + isHRA + "'").append(");").append("\n")
					.append("END;\n/\n");
			sb4 = engineConverter.addExit(sb4);
			FileUtil.writeToTextFile(sb4.toString(), wareHouseScript);
			TaskTypeNFile taskTypeNFile = (new TaskTypeNFile(
					TaskType.EXECUTE_WH_ENGINE, wareHouseScript));
			taskTypeNFile.setRunAtSource(Boolean.TRUE);
			taskTypeNFile.setHaltProcessWhenOraError(Boolean.TRUE);
			taskTypeNFile.setAlwaysWriteOutputFile(Boolean.TRUE);
			taskTypeNFile.setSendMail(Boolean.TRUE);
			taskTypeNFile.setEventIdForMail(fixedParam.getWHParam(WareHouseParams.WH_ENGINE_EXEC_EVENT));
			ls.add(taskTypeNFile);
		}

		return ls;

	}

	public boolean isWriteOutputFile() {
		return false;
	}

}
