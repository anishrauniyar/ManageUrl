package dashboard.engine.oracle.scrubbing;

import java.io.File;
import java.util.List;
import java.util.Map;

import dashboard.data.Schema;
import dashboard.data.ScrubbingTask;
import dashboard.data.TaskTypeNFile;
import dashboard.db.OracleDBConnector;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.engine.oracle.BaseSQLPlusRunnable;
import dashboard.engine.oracle.NamingUtil;
import dashboard.util.FileUtil;

public class ScrubbingModifier extends BaseSQLPlusRunnable {

	@Override
	public void init() throws Exception {
		ls = generateScript();
		Schema schema = getSchema();
		sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(schema);
		desc = "[" + schema.getServerGroupName() + "] "
				+ schema.getServerName() + ":" + schema.getPort() + "/"
				+ schema.getService() + ":" + schema.getSchemaName();

	}

	private List generateScript() throws Exception {
		ls.clear();
		File clientSpecDir = env.getHP_VC_CLIENT_SPECIFIC_MODULES_DIR();
		NamingUtil namingUtil = new NamingUtil();
		if (scrubbingTask.isRunObjectScript()) {
			String script = engineConverter
					.getModifiedObjScriptForScrub(getSchema(),getCdfObjSQLScriptsForHP());
			File scriptFile = namingUtil.getObjectScriptFile(runnerSchema);
			FileUtil.writeToTextFile(script, scriptFile);

			TaskTypeNFile runObjScriptTask = new TaskTypeNFile(
					TaskType.EXECUTE_OBJECT_SCRIPT, scriptFile);
			runObjScriptTask.setHaltProcessWhenOraError(Boolean.TRUE);
			runObjScriptTask.setAlwaysWriteOutputFile(Boolean.TRUE);
			ls.add(runObjScriptTask);
		}
		if (scrubbingTask.isRunClientScript()) {
			String script = engineConverter.getModifiedScriptForScrub(getSchema(), clientSpecDir, getClientSpecificSQLScripts());
			File scriptFile = namingUtil
					.getClientSpecificScriptFile(runnerSchema);
			FileUtil.writeToTextFile(script, scriptFile);

			TaskTypeNFile runClientScriptTask = new TaskTypeNFile(
					TaskType.EXECUTE_CLIENT_SPEC_SCRIPT, scriptFile);
			runClientScriptTask.setHaltProcessWhenOraError(Boolean.TRUE);
			runClientScriptTask.setAlwaysWriteOutputFile(Boolean.TRUE);
			ls.add(runClientScriptTask);
		}
		return ls;
	}

	private TaskType taskType = null;

	@Override
	public TaskType getTaskType() {
		return taskType;
	}

	@Override
	public SQLPlusRunnable setTaskType(TaskType taskType) {
		if (null != taskType) {
			this.taskType = taskType;
		}
		return this;
	}

	private ScrubbingTask scrubbingTask = null;

	public ScrubbingModifier setScrubbingTask(ScrubbingTask scrubbingTask) {
		this.scrubbingTask = scrubbingTask;
		if (this.scrubbingTask != null) {
			if (scrubbingTask.isRunObjectScript())
				taskType = TaskType.EXECUTE_OBJECT_SCRIPT;
			if (scrubbingTask.isRunClientScript())
				taskType = TaskType.EXECUTE_CLIENT_SPEC_SCRIPT;
		}
		return this;
	}

	private String desc = "Execute Object Script: ";

	@Override
	public String getDescription() {
		if (taskType != null) {
			Schema schema = getSchema();
			desc = // taskType.toString() +
			" [" + schema.getServerGroupName() + "] " + schema.getServerName()
					+ ":" + schema.getPort() + "/" + schema.getService() + ":"
					+ schema.getSchemaName();
		}
		return desc;
	}

	@Override
	public List getTaskTypeNFileList() {
		return ls;
	}

	private String sqlPlusUrl = null;

	@Override
	public String getSQLPlusUrl() {
		return sqlPlusUrl;
	}

	Map<String, Boolean> clientSpecificSQLScripts = null;

	public Map<String, Boolean> getClientSpecificSQLScripts() {
		return clientSpecificSQLScripts;
	}

	public BaseSQLPlusRunnable setClientSpecificSQLScripts(
			Map<String, Boolean> clientSpecificSQLScripts) {
		this.clientSpecificSQLScripts = clientSpecificSQLScripts;
		return this;
	}

	Map<String, Boolean> cdfObjSQLScriptsForHP = null;

	public Map<String, Boolean> getCdfObjSQLScriptsForHP() {
		return cdfObjSQLScriptsForHP;
	}

	public ScrubbingModifier setCdfObjSQLScriptsForHP(
			Map<String, Boolean> cdfObjSQLScriptsForHP) {
		this.cdfObjSQLScriptsForHP = cdfObjSQLScriptsForHP;
		return this;
	}

	public boolean isWriteOutputFile() {
		return false;
	}

}
