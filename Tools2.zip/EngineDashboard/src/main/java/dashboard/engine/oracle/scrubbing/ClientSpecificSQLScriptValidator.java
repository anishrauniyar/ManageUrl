package dashboard.engine.oracle.scrubbing;

import dashboard.security.User;
import dashboard.validator.BaseValidator;

public class ClientSpecificSQLScriptValidator extends BaseValidator {

	public ClientSpecificSQLScriptValidator(User user) {
		super(user);
	}

	@Override
	public void validate() throws Exception {
		logger.info("Validating Client Specific Scripts for schema "
				+ getOrclSchema());
		validateScriptsExistence(CLIENT_SPECIFIC_SCRIPTS);
	}
}
