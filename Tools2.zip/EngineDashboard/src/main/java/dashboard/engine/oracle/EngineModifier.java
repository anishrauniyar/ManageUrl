package dashboard.engine.oracle;


import java.io.File;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.EngineReplacementData;
import dashboard.data.EngineTask;
import dashboard.data.ReplaceSchema;
import dashboard.data.Report;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.TaskTypeNFile;
import dashboard.db.EngineMonitorDB;
import dashboard.db.OracleDBConnector;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.FileUtil;


public class EngineModifier extends BaseSQLPlusRunnable {
    
    boolean runDQE = false;
    
    private String diffServer;
    private String dxcgParam;
    
    private EngineMonitor engine;

    protected Log logger = LogFactory.getLog(getClass());

    public EngineModifier() {
        super();
    }
    
    private String dxcgHostUrl = "";
    public EngineModifier setDxcgHostUrl(String p){
    	dxcgHostUrl = p;
    	return this;
    }
    
    private Report[] report = null;
    public EngineModifier setReportInfo(Report[] rp) {
        report = rp;
        return this;
    }
    

    private EngineTask engineTask = null;

    public EngineModifier setEngineTask(EngineTask t) {
        engineTask = t;
        if (engineTask != null) {
            //1st task type by default
        	if (engineTask.isRunIndex()) taskType = TaskType.INDEXING;
        	if (engineTask.isRunFQCReport()) taskType = TaskType.FQC_REPORT;
        	if (engineTask.isRunDXCGRecordCount()) taskType = TaskType.DXCG_RECORD_COUNT;
            if (engineTask.isExecuteEngine()) taskType = TaskType.EXECUTE_ENGINE;
            if (engineTask.isCompileEngine()) taskType = TaskType.COMPILE_ENGINE_SCRIPT;
            if (engineTask.isRunObjectScript()) taskType = TaskType.EXECUTE_OBJECT_SCRIPT;
            if (engineTask.isRunReport()) taskType = TaskType.PROCESS_SCRIPT_OR_REPORT;
        }

        return this;
    }

    protected TaskType taskType = null;
    public SQLPlusRunnable setTaskType( TaskType tskType) {
        if (null != tskType) {
            taskType = tskType;
        }
        return this;
    }
    public TaskType getTaskType() {
        return taskType;
    }



    public EngineModifier setRunDQE(boolean rundqe) {
        runDQE = rundqe;
        return this;
    }
    public boolean isRunDQE() { return runDQE; }
  
    private List generateScript()
        throws Exception {
        ls.clear();
        Schema runnerSchema = getSchema();
        EngineReplacementData replData = NamingUtil.replacementDataByFrontSchema( runnerSchema); 
        
        replData.setSchema(this.getHistSchema());
        replData.setDiffServer(this.getDiffServer());
        replData.setDxcgParam(this.getDxcgParam());
        
        if(getReplaceSchema().isReplaceHawkeyeMaster()){
        	replData.setHawkeyeMaster(getReplaceSchema().getHawkeyeMaster());
        }
        if(getReplaceSchema().isReplaceHawkeyeQRM()){
        	replData.setHawkeyeQRM(getReplaceSchema().getHawkeyeQRM());
        }  
        
        NamingUtil namingUtil = new NamingUtil();
        if (engineTask.isRunObjectScript()) {
            String script = engineConverter.getModifiedObjectScript(replData,getSchema().getEngineVersion(),getSchema());
            File scriptFile = namingUtil.getObjectScriptFile(runnerSchema);
            FileUtil.writeToTextFile(script, scriptFile);
            ls.add( new TaskTypeNFile(TaskType.EXECUTE_OBJECT_SCRIPT, scriptFile));
        }

        if (engineTask.isCompileEngine()) {
            String script = engineConverter.getModifiedEngineScript(replData, getSchema());
            File scriptFile = (new NamingUtil()).getEngineScriptFile(runnerSchema);
            FileUtil.writeToTextFile(script, scriptFile);
            ls.add( new TaskTypeNFile(TaskType.COMPILE_ENGINE_SCRIPT, scriptFile));

        }
        
        if (engineTask.isExecuteEngine()) {
            String script = engineConverter.getRunEngineScript(replData, runDQE, threadCount, parallel, getSchema());//parallel: Added by binshakya
            File scriptFile = (new NamingUtil()).getRunEngineScriptFile(runnerSchema);
            FileUtil.writeToTextFile(script, scriptFile);
            ls.add(new TaskTypeNFile(TaskType.EXECUTE_ENGINE, scriptFile));
        }
        
        if(engineTask.isRunDXCGRecordCount()){
        	SQLPlusRunnable dxcgReportCountModifier = (new DXCGRecordCountModifier()).setSchema(this.getSchema());
        	dxcgReportCountModifier.init();
        	setStagingSQLPlusUrl(dxcgReportCountModifier.getStagingSQLPlusUrl());
        	ls.addAll(dxcgReportCountModifier.getTaskTypeNFileList());
        }
        
        if (engineTask.isRunFQCReport()) {
        	SQLPlusRunnable fqcReportModifier = (new FQCReportModifier()).setSchema(this.getSchema());
        	fqcReportModifier.init();
        	setSqlPlusUrlForFQC(fqcReportModifier.getSQLPlusUrlForFQC());// setting sqlplus URL for FQC
        	ls.addAll(fqcReportModifier.getTaskTypeNFileList());
        }
        
        if(engineTask.isRunReport()){  		        	
	        SQLPlusRunnable reportModifier = (new ReportModifier()) 
	        	.setDxcgHostUrl(dxcgHostUrl)
	            .setReportModules(reportNames)
	            .setReportInfo(report)
	            .setDxcgParam(getDxcgParam())
	            .setReplaceSchema(this.replSchema)
	            .setEngineMonitorDB( engineMonitorDB)
	            .setSchema(this.getSchema())
	            .setUser(this.getUser());        
	        reportModifier.init();  
	        ls.addAll(reportModifier.getTaskTypeNFileList());
        }
        //here index is to be runned at last
        if(engineTask.isRunIndex()){
        	SQLPlusRunnable indexModifier=(new IndexModifier())
            .setEngineMonitorDB(engineMonitorDB)
            .setSchema(this.getSchema())
            .setThreadCount(this.getThreadCount());
        	indexModifier.init();
        	List indexLS=indexModifier.getTaskTypeNFileList();
        	ls.addAll(indexLS);
        }
        
        return ls;
    }

    public void init() throws Exception {
        ls = generateScript();
        Schema frontSchema = getSchema();
        sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(frontSchema);
        desc = "[" + frontSchema.getServerGroupName() + "] " +
            frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
            frontSchema.getService() + ":" + frontSchema.getSchemaName() ;
    }

    private String desc = "Execute Engine: ";
    public String getDescription() {
        if ( null != taskType ) {
            Schema frontSchema = getSchema();

            desc = //taskType.toString() +
                " [" + frontSchema.getServerGroupName() + "] " +
                frontSchema.getServerName() + ":" + frontSchema.getPort() + "/" +
                frontSchema.getService() + ":" + frontSchema.getSchemaName() ;
            /**
             * VITTOOLS-378: Showing parallel for EXECUTE_ENGINE
             */
            if(taskType.equals(TaskType.EXECUTE_ENGINE) && parallel!=null){
            	desc +=" [Parallel:"+parallel+"]";
            }
        }
        return desc;
    }

    public List getTaskTypeNFileList() {
        return ls;
    }

    private String sqlPlusUrl = null;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }
    
    private String sqlPlusUrlForFQC = null;
    public String getSQLPlusUrlForFQC() {
		return sqlPlusUrlForFQC;
	}
	public void setSqlPlusUrlForFQC(String sqlPlusUrlForFQC) {
		this.sqlPlusUrlForFQC = sqlPlusUrlForFQC;
	}
	
	private String stagingSQLPlusUrl = null;
    public String getStagingSQLPlusUrl() {
		return stagingSQLPlusUrl;
	}
	public void setStagingSQLPlusUrl(String stagingSQLPlusUrl) {
		this.stagingSQLPlusUrl = stagingSQLPlusUrl;
	}
	
	public List getStatusList() throws Exception {    	
        if (TaskType.EXECUTE_ENGINE.equals(taskType)||TaskType.INDEXING.equals(taskType) 
        		|| taskType.getID().indexOf(TaskType.PROCESS_SCRIPT_OR_REPORT.getID()) !=-1) {
            return getStatusListCache();
        }
        return getEmptyList();
    }
    
    private volatile long lastIndexUpdate = -1;
    public RunningStatus getRunningStatus() throws Exception {
        if (TaskType.EXECUTE_ENGINE.equals(taskType) 
        		|| taskType.getID().indexOf(TaskType.PROCESS_SCRIPT_OR_REPORT.getID()) !=-1) {
            return getRunningStatusCache();
        }

    	if(TaskType.INDEXING.equals(taskType)){
			long currentTime = System.currentTimeMillis();
	        if ( currentTime - lastIndexUpdate < CACHE_TIME && lastIndexUpdate > - 1) {
	            return objectStatus;
	        } else {
	            lastIndexUpdate = currentTime;
	            int indexCount = ComponentFactory.getInstance().getEngineMonitorForSystem()
	                .getIndexCount( getRunnerSchema());
	            objectStatus.setCompletedModules(indexCount);
	        }
	        return objectStatus;
        }
       	
        return super.getRunningStatus();
    }


    public List getBeforeInvalidProcList() throws Exception {
        if ( TaskType.EXECUTE_ENGINE.equals(taskType)) {
            return invalidProcList();
        }
        return lsEmpty;
    }

    public List getAfterInvalidProcList() throws Exception {
    	if(TaskType.INDEXING.equals(taskType)){
	    	List ls=lsEmpty;
	    	List newList=new LinkedList();
	    	for(int i=0;i<this.getTaskTypeNFileList().size();i++){
	    		/**
	    		 * VITTOOLS-363: FQC exception seen in INDEXING Event
	    		 */
	    		if(!TaskType.FQC_REPORT.equals(((dashboard.data.TaskTypeNFile)this.getTaskTypeNFileList().get(i)).getTaskType())){
	    			if(((dashboard.data.TaskTypeNFile)this.getTaskTypeNFileList().get(i)).isFailure()){
	    	    		newList.add(((dashboard.data.TaskTypeNFile)this.getTaskTypeNFileList().get(i)).getScriptFile().getAbsolutePath());
	    	    		ls=newList;
	    			}
	    		}
	    	}
	    	return ls;
    	}
        if (TaskType.COMPILE_ENGINE_SCRIPT.equals(taskType)) {
            return invalidProcList();
        }
        return lsEmpty;
    }
    
    private List invalidProcList() throws Exception {
        return compFactory.getEngineMonitorForSystem().getInvalidProcList( getSchema());
    }

    public boolean isAllowKill() {
        return true;
    }
    public void kill() throws Exception {
        if (TaskType.EXECUTE_ENGINE.equals(taskType)) {
            engineMonitorDB.kill(getSchema());
        }
    }
    
    protected EngineMonitorDB engineMonitorDB = null;
    public EngineModifier setEngineMonitorDB( EngineMonitorDB engMDB) {
        engineMonitorDB = engMDB;
        return this;
    }
    protected EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }
    
    protected ReplaceSchema replSchema;
	    public EngineModifier setReplaceSchema(ReplaceSchema replSchema){
		this.replSchema = replSchema;
		return this ;
    }
    public ReplaceSchema getReplaceSchema(){
    	return replSchema ;
    }  
    
    protected Schema schema;
	    public EngineModifier setHistSchema(Schema Schema){
		this.schema = Schema;
		return this ;
    }
    
    public Schema getHistSchema(){
    	return schema ;
    }
        
    private String[] reportNames;
	public String[] getReportNames() {
		return reportNames;
	}
	public EngineModifier setReportNames(String[] reportNames) {
		this.reportNames = reportNames;
		return this;
	}
    
	public String getDiffServer() {
		return diffServer;
	}
	public EngineModifier setDiffServer(String p) {
		diffServer = (p!=null)? p.trim().toUpperCase(): "";
	    return this;
	}
	public String getDxcgParam() {
		return dxcgParam;
	}
	public EngineModifier setDxcgParam(String p) {
		dxcgParam = (p!=null)? p.trim().toUpperCase(): "";
	    return this;
	}
	public EngineMonitor getEngine() {
		return engine;
	}
	public EngineModifier setEngine(EngineMonitor engine) {
		this.engine = engine;
	    return this;
	}
	
	public List<String> getDxCGOutput(){
		return engineMonitorDB.callDxCGReport(getSchema());
	}
	
	public boolean isWriteOutputFile() {
		/**isWriteOutputFile set to false for FQC_REPORT as
		   alwaysWriteOutputFile is set to true
		**/
		if(TaskType.FQC_REPORT.equals(taskType)){
			return false;
		}
		return true;
	}
}