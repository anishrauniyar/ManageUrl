package dashboard.engine.oracle;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.db.DBUtil;
import dashboard.db.OracleDBConnector;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CustomProcedureExecutor {

    private final ComponentFactory compFactory;
    private final EngineMonitor engine;
    private final EventLogger eventLogger;
    private final Log logger = LogFactory.getLog(getClass());
    private static final String DROP_TBL_SPACE = "Drop Table Space";
    private static final String DROP_TBL_SPACE_PROCEDURE = "{call utility.sp_drptblspace_beforexfer(?)}";
//    private static final String DROP_TBL_SPACE_PROCEDURE = "{call utility.procOneINParameter(?)}";
    private final String username;
    private String task;
    private String desc;
    private final int threadCount = 0;

    public CustomProcedureExecutor(String username) {
        this.username = username;
        compFactory = ComponentFactory.getInstance();
        engine = compFactory.getEngineMonitorForSystem();
        eventLogger = compFactory.getEventLogger();
    }

    /**
     * Executes Drop TableSpace Procedure by connecting utility schema of given
     * schema
     *
     * @param schema
     */
    public void executeDropTblSpace(Schema schema) {
        logger.info("Inside executeDropTblSpace for schema:" + schema);
        Server utilServer;
        Schema utilSchema;
        Connection cnn = null;
        CallableStatement cStmt = null;
        Date startDate = new Date(System.currentTimeMillis());
        try {
            task = DROP_TBL_SPACE;
            desc = "Drop Table Space:"
                    + schema.getServerName() + ":" + schema.getPort() + "/"
                    + schema.getService() + ":" + schema.getSchemaName();
            //eventLogger.logStart(username, task, desc, threadCount, startDate, schema, Long.MIN_VALUE);
            utilServer = engine.getServer(schema);
            utilSchema = new Schema().setServerName(schema.getServerName())
                    .setPort(schema.getPort())
                    .setService(schema.getService())
                    .setSidFlag(schema.getSidFlag())
                    .setSchemaName(utilServer.getUTILITY_USER())
                    .setSchemaPwd(utilServer.getUTILITY_PASS());
            logger.info("Util Schema to executeDropTblSpace:" + schema + "{user:" + utilSchema.getSchemaName() + "}");
            // connecting utilSchema
            cnn = (new OracleDBConnector()).getConnectionForSchema(utilSchema);
            cStmt = cnn.prepareCall(DROP_TBL_SPACE_PROCEDURE);
            cStmt.setString(1, schema.getSchemaName().toUpperCase());
            cStmt.executeUpdate();
            logger.info("DropTblSpace procedure executed successfully!!!!!! in schema:" + schema);
            //eventLogger.logEnd(username, task, desc, threadCount, startDate, new Date(System.currentTimeMillis()), threadCount, schema);
        } catch (Exception e) {
            logger.error("Error executing dropTblSpace procedure for :" + schema + ":" + e);
            //eventLogger.logError(username, task, desc, threadCount, startDate, new Date(System.currentTimeMillis()), e, schema);
        } finally {
            DBUtil.release(cnn, cStmt, null);
        }
    }
}
