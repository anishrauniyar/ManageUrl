package dashboard.engine.oracle;


import java.io.File;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import dashboard.ComponentFactory;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.db.EngineMonitorDB;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineConverter;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.SQLProcessStatus;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;


public abstract class BaseSQLPlusRunnable implements SQLPlusRunnable {
    protected static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));

    
    protected ComponentFactory compFactory;
    protected EnvInfo env;
    protected FixedParameter fixedParam;
    protected List ls;
    protected EngineConverter engineConverter;
    protected EngineMonitorDB engineMonitorDB;
    protected String EMPTY_STRING = "";

    protected BaseSQLPlusRunnable() {
        compFactory = ComponentFactory.getInstance();
        env = compFactory.getEnvInfo();
        fixedParam = compFactory.getFixedParameters();
        ls = new LinkedList();
        engineConverter = compFactory.getEngineConverter();
        engineMonitorDB = compFactory.getEngineMonitorDB();
    }

    protected List getEmptyList() {
        return lsEmpty;
    }

    protected SQLProcessStatus status = SQLProcessStatus.INIT;
    public void setStatus(SQLProcessStatus st) {
        status = st;
    }

    public List getStatusList() throws Exception {
        return lsEmpty;
    }
    protected Schema srcSchema = null;
    
    public BaseSQLPlusRunnable setSrcSchema(Schema srcSchema) {
        this.srcSchema = srcSchema;
        return this;
    }

    public Schema getSrcSchema() {
        if(this.srcSchema == null){
        	return new Schema();
        }
    	return srcSchema;
    }
    
    protected Schema runnerSchema = null;

    public SQLPlusRunnable setSchema(Schema runS) {
        runnerSchema = runS;
        return this;
    }

    public Schema getSchema() {
        return runnerSchema;
    }
    
    protected Schema dmExpressSchema = null;
    
    public Schema getDmExpressSchema() {
		return dmExpressSchema;
	}

	public BaseSQLPlusRunnable setDmExpressSchema(Schema dmExpressSchema) {
		this.dmExpressSchema = dmExpressSchema;
		return this;
	}
	
	//for vertica schema 
	protected boolean createVerticaSchema = false;
	
	public boolean isCreateVerticaSchema() {
		return createVerticaSchema;
	}

	public BaseSQLPlusRunnable setCreateVerticaSchema(boolean createVerticaSchema) {
		this.createVerticaSchema = createVerticaSchema;
		return this;
	}
	
	 //vertica schema params
    protected List<String> verticaSchemaParams;
     
    public List<String> getVerticaSchemaParams() {
		return verticaSchemaParams;
	}

	public BaseSQLPlusRunnable setVerticaSchemaParams(List<String> verticaSchemaParams) {
		this.verticaSchemaParams = verticaSchemaParams;
		return this;
	}
	
	protected Long executionId =(long) 0 ;

	public Long getExecutionId() {
		return executionId;
	}

	public BaseSQLPlusRunnable setExecutionId(Long executionId) {
		this.executionId = executionId;
		return this;
	}
	
	/*
	 * TO HIDE PASSWORDS 
	 * FOR VERTICA DATA TRANSFER
	 * */
	public String hidePasswordsForVertica(String input,String hostingServer){
		//System.out.println("Runner Password from BaseSQLPlusRunnable:hidePasswordForVertica is >>>>>>>>>>>>>>>>>>>>"+runnerPassword);
		/**
		**If hostingServer is VERTICA then processing@fixedparameters table is used
		**If hostingServer is VERTICA_CMA then processing@fixedparameters_cma table is used
		**Default is VERTICA_CMA if hostingServer is null or blank
		**/
		hostingServer = ((hostingServer ==null) || (hostingServer == ""))?Constants.VERTICA_CMA:hostingServer;
		//source oracle server password[For vertica Data transfer]
        String OS_Pwd = fixedParam.getValue(Constants.OS_PASSWORD,hostingServer);
        String VS_Pwd = fixedParam.getValue(Constants.VS_PASSWORD,hostingServer);
        String VS_AdminPwd = fixedParam.getValue(Constants.VS_ADMINPWD,hostingServer);
        //String VS_NewPwd = "vertica";
        String CS_Pwd = fixedParam.getValue(Constants.CS_PASSWORD,hostingServer);
		
		if(input.contains(OS_Pwd)){
        	input = input.replace(OS_Pwd, generateHiddenChar(OS_Pwd.length()));
        }
        //vertica server password[For vertica schema creation]
        if(input.contains(VS_Pwd)){
        	input = input.replace(VS_Pwd, generateHiddenChar(VS_Pwd.length()));
        }
        //vertica db server admin password[For vertica schema creation]
        if(input.contains(VS_AdminPwd)){
        	input = input.replace(VS_AdminPwd, generateHiddenChar(VS_AdminPwd.length()));
        }
        //new vertica schema password[For vertica schema creation]
       /* if(input.contains(VS_NewPwd)){
        	input = input.replace(VS_NewPwd, generateHiddenChar(VS_NewPwd.length()));
        }*/
       
        if(hostingServer.equalsIgnoreCase(Constants.VERTICA)){
        	String DME_Pwd = fixedParam.getValue(Constants.DME_PASSWORD,hostingServer);
            //dmexpress server password
            if(input.contains(DME_Pwd)){
            	input = input.replace(DME_Pwd, generateHiddenChar(DME_Pwd.length()));
            }
        }
        
        //central schema password
        if(input.contains(CS_Pwd)){
        	input = input.replace(CS_Pwd, generateHiddenChar(CS_Pwd.length()));
        }
        if((runnerPassword!=null) && (runnerPassword!="") && (input.contains(runnerPassword))){
        	input = input.replace(runnerPassword, generateHiddenChar(runnerPassword.length()));
        }
        
		return input;
	}
	
	//generates * char of given length 
	public  String generateHiddenChar(int length){
		StringBuffer sb= new StringBuffer("*");
		
		for(int i=1;i<length;i++){
			sb.append("*");
		}
		
		return sb.toString();
	}
	
	//for BA_MOdule Transfer
	private String dataFileDirectoy = "";
	
	public String getDataFileDirectoy() {
		return dataFileDirectoy;
	}

	public BaseSQLPlusRunnable setDataFileDirectoy(String dataFileDirectoy) {
		this.dataFileDirectoy = dataFileDirectoy;
		return this;
	}

	private String runnerUserName = null;
    private String runnerPassword = null;

    public void setRunnerUserName(String rnUser) {
        if ( null != rnUser) {
            runnerUserName = rnUser.trim();
        }
    }
    public String getRunnerUserName() {
        if (null != runnerUserName)
            return runnerUserName;
        return runnerSchema.getSchemaName();
    }
    public void setRunnerPassword(String rnPass) {
        if ( null != rnPass) {
            runnerPassword = rnPass.trim();
        }
    }
    public String getRunnerPassword() {
        if (null != runnerPassword)
            return runnerPassword;
        return runnerSchema.getSchemaPwd();
    }
    

    public Schema getRunnerSchema() {
        Schema rnSchema = runnerSchema.getCopy();
        if ( null != runnerUserName ) {
            rnSchema = rnSchema.setSchemaName( runnerUserName);
        }
        if (null != runnerPassword) {
            rnSchema = rnSchema.setSchemaPwd( runnerPassword);
        }
        return rnSchema;
    }



    protected int threadCount = 1;
    public SQLPlusRunnable setThreadCount(int tc) {
        if (tc > 0) {
            threadCount = tc;
        }
        return this;
    }
    public int getThreadCount() {
        return threadCount;
    }
    
    protected String parallel;
    public String getParallel() {
		return parallel;
	}
	public SQLPlusRunnable setParallel(String p) {
		if(p!=null){
			this.parallel = p;
		}
		return this;
	}

	private volatile List statusList = lsEmpty;
    volatile long listLastUpdate = -1;
    protected static final long CACHE_TIME = 3000; //3sec.
    protected List getStatusListCache() throws Exception {

        if (SQLProcessStatus.RUNNING.equals(status)) {
            long currentTime = System.currentTimeMillis();
            if ( currentTime - listLastUpdate < CACHE_TIME && listLastUpdate > -1) {
                //System.out.println("CACHE-HIT");
                return statusList;
            } else {
                listLastUpdate = currentTime;
                try {
                List ls =
                    ComponentFactory.getInstance().getEngineMonitorForSystem().getStatusList( getSchema());
                statusList = ls;
                } catch (Exception  ex) {
                    statusList = lsEmpty;
                    throw ex;
                }
            }
            return statusList;
        } else {
            return lsEmpty;
        }

    }


    protected volatile RunningStatus runningStatus = new RunningStatus();
    public RunningStatus getRunningStatus() throws Exception {
        return runningStatus;
    }
    
    public List<VHTransferLog> getMiniEngineOutputTransferLog() throws Exception{
    	return lsEmpty;
    }

    volatile long lastRSUpdate = -1;
    protected RunningStatus getRunningStatusCache() throws Exception {

        if (SQLProcessStatus.RUNNING.equals(status)) {
            long currentTime = System.currentTimeMillis();
            if ( currentTime - lastRSUpdate < CACHE_TIME && lastRSUpdate > - 1) {
                //System.out.println("RS cache hit.");
                return runningStatus;
            } else {
                lastRSUpdate = currentTime;
                RunningStatus rnStatus = 
                ComponentFactory.getInstance().getEngineMonitorForSystem().getRunningStatusEngine( getSchema());
                runningStatus = rnStatus;
            }
        }
        return runningStatus;
    }
    
    protected RunningStatus getRunningStatusCacheForMiniEngine() throws Exception {

        if (SQLProcessStatus.RUNNING.equals(status)) {
            long currentTime = System.currentTimeMillis();
            if ( currentTime - lastRSUpdate < CACHE_TIME && lastRSUpdate > - 1) {
                //System.out.println("RS cache hit.");
                return runningStatus;
            } else {
                lastRSUpdate = currentTime;
                RunningStatus rnStatus = 
                ComponentFactory.getInstance().getEngineMonitorForSystem().getRunningStatusMiniEngine( getSchema());
                runningStatus = rnStatus;
            }
        }
        return runningStatus;
    }
    
    public List getBeforeInvalidProcList()  throws Exception {
        return lsEmpty;
    }
    public List getAfterInvalidProcList()  throws Exception {
        return lsEmpty;
    }

    public List getDxCGOutput(){
    	return engineMonitorDB.callDxCGReport(getSchema());
    }
    public boolean isAllowKill() {
        return false;
    }

    public void kill( ) throws Exception {
        throw new UnsupportedOperationException("Kill operation not supported.");
    }
    volatile long lastObjectCountUpdate = -1;
    protected volatile RunningStatus objectStatus = new RunningStatus();

    private static final long ALL_OBJECT_CACHE_TIME = CACHE_TIME; 
    
    public RunningStatus getAllObjectStatus() throws Exception {
            long currentTime = System.currentTimeMillis();
            if ( currentTime - lastObjectCountUpdate < ALL_OBJECT_CACHE_TIME && lastObjectCountUpdate > - 1) {
                return objectStatus;
            } else {
                lastObjectCountUpdate = currentTime;
                RunningStatus rnStatus = 
                compFactory.getEngineMonitorForSystem().getAllObjectStatus( getSchema());
                objectStatus = rnStatus;
            }
        return objectStatus;
    }
    public String getSrcSQLPlusUrl(){
    	return this.getSQLPlusUrl();
    }
    public void setSubTaskType(String subTaskType) {    	
    }
    public String getSubTaskType() { return ""; }
    
    public File getScriptFile(){
		return (new NamingUtil()).getImportDataScriptFile(getSchema());
	}
    
    public boolean isWriteOutputFile(){
    	return true;
    }

    protected User user =  null;
	public User getUser() {
		return user;
	}
	public SQLPlusRunnable setUser(User user) {
		this.user = user;
		return this;
	}
	public String getSQLPlusUrlForFQC(){
		return EMPTY_STRING;
	}
	public String getStagingSQLPlusUrl(){
		return EMPTY_STRING;
	}
	
	/**
	 * VITTOOLS-380
	 * 
	 * @Description: Try's to get remote link of server from processing.servers
	 *               table If not found calls method getModifiedLinkServer
	 * 
	 * @param schema
	 * @return dbLink for the server
	 */
	protected String getDbLink(Schema schema) {
		String dbLink;
		try {
			dbLink = compFactory.getEngineMonitorForSystem().getDBLink(schema);
			/*logger.info("[FROM PROCESSING.SERVERS TABLE] Remote Link[Dblink] for schema/server "
					+ schema + " is " + dbLink);*/
		} catch (Exception e) {
			/*logger.error("Error getting remote link[dblink] for schema "
					+ schema);*/
			dbLink = getModifiedLinkServer(schema.getServerName());
			/*logger.info("[MODIFIED LINK] Remote Link[Dblink] for schema/server "
					+ schema + " is " + dbLink);*/
		}
		return dbLink;
	}

	/**
	 * @param serverName
	 *            : Link Server Name
	 * @return: Modified link server [Removes .d2hawkeye.net {case
	 *          insensitive[?i]}]
	 */
	private String getModifiedLinkServer(String serverName) {
		return serverName.replaceAll("(?i).D2hawkeye.net", EMPTY_STRING);
	}

	public static void main(String[] args) {
		String test1 = "test1.d2hawkeye.net";
		String test2 = "TEST2.D2HAWKEYE.NET";
		String test3 = "TEST3.D2HAWKE33YE.NET";
		System.out.println(test1.replaceAll("(?i).D2hawkeye.net", ""));
		System.out.println(test2.replaceAll("(?i).D2hawkeye.net", ""));
		System.out.println(test3.replaceAll("(?i).D2hawkeye.net", ""));
	}
}
