package dashboard.engine.oracle;

import java.io.File;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Chart;
import dashboard.data.ClusterGroup;
import dashboard.data.DataFileDir;
import dashboard.data.DataScripts;
import dashboard.data.DataTask;
import dashboard.data.EngineTask;
import dashboard.data.MREPreCheck;
import dashboard.data.OracleSystemData;
import dashboard.data.ReplaceSchema;
import dashboard.data.Report;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.ScrubbingTask;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.data.SourceControlUser;
import dashboard.data.TempTablespace;
import dashboard.data.WareHouseTask;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.db.EngineMonitorDB;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.AsyncSQLProcessRegistry;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.SourceControl;
import dashboard.engine.TaskKey;
import dashboard.engine.oracle.scrubbing.ScrubbingModifier;
import dashboard.security.RoleSet;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.util.ErrorOnQuote;
import dashboard.util.WareHouseParams;
import dashboard.web.pagecontroller.dr.AutoDRTransferController;
import dashboard.web.util.CustomException;
import dashboard.web.util.VerticaException;

public class EngineMonitorOrcl implements EngineMonitor {

    protected Log logger = LogFactory.getLog(getClass());

    private String currentUser = "<SYSTEM>";

    public EngineMonitorOrcl setCurrentUser(String p) {
        if (null != p) {
            currentUser = p.trim();
        }
        return this;
    }

    private void logInfo(String msg) {
        logger.info(currentUser + "->" + msg);
    }

    private void logInfo(int status, String msg) {
        logger.info(currentUser + "->STATUS[" + status + "]->" + msg);
    }

    EngineMonitorDB engineMonitorDB;

    public EngineMonitorOrcl setEngineMonitorDB(EngineMonitorDB monEnDB) {
        engineMonitorDB = monEnDB;
        return this;
    }

    public User getUser(String userId, String pwd) throws Exception {
        return engineMonitorDB.getUser(userId, pwd);
    }

    public User getUserForLDAPUser(String actDirName) throws Exception {
        return engineMonitorDB.getUserForLDAPUser(actDirName);
    }

    public User getUserWithoutPwd(String loginName) throws SQLException {
        return engineMonitorDB.getUserWithoutPwd(loginName);
    }

    public RoleSet getUsersRoles(String userId) throws Exception {
        return engineMonitorDB.getUsersRoles(userId);
    }

    public Object[] isValidLogin(String loginName, String pwd) throws Exception {
        return engineMonitorDB.isValidLogin(loginName, pwd);
    }

    public Object[] isValidSSOLogin(String loginName) throws SQLException {
        return engineMonitorDB.isValidSSOLogin(loginName);
    }

    public List getStatusList(Schema schema) throws Exception {
        return engineMonitorDB.getStatusList(schema);
    }

    public List getDataTransferStatusList(String uniqueJobId) throws Exception {
        return engineMonitorDB.getDataTransferStatusList(uniqueJobId);
    }

    public RunningStatus getRunningStatusDataTransfer(String uniqueJobId) {
        return engineMonitorDB.getRunningStatusDataTransfer(uniqueJobId);
    }

    public RunningStatus getRunningStatusEngine(Schema schema) throws Exception {
        return engineMonitorDB.getRunningStatus(schema);
    }

    public RunningStatus getRunningStatusMiniEngine(Schema VCSchema)
            throws Exception {
        return engineMonitorDB.getRunningStatusMiniEngine(VCSchema);
    }

    public List<VHTransferLog> getMiniEngineOutputTransferLog(Schema destSchema) {
        return engineMonitorDB.getMiniEngineOutputTransferLog(destSchema);
    }

    public RunningStatus getAllObjectStatus(Schema schema) throws Exception {
        return engineMonitorDB.getAllObjectStatus(schema);
    }

    public Object[] isValid(Schema schema) throws Exception {
        return engineMonitorDB.isValid(schema);
    }

    public Object[] isHostReachable(String host) throws Exception {
        return engineMonitorDB.isHostReachable(host);
    }

    /*----------------------------------------------------------------------*/
 /* SHOW TABLE */
 /*----------------------------------------------------------------------*/
    public Object[] getTableAsFieldNamesNRowList(Schema schema, String tableName)
            throws Exception {
        return engineMonitorDB.getTableAsFieldNamesNRowList(schema, tableName);
    }

    public int getRowCountFromTable(Schema schema, String tableName) {
        return engineMonitorDB.getRowCountFromTable(schema, tableName);
    }

    /*----------------------------------------------------------------------*/
 /* SERVER GROUP MGMT */
 /*----------------------------------------------------------------------*/
    public List getServerGroupList() throws Exception {
        return engineMonitorDB.getServerGroupList();
    }

    public List getServerGroupList(String hostingServer) throws Exception {
        return engineMonitorDB.getServerGroupList(hostingServer);
    }

    public List getVerticaRACServerGroupList() throws Exception {
        return engineMonitorDB.getVerticaRACServerGroupList();
    }

    public List getVerticaDRServerGroupList() throws Exception {
        return engineMonitorDB.getVerticaDRServerGroupList();
    }

    public List getServerGroupListForProcessing() throws Exception {
        return engineMonitorDB.getServerGroupListForProcessing();
    }

    public List getServerGroupListForOracleDR() throws Exception {
        return engineMonitorDB.getServerGroupListForOracleDR();
    }

    public List getHistServerGroupListForProcessing() throws Exception {
        return engineMonitorDB.getHistServerGroupListForProcessing();
    }

    public List<ServerGroup> getServerGrpsByCategory(List<String> categoryList)
            throws Exception {
        return engineMonitorDB.getServerGrpsByCategory(categoryList);
    }

    public int addServerGroup(String serverGroup, String serverType,
            String hostingServer) throws Exception {
        int retVal = engineMonitorDB.addServerGroup(serverGroup, serverType,
                hostingServer);
        logInfo(retVal, "addServerGroup: " + serverGroup);
        return retVal;
    }

    public int deleteServerGroup(String serverGroupId) throws Exception {
        int retVal = engineMonitorDB.deleteServerGroup(serverGroupId);
        logInfo(retVal, "deleteServerGroup: " + serverGroupId);
        return retVal;
    }

    public ServerGroup getServerGroup(String sa_serverGroupId) throws Exception {
        return engineMonitorDB.getServerGroup(sa_serverGroupId);
    }

    public Server getServer(Schema schema) throws Exception {
        return engineMonitorDB.getServer(schema);
    }

    public List getServersForServerGroup(String serverGroupId) throws Exception {
        return engineMonitorDB.getServersForServerGroup(serverGroupId);
    }

    public List getVIPServersForServerGrp(String serverGrpId) throws Exception {
        return engineMonitorDB.getVIPServersForServerGrp(serverGrpId);
    }

    public List getServersForHistServerGroup(String serverGroupId)
            throws Exception {
        return engineMonitorDB.getServersForHistServerGroup(serverGroupId);
    }

    public int addServer(Server server) throws SQLException {
        int retVal = engineMonitorDB.addServer(server);
        logInfo(retVal, "addServer: " + server);
        return retVal;
    }

    public int editRemoteLinkofServer(Server server) throws Exception {
        int retVal = engineMonitorDB.editRemoteLinkofServer(server);
        logInfo(retVal, "editServer: " + server);
        return retVal;
    }

    public int deleteServer(Server server) throws Exception {
        int retVal = engineMonitorDB.deleteServer(server);
        logInfo(retVal, "deleteServer: " + server);
        return retVal;
    }

    public boolean hasValidServerGroup(Schema schema) throws Exception {
        return engineMonitorDB.hasValidServerGroup(schema);
    }

    public boolean isProcessingOracleServer(String serverGroupId)
            throws Exception {
        return engineMonitorDB.isProcessingOracleServer(serverGroupId);
    }

    public List getDataFileDirsForServerGroup(String serverGroupId)
            throws Exception {
        return engineMonitorDB.getDataFileDirsForServerGroup(serverGroupId);
    }

    public int addDataFileDir(DataFileDir dataFileDir) throws Exception {
        int retVal = engineMonitorDB.addDataFileDir(dataFileDir);
        logInfo(retVal, "addDataFileDir: " + dataFileDir);
        return retVal;
    }

    public int deleteDataFileDir(DataFileDir dataFileDir) throws Exception {
        int status = engineMonitorDB.deleteDataFileDir(dataFileDir);
        logInfo(status, "deleteDataFileDir : " + dataFileDir);
        return status;
    }

    public List listAllGroupNServers(boolean showDmexpress) throws Exception {
        return engineMonitorDB.listAllGroupNServers(showDmexpress);
    }

    public List getTempTablespacesForServerGroup(String serverGroupId)
            throws Exception {
        return engineMonitorDB.getTempTablespacesForServerGroup(serverGroupId);
    }

    public int addTempTablespace(TempTablespace tempTablespace)
            throws Exception {
        int retVal = engineMonitorDB.addTempTablespace(tempTablespace);
        logInfo(retVal, "addTempTablespace: " + tempTablespace);
        return retVal;
    }

    public int deleteTempTablespace(TempTablespace tempTablespace)
            throws Exception {
        int retVal = engineMonitorDB.deleteTempTablespace(tempTablespace);
        logInfo(retVal, "deleteTempTablespace: " + tempTablespace);
        return retVal;
    }

    private static final String NO_SERVER_GROUP_ID = "Schema specified does not have ServerGroupId.";

    private void checkSchema(Schema s) throws Exception {
        _checkSchema(s);
        if (!engineMonitorDB.hasValidServerGroup(s)) {
            throw new IllegalArgumentException(NO_SERVER_GROUP_ID + s);
        }
        s = setServerGroupName(s);
    }

    private void _checkSchema(Schema s) {
        if (null == s) {
            return;
        }
        ErrorOnQuote.checkQuote(s.getServerGroupId());
        ErrorOnQuote.checkQuote(s.getServerName());
        ErrorOnQuote.checkQuote(s.getPort());
        ErrorOnQuote.checkQuote(s.getSchemaName());
        ErrorOnQuote.checkQuote(s.getSchemaPwd());
    }

    /*----------------------------------------------------------------------*/
 /* CREATING SCHEMA */
 /*----------------------------------------------------------------------*/
    public AsyncSQLProcess createSchema(Schema userSchema,
            String scriptRunnerName, String scriptRunnerPwd,
            String dataFileDir, String tempTablespace, boolean isHistSchema,
            String schemaCreationMode, String schemaType,
            boolean SP_GrantNewUserScriptExists) throws Exception {
        checkSchema(userSchema);
        ErrorOnQuote.checkQuote(scriptRunnerName);
        ErrorOnQuote.checkQuote(dataFileDir);
        ErrorOnQuote.checkQuote(tempTablespace);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        OracleUserCreator userCreator = (new OracleUserCreator())
                .setDataFileDir(dataFileDir).setTempTablespace(tempTablespace)
                .setHistSchema(isHistSchema).setSchemaType(schemaType)
                .setSchemaCreationMode(schemaCreationMode)
                .setSP_GrantNewUserScriptExists(SP_GrantNewUserScriptExists);

        userCreator.setSchema(userSchema);
        userCreator.setRunnerUserName(scriptRunnerName);
        userCreator.setRunnerPassword(scriptRunnerPwd);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(userSchema.getServerGroupId())
                .setSchemaName(userSchema.getSchemaName())
                .setUserName(currentUser), userCreator);
        logInfo("Create Oracle Schema: " + userSchema.getSchemaName());
        return sqlProcess;

    }

    public AsyncSQLProcess createVerticaSchema(Schema verticaSchema,
            String databaseName, String adminUserName, String adminPass,
            String newSchemaName, String newUserName, String newUserPassword)
            throws Exception {
        checkSchema(verticaSchema);

        List<String> verticaSchemaParams = new ArrayList<String>();
        verticaSchemaParams.add(databaseName);
        verticaSchemaParams.add(adminUserName);
        verticaSchemaParams.add(adminPass);
        verticaSchemaParams.add(newSchemaName);
        verticaSchemaParams.add(newUserName);
        verticaSchemaParams.add(newUserPassword);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        OracleUserCreator userCreator = (new OracleUserCreator());

        userCreator.setCreateVerticaSchema(true);
        userCreator.setSchema(verticaSchema);
        userCreator.setVerticaSchemaParams(verticaSchemaParams);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey())
                .setServerGroupId(verticaSchema.getServerGroupId())
                .setSchemaName(verticaSchema.getSchemaName())
                .setUserName(currentUser), userCreator);
        logInfo("Create Vertica Schema: " + verticaSchema.getSchemaName());
        return sqlProcess;
    }

    /*----------------------------------------------------------------------*/
 /* EXECUTING ENGINE */
 /*----------------------------------------------------------------------*/
    public File[] getOutputFiles(Schema schema) throws Exception {
        return (new NamingUtil()).getOutputFiles(schema);
    }

    public File getVerticaOutputFile(long execNo, String hostingServer)
            throws Exception {
        return (new NamingUtil()).getVerticaDataTransferScriptFile(execNo,
                hostingServer);
    }

    public AsyncSQLProcess executeEngine(Schema frontSchema,
            ReplaceSchema replSchema, boolean runDQE, int degOfParallelism,
            String parallel, EngineTask eTask, String[] reportNames,
            String[] reportModules, User user, String dxcgHostUrl,
            Schema histSchema, String isDiffServer, String dxcgParam,
            String dxcgProcessed) throws Exception {
        checkSchema(frontSchema);

        Report[] reportsArr = null;
        if (eTask.isRunReport() && reportNames != null) {
            reportsArr = new Report[reportNames.length];
            for (int i = 0; i < reportNames.length; i++) {
                reportsArr[i] = engineMonitorDB.getReportByName(reportNames[i]);
            }
        }

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable engineModifier = (new EngineModifier())
                .setHistSchema(histSchema).setDiffServer(isDiffServer)
                .setDxcgParam(dxcgParam).setDxcgHostUrl(dxcgHostUrl)
                .setEngineTask(eTask).setReportNames(reportModules)
                .setReportInfo(reportsArr).setEngineMonitorDB(engineMonitorDB)
                .setRunDQE(runDQE).setReplaceSchema(replSchema)
                .setSchema(frontSchema).setThreadCount(degOfParallelism)
                .setParallel(parallel).setUser(user);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey())
                .setServerGroupId(frontSchema.getServerGroupId())
                .setSchemaName(frontSchema.getSchemaName())
                .setDxCGProcessed(dxcgProcessed)
                .setUserName(currentUser), engineModifier);

        logInfo("Execute Engine : " + frontSchema);
        return sqlProcess;
    }

    public AsyncSQLProcess getAsyncSQLProcess(TaskKey key) {
        return ComponentFactory.getInstance().getAsyncSQLProcessRegistry()
                .getAsyncSQLProcess(key);
    }

    public AsyncSQLProcess executeMiniEngine(Schema VCSchema,
            ReplaceSchema replSchema, int degOfParallelism, String parallel,
            EngineTask eTask, User user, Schema histSchema, String isDiffServer)
            throws Exception {
        checkSchema(VCSchema);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable miniEngineModifier = (new MiniEngineModifier())
                .setHistSchema(histSchema).setDiffServer(isDiffServer)
                .setEngineTask(eTask).setEngineMonitorDB(engineMonitorDB)
                .setReplaceSchema(replSchema).setSchema(VCSchema)
                .setThreadCount(degOfParallelism).setParallel(parallel)
                .setUser(user);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(VCSchema.getServerGroupId())
                .setSchemaName(VCSchema.getSchemaName())
                .setDxCGProcessed(VCSchema.getDxCGProcess())
                .setAsyncControllerType("ASYNC_MINI_ENGINE_CONTROLLER")
                .setUserName(currentUser), miniEngineModifier);

        logInfo("Execute Mini Engine : " + VCSchema);
        return sqlProcess;
    }

    public AsyncSQLProcess executeScrubbing(Schema scrubSchema,
            ScrubbingTask scrubTask, Map<String, Boolean> cdfObjSQLScriptsForHP, Map<String, Boolean> clientSpecificSQLScripts)
            throws Exception {
        checkSchema(scrubSchema);
        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable scrubbingModifier = (new ScrubbingModifier())
                .setScrubbingTask(scrubTask)
                .setCdfObjSQLScriptsForHP(cdfObjSQLScriptsForHP)
                .setClientSpecificSQLScripts(clientSpecificSQLScripts)
                .setSchema(scrubSchema);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey())
                .setServerGroupId(scrubSchema.getServerGroupId())
                .setSchemaName(scrubSchema.getSchemaName())
                .setAsyncControllerType("COMMON_ASYNC_CONTROLLER")
                .setUserName(currentUser), scrubbingModifier);

        logInfo("Execute Scrubbing : " + scrubSchema);
        return sqlProcess;

    }

    public List getReportsByReportName(String engVersion, String reportName)
            throws Exception {
        String rptSourceDir = "";
        try {
            Report report = engineMonitorDB.getReportByName(reportName);
            rptSourceDir = report.getSourceDir() + "/" + engVersion;
        } catch (Exception ex) {
            System.out.println("Report Name Mitchmatch: EngineMonitorOrcl.java"
                    + "Check if ReportId" + reportName
                    + " exist in ReportConfig table.");
        }

        return ComponentFactory.getInstance().getEngineConverter()
                .getReportFileNameList(rptSourceDir);
    }

    /*----------------------------------------------------------------------*/
 /* EXECUTING REPORT */
 /*----------------------------------------------------------------------*/
    public AsyncSQLProcess executeReport(Schema frontSchema,
            ReplaceSchema replSchema, String[] reportNames, String[] reports,
            User user, String dxcgHostUrl, String dxcgParam, String dxcgProcess)
            throws Exception {
        checkSchema(frontSchema);
        // ErrorOnQuote.checkQuote( reportName);

        Report[] reportsArr = new Report[reportNames.length];
        for (int i = 0; i < reportNames.length; i++) {
            ErrorOnQuote.checkQuote(reportNames[i]);
            reportsArr[i] = engineMonitorDB.getReportByName(reportNames[i]);
        }

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable reportModifier = (new ReportModifier())
                .setDxcgHostUrl(dxcgHostUrl).setDxcgParam(dxcgParam)
                .setReportModules(reports).setReportInfo(reportsArr)
                .setEngineMonitorDB(engineMonitorDB)
                .setReplaceSchema(replSchema).setSchema(frontSchema)
                .setUser(user);

        AsyncSQLProcess sqlProcess = registry
                .register(
                        (new TaskKey())
                        .setServerGroupId(
                                frontSchema.getServerGroupId())
                        .setSchemaName(frontSchema.getSchemaName())
                        .setDxCGProcessed(dxcgProcess)
                        .setUserName(currentUser), reportModifier);
        logInfo("Execute Report : " + frontSchema);
        return sqlProcess;
    }

    /*----------------------------------------------------------------------*/
 /* EXECUTING INDEX */
 /*----------------------------------------------------------------------*/
    public AsyncSQLProcess executeIndex(Schema frontSchema, int degOfParallelism)
            throws Exception {
        checkSchema(frontSchema);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable indexModifier = (new IndexModifier())
                .setEngineMonitorDB(engineMonitorDB).setSchema(frontSchema)
                .setThreadCount(degOfParallelism);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey())
                .setServerGroupId(frontSchema.getServerGroupId())
                .setSchemaName(frontSchema.getSchemaName())
                .setUserName(currentUser), indexModifier);
        logInfo("Indexing : " + frontSchema);
        return sqlProcess;
    }

    /*----------------------------------------------------------------------*/
 /* Data trannsfer */
 /*----------------------------------------------------------------------*/
    public AsyncSQLProcess executeTransfer(Schema destSchema, String srcHost,
            String srcPort, String srcService, String srcSchema, String srcPwd,
            String transferType, String appendFlag, boolean isSameServer,
            String useSidFlag, String dataFileDir, int degOfParallelism,
            String dataFileDirName, String DRTransferEnabled, String loginName,
            String sourceDbLink) throws Exception {
        checkSchema(destSchema);
        ErrorOnQuote.checkQuote(srcHost);
        ErrorOnQuote.checkQuote(srcPort);
        ErrorOnQuote.checkQuote(srcService);
        ErrorOnQuote.checkQuote(srcSchema);
        ErrorOnQuote.checkQuote(srcPwd);
        ErrorOnQuote.checkQuote(transferType);
        ErrorOnQuote.checkQuote(appendFlag);
        ErrorOnQuote.checkQuote(useSidFlag);
        ErrorOnQuote.checkQuote(dataFileDir);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable dataTransfer = (new DataTransfer())
                .setDataFileDir(dataFileDir).setSourceHost(srcHost)
                .setSourcePort(srcPort).setSourceService(srcService)
                .setSourceSchema(srcSchema).setSourcePassword(srcPwd)
                .setSourceDbLink(sourceDbLink).setUseSidForLink(useSidFlag)
                .setTransferType(transferType).setAppendFlag(appendFlag)
                .setSameServer(isSameServer)
                .setDRTransferEnabled(DRTransferEnabled)
                .setLoginName(loginName).setDataFileDirName(dataFileDirName)
                .setSrcSchema(new Schema().setSchemaName(srcSchema))// for
                // sending
                // mail
                .setSchema(destSchema)
                .setThreadCount(degOfParallelism);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(destSchema.getServerGroupId())
                .setSchemaName(destSchema.getSchemaName())
                .setUserName(currentUser), dataTransfer);
        logInfo("DATA TRANSFER FROM ORACLE TO ORACLE BY: " + currentUser);
        logInfo("Data transfer to  : " + destSchema + " from " + srcHost + ":"
                + srcPort + "/" + srcService + " :" + srcSchema + " sidFlag:"
                + useSidFlag);
        return sqlProcess;
    }

    public AsyncSQLProcess executeTransferForVerticaUsingDMExpress(
            Schema srcSchema, Schema destSchema, Schema dmExpressSchema,
            int degOfParallelism, long executionNumber) throws Exception {
        checkSchema(destSchema);
        checkSchema(dmExpressSchema);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();

        DataTransfer dataTransfer1 = new DataTransfer();
        dataTransfer1.isWriteOutputFile();
        // for description
        dataTransfer1.setSourceHost(srcSchema.getServerName());
        dataTransfer1.setSourcePort(srcSchema.getPort());
        dataTransfer1.setSourceSchema(srcSchema.getSchemaName());

        SQLPlusRunnable dataTransfer = (dataTransfer1)
                .setTransferType(Constants.VERTICA)
                .setDmExpressSchema(dmExpressSchema)
                .setExecutionId(executionNumber).setSrcSchema(srcSchema)
                .setSchema(destSchema).setThreadCount(degOfParallelism);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(destSchema.getServerGroupId())
                .setSchemaName(destSchema.getSchemaName())
                .setExecutionNumber(executionNumber)// setting execution
                // number
                .setUserName(currentUser), dataTransfer);

        logInfo("DATA TRANSFER FROM ORACLE TO VERTICA BY: " + currentUser);
        logInfo("Data transfer to  : " + destSchema + " from "
                + srcSchema.getServerName() + ":" + srcSchema.getPort() + "/"
                + srcSchema.getService() + " :" + srcSchema.getSchemaName()
                + " sidFlag:" + srcSchema.getSidFlag() + " using "
                + dmExpressSchema.getServerName() + ":"
                + dmExpressSchema.getPort() + "/"
                + dmExpressSchema.getInstance() + " with exec no "
                + executionNumber);

        return sqlProcess;
    }

    public AsyncSQLProcess executeTransferForVerticaUsingCMA(Schema srcSchema,
            Schema destSchema, long executionNumber, String runBAModule,
            Schema destOrclSchema) throws Exception {
        // System.out.println("Inside CMA.....");
        checkSchema(destSchema);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();

        DataTransfer dataTransfer1 = new DataTransfer();
        dataTransfer1.isWriteOutputFile();
        // for description
        dataTransfer1.setSourceHost(srcSchema.getServerName());
        dataTransfer1.setSourcePort(srcSchema.getPort());
        dataTransfer1.setSourceSchema(srcSchema.getSchemaName());

        SQLPlusRunnable dataTransfer = (dataTransfer1)
                .setTransferType(Constants.VERTICA_CMA)
                // .setDmExpressSchema(dmExpressSchema)
                .setExecutionId(executionNumber).setSrcSchema(srcSchema)
                .setSchema(destSchema);
        // .setThreadCount(degOfParallelism);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(destSchema.getServerGroupId())
                .setSchemaName(destSchema.getSchemaName())
                .setSrcHost(srcSchema.getServerName())
                .setSrcSchemaName(srcSchema.getSchemaName())
                .setDestHost(destSchema.getServerName())
                .setExecutionNumber(executionNumber)// setting execution
                // number
                .setUserName(currentUser), dataTransfer);
        /**
         * FOR DR TRANSFER
         */
        AutoDRTransferController autoDR = new AutoDRTransferController(
                currentUser);
        autoDR.setSrcOrclSchema(srcSchema);
        autoDR.setDestVerticaRACSchema(destSchema);
        autoDR.setRunOracleDRBAModule(runBAModule);
        autoDR.setLoginName(currentUser);
        autoDR.setDestOrclRACSchema(destOrclSchema);
        autoDR.setProdTransferExecNo(executionNumber);
        Thread thread = new Thread(autoDR);
        thread.start();
        // autoDR.automateDRTransfer();

        logInfo("DATA TRANSFER FROM ORACLE TO VERTICA USING CMA BY: "
                + currentUser);
        logInfo("Data transfer to  : " + destSchema + " from "
                + srcSchema.getServerName() + ":" + srcSchema.getPort() + "/"
                + srcSchema.getService() + " :" + srcSchema.getSchemaName()
                + " sidFlag:" + srcSchema.getSidFlag() + " with exec no "
                + executionNumber);

        return sqlProcess;
    }

    public AsyncSQLProcess executeTransferForVerticaDRUsingCMA(
            Schema srcSchema, Schema destSchema, long executionNumber)
            throws Exception {
        // System.out.println("Inside CMA.....");
        checkSchema(destSchema);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();

        DataTransfer dataTransfer1 = new DataTransfer();
        dataTransfer1.isWriteOutputFile();
        // for description
        dataTransfer1.setSourceHost(srcSchema.getServerName());
        dataTransfer1.setSourcePort(srcSchema.getPort());
        dataTransfer1.setSourceSchema(srcSchema.getSchemaName());

        SQLPlusRunnable dataTransfer = (dataTransfer1)
                .setTransferType(Constants.VERTICA_DR_CMA)
                // .setDmExpressSchema(dmExpressSchema)
                .setExecutionId(executionNumber).setSrcSchema(srcSchema)
                .setSchema(destSchema);
        // .setThreadCount(degOfParallelism);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(destSchema.getServerGroupId())
                .setSchemaName(destSchema.getSchemaName())
                .setSrcHost(srcSchema.getServerName())
                .setSrcSchemaName(srcSchema.getSchemaName())
                .setDestHost(destSchema.getServerName())
                .setExecutionNumber(executionNumber)// setting execution
                // number
                .setUserName(currentUser), dataTransfer);

        logInfo("DATA TRANSFER FROM ORACLE TO VERTICA DR USING CMA BY: "
                + currentUser);
        logInfo("Data transfer to  : " + destSchema + " from "
                + srcSchema.getServerName() + ":" + srcSchema.getPort() + "/"
                + srcSchema.getService() + " :" + srcSchema.getSchemaName()
                + " sidFlag:" + srcSchema.getSidFlag() + " with exec no "
                + executionNumber);

        return sqlProcess;
    }

    public AsyncSQLProcess executeTransferForBAModules(Schema srcSchema,
            Schema destSchema, String dataFileDirectoy) throws Exception {
        checkSchema(destSchema);

        String transferType = Constants.ORACLE_BA;// default ORACLE_BA
        String hostingServer = (destSchema.getHostingServer() == null) ? ""
                : destSchema.getHostingServer();
        if (hostingServer.equalsIgnoreCase(Constants.ORACLE_BA_CMA)) {
            transferType = Constants.ORACLE_BA_CMA;
        }

        // System.out.println("Hosting Server for running BA module>>>>>>>>>>>>>>>>>>>>"+hostingServer);
        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();

        DataTransfer dataTransfer1 = new DataTransfer();
        dataTransfer1.isWriteOutputFile();
        // for description
        dataTransfer1.setSourceHost(srcSchema.getServerName());
        dataTransfer1.setSourcePort(srcSchema.getPort());
        dataTransfer1.setSourceSchema(srcSchema.getSchemaName());
        dataTransfer1.setSourceService(srcSchema.getService());

        SQLPlusRunnable dataTransfer = (dataTransfer1)
                .setTransferType(transferType).setSrcSchema(srcSchema)
                .setDataFileDirectoy(dataFileDirectoy).setSchema(destSchema);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(destSchema.getServerGroupId())
                .setSchemaName(destSchema.getSchemaName())
                .setUserName(currentUser), dataTransfer);

        logInfo("BA MODULE TRANSFER BY: " + currentUser);
        logInfo("Data transfer to  : " + destSchema + " from "
                + srcSchema.getServerName() + ":" + srcSchema.getPort() + "/"
                + srcSchema.getService() + " :" + srcSchema.getSchemaName()
                + " sidFlag:" + srcSchema.getSidFlag());

        return sqlProcess;
    }

    public AsyncSQLProcess executeTransferForOracleDRBAModules(
            Schema srcSchema, Schema destSchema, String dataFileDirectoy)
            throws Exception {
        checkSchema(destSchema);

        String transferType = Constants.ORACLE_DR_BA_CMA;// default
        // ORACLE_DR_BA_CMA
        String hostingServer = (destSchema.getHostingServer() == null) ? ""
                : destSchema.getHostingServer();
        if (hostingServer.equalsIgnoreCase(Constants.ORACLE_DR_BA_CMA)) {
            transferType = Constants.ORACLE_DR_BA_CMA;
        }

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();

        DataTransfer dataTransfer1 = new DataTransfer();
        dataTransfer1.isWriteOutputFile();
        // for description
        dataTransfer1.setSourceHost(srcSchema.getServerName());
        dataTransfer1.setSourcePort(srcSchema.getPort());
        dataTransfer1.setSourceSchema(srcSchema.getSchemaName());
        dataTransfer1.setSourceService(srcSchema.getService());

        SQLPlusRunnable dataTransfer = (dataTransfer1)
                .setTransferType(transferType).setSrcSchema(srcSchema)
                .setDataFileDirectoy(dataFileDirectoy).setSchema(destSchema);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(destSchema.getServerGroupId())
                .setSchemaName(destSchema.getSchemaName())
                .setUserName(currentUser), dataTransfer);

        logInfo("ORACLE DR BA MODULE TRANSFER BY: " + currentUser);
        logInfo("Data transfer to  : " + destSchema + " from "
                + srcSchema.getServerName() + ":" + srcSchema.getPort() + "/"
                + srcSchema.getService() + " :" + srcSchema.getSchemaName()
                + " sidFlag:" + srcSchema.getSidFlag());

        return sqlProcess;
    }

    /*----------------------------------------------------------------------*/
 /* PROCESS MGMT */
 /*----------------------------------------------------------------------*/
    public TaskKey[] getTaskKeys() {
        ComponentFactory compFactory = ComponentFactory.getInstance();
        AsyncSQLProcessRegistry registry = compFactory
                .getAsyncSQLProcessRegistry();
        return registry.getTaskKeys();
    }

    public Boolean killProcess(TaskKey taskKey) throws Exception {
        ComponentFactory compFactory = ComponentFactory.getInstance();
        Boolean status = Boolean.FALSE;
        AsyncSQLProcessRegistry registry = compFactory
                .getAsyncSQLProcessRegistry();
        AsyncSQLProcess process = registry.getAsyncSQLProcess(taskKey);
        if (process != null) {
            TaskKey actualTaskKey = process.getTaskKey();
            status = registry.killProcess(taskKey, currentUser);
            logger.info("Kill Process :  ServerGroupId->"
                    + actualTaskKey.getServerGroupId() + " Schema->"
                    + actualTaskKey.getSchemaName() + " owned by -> "
                    + actualTaskKey.getUserName() + " status " + status
                    + " by " + currentUser);
        }
        return status;
    }

    public List getInvalidProcList(Schema schema) throws Exception {
        return engineMonitorDB.getInvalidProcList(schema);
    }

    public TaskKey getActualTaskKey(TaskKey taskKey) throws Exception {
        ComponentFactory compFactory = ComponentFactory.getInstance();
        AsyncSQLProcessRegistry registry = compFactory
                .getAsyncSQLProcessRegistry();
        AsyncSQLProcess process = registry.getAsyncSQLProcess(taskKey);
        if (process != null) {
            TaskKey actualTaskKey = process.getTaskKey();
            return actualTaskKey;
        }
        return null;
    }

    public OracleSystemData getOracleSystemData(Schema schema) throws Exception {
        _checkSchema(schema); // no need to verify serverGroupId

        return engineMonitorDB.getOracleSystemData(schema);
    }

    /*----------------------------------------------------------------------
	  REPORT
	 ----------------------------------------------------------------------*/
    public List listReportModulesOAM(Schema schema) throws Exception {
        return engineMonitorDB.listReportModulesOAM(schema);
    }

    public List listOtherReportModulesOAM(Schema schema) throws Exception {
        return engineMonitorDB.listOtherReportModulesOAM(schema);
    }

    public List listReportModulesOAM() throws Exception {
        return engineMonitorDB.listReportModulesOAM();
    }

    public void syncReportsByOAM() throws Exception {
        engineMonitorDB.syncReportsByOAM();
    }

    public void syncEngVersionWithOAM() throws Exception {
        engineMonitorDB.syncEngVersionWithOAM();
    }

    public List<Chart> getChartData() {
        return engineMonitorDB.getChartData();
    }

    public List listReportModules() throws Exception {
        return engineMonitorDB.listReportModules();
    }

    public List listReportModules(String reportType) throws Exception {
        return engineMonitorDB.listReportModules(reportType);
    }

    public int addReport(Report report) throws Exception {
        int retVal = engineMonitorDB.addReport(report);
        logInfo(retVal, "addReport: " + report);
        return retVal;
    }

    public int deleteReport(Report report) throws Exception {
        int retVal = engineMonitorDB.deleteReport(report);
        logInfo(retVal, "deleteReport " + report);
        return retVal;
    }

    public int updateReport(Report oldReport, Report newReport)
            throws Exception {
        int retVal = engineMonitorDB.updateReport(oldReport, newReport);
        logInfo(retVal, "updateReport from " + oldReport + " to " + newReport);
        return retVal;
    }

    public Report getReportByName(String name) throws Exception {
        return engineMonitorDB.getReportByName(name);
    }

    /*
	 * ----------------------------------------------------------------------
	 * SOURCE CONTROL
	 * ----------------------------------------------------------------------
     */
    public String listDirectory(SourceControlUser user, String directory)
            throws Exception {
        SourceControl sc = ComponentFactory.getInstance().getSourceControl();
        return sc.listDirectory(user, directory);
    }

    public String checkOut(SourceControlUser user, String srcDir, String destDir)
            throws Exception {
        logInfo("Check out using loginName:" + user.getUserName() + " for: "
                + srcDir + " into: " + destDir);
        SourceControl sc = ComponentFactory.getInstance().getSourceControl();
        return sc.checkOut(user, srcDir, destDir);
    }

    public int writeFileFromSVN(SourceControlUser user, String[] srcFiles,
            String destDir) throws Exception {
        SourceControl sc = ComponentFactory.getInstance().getSourceControl();
        return sc.writeFileFromSVN(user, srcFiles, destDir);
    }

    public String[] fetchPreScrub(String clientId) throws Exception {
        return ComponentFactory.getInstance().getScriptFetcher()
                .fetchPreScrub(clientId);
    }

    public int getIndexCount(Schema s) throws Exception {
        return engineMonitorDB.getIndexCount(s);
    }

    public int getProcNTableCount(Schema s) throws Exception {
        return engineMonitorDB.getProcNTableCount(s);
    }

    public int getHRHPCount(Schema s) throws Exception {
        return engineMonitorDB.getHRHPCount(s);
    }

    public Schema setServerGroupName(Schema s) {
        try {
            ServerGroup sg = getServerGroup(s.getServerGroupId());
            s.setServerGroupName(sg.getGroupName());
        } catch (Exception ex) {
            logger.info("Failed setting server group name for: " + s, ex);
        }
        return s;
    }

    public AsyncSQLProcess createPreScrubUser(Schema schema, String sysUser,
            String sysPwd) throws Exception {
        checkSchema(schema);

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable preScrubUserCreator = (new OraclePreScrubUserCreator())
                .setSchema(schema);
        ;
        preScrubUserCreator.setRunnerUserName(sysUser);
        preScrubUserCreator.setRunnerPassword(sysPwd);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey()).setServerGroupId(schema.getServerGroupId())
                .setSchemaName(schema.getSchemaName())
                .setUserName(currentUser), preScrubUserCreator);
        logInfo("createPreScrubUser  : " + schema);
        return sqlProcess;

    }

    public String getClientID(Schema schema) throws Exception {
        return engineMonitorDB.getClientID(schema);
    }

    public String getEngineVersion(Schema s) throws Exception {
        return engineMonitorDB.getEngineVersion(s);
    }

    public List getEngineVersionList() throws Exception {
        return engineMonitorDB.getEngineVersionList();
    }

    public String getEngineVersionForSchema(String schemaName) throws Exception {
        return engineMonitorDB.getEngineVersionForSchema(schemaName);
    }

    public String getClientName(String schemaName) throws Exception {
        return engineMonitorDB.getClientName(schemaName);
    }

    /**
     * Data Analytics Data Transfer/Import/Scrub
     */
    public AsyncSQLProcess executeImportScrub(Schema importSchema,
            DataTask dTask, DataScripts dScripts) throws Exception {
        checkSchema(importSchema);
        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable importScrubModifier = ((ImportScrubModifier) (new ImportScrubModifier())
                .setTask(dTask).setSchema(importSchema)).setDataScripts(
                dScripts).setEngineMonitorDB(engineMonitorDB);

        AsyncSQLProcess sqlProcess = registry.register(
                (new TaskKey())
                .setServerGroupId(importSchema.getServerGroupId())
                .setSchemaName(importSchema.getSchemaName())
                .setUserName(currentUser).setSchema(importSchema),
                importScrubModifier);
        logInfo("Execute Import : " + importSchema);

        return sqlProcess;
    }

    public AsyncSQLProcess importDataTransfer(Schema srcMachineDetail,
            String srcMachine, String destMachine, String srcLocation,
            String destLocation, String[] copyfiles, String mountDir)
            throws Exception {

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();
        SQLPlusRunnable importData = (new ImportDataTransferModifier())
                .setSrcMachine(srcMachine).setDestMachine(destMachine)
                .setSrcLocation(srcLocation).setDestLocation(destLocation)
                .setCopyfiles(copyfiles).setEngineMonitorDB(engineMonitorDB)
                .setMountDir(mountDir).setSchema(srcMachineDetail);

        AsyncSQLProcess sqlProcess = registry.register((new TaskKey())
                .setSchemaName(srcMachineDetail.getSchemaName())
                .setServerGroupId(srcMachineDetail.getServerGroupId())
                .setUserName(currentUser), importData);

        return sqlProcess;
    }

    public AsyncSQLProcess executeWareHouse(Schema wareHouseSchema,
            Schema scrubSchema, Schema frontSchema,
            WareHouseTask wareHouseTask, String isHRA) throws Exception {
        checkSchema(wareHouseSchema);
        if (wareHouseTask.isCreateSynonymForHPnHR()) {
            checkSchema(scrubSchema);
        }
        if (wareHouseTask.isCreateSynonymForHF()) {
            checkSchema(frontSchema);
        }

        AsyncSQLProcessRegistry registry = ComponentFactory.getInstance()
                .getAsyncSQLProcessRegistry();

        SQLPlusRunnable wareHouse = (new WareHouse())
                .setWareHouseTask(wareHouseTask).setScrubSchema(scrubSchema)
                .setFrontSchema(frontSchema).setIsHRA(isHRA)
                .setSchema(wareHouseSchema);

        AsyncSQLProcess sqlProcess = registry.register((new TaskKey())
                .setServerGroupId(wareHouseSchema.getServerGroupId())
                .setSchemaName(wareHouseSchema.getSchemaName())
                .setAsyncControllerType(WareHouseParams.ASYNC_WH_CONTROLLER)
                .setUserName(currentUser), wareHouse);

        logInfo("Execute wareHouse : " + wareHouseSchema);
        return sqlProcess;

    }

    public List getDataClientList() throws Exception {
        return engineMonitorDB.getDataClientList();
    }

    public List getDataTransferMonth(String clientId) throws Exception {
        return engineMonitorDB.getDataTransferMonth(clientId);
    }

    public void logDataTransferClients(String destMachine, String basepath,
            String[] copyfiles, String selectedclient) throws Exception {
        engineMonitorDB.logDataTransferClients(destMachine, basepath,
                copyfiles, selectedclient);
    }

    public void logDataTransferFolders(String destMachine,
            String scriptfilename, String selectedclient, String clientType)
            throws Exception {
        engineMonitorDB.logDataTransferFolders(destMachine, scriptfilename,
                selectedclient, clientType);
    }

    public String getEdbParameters(String paramname) throws Exception {
        return engineMonitorDB.getEdbParameters(paramname);
    }

    public List getScriptsWithDataLoc(String clientId, String payer,
            String dataMonth, String[] scriptsname, String prescrubServer,
            String dataFilePath) throws Exception {
        return engineMonitorDB.getScriptsWithDataLoc(clientId, payer,
                dataMonth, scriptsname, prescrubServer, dataFilePath);
    }

    public boolean saveDefaultFolderbyScriptName(String clientId, String payer,
            String scriptsname, String foldername, String datamonth,
            String importserver) throws Exception {
        return engineMonitorDB.saveDefaultFolderbyScriptName(clientId, payer,
                scriptsname, foldername, datamonth, importserver);
    }

    public List getDefaultScrubScripts(String exeGroup) throws Exception {
        return engineMonitorDB.getDefaultScrubScripts(exeGroup);
    }

    public List getDxCGHostList() throws Exception {
        return engineMonitorDB.getDxCGHostList();
    }

    /*----------------------------------------------------------------------*/
 /* VERTICA DATA TRANSFER DETAILS */
 /*----------------------------------------------------------------------*/
    public List getErrorDetails(Schema schema, Long execNo) {
        return engineMonitorDB.getErrorDetails(schema, execNo);
    }

    public List getErrorDetails_CMA(Schema schema, Long execNo) {
        return engineMonitorDB.getErrorDetails_CMA(schema, execNo);
    }

    public List getEventDetails(Schema schema, Long execNo) {
        return engineMonitorDB.getEventDetails(schema, execNo);
    }

    // shown in process Output
    public List getTransferSummary(Schema schema, Long execNo) {
        return engineMonitorDB.getTransferSummary(schema, execNo);
    }

    public List getTransferSummary_CMA(Schema schema, Long execNo) {
        return engineMonitorDB.getTransferSummary_CMA(schema, execNo);
    }

    public List getTransferDetails(Schema schema, Long execNo,
            String is_Transferred) {
        return engineMonitorDB.getTransferDetails(schema, execNo,
                is_Transferred);
    }

    public List getTransferDetails_CMA(Schema schema, Long execNo,
            String is_Transferred) {
        return engineMonitorDB.getTransferDetails_CMA(schema, execNo,
                is_Transferred);
    }

    public List getVwTransferDetails_CMA(Schema schema, Long execNo,
            String is_Transferred) {
        return engineMonitorDB.getVwTransferDetails_CMA(schema, execNo,
                is_Transferred);
    }

    public int getTotalTableCountFromSource(Schema schema) {
        return engineMonitorDB.getTotalTableCountFromSource(schema);
    }

    public int getTotalViewCountFromSource(Schema schema) {
        return engineMonitorDB.getTotalViewCountFromSource(schema);
    }

    /*
	 * JIRA: VITTOOLS Added by: Binay Shakya
	 * 
	 * @param schema: CentralSchema
	 * 
	 * @param execNo: Execution Number Description: returns true if the event
	 * description is "Execute DMX Task" for the given exec_no
     */
    public boolean isExecuteDMXTask(Schema schema, Long execNo) {
        return engineMonitorDB.isExecuteDMXTask(schema, execNo);
    }

    public boolean isCopyDataFromO2V(Schema schema, Long execNo) {
        return engineMonitorDB.isCopyDataFromO2V(schema, execNo);
    }

    public int getCount(Schema schema, Long execNo, String isTransfered) {
        return engineMonitorDB.getCount(schema, execNo, isTransfered);
    }

    public int getCount_CMA(Schema schema, Long execNo, String isTransferred) {
        return engineMonitorDB.getCount_CMA(schema, execNo, isTransferred);
    }

    public int getViewCount_CMA(Schema schema, Long execNo, String isTransferred) {
        return engineMonitorDB.getViewCount_CMA(schema, execNo, isTransferred);
    }

    public long getExecutionNumber() throws Exception {
        return engineMonitorDB.getExecutionNumber();
    }

    public String getDBLink(Schema schema) throws SQLException, CustomException {
        return engineMonitorDB.getDBLink(schema);
    }

    public InputStream getLogFile(Long execNO, String hostingServer)
            throws Exception {
        return engineMonitorDB.getLogFile(execNO, hostingServer);
    }

    public String getShellScriptOutput(Long execNo, String hostingServer)
            throws Exception {
        return engineMonitorDB.getShellScriptOutput(execNo, hostingServer);
    }

    public InputStream getOracleBALogFile(Schema schema) throws Exception {
        return engineMonitorDB.getOracleBALogFile(schema);
    }

    public Object[] getOracle2VerticaProcessId(String input) {
        return engineMonitorDB.getOracle2VerticaProcessId(input);
    }

    public boolean killOracleToVerticaProcess(String execNo, String process_Id,
            String srcServer, String hostingServer) {
        return engineMonitorDB.killOracleToVerticaProcess(execNo, process_Id,
                srcServer, hostingServer);
    }

    public String getHostName(Long executionNo) {
        return engineMonitorDB.getHostName(executionNo);
    }

    public String getO2VProcessId(String execNo, String srcServer,
            String hostingServer) throws Exception {
        return engineMonitorDB
                .getO2VProcessId(execNo, srcServer, hostingServer);
    }

    public String getCMABatchID(String execNo, String srcServer,
            String hostingServer) throws Exception {
        return engineMonitorDB.getCMABatchID(execNo, srcServer, hostingServer);
    }

    public String getCMABatchId(long execNo, Schema schema) {
        return engineMonitorDB.getCMABatchId(execNo, schema);
    }

    public boolean verticaSchemaExists(Schema schema, String newSchemaName)
            throws Exception {
        return engineMonitorDB.verticaSchemaExists(schema, newSchemaName);
    }

    public Object[] getTableSpaceAndItsStatus(Schema srcSchema)
            throws Exception {
        return engineMonitorDB.getTableSpaceAndItsStatus(srcSchema);
    }

    public boolean reTransferTableExists(Schema srcSchema,
            String reTransferTblName) throws Exception {
        return engineMonitorDB.reTransferTableExists(srcSchema,
                reTransferTblName);
    }

    public int checkForReTransfer(Schema srcOrclSchema, Schema destVtkaSchema,
            Schema centralSchema) throws Exception {
        return engineMonitorDB.checkForReTransfer(srcOrclSchema,
                destVtkaSchema, centralSchema);
    }

    public boolean isReTransferTblEmpty(Schema srcSchema,
            String reTransferTblName) throws Exception {
        return engineMonitorDB.isReTransferTblEmpty(srcSchema,
                reTransferTblName);
    }

    public boolean mapOracleServerGroup(String oracleRACServerGroupId,
            String oracleDRServerGroupId) throws Exception {
        return engineMonitorDB.mapOracleServerGroup(oracleRACServerGroupId,
                oracleDRServerGroupId);
    }

    public boolean mapVerticaServerGroup(String verticaRACServerGroupId,
            String verticaDRServerGroupId) throws Exception {
        return engineMonitorDB.mapVerticaServerGroup(verticaRACServerGroupId,
                verticaDRServerGroupId);
    }

    public ServerGroup getOrclDRServerGroup(Schema orclSchema) throws Exception {
        return engineMonitorDB.getOrclDRServerGroup(orclSchema);
    }

    public List<Schema> getOracleDRSchemaList(Schema oracleRacSchema)
            throws CustomException, SQLException {
        return engineMonitorDB.getOracleDRSchemaList(oracleRacSchema);
    }

    /*
	 * public List<Schema> getVerticaDRSchemaList(Schema verticaRacSchema)
	 * throws Exception{ return
	 * engineMonitorDB.getVerticaDRSchemaList(verticaRacSchema); }
     */
    public List<Schema> getVerticaSchemaList(Schema vtkaSchema)
            throws Exception {
        return engineMonitorDB.getVerticaSchemaList(vtkaSchema);
    }

    public boolean checkTableCount(Schema srcOrclSchema, Schema centralSchema,
            Long execNo) throws Exception {
        return engineMonitorDB.checkTableCount(srcOrclSchema, centralSchema,
                execNo);
    }

    public TreeMap<ServerGroup, ServerGroup> getOracleMappedServerGroupList()
            throws Exception {
        return engineMonitorDB.getOracleMappedServerGroupList();
    }

    public TreeMap<String, String> getVerticaMappedServerGroupList()
            throws Exception {
        return engineMonitorDB.getVerticaMappedServerGroupList();
    }

    public boolean isSchemaStaticallyMapped(Schema orclSchema, Schema vtkaSchema) {
        return engineMonitorDB.isSchemaStaticallyMapped(orclSchema, vtkaSchema);
    }

    public boolean oracleSchemaExists(Schema schemaCreator, String schemaName)
            throws Exception {
        return engineMonitorDB.oracleSchemaExists(schemaCreator, schemaName);
    }

    // Methods for password less design implementation
    public Schema generateSchemaPassword(Schema schema) throws Exception {
        return engineMonitorDB.generateSchemaPassword(schema);
    }

    public void insertSchemaInfo(Schema schema) throws Exception {
        engineMonitorDB.insertSchemaInfo(schema);
    }
    
    public void insertNotInSchemaInfo(Schema schema) throws Exception {
        engineMonitorDB.insertNotInSchemaInfo(schema);
    }
    public Schema setSchemaPassword(Schema schema) throws Exception {
        return engineMonitorDB.setSchemaPassword(schema);
    }

    public Schema setSchemaCreatorUserNPwd(Schema schema) throws Exception {
        return engineMonitorDB.setSchemaCreatorUserNPwd(schema);
    }

    public boolean isSchemaInfoAlreadyInserted(Schema schema) throws Exception {
        return engineMonitorDB.isSchemaInfoAlreadyInserted(schema);
    }

    public void insertSchemaInfoForVertica(String serverGroupId,
            String schemaName, String schemaPwd) throws Exception {
        engineMonitorDB.insertSchemaInfoForVertica(serverGroupId, schemaName,
                schemaPwd);
    }

    public boolean dbaObjExists(Schema schema, String objectName,
            String objectType) throws Exception {
        return engineMonitorDB.dbaObjExists(schema, objectName, objectType);
    }

    /**
     * ******* CLUSTER GROPUS MGMT **********
     */
    public List getClusterGroupList() throws Exception {
        return engineMonitorDB.getClusterGroupList();
    }

    public int addClusterGroup(String clusterGroup, String clusterType)
            throws Exception {
        int retVal = engineMonitorDB.addClusterGroup(clusterGroup, clusterType);
        logInfo(retVal, "addClusterGroup: " + clusterGroup);
        return retVal;
    }

    public int deleteClusterGroup(String clusterGroupId) throws Exception {
        int retVal = engineMonitorDB.deleteClusterGroup(clusterGroupId);
        logInfo(retVal, "deleteClusterGroup: " + clusterGroupId);
        return retVal;
    }

    public List getServerGroupListByCluster(String clusterGrpId)
            throws Exception {
        return engineMonitorDB.getServerGroupListByCluster(clusterGrpId);
    }

    public List getAvailableServerGps(String category) throws Exception {
        return engineMonitorDB.getAvailableServerGps(category);
    }

    public int assignServerGrpToCluster(String clusterGrpId, String[] serverGrps)
            throws Exception {
        return engineMonitorDB.assignServerGrpToCluster(clusterGrpId,
                serverGrps);
    }

    public int deleteServerGrpFromCluster(String clusterGrpId,
            String serverGrpId) throws Exception {
        return engineMonitorDB.deleteServerGrpFromCluster(clusterGrpId,
                serverGrpId);
    }

    public boolean mapVerticaClusterGroup(String prodVerticaClusterGrpId,
            String drVerticaClusterGrpId) throws Exception {
        return engineMonitorDB.mapVerticaClusterGroup(prodVerticaClusterGrpId,
                drVerticaClusterGrpId);
    }

    public TreeMap<ClusterGroup, ClusterGroup> getVerticaMappedClusterGroupList()
            throws Exception {
        return engineMonitorDB.getVerticaMappedClusterGroupList();
    }

    public int deleteOrclServerGrpMapping(String orclRACServerGrpId,
            String orclDRServerGrpId) throws Exception {
        return engineMonitorDB.deleteOrclServerGrpMapping(orclRACServerGrpId,
                orclDRServerGrpId);
    }

    public int deleteVtkaClusterGrpMapping(String prodVtkaClusterGrpId,
            String drVtkaClusterGrpId) throws Exception {
        return engineMonitorDB.deleteVtkaClusterGrpMapping(
                prodVtkaClusterGrpId, drVtkaClusterGrpId);
    }

    public int updateIsDeletedFlag(Schema schema, String isDeleted) {
        return engineMonitorDB.updateIsDeletedFlag(schema, isDeleted);
    }

    public int deletePwdEntry(Schema schema) {
        return engineMonitorDB.deletePwdEntry(schema);
    }

    /**
     * ******* SPLIT CLUSTER DESIGN **********
     */
    public ClusterGroup getClusterGrpDetailsForSchema(String clusterGrpId,
            String schemaName) throws Exception {
        return engineMonitorDB.getClusterGrpDetailsForSchema(clusterGrpId,
                schemaName);
    }

    public List<ClusterGroup> listVerticaClusterGrp(String category)
            throws Exception {
        return engineMonitorDB.listVerticaClusterGrp(category);
    }

    public Object[] checkSchemaInClusterGrp(ClusterGroup clusterGroup,
            Schema destVtkaSchema, String event)
            throws VerticaException {
        return engineMonitorDB.checkSchemaInClusterGrp(clusterGroup,
                destVtkaSchema, event);
    }

    public List<Map<ServerGroup, List<Server>>> getAllServerGrpWithServers(
            ClusterGroup clusterGroup, String event)
            throws VerticaException {
        return engineMonitorDB.getAllServerGrpWithServers(clusterGroup, event);
    }

    public List<Server> getServersForAServerGrp(String serverGrpId)
            throws Exception {
        return engineMonitorDB.getServersForAServerGrp(serverGrpId);
    }

    public boolean isValidVerticaNode(Schema vtkaSchema) {
        return engineMonitorDB.isValidVerticaNode(vtkaSchema);
    }

    public Server getVIPServer(ServerGroup serverGrp) throws Exception {
        return engineMonitorDB.getVIPServer(serverGrp);
    }

    public Map<String, Double> getServerGrpParams(Schema vtkaSchema,
            String event) throws VerticaException {
        return engineMonitorDB.getServerGrpParams(vtkaSchema, event);
    }

    public double getSchemaSize(Schema schema, String event)
            throws VerticaException {
        return engineMonitorDB.getSchemaSize(schema, event);
    }

    public boolean checkVIP(String host) throws Exception {
        return engineMonitorDB.checkVIP(host);
    }

    public ClusterGroup getDRClusterGroup(ClusterGroup prodClusterGroup)
            throws Exception {
        return engineMonitorDB.getDRClusterGroup(prodClusterGroup);
    }

    public String getSchemaPwdFromMappedClusters(Schema schema)
            throws SQLException {
        return engineMonitorDB.getSchemaPwdFromMappedClusters(schema);
    }

    /*
	 * User Management
     */
    public List<User> getUserListByUserRole(String userRole, String flag)
            throws SQLException {
        return engineMonitorDB.getUserListByUserRole(userRole, flag);
    }

    public int changeUserRole(String userRole, String[] users)
            throws SQLException {
        return engineMonitorDB.changeUserRole(userRole, users);
    }

    public int deleteAllUsersForUserRole(String userRole) throws SQLException {
        return engineMonitorDB.deleteAllUsersForUserRole(userRole);
    }

    /**
     * Scrubbing
     */
    public Map<String, Boolean> getClientSpecificSQLScripts(Schema schema) throws SQLException, CustomException {
        return engineMonitorDB.getClientSpecificSQLScripts(schema);
    }

    public Map<String, Boolean> getCDFObjScriptsForHP(String CDF_OBJ_SCRIPTS_FOR_HP) throws Exception {
        return engineMonitorDB.getCDFObjScriptsForHP(CDF_OBJ_SCRIPTS_FOR_HP);
    }

    /**
     * Mini Engine
     */
    public List<String> getInvalidMREPreChecks(Schema vcSchema) throws Exception {
        return engineMonitorDB.getInvalidMREPreChecks(vcSchema);
    }

    public List<MREPreCheck> getMrePreCheckForSchema(Schema vcSchema) throws Exception {
        return engineMonitorDB.getMrePreCheckForSchema(vcSchema);
    }

    public List<Map<ServerGroup, List<Server>>> getServerGroupMapListBasedOnSchema(Schema orclSchema, Schema vtkaSchema, boolean isTransferToProd, String event) throws VerticaException {
        return engineMonitorDB.getServerGroupMapListBasedOnSchema(orclSchema, vtkaSchema, isTransferToProd, event);
    }
    
    public Object[] isValidReportCount(Schema schema) throws Exception {
        return engineMonitorDB.isValidReportCount(schema);
    }

	@Override
	public boolean checkDXCGVerification() throws Exception {
		return engineMonitorDB.checkDXCGVerification();
	}
}
