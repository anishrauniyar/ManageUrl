package dashboard.engine.oracle;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Properties;

import java.io.File;
import java.io.ByteArrayInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory; 

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import dashboard.engine.ScriptFetcher;
import dashboard.util.EnvInfo;
import dashboard.util.HttpConnectorUtil;
import dashboard.util.FileUtil;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;


public class OamScriptFetcher implements ScriptFetcher {

    private EnvInfo envInfo;
    private String PRE_SCRUB_URL;
    public void setEnvInfo(EnvInfo e) {
        envInfo = e;
        PRE_SCRUB_URL = "http://mayur:7600/VSS/SF_Download_Ora_Direct.jsp";
    }

    private static final String PARAM_CLIENT_ID = "ClientID";

    private static final String ELEMENT_CLIENT_ID = "ClientID";
    private static final String ELEMENT_SCHEMA_NAME = "SchemaName";
    private static final String ELEMENT_SCRIPT = "script";

    public String [] fetchPreScrub(String clId) throws Exception {
        Log logger = LogFactory.getLog(getClass());
        String clientId = getClientId(clId);
        
        Properties param = new Properties();
        param.setProperty( PARAM_CLIENT_ID, clientId);

        byte [] contents = HttpConnectorUtil.postNGetBytes(PRE_SCRUB_URL, param);


        DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = fact.newDocumentBuilder();
        Document doc = null;
        try {
            doc = builder.parse ( new ByteArrayInputStream( contents ) );
        } catch( Exception ex) {
            logger.info("oam content parse exception: " + new String(contents), ex);
            throw ex;
        }

        Element elm = doc.getDocumentElement();

        String retClientId =  ((Element) elm.getElementsByTagName( ELEMENT_CLIENT_ID)
                            .item(0)).getFirstChild().getNodeValue();
        String retSchemaName = ((Element) elm.getElementsByTagName( ELEMENT_SCHEMA_NAME)
                             .item(0)).getFirstChild().getNodeValue();
            
        Element script = (Element) elm.getElementsByTagName( ELEMENT_SCRIPT).item(0);

        StringBuffer sb = new StringBuffer( contents.length);
        
        for(Node nd =  script.getFirstChild(); null != nd; nd = nd.getNextSibling()) {
            short ndType = nd.getNodeType();
            Node e = nd;
            switch(ndType) {
            case Node.TEXT_NODE:
                sb.append( e.getNodeValue());
                break;
            case Node.CDATA_SECTION_NODE:
                sb.append( e.getNodeValue());
                break;
            }
        }            
        File preScrubSource = (new NamingUtil()).getPreScrubOamSourceFile( retSchemaName);
        FileUtil.writeToTextFile( sb.toString(), preScrubSource);
        return new String [] {retClientId, retSchemaName };
    }

    private static final Pattern clientIdPattern
        = Pattern.compile("\\s*([0-9]{3})\\s*",Pattern.CASE_INSENSITIVE);
    private static String getClientId(String param) throws Exception {
        Matcher m = clientIdPattern.matcher(param) ; //.group();
        m.find();
        return m.group(1);
    }

}
