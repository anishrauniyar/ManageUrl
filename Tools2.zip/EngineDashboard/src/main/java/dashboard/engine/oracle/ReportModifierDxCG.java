package dashboard.engine.oracle;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import dashboard.data.Schema;
import dashboard.data.TaskTypeNFile;
import dashboard.data.Report;
import dashboard.db.EngineMonitorDB;
import dashboard.security.User;
import dashboard.util.FileUtil;
import dashboard.util.XmlCipherTool;
import dashboard.engine.TaskType;

public class ReportModifierDxCG {
	private static final String KEY_ENCRYPT_KEY = "B9327A8998CDDFF864D058AEEC9826343E91313891704F1A";
	
    public ReportModifierDxCG() {
    	ls = new LinkedList();
    }
    
    private String dxcgHostUrl = "";
    public ReportModifierDxCG setDxcgHostUrl(String p){
    	dxcgHostUrl = p;
    	return this;
    }
    
    private Report report = null;
    public ReportModifierDxCG setReportInfo(Report rp) {
        report = rp;
        return this;
    }
    
    protected Schema runnerSchema = null;

    public ReportModifierDxCG setSchema(Schema runS) {
        runnerSchema = runS;
        return this;
    }
    
    protected EngineMonitorDB engineMonitorDB = null;
    public ReportModifierDxCG setEngineMonitorDB( EngineMonitorDB engMDB) {
        engineMonitorDB = engMDB;
        return this;
    }
    protected EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }
    
    protected User user =  null;
	public User getUser() {
		return user;
	}
	public ReportModifierDxCG setUser(User user) {
		this.user = user;
		return this;
	}
    
    public List getTaskTypeNFileList() {
        return ls;
    }
    protected List ls;
    
    public void init() throws Exception {  		        
        ls = generateScript( );
    }
    
    private static final Pattern clientAppPattern
    						= Pattern.compile("\\s*HF0([0-9]{6})[0-9]*\\s*",Pattern.CASE_INSENSITIVE);
    
    private List generateScript() throws Exception {
        	String jarExecCommand = "";
        	String fileSeparator = System.getProperty("file.separator");
        	File scriptFile = (new NamingUtil()).getReportScriptFile(this.runnerSchema, report.getReportId());
        	
            Matcher m = clientAppPattern.matcher(this.runnerSchema.getSchemaName()) ;
            StringBuffer clientNAppId = new StringBuffer(0);
            if (m.find() ) {
                clientNAppId.append(m.group(1));
            } else {
                throw new IllegalArgumentException("Not a valid front name: " + this.runnerSchema.getSchemaName());
            }
        	clientNAppId.insert(3, '-');
        	
        	//String strUrl = engineMonitorDB.getEdbParameters("DxCGHost");        	
        	//System.out.println("DxCG URL"+dxcgHostUrl);
        	
        	String urlPattern = engineMonitorDB.getEdbParameters("DxCGServPattern");
        	String javaBinPath= engineMonitorDB.getEdbParameters("DxCGJavaBin");
        	String dxcgInitJarPath= engineMonitorDB.getEdbParameters("DxCGInitJar");
        	String databaseAlias = "\""+runnerSchema.getServerName()+"->"+runnerSchema.getSchemaName()+"\"";
        	String userId = getUser().getUserId();
        	String userName = getUser().getUserName();
        	
			String xmlinfo="";			
			jarExecCommand = javaBinPath + fileSeparator+"java -jar"+" "+ dxcgInitJarPath + fileSeparator+"dxcg-init.jar"
								 +" "+scriptFile+".xml "+dxcgHostUrl+" "+urlPattern+" "+databaseAlias; 
			
			xmlinfo = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"+
		        "<Node version=\"1.0.0.1\" name=\"DASHBOARD_NODE\">\n"+
		            "<Process version=\"3.0\" type=\"DASHBOARD\" name=\"DXCG\"/>\n"+
		            "<Parameters>\n"+
		                "\t<Parameter id=\"1\" name=\"userid\">\n"+
		                "\t\t	<Value>"+userId+"</Value>\n"+
		                "\t</Parameter>\n"+
		                "\t<Parameter id=\"2\" name=\"user\">\n"+
		                "\t\t	<Value>"+userName+"</Value>\n"+
		                "\t</Parameter>\n"+
		                "\t<Parameter id=\"3\" name=\"host\">\n"+
		                "\t\t	<Value>"+runnerSchema.getServerName()+"</Value>\n"+
		                "\t</Parameter>\n"+
		                "\t<Parameter id=\"4\" name=\"schema\">\n"+
		                "\t\t	<Value>"+runnerSchema.getSchemaName()+"</Value>\n"+
		                "\t</Parameter>\n"+
		                "\t<Parameter id=\"5\" name=\"password\">\n"+
		                "\t\t	<Value>"+runnerSchema.getSchemaPwd()+"</Value>\n"+
		                "\t</Parameter>\n"+
		                "\t<Parameter id=\"6\" name=\"service\">\n"+
		                "\t\t	<Value>"+runnerSchema.getService()+"</Value>\n"+
		                "\t</Parameter>\n"+
		                "\t<Parameter id=\"7\" name=\"port\">\n"+
		                "\t\t	<Value>"+runnerSchema.getPort()+"</Value>\n"+
		                "\t</Parameter>	\n"+
		                "\t<Parameter id=\"8\" name=\"sidFlag\">\n"+
		                "\t\t	<Value>"+runnerSchema.getSidFlag()+"</Value>\n"+
		                "\t</Parameter>	\n"+	
		                "\t<Parameter id=\"9\" name=\"engineVersion\">\n"+
		                "\t\t	<Value>"+runnerSchema.getEngineVersion()+"</Value>\n"+
		                "\t</Parameter>	\n"+	
		                "\t<Parameter id=\"10\" name=\"preserveReportFlag\">\n"+
		                "\t\t	<Value>Y</Value>\n"+
		                "\t</Parameter>\n"+
		            "</Parameters>\n"+
		        "</Node>";
			
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db.parse(new ByteArrayInputStream(xmlinfo.getBytes()));
            document.getDocumentElement().normalize();
            Document encrypted_document =  XmlCipherTool.getEncryptDocument(document, "Parameters", KEY_ENCRYPT_KEY);  
            
            XmlCipherTool.writeXmlDocumentToFile(encrypted_document, new File(scriptFile+".xml"));
			//FileUtil.writeToTextFile(xmlinfo, new File(scriptFile+".xml"));
            
			scriptFile = new File(scriptFile+".sh");
		    FileUtil.writeToTextFile(jarExecCommand, scriptFile);
		
		    TaskTypeNFile taskTypeNFile = new TaskTypeNFile(new TaskType("PROCESS_SCRIPT_OR_REPORT_"+ report.getReportId(), 
				    "Process Report ("+report.getReportName()+")",new Integer(4)), scriptFile);
				        
			taskTypeNFile.setShellScript(true);
			taskTypeNFile.setScriptFile(scriptFile);
			ls.add(taskTypeNFile);
			return ls;	
	}
	   
}
