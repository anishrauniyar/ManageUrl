/**
 * @author Vinaya Lal Shrestha
 * @version 1.0
 */

package dashboard.engine.oracle;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.DataScripts;
import dashboard.data.DataTask;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.TaskTypeNFile;
import dashboard.db.EngineMonitorDB;
import dashboard.db.OracleDBConnector;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.EDBUtil;
import dashboard.util.FileUtil;

public class ImportScrubModifier extends BaseSQLPlusRunnable{

	protected TaskType taskType = null;
	private DataTask dataTask = null;
	private DataScripts dataScripts = null;
	private String sqlPlusUrl = null;
	private String desc = "Import Data: ";
	private EngineMonitorDB engineMonitorDB = null;
	protected Log logger = LogFactory.getLog(getClass());
	
	public ImportScrubModifier(){
		super();
	}
	
	public void init() throws Exception {
        ls = generateScript();
        Schema importSchema = getSchema();
        sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(importSchema);
        desc = "[" + importSchema.getServerGroupName() + "] " +
        		importSchema.getServerName() + ":" + importSchema.getPort() + "/" +
        		importSchema.getService() + ":" + importSchema.getSchemaName();
    }

    private List generateScript() throws Exception{
    	ls.clear();
        Schema runnerSchema = getSchema();
        String script = "";
                
        String[] scriptFiles = dataScripts.getScriptFileName();
        String[] replacementData = dataScripts.getDataURL();
        
        for(int i = 0 ; i < scriptFiles.length; i++){            
            
            String task = "";
            String taskName = "";
            File scriptFile = null;
            
            if(dataScripts.getProcessingType().toUpperCase().equals("SCRUB")){
            	task = "EXECUTE_SCRUB";
            	taskName = "Process Scrub";
            	
            	String filename= scriptFiles[i].substring(scriptFiles[i].lastIndexOf(EDBUtil.fileseperator)+1,scriptFiles[i].length());            	
            	script = engineConverter.getScrubScript(scriptFiles[i]);
            	scriptFile = (new NamingUtil()).getScrubScriptFile(runnerSchema, filename);
            	
            } else if(dataScripts.getProcessingType().toUpperCase().equals("IMPORT")){
            	task = "EXECUTE_IMPORT";
            	taskName = "Process Import";
                
            	String filename= scriptFiles[i].substring(scriptFiles[i].lastIndexOf(EDBUtil.fileseperator)+1,scriptFiles[i].length());            	
                script = engineConverter.getModifiedImportScript(replacementData[i], scriptFiles[i]);
                scriptFile = (new NamingUtil()).getImportScriptFile(runnerSchema, filename);
            }
            
        	FileUtil.writeToTextFile(script, scriptFile);
	        ls.add(new TaskTypeNFile(new TaskType(task + "_" + scriptFiles[i],taskName + " (" + scriptFiles[i] + (")"),new Integer(6)),scriptFile));    
        }
        return ls;
    }

    // property getters and setters
	
    public ImportScrubModifier setTask(DataTask value) {
        this.dataTask = value;
        if (dataTask != null) {
        	if (dataTask.isRunImport()) taskType = TaskType.EXECUTE_IMPORT;
            if (dataTask.isRunScrub()) taskType = TaskType.EXECUTE_SCRUB;
        }
        return this;
    }
    
    public SQLPlusRunnable setTaskType( TaskType value) {
        if (null != value) {
            taskType = value;
        }
        return this;
    }
    
    public TaskType getTaskType() {
        return taskType;
    }

    public ImportScrubModifier setDataScripts(DataScripts value){
    	dataScripts = value;
    	return this;
    }
    
    public String getDescription() {
		return desc;
	}
   
    public List getTaskTypeNFileList() {
        return ls;
    }
    
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }
	
    public List getStatusList() throws Exception{
        if (TaskType.EXECUTE_IMPORT.equals(taskType)||TaskType.EXECUTE_SCRUB.equals(taskType)) {
            return getStatusListCache();
        }
        return getEmptyList();  
    }

    public RunningStatus getRunningStatus() throws Exception {     	
    	return getRunningStatusCache();
    }
    
    public boolean isAllowKill() {
        return true;
    }

    public void kill() throws Exception {
        if (TaskType.EXECUTE_IMPORT.equals(taskType)||TaskType.EXECUTE_SCRUB.equals(taskType)) {
            engineMonitorDB.kill(getSchema());
        }
    }
    
    public ImportScrubModifier setEngineMonitorDB(EngineMonitorDB value) {
        engineMonitorDB = value;
        return this;
    }
   
    protected EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }

}