package dashboard.engine.oracle;


import java.io.File;
import java.util.List;
import java.util.LinkedList;
import dashboard.ComponentFactory;
import dashboard.data.TaskTypeNFile;
import dashboard.data.Schema;
import dashboard.data.EngineReplacementData;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;

import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.engine.EngineConverter;

import dashboard.db.OracleDBConnector;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class OracleUserCreator extends BaseSQLPlusRunnable {
    
    ComponentFactory compFactory;
    EnvInfo env;
    String rootDir;
    String createAndGrandDir;
    List ls;
 

    protected Log logger = LogFactory.getLog(getClass());

    
    public OracleUserCreator() {
        compFactory = ComponentFactory.getInstance();
        env = compFactory.getEnvInfo();
        ls = new LinkedList();
    }


    String dataFileDir;
    public OracleUserCreator setDataFileDir(String dbfDir) {
        dataFileDir = dbfDir;
        return this;
    }
    String schemaCreationMode;
    public String getSchemaCreationMode() {
		return schemaCreationMode;
	}

	public OracleUserCreator setSchemaCreationMode(String schemaCreationMode) {
		this.schemaCreationMode = schemaCreationMode;
		return this;
	}


	String tempTablespace;
    public OracleUserCreator setTempTablespace(String tmpTS) {
        tempTablespace = tmpTS;
        return this;
    }

    String desc = "Create User";
    public String getDescription() {
        return desc;
    }

    public TaskType getTaskType() {
        return TaskType.CREATE_USER;
    }

    private boolean histSchema = false;
    public OracleUserCreator setHistSchema(boolean hSchema) {
        histSchema = hSchema;
        return this;
    }
    
    private String schemaType = "";
    public OracleUserCreator setSchemaType(String schemaType) {
		this.schemaType = schemaType;
		return this;
	}
    private boolean SP_GrantNewUserScriptExists;
    public OracleUserCreator setSP_GrantNewUserScriptExists(boolean sP_GrantNewUserScriptExists) {
		SP_GrantNewUserScriptExists = sP_GrantNewUserScriptExists;
		return this;
	}


	private EngineReplacementData replData = null;
	private String schemaTobeCreated = ""; // schema name 
    private File generateScriptToCreateSchema()
        throws Exception {
        Schema schema = getSchema();
        StringBuffer sb = EngineConverter.initStringBuffer();
     
        // setting schemaToBeCreated
        setSchemaTobeCreated();
        
        sb.append("\n-- creating for: " + schemaTobeCreated)
            .append("\n-----------------------------")
            .append("\nBEGIN\n")
            .append("\n  Utility.SP_CreateUser ('")
            .append(schemaTobeCreated)
            .append("'")
            .append(",'").append(dataFileDir).append("'")
            .append(",'").append(tempTablespace).append("'")
            .append(",'").append( histSchema? 'Y': 'N' ).append("'")
            .append((null == schema.getSchemaPwd() || "".equals(schema.getSchemaPwd()))?
                    "": ",'" + schema.getSchemaPwd() + "'" )
            .append(");")
            .append("\n  Utility.SP_GrantNewUser('")
            .append(schemaTobeCreated)
            .append("' ")
            .append(",'").append( histSchema? 'Y': 'N')
            .append("' ")
            .append(",'").append(schema.getEngineVersion()).append("');");
        if(histSchema){
             sb.append("\n-- creating history objects ")
               .append("\n  Utility.sp_create_history_objects ('")
               .append(schemaTobeCreated+"');");
        }
        sb.append("\nEND;")
          .append("\n/");
        sb = EngineConverter.addExit(sb);
        
        File scriptFile = (new NamingUtil()).getCreateUserFile(schema);
        FileUtil.writeToTextFile( sb.toString(), scriptFile);
        return scriptFile;
    }
    private File generateScriptToCreateSchemaForASM()
    throws Exception {
    Schema schema = getSchema();
    StringBuffer sb = EngineConverter.initStringBuffer();

    // setting schemaToBeCreated
    setSchemaTobeCreated();
        
    sb.append("\n-- creating for: " + schemaTobeCreated)
        .append("\n-----------------------------")
        .append("\nBEGIN\n")
        .append("\n  Utility.sp_createuser_smallhf ('")
        .append(schemaTobeCreated)
        .append("'")
        .append(",'").append(dataFileDir).append("'")
        .append(",'").append(tempTablespace).append("'")
        .append(",'").append( histSchema? 'Y': 'N' ).append("'")
        .append((null == schema.getSchemaPwd() || "".equals(schema.getSchemaPwd()))?
                "": ",'" + schema.getSchemaPwd() + "'" )
        .append(","+schema.getSchemaSize())       
        .append(");")
        .append("\n  Utility.SP_GrantNewUser('")
        .append(schemaTobeCreated)
        .append("' ")
        .append(",'").append( histSchema? 'Y': 'N')
        .append("' ")
        .append(",'").append(schema.getEngineVersion()).append("');");
    if(histSchema){
         sb.append("\n-- creating history objects ")
           .append("\n  Utility.sp_create_history_objects ('")
           .append(schemaTobeCreated+"');");
    }
    sb.append("\nEND;")
      .append("\n/");
    sb = EngineConverter.addExit(sb);
    
    File scriptFile = (new NamingUtil()).getCreateUserFile(schema);
    FileUtil.writeToTextFile( sb.toString(), scriptFile);
    return scriptFile;
}

	/**
	 * @Description: Generates script file for creating VC schema. Note: Only
	 *               adds the grant script [sp_grantnewuser] if it exists in
	 *               provided schema
	 * @return
	 * @throws Exception
	 */
	private File generateScriptToCreateHPandVCSchema() throws Exception {
		Schema schema = getSchema();
		StringBuffer sb = EngineConverter.initStringBuffer();
		// setting schemaToBeCreated
		setSchemaTobeCreated();

		sb.append("\n-- creating for: " + schemaTobeCreated)
				.append("\n-----------------------------").append("\nBEGIN\n")
				.append("\n  Utility.sp_createusrntblspc_grnt ('")
				.append(schemaTobeCreated).append("'")
				/*
				 * .append((null == schema.getSchemaPwd() || "".equals(schema
				 * .getSchemaPwd())) ? "" : ",'" + schema.getSchemaPwd() + "'")
				 */
				.append(");");
				if (SP_GrantNewUserScriptExists) {
					sb.append("\n  Utility.SP_GrantNewUser('")
							.append(schemaTobeCreated).append("'").append(",'")
							.append(histSchema ? 'Y' : 'N').append("' ").append(",'")
							.append(schema.getEngineVersion()).append("');");
				}
		sb.append("\nEND;").append("\n/");
		sb = EngineConverter.addExit(sb);

		File scriptFile = (new NamingUtil()).getCreateUserFile(schema);
		FileUtil.writeToTextFile(sb.toString(), scriptFile);
		return scriptFile;
	}
    
    public void init() throws Exception {
		File scriptFile = null;
		Schema schema = getSchema();
		if (schema.getHostingServer().equalsIgnoreCase(Constants.ORACLE)) {
			// Checking schema type
			if (schemaType.equals(Constants.VC) || schemaType.equals(Constants.HP)) {
					scriptFile = generateScriptToCreateHPandVCSchema();
			} else {
				if (getSchemaCreationMode().equals("Mixed")) {
					scriptFile = generateScriptToCreateSchemaForASM();
				} else {
					scriptFile = generateScriptToCreateSchema();
				}
			}
			sqlPlusUrl = OracleDBConnector.getTnsStyleUrl(getRunnerSchema());
			desc = "Create User: [" + schema.getServerGroupName() + "] "
					+ schema.getServerName() + ":" + schema.getPort() + "/"
					+ schema.getService() + "/" + (schemaTobeCreated);
			logger.info("Init oracle user create: " + desc);
			ls.add(new TaskTypeNFile(TaskType.CREATE_USER, scriptFile));
		}
    	//vertica schema creation
    	else if((schema.getHostingServer().equalsIgnoreCase(Constants.VERTICA)) || (schema.getHostingServer().equalsIgnoreCase(Constants.VERTICA_CMA)) )
    	{
    		scriptFile = (new NamingUtil()).getCreateUserFile(schema);
    		
    		desc = "Create Vertica User: [" +
	            schema.getServerGroupName() + "] " +
	            schema.getServerName() + ":" + schema.getPort();
	        logger.info("Init vertica user create: " + desc);
	        
	        TaskType taskType_VerticaSchemaCreation = (TaskType) TaskType.CREATE_USER.clone();
	        taskType_VerticaSchemaCreation.setTaskLabel(taskType_VerticaSchemaCreation.getTaskName()+ "(VERTICA)");
	        
	        ls.add( new TaskTypeNFile(taskType_VerticaSchemaCreation, scriptFile) );
    	}
    }
    
	/**
	 * 1. Checks whether the schema is history, warehouse or front schema
	 * 2. Validates schema accordingly
	 * 3. Final Schema name is placed in schemaTobeCreated variable
	 * @throws Exception
	 */
	public void setSchemaTobeCreated() throws Exception {
		Schema schema = getSchema();
		if (histSchema) {
			// Given Schema is History
			replData = NamingUtil.getReplacementDataForHistory(schema
					.getSchemaName());
			schemaTobeCreated = replData.getHawkeyeHist();

		} else if (schemaType.equals(Constants.WH)) {
			// Given Schema is WareHouseSchema,
			// checking if the schema is valid WH schema
			logger.info("Creating Warehouse schema>>>>>>"
					+ schema.getSchemaName());
			if (!NamingUtil.isValidWareHouseSchema(schema.getSchemaName())) {
				throw new IllegalArgumentException(
						"Not a valid wareHouse schema name: "
								+ schemaTobeCreated);
			} else {
				schemaTobeCreated = schema.getSchemaName();
			}
		} else if (schemaType.equals(Constants.HF)) {
			logger.info("Creating Processing schema>>>>>>"
					+ schema.getSchemaName());
			// Given Schema is Front Schema
			replData = NamingUtil.getReplacementDataBySchemaName(schema
					.getSchemaName());
			schemaTobeCreated = replData.getHawkeyeFront();
		} else if (schemaType.equals(Constants.VC)) {
			// Given Schema is VC Schema
			logger.info("Creating VC schema>>>>>>" + schema.getSchemaName());
			if (!NamingUtil.isValidVCSchema(schema.getSchemaName())) {
				throw new IllegalArgumentException(
						"Not a valid VC schema name: " + schemaTobeCreated);
			} else {
				schemaTobeCreated = schema.getSchemaName();
			}
		} else if (schemaType.equals(Constants.HP)) {
			// Given Schema is HP Schema
			logger.info("Creating HP schema>>>>>>" + schema.getSchemaName());
			if (!NamingUtil.isValidPreScrubName(schema.getSchemaName())) {
				throw new IllegalArgumentException(
						"Not a valid HP schema name: " + schemaTobeCreated);
			} else {
				schemaTobeCreated = schema.getSchemaName();
			}
		}
	}

	public List  getTaskTypeNFileList(){
        return ls;
    }

    String sqlPlusUrl;
    public String getSQLPlusUrl() {
        return sqlPlusUrl;
    }

    public SQLPlusRunnable setTaskType( TaskType tskType) {
        return this;
    }
}