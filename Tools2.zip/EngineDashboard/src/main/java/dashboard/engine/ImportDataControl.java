package dashboard.engine;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import dashboard.data.SourceControlUser;
import dashboard.util.CmdRunner;
import dashboard.util.EDBUtil;
import dashboard.util.EnvInfo;
import dashboard.util.ErrorOnDoubleQuote;
import dashboard.util.ErrorOnQuote;
import dashboard.util.KeyValue;

public class ImportDataControl {	
	
	private static final Pattern clientFolderPattern
    = Pattern.compile("HI0[0-9]{3}[^\\s-][\\w\\s-]*/",Pattern.CASE_INSENSITIVE);	
	
	public static boolean isDirectoryMounted(String srcMachine, String mountDir) throws Exception {		 	 
        String[] cmd = new String [] { "ls" , mountDir + srcMachine};   
        String outputstr = CmdRunner.invokeCommand(cmd).trim();
        boolean retval =false;
        if (!"".equals(outputstr)){
        	if (!(outputstr.indexOf("No such file or directory")>-1)){
        		retval = true;
        	}        	
        }
        return retval;            
    }
		
	/**
	 * Returns only file names only in the specified file path.
	 * 
	 * @param filepath
	 * @return
	 * @throws Exception
	 */
	public static List getDataFileList(File filepath) throws Exception {
		List retval = new LinkedList();					
		//String cmd =  "ls -l \""+ filepath.toString()+ "\" | grep ^[^d] | wc -l"; 
		String[] filelist = listDirectory(filepath).split("\n");
		
		for (int i=0; i<filelist.length; i++){			
			if (!filelist[i].endsWith(EDBUtil.fileseperator) && !"".equals(filelist[i].trim())){
				if (!(filelist[i].indexOf("No such file or directory")>-1)){
					retval.add(filelist[i]);
				}
			}
		}		
        return retval;            
    }
	
	/**
	 * Returns folder size.
	 * 
	 * @param filepath
	 * @return
	 * @throws Exception
	 */
	public static String getDirectorySize (File filepath) throws Exception {		
        String[] cmd = new String [] { "du" , "-sh", filepath.toString()}; 
        String retval = CmdRunner.invokeCommand(cmd).trim();  
        return retval;            
    }	
	
	/**
	 * Returns files and folders in the specified file path.
	 * @param filepath
	 * @return
	 * @throws Exception
	 */
	
    public static String listDirectory(File filepath) throws Exception {
        ErrorOnDoubleQuote.checkDoubleQuote( filepath.toString());
        ErrorOnQuote.checkQuote( filepath.toString());     
        String[] cmd = new String [] { "ls" ,"-F", filepath.toString()};        
        return CmdRunner.invokeCommand(cmd);            
    }
	
    
	public static String mountDirectory(SourceControlUser user,String srcMachine, String srcLocation, String mountDir) throws Exception {	
		String mountdir = mountDir + srcMachine;
		CmdRunner.invokeCommand("mkdir -p "+ mountdir);	 
		String	cmd = "mount -t smbfs -o username="+user.getUserName()+",password="+user.getPassword()+" "+"//"+srcMachine+srcLocation+" "+mountdir;
		//cmd = "mount "+srcMachine+":"+srcLocation+" "+mountdir;
        return CmdRunner.invokeCommand(cmd);            
    }
    
	/**
	 * Returns all directory name if specified folder pattern matches.
	 * 
	 * @param srcdirarray
	 * @return
	 * @throws Exception
	 */
    public static List getValidClientDirectory(String[] srcdirarray) throws Exception {
    	List filelst =  new LinkedList();   
    	
		for (int i=0; i<srcdirarray.length ; i++){
			Matcher m = clientFolderPattern.matcher(srcdirarray[i]);
			
			if (m.find()){
				filelst.add(new KeyValue().setKey(srcdirarray[i].substring(3,6)).setValue(srcdirarray[i]));				
			}					
		} 
        return filelst;            
    }
    
    /**
     * Returns directory name if client id and specified folder pattern matches.
     * 
     * @param srcdirarray
     * @param clientid
     * @return
     * @throws Exception
     */
    public static List getClientDirectory(String[] srcdirarray, String clientid) throws Exception {
    	List filelst =  new LinkedList();    	
    	for (int i=0; i<srcdirarray.length ; i++){
    		Matcher m = clientFolderPattern.matcher(srcdirarray[i]);
			if (m.find()){								
				//filelst.add(new KeyValue().setKey(srcdirarray[i].substring(3,6)).setValue(srcdirarray[i]));
				System.out.println(srcdirarray[i].substring(3,6)+":::");
				if ( srcdirarray[i].substring(3,6).equals(clientid)) {		
					filelst.clear();
					filelst.add(new KeyValue().setKey(srcdirarray[i].substring(3,6)).setValue(srcdirarray[i]));				
					break ; 
				}
			}
		}    	
        return filelst;            
    }
    
    public static List getAllDirectory(String[] srcdirarray) throws Exception {
    	List filelst =  new LinkedList();    	
    	for (int i=0; i<srcdirarray.length ; i++){			
				filelst.add(new KeyValue().setKey(srcdirarray[i]).setValue(srcdirarray[i]));	
		}    	        
        return filelst;            
    }   

}
