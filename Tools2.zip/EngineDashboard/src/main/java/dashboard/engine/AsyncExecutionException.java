package dashboard.engine;

public class AsyncExecutionException extends RuntimeException {
    public AsyncExecutionException(String msg) {
        super(msg);
    }

    public AsyncExecutionException(String msg, Throwable t) {
        super(msg, t);
    }

    public AsyncExecutionException(Throwable t) {
        super(t.getMessage(), t);
    }

}
