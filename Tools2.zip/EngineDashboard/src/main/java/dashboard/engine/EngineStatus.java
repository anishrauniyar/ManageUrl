package dashboard.engine;

public class EngineStatus {
    private static final String
        N_ERROR = "ERROR",
        N_INIT = "INIT",
        N_STARTED = "STARTED",
        N_SCRIPT_MODIFY = "SCRIPT_MODIFY",
        N_RUNNING = "RUNNING",
        N_COMPLETE = "COMPLETE";
    
    private EngineStatus() {}

    String status;
    private EngineStatus(String  st) {
        status = st;
    }
    public int hashCode() {
        return status.hashCode();
    }
    public boolean equals(Object obj) {
        return (obj instanceof EngineStatus) && this.hashCode() == obj.hashCode();
    }
    
    public static final EngineStatus FAILED = new EngineStatus(N_ERROR);
    public static final EngineStatus INIT = new EngineStatus(N_INIT);
    public static final EngineStatus STARTED = new EngineStatus(N_STARTED);
    public static final EngineStatus SCRIPT_MODIFY = new EngineStatus(N_SCRIPT_MODIFY);
    public static final EngineStatus RUNNING = new EngineStatus(N_RUNNING);
    public static final EngineStatus COMPLETE = new EngineStatus(N_COMPLETE);

    public String toString() {
        return status;
    }
}
