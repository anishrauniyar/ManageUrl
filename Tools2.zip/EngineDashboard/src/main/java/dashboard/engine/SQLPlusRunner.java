package dashboard.engine;

import java.io.File;
import java.io.InputStream;

import dashboard.ComponentFactory;

public class SQLPlusRunner {
    ComponentFactory compFactory;
    private String sqlPlus;
    StringBuffer sb;
    String execString = "";
    public SQLPlusRunner() {
        compFactory = ComponentFactory.getInstance();
        sqlPlus = compFactory.getEnvInfo().getValue("env.path.sqlplus");
        sb = new StringBuffer(30000);
    }
    public String getExecString() {
        return execString;
    }
    private int retVal = -1;
    
    public Integer getReturnValue() {
        return new Integer(retVal);
    }

    public void execute(String completeUrl, File f)  throws Exception {
        sb.delete(0, sb.length());
        InputStream is = null;
	    Runtime rt = Runtime.getRuntime();

        execString = sqlPlus + " -L " + completeUrl +  " @" + f.getAbsolutePath();
        System.out.println("EXEC STR: " + execString);
	    Process ps = rt.exec(execString);
        is = ps.getInputStream();
        int c = 0;
        try {
            while( (c=is.read()) != -1) {
                System.out.print((char)c);
                sb.append((char) c);
            }
        } finally {
            if (is != null) try { is.close(); } catch(Exception ex){}
        }
        
        retVal = ps.waitFor();
        System.out.println("process comp.." + retVal);
        ps = null;
    }

    
    public String getOutput() {
        return sb.toString();
    }

}
