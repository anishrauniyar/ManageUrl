package dashboard.engine;

import java.io.File;
import java.util.*;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.EngineReplacementData;
import dashboard.data.Schema;
import dashboard.db.FixedParameter;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;
import dashboard.util.FileUtil;
import dashboard.util.WareHouseParams;
import dashboard.web.pagecontroller.miniEngine.MiniEngine;

public class EngineConverter {

	private String engineSourceRoot = null;
	private String engineModules = null;
	private String objectScripts = null;
	private String reportScripts = null;
	private String indexScripts = null;

	private SqlFileFilter sqlFileFilter;
	private List emptyList;

	private EngineConverter() {
	}

	private ComponentFactory compFactory;
	private EnvInfo env;
	private FixedParameter fixedParam;

	protected Log logger = LogFactory.getLog(getClass());

	public EngineConverter(ComponentFactory compFact) {

		ComponentFactory compFactory = compFact;
		env = compFactory.getEnvInfo();
		fixedParam = compFactory.getFixedParameters();
		sqlFileFilter = new SqlFileFilter();
		emptyList = Collections.unmodifiableList(new ArrayList());
	}

	public static StringBuffer initStringBuffer() {
		StringBuffer sb = new StringBuffer(5000);
		sb.append("\nSET ECHO OFF;").append("\nSET FEED OFF;")
				.append("\nSET SQLBL ON;")
				.append("\nSET DEFINE OFF;\n")
				.append("\nSET SERVEROUTPUT ON SIZE UNLIMITED;\n");//SERVEROUTPUT SIZE CHANGED TO UNLIMITED
				//.append("\nSET SERVEROUTPUT ON SIZE 1000000;\n");
		return sb;
	}
	
	/**
	 * @return StringBuffer with SERVEROUTPUT Size UNLIMITED
	 */
	public static StringBuffer initStringBufferWithServerOutSizeUnLimited() {
		StringBuffer sb = new StringBuffer(5000);
		sb.append("\nSET ECHO OFF;").append("\nSET FEED OFF;")
				.append("\nSET SQLBL ON;\n")
				.append("\nSET SERVEROUTPUT ON SIZE UNLIMITED;\n");
		return sb;
	}

	public static StringBuffer addExit(StringBuffer sb) {
		sb.append("\nEXIT;").append("\n/\n");
		return sb;
	}

	public String getModifiedObjectScript(EngineReplacementData replData,
			String engVer, Schema schema) throws Exception {
		StringBuffer sb = initStringBuffer();

		File verObjectScriptDir = new File(env.getObjectScriptDir() + "/"
				+ engVer);

		sb = EngineUtil.appendSQLFiles(sb, verObjectScriptDir);
		sb = addExit(sb);
		String str = EngineUtil.findReplace(sb.toString(), replData, schema);
		return str;
	}

	/**
	 * @Description: Gets Compile Script for MI engine
	 * @param replData
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public String getModifiedEngineScript(EngineReplacementData replData,
			Schema schema) throws Exception {

		StringBuffer sb = initStringBuffer();

		File engineScriptDir = new File(env.getENGINE_DIR() + "/"
				+ schema.getEngineVersion());
		logger.debug("Engine Script ROOT Directory: "
				+ engineScriptDir.getAbsolutePath());
		/*// 1. merge object scripts
		if (engineScriptDir.isDirectory()) {
			File[] moduleFolders = engineScriptDir.listFiles();
			logger.debug("Modules folder count (considers .svn folder too :-s ): "
					+ moduleFolders.length);
			Arrays.sort(moduleFolders, new Comparator() {
				public int compare(Object o1, Object o2) {
					if (o1 != null && o2 != null && o1 instanceof File
							&& o2 instanceof File) {
						File f1 = (File) o1;
						File f2 = (File) o2;
						String name1 = f1.getName();
						String name2 = f2.getName();
						return name1.compareToIgnoreCase(name2);
					}
					return 0; // treat as equal for other types of objects.
				}

				public boolean equals(Object obj) {
					return false;
				}
			});

			logger.debug("\n----\nFound Modules\n------");
			for (int i = 0; i < moduleFolders.length; i++) {
				if (moduleFolders[i].isDirectory()) {
					File f = new File(moduleFolders[i].getAbsolutePath()
							+ "/ObjectScripts");
					if (f.exists()) {
						logger.debug(moduleFolders[i].getName());
						sb = EngineUtil.appendSQLFiles(sb, f);
					}
				}
			}

		} else {
			throw new IllegalArgumentException("Not a directory"
					+ engineScriptDir.getAbsolutePath());
		}

		// 2. merge engine modules
		if (engineScriptDir.isDirectory()) {
			File[] moduleFolders = engineScriptDir.listFiles();
			logger.debug("Modules folder count (considers .svn folder too :-s ): "
					+ moduleFolders.length);
			Arrays.sort(moduleFolders, new Comparator() {
				public int compare(Object o1, Object o2) {
					if (o1 != null && o2 != null && o1 instanceof File
							&& o2 instanceof File) {
						File f1 = (File) o1;
						File f2 = (File) o2;
						String name1 = f1.getName();
						String name2 = f2.getName();
						return name1.compareToIgnoreCase(name2);
					}
					return 0; // treat as equal for other types of objects.
				}

				public boolean equals(Object obj) {
					return false;
				}
			});

			logger.debug("\n----\nFound Modules\n------");
			for (int i = 0; i < moduleFolders.length; i++) {
				if (moduleFolders[i].isDirectory()) {
					File f = new File(moduleFolders[i].getAbsolutePath()
							+ "/EngineModules");
					if (f.exists()) {
						logger.debug(moduleFolders[i].getName());
						sb = EngineUtil.appendSQLFiles(sb, f);
					}
				}
			}

		} else {
			throw new IllegalArgumentException("Not a directory"
					+ engineScriptDir.getAbsolutePath());
		}*/

		sb = getCombinedScripts(engineScriptDir, "ENGINE",schema);
		sb = addCompileSchema(sb, schema.getSchemaName());
		sb = addExit(sb);
		String str = EngineUtil.findReplace(sb.toString(), replData, schema);
		return str;
	}

	/**
	 * @Description: For Mini Engine Compile Script
	 * @param replData
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public String getModifiedMiniEngineScript(EngineReplacementData replData,
			Schema VCSchema) throws Exception {

		StringBuffer sb = initStringBuffer();

		File miniEngineScriptDir = new File(env.getENGINE_DIR() + "/"
				+ VCSchema.getEngineVersion() + "/"
				+ env.getMINI_ENGINE_FOLDER());
		logger.debug("Mini Engine Script ROOT Directory: "
				+ miniEngineScriptDir.getAbsolutePath());
		sb = getCombinedScripts(miniEngineScriptDir, MiniEngine.MINI_ENGINE,
				VCSchema);
		sb = addCompileSchema(sb, VCSchema.getSchemaName());
		sb = addExit(sb);
		String str = EngineUtil.findReplace(sb.toString(), replData, VCSchema);
		return str;
	}
	
	/**
	 * @Description: Returns object scripts for scrub [HP & VC]
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public String getModifiedObjScriptForScrub(Schema schema,
			Map<String, Boolean> cdfObjScriptForHP) throws Exception {
		StringBuffer sb = initStringBuffer();
		File scrubDir = new File(env.getHP_MODULES_DIR() + "/"
				+ schema.getEngineVersion());
		if (schema.getSchemaName().startsWith(Constants.VC)) {
			scrubDir = new File(env.getVC_MODULES_DIR() + "/"
					+ schema.getEngineVersion());
		}
		logger.debug("Scrub ROOT Directory: " + scrubDir.getAbsolutePath());
		sb = getCombinedObjScriptForScrub(scrubDir);
		if (schema.getSchemaName().startsWith(Constants.HP)) {
			logger.info("Appending CDF Object Script for Scrub Schema "
					+ schema);
			File dir = env.getHP_VC_CLIENT_SPECIFIC_MODULES_DIR();
			sb.append(getModifiedScriptForScrub(schema, dir, cdfObjScriptForHP));
		}
		sb = addCompileSchema(sb, schema.getSchemaName());
		sb = addExit(sb);
		return sb.toString();
	}
	
	/**
	 * @Description : Simply combines the sql file from given file
	 * @param file
	 * @param scrubSchema
	 * @return
	 * @throws Exception
	 */
	public StringBuffer getCombinedObjScriptForScrub(File file) throws Exception {
		StringBuffer sb = initStringBuffer();
		sb = EngineUtil.appendSQLFiles(sb, file);
		return sb;
	}
	
	/**
	 * @Description : Get the client specific script for HP & VC
	 * @param schema
	 * @param sqlFileList
	 * @return
	 * @throws Exception
	 */
	public String getModifiedScriptForScrub(Schema schema,File dir,
			Map<String,Boolean> scripts) throws Exception {
		String fromDir = dir
				+ "/" + schema.getEngineVersion();
		//System.out.println("ClientSpecScriptDir : "+clientSpecScriptDir);
		List<File> fromList = getSQLFileNameList(fromDir);
		return getCombinedMatchedScript(fromList,
				scripts);
	}
	
	/**
	 * @Description : Checks if the file exists in SVN, and updates the value[boolean] of scripts
	 * @param schema : Schema information [Engine Version is only used]
	 * @param dir : Directory in which scripts existence is to be checked.
	 * @param scripts : Script [File name] with default existence as false [does not exists]
	 * @return scripts with updated existence
	 * @throws Exception
	 */
	public Map<String, Boolean> updateFileExistence(Schema schema,File dir,
			Map<String, Boolean> scripts) throws Exception {
		String fromDir = dir
				+ "/" + schema.getEngineVersion();
		List<File> fromList = getSQLFileNameList(fromDir);
		for (Map.Entry<String, Boolean> entry : scripts.entrySet()) {
			String toBeSearchedSQLFileName = entry.getKey();
			for (File sqlFile : fromList) {
				if (sqlFile.getName().equalsIgnoreCase(toBeSearchedSQLFileName)) {
					scripts.put(toBeSearchedSQLFileName, true);
					break;
				}
			}
		}
		return scripts;
	}
	
	/**
	 * @Description: Combines sql script from sqlFileList if they are present in
	 *               fromList of dir
	 * @param dir
	 * @param fromList
	 * @param sqlFileList
	 * @return
	 * @throws Exception
	 */
	private String getCombinedMatchedScript(List<File> fromList,
			Map<String,Boolean> clientSpecificSQLScripts) throws Exception {
		StringBuffer sb = initStringBuffer();
		for (Map.Entry<String, Boolean> entry : clientSpecificSQLScripts.entrySet()) {
			String toBeSearchedSQLFileName = entry.getKey();
			for (File sqlFile : fromList) {
				if (sqlFile.getName().equalsIgnoreCase(toBeSearchedSQLFileName)) {
					//System.out.println(">>File " + sqlFile + " found!!");
					sb = EngineUtil.appendFile(sb, sqlFile);
					break;
				}
			}
		}
		sb = addExit(sb);
		return sb.toString();
	}

	/**
	 * @Description: Combines all the sql content of Files file from
	 *               ObjectScripts and EngineModules Directory
	 * @param file
	 * @param forWhat
	 * @return
	 * @throws Exception
	 */
	public StringBuffer getCombinedScripts(File file, String forWhat,
			Schema schema) throws Exception {
		StringBuffer sb = initStringBuffer();
		File miniEngineObjScriptFile = null;
		File miniEngineEngModFile = null;
		if (forWhat.equalsIgnoreCase(MiniEngine.MINI_ENGINE)) {
			miniEngineObjScriptFile = new File(env.getENGINE_DIR() + "/"
					+ schema.getEngineVersion() + "/"
					+ env.getMINI_ENGINE_FOLDER() + "/ObjectScripts");
			miniEngineEngModFile = new File(env.getENGINE_DIR() + "/"
					+ schema.getEngineVersion() + "/"
					+ env.getMINI_ENGINE_FOLDER() + "/EngineModules");
		}

		// 1. merge object scripts
		if (file.isDirectory()) {
			File[] moduleFolders = file.listFiles();
			logger.debug("Modules folder count (considers .svn folder too :-s ) for "
					+ forWhat + " : " + moduleFolders.length);
			Arrays.sort(moduleFolders, new Comparator<File>() {
				public int compare(File f1, File f2) {
					if (f1 != null && f2 != null) {
						String name1 = f1.getName();
						String name2 = f2.getName();
						return name1.compareToIgnoreCase(name2);
					}
					return 0; // treat as equal for other types of objects.
				}

				public boolean equals(Object obj) {
					return false;
				}
			});

			logger.debug("\n----\nFound Modules for " + forWhat + "\n------");
			for (int i = 0; i < moduleFolders.length; i++) {
				if (moduleFolders[i].isDirectory()) {
					File f = null;
					if (forWhat.equalsIgnoreCase(MiniEngine.MINI_ENGINE)) {
						// for Mini Engine ObjectScripts
						f = new File(moduleFolders[i].getAbsolutePath());
						if (miniEngineObjScriptFile.equals(f)) {
							if (f.exists()) {
								logger.debug(moduleFolders[i].getName());
								sb = EngineUtil.appendSQLFiles(sb, f);
							}
						}
					} else {
						// for MI Engine
						f = new File(moduleFolders[i].getAbsolutePath()
								+ "/ObjectScripts");
						if (f.exists()) {
							logger.debug(moduleFolders[i].getName());
							sb = EngineUtil.appendSQLFiles(sb, f);
						}
					}
				}
			}

		} else {
			throw new IllegalArgumentException("Not a directory"
					+ file.getAbsolutePath());
		}

		// 2. merge engine modules
		if (file.isDirectory()) {
			File[] moduleFolders = file.listFiles();
			logger.debug("Modules folder count (considers .svn folder too :-s ) for "
					+ forWhat + " : " + moduleFolders.length);
			Arrays.sort(moduleFolders, new Comparator<File>() {
				public int compare(File f1, File f2) {
					if (f1 != null && f2 != null) {
						String name1 = f1.getName();
						String name2 = f2.getName();
						return name1.compareToIgnoreCase(name2);
					}
					return 0; // treat as equal for other types of objects.
				}

				public boolean equals(Object obj) {
					return false;
				}
			});

			logger.debug("\n----\nFound Modules for " + forWhat + "\n------");
			for (int i = 0; i < moduleFolders.length; i++) {
				if (moduleFolders[i].isDirectory()) {
					File f = null;
					if (forWhat.equalsIgnoreCase(MiniEngine.MINI_ENGINE)) {
						// for Mini Engine EngineScripts
						f = new File(moduleFolders[i].getAbsolutePath());
						if (miniEngineEngModFile.equals(f)) {
							if (f.exists()) {
								//System.out.println("Engine Module>>>>>>>>>>>>>>"+moduleFolders[i].getAbsolutePath());
								logger.debug(moduleFolders[i].getName());
								sb = EngineUtil.appendSQLFiles(sb, f);
							}
						}
					} else {
						// for MI Engine
						f = new File(moduleFolders[i].getAbsolutePath()
								+ "/EngineModules");
						if (f.exists()) {
							logger.debug(moduleFolders[i].getName());
							sb = EngineUtil.appendSQLFiles(sb, f);
						}
					}
				}
			}

		} else {
			throw new IllegalArgumentException("Not a directory"
					+ file.getAbsolutePath());
		}

		return sb;
	}

	public static StringBuffer addCompileSchema(StringBuffer sb,
			String schemaName) {
		sb.append("\n BEGIN \n").append("dbms_utility.compile_schema('")
				.append(schemaName).append("'); ").append("\nEND; \n/");
		return sb;
	}

	/**
	 * @Description: For MI Engine Execution
	 * @param replData
	 * @param runDQE
	 * @param degOfParallel
	 * @param parallel
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public String getRunEngineScript(EngineReplacementData replData,
			boolean runDQE, int degOfParallel, String parallel, Schema schema)
			throws Exception {
		StringBuffer sb = initStringBuffer();
		sb = defineDegOfParallelismForEngine(sb, runDQE, degOfParallel,
				parallel);
		sb = addExit(sb);
		String str = EngineUtil.findReplace(sb.toString(), replData, schema);
		return str;
	}

	/**
	 * @Description: For Mini Engine Execution [MRE]
	 * @param replData
	 * @param degOfParallel
	 * @param parallel
	 * @param schema
	 * @return
	 * @throws Exception
	 */
	public String getRunMiniEngineScript(EngineReplacementData replData,
			int degOfParallel, String parallel, Schema VCSchema,
			Schema histSchema) throws Exception {
		StringBuffer sb = initStringBuffer();
		sb = defineDegOfParallelismForMiniEngine(sb, degOfParallel, parallel,
				VCSchema, histSchema);
		sb = addExit(sb);
		String str = EngineUtil.findReplace(sb.toString(), replData, VCSchema);
		return str;
	}

	private static final int MAX_PARALLEL = 10;

	private StringBuffer defineDegOfParallelismForEngine(StringBuffer sb,
			boolean runDQE, int degOfParallel, String parallel) {
		StringBuffer bufferRun = new StringBuffer(300);
		bufferRun.append("\n-----------------------")
				.append("\n-- RUNNIN IN PARALLEL ")
				.append("\n----------------------").append("\nBEGIN")
				.append("\n   sp_ProcessEngine( ");
		if (runDQE) {
			bufferRun.append("'Y'");
		} else {
			bufferRun.append("'N'");
		}
		bufferRun.append(",");
		if (degOfParallel > 0 && degOfParallel < MAX_PARALLEL) {
			bufferRun.append(degOfParallel);
		} else {
			bufferRun.append("4");
		}
		if (parallel != null) {
			bufferRun.append(",");
			bufferRun.append("'" + parallel + "'");
		}
		bufferRun.append(");").append("\nEND;\n/\n");

		return sb.append(bufferRun.toString());
	}

	/**
	 * @Description: Generates Script for Mini Engine Execution
	 * @param sb
	 * @param runDQE
	 * @param degOfParallel
	 * @param parallel
	 * @return
	 */
	private StringBuffer defineDegOfParallelismForMiniEngine(StringBuffer sb,
			int degOfParallel, String parallel, Schema VCSchema,
			Schema histSchema) {
		StringBuffer bufferRun = new StringBuffer(300);
		bufferRun.append("\n-----------------------")
				.append("\n-- RUN IN PARALLEL ")
				.append("\n----------------------").append("\nBEGIN")
				.append("\n   sp_ProcessMiniEngine( ");
		if (degOfParallel > 0 && degOfParallel < MAX_PARALLEL) {
			bufferRun.append(degOfParallel);
		} else {
			bufferRun.append("4");
		}
		bufferRun.append(",'").append(histSchema.getServerName()).append("'")
				.append(",'").append(histSchema.getPort()).append("'")
				.append(",'").append(histSchema.getService()).append("'");
		if (parallel != null) {
			bufferRun.append(",");
			bufferRun.append("'" + parallel + "'");
		}
		bufferRun.append(");").append("\nEND;\n/\n");

		return sb.append(bufferRun.toString());
	}

	public String getRunIndexScript(int threadCount) {
		StringBuffer sb = initStringBuffer();
		sb = sb.append("\n-----------------------\n").append("\nBEGIN")
				.append("\n   SP_EXECMVNDX(" + threadCount + ");")
				.append("\nEND;").append("\n/\n");

		sb = addExit(sb);
		return sb.toString();
	}

	public String getCreatePreScrubUserScript(Schema schema) {
		StringBuffer sb = initStringBuffer();

		sb.append("\n-- creating pre-scrub user\n").append("\nBEGIN")
				.append("\n  DBMS_OUTPUT.PUT_LINE('Creating user.....');")
				.append("\n  sys.SP_CREATEUSRNTBLSPC('")
				.append(schema.getSchemaName()).append("'");
		if (!"".equals(schema.getSchemaPwd())) {
			sb.append(",'").append(schema.getSchemaPwd()).append("'");
		}
		sb.append(");")
				.append("\n  DBMS_OUTPUT.PUT_LINE('User created.');")
				.append("\nEND;")
				.append("\n/")
				.append("\nBEGIN")
				.append("\n  DBMS_OUTPUT.PUT_LINE('Granting rights.....');")
				.append("\n  sys.SP_GRANTUSER('" + schema.getSchemaName()
						+ "');")
				.append("\n DBMS_OUTPUT.PUT_LINE('Rights granted.');")
				.append("\nEND;").append("\n/\n");
		sb = addExit(sb);
		return sb.toString();
	}

	public String getModifiedReportScript(String sourceDir,
			EngineReplacementData replData, String[] reports, Schema schema)
			throws Exception {
		if (reports == null || reports.length <= 0) {
			return "";
		}
		File reportDir = new File(sourceDir);

		Set clientReports = new TreeSet(getReportFileNameList(sourceDir));
		Set specifiedReports = new TreeSet(Arrays.asList(reports));
		Set reportsSet = new TreeSet(new FileNameComparator());
		Iterator it = specifiedReports.iterator();
		while (it.hasNext()) {
			String repoFileName = (String) it.next();
			if (clientReports.contains(repoFileName)) {
				reportsSet.add(repoFileName);
			}
		}

		StringBuffer sb = initStringBuffer();
		Iterator itF = reportsSet.iterator();
		while (itF.hasNext()) {
			String fileName = (String) itF.next();
			File flToAdd = new File(reportDir, fileName);
			sb = EngineUtil.appendFile(sb, flToAdd);
		}
		sb = addExit(sb);
		if (null == replData)
			return sb.toString();

		String str = EngineUtil.findReplace(sb.toString(), replData, schema);
		return str;
	}

	public String getModifiedWHScript(Schema schema) throws Exception {
		String _WHDir = env.getWH_SCRIPTS_DIR().getAbsolutePath() + "/"
				+ schema.getEngineVersion();
		// System.out.println("<<<<<<<<<<<<<<<<<<<<<WAREHOUSE DIRECTORY IS :>>>>>>>>>>>>>>>>>>>>>>>>"+_WHDir);
		List ls = getWHEngineFileNameList(_WHDir);// all files
		String whCompileScripts = fixedParam
				.getWHParam(WareHouseParams.WH_COMPILE_SCRIPT);
		String[] toBeCompiledScripts = whCompileScripts.split(",");
		StringBuffer sb = initStringBuffer();
		Iterator it = ls.iterator();
		while (it.hasNext()) {
			String fileName = (String) it.next();
			for (String script : toBeCompiledScripts) {
				if (fileName.equalsIgnoreCase(script)) {
					System.out.println(">>>>>>>>>>>>>>>>>>>>>>>File " + script
							+ " found");
					File flToAdd = new File(_WHDir, fileName);
					sb = EngineUtil.appendFile(sb, flToAdd);
				}
			}
		}
		sb = addExit(sb);
		return sb.toString();
	}

	public List getReportFileNameList(String _reportDir) throws Exception {
		File reportDir = new File(_reportDir);

		if (reportDir.exists() && reportDir.isDirectory()) {
			// System.out.println("abs path: " + reportDir.getAbsolutePath());
			File[] sqlFiles = reportDir.listFiles(sqlFileFilter);
			Arrays.sort(sqlFiles, new FileNameComparator());

			if (sqlFiles.length <= 0) {
				return emptyList;
			}
			List ls = new LinkedList();
			for (int i = 0; i < sqlFiles.length; i++) {
				ls.add(sqlFiles[i].getName());
			}
			return ls;
		}
		return emptyList;
	}

	public List getWHEngineFileNameList(String _WHDir) throws Exception {
		File WHDir = new File(_WHDir);

		if (WHDir.exists() && WHDir.isDirectory()) {
			// System.out.println("abs path: " + reportDir.getAbsolutePath());
			File[] sqlFiles = WHDir.listFiles(sqlFileFilter);
			Arrays.sort(sqlFiles, new FileNameComparator());

			if (sqlFiles.length <= 0) {
				return emptyList;
			}
			List ls = new LinkedList();
			for (int i = 0; i < sqlFiles.length; i++) {
				ls.add(sqlFiles[i].getName());
			}
			return ls;
		}
		return emptyList;
	}
	
	/**
	 * @Description: Returns SQL file list from the given directory [includes sub directory]
	 * @param _dir
	 * @return
	 * @throws Exception
	 */
	public List<File> getSQLFileNameList(String _dir) throws Exception {
		File dir = new File(_dir);
		List<File> ls = new ArrayList<>();
		logger.info("<<Main Directory Client Spec Mod>>" + dir);
		if (dir.exists() && dir.isDirectory()) {
			/**
			 * Combining SQL File Name from _dir [Main Directory]
			 */
			File[] sqlFiles = dir.listFiles(sqlFileFilter);
			Arrays.sort(sqlFiles, new FileNameComparator());
			/*if (sqlFiles.length <= 0) {
				return ls;
			}*/
			for (int i = 0; i < sqlFiles.length; i++) {
				logger.info("<<<<Main Directory SQL File>>>>"
						+ sqlFiles[i]);
				ls.add(sqlFiles[i]);
			}
			/**
			 * Combining SQL File Names from subDirectory [Ignoring .svn directory]
			 */
			File[] moduleFolders = dir.listFiles();
			for (int i = 0; i < moduleFolders.length; i++) {
				if (moduleFolders[i].isDirectory()
						&& !moduleFolders[i].getName().equalsIgnoreCase(
								Constants.SVN_FOLDER)) {
					File subDir = new File(moduleFolders[i].getAbsolutePath());
					if (subDir.exists() && subDir.isDirectory()) {
						logger.info("<<Sub Directory>>" + subDir);
						File subSQLFiles[] = subDir.listFiles(sqlFileFilter);
						Arrays.sort(subSQLFiles, new FileNameComparator());
						for (int j = 0; j < subSQLFiles.length; j++) {
							logger.info("<<<<Sub Dir SQL Files>>>> "
									+ subSQLFiles[j]);
							ls.add(subSQLFiles[j]);
						}
					}
				}
			}
		}
		return ls;
	}

	public static String getClientId(String schemaName) {
		if (schemaName == null || "".equals(schemaName.trim())) {
			throw new IllegalArgumentException("Null or blank schema name");
		}
		String scName = schemaName.trim();
		if (scName.length() < 6) {
			throw new IllegalArgumentException(
					"Schema name is less than 6 characters long.");
		}
		return scName.substring(3, 6);
	}

	public String getModifiedImportScript(String replacementData,
			String fileAbsolutePath) throws Exception {
		String vPathRegex = "vPath\\s+(VARCHAR).+[0-9].+\\s*(:=)?.*";
		String basevPath = "vPath VARCHAR2(1024) := ";
		String replacingData = basevPath + "'" + replacementData + "';";
		StringBuffer sb = initStringBuffer();
		File _file = new File(fileAbsolutePath);
		sb = FileUtil.readText(_file);

		sb = sb.delete(sb.lastIndexOf("END;"), sb.length());
		sb = sb.append("\nEND;").append("\n/");

		sb = addExit(sb);
		String retVal = (Pattern.compile(vPathRegex, Pattern.CASE_INSENSITIVE)
				.matcher(sb.toString()).replaceAll(replacingData));

		return retVal;
	}

	public String getScrubScript(String fileAbsolutePath) throws Exception {
		StringBuffer sb = initStringBuffer();
		File _file = new File(fileAbsolutePath);
		sb = FileUtil.readText(_file);

		sb = sb.delete(sb.lastIndexOf("END;"), sb.length());
		sb = sb.append("\nEND;").append("\n/");

		sb = addExit(sb);
		return sb.toString();
	}

	public static void main(String[] args) throws Exception {
		System.out.println("id: " + getClientId("HF0001"));
		java.util.regex.Pattern p = java.util.regex.Pattern
				.compile("\\(BPM\\)$");
		System.out.println(" found " + p.matcher("abdla(BPM)").find());
	}

}