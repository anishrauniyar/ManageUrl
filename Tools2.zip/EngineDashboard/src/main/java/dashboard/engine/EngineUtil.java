package dashboard.engine;

import java.io.File;
import java.io.FileReader;
import java.io.Writer;
import java.io.FileWriter;
import java.util.Comparator;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.util.Calendar;
import java.util.Date;

import dashboard.data.Schema;
import dashboard.data.EngineReplacementData;

public class EngineUtil {

    public static  File getTempFile(Schema schema, String workDir) throws Exception {
        File fWorkDir = new File(workDir);
        StringBuffer sb = new StringBuffer(50);
        sb.append("H").append(schema.getServerName()).append("_")
            .append( schema.getPort()).append("_")
            .append( schema.getService())
            .append( schema.getSchemaName());
        String flNameWithoutDot = sb.toString().replace('.','_');
        return new File(fWorkDir, flNameWithoutDot + ".en_");
    }

    public static String replaceCaseInsensitive(String source, String fromString, String toString) {
        if ("".equals(toString)) {
            return source;
        }
        return Pattern.compile(fromString, Pattern.CASE_INSENSITIVE)
            .matcher(source).replaceAll(toString);            
    }
    
    /**
     * replace for case Sensitive
     * @param source
     * @param fromString
     * @param toString
     * @return
     */
    public static String replaceCaseSensitive(String source, String fromString, String toString) {
        if ("".equals(toString)) {
            return source;
        }
        return Pattern.compile(fromString, Pattern.CANON_EQ)
            .matcher(source).replaceAll(toString);            
    }

    public static String findReplace(String sourceString, EngineReplacementData replData, Schema schema) {
            String modifiedString = replaceCaseInsensitive(sourceString,
                                                           "HawkeyePreScrub", replData.getHawkeyePreScrub());
            modifiedString = replaceCaseInsensitive(modifiedString,
                                                    "HawkeyeScrub", replData.getHawkeyeScrub());
            modifiedString = replaceCaseInsensitive(modifiedString,
                                                    "HawkeyeFront", replData.getHawkeyeFront());
            modifiedString = replaceCaseInsensitive(modifiedString,
                                                    "HawkeyeCode", replData.getHawkeyeCode());
            /**
             * <p>lthjqa</p> used as hardcoded in dxcg service call object script which is encrypted version
             * of <p>oracle</p>. 
             * <p>lthjqa</p> is replaced by encrypted password entered while processing
             */
            if(schema.getEncodePassword() != null && !"".equalsIgnoreCase(schema.getEncodePassword())){
            	modifiedString = replaceCaseSensitive(modifiedString, "lthjqa",schema.getEncodePassword());
            }
            if(replData.getSchema() != null){
	            if(!"".equalsIgnoreCase(replData.getSchema().getSchemaName())){
	            	modifiedString = replaceCaseInsensitive(modifiedString,
	                                                    "HawkeyeHist", replData.getSchema().getSchemaName());
	            }else{
	            	modifiedString = replaceCaseInsensitive(modifiedString, "HawkeyeHist", replData.getHawkeyeHist());
	            }
            }else{
            	modifiedString = replaceCaseInsensitive(modifiedString, "HawkeyeHist", replData.getHawkeyeHist());
            }
            String diffServer = replData.getDiffServer();
            if("Y".equalsIgnoreCase(diffServer)){
	            modifiedString = replaceCaseInsensitive(modifiedString, "HAWKEYEPASSHIST", replData.getSchema().getSchemaPwd());
	            
	            modifiedString = replaceCaseInsensitive(modifiedString, "HAWKEYESERVERHIST", replData.getSchema().getServerName());
	            
	            modifiedString = replaceCaseInsensitive(modifiedString, "HAWKEYEPORTHIST", replData.getSchema().getPort());
	            
	            modifiedString = replaceCaseInsensitive(modifiedString, "HAWKEYESIDHIST", replData.getSchema().getService());
	            
	            modifiedString = replaceCaseInsensitive(modifiedString, "HAWKEYECENTHIST", replData.getDiffServer());
            }
            
            if(!"".equals(replData.getHawkeyeMaster())){
	            modifiedString = replaceCaseInsensitive(modifiedString,
                    				    "HawkeyeMaster(\\d*)", replData.getHawkeyeMaster());
            }
            if(!"".equals(replData.getHawkeyeQRM())){
	            modifiedString = replaceCaseInsensitive(modifiedString,
			    			    		"HawkeyeQRM(\\d*)", replData.getHawkeyeQRM());
            }
            
            return modifiedString;
    }
    public static StringBuffer appendSQLFiles(StringBuffer sb, File f) throws Exception {
        if (f.isDirectory()) {
            File [] files = f.listFiles(new SqlFileFilter());
            Arrays.sort( files,
                         new Comparator() {
                             public int compare(Object  o1, Object o2) {
                                 if (o1 != null && o2 != null && o1 instanceof File && o2 instanceof File) {
                                     File f1 = (File) o1;
                                     File f2 = (File) o2;
                                     String name1 = f1.getName();
                                     String name2 = f2.getName();
                                     return name1.compareToIgnoreCase(name2); 
                                 }
                                 return 0; //treat as equal for other types of objects.
                             }
                             public boolean equals(Object obj) {
                                 return false;
                             }
                         });
                                        
            for(int i=0; i<files.length; i++) {
            	//System.out.println("File>>>>>>>>>>>>>>>>>>"+files[i].getAbsolutePath());
                sb = appendFile(sb, files[i]);
            }
        } else {
            throw new IllegalArgumentException("Not a directory" + f.getAbsolutePath());
        }
        return sb;
    }
    public static StringBuffer appendFile(StringBuffer sb, File f) throws Exception {
        FileReader fr = null;
        try {
            fr = new FileReader(f);
            char [] content = new char[ (int) f.length()];
            int readSize = fr.read(content, 0, content.length);
            sb.append("---------------------------------\n");
            sb.append("----- Filename : [" + f.getName() + "]\n");
            sb.append("---------------------------------\n\n");

            sb.append(content);

            sb.append("\n-----------------------------------\n");
            sb.append("---- END FILE\n");
            sb.append("-----------------------------------\n");
        } finally {
            if (fr != null) {
                try { fr.close(); } catch(Exception ex) {}
            }
        }
        return sb;
    }
    public static void writeBatchQueryToFile(File tempFile, String query) throws Exception {
        Writer tempFileWriter = null;
        try {
            tempFileWriter = new FileWriter( tempFile);
            tempFileWriter.write(query);
            tempFileWriter.close();
            tempFileWriter = null;
        } finally {
            tempFileWriter = null;
        }
    }
}
