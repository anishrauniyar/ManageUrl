package dashboard.engine;

public interface ScriptFetcher {
    public String [] fetchPreScrub(String clId) throws Exception;
}
