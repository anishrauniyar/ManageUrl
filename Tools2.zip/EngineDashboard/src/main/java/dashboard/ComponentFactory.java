package dashboard;


import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.springframework.context.ApplicationContext;

import dashboard.db.DRTransferDB;
import dashboard.db.EngineMonitorDB;
import dashboard.db.FixedParameter;
import dashboard.db.OracleServerInfo;
import dashboard.engine.AsyncSQLProcessRegistry;
import dashboard.engine.EngineConverter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.engine.ScriptFetcher;
import dashboard.engine.SourceControl;
import dashboard.engine.TaskType;
import dashboard.engine.oracle.EngineMonitorOrcl;
import dashboard.quartz.DashboardJobScheduler;
import dashboard.util.EnvInfo;
import dashboard.web.pagecontroller.PageControllerMap;
import dashboard.web.util.Dispatcher;
import dashboard.web.util.UriResolver;
import dashboard.web.view.ViewMap;


/**
 * Factory class responsible for creating objects.
 * Hides the use of Spring Frameworks.
 */
public class ComponentFactory {
    private static ComponentFactory _this = null;

    ApplicationContext springContext = null;
    AsyncSQLProcessRegistry asyncRegistry = null;
    
    private ComponentFactory () {
    }

    /**
     * Can be initialzed only once.
     * @param Spring context
     * @return instance of self
     */
    public ComponentFactory init(ApplicationContext ctx) {
        System.out.println("\n--------------------\nINIT called...");
        if ( springContext == null) {
            springContext = ctx;
            engineConverter = new EngineConverter(this);
            engineMonitorDB = new EngineMonitorDB();
            dashboardJobScheduler = new DashboardJobScheduler();
            asyncRegistry = new AsyncSQLProcessRegistry(this);
        } else {
            throw new IllegalArgumentException("Context already set.");
        }
        return _this;
    }        

    public static ComponentFactory getInstance() {
        if (_this == null) {
            _this = new ComponentFactory();
        }
        return _this;
    }
    public UriResolver getUriResolver() {
        return (UriResolver) springContext.getBean("uriResolver");
    }
    public ViewMap getViewMap() {
        return (ViewMap) springContext.getBean("viewMap");
    }
    public Dispatcher getDispatcher() {
        return (Dispatcher) springContext.getBean("dispatcher");
    }
    public PageControllerMap getPageControllerMap() {
        return (PageControllerMap) springContext.getBean("pageControllerMap");
    }

    public EnvInfo getEnvInfo() {
        return (EnvInfo) springContext.getBean("envInfo");
    }
    EngineConverter engineConverter;    
    public EngineConverter getEngineConverter() {
        return engineConverter;
    }
    
    EngineMonitorDB engineMonitorDB;
    public EngineMonitorDB getEngineMonitorDB() {
        return engineMonitorDB;
    }
    
    DashboardJobScheduler dashboardJobScheduler;
    public DashboardJobScheduler getDashboardJobScheduler() {
    	return dashboardJobScheduler;
    }
    
    public AsyncSQLProcessRegistry getAsyncSQLProcessRegistry() {
        return asyncRegistry;
    }

    public EngineMonitor getEngineMonitor(String user) {
        EngineMonitorOrcl engineMonitor =  (new EngineMonitorOrcl()).setCurrentUser(user)
            .setEngineMonitorDB(  (EngineMonitorDB) springContext.getBean("engineMonitorDB"));
        return engineMonitor;
    }
    private static final String SYSTEM_USER =  "<SYSTEM>";
    public EngineMonitor getEngineMonitorForSystem() {
        return getEngineMonitor(SYSTEM_USER);
    }
    public EventLogger getEventLogger() {
        return (EventLogger) springContext.getBean("eventLogger");
    }
    
    public FixedParameter getFixedParameters(){
    	return (FixedParameter) springContext.getBean("fixedParam");
    }
    
    public DRTransferDB getDRTransferDB()
    {
    	return (DRTransferDB) springContext.getBean("drTransferDB");
    }

    public SourceControl getSourceControl() {
        return (SourceControl) springContext.getBean("sourceControl");
    }

    public ScriptFetcher getScriptFetcher() {
        return (ScriptFetcher) springContext.getBean("scriptFetcher");
    }
    
    public Map getErrorTableMap() {
        return Collections.unmodifiableMap((Map) springContext.getBean("errorTables"));
    }

    private Map taskLogMap = null;

    public Map getTaskLogMap() {
        HashMap h = null;
        if ( taskLogMap == null) {
            h = new HashMap();
            Map errTblMap = getErrorTableMap();
            Iterator it = errTblMap.keySet().iterator();
            while(it.hasNext()) {
                String logName = (String) it.next();
                if ( TaskType.isDefinedTaskId(logName)) {
                    TaskType tskType = TaskType.getTask(logName);
                    h.put( tskType.toString(), logName);
                }
            }
            taskLogMap = h;
        }
        return taskLogMap;
    }

	public Object getBean(String beanName){
    	return springContext.getBean(beanName);
    }

    public OracleServerInfo getOracleServerInfo () {
       	return (OracleServerInfo) springContext.getBean("oracleserverinfo");
    }
}

