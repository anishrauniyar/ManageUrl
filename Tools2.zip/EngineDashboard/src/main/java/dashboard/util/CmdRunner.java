package dashboard.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


public class CmdRunner {
	public static String invokeCommand(String cmd) throws Exception{
		return invokeCommand(cmd,false);
	} 
	
	/**
     * The method used for running list of commands in remote 
     * server and it will wait until command 
     * execution completes. </p>
     * Remote server should be Linux/Unix.
     * </p>
     * 
     * @param isDmENVer
     *            true only for testing connection between dmexpress server and vertica server, else false
     * @param serverName
     *            serverName or IP of remote server
     * @param userName
     *            userName to connect server
     * @param passWord
     *            password to connect server
     * @param commands
     *            List of commands thats needs to execute
     * @param privateKey
     *            privatekey if password less authentication enabled. Leave value
     *            to null or blank, if password less authentication is not
     *            enabled or not needed
     * @return output of commands
     * @throws Exception
     */
     public static String runCommandsOnShell(boolean isDmENVer, String servername,
                 String username, String password, List<String> commands,
                 String privateKey) throws Exception {
           StringBuffer sb = new StringBuffer();
           InputStream is = null;
           Channel channel = null;
           Session session = null;
           try {
                 java.util.Properties config = new java.util.Properties();
                 config.put("StrictHostKeyChecking", "no");
                 JSch jsch = new JSch();
                 if (privateKey != null && !privateKey.equals("")) {
                       jsch.addIdentity(privateKey);
                 }
                 session = jsch.getSession(username, servername, 22);
                 session.setPassword(password);
                 session.setConfig(config);
                 session.setConfig("PreferredAuthentications",
                             "publickey,keyboard-interactive,password");
                 session.connect();
                 channel = session.openChannel("shell");
                 OutputStream outPutStream = channel.getOutputStream();
                 PrintStream commander = new PrintStream(outPutStream, true);
                 channel.setOutputStream(System.out, true);
                 channel.connect();
                 for (String command : commands) {
                       commander.println(command);
                 }
                 is = channel.getInputStream();
                 if (isDmENVer) {
                       Thread.sleep(3000);
                       commander.println("quit");
                       Thread.sleep(3000);
                       commander.println("exit");
                       Thread.sleep(3000);
                 }
                 commander.println("exit");
                 commander.close();
                 byte[] tmp = new byte[1024];
                 while (true) {
                       while (is.available() > 0) {
                             int i = is.read(tmp, 0, 1024);
                             if (i < 0)
                                   break;
                             sb.append(new StringBuffer(new String(tmp, 0, i)));
                       }
                       if (channel.isClosed()) {
                             if (is.available() > 0)
                                   continue;
                             break;
                       }
                       Thread.sleep(3000);
                 }

           } catch (Exception e) {
                 throw e;
           } finally {
                 if (is != null) {
                       is.close();
                 }
                 if (channel != null) {
                       channel.disconnect();
                 }
                 if (session != null) {
                       session.disconnect();
                 }
           }
           return sb.toString();
     }
     
	
  
	public static boolean isRemoteProcessRunning(String servername,
			String username, String password, String privateKey,
			String processID) throws Exception {
		InputStream is = null;
		Session session = null;
		ChannelExec channel = null;
		String outPut = "";
		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			if (privateKey != null && !privateKey.equals("")) {
				jsch.addIdentity(privateKey);
			}
			session = jsch.getSession(username, servername, 22);
			session.setPassword(password);
			session.setConfig(config);
			Properties preferredAuth = new Properties();
			preferredAuth.put("PreferredAuthentications", "publickey");
			preferredAuth.put("PreferredAuthentications", "password");
			session.setConfig(preferredAuth);
			session.connect();
			channel = (ChannelExec) session.openChannel("exec");
			channel.setCommand("[ -d \"/proc/"
					+ processID
					+ "\" ] && echo \" PROCESS FOUND \" || echo \"PROCESS NOT FOUND\"");
			channel.setOutputStream(System.out, true);
			is = channel.getInputStream();
			channel.connect();
			byte[] tmp = new byte[1024];
			while (true) {
				while (is.available() > 0) {
					int i = is.read(tmp, 0, 1024);
					if (i < 0)
						break;
					outPut += new String(tmp, 0, i);
				}
				if (channel.isClosed()) {
					if (is.available() > 0)
						continue;
					break;
				}
				Thread.sleep(1000);
			}

		} catch (Exception e) {
			throw e;
		} finally {
			if (is != null) {
				is.close();
			}
			if (session != null) {
				session.disconnect();
			}
			if (channel != null) {
				channel.disconnect();
			}
		}
		return outPut.contains("PROCESS FOUND");
	}
    public static String invokeCommand(String cmd, boolean returnImmediate)
        throws Exception {
        
        Log logger = LogFactory.getLog(dashboard.util.CmdRunner.class);
        //logger.info("Requested cmd: " + cmd);

        int result;
		StringBuffer err=new StringBuffer(300);
		StringBuffer out=new StringBuffer(300);
        Runtime rt = Runtime.getRuntime();        
        Process ps = null;        

        try {
            ps = rt.exec(cmd);

		    StreamReaderThread outThread=new StreamReaderThread(ps.getInputStream(),out);
		    StreamReaderThread errThread=new StreamReaderThread(ps.getErrorStream(),err);
		    outThread.start();
		    errThread.start();
            
		    result=ps.waitFor();
            

		    	outThread.join(1000*5);
		    	errThread.join(1000*1);
		    /*}
		    else{
		    	outThread.join();
		    	outThread.join();
		    }*/
		    

		    if (result!=0) {
				logger.info("Process  returned non-zero value:"+result);
			}else{
				logger.info("Process   executed successfully");
			}
			//logger.info("Output for cmd: " + cmd + ">>[" + out.toString()+"]");
			//logger.info("Error for cmd: " + cmd + ">>[" + err.toString()+"]");
        } catch(Exception ex) {
            err.append( ex.getMessage());
            logger.info("Exception cmd: " + cmd, ex);
            StringWriter sw = new StringWriter(300);
            ex.printStackTrace( new PrintWriter(sw));
            
            err.append( "\n")
                .append(sw.toString());
            if ( null != ps ) {
                try {
                    ps.destroy();
                }catch (Exception procEx) {
                    err.append("\n" + procEx.getMessage());
                }
            }
        } finally {
            try {}catch(Exception ex) {}
            ps = null;
        }
        return out.toString()+err.toString();
    }
    

	public static String invokeCommand(String[] cmd) throws Exception{
		return invokeCommand(cmd,false);
	}
	
	public static String invokeCommand(String[] cmd, boolean returnImmediate)
    throws Exception {    
	    Log logger = LogFactory.getLog(dashboard.util.CmdRunner.class);
	    //logger.info("Requested cmd: " + cmd);
	
	    int result;
		StringBuffer err=new StringBuffer(300);
		StringBuffer out=new StringBuffer(300);
	    Runtime rt = Runtime.getRuntime();        
	    Process ps = null;        
	
	    try {
	        ps = rt.exec(cmd);
	
		    StreamReaderThread outThread=new StreamReaderThread(ps.getInputStream(),out);
		    StreamReaderThread errThread=new StreamReaderThread(ps.getErrorStream(),err);
		    outThread.start();
		    errThread.start();
	        
		    result=ps.waitFor();
	        
	
		    	outThread.join(1000*5);
		    	errThread.join(1000*1);
		    /*}
		    else{
		    	outThread.join();
		    	outThread.join();
		    }*/
		    
	
		    if (result!=0) {
				logger.info("Process  returned non-zero value:"+result);
			}else{
				logger.info("Process   executed successfully");
			}
			//logger.info("Output for cmd: " + cmd + ">>[" + out.toString()+"]");
			//logger.info("Error for cmd: " + cmd + ">>[" + err.toString()+"]");
	    } catch(Exception ex) {
	        err.append( ex.getMessage());
	        //logger.info("Exception cmd: " + cmd, ex);
	        StringWriter sw = new StringWriter(300);
	        ex.printStackTrace( new PrintWriter(sw));
	        
	        err.append( "\n")
	            .append(sw.toString());
	        if ( null != ps ) {
	            try {
	                ps.destroy();
	            }catch (Exception procEx) {
	                err.append("\n" + procEx.getMessage());
	            }
	        }
	    } finally {
	        try {}catch(Exception ex) {}
	        ps = null;
	    }
	    return out.toString()+err.toString();
	}
	
	public static void main (String[] args) throws Exception
	{
		System.out.println("is process running >> " + CmdRunner.isRemoteProcessRunning("qc-oam", "qcoam", "nepal@qcoam", "","27421"));
	}
	
}
