package dashboard.util;

public interface QCConstants {

	/**
	 * FQC Constants. Note: Must be same as the parameter name for FQC Extract
	 * parameters, case sensitive
	 */
	String FQC_EXTRACT = "FQC_EXTRACT";
	String FQC_SERVER = "FQC_SERVER";
	String FQC_SCHEMA = "FQC_SCHEMA";
	String FQC_SCHEMA_PWD = "FQC_SCHEMA_PWD";
	String FQC_PORT = "FQC_PORT";
	String FQC_SERVICE = "FQC_SERVICE";
	String FQC_PROCESSING_MODE = "FQC_PROCESSING_MODE";
}
