package dashboard.util;

import java.io.File;

public class DirectoryCleaner {

    private static final int WIN_PLATFORM = 0;
    private static final int NIX_PLATFORM = 1;
    private static  int PLATFORM = 
        System.getProperty("os.name").toLowerCase().startsWith("win")? WIN_PLATFORM : NIX_PLATFORM;


    private static final String RD_WIN_CMD = "cmd /c rd /S /Q ";
    private static final String RD_NIX_CMD = "rm -rf ";
    //private static final String WIN_ATTRIB = "attrib -r -h -s /s ";

    public static String remove(String  dir) throws Exception {
        String retVal = "";
        String dirPath = dir;
        if (dirPath.endsWith("/") || dirPath.endsWith("\\") ) {
            dirPath = dirPath.substring(0, dirPath.length() -1);
        }
        File dirF = new File( dirPath);
        switch(PLATFORM) {
        case WIN_PLATFORM:
            retVal = CmdRunner.invokeCommand( RD_WIN_CMD + " " + dirF.getAbsolutePath() + " ");
            break;
        default:
            retVal = CmdRunner.invokeCommand( RD_NIX_CMD + " " + dirPath + " ");
        }
        return retVal;
    }


}
