package dashboard.util;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ErrorOnDoubleQuote {
    private static final Pattern quotePattern
        = Pattern.compile("\"",Pattern.CASE_INSENSITIVE);

    public static boolean containsDoubleQuote(String s) {
        if (null == s)
            return false;
        return quotePattern.matcher(s).find();
    }

    public static void checkDoubleQuote(String s) {
        if ( containsDoubleQuote(s)) {
            throw new IllegalArgumentException("Double Quote encounted in : " + s);
        }
    }
}
