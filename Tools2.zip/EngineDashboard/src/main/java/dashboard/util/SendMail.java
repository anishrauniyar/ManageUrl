package dashboard.util;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.db.FixedParameter;

public class SendMail
{
    private String           host           = "";
    private boolean          enableMailSend = false;
    private boolean          msgSend        = false;
    private ComponentFactory compFactory;
    private FixedParameter   fixedParam;
    
    private Log              logger         = LogFactory.getLog(getClass());
    
    public SendMail() throws Exception
    {
        
        compFactory = ComponentFactory.getInstance();
        fixedParam = compFactory.getFixedParameters();
        
        String tempSmtpAdd = fixedParam.getDashboardParams(SendMailConstants.SMTP_HOST_ADDRESS);
        if (tempSmtpAdd == null || tempSmtpAdd.trim().equals(""))
            tempSmtpAdd = SendMailConstants.TEMP_SMTP_ADDRESS;
        
        boolean tempIsEnableMailSend = (fixedParam.getDashboardParams(SendMailConstants.ENABLE_MAIL_SEND) != null && fixedParam.getDashboardParams(
                SendMailConstants.ENABLE_MAIL_SEND).equalsIgnoreCase("true")) ? true : false;
        this.setHost(tempSmtpAdd);
        this.setEnableMailSend(tempIsEnableMailSend);
        
        System.out.println(" Sending Email:: using SendEmail class " + "\n Send email  Enabled " + this.isEnableMailSend() + "\n host "
                + this.getHost());
    }
    
    /**
     * @Description : Gets the TO and CC lists
     * @param from
     * @param msgSubject
     * @param msgText
     * @return
     * @throws Exception 
     */
    public boolean send(String from, String msgSubject, String msgText) throws Exception
    {
        /**
         * Getting ToLists and CCLists
         */
        Set<String> toList = null;
        Set<String> ccList = null;
        
        String toArray[] = null;
        String ccArray[] = null;
        
        String to = fixedParam.getDashboardParams(SendMailConstants.EDB_TO_RECEPIENTS);
        String cc = fixedParam.getDashboardParams(SendMailConstants.EDB_CC_RECEPIENTS);
        
        if (!to.equalsIgnoreCase(""))
        {
            toArray = to.split(",");
        }
        if (!cc.equalsIgnoreCase(""))
        {
            ccArray = cc.split(",");
        }
        
        if (toArray != null)
        {
            toList = new HashSet<String>(Arrays.asList(toArray));
        }
        if (ccArray != null)
        {
            ccList = new HashSet<String>(Arrays.asList(ccArray));
        }
        
        return send(from, toList, ccList, msgSubject, msgText);
    }
    
    /**
     * @Description : Method used to send mail
     * @param from
     * @param toList
     * @param ccList
     * @param msgSubject
     * @param msgText
     * @return
     */
    public boolean send(String from, Set<String> toList, Set<String> ccList, String msgSubject, String msgText)
    {
        if (!isEnableMailSend())
        {
            System.out.println(" Mail send is disabled ");
            return false;
        }
        if (toList == null || toList.isEmpty())
        {
            System.out.println("To List not found !!!!!");
            return false;
        }
        
        msgSend = false;
        Properties props = new Properties();
        props.put("mail.smtp.host", this.getHost());
        props.put("mail.transport.protocol", "smtp");
        
        Session session = Session.getDefaultInstance(props, null);
        
        try
        {
            InternetAddress[] finalToList = new InternetAddress[toList.size()];
            int i = 0;
            for (String to : toList)
            {
                finalToList[i] = new InternetAddress(to);
                i++;
            }
            
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipients(Message.RecipientType.TO, finalToList);
            
            if (ccList != null && !ccList.isEmpty())
            {
                InternetAddress[] finalCCList = new InternetAddress[ccList.size()];
                int j = 0;
                for (String cc : ccList)
                {
                    finalCCList[j] = new InternetAddress(cc);
                    j++;
                }
                msg.setRecipients(Message.RecipientType.CC, finalCCList);
            }
            
            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            Transport.send(msg);
            msgSend = true;
        } catch (Exception e)
        {
            logger.error("Error on SendMail.java(1)->send(from,toList,ccList,msgSubject,msgText", e);
            e.printStackTrace();
        }
        
        return msgSend;
    }
    
    public String getHost()
    {
        return host;
    }
    
    public void setHost(String host)
    {
        this.host = host;
    }
    
    public boolean isEnableMailSend()
    {
        return enableMailSend;
    }
    
    public void setEnableMailSend(boolean enableMailSend)
    {
        this.enableMailSend = enableMailSend;
    }
}
