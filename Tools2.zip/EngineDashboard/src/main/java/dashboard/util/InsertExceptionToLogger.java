package dashboard.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.logging.Log;

public class InsertExceptionToLogger {

	private final static int CAPACITY = 1000;

	public InsertExceptionToLogger() {
	}

	/*public static void insert(Exception e, Log logger) {
		StringWriter sw = new StringWriter(CAPACITY);
		e.printStackTrace(new PrintWriter(sw));
		logger.error(sw);
	}*/
	
	public static StringWriter insert(Exception e, Log logger) {
		StringWriter sw = new StringWriter(CAPACITY);
		e.printStackTrace(new PrintWriter(sw));
		logger.error(sw);
		
		return sw;
	}

}
