package dashboard.util;
public class KeyValue {
    
        private String
            key = "",
            value = "";
        
        
        public String getKey() {
	    return key;
	}
        public String getValue() {
	    return value;
	}
        
	public KeyValue setKey(String key) {
	    if(key!= null) {
		this.key = key.trim();
            }
            return this;
	}
	
	public KeyValue setValue(String value) {
	    if(value!= null) {
		this.value = value.trim();
            }
            return this;
	}
}
