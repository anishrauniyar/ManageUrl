package dashboard.util;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ErrorOnQuote {
    private static final Pattern quotePattern
        = Pattern.compile("'",Pattern.CASE_INSENSITIVE);

    public static boolean containsQuote(String s) {
        if (null == s)
            return false;
        return quotePattern.matcher(s).find();
    }

    public static void checkQuote(String s) {
        if ( containsQuote(s)) {
            throw new IllegalArgumentException("Quote encounted in : " + s);
        }
    }
}
