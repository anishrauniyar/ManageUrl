package dashboard.util;

public class Constants {

	// hosting server
	public static final String ORACLE = "ORACLE";
	public static final String VERTICA = "VERTICA";
	public static final String VERTICA_CMA = "VERTICA_CMA";
	public static final String VERTICA_DR_CMA = "VERTICA_DR_CMA";
	public static final String DMEXPRESS = "DMEXPRESS";
	public static final String ORACLE_BA = "ORACLE_BA";
	public static final String ORACLE_BA_CMA = "ORACLE_BA_CMA";
	public static final String ORACLE_DR_BA_CMA = "ORACLE_DR_BA_CMA";

	// tabs
	public static final String SERVER_ADMIN = "SERVER_ADMIN";
	public static final String DATA_TRANSFER = "DATA_TRANSFER";
	public static final String SCHEMA_ADMIN = "SCHEMA_ADMIN";

	public static final String O2V_DMEXPRESS_EVENT = "Data Transfer (VERTICA)";
	public static final String O2V_DMEXPRESS_BA_EVENT = "Data Transfer (ORACLE_BA)";
	public static final String O2V_CMA_EVENT = "Data Transfer (VERTICA_CMA)";
	public static final String O2V_DR_CMA_EVENT = "Data Transfer (VERTICA_DR_CMA)";
	public static final String O2V_CMA_BA_EVENT = "Data Transfer (ORACLE_BA_CMA)";
	public static final String O2V_DR_CMA_BA_EVENT = "Data Transfer (ORACLE_DR_BA_CMA)";

	/*
	 * VERTICA DATA TRANSFER PARAMS
	 */
	// Source Oracle Server Params
	public static final String OS_USERNAME = "OS_UserName";
	public static final String OS_PASSWORD = "OS_Password";
	public static final String OS_SHFILELOCATION = "OS_ShFileLocation";
	public static final String OS_SHFILENAME = "OS_ShFileName";

	// Destination Vertica Server Params
	public static final String VS_USERNAME = "VS_UserName";
	public static final String VS_PASSWORD = "VS_Password";
	public static final String VS_SHFILELOCATION = "VS_ShFileLocation";
	public static final String VS_SHFILENAME = "VS_ShFileName";
	// public static final String VS_DBNAME = "VS_DbName";
	public static final String VS_ADMINNAME = "VS_AdminName";
	public static final String VS_ADMINPWD = "VS_AdminPassword";
	// public static final String VS_NEWPWD = "VS_NewPassword"; user defined
	// password is used
	public static final String PRIVATE_KEY = "Private_Key";

	// Dmexpress Server Params
	public static final String DME_USERNAME = "DME_UserName";
	public static final String DME_PASSWORD = "DME_Password";

	// Central Server Params
	public static final String CS_HOST = "CS_Host";
	public static final String CS_PORT = "CS_Port";
	public static final String CS_PASSWORD = "CS_Port";
	public static final String CS_SERVICE = "CS_Service";
	public static final String CS_SCHEMA = "CS_Schema";
	public static final String CS_SCHEMAPWD = "CS_SchemaPwd";

	// Shell Script Params for Source Oracle Server and Dashboard Server
	public static final String SHELLSCRIPT_OUTPUTLOCATION = "ShellScript_OutPutLocation";
	public static final String SHELLSCRIPT_FILEPREFIX = "ShellScript_FilePrefix";

	// Execution Mode for Oracle to Vertica Data Transfer
	public static final String O2V_EXECUTIONMODE = "O2V_ExecutionMode";

	// process id pattern in shell output
	public static final String PROCESS_ID_PATTERN = "PROCESS ID:\\d*";
	public static final String PROCESS_ID_SPLITTER = ":";

	// cma batch id pattern in shell output
	public static final String CMA_BATCH_ID_PATTERN = "Batch ID.*:.*\\d*";

	// CMA api schema pwd
	public static final String CMA_API_SCHEMA_PWD = "Cma_Api_Schema_Pwd";

	// cma batch id
	public static final String CMA_BATCH_ID = "CMA_BATCH_ID";

	// retranfer table name
	public static final String RETRANSFER_TBLNAME = "RETRANSFER_TBLNAME";

	// fixedparamter table for dmexpress
	public static final String FIXEDPARAMETERS_DMX = "FIXEDPARAMETERS";
	// fixedparamter table for cma
	public static final String FIXEDPARAMETERS_CMA = "FIXEDPARAMETERS_CMA";

	public static final String HF = "HF";
	public static final String WH = "WH";
	public static final String HP = "HP";
	public static final String VC = "VC";
	public static final String DEFAULT_SCHEMA_PWD = "oracle";

	public static final String READ_ONLY = "READ ONLY";

	// this value is used in ReportDB.java
	public static String REPORT_CONFIG_TBL = "REPORTCONFIG";

	public static String VERSION_CONTROL_EVENT = "Version Control";

	/**
	 * Server Categories
	 */
	public static String PROCESSING_SERVER = "PROCESSINGSERVER";
	public static String HISTORY_SERVER = "HISTORYSERVER";
	public static String ORACLE_DR_SERVER = "ORACLEDRSERVER";
	public static String VERTICA_SERVER = "VERTICASERVER";
	public static String VERTICA_DR_SERVER = "VERTICADRSERVER";
	public static String DMEXPRESS_SERVER = "DMEXPRESSSERVER";

	public static String TRUE = "TRUE";
	public static String FALSE = "FALSE";

	public static String SVN_FOLDER = ".svn";

	public static String DEFAULT_SERVICE_NAME = "D2HE";
        public static String EMPTY_STRING = "";

}
