package dashboard.util;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;


public class FileUtil {
    public static StringBuffer readText(StringBuffer sb, File f) throws Exception {
        FileReader fr = null;
        try {
            fr = new FileReader(f);
            char [] content = new char[ (int) f.length()];
            int readSize = fr.read(content, 0, content.length);
            sb.append(content);
        } finally {
            if (fr != null) {
                try { fr.close(); } catch(Exception ex) {}
            }
        }
        return sb;
    }

    public static StringBuffer readText(File f) throws Exception {
        return  readText(new StringBuffer(), f);
    }

    public static void writeToTextFile(String s, File f) throws Exception {
        FileWriter fw = null;
        try {
            fw = new FileWriter(f);
            fw.write(s);
        } finally {
            if (fw != null) {
                try {
                    fw.close();
                } catch(Exception ex) {}
            }
        }
    }

    public static boolean deleteFile(File f) throws Exception {
        Log logger = LogFactory.getLog(dashboard.util.FileUtil.class);
        boolean status = false;
        if ( null == f)
            return false;
        if (! f.exists()) {
            return false;
        }

        if (isSymbolicLink( f)) {
            status = f.delete();
            logger.info("Delete " + f.getAbsolutePath() + ":" + status);
            return true;
        } else if (f.isDirectory()) {
            File [] files = f.listFiles();
            for(int i=0; i < files.length; i++) {
                deleteFile(files[i]);
            }
        }

        status = f.delete();
        logger.info("Delete " + f.getAbsolutePath() + ":" + status);
        
        return true;
    }

    public static boolean isSymbolicLink(File f)
        throws Exception {
        File canonicalDir = f.getCanonicalFile();
        File absoluteFile = f.getAbsoluteFile();
        if ( canonicalDir.equals(absoluteFile)) {
            return true;
        }
        return false;
    }
        
    public static boolean clearDirectory(File f) throws Exception {
        if ( null == f || ! f.exists() || !f.isDirectory()) {
            return false;
        }
        File [] files = f.listFiles();
        for(int i=0; i<files.length; i++) {
            deleteFile( files[i]);
        }
        return true;
    }
    
    
    /**
     * The method used to check file in remote server is exits or not
     * </p>
     * Remote server should be Linux/Unix.
     * </p>
     * 
     * @param serverName
     *            serverName or IP of remote server
     * @param userName
     *            userName to connect server
     * @param passWord
     *            password to connect server
     * @param privateKey
     *            private key if password less authentication enabled. Leave value
     *            to null or blank, if password less authentication is not
     *            enabled or not needed
     * @return <code>true</code> if file exits otherwise <code> false </code>
     * @throws Exception
     */
    
   public static boolean isRemoteFileExists(String servername,
    		   String username, String password, String privatekey,
    		   String filepath, String filename) throws Exception {
    		  Session session = null;
    		  Channel channel = null;
    		  ChannelSftp channelSftp = null;
    		  try {
    		   Properties config = new Properties();
    		   config.put("StrictHostKeyChecking", "no");
    		   config.put("PreferredAuthentications",
    		     "publickey,keyboard-interactive,password");
    		   JSch jsch = new JSch();
    		   if (privatekey != null && !privatekey.equals("")) {
    		    jsch.addIdentity(privatekey);
    		   }
    		   session = jsch.getSession(username, servername, 22);
    		   session.setPassword(password);
    		   session.setConfig(config);
    		   session.connect();
    		   channel = session.openChannel("sftp");
    		   channel.connect();
    		   channelSftp = (ChannelSftp) channel;
    		   channelSftp.stat(filepath + "/" + filename);
    		   return true;
    		  } catch (SftpException e) {
    		   if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
    		    return false;
    		   }
    		   throw e;
    		  } catch (Exception e) {
    		   throw e;
    		  } finally {
    		   if (channel != null) {
    		    channel.disconnect();
    		   }
    		   if (session != null) {
    		    session.disconnect();
    		   }
    		  }

    		 }
    
    

}
