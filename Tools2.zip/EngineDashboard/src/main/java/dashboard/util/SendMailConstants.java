package dashboard.util;

public interface SendMailConstants
{
    String SMTP_HOST_ADDRESS = "smtpHostAddress";
    String TEMP_SMTP_ADDRESS = "smtpnj.d2hawkeye.net";
    String ENABLE_MAIL_SEND  = "enableMailSend";
    String EDB_TO_RECEPIENTS = "edbToEmailRecepients";
    String EDB_CC_RECEPIENTS = "edbCCEmailRecepients"; 
            
}
