package dashboard.util;

import java.io.File;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.RollingFileAppender;


public class EnvInfo {
    private String Heuser;
	private String Heuserqc;
    private Map map = null;
    private Properties envProp;
    private String prefix;
    private static final String LOG_FILE = "logfile";

    private String SQL_PLUS;
    private String SVN_CLIENT;

    private static final String REPORT_CONFIG_TBL_KEY = "reportConfigTbl";
    private String REPORT_CONFIG_TBL = "reportconfig";
    public String getREPORT_CONFIG_TBL() {
		return REPORT_CONFIG_TBL;
	}
    private static final String MINI_ENGINE_FOLDER_KEY = "miniEngine.folder";
    private String MINI_ENGINE_FOLDER = "000_0_MiniEngine";
    public String getMINI_ENGINE_FOLDER() {
		return MINI_ENGINE_FOLDER;
	}

	File SOURCE_DIR;
    File OBJECT_SCRIPTS_DIR;
    File ENGINE_MODULES_DIR;
    File ENGINE_DIR;
    File SCRUB_OBJECT_SCRIPT_DIR;
    File TEMP_DIR;
    File IMPORT_SCRIPTS_DIR;
    File SCRUB_SCRIPTS_DIR;
    File WH_SCRIPTS_DIR;
	/**
	 * JIRA: VITTOOLS-384
	 */
	File HP_MODULES_DIR;
	File VC_MODULES_DIR;
	File HP_VC_CLIENT_SPECIFIC_MODULES_DIR;
    
    public EnvInfo() {
        map = new HashMap();
    }


    public String appVersion = null;
    public boolean isVersionDefined() {
        return null != appVersion;
    }
    public String getAppVersion() {
        return appVersion;
    }
    
    public String dashboardVersion = null;
    public String getDashboardVersion() {
		return dashboardVersion;
	}
    
	private static final String APP_VERSION_KEY = "app.version";
    private static final String DASHBOARD_VERSION_KEY = "dashboard.version";
    
	public void setProperty(Properties prop) throws Exception {
        envProp = prop;
        prefix = System.getProperty("os.name").toLowerCase().startsWith("win")? "windows.": "linux.";
        int len = prefix.length();

        for( Enumeration enumKey = envProp.propertyNames(); enumKey.hasMoreElements(); ) {
            String key = (String) enumKey.nextElement();
            if (key.startsWith(prefix)) {
                String keyEff = key.substring(len);
                String propEff = prop.getProperty(key);
                System.out.println("MAP... " + keyEff + " --> " + propEff);
                map.put(keyEff, propEff);
            }
        }

        if (containsKey(LOG_FILE)) {
            Logger logger = Logger.getRootLogger();

            Appender fileAppender = logger.getAppender(LOG_FILE);

            if(fileAppender != null && fileAppender instanceof RollingFileAppender ) {
                RollingFileAppender appender = (RollingFileAppender) fileAppender;
                appender.setFile( getValue(LOG_FILE));
                appender.activateOptions();
                System.out.println("\n-----------------\nAppender reset to: " + getValue(LOG_FILE) );
            }
        }

        SOURCE_DIR = new File (getValue("engine.source.dir"));
        OBJECT_SCRIPTS_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.ObjectScripts"));
        ENGINE_MODULES_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.EngineModules"));
        ENGINE_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.Engine"));
        SCRUB_OBJECT_SCRIPT_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.ScrubObjects"));
        TEMP_DIR = new File(getValue("work.temp.dir"));
        
        IMPORT_SCRIPTS_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.ImportScripts"));
        SCRUB_SCRIPTS_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.ScrubScripts"));
        WH_SCRIPTS_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.WareHouseScripts"));
        HP_MODULES_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.HPModules"));
        VC_MODULES_DIR = new File(SOURCE_DIR, getValue("engine.source.dir.VCModules"));
        HP_VC_CLIENT_SPECIFIC_MODULES_DIR= new File(SOURCE_DIR, getValue("engine.source.dir.HPandVCClientSpecificModules"));
        
        
        SQL_PLUS = getValue("env.path.sqlplus");
        SVN_CLIENT = getValue("env.path.svn");
        
        if (envProp.containsKey(APP_VERSION_KEY)) {
            String version = envProp.getProperty(APP_VERSION_KEY);
            if (version != null && !"".equals(version.trim())) {
                appVersion = version.trim();
            }
        }
        if (envProp.containsKey(DASHBOARD_VERSION_KEY)) {
            String dbVersion = envProp.getProperty(DASHBOARD_VERSION_KEY);
            if (dbVersion != null && !"".equals(dbVersion.trim())) {
                dashboardVersion = dbVersion.trim();
            }
        }
        if (envProp.containsKey(REPORT_CONFIG_TBL_KEY)) {
            String reportConfigTbl = envProp.getProperty(REPORT_CONFIG_TBL_KEY);
            if (null != reportConfigTbl && !"".equals( reportConfigTbl.trim())) {
            	REPORT_CONFIG_TBL =  reportConfigTbl.trim();
            	Constants.REPORT_CONFIG_TBL = REPORT_CONFIG_TBL;
            }
        }
        if (envProp.containsKey(MINI_ENGINE_FOLDER_KEY)) {
            String miniEngineFolder = envProp.getProperty(MINI_ENGINE_FOLDER_KEY);
            if (null != miniEngineFolder && !"".equals( miniEngineFolder.trim())) {
            	MINI_ENGINE_FOLDER =  miniEngineFolder.trim();
            }
        }
    }
    
    public String getValue( String key) {
        if(!containsKey(key)) {
            throw new IllegalArgumentException("Unknow environment key: " + key);
        }
        return (String) map.get( key);
    }
    public boolean containsKey(String key) {
        return map.containsKey( key);
    }

    public File getSourceDir() {
        return SOURCE_DIR;
    }
    public File getObjectScriptDir() {
        return OBJECT_SCRIPTS_DIR;
    }
    public File getEngineModulesDir() {
        return ENGINE_MODULES_DIR;
    }

    public File getScrubObjectScriptDir() {
        return SCRUB_OBJECT_SCRIPT_DIR;
    }

    public File getENGINE_DIR() {
        return ENGINE_DIR;
    }

    public void setENGINE_DIR(File ENGINE_DIR) {
        this.ENGINE_DIR = ENGINE_DIR;
    }

    public File getTempDir() {
        return TEMP_DIR;
    }
    public String getSqlPlusPath() {
        return SQL_PLUS;
    }

    public String getSVN() {
        return SVN_CLIENT;
    }
        
    public String getHeuser() {
		return Heuser;
	}
	public void setHeuser(String heuser) {
		this.Heuser = heuser;
	}
	public String getHeuserqc() {
		return Heuserqc;
	}
	public void setHeuserqc(String heuserqc) {
		this.Heuserqc = heuserqc;
	}	
	public File getIMPORT_SCRIPTS_DIR() {
		return IMPORT_SCRIPTS_DIR;
	}
	public File getSCRUB_SCRIPTS_DIR() {
		return SCRUB_SCRIPTS_DIR;
	}
	public File getWH_SCRIPTS_DIR() {
		return WH_SCRIPTS_DIR;
	}
	public File getHP_MODULES_DIR() {
		return HP_MODULES_DIR;
	}
	public File getVC_MODULES_DIR() {
		return VC_MODULES_DIR;
	}
	public File getHP_VC_CLIENT_SPECIFIC_MODULES_DIR() {
		return HP_VC_CLIENT_SPECIFIC_MODULES_DIR;
	}
}
