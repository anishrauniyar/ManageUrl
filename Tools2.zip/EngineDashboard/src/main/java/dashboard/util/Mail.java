package dashboard.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.data.Schema;
import dashboard.db.OracleDBConnector;

public class Mail {

	protected Log logger = LogFactory.getLog(getClass());

	/**
	 ****************** CALLS SEND_MAIL PROCEDURE BY CONNECTING THE GIVEN SCHEMA ****************
	 *
	 * @param schema
	 * @param loginName
	 * @param event (only 2 and 3)
	 * @param startTime
	 * @param endTime
	 * @param error
	 * @param from
	 * @param to
	 * @throws Exception
	 */
	public void sendMail(Schema schema, String loginName, String event,
			Date startTime, Date endTime, String error, String from, String to)
			throws Exception {
		Connection cnn = null;
		CallableStatement cs = null;

		String sql = "{CALL UTILITY.SEND_MAIL(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

		try {
			cnn = (new OracleDBConnector()).getConnectionForSchema(schema);
			cs = cnn.prepareCall(sql);
			cs.setString(1, event);// event id
			cs.setString(2, schema.getClientName()); // client Name
			cs.setString(3, ""); // App Name
			cs.setString(4, ""); // App Id
			cs.setString(5, schema.getSchemaName()); // Schema Name
			cs.setString(6, startTime.toString());// StartTime
			cs.setString(7, endTime.toString());// EndTime
			cs.setString(8, Mail.getDateDifferenceInHours(startTime, endTime)+"( HRS )");// TotalTime
			cs.setString(9, error);// error
			cs.setString(10, "");// errorMessage
			cs.setString(11, "");// extHtmlmsg
			cs.setString(12, "");// total_modules
			cs.setString(13, "");// total_processed
			cs.setString(14, from);// from
			cs.setString(15, to);// to
			cs.setString(16, "");// dop

			cs.executeUpdate();

			logger.info("Mail send successfully with event id "+event+" for schema "+schema.getSchemaName());

		} finally {
			if (cs != null) {
				cs.close();
			}
			if (cnn != null) {
				cnn.close();
			}
		}
	}
	
	public static String getDateDifferenceInHours(Date startTime, Date endTime){
		
		long diff = endTime.getTime() - startTime.getTime();
		double diffMinutes =(double) (diff / (60 * 1000) % 60 )  / 60; //in terms of hours 
		double finalMinutes = Math.round(diffMinutes * 100.0) / 100.0; //simply rounding 
		double diffHours = diff / (60 * 60 * 1000 )  + finalMinutes;
		
		return String.valueOf(diffHours);
	}

	public static void main(String[] args) throws Exception {
		Schema schema = new Schema();
		schema.setServerName("nvoamdbd2");
		schema.setSchemaName("PROCESSING");
		schema.setClientName("Test Client");
		schema.setPort("1521");
		schema.setService("d2he");
		schema.setSchemaPwd("aic7psUfmu");

		Mail mail = new Mail();
		mail.sendMail(schema, "binshakya", "3", new Date(), new Date(),
				"This is error message", "this is from", "this is to");

	}
}
