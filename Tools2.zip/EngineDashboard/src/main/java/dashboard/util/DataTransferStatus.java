package dashboard.util;
import java.io.*;
import java.util.StringTokenizer;
public class DataTransferStatus {
	
	private String sourceServer;
	private String destServer;
	private String[] sourceFileName;
	private String[] destFileName;	
	private int completed=0;
	private long totalSourceSize=0;
	private long totalDestinationSize=0;
	private long[] sourceFileSize;
	private long[] destinationFileSize;
	
	public long[] getDestinationFileSize() {
		return destinationFileSize;
	}

	public void setDestinationFileSize(long[] destinationFileSize) {
		this.destinationFileSize = destinationFileSize;
	}

	public long[] getSourceFileSize() {
		return sourceFileSize;
	}

	public void setSourceFileSize(long[] sourceFileSize) {
		this.sourceFileSize = sourceFileSize;
	}

	public String[] getDestFileName() {
		return destFileName;
	}

	public void setDestFileName(String[] destFileName) {
		this.destFileName = destFileName;
	}

	public String[] getSourceFileName() {
		return sourceFileName;
	}

	public void setSourceFileName(String[] sourceFileName) {
		this.sourceFileName = sourceFileName;
	}

	public long getTotalDestinationSize() {
		return totalDestinationSize;
	}

	public void setTotalDestinationSize(long totalDestinationSize) {
		this.totalDestinationSize = totalDestinationSize;
	}

	public long getTotalSourceSize() {
		return totalSourceSize;
	}

	public void setTotalSourceSize(long totalSourceSize) {
		this.totalSourceSize = totalSourceSize;
	}

	public int getCompleted() throws Exception{
		this.calculateCompletion(); 		
		return completed;
	}

	public void setCompleted(int completed) {
		this.completed = completed;
	}

	public String getDestServer() {
		return destServer;
	}

	public void setDestServer(String destServer) {
		this.destServer = destServer;
	}

	public String getSourceServer() {
		return sourceServer;
	}

	public void setSourceServer(String sourceServer) {
		this.sourceServer = sourceServer;
	}
	
	public String fileExists(String serverName,String fileName) throws Exception{
		String nameOnly=fileName.substring(fileName.lastIndexOf("/")+1);
		String retval="Exists or not, I do not know";
		String outPut="";
		String command="ssh "+serverName+" ls -l "+fileName + "\n ";        
        outPut = CmdRunner.invokeCommand(command,true);
        if(outPut.indexOf("No such file or directory")>-1) {
        	retval="File does not exist--->"+fileName+"@"+serverName;
        } else if(outPut.indexOf(nameOnly)>-1) {
        	//"File exists"
        	retval=outPut;
        }
        System.out.println("Check file:--->"+retval);
		return retval;
	}
	
	public long computeFileSize(String fileSizeStr){
		long fileSize=0;
		if(fileSizeStr!=null)
		try{
			 StringTokenizer stk= new StringTokenizer(fileSizeStr," ");
			 int cnt=0; 
			 while(stk.hasMoreTokens()){
				 String token=stk.nextToken();
				 if(cnt==4){
					 fileSize=Long.parseLong(token.trim());
					 break;
				 }
				 cnt++;
			  }
		
		}catch(Exception e){e.printStackTrace();}
		return fileSize;
	}
	public void calculateCompletion() throws Exception {
        sourceFileSize=new long[this.sourceFileName.length];
        destinationFileSize=new long[this.destFileName.length];
        
        //Get source file size
    	for(int i=0;i<this.sourceFileName.length;i++){
            String fileSizeStr=fileExists(sourceServer, sourceFileName[i]);
            sourceFileSize[i]=(this.computeFileSize(fileSizeStr));
            totalSourceSize+=sourceFileSize[i];
            //System.out.println("Source file:"+this.sourceFileName[i]+":"+this.sourceFileSize[i]);
    	}  
        
		//Get destination file size
    	for(int i=0;i<this.destFileName.length;i++){
            String fileSizeStr=fileExists(destServer,destFileName[i]);
            destinationFileSize[i]=(this.computeFileSize(fileSizeStr));
            totalDestinationSize+=destinationFileSize[i];
            //System.out.println("Destination file:"+this.destFileName[i]+":"+this.destinationFileSize[i]);
    	}
		
    	if(totalSourceSize>0){
    		this.completed=(int)((totalDestinationSize/(double)totalSourceSize)*100);
    	}
    	else{
    		this.completed=0;
    	}
    	//System.out.println("Completed:"+this.completed);
	}
}
