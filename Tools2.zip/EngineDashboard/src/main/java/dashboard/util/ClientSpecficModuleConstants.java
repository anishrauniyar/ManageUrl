package dashboard.util;

public interface ClientSpecficModuleConstants {
	
	String SVN_USERNAME = "svnUserName";//svn username 
	String SVN_PASSWORD = "svnPassword";//svn password
	String SVN_CLIENT_SPECIFIC_MODULES_LOCATION = "svnclientSpecModLoc"; // svn location for client specific modules
	String ENGINE_VERSION = "engineVersion"; // engine version for checkout location
	String CRON_EXP_FOR_CLIENT_SPECIFIC_MODULES_CHECKOUT = "cronExpForClientSpecModCheckOut"; // cron expression for client spec module checkout
	String SCHEDULE_CLIENT_SPECIFIC_MODULE_CHECKOUT = "scheduleClientSpecModCheckOut";// parameter that determines whether to start scheduler for client spec mod checkout
	
	String HP_VC_CLIENT_SPECIFIC_MODULES = "HP/VC Client Specific Modules";
	String CLIENT_SPECIFIC_MODULES_CHKOUT_EVENT = "Version Control [Client Spec Module]"; // event
	
	

}
