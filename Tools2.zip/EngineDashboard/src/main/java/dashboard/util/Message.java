package dashboard.util;

public interface Message {
	
	public String ERROR_TCP_KEEP_ALIVE = "Network Error! There seems network " +
			"error between dashboard server to processing server. Please contact IT";
	

}
