package dashboard.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class EDBUtil {

	public static String  fileseperator = "/";
	private static final long SECONDS_IN_MILLI = 1000;
	private static final long MINUTES_IN_MILL = SECONDS_IN_MILLI * 60;
	private static final long HOURS_IN_MILL = MINUTES_IN_MILL * 60;
	private static final long DAYS_IN_MILL = HOURS_IN_MILL * 24;
	
    public static String ifNullBlank(String p) {
        if (p == null || "null".equalsIgnoreCase(p.trim())) return "";
        return p.trim();
    }
	
	/**
	 * 
	 * @param date
	 * @return total time taken in days, hours, minutes and seconds.
	 */
	public static String totalTime(Date date) {
		String totalExecTime ="";
		Calendar startTime = Calendar.getInstance();
		startTime.setTime(date);
		
		long milliseconddiff = Calendar.getInstance().getTimeInMillis() - startTime.getTimeInMillis();		
		
		long days = milliseconddiff / (24 * 60 * 60 * 1000);
	    totalExecTime = days >= 1 ? days + " days, " : "";
	    
	    DateFormat df = new SimpleDateFormat("HH 'hours', mm 'mins,' ss 'seconds'"); 
	    df.setTimeZone(TimeZone.getTimeZone("GMT+0")); 
	    totalExecTime += df.format(new Date(milliseconddiff));	
	    
		return totalExecTime;
	}
	
	/**
	 * Returns date in specified format
	 * 
	 * @param dateformat
	 *            A valid java date format e.g. MM-dd-yy-HH:mm
	 * @return Current date in specified format. 02-22-09-12:40
	 */
	public static String getDateTime(String dateformat) {
		//dateformat = "MM-dd-yy-HH:mm";			
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat(dateformat);
	    return sdf.format(cal.getTime());
	}
    
	public static Timestamp getTS( Date d) {
        Timestamp ts = new Timestamp(d.getTime());
        ts.setNanos(0);
        return ts;
    }
	
	/**
	 * Sorts date String. e.g. input: "Folder1/ Jan09/ Dec08/ Feb09/ Folder2/"
	 * output: "Feb09/ Jan09/ Dec08/ Folder1/ Folder2/"
	 * 
	 * @param dirList
	 * @return sorted date string
	 */
	public static String sortDateFolder(String dirList ) {
		String retval = "";	
		
		String[] tempstr = dirList.split("\n");			
		SimpleDateFormat sdf = new SimpleDateFormat("MMMyy");
		
		ArrayList datearrlst= new ArrayList();	
		
		String invalidformatfolder =""; 
		
		for (int i=0; i<tempstr.length; i++){			
			try{					
				datearrlst.add(sdf.parse(tempstr[i]));					
			}catch (Exception e) {
				invalidformatfolder += tempstr[i]+"\n";				
				//System.out.println("Exception while sorting date folder: \n"+e);
			}			
		}	
		
		List list = Collections.synchronizedList(datearrlst);        
        Collections.sort(list);
        Collections.reverse(list);         
        
		for (int i=0; i<list.size(); i++){	
				Date dat = (Date) list.get(i);				
				retval += sdf.format(dat)+fileseperator+"\n";					
		}		
		
		retval += invalidformatfolder;
		return retval ;
		
	}
	
	
	/**
	 * Sorts files and folders. Files at first and then folders.
	 * 
	 * @param filendir
	 * @return array of sorted files and folders
	 */
    public static String[] sortFilesNFolders(String[] filendir) {    	
	    List filelist = new ArrayList();
		List dirlist = new ArrayList();				
		for(int i=0; i<filendir.length; i++){			
			if(filendir[i].endsWith(EDBUtil.fileseperator)) 
				dirlist.add(filendir[i]);
			else 
				filelist.add(filendir[i]);
		}		
		filelist.addAll(dirlist);		
		return ((String[]) filelist.toArray(new String[filelist.size()]));
    }
    
    public static String getTimeDifference(Date d1, Date d2) {
		StringBuffer sb = new StringBuffer();
		long different = d2.getTime() - d1.getTime();
		long elapsedDays = different / DAYS_IN_MILL;

		different = different % DAYS_IN_MILL;
		if (elapsedDays > 0) {
			sb.append(elapsedDays + " day ");
		}

		long elapsedHours = different / HOURS_IN_MILL;
		different = different % HOURS_IN_MILL;
		if (elapsedHours > 0) {
			sb.append(elapsedHours + " hr ");
		}

		long elapsedMinutes = different / MINUTES_IN_MILL;
		different = different % MINUTES_IN_MILL;
		if (elapsedMinutes > 0) {
			sb.append(elapsedMinutes + " min ");
		}

		long elapsedSeconds = different / SECONDS_IN_MILLI;
		//if (elapsedSeconds > 0) {
			sb.append(elapsedSeconds + " sec ");
		//}
		return sb.toString();
	}
    

    public static void main(String[] args) throws ParseException {

		
    	String dateStart = "01/14/2012 09:29:58";
		//String dateStop = "01/15/2012 10:31:48";
    	String dateStop = "01/14/2012 10:39:58";
 
		//HH converts hour in 24 hours format (0-23), day calculation
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
 
		Date d1 = null;
		Date d2 = null;
 
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);
 
			//in milliseconds
			long diff = d2.getTime() - d1.getTime();
 
			long diffSeconds = diff / 1000 % 60;
			//double diffMinutes = (diff / (60 * 1000) % 60 )  / 60;
			double diffMinutes1 =(double) (diff / (60 * 1000) % 60 )  / 60;
			
			double finalMinutes = Math.round(diffMinutes1 * 100.0) / 100.0;
			double diffHours = diff / (60 * 60 * 1000 ) + finalMinutes;
			double finalHours = Math.round((diffHours * 100.0) / 100.0);
			//long diffDays = diff / (24 * 60 * 60 * 1000);
 
			//System.out.print(diffDays + " days, ");
			System.out.print(String.valueOf(diffHours) + " hours, ");
			System.out.print(finalMinutes + " minutes, ");
			System.out.print(diffSeconds + " seconds.");
			
			
 
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			d1 = format.parse(dateStart);
			d2 = format.parse(dateStop);
 
			//in milliseconds
			long diff = d2.getTime() - d1.getTime();
 
			long diffSeconds = diff / 1000 % 60;
			long diffMinutes = diff / (60 * 1000) % 60;
			long diffHours = diff / (60 * 60 * 1000) % 24;
			long diffDays = diff / (24 * 60 * 60 * 1000);
 
			System.out.print(diffDays + " days, ");
			System.out.print(diffHours + " hours, ");
			System.out.print(diffMinutes + " minutes, ");
			System.out.print(diffSeconds + " seconds.");
 
		} catch (Exception e) {
			e.printStackTrace();
		}
 	  }
	}
