package dashboard.util;

import java.util.Properties;
import java.util.Enumeration;

import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.BufferedOutputStream;
import java.io.OutputStreamWriter;


import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;


public class HttpConnectorUtil {

    public static String post(String url, Properties param) throws Exception {
        return post( new URL( url), param);
    }

    public static String post(URL url, Properties param) throws Exception {
        return new String(post( url, param, "UTF-8"), "UTF-8");
    }

    public static byte [] postNGetBytes( String url, Properties param) throws Exception {
        return post( new URL(url), param, "UTF-8" );
    }
    
    private static final int INIT_SIZE = 1024;
    
    private static byte []  post( URL url, Properties param, String format) throws Exception {
        if (null == param ) {
            throw new NullPointerException("Null properties to post.");
        }
        suppressHandShake();

        
        OutputStreamWriter dataOut = null;
        BufferedInputStream dataIn = null;
        ByteArrayOutputStream byteArray = new ByteArrayOutputStream( INIT_SIZE * 3);
        
        StringBuffer sb = new StringBuffer(INIT_SIZE);
        Enumeration keys = param.propertyNames();
        while (keys.hasMoreElements()) {
            String key = (String) keys.nextElement();
            String val = param.getProperty(key);
            sb.append( URLEncoder.encode(key, format))
                .append("=")
                .append( URLEncoder.encode(val, format));
        }

        try {
            URLConnection cnn = url.openConnection();
            /*
            if ( cnn instanceof HttpsURLConnection) {
                ((HttpsURLConnection) cnn)
                    .setHostnameVerifier( new HostnameVerifier() {
                            public boolean verify(String urlHostname, SSLSession session) {
                                return true;
                            }});
            }
            */

        cnn.setDoOutput( true);
        cnn.setUseCaches(false);
        cnn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");

        dataOut = new OutputStreamWriter( cnn.getOutputStream());
        dataOut.write( sb.toString());
        dataOut.flush();
        dataOut.close();
        dataOut = null;

        dataIn = new BufferedInputStream( cnn.getInputStream());
        byte [] readArea = new byte [INIT_SIZE];
        
        String str = null;
        int readCount = -1;
        while ( -1  != (readCount = dataIn.read(readArea, 0, INIT_SIZE)) ){
            byteArray.write( readArea, 0, readCount);
        }
        dataIn.close();
        dataIn = null;
        } finally {
            if (null != dataOut) { try { dataOut.close(); } catch(Exception ex) {} }
            if (null != dataIn) { try { dataIn.close(); }  catch(Exception ex) {} }
            dataOut = null;
            dataIn = null;
        }
        return byteArray.toByteArray();
    }

    private static void suppressHandShake() throws Exception {
        TrustManager [] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                public X509Certificate [] getAcceptedIssuers() { return null; }
                public void checkClientTrusted( X509Certificate[] certs, String authType ) {}
                public void checkServerTrusted( X509Certificate[] certs, String authType ) {}
            }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    }
}
