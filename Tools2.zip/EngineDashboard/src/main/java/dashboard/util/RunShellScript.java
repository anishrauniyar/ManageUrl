package dashboard.util;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class RunShellScript {

	public RunShellScript() {

	}

	public static List runShellScript(boolean isDmENVer, String... params)
			throws Exception {
		List ls = new LinkedList();
		boolean error = false;
		StringBuffer sb = new StringBuffer(10000);
		InputStream is = null;
		Channel channel = null;
		Session session = null;

		String user = params[0];
		String password = params[1];
		String server = params[2];
		List<String> commands = new ArrayList<String>();
		commands.add(params[3]);
		commands.add(params[4]);

		String privateKey = params[5];

		/*
		 * System.out.println("User:"+user);
		 * System.out.println("Password:"+password);
		 * System.out.println("Server:"+server);
		 */

		try {
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			jsch.addIdentity(privateKey);// adding private key for password less
											// connection
			session = jsch.getSession(user, server, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.setConfig("PreferredAuthentications",
					"publickey,keyboard-interactive,password");

			session.connect();
			channel = session.openChannel("shell");

			OutputStream outPutStream = channel.getOutputStream();
			PrintStream commander = new PrintStream(outPutStream, true);

			channel.setOutputStream(System.out, true);

			channel.connect();
			is = channel.getInputStream();

			for (String command : commands) {
				commander.println(command);
			}

			if (isDmENVer) {
				Thread.sleep(3000);
				commander.println("quit");
				Thread.sleep(3000);
				commander.println("exit");
				Thread.sleep(3000);
			}
			commander.println("exit");
			commander.close();

			/*
			 * int c = 0; while ((c = is.read()) != -1) { sb.append((char) c); }
			 */

			byte[] tmp = new byte[1024];
			while (true) {
				while (is.available() > 0) {
					int i = is.read(tmp, 0, 1024);
					if (i < 0)
						break;
					sb.append(new StringBuffer(new String(tmp, 0, i)));
				}
				if (channel.isClosed()) {
					if (is.available() > 0)
						continue;
					System.out.println("exit-status: "
							+ channel.getExitStatus());
					break;
				}

				Thread.sleep(1000);

			}

		} catch (Exception e) {
			error = true;
			// StringWriter sw = new StringWriter(1000);
			// e.printStackTrace(new PrintWriter(sw));
			sb.append(e.toString());
			throw e;
		} finally {
			if (is != null) {
				is.close();
			}
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null) {
				session.disconnect();
			}
		}

		// System.out.println("DONE");
		ls.add(error);
		ls.add(sb.toString());

		// System.out.println("<<<<<<<<OUTPUT::::>>>>>"+sb.toString());

		return ls;
	}

	public static void main(String args[]) throws Exception {
		String user = "";
		String pwd = "";

	}

}
