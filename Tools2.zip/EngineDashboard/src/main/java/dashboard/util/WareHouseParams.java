package dashboard.util;

public interface WareHouseParams {

	// Warehouse async controller name
	String ASYNC_WH_CONTROLLER = "ASYNC_WH_CONTROLLER";
	
	// Warehouse compile scripts file names
	String WH_COMPILE_SCRIPT = "WH_COMPILE_SCRIPT";
	
	/**
	 *  For sending mails
	 */
	String WH_ENGINE_EXEC_EVENT = "WH_ENGINE_EXEC_EVENT";
	String WH_DATA_TRANSFER_EVENT = "WH_DATA_TRANSFER_EVENT";
}
