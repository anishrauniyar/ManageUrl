package dashboard.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.security.Key;
import java.security.Security;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.xml.security.encryption.EncryptedData;
import org.apache.xml.security.encryption.EncryptedKey;
import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.utils.EncryptionConstants;
import org.apache.xml.security.utils.JavaUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XmlCipherTool {

	//private static final int READ_HEX_KEY = 1;
	//private static final int READ_BYTE_KEY = 2;
	//private static final String KEY_ENCRYPT_KEY = "B9327A8998CDDFF864D058AEEC9826343E91313891704F1A";
	
	private static char[] hexChars = { '0', '1', '2', '3', '4', '5', '6', '7',
			'8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

	static {
		org.apache.xml.security.Init.init();
	}
	static {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}

	/**
	 * 
	 * @param ba
	 * @return
	 */
	private static String bytes2Hex(byte[] ba) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < ba.length; i++) {
			int hbits = (ba[i] & 0x000000f0) >> 4;
			int lbits = ba[i] & 0x0000000f;
			sb.append("" + hexChars[hbits] + hexChars[lbits]);
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param hex
	 * @return
	 */
	private static byte[] hex2Bytes(char[] hex) {
		int length = hex.length / 2;
		byte[] raw = new byte[length];
		for (int i = 0; i < length; i++) {
			int high = Character.digit(hex[i * 2], 16);
			int low = Character.digit(hex[i * 2 + 1], 16);
			int value = (high << 4) | low;
			if (value > 127)
				value -= 256;
			raw[i] = (byte) value;
		}
		return raw;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	private static Document parseFile(File fileName) throws Exception {
		javax.xml.parsers.DocumentBuilderFactory dbf = javax.xml.parsers.DocumentBuilderFactory
				.newInstance();
		dbf.setNamespaceAware(true);
		javax.xml.parsers.DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse(fileName);

		return document;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private static SecretKey GenerateKeyEncryptionKey() throws Exception {
		String jceAlgorithmName = "DESede";
		KeyGenerator keyGenerator = KeyGenerator.getInstance(jceAlgorithmName);
		SecretKey keyEncryptKey = keyGenerator.generateKey();

		return keyEncryptKey;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private static SecretKey GenerateSymmetricKey() throws Exception {
		String jceAlgorithmName = "AES";
		KeyGenerator keyGenerator = KeyGenerator.getInstance(jceAlgorithmName);
		keyGenerator.init(128);

		return keyGenerator.generateKey();
	}

	/**
	 * 
	 * @param keyEncryptKey
	 * @throws IOException
	 */
	private static void storeBytesKey2File(Key keyEncryptKey, File fileName)
			throws IOException {
		byte[] keyBytes = keyEncryptKey.getEncoded();
		FileOutputStream outStream = new FileOutputStream(fileName);
		outStream.write(keyBytes);
		outStream.close();

		System.out.println("Key encryption bytes key stored in: " + fileName);
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	private static SecretKey loadBytesKeyEncryptionKey(File fileName)
			throws Exception {
		String jceAlgorithmName = "DESede";
		DESedeKeySpec keySpec = new DESedeKeySpec(JavaUtils
				.getBytesFromFile(fileName.toString()));
		SecretKeyFactory skf = SecretKeyFactory.getInstance(jceAlgorithmName);
		SecretKey key = skf.generateSecret(keySpec);
		
		System.out.println("Key encryption bytes key loaded from: " + fileName);
		return key;
	}

	/**
	 * 
	 * @param keyEncryptKey
	 * @throws IOException
	 */
	/*private static void storeKeyFile2Hex(Key keyEncryptKey, File fileName)
			throws IOException {
		FileWriter outStream = new FileWriter(fileName);
		outStream.append(bytes2Hex(keyEncryptKey.getEncoded()));
		outStream.close();

		System.out.println("Key encryption hex key stored in: " + fileName);
	}*/

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private static SecretKey loadHexKeyEncryptionKey(String key_encrypt_key)
			throws Exception {
		String jceAlgorithmName = "DESede";

		DESedeKeySpec keySpec = new DESedeKeySpec(hex2Bytes(key_encrypt_key
				.toCharArray()));

		SecretKeyFactory skf = SecretKeyFactory.getInstance(jceAlgorithmName);
		SecretKey key = skf.generateSecret(keySpec);

		System.out.println("Key encryption hex key loaded.");
		return key;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	private static SecretKey loadHexKeyEncryptionKey(File fileName)
			throws Exception {
		FileReader inStream = new FileReader(fileName);
		int i;
		StringBuffer hexstring = new StringBuffer(48);
		while ((i = inStream.read()) != -1) {
			hexstring.append((char) i);
		}

		SecretKey key = loadHexKeyEncryptionKey(hexstring.toString());
		
		System.out.println("Key encryption hex key loaded from: " +fileName);
		return key;
	}

	/**
	 * 
	 * @param doc
	 * @param fileName
	 * @throws Exception
	 */
	public static void writeXmlDocumentToFile(Document doc, File fileName)
			throws Exception {

		FileOutputStream outStream = new FileOutputStream(fileName);

		TransformerFactory factory = TransformerFactory.newInstance();
		Transformer transformer = factory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(outStream);
		transformer.transform(source, result);

		outStream.close();

		System.out.println("Encrypted XML document written to: " + fileName);
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public static Document loadEncryptedFile(File encryptedFile)
			throws Exception {
		javax.xml.parsers.DocumentBuilderFactory dbf = javax.xml.parsers.DocumentBuilderFactory
				.newInstance();
		dbf.setNamespaceAware(true);
		javax.xml.parsers.DocumentBuilder builder = dbf.newDocumentBuilder();
		Document document = builder.parse(encryptedFile);

		System.out.println("Encryption document loaded from: "+encryptedFile);
		return document;
	}

	/**
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public static Document loadEncryptedFile(InputStream filestream)
			throws Exception {
		javax.xml.parsers.DocumentBuilderFactory dbf = javax.xml.parsers.DocumentBuilderFactory
				.newInstance();
		dbf.setNamespaceAware(true);
		javax.xml.parsers.DocumentBuilder builder = dbf.newDocumentBuilder();
		Document document = builder.parse(filestream);
		
		return document;
	}

	/**
	 * 
	 * @param args
	 * @throws Exception
	 */
	private static Document getEncryptDocument(Document document,
			String elementtoencrypt, Key symmetricKey, SecretKey keyEncryptKey)
			throws Exception {
		// initialize cipher
		XMLCipher keyCipher = XMLCipher
				.getInstance(XMLCipher.TRIPLEDES_KeyWrap);
		keyCipher.init(XMLCipher.WRAP_MODE, keyEncryptKey);

		// encrypt symmetric key
		EncryptedKey encryptedKey = keyCipher
				.encryptKey(document, symmetricKey);

		// specify the element to encrypt
		Element rootElement = document.getDocumentElement();
		Element elementToEncrypt = rootElement;

		// if (args.length > 2){
		elementToEncrypt = (Element) rootElement.getElementsByTagName(
				elementtoencrypt).item(0);
		if (elementToEncrypt == null) {
			System.err.println("Unable to find element: " + elementtoencrypt);
			System.exit(1);
		}
		// }

		// initialize cipher
		XMLCipher xmlCipher = XMLCipher.getInstance(XMLCipher.AES_128);
		xmlCipher.init(XMLCipher.ENCRYPT_MODE, symmetricKey);

		// add key info to encrypted data element
		EncryptedData encryptedDataElement = xmlCipher.getEncryptedData();
		KeyInfo keyInfo = new KeyInfo(document);
		keyInfo.add(encryptedKey);
		encryptedDataElement.setKeyInfo(keyInfo);

		// do the actual encryption
		boolean encryptContentsOnly = true;
		xmlCipher.doFinal(document, elementToEncrypt, encryptContentsOnly);

		return document;
	}

	public static Document getEncryptDocument(Document document,
			String elementtoencrypt, String key_encrypt_key) throws Exception {
		// generate symmetric key
		Key symmetricKey = GenerateSymmetricKey();
		SecretKey keyEncryptKey = loadHexKeyEncryptionKey(key_encrypt_key);

		return getEncryptDocument(document, elementtoencrypt, symmetricKey,
				keyEncryptKey);
	}

	private static Document getEncryptDocument(Document document,
			String elementtoencrypt, File keyEncryptKeyFile, int keyFormat)
			throws Exception {
		// generate symmetric key
		Key symmetricKey = GenerateSymmetricKey();

		SecretKey keyEncryptKey = null;

		// keyEncryptKey = GenerateKeyEncryptionKey();
		// storeKeyFile2Hex(keyEncryptKey, keyEncryptKeyFile);
		// storeBytesKey2File(keyEncryptKey, keyEncryptKeyFile);

		switch (keyFormat) {
		case (1):
			keyEncryptKey = loadHexKeyEncryptionKey(keyEncryptKeyFile);
			break;
		case (2):
			keyEncryptKey = loadBytesKeyEncryptionKey(keyEncryptKeyFile);
			break;
		default:
			keyEncryptKey = loadHexKeyEncryptionKey(keyEncryptKeyFile);
			break;
		}

		return getEncryptDocument(document, elementtoencrypt, symmetricKey,
				keyEncryptKey);
	}

	public static Document getDecryptDocument(Document document,
			File keyEncryptKeyFile, int keyFormat) throws Exception {
		// get the encrypted data element
		String namespaceURI = EncryptionConstants.EncryptionSpecNS;
		String localName = EncryptionConstants._TAG_ENCRYPTEDDATA;
		Element encryptedDataElement = (Element) document
				.getElementsByTagNameNS(namespaceURI, localName).item(0);

		// Load the key encryption key.

		Key key = null;

		switch (keyFormat) {
		case (1):
			key = loadHexKeyEncryptionKey(keyEncryptKeyFile);
			break;
		case (2):
			key = loadBytesKeyEncryptionKey(keyEncryptKeyFile);
			break;
		default:
			key = loadHexKeyEncryptionKey(keyEncryptKeyFile);
			break;
		}

		// initialize cipher
		XMLCipher xmlCipher = XMLCipher.getInstance();
		xmlCipher.init(XMLCipher.DECRYPT_MODE, null);
		xmlCipher.setKEK(key);

		// do the actual decryption
		xmlCipher.doFinal(document, encryptedDataElement);
		return document;
	}

	public static Document getDecryptDocument(Document document,
			String keyEncryptKey) throws Exception {
		// get the encrypted data element
		String namespaceURI = EncryptionConstants.EncryptionSpecNS;
		String localName = EncryptionConstants._TAG_ENCRYPTEDDATA;
		Element encryptedDataElement = (Element) document
				.getElementsByTagNameNS(namespaceURI, localName).item(0);

		// Load the key encryption key.
		Key key = loadHexKeyEncryptionKey(keyEncryptKey);
		// initialize cipher

		XMLCipher xmlCipher = XMLCipher.getInstance();
		xmlCipher.init(XMLCipher.DECRYPT_MODE, null);
		xmlCipher.setKEK(key);

		// do the actual decryption
		xmlCipher.doFinal(document, encryptedDataElement);
		return document;
	}
	
	/*public static void main(String args[]) throws Exception {
		String keyEncryptKeyFile = "C:\\Users\\spun.D2HS\\Desktop\\dashboard\\encrypt\\keyEncryptKey";
		String elementtoencrypt = "Parameters";

		String encrypt_infilename = "C:\\Users\\spun.D2HS\\Desktop\\dashboard\\encrypt\\sql.xml";
		String encrypt_outfilename = "C:\\Users\\spun.D2HS\\Desktop\\dashboard\\encrypt\\encrypted.xml";

		Document encrypt_document = getEncryptDocument(parseFile(new File(
				encrypt_infilename)), elementtoencrypt, KEY_ENCRYPT_KEY);
		// Document encrypt_document =
		// getEncryptDocument(parseFile(new File(encrypt_infilename)), elementtoencrypt,
		// new File(keyEncryptKeyFile),READ_HEX_KEY);

		// write the results to a file
		writeXmlDocumentToFile(encrypt_document, new File(encrypt_outfilename));

		String decrypt_infilename = "C:\\Users\\spun.D2HS\\Desktop\\dashboard\\encrypt\\encrypted.xml";
		String decrypt_outfilename = "C:\\Users\\spun.D2HS\\Desktop\\dashboard\\encrypt\\original.xml";
		// load the encrypted file into a Document
		Document decrypt_document = getDecryptDocument(
				loadEncryptedFile(new File(decrypt_infilename)),
				KEY_ENCRYPT_KEY);
		//Document decrypt_document =
		//getDecryptDocument(loadEncryptedFile(new File(decrypt_infilename)), new
		//File(keyEncryptKeyFile),READ_HEX_KEY);
		 
		// write the results to a file
		writeXmlDocumentToFile(decrypt_document, new File(decrypt_outfilename));
	}*/

}
