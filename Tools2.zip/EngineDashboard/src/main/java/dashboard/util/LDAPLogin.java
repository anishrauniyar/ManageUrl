package dashboard.util;

import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import dashboard.data.LDAP;

public class LDAPLogin {
	public static Boolean checkvalidlogin(List LDAPList, String loginName,
			String password) {
		Boolean validUser = Boolean.FALSE;
		List ls = LDAPList;
		for (int i = 0; i < ls.size(); i++) {
			try {
				// Set up the environment for creating the initial context
				LDAP ldap2 = (LDAP) ls.get(i);
				Hashtable env = new Hashtable();
				env.put(Context.INITIAL_CONTEXT_FACTORY,
						"com.sun.jndi.ldap.LdapCtxFactory");
				// env.put(Context.PROVIDER_URL, "ldap://d2hs.com");
				env.put(Context.PROVIDER_URL, ldap2.getLdap_url());

				// Authenticate as S. User and password "mysecret"
				env.put(Context.SECURITY_AUTHENTICATION, "simple");
				// env.put(Context.SECURITY_PRINCIPAL, loginName + "@d2hs.com");
				env.put(Context.SECURITY_PRINCIPAL,
						loginName + ldap2.getPrincipal());
				env.put(Context.SECURITY_CREDENTIALS, password);
				// Create the initial context
				LdapContext ctxGC = new InitialLdapContext(env, null);
				Attributes attr = ctxGC.getAttributes("");
				validUser = Boolean.TRUE;
				ctxGC.close();
				break;
			} catch (NamingException e) {
				System.err.println("User is not valid");

			}
		}
		return validUser;

	}

}