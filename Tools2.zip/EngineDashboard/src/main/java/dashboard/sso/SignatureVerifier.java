package dashboard.sso;

import com.d2oam.sso.SSOHandler;

public class SignatureVerifier {
	/**
	 * @param data
	 *            :UserName
	 * @param signature
	 *            :Signature
	 * @return
	 * @throws Exception
	 */
	public boolean verifySignature(String data, String signature)
			throws Exception {
		String filePath = SignatureVerifier.class.getResource("/dashboard/sso")
				.getPath();
		SSOHandler ssoHandler = new SSOHandler(filePath, "sso.d2oam.com.jks",
				"sso.d2oam.com", "oamsso");
		return ssoHandler.verifySignature(data, signature);
	}
}
