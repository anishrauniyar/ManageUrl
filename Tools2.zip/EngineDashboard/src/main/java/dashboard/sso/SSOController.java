package dashboard.sso;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;
import dashboard.web.pagecontroller.Controller;

public class SSOController extends Controller {

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String loginName = webTransfer.getString("userId");
		String signature = webTransfer.getString("signature");
		SignatureVerifier verifier = new SignatureVerifier();
		boolean verified = verifier.verifySignature(loginName, signature);
		if (!verified) {
			return "relogin";
		} else {
			webTransfer.setString("encLogin", loginName);
			return getPageControllerMap().getController("/login").process(request, response);
		}
	}

}
