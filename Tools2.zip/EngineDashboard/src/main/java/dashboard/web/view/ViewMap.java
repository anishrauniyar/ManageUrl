package dashboard.web.view;

import java.util.Map;
import java.util.HashMap;
import java.util.Collections;


import dashboard.web.util.UriResolver;

public class ViewMap {
    private Map pageMap = null;
    
    public void setPageMap( Map m) {
        if (pageMap == null) {
            pageMap = Collections.unmodifiableMap(m);
        } else {
            throw new IllegalArgumentException("pageMap already set");
        }
    }

    public Page getPage( String uri) {
        if (pageMap.containsKey(uri)) {
            return new Page(uri, pageMap.get(uri).toString());
        }
        throw new IllegalArgumentException("Unknow uri : " + uri);
    }
    public boolean containsLogicalPage(String page) {
        return pageMap.containsKey(page);
    }
}
