package dashboard.web.view;

/**
 * This class represents the internal url for the jsp pages.
 * This class is used instead of String to restrict the unrestricted
 * use of String for specifying jsp pages.
 */
public class Page {
    private Page() {
    }
    String requestPage ;
    String resourcePage;
    protected Page(String pg, String resPage) {
        requestPage = pg;
        resourcePage = resPage;
    }
    public String getRequestPage() {
        return requestPage;
    }
    public String getResourcePage() {
        return resourcePage;
    }
}
