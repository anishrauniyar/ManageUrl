package dashboard.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import dashboard.ComponentFactory;
import dashboard.data.WebTransfer;
import dashboard.quartz.DashboardJobScheduler;
import dashboard.security.ProcessingRole;
import dashboard.security.RoleSet;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;
import dashboard.web.pagecontroller.PageController;
import dashboard.web.pagecontroller.PageControllerMap;
import dashboard.web.util.Dispatcher;
import dashboard.web.util.UriResolver;
import dashboard.web.view.Page;
import dashboard.web.view.ViewMap;

/**
 * Front Controller for Engine Dashboard.
 */
public class DashboardFrontController extends HttpServlet {
	ApplicationContext springContext;
	boolean contextLoadingError = true;
	boolean startupError = true;
	Exception loadingEx;
	String errorMsg;
	UriResolver uriResolver;
	ViewMap viewMap;
	PageControllerMap pageControllerMap;
	EnvInfo envInfo;
	DashboardJobScheduler dashboardJobScheduler;
	private static final int VERSION_LEN = 30;

	protected Log logger = LogFactory.getLog(getClass());
	ComponentFactory componentFactory;
	Dispatcher dispatcher;

	public void init(ServletConfig config) throws ServletException {
		try {
			springContext = WebApplicationContextUtils
					.getRequiredWebApplicationContext(config
							.getServletContext());
			contextLoadingError = startupError = false;

			componentFactory = ComponentFactory.getInstance().init(
					springContext);

			uriResolver = componentFactory.getUriResolver();
			viewMap = componentFactory.getViewMap();
			dispatcher = componentFactory.getDispatcher();
			pageControllerMap = componentFactory.getPageControllerMap();
			envInfo = componentFactory.getEnvInfo();
			if (!envInfo.isVersionDefined()) {
				errorMsg = "Application version not defined during build.";
				startupError = true;
				logger.error("START UP: Application version is not defined.");
			} else {
				String version = envInfo.getAppVersion();
				if (version.length() > VERSION_LEN) {
					errorMsg = "Invalid version (lenth exceeds " + VERSION_LEN
							+ "): " + version;
					startupError = true;
					logger.error("INVALID VERSION (exceed  " + VERSION_LEN
							+ "): " + version);
				}
			}
			/**
			 * VITTOOLS-385 : Cron Job
			 */
			dashboardJobScheduler = componentFactory.getDashboardJobScheduler();
			dashboardJobScheduler.schedule();

		} catch (IllegalStateException illegalExp) {
			// context not found.
			contextLoadingError = true;
			loadingEx = illegalExp;
			errorMsg = "MISSING CONTEXT AT STARTUP: " + loadingEx.getMessage();
			logger.info(errorMsg);
		} catch (Exception ex) {
			// startup error.
			startupError = true;
			loadingEx = ex;
			errorMsg = "BOOT START ERROR: " + loadingEx.getMessage();
			ex.printStackTrace();
			logger.info(errorMsg);
		}
	}

	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (startupError || contextLoadingError) {
			PrintWriter out = response.getWriter();
			out.print("<h1>System is not available. Sorry for the inconvenience</h1><br/>");
			out.print("<!-- \n\t" + errorMsg + "\n-->");
			out.close();
			return;
		}

		String uriToResolve = request.getServletPath();
		String resolvedUri = uriResolver.getResolved(uriToResolve);
		HttpSession session = request.getSession(false); // session not created
															// by default
		WebTransfer webTransfer = transferRequest(request);
		request.setAttribute("webTransfer", webTransfer);

		try {
			if ("/login".equals(resolvedUri) || "/loginOAM".equals(resolvedUri)) { // login attempt
				PageController pgController = pageControllerMap
						.getController(resolvedUri);
				String outCome = pgController.process(request, response);
				Page page = viewMap.getPage(outCome);
				dispatcher.dispatch(request, response, page);
			} else if (session != null
					&& session.getAttribute("session:loginName") != null
					&& Boolean.TRUE
							.equals(session.getAttribute("isValidLogin"))) { // valid
																				// login
				RoleSet roleSet = (RoleSet) session
						.getAttribute("session:roles");

				if (null != roleSet
						&& (roleSet.hasRole(ProcessingRole.PROCESS_SUPERADMIN) || 
								roleSet.hasRole(ProcessingRole.PROCESS_ADMIN) ||
								roleSet.hasRole(ProcessingRole.PROCESS_MANAGER) ||
								roleSet.hasRole(ProcessingRole.PROCESS_USER)  ||
								roleSet.hasRole(ProcessingRole.PROCESS_SCRUB_N_VERSION_CONTROL) ||
								roleSet.hasRole(ProcessingRole.PROCESS_SCRUB) ||
								roleSet.hasRole(ProcessingRole.PROCESS_SCRUB_VERSION_CONTROL))) {
					PageController pgController = pageControllerMap
							.getController(resolvedUri);
					webTransfer.setString("session:loginName",
							(String) session.getAttribute("session:loginName"));
					webTransfer.setString("session:userId",
							(String) session.getAttribute("session:userId"));
					request.setAttribute("EngineMonitor", componentFactory
							.getEngineMonitor(webTransfer
									.getString("session:loginName")));

					String outCome = pgController.process(request, response);

					if (!outCome.equals("downloadfile")) {
						Page page = viewMap.getPage(outCome);
						dispatcher.dispatch(request, response, page);
					}

				} else {
					Page page = viewMap.getPage("accessNotDefined");
					dispatcher.dispatch(request, response, page);
					session.invalidate();
				}
			} else {
				// session timeout.
				Page page = viewMap.getPage("sessionTimeout");
				logger.info("Session out while accession URL "+resolvedUri);
				if(resolvedUri.equalsIgnoreCase("/dataTransfer")){
					String hostingServer = (request.getParameter("hostingServer") == null)?"":request.getParameter("hostingServer");
					if(hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA) || hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)){
						logger.error("<<<<<<Vertica CMA Data Transfer could not be started because of session time out!!!!!!>>>>>>>>");
					}
				}
				dispatcher.dispatch(request, response, page);
			}
		} catch (Exception ex) {
		    logger.error( "Current Request: " + uriToResolve + " [" +
			 webTransfer.toString() + "]", ex);
			response.getWriter().print("<font color='red'>"+ex.getMessage()+"</font>");
			//ex.printStackTrace();
		}
	}

	private static WebTransfer transferRequest(HttpServletRequest request) {
		WebTransfer webTransfer = new WebTransfer();
		Enumeration names = request.getParameterNames();
		while (names.hasMoreElements()) {
			String key = (String) names.nextElement();
			String[] values = request.getParameterValues(key);
			if (values.length > 1) {
				webTransfer.setStringArray(key, values);
			} else {
				webTransfer.setString(key, values[0]);
			}
		}
		return webTransfer;
	}

}
