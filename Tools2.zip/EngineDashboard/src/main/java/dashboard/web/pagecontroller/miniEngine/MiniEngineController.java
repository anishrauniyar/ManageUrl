package dashboard.web.pagecontroller.miniEngine;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.EngineTask;
import dashboard.data.MREPreCheck;
import dashboard.data.ReplaceSchema;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;

public class MiniEngineController extends Controller {

	private static List lsEmpty = Collections
			.unmodifiableList(new java.util.ArrayList(0));

	private static final String MINI_ENGINE_PARAM = "MINI_ENGINE_PARAM";
	private static final String SERVER_LIST = "SERVER_LIST";
	private static final String HIST_SERVER_LIST = "HIST_SERVER_LIST";
	private static final String RUN_MINI_ENGINE = "RUN_MINI_ENGINE";
	private static final String GET_MINI_ENGINE_OUT_TRANSFER_LOG = "GET_MINI_ENGINE_OUT_TRANSFER_LOG";
	private static final String GET_MRE_PRE_CHECK_DETAILS_FOR_A_SCHEMA = "GET_MRE_PRE_CHECK_DETAILS_FOR_A_SCHEMA";
	private static final String S_TRUE = "TRUE";
	private static final RunningStatus RUNNING_STATUS = new RunningStatus();

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String retVal = "miniEngineOutput";
		Boolean isRefreshAgain = Boolean.TRUE;

		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String loginName = webTransfer.getString("session:loginName");
		User user = (User) request.getSession().getAttribute("session:user");
		String action = webTransfer.getString("action");

		EngineMonitor engine = getEngineMonitor(request);

		List lsServerGroups = lsEmpty;
		List histServerGroups = lsEmpty;
		List lsEngineVersions = lsEmpty;
		List lsServers = lsEmpty;
		List histServers = lsEmpty;

		String serverGroupId = webTransfer.getString("serverGroupId");
		serverGroupId = (serverGroupId == null) ? "" : serverGroupId.trim();
		String dxcgProcess = "";
		List<VHTransferLog> miniEngineTL = lsEmpty;
		String dataTransferProcess = "N";
		List<String> serverGrpCategory = new ArrayList<>();
		if (MINI_ENGINE_PARAM.equals(action)) {
			lsEngineVersions = engine.getEngineVersionList();
			lsServerGroups = engine.getServerGroupListForProcessing();

			/**
			 * History server group [Showing HISTORY_SERVER n PROCESS_SERVER]
			 */
			serverGrpCategory.add(Constants.HISTORY_SERVER);
			serverGrpCategory.add(Constants.PROCESSING_SERVER);
			histServerGroups = engine
					.getServerGrpsByCategory(serverGrpCategory);

			retVal = "setupMiniEngineParam";
		} else if (SERVER_LIST.equals(action)) {
			lsServers = engine.getServersForServerGroup(serverGroupId);
			retVal = "serverListForMiniEngine";

		} else if (HIST_SERVER_LIST.equals(action)) {
			retVal = "histServerListForMiniEngine";
			histServers = engine.getServersForHistServerGroup(serverGroupId);
			if (histServers.size() == 1) {
				request.setAttribute("isSingleHistServer", Boolean.TRUE);
			} else {
				request.setAttribute("isSingleHistServer", Boolean.FALSE);
			}
		} else if (RUN_MINI_ENGINE.equals(action)) {
			String event = "Process Mini Engine";
			retVal = "miniEngineOutput";
			AsyncSQLProcess sqlProcess = null;

			dxcgProcess = (webTransfer.getString("dxcgProcessed") == null)?"N":webTransfer.getString("dxcgProcessed"); //not always set dxcg to Y
			String engineVersion = "";
			// Engine Version
			if (null != webTransfer.getString("VCSchema")
					&& !"".equalsIgnoreCase(webTransfer.getString("VCSchema"))) {
				engineVersion = engine.getEngineVersionForSchema(webTransfer
						.getString("VCSchema"));
				logger.info("Engine version from OAM : {}" + engineVersion);
			}
			// Override setting for engine version by user
			if (null != webTransfer.getString("overrideEngineVersion")
					&& webTransfer.getString("overrideEngineVersion")
							.equalsIgnoreCase("TRUE")
					&& null != webTransfer.getString("ENG_VERSION")
					&& !"".equals(webTransfer.getString("ENG_VERSION").trim())) {
				engineVersion = webTransfer.getString("ENG_VERSION").trim();
				logger.info("Engine version overriden by user : {}"
						+ engineVersion);
			}
			// VC Schema
			Schema VCSchema = getVCSchemaForMiniEngine(webTransfer);
			String desc = VCSchema.getServerName() + ":" + VCSchema.getPort()
					+ "/" + VCSchema.getService() + ":"
					+ VCSchema.getSchemaName();
			// Getting VC Schema Password
			try {
				VCSchema = engine.setSchemaPassword(VCSchema);
				VCSchema.setEncodePassword(encryptPassword(VCSchema
						.getSchemaPwd()));
			} catch (Exception e) {
				logger.error("MiniEngineController.java (RUN_MINI_ENGINE) >> Error getting password for VC Schema");
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger);
				// show error in event log
				ComponentFactory
						.getInstance()
						.getEventLogger()
						.logError(loginName, event, desc, 0, new Date(),
								new Date(), sw.toString(), VCSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
			// Setting engine version,clientName and dxcg status
			VCSchema.setEngineVersion(engineVersion)
					.setClientName(
							engine.getClientName(VCSchema.getSchemaName()))
					.setDxCGProcess(dxcgProcess);

			String isDiffServer = webTransfer.getString("isDiffServer");
			Schema historySchema = null;
			try {
				if ("Y".equalsIgnoreCase(isDiffServer)) {
					historySchema = getHistSchemaForMiniEngine(webTransfer);
					// setting password for history schema
					try {
						historySchema = engine.setSchemaPassword(historySchema);
					} catch (Exception e) {
						logger.error("MiniEngineController.java (RUN_MINI_ENGINE) >> Error getting password for history schema "
								+ historySchema.getSchemaName());
						// inserting exception caught to logger.
						StringWriter sw = InsertExceptionToLogger.insert(e,
								logger);
						// show error in event log
						ComponentFactory
								.getInstance()
								.getEventLogger()
								.logError(loginName, event, desc, 0,
										new Date(), new Date(), sw.toString(),
										historySchema);
						// show error in UI
						errorList.add(e.getMessage());
						return retVal;
					}
					// uncomment this later
					Object[] histTestVal = engine.isValid(historySchema);
					if (Boolean.TRUE.equals(histTestVal[0])) {
						ValidatorRoot.getMessageList(request).add(
								"[History Schema]Successfully connected.");
					} else {
						List errors = ValidatorRoot.getErrorList(request);
						errors.add("[History Schema] Connection failure ");
						errors.add(histTestVal[1]);
						return retVal;
					}
				}
				// Preparing Replace Schema
				String engVersionNo = engineVersion.substring(1,
						engineVersion.length());
				boolean isReplace_Master_QRM = engVersionNo.compareTo("5") > -1;
				/**
				 * Note: For MRE and Hedis HAWKEYEMASTER AND HAWKEYEQRM is
				 * always used as HAWKEYEMASTER AND HAWKEYEQRM Not,
				 * HAWKEYEMASTER5 AND HAWKEYEQRM5
				 */
				ReplaceSchema replSchema = (new ReplaceSchema())
						.setHawkeyeMaster("HAWKEYEMASTER")
						.setHawkeyeQRM("HAWKEYEQRM")
						.setReplaceHawkeyeMaster(isReplace_Master_QRM)
						.setReplaceHawkeyeQRM(isReplace_Master_QRM);
				// DOP
				int degOfParallelism = 1;
				try {
					degOfParallelism = Integer.parseInt(webTransfer
							.getString("degreeOfParallelism"));
				} catch (Exception nfe) {
				}
				// parallel
				String parallel = (webTransfer.getString("parallel") == null) ? "N"
						: webTransfer.getString("parallel");
				
                
                boolean runDXCGVerification=false;
                boolean dxcgVerification=engine.checkDXCGVerification();
                logger.info("dxcgVerification:"+dxcgVerification);
                
                if(S_TRUE.equals(webTransfer.getString("EXECUTE_MINI_ENGINE")) && dxcgVerification){
                	runDXCGVerification=true;
                }
                
                logger.info("runDXCGVerification:"+runDXCGVerification);
                

				EngineTask engineTask = (new EngineTask()).setCompileEngine(
						S_TRUE.equals(webTransfer
								.getString("COMPILE_MINI_ENGINE")))
						.setExecuteEngine(
								S_TRUE.equals(webTransfer
										.getString("EXECUTE_MINI_ENGINE")))
					 	.setRunDXCGRecordCount(runDXCGVerification)
					 	.setRunPreCheck(S_TRUE.equals(webTransfer
								.getString("RUN_PRE_CHECK")));

				sqlProcess = engine.executeMiniEngine(VCSchema, replSchema,
						degOfParallelism, parallel, engineTask, user,
						historySchema, isDiffServer);

				SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
				isRefreshAgain = Boolean.TRUE;
				TaskType taskType = sqlRunnable.getTaskType();
				TaskKey taskKey = sqlProcess.getTaskKey();

				messageList.add(sqlRunnable.getDescription());
				request.setAttribute("schema", VCSchema);

				if ((loginName.equals(taskKey.getUserName()))
						&& (TaskType.MINI_ENGINE_PRE_CHECK.equals(taskType) || TaskType.COMPILE_MINI_ENGINE.equals(taskType) || TaskType.EXECUTE_MINI_ENGINE
								.equals(taskType)) || TaskType.DXCG_RECORD_COUNT
						.equals(taskType)) {
					messageList.add("Currently queued: " + taskType.toString());
				} else {
					errorListMsg(errorList, taskType, taskKey);
					isRefreshAgain = Boolean.FALSE;
				}

			} catch (Exception e) {
				if (e.getMessage().equals("Max Dop Exceeded!!!")) {
					System.out
							.println("Max Dop Exceeded!! Cannot run new Process until one of the running gets completed!!!");
					errorList
							.add("Max Dop Exceeded!! Cannot run new Process until one of the running gets completed!!!");
					isRefreshAgain = Boolean.FALSE;
				} else if (e.getMessage().equals(
						"No process ready to share Dop!!!")) {
					System.out.println("No process Ready to share Dop!!!");
					errorList.add("No process ready to share Dop!!!");
					isRefreshAgain = Boolean.FALSE;
				} else {
					throw e;
				}
			}
		} else if (GET_MINI_ENGINE_OUT_TRANSFER_LOG.equals(action)) {
			retVal = "miniEngineOutputTranferLog";
			Schema VCSchema = getVCSchemaForMiniEngine(webTransfer);
			VCSchema.setSchemaPwd(Constants.DEFAULT_SCHEMA_PWD);// pwd is
																// default for
																// VC Schema
			/*
			 * try { VCSchema = engine.setSchemaPassword(VCSchema); } catch
			 * (Exception e) { errorList.add(e.getMessage()); return retVal; }
			 */
			dataTransferProcess = "Y";
			try {
				miniEngineTL = engine.getMiniEngineOutputTransferLog(VCSchema);
			} catch (Exception e) {
				errorList.add(e.getMessage());
				e.printStackTrace();
				return retVal;
			}
			request.setAttribute("VCSchema", VCSchema);
			request.setAttribute("tableCount", miniEngineTL.size());

		}else if (GET_MRE_PRE_CHECK_DETAILS_FOR_A_SCHEMA.equals(action)) {
			retVal = "mrePreCheckOutputLog";
			List<MREPreCheck> mrePreCheckDetails = null;
			Schema VCSchema = getVCSchemaForMiniEngine(webTransfer);
			VCSchema.setSchemaPwd(Constants.DEFAULT_SCHEMA_PWD);
			try {
				mrePreCheckDetails = engine.getMrePreCheckForSchema(VCSchema);
			} catch (Exception e) {
				errorList.add(e.getMessage());
				return retVal;
			}
			request.setAttribute("VCSchema", VCSchema);
			request.setAttribute("mrePreCheckDetails", mrePreCheckDetails);

		}

		request.setAttribute("lsEngineVersions", lsEngineVersions);
		request.setAttribute("lsServerGroups", lsServerGroups);
		request.setAttribute("histServerGroups", histServerGroups);
		request.setAttribute("lsServers", lsServers);
		request.setAttribute("histServers", histServers);
		request.setAttribute("isRefreshAgain", isRefreshAgain);
		request.setAttribute("dxcgProcess", dxcgProcess);
		request.setAttribute("dataTransferProcess", dataTransferProcess);
		request.setAttribute("miniEngineTL", miniEngineTL);
		return retVal;
	}

	private static void errorListMsg(List ls, TaskType taskType, TaskKey taskKey) {
		ls.add("Schema is being used for " + taskType);
		ls.add("Operation requested is not queued.");
		ls.add("Job was scheuled by: " + taskKey.getUserName());

	}
}
