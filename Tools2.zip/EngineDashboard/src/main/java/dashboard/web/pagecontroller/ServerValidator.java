package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import dashboard.data.Server;

public class ServerValidator extends ValidatorRoot {
    public boolean isValid(Object obj, HttpServletRequest request){
        boolean retVal = true;
        if (null == obj) {
            throw new NullPointerException("Object to verify null in " + this.getClass().getName());
        }
        if ( ! (obj instanceof Server) ) {
            throw new IllegalArgumentException("Object to verify is not Server in " + this.getClass().getName());
        }
        
        init(request);
        List errors = getErrorList();
        List message = getMessageList();
        Server server = (Server) obj;

        if ("".equals(server.getServerGroupId())) {
            errors.add("ServerGroupId is blank");
            retVal = false;
        }
        if( "".equals(server.getHost())) {
            errors.add("Host is blank");
            retVal = false;
        }
        if (server.getHost().length() > 100) {
            errors.add("Host exceed length");
        }
        //hosting server type (ORACLE,VERTICA,DMEXPRESS)
        if("".equals(server.getHostingServer())){
        	 errors.add("Hosting Server is blank");
             retVal = false;
        }
        if("ORACLE".equalsIgnoreCase(server.getHostingServer()))
        {
        	if("".equals(server.getService())) 
        	{
                errors.add("Service is blank");
                retVal = false;
            }
            if(server.getService().length() > 100) 
            {
                errors.add("Service exceed length");
            }
            if(server.isProcessingOracleServer())
            {
            	/*if("".equals(server.getConnection()))
            	{
            		errors.add("Connection is blank");
                    retVal = false;
            	}*/
            }
        }
        if("VERTICA".equalsIgnoreCase(server.getHostingServer()))
        {
        	if("".equals(server.getDatabase()))
        	{
        		errors.add("Database is blank");
                retVal = false;
        	}
        	if("".equals(server.getConnection()))
        	{
        		errors.add("Connection is blank");
                retVal = false;
        	}
        }
        if("DMEXPRESS".equalsIgnoreCase(server.getHostingServer()))
        {
        	if("".equals(server.getInstance()))
        	{
        		errors.add("Instance is blank");
                retVal = false;
        	}
        }
        if(server.getPort() <=0 ) {
            errors.add("Invalid port.");
            retVal = false;
        }
        return retVal;
    }
}
