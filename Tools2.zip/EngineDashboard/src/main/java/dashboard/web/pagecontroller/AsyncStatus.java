package dashboard.web.pagecontroller;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.data.miniEngine.VHTransferLog;
import dashboard.db.FixedParameter;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.util.Constants;
import dashboard.util.EDBUtil;

public class AsyncStatus extends Controller {

    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));
    private static final RunningStatus RUNNING_STATUS = new RunningStatus();
    private static final String DATE_PATTERN = "MMM d, yyyy HH:mm a, zzzz";
    public String dxOutputString ="";
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        Locale locale = request.getLocale();
        SimpleDateFormat dateFormat = new SimpleDateFormat( DATE_PATTERN, locale);
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();
        
        String retVal = "processOutput";
        List statusList = lsEmpty;
        List<VHTransferLog> miniEngineTL = lsEmpty; // for Mini Engine Output Transfer [CDF Out]
        String dxcgProcess="";
        String dataTransferProcess="";
        
    	int totalTableCount = 0;
    	int totalViewCount = 0;
    	int successTableCount = 0;
    	int successVwCount = 0;
    	int errorCount = 0;
    	int errorVwCount = 0;
    	Long  execNo = (long) 0;
    	List eventDetails = null;
        
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        
        RunningStatus runningStatus = RUNNING_STATUS;
        Boolean isRefreshAgain = Boolean.FALSE;
        String serverGroupId = webTransfer.getString("serverGroupId");
        String hostingServer = webTransfer.getString("hostingServer") ==null?"":webTransfer.getString("hostingServer");
        String showVerticaDetails = webTransfer.getString("showVerticaDetails");
        
        EngineMonitor engine = getEngineMonitor(request);
        
        String frontSchema = webTransfer.getString("frontSchema") == null ? webTransfer.getString("verticaFrontSchema"):webTransfer.getString("frontSchema");
        AsyncSQLProcess sqlProcess = ((EngineMonitor) request.getAttribute("EngineMonitor"))
            .getAsyncSQLProcess( (new TaskKey()).setServerGroupId(serverGroupId)
                                 .setSchemaName(frontSchema));
        
        String executionNumber = webTransfer.getString("executionNumber");
                                 
        SQLPlusRunnable sqlRunnable = null;
        if (sqlProcess != null ) {
            sqlRunnable = sqlProcess.getSQLPlusRunnable();
        }
        if(sqlRunnable != null){
	        if(sqlRunnable.getSchema() != null){
	        	dxcgProcess = sqlRunnable.getSchema().getDxCGProcess();
	        }
	        
	      //to show tables transferred for oracle to vertica data transfer
	      //only for vertica and vertica_cma
	        if(showVerticaDetails.equalsIgnoreCase("true")){
	        	//System.out.println("Hosting Server from AsyncStatus>>>>>>>>>>>>>>>>>>>"+hostingServer);
	        	execNo = sqlRunnable.getExecutionId();
	        	//System.out.println("Execution Id from Asystatus:>>>>>>>>>>>>>>>>>"+execNo);
	        	
    			String centralHost = fixedParam.getValue(Constants.CS_HOST,hostingServer);
	    		String centralPort = fixedParam.getValue(Constants.CS_PORT,hostingServer);
	    		String centralService = fixedParam.getValue(Constants.CS_SERVICE,hostingServer);
	    		String centralSchemaName = fixedParam.getValue(Constants.CS_SCHEMA,hostingServer);
	    		String centralSchemaPwd = fixedParam.getValue(Constants.CS_SCHEMAPWD,hostingServer);
	    		
	    		Schema centralSchema = (new Schema())
	    									.setServerName(centralHost)
	    									.setPort(centralPort)
	    									.setService(centralService)
	    									.setSchemaName(centralSchemaName)
	    									.setSchemaPwd(centralSchemaPwd);
	        	
	        	/*
	    		 * FOR ORACLE TO VERTICA DATA TRANSFER USING DMEXPRESS
	    		 */
	    		if((hostingServer.equalsIgnoreCase(Constants.VERTICA))){
	    			/**
		    		 * TO FIND TOTAL TABLE COUNT ONLY AFTER "Execute DMX Task" FOR ORACLE TO VERTICA DATA TRANSFER USING "DMEXPRESS"
		    		 * i.e if event id is 90 then only count total table count in source server 
		    		 * **/
	    			boolean isExecuteDMXTask = engine.isExecuteDMXTask(centralSchema,execNo);
		    		if(isExecuteDMXTask){
		    			Schema srcSchema = sqlRunnable.getSrcSchema();
		    			totalTableCount = engine.getTotalTableCountFromSource(srcSchema);
		    			//System.out.println("TOTAL TABLE COUNT FROM ASYSTATUS:"+totalTableCount);
		    		}
		    		
		    		/**
	    			 * GETTING SUCCESS TABLE COUNT, ERROR TABLE COUNT AND EVENT DETAILS FOR O2V TRANSFER USING DMEXPRESS
	    			 * 
	    			 * */
		    		successTableCount = engine.getCount(centralSchema, execNo, "Y");
		    		errorCount = engine.getCount(centralSchema, execNo, "E");
		    		eventDetails = engine.getEventDetails(centralSchema, execNo);
	    		}
	    		/**
	    		 * FOR ORACLE TO VERTICA DATA TRANSFER USING CMA
	    		 **/
	    		else if((hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA)) ||
	    			   (hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)))
	    		{
	    			/**
		    		 * TO FIND TOTAL TABLE COUNT ONLY AFTER "Copy data from oracle to vertica" FOR ORACLE TO VERTICA DATA TRANSFER USING "CMA"
		    		 * i.e if event id is 80 then only count total table count in source server 
		    		 * **/
	    			boolean isCopyDataFromO2V = engine.isCopyDataFromO2V(centralSchema,execNo);
	    			if(isCopyDataFromO2V){
	    				Schema srcSchema = sqlRunnable.getSrcSchema();
		    			totalTableCount = engine.getTotalTableCountFromSource(srcSchema);
		    			totalViewCount = engine.getTotalViewCountFromSource(srcSchema);
	    			}
	    			/**
	    			 * GETTING SUCCESS TABLE COUNT, ERROR TABLE COUNT AND EVENT DETAILS FOR O2V TRANSFER USING CMA
	    			 * 
	    			 * */
	    			successTableCount = engine.getCount_CMA(centralSchema, execNo, "Y");
		    		errorCount = engine.getCount_CMA(centralSchema, execNo, "E");
		    		eventDetails = engine.getEventDetails(centralSchema, execNo);
		    		
		    		/*
		    		 *	GETTING SUCCESS VIEW COUNT, ERROR VIEW COUNT  
		    		 */
		    		successVwCount = engine.getViewCount_CMA(centralSchema, execNo, "Y");
		    		errorVwCount   = engine.getViewCount_CMA(centralSchema, execNo, "N");
	    		}

	    		
	    		/**
	    		 * TO SHOW EXECUTION NUMBER IN UI 
	    		 * JIRA VITTOOLS-N/A
	    		 * **/
	    		request.setAttribute("execNo", execNo);
	        }
        }
        
        String desc = "<NO PROCESS>", out_put = "NO MORE PROCESS.";
        String dx_output = "";
        String moduleOrObject = "modules";
        if (sqlProcess != null) {
            desc = sqlRunnable.getDescription();            
            out_put = sqlProcess.getOutput();
            
            if((hostingServer.equalsIgnoreCase(Constants.VERTICA)) || 
               (hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA)) ||
               ((hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)))){
            	/**
        		 * TO SHOW SHELL SCRIPT OUTPUT FROM REMOTE SERVER NUMBER IN UI 
        		 * JIRA VITTOOLS-N/A
        		 * **/
        		//overriding the output(thread output) with remote shell script output
    			out_put = engine.getShellScriptOutput(execNo,hostingServer);
    		/*	sqlProcess = ((EngineMonitor) request.getAttribute("EngineMonitor"))
    		            .getAsyncSQLProcess( (new TaskKey()).setServerGroupId(serverGroupId)
    		                                 .setSchemaName(frontSchema));*/
            }
            
    		if("Y".equalsIgnoreCase(dxcgProcess)){
	            dx_output = sqlProcess.getDxCGStatus();
	            dxOutputString = dx_output;
            }
            statusList = sqlRunnable.getStatusList();
            runningStatus = sqlRunnable.getRunningStatus();
            miniEngineTL  = sqlRunnable.getMiniEngineOutputTransferLog();
            TaskKey task = sqlProcess.getTaskKey();
            request.setAttribute("startedAt", dateFormat.format( sqlProcess.getTaskKey().getStartDate()));
            request.setAttribute("owner", task.getUserName());
            isRefreshAgain = Boolean.TRUE;            
            moduleOrObject = sqlRunnable.getTaskType().getID().equals("DATA_TRANSFER")?"objects":
            				 sqlRunnable.getTaskType().getID().equals("INDEXING")?"indexes":"modules";
            if(sqlRunnable.getTaskType().getID().equals("DATA_TRANSFER")){
            	dataTransferProcess="Y";
            }
         } else {
        	webTransfer.setString("dxOutputString", dxOutputString);
            request.setAttribute("isRefreshAgain", Boolean.FALSE);
            webTransfer.setString("schema", frontSchema);
            webTransfer.setString("executionNumber",executionNumber);
            webTransfer.setString("hostingServer", hostingServer);
            return getPageControllerMap().getController("/lastOutput").process(request, response);
        }
        request.setAttribute("isRefreshAgain", isRefreshAgain);

        request.setAttribute("statusList", statusList);
        request.setAttribute("runningStatus", runningStatus);
        request.setAttribute("miniEngineTL", miniEngineTL);

        request.setAttribute("processName", sqlRunnable.getTaskType().getTaskName());
        request.setAttribute("processLabel", sqlRunnable.getTaskType().getTaskLabel());
        request.setAttribute("processDescription", desc);
        request.setAttribute("serverOutput", out_put );
        request.setAttribute("dxOutput", dx_output );
        request.setAttribute("dxcgProcess", dxcgProcess);
        request.setAttribute("dataTransferProcess", dataTransferProcess);
        
        request.setAttribute("totalExecTime", EDBUtil.totalTime(sqlProcess.getTaskKey().getStartDate()));
        request.setAttribute("moduleOrObject", moduleOrObject);
        
        //request.setAttribute("transferSummary", transferSummary);
        request.setAttribute("totalTableCount", totalTableCount);
        request.setAttribute("totalViewCount", totalViewCount);
        request.setAttribute("successTableCount", successTableCount);
        request.setAttribute("errorCount", errorCount);
        request.setAttribute("execNo", execNo);
        request.setAttribute("eventDetails", eventDetails);
        
        request.setAttribute("successVwCount", successVwCount);
        request.setAttribute("errorVwCount", errorVwCount);
        
        //hidden parameters
        request.setAttribute("serverGroupId", serverGroupId);
        request.setAttribute("hostingServer", hostingServer);
        request.setAttribute("showVerticaDetails", showVerticaDetails);
        request.setAttribute("frontSchema", frontSchema);

        return retVal;
    }
}