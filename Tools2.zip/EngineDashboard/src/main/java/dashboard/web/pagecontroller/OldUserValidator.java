package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import dashboard.security.User;

public class OldUserValidator extends ValidatorRoot {
    public boolean isValid(Object obj, HttpServletRequest request){
        boolean retVal = true;
        if (null == obj) {
            throw new NullPointerException("Object to verify null in UserValidator.");
        }
        if (! (obj instanceof User) ) {
            throw new IllegalArgumentException("Object to verify is not User in UserValidator.");
        }
        
        init(request);
        List errors = getErrorList();
        List message = getMessageList();
        User user = (User) obj;
        if ("".equals(user.getUserId())) {
            errors.add("Blank user id found.");
            retVal = false;
        }
        if("".equals(user.getLoginName())) {
            errors.add("Blank login Name is not allowed for exiting user .");
            retVal = false;
        }
        if("".equals(user.getUserName())) {
            errors.add("Blank user name is not allowed  for exiting user .");
            retVal = false;
        }        
        return retVal;
    }
}
