package dashboard.web.pagecontroller;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.oracle.NamingUtil;
import dashboard.util.Constants;

public class VerticaDataTransferDetails extends Controller {

	private final static String CONTENT_TYPE = "application/octet-stream";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		List transferSummary = null;
		List success = null;
		List successVw = null;
		List error = null;
		List errorVw = null;
		List running = null;
		List errorDetails  =null;
		
		FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		EngineMonitor engine = getEngineMonitor(request);
		String retVal = "verticaDataTransferDetails";
		long execNo = 0;
		if(webTransfer.getString("execNo") != null){
			execNo= Long.valueOf(webTransfer.getString("execNo"));
		}
		
		/**
		 * SETTING HOSTING SERVER ACCORDING TO EVENT NAME
		 * 
		 * **/
		String eventName = (webTransfer.getString("eventName") == null)?"":webTransfer.getString("eventName");
		String hostingServer = Constants.VERTICA_CMA;
		//System.out.println("Event Name >>>>>>>>>>>>>>: "+eventName);
		if(eventName.trim().equalsIgnoreCase(Constants.O2V_DMEXPRESS_EVENT)){
			//System.out.println(eventName);
			hostingServer = Constants.VERTICA;
		}
		//hostingServer = Constants.VERTICA_CMA;
		//System.out.println("Hosting Server >>>>>>>>>>"+hostingServer);
		/**
		 *  if isLogFileDownload is true
		 *  it gets respective logfile(Console OutPut) of execNo
		 *  if file is cached locally, it returns the same
		 *  else connects to remote server to get file
		 */
		boolean isLogFileDownload = "true".equals(webTransfer.getString("getLogFile") != null ? webTransfer
						.getString("getLogFile") : "false" );
		if (isLogFileDownload) {
			System.out.println("Hosting server for downloading shell scripts o2v:>>>>>>>>>>>>>>>"+hostingServer);
			
			String fileName = fixedParam.getValue(Constants.SHELLSCRIPT_FILEPREFIX,hostingServer) + "_" + execNo + ".log";
			response.setHeader("Content-Disposition", "attachment;filename=\""
					+ fileName + "\"");
			response.setContentType(CONTENT_TYPE);
			IOUtils.copy(engine.getLogFile(execNo,hostingServer), response.getOutputStream());
			response.flushBuffer();
			return "downloadfile";
		}
		
		/*
		 * if isOracleBALogFileDownload is true
		 * it gets respective log file for oracle BA module transfer
		 * */
		boolean isOracleBALogFileDownload = "true".equals(webTransfer.getString("getOracleBALogFile") != null ? webTransfer
				.getString("getOracleBALogFile") : "false" );
		
		if(isOracleBALogFileDownload)
		{
			Schema schema = (new Schema())
					.setServerGroupId(webTransfer.getString("serverGroupId"))
					.setServerName(webTransfer.getString("host"))
					.setSchemaName(webTransfer.getString("schemaName"));
			
			response.setHeader("Content-Disposition", "attachment;filename=\""
					+ NamingUtil.getFilePrefix(schema)+ ".tx.sql_out" + "\"");
			response.setContentType(CONTENT_TYPE);
			InputStream inputStream = engine.getOracleBALogFile(schema);
			if(inputStream!=null){
				IOUtils.copy(inputStream, response.getOutputStream());
			}
			else{
				String fileNotFound = "FILE NOT FOUND";
				InputStream is = new ByteArrayInputStream(fileNotFound.getBytes("UTF-8"));
				IOUtils.copy(is, response.getOutputStream());
			}
			response.flushBuffer();
			return "downloadfile";
		}

		
		/**
		 * 
		 * SHOWING LOGS IN UI ACCORDING TO HOSTING SERVER
		 * 
		 * **/
		
		/**
		 * TO SHOW EXECUTION NUMBER IN UI JIRA VITTOOLS-
		 * **/

		request.setAttribute("execNo", execNo);

		// Central Schema for dmexpress
		String centralHost = fixedParam.getValue(Constants.CS_HOST,hostingServer);
		String centralPort = fixedParam.getValue(Constants.CS_PORT,hostingServer);
		String centralService = fixedParam.getValue(Constants.CS_SERVICE,hostingServer);
		String centralSchemaName = fixedParam.getValue(Constants.CS_SCHEMA,hostingServer);
		String centralSchemaPwd = fixedParam.getValue(Constants.CS_SCHEMAPWD,hostingServer);
	
		Schema centralSchema = (new Schema()).setServerName(centralHost)
				.setPort(centralPort).setService(centralService)
				.setSchemaName(centralSchemaName)
				.setSchemaPwd(centralSchemaPwd);
		
		/**
		 * FOR O2V DATA TRANSFER USING DMEXPRESS
		 * **/
		if(hostingServer.equalsIgnoreCase(Constants.VERTICA)){
			
			// getting eventdetails 
			List eventDetails = engine.getEventDetails(centralSchema, execNo);// 1
			request.setAttribute("eventDetails", eventDetails);
			
			// getting transfersummary
			transferSummary = engine.getTransferSummary(centralSchema, execNo);
			request.setAttribute("transferSummary", transferSummary);

			// gettting success,error and running details
			success = engine.getTransferDetails(centralSchema, execNo, "Y");
			error = engine.getTransferDetails(centralSchema, execNo, "E");
			running = engine.getTransferDetails(centralSchema, execNo, "R");

			// getting error details
			errorDetails = engine.getErrorDetails(centralSchema, execNo);
		}
		/**
		 * FOR O2V DATA TRANSFER USING CMA
		 * **/
		else{
			
			// getting eventdetails 
			List eventDetails = engine.getEventDetails(centralSchema, execNo);// 1
			request.setAttribute("eventDetails", eventDetails);
			
			// getting transfersummary
			transferSummary = engine.getTransferSummary_CMA(centralSchema, execNo);
			request.setAttribute("transferSummary", transferSummary);

			// gettting success,error and running details
			success = engine.getTransferDetails_CMA(centralSchema, execNo, "Y");
			error = engine.getTransferDetails_CMA(centralSchema, execNo, "E");
			running = engine.getTransferDetails_CMA(centralSchema, execNo, "R");
			
			/*
			 * For View
			 */
			successVw = engine.getVwTransferDetails_CMA(centralSchema, execNo, "Y");
			errorVw = engine.getVwTransferDetails_CMA(centralSchema, execNo, "N");

			// getting error details
			errorDetails = engine.getErrorDetails_CMA(centralSchema, execNo);
		}
		

		request.setAttribute("success", success);
		request.setAttribute("error", error);
		request.setAttribute("running", running);
		request.setAttribute("errorDetails", errorDetails);
		
		request.setAttribute("successVw", successVw);
		request.setAttribute("errorVw", errorVw);
		
		request.setAttribute("hostingServer", hostingServer);

		return retVal;
	}

}
