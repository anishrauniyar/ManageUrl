package dashboard.web.pagecontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;
import dashboard.data.OracleSystemData;
import dashboard.data.Schema;

import dashboard.engine.EngineMonitor;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class SysMetricsController extends Controller {


    protected Log logger = LogFactory.getLog(getClass());
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception{
        String retVal = "sysMetrics";
        
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");

        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);

        Schema schema = (new Schema())
            .setServerName( webTransfer.getString("host"))
            .setPort( webTransfer.getString("port"))
            .setService( webTransfer.getString("service"))
            .setSchemaName( webTransfer.getString("schema"))
            //.setSchemaPwd( webTransfer.getString("pwd"))
            .setServerGroupId( webTransfer.getString("serverGroupId"))
            .setSidFlag( webTransfer.getString("sidFlag"))
            .setDatabaseId( webTransfer.getString("databaseId"));
        
        String tab = (webTransfer.getString("tab") ==null)?"":webTransfer.getString("tab");
        if(tab.equals("SCHEMA_ADMIN")){
        	// setting schema creator username and passowd
        	try{
        		schema.setServerGroupId(webTransfer.getString("serverGroupId"));
        		schema = getEngineMonitor(request).setSchemaCreatorUserNPwd(schema);
        	}catch(Exception e){
        		retVal = "messageList";
            	logger.info("Error getting schema creator username and  password for schema : "+schema.getSchemaName());
            	e.printStackTrace();
            	errorList.add( e.getMessage());
                return retVal;
        	}
        }
        else{
            // settting schema password 
            try{
            	schema = getEngineMonitor( request).setSchemaPassword(schema);
            }catch(Exception e){
            	retVal = "messageList";
            	logger.info("Error getting schema password for schema : "+schema.getSchemaName());
            	e.printStackTrace();
            	errorList.add( e.getMessage());
                return retVal;
            }

        }
        
        if (schema.isParamSet()) {
            EngineMonitor engine = getEngineMonitor( request);
            try {
                OracleSystemData sysData = engine.getOracleSystemData(schema);
                request.setAttribute("sysData", sysData );
                request.setAttribute("server",
                                     schema.getServerName() + ":" + schema.getPort() + "/" + schema.getService());
            } catch(Exception ex) {
                retVal = "messageList";
                errorList.add("System experienced problem.");
                errorList.add( ex.getMessage());
                logger.info("Error during sys metrics.", ex);
            }
        } else {
            errorList.add("Not enough parameters.");
            retVal = "messageList";
        }

        return retVal;
    }
}
