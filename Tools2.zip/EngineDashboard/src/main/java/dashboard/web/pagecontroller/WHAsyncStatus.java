package dashboard.web.pagecontroller;

import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.util.EDBUtil;

public class WHAsyncStatus extends Controller {

	private static final String DATE_PATTERN = "MMM d, yyyy HH:mm a, zzzz";

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Locale locale = request.getLocale();
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_PATTERN, locale);

		String retVal = "WHOutput";
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		Boolean isRefreshAgain = Boolean.FALSE;
		String serverGroupId = webTransfer.getString("serverGroupId");
		String wareHouseSchema = webTransfer.getString("wareHouseSchema");
		/*System.out.println("serverGroupId"+serverGroupId);
		System.out.println("wareHouseSchema"+wareHouseSchema);*/

		AsyncSQLProcess sqlProcess = ((EngineMonitor) request
				.getAttribute("EngineMonitor"))
				.getAsyncSQLProcess((new TaskKey()).setServerGroupId(
						serverGroupId).setSchemaName(wareHouseSchema));

		SQLPlusRunnable sqlRunnable = null;
		String desc = "<NO PROCESS>", out_put = "NO MORE PROCESS.";
		if (sqlProcess != null) {
			sqlRunnable = sqlProcess.getSQLPlusRunnable();
			desc = sqlRunnable.getDescription();
			out_put = sqlProcess.getOutput();

			TaskKey task = sqlProcess.getTaskKey();
			request.setAttribute("startedAt",dateFormat.format(sqlProcess.getTaskKey().getStartDate()));
			request.setAttribute("owner", task.getUserName());
			isRefreshAgain = Boolean.TRUE;
		} else {
			request.setAttribute("isRefreshAgain", Boolean.FALSE);
			webTransfer.setString("schema", wareHouseSchema);
			return getPageControllerMap().getController("/lastOutput").process(request, response);
		}
		request.setAttribute("isRefreshAgain", isRefreshAgain);
		request.setAttribute("processName", sqlRunnable.getTaskType().getTaskName());
		request.setAttribute("processLabel", sqlRunnable.getTaskType().getTaskLabel());
		request.setAttribute("processDescription", desc);
		request.setAttribute("serverOutput", out_put);
		request.setAttribute("totalExecTime",EDBUtil.totalTime(sqlProcess.getTaskKey().getStartDate()));
		request.setAttribute("serverGroupId", serverGroupId);
		return retVal;
	}

}
