package dashboard.web.pagecontroller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.security.ProcessingRole;
import dashboard.security.User;
import dashboard.security.UserRole;

public class UserManager extends Controller {

	public static final String LIST_USERS = "LIST_USERS";
	public static final String LIST_ROLES = "LIST_ROLES";
	public static final String CHANGE_USER_ROLES = "CHANGE_USER_ROLES";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String retVal = "userMgmt";
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		EngineMonitor engine = getEngineMonitor(request);
		String action = webTransfer.getString("action");
		// System.out.println(action);

		String userRole = "";

		List<UserRole> userRoleList = null;
		List<User> mappedUserListByUserRole = null;
		List<User> unmappedUserListByUserRole = null;
		if (LIST_ROLES.equals(action) || CHANGE_USER_ROLES.equals(action)) {
			if (CHANGE_USER_ROLES.equals(action)) {
				boolean deleteUsersForAUserRole = (webTransfer
						.getString("deleteUsersForAUserRole") != null) ? true
						: false;
				userRole = webTransfer.getString("userRole");
				int count = 0;
				System.out.println("deleteUsersForAUserRole >>>"
						+ deleteUsersForAUserRole);
				System.out.println("userRole >>" + userRole);
				if (deleteUsersForAUserRole) {
					try {
						count = engine.deleteAllUsersForUserRole(userRole);
						messageList.add("No. of users deleted for role "
								+ userRole + " is :" + count);
					} catch (SQLException e) {
						errorList.add("Could not delete users for role "
								+ userRole + ": " + e.getMessage());
					}
				} else {
					String selectedUsers = webTransfer
							.getString("selectedUsers");
					String userList[] = selectedUsers.split(",");
					try {
						count = engine.changeUserRole(userRole, userList);
						messageList.add("No. of user roles changed :" + count);
					} catch (SQLException e) {
						errorList.add("Could not change user roles : "
								+ e.getMessage());
					}
				}
				retVal = "userRole";
			}
			userRoleList = new ArrayList<UserRole>();
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_SUPERADMIN).setRoleName(
					ProcessingRole.PROCESS_SUPERADMIN));
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_MANAGER).setRoleName(
					ProcessingRole.PROCESS_MANAGER));
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_ADMIN).setRoleName(
					ProcessingRole.PROCESS_ADMIN));
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_USER).setRoleName(
					ProcessingRole.PROCESS_USER));
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_SCRUB_N_VERSION_CONTROL).setRoleName(
					ProcessingRole.PROCESS_SCRUB_N_VERSION_CONTROL));
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_SCRUB).setRoleName(
					ProcessingRole.PROCESS_SCRUB));
			userRoleList.add(new UserRole().setRoleId(
					ProcessingRole.PROCESS_SCRUB_VERSION_CONTROL).setRoleName(
					ProcessingRole.PROCESS_SCRUB_VERSION_CONTROL));
			request.setAttribute("userRoleList", userRoleList);
			retVal = "userRole";
		}
		if (LIST_USERS.equals(action)) {
			userRole = webTransfer.getString("userRole");
			mappedUserListByUserRole = engine.getUserListByUserRole(userRole,
					"MAPPED_USER_LIST");
			unmappedUserListByUserRole = engine.getUserListByUserRole(userRole,
					"UNMAPPED_USER_LIST");
			request.setAttribute("assignedUsers", mappedUserListByUserRole);
			request.setAttribute("availableUsers", unmappedUserListByUserRole);
			retVal = "userMgmt";
		}
		return retVal;
	}
}
