package dashboard.web.pagecontroller.miniEngine;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;

public class MiniEngineConnectionTester extends Controller {

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String retVal = "messageList";
		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		Object[] retTestVal = null;
		Object[] histTestVal = null;

		EngineMonitor engineMonitor = getEngineMonitor(request);
		Schema VCSchema = getVCSchemaForMiniEngine(webTransfer);

		String isDiffServer = webTransfer.getString("isDiffServer");

		System.out.println("History server selected " + isDiffServer);
		if ("Y".equalsIgnoreCase(isDiffServer)) {
			// Getting History Schema
			Schema historySchema = getHistSchemaForMiniEngine(webTransfer);
			try {
				historySchema = engineMonitor.setSchemaPassword(historySchema);
			} catch (Exception e) {
				logger.error("MiniEngineConnectionTester.java>>>Error getting histroy schema password for schema : "
						+ historySchema.getSchemaName());
				e.printStackTrace();
				errorList.add(e.getMessage());
				return retVal;
			}
			histTestVal = engineMonitor.isValid(historySchema);
			if (Boolean.TRUE.equals(histTestVal[0])) {
				ValidatorRoot.getMessageList(request).add(
						"[History Schema]Successfully connected.");
			} else {
				List errors = ValidatorRoot.getErrorList(request);
				errors.add("[History Schema] Connection failure ");
				errors.add(histTestVal[1]);
			}
		}
		// setting password for VC Schema
		try {
			VCSchema = engineMonitor.setSchemaPassword(VCSchema);
		} catch (Exception e) {
			logger.error("MiniEngineConnectionTester.java>>>Error getting front schema password for schema : "
					+ VCSchema.getSchemaName());
			e.printStackTrace();
			errorList.add(e.getMessage());
			return retVal;
		}
		retTestVal = engineMonitor.isValid(VCSchema);
		if (Boolean.TRUE.equals(retTestVal[0])) {
			ValidatorRoot.getMessageList(request).add(
					"[Mini Engine Schema]Successfully connected.");
		} else {
			List errors = ValidatorRoot.getErrorList(request);
			errors.add("[Mine Engine Schema] Connection failure ");
			errors.add(retTestVal[1]);
		}
		return retVal;
	}
}