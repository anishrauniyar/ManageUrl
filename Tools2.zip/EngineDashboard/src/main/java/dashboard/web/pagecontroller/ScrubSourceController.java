package dashboard.web.pagecontroller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Report;
import dashboard.data.SourceControlUser;
import dashboard.data.WebTransfer;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.util.ClientSpecficModuleConstants;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;


public class ScrubSourceController extends Controller {

    private static final String ACTION = "vc_action";
    private static final String CHECKOUT = "CHECKOUT";
    private static final String LIST_URL = "LIST_URL";
    private static final String MOD_NAME = "MOD_NAME";

    private static final String VC_LOGIN_NAME = "svnUserName";
    private static final String VC_PASSWORD = "svnPassword";
    private static final String VC_URL = "VC_URL";

    private static final String HP_MODULES = "HP Modules";
    private static final String VC_MODULES = "VC Modules";
    

    private static Log logger = LogFactory.getLog(SourceController.class);
    
    private EnvInfo envInfo = null;

    public void setEnvInfo(EnvInfo e) {
        envInfo = e;
    }
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "scrubVersionControl";

        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        
        String action = webTransfer.getString(ACTION);
        
        EngineMonitor engine = getEngineMonitor(request);
        EventLogger eventLogger = ComponentFactory.getInstance().getEventLogger();
        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();
        String error = "";

        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        
      
        String vcUrl = webTransfer.getString( VC_URL);
        String modName = webTransfer.getString( MOD_NAME);
        String engVersion = webTransfer.getString("ENG_VERSION");
        
        List lsEngineVersions = engine.getEngineVersionList();
        request.setAttribute("lsEngineVersions", lsEngineVersions);
        
        String output = "";
        String svnUserName= null;
        String svnPassword= null;
        String event = Constants.VERSION_CONTROL_EVENT;
        String desc = "Version Control of " +modName+" from "+vcUrl;
        Date startDate = new Date(System.currentTimeMillis());
        /**
         * GETTING USERNAME AND PASSWORD FOR SVN CHECKOUT/LISTING
         */
        try{
        	svnUserName = fixedParam.getDashboardParams(VC_LOGIN_NAME);
        	svnPassword = fixedParam.getDashboardParams(VC_PASSWORD);
        }catch(Exception e){
        	logger.error("Error while getting SVN Username/Password:",e);
        	errorList.add(e.getMessage());
        	/**
        	 * Event log only for CHECKOUT case
        	 */
        	if(action.equals(CHECKOUT)){
        		eventLogger.logError(loginName, event, desc, 0, startDate,
    					new Date(System.currentTimeMillis()),e.getMessage(), null);
        	}
        	retVal = "messageList";
        	return retVal;
        }
        
        SourceControlUser scUser =
            ( new SourceControlUser())
            .setUserName(svnUserName)
            .setPassword(svnPassword);
            
		/**
		 * JIRA : VITTOOLS-384
		 */
		Report HPModules = new Report()
				.setReportName(HP_MODULES)
				.setReportDesc(
						"HP Modules. Location is configured in the application")
				.setSourceDir(envInfo.getHP_MODULES_DIR().getAbsolutePath());
		request.setAttribute("HPModules", HPModules);
		Report VCModules = new Report()
				.setReportName(VC_MODULES)
				.setReportDesc(
						"VC Modules. Location is configured in the application")
				.setSourceDir(envInfo.getVC_MODULES_DIR().getAbsolutePath());
		request.setAttribute("VCModules", VCModules);
		Report HPandVCClientSpecificModules = new Report()
				.setReportName(ClientSpecficModuleConstants.HP_VC_CLIENT_SPECIFIC_MODULES)
				.setReportDesc(
						"HP and VC Client Specific Modules. Location is configured in the application")
				.setSourceDir(
						envInfo.getHP_VC_CLIENT_SPECIFIC_MODULES_DIR()
								.getAbsolutePath());
		request.setAttribute("HPandVCClientSpecificModules",
				HPandVCClientSpecificModules);

        if ( LIST_URL.equals(action) || CHECKOUT.equals(action) ) {
        	retVal = "scrubVersionControlOutput";

            if (scUser.isAllParamSet()) {
                if (LIST_URL.equals(action)) {
                    if ( null != vcUrl && !"".equals(vcUrl.trim())) {
                        output = engine.listDirectory( scUser, vcUrl.trim());
                        logger.info("cmd out: " + output);
                        if ("".equals(output)) {
                            messageList.add("No output returned.");
                        }
                    } else {
                        errorList.add("Missing source control url.");
                        retVal = "messageList";
                    }
                }
                else if( CHECKOUT.equals(action)) {
                	if (null != vcUrl && !"".equals(vcUrl)) {
                        String listing = engine.listDirectory( scUser, vcUrl.trim());
                        if (null == listing || "".equals( listing.trim())) {
                            output = "Version control did not return anything. Make sure you can login and see the listing.";
                        } else {
                        	if ( HPModules.getReportName().equals( modName)) {
                            	output = SourceController.checkOut(scUser, vcUrl, HPModules, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( VCModules.getReportName().equals( modName)) {
                            	output = SourceController.checkOut(scUser, vcUrl, VCModules, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( HPandVCClientSpecificModules.getReportName().equals( modName)) {
                            	output = SourceController.checkOut(scUser, vcUrl, HPandVCClientSpecificModules, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }
                        }
                    } else {
                    	error = "Missing source control url.";
                        errorList.add(error);
                        retVal = "messageList";
                    }
                }
                if (null != output && "".equals(output.trim()) ) {
                    messageList.add("No output from version control client.");
                }

            } else {
                errorList.add("Both username and password for version control system required.");
                retVal = "messageList";                    
            }
        } else {
            List ls = engine.listReportModules();
            request.setAttribute("ls", ls);
        }
        request.setAttribute("vcOutput", output);

        return retVal;
    }
}

