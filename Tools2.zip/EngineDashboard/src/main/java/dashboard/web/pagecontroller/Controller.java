package dashboard.web.pagecontroller;


import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.engine.EngineMonitor;
import dashboard.engine.TaskKey;
import dashboard.security.ProcessingRole;
import dashboard.util.Constants;

public abstract class Controller extends CommonMethods implements PageController  {

    protected PageControllerMap pageControllerMap;
    protected Log logger = LogFactory.getLog(getClass());
    protected Schema destVtkaSchema = null;
    protected Schema destOrclSchema = null;
    /**
	 * VITTOOLS-383 : BA module not in use , so runBAModule is set to false
	 * by default
	 */
    protected String runBAModule = Constants.FALSE;
    protected boolean vtkaSchemaInfoInserted = false;
    
    public void setPageControllerMap(PageControllerMap pgControllerMap) {
        pageControllerMap = pgControllerMap;
    }
    protected PageControllerMap getPageControllerMap() {
        return pageControllerMap;        
    }

    /**
     * authorization disabled by default.
     * sub-classes need to enable it based on their requirement.
     */
    public boolean isAuthorizationEnabled() {
        return false;
    }
    /**
     * @return default processing role
     */
    public ProcessingRole getRequiredRole() {
        return ProcessingRole.PROCESS_USER;
    }

    protected EngineMonitor getEngineMonitor(HttpServletRequest request) {
        EngineMonitor engineMonitor = (EngineMonitor) request.getAttribute("EngineMonitor");
        if (engineMonitor == null) {
            engineMonitor = ComponentFactory.getInstance().getEngineMonitor("NO_LOGIN_YET");
        }
        return engineMonitor;
    }
    
	protected synchronized String allowO2VDataTransfer(HttpServletRequest request, Schema srcSchema , Schema destSchema){
		logger.info("Checking if oracle to vertica data transfer is already running");
		TaskKey [] taskKeys = getEngineMonitor(request).getTaskKeys();
		String O2VStatus = "";
    	if(taskKeys!=null){
    		for(TaskKey taskKey:taskKeys){
    			
    			// checking for source server
    			if((taskKey.getSrcHost().equals(srcSchema.getServerName())) && (taskKey.getSrcSchemaName().equals(srcSchema.getSchemaName()))){
    				logger.info("Data Transfer Process in already taking place in "+srcSchema.getServerName()+"/"+srcSchema.getSchemaName());
    				O2VStatus = "Data Transfer Process in already taking place in "+srcSchema.getServerName()+"/"+srcSchema.getSchemaName();
    				break;
    			}
    			
    			// checking for destination server
    			if((taskKey.getServerGroupId().equals(destSchema.getServerGroupId())) && (taskKey.getSchemaName().equals(destSchema.getSchemaName()))){
    				logger.info("Data Transfer Process in already taking place in "+destSchema.getServerGroupName()+"/"+destSchema.getSchemaName());
    				O2VStatus = "Data Transfer Process in already taking place in "+destSchema.getServerGroupName()+"/"+destSchema.getSchemaName();
    				break;
    			}
    		}
    	}
    	
    	return O2VStatus;
	}
	
    /**
     * @Description 
     * 1. Sets schema pwd for destination vertica and oracle schema
     * 2. First checks if the pwd for the given schema is 
     *    already inserted or not in processing.platform_schema_info,if already inserted then sets that pwd
     * 3. Else, generates new pwd and sets the generated pwd to schema.
     * Note: For Vertica Schema, generated pwd will be used for all the vertica nodes of server group    
     * @param request
     * @throws Exception
     */
    protected synchronized void setPwdForSchema(HttpServletRequest request) throws Exception
    {
        vtkaSchemaInfoInserted = false;
        EngineMonitor engineMonitor = getEngineMonitor(request);
        /*
         * FOR VERTICA
         */
        vtkaSchemaInfoInserted = engineMonitor.isSchemaInfoAlreadyInserted(destVtkaSchema);
        System.out.println("Vertica Schema " + destVtkaSchema.getSchemaName() + " info inserted>>" + vtkaSchemaInfoInserted);
        if (vtkaSchemaInfoInserted)
        {
            // get password from database
            logger.info("Password for Vertica DR Schema " + destVtkaSchema.getSchemaName() + " with dbid " + destVtkaSchema.getDatabaseId()
                    + " is already inserted!!!!");
            destVtkaSchema = engineMonitor.setSchemaPassword(destVtkaSchema);
            System.out.println("So password for vertica DR schema " + destVtkaSchema.getSchemaName() + " is " + destVtkaSchema.getSchemaPwd());
        } else
        {
            // generating password for vertica and storing schema details
            // generating password
        	
        	/**
        	 * [VITTOOLS-358] Same pwd for S schema in vertica.
        	 * To check if the schema pwd exists in mapped clusters or not
        	 */
        	logger.info("Checking pwd in mapped clusters for schema "+destVtkaSchema);
        	String schemaPwdFromMappedCluster = engineMonitor.getSchemaPwdFromMappedClusters(destVtkaSchema);
        	if(schemaPwdFromMappedCluster!=null &&  schemaPwdFromMappedCluster!=""){
        		logger.info("Password for schema "+destVtkaSchema+" was found in mapped clusters");
        		destVtkaSchema.setSchemaPwd(schemaPwdFromMappedCluster);
        		engineMonitor.insertSchemaInfoForVertica(destVtkaSchema.getServerGroupId(), destVtkaSchema.getSchemaName(), destVtkaSchema.getSchemaPwd());
        		vtkaSchemaInfoInserted = true;
        	}
        	else{
        		logger.info("Generating new schema pwd for "+destVtkaSchema);
        		destVtkaSchema = engineMonitor.generateSchemaPassword(destVtkaSchema);
                // storing schema details
                engineMonitor
                        .insertSchemaInfoForVertica(destVtkaSchema.getServerGroupId(), destVtkaSchema.getSchemaName(), destVtkaSchema.getSchemaPwd());
        	}
        }
        
        /*
         * FOR BA MODULE
         */
        if (runBAModule.equalsIgnoreCase("TRUE"))
        {
            // check if schema info for dest oracle schema alerady
            // exists
            boolean destOrclSchemaInfoAlreadyInserted = false;
            destOrclSchemaInfoAlreadyInserted = engineMonitor.isSchemaInfoAlreadyInserted(destOrclSchema);
            if (destOrclSchemaInfoAlreadyInserted)
            {
                logger.info("Getting schema password for destination oracle schema " + destOrclSchema.getSchemaName()
                        + "from processing.platform_schema_info");
                // getting password
                destOrclSchema = engineMonitor.setSchemaPassword(destOrclSchema);
            } else
            {
                logger.info("Setting same password as for vertica for destination oracle schema " + destOrclSchema.getSchemaName());
                // using same password as for vertica
                destOrclSchema.setSchemaPwd(destVtkaSchema.getSchemaPwd());
                // inserting destination oracle schema info
                engineMonitor.insertSchemaInfo(destOrclSchema);
            }
        }
        
    }
    
    protected String encryptPassword(String password){
    	if(password != null && !"".equalsIgnoreCase(password)){
    		return CaseSensitiveEncoder.encode(password);
    	}
    	return "";
    }
    
}
