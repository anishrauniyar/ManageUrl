package dashboard.web.pagecontroller;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.EngineTask;
import dashboard.data.ReplaceSchema;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.OracleServerInfo;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;


public class ProcessManager extends Controller {

    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));

    private static final String ENGINE_PARAM = "ENGINE_PARAM";
    private static final String INDEX_PARAM = "INDEX_PARAM";
    private static final String REPORT_PARAM = "REPORT_PARAM";
    private static final String LIST_REPORT = "LIST_REPORT";
    private static final String LIST_MODULES = "LIST_MODULES";
    private static final String DATAFILE_LIST = "DATAFILE_LIST";
    private static final String LIST_PARTITIONS = "LIST_PARTITIONS";
    private static final String DISTRIBUTE_PARTITIONS = "DISTRIBUTE_PARTITIONS";
    private static final String SERVER_LIST = "SERVER_LIST";
    private static final String VERTICA_SERVER_LIST = "VERTICA_SERVER_LIST";
    private static final String DMEXPRESS_SERVER_LIST = "DMEXPRESS_SERVER_LIST";
    private static final String HIST_SERVER_LIST = "HIST_SERVER_LIST";
    private static final String SERVER_GROUP = "SERVER_GROUP";
    private static final String TEST_CONNECTION = "TEST_CONNECTION";
    private static final String RUN_ENGINE = "RUN_ENGINE";
    private static final String RUN_INDEX = "RUN_INDEX";
    private static final String UPDATE_STATUS = "UPDATE_STATUS";
    private static final String RUN_REPORT = "RUN_REPORT";
    private static final String DATA_TRANSFER_PARAM = "DATA_TRANSFER_PARAM";
    private static final String TRANSFER_DATA = "TRANSFER_DATA";
    private static final String REPORTS_ASSIGNED = "REPORTS_ASSIGNED";
    private static final String LIST_DIR = "LIST_DIR";
    

    private static final String S_TRUE = "TRUE";

    private static final RunningStatus RUNNING_STATUS = new RunningStatus();
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "processOutput";
        Boolean isRefreshAgain = Boolean.TRUE;
        
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        
        User user = (User)request.getSession().getAttribute("session:user");
        
        String action = webTransfer.getString("action");
        EngineMonitor engine = getEngineMonitor(request);
        
        String serverGroupId = webTransfer.getString("serverGroupId");
        serverGroupId = (serverGroupId == null)? "": serverGroupId.trim();
        
        String engineVersion = "";
        String dxcgParam = webTransfer.getString("dxcgParam");
        String dxcgProcess = webTransfer.getString("dxcgProcessed");
        
        if( null != webTransfer.getString("frontSchema") &&
                !"".equalsIgnoreCase(webTransfer.getString("frontSchema"))){
            engineVersion = engine.getEngineVersionForSchema(webTransfer.getString("frontSchema"));
            logger.info("Engine version from OAM : {}"+engineVersion );
        }

        //Override setting for engine version by user
        if ( null != webTransfer.getString("overrideEngineVersion")
                && webTransfer.getString("overrideEngineVersion").equalsIgnoreCase("TRUE")
                && null != webTransfer.getString("ENG_VERSION")
                && !"".equals(webTransfer.getString("ENG_VERSION").trim())){
            engineVersion = webTransfer.getString("ENG_VERSION").trim();
            logger.info("Engine version overriden by user : {}"+engineVersion);
        }
        
        Schema psSchema = (new Schema())
        	.setServerGroupId( serverGroupId)
        	.setServerName( webTransfer.getString("host") )
        	.setPort( webTransfer.getString("port"))
        	.setService( webTransfer.getString("service"))
        	.setSchemaName( webTransfer.getString("frontSchema") )
        	//.setSchemaPwd( webTransfer.getString("frontPassword"))
        	.setDatabaseId( webTransfer.getString("databaseId"))
        	.setSidFlag( webTransfer.getString("sidFlag"))
        	.setEngineVersion(engineVersion)
        	.setClientName(engine.getClientName(webTransfer.getString("frontSchema")))
        	.setDxCGProcess(dxcgProcess);
        	//.setEncodePassword(encryptPassword(webTransfer.getString("frontPassword")));
        
        List lsServerGroups = lsEmpty;
        List lsServers = lsEmpty;
        List histServerGroups = lsEmpty;
        List histServers = lsEmpty;
        List statusList = lsEmpty;
        List lsReports  = lsEmpty;
        List lsReportModules = lsEmpty;
        List lsEngineVersions = lsEmpty;      
        List lsDataFile= lsEmpty;
        List lsDirs = lsEmpty;
        
        lsEngineVersions = engine.getEngineVersionList();
        
        List lsDxcgHost = engine.getDxCGHostList(); 
                
        //String histSchemaPwd = "";
        String histServerName = "";
        String histServerPort = "";
        String histServerSid = "";
        String _histSchema = "";
        String histDatabaseId = "";
        
        String isDifferentServer = webTransfer.getString("isDiffServerVal");
        
        if("Y".equalsIgnoreCase(isDifferentServer)){
        	//histSchemaPwd = webTransfer.getString("historyPassword");
            histServerName = webTransfer.getString("histhost");
            histServerPort = webTransfer.getString("histport");
            histServerSid = webTransfer.getString("histservice");
            _histSchema = webTransfer.getString("histSchema");
            histDatabaseId = webTransfer.getString("histdatabaseId");
        }
        
        Schema histSchema = (new Schema ())
            				//.setSchemaPwd(histSchemaPwd)
            				.setServerName(histServerName)
            				.setPort(histServerPort)
            				.setService(histServerSid)
        					.setSchemaName(_histSchema)
        					.setDatabaseId(histDatabaseId);
        
        RunningStatus runningStatus = RUNNING_STATUS;
        String serverGroup_id="";
        
        List lsReportsAssigned = lsEmpty;
        List lsReportsNotAssigned = lsEmpty;
        if(REPORTS_ASSIGNED.equals( action)){  
        	retVal = "list".equals(webTransfer.getString("type")) ? 
        			 "assignedReportsList": "assignedReportsChoice";  	
	        	Schema schema = (new Schema())
	            .setServerGroupId( serverGroupId)
	            .setServerName( webTransfer.getString("host") )
	            .setPort( webTransfer.getString("port"))
	            .setService( webTransfer.getString("service"))
	            .setSchemaName( webTransfer.getString("frontSchema") )
	            .setSchemaPwd( webTransfer.getString("frontPassword"))
	            .setSidFlag( webTransfer.getString("sidFlag"))
	            .setEngineVersion(engineVersion)
//	            .setEngineVersion(webTransfer.getString("ENG_VERSION"))
	            .setClientName(engine.getClientName(webTransfer.getString("frontSchema")));
	        
	        	lsReportsAssigned = engine.listReportModulesOAM(schema);
	        	lsReportsNotAssigned = engine.listOtherReportModulesOAM(schema);
	        	
        } else if(ENGINE_PARAM.equals( action) || REPORT_PARAM.equals(action) ||
           INDEX_PARAM.equals(action) || DATA_TRANSFER_PARAM.equals(action)  ) {
        	lsServerGroups = engine.getServerGroupListForProcessing();
        	histServerGroups = engine.getHistServerGroupListForProcessing();
            if ( ENGINE_PARAM.equals(action)) {
                retVal = "setupEngineParam";
                //lsReportModules = engine.listReportModules(); 
            } else if ( REPORT_PARAM.equals( action)) {
                retVal = "setupReportParam";
                lsReportModules = engine.listReportModules();
                //lsReportModules = engine.listReportModulesOAM();
            } else if ( INDEX_PARAM.equals( action)) {
                retVal = "setupIndexParam";
            } else if ( DATA_TRANSFER_PARAM.equals(action)) {
            	List lsVerticaServerGroups = null;
            	List lsDMExpressServerGroups = null;
            	List lsVerticaDRServerGroups = null;
            	List lsOracleDRServerGroups	 = null;
            	List lsVerticaClusterGrps = null;
            	List lsVerticaDRClusterGrps = null;
            	String hostingServer = webTransfer.getString("hostingServer");
            	if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
                {
                	lsVerticaServerGroups = engine.getServerGroupList(hostingServer);
            		lsDMExpressServerGroups = engine.getServerGroupList(Constants.DMEXPRESS);
                }
            	else if(hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA)){
            		//lsVerticaServerGroups = engine.getServerGroupList(Constants.VERTICA);
            		//lsVerticaServerGroups	= engine.getVerticaRACServerGroupList();
            		lsVerticaDRServerGroups	= engine.getVerticaDRServerGroupList();
            		lsOracleDRServerGroups	= engine.getServerGroupListForOracleDR();
            		lsVerticaClusterGrps    = engine.listVerticaClusterGrp("PROD");
            		lsVerticaDRClusterGrps =engine.listVerticaClusterGrp("DR");
            	}
            	request.setAttribute("hostingServer", hostingServer);
            	request.setAttribute("lsVerticaClusterGrps",lsVerticaClusterGrps);
            	request.setAttribute("lsVerticaDRClusterGrps",lsVerticaDRClusterGrps);
            	request.setAttribute("lsVerticaServerGroups",lsVerticaServerGroups);
            	request.setAttribute("lsDMExpressServerGroups",lsDMExpressServerGroups);
            	request.setAttribute("lsOracleDRServerGroups", lsOracleDRServerGroups);
            	request.setAttribute("verticaServerGroup_DR", lsVerticaDRServerGroups);
                retVal = "setupDataTransferParam";
            } 
            
        }//to list servers for oracle source/destination
        else if (SERVER_LIST.equals( action)) {
        	boolean runBaModule = false;
        	if(webTransfer.getString("runBaModule") !=null)
        	{
        	    //System.out.println("Run BA MOdule "+webTransfer.getString("runBaModule"));
        	    runBaModule = (webTransfer.getString("runBaModule").equalsIgnoreCase("true"))?true:false;
        	}
            
        	//to list source server for oracle
        	String source = webTransfer.getString("source");
            
        	if(source == null)
            {
        		retVal = "serverList";
            }
            else if(source.equalsIgnoreCase(Constants.ORACLE))
            {
            	String hostingServer = webTransfer.getString("hostingServer");
            	request.setAttribute("hostingServer", hostingServer);
            	retVal = "sourceServerList";
            }
            
            if(runBaModule)
            {
                lsServers = engine.getVIPServersForServerGrp(serverGroupId);
            }
            else{
                lsServers = engine.getServersForServerGroup(serverGroupId);
            }
            
        	if (lsServers.size() == 1) {
                request.setAttribute("isSingleServer", Boolean.TRUE);
            } else {
                request.setAttribute("isSingleServer", Boolean.FALSE);
            }
            
        }
        //to list servers for destination vertica
        else if (VERTICA_SERVER_LIST.equals( action)) {
        	String hostingServer = webTransfer.getString("hostingServer");
        	request.setAttribute("hostingServer", hostingServer);
        	List lsVerticaServers = null;
        	lsVerticaServers = engine.getServersForServerGroup(serverGroupId);
        	
        	request.setAttribute("lsVerticaServers", lsVerticaServers);
        	retVal = "verticaServerList";
            
        }
        //to list servers for destination dmexpress
        else if (DMEXPRESS_SERVER_LIST.equals( action)) {
        	List lsDMExpressServers = null;
        	lsDMExpressServers = engine.getServersForServerGroup(serverGroupId);
        	
        	request.setAttribute("lsDMExpressServers", lsDMExpressServers);
        	retVal = "dmExpressServerList";
            
        }else if (HIST_SERVER_LIST.equals(action)){
        	retVal = "histServerList";
        	histServers = engine.getServersForHistServerGroup(serverGroupId);
        	if (histServers.size() == 1) {
                request.setAttribute("isSingleHistServer", Boolean.TRUE);
            } else {
                request.setAttribute("isSingleHistServer", Boolean.FALSE);
            }
        }
        
        else if ( DATAFILE_LIST.equals(action)) {
            retVal = "dataFileList";
        	lsDataFile = engine.getDataFileDirsForServerGroup(serverGroupId);
        	if(lsDataFile.size()==1){
        		request.setAttribute("isSingleDataFile", Boolean.TRUE);
        	} else{
        		request.setAttribute("isSingleDataFile", Boolean.FALSE);
        	}
        	System.out.println("ServerGroup:"+serverGroupId+":Dir:"+lsDataFile.size());
        	if(lsDataFile.size()>0){
        		System.out.println(((dashboard.data.DataFileDir)lsDataFile.get(0)).getDataFileDir());
        	}
        	request.setAttribute("lsDataFile",lsDataFile);
        }else if ( RUN_ENGINE.equals(action)) {
        	String event = "Process Engine";
        	String desc = psSchema.getServerName() + ":" + psSchema.getPort() + "/" +
        			      psSchema.getService() + ":" + psSchema.getSchemaName() ;
        	retVal = "processOutput";
        	AsyncSQLProcess sqlProcess =null; 
        	
        	/*
        	 * setting password for front and history schema
        	 */
			try {
				psSchema = engine.setSchemaPassword(psSchema);
				psSchema.setEncodePassword(encryptPassword(psSchema.getSchemaPwd()));
				
				if("Y".equalsIgnoreCase(isDifferentServer)){
					histSchema = engine.setSchemaPassword(histSchema);
				}
			} catch (Exception e) {
				logger.error("ProcessManager.java (RUN-ENGINE) >> Error getting password for schema");
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
				// show error in event log
				ComponentFactory.getInstance().getEventLogger().logError(
								loginName,event, desc, 0, new Date(), new Date(), sw.toString() , psSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
        				            
            try{
                     
	            /*ReplaceSchema replSchema =(new ReplaceSchema())
	            	.setHawkeyeMaster(webTransfer.getString("hawkeyeMaster"))
	            	.setHawkeyeQRM(webTransfer.getString("hawkeyeQRM"))
	            	.setReplaceHawkeyeMaster(S_TRUE.equals( webTransfer.getString("replaceHawkeyeMaster")))
	            	.setReplaceHawkeyeQRM(S_TRUE.equals( webTransfer.getString("replaceHawkeyeQRM"))); 
	            */
	            EngineMonitor engineMonitor = getEngineMonitor(request);
	           
	            if("Y".equalsIgnoreCase(isDifferentServer)){
	            	Schema historySchema = (new Schema()).setServerName( webTransfer.getString("histhost") )
	    			  .setPort( webTransfer.getString("histport"))
	    			  .setService( webTransfer.getString("histservice"))
	    			  .setSchemaName( webTransfer.getString("histSchema"))
	    			  //.setSchemaPwd( webTransfer.getString("historyPassword"));
	    			  .setDatabaseId( webTransfer.getString("histdatabaseId"));
	            	
					// setting password for history schema
					try {
						historySchema = engine.setSchemaPassword(historySchema);
					} catch (Exception e) {
						logger.error("ProcessManager.java (RUN-ENGINE) >> Error getting password for history schema "
								+ historySchema.getSchemaName());
						// inserting exception caught to logger.
						StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
						// show error in event log
						ComponentFactory.getInstance().getEventLogger().logError(
										loginName,event, desc, 0, new Date(), new Date(), sw.toString() , historySchema);
						// show error in UI
						errorList.add(e.getMessage());
						return retVal;
					}
	            	String histSidFlag = webTransfer.getString("histsidFlag");
	    			if(histSidFlag != null){
	    				historySchema = historySchema.setSidFlag(webTransfer.getString("histsidFlag"));
	    			}
	    			Object [] histTestVal = engineMonitor.isValid(historySchema);
	    			if(Boolean.TRUE.equals( histTestVal[0])){
	               	 	ValidatorRoot.getMessageList( request).add("[History Schema]Successfully connected.");
	                }else{
	               	 	List errors = ValidatorRoot.getErrorList( request);
	               	 	errors.add("[History Schema] Connection failure ");
	              	    errors.add(histTestVal[1]);
	              	    return retVal;
	                }
	            }
	            
	            String engVersionNo = engineVersion.substring(1, engineVersion.length());            
	            boolean isReplace_Master_QRM = engVersionNo.compareTo("5")>-1;
	            ReplaceSchema replSchema =(new ReplaceSchema())
	    		        	  .setHawkeyeMaster(isReplace_Master_QRM?"HAWKEYEMASTER5":"HAWKEYEMASTER")
	    		        	  .setHawkeyeQRM(isReplace_Master_QRM?"HAWKEYEQRM5":"HAWKEYEQRM")
	    		        	  .setReplaceHawkeyeMaster(isReplace_Master_QRM)
	    		        	  .setReplaceHawkeyeQRM(isReplace_Master_QRM); 
	            
	            if ( !engine.hasValidServerGroup( psSchema)) {
	                throw new IllegalArgumentException("Non existent combination of ServerGroupId|Host|Port|Service");
	            }
	            /**
	             * runDQE feature is disabled from 05.08.00 release
	             */
	            //boolean runDQE = "Y".equals( webTransfer.getString("processDQE"));
	            boolean runDQE = false;
	            int degOfParallelism = 1;
	            try {
	                degOfParallelism = Integer.parseInt(webTransfer.getString("degreeOfParallelism"));
	            } catch(Exception nfe) {}
	            
	            String parallel = (webTransfer.getString("parallel")==null)?"N":webTransfer.getString("parallel");
                List reportList = new LinkedList();
                
                if(webTransfer.getStringArray("reportsAssigned") != null ){
                    logger.debug("reportsAssigned:"+webTransfer.getStringArray("reportsAssigned"));
                    reportList = new LinkedList(Arrays.asList(webTransfer.getStringArray("reportsAssigned")));
                    //reportList.addAll((Arrays.asList(webTransfer.getStringArray("reportsAssigned"))));
                }
                logger.debug("reportList:"+reportList);
                if("1".equalsIgnoreCase(dxcgParam)){
                	reportList.remove(reportList.indexOf("1039"));
                	reportList.remove(reportList.indexOf("1040"));
                }
                if("2".equalsIgnoreCase(dxcgParam)){
                	reportList.remove(reportList.indexOf("1040"));
                }
                
                logger.debug("reportList:"+reportList);
                
                String [] reportNames = new String[reportList.size()];
                reportList.toArray(reportNames);

                String [] reportModules = webTransfer.getStringArray("reportModules");
                
                String dxcgHostUrl = webTransfer.getString("DxCGHostUrl");
                
                boolean runDXCGVerification=false;
                boolean dxcgVerification=engine.checkDXCGVerification();
                logger.info("dxcgVerification:"+dxcgVerification);
                
                if(S_TRUE.equals(webTransfer.getString("EXECUTE_ENGINE")) && dxcgVerification){
                	runDXCGVerification=true;
                }
                
                logger.info("runDXCGVerification:"+runDXCGVerification);
                
              EngineTask engineTask = (new EngineTask())
	                .setRunObjectScript( S_TRUE.equals(webTransfer.getString("RUN_OBJECT")))
	                .setCompileEngine(  S_TRUE.equals(webTransfer.getString("COMPILE_ENGINE")))
				                .setExecuteEngine(  S_TRUE.equals(webTransfer.getString("EXECUTE_ENGINE")))
				                .setRunIndex(S_TRUE.equals(webTransfer.getString("RUN_INDEX")))
				                .setRunFQCReport(S_TRUE.equals(webTransfer.getString("RUN_FQC_REPORT")))
				                .setRunDXCGRecordCount(runDXCGVerification)
				                .setRunReport(reportNames!=null && reportNames.length>0);  

                sqlProcess = engine.executeEngine(psSchema, replSchema, runDQE, degOfParallelism, parallel, engineTask, reportNames, 
                					reportModules, user, dxcgHostUrl,histSchema,isDifferentServer,dxcgParam,dxcgProcess);
	            
	            SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
	            isRefreshAgain = Boolean.TRUE;
	            TaskType taskType = sqlRunnable.getTaskType();
	            TaskKey taskKey = sqlProcess.getTaskKey();
		             
	            messageList.add( sqlRunnable.getDescription());
	            request.setAttribute("schema", psSchema);
	            
	            if ( ( loginName.equals( taskKey.getUserName() )) &&
		                 (TaskType.EXECUTE_OBJECT_SCRIPT.equals(taskType) ||
		                  TaskType.COMPILE_ENGINE_SCRIPT.equals(taskType) ||
		                  TaskType.EXECUTE_ENGINE.equals(taskType)  ||
		                  TaskType.INDEXING.equals(taskType) ||
		                  TaskType.DXCG_RECORD_COUNT.equals(taskType) ||
		                  TaskType.FQC_REPORT.equals(taskType)) ||
		                  TaskType.PROCESS_SCRIPT_OR_REPORT.equals(taskType)){
	            	
	                messageList.add("Currently queued: " + taskType.toString());
		        } else {
	                errorListMsg(errorList, taskType, taskKey);
	                isRefreshAgain = Boolean.FALSE;
		       }

            } catch (Exception e) {
	           	
	           	if (e.getMessage().equals("Max Dop Exceeded!!!")){
	           		System.out.println("Max Dop Exceeded!! Cannot run new Process until one of the running gets completed!!!");
	       			errorList.add("Max Dop Exceeded!! Cannot run new Process until one of the running gets completed!!!");
	       			isRefreshAgain = Boolean.FALSE;
				}
	           	else if(e.getMessage().equals("No process ready to share Dop!!!")){
	           		System.out.println("No process Ready to share Dop!!!");
	           		errorList.add("No process ready to share Dop!!!");
	           		isRefreshAgain = Boolean.FALSE;
	           	} else {
                       throw e;
                   }
	       }

        } else if (LIST_REPORT.equals(action)) {
        	retVal = "reportList";	        
            lsReports = engine.getReportsByReportName(engineVersion, webTransfer.getString("reportName"));
        } else if ( RUN_REPORT.equals( action)) {
        	retVal = "processOutput";
            //String reportName = webTransfer.getString("reportName");
            Schema schema = (new Schema())
                .setServerGroupId( serverGroupId)
                .setServerName( webTransfer.getString("host") )
                .setPort( webTransfer.getString("port"))
                .setService( webTransfer.getString("service"))
                .setSchemaName( webTransfer.getString("frontSchema") )
                //.setSchemaPwd( webTransfer.getString("frontPassword"))
                .setDatabaseId( webTransfer.getString("databaseId"))
                .setSidFlag( webTransfer.getString("sidFlag"))
                .setEngineVersion(engineVersion)
                //.setEngineVersion(webTransfer.getString("ENG_VERSION"))
                .setClientName(engine.getClientName(webTransfer.getString("frontSchema")))
                .setDxCGProcess(dxcgProcess);
                //.setEncodePassword(encryptPassword(webTransfer.getString("frontPassword")));
            
            String event = "Process Report";
        	String desc = schema.getServerName() + ":" + schema.getPort() + "/" +
        			      schema.getService() + ":" + schema.getSchemaName() ;  
            /*
        	 * setting password for front schema
        	 */
			try {
				schema = engine.setSchemaPassword(schema);
			} catch (Exception e) {
				logger.error("ProcessManager.java (RUN_REPORT) >> Error getting password for schema");
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
				// show error in event log
				ComponentFactory.getInstance().getEventLogger().logError(
				loginName,event, desc, 0, new Date(), new Date(), sw.toString() , schema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
				
            
            String engVersionNo = engineVersion.substring(1, engineVersion.length());
            boolean isReplace_Master_QRM = engVersionNo.compareTo("5")>-1;            
            ReplaceSchema replSchema =(new ReplaceSchema())
    		        	  .setHawkeyeMaster(isReplace_Master_QRM?"HAWKEYEMASTER5":"HAWKEYEMASTER")
    		        	  .setHawkeyeQRM(isReplace_Master_QRM?"HAWKEYEQRM5":"HAWKEYEQRM")
    		        	  .setReplaceHawkeyeMaster(isReplace_Master_QRM)
    		        	  .setReplaceHawkeyeQRM(isReplace_Master_QRM);
            
            if ( !engine.hasValidServerGroup( schema)) {
                throw new IllegalArgumentException("Non existent combination of ServerGroupId|Host|Port|Service");
            }
            	
            String [] reportNames = webTransfer.getStringArray("reportsAssigned"); 
            if("Y".equalsIgnoreCase(dxcgProcess)){
            	if("1".equalsIgnoreCase(dxcgParam)){
            		List<String> list = new ArrayList<String>();
            		for(String s : reportNames) {
            	       if(!(s.contains("1039") || s.contains("1040"))) {
            	          list.add(s);
            	       }
            	    }
            		reportNames = list.toArray(new String[list.size()]);
            	}
            	if("2".equalsIgnoreCase(dxcgParam)){
            		List<String> list = new ArrayList<String>();
            		for(String s : reportNames) {
            	       if(!s.contains("1040")) {
            	          list.add(s);
            	       }
            	    }
            		reportNames = list.toArray(new String[list.size()]);
            	}
            }
            String [] reportModules = webTransfer.getStringArray("reportModules");

            String dxcgHostUrl = webTransfer.getString("DxCGHostUrl");            
            
            AsyncSQLProcess sqlProcess = engine.executeReport(schema, replSchema, reportNames, reportModules, user, dxcgHostUrl,dxcgParam,dxcgProcess);
            SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
            isRefreshAgain = Boolean.TRUE;

            TaskType taskType = sqlRunnable.getTaskType();
            TaskKey taskKey = sqlProcess.getTaskKey();

            messageList.add( sqlRunnable.getDescription());

            if ( ( loginName.equals( taskKey.getUserName() ))
                 && TaskType.PROCESS_SCRIPT_OR_REPORT.equals(taskType) ) { 
                messageList.add("Currently queued: " + taskType.toString());
            } else {
                errorListMsg(errorList, taskType, taskKey);
                isRefreshAgain = Boolean.FALSE;
            }

        } else if ( RUN_INDEX.equals( action)) {
            retVal = "processOutput";
            Schema schema = (new Schema())
                .setServerGroupId( serverGroupId)
                .setServerName( webTransfer.getString("host") )
                .setPort( webTransfer.getString("port"))
                .setService( webTransfer.getString("service"))
                .setSchemaName( webTransfer.getString("frontSchema") )
                //.setSchemaPwd( webTransfer.getString("frontPassword"))
                .setDatabaseId( webTransfer.getString("databaseId"))
                .setSidFlag( webTransfer.getString("sidFlag"))
                .setEngineVersion(engineVersion)
//                .setEngineVersion(webTransfer.getString("ENG_VERSION"))
                .setClientName(engine.getClientName(webTransfer.getString("frontSchema")));
            
            String event = "Indexing";
            String desc = "Index on: "+ schema.getServerName() + ":"+ schema.getPort() + "/" +
            		schema.getService() + ":" + schema.getSchemaName();
            
            /*
        	 * setting password for front schema
        	 */
			try {
				schema = engine.setSchemaPassword(schema);
			} catch (Exception e) {
				logger.error("ProcessManager.java (RUN_REPORT) >> Error getting password for schema");
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
				// show error in event log
				ComponentFactory.getInstance().getEventLogger().logError(
				                 loginName,event, desc, 0, new Date(), new Date(), sw.toString() , schema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
				
            int degOfParallelism = 1;
            
            try {
                degOfParallelism = Integer.parseInt(webTransfer.getString("degreeOfParallelism"));
            } catch(Exception nfe) {}

            if ( !engine.hasValidServerGroup( schema)) {
                throw new IllegalArgumentException("Non existent combination of ServerGroupId|Host|Port|Service");
            }

            AsyncSQLProcess sqlProcess = engine.executeIndex(schema, degOfParallelism);
            SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
            isRefreshAgain = Boolean.TRUE;
            

            TaskType taskType = sqlRunnable.getTaskType();
            TaskKey taskKey = sqlProcess.getTaskKey();

            messageList.add( sqlRunnable.getDescription());

            if ( ( loginName.equals( taskKey.getUserName() )) &&
                 TaskType.INDEXING.equals(taskType) ) {
                messageList.add("Currently queued: " + taskType.toString());
            } else {
                errorListMsg(errorList, taskType, taskKey);
                isRefreshAgain = Boolean.FALSE;
            }

        } else if ( "GETSERVERINFO".equals( action)) {

        	retVal = "serverList";

            String schema = webTransfer.getString("schema_name");
        	schema= schema.trim();

        	ComponentFactory compFactory = ComponentFactory.getInstance();
            OracleServerInfo oracleserverinfo = compFactory.getOracleServerInfo();

            String servername=null;
            try{
            	servername= oracleserverinfo.serverinfo(schema);

            System.out.println("This is from process manager:"+ servername);
            servername=servername.trim();
            serverGroup_id= oracleserverinfo.serverGroupId(servername);

            System.out.println("This servername is from process manager:"+ serverGroup_id);
            }catch(Exception e){
            	servername="No server found";
            }
            if (serverGroup_id==null)
                {
            		serverGroup_id="No server found";
                }
            request.setAttribute("serverGroup_id",serverGroup_id);
            request.setAttribute("servername",servername);

        }else if("LIST_DIR".equals(LIST_DIR)){
        	retVal = "dataFileDirectory";
        	
        	lsDirs = engine.getDataFileDirsForServerGroup(serverGroupId);
        	if (lsDirs.size() == 1) {
                request.setAttribute("isSingleDir", Boolean.TRUE);
            } else {
                request.setAttribute("isSingleDir", Boolean.FALSE);
            }
        	
        }
        
        request.setAttribute("isRefreshAgain", isRefreshAgain);
        request.setAttribute("runningStatus", runningStatus);
        request.setAttribute("lsReportModules", lsReportModules);
        
        request.setAttribute("reportCount", new Integer(lsReports.size()));
        request.setAttribute("lsReports", lsReports);
        request.setAttribute("lsServerGroups", lsServerGroups);
        request.setAttribute("lsServers", lsServers);
        request.setAttribute("lsDirs", lsDirs);
        request.setAttribute("lsEngineVersions", lsEngineVersions);
        
        request.setAttribute("lsReportsAssigned", lsReportsAssigned); 
        request.setAttribute("lsReportsNotAssigned", lsReportsNotAssigned); 
        request.setAttribute("reportsAssignedCount", new Integer(lsReportsAssigned.size())); 
        request.setAttribute("totalReportsCount", new Integer(lsReportsAssigned.size()+lsReportsNotAssigned.size())); 
        
        request.setAttribute("lsDxcgHost", lsDxcgHost);               
        request.setAttribute("dxcgProcess", dxcgProcess);
        request.setAttribute("histServers", histServers);
        request.setAttribute("histServerGroups", histServerGroups);
        return retVal;
    }

    private static void errorListMsg(List ls, TaskType taskType, TaskKey taskKey) {
        ls.add("Schema is being used for " + taskType );
        ls.add("Operation requested is not queued.");
        ls.add("Job was scheuled by: " + taskKey.getUserName());  
        
    }
    
   /* private String encryptPassword(String password){
    	if(password != null && !"".equalsIgnoreCase(password)){
    		return CaseSensitiveEncoder.encode(password);
    	}
    	return "";
    }*/
}