package dashboard.web.pagecontroller;

import java.util.List;
import java.util.Map;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;

import dashboard.ComponentFactory;
import dashboard.engine.EventLogger;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class EventLogController extends Controller {


    protected Log logger = LogFactory.getLog(getClass());
    private static final String DATE_PATTERN = "MMM d, yyyy HH:mm:ss, z";
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception{
        String retVal = "eventLog";
        
        //Locale locale = request.getLocale();
        SimpleDateFormat dateFormat = new SimpleDateFormat( DATE_PATTERN);

        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");

        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);

        String loginName = webTransfer.getString("session:loginName");
        String log_page_no = webTransfer.getString("log_page_no");
        int page = 0;

        try {
            page = Integer.parseInt(log_page_no);
        } catch(Exception nfe){
        }

        String log_for = webTransfer.getString("log_for");
        if (null == log_for || "".equals(log_for.trim())) {
            log_for = "";
        }

        String loginNameParam = (null == log_for || "".equals(log_for.trim()))?
            "" : log_for.trim();

        ComponentFactory compFactory = ComponentFactory.getInstance();
        Map taskLogMap = compFactory.getTaskLogMap();
        
        EventLogger eventLogger = compFactory.getEventLogger();
        Object[] lgOut = eventLogger.showLogForUser(loginNameParam, page, dateFormat);
        Boolean hasMoreLog = (Boolean) lgOut[0];
        if (Boolean.TRUE.equals(hasMoreLog)) {
            Integer nextPage = new Integer (page + 1);
            request.setAttribute("nextPage", nextPage);
        }

        request.setAttribute("hasMoreLog", hasMoreLog);
        request.setAttribute("lsLog", lgOut[1]);
        request.setAttribute("log_for", log_for);
        request.setAttribute("taskLogMap", taskLogMap); 
       

        request.setAttribute("loginname", webTransfer.getString("loginname"));
        request.setAttribute("eventname", webTransfer.getString("eventname"));
        request.setAttribute("engineversion", webTransfer.getString("engineversion"));
        request.setAttribute("eventdesc", webTransfer.getString("eventdesc"));
        request.setAttribute("threadcount", webTransfer.getString("threadcount"));
        request.setAttribute("retstatus", webTransfer.getString("retstatus"));
        request.setAttribute("starttime", webTransfer.getString("starttime"));
        request.setAttribute("endtime", webTransfer.getString("endtime"));
        request.setAttribute("sysmessage", webTransfer.getString("sysmessage"));  
        request.setAttribute("sysmessage", webTransfer.getString("sysmessage")); 
        
        /**
         * To do
         * For Pagination
         * To be replaced by JSP 
         */
        String htmlstr="";  
        request.setAttribute("totRecs", lgOut[2]);           
	    int iTotRec=getNumeric(lgOut[2].toString());	      
	    if(iTotRec>10){
	          int iCurrentPage=getNumeric(webTransfer.getString("log_page_no"))+1;
	          int iPageSize=getNumeric("100");
	          int iTotalNoofPages=(int)Math.ceil((double)iTotRec/iPageSize);
	          int iTotalFrameCount=(int)Math.ceil((double)iTotRec/(iPageSize*10));
	          int frameCount = (int)(Math.ceil(iCurrentPage/10.0));
	          int iStartRecDisp=(frameCount-1)*10;
	          int iRemPageCount=iTotalNoofPages-iStartRecDisp;
	          int iTotPageToDispPerFrame=(iRemPageCount>10) ? 10 : iRemPageCount;   
	          htmlstr ="<table  id=\"totrec\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"left\" style=\"background-color: #f6f6f6;\">";

	          if( iTotalNoofPages > 1 ){
	        	  htmlstr+="<tr>" +
	        	      "<td class=\"frmP\" style=\"padding-top:0.8rem; padding-right: 0.5rem;\"> Total Records: "+lgOut[2]+"</td> "+
	                  "<td align=\"center\">" +
	                      "<table id=\"framepage\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" style=\"margin-bottom: 0;\">"+
	                      "<tr style=\"font-size:10pt; width: 20px; text-align: center; cursor: pointer;\">";

	                if(frameCount>1){
	                	htmlstr+="<td onClick=\"Controller.JumpTo('"+(((frameCount-2)+1)-1)*10+"')\"><<</td>";
	                }

	                for(int k=iStartRecDisp+1;k<=iStartRecDisp+iTotPageToDispPerFrame;k++){  
	                  if(k!=iCurrentPage){ 
	                	  htmlstr+="<td onclick=\"Controller.JumpTo('"+(k-1)+"','"+frameCount+"')\">&nbsp;"+k+"&nbsp;"+
	                	  		"</td>";
	                  }else{
	                	  htmlstr+="<td style=\"background-color:#3572b0;color:#fff!important; cursor: text;\">&nbsp;"+k+"&nbsp;</td>";
	                  }
	              }

	              if(frameCount<iTotalFrameCount){
	            	  htmlstr+="<td onClick=\"Controller.JumpTo('"+((frameCount+1)-1)*10+"')\">>></td>";
	              }
	              
	              htmlstr+="</tr>"+
	                    "</table>"+
	                 "</td>"+
	              "</tr>";
	           } 
	          htmlstr+="</table>";
    		}  
	    
	      	request.setAttribute("paginationHTML", htmlstr); 	      	
	       
              
        return retVal;
    }
    
    int getNumeric(String param){
        try{
            return Integer.parseInt(param);
        }catch(Exception nfe){
            return 1;
        }
    }
}
