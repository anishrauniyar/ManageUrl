package dashboard.web.pagecontroller;

import java.util.Collections;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;


public class ErrorLogTable extends Controller {

    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));
    private static final String ERROR_TABLE = "ERROR_TABLE";

    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "errorTable";
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");

        
        String tableName = webTransfer.getString(ERROR_TABLE);
        if ( tableName == null || !errorProp.containsKey(tableName)) {
            retVal = "messageList";
            errorList.add( "INVALID REQUEST FROM APPLICATION for log table.");
        } else {
            Schema schema = (new Schema())
                .setServerGroupId( webTransfer.getString("serverGroupId"))
                .setServerName( webTransfer.getString("host") )
                .setPort( webTransfer.getString("port"))
                .setService( webTransfer.getString("service"))
                .setSchemaName( webTransfer.getString("frontSchema") )
                //.setSchemaPwd( webTransfer.getString("frontPassword"))
                .setSidFlag( webTransfer.getString("sidFlag"))
                .setDatabaseId( webTransfer.getString("databaseId"));
            
            try{
            	schema = getEngineMonitor(request).setSchemaPassword(schema);
            }catch(Exception e){
            	logger.error("ErrorLogTable.java>> Error getting schema password for schema : "+schema.getSchemaName());
            	errorList.add(e.getMessage());
            	return "messageList";
            }
            
            Object [] fieldsNList = getEngineMonitor(request)
                .getTableAsFieldNamesNRowList(schema, errorProp.getProperty(tableName));
            String [] fields = (String []) fieldsNList[0];
            List rowList = (List) fieldsNList[1];
            request.setAttribute("tableFields", fields);
            request.setAttribute("rowList", rowList);
        }

        return retVal;
    }

    private Properties errorProp;

    public void setErrorTables (Properties prop ) {
        errorProp = prop;
    }
}
