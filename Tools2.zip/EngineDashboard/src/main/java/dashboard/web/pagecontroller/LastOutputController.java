package dashboard.web.pagecontroller;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.VerticaDB;
import dashboard.engine.EngineMonitor;
import dashboard.util.Constants;
import dashboard.util.FileUtil;


public class LastOutputController extends Controller {

    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));

    private static final String S_TRUE = "TRUE";

    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "processOutput";
        Boolean isRefreshAgain = Boolean.FALSE;
        
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        
        EngineMonitor engine = getEngineMonitor(request);
        
        String hostingServer = (webTransfer.getString("hostingServer") == null)?"": webTransfer.getString("hostingServer");
        Schema schema = (new Schema()).setServerName( webTransfer.getString("host") )
            .setPort( webTransfer.getString("port"))
            .setService( webTransfer.getString("service"))
            .setSchemaName( webTransfer.getString("schema"))
            .setServerGroupId( webTransfer.getString("serverGroupId"))
            .setEngineVersion(webTransfer.getString("ENG_VERSION"))
            .setHostingServer(hostingServer);
        String dxcgProcess = webTransfer.getString("dxcgProcessed");
        
        if(hostingServer.equalsIgnoreCase(Constants.VERTICA) || 
           hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA) || 
           hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)){
        	String execNo = webTransfer.getString("executionNumber");
        	String fileContent = "";
        	logger.info("Trying to get oracle to vertia data transfer file from last output controller for execution number :"+execNo);
        	
        	File verticaOutputFile = engine.getVerticaOutputFile(Long.valueOf(execNo) ,schema.getHostingServer());
        	if(verticaOutputFile.exists()){
        		try{
        			getO2VLogFileFromLocal(verticaOutputFile,request);
        		}catch(Exception e){
        			logger.error("Error getting O2V log file locally for exec no "+execNo);
        			e.printStackTrace();
        			errorList.add("Output file does not exists.");
        		}
        	}
        	else{
        		String srcHost = "";
        		try{
        			srcHost = engine.getHostName(Long.valueOf(execNo));
        			IOUtils.copy(new VerticaDB().getVerticaOutputStream(Long.valueOf(execNo), srcHost,hostingServer), new FileOutputStream(verticaOutputFile));
        		}catch(Exception e1){
        			logger.error("Error getting O2V log file remotely for exec no "+execNo +" from "+srcHost);
        			e1.printStackTrace();
        			errorList.add("Output file does not exists.");
        		}
        		finally{
        			logger.info("Getting O2V log file from finally block");
        			if(verticaOutputFile.exists()){
        				try{
                			getO2VLogFileFromLocal(verticaOutputFile,request);
                		}catch(Exception e){
                			logger.error("Error getting O2V log file locally for exec no "+execNo);
                			e.printStackTrace();
                			errorList.add("Output file does not exists.");
                		}
        			}
        		}
        	}
        	
        }
        
        else{
        	File [] lastOutputs = engine.getOutputFiles(schema);
            int lastModifiedIndex = -1;
            long lastModifiedTime = -1;
            
            for ( int i=0; lastOutputs != null && i<lastOutputs.length; i++) {
            	if (lastOutputs[i].exists()) {
                	if (lastModifiedTime < lastOutputs[i].lastModified() ) {
                        lastModifiedTime = lastOutputs[i].lastModified();
                        lastModifiedIndex = i;
                    }
                }
            }
            if ( lastModifiedIndex > -1 ) {
            	String dxOutput = webTransfer.getString("dxOutputString");
            	String flContent = FileUtil.readText(lastOutputs[lastModifiedIndex]).toString();
                request.setAttribute("serverOutput", flContent);
                request.setAttribute("processDescription", lastOutputs[lastModifiedIndex].getName());
                request.setAttribute("dxcgProcess", dxcgProcess);
                request.setAttribute("dxOutput", dxOutput);
                
                
            } else {
                errorList.add("Output file does not exists.");
            }

        }
                
        request.setAttribute("isRefreshAgain", isRefreshAgain);
        return retVal;
    }
    
    public void getO2VLogFileFromLocal(File verticaOutputFile,HttpServletRequest request) throws Exception{
		String flContent = FileUtil.readText(verticaOutputFile).toString();
		request.setAttribute("serverOutput", flContent);
        request.setAttribute("processDescription", verticaOutputFile.getName());

    }
 
}


