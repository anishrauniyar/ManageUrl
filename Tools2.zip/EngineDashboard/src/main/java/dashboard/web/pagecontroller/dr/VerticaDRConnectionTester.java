package dashboard.web.pagecontroller.dr;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.engine.vertica.BaseVerticaManager;
import dashboard.engine.vertica.OracleConnectionTester;
import dashboard.engine.vertica.VerticaManager;
import dashboard.engine.vertica.VerticaNodeSelecter;
import dashboard.util.Constants;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.util.VerticaException;

public class VerticaDRConnectionTester extends Controller {

    // Source Parameters
    private boolean srcOracleConn;
    private String srcOracleResult;
    private boolean dataTransferScriptFound;
    private String dataTransferScriptError;
    private boolean tblSpaceStatus_Error;
    private String tblSpaceStatus;

    // Destination Parameters
    private Schema verticaDRSchema;
    private boolean destVerticaDRConn;
    private String destVerticaDRResult;
    private boolean schemaCreationScriptFound;
    private String schemaCreationScriptError;

    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String retVal = "verticaDRTestConnResult";

        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        BaseVerticaManager srcOrclCnnTester = null;
        //Manager destOrclCnnTester = null;
        BaseVerticaManager destVtkaCnnTester = null;
        String hostingServer = ((webTransfer.getString("hostingServer") == null)
                || (webTransfer.getString("hostingServer").equals(Constants.EMPTY_STRING))) ? Constants.VERTICA_DR_CMA
                : webTransfer.getString("hostingServer");
        boolean testConnError = false;
        boolean fileNotFoundError = false;

        String runVerticaDROnly = webTransfer.getString("runVerticaDROnly");
        /**
         * VITTOOLS-383 : BA module not in use , so runBaModule is set to false
         * by default
         */
        //String runOracleDRBaModule = webTransfer.getString("runOracleDRBaModule");
        String runOracleDRBaModule = Constants.FALSE;
        EngineMonitor engine = getEngineMonitor(request);

        Schema srcOracleSchema = getOracleSrcSchema(webTransfer, engine);
        srcOrclCnnTester = (new OracleConnectionTester()).setHostingServer(hostingServer).setEngineMonitor(engine).setOrclSchema(srcOracleSchema);
        srcOrclCnnTester.init();

        if (runVerticaDROnly.equalsIgnoreCase("true")) {
            /**
             * ** Testing for Destination Vertica DR ***
             */
            verticaDRSchema = (new Schema()).setClusterGroupId(webTransfer.getString("destVerticaDRClusterGroupId"))
                    .setClusterGroupName(webTransfer.getString("destVerticaDRClusterGroupName"))
                    .setSchemaName(webTransfer.getString("destVerticaDRSchema")).setHostingServer(Constants.VERTICA);
            ClusterGroup clusterGroup = new ClusterGroup().setClusterGroupId(webTransfer.getString("destVerticaDRClusterGroupId")).setGroupName(
                    webTransfer.getString("destVerticaDRClusterGroupName"));
            /**
             ** CHECK FOR STATIC MAPPING
             */
            boolean vtkaSchemaStaticallyMapped = engine.isSchemaStaticallyMapped(srcOracleSchema, verticaDRSchema);
            logger.info("[Vertica Schema " + verticaDRSchema + " statically mapped]:" + vtkaSchemaStaticallyMapped);
            VerticaManager verticaNodeSelecter = new VerticaNodeSelecter();
            verticaNodeSelecter.setHostingServer(hostingServer).setClusterGrp(clusterGroup).setEngineMonitor(engine)
                    .setVtkaSchema(verticaDRSchema).setOrclSchema(srcOracleSchema).setTransferToProduction(Boolean.FALSE)
                    .setIsSchemaStaticallyMapped(vtkaSchemaStaticallyMapped);
            BaseVerticaManager vtkaConnectionTester;
            boolean nodeFound;
            try {
                verticaNodeSelecter.init();
                vtkaConnectionTester = verticaNodeSelecter.getVtkaConnTester();
                verticaDRSchema = verticaNodeSelecter.getVtkaSchema();
                nodeFound = verticaNodeSelecter.isNodeFound();
                if (nodeFound) {
                    setVtkaConnSuccessResult(vtkaConnectionTester);
                } else {
                    setVtkaConnFailureResult(vtkaConnectionTester, clusterGroup);
                }
            } catch (VerticaException spEx) {
                logger.error("VerticaDRConnectionTester.java [VerticaException] ", spEx);
                destVerticaDRConn = false;
                destVerticaDRResult = spEx.toString();
            } catch (Exception e) {
                logger.error("VerticaDRConnectionTester.java [Exception] ", e);
                destVerticaDRConn = false;
                destVerticaDRResult = e.getMessage();
            }
        }
        dataTransferScriptFound = srcOrclCnnTester.isDataTransferScriptFound();
        dataTransferScriptError = srcOrclCnnTester.getDataTransferScript_Error();
        if ((!dataTransferScriptFound) || (!schemaCreationScriptFound)) {
            fileNotFoundError = true;
        }
        srcOracleConn = (Boolean) srcOrclCnnTester.getOrclJdbcResult()[0];
        srcOracleResult = (String) srcOrclCnnTester.getOrclJdbcResult()[1];
        tblSpaceStatus = srcOrclCnnTester.getTblSpaceStatus();
        tblSpaceStatus_Error = srcOrclCnnTester.isTblSpaceStatus_Error();
        /* ERROR LISTING */
        if (!srcOracleConn || !destVerticaDRConn || fileNotFoundError || tblSpaceStatus_Error) {
            testConnError = true;
        }

        request.setAttribute("runOracleDRBaModule", runOracleDRBaModule);
        request.setAttribute("runVerticaDROnly", runVerticaDROnly);
        request.setAttribute("srcOracleConn", srcOracleConn);
        request.setAttribute("destVerticaDRConn", destVerticaDRConn);
        request.setAttribute("srcOracleResult", srcOracleResult);
        request.setAttribute("destVerticaDRResult", destVerticaDRResult);
        request.setAttribute("testConnError", testConnError);
        request.setAttribute("fileNotFoundError", fileNotFoundError);
        request.setAttribute("O2V_shFileFound", dataTransferScriptFound);
        request.setAttribute("VS_DR_shFileFound", schemaCreationScriptFound);
        request.setAttribute("hostingServer", hostingServer);
        request.setAttribute("verticaDRSchema", verticaDRSchema);
        request.setAttribute("dataTransferScriptError", dataTransferScriptError);
        request.setAttribute("schemaCreationScriptError", schemaCreationScriptError);
        request.setAttribute("tblSpaceStatus", tblSpaceStatus);
        request.setAttribute("tblSpaceStatus_Error", tblSpaceStatus_Error);
        return retVal;
    }

    /**
     * @Description: Method for setting parameters for verticaRACSchema from the
     * server fetched by algorithm
     * @param engine
     * @param vtkaSplitClustResult
     */
    public void setVtkaDRSchema(EngineMonitor engine, Object[] vtkaSplitClustResult) {
        Server destVtkaDRServer = (Server) vtkaSplitClustResult[1];
        verticaDRSchema.setServerGroupId(destVtkaDRServer.getServerGroupId());
        verticaDRSchema.setServerName(destVtkaDRServer.getHost());
        verticaDRSchema.setPort(String.valueOf(destVtkaDRServer.getPort()));
        verticaDRSchema.setService(destVtkaDRServer.getDatabase());
        verticaDRSchema.setDatabase(destVtkaDRServer.getDatabase());
        verticaDRSchema.setDatabaseId(destVtkaDRServer.getDatabaseId());
        engine.setServerGroupName(verticaDRSchema);
    }

    /**
     * @Description: Method to set the connection result when the server is
     * found by the algorithm
     * @param destVtkaCnnTester
     */
    public void setVtkaConnSuccessResult(BaseVerticaManager destVtkaCnnTester) {
        schemaCreationScriptFound = destVtkaCnnTester.isSchemaCreationScriptFound();
        schemaCreationScriptError = destVtkaCnnTester.getSchemaCreationScript_Error();
        destVerticaDRConn = (Boolean) destVtkaCnnTester.getVtkJdbcResult()[0];
        destVerticaDRResult = (String) destVtkaCnnTester.getVtkJdbcResult()[1];
    }

    /**
     * @Description : Method to set the connection result when the server is not
     * found by the algorithm
     * @param destVtkaCnnTester
     * @param clusterGroup
     */
    public void setVtkaConnFailureResult(BaseVerticaManager destVtkaCnnTester, ClusterGroup clusterGroup) {
        destVerticaDRConn = false;
        destVerticaDRResult = "Could not get vertica server for cluster group " + clusterGroup.getGroupName();
    }
}
