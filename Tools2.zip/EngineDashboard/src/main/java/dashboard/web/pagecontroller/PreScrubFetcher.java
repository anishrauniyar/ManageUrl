package dashboard.web.pagecontroller;

import java.util.List;
import java.util.Set;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.engine.EngineMonitor;
import dashboard.data.WebTransfer;
import dashboard.data.Schema;
import dashboard.data.EngineReplacementData;


import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class PreScrubFetcher extends Controller {

    protected Log logger = LogFactory.getLog(getClass());
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "preScrubClient";
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String clientId = webTransfer.getString("clientID");
        logger.info("Fetching pre-scrub for: " + clientId);
        EngineMonitor engine = getEngineMonitor(request);
        try {
        String [] clientIdNSchema = engine.fetchPreScrub(clientId);

        request.setAttribute("preScrubClientID", clientIdNSchema[0]);
        request.setAttribute("preScrubSchema", clientIdNSchema[1]);
        } catch(Exception ex) {
            errorList.add("Failed to obtain pre-scrub");
            errorList.add(ex.getMessage());
            logger.error("PRESCRUB fetch: Supplied client id: " + clientId, ex);
        }

        return retVal;
    }
}
