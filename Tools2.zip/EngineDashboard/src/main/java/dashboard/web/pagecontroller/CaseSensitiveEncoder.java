package dashboard.web.pagecontroller;

/**
 * 
 * The CaseSensitiveEncoder class is used to encode the db password for DxCG.
 * 
 *  This utilizes all the implementation of IDEncoder.java file 
 *  except that it takes the lettercase into consideration.
 *  So, it has extra substitution set for lowercase alphabets.
 *  Additionally, toUpperCase() method in substitute() and deSubstitute() method are removed.
 *  
 *  Please refer to IDEncoder.java class by @JMorgan for other details.
 * 
 * @author rajishrestha
 */

public class CaseSensitiveEncoder {
    	private static final int[] column = { 4, 2, 1, 3, 0 };
	private static final int rowSize = column.length;

	private static final String plain = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private static final String subs  = "qmhfloyuxvcabwtzgjrispdkenQMHFLOYUXVCABWTZGJRISPDKEN9048231657";

	/**
	 * Blinds a member ID using the algorithm described in the class summary.
	 * 
	 * @param input
	 *            the real member ID to encode
	 * @return the blinded member ID
	 */
	public static String encode(String input) {
		return new StringBuffer(transpose(substitute(input))).reverse()
				.toString();
	}

	/**
	 * Restores a real member ID by reversing the encoding process.
	 * 
	 * @param input
	 *            the blinded member ID to decode
	 * @return the real member ID
	 */
	public static String decode(String input) {
		return deTranspose(deSubstitute(new StringBuffer(input).reverse()
				.toString()));
	}

	private static String transpose(String input) {
		int len = input.length();
		int numFullRows = len / rowSize;
		StringBuffer sb = new StringBuffer(len);

		for (int i = 0; i < rowSize; i++) {
			for (int x = 0; x < numFullRows + 1; x++) {
				int loc = x * rowSize + column[i];
				if (loc >= len) {
					break;
				}
				sb.append(input.charAt(loc));
			}
		}

		return sb.toString();
	}

	private static String deTranspose(String input) {
		int len = input.length();
		int numFullRows = len / rowSize;
		int numShortCols = rowSize - (len % rowSize);
		if (numShortCols == rowSize) {
			numShortCols = 0;
		}

		String[] colText = new String[rowSize];
		int inputLoc = 0;

		// Special case for strings less than rowSize length
		if (len <= rowSize) {
			for (int i = 0; i < rowSize; i++) {
				if (column[i] < len) {
					colText[column[i]] = input
							.substring(inputLoc, inputLoc + 1);
					inputLoc++;
				} else {
					colText[column[i]] = "";
				}
			}
		} else {
			// Normal case
			for (int i = 0; i < rowSize; i++) {
				int colHeight;
				if (column[i] >= rowSize - numShortCols || numShortCols == 0) {
					colHeight = numFullRows;
				} else {
					colHeight = numFullRows + 1;
				}
				colText[column[i]] = input.substring(inputLoc, inputLoc
						+ colHeight);
				inputLoc += colHeight;
				// System.out.println("col " + column[i] + ": "
				// + colText[column[i]]);
			}
		}

		StringBuffer sb = new StringBuffer(len);
		int col = 0;
		int colLocs[] = new int[rowSize];
		for (int x = 0; x < Math.max(len, rowSize); x++) {
			if (colText[col].length() > 0) {
				sb.append(colText[col]
						.substring(colLocs[col], colLocs[col] + 1));
				colLocs[col]++;
			}
			col++;
			if (col >= rowSize) {
				col = 0;
			}
			// System.out.println("x=" + x + "; " + sb.toString());
		}

		return sb.toString();
	}

	private static String substitute(String inputString) {
		/*- plaintext key: ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789
		       cipher key: QMHFLOYUXVCABWTZGJRISPDKEN9048231657 */
		int len = inputString.length();
		StringBuffer sb = new StringBuffer(len);
		char[] input = inputString.toCharArray();

		for (int i = 0; i < len; i++) {
			int pos = plain.indexOf(input[i]);
			if (pos == -1) {
				sb.append(input[i]);
			} else {
				sb.append(subs.charAt(pos));
			}
		}
		return sb.toString();
	}

	private static String deSubstitute(String inputString) {
		int len = inputString.length();
		StringBuffer sb = new StringBuffer(len);
		char[] input = inputString.toCharArray();

		for (int i = 0; i < len; i++) {
			int pos = subs.indexOf(input[i]);
			if (pos == -1) {
				sb.append(input[i]);
			} else {
				sb.append(plain.charAt(pos));
			}
		}
		return sb.toString();
	}

}
