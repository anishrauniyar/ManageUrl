package dashboard.web.pagecontroller;

import java.io.StringWriter;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.OracleDBConnector;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;

public class DataTransferController extends Controller {


    private static final RunningStatus RUNNING_STATUS = new RunningStatus();
    
    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));

    protected Log logger = LogFactory.getLog(getClass());
    
    private long executionNumber = 0;
    
	private String getDataFile(Schema utilSchema,String schemaName){
		String dataFileDir="";
		
		java.sql.Connection conn=null;
		java.sql.ResultSet rs=null;
		java.sql.PreparedStatement pstmt=null;
		
		try{
	    	String dataFileSql="select Utility.FN_GETFILEOF_USER(?) from dual";
			OracleDBConnector con=new OracleDBConnector();
	    	conn=con.getConnectionForSchema(utilSchema);
	    	pstmt=conn.prepareStatement(dataFileSql);
	    	pstmt.setString(1,schemaName);
	    	rs=pstmt.executeQuery();
	    	if(rs.next()){
	    		dataFileDir=rs.getString(1);
	    	}
		} catch(Exception e){
		} finally{
			try{
			rs.close();
			pstmt.close();
			conn.close();
			}catch(Exception e){}
		}
    	return dataFileDir;
	}    
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "processOutput";
        Boolean isRefreshAgain = Boolean.FALSE;

        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        String hostingServer = webTransfer.getString("hostingServer");
        /**
		 * VITTOOLS-383 : BA module not in use , so runBAModule is set to false
		 * by default
		 */
        //String runBaModule = webTransfer.getString("runBaModule");
        String runBaModule = Constants.FALSE;
        String DRTransferEnabled = webTransfer.getString("isDRTransfer");
        
        Date startDate = new Date();
        
        AsyncSQLProcess sqlProcess = null;
        //AsyncSQLProcess sqlProcessForBATransfer = null;
        boolean oracleSchemaInfoAlreadyInserted = false;

        EngineMonitor engine = getEngineMonitor(request);
        
        String srcHost = webTransfer.getString("srcHost");
        String srcPort = webTransfer.getString("srcPort");
        String srcService = webTransfer.getString("srcService");
        String srcSchm =  webTransfer.getString("srcSchema");
        String srcPwd =  "";//webTransfer.getString("srcPwd");
        String srcSidFlag = webTransfer.getString("srcSidFlag");
        String connection = "";
        String srcDatabaseId = webTransfer.getString("srcDatabaseId");
        if(hostingServer.equalsIgnoreCase(Constants.VERTICA)){
        	connection = webTransfer.getString("srcConnection");
        }
        
        
        Schema srcSchema = (new Schema())
	        .setServerName(srcHost)
	        .setPort(srcPort)
	        .setService(srcService)
	        .setSidFlag(srcSidFlag)
	        .setSchemaName(srcSchm)
	        //.setSchemaPwd(srcPwd)
	        .setDatabaseId(srcDatabaseId)
        	.setHostingServer(hostingServer)
        	.setConnection(connection);
        
        dashboard.data.Server srcServer= ComponentFactory.getInstance().getEngineMonitorForSystem().getServer(srcSchema);
        
        String engineVersion = engine.getEngineVersion(srcSchema) ;//getting engine version
        srcSchema.setEngineVersion(engineVersion);//setting engine version in src schema
        
        Schema srcUtilSchema = new Schema()
        	.setServerName(srcHost)
        	.setPort(srcPort)
        	.setService(srcService)
        	.setSidFlag(srcSidFlag)
        	.setSchemaName(srcServer.getUTILITY_USER())
        	.setSchemaPwd(srcServer.getUTILITY_PASS());
        
        //for ORACLE
        if(hostingServer.equalsIgnoreCase(Constants.ORACLE))
        {
	        	 Schema destSchema = (new Schema())
	             .setServerGroupId( webTransfer.getString("destServerGroupId"))
	             .setServerName( webTransfer.getString("destHost") )
	             .setPort( webTransfer.getString("destPort"))
	             .setService( webTransfer.getString("destService"))
	             .setSidFlag( webTransfer.getString("destSidFlag"))
	             .setSchemaName( webTransfer.getString("destSchema"))
	             //.setSchemaPwd( webTransfer.getString("destPwd"))
	             .setDatabaseId(webTransfer.getString("destDatabaseId"))
	             .setHostingServer(webTransfer.getString("hostingServer"))
	             .setClientName(engine.getClientName(webTransfer.getString("destSchema")))
	             .setEngineVersion(engineVersion);
	        	 
				 
			String transferType = webTransfer.getString("transferType");
			String label = getDataTransferLabel(transferType);
		
			if (transferType.equals("ASM")) {
				// generate and insert password 
				try{
					oracleSchemaInfoAlreadyInserted = engine.isSchemaInfoAlreadyInserted(destSchema);
					System.out.println("IS Schema info for schema "+destSchema.getSchemaName()+" already inserted?? "+oracleSchemaInfoAlreadyInserted);
					if(oracleSchemaInfoAlreadyInserted){
						// getting password from db
						destSchema = engine.setSchemaPassword(destSchema);
					}
					else{
						// generate pwd and insert schema info
						destSchema = engine.generateSchemaPassword(destSchema);
						engine.insertSchemaInfo(destSchema);
					}
				}catch(Exception e){
					logger.error("Data TransferController.java (TTS/ASM)>>> Error while generate/insert password for schema "+destSchema.getSchemaName());
					// inserting exception caught to logger.
					StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
					// show error in event log
					ComponentFactory.getInstance().getEventLogger().logError(
					loginName,"Data Transfer"+label, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
					// show error in UI
					errorList.add(e.getMessage());
					return retVal;
				}

			}
			else {
				// setting password for source and destination oracle server
				try {
					srcSchema = engine.setSchemaPassword(srcSchema);
					srcPwd = srcSchema.getSchemaPwd();
					destSchema = engine.setSchemaPassword(destSchema);
				} catch (Exception e) {
					logger.error("DataTransferController.java>>>Error setting schema passsword for oracle to oracle data transfer by :"
							+ loginName);
					// inserting exception caught to logger.
					StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
					// show error in event log
					ComponentFactory.getInstance().getEventLogger().logError(
					loginName,"Data Transfer"+label, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
					// show error in UI
					errorList.add(e.getMessage());
					return retVal;
				}
			}
	         
	         String appendFlag = webTransfer.getString("appendFlag");
	         String sameServer = webTransfer.getString("isSameServer");
	         
	         int degOfParallelism = 1;
	         try {
	             degOfParallelism = Integer.parseInt(webTransfer.getString("degreeOfParallelism"));
	         } catch(Exception nfe) {
	         	System.out.println("dop exception");
	         }
	         
	         String srcDataFile=getDataFile(srcUtilSchema, srcSchm);
	         String srcDataFileNameOnly=srcDataFile.substring(srcDataFile.lastIndexOf("/")+1);
	
	         String dataFileDirName= webTransfer.getString("dataFileDirName");
	         System.out.println("dataFileDirName:>>>>>"+dataFileDirName);
	         String dataFileDir="";
	         if(transferType.equals("TTS")){
	         	dataFileDir= webTransfer.getString("dataFileDir");
	         	String destDataFile=dataFileDir+"/"+srcDataFileNameOnly;
	         	String destServerName=webTransfer.getString("destHost");
	         	String fileExists=new dashboard.util.DataTransferStatus().fileExists(destServerName, destDataFile);
	         	//if(!fileExists.equals("File does not exist")){
	         	if(fileExists.equals("File does not exist")){
	         		request.setAttribute("isRefreshAgain",Boolean.FALSE);
	         		System.out.println("TTS Transfer not allowed:"+fileExists);
	         		errorList.add("TTS Transfer not allowed:"+fileExists);
	         		return retVal;
	         	}else{
	         		System.out.println("TTS Transfer:Allowed:"+fileExists);
	         	}
	         }
	
	         if (null == sameServer || "".equals(sameServer.trim())) {
	             sameServer = "N";
	         }
	         boolean isSameServer = "Y".equalsIgnoreCase( sameServer.trim());
	         String sourceDbLink  = "";
	         if(transferType.equals("VC") || transferType.equals("ME")){
	        	 try {
	 				sourceDbLink = engine.getDBLink(srcSchema);
	 			 } catch (Exception e) {
	 				errorList.add(e.getMessage());
	 				ComponentFactory.getInstance().getEventLogger().logError(
	 						loginName,"Data Transfer"+label, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), e.getMessage() , destSchema);
	 				return retVal;
	 			 }
	         }
	         sqlProcess = engine.executeTransfer(destSchema, srcHost, srcPort, srcService, srcSchm, srcPwd,
	                              transferType, appendFlag, isSameServer, srcSidFlag, dataFileDir,degOfParallelism,dataFileDirName,DRTransferEnabled,loginName,sourceDbLink);
        }
        
        else if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
        {
        	Schema destSchema = (new Schema())
        	.setServerGroupId( webTransfer.getString("destServerGroupId"))
            .setServerName( webTransfer.getString("destHost") )
            .setPort( webTransfer.getString("destPort"))
            .setService( webTransfer.getString("destConnection"))//used in event log
            .setConnection( webTransfer.getString("destConnection"))
            .setDatabase( webTransfer.getString("destDatabase"))
            .setSchemaName( webTransfer.getString("destSchema"))
            .setClientName(engine.getClientName(webTransfer.getString("destSchema")))// added client name
            //.setSchemaPwd( webTransfer.getString("destPwd"))
            .setHostingServer(webTransfer.getString("hostingServer"))
        	.setEngineVersion(engineVersion)
        	.setDatabaseId(webTransfer.getString("destDatabaseId"));
        	
        	
        	// setting schema password
			try {
				srcSchema = engine.setSchemaPassword(srcSchema);
				destSchema = engine.setSchemaPassword(destSchema);
			} catch (Exception e) {
				logger.error("DataTransferController.java>>>Error setting schema passsword for oracle to vertica data transfer using dmexpress by "+loginName);
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
				// show error in event log
				ComponentFactory.getInstance().getEventLogger().logError(
				loginName,Constants.O2V_DMEXPRESS_EVENT, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
        	
        	Schema dmExpressSchema = (new Schema())
        	.setServerGroupId( webTransfer.getString("dmExpressServerGroupId"))
            .setServerName( webTransfer.getString("dmExpressHost") )
            .setPort( webTransfer.getString("dmExpressPort"))
            .setInstance( webTransfer.getString("dmExpressInstance"))
            .setHostingServer(Constants.DMEXPRESS);
        	
        	int degOfParallelism = 1;
	         try {
	             degOfParallelism = Integer.parseInt(webTransfer.getString("dmExpressDop"));
	         } catch(Exception nfe) {
	         	System.out.println("dop exception");
	         }
	         
	        
	        /* if(runBaModule.equalsIgnoreCase("TRUE"))
	        	{
	        	 	Schema oraDestSchema = (new Schema())
	                     .setServerGroupId( webTransfer.getString("destOracleServerGroupId"))
	                     .setServerName( webTransfer.getString("destOracleHost") )
	                     .setPort( webTransfer.getString("destOraclePort"))
	                     .setService( webTransfer.getString("destOracleService"))
	                     .setSidFlag( webTransfer.getString("destOracleSidFlag"))
	                     .setSchemaName( webTransfer.getString("destOracleSchema"))
	                     //.setSchemaPwd( webTransfer.getString("destOraclePwd"))
	                     .setHostingServer(Constants.ORACLE_BA)
	                     .setClientName(engine.getClientName(webTransfer.getString("destOracleSchema")))
	                     .setEngineVersion(engineVersion)
	                     .setDatabaseId(webTransfer.getString("destOracleDatabaseId"));
	        	 	
				// settting password for destination oracle schema
				try {
					oraDestSchema = engine.setSchemaPassword(oraDestSchema);
				} catch (Exception e) {
					logger.error("DataTransferController.java>>>Error setting schema passsword for destination oracle server (BA) using dmexpress by "
							+ loginName);
					// inserting exception caught to logger.
					StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
					// show error in event log
					ComponentFactory.getInstance().getEventLogger().logError(
					loginName,Constants.O2V_DMEXPRESS_BA_EVENT, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
					// show error in UI
					errorList.add(e.getMessage());
					return retVal;
				}
	        	 
	        	 	 String dataFileDirectoy = webTransfer.getString("dataFileDir");
	        		 System.out.println("Data File Directory for Destination Oracle:"+dataFileDirectoy);
	        	     sqlProcessForBATransfer = engine.executeTransferForBAModules(srcSchema, oraDestSchema ,dataFileDirectoy);
	        	}*/
	         
	         executionNumber = engine.getExecutionNumber();
	         //System.out.println("-----------EXECUTION NUMBER FROM DATA TRANSFER CONTROLLER:"+executionNumber);
	         sqlProcess = engine.executeTransferForVerticaUsingDMExpress(srcSchema,destSchema,dmExpressSchema,degOfParallelism,executionNumber);
	        
        }
        
        
        else if(hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA))
        {
            Schema oraDestSchema = null;
            Schema destSchema = getDestVerticaRACSchema(webTransfer, engine);
            destSchema.setHostingServer(hostingServer);// this is imp for transfer
        	destSchema.setEngineVersion(engineVersion);
        	
        	
         String O2VStatus = allowO2VDataTransfer(request, srcSchema, destSchema);
         if(!O2VStatus.equals("")){
        	 logger.info("Oracle to Vertica Data Transfer Process Already Exists (DataTransferController.java)");
        	 request.setAttribute("O2VStatus", O2VStatus);
        	 return retVal;
         }
         
         // setting schema password
			try {
				srcSchema = engine.setSchemaPassword(srcSchema);
				destSchema = engine.setSchemaPassword(destSchema);
			} catch (Exception e) {
				logger.error("DataTransferController.java>>>Error setting schema passsword for oracle to vertica data transfer using cma by "
						+ loginName);
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
				// show error in event log
				ComponentFactory.getInstance().getEventLogger().logError(
						loginName,Constants.O2V_CMA_EVENT, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
         
			logger.info("Oracle to Vertica Data Transfer Process Does Not Exists (DataTransferController.java) ");
			/**
			 * VITTOOLS-383 : BA module no longer in use
			*/
             /*if(runBaModule.equalsIgnoreCase("TRUE"))
	        	{
	        	 	oraDestSchema = (new Schema())
	                     .setServerGroupId( webTransfer.getString("destOracleServerGroupId"))
	                     .setServerName( webTransfer.getString("destOracleHost") )
	                     .setPort( webTransfer.getString("destOraclePort"))
	                     .setService( webTransfer.getString("destOracleService"))
	                     .setSidFlag( webTransfer.getString("destOracleSidFlag"))
	                     .setSchemaName( webTransfer.getString("destOracleSchema"))
	                     //.setSchemaPwd( webTransfer.getString("destOraclePwd"))
	                     .setHostingServer(Constants.ORACLE_BA_CMA)
	                     .setClientName(engine.getClientName(webTransfer.getString("destOracleSchema")))
	                     .setEngineVersion(engineVersion)
	                     .setDatabaseId(webTransfer.getString("destOracleDatabaseId"));;
	        	 
	        	 	 String dataFileDirectoy = webTransfer.getString("dataFileDir");
	        		 //System.out.println("Data File Directory for Destination Oracle:"+dataFileDirectoy);
	        	 	 
				// settting password for destination oracle schema
				try {
					oraDestSchema = engine.setSchemaPassword(oraDestSchema);
				} catch (Exception e) {
					logger.error("DataTransferController.java>>>Error setting schema passsword for destination oracle server (BA) using cma by "
							+ loginName);
					StringWriter sw = InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
					//show error in event log
					ComponentFactory.getInstance().getEventLogger().logError(
							loginName,Constants.O2V_CMA_BA_EVENT, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
					errorList.add(e.getMessage());
					return retVal;
				}
	        	 	 
	        	     sqlProcessForBATransfer = engine.executeTransferForBAModules(srcSchema, oraDestSchema ,dataFileDirectoy);
	        	}*/
	         
	         executionNumber = engine.getExecutionNumber();
	         //System.out.println("-----------EXECUTION NUMBER FROM DATA TRANSFER CONTROLLER:"+executionNumber);
	         sqlProcess = engine.executeTransferForVerticaUsingCMA(srcSchema,destSchema,executionNumber,runBaModule,oraDestSchema);
	        
        }
            
        SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
        isRefreshAgain = Boolean.TRUE;

        messageList.add(sqlRunnable.getDescription());
        
        TaskType taskType = sqlRunnable.getTaskType();
        TaskKey taskKey = sqlProcess.getTaskKey();

        if (( loginName.equals( taskKey.getUserName() )) &&
            TaskType.DATA_TRANSFER.equals(taskType)) {
            messageList.add("Operation queued: " + taskType.getTaskLabel());
        } else {
            isRefreshAgain = Boolean.FALSE;
            errorList.add("Schema is already in use for " + taskType );
            errorList.add("Requested operation is not queued.");
            errorList.add("Job was scheuled by: " + taskKey.getUserName());  
        }
        
        request.setAttribute("executionNumber", executionNumber);
        request.setAttribute("isRefreshAgain", isRefreshAgain);
        
        logger.info("End of data transfer method >>>>>>>>>>>>>>>>>>>>");
        
        return retVal;
    }
    
	public String getDataTransferLabel(String transferType){
		String label = "";
		if( transferType.equals("F") ) {
            label = " (Front) ";
        } else if ( transferType.equals("H") ) {
            label = " (History) ";
        } else if ( transferType.equals("S") ) {
            label = " (Scrub) ";
        } else if ( transferType.equals("TTS") ) {
            label = " (TTS) ";
        } else if ( transferType.equals("ASM") ) {
            label = " (ASM) ";
        } else if ( transferType.equals("WH") ) {
            label = " (WareHouse) ";
        } else if ( transferType.equals("VC") ) {
            label = " (VC Scrub) ";
        } else if ( transferType.equals("ME") ) {
            label = " (Mini Engine Output) ";
        }
		
		return label;
	}
}
