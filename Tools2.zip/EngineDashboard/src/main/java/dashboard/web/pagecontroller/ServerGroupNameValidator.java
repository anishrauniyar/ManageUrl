package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public class ServerGroupNameValidator extends ValidatorRoot {
    public boolean isValid(Object obj, HttpServletRequest request){
        boolean retVal = true;
        if (null == obj) {
            throw new NullPointerException("Object to verify null in ServerGroupNameValidator.");
        }
        if ( ! (obj instanceof String) ) {
            throw new IllegalArgumentException("Object to verify is not String in ServerGroupNameValidator.");
        }
        
        init(request);
        List errors = getErrorList();
        List message = getMessageList();
        String groupName = (String) obj;
        groupName = groupName.trim();
        if("".equals(groupName)) {
            errors.add("Blank server group name is not valid");
            retVal = false;
        }
        if (groupName.length() > 50) {
            errors.add("Server Group Name exceeds length.");
        }        
        return retVal;
    }
}
