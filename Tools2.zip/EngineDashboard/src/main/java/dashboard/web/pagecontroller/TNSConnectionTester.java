package dashboard.web.pagecontroller;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import dashboard.ComponentFactory;
import dashboard.data.WebTransfer;
import dashboard.engine.AsyncSQLProcess;
import dashboard.util.EnvInfo;

public class TNSConnectionTester extends Controller {

	private static String TNS_ORACLE = "TNS_ORACLE";
	private static String TNS_VERTICA = "TNS_VERTICA";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String retVal = "messageList";

		List messageList = ValidatorRoot.getMessageList(request);
		AsyncSQLProcess sqlProcess = null;
		String command1 = "";
		String command2 = "";
		EnvInfo env = ComponentFactory.getInstance().getEnvInfo();
		String tnsOutput = "";
		String dmExpressUserName = "dmxuser";

		String dmExpressPassword = "Verisk2@12";

		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		String action = webTransfer.getString("action");

		String dmExpressServer = webTransfer.getString("dmExpressHost");

		if (action.equalsIgnoreCase(TNS_ORACLE)) {

			String sourceTNS = webTransfer.getString("srcConnection");

			command1 = "cd /";
			command2 = "tnsping " + sourceTNS;
			/*
			 * command1 = "ssh dmxuser@10.48.11.8"; command2 =
			 * "tnsping "+sourceTNS;
			 */

			// ValidatorRoot.getMessageList(request).add(runShellScript(dmExpressUserName,dmExpressPassword,dmExpressServer,command1,command2));
			tnsOutput = runShellScript(dmExpressUserName, dmExpressPassword,
					dmExpressServer, command1, command2);
			

		} else if (action.equalsIgnoreCase(TNS_VERTICA)) {

			System.out.println("VVVVVVVEEEEEEEEEEERRRRRRRTICA");
			String verticaTNS = webTransfer.getString("destConnection");
			command1 = "cd /";
			command2 = "isql -v Vertica-UAT dbadmin Verisk2@12";

			tnsOutput = runShellScript1(dmExpressUserName, dmExpressPassword,
					dmExpressServer, command1, command2);
			// ValidatorRoot.getMessageList(request).add(runShellScript(dmExpressUserName,dmExpressPassword,dmExpressServer,command1,command2));
		}
		request.setAttribute("showTnsOutput", true);
		request.setAttribute("tnsOutput", tnsOutput);
		return retVal;
	}

	public String runShellScript(String... param) throws Exception {

		StringBuffer sb = new StringBuffer(10000);
		String user = param[0];
		String password = param[1];
		String server = param[2];
		List<String> commands = new ArrayList<String>();
		commands.add(param[3]);
		commands.add(param[4]);

		System.out.println("LOGIN USER:" + user);
		System.out.println("PASSWORD:" + password);
		System.out.println("SERVER:" + server);
		System.out.println("CDCOMMAND:" + commands.get(0));
		System.out.println("SHCOMMAND:" + commands.get(1));

		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session = jsch.getSession(user, server, 22);
		session.setPassword(password);
		session.setConfig(config);
		/*
		 * if(createVerticaSchema.equalsIgnoreCase("true")) {
		 */
		session.setConfig("PreferredAuthentications",
				"publickey,keyboard-interactive,password");

		// }
		session.connect();
		Channel channel = session.openChannel("shell");

		OutputStream outPutStream = channel.getOutputStream();
		PrintStream commander = new PrintStream(outPutStream, true);

		channel.setOutputStream(System.out, true);

		channel.connect();
		InputStream is = channel.getInputStream();

		for (String command : commands) {
			commander.println(command);
			// /commander.flush();
		}

		commander.println("exit");
		/*
		 * Thread.sleep(10000); commander.println("exit");
		 */

		outPutStream.flush();
		outPutStream.close();

		commander.close();

		int c = 0;
		while ((c = is.read()) != -1) {
			// System.out.print((char)c);
			sb.append((char) c);
			/*
			 * if(channel.isClosed()) { System.out.println("exit-status: " +
			 * channel.getExitStatus()); break; }
			 */
			/*
			 * try { Thread.sleep(3000); } catch (Exception ee) { }
			 */
		}
		System.out.println(">>>>>>>>>" + sb.toString());
		is.close();

		/*
		 * do { Thread.sleep(1000); } while (!channel.isEOF());
		 */

		channel.disconnect();
		session.disconnect();
		System.out.println("DONE");

		return sb.toString();

	}

	public String runShellScript1(String... param) throws Exception {

		StringBuffer sb = new StringBuffer(10000);
		String user = param[0];
		String password = param[1];
		String server = param[2];
		List<String> commands = new ArrayList<String>();
		commands.add(param[3]);
		commands.add(param[4]);

		System.out.println("LOGIN USER:" + user);
		System.out.println("PASSWORD:" + password);
		System.out.println("SERVER:" + server);
		System.out.println("CDCOMMAND:" + commands.get(0));
		System.out.println("SHCOMMAND:" + commands.get(1));

		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session = jsch.getSession(user, server, 22);
		session.setPassword(password);
		session.setConfig(config);
		/*
		 * if(createVerticaSchema.equalsIgnoreCase("true")) {
		 */
		session.setConfig("PreferredAuthentications",
				"publickey,keyboard-interactive,password");

		// }
		session.connect();
		Channel channel = session.openChannel("shell");

		OutputStream outPutStream = channel.getOutputStream();
		PrintStream commander = new PrintStream(outPutStream, true);

		channel.setOutputStream(System.out, true);

		channel.connect();
		InputStream is = channel.getInputStream();

		for (String command : commands) {
			commander.println(command);
			// /commander.flush();
		}

		Thread.sleep(3000);
		commander.println("quit");
		Thread.sleep(3000);
		commander.println("exit");
		Thread.sleep(3000);
		commander.println("exit");
		/*
		 * Thread.sleep(10000); commander.println("exit");
		 */

		outPutStream.flush();
		outPutStream.close();

		commander.close();

		int c = 0;
		while ((c = is.read()) != -1) {
			// System.out.print((char)c);
			sb.append((char) c);
			/*
			 * if(channel.isClosed()) { System.out.println("exit-status: " +
			 * channel.getExitStatus()); break; }
			 */
			/*
			 * try { Thread.sleep(3000); } catch (Exception ee) { }
			 */
		}
		System.out.println(">>>>>>>>>" + sb.toString());
		is.close();

		/*
		 * do { Thread.sleep(1000); } while (!channel.isEOF());
		 */

		channel.disconnect();
		session.disconnect();
		System.out.println("DONE");

		return sb.toString();

	}

}
