package dashboard.web.pagecontroller;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.engine.oracle.NamingUtil;
import dashboard.engine.oracle.OracleUserCreator;
import dashboard.engine.vertica.BaseVerticaManager;
import dashboard.engine.vertica.VerticaTransferValidation;
import dashboard.util.CmdRunner;
import dashboard.util.Constants;
import dashboard.util.FileUtil;
import dashboard.util.InsertExceptionToLogger;
import dashboard.web.util.CustomException;

/**
 *
 * *********************************DESCRIPTION*********************************
 * Please note that 1. and 2. are validation processes 1. Check whether data
 * transfer for the selected schema is ongoing or not
 *
 * 2. Check whether the table space for source schema is in read only mode
 *
 * 3. Check whether table VT_RETRANSFER_OBJLIST exists on source schema. 3.1 If
 * table do not exists then initiate transfer normally. NOTE: The table will be
 * created only after the first data transfer is executed. 3.2 If table exists
 * then initiate transfer only if record count of the table is > 0 3.3 Error
 * Handling: re-transfer with record count = 0 3.3.1.	Dashboard will display
 * error message if VT_RETRANSFER_OBJLIST exists and record count = 0 3.3.2.
 * Message will tell user that this is a re-transfer and they are required to
 * add table names to VT_RETRANSFER_OBJLIST
 *
 * 4. Check whether the given vertica schema (destSchema) exists or not in
 * destination vertica server using verticaUtilSchema. 4.1 If schema does not
 * exists, then first 4.1.1 Checks whether destination vertica schema info is
 * already inserted in processing.platform_schema_info table,if not then
 * generates schema password and inserts schema info with password to
 * processing.platform_schema_info table. Else, fetches password for
 * processing.platform_schema_info table 4.1.2 invokes a shell script in
 * destination vertica server to create vertica schema 4.2 If schema already
 * exists, alerts user for retransfer.
 *
 *
 * NOTE:1. SERVER SIDE VALIDATIONS 1,2 AND 3 MUST BE REPLACED BY METHODS IN
 * CLASS VERTICATRANFERVALIDATION.JAVA 2. VERTICA SCHEMA CREATION TO BE REPLACED
 * BY VERTICASCHEMAMANAGER.JAVA
 */
public class VerticaPRODSchemaManager extends Controller {

    public static final String READ_ONLY = "READ ONLY";

    @Override
    public String process(HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        EngineMonitor engineMonitor = getEngineMonitor(request);
        EventLogger eventLogger = ComponentFactory.getInstance().getEventLogger();
        String retVal = "processOutput";
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        boolean schemaExists = false;
        boolean error = false;
        boolean verticaDbError = false;
        boolean verticaSchemaExists = false;
        boolean verticaSchemaInfoAlreadyInserted = false;

        String errorMsg = "";
        String verticaSchemaCreationOutput = "";
        String verticaSchemaExistsError = "";
        String O2VStatus = "";

        String srcServerGroupId = webTransfer.getString("srcServerGroupId");
        String srcHost = webTransfer.getString("srcHost");
        String srcPort = webTransfer.getString("srcPort");
        String srcService = webTransfer.getString("srcService");
        String srcSchm = webTransfer.getString("srcSchema");
        //String srcPwd =  webTransfer.getString("srcPwd");
        String srcSidFlag = webTransfer.getString("srcSidFlag");
        String connection = webTransfer.getString("srcConnection");
        String srcDatabaseId = webTransfer.getString("srcDatabaseId");

        Schema srcSchema = (new Schema())
                .setServerGroupId(srcServerGroupId)
                .setServerName(srcHost)
                .setPort(srcPort)
                .setService(srcService)
                .setSidFlag(srcSidFlag)
                .setSchemaName(srcSchm)
                //.setSchemaPwd(srcPwd)
                .setConnection(connection)
                .setDatabaseId(srcDatabaseId);
        engineMonitor.setServerGroupName(srcSchema);

        String engineVersion = engineMonitor.getEngineVersion(srcSchema);
        srcSchema.setEngineVersion(engineVersion);

        String hostingServer = ((webTransfer.getString("hostingServer") == null) || (webTransfer.getString("hostingServer") == ""))
                ? Constants.VERTICA_CMA : webTransfer.getString("hostingServer");

        destVtkaSchema = getDestVerticaRACSchema(webTransfer, engineMonitor);
        destVtkaSchema.setEngineVersion(engineVersion);//added engine version

        /**
         * VITTOOLS-383 : BA module not in use , so runBAModule is set to false
         * by default
         */
        //runBAModule = (webTransfer.getString("runBaModule") ==null)?"":webTransfer.getString("runBaModule");
        runBAModule = Constants.FALSE;
        destOrclSchema = new Schema();
        /**
         * VITTOOLS-383 : BA module no longer in use
         */
        //get destination oracle server for ba module transfer
        /*if(runBAModule.equalsIgnoreCase("TRUE")){
			System.out.println("BA module is checked!!!!!");
			destOrclSchema.setServerGroupId( webTransfer.getString("destOracleServerGroupId"));
            destOrclSchema.setServerName( webTransfer.getString("destOracleHost") );
            destOrclSchema.setPort( webTransfer.getString("destOraclePort"));
            destOrclSchema.setService( webTransfer.getString("destOracleService"));
            destOrclSchema.setSidFlag( webTransfer.getString("destOracleSidFlag"));
            destOrclSchema.setSchemaName( webTransfer.getString("destOracleSchema"));
            //.setSchemaPwd( webTransfer.getString("destOraclePwd"))
            destOrclSchema.setHostingServer(Constants.ORACLE_BA);
            //destOracleSchema.setClientName(engineMonitor.getClientName(webTransfer.getString("destOracleSchema")));
            //destOracleSchema.setEngineVersion(engineVersion);
            destOrclSchema.setDatabaseId(webTransfer.getString("destOracleDatabaseId"));
            engineMonitor.setServerGroupName(destOrclSchema);
		}*/

        String event = "Create Schema(Vertica)";
        String desc = "Create Vertica User: " + destVtkaSchema.getServerGroupName() + " "
                + destVtkaSchema.getServerName() + ":" + destVtkaSchema.getPort() + "/" + destVtkaSchema.getDatabase() + "/" + destVtkaSchema.getSchemaName();
        Date startDate = new Date(System.currentTimeMillis());

        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();
        BaseVerticaManager validations = null;
        try {
            validations = (new VerticaTransferValidation()).setEngineMonitor(engineMonitor)
                    .setHostingServer(hostingServer)
                    .setOrclSchema(srcSchema)
                    .setDestOrclSchema(destOrclSchema)
                    .setVtkaSchema(destVtkaSchema)
                    .setTransferToProduction(Boolean.TRUE)//This enables checking retranfer valdation in verticaTransferValidation
                    .setBaTransfer(runBAModule.equalsIgnoreCase("TRUE"));// To check for oracle mapping
            validations.init();
        } catch (Exception e) {
            logger.error("VerticaProdSchemaManager.java>> Error while O2V Data Transfer with sub task " + desc + validations.getSubDesc());
            StringWriter sw = InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
            ComponentFactory.getInstance().getEventLogger().logError(
                    loginName, event, desc + validations.getSubDesc(), 0, startDate, new Date(), sw.toString(), destVtkaSchema);
            errorList.add(e.getMessage());
            // setting error
            error = true;
            request.setAttribute("O2VStatus", validations.getO2VStatus());
            request.setAttribute("error", error);
            return retVal;
        }

        //event log
        eventLogger.logStart(loginName, event, desc, 0, startDate, destVtkaSchema, (long) 0);

        /**
         *
         * CHECKING WHETHER VERTICA SHEMA EXISTS OR NOT
         *
         * *
         */
        String adminUserName = fixedParam.getValue(Constants.VS_ADMINNAME, hostingServer);
        String adminPass = fixedParam.getValue(Constants.VS_ADMINPWD, hostingServer);
        Schema verticaUtilSchema = new Schema()
                .setServerGroupId(webTransfer.getString("destServerGroupId"))
                .setServerName(webTransfer.getString("destHost"))
                .setPort(webTransfer.getString("destPort"))
                .setService(webTransfer.getString("destConnection"))
                .setConnection(webTransfer.getString("destConnection"))
                .setDatabase(webTransfer.getString("destDatabase"))
                .setSchemaName(adminUserName)//admin schema name
                .setSchemaPwd(adminPass)//admin schema password
                .setHostingServer(Constants.VERTICA);

        try {
            /*
             * PASSWORD LESS DESIGN
             */
            try {
                setPwdForSchema(request);
            } catch (Exception e) {
                logger.error("VerticaProdSchemaManager.java>> Error!!!");
                StringWriter sw = InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
                // show error in event log
                ComponentFactory.getInstance().getEventLogger().logError(
                        loginName, event, desc, 0, startDate, new Date(), sw.toString(), destVtkaSchema);
                //showing error in UI
                errorList.add(e.getMessage());
                // setting error
                error = true;
                request.setAttribute("error", error);
                return retVal;
            }
            verticaSchemaExists = engineMonitor.verticaSchemaExists(verticaUtilSchema, destVtkaSchema.getSchemaName());
            if (verticaSchemaExists) {
                schemaExists = true;
                if (!vtkaSchemaInfoInserted) {
                    /**
                     * @Description: Case where vertica schema physically exists
                     * but there was not entry in platform_schema_info table.
                     * Steps : 1. Delete the inserted password for this schema
                     * 2. AND halt the transfer.
                     *
                     *
                     */
                    logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                            + " but pwd entry was not found in platform_schema_info");
                    //int count = engineMonitor.deletePwdEntry(destVtkaSchema);
                    //logger.info("Total Number of Password entry deleted for "+destVtkaSchema.getServerGroupName()+"/"+destVtkaSchema.getSchemaName()+": "+count);
                    CustomException.assertError("Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                            + " but its password was not found in processing.platform_schema_info table. "
                            + "Please drop the schema and re-initiate the transfer.");
                } else {
                    /**
                     * @Description: Case where vertica schema physically exists
                     * and there was also the entry for this schema in
                     * platform_schema_info table. Steps: 1. Test the schema
                     * using the fetched pwd 2. If connection failed, halt the
                     * transfer 3. Else continue the transfer *
                     */
                    Object[] jbdcResult = engineMonitor.isValid(destVtkaSchema);
                    boolean conn = (Boolean) jbdcResult[0];
                    if (!conn) {
                        logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                                + " but jdbc connection was failed");
                        /*int count = engineMonitor.updateIsDeletedFlag(destVtkaSchema,"Y");*/
                        CustomException.assertError("Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                                + " but jdbc connection failed ");
                    } else {
                        verticaSchemaCreationOutput = "Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName();
                        errorMsg = "Schema " + destVtkaSchema.getSchemaName() + " already exists in " + destVtkaSchema.getServerName();
                        eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVtkaSchema);
                        logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName());
                    }
                }
                /*schemaExists = true;
				verticaSchemaCreationOutput = "Schema "+destVtkaSchema.getSchemaName()+" already exists on "+destVtkaSchema.getServerName();
				errorMsg = "Schema "+destVtkaSchema.getSchemaName()+" already exists in "+destVtkaSchema.getServerName();
	   	 		eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVtkaSchema);
	   	 		logger.info("Vertica Schema "+destVtkaSchema.getSchemaName()+" already exists on "+destVtkaSchema.getServerName());*/
            } else {
                String databaseName = destVtkaSchema.getDatabase();// getting database from UI
                String user = fixedParam.getValue(Constants.VS_USERNAME, hostingServer);
                String commandLocation = fixedParam.getValue(Constants.VS_SHFILELOCATION, hostingServer);
                String commandName = fixedParam.getValue(Constants.VS_SHFILENAME, hostingServer);
                String password = fixedParam.getValue(Constants.VS_PASSWORD, hostingServer);
                String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

                String params = databaseName + " "
                        + adminUserName + " "
                        + adminPass + " "
                        + destVtkaSchema.getSchemaName() + " "
                        + destVtkaSchema.getSchemaName() + " "
                        + destVtkaSchema.getSchemaPwd();

                String cdCommand = "cd " + commandLocation;
                String shCommand = "sh " + commandName + " " + params;

                List<String> commands = new ArrayList<String>();
                commands.add(cdCommand);
                commands.add(shCommand);

                //logger.info("Command executed for vertica schema creation "+cdCommand+" "+shCommand);
                verticaSchemaCreationOutput = CmdRunner.runCommandsOnShell(false, destVtkaSchema.getServerName(), user, password, commands, privateKey);

                Object[] checkVerticaDbError = getError(verticaSchemaCreationOutput, PAT_VERTICA_DB_ERROR);
                if (Boolean.TRUE.equals(checkVerticaDbError[0])) {
                    verticaDbError = true;
                    errorMsg = (String) checkVerticaDbError[1];
                    logger.error("Schema " + destVtkaSchema.getSchemaName() + " cannot be created on " + destVtkaSchema.getServerName() + ": " + errorMsg);
                    eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVtkaSchema);
                } else {
                    eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVtkaSchema);
                    logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " successfully created on " + destVtkaSchema.getServerName());
                }
            }
        } catch (Exception e) {
            logger.error("Error while checking vertica schema " + destVtkaSchema.getSchemaName() + " on server " + destVtkaSchema.getServerName() + ": " + e.toString());
            InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
            verticaSchemaExistsError = e.toString();
            error = true;
            verticaSchemaCreationOutput = verticaSchemaExistsError;
            eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), verticaSchemaCreationOutput, destVtkaSchema);
            /*
			 * Delete the inserted password if any error occurs while creating schema
             */
            int count = engineMonitor.deletePwdEntry(destVtkaSchema);
            logger.info("CATCHED EXECEPTION while creating schema:Total Number of Password entry deleted for " + destVtkaSchema.getServerGroupName() + "/" + destVtkaSchema.getSchemaName() + ": " + count);

        }
        /*
   	 	 * TO HIDE PASSWORD
   	 	 * */
        OracleUserCreator oracleUserCreator = new OracleUserCreator();
        oracleUserCreator.setRunnerPassword(destVtkaSchema.getSchemaPwd());
        verticaSchemaCreationOutput = oracleUserCreator.hidePasswordsForVertica(verticaSchemaCreationOutput, hostingServer);

        /*writing schema creation shell script output to a file*/
        FileUtil.writeToTextFile(verticaSchemaCreationOutput, new NamingUtil().getCreateUserFile(destVtkaSchema));

        request.setAttribute("serverOutput", verticaSchemaCreationOutput);
        request.setAttribute("error", error);
        request.setAttribute("processDescription", "Vertica Schema Creation");
        request.setAttribute("schemaExists", schemaExists);
        request.setAttribute("verticaDbError", verticaDbError);

        return retVal;
    }

    //vsql: FATAL 2983: and vsql: FATAL 3781:
    private static final String VERTICA_DB_ERROR = "FATAL.*";
    public static final Pattern PAT_VERTICA_DB_ERROR = Pattern.compile(VERTICA_DB_ERROR, Pattern.MULTILINE);

    public static Object[] getError(String input, Pattern pattern) {
        Object[] ret = new Object[]{Boolean.FALSE, ""};
        if (null == input) {
            return ret;
        }

        StringBuffer sb = new StringBuffer();
        Matcher m = pattern.matcher(input);
        while (m.find()) {
            ret[0] = Boolean.TRUE;
            sb.append(m.group()).append("\n");
        }
        ret[1] = sb.toString();
        return ret;
    }

    public static void main(String args[]) {
        String test2 = "fjkdsahfdsa dsfas \t djafashf fatal     :23232 this is dsafsdafkdsa";
        System.out.println(test2);

        VerticaPRODSchemaManager vs = new VerticaPRODSchemaManager();

        Object[] testing2 = vs.getError(test2, PAT_VERTICA_DB_ERROR);
        System.out.println(testing2[0]);
    }
}
