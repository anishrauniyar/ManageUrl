package dashboard.web.pagecontroller;

import java.util.List;
import java.util.Collections;
import java.util.LinkedList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.engine.EngineMonitor;

import dashboard.data.WebTransfer;
import dashboard.data.Report;

import dashboard.engine.EngineMonitor;

public class ReportAdminController extends Controller {

    private static final String ADD_REPORT = "ADD_REPORT";
    private static final String UPDATE_REPORT = "UPDATE_REPORT";
    private static final String DELETE_REPORT = "DELETE_REPORT";
    private static final String LIST_REPORT = "LIST_REPORT";
    private static final String SYNC_REPORT = "SYNC_REPORT";
    private static final String SYNC_ENGVERSION = "SYNC_ENGVERSION";

    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception{
        String retVal = "setupReportAdmin";
        ComponentFactory compFactory  = ComponentFactory.getInstance();
        String appVersion = compFactory.getEnvInfo().getAppVersion();
        
        EngineMonitor engine = getEngineMonitor(request);
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String action = webTransfer.getString("ra_action");

        Report report = (new Report())
            .setReportName( webTransfer.getString("reportName"))
            .setReportDesc( webTransfer.getString("reportDesc"))
            .setSourceDir( webTransfer.getString("sourceDir"))
            .setReportId(webTransfer.getString("reportId") != null ? 
            			 Integer.parseInt(webTransfer.getString("reportId")) : 0);

        Report oldReport = (new Report())
            .setReportName( webTransfer.getString("oldReportName"))
            .setReportDesc( webTransfer.getString("oldReportDesc"))
            .setSourceDir( webTransfer.getString("oldSourceDir"))
            .setReportId(webTransfer.getString("oldReportId") != null ? 
            			 Integer.parseInt(webTransfer.getString("oldReportId")) : 0);

        request.setAttribute("report", report);

        
        int count = 0;
        try {
            if (ADD_REPORT.equals(action)) {

                count = engine.addReport(report);
                messageList.add("Reports added: " + count);
                if (count == 0) {
                    messageList.add("Make sure report name is unique.");
                }
            } else if ( UPDATE_REPORT.equals(action)) {
                if (report.isAllDefined() && oldReport.isAllDefined() ) {
                    count = engine.updateReport(oldReport, report);
                    messageList.add("Reports updated: " + count);
                    if (count == 0) {
                        messageList.add("Report may have changed. Reload.");
                    }
                } else {
                    errorList.add("Not a valid request for update.");
                    logger.info("Invalid update request: old " + oldReport + " :new:" + report);
                }
            }
            else if (DELETE_REPORT.equals( action)) {
                count = engine.deleteReport(report);
                messageList.add("Reports deleted: " + count);
                if (count == 0) {
                    messageList.add("Report may have changed.");
                }
                
            }else if (SYNC_REPORT.equals(action)){   
            	engine.syncReportsByOAM();  
            	messageList.add("Reports synchronized with OAM");
            } else if (SYNC_ENGVERSION.equals(action)) {
                engine.syncEngVersionWithOAM();
                messageList.add("Client engine versions synchronized with OAM");
            }
            
            
        } catch(Exception ex) {
            errorList.add("Error: " + ex.getMessage() + action + report);
        }
        oldReport = new Report();
        
        List lsReports = engine.listReportModulesOAM();
        request.setAttribute("lsReports", lsReports);
        List ls = engine.listReportModules();
        request.setAttribute("ls", ls);
        request.setAttribute("oldReport", oldReport);
        request.setAttribute("srcDirectory",compFactory.getEnvInfo().getSourceDir());
        return retVal;
    }
}
