package dashboard.web.pagecontroller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.TaskKey;
import dashboard.util.Constants;


public class ServersStatus extends Controller {

    private static final String KILL_PROCESS = "KILL_PROCESS";

    protected Log logger = LogFactory.getLog(getClass());
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception{
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        ComponentFactory fact = ComponentFactory.getInstance();
        FixedParameter fixedParam = null;

        Map errorTableMap = fact.getErrorTableMap();
        Map taskLogMap = fact.getTaskLogMap();

        
        String action = webTransfer.getString("action");
        String loginName = webTransfer.getString("session:loginName");

        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);

        HttpSession session = request.getSession(false);
        boolean isProcessSuperAdmin = Boolean.TRUE.equals( session.getAttribute("isProcessSuperAdmin"));//Techops
        boolean isProcessAdmin = Boolean.TRUE.equals( session.getAttribute("isProcessAdmin"));// PE
        boolean isProcessManager = Boolean.TRUE.equals( session.getAttribute("isProcessManager"));// System/DBA
        
        
        EngineMonitor engine = getEngineMonitor( request);
        

        if ( KILL_PROCESS.equals(action)) {
            try {
                String serverGroupId = webTransfer.getString("serverGroupId");
                String frontSchema = webTransfer.getString("frontSchema");
                String execNo = webTransfer.getString("executionNumber");
                if (serverGroupId != null && frontSchema != null) {
                    TaskKey taskKey
                        =  (new TaskKey())
                        .setServerGroupId(serverGroupId)
                        .setSchemaName(frontSchema);
                    taskKey.setExecutionNumber(Long.valueOf(execNo));
                    TaskKey actualTaskKey = engine.getActualTaskKey( taskKey);
                    if ( null != actualTaskKey ) {
                        if ( isProcessSuperAdmin || isProcessAdmin || isProcessManager || actualTaskKey.getUserName().equals(loginName)) {
                            Boolean ret = engine.killProcess( taskKey);
                            messageList.add("Process killed?  " + ret);
                            
                            //for oracle to vertica data transfer
                            String hostingServer = webTransfer.getString("hostingServer");
                            if((hostingServer!=null) && 
                               (hostingServer !="")  && 
                               ((hostingServer.equalsIgnoreCase(Constants.VERTICA)) || 
                                (hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA))) ||
                                (hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)))
                            {
                            	//String O2VProcessID = webTransfer.getString("O2VProcessID");
                            	String srcServer = engine.getHostName(Long.valueOf(execNo));
                            	String O2VProcessID = engine.getO2VProcessId(execNo, srcServer,hostingServer);
                            	if(O2VProcessID.equals("0")){
                            		errorList.add("Oracle to Vertica Process could not be killed");
                            		errorList.add("Please kill the process manually");
                            	}
                            	else{
                            		//String execNo = webTransfer.getString("executionNumber");
                            		
                            		boolean O2VProcessKilled = engine.killOracleToVerticaProcess(execNo, O2VProcessID, srcServer,hostingServer);
                            		String cma_batch_id = "";	
                            		//for cma
                            		if((hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA)) ||
                            		   ((hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)))){
                            			fixedParam = fact.getFixedParameters();
                            			String centralHost = fixedParam.getValue(Constants.CS_HOST,hostingServer);
                        	    		String centralPort = fixedParam.getValue(Constants.CS_PORT,hostingServer);
                        	    		String centralService = fixedParam.getValue(Constants.CS_SERVICE,hostingServer);
                        	    		String centralSchemaName = fixedParam.getValue(Constants.CS_SCHEMA,hostingServer);
                        	    		String centralSchemaPwd = fixedParam.getValue(Constants.CS_SCHEMAPWD,hostingServer);
                        	    		
                        	    		Schema centralSchema = (new Schema())
    	    									.setServerName(centralHost)
    	    									.setPort(centralPort)
    	    									.setService(centralService)
    	    									.setSchemaName(centralSchemaName)
    	    									.setSchemaPwd(centralSchemaPwd);
                        	    		
                        	    		cma_batch_id = engine.getCMABatchId(Long.valueOf(execNo), centralSchema);
                            			
                            			//cma_batch_id = engine.getCMABatchID(execNo, srcServer);//from shell output
                            		}
                            		
                            		//showing messages in UI
                            		if(O2VProcessKilled){
                            			messageList.add("Oracle to Vertica Process ID "+O2VProcessID+" Killed on "+srcServer+" server");
                            			logger.info("Oracle to Vertica Process ID "+O2VProcessID+" Killed on "+srcServer+" server "+"by "+loginName);
                            			
                            			//for cma
                            			if(((hostingServer.equalsIgnoreCase(Constants.VERTICA_DR_CMA)) ||
                            			        (hostingServer.equalsIgnoreCase(Constants.VERTICA_CMA))) && (!cma_batch_id.equalsIgnoreCase(""))){
                            				messageList.add("Please contact DBA to kill cma batch id :"+cma_batch_id);
                            				logger.info("CMA Batch ID is :"+cma_batch_id);
                            			}
                            		}
                            		else{
                            			//if process cannot be killed or killed log file could not be written
                            			errorList.add("Oracle to Vertica Process could not be killed on "+srcServer);
                            			errorList.add("Please kill the process manually");
                            		}
                            	}
                            }
                            
                        } else {
                            errorList.add("Access denied.");
                        }
                    } else {
                        messageList.add("Process does not exist.");
                    }
                }
            }catch (Exception ex) {
                errorList.add("Failed killing process.");
                errorList.add( ex.getMessage());
            }
        }       
        TaskKey [] taskKeys = engine.getTaskKeys();
        request.setAttribute("taskKeys", taskKeys);
        request.setAttribute("loginName", loginName);
        request.setAttribute("errorTableMap", errorTableMap);
        request.setAttribute("taskLogMap", taskLogMap);
        request.setAttribute("isProcessAdmin", isProcessAdmin); 
        return "serversStatus";
    }
}
