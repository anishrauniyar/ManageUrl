package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import dashboard.data.TempTablespace;

public class TempTablespaceValidator extends ValidatorRoot {
    public boolean isValid(Object obj, HttpServletRequest request){
        boolean retVal = true;
        if (null == obj) {
            throw new NullPointerException("Object to verify null in " + this.getClass().getName());
        }
        if ( ! (obj instanceof TempTablespace) ) {
            throw new IllegalArgumentException("Object to verify is not TempTablespace in " + this.getClass().getName());
        }
        
        init(request);
        List errors = getErrorList();
        List message = getMessageList();
        TempTablespace tempTablespace = (TempTablespace) obj;

        if ("".equals(tempTablespace.getServerGroupId())) {
            errors.add("serverGroupId is blank");
            retVal = false;
        }
        if( "".equals(tempTablespace.getTempTablespace())) {
            errors.add("TempTablespace is blank");
            retVal = false;
        }        
        return retVal;
    }
}
