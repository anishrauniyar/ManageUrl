package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;

public class DashBoardController extends Controller {

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String userId = webTransfer.getString("session:userId");
		/*EngineMonitor engineMonitor = getEngineMonitor(request);
		List<Chart> lsCharts = engineMonitor.getChartData();
		request.setAttribute("lsCharts", lsCharts);*/
		return "dashboard";
	}
}
