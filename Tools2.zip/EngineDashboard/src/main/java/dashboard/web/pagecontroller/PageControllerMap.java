package dashboard.web.pagecontroller;

import java.util.Collections;
import java.util.Map;

public class PageControllerMap {
    Map controllerMap = null;
    public void setPageControllerMap(Map cntrlMap) {
        if(controllerMap == null) {
            controllerMap = Collections.unmodifiableMap(cntrlMap);
        } else {
            throw new IllegalArgumentException("ControllerMap already set");
        }
    }
    public PageController getController(String controllerName) {
        if (controllerMap.containsKey(controllerName)) {
            return (PageController) controllerMap.get(controllerName);
        }
        System.out.println("Controller missing: " + controllerName);  
        throw new UnknownPageControllerException(controllerName);        
    }
    
    public boolean isSupportedPageController(String controllerName) {
        return controllerMap.containsKey(controllerName);
    }

}
