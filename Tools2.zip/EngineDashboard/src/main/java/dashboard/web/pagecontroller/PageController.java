package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.web.view.Page;
import dashboard.security.ProcessingRole;

public interface PageController {
    
    void setPageControllerMap(PageControllerMap pgControllerMap);
    String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception;
    boolean isAuthorizationEnabled();

    ProcessingRole getRequiredRole() ;

}
