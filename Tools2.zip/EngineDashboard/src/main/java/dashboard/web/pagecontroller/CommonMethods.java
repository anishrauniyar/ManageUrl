package dashboard.web.pagecontroller;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.util.Constants;

/**
 * Some the common methods used by controllers
 * 
 */
public class CommonMethods {
	
	/**
	 * Description : Returns event description for data transfer event
	 * 
	 * @param srcSchema
	 * @param destSchema
	 * @return
	 */
	protected String getEventDescForDataTransfer(Schema srcSchema, Schema destSchema) {
		return "Data Transfer to "
		        +
		        // " [" + destSchema.getServerGroupName() + "] " +
		        destSchema.getServerName() + ":" + destSchema.getPort() + "/"
		        + destSchema.getDatabase() + ":" + destSchema.getSchemaName() + " from "
		        + srcSchema.getServerName() + ":" + srcSchema.getPort() + ":"
		        + srcSchema.getSchemaName();
	}
	
	/**
	 * Description : Returns source oracle schema
	 * 
	 * @param webTransfer
	 * @return
	 * @throws Exception
	 */
	protected Schema getOracleSrcSchema(WebTransfer webTransfer, EngineMonitor engine)
	        throws Exception {
		Schema srcSchema = (new Schema()).setServerGroupId(webTransfer.getString("srcServerGroupId"))
		        .setServerName(webTransfer.getString("srcHost"))
		        .setPort(webTransfer.getString("srcPort"))
		        .setService(webTransfer.getString("srcService"))
		        .setSidFlag(webTransfer.getString("srcSidFlag"))
		        .setSchemaName(webTransfer.getString("srcSchema"))
		        .setDatabaseId(webTransfer.getString("srcDatabaseId"))
		        .setHostingServer(Constants.ORACLE)
		        .setConnection(webTransfer.getString("connection"));
		
		/**
		 * Setting Engine Version
		 */
		srcSchema.setEngineVersion(engine.getEngineVersion(srcSchema));
		
		return srcSchema;
		
	}
	
	
	/**
	 * Description : Returns destination vertica schema. 
	 * 
	 * NOTES: 
	 * 1. Engine Version not SET here 
	 * 2. Hosting server is just a flag
	 * 
	 * @param webTransfer
	 * @return
	 * @throws Exception
	 */
	protected Schema getDestVerticaRACSchema(WebTransfer webTransfer, EngineMonitor engine)
	        throws Exception {
		Schema verticaSchema = (new Schema())
            	        	.setClusterGroupId(webTransfer.getString("destClusterGroupId"))
            	        	.setClusterGroupName(webTransfer.getString("destClusterGroupName"))
		                    .setServerGroupId( webTransfer.getString("destServerGroupId"))
            	            .setServerName( webTransfer.getString("destHost") )
            	            .setPort( webTransfer.getString("destPort"))
            	            //.setService( webTransfer.getString("destConnection"))//used in event log
            	            .setConnection( webTransfer.getString("destConnection"))
            	            .setDatabase( webTransfer.getString("destDatabase"))
            	            .setSchemaName( webTransfer.getString("destSchema"))
            	            .setHostingServer(Constants.VERTICA)
            	        	.setDatabaseId(webTransfer.getString("destDatabaseId"));
		
		/**
		 * Setting Client Name
		 */
		
		verticaSchema.setClientName(engine.getClientName(verticaSchema.getSchemaName()));
		/*
		 * Setting Server Group Name
		 */
		engine.setServerGroupName(verticaSchema);
		
		return verticaSchema;
	}
	
	/**
	 * Description : Returns destination verticaDR schema. 
	 * 
	 * NOTES: 
	 * 1. Engine Version not SET here 
	 * 2. Hosting server is just a flag
	 * 
	 * @param webTransfer
	 * @return
	 * @throws Exception
	 */
	protected Schema getDestVerticaDRSchema(WebTransfer webTransfer, EngineMonitor engine)
	        throws Exception {
		Schema verticaDRSchema = (new Schema())
		        .setClusterGroupId(webTransfer.getString("destClusterGroupId"))
                .setClusterGroupName(webTransfer.getString("destClusterGroupName"))
		        .setServerGroupId(webTransfer.getString("destVerticaDRServerGroupId"))
		        .setServerName(webTransfer.getString("destVerticaDRHost"))
		        .setPort(webTransfer.getString("destVerticaDRPort"))
		        .setService(webTransfer.getString("destVerticaDRDatabase"))
		        .setConnection(webTransfer.getString("destVerticaDRConnection"))
		        .setDatabase(webTransfer.getString("destVerticaDRDatabase"))
		        .setSchemaName(webTransfer.getString("destVerticaDRSchema"))
		        .setHostingServer(Constants.VERTICA)
		        .setDatabaseId(webTransfer.getString("destVerticaDRDatabaseId"));
		
		/**
		 * Setting Client Name
		 */
		
		verticaDRSchema.setClientName(engine.getClientName(verticaDRSchema.getSchemaName()));
		
		/*
         * Setting Server Group Name
         */
        engine.setServerGroupName(verticaDRSchema);
		
		return verticaDRSchema;
	}
	
	
	/**
	 * Description : Returns destination oracleDR schema. 
	 * NOTES: 
	 * 1. Engine Version not SET here 
	 * 2. Hosting server is just a flag
	 * 
	 * @param webTransfer
	 * @return
	 * @throws Exception
	 */
	protected Schema getDestOracleDRSchema(WebTransfer webTransfer, EngineMonitor engine)
	        throws Exception {
		Schema oracleDRSchema = (new Schema())
		        .setServerGroupId(webTransfer.getString("oracleDRServerGroupId"))
		        .setServerName(webTransfer.getString("oracleDRHost"))
		        .setPort(webTransfer.getString("oracleDRPort"))
		        .setService(webTransfer.getString("oracleDRService"))
		        .setSidFlag(webTransfer.getString("oracleDRSid"))
		        //.setConnection(webTransfer.getString("oracleDRConnection"))
		        //.setDatabase(webTransfer.getString("oracleDRDataBase"))
		        .setSchemaName(webTransfer.getString("oracleDRSchema"))
		        .setHostingServer(Constants.ORACLE_DR_BA_CMA)
		        .setDatabaseId(webTransfer.getString("oracleDRDbId"));
		
		/**
		 * Setting Client Name
		 */
		
		oracleDRSchema.setClientName(engine.getClientName(oracleDRSchema.getSchemaName()));
		
		/**
		 * Setting Engine Version
		 */
		oracleDRSchema.setEngineVersion(engine.getEngineVersion(oracleDRSchema));
		
		return oracleDRSchema;
	}
	
	public Schema getVerticaSchema(Schema vtkaSchema,EngineMonitor engine) throws Exception
	{
	    List<Schema> verticaSchemaList = engine.getVerticaSchemaList(vtkaSchema);
	    return verticaSchemaList.get(0);
	}
	
	/**
	 * @Description : Gets VC schema for Mini Engine
	 * @param webTransfer
	 * @return
	 */
	protected Schema getVCSchemaForMiniEngine(WebTransfer webTransfer) {
		Schema vcSchema = (new Schema())
				.setServerGroupId(webTransfer.getString("VCServerGroupId"))
				.setServerName(webTransfer.getString("VCHost"))
				.setPort(webTransfer.getString("VCPort"))
				.setService(webTransfer.getString("VCService"))
				.setSchemaName(webTransfer.getString("VCSchema"))
				.setDatabaseId(webTransfer.getString("VCDatabaseId"));
		String sidFlag = webTransfer.getString("VCSidFlag");

		if (sidFlag != null) {
			vcSchema = vcSchema.setSidFlag(webTransfer.getString("VCSidFlag"));
		}

		return vcSchema;
	}
	
	/**
	 * @Description : Gets History schema for Mini Engine
	 * @param webTransfer
	 * @return
	 */
	protected Schema getHistSchemaForMiniEngine(WebTransfer webTransfer) {

		Schema historySchema = (new Schema())
				.setServerName(webTransfer.getString("histHost"))
				.setPort(webTransfer.getString("histPort"))
				.setService(webTransfer.getString("histService"))
				.setSchemaName(webTransfer.getString("histdbUser"))
				.setDatabaseId(webTransfer.getString("histdatabaseId"));

		String histSidFlag = webTransfer.getString("histSidFlag");
		if (histSidFlag != null) {
			historySchema = historySchema.setSidFlag(webTransfer
					.getString("histSidFlag"));
		}
		return historySchema;
	}
	
	/**
	 * @param input
	 * @param pattern
	 * @return true if given pattern is found
	 */
	public static boolean checkPattern(String input, Pattern pattern) {
		if (null == input) {
			return false;
		}
		Matcher m = pattern.matcher(input);
		while (m.find()) {
			return true;
		}
		return false;
	}
}
