package dashboard.web.pagecontroller.miniEngine;

import java.io.File;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.util.FileUtil;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;

public class MiniEngineLastOutputController extends Controller {

    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));

    private static final String S_TRUE = "TRUE";

    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "MREOutput";
        Boolean isRefreshAgain = Boolean.FALSE;
        
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        
        EngineMonitor engine = getEngineMonitor(request);
        
        String hostingServer = (webTransfer.getString("hostingServer") == null)?"": webTransfer.getString("hostingServer");
        Schema schema = (new Schema()).setServerName( webTransfer.getString("host") )
            .setPort( webTransfer.getString("port"))
            .setService( webTransfer.getString("service"))
            .setSchemaName( webTransfer.getString("schema"))
            .setServerGroupId( webTransfer.getString("serverGroupId"))
            .setEngineVersion(webTransfer.getString("ENG_VERSION"))
            .setHostingServer(hostingServer);
       
        
    
        	File [] lastOutputs = engine.getOutputFiles(schema);
            int lastModifiedIndex = -1;
            long lastModifiedTime = -1;
            
            for ( int i=0; lastOutputs != null && i<lastOutputs.length; i++) {
            	if (lastOutputs[i].exists()) {
                	if (lastModifiedTime < lastOutputs[i].lastModified() ) {
                        lastModifiedTime = lastOutputs[i].lastModified();
                        lastModifiedIndex = i;
                    }
                }
            }
            if ( lastModifiedIndex > -1 ) {
            	String flContent = FileUtil.readText(lastOutputs[lastModifiedIndex]).toString();
                request.setAttribute("serverOutput", flContent);
                request.setAttribute("processDescription", lastOutputs[lastModifiedIndex].getName());               
                
                
            } else {
                errorList.add("Output file does not exists.");
            }

      
                
        request.setAttribute("isRefreshAgain", isRefreshAgain);
        return retVal;
    }    
   
}
