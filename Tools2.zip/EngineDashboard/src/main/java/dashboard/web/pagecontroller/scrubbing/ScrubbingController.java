package dashboard.web.pagecontroller.scrubbing;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.ScrubbingTask;
import dashboard.data.WebTransfer;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.engine.oracle.scrubbing.CDFObjectScriptForHPValidator;
import dashboard.engine.oracle.scrubbing.ClientSpecificSQLScriptValidator;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.validator.Validator;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;

public class ScrubbingController extends Controller {

	private static final String PROCESS_SCRUBBING = "PROCESS_SCRUBBING";
	private static final String S_TRUE = "TRUE";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String retVal = "commonServerOutput";
		Boolean isRefreshAgain = Boolean.TRUE;

		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String loginName = webTransfer.getString("session:loginName");
		User user = (User) request.getSession().getAttribute("session:user");
		String action = webTransfer.getString("action");
		EngineMonitor engine = getEngineMonitor(request);

		if (action.equals(PROCESS_SCRUBBING)) {
			String event = "Process Scrub";
			AsyncSQLProcess sqlProcess = null;
			String engineVersion = "";
			if (null != webTransfer.getString("dbUser")
					&& !"".equalsIgnoreCase(webTransfer.getString("dbUser"))) {
				engineVersion = engine.getEngineVersionForSchema(webTransfer
						.getString("dbUser"));
				logger.info("Engine version from OAM : {}" + engineVersion);
			}
			// Override setting for engine version by user
			if (null != webTransfer.getString("overrideEngineVersion")
					&& webTransfer.getString("overrideEngineVersion")
							.equalsIgnoreCase("TRUE")
					&& null != webTransfer.getString("ENG_VERSION")
					&& !"".equals(webTransfer.getString("ENG_VERSION").trim())) {
				engineVersion = webTransfer.getString("ENG_VERSION").trim();
				logger.info("Engine version overriden by user : {}"
						+ engineVersion);
			}
			Schema scrubSchema = (new Schema())
					.setServerGroupId(
							(webTransfer.getString("serverGroupId") == null) ? ""
									: webTransfer.getString("serverGroupId"))
					.setServerName(webTransfer.getString("host"))
					.setPort(webTransfer.getString("port"))
					.setService(webTransfer.getString("service"))
					.setSchemaName(webTransfer.getString("schema"))
					// .setSchemaPwd(webTransfer.getString("dbPassword"))
					.setHostingServer(Constants.ORACLE)
					.setDatabaseId(webTransfer.getString("databaseId"));// getting
																		// database
																		// id
			String sidFlag = webTransfer.getString("sidFlag");
			if (sidFlag != null) {
				scrubSchema = scrubSchema.setSidFlag(webTransfer
						.getString("sidFlag"));
			}
			String desc = "[" + event + "]" + scrubSchema.getServerName() + ":"
					+ scrubSchema.getPort() + "/" + scrubSchema.getService()
					+ ":" + scrubSchema.getSchemaName();

			// Getting schema Password
			try {
				scrubSchema = engine.setSchemaPassword(scrubSchema);
			} catch (Exception e) {
				logger.error(
						"ScrubbingController.java (PROCESS_SCRUBBING) >> Error getting password for schema",
						e);
				ComponentFactory
						.getInstance()
						.getEventLogger()
						.logError(loginName, event, desc, 0, new Date(),
								new Date(), e, scrubSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}
			// Setting engine version and clientName
			scrubSchema.setEngineVersion(engineVersion).setClientName(
					engine.getClientName(scrubSchema.getSchemaName()));

			// getting scrub type and processing options
			ScrubbingTask scrubTask = new ScrubbingTask().setRunObjectScript(
					S_TRUE.equals(webTransfer.getString("COMPILE_SCRUB")))
					.setRunClientScript(
							S_TRUE.equals(webTransfer
									.getString("COMPILE_SCRUB")));

			Map<String, Boolean> cdfObjScriptForHP = null; // Additional Object Script for HP 
			Map<String, Boolean> clientSpecificSQLScripts = null;
			Validator clientSpecficSQLScriptsValidator = new ClientSpecificSQLScriptValidator(
					user);
			clientSpecficSQLScriptsValidator.setOrclSchema(scrubSchema);
			try {
				if (scrubSchema.getSchemaName().startsWith(Constants.HP)) {
					/*
					 * @Description: Validating CDF_OBJ_SCRIPTS_FOR_HP existence
					 * in SVN [For HP]
					 */
					Validator cdfObjScriptForHPValidator = new CDFObjectScriptForHPValidator(
							user);
					cdfObjScriptForHPValidator.setOrclSchema(scrubSchema);
					cdfObjScriptForHPValidator.validate();
					cdfObjScriptForHP = cdfObjScriptForHPValidator.getScripts();
				}
				/*
				 * @Description: Validating CLIENT_SPECIFIC_SCRIPTS existence in
				 * SVN [For Both HP & VC]
				 */
				clientSpecficSQLScriptsValidator.validate();
				clientSpecificSQLScripts = clientSpecficSQLScriptsValidator
						.getScripts();
			} catch (Exception e) {
				logger.error(
						"ScrubbingController.java (PROCESS_SCRUBBING) >> Error getting scripts ",
						e);
				// show error in event log
				ComponentFactory
						.getInstance()
						.getEventLogger()
						.logError(loginName, event, desc, 0, new Date(),
								new Date(),
								"[Error getting scripts] : " + e.toString(),
								scrubSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
			}

			sqlProcess = engine.executeScrubbing(scrubSchema, scrubTask,
					cdfObjScriptForHP, clientSpecificSQLScripts);

			SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
			TaskType taskType = sqlRunnable.getTaskType();
			TaskKey taskKey = sqlProcess.getTaskKey();

			messageList.add(sqlRunnable.getDescription());
			request.setAttribute("schema", scrubSchema);
			if ((loginName.equals(taskKey.getUserName()))
					&& ((TaskType.EXECUTE_CLIENT_SPEC_SCRIPT.equals(taskType)) || (TaskType.EXECUTE_OBJECT_SCRIPT
							.equals(taskType)))) {
				messageList.add("Currently queued: " + taskType.toString());
			} else {
				errorList.add("Schema is being used for " + taskType);
				errorList.add("Operation requested is not queued.");
				errorList.add("Job was scheuled by: " + taskKey.getUserName());
				isRefreshAgain = Boolean.FALSE;
			}
			request.setAttribute("isRefreshAgain", isRefreshAgain);

		}

		return retVal;
	}
}
