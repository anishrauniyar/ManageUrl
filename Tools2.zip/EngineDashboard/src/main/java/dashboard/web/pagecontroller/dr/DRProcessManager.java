package dashboard.web.pagecontroller.dr;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.ClusterGroup;
import dashboard.data.ServerGroup;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;

public class DRProcessManager extends Controller
{
    
    private static final String LIST_SERVER_GROUPS             = "LIST_SERVER_GROUPS";
    // /private static final String LIST_VERTICA_RAC_SERVER =
    // "LIST_VERTICA_RAC_SERVER";
    private static final String LIST_VERTICA_DR_SERVER         = "LIST_VERTICA_DR_SERVER";
    private static final String LIST_ORACLE_DR_SERVER          = "LIST_ORACLE_DR_SERVER";
    private static final String LIST_ORACLE_DR_DIR             = "LIST_ORACLE_DR_DIR";
    private static final String MAP_ORACLE_SERVERS             = "MAP_ORACLE_SERVERS";
    private static final String MAP_VERTICA_SERVERS            = "MAP_VERTICA_SERVERS";
    private static final String MAP_VERTICA_CLUSTERS           = "MAP_VERTICA_CLUSTERS";
    private static final String DELETE_VTKA_CLUSTERGRP_MAPPING = "DELETE_VTKA_CLUSTERGRP_MAPPING";
    private static final String DELETE_ORCL_SERVERGRP_MAPPING  = "DELETE_ORCL_SERVERGRP_MAPPING";
    private static final String PROD                           = "PROD";
    private static final String DR                             = "DR";
    
    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        
        String retVal = "serverMapper";
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String action = webTransfer.getString("action");
        
        EngineMonitor engine = getEngineMonitor(request);
        
        List lsOracleRACServerGroups = null;
        List lsOracleDRServerGroups = null;
        // List lsVerticaRACServerGroups = null;
        // List lsVerticaDRServerGroups = null;
        List lsProdVerticaClusterGrps = null;
        List lsDRVerticaClusterGrps = null;
        List lsVerticaRACServers = null;
        List lsVerticaDRServers = null;
        List lsOracleDRDirs = null;
        
        Map<ServerGroup, ServerGroup> oracleMappedList = null;
        Map<ClusterGroup, ClusterGroup> verticaMappedList = null;
        
        String oracleRACServerGroupId = "";
        String oracleDRServerGroupId = "";
        String verticaServerGroupId_RAC = "";
        String verticaServerGroupId_DR = "";
        String prodVerticaClusterGrpId = "";
        String drVerticaClusterGrpId = "";
        
        if (action.equals(LIST_SERVER_GROUPS))
        {
            lsOracleRACServerGroups = engine.getServerGroupListForProcessing();
            lsOracleDRServerGroups = engine.getServerGroupListForOracleDR();
            // lsVerticaRACServerGroups = engine.getVerticaRACServerGroupList();
            // lsVerticaDRServerGroups = engine.getVerticaDRServerGroupList();
            lsProdVerticaClusterGrps = engine.listVerticaClusterGrp(PROD);
            lsDRVerticaClusterGrps = engine.listVerticaClusterGrp(DR);
            
            oracleMappedList = engine.getOracleMappedServerGroupList();
            // verticaMappedList = engine.getVerticaMappedServerGroupList();
            verticaMappedList = engine.getVerticaMappedClusterGroupList();
            
            request.setAttribute("oracleRACServerGroup", lsOracleRACServerGroups);
            request.setAttribute("oracleDRServerGroup", lsOracleDRServerGroups);
            // request.setAttribute("verticaRACServerGroup",
            // lsVerticaRACServerGroups);
            // request.setAttribute("verticaDRServerGroup",
            // lsVerticaDRServerGroups);
            request.setAttribute("prodVerticaClusterGrps", lsProdVerticaClusterGrps);
            request.setAttribute("drVerticaClusterGrps", lsDRVerticaClusterGrps);
            request.setAttribute("oracleMappedList", oracleMappedList);
            request.setAttribute("verticaMappedList", verticaMappedList);
            
            return retVal;
        } else if (action.equals(MAP_ORACLE_SERVERS))
        {
            boolean mapped = false;
            oracleRACServerGroupId = webTransfer.getString("oracleRACServerGroupId");
            oracleDRServerGroupId = webTransfer.getString("oracleDRServerGroupId");
            
            try
            {
                mapped = engine.mapOracleServerGroup(oracleRACServerGroupId, oracleDRServerGroupId);
                messageList.add("Oracle Server Mapped: " + mapped);
            } catch (Exception e)
            {
                errorList.add("Oracle Server Mapped: " + mapped);
                errorList.add(e.getMessage());
            }
            return retVal;
        } else if (action.equals(MAP_VERTICA_SERVERS))
        {
            boolean mapped = false;
            verticaServerGroupId_RAC = webTransfer.getString("verticaRACServerGroupId");
            verticaServerGroupId_DR = webTransfer.getString("verticaDRServerGroupId");
            
            try
            {
                mapped = engine.mapVerticaServerGroup(verticaServerGroupId_RAC, verticaServerGroupId_DR);
                messageList.add("Vertica Server Mapped: " + mapped);
            } catch (Exception e)
            {
                errorList.add("Vertica Server Mapped: " + mapped);
                errorList.add(e.getMessage());
            }
            return retVal;
        } else if (action.equals(MAP_VERTICA_CLUSTERS))
        {
            boolean mapped = false;
            prodVerticaClusterGrpId = webTransfer.getString("prodVerticaClusterGrpId");
            drVerticaClusterGrpId = webTransfer.getString("drVerticaClusterGrpId");
            System.out.println(prodVerticaClusterGrpId);
            System.out.println(drVerticaClusterGrpId);
            
            try
            {
                mapped = engine.mapVerticaClusterGroup(prodVerticaClusterGrpId, drVerticaClusterGrpId);
                messageList.add("Vertica Cluster Mapped: " + mapped);
            } catch (Exception e)
            {
                errorList.add("Vertica Cluster Mapped: " + mapped);
                errorList.add(e.getMessage());
            }
            return retVal;
        } else if (action.equals(DELETE_VTKA_CLUSTERGRP_MAPPING))
        {
            prodVerticaClusterGrpId = webTransfer.getString("prodVtkaClusterGrpId");
            drVerticaClusterGrpId = webTransfer.getString("drVtkaClusterGrpId");
            try
            {
                int count = engine.deleteVtkaClusterGrpMapping(prodVerticaClusterGrpId, drVerticaClusterGrpId);
                messageList.add("No of mapping deleted " + count);
            } catch (Exception e)
            {
                errorList.add(e.getMessage());
            }
        } else if (action.equals(DELETE_ORCL_SERVERGRP_MAPPING))
        {
            oracleRACServerGroupId = webTransfer.getString("orclRACServerGrpId");
            oracleDRServerGroupId = webTransfer.getString("orclDRServerGrpId");
            try
            {
                int count = engine.deleteOrclServerGrpMapping(oracleRACServerGroupId,oracleDRServerGroupId);
                messageList.add("No of mapping deleted " + count);
            } catch (Exception e)
            {
                errorList.add(e.getMessage());
            }
        } else if (action.equals(LIST_VERTICA_DR_SERVER))
        {
            verticaServerGroupId_DR = webTransfer.getString("verticaServerGroupId_DR");
            lsVerticaDRServers = engine.getServersForServerGroup(verticaServerGroupId_DR);
            
            request.setAttribute("lsVerticaServers_DR", lsVerticaDRServers);
            
            return "verticaDRServerList";
        } else if (action.equals(LIST_ORACLE_DR_SERVER))
        {
            oracleDRServerGroupId = webTransfer.getString("oracleDRServerGroupId");
            //lsOracleDRServerGroups = engine.getServersForServerGroup(oracleDRServerGroupId);
            lsOracleDRServerGroups = engine.getVIPServersForServerGrp(oracleDRServerGroupId);
            
            request.setAttribute("lsDROracleServers", lsOracleDRServerGroups);
            
            return "oracleServerList_DR";
        } else if (action.equals(LIST_ORACLE_DR_DIR))
        {
            oracleDRServerGroupId = webTransfer.getString("oracleServerGroupId_DR");
            lsOracleDRDirs = engine.getDataFileDirsForServerGroup(oracleDRServerGroupId);
            
            request.setAttribute("lsOracleDRDirs", lsOracleDRDirs);
            
            return "oracleDRDataFileDirectory";
        }
        return retVal;
    }
}
