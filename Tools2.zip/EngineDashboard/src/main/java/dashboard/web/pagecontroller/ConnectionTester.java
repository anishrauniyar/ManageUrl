package dashboard.web.pagecontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.util.Constants;

public class ConnectionTester extends Controller {

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String retVal = "messageList";
		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		String hostingServer = webTransfer.getString("sa_hostingServer");
		String tab = (webTransfer.getString("tab") == null)?"":webTransfer.getString("tab");
		request.setAttribute("hostingServer", hostingServer);
		EngineMonitor engineMonitor = getEngineMonitor(request);
		Schema schema = null;
		ConnectionTester connectionTester = new ConnectionTester();

		if (hostingServer.equalsIgnoreCase(Constants.ORACLE)) {
			schema = connectionTester.getOracleSchema(webTransfer);
			if("SCHEMA_ADMIN".equalsIgnoreCase(tab)){
				
				try {
					schema = engineMonitor.setSchemaCreatorUserNPwd(schema);
					System.out.println("ConnectionTester.java>>>>> Schema Creator username >>"+schema.getSchemaName());
					//System.out.println("ConnectionTester.java>>>>> Schema Creator password >>"+schema.getSchemaPwd());
				} catch (Exception e) {
					logger.error("ConnectionTester.java>>>>Error getting schema creator user and password with schema "
							+ schema.getSchemaName()
							+ " with database id "
							+ schema.getDatabaseId());
					e.printStackTrace();
					connectionTester.setMessage(
							new Object[] { Boolean.FALSE, e.getMessage() },
							request, hostingServer);
					return retVal;
				}
			}
			else{
				try {
					schema = engineMonitor.setSchemaPassword(schema);
				} catch (Exception e) {
					logger.error("ConnectionTester.java>>>Error getting password for schema "
							+ schema.getSchemaName()
							+ " with database id "
							+ schema.getDatabaseId());
					e.printStackTrace();
					connectionTester.setMessage(
							new Object[] { Boolean.FALSE, e.getMessage() },
							request, hostingServer);
					return retVal;
				}

			}
		} else if (hostingServer.equalsIgnoreCase(Constants.VERTICA)
				&& (tab.equalsIgnoreCase(Constants.DATA_TRANSFER)  || tab.equalsIgnoreCase(Constants.SCHEMA_ADMIN))) {
			String runBaModule = webTransfer.getString("runBaModule");
			if(runBaModule.equalsIgnoreCase("TRUE"))
			{
				//for destination oracle
				Schema oracleSchema = connectionTester.getOracleSchema(webTransfer);
				Object[] retTestValForDestOracle = engineMonitor.isValid(oracleSchema);
				connectionTester.setMessage(retTestValForDestOracle, request, Constants.ORACLE);
				
				//for destination vertica
				schema = connectionTester.getVerticaSchema(webTransfer);
				Object[] retTestValForDestVertica = engineMonitor.isValid(schema);
				connectionTester.setMessage(retTestValForDestVertica, request, hostingServer);
			}
			
			else
			{
				//for destination vertica
				schema = connectionTester.getVerticaSchema(webTransfer);
				Object[] retTestValForDestVertica = engineMonitor.isValid(schema);
				connectionTester.setMessage(retTestValForDestVertica, request, hostingServer);
			}
			return retVal;
		} else if (hostingServer.equalsIgnoreCase(Constants.VERTICA)
				&& tab.equalsIgnoreCase(Constants.SERVER_ADMIN)) {
			String verticaHostName = webTransfer.getString("host");
			connectionTester.isHostReachable(engineMonitor, request,
					verticaHostName);
			return retVal;
		} else if (hostingServer.equalsIgnoreCase(Constants.DMEXPRESS)) {
			String dmExpressHostName = webTransfer.getString("host");
			connectionTester.isHostReachable(engineMonitor, request,
					dmExpressHostName);
			return retVal;
		}
		Object[] retTestVal = engineMonitor.isValid(schema);
		connectionTester.setMessage(retTestVal, request, hostingServer);
		return retVal;
	}

	private void isHostReachable(EngineMonitor engineMonitor,
			HttpServletRequest request, String host) throws Exception {
		Object[] retTestVal = engineMonitor.isHostReachable(host);
		if (Boolean.TRUE.equals(retTestVal[0])) {
			ValidatorRoot.getMessageList(request).add("Host is reachable.");
		} else {
			List errors = ValidatorRoot.getErrorList(request);
			errors.add("Host not reachable.");
			errors.add(retTestVal[1]);
		}
	}

	private Schema getOracleSchema(WebTransfer webTransfer) {
		Schema schema = (new Schema())
				.setServerGroupId((webTransfer.getString("serverGroupId") ==null)?"":webTransfer.getString("serverGroupId"))
				.setServerName(webTransfer.getString("host"))
				.setPort(webTransfer.getString("port"))
				.setService(webTransfer.getString("service"))
				.setSchemaName(webTransfer.getString("dbUser"))
				//.setSchemaPwd(webTransfer.getString("dbPassword"))
				.setHostingServer(Constants.ORACLE)
				.setDatabaseId(webTransfer.getString("databaseId"));//getting database id 
		String sidFlag = webTransfer.getString("sidFlag");
		if (sidFlag != null) {
			schema = schema.setSidFlag(webTransfer.getString("sidFlag"));
		}
		return schema;
	}

	private Schema getVerticaSchema(WebTransfer webTransfer) {

		Schema schema = (new Schema())
				.setDatabase(webTransfer.getString("destVerticaDb"))
				.setServerName(webTransfer.getString("destVerticaHost"))
				.setPort(webTransfer.getString("destVerticaPort"))
				.setConnection(webTransfer.getString("destVerticaConnection"))
				.setSchemaName(webTransfer.getString("destVerticaFrontSchema"))
				.setSchemaPwd(webTransfer.getString("destVerticaFrontPassword"))
				.setHostingServer(Constants.VERTICA);

		return schema;
	}
	
	private void setMessage(Object[] retTestVal ,HttpServletRequest request , String hostingServer)
	{
		if (Boolean.TRUE.equals(retTestVal[0])) {
			ValidatorRoot.getMessageList(request)
					.add(hostingServer+": Successfully connected.");
		} else {
			List errors = ValidatorRoot.getErrorList(request);
			errors.add(hostingServer+": Connection failure.");
			errors.add(retTestVal[1]);
		}
	}
}
