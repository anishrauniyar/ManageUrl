package dashboard.web.pagecontroller;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskType;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;

public class SchemaManager extends Controller {

	private static List lsEmpty = Collections
			.unmodifiableList(new java.util.ArrayList(0));
	private static final String SERVER_N_DIR = "SERVER_N_DIR";
	private static final String TEST_DB_CONNECTION = "TEST_DB_CONNECTION";
	private static final String CREATE_SCHEMA = "CREATE_SCHEMA";
	private static final String SP_GRANTNEWUSER = "SP_GRANTNEWUSER";
	private static final String PROCEDURE = "PROCEDURE";

	protected Log logger = LogFactory.getLog(getClass());

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String retVal = "setupSchemaParam";
		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String hostingServer = webTransfer.getString("hostingServer");
		String loginName = webTransfer.getString("session:loginName");
		AsyncSQLProcess sqlProcess = null;

		String action = webTransfer.getString("action");
		EngineMonitor engine = getEngineMonitor(request);

		Boolean isRefreshAgain = Boolean.FALSE;
		List lsServerGroups = lsEmpty;
		List lsServers = lsEmpty;
		List lsDirs = lsEmpty;
		List lsTablespaces = lsEmpty;
		List lsEngineVersions = lsEmpty;
		lsEngineVersions = engine.getEngineVersionList();

		Schema schemaCreator = null;
		EventLogger eventLogger = ComponentFactory.getInstance()
				.getEventLogger();
		String event = TaskType.CREATE_USER.getTaskLabel();
		;
		Date startDate = new Date(System.currentTimeMillis());
		String desc = "";
		String errorMsg = "";

		boolean oracleSchemaExists = false;
		boolean oracleSchemaInfoAlreadyInserted = false;

		if (SERVER_N_DIR.equals(action)) {
			retVal = "serverNDir";
			String serverGroupId = webTransfer.getString("serverGroupId");
			lsServers = engine.getServersForServerGroup(serverGroupId);

			// check hosting Server
			if (hostingServer.equalsIgnoreCase(Constants.ORACLE)) {
				lsDirs = engine.getDataFileDirsForServerGroup(serverGroupId);
				lsTablespaces = engine
						.getTempTablespacesForServerGroup(serverGroupId);
				request.setAttribute("isSingleDir",
						(lsDirs.size() == 1) ? Boolean.TRUE : Boolean.FALSE);
				request.setAttribute("isSingleTablespace", (lsTablespaces
						.size() == 1) ? Boolean.TRUE : Boolean.FALSE);
			}
			request.setAttribute("isSingleServer",
					(lsServers.size() == 1) ? Boolean.TRUE : Boolean.FALSE);
		} else if (CREATE_SCHEMA.equals(action)) {
			retVal = "processOutput";

			if (hostingServer.equalsIgnoreCase(Constants.ORACLE)) {
				String engineVersion = "";

				if (null != webTransfer.getString("frontSchema")
						&& !"".equalsIgnoreCase(webTransfer
								.getString("frontSchema"))) {
					engineVersion = engine
							.getEngineVersionForSchema(webTransfer
									.getString("processingSchema"));
					logger.info("Engine version from OAM : {}" + engineVersion);
				}

				// Override setting for engine version by user
				if (null != webTransfer.getString("overrideEngineVersion")
						&& webTransfer.getString("overrideEngineVersion")
								.equalsIgnoreCase("TRUE")
						&& null != webTransfer.getString("ENG_VERSION")
						&& !"".equals(webTransfer.getString("ENG_VERSION")
								.trim())) {
					engineVersion = webTransfer.getString("ENG_VERSION").trim();
					logger.info("Engine version overriden by user : {}"
							+ engineVersion);
				}

				Schema schema = (new Schema())
						.setServerName(webTransfer.getString("host"))
						.setPort(webTransfer.getString("port"))
						.setService(webTransfer.getString("service"))
						.setSchemaName(
								webTransfer.getString("processingSchema"))
						// .setSchemaPwd(
						// webTransfer.getString("processingPwd"))
						.setDatabaseId(webTransfer.getString("databaseId"))
						.setServerGroupId(
								webTransfer.getString("serverGroupId"))
						.setSidFlag(webTransfer.getString("sidFlag"))
						.setEngineVersion(engineVersion)
						.setSchemaSize(webTransfer.getString("schemaSize"))
						.setHostingServer(Constants.ORACLE);

				try {
					schemaCreator = (schema.getCopy());
					/*
					 * Setting schemacreator_user and schemacreator_pass in
					 * schemaCreator If either
					 * values(schemacreator_user/schemacreator_pass) is null or
					 * blank, default user(utility) and default password(oracle)
					 * is set
					 */
					schemaCreator = engine
							.setSchemaCreatorUserNPwd(schemaCreator);
					// System.out.println("Schema creator user for "+
					// schema.getServerName()+" >>>>>"+schemaCreator.getSchemaName());
					// System.out.println("Schema creator pass for "+
					// schema.getServerName()+">>>>>"+schemaCreator.getSchemaPwd());

					/*
					 * Checking whether given new schema exists or not. Checked
					 * by connecting to schemaCreator schema
					 */
					oracleSchemaExists = engine.oracleSchemaExists(
							schemaCreator, schema.getSchemaName());

					if (oracleSchemaExists) {
						logger.error("Oracle schema " + schema.getSchemaName()
								+ " already exists on server "
								+ schema.getServerName());

						desc = "Create User: ["
								+ engine.getServerGroup(
										schema.getServerGroupId())
										.getGroupName() + "] "
								+ schema.getServerName() + ":"
								+ schema.getPort();

						errorMsg = "Schema " + schema.getSchemaName()
								+ " already exists on server "
								+ schema.getServerName();

						eventLogger.logError(loginName, event, desc, 0,
								startDate,
								new Date(System.currentTimeMillis()), errorMsg,
								schema);

						request.setAttribute("serverOutput", errorMsg);
						return retVal;
					} else {
						/*
						 * PASSWORD LESS DESIGN
						 */
						// first check whether the same schema (HF) with same
						// dbid exists in platform_schema_info table
						// if exists then use the default password for creating
						// the schema
						oracleSchemaInfoAlreadyInserted = engine
								.isSchemaInfoAlreadyInserted(schema);
						System.out
								.println("Schema info already inserted for schema "
										+ schema.getSchemaName()
										+ " >>>>>>>>>>>"
										+ oracleSchemaInfoAlreadyInserted);
						if (!oracleSchemaInfoAlreadyInserted) {
							logger.info("Schema Info not inserted for schema "
									+ schema.getSchemaName()
									+ " with database id "
									+ schema.getDatabaseId());
							logger.info("Generate/Insert password for schema "
									+ schema.getSchemaName()
									+ " with database id "
									+ schema.getDatabaseId());
							// generating password
							schema = engine.generateSchemaPassword(schema);
							// inserting schema details
							// Only HF schema is created, and password generated
							// by engine.generateSchemaPassword will not be
							// used,
							// as method below will insert default password
							// "oracle" for all HF schemas
							engine.insertSchemaInfo(schema);
						} else {
							logger.info("Schema Info is already inserted for schema "
									+ schema.getSchemaName()
									+ " with database id "
									+ schema.getDatabaseId());
							// logger.info("Using default password oracle for  "+schema.getSchemaName()+" with database id "+schema.getDatabaseId());
							// schema.setSchemaPwd(Constants.DEFAULT_SCHEMA_PWD);
							logger.info("Getting inserted password for schema "
									+ schema.getSchemaName());
							schema = engine.setSchemaPassword(schema);
							engine.insertNotInSchemaInfo(schema);
						}
					}
				} catch (Exception e) {
					logger.error("SchemaManager.java >>>Error!!!!!");
					// inserting exception caught to logger.
					InsertExceptionToLogger.insert(e, logger);
					errorMsg = e.getMessage();
					errorList.add(errorMsg);
					// logging error
					desc = "Create User: ["
							+ engine.getServerGroup(schema.getServerGroupId())
									.getGroupName() + "] "
							+ schema.getServerName() + ":" + schema.getPort();

					eventLogger.logError(loginName, event, desc, 0, startDate,
							new Date(System.currentTimeMillis()), errorMsg,
							schema);
					return retVal;
				}

				String dataFileDir = "";
				String tempTableSpace = "";
				String schemaCreationMode = "";
				boolean SP_GrantNewUserScriptExists = false;
				String schemaType = webTransfer.getString("schemaType");
				if (schemaType.equals("HF") || schemaType.equals("WH")) {
					dataFileDir = webTransfer.getString("dataFileDir");
					tempTableSpace = webTransfer.getString("tempTablespace");
					schemaCreationMode = webTransfer.getString("schemaMode");
					System.out.println("schemaMode:" + schemaCreationMode);
				}else if(schemaType.equals(Constants.VC) || schemaType.equals(Constants.HP)){
					/* Checking if SP_GRANTNEWUSER exists or not.
					 * If exists then  SP_GRANTNEWUSER will be added in VC schema creation. 
					 */
					try {
						SP_GrantNewUserScriptExists = engine.dbaObjExists(
								schemaCreator, SP_GRANTNEWUSER, PROCEDURE);
						System.out.println("SP_GrantNewUserScriptExists for VC Schema Creation : "+SP_GrantNewUserScriptExists);
					} catch (Exception e) {
						SP_GrantNewUserScriptExists = false;
					}
				}

				String histFlag = webTransfer.getString("isHist");
				/*
				 * String runnerUserName = webTransfer.getString("dbUser");
				 * String runnerPassword = webTransfer.getString("dbPassword");
				 */
				String runnerUserName = schemaCreator.getSchemaName();
				String runnerPassword = schemaCreator.getSchemaPwd();

				logger.info(" process schema:" + schema.getSchemaName()
						+ " pwd: " + schema.getSchemaPwd());
				logger.info(" by: " + runnerUserName + "/" + runnerPassword);

				boolean isHistSchema = histFlag != null
						&& "Y".equals(histFlag.trim());

				sqlProcess = engine.createSchema(schema, runnerUserName,
						runnerPassword, dataFileDir, tempTableSpace,
						isHistSchema, schemaCreationMode, schemaType,SP_GrantNewUserScriptExists);
			}
			// NOT CALLED [MIGHT BE USEFUL IN FUTURE]
			else if (hostingServer.equalsIgnoreCase(Constants.VERTICA)) {
				// get Correct params for vertica schema
				Schema verticaSchema = (new Schema())
						.setServerName(webTransfer.getString("host"))
						.setPort(webTransfer.getString("port"))
						.setDatabase(webTransfer.getString("database"))
						.setConnection(webTransfer.getString("connection"))
						.setServerGroupId(
								webTransfer.getString("serverGroupId"))
						.setSchemaName(webTransfer.getString("newSchemaName"))
						.setHostingServer(Constants.VERTICA);

				String databaseName = webTransfer.getString("databaseName");
				String adminUserName = webTransfer.getString("adminName");
				String adminPass = webTransfer.getString("adminPass");
				String newSchemaName = webTransfer.getString("newSchemaName");
				String newUserName = webTransfer.getString("newUserName");
				String newUserPassword = webTransfer
						.getString("newUserPassword");

				sqlProcess = engine.createVerticaSchema(verticaSchema,
						databaseName, adminUserName, adminPass, newSchemaName,
						newUserName, newUserPassword);
			}

			SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
			isRefreshAgain = Boolean.TRUE;

			TaskType taskType = sqlRunnable.getTaskType();
			messageList.add(sqlRunnable.getDescription());

			if (TaskType.CREATE_USER.equals(taskType)) {
				messageList.add("Currently queued: " + taskType.toString());
			} else {
				errorList.add("Schema is being used.");
				errorList.add("Operation requested is not queued.");
				isRefreshAgain = Boolean.FALSE;
			}
		} else {
			// showing server list according to hostingserver
			lsServerGroups = engine.getServerGroupList(hostingServer);
		}

		request.setAttribute("lsServerGroups", lsServerGroups);
		request.setAttribute("lsServers", lsServers);
		request.setAttribute("lsDirs", lsDirs);
		request.setAttribute("lsTablespaces", lsTablespaces);
		request.setAttribute("isRefreshAgain", isRefreshAgain);
		request.setAttribute("lsEngineVersions", lsEngineVersions);
		request.setAttribute("hostingServer", hostingServer);

		return retVal;
	}
}
