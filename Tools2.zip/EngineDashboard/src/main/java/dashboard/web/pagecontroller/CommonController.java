package dashboard.web.pagecontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;

public class CommonController extends Controller {

	private static final String LOAD_PAGE = "LOAD_PAGE";
	private static final String UPDATE_SERVER_LIST = "UPDATE_SERVER_LIST";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String action = webTransfer.getString("action");
		EngineMonitor engine = getEngineMonitor(request);

		List lsServerGroups = null;
		List lsServers = null;
		List lsEngineVersions = null;

		String serverGroupId = webTransfer.getString("serverGroupId");
		serverGroupId = (serverGroupId == null) ? "" : serverGroupId.trim();
		String page = webTransfer.getString("page");// pageToReturn
		if (action.equals(LOAD_PAGE)) {
			lsEngineVersions = engine.getEngineVersionList();
			lsServerGroups = engine.getServerGroupListForProcessing();
		} else if (action.equals(UPDATE_SERVER_LIST)) {
			lsServers = engine.getServersForServerGroup(serverGroupId);
		}
		request.setAttribute("lsEngineVersions", lsEngineVersions);
		request.setAttribute("lsServerGroups", lsServerGroups);
		request.setAttribute("lsServers", lsServers);
		return page;
	}

}
