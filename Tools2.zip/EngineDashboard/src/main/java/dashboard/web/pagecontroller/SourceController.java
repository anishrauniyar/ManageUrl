package dashboard.web.pagecontroller;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Report;
import dashboard.data.SourceControlUser;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.util.ClientSpecficModuleConstants;
import dashboard.util.Constants;
import dashboard.util.EnvInfo;


public class SourceController extends Controller {

    private static final String ACTION = "vc_action";
    private static final String CHECKOUT = "CHECKOUT";
    private static final String LIST_URL = "LIST_URL";
    private static final String MOD_NAME = "MOD_NAME";

    private static final String VC_LOGIN_NAME = "VC_LOGIN_NAME";
    private static final String VC_PASSWORD = "VC_PASSWORD";
    private static final String VC_URL = "VC_URL";

    private static final String ENGINE_MODULES = "Engine Modules";
    private static final String OBJECT_SCRIPTS = "Object Scripts";
    private static final String PRE_SCRUB_OBJECT_SCRIPTS = "Pre Scrub Object Scripts";
    private static final String WH_SCRIPTS = "WareHouse Scripts";
    private static final String HP_MODULES = "HP Modules";
    private static final String VC_MODULES = "VC Modules";
    

    private static Log logger = LogFactory.getLog(SourceController.class);
    
    private EnvInfo envInfo = null;

    public void setEnvInfo(EnvInfo e) {
        envInfo = e;
    }
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "versionControl";

        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        
        String action = webTransfer.getString(ACTION);
        
        EngineMonitor engine = getEngineMonitor(request);
        EventLogger eventLogger = ComponentFactory.getInstance().getEventLogger();
        String error = "";

        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        
        SourceControlUser scUser =
            ( new SourceControlUser())
            .setUserName( webTransfer.getString( VC_LOGIN_NAME))
            .setPassword( webTransfer.getString( VC_PASSWORD));

        String vcUrl = webTransfer.getString( VC_URL);
        String modName = webTransfer.getString( MOD_NAME);
        
        String engVersion = webTransfer.getString("ENG_VERSION");
        
        List lsEngineVersions = engine.getEngineVersionList();
        request.setAttribute("lsEngineVersions", lsEngineVersions);
        
        
        String output = "";

        Report engineModule =
            (new Report())
            .setReportName( ENGINE_MODULES)
            .setReportDesc("Engine Module. Location is configured in the application.")
            .setSourceDir( envInfo.getENGINE_DIR().getAbsolutePath());
        
        request.setAttribute("engineModule", engineModule);
        
        Report objectScript =
            (new Report()).setReportName( OBJECT_SCRIPTS)
            .setReportDesc("Object Scripts. Location is configured in the application.")
            .setSourceDir( envInfo.getObjectScriptDir().getAbsolutePath());
        request.setAttribute("objectScript", objectScript);        
        
        Report preScrubObjectScript =
            (new Report()).setReportName( PRE_SCRUB_OBJECT_SCRIPTS)
            .setReportDesc("PreScrub Object Scripts. Location is configured in the application.")
            .setSourceDir( envInfo.getScrubObjectScriptDir().getAbsolutePath());
        request.setAttribute("preScrubObjectScript", preScrubObjectScript);
        
        Report wareHouseScript =
                (new Report()).setReportName( WH_SCRIPTS)
                .setReportDesc("WareHouse Scripts. Location is configured in the application.")
                .setSourceDir( envInfo.getWH_SCRIPTS_DIR().getAbsolutePath());
            request.setAttribute("wareHouseScript", wareHouseScript);
            
		/**
		 * JIRA : VITTOOLS-384
		 */
		Report HPModules = new Report()
				.setReportName(HP_MODULES)
				.setReportDesc(
						"HP Modules. Location is configured in the application")
				.setSourceDir(envInfo.getHP_MODULES_DIR().getAbsolutePath());
		request.setAttribute("HPModules", HPModules);
		Report VCModules = new Report()
				.setReportName(VC_MODULES)
				.setReportDesc(
						"VC Modules. Location is configured in the application")
				.setSourceDir(envInfo.getVC_MODULES_DIR().getAbsolutePath());
		request.setAttribute("VCModules", VCModules);
		Report HPandVCClientSpecificModules = new Report()
				.setReportName(ClientSpecficModuleConstants.HP_VC_CLIENT_SPECIFIC_MODULES)
				.setReportDesc(
						"HP and VC Client Specific Modules. Location is configured in the application")
				.setSourceDir(
						envInfo.getHP_VC_CLIENT_SPECIFIC_MODULES_DIR()
								.getAbsolutePath());
		request.setAttribute("HPandVCClientSpecificModules",
				HPandVCClientSpecificModules);

        if ( LIST_URL.equals(action) || CHECKOUT.equals(action) ) {
        	retVal = "versionControlOutput";

            if (scUser.isAllParamSet()) {
                if (LIST_URL.equals(action)) {
                    if ( null != vcUrl && !"".equals(vcUrl.trim())) {
                        output = engine.listDirectory( scUser, vcUrl.trim());
                        logger.info("cmd out: " + output);
                        if ("".equals(output)) {
                            messageList.add("No output returned.");
                        }
                    } else {
                        errorList.add("Missing source control url.");
                        retVal = "messageList";
                    }
                }
                else if( CHECKOUT.equals(action)) {
                	if (null != vcUrl && !"".equals(vcUrl)) {
                        String listing = engine.listDirectory( scUser, vcUrl.trim());
                        if (null == listing || "".equals( listing.trim())) {
                            output = "Version control did not return anything. Make sure you can login and see the listing.";
                        } else {
                        	String event = Constants.VERSION_CONTROL_EVENT;
                            if ( engineModule.getReportName().equals( modName)) {
                            	output = checkOut(scUser, vcUrl, engineModule, engVersion, eventLogger, engine, loginName,event);
                               // output = engine.checkOut(scUser, vcUrl, engineModule.getSourceDir()+"/"+engVersion);
                            }
                            else if ( objectScript.getReportName().equals( modName)) {    
                            	output = checkOut(scUser, vcUrl, objectScript, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, objectScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( preScrubObjectScript.getReportName().equals( modName)) {
                            	output = checkOut(scUser, vcUrl, preScrubObjectScript, engVersion, eventLogger, engine, loginName,event);
                            	//output = engine.checkOut(scUser, vcUrl, preScrubObjectScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( wareHouseScript.getReportName().equals( modName)) {
                            	output = checkOut(scUser, vcUrl, wareHouseScript, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( HPModules.getReportName().equals( modName)) {
                            	output = checkOut(scUser, vcUrl, HPModules, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( VCModules.getReportName().equals( modName)) {
                            	output = checkOut(scUser, vcUrl, VCModules, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }
                            else if ( HPandVCClientSpecificModules.getReportName().equals( modName)) {
                            	output = checkOut(scUser, vcUrl, HPandVCClientSpecificModules, engVersion, eventLogger, engine, loginName,event);
                                //output = engine.checkOut(scUser, vcUrl, wareHouseScript.getSourceDir()+"/"+engVersion);
                            }

                            else {
                                Report rpt = engine.getReportByName( modName);
                                if (null != rpt) {
                                	output = checkOut(scUser, vcUrl, rpt, engVersion, eventLogger, engine, loginName,event);
                                    //output = engine.checkOut(scUser, vcUrl, rpt.getSourceDir()+"/"+engVersion);
                                } else {
                                    error = "Module specified is not the registered one.";
                                	errorList.add(error);
                                    eventLogger.logError(loginName, Constants.VERSION_CONTROL_EVENT, "Version Control", 0, new Date(System.currentTimeMillis()),
                        					new Date(System.currentTimeMillis()),error, null);
                                }
                            }
                        }
                    } else {
                    	error = "Missing source control url.";
                        errorList.add(error);
                        retVal = "messageList";
                    }
                }
                if (null != output && "".equals(output.trim()) ) {
                    messageList.add("No output from version control client.");
                }

            } else {
                errorList.add("Both username and password for version control system required.");
                retVal = "messageList";                    
            }
        } else {
            List ls = engine.listReportModules();
            request.setAttribute("ls", ls);
        }
        request.setAttribute("vcOutput", output);

        return retVal;
    }
    
	/**
	 * Possible event log errors
	 */
    private static final String AUTH_FAIL_ERROR = ".*(?i)AUTHORIZATION FAILED.*";
	private static final Pattern PAT_AUTH_FAIL_ERROR = Pattern.compile(AUTH_FAIL_ERROR,Pattern.MULTILINE);
	
	private static final String ALREADY_WORKING_COPY_ERROR = ".*(?i)is already a working copy for a different URL*";
	private static final Pattern PAT_ALREADY_WORKING_COPY_ERROR = Pattern.compile(ALREADY_WORKING_COPY_ERROR,Pattern.MULTILINE);
	
	public static void main(String[] args) {
		String input = "svn: OPTIONS of 'https://svn.d2hawkeye.net/svn/d2svn/VHProducts/SMI/MI/Branches/BackEnd/6.6.0/Engine': authorization failed (https://svn.d2hawkeye.net)";
		System.out.println(CommonMethods.checkPattern(input, PAT_AUTH_FAIL_ERROR));
	}
    
    /**
     * @Description: Checkout method
     * @param scUser
     * @param vcUrl
     * @param report
     * @param engVersion
     * @param eventLogger
     * @param engine
     * @param loginName
     * @return
     */
    public static String checkOut(SourceControlUser scUser, String vcUrl,
			Report report, String engVersion, EventLogger eventLogger,
			EngineMonitor engine, String loginName,String event) {
		String desc = "Version Control of " + report.getReportName()+" from "+vcUrl
				+ " on directory " + report.getSourceDir()+ "/" + engVersion;
		Date startDate = new Date(System.currentTimeMillis());
		String output = "";

		// start event logger
		eventLogger.logStart(loginName, event, desc, 0, startDate, null,
				(long) 0);
		logger.info("STARTED "+desc+" by: "+loginName);
		try {
			output = engine.checkOut(scUser, vcUrl, report.getSourceDir() + "/"
					+ engVersion);
			// Authorization failed case
			if(CommonMethods.checkPattern(output, PAT_AUTH_FAIL_ERROR)){
				eventLogger.logError(loginName, event, desc, 0, startDate,
						new Date(System.currentTimeMillis()),"Authentication Failure", null);
				logger.error("ERROR [AUTHENTICATION FAILURE] "+desc+" by: "+loginName);
				return output;
			}
			// Already a working copy for a different URL case
			if(CommonMethods.checkPattern(output, PAT_ALREADY_WORKING_COPY_ERROR)){
				eventLogger.logError(loginName, event, desc, 0, startDate,
						new Date(System.currentTimeMillis()),"svn:'"+vcUrl+"' is already a working copy for a different URL", null);
				logger.error("ERROR [ALREADY_WORKING_COPY_ERROR] "+desc+" by: "+loginName);
				return output;
			}
		} catch (Exception e) {
			logger.error("ERROR "+desc+" by: "+loginName,e);
			eventLogger.logError(loginName, event, desc, 0, startDate,
					new Date(System.currentTimeMillis()), e, null);
			
			return output;
		}
		eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(
				System.currentTimeMillis()), 0, null);
		logger.info("COMPLETED "+desc+" by: "+loginName);
		return output;
	}

}

