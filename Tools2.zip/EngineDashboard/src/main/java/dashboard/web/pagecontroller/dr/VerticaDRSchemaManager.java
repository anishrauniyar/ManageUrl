package dashboard.web.pagecontroller.dr;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.engine.oracle.NamingUtil;
import dashboard.engine.oracle.OracleUserCreator;
import dashboard.engine.vertica.BaseVerticaManager;
import dashboard.engine.vertica.VerticaTransferValidation;
import dashboard.util.CmdRunner;
import dashboard.util.Constants;
import dashboard.util.FileUtil;
import dashboard.util.InsertExceptionToLogger;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;
import dashboard.web.pagecontroller.VerticaPRODSchemaManager;
import dashboard.web.util.CustomException;

/**
 * NOTE:1. VERTICA DR SCHEMA CREATION TO BE REPLACED BY
 * VERTICASCHEMAMANAGER.JAVA
 */
public class VerticaDRSchemaManager extends Controller {

    public static final String READ_ONLY = "READ ONLY";

    @Override
    public String process(HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        EngineMonitor engineMonitor = getEngineMonitor(request);
        EventLogger eventLogger = ComponentFactory.getInstance().getEventLogger();
        String retVal = "processOutput";
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        boolean schemaExists = false;
        boolean error = false;
        boolean verticaDbError = false;
        boolean verticaSchemaExists = false;
        boolean verticaSchemaInfoAlreadyInserted = false;

        String errorMsg = "";
        String verticaSchemaCreationOutput = "";
        String verticaSchemaExistsError = "";

        Schema srcSchema = getOracleSrcSchema(webTransfer, engineMonitor);

        String engineVersion = engineMonitor.getEngineVersion(srcSchema);
        srcSchema.setEngineVersion(engineVersion);

        String hostingServer = ((webTransfer.getString("hostingServer") == null) || (webTransfer.getString("hostingServer") == ""))
                ? Constants.VERTICA_DR_CMA : webTransfer.getString("hostingServer");

        // Getting Vertica DR Schema
        destVtkaSchema = getDestVerticaDRSchema(webTransfer, engineMonitor);
        destVtkaSchema.setEngineVersion(engineVersion);//added engine version

        /**
         * VITTOOLS-383 : BA module not in use , so runBaModule is set to false
         * by default
         */
        //runBAModule = (webTransfer.getString("runOracleDRBaModule") ==null)?"":webTransfer.getString("runOracleDRBaModule");
        runBAModule = Constants.FALSE;
        /**
         * VITTOOLS-383 : BA module no longer in use
         */
        //get destination oracle server for ba module transfer
        /*if(runBAModule.equalsIgnoreCase("TRUE")){
			System.out.println("Oracle DR BA module is checked!!!!!");
			destOrclSchema = getDestOracleDRSchema(webTransfer, engineMonitor);
			engineMonitor.setServerGroupName(destOrclSchema);
		}*/

        String event = "Create Schema(Vertica DR)";
        String desc = "Create Vertica DR User: " + destVtkaSchema.getServerGroupName() + " "
                + destVtkaSchema.getServerName() + ":" + destVtkaSchema.getPort() + "/" + destVtkaSchema.getDatabase() + "/" + destVtkaSchema.getSchemaName();
        Date startDate = new Date(System.currentTimeMillis());

        FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();

        BaseVerticaManager validations = null;
        try {
            validations = (new VerticaTransferValidation()).setEngineMonitor(engineMonitor)
                    .setHostingServer(hostingServer)
                    .setOrclSchema(srcSchema)
                    .setVtkaSchema(destVtkaSchema);
            validations.init();
        } catch (Exception e) {
            logger.error("VerticaDRSchemaManager.java>> Error while O2V Data Transfer with sub task " + desc + validations.getSubDesc());
            StringWriter sw = InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
            // show error in event log
            ComponentFactory.getInstance().getEventLogger().logError(
                    loginName, event, desc + validations.getSubDesc(), 0, startDate, new Date(), sw.toString(), destVtkaSchema);
            //showing error in UI
            errorList.add(e.getMessage());
            // setting error
            error = true;
            request.setAttribute("O2VStatus", validations.getO2VStatus());
            request.setAttribute("error", error);
            return retVal;
        }

        /*
		 * Creating vertica dr schema == > To Be replaced by vertica schema manager
         */
        //event log
        eventLogger.logStart(loginName, event, desc, 0, startDate, destVtkaSchema, (long) 0);

        /**
         *
         * CHECKING WHETHER VERTICA DR SHEMA EXISTS OR NOT
         *
         * *
         */
        String adminUserName = fixedParam.getValue(Constants.VS_ADMINNAME, hostingServer);
        String adminPass = fixedParam.getValue(Constants.VS_ADMINPWD, hostingServer);
        Schema verticaUtilSchema = new Schema()
                .setServerGroupId(webTransfer.getString("destVerticaDRServerGroupId"))
                .setServerName(webTransfer.getString("destVerticaDRHost"))
                .setPort(webTransfer.getString("destVerticaDRPort"))
                .setService(webTransfer.getString("destVerticaDRConnection"))
                .setConnection(webTransfer.getString("destVerticaDRConnection"))
                .setDatabase(webTransfer.getString("destVerticaDRDatabase"))
                .setSchemaName(adminUserName)//admin schema name
                .setSchemaPwd(adminPass)//admin schema password
                .setHostingServer(Constants.VERTICA);

        try {
            /*
             * PASSWORD LESS DESIGN
             */
            try {
                setPwdForSchema(request);
            } catch (Exception e) {
                logger.error("VerticaDRSchemaManager.java>> Error!!!");
                StringWriter sw = InsertExceptionToLogger.insert(e, logger); // inserting exception caught to logger.
                // show error in event log
                ComponentFactory.getInstance().getEventLogger()
                        .logError(loginName, event, desc, 0, startDate, new Date(), sw.toString(), destVtkaSchema);
                // showing error in UI
                errorList.add(e.getMessage());
                // setting error
                error = true;
                request.setAttribute("error", error);
                return retVal;
            }

            verticaSchemaExists = engineMonitor.verticaSchemaExists(verticaUtilSchema, destVtkaSchema.getSchemaName());
            if (verticaSchemaExists) {
                schemaExists = true;
                if (!vtkaSchemaInfoInserted) {
                    /**
                     * @Description: Case where vertica schema physically exists
                     * but there was not entry in platform_schema_info table.
                     * Steps : 1. Delete the inserted password for this schema
                     * [update isdeleted flag to Y] 2. AND halt the transfer.
                     *
                     *
                     */
                    logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                            + " but pwd entry was not found in platform_schema_info");
                    //int count = engineMonitor.deletePwdEntry(destVtkaSchema);
                    //logger.info("Total Number of Password entry deleted for "+destVtkaSchema.getServerGroupName()+"/"+destVtkaSchema.getSchemaName()+": "+count);
                    CustomException.assertError("Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                            + " but its password was not found in processing.platform_schema_info table. "
                            + "Please drop the schema and re-initiate the transfer.");
                } else {
                    /**
                     * @Description: Case where vertica schema physically exists
                     * and there was also the entry for this schema in
                     * platform_schema_info table. Steps: 1. Test the schema
                     * using the fetched pwd 2. If connection failed, halt the
                     * transfer 3. Else continue the transfer 
                     * *
                     */
                    Object[] jbdcResult = engineMonitor.isValid(destVtkaSchema);
                    boolean conn = (Boolean) jbdcResult[0];
                    if (!conn) {
                        logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                                + " but jdbc connection was failed");
                        /*int count = engineMonitor.updateIsDeletedFlag(destVtkaSchema,"Y");*/
                        CustomException.assertError("Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName()
                                + " but jdbc connection failed ");
                    } else {
                        verticaSchemaCreationOutput = "Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName();
                        errorMsg = "Schema " + destVtkaSchema.getSchemaName() + " already exists in " + destVtkaSchema.getServerName();
                        eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVtkaSchema);
                        logger.info("Vertica Schema " + destVtkaSchema.getSchemaName() + " already exists on " + destVtkaSchema.getServerName());
                    }
                }
                /*schemaExists = true;
				verticaSchemaCreationOutput = "Vertica DR Schema "+destVtkaSchema.getSchemaName()+" already exists on "+destVtkaSchema.getServerName();
				errorMsg = "Vertica DR Schema "+destVtkaSchema.getSchemaName()+" already exists in "+destVtkaSchema.getServerName();
	   	 		eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVtkaSchema);
	   	 		logger.info("Vertica DR Schema "+destVtkaSchema.getSchemaName()+" already exists on "+destVtkaSchema.getServerName());*/
            } else {
                String databaseName = destVtkaSchema.getDatabase();// getting database from UI
                String user = fixedParam.getValue(Constants.VS_USERNAME, hostingServer);
                String commandLocation = fixedParam.getValue(Constants.VS_SHFILELOCATION, hostingServer);
                String commandName = fixedParam.getValue(Constants.VS_SHFILENAME, hostingServer);
                String password = fixedParam.getValue(Constants.VS_PASSWORD, hostingServer);
                String privateKey = fixedParam.getValue(Constants.PRIVATE_KEY, hostingServer);

                String params = databaseName + " "
                        + adminUserName + " "
                        + adminPass + " "
                        + destVtkaSchema.getSchemaName() + " "
                        + destVtkaSchema.getSchemaName() + " "
                        + destVtkaSchema.getSchemaPwd();

                String cdCommand = "cd " + commandLocation;
                String shCommand = "sh " + commandName + " " + params;

                List<String> commands = new ArrayList<String>();
                commands.add(cdCommand);
                commands.add(shCommand);

                logger.info("Command executed for vertica DR schema creation " + cdCommand + " " + shCommand);

                verticaSchemaCreationOutput = CmdRunner.runCommandsOnShell(false, destVtkaSchema.getServerName(), user, password, commands, privateKey);

                Object[] checkVerticaDbError = getError(verticaSchemaCreationOutput, PAT_VERTICA_DB_ERROR);
                if (Boolean.TRUE.equals(checkVerticaDbError[0])) {
                    verticaDbError = true;
                    errorMsg = (String) checkVerticaDbError[1];
                    logger.error("Vertica DR Schema " + destVtkaSchema.getSchemaName() + " cannot be created on " + destVtkaSchema.getServerName() + ": " + errorMsg);
                    eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVtkaSchema);
                } else {
                    eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVtkaSchema);
                    logger.info("Vertica DR Schema " + destVtkaSchema.getSchemaName() + " successfully created on " + destVtkaSchema.getServerName());
                }
            }
        } catch (Exception e) {
            logger.error("Error in VerticaDRSchemaManager with vertica DR schema " + destVtkaSchema.getSchemaName() + " on server " + destVtkaSchema.getServerName() + ": " + e.toString());
            InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
            verticaSchemaExistsError = e.toString();
            error = true;
            verticaSchemaCreationOutput = verticaSchemaExistsError;
            eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), verticaSchemaCreationOutput, destVtkaSchema);
            /*
             * Delete the inserted password if any error occurs while creating schema
             */
            int count = engineMonitor.deletePwdEntry(destVtkaSchema);
            logger.info("CATCHED EXECEPTION while creating schema:Total Number of Password entry deleted for " + destVtkaSchema.getServerGroupName() + "/" + destVtkaSchema.getSchemaName() + ": " + count);
        }
        /*
   	 	 * TO HIDE PASSWORD
   	 	 * */
        OracleUserCreator oracleUserCreator = new OracleUserCreator();
        oracleUserCreator.setRunnerPassword(destVtkaSchema.getSchemaPwd());
        verticaSchemaCreationOutput = oracleUserCreator.hidePasswordsForVertica(verticaSchemaCreationOutput, hostingServer);

        /*writing schema creation shell script output to a file*/
        FileUtil.writeToTextFile(verticaSchemaCreationOutput, new NamingUtil().getCreateUserFile(destVtkaSchema));

        request.setAttribute("serverOutput", verticaSchemaCreationOutput);
        request.setAttribute("error", error);
        request.setAttribute("processDescription", "Vertica DR Schema Creation");
        request.setAttribute("schemaExists", schemaExists);
        request.setAttribute("verticaDbError", verticaDbError);

        /*
   	 	 * For Auto DR Transfer
         */
        request.setAttribute("autoDRTransfer", request.getAttribute("autoDRTransfer"));

        return retVal;
    }

    //vsql: FATAL 2983: and vsql: FATAL 3781:
    private static final String VERTICA_DB_ERROR = "FATAL.*";
    public static final Pattern PAT_VERTICA_DB_ERROR = Pattern.compile(VERTICA_DB_ERROR, Pattern.MULTILINE);

    public static Object[] getError(String input, Pattern pattern) {
        Object[] ret = new Object[]{Boolean.FALSE, ""};
        if (null == input) {
            return ret;
        }

        StringBuffer sb = new StringBuffer();
        Matcher m = pattern.matcher(input);
        while (m.find()) {
            ret[0] = Boolean.TRUE;
            sb.append(m.group()).append("\n");
        }
        ret[1] = sb.toString();
        return ret;
    }

    public static void main(String args[]) {
        String test2 = "fjkdsahfdsa dsfas \t djafashf fatal     :23232 this is dsafsdafkdsa";
        System.out.println(test2);

        VerticaPRODSchemaManager vs = new VerticaPRODSchemaManager();

        Object[] testing2 = vs.getError(test2, PAT_VERTICA_DB_ERROR);
        System.out.println(testing2[0]);
    }

}
