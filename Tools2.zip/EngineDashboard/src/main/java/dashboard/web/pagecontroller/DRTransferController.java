package dashboard.web.pagecontroller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dashboard.ComponentFactory;
import dashboard.data.RunningStatus;
import dashboard.data.WebTransfer;
import dashboard.engine.EventLogger;
import dashboard.engine.TaskType;
import dashboard.util.EDBUtil;

public class DRTransferController extends Controller {

	private static List lsEmpty = Collections
			.unmodifiableList(new java.util.ArrayList(0));

	private static final String LIST_RUNNING_DRTRANSFER = "LIST_RUNNING_DRTRANSFER";
	private static final String KILL_DRTRANSFER = "KILL_DRTRANSFER";
	private static final String SHOW_DR_TRANSFER_STATUS = "SHOW_DR_TRANSFER_STATUS";
	private static final String ASM = "ASM";
	private static final RunningStatus RUNNING_STATUS = new RunningStatus();
	private static final String DATE_PATTERN1 = "yyyy-MM-d h:m:s";
	private static final String DATE_PATTERN2 = "MMM d, yyyy HH:mm a, zzzz";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		Locale locale = request.getLocale();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat(DATE_PATTERN1,
				locale);
		SimpleDateFormat dateFormat2 = new SimpleDateFormat(DATE_PATTERN2,
				locale);

		String loginName = webTransfer.getString("session:loginName");
		String action = webTransfer.getString("action");

		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);

		String retVal = "drTransferStatus";
		String processOutput = "processOutput";
		String exec_no = ""; //this is the current job id for dr transfer
		String refJobId = "";
		String dataTransferProcess = "";
		String moduleOrObject = "";
		String processName = "";
		String owner = "";
		String startDate = "";
		String eventDesc = "";
		Boolean isRefreshAgain = Boolean.FALSE;
		RunningStatus runningStatus = RUNNING_STATUS;
		List statusList = lsEmpty;
		Date date = null;
		String startedAt = "";
		
		HttpSession session = request.getSession(false);
		boolean isProcessAdmin = Boolean.TRUE.equals( session.getAttribute("isProcessAdmin"));
		request.setAttribute("isProcessAdmin", isProcessAdmin);

		if (LIST_RUNNING_DRTRANSFER.equals(action)) {
			request.setAttribute("taskKeys", ComponentFactory.getInstance()
					.getDRTransferDB().getRunningDRTransfer());
			request.setAttribute("loginName", loginName);
		} else if (KILL_DRTRANSFER.equals(action)) {
			refJobId = (webTransfer.getString("refJobId") == null) ? ""
					: webTransfer.getString("refJobId");
			String frontSchema = (webTransfer.getString("frontSchema") == null) ? ""
					: webTransfer.getString("frontSchema");
			startDate = (webTransfer.getString("startDate") == null) ? ""
					: webTransfer.getString("startDate");

			int count = 0;
			if (!refJobId.equals("") && !refJobId.equals("0")) {
				count = ComponentFactory.getInstance().getDRTransferDB()
						.killDRTransfer(Long.valueOf(refJobId));

				if (count > 0) {
					messageList.add("Dr Transfer for schema " + frontSchema
							+ " killed successfully !!");
					messageList.add("Process Killed by :" + loginName);

					// logging in event log
					EventLogger eventLogger = ComponentFactory.getInstance()
							.getEventLogger();
					Date endDate = new Date(System.currentTimeMillis());
					eventLogger.logErrorForDrTransfer(endDate,
							"Kill operation initiated by: " + loginName,
							refJobId);

				} else {
					errorList.add("DR Transfer for schema " + frontSchema
							+ " could not be killed !!");
				}

			} else {
				errorList.add("DR Transfer for schema " + frontSchema
						+ " could not be killed !!");
			}
		} else if (SHOW_DR_TRANSFER_STATUS.equals(action)) {
			refJobId = (webTransfer.getString("refJobId") == null) ? ""
					: webTransfer.getString("refJobId");
			
			exec_no = (webTransfer.getString("executionNumber") == null) ? ""
					: webTransfer.getString("executionNumber");

			boolean isRunning = false;
			if (!refJobId.equals("") && !refJobId.equals("0")) {
				// checking whether ASM Data Transfer is ongoing for given
				// exec_no
				isRunning = ComponentFactory.getInstance().getDRTransferDB()
						.isDRTransferOngoing(Long.valueOf(refJobId));

				if (isRunning) {
					isRefreshAgain = Boolean.TRUE;
					// get status list for ASM Data Transfer
					statusList = ComponentFactory.getInstance()
							.getEngineMonitorForSystem()
							.getDataTransferStatusList(exec_no);
					request.setAttribute("statusList", statusList);

					// getting running status for ASM Data Transfer
					runningStatus = ComponentFactory.getInstance()
							.getEngineMonitorForSystem()
							.getRunningStatusDataTransfer(exec_no);
					runningStatus.setUniqueJobId(exec_no);
					request.setAttribute("runningStatus", runningStatus);

					// setting details for ASM Data transfer
					startDate = (webTransfer.getString("startdate") == null) ? ""
							: webTransfer.getString("startdate");
					//System.out.println("StartDate>>>>>>>>>>>>>>>>" + startDate);
					try {
						date = dateFormat1.parse(startDate);
						startedAt = dateFormat2.format(date);
					} catch (ParseException e) {
						startedAt = e.getMessage();
						logger.error("Could not parse date " + startDate
								+ " to" + dateFormat1.toPattern());
						e.printStackTrace();
					}
//					System.out.println("Date>>>>>>>>>>>>>>>>>" + date);

					eventDesc = (webTransfer.getString("eventDesc") == null ? ""
							: webTransfer.getString("eventDesc"));
					owner = (webTransfer.getString("owner") == null ? ""
							: webTransfer.getString("owner"));
					dataTransferProcess = "Y";
					moduleOrObject = "objects";
					processName = TaskType.DR_DATA_TRANSFER.getTaskLabel();

					request.setAttribute("startedAt", startedAt);
					request.setAttribute("totalExecTime",
							EDBUtil.totalTime(date));
					request.setAttribute("processName", processName);
					request.setAttribute("owner", owner);
					request.setAttribute("moduleOrObject", moduleOrObject);
					request.setAttribute("dataTransferProcess",
							dataTransferProcess);
					request.setAttribute("isRefreshAgain", isRefreshAgain);
					request.setAttribute("executionNumber",exec_no);
					request.setAttribute("refJobId", refJobId);
					request.setAttribute("processDescription", eventDesc);

				} else {
					messageList.add("DR transfer has been completed");
				}
			} else {
				errorList
						.add("Output could not be fetched for execution number :"
								+ refJobId);
			}

			return processOutput;
		}
		return retVal;
	}

}
