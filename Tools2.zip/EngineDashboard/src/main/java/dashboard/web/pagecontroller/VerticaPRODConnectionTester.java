package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.engine.vertica.BaseVerticaManager;
import dashboard.engine.vertica.OracleConnectionTester;
import dashboard.engine.vertica.VerticaManager;
import dashboard.engine.vertica.VerticaNodeSelecter;
import dashboard.util.Constants;
import dashboard.web.util.VerticaException;

public class VerticaPRODConnectionTester extends Controller {

    // Source Parameters
    private boolean srcOracleConn;
    private String srcOracleResult;
    private boolean dataTransferScriptFound;
    private String dataTransferScriptError;
    private boolean tblSpaceStatus_Error;
    private String tblSpaceStatus;
    
    private String reportCheckMsg;

    // Destination Parameters
    private Schema verticaRACSchema;
    private boolean destVerticaConn;
    private String destVerticaResult;
    private boolean schemaCreationScriptFound;
    private String schemaCreationScriptError;
    private boolean destVtkaServerMapped;
    private String vtkaMappedDRSchema;

    @Override
    public String process(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String retVal = "verticaPRODTestConnResult";
        BaseVerticaManager srcOrclCnnTester;
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        EngineMonitor engineMonitor = getEngineMonitor(request);
        String hostingServer = ((webTransfer.getString("hostingServer") == null)
                || (webTransfer.getString("hostingServer").equals(Constants.EMPTY_STRING))) ? Constants.VERTICA_CMA
                : webTransfer.getString("hostingServer");
        boolean testConnError = false;
        boolean fileNotFoundError = false;

        String srcServerGroupId = webTransfer.getString("srcServerGroupId");
        String srcHost = webTransfer.getString("srcHost");
        String srcPort = webTransfer.getString("srcPort");
        String srcService = webTransfer.getString("srcService");
        String srcSchm = webTransfer.getString("srcSchema");
        String srcSidFlag = webTransfer.getString("srcSidFlag");
        String connection = webTransfer.getString("srcConnection");
        String srcDatabaseId = webTransfer.getString("srcDatabaseId");
        /**
         * VITTOOLS-383 : BA module not in use , so runBaModule is set to false
         * by default
         */
        String runBaModule = Constants.FALSE;
        Schema srcOracleSchema = (new Schema()).setServerGroupId(srcServerGroupId).setServerName(srcHost)
                .setPort(srcPort).setService(srcService).setSidFlag(srcSidFlag).setSchemaName(srcSchm)// .setSchemaPwd(srcPwd)
                .setDatabaseId(srcDatabaseId).setHostingServer(Constants.ORACLE).setConnection(connection);
        srcOrclCnnTester = (new OracleConnectionTester()).setHostingServer(hostingServer)
                .setEngineMonitor(engineMonitor).setOrclSchema(srcOracleSchema);
        srcOrclCnnTester.init();
        
     // for Report Check
        Object[] result = new Object[]{Boolean.TRUE,
        "Report Verified"};
        boolean reportCheck=false;
        if(engineMonitor.checkDXCGVerification()){
                 result = engineMonitor.isValidReportCount(srcOracleSchema);
                 reportCheck=true;
                 reportCheckMsg=(String) result[1];
        }
        

        verticaRACSchema = (new Schema()).setClusterGroupId(webTransfer.getString("destClusterGroupId"))
                .setClusterGroupName(webTransfer.getString("destClusterGroupName"))
                .setSchemaName(webTransfer.getString("destSchema")).setHostingServer(Constants.VERTICA);
        ClusterGroup clusterGroup = new ClusterGroup().setClusterGroupId(webTransfer.getString("destClusterGroupId"))
                .setGroupName(webTransfer.getString("destClusterGroupName"));
        /**
         ** CHECK FOR STATIC MAPPING
         */
        boolean vtkaSchemaStaticallyMapped = engineMonitor.isSchemaStaticallyMapped(srcOracleSchema,verticaRACSchema);
        logger.info("[Vertica Schema " + verticaRACSchema + " statically mapped]:" + vtkaSchemaStaticallyMapped);
        VerticaManager verticaNodeSelecter = new VerticaNodeSelecter();
        verticaNodeSelecter.setHostingServer(hostingServer).setClusterGrp(clusterGroup).setEngineMonitor(engineMonitor)
                .setVtkaSchema(verticaRACSchema).setOrclSchema(srcOracleSchema).setTransferToProduction(Boolean.TRUE)
                .setIsSchemaStaticallyMapped(vtkaSchemaStaticallyMapped);
        BaseVerticaManager vtkaConnectionTester;
        boolean nodeFound;
        try {
            verticaNodeSelecter.init();
            vtkaConnectionTester = verticaNodeSelecter.getVtkaConnTester();
            verticaRACSchema = verticaNodeSelecter.getVtkaSchema();
            nodeFound = verticaNodeSelecter.isNodeFound();
            if (nodeFound) {
                setVtkaConnSuccessResult(vtkaConnectionTester);
            } else {
                setVtkaConnFailureResult(vtkaConnectionTester, clusterGroup);
            }
        } catch (VerticaException spEx) {
            logger.error("VerticaPRODConnectionTester.java [VerticaException] ", spEx);
            destVerticaConn = false;
            destVerticaResult = spEx.toString();
            vtkaMappedDRSchema = spEx.toString();
            // e.printStackTrace();
        } catch (Exception e) {
            logger.error("VerticaPRODConnectionTester.java [Exception] ", e);
            destVerticaConn = false;
            destVerticaResult = e.toString();
            vtkaMappedDRSchema = e.toString();
            // e.printStackTrace();
        }
        dataTransferScriptFound = srcOrclCnnTester.isDataTransferScriptFound();
        dataTransferScriptError = srcOrclCnnTester.getDataTransferScript_Error();
        if ((!dataTransferScriptFound) || (!schemaCreationScriptFound)) {
            fileNotFoundError = true;
        }
        srcOracleConn = (Boolean) srcOrclCnnTester.getOrclJdbcResult()[0];
        srcOracleResult = (String) srcOrclCnnTester.getOrclJdbcResult()[1];
        tblSpaceStatus = srcOrclCnnTester.getTblSpaceStatus();
        tblSpaceStatus_Error = srcOrclCnnTester.isTblSpaceStatus_Error();
        /* ERROR LISTING */
        if (!srcOracleConn || !destVerticaConn || fileNotFoundError || tblSpaceStatus_Error || !destVtkaServerMapped) {
            testConnError = true;
        }
        request.setAttribute("runBaModule", runBaModule);
        request.setAttribute("srcOracleConn", srcOracleConn);
        request.setAttribute("destVerticaConn", destVerticaConn);
        request.setAttribute("srcOracleResult", srcOracleResult);
        request.setAttribute("destVerticaResult", destVerticaResult);
        request.setAttribute("oneClickTest", true);
        request.setAttribute("testConnError", testConnError);
        request.setAttribute("reportCheck", reportCheck);
        request.setAttribute("reportCheckMsg", reportCheckMsg);
        request.setAttribute("fileNotFoundError", fileNotFoundError);
        request.setAttribute("O2V_shFileFound", dataTransferScriptFound);
        request.setAttribute("VS_shFileFound", schemaCreationScriptFound);
        request.setAttribute("hostingServer", hostingServer);
        request.setAttribute("verticaRACSchema", verticaRACSchema);
        request.setAttribute("dataTransferScriptError", dataTransferScriptError);
        request.setAttribute("schemaCreationScriptError", schemaCreationScriptError);
        request.setAttribute("tblSpaceStatus", tblSpaceStatus);
        request.setAttribute("tblSpaceStatus_Error", tblSpaceStatus_Error);
        request.setAttribute("destVtkaServerMapped", destVtkaServerMapped);
        request.setAttribute("vtkaMappedDRSchema", vtkaMappedDRSchema);
        return retVal;
    }

    /**
     * @Description: Method to set the connection result when the server is
     * found by the algorithm
     * @param destVtkaCnnTester
     */
    public void setVtkaConnSuccessResult(BaseVerticaManager destVtkaCnnTester) {
        schemaCreationScriptFound = destVtkaCnnTester.isSchemaCreationScriptFound();
        schemaCreationScriptError = destVtkaCnnTester.getSchemaCreationScript_Error();
        destVerticaConn = (Boolean) destVtkaCnnTester.getVtkJdbcResult()[0];
        destVerticaResult = (String) destVtkaCnnTester.getVtkJdbcResult()[1];

        // For auto DR
        Object vtkaMappingResult[] = destVtkaCnnTester.getVtkaMappingResult();
        destVtkaServerMapped = (Boolean) vtkaMappingResult[0];
        vtkaMappedDRSchema = (String) vtkaMappingResult[1];
    }

    /**
     * @Description : Method to set the connection result when the server is not
     * found by the algorithm
     * @param destVtkaCnnTester
     * @param clusterGroup
     */
    public void setVtkaConnFailureResult(BaseVerticaManager destVtkaCnnTester, ClusterGroup clusterGroup) {
        destVerticaConn = false;
        destVerticaResult = "Could not get vertica server for cluster group " + clusterGroup.getGroupName();
        tblSpaceStatus_Error = true;
        tblSpaceStatus = destVerticaResult;
    }
}
