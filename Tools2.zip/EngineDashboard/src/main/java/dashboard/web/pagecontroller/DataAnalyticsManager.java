package dashboard.web.pagecontroller;

import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.DataScripts;
import dashboard.data.DataTask;
import dashboard.data.RunningStatus;
import dashboard.data.Schema;
import dashboard.data.SourceControlUser;
import dashboard.data.WebTransfer;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.ImportDataControl;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.SQLProcessStatus;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.util.EDBUtil;


public class DataAnalyticsManager extends Controller{

	private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));
	private static final String DATA_ANALYTICS_PARAM = "DATA_ANALYTICS_PARAM";
    private static final String SERVER_LIST_IMPORT = "SERVER_LIST_IMPORT";
    private static final String SERVER_LIST_SCRUB = "SERVER_LIST_SCRUB";
    private static final String LIST_IMPORT_SCRIPTS = "LIST_IMPORT_SCRIPTS";
    private static final String LIST_SCRUB_SCRIPTS = "LIST_SCRUB_SCRIPTS";
    private static final String UPDATE_IMPORT_MONTH = "UPDATE_IMPORT_MONTH";
    private static final String RUN_IMPORT_SCRIPTS = "RUN_IMPORT_SCRIPTS";
    private static final String RUN_SCRUB_SCRIPTS = "RUN_SCRUB_SCRIPTS";
    private static final String DIRECTORY_BROWSE = "DIRECTORY_BROWSE";
    private static final String IMPORT_DATA = "IMPORT_DATA";
    private static final String MOUNT_DIRECTORY = "MOUNT_DIRECTORY";
    private static final String SAVE_DEFAULT_DATA_FOLDER = "SAVE_DEFAULT_DATA_FOLDER";
    
    private static final String SVN_LOGIN_NAME_IMPORT = "iSvnLoginName";
    private static final String SNV_PASSWORD_IMPORT = "iSvnPassword";
    private static final String SVN_LOGIN_NAME_SCRUB = "sSvnLoginName";
    private static final String SNV_PASSWORD_SCRUB = "sSvnPassword";

    private static final String SVN_ORACLE_IMPORT_FOLDER = "ImportScriptsORACLE";
    private static final String SVN_ORACLE_SCRUB_FOLDER = "PreScrubScriptsORACLE";
    private static final String SVN_MSSQL_IMPORT_FOLDER = "ImportScriptsMSSQL";
    private static final String SVN_MSSQL_SCRUB_FOLDER = "PreScrubScriptsMSSQL";
        
    private static final String TYPE_IMPORT = "IMPORT";
    private static final String TYPE_SCRUB = "SCRUB";

	private SourceControlUser importSCUser;
	private SourceControlUser scrubSCUser;
	
	private List lsImportServerGroups = lsEmpty;
	private List lsImportServers = lsEmpty;
	private List lsDataTransferMonth = lsEmpty;
	
	private List lsScrubServerGroups = lsEmpty;
	private List lsScrubServers = lsEmpty;
	private List lsClients = lsEmpty;
        
    private static final RunningStatus RUNNING_STATUS = new RunningStatus();
	public String process(HttpServletRequest request, HttpServletResponse response) 
																	throws Exception {
		String retVal = "";
		Boolean isRefreshAgain = Boolean.TRUE;
		Boolean isValidSVNOutput = Boolean.TRUE;
		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		
		WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
		String action = webTransfer.getString("action");
		String loginName = webTransfer.getString("session:loginName");
		EngineMonitor engine = getEngineMonitor(request);
		
		String ImportServerGroupId = webTransfer.getString("ImportServerGroupId");
		String ScrubServerGroupId = webTransfer.getString("ScrubServerGroupId");
		
		String srcMachine = engine.getEdbParameters("DataServer");
	    String mountDirectory = engine.getEdbParameters("MountDir");
	    String clientDataPath = engine.getEdbParameters("ClientDataPath");
	    
	    Boolean isSrcDirMounted = Boolean.valueOf(ImportDataControl.isDirectoryMounted(srcMachine, mountDirectory));	
	    
	    String BASE_IMPORT_SCRIPTS_DIR = ComponentFactory.getInstance().getEnvInfo().getIMPORT_SCRIPTS_DIR().toString();
	    String BASE_SCRUB_SCRIPTS_DIR = ComponentFactory.getInstance().getEnvInfo().getSCRUB_SCRIPTS_DIR().toString();
	    
	    ComponentFactory.getInstance().getEnvInfo().getSCRUB_SCRIPTS_DIR();
	    

		if(DATA_ANALYTICS_PARAM.equals(action)){
			/*StringBuffer out = new StringBuffer(300);
			String dirList = ImportDataControl.listDirectory(srcMachine, srcLocation, "");
			List filelst = ImportDataControl.getValidClientDirectory(dirList.split("\n"));
			request.setAttribute("filelstarray", filelst);*/
			
			retVal = "dataAnalyticsPane";
          	lsClients = engine.getDataClientList();
          	lsImportServerGroups = engine.getServerGroupList();
          	lsScrubServerGroups = lsImportServerGroups;

	        request.setAttribute("lsClients", lsClients);
	        request.setAttribute("lsImportServerGroups", lsImportServerGroups);
	        request.setAttribute("lsScrubServerGroups", lsScrubServerGroups);
	        
		}else if(UPDATE_IMPORT_MONTH.equals(action)){
			retVal = "importMonths";
			String _clientID = webTransfer.getString("importClientID");
			lsDataTransferMonth = engine.getDataTransferMonth(_clientID);
			request.setAttribute("lsDataTransferMonth", lsDataTransferMonth);
			
		}else if (SERVER_LIST_IMPORT.equals(action)) {			
            retVal = "serverListForImport";
            lsImportServers = engine.getServersForServerGroup(ImportServerGroupId);
            if (lsImportServers.size() == 1) {
                request.setAttribute("isSingleServer", Boolean.TRUE);
            } else {
                request.setAttribute("isSingleServer", Boolean.FALSE);
            }
            request.setAttribute("lsImportServers", lsImportServers);
            
        }else if (SERVER_LIST_SCRUB.equals(action)) {        	
            retVal = "serverListForScrub";
            lsScrubServers = engine.getServersForServerGroup(ScrubServerGroupId);
            if (lsScrubServers.size() == 1) {
                request.setAttribute("isSingleServer", Boolean.TRUE);
            } else {
                request.setAttribute("isSingleServer", Boolean.FALSE);
            }
            request.setAttribute("lsScrubServers", lsScrubServers);
            
        }else if(LIST_IMPORT_SCRIPTS.equals(action)){
			retVal = "importScripts";
			
			String importClientId = webTransfer.getString("iClient");
			String svnPayerDir = webTransfer.getString("dirName");			
			String importMonth = webTransfer.getString("iDataMonth");		
			String vssImportFolder = webTransfer.getString("ivssImportFolder");			
			String importSvnScriptURL = webTransfer.getString("iScriptURL");	
			String clientDataFolder = webTransfer.getString("iClientDataFolder");
			String prescrubServer = webTransfer.getString("iPrescrubServer");
			
			
			if(!importSvnScriptURL.endsWith(EDBUtil.fileseperator)){importSvnScriptURL += EDBUtil.fileseperator;}

			importSCUser = (new SourceControlUser())
					.setUserName( webTransfer.getString(SVN_LOGIN_NAME_IMPORT))
					.setPassword( webTransfer.getString(SNV_PASSWORD_IMPORT));


			if(vssImportFolder == null){vssImportFolder = "";}
			if(vssImportFolder.startsWith(EDBUtil.fileseperator)){vssImportFolder = vssImportFolder.substring(1);}
			if(!vssImportFolder.endsWith(EDBUtil.fileseperator)){vssImportFolder += EDBUtil.fileseperator;}
			
			/**
			 * Completes SVN URL by appending the base SVN Directory with client
			 * specific folder obtained from the list.
			 */
			importSvnScriptURL += vssImportFolder;
			
			/**
			 * Add Payer Directory
			 */
			importSvnScriptURL += EDBUtil.ifNullBlank(svnPayerDir);

			if (null != importSvnScriptURL && !"".equals(importSvnScriptURL)) {
				String dirList = engine.listDirectory(importSCUser, importSvnScriptURL);				
				if(dirList.toUpperCase().indexOf("PROPFIND REQUEST FAILED") != -1 || dirList.toUpperCase().indexOf("AUTHORIZATION FAILED") != -1){ 
                     messageList.add("No output returned.");
                     isValidSVNOutput = Boolean.FALSE;
                 } else{
                	 String[] arrySvnFiles = EDBUtil.sortFilesNFolders(dirList.split("\n"));
                	 isValidSVNOutput = Boolean.TRUE;
                	 
                	 String dataFilePath = mountDirectory + prescrubServer+ EDBUtil.fileseperator+clientDataFolder + importMonth;
                	 
                	 List scriptsWithDataLoc = engine.getScriptsWithDataLoc(importClientId, svnPayerDir, importMonth , arrySvnFiles, prescrubServer, dataFilePath);
                	 request.setAttribute("lsScriptsWithDataLoc",scriptsWithDataLoc);
                 }
			}

			request.setAttribute("prescrubServer", prescrubServer);
			request.setAttribute("clientDataPath", clientDataPath);
			request.setAttribute("dataFolder", clientDataFolder+importMonth);
			
			request.setAttribute("svnPayerDir", svnPayerDir);
			request.setAttribute("isValidSVNOutput", isValidSVNOutput);
			request.setAttribute("JobType", TYPE_IMPORT);
			request.setAttribute("isFirstList", Boolean.valueOf("Y".equals(webTransfer.getString("isFirstList"))));
		
        }else if(LIST_SCRUB_SCRIPTS.equals(action)){
			retVal = "scrubScripts";
			
			String scrubSvnScriptURL = webTransfer.getString("sScriptURL");

			if(!scrubSvnScriptURL.endsWith(EDBUtil.fileseperator)){scrubSvnScriptURL += EDBUtil.fileseperator;}

			scrubSCUser = (new SourceControlUser())
					.setUserName(webTransfer.getString(SVN_LOGIN_NAME_SCRUB))
					.setPassword(webTransfer.getString(SNV_PASSWORD_SCRUB));

			String svnFolder = webTransfer.getString("sVssScrubFolder");			
			if(svnFolder == null){svnFolder = "";}
			if(svnFolder.startsWith(EDBUtil.fileseperator)){svnFolder = svnFolder.substring(1);}
			if(!svnFolder.endsWith(EDBUtil.fileseperator)){svnFolder += EDBUtil.fileseperator;}
			
			
			/**
			 * Completes SVN URL by appending the base SVN Directory with client
			 * specific folder obtained from the list.
			 */
			scrubSvnScriptURL += svnFolder; 
			
			if (null != scrubSvnScriptURL && !"".equals(scrubSvnScriptURL)) {
				String dirList = engine.listDirectory(scrubSCUser, scrubSvnScriptURL); 
				if(dirList.toUpperCase().indexOf("PROPFIND REQUEST FAILED") != -1 || dirList.toUpperCase().indexOf("AUTHORIZATION FAILED") != -1 ){ 
                     messageList.add("No output returned.");
                     isValidSVNOutput = Boolean.FALSE;
                 } else{
                	 String[] arrySvnFiles = dirList.split("\n");
                	 isValidSVNOutput = Boolean.TRUE;
                	 request.setAttribute("lsSvnFiles", arrySvnFiles);
                 }
			}

			request.setAttribute("isValidSVNOutput", isValidSVNOutput);
			request.setAttribute("JobType", TYPE_SCRUB);
			
		} else if(RUN_IMPORT_SCRIPTS.equals(action)){
			retVal = "processOutput";
			isRefreshAgain = Boolean.TRUE;
			String processingType = TYPE_IMPORT;
			
			String importClientId = webTransfer.getString("iClientId");			
			String importClientName = webTransfer.getString("iClientName");
			String importSvnScriptURL = webTransfer.getString("iScriptURL");
			String vssImportFolder = webTransfer.getString("iVssImportFolder");			
			String importPlatform = webTransfer.getString("iClientPlatform");
			String importMonth = webTransfer.getString("iDataMonth");
			String clientDataFolder = webTransfer.getString("iClientDataFolder");
			String[] arrySelectedScripts = webTransfer.getStringArray("selectedImportScriptList");
			String[] selectedScriptsDataLocList = webTransfer.getStringArray("selectedScriptsDataLocList");	

			Schema schema = new Schema()
								.setClientName(importClientName)
								.setSchemaName(webTransfer.getString("iSchema"))
								//.setSchemaPwd(webTransfer.getString("iPassword"))
								.setDatabaseId(webTransfer.getString("iDatabaseId"))
					 			.setServerGroupId(webTransfer.getString("iServerGroup"))
								.setServerName(webTransfer.getString("iServer"))
								.setPort(webTransfer.getString("iPort"))
								.setService(webTransfer.getString("iService"))
								.setSidFlag(webTransfer.getString("iSidFlag"));
			
			// setting password for schema
			try {
				schema = engine.setSchemaPassword(schema);
			} catch (Exception e) {
				logger.error("DataAnalyticsManager.java (RUN_IMPORT_SCRIPTS)>> Error setting password for schema : "
						+ schema.getSchemaName());
				e.printStackTrace();
				errorList.add(e.getMessage());
				return retVal;
			}
			
			/**
			 * Check schema validity.
			 */
			Object [] retTestVal = engine.isValid(schema);
	        if (!Boolean.TRUE.equals( retTestVal[0])){
	        	errorValidSchema(request, retTestVal);
	            isRefreshAgain = Boolean.FALSE;
	            return retVal;
	        }
			
			
			
			/**
			 * Data path selected from Combo Box
			 */
	        String basedatapath = clientDataPath +EDBUtil.fileseperator+clientDataFolder +importMonth;	
	        
			for(int i=0; i<selectedScriptsDataLocList.length; i++){				
				String  selScriptDataLoc = URLDecoder.decode(selectedScriptsDataLocList[i]);				
				String[] temparr = selScriptDataLoc.split("::");
				
				if("TXT".equals(temparr[0])){
					/**
					 * Data path selected from Text Box
					 */
					selectedScriptsDataLocList[i]= temparr[1];
				}else if ("CMB".equals(temparr[0])){
					/**
					 * Builds full data path
					 * basedatapath    = /u02/ClientData/HI0571Lockton Benefit Group/Data/Apr09
					 * selecteddatadir = BCBSIL/RxClaims 
					 */		
					selectedScriptsDataLocList[i] = basedatapath + EDBUtil.fileseperator + temparr[1];
				}		
			}
			
			
			/**
			 * Completes SVN URL by appending the base SVN Directory with client
			 * specific folder obtained from the list.
			 */
			importSvnScriptURL += vssImportFolder;
			
			String baseDestDir = "";
			int _index = 0;
			if (importPlatform.toUpperCase().equals("O")){
				_index = importSvnScriptURL.indexOf(SVN_ORACLE_IMPORT_FOLDER);
				baseDestDir = BASE_IMPORT_SCRIPTS_DIR + EDBUtil.fileseperator + importSvnScriptURL.substring(_index + SVN_ORACLE_IMPORT_FOLDER.length() + EDBUtil.fileseperator.length(), importSvnScriptURL.length());
			} else if(importPlatform.toUpperCase().equals("S")){
				_index = importSvnScriptURL.indexOf(SVN_MSSQL_IMPORT_FOLDER);
				baseDestDir = BASE_IMPORT_SCRIPTS_DIR + EDBUtil.fileseperator + importSvnScriptURL.substring(_index + SVN_MSSQL_IMPORT_FOLDER.length() + EDBUtil.fileseperator.length(), importSvnScriptURL.length());
			}
			
			Set svncheckoutdirset = new HashSet();
			Set svncheckoutfileset = new HashSet();
			
			for(int i=0; i<arrySelectedScripts.length; i++){				
				String selectedscript = URLDecoder.decode(arrySelectedScripts[i]);				
				if (selectedscript.indexOf(EDBUtil.fileseperator)>-1){					
					svncheckoutdirset.add(selectedscript.substring(0,selectedscript.lastIndexOf(EDBUtil.fileseperator)));	
				} else {
					svncheckoutfileset.add(importSvnScriptURL + selectedscript);
				}
				
				/**
				 * Assigns full destination path to the import Scripts
				 * baseDestDir    = /engine/dbscript/ImportScripts/0571-LocktonBenefitGroup/trunk/
				 * selectedscript = BCBSIL/010_LocktonBenefitGroup_571_Eligibilities_BCBSIL.sql 
				 */				
				arrySelectedScripts[i] = baseDestDir + selectedscript;
			}
				
			
			
			/**
			 * SVN Checkout Started.
			 */
			ValidatorRoot.getMessageList(request).add("Please wait while the SVN checkout is on progress.");
			
			/**
			 * Checkout folders for Payer Folders only.
			 */
			Iterator it = svncheckoutdirset.iterator();
	        while (it.hasNext()) {
	            String dirstr= it.next().toString();
	            String _importSvnScriptURL = importSvnScriptURL + dirstr;
	            String fullDestDir = baseDestDir + dirstr;
	            
	            engine.checkOut(importSCUser, _importSvnScriptURL, fullDestDir);
	        }	        
	        
	        /**
	         * Checkout only selected files for normal clients.
	         */
	        String[] svnfilearr = (String[])svncheckoutfileset.toArray(new String[svncheckoutfileset.size()]);	 
	        engine.writeFileFromSVN(importSCUser, svnfilearr, baseDestDir);	
	        
	        ValidatorRoot.getMessageList(request).add("SVN checkout is completed.");	        
	        /**
			 * SVN Checkout Completed.
			 */

			
			DataTask dataTask = (new DataTask())
							.setRunImport(TYPE_IMPORT.equals(processingType))
							.setRunScrub(TYPE_SCRUB.equals(processingType));
			
			DataScripts dataScripts = (new DataScripts())
										.setClientID(importClientId)
										.setProcessingType(processingType)
										.setPrescrubPlatform(importPlatform)
										.setScriptFileName(arrySelectedScripts)
										.setDataURL(selectedScriptsDataLocList);	       
			
			AsyncSQLProcess sqlProcess = engine.executeImportScrub(schema, dataTask, dataScripts);			
			SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
            TaskType taskType = sqlRunnable.getTaskType();
            TaskKey taskKey = sqlProcess.getTaskKey();
            messageList.add(sqlRunnable.getDescription());  
            
            if ((loginName.equals( taskKey.getUserName())) && (TaskType.EXECUTE_IMPORT.equals(taskType))){
        		messageList.add("Currently queued: " + taskType.toString());
	        }else {
        		errorListMsg(errorList, taskType, taskKey);
        		isRefreshAgain = Boolean.FALSE;
	        }            
            
		}else if(RUN_SCRUB_SCRIPTS.equals(action)){
			retVal = "processOutput";
			isRefreshAgain = Boolean.TRUE;
			String processingType = TYPE_SCRUB;
			
			String scrubClientId = webTransfer.getString("sClientId");			
			String scrubClientName = webTransfer.getString("sClientName");			
			String scrubPlatform = webTransfer.getString("sClientPlatform");			
			String scrubSvnScriptURL = webTransfer.getString("sScriptURL");
			String sVssScrubFolder = webTransfer.getString("sVssScrubFolder");
			
			String[] selectedScrubScriptList = webTransfer.getStringArray("selectedScrubScriptList");	
			
			List lsDefaultScrubScriptsPre = engine.getDefaultScrubScripts("PreScrubScript");
			List lsDefaultScrubScriptsPost = engine.getDefaultScrubScripts("PostScrubScript");
			
			Schema schema = new Schema()
								.setClientName(scrubClientName)
								.setSchemaName(webTransfer.getString("sSchema"))
								//.setSchemaPwd(webTransfer.getString("sPassword"))
								.setDatabaseId(webTransfer.getString("sDatabaseId"))
								.setServerGroupId(webTransfer.getString("sServerGroup"))
								.setServerName(webTransfer.getString("sServer"))
								.setPort(webTransfer.getString("sPort"))
								.setService(webTransfer.getString("sService"))
								.setSidFlag(webTransfer.getString("sSidFlag"));
			
			// setting password for schema
			try {
				schema = engine.setSchemaPassword(schema);
			} catch (Exception e) {
				logger.error("DataAnalyticsManager.java (RUN_SCRUB_SCRIPTS)>> Error setting password for schema : "
						+ schema.getSchemaName());
				e.printStackTrace();
				errorList.add(e.getMessage());
				return retVal;
			}
			
			/**
			 * Check schema validity.
			 */
			Object [] retTestVal = engine.isValid(schema);
	        if (!Boolean.TRUE.equals( retTestVal[0])){
	        	errorValidSchema(request, retTestVal);
	            isRefreshAgain = Boolean.FALSE;
	            return retVal;
	        }
			
			/**
			 * Completes SVN URL by appending the base SVN Directory with client
			 * specific folder obtained from the list.
			 */
			scrubSvnScriptURL += sVssScrubFolder;
			
			
			int _index = 0;
			String baseDestDir = "";
			if (scrubPlatform.toUpperCase().equals("O")){
					_index = scrubSvnScriptURL.indexOf(SVN_ORACLE_SCRUB_FOLDER);
					baseDestDir = BASE_SCRUB_SCRIPTS_DIR + EDBUtil.fileseperator + scrubSvnScriptURL.substring(_index + SVN_ORACLE_SCRUB_FOLDER.length() + EDBUtil.fileseperator.length(), scrubSvnScriptURL.length());
			} else if(scrubPlatform.toUpperCase().equals("S")){
					_index = scrubSvnScriptURL.indexOf(SVN_MSSQL_SCRUB_FOLDER);
					baseDestDir = BASE_SCRUB_SCRIPTS_DIR + EDBUtil.fileseperator + scrubSvnScriptURL.substring(_index + SVN_MSSQL_SCRUB_FOLDER.length() + EDBUtil.fileseperator.length(), scrubSvnScriptURL.length());				
			}
			
			
			List selectedScriptLst = new ArrayList();
						
			for(int i=0; i<lsDefaultScrubScriptsPre.size();i++){	
				String[] scripts = (String[]) lsDefaultScrubScriptsPre.get(i);
				String scriptname = scripts[0];
				String scriptsvnurl = scripts[1];				
				engine.writeFileFromSVN(scrubSCUser, new String[]{scriptsvnurl+scriptname}, baseDestDir);
				/**
				 * Adds prescrub scripts.
				 */
				selectedScriptLst.add(baseDestDir+scriptname);
			}
			
			
			for(int i = 0; i < selectedScrubScriptList.length; i++){
				/**
				 * Adds selected scripts.
				 */
				selectedScriptLst.add(baseDestDir+URLDecoder.decode(selectedScrubScriptList[i]));
				
				selectedScrubScriptList[i] = scrubSvnScriptURL + selectedScrubScriptList[i] ;
		    }		
			
			/*** SVN Checkout Started.*/
			ValidatorRoot.getMessageList(request).add("Please wait while the SVN checkout is on progress.");
			
			/**
	         * Checkout only selected files.
	         */
			engine.writeFileFromSVN(scrubSCUser, selectedScrubScriptList, baseDestDir);	
			
			for(int i=0; i<lsDefaultScrubScriptsPost.size();i++){	
				String[] scripts = (String[]) lsDefaultScrubScriptsPost.get(i);
				String scriptname = scripts[0];
				String scriptsvnurl = scripts[1];				
				engine.writeFileFromSVN(scrubSCUser, new String[]{scriptsvnurl+scriptname}, baseDestDir);
				/**
				 * Adds postscrub scripts.
				 */
				selectedScriptLst.add(baseDestDir+scriptname);
			}
			ValidatorRoot.getMessageList(request).add("SVN checkout is completed.");
			/*** SVN Checkout Completed.*/
			
			
			
			String[] arrySelectedScripts=  (String[]) selectedScriptLst.toArray(new String[0]);

			DataTask dataTask = (new DataTask())
								.setRunImport(TYPE_IMPORT.equals(processingType))
								.setRunScrub(TYPE_SCRUB.equals(processingType));

		    DataScripts dataScripts = (new DataScripts())
											.setClientID(scrubClientId)
											.setProcessingType(processingType)
											.setPrescrubPlatform(scrubPlatform)
											.setScriptFileName(arrySelectedScripts);
		    
		    AsyncSQLProcess sqlProcess = engine.executeImportScrub(schema, dataTask, dataScripts);
			
			SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();            
            TaskType taskType = sqlRunnable.getTaskType();
            TaskKey taskKey = sqlProcess.getTaskKey();
            messageList.add(sqlRunnable.getDescription());

            if ((loginName.equals( taskKey.getUserName())) &&(TaskType.EXECUTE_IMPORT.equals(taskType)||TaskType.EXECUTE_SCRUB.equals(taskType))){
            		messageList.add("Currently queued: " + taskType.toString());
	        }else {
        		errorListMsg(errorList, taskType, taskKey);
        		isRefreshAgain = Boolean.FALSE;
	       }
            
	} else if (DIRECTORY_BROWSE.equals(action)) {
			List filelst = lsEmpty;
			String dirList = "";
			String dirSize = "";
			
			String filepath = webTransfer.getString("filePath");
			String selectedpath = webTransfer.getString("selectedpath") + filepath;
			String clientid = webTransfer.getString("clientid");
			
			if ("..".equals(filepath)) {					
				selectedpath = webTransfer.getString("selectedpath");
				selectedpath = selectedpath.substring(0, selectedpath.lastIndexOf(EDBUtil.fileseperator));
				selectedpath = selectedpath.substring(0, selectedpath.lastIndexOf(EDBUtil.fileseperator) + 1);
			}
								
			dirList = ImportDataControl.listDirectory(new File(mountDirectory + srcMachine+EDBUtil.fileseperator + selectedpath));
			
			dirList = EDBUtil.sortDateFolder(dirList);		

			if ("".equals(selectedpath)) {
				filelst = ImportDataControl.getClientDirectory(dirList.split("\n"),clientid);					
			} else {
				filelst = ImportDataControl.getAllDirectory(EDBUtil.sortFilesNFolders(dirList.split("\n")));
				dirSize = ImportDataControl.getDirectorySize(new File(mountDirectory + srcMachine+EDBUtil.fileseperator+selectedpath));
				
				if (filelst.size()>0){
					request.setAttribute("dirsize", "(Size: "+dirSize.split("\t")[0]+")");
				}
			}
			
			request.setAttribute("filelstarray", filelst);
			request.setAttribute("filepath", filepath);
			request.setAttribute("selectedpath", selectedpath);

			retVal = "fileBrowser";

		}else if (IMPORT_DATA.equals(action)) {
			String selectedclient = webTransfer.getString("selectedclient");	
			
			Schema srcMachineDetail = (new Schema())
	        .setServerGroupId(webTransfer.getString("serverGroupId"))
	        .setServerName(webTransfer.getString("host"))
	        .setPort("-")
	        .setService("-")
	        .setSchemaName(selectedclient.substring(0,6))
	        .setSchemaPwd("-")
	        .setSidFlag("-")
	        .setEngineVersion("-")
	        .setClientName(selectedclient.substring(6));
	        
			String[] copyfiles = webTransfer.getStringArray("copyfiles");
			String destLocation = webTransfer.getString("destLocation");
			String destMachine = webTransfer.getString("destMachine");			
			String srcLocation = webTransfer.getString("srcLocation");
			
			AsyncSQLProcess sqlProcess = engine.importDataTransfer(srcMachineDetail ,srcMachine, destMachine, srcLocation, destLocation,copyfiles , mountDirectory);
			
			SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
            isRefreshAgain = Boolean.TRUE;

            TaskType taskType = sqlRunnable.getTaskType();
            TaskKey taskKey = sqlProcess.getTaskKey();
			messageList.add( sqlRunnable.getDescription());
			
			
			if ( ( loginName.equals( taskKey.getUserName() ))
	                 && TaskType.IMPORT_DATA_TRANSFER.equals(taskType)) { 
	                messageList.add("Currently queued: " + taskType.toString());
	        } else {
	                errorListMsg(errorList, taskType, taskKey);
	                isRefreshAgain = Boolean.FALSE;
	        };			
			
	        new DataFileTransferLogThread(engine, sqlProcess, destMachine, destLocation, copyfiles, selectedclient, webTransfer.getString("clientType")).start();
			
			
			retVal = "processOutput";
			
		}else if(MOUNT_DIRECTORY.equals(action)) {	
			lsClients = engine.getDataClientList();
	        request.setAttribute("lsClients", lsClients);
	        
	        String srcServer = webTransfer.getString("srcServer");
	        String srcLoc = webTransfer.getString("srcLoc");
	        String username = webTransfer.getString("username");
	        String password = webTransfer.getString("password");
	        				
			SourceControlUser user =new SourceControlUser();
			user.setUserName(username);
			user.setPassword(password);				
			String mountretval = ImportDataControl.mountDirectory(user,srcServer, srcLoc, mountDirectory);
			
			retVal = "dataAnalyticsPane";
			
		}else if(SAVE_DEFAULT_DATA_FOLDER.equals(action)){	
			String clientid = webTransfer.getString("clientid");
	        String payer = webTransfer.getString("payer");
	        String scriptname = webTransfer.getString("scriptname");
	        String foldername = webTransfer.getString("foldername");
	        
	        String datamonth = webTransfer.getString("datamonth");
	        String importserver = webTransfer.getString("importserver");
	        
	        engine.saveDefaultFolderbyScriptName(clientid,payer,scriptname, foldername, datamonth, importserver);
	        retVal = "processOutput";        
		}
		
		
		
		request.setAttribute("srcMachine", srcMachine); 
		request.setAttribute("isSrcDirMounted", isSrcDirMounted);
		
		request.setAttribute("isRefreshAgain", isRefreshAgain);
        request.setAttribute("runningStatus", RUNNING_STATUS);
		
		return retVal;
	}
	
	private static void errorValidSchema(HttpServletRequest request, Object[] retTestVal) {
		List errors = ValidatorRoot.getErrorList( request);
		errors.add("Connection failure.");
        errors.add(retTestVal[1]);
    }
	
    private static void errorListMsg(List ls, TaskType taskType, TaskKey taskKey) {
        ls.add("Schema is being used for " + taskType );
        ls.add("Operation requested is not queued.");
        ls.add("Job was scheuled by: " + taskKey.getUserName());  
    }
    
}

/**
 * 
 * @author D2HS\spun
 *
 */

class DataFileTransferLogThread extends Thread{
   	 private EngineMonitor engine;
   	 private AsyncSQLProcess engineProcess;
   	 private static int POLL_INTERVAL = 10000; //milliseconds
   	 
   	 private String destMachine; 
   	 private String destLocation;
   	 private String[] copyfiles;
   	 private String selectedclient;
   	 private String clientType;
   	 
   	 
   	 public DataFileTransferLogThread(EngineMonitor engine,AsyncSQLProcess engineProcess, String destMachine, 
   			 					  String destLocation, String[] copyfiles, String selectedclient, String clientType){
   		 this.engine = engine;  		 
   		 this.engineProcess = engineProcess;
   		 this.destMachine = destMachine;
   		 this.destLocation = destLocation;
   		 this.copyfiles = copyfiles;
   	     this.selectedclient = selectedclient;
   	     this.clientType = clientType;
   	 }
   	 
   	 public void run(){
   		 boolean transferProcessSuccessfull = true; 
   		 try{   			   
			   while ( !engineProcess.getStatus().toString().equalsIgnoreCase(SQLProcessStatus.COMPLETE.toString())){					  
					  
				   if ( engineProcess.getStatus().toString().equalsIgnoreCase(SQLProcessStatus.FAILED.toString())) {
					   	  transferProcessSuccessfull = false; 
						  break; 
					  } 					  
					  Thread.sleep(POLL_INTERVAL);
					  //System.out.println("Data File Transfer Log waiting. [Data File Transfer status: "+engineProcess.getStatus()+"] "); 
			   		}				   
				  
				  if (!engineProcess.isAllowRun()){
					  transferProcessSuccessfull=false;
					System.out.println("************ Data File Transfer Process killed. execution terminated.");	
				  }
				  
				  if(transferProcessSuccessfull){					  
					  engine.logDataTransferClients(destMachine, destLocation, copyfiles, selectedclient);
					  engine.logDataTransferFolders(destMachine, engineProcess.getSQLPlusRunnable().getScriptFile().toString()+"._out", selectedclient, clientType);   						  
					  System.out.println("************Data File Transfer Logged.");
				  }   				    
   			   
   		   }catch(Exception ex){
   			   ex.printStackTrace();
   			   System.out.println("[ERROR: DataAnalyticsManager.java] Data File Transfer Thread \n"+ex);
   		   }
   	 }
   }
