package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import dashboard.data.DataFileDir;

public class DataFileDirValidator extends ValidatorRoot {
    public boolean isValid(Object obj, HttpServletRequest request){
        boolean retVal = true;
        if (null == obj) {
            throw new NullPointerException("Object to verify null in " + this.getClass().getName());
        }
        if ( ! (obj instanceof DataFileDir) ) {
            throw new IllegalArgumentException("Object to verify is not DataFileDir in " + this.getClass().getName());
        }
        
        init(request);
        List errors = getErrorList();
        List message = getMessageList();
        DataFileDir dataFileDir = (DataFileDir) obj;

        if ("".equals(dataFileDir.getServerGroupId())) {
            errors.add("serverGroupId is blank");
            retVal = false;
        }
        if( "".equals(dataFileDir.getDataFileDir())) {
            errors.add("DataFileDirectory is blank");
            retVal = false;
        } 
        if( "".equals(dataFileDir.getDataFileDirName())) {
            errors.add("DataFileDirectory name is blank");
            retVal = false;
        } 
        return retVal;
    }
}
