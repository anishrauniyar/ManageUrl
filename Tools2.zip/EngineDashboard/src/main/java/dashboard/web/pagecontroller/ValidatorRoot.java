package dashboard.web.pagecontroller;

import java.util.List;
import java.util.LinkedList;
import javax.servlet.http.HttpServletRequest;

public abstract class ValidatorRoot implements Validator {
    protected List errorList = null;
    protected List messageList = null;

    public static void initErrorNMessageList(HttpServletRequest request) {
        getErrorList(request);
        getMessageList(request);
    }
    public List getErrorList() {
        return errorList;
    }
    public List getMessageList() {
        return messageList;
    }
    protected void init(HttpServletRequest request) {
        List messageList = getMessageList(request);
        List errorList =  getErrorList(request);
        
    }
    public static List getErrorList(HttpServletRequest request) {
        List errorList =  (List) request.getAttribute("errorList");
        if (null == errorList) {
            errorList = new LinkedList();
            request.setAttribute("errorList", errorList);
        }
        return errorList;            
    }

    public static List getMessageList(HttpServletRequest request) {
        List messageList =  (List) request.getAttribute("messageList");
        if (null == messageList) {
            messageList = new LinkedList();
            request.setAttribute("messageList", messageList);
        }
        return messageList;            
    }

}
