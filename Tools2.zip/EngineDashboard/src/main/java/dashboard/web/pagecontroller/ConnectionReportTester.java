package dashboard.web.pagecontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.util.Constants;

public class ConnectionReportTester extends Controller {

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		String retVal = "messageList";
		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		EngineMonitor engineMonitor = getEngineMonitor(request);
	    Schema oracleSchema = getOracleSchema(webTransfer);
		Object[] result = engineMonitor.isValidReportCount(oracleSchema);
	   setMessage(result, request, "SUCCESS");
			return retVal;
		}
	
	private Schema getOracleSchema(WebTransfer webTransfer) {
		Schema schema = (new Schema())
				.setServerGroupId((webTransfer.getString("serverGroupId") ==null)?"":webTransfer.getString("serverGroupId"))
				.setServerName(webTransfer.getString("host"))
				.setPort(webTransfer.getString("port"))
				.setService(webTransfer.getString("service"))
				.setSchemaName(webTransfer.getString("dbUser"))
				//.setSchemaPwd(webTransfer.getString("dbPassword"))
				.setHostingServer(Constants.ORACLE)
				.setDatabaseId(webTransfer.getString("databaseId"));//getting database id 
		String sidFlag = webTransfer.getString("sidFlag");
		if (sidFlag != null) {
			schema = schema.setSidFlag(webTransfer.getString("sidFlag"));
		}
		return schema;
	}
	
	
	private void setMessage(Object[] result ,HttpServletRequest request , String msg)
	{
		if (Boolean.TRUE.equals(result[0])) {
			//ValidatorRoot.getMessageList(request)
			//		.add("Success - Report Verification.");
			ValidatorRoot.getMessageList(request)
			.add(result[1]);
			
		} else {
			List errors = ValidatorRoot.getErrorList(request);
			errors.add("Fail - Report Verification.");
			errors.add(result[1]);
			
		}
	}
	
}
