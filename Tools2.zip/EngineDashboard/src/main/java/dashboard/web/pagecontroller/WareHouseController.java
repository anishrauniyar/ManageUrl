package dashboard.web.pagecontroller;

import java.io.StringWriter;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WareHouseTask;
import dashboard.data.WebTransfer;
import dashboard.db.FixedParameter;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.security.User;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;
import dashboard.util.Mail;
import dashboard.util.WareHouseParams;

public class WareHouseController extends Controller {

	private static List lsEmpty = Collections
			.unmodifiableList(new java.util.ArrayList(0));

	private static final String WH_PARAM = "WH_PARAM";
	private static final String SERVER_LIST = "SERVER_LIST";
	private static final String TEST_CONN = "TEST_CONN";
	private static final String RUN_WH = "RUN_WH";
	private static final String WH_ENGINE = "WH_ENGINE";
	private static final String WH_SCRUB = "WH_SCRUB";
	private static final String WH_FRONT = "WH_FRONT";

	@Override
	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String retVal = "processOutput";
		Boolean isRefreshAgain = Boolean.TRUE;
		Boolean createSynonymChecked = Boolean.FALSE;
		Boolean compileEngineChecked = Boolean.FALSE;
		Boolean executeEngineChecked = Boolean.FALSE;

		List messageList = ValidatorRoot.getMessageList(request);
		List errorList = ValidatorRoot.getErrorList(request);
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");
		String loginName = webTransfer.getString("session:loginName");

		User user = (User) request.getSession().getAttribute("session:user");

		String action = webTransfer.getString("action");
		EngineMonitor engine = getEngineMonitor(request);

		List lsServerGroups = lsEmpty;
		List lsEngineVersions = lsEmpty;
		List lsServers = lsEmpty;

		Schema WHSchema = null;
		Schema HPSchema = null;
		Schema HFSchema = null;

		String engineVersion = "";

		lsEngineVersions = engine.getEngineVersionList();

		if (WH_PARAM.equals(action)) {
			lsServerGroups = engine.getServerGroupListForProcessing();
			retVal = "setupWHParam";
		} else if (SERVER_LIST.equals(action)) {
			String serverGroupId = webTransfer.getString("serverGroupId");
			String requestFrom = webTransfer.getString("requestFrom");
			lsServers = engine.getServersForServerGroup(serverGroupId);

			if (requestFrom.equals(WH_ENGINE)) {
				retVal = "serverListForWHEngine";
			} else if (requestFrom.equals(WH_SCRUB)) {
				retVal = "serverListForWHScrub";
			} else if (requestFrom.equals(WH_FRONT)) {
				retVal = "serverListForWHFront";
			}
		} else if (TEST_CONN.equals(action)) {
			retVal = "messageList";
			WHSchema = getWareHouseSchema(webTransfer);

			createSynonymChecked = (webTransfer
					.getString("createSynonymChecked").equalsIgnoreCase("true")) ? Boolean.TRUE
					: Boolean.FALSE;
			
			/*executeEngineChecked = (webTransfer
					.getString("executeEngineChecked").equalsIgnoreCase("true")) ? Boolean.TRUE
					: Boolean.FALSE;*/

			/*System.out.println("createSynonymChecked>>>>>> "
					+ createSynonymChecked);*/

			/**
			 * GETTING PASSWORD
			 * 
			 */
			try {
				WHSchema = engine.setSchemaPassword(WHSchema);
				//if (createSynonymChecked || executeEngineChecked) {
				if (createSynonymChecked) {
					HPSchema = getScrubSchema(webTransfer);
					HFSchema = getFrontSchema(webTransfer);

					HPSchema = engine.setSchemaPassword(HPSchema);
					HFSchema = engine.setSchemaPassword(HFSchema);

					Object[] testHPSchema = engine.isValid(HPSchema);
					Object[] testHFSchema = engine.isValid(HFSchema);
					setMessage(testHPSchema, request, "[Scrub Schema]");
					setMessage(testHFSchema, request, "[Front Schema]");
				}
				Object[] testWHSchema = engine.isValid(WHSchema);
				setMessage(testWHSchema, request, "[WareHouse Schema]");
			} catch (Exception e) {
				errorList.add(e.getMessage());
				logger.error("Error testing connection for WareHouse");
				InsertExceptionToLogger.insert(e, logger);
				return retVal;
			}
		} else if (RUN_WH.equals(action)) {
			retVal = "WHOutput";

			createSynonymChecked = (webTransfer
					.getString("createSynonymChecked").equalsIgnoreCase("true")) ? Boolean.TRUE
					: Boolean.FALSE;
			compileEngineChecked = (webTransfer
					.getString("compileEngineChecked").equalsIgnoreCase("true")) ? Boolean.TRUE
					: Boolean.FALSE;
			executeEngineChecked = (webTransfer
					.getString("executeEngineChecked").equalsIgnoreCase("true")) ? Boolean.TRUE
					: Boolean.FALSE;

			if (null != webTransfer.getString("WHEngineWHSchema")
					&& !"".equalsIgnoreCase(webTransfer
							.getString("WHEngineWHSchema"))) {
				engineVersion = engine.getEngineVersionForSchema(webTransfer
						.getString("WHEngineWHSchema"));
				logger.info("Engine version from OAM : {}" + engineVersion);
			}

			// Override setting for engine version by user
			if (null != webTransfer.getString("overrideEngineVersion")
					&& webTransfer.getString("overrideEngineVersion")
							.equalsIgnoreCase("TRUE")
					&& null != webTransfer.getString("ENG_VERSION")
					&& !"".equals(webTransfer.getString("ENG_VERSION").trim())) {
				engineVersion = webTransfer.getString("ENG_VERSION").trim();
				logger.info("Engine version overriden by user : {}"
						+ engineVersion);
			}

			AsyncSQLProcess sqlProcess = null;
			WHSchema = getWareHouseSchema(webTransfer);
			WHSchema.setEngineVersion(engineVersion); // setting engine version
			WHSchema.setClientName(engine.getClientName(WHSchema.getSchemaName()));// setting client name 

			String desc = WHSchema.getServerName() + ":" + WHSchema.getPort()
					+ "/" + WHSchema.getService() + ":"
					+ WHSchema.getSchemaName();
			/**
			 * GETTING PASSWORD
			 * 
			 */
			try {
				WHSchema = engine.setSchemaPassword(WHSchema);
				//if (createSynonymChecked || executeEngineChecked ) {
				if (createSynonymChecked) {
					HPSchema = getScrubSchema(webTransfer);
					HFSchema = getFrontSchema(webTransfer);
					HPSchema = engine.setSchemaPassword(HPSchema);
					HFSchema = engine.setSchemaPassword(HFSchema);
				}
			} catch (Exception e) {
				logger.error("Error in WareHouseController.java while getting schema password");
				StringWriter sw = InsertExceptionToLogger.insert(e, logger);
				// show error in event log
				ComponentFactory
						.getInstance()
						.getEventLogger()
						.logError(loginName,
								TaskType.EXECUTE_WH_ENGINE.getTaskLabel(),
								desc, 0, new Date(), new Date(), sw.toString(),
								WHSchema);
				// show error in UI
				errorList.add(e.getMessage());
				request.setAttribute("isRefreshAgain", false);
				return retVal;
			}

			String isHRA = webTransfer.getString("isHRA");

			/*
			 * Setting warehouse task
			 */
			WareHouseTask wareHouseTask = new WareHouseTask();
			wareHouseTask.setCreateSynonymForHPnHR(Boolean.TRUE
					.equals(createSynonymChecked));
			wareHouseTask.setCreateSynonymForHF(Boolean.TRUE
					.equals(createSynonymChecked));
			wareHouseTask.setCompileWHEngine(Boolean.TRUE
					.equals(compileEngineChecked));
			wareHouseTask.setExecuteWHEngine(Boolean.TRUE
					.equals(executeEngineChecked));

			System.out.println("WareHouse task (CREATE_SYNONYM FOR HPNHR) "
					+ wareHouseTask.isCreateSynonymForHPnHR());
			System.out.println("WareHouse task (CREATE_SYNONYM FOR HF) "
					+ wareHouseTask.isCreateSynonymForHF());
			System.out.println("WareHouse task (COMPILE ENGINE) "
					+ wareHouseTask.isCompileWHEngine());
			System.out.println("WareHouse task (EXECUTE ENGINE) "
					+ wareHouseTask.isExecuteWHEngine());

			/*
			 * WH Engine Execution
			 */
			try {
				sqlProcess = engine.executeWareHouse(WHSchema, HPSchema,
						HFSchema, wareHouseTask, isHRA);
			} catch (Exception e) {
				logger.error("Error executing warehouse engine on schema "
						+ WHSchema.getSchemaName() + " by " + loginName);
				StringWriter sw = InsertExceptionToLogger.insert(e, logger);
				// show error in event log
				ComponentFactory
						.getInstance()
						.getEventLogger()
						.logError(loginName,
								TaskType.EXECUTE_WH_ENGINE.getTaskLabel(),
								desc, 0, new Date(), new Date(), sw.toString(),
								WHSchema);
				// show error in UI
				errorList.add(e.getMessage());
				request.setAttribute("isRefreshAgain", false);
				return retVal;
			}

			SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
			isRefreshAgain = Boolean.TRUE;

			messageList.add(sqlRunnable.getDescription());

			TaskType taskType = sqlRunnable.getTaskType();
			TaskKey taskKey = sqlProcess.getTaskKey();

			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>:" + taskType);

			if ((loginName.equals(taskKey.getUserName()))
					&& (TaskType.EXECUTE_WH_ENGINE.equals(taskType)
						|| TaskType.COMPLIE_WH_ENGINE_SCRIPT.equals(taskType)
						|| TaskType.CREATE_SYNONYMS_HPNHR.equals(taskType) 
						|| TaskType.CREATE_SYNONYMS_HF.equals(taskType))) {
				messageList.add("Currently queued: " + taskType.toString());
			} else {
				errorListMsg(errorList, taskType, taskKey);
				isRefreshAgain = Boolean.FALSE;
			}

			request.setAttribute("isRefreshAgain", isRefreshAgain);
		}
		
		else if ("SEND_MAIL".equals("SEND_MAIL")) {
			WHSchema = getWareHouseSchema(webTransfer);
			WHSchema.setSchemaPwd(webTransfer.getString("pwd"));
			WHSchema.setClientName(webTransfer.getString("clientName"));
			
			FixedParameter fixedParam = ComponentFactory.getInstance().getFixedParameters();
			String event = webTransfer.getString("eventName");
			if(event.equalsIgnoreCase("ENGINE")){
				event = fixedParam.getWHParam(WareHouseParams.WH_ENGINE_EXEC_EVENT);
			}
			else if (event.equalsIgnoreCase("TRANSFER")){
				event = fixedParam.getWHParam(WareHouseParams.WH_DATA_TRANSFER_EVENT);
			}
			System.out.println("Event is >>>>>>>>>>>>>>>>"+event);
			loginName = webTransfer.getString("loginName");
			Date startTime = new Date();
			Date endTime = new Date();
			
			String error = webTransfer.getString("error");
			String from = webTransfer.getString("from"); 
			String to = webTransfer.getString("to");
			
			Mail mail = new Mail();
			
			try{
				mail.sendMail(WHSchema, loginName, event, startTime, endTime, error, from, to);
			}catch(Exception e){
				logger.error("Could not send mail");
				e.printStackTrace();
			}
		}

		request.setAttribute("lsServers", lsServers);
		request.setAttribute("lsEngineVersions", lsEngineVersions);
		request.setAttribute("lsServerGroups", lsServerGroups);
		return retVal;
	}

	public Schema getWareHouseSchema(WebTransfer webTransfer) {
		Schema schema = (new Schema())
				.setServerGroupId(
						webTransfer.getString("WHEngineServerGroupId"))
				.setServerName(webTransfer.getString("WHEngineHost"))
				.setPort(webTransfer.getString("WHEnginePort"))
				.setService(webTransfer.getString("WHEngineService"))
				.setSchemaName(webTransfer.getString("WHEngineWHSchema"))
				.setHostingServer(Constants.ORACLE)
				.setDatabaseId(webTransfer.getString("WHEngineDatabaseId"));
		String sidFlag = webTransfer.getString("WHEngineSidFlag");
		if (sidFlag != null) {
			schema = schema
					.setSidFlag(webTransfer.getString("WHEngineSidFlag"));
		}
		return schema;
	}

	public Schema getScrubSchema(WebTransfer webTransfer) {
		Schema schema = (new Schema())
				.setServerGroupId(webTransfer.getString("WHScrubServerGroupId"))
				.setServerName(webTransfer.getString("WHScrubHost"))
				.setPort(webTransfer.getString("WHScrubPort"))
				.setService(webTransfer.getString("WHScrubService"))
				.setSchemaName(webTransfer.getString("WHScrubSchema"))
				.setHostingServer(Constants.ORACLE)
				.setDatabaseId(webTransfer.getString("WHScrubDatabaseId"));
		String sidFlag = webTransfer.getString("WHScrubSidFlag");
		if (sidFlag != null) {
			schema = schema.setSidFlag(webTransfer.getString("WHScrubSidFlag"));
		}
		return schema;
	}

	public Schema getFrontSchema(WebTransfer webTransfer) {
		Schema schema = (new Schema())
				.setServerGroupId(webTransfer.getString("WHFrontServerGroupId"))
				.setServerName(webTransfer.getString("WHFrontHost"))
				.setPort(webTransfer.getString("WHFrontPort"))
				.setService(webTransfer.getString("WHFrontService"))
				.setSchemaName(webTransfer.getString("WHFrontSchema"))
				.setHostingServer(Constants.ORACLE)
				.setDatabaseId(webTransfer.getString("WHFrontDatabaseId"));
		String sidFlag = webTransfer.getString("WHFrontSidFlag");
		if (sidFlag != null) {
			schema = schema.setSidFlag(webTransfer.getString("WHFrontSidFlag"));
		}
		return schema;
	}

	public void setMessage(Object[] retTestVal, HttpServletRequest request,
			String schemaType) {
		if (Boolean.TRUE.equals(retTestVal[0])) {
			List success = ValidatorRoot.getMessageList(request);
			success.add(schemaType + " : Successfully connected.");
		} else {
			List errors = ValidatorRoot.getErrorList(request);
			errors.add(schemaType + " : Connection failure.");
			errors.add(retTestVal[1]);
		}
	}

	private static void errorListMsg(List ls, TaskType taskType, TaskKey taskKey) {
		ls.add("Schema is being used for " + taskType);
		ls.add("Operation requested is not queued.");
		ls.add("Job was scheuled by: " + taskKey.getUserName());

	}
}
