package dashboard.web.pagecontroller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;


public interface Validator {
    public List getErrorList();

    public List getMessageList();

    boolean isValid(Object toValid, HttpServletRequest request);
}
