package dashboard.web.pagecontroller;

public class UnknownPageControllerException extends RuntimeException {
    private String controllerName;
    public UnknownPageControllerException(String cntrlName) {
        controllerName = cntrlName;
    }
    public String getMessage() {
        return "Specified Unknown PageController: " + controllerName;
    }
    public String toString() {
        return getMessage();
    }    
}
