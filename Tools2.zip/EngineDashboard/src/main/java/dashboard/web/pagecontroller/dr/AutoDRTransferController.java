package dashboard.web.pagecontroller.dr;

import java.io.StringWriter;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.ClusterGroup;
import dashboard.data.Schema;
import dashboard.data.Server;
import dashboard.db.FixedParameter;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.engine.SQLProcessStatus;
import dashboard.engine.TaskKey;
import dashboard.engine.vertica.BaseVerticaManager;
import dashboard.engine.vertica.VerticaManager;
import dashboard.engine.vertica.VerticaManagerFactory;
import dashboard.engine.vertica.VerticaSchemaManager;
import dashboard.engine.vertica.VerticaSplitCluster;
import dashboard.engine.vertica.VerticaTransferValidation;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;
import dashboard.web.pagecontroller.CommonMethods;
import dashboard.web.util.CustomException;

public class AutoDRTransferController extends CommonMethods implements Runnable {

    /*
     * As this is dr transfer, so hosting server is set to VERTICA_DR_CMA to get
     * dr parameters from drfixedparameters_cma
     */
    private static final String HOSTING_SERVER = Constants.VERTICA_DR_CMA;
    private ComponentFactory compFactory;
    private EventLogger eventLogger;
    private FixedParameter fixedParam;
    private EngineMonitor engine;
    private Schema srcOrclSchema;
    private Schema destOrclRACSchema;
    private Schema destOrclDRSchema;
    private Schema destVerticaRACSchema;
    private Schema destVerticaDRSchema;
    private String runOracleDRBAModule;
    private String loginName;
    private String event;
    private String desc;
    private Date startDate;
    private long executionNumber = 0;
    AsyncSQLProcess verticaDRTransferSqlProcess = null;
    ClusterGroup destProdClusterGrp;
    ClusterGroup destDRClusterGrp;

    private Log logger = LogFactory.getLog(getClass());

    private long EXEC_NO;
    private VerticaManager verticaNodeSelecter = null;
    private long prodTransferExecNo = 0;

    /**
     * Constructor
     */
    public AutoDRTransferController(String loginName) {
        compFactory = ComponentFactory.getInstance();
        eventLogger = compFactory.getEventLogger();
        fixedParam = compFactory.getFixedParameters();
        engine = compFactory.getEngineMonitor(loginName);
    }

    @Override
    public void run() {
        startDate = new Date(System.currentTimeMillis());
        automateDRTransfer();

    }

    public void automateDRTransfer() {
        logger.info("Automating Vertica DR Transfer with Source Oracle Server " + srcOrclSchema.toString() + " and vertica rac Schema "
                + destVerticaRACSchema.toString() + " initiated by " + loginName);
        BaseVerticaManager validations = null;
        BaseVerticaManager verticaSchemaManager = null;
        try {
            /**
             * INITIATING DR TRANSFER
             */
            initiateDRTransfer();

            /*
             * GETTING VERTICA DR SCHEMA FROM VERTICA RAC SCHEMA
             * 
             * destVerticaDRSchema = getVerticaDRSchema(destVerticaRACSchema);
             */
 /*
             * SPLIT CLUSTER DESIGN
             */
            destProdClusterGrp = new ClusterGroup().setClusterGroupId(destVerticaRACSchema.getClusterGroupId()).setGroupName(
                    destVerticaRACSchema.getClusterGroupName());
            destDRClusterGrp = getDestDRClusterGrp(destProdClusterGrp);
            destVerticaDRSchema = getVerticaDRSchema();
            /*
             * USING SAME VERTICA RAC SCHEMA NAME FOR VERTICA DR SCHEMA
             */
            destVerticaDRSchema.setSchemaName(destVerticaRACSchema.getSchemaName());
            //Note: Password for destVerticaDRSchema is done in VerticaSchemaManager
            /*
             * VERTICA DR SCHEMA CREATION AND VALIDATIONS
             */
            event = "Create Schema(Vertica DR)";
            desc = "Create Vertica DR User: " + destVerticaDRSchema.getServerGroupName() + " " + destVerticaDRSchema.getServerName() + ":"
                    + destVerticaDRSchema.getPort() + "/" + destVerticaDRSchema.getDatabase() + "/" + destVerticaDRSchema.getSchemaName()
                    + " [PROD TRANSFER EXEC NO]==>" + prodTransferExecNo;
            startDate = new Date(System.currentTimeMillis());
            // Validations
            validations = (new VerticaTransferValidation()).setOrclSchema(srcOrclSchema).setVtkaSchema(destVerticaDRSchema).setEngineMonitor(engine)
                    .setHostingServer(HOSTING_SERVER);
            validations.init();
            // Vertica DR Schema Creation
            eventLogger.logStart(loginName, event, desc, 0, startDate, destVerticaRACSchema, (long) 0);
            verticaSchemaManager = (new VerticaSchemaManager()).setVtkaSchema(destVerticaDRSchema).setEngineMonitor(engine)
                    .setHostingServer(HOSTING_SERVER).setOrclSchema(srcOrclSchema)
                    .setSchema_info_inserted(verticaNodeSelecter.isSchema_info_inserted())
                    //Setting production pwd [VITTOOLS-358]
                    .setProdVtkaSchemaPwd(destVerticaRACSchema.getSchemaPwd());
            verticaSchemaManager.init(); // Vertica Schema Creation Event #1
            /*
             * ReApply algorithm case
             */
            if (verticaSchemaManager.isReApplyVtkaNodeSelectionAlgo()) {
                // Event logging for schema creation if vtkaSchema already
                // exists for Vertica Schema Creation Event #1

                String errorMsg = "[INFO]Schema " + destVerticaDRSchema.getSchemaName() + " does not exists on " + destVerticaDRSchema.getServerName()
                        + " but its password was found.";
                eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVerticaRACSchema);

                logger.info("Re Applying Vertica Split Cluster Algo....for auto DR Transfer ");
                destVerticaDRSchema = getVerticaDRSchema();
                destVerticaDRSchema.setSchemaName(destVerticaRACSchema.getSchemaName());
                // Another Create schema event Vertica Schema Creation Event #2
                event = "Create Schema(Vertica DR)";
                desc = "Create Vertica DR User: " + destVerticaDRSchema.getServerGroupName() + " " + destVerticaDRSchema.getServerName() + ":"
                        + destVerticaDRSchema.getPort() + "/" + destVerticaDRSchema.getDatabase() + "/" + destVerticaDRSchema.getSchemaName()
                        + " [PROD TRANSFER EXEC NO]==>" + prodTransferExecNo;
                startDate = new Date(System.currentTimeMillis());
                verticaSchemaManager = (new VerticaSchemaManager()).setVtkaSchema(destVerticaDRSchema).setEngineMonitor(engine)
                        .setHostingServer(HOSTING_SERVER).setOrclSchema(srcOrclSchema)
                        .setSchema_info_inserted(verticaNodeSelecter.isSchema_info_inserted())
                        //Setting production pwd [VITTOOLS-358]
                        .setProdVtkaSchemaPwd(destVerticaRACSchema.getSchemaPwd());
                verticaSchemaManager.init();
            }
            destVerticaDRSchema = verticaSchemaManager.getVtkaSchema().getCopy();
            // Event logging for schema creation if vtkaSchema already exists
            if (verticaSchemaManager.isVtkaSchemaExists()) {
                String errorMsg = "Schema " + destVerticaDRSchema.getSchemaName() + " already exists on " + destVerticaDRSchema.getServerName();
                eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), errorMsg, destVerticaRACSchema);
            } else {
                eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVerticaRACSchema);
            }
            /**
             * VITTOOLS-383 : BA module no longer in use
             */
            /*
             * ORACLE BA MODULE (DR)
             */
 /*if (runOracleDRBAModule.equalsIgnoreCase("true"))
            {
                logger.info("Initiating Oracle DR BA module transfer ");
                event = "Data Transfer (ORACLE_DR_BA_CMA)";
                desc = "Data Transfer to " + " [" + destVerticaDRSchema.getServerGroupName() + "] " + destVerticaDRSchema.getServerName() + ":"
                        + destVerticaDRSchema.getPort() + "/" + destVerticaDRSchema.getService() + ":" + destVerticaDRSchema.getSchemaName()
                        + " from " + srcOrclSchema.getServerName() + ":" + srcOrclSchema.getPort() + ":" + srcOrclSchema.getService() + ":"
                        + srcOrclSchema.getSchemaName() + " [PROD TRANSFER EXEC NO]==>" + prodTransferExecNo;
                
                // getting oracle DR Schema
                destOrclDRSchema = getOracleDRSchema(destOrclRACSchema);
                destOrclDRSchema.setEngineVersion(srcOrclSchema.getEngineVersion()); // setting
                                                                                     // engine
                                                                                     // version
                // setting same schema vertica rac schema name for oracle dr ba
                // schema
                destOrclDRSchema.setSchemaName(destVerticaRACSchema.getSchemaName());
                // getting data file directory
                String dataFileDir = getOracleDRDataFileDir(destOrclDRSchema.getServerGroupId());
                
                Manager oracleBAManager = (new OracleBAManager()).setVtkaSchema(destVerticaDRSchema).setOrclSchema(destOrclDRSchema)
                        .setEngineMonitor(engine).setHostingServer(Constants.ORACLE_DR_BA_CMA);
                logger.info("Using oracle dr schema " + oracleBAManager.getOrclSchema() + " and data file dir " + dataFileDir
                        + " for auto ba module transfer");
                oracleBAManager.init();
                engine.executeTransferForOracleDRBAModules(srcOrclSchema, oracleBAManager.getOrclSchema(), dataFileDir);
            }*/

            startDRTransfer(srcOrclSchema, verticaSchemaManager.getVtkaSchema());

        } catch (Exception e) {
            logger.error("AutoDRTransferController>>>>Error!!!!!!!");
            StringWriter sw = InsertExceptionToLogger.insert(e, logger);
            if (validations != null) {
                if (validations.getSubDesc() != null && validations.getSubDesc().length() > 0) {
                    event += validations.getSubDesc();// adding subDesc from
                    // validations
                }
            }

            eventLogger.logError(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), sw.toString(), destVerticaRACSchema);
        }
    }

    /**
     * Description : Checks whether or not to initiate dr transfer
     *
     * @return
     * @throws Exception
     */
    public void initiateDRTransfer() throws Exception {
        Thread.sleep(3000);
        logger.info("initiateDRTransfer start>>>>>>>>>>>>>>>>>");
        event = "AUTO DR TRANSFER (VERTICA)";
        desc = "Waiting for Auto DR transfer for Production transfer with Execution Number :" + prodTransferExecNo;
        startDate = new Date(System.currentTimeMillis());
        eventLogger.logStart(loginName, event, desc, 0, startDate, destVerticaRACSchema, (long) 0);
        TaskKey taskKey = new TaskKey().setServerGroupId(destVerticaRACSchema.getServerGroupId()).setSchemaName(destVerticaRACSchema.getSchemaName());
        SQLProcessStatus sqlProcessStatus = null;
        boolean autoVerticaDRTransfer = false;
        boolean actualTaskKeyNull = false;
        boolean initiateTransfer = false;
        TaskKey actualTaskKey = engine.getActualTaskKey(taskKey);
        if (actualTaskKey != null) {
            if (acutalTaskKeyMatched(actualTaskKey, srcOrclSchema, destVerticaRACSchema)) {

                int count = 0; // remove this later
                while (true) {
                    if (engine.getActualTaskKey(taskKey) != null) {
                        logger.info("Inside while loop " + destVerticaRACSchema + " >>>>>>>>>>>>>> " + count);

                        // setting exeution number from task key once
                        if (count == 0) {
                            EXEC_NO = actualTaskKey.getExecutionNumber();
                            logger.info("Execution number for vertica cma transfer is " + EXEC_NO);
                        }

                        // Getting sqlProcessStatus
                        sqlProcessStatus = actualTaskKey.getSQLProcessStatus();
                        // Checking for failure
                        if (processFailed(sqlProcessStatus)) {
                            autoVerticaDRTransfer = false;
                            break;
                        }
                        if (processCompleted(sqlProcessStatus)) // || count ==3)
                        {
                            autoVerticaDRTransfer = true;
                            break;
                        }
                        Thread.sleep(3 * 1000 * 60);// 3 minute
                        count++;
                    } else {
                        autoVerticaDRTransfer = false;
                        actualTaskKeyNull = true;
                        break;
                    }
                }
            }
        }
        /**
         * Checking different conditions just for logging
         */
        if (!actualTaskKeyNull && autoVerticaDRTransfer) {
            logger.info("<<<<<<<<<<<<<<<Inside #actualTaskKeyNull: " + actualTaskKeyNull + " & #autoVerticaDRTransfer: " + autoVerticaDRTransfer
                    + " condition for auto dr transfer>>>>>>>>>>>>>>>");
            // check table count
            if (engine.checkTableCount(srcOrclSchema, getCentralSchema(), EXEC_NO)) {
                initiateTransfer = true;
            }
        } else if (!actualTaskKeyNull && !autoVerticaDRTransfer) {
            logger.info("<<<<<<<<<<<<<<<Inside #actualTaskKeyNull: " + actualTaskKeyNull + " & #autoVerticaDRTransfer: " + autoVerticaDRTransfer
                    + " condition for auto dr transfer>>>>>>>>>>>>>>>");
            initiateTransfer = false;

        } else if (actualTaskKeyNull && !autoVerticaDRTransfer) {
            logger.info("<<<<<<<<<<<<<<<Inside #actualTaskKeyNull: " + actualTaskKeyNull + " & #autoVerticaDRTransfer: " + autoVerticaDRTransfer
                    + " condition for auto dr transfer>>>>>>>>>>>>>>>");
            // check table count
            if (engine.checkTableCount(srcOrclSchema, getCentralSchema(), EXEC_NO)) {
                initiateTransfer = true;
            }
        }

        logger.info("initiateDRTransfer end>>>>>>>>>>>>>>>>>");

        CustomException.assertFalse(initiateTransfer,
                "Vertica DR Transfer could not be initiated using source oracle(RAC) schema " + srcOrclSchema.toString()
                + " and destination vertica(RAC) schema " + destVerticaRACSchema.toString());

        eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVerticaRACSchema);

    }

    public boolean acutalTaskKeyMatched(TaskKey actualTaskKey, Schema srcSchema, Schema destVerticaSchema) {
        if ((actualTaskKey.getSrcHost().equals(srcSchema.getServerName())) && (actualTaskKey.getSrcSchemaName().equals(srcSchema.getSchemaName()))
                && (actualTaskKey.getDestHost().equals(destVerticaSchema.getServerName()))
                && (actualTaskKey.getSchemaName().equals(destVerticaSchema.getSchemaName()))) {
            return true;
        } else {
            return false;
        }
    }

    public boolean processStarted(SQLProcessStatus sqlProcessStatus) {
        return sqlProcessStatus.equals(SQLProcessStatus.INIT);
    }

    public boolean processFailed(SQLProcessStatus sqlProcessStatus) {
        return sqlProcessStatus.equals(SQLProcessStatus.FAILED);
    }

    public boolean processCompleted(SQLProcessStatus sqlProcessStatus) {
        return sqlProcessStatus.equals(SQLProcessStatus.COMPLETE);
    }

    public Schema getCentralSchema() {
        return (new Schema()).setServerName(fixedParam.getValue(Constants.CS_HOST, HOSTING_SERVER))
                .setPort(fixedParam.getValue(Constants.CS_PORT, HOSTING_SERVER))
                .setService(fixedParam.getValue(Constants.CS_SERVICE, HOSTING_SERVER))
                .setSchemaName(fixedParam.getValue(Constants.CS_SCHEMA, HOSTING_SERVER))
                .setSchemaPwd(fixedParam.getValue(Constants.CS_SCHEMAPWD, HOSTING_SERVER));
    }

    /*public String getOracleDRDataFileDir(String serverGroupId) throws Exception
    {
        List ls = engine.getDataFileDirsForServerGroup(serverGroupId);
        CustomException.assertEmptyList(ls, "Could not find data file dir for oracle dr servergroupid " + serverGroupId);
        DataFileDir dataFileDir = (DataFileDir) ls.get(0);
        return (String) dataFileDir.getDataFileDir();
    }*/
    /**
     * Description : Gets destOracleDRSchema
     *
     * @param destOracleRACSchema
     * @return
     * @throws SQLException
     * @throws CustomException
     */
    /*public Schema getOracleDRSchema(Schema destOracleRACSchema) throws CustomException, SQLException
    {
        Schema orclDRSchema = new Schema();
        logger.info("Getting Oracle DR Schema for Oracle RAC Schema " + destOracleRACSchema);
        startDate = new Date(System.currentTimeMillis());
        event = "GET ORACLE DR SERVER";
        desc = "Getting Oracle DR Server Details for Oracle RAC Server " + " [" + destOrclRACSchema.getServerGroupName() + "] "
                + destOrclRACSchema.getServerName() + ":" + destOrclRACSchema.getPort() + "/" + destOrclRACSchema.getDatabase() + ":"
                + destOrclRACSchema.getSchemaName();
        List<Schema> oracleDRSchemaList = engine.getOracleDRSchemaList(destOracleRACSchema);
        if (oracleDRSchemaList.size() > 1)
        {
            logger.info("Getting random content from list >> AutoDRTransferController.java [Auto BA Module Transfer]");
            Random myRandomizer = new Random();
            int index = myRandomizer.nextInt(oracleDRSchemaList.size());
            eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVerticaRACSchema);
            return oracleDRSchemaList.get(index);
        } else
        {
            logger.info("Getting the first content from list >> AutoDRTransferController.java [Auto BA Module Transfer]");
            eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVerticaRACSchema);
            return oracleDRSchemaList.get(0);
        }
    }*/
    /**
     * Description : Gets destVerticaDRSchema
     *
     * @return destVerticaDRSchema for the given verticaRACSchema
     * @throws Exception
     */
    /*
     * public Schema getVerticaDRSchema(Schema destVerticaRACSchema) throws
     * Exception {
     * logger.info("Getting Vertica DR Schema for Vertica RAC Schema " +
     * destVerticaRACSchema.toString()); startDate = new
     * Date(System.currentTimeMillis()); event = "GET VERTICA DR SERVER"; desc =
     * "Getting Vertica DR Server Details for Vertica RAC Server " + " [" +
     * destVerticaRACSchema.getServerGroupName() + "] " +
     * destVerticaRACSchema.getServerName() + ":" +
     * destVerticaRACSchema.getPort() + "/" + destVerticaRACSchema.getDatabase()
     * + ":" + destVerticaRACSchema.getSchemaName();
     * 
     * List<Schema> verticaDRSchemaList =
     * engine.getVerticaDRSchemaList(destVerticaRACSchema);
     * 
     * eventLogger.logEnd(loginName, event, desc, 0, startDate, new
     * Date(System.currentTimeMillis()), 0, destVerticaRACSchema); return
     * verticaDRSchemaList.get(0); }
     */
    /**
     * @Description: Returns the mapped dr cluster group for the given
     * prodClusterGrp
     * @param destProdClusterGroup
     * @return
     * @throws Exception
     */
    public ClusterGroup getDestDRClusterGrp(ClusterGroup destProdClusterGroup) throws Exception {
        logger.info("Getting Vertica DR Cluster Group from Vertica Prod Cluster Group " + destProdClusterGroup.toString());
        startDate = new Date(System.currentTimeMillis());
        event = "GET VERTICA DR CLUSTER GROUP";
        desc = "Getting Vertica DR Cluster Details for Vertica Prod Cluster Group " + destProdClusterGroup.getClusterGroupId() + "/"
                + destProdClusterGroup.getGroupName() + " [PROD TRANSFER EXEC NO]==>" + prodTransferExecNo;

        ClusterGroup drClusterGroup = engine.getDRClusterGroup(destProdClusterGroup);

        eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVerticaRACSchema);
        return drClusterGroup;
    }

    /**
     * @Description: Get the DR node from DR cluster and set schema params
     * @return
     * @throws Exception
     */
    public Schema getVerticaDRSchema() throws Exception {
        logger.info("Getting Vertica DR schema for DR cluster group " + destDRClusterGrp);
        startDate = new Date(System.currentTimeMillis());
        event = "GET VERTICA DR SERVER";
        desc = "Getting Vertica DR Server for Vertica DR cluster group " + destDRClusterGrp.getClusterGroupId() + "/"
                + destDRClusterGrp.getGroupName() + " [PROD TRANSFER EXEC NO]==>" + prodTransferExecNo;

        boolean isSchemaStaticallyMapped = engine.isSchemaStaticallyMapped(srcOrclSchema,destVerticaRACSchema);
        verticaNodeSelecter = VerticaManagerFactory.getRequiredManagerBean(isSchemaStaticallyMapped);
        verticaNodeSelecter.setHostingServer(HOSTING_SERVER).setClusterGrp(destDRClusterGrp).setEngineMonitor(engine)
                .setVtkaSchema(destVerticaRACSchema).setOrclSchema(srcOrclSchema);
        verticaNodeSelecter.init();

        Object[] result = verticaNodeSelecter.getVtkaNodeSelecterResult();
        if (!(Boolean) result[0] && !isSchemaStaticallyMapped) {
            CustomException.assertError("Could not get the dr server node from dr cluster group " + destDRClusterGrp);
        } else if (isSchemaStaticallyMapped && !(Boolean) result[0]) {
            verticaNodeSelecter = new VerticaSplitCluster().setHostingServer(HOSTING_SERVER).setClusterGrp(destDRClusterGrp).setEngineMonitor(engine)
                    .setVtkaSchema(destVerticaRACSchema).setOrclSchema(srcOrclSchema);
            verticaNodeSelecter.init();
            Object[] vtkaSplitClusterResult = verticaNodeSelecter.getVtkaNodeSelecterResult();
            if (!(Boolean) vtkaSplitClusterResult[0]) {
                CustomException.assertError("Could not get the dr server node from dr cluster group " + destDRClusterGrp);
            } else {
                Server destDRServer = (Server) verticaNodeSelecter.getVtkaNodeSelecterResult()[1];
                destVerticaDRSchema = new Schema();
                destVerticaDRSchema.setServerGroupId(destDRServer.getServerGroupId());
                destVerticaDRSchema.setServerName(destDRServer.getHost());
                destVerticaDRSchema.setPort(String.valueOf(destDRServer.getPort()));
                destVerticaDRSchema.setService(destDRServer.getDatabase());
                destVerticaDRSchema.setDatabase(destDRServer.getDatabase());
                destVerticaDRSchema.setDatabaseId(destDRServer.getDatabaseId());
                // setting cluster group information in destVerticaDRSchema
                // this is important for checking the cluster group in
                // VerticaTransferValidation
                destVerticaDRSchema.setClusterGroupId(destDRClusterGrp.getClusterGroupId());
                destVerticaDRSchema.setClusterGroupName(destDRClusterGrp.getGroupName());
                engine.setServerGroupName(destVerticaDRSchema);
            }
        } else {
            Server destDRServer = (Server) verticaNodeSelecter.getVtkaNodeSelecterResult()[1];
            destVerticaDRSchema = new Schema();
            destVerticaDRSchema.setServerGroupId(destDRServer.getServerGroupId());
            destVerticaDRSchema.setServerName(destDRServer.getHost());
            destVerticaDRSchema.setPort(String.valueOf(destDRServer.getPort()));
            destVerticaDRSchema.setService(destDRServer.getDatabase());
            destVerticaDRSchema.setDatabase(destDRServer.getDatabase());
            destVerticaDRSchema.setDatabaseId(destDRServer.getDatabaseId());
            // setting cluster group information in destVerticaDRSchema
            // this is important for checking the cluster group in
            // VerticaTransferValidation
            destVerticaDRSchema.setClusterGroupId(destDRClusterGrp.getClusterGroupId());
            destVerticaDRSchema.setClusterGroupName(destDRClusterGrp.getGroupName());
            engine.setServerGroupName(destVerticaDRSchema);
        }
        eventLogger.logEnd(loginName, event, desc, 0, startDate, new Date(System.currentTimeMillis()), 0, destVerticaRACSchema);

        return destVerticaDRSchema;
    }

    public void startDRTransfer(Schema srcOracleRACSchema, Schema destVerticaDRSchema) throws Exception {
        event = Constants.O2V_DR_CMA_EVENT;
        desc = "Data Transfer to " + " [" + destVerticaDRSchema.getServerGroupName() + "] " + destVerticaDRSchema.getServerName() + ":"
                + destVerticaDRSchema.getPort() + "/" + destVerticaDRSchema.getService() + ":" + destVerticaDRSchema.getSchemaName() + " from "
                + srcOracleRACSchema.getServerName() + ":" + srcOracleRACSchema.getPort() + ":" + srcOracleRACSchema.getService() + ":"
                + srcOracleRACSchema.getSchemaName();

        executionNumber = engine.getExecutionNumber();
        logger.info("Starting Vertica DR Transfer using execution number : " + executionNumber + " Source Schema : " + srcOracleRACSchema.toString()
                + " Destination Vertica DR Schema : " + destVerticaDRSchema.toString());
        verticaDRTransferSqlProcess = engine.executeTransferForVerticaDRUsingCMA(srcOracleRACSchema, destVerticaDRSchema, executionNumber);
    }

    /**
     * @return the srcOrclSchema
     */
    public Schema getSrcOrclSchema() {
        return srcOrclSchema;
    }

    /**
     * @param srcOrclSchema the srcOrclSchema to set
     */
    public void setSrcOrclSchema(Schema srcOrclSchema) {
        this.srcOrclSchema = srcOrclSchema;
    }

    /**
     * @return the destVerticaRACSchema
     */
    public Schema getDestVerticaRACSchema() {
        return destVerticaRACSchema;
    }

    /**
     * @param destVerticaRACSchema the destVerticaRACSchema to set
     */
    public void setDestVerticaRACSchema(Schema destVerticaRACSchema) {
        this.destVerticaRACSchema = destVerticaRACSchema;
    }

    /**
     * @return the destVerticaDRSchema
     */
    public Schema getDestVerticaDRSchema() {
        return destVerticaDRSchema;
    }

    /**
     * @param destVerticaDRSchema the destVerticaDRSchema to set
     */
    public void setDestVerticaDRSchema(Schema destVerticaDRSchema) {
        this.destVerticaDRSchema = destVerticaDRSchema;
    }

    /**
     * @return the runOracleDRBAModule
     */
    public String getRunOracleDRBAModule() {
        return runOracleDRBAModule;
    }

    /**
     * @param runOracleDRBAModule the runOracleDRBAModule to set
     */
    public void setRunOracleDRBAModule(String runOracleDRBAModule) {
        this.runOracleDRBAModule = runOracleDRBAModule;
    }

    /**
     * @return the loginName
     */
    public String getLoginName() {
        return loginName;
    }

    /**
     * @param loginName the loginName to set
     */
    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    /**
     * @return the destOrclRACSchema
     */
    public Schema getDestOrclRACSchema() {
        return destOrclRACSchema;
    }

    /**
     * @param destOrclRACSchema the destOrclRACSchema to set
     */
    public void setDestOrclRACSchema(Schema destOrclRACSchema) {
        this.destOrclRACSchema = destOrclRACSchema;
    }

    /**
     * @return the destOrclDRSchema
     */
    public Schema getDestOrclDRSchema() {
        return destOrclDRSchema;
    }

    /**
     * @param destOrclDRSchema the destOrclDRSchema to set
     */
    public void setDestOrclDRSchema(Schema destOrclDRSchema) {
        this.destOrclDRSchema = destOrclDRSchema;
    }

    /**
     * @return the prodTransferExecNo
     */
    public long getProdTransferExecNo() {
        return prodTransferExecNo;
    }

    /**
     * @param prodTransferExecNo the prodTransferExecNo to set
     */
    public void setProdTransferExecNo(long prodTransferExecNo) {
        this.prodTransferExecNo = prodTransferExecNo;
    }
}
