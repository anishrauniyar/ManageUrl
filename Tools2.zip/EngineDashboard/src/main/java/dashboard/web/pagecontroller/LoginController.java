package dashboard.web.pagecontroller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dashboard.ComponentFactory;
import dashboard.engine.EngineMonitor;
import dashboard.data.WebTransfer;
import dashboard.security.User;
import dashboard.security.RoleSet;
import dashboard.security.ProcessingRole;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

public class LoginController extends Controller {

	protected Log logger = LogFactory.getLog(getClass());

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String retVal = "";
		WebTransfer webTransfer = (WebTransfer) request
				.getAttribute("webTransfer");

		String loginName = webTransfer.getString("loginName");
		String password = webTransfer.getString("password");
		String encLogin = webTransfer.getString("encLogin");
		//System.out.println("ENC Login "+encLogin);
		String app_version = ComponentFactory.getInstance().getEnvInfo()
				.getAppVersion();
		String dashboardVersion = ComponentFactory.getInstance().getEnvInfo()
				.getDashboardVersion();

		Object isValidLogin[] = new Object[] { Boolean.FALSE, Boolean.FALSE };

		EngineMonitor engineMonitor = getEngineMonitor(request);
		if(encLogin == null){
			logger.info("<<<<<<<<<<Normal Login>>>>>>>>>>>>>");
			isValidLogin = engineMonitor.isValidLogin(loginName, password);
		}else{
			logger.info("<<<<<<<<<<SSO Login>>>>>>>>>>>>>");
			loginName = encLogin;// SSO Login
			isValidLogin  = engineMonitor.isValidSSOLogin(loginName);
		}
		if (Boolean.TRUE.equals(isValidLogin[0])){
				//|| Boolean.TRUE.equals(isValidLogin[1])) {
			HttpSession session = request.getSession(true);
			logger.info("App version " + app_version);
			logger.info("Dashboard version " + dashboardVersion);
			session.setAttribute("appVersion", app_version);
			session.setAttribute("dashboardVersion", dashboardVersion);
			User user = null;
			if (encLogin!=null){
				user = engineMonitor.getUserWithoutPwd(loginName);
			}
			/*else if (Boolean.TRUE.equals(isValidLogin[1])) {
				user = engineMonitor.getUserForLDAPUser(loginName);
			}*/else {
				user = engineMonitor.getUser(loginName, password);
			}

			if (user != null) {

				logger.info("logged in : " + user.getLoginName());

				RoleSet roleSet = engineMonitor.getUsersRoles(user.getUserId());
				session.setAttribute("session:loginName", user.getLoginName());
				session.setAttribute("session_user_name", user.getUserName());
				session.setAttribute("session:user", user);
				session.setAttribute("session:userId", user.getUserId());
				session.setAttribute("session:roles", roleSet);
				session.setAttribute("isValidLogin", Boolean.TRUE);
				
				if (roleSet.hasRole(ProcessingRole.PROCESS_SUPERADMIN)) {
					session.setAttribute("isProcessSuperAdmin", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_SUPERADMIN.getRole());
				}
				
				if (roleSet.hasRole(ProcessingRole.PROCESS_ADMIN)) {
					session.setAttribute("isProcessAdmin", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_ADMIN.getRole());
				}

				if (roleSet.hasRole(ProcessingRole.PROCESS_MANAGER)) {
					session.setAttribute("isProcessManager", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_MANAGER.getRole());
				}
				if (roleSet.hasRole(ProcessingRole.PROCESS_USER)) {
					session.setAttribute("isProcessUser", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_USER.getRole());
				}
				if (roleSet.hasRole(ProcessingRole.PROCESS_SCRUB_N_VERSION_CONTROL)) {
					session.setAttribute("isProcessScrubNVersionControl", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_SCRUB_N_VERSION_CONTROL.getRole());
				}
				if (roleSet.hasRole(ProcessingRole.PROCESS_SCRUB)) {
					session.setAttribute("isProcessScrub", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_SCRUB.getRole());
				}
				if (roleSet.hasRole(ProcessingRole.PROCESS_SCRUB_VERSION_CONTROL)) {
					session.setAttribute("isProcessScrubVersionControl", Boolean.TRUE);
					
					logger.info("logged in role for "+user.getLoginName()+">>>>>"+ProcessingRole.PROCESS_SCRUB_VERSION_CONTROL.getRole());
				}
				
				return "loggedIn";
			}
		}

		request.setAttribute("msg", "Authentication failed. Try again");
		return "relogin";
	}
}
