package dashboard.web.pagecontroller;

import java.io.File;

import java.util.List;
import java.util.Set;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

import dashboard.data.WebTransfer;
import dashboard.data.Schema;
import dashboard.data.RunningStatus;
import dashboard.data.EngineReplacementData;
import dashboard.data.EngineTask;

import dashboard.util.FileUtil;

import dashboard.engine.EngineMonitor;
import dashboard.engine.TaskType;
import dashboard.engine.TaskKey;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.SQLPlusRunnable;


public class PreScrubController extends Controller {

    protected Log logger = LogFactory.getLog(getClass());

    private static List lsEmpty = Collections.unmodifiableList( new java.util.ArrayList(0));

    private static final String PRE_SCRUB_PARAM = "PRE_SCRUB_PARAM";
    private static final String CREATE_PRESCRUB_USER = "CREATE_PRESCRUB_USER";

    private static final String S_TRUE = "TRUE";

    private static final RunningStatus RUNNING_STATUS = new RunningStatus();
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "processOutput";
        if (true) return "";//not supported for now.
        Boolean isRefreshAgain = Boolean.TRUE;
        RunningStatus runningStatus = RUNNING_STATUS;
        
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String loginName = webTransfer.getString("session:loginName");
        
        String action = webTransfer.getString("action");
        EngineMonitor engine = getEngineMonitor(request);

        String serverGroupId = webTransfer.getString("serverGroupId");
        serverGroupId = (serverGroupId == null)? "": serverGroupId.trim();
        
        List lsServerGroups = lsEmpty;
        
        if( PRE_SCRUB_PARAM.equals(action) ) {
            lsServerGroups = engine.getServerGroupList();
            retVal = "setupPreScrubParam";

        } else if ( CREATE_PRESCRUB_USER.equals(action) ) {
            retVal = "processOutput";
            Schema schema = (new Schema())
                .setServerGroupId( serverGroupId)
                .setServerName( webTransfer.getString("host") )
                .setPort( webTransfer.getString("port"))
                .setService( webTransfer.getString("service"))
                .setSchemaName( webTransfer.getString("frontSchema") )
                .setSchemaPwd( webTransfer.getString("frontPassword"))
                .setSidFlag( webTransfer.getString("sidFlag"));
            String sysUser = webTransfer.getString("dbUser");
            String sysPwd = webTransfer.getString("dbPassword");
            
            if ( !engine.hasValidServerGroup( schema)) {
                throw new IllegalArgumentException("Non existent combination of ServerGroupId|Host|Port|Service");
            }
            logger.info("schema: " + schema.getSchemaName() + ":" + sysUser + ":" + sysPwd);
            AsyncSQLProcess sqlProcess = engine.createPreScrubUser(schema, sysUser, sysPwd);
            SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
            isRefreshAgain = Boolean.TRUE;

            TaskType taskType = sqlRunnable.getTaskType();
            TaskKey taskKey = sqlProcess.getTaskKey();

            messageList.add( sqlRunnable.getDescription());

            if ( ( loginName.equals( taskKey.getUserName() ))
                 && TaskType.CREATE_PRESCRUB_USER.equals(taskType) ) { 
                messageList.add("Currently queued: " + taskType.toString());
            } else {
                errorListMsg(errorList, taskType, taskKey);
                isRefreshAgain = Boolean.FALSE;
            }


        }
        
        request.setAttribute("lsServerGroups", lsServerGroups);
        request.setAttribute("isRefreshAgain", isRefreshAgain);
        request.setAttribute("runningStatus", runningStatus);


        return retVal;
    }

    private static void errorListMsg(List ls, TaskType taskType, TaskKey taskKey) {
        ls.add("Schema is being used for " + taskType );
        ls.add("Operation requested is not queued.");
        ls.add("Job was scheuled by: " + taskKey.getUserName());  
    }
}

