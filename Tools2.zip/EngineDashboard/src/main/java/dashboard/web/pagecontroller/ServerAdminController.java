package dashboard.web.pagecontroller;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.ClusterGroup;
import dashboard.data.DataFileDir;
import dashboard.data.Server;
import dashboard.data.ServerGroup;
import dashboard.data.TempTablespace;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;
import dashboard.util.Constants;

public class ServerAdminController extends Controller {
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception{
        String retVal = "serverGroupList";

        EngineMonitor engine = getEngineMonitor(request);
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        String action = webTransfer.getString("sa_action");
        String serverGroupName = webTransfer.getString("sa_serverGroupName");
        String serverType = webTransfer.getString("sa_serverType");
        String clusterGroupName = webTransfer.getString("sa_clusterGroupName");
        String clusterType = webTransfer.getString("sa_clusterType");
        String hostingServer = webTransfer.getString("sa_hostingServer");
        
        request.setAttribute("hostingServer", hostingServer);

        if( "ADD_SERVER_GROUP".equals(action) || "DELETE_SERVER_GROUP".equals(action) ||
            "LIST_SERVER_GROUP".equals(action)) {
            if( "ADD_SERVER_GROUP".equals(action)) {
                if ( (new ServerGroupNameValidator()).isValid(serverGroupName, request)) {
                    int count = engine.addServerGroup(serverGroupName,serverType,hostingServer);
                    if(0 == count) {
                        errorList.add("Make sure server group name is not already used.");
                    }
                }
            } else if ("DELETE_SERVER_GROUP".equals(action)) {
                try
                {
                    String sa_serverGroupId  = webTransfer.getString("sa_serverGroupId");
                    int count = engine.deleteServerGroup(sa_serverGroupId);
                    messageList.add("Number of server group deleted: " + count);
                } catch (Exception e)
                {
                   errorList.add(e.getMessage());
                }
            }
            List ls = engine.getServerGroupList(hostingServer);
            request.setAttribute("serverGroupList", ls);
            retVal = "serverGroupList";
            
        } else if ( "EDIT_SERVERS_FOR_SERVER_GROUP".equals(action) ||
                    "ADD_SERVER_TO_SERVER_GROUP".equals(action) ||
                    "DELETE_SERVER_FROM_SERVER_GROUP".equals(action) ||
                    "EDIT_REMOTE_LINK_OF_SERVER_FROM_SERVER_GROUP".equals(action)) {
            String sa_serverGroupId  = webTransfer.getString("sa_serverGroupId");
            ServerGroup serverGroup = engine.getServerGroup(sa_serverGroupId);
            Server server = (new Server()).setServerGroupId( sa_serverGroupId).setHostingServer(hostingServer);
            //for UI parameters
            boolean isProcessingOracleServer = false;
            if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
            {
            	server.setPort(5433);
            }
            else if (hostingServer.equalsIgnoreCase(Constants.DMEXPRESS))
            {
            	server.setPort(0);
            }
            else
            {
            	isProcessingOracleServer = engine.isProcessingOracleServer(serverGroup.getServerGroupId());
                server.setProcessingOracleServer(isProcessingOracleServer);
            }
            
            List lsServers = null;
            
            if(serverGroup == null) 
            {
                serverGroup = new ServerGroup();
                lsServers = new LinkedList();
            } 
            else 
            {
                if( "ADD_SERVER_TO_SERVER_GROUP".equals(action) ||
                    "DELETE_SERVER_FROM_SERVER_GROUP".equals(action)||
                    "EDIT_REMOTE_LINK_OF_SERVER_FROM_SERVER_GROUP".equals(action)) 
                {
                    //check for hosting Server
                	if(hostingServer.equalsIgnoreCase(Constants.ORACLE))
                	{
	                	server.setHost( webTransfer.getString("sa_Host"))
	                          .setPort( Integer.parseInt(webTransfer.getString("sa_Port") ) )
	                          .setService( webTransfer.getString("sa_Service"))
	                          .setSidFlag( webTransfer.getString("sa_SidFlag"))
	                          .setRemote_Link(webTransfer.getString("sa_RemoteLink"))
	                          .setDatabaseId( webTransfer.getString("sa_DatabaseId"))
	                          .setIsVip(webTransfer.getString("sa_isVIP"));
	                	
	                	if(isProcessingOracleServer)
	                	{
	                		String connection = (webTransfer.getString("sa_Connection") == null || webTransfer.getString("sa_Connection") == "")? "":webTransfer.getString("sa_Connection");
	                		//System.out.println("CONNECTION>>>>>"+connection);
	                		server.setConnection(connection);
	                	}
                	}
                	else if(hostingServer.equalsIgnoreCase(Constants.VERTICA))
                	{
                		server.setHost( webTransfer.getString("sa_Host"))
                        	  .setPort( Integer.parseInt(webTransfer.getString("sa_Port") ) )
                        	  .setConnection(webTransfer.getString("sa_Connection"))
                        	  .setDatabase(webTransfer.getString("sa_Database"))
                        	  .setDatabaseId( webTransfer.getString("sa_DatabaseId"))
                        	  .setIsVip(webTransfer.getString("sa_isVIP"))
                        	  .setService(Constants.VERTICA);
                	}
                	else
                	{
                		server.setHost( webTransfer.getString("sa_Host"))
                        	  .setPort( Integer.parseInt(webTransfer.getString("sa_Port") ) )
                        	  .setInstance(webTransfer.getString("sa_Instance"))
                        	  .setService(Constants.DMEXPRESS);
                	}
                	//validate server
                    if ( (new ServerValidator()).isValid(server, request)) {
                        int count = 0;
                        if("ADD_SERVER_TO_SERVER_GROUP".equals(action)) {
                            try{
                            	count = engine.addServer(server);
	                            messageList.add("No. of server added: " + count);
	                            if (count == 0) {
	                                errorList.add("Same server can not be added multiple times nor can they be in multiple groups.");
	                            }
                            }catch(SQLException e)
                            {
                            	errorList.add(e.getMessage());
                            }
                        } else if ("DELETE_SERVER_FROM_SERVER_GROUP".equals(action) ) {
                            try
                            {
                                count = engine.deleteServer(server);
                                messageList.add("No. of server deleted: " + count);
                                if (count == 0) {
                                    errorList.add("Server to delete is no more registered.");
                                }
                            } catch (Exception e)
                            {
                                errorList.add(e.getMessage());
                            }
                        }
                        else if ("EDIT_REMOTE_LINK_OF_SERVER_FROM_SERVER_GROUP".equals(action))
                        {
                        	count = engine.editRemoteLinkofServer(server);
                        	messageList.add("No. of server whose remote link was updated: " + count);
                            if (count == 0) {
                                errorList.add("Remote link could't be updated");
                            }
                        }
                    }
                }
                lsServers = engine.getServersForServerGroup(serverGroup.getServerGroupId());
            }
            request.setAttribute("serverGroup", serverGroup);
            request.setAttribute("server", server);
            request.setAttribute("lsServers", lsServers);
            request.setAttribute("isProcessingOracleServer", isProcessingOracleServer);
            retVal = "serverListByServerGroup";

        } else if ( "EDIT_DATA_FILE_DIRS_FOR_SERVER_GROUP".equals(action) ||
                    "ADD_DATA_FILE_DIR_TO_SERVER_GROUP".equals(action) ||
                    "DELETE_DATA_FILE_DIR_FROM_SERVER_GROUP".equals(action) ) {
            String sa_serverGroupId  = webTransfer.getString("sa_serverGroupId");
            ServerGroup serverGroup = engine.getServerGroup(sa_serverGroupId);

            DataFileDir dataFileDir = (new DataFileDir()).setServerGroupId( sa_serverGroupId);
            List lsDataFileDirs = null;
            if(serverGroup == null) {
                serverGroup = new ServerGroup();
                lsDataFileDirs = new LinkedList();
            } else {
                if( "ADD_DATA_FILE_DIR_TO_SERVER_GROUP".equals(action) ||
                    "DELETE_DATA_FILE_DIR_FROM_SERVER_GROUP".equals(action) ) {
                    dataFileDir.setDataFileDir( webTransfer.getString("sa_dataFileDir"));
                    dataFileDir.setDataFileDirName( webTransfer.getString("sa_dataFileDirName"));
                    if ( (new DataFileDirValidator()).isValid(dataFileDir, request)) {
                        int count = 0;
                        if("ADD_DATA_FILE_DIR_TO_SERVER_GROUP".equals(action)) {
                            count = engine.addDataFileDir(dataFileDir);
                            messageList.add("No. of data files added: " + count);
                        } else if ("DELETE_DATA_FILE_DIR_FROM_SERVER_GROUP".equals(action) ) {
                            count = engine.deleteDataFileDir(dataFileDir);
                            messageList.add("No. of data files deleted: " + count);
                        }
                    }
                }
                lsDataFileDirs = engine.getDataFileDirsForServerGroup(serverGroup.getServerGroupId());
            }
            request.setAttribute("serverGroup", serverGroup);
            request.setAttribute("dataFileDir", dataFileDir);
            request.setAttribute("lsDataFileDirs", lsDataFileDirs);
            retVal = "dataFileDirListByServerGroup";
        } else if ( "EDIT_TEMPSPACE_FOR_SERVER_GROUP".equals(action) ||
                    "ADD_TEMPSPACE_TO_SERVER_GROUP".equals(action) ||
                    "DELETE_TEMPSPACE_FROM_SERVER_GROUP".equals(action) ) {
            String sa_serverGroupId  = webTransfer.getString("sa_serverGroupId");
            ServerGroup serverGroup = engine.getServerGroup(sa_serverGroupId);

            TempTablespace tempTablespace = (new TempTablespace()).setServerGroupId( sa_serverGroupId);
            List lsTempTablespaces = null;
            if(serverGroup == null) {
                serverGroup = new ServerGroup();
                lsTempTablespaces = new LinkedList();
            } else {
                if( "ADD_TEMPSPACE_TO_SERVER_GROUP".equals(action) ||
                    "DELETE_TEMPSPACE_FROM_SERVER_GROUP".equals(action) ) {
                    tempTablespace.setTempTablespace( webTransfer.getString("sa_tempTablespace"));
                    if ( (new TempTablespaceValidator()).isValid(tempTablespace, request)) {
                        int count = 0;
                        if("ADD_TEMPSPACE_TO_SERVER_GROUP".equals(action)) {
                            count = engine.addTempTablespace(tempTablespace);
                            messageList.add("No. of tempspace added: " + count);
                        } else if ("DELETE_TEMPSPACE_FROM_SERVER_GROUP".equals(action) ) {
                            count = engine.deleteTempTablespace(tempTablespace);
                            messageList.add("No. of tempspace deleted: " + count);
                        }
                    }
                }
                lsTempTablespaces = engine.getTempTablespacesForServerGroup(serverGroup.getServerGroupId());
            }
            request.setAttribute("serverGroup", serverGroup);
            request.setAttribute("tempTablespace", tempTablespace);
            request.setAttribute("lsTempTablespaces", lsTempTablespaces);
            retVal = "tempTablespaceListByServerGroup";
        }// Cluster Group Implementation
        else if ("LIST_CLUSTER_GROUP".equals(action) || "ADD_CLUSTER_GROUP".equals(action) || "DELETE_CLUSTER_GROUP".equals(action))
        {
            if ("ADD_CLUSTER_GROUP".equals(action))
            {
                if ((new ClusterGroupNameValidator()).isValid(clusterGroupName, request))
                {
                    try
                    {
                        int count = engine.addClusterGroup(clusterGroupName, clusterType);
                        if (0 == count)
                        {
                            errorList.add("Make sure cluster group name is not already used.");
                        }
                    } catch (Exception e)
                    {
                        errorList.add(e.getMessage());
                    }
                }
            } else if ("DELETE_CLUSTER_GROUP".equals(action))
            {
                String sa_clusterGroupId = webTransfer.getString("sa_clusterGroupId");
                try
                {
                    int count = engine.deleteClusterGroup(sa_clusterGroupId);
                    messageList.add("Number of cluster group deleted: " + count);
                } catch (Exception e)
                {
                    errorList.add(e.getMessage());
                }
            }
            List ls = engine.getClusterGroupList();
            request.setAttribute("clusterGroupList", ls);
            retVal = "listAllClusters";
        } else if ("LIST_SERVER_GROUPS_FOR_CLUSTERS".equals(action) || 
                   "EDIT_SERVER_GROUPS_FOR_CLUSTERS".equals(action) ||
                   "DELETE_SERVER_GROUPS_FOR_CLUSTERS".equals(action))
        {
            ClusterGroup clusterGrp = new ClusterGroup().setClusterGroupId(webTransfer.getString("sa_clusterGroupId")).setGroupName(clusterGroupName)
                    .setCategory(clusterType);
            
            if("EDIT_SERVER_GROUPS_FOR_CLUSTERS".equals(action))
            {
                int count = 0;
                String selectedServerGrpString = webTransfer.getString("sa_selectedServerGrps");
                String serverGrps[]= selectedServerGrpString.split(",");
                try
                {
                    count = engine.assignServerGrpToCluster(clusterGrp.getClusterGroupId(), serverGrps);
                    messageList.add("No. of server groups added "+count);
                } catch (Exception e)
                {
                    errorList.add(e.getMessage());
                }
            }
            else if("DELETE_SERVER_GROUPS_FOR_CLUSTERS".equals(action))
            {
                int count = 0;
                String serverGroupId = webTransfer.getString("sa_serverGrpId");
                try
                {
                    count = engine.deleteServerGrpFromCluster(clusterGrp.getClusterGroupId(),serverGroupId);
                    messageList.add("No. of server groups mapping deleted "+count);
                } catch (Exception e)
                {
                       errorList.add(e.getMessage());
                }
            }
            List ls = engine.getServerGroupListByCluster(clusterGrp.getClusterGroupId());
            List ls1 = engine.getAvailableServerGps(clusterGrp.getCategory());
            /*System.out.println("Available server groups");
            for (int i = 0; i < ls1.size(); i++)
            {
               System.out.println(ls1.get(i)); 
            }
            
            System.out.println("Selected server groups");
            for (int i = 0; i < ls.size(); i++)
            {
               System.out.println(ls.get(i)); 
            }*/
            request.setAttribute("clusterGrp",clusterGrp);
            request.setAttribute("assignedServerGrps", ls);
            request.setAttribute("availableServerGrps", ls1);
            retVal = "serverGroupByClusterList";
        }
        if("LIST_ALL_SERVERS".equals(action) ){
        	Boolean showDmexpress = Boolean.parseBoolean((webTransfer.getString("showDmexpress")==null)?"false":webTransfer.getString("showDmexpress"));
        	//System.out.println("ShowDMexpress >>>>>>>>>>>>>>"+showDmexpress);
            request.setAttribute("lsGroupNServers", engine.listAllGroupNServers(showDmexpress));
            retVal = "listAllServers";
        }        
        return retVal;
    }
}
