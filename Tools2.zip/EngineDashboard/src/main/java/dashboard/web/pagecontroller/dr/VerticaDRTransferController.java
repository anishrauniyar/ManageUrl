package dashboard.web.pagecontroller.dr;

import java.io.StringWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.AsyncSQLProcess;
import dashboard.engine.EngineMonitor;
import dashboard.engine.SQLPlusRunnable;
import dashboard.engine.TaskKey;
import dashboard.engine.TaskType;
import dashboard.util.Constants;
import dashboard.util.InsertExceptionToLogger;
import dashboard.web.pagecontroller.Controller;
import dashboard.web.pagecontroller.ValidatorRoot;

public class VerticaDRTransferController extends Controller {
	
	private long executionNumber = 0;
	
	public String process(HttpServletRequest request, HttpServletResponse response)
	        throws Exception {
	        String retVal = "processOutput";
	        Boolean isRefreshAgain = Boolean.FALSE;

	        List messageList = ValidatorRoot.getMessageList(request);
	        List errorList = ValidatorRoot.getErrorList(request);
	        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
	        String loginName = webTransfer.getString("session:loginName");
	        //String hostingServer = webTransfer.getString("hostingServer");
	        /**
	         * VITTOOLS-383 : BA module not in use , so runOracleDRBaModule is set to false
	         * by default
	        */
	        //String runOracleDRBaModule = webTransfer.getString("runOracleDRBaModule");
	        String runOracleDRBaModule = Constants.FALSE;
	        
	        Date startDate = new Date();
	        
	        AsyncSQLProcess sqlProcess = null;
	        AsyncSQLProcess sqlProcessForOracleDRBATransfer = null;

	        EngineMonitor engine = getEngineMonitor(request);
	        
	        Schema srcSchema = getOracleSrcSchema(webTransfer,engine);
	        
	        Schema destSchema = getDestVerticaDRSchema(webTransfer,engine);
	        destSchema.setClientName(engine.getClientName(destSchema.getSchemaName()));
	        destSchema.setEngineVersion(srcSchema.getEngineVersion());
	        destSchema.setHostingServer(Constants.VERTICA_DR_CMA); //for oracle to vertica dr transfer [IMPORTANT]
	        	
	        String O2VStatus = allowO2VDataTransfer(request, srcSchema, destSchema);
	        if(!O2VStatus.equals("")){
	        	 logger.info("Oracle to Vertica DR Data Transfer Process Already Exists (VerticaDRTransferController.java)");
	        	 request.setAttribute("O2VStatus", O2VStatus);
	        	 return retVal;
	        }
	         
	         // setting schema password
	        try {
				srcSchema = engine.setSchemaPassword(srcSchema);
				destSchema = engine.setSchemaPassword(destSchema);
	        } catch (Exception e) {
				logger.error("VerticaDRTransferController.java>>>Error setting schema passsword for oracle to vertica dr data transfer using cma by "
						+ loginName);
				// inserting exception caught to logger.
				StringWriter sw = InsertExceptionToLogger.insert(e, logger); 
				// show error in event log
				ComponentFactory.getInstance().getEventLogger().logError(
						loginName,Constants.O2V_DR_CMA_EVENT, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
				// show error in UI
				errorList.add(e.getMessage());
				return retVal;
	        }
	         
	        logger.info("Oracle to Vertica DR Data Transfer Process Does Not Exists (VerticaDRTransferController.java) ");
	        
	        /**
	         * VITTOOLS-383 : BA module no longer in use
	         */
            /*if(runOracleDRBaModule.equalsIgnoreCase("TRUE"))
	        	{
	        	 	Schema oraDRDestSchema = getDestOracleDRSchema(webTransfer,engine);
	        	 	oraDRDestSchema.setHostingServer(Constants.ORACLE_DR_BA_CMA);//this is needed in status.jsp page
	        	 	oraDRDestSchema.setEngineVersion(srcSchema.getEngineVersion());
	        	 
	        	 	 String oracleDRDataFileDir = webTransfer.getString("oracleDRDataFileDir");
	        		 //System.out.println("Data File Directory for Destination Oracle:"+dataFileDirectoy);
	        	 	 
				// settting password for destination oracle schema
				try {
					oraDRDestSchema = engine.setSchemaPassword(oraDRDestSchema);
				} catch (Exception e) {
					logger.error("VerticaDRTransferController.java>>>Error setting schema passsword for destination oracle DR server (BA) using cma by "
							+ loginName);
					StringWriter sw = InsertExceptionToLogger.insert(e, logger); //inserting exception caught to logger.
					//show error in event log
					ComponentFactory.getInstance().getEventLogger().logError(
							loginName,Constants.O2V_DR_CMA_BA_EVENT, getEventDescForDataTransfer(srcSchema, destSchema), 0, startDate, new Date(), sw.toString() , destSchema);
					errorList.add(e.getMessage());
					return retVal;
				}
	        	 	 
				sqlProcessForOracleDRBATransfer = engine.executeTransferForOracleDRBAModules(srcSchema, oraDRDestSchema, oracleDRDataFileDir);
				//sqlProcessForOracleDRBATransfer = engine.executeTransferForBAModules(srcSchema, oraDRDestSchema ,oracleDRDataFileDir);
        	}*/
             
	        executionNumber = engine.getExecutionNumber();
	        //System.out.println("-----------EXECUTION NUMBER FROM VERTICA DR TRANSFER CONTROLLER:"+executionNumber);
	        sqlProcess = engine.executeTransferForVerticaDRUsingCMA(srcSchema,destSchema,executionNumber);
		        
	        
	            
	        SQLPlusRunnable sqlRunnable = sqlProcess.getSQLPlusRunnable();
	        isRefreshAgain = Boolean.TRUE;

	        messageList.add(sqlRunnable.getDescription());
	        
	        TaskType taskType = sqlRunnable.getTaskType();
	        TaskKey taskKey = sqlProcess.getTaskKey();

	        if (( loginName.equals( taskKey.getUserName() )) &&
	            TaskType.DATA_TRANSFER.equals(taskType)) {
	            messageList.add("Operation queued: " + taskType.getTaskLabel());
	        } else {
	            isRefreshAgain = Boolean.FALSE;
	            errorList.add("Schema is already in use for " + taskType );
	            errorList.add("Requested operation is not queued.");
	            errorList.add("Job was scheuled by: " + taskKey.getUserName());  
	        }
	        
	        request.setAttribute("executionNumber", executionNumber);
	        request.setAttribute("isRefreshAgain", isRefreshAgain);
	            
	        return retVal;
	    }

}
