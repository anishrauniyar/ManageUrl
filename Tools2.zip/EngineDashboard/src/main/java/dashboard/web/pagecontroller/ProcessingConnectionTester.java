package dashboard.web.pagecontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dashboard.data.Schema;
import dashboard.data.WebTransfer;
import dashboard.engine.EngineMonitor;


public class ProcessingConnectionTester extends Controller {
    
    public String process(HttpServletRequest request, HttpServletResponse response)
        throws Exception {
        String retVal = "messageList";
        List messageList = ValidatorRoot.getMessageList(request);
        List errorList = ValidatorRoot.getErrorList(request);
        WebTransfer webTransfer = (WebTransfer) request.getAttribute("webTransfer");
        
        Object [] retTestVal = null;
        Object [] histTestVal = null;
        
        EngineMonitor engineMonitor = getEngineMonitor(request);

        Schema schema = (new Schema()).setServerName( webTransfer.getString("host") )
            .setPort( webTransfer.getString("port"))
            .setService( webTransfer.getString("service"))
            .setSchemaName( webTransfer.getString("dbUser"))
            .setDatabaseId(webTransfer.getString("frontDatabaseId"));
            //.setSchemaPwd( webTransfer.getString("dbPassword"));
        String sidFlag = webTransfer.getString("sidFlag");
        
        if (sidFlag != null) {
            schema = schema.setSidFlag( webTransfer.getString("sidFlag"));
        }
        
        String isDiffServer = webTransfer.getString("isDiffServer");
        
        if("Y".equalsIgnoreCase(isDiffServer)){
        	Schema historySchema = (new Schema()).setServerName( webTransfer.getString("histHost") )
			  .setPort( webTransfer.getString("histPort"))
			  .setService( webTransfer.getString("histService"))
			  .setSchemaName( webTransfer.getString("histdbUser"))
			  .setDatabaseId( webTransfer.getString("histdatabaseId"));
			  //.setSchemaPwd( webTransfer.getString("histdbPassword"));

        	String histSidFlag = webTransfer.getString("histSidFlag");
			if(histSidFlag != null){
				historySchema = historySchema.setSidFlag(webTransfer.getString("histSidFlag"));
			}
			// getting password for history schema
			try {
				historySchema = engineMonitor.setSchemaPassword(historySchema);
			} catch (Exception e) {
				logger.error("ProcessConnectionTestor.java>>>Error getting histroy schema password for schema : "
						+ schema.getSchemaName());
				e.printStackTrace();
				errorList.add(e.getMessage());
				return retVal;
			}
			histTestVal = engineMonitor.isValid(historySchema);
			if(Boolean.TRUE.equals( histTestVal[0])){
           	 	ValidatorRoot.getMessageList( request).add("[History Schema]Successfully connected.");
            }else{
           	 	List errors = ValidatorRoot.getErrorList( request);
           	 	errors.add("[History Schema] Connection failure ");
          	     errors.add(histTestVal[1]);
            }
        }
        
		// setting password for front schema
		try {
			schema = engineMonitor.setSchemaPassword(schema);
		} catch (Exception e) {
			logger.error("ProcessConnectionTestor.java>>>Error getting front schema password for schema : "
					+ schema.getSchemaName());
			e.printStackTrace();
			errorList.add(e.getMessage());
			return retVal;
		}
        retTestVal = engineMonitor.isValid(schema);
        if (Boolean.TRUE.equals( retTestVal[0])) {
                 ValidatorRoot.getMessageList( request).add("[Processing Schema]Successfully connected.");
        }else{
        	List errors = ValidatorRoot.getErrorList( request);
        	errors.add("[Processing Schema] Connection failure ");
           	errors.add(retTestVal[1]);
        }
        return retVal;
    }
}