package dashboard.web.pagecontroller.miniEngine;

public interface MiniEngine {
	
	String MINI_ENGINE = "MINI-ENGINE";
}
