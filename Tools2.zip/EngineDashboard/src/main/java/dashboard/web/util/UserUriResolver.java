package dashboard.web.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserUriResolver implements UriResolver {
    String prefix = null;
    public void setPrefix(String pf) {
        prefix = (pf == null)? ".*?": ".*?" + pf.trim();
    }
    String suffix = null;
    public void setSuffix(String sf) {
        suffix = (sf == null) ? "": sf.trim();
    }

    Pattern p = null;;

    private void init() {
        if(p == null ) {
            if( prefix == null || suffix == null
                // || resourcePrefix == null || resourceSuffix == null
                ) {
                throw new IllegalStateException(" both prefix and suffix must be specified.");
            }
            p = Pattern.compile(prefix + "(.*?)" + suffix);
        }
    }

    public String getResolved(String uri) {
        init();
        Matcher m = p.matcher(uri);
        if(m.matches()) {
            return m.group(1);
        }
        System.out.println("Not .. mathced..");
        return "";
    }

}
