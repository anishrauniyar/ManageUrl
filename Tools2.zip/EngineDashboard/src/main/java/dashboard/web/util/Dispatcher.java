package dashboard.web.util;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.RequestDispatcher;

import dashboard.web.view.Page;

public class Dispatcher {
    public void dispatch(ServletRequest request, ServletResponse response, Page pg) throws Exception {
        request.getRequestDispatcher( pg.getResourcePage()).forward( request, response);
    }
}
