package dashboard.web.util;


public interface UriResolver {
    String getResolved(String uri);
    //String getResourceUriFromResolved(String uri);
}
