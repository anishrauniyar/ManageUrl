package dashboard.web.util;

public class VerticaException extends Exception
{
    private String message = "";
    private String event = "";
    
    public VerticaException()
    {
        super();
    }
    
    public VerticaException(String event, String message)
    {
        super(message);
        this.message = message;
        this.event = event;
    }
    
    public VerticaException(String message)
    {
        super(message);
    }
    
    public static void assertError(String event, String message) throws VerticaException
    {
        throw new VerticaException(event, message);
    }
    
    /**
     * @return the event
     */
    public String getEvent()
    {
        return event;
    }
    
    /**
     * @param event
     *            the event to set
     * @return 
     */
    public VerticaException setEvent(String event)
    {
        this.event = event;
        return this;
    }
    
    @Override
    public String toString()
    {
        return this.getEvent()+" "+this.getMessage();
    }
    
}
