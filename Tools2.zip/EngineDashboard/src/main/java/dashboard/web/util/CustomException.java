package dashboard.web.util;

import java.util.List;
import java.util.Map;

public class CustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomException() {
	}

	public CustomException(String message) {
		super(message);
	}

	public static void assertEqualsZero(int value, String message)
			throws CustomException {
		if (value == 0) {
			throw new CustomException(message);
		}
	}

	public static void assertEmptyString(String string, String message)
			throws CustomException {
		if ("".equals(string)) {
			throw new CustomException("Could not get " + message);
		}
	}

	public static void assertNull(Object obj, String message)
			throws CustomException {
		if (null == obj) {
			throw new CustomException(message);
		}
	}

	public static void assertTrue(Boolean obj, String message)
			throws CustomException {
		if (obj) {
			throw new CustomException(message);
		}
	}

	public static void assertFalse(Boolean obj, String message)
			throws CustomException {
		if (!obj) {
			throw new CustomException(message);
		}
	}

	public static void assertError(String message) throws CustomException {
		throw new CustomException(message);
	}

	public static void assertEmptyList(List ls, String message)
			throws CustomException {
		if (ls.isEmpty()) {
			throw new CustomException(message);
		}
	}
	
	public static void assertEmptyMap(Map map, String message)
			throws CustomException {
		if (map.isEmpty()) {
			throw new CustomException(message);
		}
	}
}
