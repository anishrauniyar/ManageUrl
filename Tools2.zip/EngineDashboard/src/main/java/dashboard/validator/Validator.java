package dashboard.validator;

import java.util.Map;

import dashboard.data.Schema;

public interface Validator {

	void validate() throws Exception;

	BaseValidator setOrclSchema(Schema orclSchema);

	Map<String, Boolean> getScripts();

}
