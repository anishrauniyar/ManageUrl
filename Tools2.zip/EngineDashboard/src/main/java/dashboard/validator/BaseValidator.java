package dashboard.validator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import dashboard.ComponentFactory;
import dashboard.data.Schema;
import dashboard.engine.EngineConverter;
import dashboard.engine.EngineMonitor;
import dashboard.security.User;
import dashboard.util.EnvInfo;
import dashboard.web.util.CustomException;

public abstract class BaseValidator implements Validator {

	protected ComponentFactory compFactory;
	protected EngineMonitor engine;
	protected EngineConverter engineConverter;
	protected Schema orclSchema;
	protected EnvInfo env;

	protected String CLIENT_SPECIFIC_SCRIPTS = "CLIENT_SPECIFIC_SCRIPTS";
	protected String CDF_OBJ_SCRIPTS_FOR_HP = "CDF_OBJ_SCRIPTS_FOR_HP";
	protected Map<String, Boolean> scripts;
	protected List<String> scriptsNotFoundInSVN;
	protected Log logger = LogFactory.getLog(getClass());

	protected BaseValidator(User user) {
		compFactory = ComponentFactory.getInstance();
		engine = compFactory.getEngineMonitor(user.getUserName());
		engineConverter = compFactory.getEngineConverter();
		env = compFactory.getEnvInfo();
	}

	/**
	 * @Description : Checks if scripts exists or not in SVN.
	 * @param scriptType
	 * @throws Exception
	 */
	public void validateScriptsExistence(String scriptType) throws Exception {
		File dir = env.getHP_VC_CLIENT_SPECIFIC_MODULES_DIR();
		if (scriptType.equals(CLIENT_SPECIFIC_SCRIPTS)) {
			/*
			 * Get SQL Files related to client specific scripts from database
			 * [HR_GLOBAL_CLIENT_LAYOUT@HAWKEYERULES]
			 */
			scripts = engine.getClientSpecificSQLScripts(orclSchema);
		} else if (scriptType.equals(CDF_OBJ_SCRIPTS_FOR_HP)) {
			/*
			 * Get CDF Object Script for HP from database [ZEDBPARAMS@PROCESSING
			 * WHERE PARAMETERNAME=CDF_OBJ_SCRIPTS_FOR_HP]
			 */
			scripts = engine.getCDFObjScriptsForHP(CDF_OBJ_SCRIPTS_FOR_HP);
		}
		if (scripts.size() > 0) {
			logger.info("Checking scripts existence in SVN");
			/*
			 * Update the file existence [if file found , update value of
			 * respective key to true]
			 */
			scripts = engineConverter.updateFileExistence(orclSchema, dir,
					scripts);
			scriptsNotFoundInSVN = new ArrayList<String>();
			/*
			 * List the scripts that does not exists in SVN and throw exception
			 * if found
			 */
			for (Map.Entry<String, Boolean> entry : scripts.entrySet()) {
				String fileName = entry.getKey();
				Boolean found = entry.getValue();
				// System.out.println(">>>File " + fileName + " found " +
				// found);
				if (!found) {
					// System.out.println("<<<<<<<<<<< " + fileName);
					scriptsNotFoundInSVN.add(fileName);
				}
			}
			// if files are not found in SVN then throw error
			if (scriptsNotFoundInSVN.size() > 0) {
				String error = "Following "+scriptType+" files were not found in checkout location.\nPlease checkout the latest scripts";
				for (int i = 0; i < scriptsNotFoundInSVN.size(); i++) {
					error += i + 1 + ". " + scriptsNotFoundInSVN.get(i) + "\n";
				}
				CustomException.assertError(error);
			}
		}
	}

	public Map<String, Boolean> getScripts() {
		return scripts;
	}

	public Schema getOrclSchema() {
		return orclSchema;
	}

	public BaseValidator setOrclSchema(Schema orclSchema) {
		this.orclSchema = orclSchema;
		return this;
	}

}
