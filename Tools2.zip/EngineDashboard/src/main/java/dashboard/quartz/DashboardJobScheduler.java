package dashboard.quartz;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.KeyMatcher;

import dashboard.quartz.listener.CommonJobListener;
import dashboard.util.ClientSpecficModuleConstants;
import dashboard.util.Constants;

public class DashboardJobScheduler extends BaseJobScheduler {

	private static final String CHECKOUT_CLIENT_SPECIFIC_MODULE = "CheckOutClientSpecMod";
	private static final String GROUP1 = "GROUP1";
	private static final String TRIGGER_FOR_CLIENT_SPECIFIC_MODULE_CHECKOUT = "TriggerForClientSpecModCheckOut";
	private static final String CRON_SCHEDULE_EVERY_MONDAY_10_AM = "0 0 10 ? * MON *";

	// private static final String CRON_SCHEDULE_EVERY_FIVE_MIN =
	// "0 0/5 * 1/1 * ? *";

	// private static final String CRON_SCHEDULE_EVERY_FIVE_SEC =
	// "0/5 * * * * ?";

	/**
	 * @Description: Schedules client specific module checkout only if
	 *               scheduleClientSpecModCheckOut is true
	 */
	public void schedule() {
		Boolean scheduleClientSpecModCheckOut;
		try {
			scheduleClientSpecModCheckOut = (fixedParam
					.getDashboardParams(ClientSpecficModuleConstants.SCHEDULE_CLIENT_SPECIFIC_MODULE_CHECKOUT)
					.equalsIgnoreCase(Constants.TRUE)) ? Boolean.TRUE
					: Boolean.FALSE;
		} catch (Exception e) {
			/*
			 * logger.error(
			 * "DashboardJobScheduler->schedule() [Could not get scheduleClientSpecModCheckOut param ]"
			 * , e);
			 */
			scheduleClientSpecModCheckOut = Boolean.FALSE;
		}
		if (scheduleClientSpecModCheckOut) {
			logger.info("Scheduling client specific module checkout !!!!!!!!");
			String cronExp = "";
			try {
				cronExp = fixedParam
						.getDashboardParams(ClientSpecficModuleConstants.CRON_EXP_FOR_CLIENT_SPECIFIC_MODULES_CHECKOUT);
			} catch (Exception e) {
				logger.error("Error getting cron expression", e);
				logger.info("Setting default cron expression!!!!!!!!!!! "
						+ CRON_SCHEDULE_EVERY_MONDAY_10_AM);
				cronExp = CRON_SCHEDULE_EVERY_MONDAY_10_AM;
			}

			logger.info("Cron Expression is " + cronExp);

			JobKey checkOutClientSpecModJobKey = new JobKey(
					CHECKOUT_CLIENT_SPECIFIC_MODULE, GROUP1);

			JobDetail checkOutClientSpecModJob = JobBuilder
					.newJob(ClientSpecificModuleCheckOutJob.class)
					.withIdentity(checkOutClientSpecModJobKey).build();

			Trigger checkOutClientSpecModTrigger = TriggerBuilder
					.newTrigger()
					.withIdentity(TRIGGER_FOR_CLIENT_SPECIFIC_MODULE_CHECKOUT,
							GROUP1)
					.withSchedule(CronScheduleBuilder.cronSchedule(cronExp))
					.build();

			try {
				Scheduler scheduler = new StdSchedulerFactory().getScheduler();

				// Listener attached to jobKey
				scheduler.getListenerManager().addJobListener(
						new CommonJobListener(),
						KeyMatcher.keyEquals(checkOutClientSpecModJobKey));

				scheduler.start();
				scheduler.scheduleJob(checkOutClientSpecModJob,
						checkOutClientSpecModTrigger);
			} catch (SchedulerException e) {
				e.printStackTrace();
			}
		} else {
			logger.info("No any scheduling done from dashboard!!!!");
		}

	}
}
