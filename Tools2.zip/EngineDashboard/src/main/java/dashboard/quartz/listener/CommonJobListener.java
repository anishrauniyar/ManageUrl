package dashboard.quartz.listener;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

public class CommonJobListener implements JobListener {

	private static final String LISTENER_NAME = "commonJobListener";

	@Override
	public String getName() {
		return LISTENER_NAME;
	}

	@Override
	public void jobExecutionVetoed(JobExecutionContext arg0) {
		System.out.println("jobExecutionVetoed");
	}

	@Override
	public void jobToBeExecuted(JobExecutionContext arg0) {
		String jobName = arg0.getJobDetail().getKey().toString();
		System.out
				.println("\n ---------------DashboardJobScheduler---------------");
		System.out.println("Job : " + jobName + " is going to start...");
	}

	@Override
	public void jobWasExecuted(JobExecutionContext arg0,
			JobExecutionException arg1) {
		System.out.println("jobWasExecuted");

		String jobName = arg0.getJobDetail().getKey().toString();
		System.out.println("Job : " + jobName + " is finished...");

		if (arg1 != null && !arg1.getMessage().equals("")) {
			System.out.println("Exception thrown by: " + jobName
					+ " Exception: " + arg1.getMessage());
			arg1.printStackTrace();
		}
	}

}
