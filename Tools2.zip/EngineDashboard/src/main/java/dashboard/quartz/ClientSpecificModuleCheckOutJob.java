package dashboard.quartz;

import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import dashboard.data.Report;
import dashboard.data.Schema;
import dashboard.data.SourceControlUser;
import dashboard.util.ClientSpecficModuleConstants;
import dashboard.web.pagecontroller.SourceController;

public class ClientSpecificModuleCheckOutJob extends BaseJobScheduler {

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		SourceControlUser scUser;
		String vcUrl;
		String engVersion;
		String loginName = SYSTEM;
		String event = ClientSpecficModuleConstants.CLIENT_SPECIFIC_MODULES_CHKOUT_EVENT;
		Report HPandVCClientSpecificModules;
		String errorDesc = "Checkout Client Specific Modules";
		try {
			scUser = (new SourceControlUser())
					.setUserName(
							fixedParam
									.getDashboardParams(ClientSpecficModuleConstants.SVN_USERNAME))
					.setPassword(
							fixedParam
									.getDashboardParams(ClientSpecficModuleConstants.SVN_PASSWORD));
			vcUrl = fixedParam
					.getDashboardParams(ClientSpecficModuleConstants.SVN_CLIENT_SPECIFIC_MODULES_LOCATION);
			engVersion = fixedParam
					.getDashboardParams(ClientSpecficModuleConstants.ENGINE_VERSION);
			HPandVCClientSpecificModules = new Report()
					.setReportName(
							ClientSpecficModuleConstants.HP_VC_CLIENT_SPECIFIC_MODULES)
					.setReportDesc(
							"HP and VC Client Specific Modules. Location is configured in the application")
					.setSourceDir(
							env.getHP_VC_CLIENT_SPECIFIC_MODULES_DIR()
									.getAbsolutePath());
		} catch (Exception e) {
			eventLogger.logError(loginName, event, errorDesc, 0, new Date(),
					new Date(), e.getMessage(), new Schema());
			throw new JobExecutionException(e.getMessage().toString());
		}
		SourceController.checkOut(scUser, vcUrl, HPandVCClientSpecificModules,
				engVersion, eventLogger, engine, loginName, event);
	}

}
