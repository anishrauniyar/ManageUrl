package dashboard.quartz;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import dashboard.ComponentFactory;
import dashboard.db.EngineMonitorDB;
import dashboard.db.FixedParameter;
import dashboard.engine.EngineMonitor;
import dashboard.engine.EventLogger;
import dashboard.util.EnvInfo;

public abstract class BaseJobScheduler implements Job {

	protected ComponentFactory compFactory;
	protected EnvInfo env;
	protected EngineMonitor engine;
	protected EngineMonitorDB engineMonitorDB;
	protected EventLogger eventLogger;
	protected FixedParameter fixedParam;
	protected final String SYSTEM = "SYSTEM";
	protected Log logger = LogFactory.getLog(getClass());

	public BaseJobScheduler() {
		compFactory = ComponentFactory.getInstance();
		env = compFactory.getEnvInfo();
		engine = compFactory.getEngineMonitor(SYSTEM);
		engineMonitorDB = compFactory.getEngineMonitorDB();
		eventLogger = compFactory.getEventLogger();
		fixedParam = compFactory.getFixedParameters();
	}

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
	}

}
