package dashboard.data;

public class MREPreCheck {
	private String fieldName;
	private String requiredOutput;
	private String result;

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getRequiredOutput() {
		return requiredOutput;
	}

	public void setRequiredOutput(String requiredOutput) {
		this.requiredOutput = requiredOutput;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fieldName == null) ? 0 : fieldName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MREPreCheck other = (MREPreCheck) obj;
		if (fieldName == null) {
			if (other.fieldName != null)
				return false;
		} else if (!fieldName.equalsIgnoreCase(other.fieldName))
			return false;
		return true;
	}

}
