package dashboard.data;

public class Chart {

	private String year;
	private String executeEngineCount;
	private String executeMiniEngineCount;

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getExecuteEngineCount() {
		return executeEngineCount;
	}

	public void setExecuteEngineCount(String executeEngineCount) {
		this.executeEngineCount = executeEngineCount;
	}

	public String getExecuteMiniEngineCount() {
		return executeMiniEngineCount;
	}

	public void setExecuteMiniEngineCount(String executeMiniEngineCount) {
		this.executeMiniEngineCount = executeMiniEngineCount;
	}

}
