package dashboard.data;

public class EngineReplacementData {
    private String
        hawkeyeCode = "",
        hawkeyeHist = "",
        hawkeyePreScrub = "",
        hawkeyeScrub = "",
        hawkeyeFront = "",
        hawkeyeMaster = "",
        hawkeyeQRM = "",
        diffServer="",
        dxcgParam="";

    public EngineReplacementData setHawkeyeCode(String p) {
        hawkeyeCode = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
    public EngineReplacementData setHawkeyeHist(String p) {
        hawkeyeHist = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
    public EngineReplacementData setHawkeyePreScrub(String p) {
        hawkeyePreScrub = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
    public EngineReplacementData setHawkeyeScrub(String p) {
        hawkeyeScrub = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
    public EngineReplacementData setHawkeyeFront(String p) {
        hawkeyeFront = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
    public EngineReplacementData setHawkeyeMaster(String p) {
        hawkeyeMaster = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
    public EngineReplacementData setHawkeyeQRM(String p) {
	hawkeyeQRM = (p!=null)? p.trim().toUpperCase(): "";
        return this;
    }
        
    public String getHawkeyeCode() {
        return hawkeyeCode;
    }
    public String getHawkeyePreScrub() {
        return hawkeyePreScrub;
    }
    public String getHawkeyeScrub() {
        return hawkeyeScrub;
    }
    public String getHawkeyeHist() {
        return hawkeyeHist;
    }
    public String getHawkeyeFront() {
        return hawkeyeFront;
    }
    public String getHawkeyeMaster() {
        return hawkeyeMaster;
    }
    public String getHawkeyeQRM() {
        return hawkeyeQRM;
    }

    public boolean isAllParamSet() {
        return !"".equals(hawkeyeCode) &&
            !"".equals(hawkeyeFront) &&
            !"".equals(hawkeyeHist) &&
            !"".equals(hawkeyePreScrub) &&
            !"".equals(hawkeyeScrub);
    }
	
	public String getDiffServer() {
		return diffServer;
	}
	public EngineReplacementData setDiffServer(String p) {
		diffServer = (p!=null)? p.trim().toUpperCase(): "";
	    return this;
	}
	
	protected Schema schema;
	    public EngineReplacementData setSchema(Schema Schema){
		this.schema = Schema;
		return this;
    }

	public Schema getSchema(){
		return schema ;
	}
	public String getDxcgParam() {
		return dxcgParam;
	}
	public EngineReplacementData setDxcgParam(String p) {
		dxcgParam = (p!=null)? p.trim().toUpperCase(): "";
	    return this;
	}
}