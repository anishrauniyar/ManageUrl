package dashboard.data;

public class DataFileDir {
    private String serverGroupId = "",
        dataFileDir = "",dataFileDirName="";
 

	public DataFileDir(){}

   public String getDataFileDirName() {
		return dataFileDirName;
	}

	public DataFileDir setDataFileDirName(String p) {
		this.dataFileDirName =(null==p)? dataFileDirName : p.trim();
		
		return this;
	}
    public String getServerGroupId() {
        return serverGroupId;
    }
    public String getDataFileDir() {
        return dataFileDir;
    }

    public DataFileDir setServerGroupId(String p) {
        serverGroupId = (null==p)? serverGroupId : p.trim();
        return this;
    }
    public DataFileDir setDataFileDir(String p) {
        dataFileDir = (null==p)? dataFileDir : p.trim();
        return this;
    }

    public String toString() {
        return serverGroupId + "->" + dataFileDir;
    }
}
