package dashboard.data;

public class Schema {

    private String
        clusterGroupId = "",
        clusterGroupName = "",
        serverGroupId = "",
        serverGroupName = "",
        serverName = "",
        port = "1521",
        service = "",
        schemaName = "",
        schemaPwd = "", //default pwd
        engineVersion = "",
        clientName = "",
        dxCGProcess = "",
        encodePassword = "",
		schemaSize = "0",
		database  = "",
		instance = "",
		connection = "",
    	hostingServer = "",
    	databaseId = "",
    	mountedOn = "";
        
    
    public Schema() {}

    public String getDatabase() {
		return database;
	}

	public Schema setDatabase(String database) {
		this.database = database;
		return this;
	}

	public String getInstance() {
		return instance;
	}

	public Schema setInstance(String instance) {
		this.instance = instance;
		return this;
	}

	public String getConnection() {
		return connection;
	}

	public Schema setConnection(String connection) {
		this.connection = connection;
		return this;
	}
	
	public String getHostingServer() {
		return hostingServer;
	}

	public Schema setHostingServer(String hostingServer) {
		this.hostingServer = hostingServer;
		return this;
	}
	
	public String getDatabaseId() {
		return databaseId;
	}

	public Schema setDatabaseId(String databaseId) {
		if( null != databaseId ){
			this.databaseId = databaseId;
		}
		return this;
	}
	
	public Schema setClusterGroupId(String p)
    {
        if(null !=p){
            clusterGroupId = p.trim();
        }
	    return this;
    }
	
    public Schema setClusterGroupName(String p)
    {
        if(null !=p){
            clusterGroupName = p.trim();
        }
        return this;
    }

    public Schema setServerGroupId(String p) {
        if(null != p) {
            serverGroupId = p.trim();
        }
        return this;
    }

    public Schema setServerGroupName(String p) {
        if(null != p) {
            serverGroupName = p.trim();
        }
        return this;
    }

    public Schema setServerName(String p) {
        if(null != p) {
            serverName = p.trim().toUpperCase();
        }
        return this;
    }
    public Schema setPort(String p) {
        if( null != p && !"".equals(p.trim()) ) {
            port = p.trim();
        }
        return this;
    }
    public Schema setService(String p) {
        if(null != p) {
            service = p.trim().toUpperCase();
        }
        return this;
    }
    public Schema setSchemaName(String p) {
        if(null != p) {
            schemaName = p.trim().toUpperCase();
        }
        return this;
    }
    public Schema setSchemaPwd(String p) {
        if (null != p && !"".equals(p.trim()) ) {
            schemaPwd = p.trim();
        }
        return this;
    }    
    
	public Schema setClientName(String clientName) {
		if(null != clientName) {
			this.clientName = clientName.trim();
        }
        return this;
	} 
	
    public Schema setEngineVersion(String engVer) {
        this.engineVersion = engVer;
        return this;
    } 

    
    public String getClusterGroupId(){ return clusterGroupId; }
    public String getClusterGroupName(){ return clusterGroupName; }
    public String getServerGroupId() { return serverGroupId; }
    public String getServerGroupName() { return serverGroupName; }
    public String getServerName() { return  serverName;   }
    public String getPort() { return port; }
    public String getService() { return service; }
    public String getSchemaName() { return schemaName; }
    public String getSchemaPwd() { return schemaPwd; }
    public String getClientName() {return clientName;}
    public String getEngineVersion() {return engineVersion;}
    
    public boolean isPwdSet() {
        return (null != schemaPwd) && !"".equals(schemaPwd);
    }
    public boolean isParamSet() {
        return !"".equals(serverName) && !"".equals(service)
            && !"".equals(schemaName) && !"".equals(schemaPwd);
    }
    public boolean isParamSetExceptPwd() {
        return !"".equals(serverName) && !"".equals(service)
            && !"".equals(schemaName);
    }
    public String toString() {
        return "->" + serverGroupId + ":" + serverName+":" + port +
            "/" + service + ":" + schemaName + "[" + sidFlag + "] [" + serverGroupId + "] ";
    }

    String sidFlag = "Y";
    public Schema setSidFlag(String c) {
        if ( null != c) {
            String p = c.trim().toUpperCase();
            if ("Y".equals(p) ) {
                sidFlag = "Y";
            } else if ("N".equals(p)) {
                sidFlag = "N";
            } else {
                new IllegalArgumentException("Invalid sid flag tried to be set: " + c);
            }
        }
        return this;
    }
    public String getSidFlag() {
        return sidFlag;
    }
    public boolean isSid() {
        return "Y".equals(sidFlag);
    }

    public Schema getCopy() {
        Schema _copy = new Schema();
        _copy.clusterGroupId = clusterGroupId;
        _copy.serverGroupId = serverGroupId;
        _copy.serverGroupName =serverGroupName;
        _copy.serverName = serverName;
        _copy.port = port;
        _copy.service = service;
        _copy.schemaName = schemaName;
        _copy.schemaPwd = schemaPwd;
        _copy.sidFlag=sidFlag;
        _copy.database=database;
        _copy.databaseId=databaseId;
        _copy.engineVersion=engineVersion;
        _copy.clientName=clientName;
        _copy.connection=connection;
        _copy.hostingServer=hostingServer;
        return _copy;
    }

	public String getDxCGProcess() {
		return dxCGProcess;
	}

	public Schema setDxCGProcess(String dxCGProcess) {
		this.dxCGProcess = dxCGProcess;
		return this;
	}

	public String getEncodePassword() {
		return encodePassword;
	}

	public Schema setEncodePassword(String encodePassword) {
		this.encodePassword = encodePassword;
		return this;
	}

	public Schema setSchemaSize(String p) throws NumberFormatException {
		this.schemaSize="0";
		if (null != p) {
			try {
				Integer tempSchemaSize = Integer.parseInt(p.trim());
				this.schemaSize = tempSchemaSize.toString();
			} catch (NumberFormatException e) {
				throw new NumberFormatException();
				
			}
		}
		return this;
	}

	public String getSchemaSize() {
		return schemaSize;
	}
	
	// for dr transfer
	public Schema setSchemaSize(String p,boolean dr){
		if(null!=p){
			this.schemaSize = p;
		}
		return this;
	}

	public String getMountedOn() {
		return mountedOn;
	}

	public Schema setMountedOn(String mountedOn) {
		if(null!=mountedOn){
			this.mountedOn = mountedOn;
		}
		return this;
	}
	
	
}