package dashboard.data;

import java.util.Set;

public interface DataTransfer {

    public DataTransfer setString(String key, String value);
    public String getString(String key);

    public DataTransfer setStringArray(String key, String [] str_array);
    public String [] getStringArray(String key);

    public boolean containsKey(String key) ;
    public Set keySet();

    public DataTransfer remove(String key);
}
