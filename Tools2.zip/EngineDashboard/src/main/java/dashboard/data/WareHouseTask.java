package dashboard.data;

public class WareHouseTask {

	public WareHouseTask() {
	}

	private boolean createSynonymForHPnHR = false;
	private boolean createSynonymForHF = false;
	private boolean compileWHEngine = false;
	private boolean executeWHEngine = false;

	public boolean isCreateSynonymForHPnHR() {
		return createSynonymForHPnHR;
	}

	public void setCreateSynonymForHPnHR(boolean createSynonymForHPnHR) {
		this.createSynonymForHPnHR = createSynonymForHPnHR;
	}

	public boolean isCreateSynonymForHF() {
		return createSynonymForHF;
	}

	public void setCreateSynonymForHF(boolean createSynonymForHF) {
		this.createSynonymForHF = createSynonymForHF;
	}

	public boolean isCompileWHEngine() {
		return compileWHEngine;
	}

	public void setCompileWHEngine(boolean compileWHEngine) {
		this.compileWHEngine = compileWHEngine;
	}

	public boolean isExecuteWHEngine() {
		return executeWHEngine;
	}

	public void setExecuteWHEngine(boolean executeWHEngine) {
		this.executeWHEngine = executeWHEngine;
	}

}
