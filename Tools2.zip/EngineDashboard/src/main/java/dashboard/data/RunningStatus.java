package dashboard.data;

import java.util.List;
import java.util.LinkedList;
import java.util.Collections;

public class RunningStatus {

    private int
        noOfModules = 0,
        completedModules = 0,
        runningModules = 0;
    String uniqueJobId="";


	private static List emptyList = Collections.unmodifiableList(new LinkedList());
    
	
    public RunningStatus() {}
    public RunningStatus setNoOfModules(int p) {
        noOfModules = p;
        return this;
    }
    public RunningStatus setCompletedModules(int p) {
        completedModules = p;
        return this;
    }
    public RunningStatus setRunningModules(int p) {
        runningModules = p;
        return this;
    }
    public String getUniqueJobId() {
		return uniqueJobId;
	}
	public RunningStatus setUniqueJobId(String p) {
		this.uniqueJobId = p;
		return this;

	}
    
    public int getNoOfModules() { return noOfModules;}
    public int getCompletedModules() { return completedModules; }
    public int getRunningModules() { return runningModules; }

    private List statusList = emptyList;
    public RunningStatus setCompletedList(List ls) {
        if (ls != null) {
            statusList = ls;
        }
        return this;
    }

    public List getCompletedList() {
        return statusList;
    }
    public boolean isCompletedAny() {
        return !statusList.isEmpty();
    }
}
