package dashboard.data;

public class Status {
    private String job = "";
    public String getJob() { return job; }
    public Status setJob(String p) {
        if(p!=null) {
            job = p.trim();
        }
        return this;
    }

    private String sid = "";
    public String getSid() { return sid; }
    public Status setSid(String p) {
        if(p!=null) {
            sid = p.trim();
        }
        return this;
    }

    private String failures = "";
    public String getFailures() { return failures; }
    public Status setFailures(String p) {
        if(p!=null) {
            failures = p.trim();
        }
        return this;
    }

    private String broken = "";
    public String getBroken() { return broken; }
    public Status setBroken(String p) {
        if(p!=null) {
            broken = p.trim();
        }
        return this;
    }


    private String what = "";
    public String getWhat() { return what; }
    public Status setWhat(String p) {
        if(p!=null) {
            what = p.trim();
        }
        return this;
    }

    private String event = "";
    public String getEvent() { return event; }
    public Status setEvent(String p) {
        if(p!=null) {
            event = p.trim();
        }
        return this;
    }

    private String p1text = "";
    public String getP1text() { return p1text; }
    public Status setP1text(String p) {
        if(p!=null) {
            p1text = p.trim();
        }
        return this;
    }

    private String p1 = "";
    public String getP1() { return p1; }
    public Status setP1(String p) {
        if(p!=null) {
            p1 = p.trim();
        }
        return this;
    }

    private String p2text = "";
    public String getP2text() { return p2text; }
    public Status setP2text(String p) {
        if(p!=null) {
            p2text = p.trim();
        }
        return this;
    }

    private String p2 = "";
    public String getP2() { return p2; }
    public Status setP2(String p) {
        if(p!=null) {
            p2 = p.trim();
        }
        return this;
    }

    private String p3text = "";
    public String getP3text() { return p3text; }
    public Status setP3text(String p) {
        if(p!=null) {
            p3text = p.trim();
        }
        return this;
    }

    private String p3 = "";
    public String getP3() { return p3; }
    public Status setP3(String p) {
        if(p!=null) {
            p3 = p.trim();
        }
        return this;
    }

    private String waitClass = "";
    public String getWaitClass() { return waitClass; }
    public Status setWaitClass(String p) {
        if(p!=null) {
            waitClass = p.trim();
        }
        return this;
    }

    private String waitTime = "";
    public String getWaitTime() { return waitTime; }
    public Status setWaitTime(String p) {
        if(p!=null) {
            waitTime = p.trim();
        }
        return this;
    }

    private String secondsInWait = "";
    public String getSecondsInWait() { return secondsInWait; }
    public Status setSecondsInWait(String p) {
        if(p!=null) {
            secondsInWait = p.trim();
        }
        return this;
    }

    private String state = "";
    public String getState() { return state; }
    public Status setState(String p) {
        if(p!=null) {
            state = p.trim();
        }
        return this;
    }

	private String dataTransferStatus = "";

	public String getDataTransferStatus() {
		return dataTransferStatus;
	}

	public Status setDataTransferStatus(String dataTransferStatus) {
		this.dataTransferStatus = dataTransferStatus;
		return this;
	}
	
	private String noOfModules;
	public String getNoOfModules() {
		return noOfModules;
	}
	public Status setNoOfModules(String noOfModules) {
		this.noOfModules = noOfModules;
		return this;
	}
	
    
}
