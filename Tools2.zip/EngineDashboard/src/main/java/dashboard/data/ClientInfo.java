package dashboard.data;

public class ClientInfo {
	private String clientId = "",
			clientName = "",
			clientId_Name = "",
			prescrubPlatfrom = "",
			prescrubServer = "",
			vssScrubFolder = "",
			vssImportFolder = "",
			clientType = "",
			clientDataFolder = "";
	
	// setters and getters
	
	public void setClientId(String value){
		clientId = value;
	}
	
	public String getClientId(){
		return clientId;
	}
	
	public void setPrescrubPlatfrom(String value){
		prescrubPlatfrom = value;
	}
	
	public String getPrescrubPlatfrom(){
		return prescrubPlatfrom;
	}
	
	public void setPrescrubServer(String value){
		prescrubServer = value;
	}
	
	public String getPrescrubServer(){
		return prescrubServer;
	}


	public String getClientType() {
		return clientType;
	}

	public void setClientType(String clientType) {
		this.clientType = clientType;
	}

	public String getClientDataFolder() {
		return clientDataFolder;
	}

	public void setClientDataFolder(String clientDataFolder) {
		this.clientDataFolder = clientDataFolder;
	}

	public String getVssScrubFolder() {
		return vssScrubFolder;
	}

	public void setVssScrubFolder(String vssScrubFolder) {
		this.vssScrubFolder = vssScrubFolder;
	}

	public String getVssImportFolder() {
		return vssImportFolder;
	}

	public void setVssImportFolder(String vssImportFolder) {
		this.vssImportFolder = vssImportFolder;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientId_Name() {
		return clientId_Name;
	}

	public void setClientId_Name(String clientId_Name) {
		this.clientId_Name = clientId_Name;
	}	
}
