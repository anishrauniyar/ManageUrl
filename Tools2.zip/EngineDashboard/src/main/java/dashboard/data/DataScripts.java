package dashboard.data;

public class DataScripts {
	private String clientID = "";
	private String processingType = "";
	private String prescrubPlatform;
	private String[] scriptFileName;
	private String[] dataURL;

	public DataScripts setClientID(String value){
		clientID = value;
		return this;
	}
	
	public String getClientID(){
		return clientID;
	}

	public DataScripts setProcessingType(String value){
		processingType = value;
		return this;
	}
	
	public String getProcessingType(){
		return processingType;
	}		
	
	public DataScripts setPrescrubPlatform(String value){
		prescrubPlatform = value;
		return this;
	}

	public String getPrescrubPlatform(){
		return prescrubPlatform;
	}
	
	public DataScripts setScriptFileName(String[] value){
		scriptFileName = value;
		return this;
	}
	
	public String[] getScriptFileName(){
		return scriptFileName;
	}

	public DataScripts setDataURL(String[] value){
		dataURL = value;
		return this;
	}

	public String[] getDataURL(){
		return dataURL;
	}
	
}