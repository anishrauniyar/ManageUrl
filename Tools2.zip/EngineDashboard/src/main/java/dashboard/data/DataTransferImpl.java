package dashboard.data;

import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;

public class DataTransferImpl implements DataTransfer {

    Map m = null;
    public DataTransferImpl() {
        m = new HashMap(10);
    }
    public DataTransfer setString(String key, String value) {
        m.put(key, new String [] {value});
        return this;
    }
    public String getString(String key) {
        return containsKey(key)? ((String []) m.get(key))[0] : null;
    }
    public DataTransfer setStringArray(String key, String [] str_array) {
        m.put(key, str_array);
        return this;
    }
    public String [] getStringArray(String key) {
        return containsKey(key)? (String []) m.get(key) : null;
    }
    public boolean containsKey(String key) {
        return m.containsKey(key);
    }
    public Set keySet() {
        return Collections.unmodifiableSet(m.keySet());
    }
    public DataTransfer remove(String key) {
        m.remove(key);
        return this;
    }
    public String toString() {
        StringBuffer sb = new StringBuffer();
        Iterator it = m.keySet().iterator();
        while(it.hasNext()) {
            Object key = it.next();
            String [] values = (String []) m.get(key);
            for(int i=0; i<values.length; i++) {
                sb.append(key).append("=").append(values[i]).append('&');
            }
        }
        return sb.toString();
    }
}
