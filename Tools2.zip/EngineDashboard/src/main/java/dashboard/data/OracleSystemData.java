package dashboard.data;

import java.util.Collections;
import java.util.List;
import java.util.LinkedList;


/**
 * Represents the oracle database server status.
 */
public class OracleSystemData {

    private static List emptyList = Collections.unmodifiableList( new LinkedList());

    List memList = emptyList;
    List storageList = emptyList;
    List osList = emptyList;

    /**
     * @param list containing memeory distribution.
     *        ( each element contains sganame, sgasize in an array).
     */
    public OracleSystemData setMemoryDistribution(List ls) {
        if (null != ls) {
            memList = ls;
        }
        return this;
    }
    /**
     * @param list containing storage metrics
     *          (each element contains file system name, file system size in MB, % free in an array)
     */
    public OracleSystemData setStorageMetrics(List ls) {
        if (null != ls) {
            storageList = ls;
        }        
        return this;
    }

    /**
     * @param list containing OS metrics
     *          (each element contains metrics name and metrics value in an array)
     */
    
    public OracleSystemData setOSMetrics(List ls) {
        if (null != ls) {
            osList = ls;
        }
        return this;
    }

    public List getMemoryDistribution() {
        return memList;
    }
    public List getStorageMetrics() {
        return storageList;
    }
    public List getOSMetrics() {
        return osList;
    }
}
