package dashboard.data;

public class LDAP {
	private String ldap_name = "", 
				   ldap_url = "", 
				   authentication_type = "",
				   principal = "",
				   ldap_detail = "",
				   ldap_location = "";

	public String getLdap_name() {
		return ldap_name;
	}

	public void setLdap_name(String ldap_name) {
		this.ldap_name = ldap_name;
	}

	public String getLdap_url() {
		return ldap_url;
	}

	public void setLdap_url(String ldap_url) {
		this.ldap_url = ldap_url;
	}

	public String getAuthentication_type() {
		return authentication_type;
	}

	public void setAuthentication_type(String authentication_type) {
		this.authentication_type = authentication_type;
	}

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getLdap_detail() {
		return ldap_detail;
	}

	public void setLdap_detail(String ldap_detail) {
		this.ldap_detail = ldap_detail;
	}

	public String getLdap_location() {
		return ldap_location;
	}

	public void setLdap_location(String ldap_location) {
		this.ldap_location = ldap_location;
	}
	
}
