package dashboard.data;

import dashboard.util.ErrorOnQuote;
import dashboard.util.ErrorOnDoubleQuote;

public class SourceControlUser {
    
    public SourceControlUser() {
    }

    private String userName = null;
    private String pwd = null;

    public SourceControlUser setUserName(String un) {
        if (un != null && !"".equals( un.trim())) {
            userName = un.trim();
            ErrorOnQuote.containsQuote(userName);
            ErrorOnDoubleQuote.containsDoubleQuote(userName);
        }
        return this;
    }

    public String getUserName() {
        return userName;
    }
    
    public SourceControlUser setPassword(String p) {
        if ( null != p && !"".equals(p.trim()) ) {
            pwd = p.trim();
            ErrorOnQuote.containsQuote(pwd);
            ErrorOnDoubleQuote.containsDoubleQuote(pwd);
        }
        return this;
    }

    public String getPassword() {
        return pwd;
    }

    public boolean isAllParamSet() {
        return userName != null && pwd != null;
    }

}
