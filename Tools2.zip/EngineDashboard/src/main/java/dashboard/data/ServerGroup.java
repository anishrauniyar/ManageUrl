package dashboard.data;

import java.io.Serializable;

public class ServerGroup implements Serializable,Comparable<ServerGroup>
{
    private String serverGroupId = "", groupName = "", category = "";
    
    private double percentFreeSpace = 0, total_space_mb = 0, projection_count = 0;
    
    public String getServerGroupId()
    {
        return serverGroupId;
    }
    
    public String getGroupName()
    {
        return groupName;
    }
    
    public String getCategory()
    {
        return category;
    }
    
    public ServerGroup setServerGroupId(String p)
    {
        if (p != null)
        {
            serverGroupId = p.trim();
        }
        return this;
    }
    
    public ServerGroup setGroupName(String p)
    {
        if (p != null)
        {
            groupName = p.trim();
        }
        return this;
    }
    
    public ServerGroup setCategory(String p)
    {
        if (p != null)
        {
            category = p.trim();
        }
        return this;
    }
    
    public double getPercentFreeSpace()
    {
        return percentFreeSpace;
    }
    
    public ServerGroup setPercentFreeSpace(double percentFreeSpace)
    {
        this.percentFreeSpace = percentFreeSpace;
        return this;
    }
    
    public double getTotal_space_mb()
    {
        return total_space_mb;
    }
    
    public ServerGroup setTotal_space_mb(double total_space_mb)
    {
        this.total_space_mb = total_space_mb;
        return this;
    }
    
    public double getProjection_count()
    {
        return projection_count;
    }
    
    public ServerGroup setProjection_count(double projection_count)
    {
        this.projection_count = projection_count;
        return this;
    }
    
    // Over ride equals method
    @Override
    public boolean equals(Object arg0)
    {
        // System.out.println("m called!!!!!!!!!!!");
        if (arg0 == null)
            return false;
        if (!(arg0 instanceof ServerGroup))
            return false;
        
        ServerGroup serverGroup = (ServerGroup) arg0;
        if (serverGroup.getServerGroupId().equalsIgnoreCase(this.getServerGroupId()))
        {
            return true;
        } else
        {
            return false;
        }
        
    }

    @Override
    public int compareTo(ServerGroup o)
    {
        return this.groupName.compareTo(o.groupName);
    }
    
}
