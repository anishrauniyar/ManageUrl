package dashboard.data;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import dashboard.util.EDBUtil;


public class LogData {

    protected  String
        loginName = "",
        eventName = "",
        eventDesc = "",
        sysMessage = "",
        retVal = "",
        serverGroupId = "",
        host = "",
        port = "",
        service = "",
        sidFlag = "",
        schemaName = "",
        engineVersion = "";
    
    
    protected Long  executionNumber =(long)0;
    protected int
        threadCount = 1;

    protected Date
        startTime = null,
        endTime = null;

    public LogData() {
    }
    private static final String DATE_PATTERN = "MMM d, yyyy HH:mm:ss a";

    private static final SimpleDateFormat DEFAULT_DF = new SimpleDateFormat( DATE_PATTERN);

    private DateFormat df = DEFAULT_DF;

    public LogData setDateFormat(DateFormat _df) {
        if ( null != _df) {
            df = _df;
        }
        return this;
    }
    
    public String getLoginName () {
        return loginName ;
    }
    public String getEventName () {
        return eventName ;
    }
    public String getEventDesc () {
        return eventDesc ;
    }
    public String getSysMessage () {
        return sysMessage ;
    }

    public int getThreadCount() {
        return threadCount;
    }
    public String getReturnValue() {
        return retVal;
    }
    public Date getStartTime() {
        return startTime;
    }
    public Date getEndTime() {
        return endTime;
    }
    public String getFormattedStartTime() {
        if (null == startTime) return "";
        return df.format(startTime);
    }
    public String getFormattedEndTime() {
        if (null == endTime) return "";
        return df.format(endTime);
    }
    public String getTimeDifference(){
    	if(null==startTime || null==endTime)
    		return "";
    	return EDBUtil.getTimeDifference(startTime,endTime);
    }
    public String getServerGroupId() {
        return serverGroupId;
    }
    public String getHost() {
        return host;
    }
    public String getPort() {
        return port;
    }
    public String getService() {
        return service;
    }
    public String getSidFlag() {
        return sidFlag;
    }
    public String getSchemaName () {
        return schemaName ;
    }
    public String getEngineVersion() {
		return engineVersion;
	}

    public Long getExecutionNumber() {
		return executionNumber;
	}

	public LogData setLoginName(String p) {
        loginName = (null != p)? p : loginName;
        return this;
    }
    public LogData setEventName(String p) {
        eventName = (null != p)? p : eventName;
        return this;
    }
    public LogData setEventDesc(String p) {
        eventDesc = (null != p)? p : eventDesc;
        return this;
    }
    public LogData setSysMessage(String p) {
        sysMessage = (null != p)? p : sysMessage;
        return this;
    }

    public LogData setThreadCount(int p) {
        threadCount = p;
        return this;
    }
    public LogData setReturnValue(String p) {
        retVal = (null != p)? p: retVal;
        return this;
    }
    public LogData setStartTime(Date p) {
        startTime = (null != p)? p : startTime;
        return this;
    }
    public LogData setEndTime(Date p) {
        endTime = (null != p)? p : endTime;
        return this;
    }

    public LogData setServerGroupId(String p) {
        serverGroupId = (null != p)? p : serverGroupId;
        return this;
    }
    public LogData setHost(String p) {
        host = (null != p)? p : host;
        return this;
    }
    public LogData setPort(String p) {
        port = (null != p)? p : port;
        return this;
    }
    public LogData setService(String p) {
        service = (null != p)? p : service;
        return this;
    }
    public LogData setSidFlag(String p) {
        sidFlag = (null != p)? p : sidFlag;
        return this;
    }
    public LogData setSchemaName(String p) {
        schemaName = (null != p)? p : schemaName;
        return this;
    }	
	public LogData setEngineVersion(String p) {		
		engineVersion = (null != p)? p : engineVersion;
		return this;
	}
	public LogData setExecutionNumber(Long executionNumber) {
		this.executionNumber = executionNumber;
		return this;
	}
 
}
