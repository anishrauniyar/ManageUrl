package dashboard.data;

public class DataTransferLog {
	private String clientId = "",
			importServer = "",
			transferLoc = "",
			dataMonth = "",
			transferDate = "";
	
	public void setClientId(String value){
		clientId = value;
	}
	
	public String getClientId(){
		return clientId;
	}

	public void setImportServer(String value){
		importServer = value;
	}
	
	public String getImportServer(){
		return importServer;
	}	
	
	public void setTransferLoc(String value){
		if(!value.endsWith("/")){
			value += "/";
		}
		transferLoc = value;
	}
	
	public String getTransferLoc(){
		return transferLoc;
	}	

	public void setTransferDate(String value){
		transferDate = value;
	}
	
	public String getTransferDate(){
		return transferDate;
	}

	public void setDataMonth(String value) {
		dataMonth = value;
	}

	public String getDataMonth() {
		return dataMonth;
	}

}
