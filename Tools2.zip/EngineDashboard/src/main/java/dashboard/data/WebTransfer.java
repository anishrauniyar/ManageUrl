package dashboard.data;

/*
 * Required for compatibility and representing
 * web request specific data.
 */

public class WebTransfer extends DataTransferImpl {

}
