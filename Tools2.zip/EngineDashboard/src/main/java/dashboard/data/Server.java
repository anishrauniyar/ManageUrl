package dashboard.data;

public class Server {

    private String
        clusterGroupId = "",
        clusterGroupName = "",
        serverGroupId = "",
        host = "",
        service = "",
		TTS_DIR_DUMP_ORA = "DIR_TTS_DUMP",
        TTS_DIR_DUMP_PHYS = "/home/oracle/tts_dump",
        UTILITY_USER = "Utility",
        UTILITY_PASS = "oracle",
        remote_Link="",
        connection="",//for processing oracle server and vertica server
    	database="",// for vertica server
    	instance="",//for dmexpress server
    	hostingServer="",//(ORACLE,VERTICA,DMEXPRESS))
    	databaseId="",
    	isVip="N";//for vip nodes [VERTICA]
    	
    private boolean processingOracleServer =false;
    
	private int port = 1521;
	
    public Server getCopy()
    {
        Server _copy = new Server();
        _copy.clusterGroupId = clusterGroupId;
        _copy.clusterGroupName = clusterGroupName;
        _copy.serverGroupId = serverGroupId;
        _copy.databaseId = databaseId;
        _copy.host = host;
        _copy.port = port;
        _copy.database = database;
        _copy.service = service;
        _copy.isVip = isVip;
        return _copy;
    }

	public String getTTS_DIR_DUMP_ORA() {
		return TTS_DIR_DUMP_ORA;
	}

	public Server setTTS_DIR_DUMP_ORA(String tts_dir_dump_ora) {
		if(null!=tts_dir_dump_ora)TTS_DIR_DUMP_ORA = tts_dir_dump_ora;
		return this;
	}

	public String getTTS_DIR_DUMP_PHYS() {
		return TTS_DIR_DUMP_PHYS;
	}

	public Server setTTS_DIR_DUMP_PHYS(String tts_dir_dump_phys) {
		if(null!=tts_dir_dump_phys)TTS_DIR_DUMP_PHYS = tts_dir_dump_phys;
		return this;
	}

	public String getUTILITY_PASS() {
		return UTILITY_PASS;
	}

	public Server setUTILITY_PASS(String utility_pass) {
		if(null!=utility_pass)UTILITY_PASS = utility_pass;
		return this;
	}

	public String getUTILITY_USER() {
		return UTILITY_USER.toLowerCase();
	}

	public Server setUTILITY_USER(String utility_user) {
		if(utility_user!=null)UTILITY_USER = utility_user;
		return this;
	}
    public Server(){}

    public String getServerGroupId() {
        return serverGroupId;
    }
    public String getClusterGroupId(){
        return clusterGroupId;
    }
    public String getClusterGroupName(){
        return clusterGroupName;
    }
    public String getHost() {
        return host;
    }
    public String getService() {
        return service;
    }
    public int getPort() {
        return port;
    }


    public Server setServerGroupId(String p) {
        if ( null != p ) {
            serverGroupId = p.trim();
        }
        return this;
    }
    public Server setClusterGroupId(String p){
        if( null !=p )
        {
            this.clusterGroupId = p.trim();
        }
        return this;
    }
    public Server setClusterGroupName(String p){
        if( null !=p )
        {
            this.clusterGroupName = p.trim();
        }
        return this;
    }

    public Server setHost(String p) {
        if ( null != p ) {
            host = p.trim();
        }
        return this;
    }
    public Server setService(String p) {
        if ( null != p ) {
            service = p.trim();
        }
        return this;
    }
    public Server setPort(int p) {
        port = p;
        return this;
    }


    String sidFlag = "Y";
    public Server setSidFlag(String c) {
        if ( null != c) {
            String p = c.trim().toUpperCase();
            if ("Y".equals(p) ) {
                sidFlag = "Y";
            } else if ("N".equals(p)) {
                sidFlag = "N";
            } else {
                new IllegalArgumentException("Invalid sid flag tried to be set: " + c);
            }
        }
        return this;
    }
    public String getSidFlag() {
        return sidFlag;
    }
    public boolean isSid() {
        return "Y".equals(sidFlag);
    }
    
    public String getRemote_Link() {
		return remote_Link;
	}

	public Server setRemote_Link(String p) {
		
		if(p!=null)this.remote_Link = p;
		return this;
	}
	
	public String getConnection() {
		return connection;
	}

	public Server setConnection(String connection) {
		this.connection = connection;
		return this;
	}

	public String getDatabase() {
		return database;
	}

	public Server setDatabase(String database) {
		if(database!=null)
		{
		    this.database = database.trim();
		}
	    return this;
	}

	public String getInstance() {
		return instance;
	}

	public Server setInstance(String instance) {
		this.instance = instance;
		return this;
	}
	
	public String getDatabaseId() {
		return databaseId;
	}

	public Server setDatabaseId(String databaseId) {
		if(null!=databaseId){
			this.databaseId = databaseId.trim();
		}
		return this;
	}
	
	public String getIsVip()
    {
        return isVip;
    }

    public Server setIsVip(String isVip)
    {
        this.isVip = isVip;
        return this;
    }

    public String getHostingServer() {
		return hostingServer;
	}

	public Server setHostingServer(String hostingServer) {
		this.hostingServer = hostingServer;
		return this;
	}

	public boolean isProcessingOracleServer() {
		return processingOracleServer;
	}

	public Server setProcessingOracleServer(boolean processingOracleServer) {
		this.processingOracleServer = processingOracleServer;
		return this;
	}

	public String toString() {
        return serverGroupId + ":" + host + ":" + port + "/" + service + " sidFlag:" + sidFlag +" vipFlag:" + isVip;
    }

}
