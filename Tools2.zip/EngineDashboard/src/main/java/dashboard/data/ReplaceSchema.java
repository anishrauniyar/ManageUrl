package dashboard.data;


public class ReplaceSchema {
    private String
    hawkeyeMaster = "",
    hawkeyeQRM = "";
    boolean replaceHawkeyeMaster = false;
    boolean replaceHawkeyeQRM = false;
    
    public ReplaceSchema setHawkeyeMaster(String p) {
        if(null != p) {
            hawkeyeMaster = p.trim().toUpperCase();
        }
        return this;
    }
    
    public ReplaceSchema setHawkeyeQRM(String p) {
        if(null != p) {
            hawkeyeQRM = p.trim().toUpperCase();
        }
        return this;
    }
    
	public ReplaceSchema setReplaceHawkeyeMaster(boolean replaceHawkeyeMaster) {
		this.replaceHawkeyeMaster = replaceHawkeyeMaster;
		return this;
	}

	
	public ReplaceSchema setReplaceHawkeyeQRM(boolean replaceHawkeyeQRM) {
		this.replaceHawkeyeQRM = replaceHawkeyeQRM;
		return this;
	}
    
    public String getHawkeyeMaster() { return hawkeyeMaster; }
    public String getHawkeyeQRM() { return hawkeyeQRM; }
	public boolean isReplaceHawkeyeMaster() {return replaceHawkeyeMaster;}
	public boolean isReplaceHawkeyeQRM() {return replaceHawkeyeQRM;}  
    
}
