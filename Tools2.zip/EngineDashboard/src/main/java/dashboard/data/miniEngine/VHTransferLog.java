package dashboard.data.miniEngine;

/**
 * @Description : For Mini Engine Output Transfer Log [CDF OUT Transfer]
 *
 */
public class VHTransferLog {

	private String src_schema_name;
	private String dest_schema_name;
	private String server;
	private String table_name;
	private String source_count;
	private String dest_count;
	private String query_status;
	private String query_time;

	public String getSrc_schema_name() {
		return src_schema_name;
	}

	public VHTransferLog setSrc_schema_name(String src_schema_name) {
		this.src_schema_name = src_schema_name;
		return this;
	}

	public String getDest_schema_name() {
		return dest_schema_name;
	}

	public VHTransferLog setDest_schema_name(String dest_schema_name) {
		this.dest_schema_name = dest_schema_name;
		return this;
	}

	public String getServer() {
		return server;
	}

	public VHTransferLog setServer(String server) {
		this.server = server;
		return this;
	}

	public String getTable_name() {
		return table_name;
	}

	public VHTransferLog setTable_name(String table_name) {
		this.table_name = table_name;
		return this;
	}

	public String getSource_count() {
		return source_count;
	}

	public VHTransferLog setSource_count(String source_count) {
		this.source_count = source_count;
		return this;
	}

	public String getDest_count() {
		return dest_count;
	}

	public VHTransferLog setDest_count(String dest_count) {
		this.dest_count = dest_count;
		return this;
	}

	public String getQuery_status() {
		return query_status;
	}

	public VHTransferLog setQuery_status(String query_status) {
		this.query_status = query_status;
		return this;
	}

	public String getQuery_time() {
		return query_time;
	}

	public VHTransferLog setQuery_time(String query_time) {
		this.query_time = query_time;
		return this;
	}

}
