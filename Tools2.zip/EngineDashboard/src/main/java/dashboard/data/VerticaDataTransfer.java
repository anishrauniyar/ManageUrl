package dashboard.data;

import java.sql.Timestamp;

public class VerticaDataTransfer {

	private Long execNo;

	// error details
	private String errorSource;
	private String tableName;
	private String errorType;
	private String errorMessage;

	public Long getExecNo() {
		return execNo;
	}

	public VerticaDataTransfer setExecNo(Long execNo) {
		this.execNo = execNo;
		return this;
	}

	public String getErrorSource() {
		return errorSource;
	}

	public VerticaDataTransfer setErrorSource(String errorSource) {
		this.errorSource = errorSource;
		return this;
	}

	public String getTableName() {
		return tableName;
	}

	public VerticaDataTransfer setTableName(String tableName) {
		this.tableName = tableName;
		return this;
	}

	public String getErrorType() {
		return errorType;
	}

	public VerticaDataTransfer setErrorType(String errorType) {
		this.errorType = errorType;
		return this;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public VerticaDataTransfer setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
		return this;
	}

	// event details
	private String eventDescription;
	private Timestamp startTime;
	private Timestamp endTime;

	public String getEventDescription() {
		return eventDescription;
	}

	public VerticaDataTransfer setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
		return this;
	}

	public Timestamp getStartTime() {
		return startTime;
	}

	public VerticaDataTransfer setStartTime(Timestamp startTime) {
		this.startTime = startTime;
		return this;
	}

	public Timestamp getEndTime() {
		return endTime;
	}

	public VerticaDataTransfer setEndTime(Timestamp endTime) {
		this.endTime = endTime;
		return this;
	}

	// transfer details

	private String app_id;
	private String execMode;
	private String srcSchemaId;
	private String srcSchemaName;
	private String destSchemaId;
	private String destSchemaName;
	private String srcObjName;
	private String destObjName;
	private String objType;
	private String taskName;
	private String srcRecCount;
	private String cpyRecCount;
	private String  destRecCount;
	private String srcTableSize;
	private String cpyTableSize;
	private String destTableSize;
	private String srcRecLength;
	private String cpyRecLength;
	private String desRecLength;
	private String execTime;
	private String CPUTime;
	private String isTransferred;
	private String jobId;
	private String dest_ip;
	private String src_ip;

	public String getApp_id() {
		return app_id;
	}

	public VerticaDataTransfer setApp_id(String app_id) {
		this.app_id = app_id;
		return this;
	}

	public String getExecMode() {
		return execMode;
	}

	public VerticaDataTransfer setExecMode(String execMode) {
		this.execMode = execMode;
		return this;
	}

	public String getSrcSchemaId() {
		return srcSchemaId;
	}

	public VerticaDataTransfer setSrcSchemaId(String srcSchemaId) {
		this.srcSchemaId = srcSchemaId;
		return this;
	}

	public String getSrcSchemaName() {
		return srcSchemaName;
	}

	public VerticaDataTransfer setSrcSchemaName(String srcSchemaName) {
		this.srcSchemaName = srcSchemaName;
		return this;
	}

	public String getDestSchemaId() {
		return destSchemaId;
	}

	public VerticaDataTransfer setDestSchemaId(String destSchemaId) {
		this.destSchemaId = destSchemaId;
		return this;
	}

	public String getDestSchemaName() {
		return destSchemaName;
	}

	public VerticaDataTransfer setDestSchemaName(String destSchemaName) {
		this.destSchemaName = destSchemaName;
		return this;
	}

	public String getSrcObjName() {
		return srcObjName;
	}

	public VerticaDataTransfer setSrcObjName(String srcObjName) {
		this.srcObjName = srcObjName;
		return this;
	}

	public String getDestObjName() {
		return destObjName;
	}

	public VerticaDataTransfer setDestObjName(String destObjName) {
		this.destObjName = destObjName;
		return this;
	}

	public String getObjType() {
		return objType;
	}

	public VerticaDataTransfer setObjType(String objType) {
		this.objType = objType;
		return this;
	}

	public String getTaskName() {
		return taskName;
	}

	public VerticaDataTransfer setTaskName(String taskName) {
		this.taskName = taskName;
		return this;
	}

	public String getSrcRecCount() {
		return srcRecCount;
	}

	public VerticaDataTransfer setSrcRecCount(String srcRecCount) {
		this.srcRecCount = srcRecCount;
		return this;
	}

	public String getCpyRecCount() {
		return cpyRecCount;
	}

	public VerticaDataTransfer setCpyRecCount(String cpyRecCount) {
		this.cpyRecCount = cpyRecCount;
		return this;
	}

	public String getDestRecCount() {
		return destRecCount;
	}

	public VerticaDataTransfer setDestRecCount(String destRecCount) {
		this.destRecCount = destRecCount;
		return this;
	}

	public String getSrcTableSize() {
		return srcTableSize;
	}

	public VerticaDataTransfer setSrcTableSize(String srcTableSize) {
		this.srcTableSize = srcTableSize;
		return this;
	}

	public String getCpyTableSize() {
		return cpyTableSize;
	}

	public VerticaDataTransfer setCpyTableSize(String cpyTableSize) {
		this.cpyTableSize = cpyTableSize;
		return this;
	}

	public String getDestTableSize() {
		return destTableSize;
	}

	public VerticaDataTransfer setDestTableSize(String destTableSize) {
		this.destTableSize = destTableSize;
		return this;
	}

	public String getSrcRecLength() {
		return srcRecLength;
	}

	public VerticaDataTransfer setSrcRecLength(String srcRecLength) {
		this.srcRecLength = srcRecLength;
		return this;
	}

	public String getCpyRecLength() {
		return cpyRecLength;
	}

	public VerticaDataTransfer setCpyRecLength(String cpyRecLength) {
		this.cpyRecLength = cpyRecLength;
		return this;
	}

	public String getDesRecLength() {
		return desRecLength;
	}

	public VerticaDataTransfer setDesRecLength(String desRecLength) {
		this.desRecLength = desRecLength;
		return this;
	}

	public String getExecTime() {
		return execTime;
	}

	public VerticaDataTransfer setExecTime(String execTime) {
		this.execTime = execTime;
		return this;
	}

	public String getCPUTime() {
		return CPUTime;
	}

	public VerticaDataTransfer setCPUTime(String cPUTime) {
		CPUTime = cPUTime;
		return this;
	}

	public String getIsTransferred() {
		return isTransferred;
	}

	public VerticaDataTransfer setIsTransferred(String isTransferred) {
		this.isTransferred = isTransferred;
		return this;
	}

	public String getJobId() {
		return jobId;
	}

	public VerticaDataTransfer setJobId(String jobId) {
		this.jobId = jobId;
		return this;
	}

	public String getDest_ip() {
		return dest_ip;
	}

	public VerticaDataTransfer setDest_ip(String dest_ip) {
		this.dest_ip = dest_ip;
		return this;
	}

	public String getSrc_ip() {
		return src_ip;
	}

	public VerticaDataTransfer setSrc_ip(String src_ip) {
		this.src_ip = src_ip;
		return this;
	}

	// table details
	private int tableSize;

	private String totalTablesAndSize;
	private int totalTables;
	private int totalTableSize;

	public int getTableSize() {
		return tableSize;
	}

	public VerticaDataTransfer setTableSize(int tableSize) {
		this.tableSize = tableSize;
		return this;
	}

	public String getTotalTablesAndSize() {
		return totalTablesAndSize;
	}

	public VerticaDataTransfer setTotalTablesAndSize(String totalTablesAndSize) {
		this.totalTablesAndSize = totalTablesAndSize;
		return this;
	}

	public int getTotalTables() {
		return totalTables;
	}

	public VerticaDataTransfer setTotalTables(int totalTables) {
		this.totalTables = totalTables;
		return this;
	}

	public int getTotalTableSize() {
		return totalTableSize;
	}

	public VerticaDataTransfer setTotalTableSize(int totalTableSize) {
		this.totalTableSize = totalTableSize;
		return this;
	}
	
	//transfer summary
	private String transferStatus;
	private long src_obj_name;
	private long src_table_size;

	public String getTransferStatus() {
		return transferStatus;
	}

	public VerticaDataTransfer setTransferStatus(String transferStatus) {
		this.transferStatus = transferStatus;
		return this;
	}

	public long getSrc_obj_name() {
		return src_obj_name;
	}

	public VerticaDataTransfer setSrc_obj_name(long src_obj_name) {
		this.src_obj_name = src_obj_name;
		return this;
	}

	public long getSrc_table_size() {
		return src_table_size;
	}

	public VerticaDataTransfer setSrc_table_size(long src_table_size) {
		this.src_table_size = src_table_size;
		return this;
	}
}
