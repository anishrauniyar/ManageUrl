package dashboard.data;

public class TempTablespace {
    private String serverGroupId = "",
        tempTablespace = "";
    public TempTablespace(){}

    public String getServerGroupId() {
        return serverGroupId;
    }
    public String getTempTablespace() {
        return tempTablespace;
    }

    public TempTablespace setServerGroupId(String p) {
        serverGroupId = (null==p)? serverGroupId : p.trim();
        return this;
    }
    public TempTablespace setTempTablespace(String p) {
        tempTablespace = (null==p)? tempTablespace : p.trim();
        return this;
    }

    public String toString() {
        return serverGroupId + "->" + tempTablespace;
    }

}
