package dashboard.data;

public class EngineTask {
    private boolean
        runObjectScript = false,
        compileEngine = false,
        executeEngine = false,
    	runIndex = false,    	
    	runReport = false,
    	runFQCReport = false,
    	runDXCGRecordCount = false,
    	runPreCheck = false;
    public EngineTask setRunObjectScript( boolean p) {
        runObjectScript = p;
        return this;
    }
    public boolean isRunObjectScript() {
        return runObjectScript;
    }

    public EngineTask setCompileEngine( boolean p) {
        compileEngine = p;
        return this;
    }
    public boolean isCompileEngine() {
        return compileEngine;
    }

    public EngineTask setExecuteEngine( boolean p) {
        executeEngine = p;
        return this;
    }
    public boolean isExecuteEngine() {
        return executeEngine;
    }

    public boolean isAnyTaskSet() {
        return runObjectScript && compileEngine && executeEngine && runIndex;
    }
	public boolean isRunIndex() {
		return runIndex;
	}
	public EngineTask setRunIndex(boolean runIndex) {
		this.runIndex = runIndex;
		return this;
    }
	
	public boolean isRunReport() {
		return runReport;
	}
	public EngineTask setRunReport(boolean runReport) {
		this.runReport = runReport;
		return this;
	}
	public boolean isRunFQCReport() {
		return runFQCReport;
	}
	public EngineTask setRunFQCReport(boolean runFQCReport) {
		this.runFQCReport = runFQCReport;
		return this;
	}
	public boolean isRunDXCGRecordCount(){
		return runDXCGRecordCount;
	}
	public EngineTask setRunDXCGRecordCount(boolean runDXCGRecordCount){
		this.runDXCGRecordCount = runDXCGRecordCount;
		return this;
	}
	public boolean isRunPreCheck() {
		return runPreCheck;
	}
	public EngineTask setRunPreCheck(boolean runPreCheck) {
		this.runPreCheck = runPreCheck;
		return this;
	}
	

}
