package dashboard.data;

public class ClusterGroup implements Comparable<ClusterGroup>
{
    private String clusterGroupId = "", groupName = "", category = "";
    
    public String getClusterGroupId()
    {
        return clusterGroupId;
    }
    
    public ClusterGroup setClusterGroupId(String clusterGroupId)
    {
        if (clusterGroupId != null)
        {
            this.clusterGroupId = clusterGroupId.toUpperCase();
        }
        return this;
    }
    
    public String getGroupName()
    {
        return groupName;
    }
    
    public ClusterGroup setGroupName(String groupName)
    {
        if (groupName != null)
        {
            this.groupName = groupName.toUpperCase();
        }
        return this;
    }
    
    public String getCategory()
    {
        return category;
    }
    
    public ClusterGroup setCategory(String category)
    {
        if (category != null)
        {
            this.category = category.toUpperCase();
        }
        return this;
    }
    
    public String toString()
    {
        return groupName;
    }
    
    @Override
    public int compareTo(ClusterGroup o)
    {
        return this.groupName.compareTo(o.groupName);
    }
    
}
