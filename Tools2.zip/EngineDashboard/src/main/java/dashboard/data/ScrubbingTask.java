package dashboard.data;

public class ScrubbingTask {
	private boolean runObjectScript = false;
	private boolean runClientScript = false;

	public boolean isRunObjectScript() {
		return runObjectScript;
	}

	public ScrubbingTask setRunObjectScript(boolean runObjectScript) {
		this.runObjectScript = runObjectScript;
		return this;
	}

	public boolean isRunClientScript() {
		return runClientScript;
	}

	public ScrubbingTask setRunClientScript(boolean runClientScript) {
		this.runClientScript = runClientScript;
		return this;
	}

}
