package dashboard.data;

import dashboard.util.ErrorOnDoubleQuote;

public class Report {
    public String reportName = "",
        reportDesc = "",
        sourceDir = "";
            
    private int reportId;
    private int execOrder;
    private int execGroup;
    private int reportnGrpCount;

	public Report() {
    }

    public Report setReportName(String p) {
        if (null != p) {
            reportName = p.trim();
        }
        return this;
    }

    public Report setReportDesc(String p) {
        if (null != p) {
            reportDesc = p.trim();
        }
        return this;
    }

    public Report setSourceDir(String p) {
        if (null != p) {
            sourceDir = p.trim();
            ErrorOnDoubleQuote.containsDoubleQuote( p);
        }
        return this;
    }

    public String getReportName() {
        return reportName;
    }

    public String getReportDesc() {
        return reportDesc;
    }

    public String getSourceDir() {
        return sourceDir;
    }
    public String toString() {
        return "Name: " + reportName + " Desc:" + reportDesc +
            " sourceDir:" + sourceDir;
    }
    public boolean isAllDefined() {
        return !"".equals(reportName) && !"".equals(reportDesc) && !"".equals(sourceDir);
    }

	public int getReportId() {return reportId;}

	public Report setReportId(int reportId) {
		this.reportId = reportId;
		return this;
	}

	public int getExecOrder() {
		return execOrder;
	}

	public Report setExecOrder(int execOrder) {
		this.execOrder = execOrder;
		return this;
	}
	
	public int getExecGroup() {
		return execGroup;
	}

	public Report setExecGroup(int execGroup) {
		this.execGroup = execGroup;
		return this;
	}

	public int getReportnGrpCount() {
		return reportnGrpCount;
	}

	public Report setReportnGrpCount(int reportnGrpCount) {
		this.reportnGrpCount = reportnGrpCount;
		return this;
	}




    
}
