package dashboard.data;

public class DataTask {

	    private boolean
	        runImport = false,
	        runScrub = false;

	    public DataTask setRunImport( boolean value) {
	    	runImport = value;
	        return this;
	    }
	    public boolean isRunImport() {
	        return runImport;
	    }

	    public DataTask setRunScrub( boolean value) {
	    	runScrub = value;
	        return this;
	    }
	    public boolean isRunScrub() {
	        return runScrub;
	    }
}
