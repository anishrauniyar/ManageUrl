package dashboard.data;

import java.io.File;

import dashboard.engine.TaskType;

public class TaskTypeNFile {
    File scriptFile;
    TaskType taskType;

    boolean shellScript;//SHELL_SCRIPT or SQL_SCRIPT
    boolean runAtSource;//run export at source when data transfered to destination
    boolean runAtFQCServer;//run fqc package in FQC server
    boolean runAtStagingServer;// run in Staging Server
	boolean failure; //set false if this task fails
    boolean started;
    boolean completed;
    /*boolean wareHouseTasks;*/
    boolean sendMail;
    boolean haltProcessWhenOraError;
    boolean alwaysWriteOutputFile;
    boolean avoidOraError;
    String eventIdForMail;

	public boolean isCompleted() {
		return completed;
	}
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	public boolean isStarted() {
		return started;
	}
	public void setStarted(boolean started) {
		this.started = started;
	}
	public void setFailure(boolean failure) {
		this.failure = failure;
	}    
	public boolean isFailure() {
		return failure;
	}
	public boolean isShellScript() {
		return shellScript;
	}
	public TaskTypeNFile setShellScript(boolean shellScript) {
		this.shellScript = shellScript;
		return this;
	}
	public boolean isRunAtSource() {
		return runAtSource;
	}
	public TaskTypeNFile setRunAtSource(boolean runAtSource) {
		this.runAtSource = runAtSource;
		return this;
	}
	public boolean isRunAtFQCServer() {
		return runAtFQCServer;
	}
	public TaskTypeNFile setRunAtFQCServer(boolean runAtFQCServer) {
		this.runAtFQCServer = runAtFQCServer;
		return this;
	}
	public boolean isRunAtStaginServer(){
		return runAtStagingServer;
	}
	public TaskTypeNFile setRunAtStagingServer(boolean runAtStagingServer) {
		this.runAtStagingServer = runAtStagingServer;
		return this;
	}
	public TaskTypeNFile ( TaskType t, File f) {
        scriptFile = f;
        taskType = t;
        shellScript = false;
        runAtSource = false;
        started = false;
        completed = false;
        failure = false;        
    }
    public File getScriptFile() {
        return scriptFile;
    }
    public TaskType getTaskType() {
        return taskType;
    }
    private String subTaskType = "";
    public String getSubTaskType() {
    	return subTaskType;
    }
    public void setSubTaskType(String param) {
    	if(null != param) {
    	    subTaskType = param.trim();	
    	}    		
    }
    
    public void setScriptFile(File scriptFile) {
    	this.scriptFile = scriptFile;	
    }
	/*public boolean isWareHouseTasks() {
		return wareHouseTasks;
	}
	public void setWareHouseTasks(boolean wareHouseTasks) {
		this.wareHouseTasks = wareHouseTasks;
	}*/
	public boolean isSendMail() {
		return sendMail;
	}
	public void setSendMail(boolean sendMail) {
		this.sendMail = sendMail;
	}
	public boolean isHaltProcessWhenOraError() {
		return haltProcessWhenOraError;
	}
	public void setHaltProcessWhenOraError(boolean haltProcessWhenOraError) {
		this.haltProcessWhenOraError = haltProcessWhenOraError;
	}
	public boolean isAlwaysWriteOutputFile() {
		return alwaysWriteOutputFile;
	}
	public void setAlwaysWriteOutputFile(boolean alwaysWriteOutputFile) {
		this.alwaysWriteOutputFile = alwaysWriteOutputFile;
	}
	public boolean isAvoidOraError(){
		return avoidOraError;
	}
	public void setAvoidOraError(boolean avoidOraError){
		this.avoidOraError = avoidOraError;
	}
	public String getEventIdForMail() {
		return eventIdForMail;
	}
	public void setEventIdForMail(String eventIdForMail) {
		this.eventIdForMail = eventIdForMail;
	}

	
	
}
