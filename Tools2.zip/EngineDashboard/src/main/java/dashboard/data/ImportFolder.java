package dashboard.data;

import java.util.List;

public class ImportFolder {
	private String clientId = "",
			payer = "",
			scriptName = "",
			defaultDataFolder = "";
	
	private List dataFolderList;
	
	private boolean folderContainsData = false;
	private List dataFileList;
	
	public void setClientId(String value){
		clientId = value;
	}
	
	public String getClientId(){
		return clientId;
	}

	public void setPayer(String value){
		payer = value;
	}
	
	public String getPayer(){
		return payer;
	}	
	
	public void setScriptName(String value){
		scriptName = value;
	}
	
	public String getScriptName(){
		return scriptName;
	}	

	public String getDefaultDataFolder() {
		return defaultDataFolder;
	}

	public void setDefaultDataFolder(String defaultDataFolder) {
		this.defaultDataFolder = defaultDataFolder;
	}

	public List getDataFolderList() {
		return dataFolderList;
	}

	public void setDataFolderList(List dataFolderList) {
		this.dataFolderList = dataFolderList;
	}

	public boolean isFolderContainsData() {
		return folderContainsData;
	}

	public void setFolderContainsData(boolean folderContainsData) {
		this.folderContainsData = folderContainsData;
	}

	public List getDataFileList() {
		return dataFileList;
	}

	public void setDataFileList(List dataFileList) {
		this.dataFileList = dataFileList;
	}
}
