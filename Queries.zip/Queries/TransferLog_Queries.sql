-- Transfer Log Page

-- By Inventory Id
SELECT * FROM (SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, 
transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename 
,d.releaseno FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d
WHERE (a.fileid||'_'||a.dmfileid)=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid) c
where EXISTS (SELECT 1 FROM imp_inventory_rep_log_details b WHERE b.reportid='' AND c.fileid||'_'||c.dmfileid=b.fileid  )

-- By Release Number (Data Batch)
SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, 
transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename 
,d.releaseno FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d
WHERE (a.fileid||'_'||a.dmfileid)=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid and
a.clientid='' and d.releaseno=''

-- By Process Date
SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, 
transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename,d.releaseno 
FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d
WHERE (a.fileid||'_'||a.dmfileid=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid  AND a.CLIENTID=''
AND a.histarttime >= TO_DATE('','dd.MM.yyyy hh24:mi:ss') AND a.hiendtime <= TO_DATE('','dd.MM.yyyy hh24:mi:ss') ) ORDER BY  To_Number(FILEID) DESC

-- By Release Tag (Testing...)
SELECT * FROM (SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, 
transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename 
,d.releaseno FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d
WHERE (a.fileid||'_'||a.dmfileid)=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid) c
where EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='' AND b.dmfileid=c.dmfileid) 