--Exception import 
SELECT
fileid,
dmfileid,
filename,
b.file_date,
b.layoutid  AS oldlayoutid,
nvl(a.layoutid,'0') AS newlayoutid ,
CASE WHEN B.LAYOUTID= nvl(a.layoutid,'0') THEN  Nvl(Trim(STATUS_OF_IMPORT),info13) ELSE NULL END AS STATUS_OF_IMPORT,
PROCESSSTATUS ,
UPPER(a.DATATYPE)   AS newdatatype,
a.EMPLOYERGROUP  AS empgrp ,
a.header_skiprow  SKIPROWS,
g.LAYOUTTYPEID  AS  DELIMITER,
optionally_enc,
processfilepath,
b.IMPORTSERVER ,
nvl(a.ignoreexception,'N') AS ignoreexception,
a.PAYOR    AS payor ,
b.clientid ,
Nvl(b.aip_filename,b.filename) AS original_filename,
CASE WHEN B.LAYOUTID!= nvl(a.layoutid,'0') THEN 'Y' END AS colorflag ,
CASE WHEN ISOVERRIDDEN ='Y' THEN a.sn else NULL END AS pattern_sn,
overridden_date as overriddendate,
coalesce(b.releaseno,cm.release_number,'Data Batch Not Generated') AS releaseno ,
a.sn AS defaultpatternsn,
processstarttime as processdate,
CASE WHEN (FILE_CATEGORY='CONTROLTOTAL' OR FILE_CATEGORY='CTLDATA') and PROCESSSTATUS  NOT IN ('RUNNING','MANUAL SUBMITTED EXCEPTIONS') THEN 'CONTROL' ELSE PROCESSSTATUS END AS dashboard_file_category,
nvl(a.category_id,b.category_id) as category_id,
manualflag
FROM (
      SELECT b.fileid,b.dmfileid, b.filename, b.layoutid , b.datatype, b.file_date, b.file_record_cnt,
      b.import_record_cnt, b.status_of_import,  b.processfilepath, b.IMPORTSERVER, b.processstatus,
      b.cuttingfloor ,b.clientid ,b.empgrp  ,coalesce(m.aip_filename,c.aip_filename) as aip_filename  ,coalesce(m.info13,c.info13) AS info13
       , b.file_date AS filedate  , B.RELEASENO, c.processstarttime,ifc.category_id,ifc.category_name as file_category
      FROM imp_main_log  b
      left JOIN aip_dmfilelist_log   c
      ON b.clientid=c.clientid AND b.dmfileid=c.dmfileid  AND b.filename=c.filename
	  left join imp_file_categories ifc on b.file_category= ifc.category_ID
      left JOIN ( SELECT * FROM aip_manualrun_log q WHERE sn IN
                        ( SELECT  Max(sn) AS sn from  aip_manualrun_log r GROUP BY fileid )) m
      ON m.fileid=b.fileid||'_'||b.dmfileid
      WHERE  (PROCESSSTATUS IN ('EXCEPTIONS','UNKNOWN','RUNNING','MANUAL SUBMITTED EXCEPTIONS','DONOTUSE') or (import_record_cnt=0 and file_record_cnt!=0))
      AND EXCEPTIONFLAG IS NULL
      --Using filter  over hear will imporve performance
      --and b.clientid='657'
      --For filter by Inventory id
            --AND EXISTS (SELECT DISTINCT(fileid) FROM imp_inventory_rep_log_details r WHERE r.reportid='7170'
            --AND b.fileid||'_'||b.dmfileid=r.fileid  )
          --
      --For filter by data batches
            --AND (b.releaseno='657.2016.08.S2' )
      --Filter by processcess
            --AND (b.processstarttime <= To_Date('09.11.2016 20:52:13','DD.MM.YYYY HH24:MI:SS') AND b.processstarttime > To_Date('25.10.2016 20:52:13','DD.MM.YYYY HH24:MI:SS') )
      --Filter by release tag
            --AND EXISTS ( SELECT distinct(dmfileid) FROM imp_files_reltag_reln rel WHERE rel.reltag='WIL657.2016.09-001'
            --AND b.dmfileid=rel.dmfileid and b.filename=rel.filename )
    ) b
left JOIN  ( SELECT i.* , h.datatype , h.payor   ,
			case when isoverridden='Y'	then Nvl(i.delimiter,k.layouttype) else k.layouttype end  AS  file_delimiter,
			case when isoverridden='Y'	then Nvl(i.skiprows,h.skiprow) else h.skiprow end  AS  header_skiprow,
			case when isoverridden='Y'	then Nvl(i.OPTIONALLY,h.OPTIONALLY) else h.OPTIONALLY end  AS  optionally_enc,
			case when isoverridden='Y'	then overriddendate else NULL end  AS  overridden_date,
			ifc.category_id,
			nvl(h.manualflag,'N') as manualflag
              FROM imp_clientpatterns i
			  left join imp_file_categories ifc on i.filetype= ifc.category_name
               left JOIN  imp_layouts h
               ON i.layoutid=h.layoutid
                left JOIN imp_sub_layouts k
               ON k.layoutid=h.layoutid  AND   k.sublayoutid=1
                )  a
ON b.clientid = a.clientid  AND aip_file_match (b.filename,a.pattern)=1
 LEFT JOIN  tbl_filepatterns_layout g
               on a.file_delimiter=g.LAYOUTTYPE
left JOIN (
SELECT clientid, data_start_date,data_end_date, releaseby
                         ,Nvl(SUBRELEASENUMBER,release_number) AS  release_number
                        FROM aip_cycle_master m
                        ) cm
                ON b.clientid=cm.clientid
                AND b.processstarttime >=  cm.data_start_date  AND  b.processstarttime <= cm.data_end_date

