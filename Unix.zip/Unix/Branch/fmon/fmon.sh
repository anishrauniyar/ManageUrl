#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: Script to monitor DM or Folder and perform appropiate actions

##Program Flow in Pseudo code##
###############################
# Run the main file
# Get New file list
# Pass the list of filesnames from the lits to the action script
# Do all the actions stated in the action file list
# Done
#Default values

## Source Function
#Below conf file has all the required paramaters defined for running fmon
source /data1/AIP/conf/fmon.conf
#Below conf file has function defined for logging using rsyslog
source /data1/AIP/conf/rlog.sh
#source /data1/AIP/conf/error-trap

usage()
{   
cat << EOF

Usage: `basename $0` [-d inputdir] [-a actionfiledirectory] [-l logdir] 

Example: ./fmon.sh -d /home/pictures -a /home/myactions -l /home/pictures/logs
         ./fmon.sh -s "20150101 00:00:01" -e "20150217 04:41:39" -c "'019'" 
         ./fmon.sh -l "'15671','15612','15631'"
         ./fmon.sh -m "15631"
         ./fmon.sh -m "15621" -x "15671"
Help: 

-d: Input directory where FMON will scan and generate file list. 
	Default - $SCANDIR
-a: Directory where ACTIONSFILE is located.* Should also contain all the action scripts. 
	Default - $DEFAULTACTIONDIR
-g: Log Directory. 
	Default - $BASEDIR/logs
-l: List of dmfile ids
-m: min dmfile id
-x: max dmfile id
-f: Override default config file
-s: Start time
        Default - $BASEDIR/time
-e: End time
        Default - current time stamp
-c: Clients
        Default - $BASEDIR/conf
EOF
}
################################################
####./fmon.sh -f "/data1/AIP/conf/mfmon.conf" -d '/data1/AIPFM/Clients/759 - Aon Hewitt Corporate Exchange/data/201501/' -s "20141101 00:01:01" -e "20150123 00:01:03" -c "'759'
##############################################
#Variables defination
INFO1=''
INFO2=''
INFO3=''
INFO4=''
INFO5=''
INFO6=''
INFO7=''
INFO17=''
CUSTACTIONDIR=0
declare -a fileList=()

declare -A listGeneratorMode=(
 [DM]='f_genListDM'
 [MANUAL]='f_genListManual'
)

#Check correct options are given to the script.
while getopts ":d:a:l:m::x:s:e:c:f:" options
do
    case $options 
	in
	d) INPUTDIR=${OPTARG}
	    if [[ ! -d "$INPUTDIR" ]]; then 
		echo "Invalid INPUT Directory" 2>&1 | tee -a $LOGDIR/fmon.log 
		exit 1
	    else
		SCANDIR="$INPUTDIR"
	    fi 
	    MANUAL="TRUE";;
	a) CUSTACTIONDIR=${OPTARG}
	    if [[ ! -d "$CUSTACTIONDIR"  &&  ! -f "$CUSTACTIONDIR/ACTIONSFILE" ]]; then
                echo "Invalid ACTIONS Directory or ACTIONSFILE not found" 2>&1 | tee -a $LOGDIR/fmon.log
                exit 1
	    else
		DEFAULTACTIONSDIR="$CUSTACTIONDIR"
            fi
	    ;;
	g) CUSTLOGDIR=${OPTARG}
	    if [[ ! -d "$CUSTLOGDIR" ]]; then
		echo "Invalid LOG Directory" 2>&1 | tee -a $LOGDIR/fmon.log
		exit 1
	    else
		LOGDIR="$CUSTLOGDIR"
	    fi
	    ;;
	l) dmfilelist=${OPTARG};MANUAL="TRUE";;
	m) mindmfile=${OPTARG};MANUAL="TRUE";;
	x) maxdmfile=${OPTARG};MANUAL="TRUE";;
	s) STIMEARG=${OPTARG};MANUAL="TRUE";;
	e) ETIMEARG=${OPTARG};MANUAL="TRUE";;
	c) CLIENTIDARG=${OPTARG};MANUAL="TRUE";;
	f) confFileOverRide=${OPTARG}; source "$confFileOverRide";;
	*) usage; exit ;;
    esac
done

FILETAG=$(echo $TIMEFILE | awk -F'/' '{print $NF}')
##Time Function
##If start and end time given in argument it uses that value.
##Otherwise reads from the time/time file and updates the time there
function timegen()
{
    if [ ! -z  "$STIMEARG" ];then
	STIME="$STIMEARG"
    fi
    if [ ! -z  "$ETIMEARG" ];then
        ETIME="$ETIMEARG"
    fi
    if [ ! -z  "$CLIENTIDARG" ];then
        CLIENTID="$CLIENTIDARG"
    fi
    if [ ! -z "$STIMEARG" ] && [ ! -z "$ETIMEARG" ]  && [ ! -z "$CLIENTIDARG" ]; then
	cond='1'
	#echo "Condtion 1"
    elif [ -z "$STIMEARG" ] && [ -z "$ETIMEARG" ] && [ ! -z "$dmfilelist" ]; then
	cond='2'
	#echo "Condtion 2"
    elif [ -z "$STIMEARG" ] && [ -z "$ETIMEARG" ] && [ ! -z "$mindmfile" ] && [ -z "$maxdmfile" ]; then
	cond='3'
	#echo "Condtion 3"
    elif [ -z "$STIMEARG" ] && [ -z "$ETIMEARG" ] && [ ! -z "$mindmfile" ] && [ ! -z "$maxdmfile" ]; then
	cond='4'
	#echo "Condtion 4"
    elif [ ! -z "$CLIENTIDARG" ]; then
	STIME=$(cat $TIMEFILE)
	cond='6'
    else
	 STIME=$(cat $TIMEFILE)
	 echo "$ETIME" > $TIMEFILE 
	 cond='5'
	 MANUAL="FALSE"
	 FILETAG=$(echo $TIMEFILE | awk -F'/' '{print $NF}')
	 #echo "Condtion 5"
    fi
}

function f_genListDM()
{
    #Generates new File List from Data Manager
    #find /home/hsharma/AIP/temp/tempfiles -maxdepth 0 -type f
    timegen
    if [[ $cond == '1' ]] || [[ $cond == '5' ]] || [[ $cond == '6' ]]; then
	echo "$DEFAULTACTIONDIR/getFileNames.sh -s "$STIME" -e "$ETIME" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG"
	$DEFAULTACTIONDIR/getFileNames.sh -s "$STIME" -e "$ETIME" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG
    elif [[ $cond == '2' ]]; then
	echo "$DEFAULTACTIONDIR/getFileNames.sh -l "$dmfilelist" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG"
	$DEFAULTACTIONDIR/getFileNames.sh -l "$dmfilelist" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG
    elif [[ $cond == '3' ]]; then
	echo "$DEFAULTACTIONDIR/getFileNames.sh -m "$mindmfile" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG"
        $DEFAULTACTIONDIR/getFileNames.sh -m "$mindmfile" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG
    elif [[ $cond == '4' ]]; then
	echo "$DEFAULTACTIONDIR/getFileNames.sh -m "$mindmfile" -x "$maxdmfile" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG"
        $DEFAULTACTIONDIR/getFileNames.sh -m "$mindmfile" -x "$maxdmfile" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG
    else
	echo "$DEFAULTACTIONDIR/getFileNames.sh -s "$STIME" -e "$ETIME" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG"
        $DEFAULTACTIONDIR/getFileNames.sh -s "$STIME" -e "$ETIME" -c "$CLIENTID" -o dmfile.$FMONID.flist.$FILETAG
    fi
    local IFS=$'\n'
    fileList=($(cat $TMPDIR/dmfile.$FMONID.flist.$FILETAG))    
}

function f_genListManual()
{
    echo "Unset AIPCOPYDIR if file list is not generated by dm"
    #AIPCOPYDIR=""
    #export listGenerate
    #find "$SCANDIR" -type f -newermt "$STIME" -and -not -newermt "$ETIME" > $TMPDIR/dmfile.$FMONID.flist
    #genListManualRoute
}

##Get new file list
##Generate list of files based on the flag on the conf file
function genFileList()
{
    if [[ ${listGeneratorMode[${listGenerate}]} ]]; then
	${listGeneratorMode[${listGenerate}]}
	#elif [ -n $CUSTSCANDIR ]
	#then
	#    timegen
	#    find $CUSTSCANDIR -type f
    else
	echo "List generation mode not defined"
    fi
	}

function checkFmon()
{
    contentsList=''
    oFMONID=''
    latestListFile=''
    echo "$FILETAG FROM Checkfmon function"
#    latestListFile=$(ls -ltr $TMPDIR/resume | grep $USER |tail -n 1 | awk '{print $NF}')
    ls -ltr $TMPDIR/resume | awk '/dmfile/ {print $NF}' | awk -F'.' '{if(filetag==$NF)print $1"."$2"."$3"."$4}' filetag=$FILETAG | tail -n 1
    #ls -ltr $TMPDIR/resume | awk '{print $NF}' | awk -F'.' '{if($NF=filetag)print $1"."$2"."$3"."$4}' filetag=$FILETAG
    latestListFile=$(ls -ltr $TMPDIR/resume | awk '/dmfile/ {print $NF}' | awk -F'.' '{if(filetag==$NF)print $1"."$2"."$3"."$4}' filetag=$FILETAG | tail -n 1)
    #echo "ls -ltr $TMPDIR/resume | awk '{print $NF}' | awk -F'.' '{if($NF=filetag)print $1"."$2"."$3"."$4}' filetag=$FILETAG | tail -n 1"
    #echo "latestListFile"
    if [ ! -f $TMPDIR/resume/$latestListFile ]; then
	echo "No resume file found;"
    else
	contentsList=$(cat $TMPDIR/resume/$latestListFile)
    fi
    if [[ "${#contentsList}" = 0 ]] ; then
	echo "Previous FMON was successful"
	resumeMode="False"
    else
	echo "Previous FMON was not successful. Resuming ..."
	mv $TMPDIR/$latestListFile $TMPDIR/${latestListFile}_${FMONID}.bak
	cp $TMPDIR/resume/$latestListFile $TMPDIR
	local IFS=$'\n'
	fileList=($(cat $TMPDIR/$latestListFile))
	echo ${#fileList[@]}
	oFMONID=$(echo $latestListFile | awk -F'.' '{print $2}')
	#mv $TMPDIR/$latestListFIle $TMPDIR/dmfile.$FMONID.flist
	#mv $TMPDIR/$latestListFile $TMPDIR/dmfile.$oFMONID.flist
	resumeMode="True"
	echo "Resuming previous fmon process with FMONID $oFMONID"
	FMONID=$oFMONID
    fi    
}

function gen_dmfileid()
{
    query="select seq_aip_manualimport_dmfileid.NEXTVAL from dual"
dmfileid=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
SET DEFINE OFF;
$query;
SET DEFINE ON;
EOF
exit;
)
}

#Insert the cron info into the table AIP_CRON_LOG
function aip_cron_log()
{	
CLIENTID=$(echo "$CLIENTID" | sed -e "s/'//g")
ECTIME=`date "+%F %T"`
FMONTAG="${FILETAG}_${USER}_${HOSTNAME}"
if [[ ${#USER} = 0 ]]; then 
USER="service"
fi
if [[ $1 == "EARLY_EXIT" ]];then
query="INSERT INTO aip_cron_log(fmonid,start_time,end_time,machine,executed_by,dmfile_list,client_id,info1,info2,info3,info4,info5,info6,info17,cronstarttime,cronendtime,fmontag) VALUES('"${FMONID}"', '"$STIME"', '"$ETIME"', '"$HOSTNAME"' ,'"$USER"', '"${TMPDIR}/dmfile.${FMONID}.flist.${FMONTAG}"' ,'"$CLIENTID"' ,'"$INFO1"','"$INFO2"','"$INFO3"','"${INFO4}"','"${INFO5}"','"${INFO6}"','"${INFO17}"','"$SCTIME"','"$ECTIME"','"$FMONTAG"')"
else
query="INSERT INTO aip_cron_log(fmonid,start_time,end_time,machine,executed_by,dmfile_list,client_id,info1,info2,info3,info4,info5,info6,info17,cronstarttime,cronendtime,fmontag) VALUES('"${FMONID}"', '"$STIME"', '"$ETIME"', '"$HOSTNAME"' ,'"$USER"', '"${TMPDIR}/dmfile.${FMONID}.flist.${FMONTAG}"' ,'"$CLIENTID"' ,'"$INFO1"','"$INFO2"','"$INFO3"','"${INFO4}"','"${INFO5}"','"${INFO6}"','"${INFO17}"','"$SCTIME"','','"$FMONTAG"')"
fi
echo $query
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
$query;
commit;
EOF
else
 echo "DRYRUN Flag set as TRUE"
fi
}

#Function that updates resume field UPDATE aip_cron_log set info1=info1||' testing' where fmonid='20141013213013'
function update_cron_log_resume()
{
resumetext=$(date "+%F %T")
query="UPDATE aip_cron_log set resume_status=resume_status||'Resumed at "$resumetext",' where fmonid='"$FMONID"'"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
$query;
commit;
EOF
else
 echo "DRYRUN Flag set as TRUE"
fi
}


#Functions update the cron_log end_time and info17
function update_cron_log()
{
query="UPDATE aip_cron_log set cronendtime='"$1"',info17='"$2"',info4='"$3"',info5='"$4"' where fmonid='"$FMONID"'"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
$query;
commit;
EOF
else
 echo "DRYRUN Flag set as TRUE"
fi
}

############################################################################
################################Database Function End  #####################
############################################################################


###################################################################################################################################
###################################################################################################################################
###################################################Function to check Servers starts#################################################
###################################################################################################################################
#Function that checks oracle connection
function checkOracleConn()
{
#Define oracleHealth status as 2 at first
oracleHealth=2
sqlReturn="SELECT 1 AS ORCLEHEALTH FROM dual"
oracleHealth=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
$sqlReturn;
EXIT;
EOF
)
#echo "$oracleHealth from check oracle function"
oracleHealth=$(echo "$oracleHealth" | sed -e 's/[[:space:]]//g' -e 's/[[:blank:]]//g')
#oracleHealth=2
}

#Check svn server status
function svnStatusCheck()
{
    svn_user="datadashboard"
    svn_pass="innovation"
    svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/"
    svnstatus=$(svn info --username $svn_user --password $svn_pass $svn_url | grep "Revision")
    if [ -z "$svnstatus" ]; then
	echo "ERROR : SVN system down"
	delLock
	exit 1
    else
        echo "SVN server link ok"
    fi
}

#Check /eiger mount point
function checkMountPoint()
{
    echo "Mount point"
    if mount | grep "10.48.6.226:/data1 on /eiger" > /dev/null ; then
	echo "/eiger is mounted "
    else
	echo "Error : /eiger not mounted"
	delLock
	exit 1
    fi
}

#Check lock file
function checkLock()
{
    if [[ "$LOCKFILE" == 'TRUE' ]]; then
    ##Check lock for particular File tag
	if [ -f "${TMPDIR}/${FILETAG}" ]; then
	    echo "FMON instance with ${FILETAG} already running"
	    exit 1
	else
	    echo "No previous instance with ${FILETAG} found. Starting new instance"
	    touch "${TMPDIR}/${FILETAG}"
	fi
    fi
}

#Delete file after fmon process successful
function delLock()
{
    if [[ "$LOCKFILE" == 'TRUE' ]]; then
    ##Check lock for particular File tag
	if [ -f "${TMPDIR}/${FILETAG}" ]; then
	    echo "FMON process compelted. Removing lock file"
	    rm -f "${TMPDIR}/${FILETAG}"
	else
	    echo "No previous instance with ${FILETAG} found"
	fi
    fi
}

###################################################################################################################################
###################################################################################################################################
###################################################Function to check Servers ends#################################################
###################################################################################################################################


#Check lock file before processing
if [[ $MANUAL == "TRUE" ]]; then
    FILETAG='MANUAL'
fi
checkLock
##Main Process Start for FMON
##Unique id for each process of FMON.
FMONID=`date +%Y%m%d%H%M%S%N`
SCTIME=$(date "+%F %T")
export FMONID
#Check if previous fmon process was successful
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
#Check oracle server status and eiger mount point
checkMountPoint
checkOracleConn
if [[ "$oracleHealth" == "1" ]]; then
    echo "Oralce Connection Successful"
else
    echo "Oracle Connection Unsuccessful.exiting"
    delLock
    exit 1
fi
#Other wise resume the previous process
if [[ $RESUMEFET == 'TRUE' ]] && [[ $MANUAL != "TRUE" ]]; then
    checkFmon
else
    resumeMode='False'
fi
#SCTIME=`date "+%F %T"`
if [[ $MANUAL == "TRUE" ]]; then
    INFO1="Manually Started FMON Process $FMONID"
else
    INFO1="FMON Process $FMONID Started by Cron"
fi
echo "$INFO1"
allLogging "::::$INFO1"
if [[ $resumeMode == "False" ]]; then
##Call genFileList function which will generate list of files for procession by fmon
genFileList
fi

#Create a lock file

if [[ "${#fileList[@]}" = 0 ]]
    then
    INFO2="File List Empty. Nothing to copy. Exiting"
    echo "$INFO2"
    allLogging "::::$INFO2"
    INFO17="FMON process ended with no file list"
    ECTIME=`date "+%F %T"`
    if [[ $resumeMode == "False" ]]; then
	aip_cron_log "EARLY_EXIT"
    fi
    #echo "File List Empty. Exiting" 2>&1 | tee -a $LOGDIR/fmon.log
    delLock
    exit
else
    filelistErr=0
    filelistErr=`echo ${fileList[@]} | sed -n -e '/ERROR\|unknown/p' `
    #echo "After Filelist erro var ${#filelistErr}"
    if [[ "${#filelistErr}" = 0 ]]; then
	cp $TMPDIR/dmfile.$FMONID.flist.$FILETAG $TMPDIR/resume
	#filelistrec=$(wc -l $TMPDIR/dmfile.$FMONID.flist.$FILETAG)
	INFO2="File List found with ${#fileList[@]} records. Starting FMON Process"
	echo "$INFO2"
	allLogging "::::$INFO2"
    else
	INFO2="Invalid File List. Exiting"
	#If file list was invalid revert update restore time
	if [[ $MANUAL == "FLASE" ]]; then
	    echo "$STIME" > $TIMEFILE
	else
	    echo "Manual run. No need to update time file"
	fi
	echo "$INFO2"
	allLogging "::::$INFO2"
	INFO17="FMON process ended with invalid file list"
	ECTIME=`date "+%F %T"`
	if [[ $resumeMode == "False" ]]; then
            aip_cron_log "EARLY_EXIT"
	fi
	delLock
        exit 
    fi
    #echo "Found File List." 2>&1 | tee -a $LOGDIR/fmon.log
    #echo $fileList
fi
#echo $fileList
#Check config file for default actions folder
if [[ ${#CUSTACTIONDIR} = 0 ]]
    then
	ACTIONDIR="$CUSTACTIONDIR" 
    else
        ACTIONDIR="$DEFAULTACTIONDIR"
fi
###### Building action list ####################
function buildActionList()
{
    OLDIFS="$IFS"
    IFS=$'\n'
    actionList=($(awk -F':' '/^ACTION/ {print $2}' "${ACTIONDIR}/${ACTIONSLIST}"))
    IFS="$OLDIFS"
}
#Load Global Actions File
    buildActionList
    if [[ -z "${actionList[@]}" ]]
	then
		#echo "Action List not found. Exiting" 2>&1 | tee -a $LOGDIR/fmon.lopg
	INFO3="Action list not found"
	echo "$INFO3"
	allLogging "::::$INFO3"
	INFO17="FMON Process ended with no action files"
	ECTIME=`date "+%F %T"`
	if [[ $resumeMode == "False" ]]; then
            aip_cron_log "EARLY_EXIT"
	fi
	delLock
	exit 1
	else
		#echo "Action List created." 2>&1 | tee -a $LOGDIR/fmon.log
	INFO3="Action list found"
	echo "$INFO3"
        allLogging "::::$INFO3"
    fi
    #echo ${actionList[@]}
#For each file in the fileList run all the actions, i.e: actionList
    if [[ $resumeMode == "False" ]]; then
        aip_cron_log
    else
	update_cron_log_resume
    fi
    fmonIdLogDir="$LOGDIR/${FMONID}"
    mkdir -p $fmonIdLogDir
    export FILETAG
    #echo "${fileList[@]}" | xargs -i --null --max-procs=4 bash -c "
    #echo start {}
    for file in "${fileList[@]}"
    do
	checkOracleConn
	#svnStatusCheck
	if [[ "$oracleHealth" == "1" ]]; then
	    echo "Oralce Connection Successful"
	else
	    echo "Oracle Connection Unsuccessful.exiting"
	    delLock
	    exit 1
	fi
	#fileName=`echo ${file} | awk -F'|' '{print $4}'`
	fname=`echo "$file" |  awk -F"|" '{print $1}'`
	clientid=`echo "$file" |  awk -F"|" '{print $2}'`
	export fileName=`echo "$fname" |  awk -F"/" '{print $NF}'`
	for actions in "${actionList[@]}"
	do
	#Run each actions for the file
	INFO4="BEGIN | $actions | `date "+%F %T"`"
        echo "$INFO4" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	allLogging "::::$INFO4"
	#sem -j4 --id 'AIP' -q "$ACTIONDIR/$actions" "$file"
	#echo "$file"
	"$ACTIONDIR/$actions" "$file" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	INFO5="END | $actions | `date "+%F %T"`"
        echo "$INFO5" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	allLogging "::::$INFO5"
	done
    echo "---------------------------------------------------------------------------------------------------------------------------------------------- "
    done
    #sem --wait --id 'AIP'
INFO17="FMON Process ended $FMONID Successfully"
echo "$INFO17"
allLogging "::::$INFO17"
ECTIME=`date "+%F %T"`
#update cron log
if [[ $resumeMode == "False" ]]; then
    update_cron_log "$ECTIME" "$INFO17" "$INFO4" "$INFO5"
fi
echo ""
echo "_____________________________________________________________________________________________________________________________________________________"
echo ""
delLock