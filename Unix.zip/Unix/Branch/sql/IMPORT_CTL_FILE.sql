--------------------
--Version 1
CREATE OR REPLACE PROCEDURE IMPORT_CTL_FILE
(p_cid VARCHAR2,p_fid VARCHAR2,p_ctfname VARCHAR2 DEFAULT NULL,p_dtfname VARCHAR2 DEFAULT NULL,
p_category VARCHAR2,p_empgrp VARCHAR2,p_payor VARCHAR2, p_fdate VARCHAR2, p_tdate VARCHAR2,
p_billedamt VARCHAR2, p_allowedamt VARCHAR2, p_paidamt VARCHAR2, p_employeeamt VARCHAR2,
p_employeecnt VARCHAR2, p_membercnt VARCHAR2,p_recordcnt VARCHAR2)
IS
	impdate VARCHAR2(20);
  ctlstatus VARCHAR2(20);
  v_ErrMsg VARCHAR2(4000);
BEGIN
impdate:=To_char(SYSDATE,'YYYY-MM-DD HH24:MI:SS');
ctlstatus:='PROCESSED';
INSERT INTO imp_vh_control_total(clientid,fileid,ctlfilename, datafilename, importeddate, category,
 empname, payornname, fromdate, todate, billed_amt, allowed_amt, paid_amt, employee_amt,
 employee_cnt, member_cnt, record_cnt, ctl_status)
VALUES (p_cid,p_fid,p_ctfname,p_dtfname,impdate,p_category,p_empgrp,p_payor,p_fdate,p_tdate,
to_number(nvl(p_billedamt,0)),to_number(nvl(p_allowedamt,0)),to_number(nvl(p_paidamt,0)),
to_number(nvl(p_employeeamt,0)),
to_number(nvl(p_employeecnt,0)),to_number(nvl(p_membercnt,0)),to_number(nvl(p_recordcnt,'0')),ctlstatus);
COMMIT;
EXCEPTION WHEN OTHERS THEN
BEGIN
ctlstatus:='UNPROCESSED';
v_ErrMsg:=SQLERRM||'|'||p_fdate||'|'||p_tdate||'|'||p_billedamt||'|'||p_allowedamt||'|'||p_paidamt||'|'||p_employeeamt||'|'||p_employeecnt||'|'||p_membercnt||'|'||p_recordcnt||'|'||ctlstatus;
INSERT INTO imp_vh_control_total(clientid,fileid,ctlfilename, datafilename, importeddate,ctl_status,ctl_extract)
VALUES (p_cid,p_fid,p_ctfname,p_dtfname,impdate,ctlstatus,v_ErrMsg);
COMMIT;
END;
END;
/
