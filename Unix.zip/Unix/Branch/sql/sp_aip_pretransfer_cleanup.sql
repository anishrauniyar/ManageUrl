PROMPT CREATE OR REPLACE PROCEDURE sp_aip_pretransfer_cleanup
CREATE OR REPLACE PROCEDURE sp_aip_pretransfer_cleanup(pclientid VARCHAR2,hischema VARCHAR2,hiserver VARCHAR2,userlog VARCHAR2 DEFAULT 'AIP')
IS
-- Procedure to cleanup HI_T Schema before AI to HI Transfer, used for one time activity before starting the monthly cycle
--- exec sp_aip_pretransfer_cleanup('100','HI0100001_T','NVSCRUBP6','TEST' );
vsn NUMBER;
verr VARCHAR2(500);
BEGIN
       SELECT importdb.seq_hi_prettransfer_cleanup.nextval@nveigerworkq1  INTO vsn FROM dual ;
      

        FOR i IN (SELECT  DISTINCT HITABLENAME FROM importdb.HI_LEGACY_TRANSFER@nveigerworkq1  WHERE   CLIENTID=''||pclientid||'' )
        LOOP
            begin

                EXECUTE IMMEDIATE 'truncate table ' || i.HITABLENAME || '' ;

                EXECUTE IMMEDIATE 'INSERT INTO importdb.hi_prettransfer_cleanup@nveigerworkq1 (sn, schemaname, servername, hitablename, userlog, status, createddate)
                VALUES ('||vsn||','''||hischema||''','''||hiserver||''','''|| i.HITABLENAME||''','''|| userlog||''',''SUCCESS'',sysdate ) ' ;
                COMMIT;


              EXCEPTION WHEN OTHERS THEN


               VERR:=SUBSTR(SQLERRM, 1,400) ;

              EXECUTE IMMEDIATE 'INSERT INTO importdb.hi_prettransfer_cleanup@nveigerworkq1 (sn, schemaname, servername, hitablename, userlog, status,ERROR, createddate)
                VALUES ('||vsn||','''||hischema||''','''||hiserver||''','''|| i.HITABLENAME||''','''|| userlog||''',''failed'','''||VERR||''',sysdate ) ' ;
                COMMIT;

              COMMIT;

           END ;
        END LOOP;

END  sp_aip_pretransfer_cleanup ;
/
