PROMPT CREATE OR REPLACE PROCEDURE sp_aip_hi_transfer
CREATE OR REPLACE PROCEDURE sp_aip_hi_transfer (P_CID VARCHAR2 , P_FILEIDLIST VARCHAR2 , P_IMPORTSERVER VARCHAR2,p_schemaname VARCHAR2, p_sn NUMBER DEFAULT NULL)  IS
-- Procedure to move data from AIP Server to Client Server
-- To be executed in HI schema where data needs to be transfered, reads/update logs from FLMS for transfer , copies data from AI tables to HI tables
-- Uses HI_LEGACY_TRANSFER config table to transfer data
-- Transfers data only in append mode.
-- exec sp_aip_hi_transfer ('759' ,  '43457_1596941', 'nveigerwork','HI0759001')
-- exec sp_aip_hi_transfer ('759' ,  '43457_1596941', 'nveigerwork','HI0759001',123)


  VQUERY clob;
  VHPAYERID VARCHAR2(100);
  VROWINSERTED INTEGER ;
  VERRMSG VARCHAR2(100);
  VSTARTTIME DATE;
  VTABLENAME VARCHAR2(100);
  VCID VARCHAR2(10);
  VTRANSFERTYPE VARCHAR2(50);
  VCNT NUMBER(19,4) ;
  VSQLSTRING clob;
  VJOBNUM BINARY_INTEGER ;
  JOBCNT NUMBER (19,0);
  VCOND VARCHAR2(4000 ) ;
  VFILELIST VARCHAR2(4000);

  TYPE FILE_REC IS RECORD
  (FILEID VARCHAR2(200),
   DMFILEID   VARCHAR2(100),
   LAYOUTID VARCHAR2(100),
   FILENAME VARCHAR2(500),
   EMPGRP VARCHAR2(500),
   SUBLAYOUTID VARCHAR2(500),
   RECORDCOUNT NUMBER  ,
   AITABLENAME VARCHAR2(50),
    TRANSFERTYPE VARCHAR2(50),
    HITABLENAME VARCHAR2(50),
    HISCHEMANAME VARCHAR2(50) ,
    WHERECONDITION VARCHAR2(500) ,
    SN  NUMBER,
    HISERVERNAME VARCHAR2(50)

  ) ;

  TYPE FILE_SET IS TABLE OF FILE_REC ;
  FILE_LIST FILE_SET;
  VFILENAME VARCHAR2(500) ;
  VEMPGRP VARCHAR2(500);

  AICOLUMNLIST clob;
  HICOLUMNLIST clob;

  VBKPDATE VARCHAR2(50);
  AISCHEMA VARCHAR2(50);
  VWHERECONDITION VARCHAR2(4000);
  IMPORTSERVER VARCHAR2(50);


BEGIN

  VCID:=LPAD(P_CID,4,'0');
  VFILELIST := REPLACE(P_FILEIDLIST,',',''',''')   ;
  AISCHEMA:='AI'||VCID;

  IF  p_sn IS NOT NULL THEN
         vcond:= 'join IMPORTDB.hi_main_log@NVEIGERWORKQ1 f
          on a.fileid=f.fileid and c.sn=f.legacy_sn  and f.sn='||p_sn||' ' ;
  END IF;


  IF P_IMPORTSERVER IS NOT NULL THEN   IMPORTSERVER:='@'||P_IMPORTSERVER ; END IF;


 -- PICKUP FILES FROM IMPORT LOG IN SUCCESS MODE FOR TRANSFER.
          EXECUTE IMMEDIATE  'SELECT A.FILEID , A.DMFILEID, A.LAYOUTID,A.FILENAME,A.EMPGRP,B.SUBLAYOUTID,B.RECORDCOUNT,B.AITABLENAME,''APPEND'' TRANSFERTYPE,
                              C.HITABLENAME,C.HISCHEMANAME,C.WHERECONDITION,C.SN , c.HISERVERNAME
                              FROM  IMPORTDB.IMP_MAIN_LOG@NVEIGERWORKQ1 A
                              JOIN IMPORTDB.IMP_MAIN_DET_LOG@NVEIGERWORKQ1 B
                                ON A.FILEID||''_''||A.DMFILEID =B.FILEID
                              LEFT JOIN   IMPORTDB.HI_LEGACY_TRANSFER@NVEIGERWORKQ1 C
                                ON  A.CLIENTID=C.CLIENTID AND B.AITABLENAME=C.AITABLENAME AND A.EMPGRP=C.EMPGRP
                              '||vcond||' WHERE  a.STATUS_OF_IMPORT =''SUCCESS'' AND a.CLIENTID = '''||P_CID||'''
                              AND B.FILEID IN ('''||VFILELIST||''') and upper(C.HISCHEMANAME)=upper( '''||p_schemaname||''' )'
          BULK COLLECT INTO FILE_LIST;



    IF FILE_LIST.Count !=0 THEN

          FOR I IN FILE_LIST.FIRST..FILE_LIST.LAST
              LOOP

                VSTARTTIME:=SYSDATE;

                            SELECT Count(*) INTO vcnt FROM IMPORTDB.hi_main_log@NVEIGERWORKQ1 WHERE  HISTATUS ='FAILED' AND fileid=''||FILE_LIST(I).FILEID||'' AND sn=''||p_sn||'' ;


                              IF   (vcnt = 0 )  THEN


                                  INSERT INTO   IMPORTDB.HI_MAIN_LOG@NVEIGERWORKQ1  ( FILEID,DMFILEID ,LAYOUTID, SUBLAYOUTID, CLIENTID, EMPLOYERNAME,
                                  AITABLENAME, HISCHEMANAME,HITABLENAME, WHERECONDITION,HISTATUS, HISTARTTIME, TRANSFERTYPE,legacy_sn)
                                  VALUES (FILE_LIST(I).FILEID,FILE_LIST(I).DMFILEID,FILE_LIST(I).LAYOUTID,FILE_LIST(I).SUBLAYOUTID,P_CID,FILE_LIST(I).EMPGRP,FILE_LIST(I).AITABLENAME,
                                  FILE_LIST(I).HISCHEMANAME,
                                  FILE_LIST(I).HITABLENAME,FILE_LIST(I).WHERECONDITION,'QUEUED',VSTARTTIME,FILE_LIST(I).TRANSFERTYPE,FILE_LIST(I).sn);  -- change next val sequnece
                                  COMMIT ;
                              ELSE

                            VWHERECONDITION:=REPLACE(FILE_LIST(I).WHERECONDITION,'''','''''');

                              EXECUTE IMMEDIATE 'UPDATE  IMPORTDB.HI_MAIN_LOG@NVEIGERWORKQ1
                              SET HISTATUS=''QUEUED'' , HISTARTTIME =sysdate , HIENDTIME = NULL , HIERRMSG=null,
                              HISCHEMANAME='''||FILE_LIST(I).HISCHEMANAME||''',
                              HITABLENAME='''||FILE_LIST(I).HITABLENAME||''' , WHERECONDITION='''||VWHERECONDITION||''' WHERE   SN= '''||P_SN||''' ';
                              COMMIT;

                            END IF;



                END LOOP;

      -- START PROCESSING TRANSFER FOR EACH FILE
          FOR TRANSFER IN (SELECT FILEID, DMFILEID , LAYOUTID, SUBLAYOUTID, CLIENTID, EMPLOYERNAME,
          AITABLENAME, HISCHEMANAME,HITABLENAME,TRANSFERTYPE, WHERECONDITION,SN, LEGACY_SN FROM IMPORTDB.HI_MAIN_LOG@NVEIGERWORKQ1 WHERE HISTATUS='QUEUED' )
                LOOP


                    EXECUTE IMMEDIATE 'UPDATE  IMPORTDB.HI_MAIN_LOG@NVEIGERWORKQ1  SET HISTATUS=''RUNNING'' WHERE SN= '''||TRANSFER.SN||'''  ' ;
                    COMMIT;

                  IF TRANSFER.WHERECONDITION IS NULL THEN
                  VWHERECONDITION:='  A.FILEID= '''||TRANSFER.FILEID||'_' ||TRANSFER.DMFILEID||''' '    ;
                    ELSE
                    VWHERECONDITION:='  A.FILEID= '''||TRANSFER.FILEID||'_' ||TRANSFER.DMFILEID||''' AND '||TRANSFER.WHERECONDITION     ;
                  END IF;


                    VWHERECONDITION:=REPLACE(VWHERECONDITION,'''','''');


                  -- Check if table exists else create
                    SELECT Count(1) INTO vcnt FROM tab WHERE TNAME=Upper(''||TRANSFER.HITABLENAME||'') ;
                    IF  (vcnt =0 ) THEN
                    BEGIN


                        EXECUTE IMMEDIATE ' SELECT rtrim (xmlagg (xmlelement (e, column_name || '','')).EXTRACT (''//text()'').getclobval(), '','') column_name
                                            FROM ( SELECT column_name ||'' AS ''|| Nvl(b.HICOLUMNNAME,a.column_name )  AS COLUMN_NAME
                                                    FROM all_tab_cols'||IMPORTSERVER||'   A
                                                    LEFT JOIN   IMPORTDB.HI_LEGACY_LABEL_CHG@NVEIGERWORKQ1  B
                                                    ON  A.COLUMN_ID=B.AICOLUMNID AND B.SN='||TRANSFER.LEGACY_SN||'  AND   b.HICOLUMNID !=0
                                                    WHERE A.OWNER=Upper('''||AISCHEMA||''')
                                                    AND A.TABLE_NAME=Upper('''||TRANSFER.AITABLENAME||''')
                                                    order by column_id
                                                ) ' INTO  HICOLUMNLIST ;


                        VQUERY:='CREATE TABLE '||TRANSFER.HISCHEMANAME||'.'||TRANSFER.HITABLENAME||'
                          AS SELECT '||HICOLUMNLIST||' FROM '||AISCHEMA||'.'||TRANSFER.AITABLENAME||IMPORTSERVER||'  A
                          WHERE 1=2';

                        --Dbms_Output.PUT_LINE(vquery);

                          EXECUTE IMMEDIATE VQUERY;
                          EXCEPTION WHEN OTHERS THEN  NULL;
                    END;
                    END IF;

                    BEGIN

                      EXECUTE IMMEDIATE ' SELECT rtrim (xmlagg (xmlelement (e, column_name || '','')).EXTRACT (''//text()'').getclobval(), '','') column_name
                                          FROM (select column_name FROM all_tab_cols'||IMPORTSERVER||' WHERE OWNER=Upper('''||AISCHEMA||''')
                                          AND TABLE_NAME=Upper('''||TRANSFER.AITABLENAME||''') order by column_id) ' INTO  AICOLUMNLIST ;

                        --Dbms_Output.PUT_LINE('before list');

                      EXECUTE IMMEDIATE ' SELECT rtrim (xmlagg (xmlelement (e, column_name || '','')).EXTRACT (''//text()'').getclobval(), '','') column_name
                                          FROM (    SELECT  NVL(B.HICOLUMNNAME,A.COLUMN_NAME ) AS COLUMN_NAME
                                                      FROM all_tab_cols'||IMPORTSERVER||'   A
                                                      LEFT JOIN   IMPORTDB.HI_LEGACY_LABEL_CHG@NVEIGERWORKQ1  B
                                                      ON  A.COLUMN_ID=B.AICOLUMNID AND B.SN='||TRANSFER.LEGACY_SN||'    AND   b.HICOLUMNID !=0
                                                      WHERE A.OWNER=Upper('''||AISCHEMA||''')
                                                      AND A.TABLE_NAME=Upper('''||TRANSFER.AITABLENAME||''')
                                                      order by column_id
                                                  ) ' INTO  HICOLUMNLIST ;


                      EXCEPTION WHEN OTHERS THEN NULL;
                    END ;


                    --Dbms_Output.PUT_LINE(AICOLUMNLIST);

                        VQUERY:= 'INSERT /*+ APPEND PARALLEL */INTO '||TRANSFER.HISCHEMANAME||'.'||TRANSFER.HITABLENAME||' ('||HICOLUMNLIST||')
                        SELECT  /*+ PARALLEL */ '||AICOLUMNLIST||' FROM  '||AISCHEMA||'.'||TRANSFER.AITABLENAME||IMPORTSERVER||' A  WHERE '||VWHERECONDITION||' ' ;
                       --Dbms_Output.PUT_LINE(VQUERY);
                        --dbms_output.put_line(TRANSFER.AITABLENAME);



                            BEGIN

                              EXECUTE IMMEDIATE VQUERY;

                                VROWINSERTED :=SQL%ROWCOUNT;
                                COMMIT;

                                EXECUTE IMMEDIATE 'UPDATE  IMPORTDB.HI_MAIN_LOG@NVEIGERWORKQ1  SET HISTATUS=''SUCCESS'', HIROWS = '||VROWINSERTED||' , HIENDTIME=SYSDATE  , ENABLESCRUBFLAG=''Y''
                                WHERE   SN= '''||TRANSFER.SN||''' ' ;
                                COMMIT;
                            EXCEPTION WHEN OTHERS THEN

                                VERRMSG:='Error at Insert from AI to HI: '|| SUBSTR(SQLERRM, 1,400);

                                EXECUTE IMMEDIATE 'UPDATE  IMPORTDB.HI_MAIN_LOG@NVEIGERWORKQ1  SET HISTATUS=''FAILED'', HIERRMSG = '''||VERRMSG||''' , HIENDTIME=SYSDATE
                                WHERE   FILEID= '''||TRANSFER.FILEID||''' and HITABLENAME='''||TRANSFER.HITABLENAME||''' ' ;


   				                      COMMIT;


                            END;




                END LOOP;

--           EXECUTE IMMEDIATE 'ALTER SESSION CLOSE DATABASE LINK IMPORTDB';
  --         COMMIT;

        END IF;


END sp_aip_hi_transfer  ;
/


