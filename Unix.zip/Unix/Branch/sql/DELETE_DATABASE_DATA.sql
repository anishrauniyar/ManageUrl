--------------------
--Version 1
CREATE OR REPLACE PROCEDURE DELETE_DATABASE_DATA
(p_cid VARCHAR2)
IS
  v_Query VARCHAR2(200);
  CURSOR fileid_c IS
  SELECT fileid,dmfileid FROM imp_main_log@FLMSDEV WHERE clientid=p_cid;
  fileid_list fileid_c%rowtype;
  ctlstatus VARCHAR2(20);
  mixfileid VARCHAR2(50);
  v_ErrMsg VARCHAR2(4000);

BEGIN

  OPEN fileid_c;
  LOOP
  FETCH fileid_c INTO fileid_list;
  EXIT WHEN fileid_c%NOTFOUND;
  mixfileid:=fileid_list.fileid||'_'||fileid_list.dmfileid;
  Dbms_Output.put_line(mixfileid);
  DELETE FROM importdb.aip_manualrun_log WHERE fileid =mixfileid;
  DELETE FROM importdb.imp_file_stats_log WHERE fileid =mixfileid;
  DELETE FROM importdb.imp_main_det_log WHERE fileid =mixfileid;
  DELETE FROM importdb.aip_manualrun_log WHERE fileid =mixfileid;
  END LOOP;

delete FROM  importdb.imp_vh_control_total WHERE clientid =p_cid;
DELETE FROM importdb.imp_main_log WHERE clientid =p_cid;
delete FRoM importdb.hi_main_log  WHERE clientid =p_cid;
DELETE FROM importdb.aip_dmfilelist_log WHERE client_id= p_cid;
DELETE FROM importdb.aip_cron_log WHERE client_id = p_cid;
delete FRoM importdb.imp_dmfilelist  WHERE clientid =p_cid;
COMMIT;
--exec DELETE_DATABASE_DATA('759','FLMSDEV')

EXCEPTION WHEN OTHERS THEN
BEGIN
v_ErrMsg:=SQLERRM;
Dbms_Output.put_line(v_ErrMsg);
END;
END;
/
