#!/bin/bash
# Script to execute Imported Files Report Package in AI schemas of each client

source /data1/AIP/conf/main.conf

USAGE="
Usage: sh runReport.sh -c  <Clientid> -f <fileid>
       Examples
       sh runReport.sh -c '019' -f '22_11'
"

if [ $# -lt 1 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi
while getopts ":c:f:" options
do
        case $options in
        "c")
        clientId="$OPTARG"
        ;;
        "f")
        FileID="$OPTARG"
        ;;
        ":")
        echo "No argument value for option $OPTARG"
        echo "$USAGE"
        exit;;
        *)
        echo "$USAGE"
        exit;;
        esac
done
#reporttype="ALL"
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
## Atributes used by oracle
schema="${IMPORTDB}${clientId}"
#echo $schema
#server=nveigerworkq1
#sid=d2he
#port=1521
#echo $schema
sqlBase="$BASEDIR/sql/"
#Check of the script exists.Else termnilate
sqlFullPath=${sqlBase}pkg_aip_file_report.sql
if [ ! -f "$sqlFullPath" ]
then
    INFO14="INFO15: Oracle Procedure not found for report"
    echo "$INFO15"
    #export INFO15
    #allLogging "::::$INFO14"
    exit 1
fi
#sqlexe="pkg_aip_file_report.exe_report('"$FileID"')"
sqlexe="declare
VBLQUERY varchar2(4000);
VJOBNUM binary_integer ;
begin
VBLQUERY:= 'begin pkg_aip_file_report.exe_report(''"$FileID"''); end ; ';
DBMS_JOB.SUBMIT(JOB=>VJOBNUM,WHAT=>VBLQUERY,INSTANCE=>1);
COMMIT;
end
"

echo $sqlexe
sqlplus -S "$schema/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$IMPORTDBSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
@$sqlFullPath;
$sqlexe;
/
EOF
exit 1
# End of Script

