#!/bin/bash

#undef OSENV
#OSENV="MACOSX"

if [ "$OSENV" = "MACOSX" ]
then
AWK=/opt/local/bin/gawk
MD5=/opt/local/bin/gmd5sum
STAT=/opt/local/bin/gstat
TAIL=/opt/local/bin/gtail
HEAD=/opt/local/bin/ghead
else
#Linux
AWK=/bin/awk
MD5=/usr/bin/md5sum
STAT=/usr/bin/stat
TAIL=/usr/bin/tail
HEAD=/usr/bin/head
fi

shopt -s extglob

#DEBUGPRT=1
#DBG_TIME_FLG=1
LOGDIR=LOGS
OPTIND=0
#
# exit codes: 0:SUCCESS  1:FAIL  2:WARNING
#
let EXITCODE=0
nnUSAGEFULL="
Usage: getFileStats <datafile> [<attrfile> ]
"
SAMPLEOUT="
SAMPLE#1 without attribute file
getFileStats.sh d5.txt
     getFileStats BEGIN FILENAME:  d5.txt
			NUMLINES:  26
			    SIZE:  1937
		       TIMESTAMP:  2014-04-16 13:09:12
			   CKSUM:  2667880435
			 HASHKEY:  d304aa4fa0e07a33d4c45e75702d90e7
		      DUPRECORDS:  2 [ 20 25 ...]
       getFileStats END FILENAME:  d5.txt

SAMPLE#2 with attribute file
getFileStats.sh d555.txt d555.attr
     getFileStats BEGIN FILENAME:  d555.txt
			NUMLINES:  26
			    SIZE:  1907
		       TIMESTAMP:  2014-04-11 09:57:11
			   CKSUM:  2509706398
			 HASHKEY:  f1278e5ced2bd30234ff18e20c0fe5ea
		      DUPRECORDS:  0 [ ...]
			    FLID:  1001 [DATA FILE]
			  HEADER:  YES [ 1 ]
			 TRAILER:  YES [ 1 ]
			  LAYOUT:  1 [ 21]
	    CTLTOTIDENT:[1=^Z99]:  1
	   CHKNUMFIELDS:[NF!=10]:  0 [ ...]
     CHKVAL:GENDER[5][M,F,EMPTY]:  20 [11 3 6]
       CHKVAL:GENDER[4][K,M,F,L]:  0 [0 0 0 0]
			  LAYOUT:  2 [ 3]
	    CHKNUMFIELDS:[NF!=8]:  0 [ ...]
     CHKVAL:GENDER[4][M,F,EMPTY]:  3 [2 1 0]
		COLSUM:AMOUNT[8]:  400.50
       getFileStats END FILENAME:  d555.txt
"

USAGE="
Usage: getFileStats <datafile> [<attrfile> ]
"

prtUSAGEFULL () {
echo -e "$USAGEFULL $USAGE $SAMPLEOUT" >&2
}

#echo NUMOFARGS=$#

# passing dir names with spaces has lots of problems. So, dump the name in an array and use it. Seems to work seamlessly
declare -A FILENAMES=()
declare -a vhcatcommand=()
#recordtype[$recordidentcnt]
declare recordtype=()
#let nfiles=0

#OPTS=$(getopt -o f:a:h:t:o: --long attr:,out:,$HEADer:,trailer:,help, -- "$@")
#if [ $? != 0 ] ; then echo "Error: Invalid options" ; echo -e "$USAGE" >&2 ; exit 1 ; fi
#eval set -- "$OPTS"

#echo NUMOFARGS=$#
let "numargs = $# - 1"
let "hrows = 0"
let "hrows0 = 0"
let "trows = 0"
let "conditioncnt = 0"
let "recordidentcnt = 0"
let "recordidentfixedcnt = 0"
let "recordidentdelicnt = 0"
let "recordfixed = 0"
let "recorddeli = 0"
listfile=""
#ifile=""
export vhcatflg=""
export CTLTOTFLG=""
export RECFLG=""
export RECORDNEW=""
#while true; do
#    case "$1" in
#        -h | --$HEADer ) hrows=$2; let hrows0=$2+1; shift 2 ;;
#        -t | --trailer ) trows=$2; shift 2;;
#	-f ) FILENAMES[0]="$2"
#	     shift 2 ;;
#	-a | --attr ) attrfile="$2"; shift 2 ;;
#	-o | --out ) logfile="$2"; shift 2 ;;
#	-- ) shift; break ;;
#	--help | * )
#	     prtUSAGEFULL; shift; exit 1 ;;
#    esac
#done

#echo NUMARGS=$#

if [ "$#" = 0 ] ; then echo -e "$USAGE" >&2; exit 1; fi
if [ "$1" = "--help" ] ; then echo -e "$USAGE" >&2; exit 1; fi

if [ $# -gt 0 -a -f "$1" ]
then
FILENAMES[0]="$1"
if [ $# -gt 1 ]
then
   if [ -f "$2" ]
   then
	attrfile="$2"
	declare -a lineArray=()
	o_ifs=$IFS
	IFS=$'\r\n' lineArray=($(grep -v "^#" $attrfile))
	IFS=$o_ifs
	chkinvalid=$(echo "${lineArray[@]}" | grep "INVALID")
	if [[ ${#chkinvalid} != '0' ]];then
	    echo "WARNING: Invalid Attribute file: $attrfile. Ignoring"
	    lineArray=""
	fi
   else
	echo "WARNING: Invalid Attribute file: $attrfile. Ignoring"
   fi
fi
else
echo "ERROR: Invalid data file: $1"
exit 1
fi

#if [ ! -f "${FILENAMES[0]}" ] ; then echo "ERROR: Invalid data file: ${FILENAMES[0]}" >&2; exit 1; fi

#if [ "$attrfile" != "" ]
#then
#     if [ -f "$attrfile" ]
#     then
#	declare -a lineArray=()
#	o_ifs=$IFS
#	IFS=$'\r\n' lineArray=($(grep -v "^#" $attrfile))
#	IFS=$o_ifs
#     else
#	echo "WARNING: Invalid Attribute file: $attrfile. Ignoring"
#     fi
#fi

#echo "DEBUG: ${FILENAMES[0]} $attrfile"

#Declare array for date formats
declare -A DATEARGS=(
[YYDDD]='${DATE:0:2}${DATE:2:3}'
[DDDYY]='${DATE:3:2}${DATE:0:3}'
[YYYYDDD]='${DATE:0:4}${DATE:4:3}'
[DDDYYYY]='${DATE:3:4}${DATE:0:3}'
[YYMMDD]='${DATE:0:2}${DATE:2:2}${DATE:4:2}'
[YYDDMM]='${DATE:0:2}${DATE:4:2}${DATE:2:2}'
[DDMMYY]='${DATE:4:2}${DATE:2:2}${DATE:0:2}'
[MMDDYY]='${DATE:4:2}${DATE:0:2}${DATE:2:2}'
[MMYYDD]='${DATE:2:2}${DATE:0:2}${DATE:4:2}'
[DDYYMM]='${DATE:2:2}${DATE:4:2}${DATE:0:2}'
[YY-MM-DD]='${DATE:0:2}${DATE:3:2}${DATE:6:2}'
[YY-DD-MM]='${DATE:0:2}${DATE:6:2}${DATE:3:2}'
[DD-MM-YY]='${DATE:6:2}${DATE:3:2}${DATE:0:2}'
[MM-DD-YY]='${DATE:6:2}${DATE:0:2}${DATE:3:2}'
[MM-YY-DD]='${DATE:3:2}${DATE:0:2}${DATE:6:2}'
[DD-YY-MM]='${DATE:3:2}${DATE:6:2}${DATE:0:2}'
[YY/MM/DD]='${DATE:0:2}${DATE:3:2}${DATE:6:2}'
[YY/DD/MM]='${DATE:0:2}${DATE:6:2}${DATE:3:2}'
[DD/MM/YY]='${DATE:6:2}${DATE:3:2}${DATE:0:2}'
[MM/DD/YY]='${DATE:6:2}${DATE:0:2}${DATE:3:2}'
[MM/YY/DD]='${DATE:3:2}${DATE:0:2}${DATE:6:2}'
[DD/YY/MM]='${DATE:3:2}${DATE:6:2}${DATE:0:2}'
[YY_MM_DD]='${DATE:0:2}${DATE:3:2}${DATE:6:2}'
[YY_DD_MM]='${DATE:0:2}${DATE:6:2}${DATE:3:2}'
[DD_MM_YY]='${DATE:6:2}${DATE:3:2}${DATE:0:2}'
[MM_DD_YY]='${DATE:6:2}${DATE:0:2}${DATE:3:2}'
[MM_YY_DD]='${DATE:3:2}${DATE:0:2}${DATE:6:2}'
[DD_YY_MM]='${DATE:3:2}${DATE:6:2}${DATE:0:2}'
[RRMMDD]='${DATE:0:2}${DATE:2:2}${DATE:4:2}'
[RRDDMM]='${DATE:0:2}${DATE:4:2}${DATE:2:2}'
[DDMMRR]='${DATE:4:2}${DATE:2:2}${DATE:0:2}'
[MMDDRR]='${DATE:4:2}${DATE:0:2}${DATE:2:2}'
[MMRRDD]='${DATE:2:2}${DATE:0:2}${DATE:4:2}'
[DDRRMM]='${DATE:2:2}${DATE:4:2}${DATE:0:2}'
[RR-MM-DD]='${DATE:0:2}${DATE:3:2}${DATE:6:2}'
[RR-DD-MM]='${DATE:0:2}${DATE:6:2}${DATE:3:2}'
[DD-MM-RR]='${DATE:6:2}${DATE:3:2}${DATE:0:2}'
[MM-DD-RR]='${DATE:6:2}${DATE:0:2}${DATE:3:2}'
[MM-RR-DD]='${DATE:3:2}${DATE:0:2}${DATE:6:2}'
[DD-RR-MM]='${DATE:3:2}${DATE:6:2}${DATE:0:2}'
[RR/MM/DD]='${DATE:0:2}${DATE:3:2}${DATE:6:2}'
[RR/DD/MM]='${DATE:0:2}${DATE:6:2}${DATE:3:2}'
[DD/MM/RR]='${DATE:6:2}${DATE:3:2}${DATE:0:2}'
[MM/DD/RR]='${DATE:6:2}${DATE:0:2}${DATE:3:2}'
[MM/RR/DD]='${DATE:3:2}${DATE:0:2}${DATE:6:2}'
[DD/RR/MM]='${DATE:3:2}${DATE:6:2}${DATE:0:2}'
[RR_MM_DD]='${DATE:0:2}${DATE:3:2}${DATE:6:2}'
[RR_DD_MM]='${DATE:0:2}${DATE:6:2}${DATE:3:2}'
[DD_MM_RR]='${DATE:6:2}${DATE:3:2}${DATE:0:2}'
[MM_DD_RR]='${DATE:6:2}${DATE:0:2}${DATE:3:2}'
[MM_RR_DD]='${DATE:3:2}${DATE:0:2}${DATE:6:2}'
[DD_RR_MM]='${DATE:3:2}${DATE:6:2}${DATE:0:2}'
[YYYYMMDD]='${DATE:0:4}${DATE:4:2}${DATE:6:2}'
[YYYYDDMM]='${DATE:0:4}${DATE:6:2}${DATE:4:2}'
[DDMMYYYY]='${DATE:4:4}${DATE:2:2}${DATE:0:2}'
[MMDDYYYY]='${DATE:4:4}${DATE:0:2}${DATE:2:2}'
[MMYYYYDD]='${DATE:2:4}${DATE:0:2}${DATE:6:2}'
[DDYYYYMM]='${DATE:2:4}${DATE:6:2}${DATE:0:2}'
[CCYYMMDD]='${DATE:0:4}${DATE:4:2}${DATE:6:2}'
[CCYYDDMM]='${DATE:0:4}${DATE:6:2}${DATE:4:2}'
[DDMMCCYY]='${DATE:4:4}${DATE:2:2}${DATE:0:2}'
[MMDDCCYY]='${DATE:4:4}${DATE:0:2}${DATE:2:2}'
[MMCCYYDD]='${DATE:2:4}${DATE:0:2}${DATE:6:2}'
[DDCCYYMM]='${DATE:2:4}${DATE:6:2}${DATE:0:2}'
[RRRRMMDD]='${DATE:0:4}${DATE:4:2}${DATE:6:2}'
[RRRRDDMM]='${DATE:0:4}${DATE:6:2}${DATE:4:2}'
[DDMMRRRR]='${DATE:4:4}${DATE:2:2}${DATE:0:2}'
[MMDDRRRR]='${DATE:4:4}${DATE:0:2}${DATE:2:2}'
[MMRRRRDD]='${DATE:2:4}${DATE:0:2}${DATE:6:2}'
[DDRRRRMM]='${DATE:2:4}${DATE:6:2}${DATE:0:2}'
[DD-MON-YY]='${DATE:7:2}${DATE:3:3}${DATE:0:2}'
[DD-MON-RR]='${DATE:7:2}${DATE:3:3}${DATE:0:2}'
[DD/MON/YY]='${DATE:7:2}${DATE:3:3}${DATE:0:2}'
[DD/MON/RR]='${DATE:7:2}${DATE:3:3}${DATE:0:2}'
[DDMONYYYY]='${DATE:5:4}${DATE:2:3}${DATE:0:2}'
[MONDDYYYY]='${DATE:5:4}${DATE:0:3}${DATE:3:2}'
[DDYYYYMON]='${DATE:2:4}${DATE:6:3}${DATE:0:2}'
[YYYYDDMON]='${DATE:0:4}${DATE:6:3}${DATE:4:2}'
[YYYYMONDD]='${DATE:0:4}${DATE:4:3}${DATE:7:2}'
[MONYYYYDD]='${DATE:3:4}${DATE:0:3}${DATE:7:2}'
[DD-MON-YYYY]='${DATE:7:4}${DATE:3:3}${DATE:0:2}'
[DD/MON/YYYY]='${DATE:7:4}${DATE:3:3}${DATE:0:2}'
[MON-DD-YYYY]='${DATE:7:4}${DATE:0:3}${DATE:4:2}'
[DD-YYYY-MON]='${DATE:3:4}${DATE:8:3}${DATE:0:2}'
[YYYY-DD-MON]='${DATE:0:4}${DATE:8:3}${DATE:5:2}'
[YYYY-MON-DD]='${DATE:0:4}${DATE:5:3}${DATE:9:2}'
[MON-YYYY-DD]='${DATE:4:4}${DATE:0:3}${DATE:9:2}'
[MON/DD/YYYY]='${DATE:7:4}${DATE:0:3}${DATE:4:2}'
[DD/YYYY/MON]='${DATE:3:4}${DATE:8:3}${DATE:0:2}'
[YYYY/DD/MON]='${DATE:0:4}${DATE:8:3}${DATE:5:2}'
[YYYY/MON/DD]='${DATE:0:4}${DATE:5:3}${DATE:9:2}'
[MON/YYYY/DD]='${DATE:4:4}${DATE:0:3}${DATE:9:2}'
[RRRR/MM/DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[RRRR/DD/MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD/MM/RRRR]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM/DD/RRRR]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM/RRRR/DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD/RRRR/MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[RRRR-MM-DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[RRRR-DD-MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD-MM-RRRR]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM-DD-RRRR]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM-RRRR-DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD-RRRR-MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[RRRR_MM_DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[RRRR_DD_MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD_MM_RRRR]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM_DD_RRRR]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM_RRRR_DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD_RRRR_MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[YYYY/MM/DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[YYYY/DD/MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD/MM/YYYY]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM/DD/YYYY]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM/YYYY/DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD/YYYY/MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[YYYY-MM-DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[YYYY-DD-MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD-MM-YYYY]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM-DD-YYYY]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM-YYYY-DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD-YYYY-MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[YYYY_MM_DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[YYYY_DD_MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD_MM_YYYY]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM_DD_YYYY]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM_YYYY_DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD_YYYY_MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[YYYY/MM]='${DATE:0:4}${DATE:5:2}"01"' 
[MM/YYYY]='${DATE:3:4}${DATE:0:2}"01"'
[YYYY-MM]='${DATE:0:4}${DATE:5:2}"01"'
[MM-YYYY]='${DATE:3:4}${DATE:0:2}"01"'
[YYYY_MM]='${DATE:0:4}${DATE:5:2}"01"'
[MM_YYYY]='${DATE:3:4}${DATE:0:2}"01"'
[YYYYMM]='${DATE:0:4}${DATE:4:2}"01"'
[MMYYYY]='${DATE:2:4}${DATE:0:2}"01"'
[CCYY/MM/DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[CCYY/DD/MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD/MM/CCYY]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM/DD/CCYY]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM/CCYY/DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD/CCYY/MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[CCYY-MM-DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[CCYY-DD-MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD-MM-CCYY]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM-DD-CCYY]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM-CCYY-DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD-CCYY-MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[CCYY_MM_DD]='${DATE:0:4}${DATE:5:2}${DATE:8:2}'
[CCYY_DD_MM]='${DATE:0:4}${DATE:8:2}${DATE:5:2}'
[DD_MM_CCYY]='${DATE:6:4}${DATE:3:2}${DATE:0:2}'
[MM_DD_CCYY]='${DATE:6:4}${DATE:0:2}${DATE:3:2}'
[MM_CCYY_DD]='${DATE:3:4}${DATE:0:2}${DATE:8:2}'
[DD_CCYY_MM]='${DATE:3:4}${DATE:8:2}${DATE:0:2}'
[YYYYMMDDHH24MISS]='${DATE:0:4}${DATE:4:2}${DATE:6:2}" "${DATE:8:2}":"${DATE:10:2}":"${DATE:12:2}'
[DDMMYYYYHH24MISS]='${DATE:4:4}${DATE:2:2}${DATE:0:2}" "${DATE:8:2}":"${DATE:10:2}":"${DATE:12:2}'
[MMDDYYYYHH24MISS]='${DATE:4:4}${DATE:0:2}${DATE:2:2}" "${DATE:8:2}":"${DATE:10:2}":"${DATE:12:2}'	
[YYYYDDMMHH24MISS]='${DATE:0:4}${DATE:6:2}${DATE:4:2}" "${DATE:8:2}":"${DATE:10:2}":"${DATE:12:2}'
[CCYYMMDDHHMM]='${DATE:0:4}${DATE:4:2}${DATE:6:2}" "${DATE:8:2}":"${DATE:10:2}'
[DDMMCCYYHHMM]='${DATE:4:4}${DATE:2:2}${DATE:0:2}" "${DATE:8:2}":"${DATE:10:2}'
[MMDDCCYYHHMM]='${DATE:4:4}${DATE:0:2}${DATE:2:2}" "${DATE:8:2}":"${DATE:10:2}'
[CCYYDDMMHHMM]='${DATE:0:4}${DATE:6:2}${DATE:4:2}" "${DATE:8:2}":"${DATE:10:2}'
[YYYY-MM-DDHH:MI:SS]='${DATE:0:4}${DATE:5:2}${DATE:8:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}'
[YYYY-DD-MMHH:MI:SS]='${DATE:0:4}${DATE:8:2}${DATE:5:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[DD-MM-YYYYHH:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[MM-DD-YYYYHH:MI:SS]='${DATE:6:4}${DATE:0:2}${DATE:3:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY/MM/DDHH:MI:SS]='${DATE:0:4}${DATE:5:2}${DATE:8:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY/DD/MMHH:MI:SS]='${DATE:0:4}${DATE:8:2}${DATE:5:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[DD/MM/YYYYHH:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[MM/DD/YYYYHH:MI:SS]='${DATE:6:4}${DATE:0:2}${DATE:3:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY_MM_DDHH:MI:SS]='${DATE:0:4}${DATE:5:2}${DATE:8:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY_DD_MMHH:MI:SS]='${DATE:0:4}${DATE:8:2}${DATE:5:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[DD_MM_YYYYHH:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[MM_DD_YYYYHH:MI:SS]='${DATE:6:4}${DATE:0:2}${DATE:3:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY-MM-DDHH24:MI:SS]='${DATE:0:4}${DATE:5:2}${DATE:8:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY-DD-MMHH24:MI:SS]='${DATE:0:4}${DATE:8:2}${DATE:5:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[DD-MM-YYYYHH24:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}'
[MM-DD-YYYYHH24:MI:SS]='${DATE:6:4}${DATE:0:2}${DATE:3:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY/MM/DDHH24:MI:SS]='${DATE:0:4}${DATE:5:2}${DATE:8:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY/DD/MMHH24:MI:SS]='${DATE:0:4}${DATE:8:2}${DATE:5:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[DD/MM/YYYYHH24:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[MM/DD/YYYYHH24:MI:SS]='${DATE:6:4}${DATE:0:2}${DATE:3:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY_MM_DDHH24:MI:SS]='${DATE:0:4}${DATE:5:2}${DATE:8:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[YYYY_DD_MMHH24:MI:SS]='${DATE:0:4}${DATE:8:2}${DATE:5:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[DD_MM_YYYYHH24:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}' 
[MM_DD_YYYYHH24:MI:SS]='${DATE:6:4}${DATE:0:2}${DATE:3:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}'
[DD.MM.YYYYHH24:MI:SS]='${DATE:6:4}${DATE:3:2}${DATE:0:2}" "${DATE:10:2}":"${DATE:13:2}":"${DATE:16:2}'
[MONDDYYYYHH:MI:SS]='${DATE:5:4}${DATE:0:3}${DATE:3:2}" "${DATE:9:2}":"${DATE:12:2}":"${DATE:15:2}' 
[MONDDYYYYHH:MI]='${DATE:5:4}${DATE:0:3}${DATE:3:2}" "${DATE:9:2}":"${DATE:12:2}'
[MM/DD/YYHH24:MI]='${DATE:6:2}${DATE:0:2}${DATE:3:2}" "${DATE:8:2}":"${DATE:11:2}'	
)

declare -A MonthName=(
[JAN]='01'
[FEB]='02'
[MAR]='03'
[APR]='04'
[MAY]='05'
[JUN]='06'
[JUL]='07'
[AUG]='08'
[SEP]='09'
[OCT]='10'
[NOV]='11'
[DEC]='12'
[Jan]='01'
[Feb]='02'
[Mar]='03'
[Apr]='04'
[May]='05'
[Jun]='06'
[Jul]='07'
[Aug]='08'
[Sep]='09'
[Oct]='10'
[Nov]='11'
[Dec]='12'
[jan]='01'
[feb]='02'
[mar]='03'
[apr]='04'
[may]='05'
[jun]='06'
[jul]='07'
[aug]='08'
[sep]='09'
[oct]='10'
[nov]='11'
[dec]='12'
)
#Date Check Function

mesgNo=0
function addMesg()
{
mesg[$mesgNo]=$1
let mesgNo=mesgNo+1
}


function checkValue()
{	#	echo "${fileContents[@]// /}"
	sum=0
	total=0
	totalInv=0
	declare -a mesg=()
	nullCount=0
	for arrIn in ${fileContents[@]// /}
	do
		field=(${arrIn//:/ })
		DATE=(${field[0]})
		#echo "${arrIn[@]}"
		#echo $DATE
		#exit 0
		if [[ ${#field[@]} -lt 2 ]]
		then
			((sum=$sum+"${field[0]}"))
			((nullCount=$nullCount+"${field[0]}"))
			total="${field[0]}"
		 else
			((sum=$sum+"${field[1]}"))
			total="${field[1]}"
		fi
		#if [[ $DATE == "NULL" ]]
		#then
		#	((nullCount=$nullCount+"${field}"))
		#	continue
		#fi
		eval dateString=${DATEARGS[$dateFormat]}
		#echo "$dateFormat $dateString"
		if [[ -z "$dateString" ]]
		then
			echo " [$dateFormat] Date Format Not Defined "
			break
		
		elif ((${#dateString} == 15 || ${#dateString} == 18))
		then
			subStr=${dateString:4:3}
			dateString="${dateString:0:4}${MonthName[$subStr]}${dateString:7:2} ${dateString:10:5}"
		elif ((${#dateString} == 9))
		then
			subStr=${dateString:4:3}
			dateString=${dateString:0:4}${MonthName[$subStr]}${dateString:7:2} 
		elif ((${#dateString} == 7))
		then
			if [[ "${dateString}" =~ [a-zA-Z] ]]
			then
				subStr=${dateString:2:3}
				dateString=${dateString:0:2}${MonthName[$subStr]}${dateString:5:2}
			else
				subStr=${dateString:4:3}
				temp=$((10#$subStr))
				if [[ "$temp" -gt 29 ]]
				then
					let mon=temp/30
					let days=temp%30
				else
					mon="01";days="$temp"
				fi
				#let days=subStr%30
				if [[ ${#mon} == 1 ]]
				then
					mon="0$mon"
				fi
				if [[ ${#days} == 1 ]]
				then
					days="0$days"
				fi
				dateString=${dateString:0:2}${mon}${days}
			fi
		elif ((${#dateString} == 5))
		then
			subStr=${dateString:2:3}
			temp=$((10#$subStr))
			if [[ "$temp" -gt 29 ]]
			then
				let mon=temp/30
				let days=temp%30
			else
				mon="01";days="$temp"
			fi
			#let days=subStr%30
			if [[ ${#mon} == 1 ]]
			then 
				mon="0$mon"
			fi
			if [[ ${#days} == 1 ]]
			then
				days="0$days"
			fi
			dateString=${dateString:0:2}${mon}${days}
		else
			dateString="$dateString"
		fi
		#echo "$dateString"
		#echo $mon $days
		date -d "$dateString" &> /dev/null
		#date -d "$dateString" 
		status=$?
		if (($status != 0))
		   then
			((totalInv=$totalInv+"$total"))
			addMesg "$arrIn"
		fi
		#((total+=1))
	done
	ADDMSG "CHKDATE ${fieldname}[${column}][${dateFormat}]# $sum [Invalid:$totalInv, Null:$nullCount] [${mesg[0]}, ${mesg[1]} ,${mesg[2]} ...]"
}

declare -A DELIMETERS=( 
[TILD]='~'
[FIXED]='\n'
[PIPE]='|'
[COMA]=','
[COLN]=':'
[TAB]='\t'
[SCLN]=';'
[DOLR]='$'
[EXCL]='!'
[CAPS]='^'
[ATSI]='@'
[HASH]='#'
[DBQUOTES]='\"'
[PLUS]='+'
)

let nmsgs=0
declare -A MSGS=()

dbgPRINT () { if [ "$DEBUGPRT" = "1" ]; then echo "$@"; fi }


#GETARGS() {
#read a1 a2 a3 a4 a5 a6 <<< $(echo "$1" | $AWK -F'|' '{print $1 " " $2 " " $3 " " $4 " " $5 " " $6}')
#}

GETARGS(){
    a1=$(echo "$1" | $AWK -F'|' '{print $1}')
    a2=$(echo "$1" | $AWK -F'|' '{print $2}')
    a3=$(echo "$1" | $AWK -F'|' '{print $3}')
    a4=$(echo "$1" | $AWK -F'|' '{print $4}')
    a5=$(echo "$1" | $AWK -F'|' '{print $5}')
    a6=$(echo "$1" | $AWK -F'|' '{print $6}')
    a7=$(echo "$1" | $AWK -F'|' '{print $7}')
    a8=$(echo "$1" | $AWK -F'|' '{print $8}')
}

ADDMSG() {
MSGS[$nmsgs]="$1"
let nmsgs=$nmsgs+1
}

DBG_TIMESTAMP()
{
dbg_label="$1"
if [ "$DBG_TIME_FLG" = "1" ] ; then
dbgmsg=$(echo "$dbg_label# " `date "+%F %T"`)
ADDMSG "$dbgmsg"
fi
}

#
# custom 'cat' to exclude the $HEADer, trailer and any control total lines
#
VHCAT(){
    local IFS=$'\n'
    local cnt1=$conditioncnt
    local strand=''
    if [[ $conditioncnt == '0' ]];then
	eval VHCAT1
    else

	#echo "$str2"
	#echo "${vhcatcommand[2]}"
	#echo "${vhcatcommand[1]}"
	#eval VHCAT1 | head -n 2
	if [[ ${recordcond[0]} == "AND" ]]; then
	    while [[ $cnt1 -ge 1 ]]; do
		strand+=' | eval ${vhcatcommand['$cnt1']}'
		((cnt1=cnt1-1))
	    done
	    #eval VHCAT1 | eval "${vhcatcommand[1]}"
	    eval VHCAT1 "$strand"
	   # echo  "${vhcatcommand[1]}"
	elif [[ ${recordcond[0]} == "OR" ]]; then
	    #VHCAT1
	    #echo "$str3"
	    #eval "$str3"
	    #eval "${vhcatcommand[1]} ${FILENAMES[0]}"
	    local mainstr='awk "{arr[$0]++}END{for(i in arr){print i}}" <(eval VHCAT1)'
	    while [[ $cnt1 -ge 1 ]]; do
		local str1=$(echo "'$TAIL -n +$hrows0 '"${FILENAMES[0]}"' | $HEAD -n -"$trows0" | ${vhcatcommand["$cnt1"]}'" | sed -e 's:arr\[1\]:NR:g' -e 's:arr\[2\]:$0:g' -e 's:split.*BLANKS:if(pat=="BLANKS:g' -e "s:^'::g" -e "s:'$::g")
		#echo "$str1"
		#exit
		mainstr+=" <($str1)"
		((cnt1=cnt1-1))
	    done
	    mainstr=$(echo "$mainstr" | sed "s:\"{:'{:g" | sed "s:}\":}':g")
	    #echo "$mainstr"
	    eval "$mainstr"
	    #eval VHCAT1
	    #awk '{arr[$0]++}END{for(i in arr){print i}}' <(eval VHCAT1) <(eval "$str3")
	else
	   eval VHCAT1 | eval "${vhcatcommand[$cnt]}"
	fi
    fi
	
}

VHCAT1() {
    local IFS=$'\n'
    if [ "$CTLTOTFLG" = "" ]
    then
	if [[ "$RECORDNEW" == "FIXED" ]]
	then
	    if [[ $condition == "!=" ]]
	    then
		$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v sp="$startpos" -v w="$width" -v pat="$patt" '{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp!=""){ans=$0;printf "%d++%s\n",NR,ans}}else{if(substr($0,sp,w)!=pat){ans=$0;printf "%d++%s\n",NR,ans}}}'
	    else
		$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v sp="$startpos" -v w="$width" -v pat="$patt" '{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp==""){ans=$0;printf "%d++%s\n",NR,ans}}else{if(substr($0,sp,w)==pat){ans=$0;printf "%d++%s\n",NR,ans}}}'
	    fi
	elif [[ "$RECORDNEW" == "DELI" ]]
	then
	    if [[ $condition == "!=" ]]
	    then
	#$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v colno="$col" -v pat="$patt" -F"$deliValue" '{if($colno!=pat){ans=$0;printf"%d++%s\n",NR,ans}}'
		$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v colno="$col" -v pat="$patt" -F"$deliValue" '{if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno!=""){ans=$0;printf "%d++%s\n",NR,ans}}else{if($colno!=pat){ans=$0;printf "%d++%s\n",NR,ans}}}'
	    else
	#$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v colno="$col" -v pat="$patt" -F"$deliValue" '{if($colno==pat){ans=$0;printf"%d++%s\n",NR,ans}}'
		$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v colno="$col" -v pat="$patt" -F"$deliValue" '{if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno==""){ans=$0;printf "%d++%s\n",NR,ans}}else{if($colno==pat){ans=$0;printf "%d++%s\n",NR,ans}}}'
	    fi
	else
	    $TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -$trows0
	fi
    else
	if [ "$RECFLG" = "" ]
	then
	    $TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | grep -v "$CTLTOTFLG"
	else
	    $TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | grep -v "$CTLTOTFLG" | grep "$RECFLG"
	fi
    fi

}


___VHCAT() {

    local cnt=$recordidentcnt
    if [[ $cnt == 0 ]];then
	$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -$trows0
	echo "Cnt first"
    else
	#while [[ $cnt -ge 1 ]];do
	echo "${vhcatcommand[1]}"
	echo "${vhcatcommand[2]}"
	if [[ ${recordcond[0]} == "AND" ]]; then
	    $TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -$trows0 | eval "${vhcatcommand[1]}" | eval "${vhcatcommand[2]}"
	elif [[ ${recordcond[0]} == "OR" ]]; then
	    $TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -$trows0 | eval "${vhcatcommand[$cnt]}"
	else
	    $TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -$trows0 | eval "${vhcatcommand[$cnt]}"
	fi
	 #   ((cnt=cnt-1))
	#done
    fi

#echo "From VCAT FUNCTION"
##a=substr($0,8,3);gsub("[[:space:]]","",a);if(a==""){print "T"}
    if [ "$CTLTOTFLG" = "" ]
    then
	sed "$vhcatflg" "${FILENAMES[0]}"
    else
	if [ "$RECFLG" = "" ]
	then
	    sed "$vhcatflg" "${FILENAMES[0]}" | grep -v "$CTLTOTFLG" 
	else
	    sed "$vhcatflg" "${FILENAMES[0]}" | grep -v "$CTLTOTFLG" | grep "$RECFLG"
	fi
    fi


}

f_vhcatstrbuild(){
#echo "From VCAT FUNCTION"
##a=substr($0,8,3);gsub("[[:space:]]","",a);if(a==""){print "T"}
    if [[ "$RECORDNEW" == "FIXED" ]]
    then
	if [[ $condition == "!=" ]]
	then
	    str=$(echo '$AWK -v sp="'$startpos'" -v w="'$width'" -v pat="'$patt'" "{split($0,arr,"[+]{2}");sub("\r","",arr[2]);if(pat=="BLANKS"){temp=substr(arr[2],sp,w);gsub("[[:space:]]","",temp);if(temp!=""){ans=arr[2];printf "%d++%s\n",arr[1],ans}}else{if(substr(arr[2],sp,w)!=pat){ans=arr[2];printf "%d++%s\n",arr[1],ans}}}"')
	    #str=$(echo '$AWK -v sp="'$startpos'" -v w="'$width'" -v pat="'$patt'" "{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp!=""){ans=$0;printf "%d++%s\n",NR,ans}}else{if(substr($0,sp,w)!=pat){ans=$0;printf "%d++%s\n",NR,ans}}}"')
	else
	    str=$(echo '$AWK -v sp="'$startpos'" -v w="'$width'" -v pat="'$patt'" "{split($0,arr,"[+]{2}");sub("\r","",arr[2]);if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp==""){ans=arr[2];printf "%d++%s\n",arr[1],ans}}else{if(substr(arr[2],sp,w)==pat){ans=arr[2];printf "%d++%s\n",arr[1],ans}}}"')
	fi
    elif [[ "$RECORDNEW" == "DELI" ]]
    then
	if [[ $condition == "!=" ]]
	then
	#$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v colno="$col" -v pat="$patt" -F"$deliValue" '{if($colno!=pat){ans=$0;printf"%d++%s\n",NR,ans}}'
	    str=$(echo '$AWK -v colno="'$col'" -v pat="'$patt'" -F"'$deliValue'" "{split($0,arr,"[+]{2}");sub("\r","",arr[2]);gsub("^[0-9+]+","",$1);if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno!=""){ans=arr[2];printf "%d++%s\n",arr[1],ans}}else{if($colno!=pat){ans=arr[2];printf "%d++%s\n",arr[1],ans}}}"')
	else
	#$TAIL -n +$hrows0 "${FILENAMES[0]}" | $HEAD -n -"$trows0" | $AWK -v colno="$col" -v pat="$patt" -F"$deliValue" '{if($colno==pat){ans=$0;printf"%d++%s\n",NR,ans}}'
	    str=$(echo '$AWK -v colno="'$col'" -v pat="'$patt'" -F"'$deliValue'" "{split($0,arr,"[+]{2}");sub("\r","",arr[2]);gsub("^[0-9+]+","",$1);if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno==""){ans=arr[2];printf "%d++%s\n",arr[1],ans}}else{if($colno==pat){ans=arr[2];printf "%d++%s\n",arr[1],ans}}}"')
	fi
    else
	str=$(echo '$TAIL -n "+'$hrows0'" "'${FILENAMES[0]}'" | $HEAD -n "-'$trows0'"')
    fi
    str=$(echo "$str" | sed -e "s:\"{:'{:g" -e "s:}}\":}}':g")
    #echo "$str $recordidentcnt"
    vhcatcommand[$recordidentcnt]="$str"
}


isKeyValid() {
eval 'local keys=${!lineArray[@]}';
eval "case '$1' in
${keys// /|}) echo \${lineArray[$1]};return 0 ;;
* ) return 1 ;;
esac";
}

#DELETE
#  CTLTOTLINE|1|1=4
#
# SAMPLE fileattr.def file that is returned from getFLID
#
#  FLID|1|1001
#  LAYOUTNUM|number
#  H  DER|1
#  TRAILER|1
#  PUCHCHAR|N
#  RECORDIDENT|PIPE|COLNUM|VAL
#  CTLTOTIDENT|PIPE|COLNUM|VAL
#  OPTENC|N
#  CHKNUMFIELDS|PIPE|NUM
#  CHKVAL|GENDER|PIPE|COLNUM|VAL1,VAL2,VAL3,..,VALn
#  COLSUM|AMOUNT|PIPE|11
#  CTLTOTIDENTFIXED|START|LEN|VAL
#  RECORDIDENTFIXED|START|LEN|VAL
#  CHKLENFIXED|START|END
#  CHKVALFIXED|GENDER|START,LEN|VAL1,VAL2,VAL3,..,VALn
#  COLSUMFIXED|LABEL|start,len

# each line can have a max 6 tokens
# each line is split into tokens and set to variables, a1, a2, ....,a6  (Mar 2014)
#  FLID|1|1001  #  FLID|0   #  FLID|2|1001	a2= 1:datafile, 0:unknown, 2:ctltotal file
f_flid () {
dbgPRINT "In f_flid: $1"
DBG_TIMESTAMP "BEGIN f_flid: "
#dbgPRINT a1=$a1 :: a2=$a2 :: a3=$a3
FLID=""
if [ "$a2" = 1 -o  "$a2" = 2 ]
then
   FLID=$a3
   TYPE="DATA FILE"
   if [ "$a2" = "2" ]; then TYPE="CTLTOTAL FILE"; fi
   ADDMSG "FLID# $a3 [$TYPE]"
else
   EXITCODE=1
   ADDMSG "ERROR# UNKNOWN FILE TYPE=${FILENAMES[0]}"
fi
DBG_TIMESTAMP "END f_flid: "
}

# LAYOUTNUM|1
f_layoutnum() {
    dbgPRINT "In f_layoutnum: $1"
#DBG_TIMESTAMP "BEGIN f_layoutnum: "
    CURLAYOUT=$a2
    cntlay=$totlines
#cntlay=$(cat "${FILENAMES[0]}" | wc -l)
    if [[ $recordidentflag == 'T' ]];then
#VHCAT "${FILENAMES[0]}" | wc -l
	if [ "$RECFLG" = "" ]
	then
	    cntlay=$(VHCAT | $AWK 'END{print FNR}')
	    #VHCAT | wc -l
	else
	    cntlay=$(VHCAT | grep "$RECFLG" "${FILENAMES[0]}" | $AWK 'END{print FNR}')
	fi
    else
	if [ ! -z $hrows ] || [ ! -z $trows ]; then
    #((csntlay=cntlay-hrows-trows))
	    ((cntlay=cntlay-hrows))
	    ((cntlay=cntlay-trows))
    #echo "From layout $cntlay"
	fi
    fi
    dbgPRINT "$cnt LAYOUT# $CURLAYOUT [$cntlay]"
    ADDMSG "LAYOUT# $CURLAYOUT ${cntlay}"
#DBG_TIMESTAMP "END f_layoutnum: "
}

#  HEADER|1
f_header () {
dbgPRINT "In f_header: $1"
DBG_TIMESTAMP "BEGIN f_header: "
   hrows=$a2
   let hrows0=$a2+1
   if [[ $hrows != "0" ]]; then
       HEADER='1'
       ADDMSG "HEADER# YES [ $a2 ]"
   fi 
DBG_TIMESTAMP "END f_$header: "
}

__f_header () {
dbgPRINT "In f_header: $1"
HEADER=""
if [ $a2 = "1" ]
then
   HEADER=1
   hrows=$a2
   let hrows0=$a2+1 
   ADDMSG "Header# YES [ $a2 ]"
fi
if [ "$HEADER" = "1" -a "$TRAILER" = "1" ] ; then  
	vhcatflg='1d;$d'
elif [ "$HEADER" = "1" ]  ; then
	vhcatflg='1d'
elif [ "$TRAILER" = "1" ] ;  then
	vhcatflg='$d'
fi
}

#  TRAILER|1
f_trailer () {
dbgPRINT "In f_trailer: $1"
#DBG_TIMESTAMP "BEGIN f_trailer: "
TRAILER=""
trows=$a2
let trows0=0
if [[ $trows != "0" ]]
then
   TRAILER=1
   trows0=$a2
   ADDMSG "TRAILER# YES [ $a2 ]"
fi

if [ "$HEADER" = "1" -a "$TRAILER" = "1" ] ; then  
	vhcatflg='1d;$d'
elif [ "$HEADER" = "1" ]  ; then
	vhcatflg='1d'
elif [ "$TRAILER" = "1" ] ;  then
	vhcatflg='$d'
fi
#DBG_TIMESTAMP "END f_trailer: "
}

# PUCHCHAR|Y
f_puchchar() {
dbgPRINT "In f_puchchar : $1"
#DBG_TIMESTAMP "BEGIN f_puchchar: "
PUCHCHAR=""
if [[ $a2 == "Y" ]]; then
PUCHCHAR="Y"
else
PUCHCHAR="N"
fi
#DBG_TIMESTAMP "END f_puchchar: "
}

f_recordcondition(){
    dbgPRINT "TBD: In f_recordcondition: $1 $a2"
    DBG_TIMESTAMP "BEGIN f_recordcondition: "
    recordcond[$conditioncnt]="$a2"
    ((conditioncnt=conditioncnt+1))
    dbgPRINT "$conditioncnt RECORDCONDITION# $a2 [$conditioncnt]"
#ADDMSG "LAYOUT# $CURLAYOUT ${cnt}"
    DBG_TIMESTAMP "END f_recordcondiion: "
}

# record identifier - FIXED
f_recordident() {
    dbgPRINT "TBD: In f_recordident: $1 $a2"
    DBG_TIMESTAMP "BEGIN f_recordident: "
    recordidentflag="T"
    recordtype[$recordidentcnt]="$a2"
    ((recordidentcnt=recordidentcnt+1))
#let "recordidentfixedcnt = 0"
#let "recordidentdelicnt = 0"
    if [[ $a2 == "FIXED" ]]
    then
	patt=$(echo "$a5" | sed -e 's:^[[:space:]]::' -e 's:[[:space:]]$::')
	condition="$a4"
	startpos=$(echo $a3 | $AWK -F',' '{print $1}')
	width=$(echo $a3 | $AWK -F',' '{print $2}')
	RECORDNEW='FIXED'
	f_vhcatstrbuild
	#((recordidentfixedcnt=recordidentfixedcnt+1))
    else
	delimeter="$a2"
	deliValue=${DELIMETERS[$delimeter]}
	col="$a3"
	condition="$a4"
	patt=$(echo "$a5" | sed -e 's:^[[:space:]]::' -e 's:[[:space:]]$::')
	RECORDNEW='DELI'
	f_vhcatstrbuild
	#((recordidentdelicnt=recordidentdelicnt+1))
    fi

#VHCAT "${FILENAMES[0]}" | wc -l
    #VHCAT
  #  if [ "$RECFLG" = "" ]
   # then#
#	cnt=$(VHCAT | $AWK 'END{print FNR}')
#    else
#	cnt=$(VHCAT | grep "$RECFLG" "${FILENAMES[0]}" | $AWK 'END{print FNR}')
 #   fi
    
  #  dbgPRINT "$cnt LAYOUT# $CURLAYOUT [$cnt]"
  #  ADDMSG "LAYOUT# $CURLAYOUT ${cnt}"
    DBG_TIMESTAMP "END f_recordident: "
}

#  CTLTOTLINE|1|^4
#  CTLIDENT|DELIMETER|COLNUM|VAL
#  CTLIDENT|PIPE|1|4
f_controlline(){
dbgPRINT "In f_controlline:"
}

f_ctltotident() {
dbgPRINT "In f_ctlident: $1"
DBG_TIMESTAMP "BEGIN f_ctltoident: "
if [ $a3 = "1" ]
then
   CTLTOTFLG="$a4"
   cnt=$(grep "$a4" "${FILENAMES[0]}" | $AWK 'END{print FNR}')
   ADDMSG "$a1[$a3=$a4]# $cnt"
fi
DBG_TIMESTAMP "END f_ctltotident: "
}

f_optionallyenc(){
DBG_TIMESTAMP "BEGIN f_optionallyenc: "
optencchar="${DELIMETERS[DBQUOTES]}"
if [[ $a2 == "Y" ]]; then
OPTIONALLYENCFLG="TRUE"
ADDMSG "OPTENC# TRUE"
else
OPTIONALLYENCFLG="FALSE"
ADDMSG "OPTENC# FALSE"
fi
DBG_TIMESTAMP "END f_optionallyenc: "
}


# exclude $HEADer, trailer, ctltotal lines and check for the number of flds in the rest of the lines
# print total count and line numbers (10) of the records that dont match reqd # flds. 
# print actual number of the line from raw file, ie: not after removing hdr,trailer,ctl etc

#CHKNUMFIELDS|PIPE|12
f_chknumfields() {
dbgPRINT "In f_numfieldsdel: $1"
DBG_TIMESTAMP "BEGIN f_chknumfields: "
d="${DELIMETERS[$a2]}"
#cat "$ifile" | $AWK -F"$d" 'lcnt=0; NF!=val {++lcnt} END {print lcnt}' val="$a3"
#tcnt=$(eval VHCAT "$ifile" | $AWK -F"$d" 'NF!=val  {lcnt++} END {print lcnt}' val="$a3")
#nlines=$(cat "$ifile" | $AWK -F"$d" 'NF!=val {print NR}' val=$a3 | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS')
##ll=$(eval VHCAT "$ifile" | g$AWK -v val=$a3 -F"$d" 'NF!=val {lcnt++; print NR} END {print "UNMATCHED: lcnt}' | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS')
#get all the line numbers where num of fields not equal to the given number
#eval VHCAT | head -n 3
if [ -z $RECORDNEW ]; then
    if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
	#ll=$(eval VHCAT "${FILENAMES[0]}" | $AWK -F"${optencchar}${d}${optencchar}" 'NF!=val {lcnt++; printf "%d-%d\n",NR,NF} END {print lcnt}' val="$a3")
	ll=$(eval VHCAT  | sed -e "s/${d}\(\"[^\"]*\"\)*/==\1/g" | $AWK -F"==" 'NF!=val {lcnt++; printf "%d-%d\n",NR,NF} END {print lcnt}' val="$a3")
    else
	ll=$(eval VHCAT  | $AWK -F"$d" 'NF!=val {lcnt++; printf "%d-%d\n",NR,NF} END {print lcnt}' val="$a3")
    fi
else
    if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
	ll=$(eval VHCAT | sed -e "s/${d}\(\"[^\"]*\"\)*/==\1/g" | $AWK -F"==" 'NF!=val {split($0,arr,"[+]{2}");lcnt++; printf "%d-%d\n",arr[1],NF} END {print lcnt}' val="$a3")
    else
	ll=$(eval VHCAT | $AWK -F"$d" 'NF!=val {split($0,arr,"[+]{2}");lcnt++; printf "%d-%d\n",arr[1],NF} END {print lcnt}' val="$a3")
    fi
fi
if [ "$ll" = "" ]; then ll="0"; fi

#get the total number of lines that didn't match the num of fields
tcnt=$(echo -e $ll | $AWK -F' ' '{print $NF}')

#truncate the list to 10 line numbers
nlines=$(eval echo -e $ll | $AWK -F' ' '{$NF=""}1' | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS' | cut -d' ' -f1-10 | sed -e 's: :, :g')

#echo "TCNT= $tcnt,  TLIST=$tlist"
if [ "$tcnt" = "" ]; then tcnt=0; fi
ADDMSG "$a1 [NF!=$a3]# $tcnt [ $nlines ...]"

if [ "$tcnt" != "0" ]; then EXITCODE=1; fi

let "conditioncnt = 0"
let "recordidentcnt = 0"
DBG_TIMESTAMP "END f_chknumfields: "
}

#CHKVAL|GENDER|PIPE|4|M,F,EMPTY
#
#f_chkval () {
#   dbgPRINT "In f_chkvaldel: $1  subargs: $a1, $a2, $a3, $a4, $a5"

#check if delimeter is valid/supported
#   if [	${DELIMETERS[$a3]} ]
#   then
#      col=$a4
#      let "tot=0"
#      nlist=""
#      d="${DELIMETERS[$a3]}"
#
#      if [ "$a5" != "" ]
#      then
#	nv=$(echo "$a5" | $AWK -F',' '{print NF}')
#	dbgPRINT "Number of values: $nv"
#
#	for (( i=1; i<$nv+1; i++ ))
#	do
#	   val=$(echo "$a5" | $AWK -F',' '{print $pos}' pos=$i )
#	   if [ "$val" = "EMPTY" ]; then
#		nn=$(VHCAT | $AWK -F"$d" '!$colnum && $colnum != 0 {lcnt++} END {print lcnt}' colnum="$col")
#	   else
#		nn=$(VHCAT | $AWK -F"$d" '$colnum == val {lcnt++} END {print lcnt}' colnum="$col" val="$val")
#	   fi
#	   dbgPRINT "VAL=$val, NN=$nn"
#	   if [ "$nn" = "" ]; then nn=0; fi
#          nlist=`echo $nlist" "$nn`
#	   let "tot = $tot + $nn"
#	done
# 
#   	ADDMSG "$a1 $a2[$col][$a5]# $tot [$nlist]"
#      fi
#   else
#	#CHKVAL|GENDER|PIPE|4|M,F,EMPTY|1,1=4
#   	ADDMSG "WARNING-$a1 Invalid delimeter [ $a3 ]# [$a1] DIRECTIVE IGNORED"
#   fi
#dbgPRINT "ARGS: label=$a2; d=$d; vals=$v1, $v2"
#}
f_chkval () {
    dbgPRINT "In f_chkvaldel: $1  subargs: $a1, $a2, $a3, $a4, $a5"
    DBG_TIMESTAMP "BEGIN f_chkval: "
#check if delimeter is valid/supported
    if [ ${DELIMETERS[$a3]} ]
    then
	col=$a4
	let "tot=0"
	let "k=0"
	nlist=""
	d="${DELIMETERS[$a3]}"
	chkvalues=($(echo "$a5" | $AWK 'BEGIN{FS=","}{for(i=1;i<=NF;i++)print $i}'))
	oldIFS="$IFS"
	IFS=$'\n'

	if [ -z $RECORDNEW ]; then
	    #if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
  #mm=($(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v colnum=$a4 '{print $colnum}' | sort | uniq -c))
		#mm=($(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v colnum=$a4 '{sub(/^[ \t]+|[ \t]+$/,"",$colnum);count[$colnum]++} END { for(i in count){printf "%d %s\n",count[i],i;}}' | sort -g -r))
	    #else
		mm=($(VHCAT | $AWK -F"$d" -v colnum=$a4 -v optencchar="$optencchar" '{sub(/^[ \t]+|[ \t]+$/,"",$colnum);gsub(optencchar,"",$colnum);count[$colnum]++} END { for(i in count){printf "%d %s\n",count[i],i;}}' | sort -g -r))
	    #fi
	else
	    #if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
  #mm=($(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v colnum=$a4 '{print $colnum}' | sort | uniq -c))
		#mm=($(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v del="$d" -v colnum=$a4 '{split($0,arr,"[+]{2}");split(arr[2],data,del);sub(/^[ \t]+|[ \t]+$/,"",data[colnum]);count[data[colnum]]++}END{for(i in count){printf "%d %s\n",count[i],i;}}' | sort -g -r))
	    #else
		mm=($(VHCAT | $AWK -v del="$d" -v colnum=$a4  -v optencchar="$optencchar" '{split($0,arr,"[+]{2}");split(arr[2],data,del);sub(/^[ \t]+|[ \t]+$/,"",data[colnum]);gsub(optencchar,"",data[colnum]);count[data[colnum]]++}END{for(i in count){printf "%d %s\n",count[i],i;}}' | sort -g -r))
	    #fi
	fi

	if [ "$a5" != "" ]
	then
#nv=$(echo "$a5" | $AWK -F',' '{print NF}')
#dbgPRINT "Number of values: $nv"
#for (( i=1; i<$nv+1; i++ ))
	    for (( i=0; i<${#mm[@]}; ((i=i+1)) ))
	    do
   #val=$(echo "$a5" | $AWK -F',' '{print $pos}' pos=$i )
   #if [ "$val" = "EMPTY" ]; then
   #nn=$(VHCAT | $AWK -F"$d" '!$colnum && $colnum != 0 {lcnt++} END {print lcnt}' colnum="$col")
   #else
   #	nn=$(VHCAT | $AWK -F"$d" '$colnum == val {lcnt++} END {print lcnt}' colnum="$col" val="$val")
   #fi
   #dbgPRINT "VAL=$val, NN=$nn"
   #if [ "$nn" = "" ]; then nn=0; fi
   #echo $i
   #fieldvalchk=`echo "${fieldval[$k]}" | grep "${mm[$j]}"`
   #if [ ! -z ${fieldvalchk} ]; then
   #    nlist=`echo $nlist" "${mm[$i]}`
   #else
  #( mod=${#mm[@]}%2))
   #if [ $mod -eq 1 ]; then
   #    nlist=`echo $nlist" "EMPTY:${mm[$i]},`
   #    let "tot = $tot + ${mm[$i]}"
   #    ((i=i-1))
   #else
   #    ((j=i+1))
   #    nlist=`echo $nlist" "${mm[$j]}:${mm[$i]},`
   #    let "tot = $tot + ${mm[$i]}"
   #fi
   #echo ${mm[$i]} | $AWK -F' ' '{printf "%s %s %s\n",$1,$2,$3}'
		nlist+=`echo ${mm[$i]} | $AWK -F' ' '{if($2==""){printf "EMPTY:%s, ",$1;}else{for(q=2;q<=NF;q++){printf " %s",$q}printf ":%s, ",$1;}}'`
		intval=`echo ${mm[$i]} | $AWK -F' ' '{printf "%d",$1}'`
   #nlist+=`echo ${mm[$i]} | $AWK -F' ' '{if($2==""){printf "EMPTY:%s, ",$1;}else{printf "%s:%s, ",$2,$1;}}'`
   #intval=`echo ${mm[$i]} | $AWK -F' ' '{printf "%d",$1}'`
		let "tot = $tot + $intval"
  # if [ $i -ne 0 ]; then
  # ((k=k/i))
  # fi
	    done

	    chkval_invalid
#nlist=$(echo "$nlist" | sed 's/, $//' | cut -d',' -f1-10)
	    ADDMSG "$a1 $a2[$col][$a5]# $tot [Valid:$validsum , Invalid:$invalidsum , Samples: {${nlistinvalid} ...} ]"
	fi
    else
#CHKVAL|GENDER|PIPE|4|M,F,EMPTY|1,1=4
	ADDMSG "WARNING-$a1 Invalid delimeter [ $a3 ]# [$a1] DIRECTIVE IGNORED"
    fi
    IFS="$oldIFS"
    DBG_TIMESTAMP "END f_chkval: "
#dbgPRINT "ARGS: label=$a2; d=$d; vals=$v1, $v2"
}

chkval_invalid()
{
    let "invalidsum=0"
    let "validsum=0"
    nlist=$(echo "$nlist" | sed 's/, $//')
    #echo "$nlist"
    invalidresult=$(echo "${nlist}" | awk '
{
    split($0,arr,",");
    split(values,arr1," ");
    for(i in arr){
        split(arr[i],a,":");
        sub(/^[ \t]+|[ \t]+$/,"",a[1]);
        sub(/^[ \t]+|[ \t]+$/,"",a[2]);
        temp=a[1]":"a[2];
        temp1=""
        for(j in arr1){
            if(arr1[j]==a[1]){
                delete arr[i];
                delete arr1[j]}
        }
    }
}
END{
    lvalues=length(arr);
    chkvalues=length(arr1);
    if(lvalues==0 && chkvalues>=1)
    {
        for(k in arr1)
        {
                   {printf "%s:0, ",arr1[k]}
        }
    }
    else if(lvalues>=1 && chkvalues==0)
    {
        for(b in arr)printf "%s, ",arr[b]
    }
    else if(lvalues>=1 && chkvalues>=1)
    {
            for(c in arr)
            {
                printf "%s, ",arr[c];
            }
            for(d in arr1)
            {
                   {printf "%s:0, ",arr1[d]}
            }
    }
}
' values="$(echo ${chkvalues[@]})"
)
    invalidsum=$(echo "${nlist}" | awk '
BEGIN{    sum=0;}
{
    split($0,arr,",");
    split(values,arr1," ");
    for(i in arr){
	split(arr[i],a,":");
	sub(/^[ \t]+|[ \t]+$/,"",a[1]);
	sub(/^[ \t]+|[ \t]+$/,"",a[2]);
	temp=a[1]":"a[2];
	for(j in arr1){
	    if(arr1[j]==a[1]){
		delete arr[i];
		delete arr1[j]}
	}
    }
} 
END{
    lvalues=length(arr);
    chkvalues=length(arr1);
    if(lvalues==0 && chkvalues>=1)
    {
	for(k in arr1)
	{
            printf "SUM<0< \n";
	}
    }
    else if(lvalues>=1 && chkvalues==0)
    {
	for(b in arr)
      {
        split(arr[b],a,":");
        printf "SUM<%d< \n",a[2];
       }
    }
    else if(lvalues>=1 && chkvalues>=1)
    {
	if(lvalues>chkvalues)
	{
	    for(c in arr)
	    {
                split(arr[c],a,":");
                 printf "SUM<%d< \n",a[2];
	    }
	}
	else
	{
	    for(c in arr)
	    {
                split(arr[c],a,":");
                printf "SUM<%d< \n",a[2];
	    }
	}
    }
}
' values="$(echo ${chkvalues[@]})"
)
    for val in ${chkvalues[@]}
    do
	#echo $val
	#validresult+=$(
	#echo "$nlist" | awk -v val="$val" 'BEGIN{split($0,arr,",")}{for(i in arr){split(i,a,":");if(a[0]=="val"){print i}}}'
	#echo "$nlist"
	validresult+="$(echo "${nlist}" | awk '{split($0,arr,",");for(i in arr){split(arr[i],a,":");sub(/^[ \t]+|[ \t]+$/,"",a[1]);if(val==a[1]){printf "%s, ",arr[i]}}}' val="$val")"
	validsum+="$(echo "${nlist}" | awk '{split($0,arr,",");for(i in arr){split(arr[i],a,":");sub(/^[ \t]+|[ \t]+$/,"",a[1]);sub(/^[ \t]+|[ \t]+$/,"",a[2]);if(val==a[1]){printf "SUM<%d< ",a[2]}}}' val="$val")"
	validsum+=$'\n'
	#invalidresult+=$(echo "$val" | awk '{split(nlist,arr,",");for(i in arr){split(arr[i],a,":");sub(/^[ \t]+|[ \t]+$/,"",a[1]);sub(/^[ \t]+|[ \t]+$/,"",a[2]);if($0!=a[1]){sum=a[2];printf "%s, ",arr[i]}}printf "\n"}END{printf "SUM<%d<\n",sum}' nlist="$nlist")
	#echo "$validresult"
    done
    #echo "$validsum"
    #echo "$validresult"
    invalidsum=$(echo "$invalidsum" | awk -F'<' '/SUM/ {sum=sum+$2}END{printf "%d",sum}')
    validsum=$(echo "$validsum" | awk -F'<' '/SUM/  {sum=sum+$2}END{printf "%d",sum}')
    #echo "$validsum"
    #invalidsum=0
    #echo "$invalidresult"
    #echo "$invalidresult"
    #nlistvalid=$(echo "$validresult" | sed 's/, $//' | cut -d',' -f1-10)
    nlistinvalid=$(echo "$invalidresult" | sed 's/, $//' | cut -d',' -f1-10)
    #nlist=$(echo "$nlist" | sed 's/, $//')
}

f_chkfieldlen () {
dbgPRINT "In f_chkfieldlen : $1  subargs: $a1, $a2, $a3, $a4, $a5, $a6"
DBG_TIMESTAMP "BEGIN f_chkfieldlen: "
#check if delimeter is valid/supported
if [ ${DELIMETERS[$a3]} ]
then
    #VHCAT
    #col=$a4
    let "tot=0"
    let "k=0"
    nlist=""
    d="${DELIMETERS[$a3]}"
    condition="$a5"
    fieldval="$a6"
#fieldval=($(echo $a5 | $AWK 'BEGIN{FS=","}{for(i=0;i<=NF;i++)print $i}'))
    oldIFS="$IFS"
    IFS=$'\n'  
    if [ -z $RECORDNEW ]; then
	#if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
	#ll=$(eval VHCAT "${FILENAMES[0]}" | $AWK -F"${optencchar}${d}${optencchar}" 'NF!=val {lcnt++; printf "%d-%d\n",NR,NF} END {print lcnt}' val="$a3")
	    ll=$(eval VHCAT | $AWK -F"$d" '{sub(/^[ \t]+|[ \t]+$/,"",$colnum);gsub(optencchar,"",$colnum);collen=length($colnum);if(con=="="){if(collen==val){printf "%d-%d\n",NR,collen;count++}}else if(con==">"){if(collen>val){printf "%d-%d\n",NR,collen;count++}}else{if(collen<val){printf "%d-%d\n",NR,collen;count++}}}END{print count}' val="$fieldval" colnum="$a4" con="$condition" optencchar="$optencchar")
	#else
	 #   ll=$(eval VHCAT  | sed -e "s/${optencchar}//g"  |$AWK -F"$d" '{sub(/^[ \t]+|[ \t]+$/,"",$colnum);collen=length($colnum);if(con=="="){if(collen==val){printf "%d-%d\n",NR,collen;count++}}else if(con==">"){if(collen>val){printf "%d-%d\n",NR,collen;count++}}else{if(collen<val){printf "%d-%d\n",NR,collen;count++}}}END{print count}' val="$fieldval" colnum="$a4" con="$condition")
	#fi
    else
	#if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
  #mm=($(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v colnum=$a4 '{print $colnum}' | sort | uniq -c))
	    ll=$(VHCAT | $AWK -v del="$d" -v colnum=$a4 -v val=$fieldval -v optencchar="$optencchar" '{split($0,arr,"[+]{2}");split(arr[2],data,del);sub(/^[ \t]+|[ \t]+$/,"",data[colnum]);gsub(optencchar,"",data[colnum]);collen=length(data[colnum]);if(con=="="){if(collen==val){printf "%d-%d\n",arr[1],collen;count++}}else if(con==">"){if(collen>val){printf "%d-%d\n",arr[1],collen;count++}}else{if(collen<val){printf "%d-%d\n",arr[1],collen;count++}}}END{print count}')
	#else
	    #ll=$(VHCAT | $AWK -F"$d" -v del="$d" -v colnum=$a4 -v val=$fieldval '{split($0,arr,"[+]{2}");split(arr[2],data,del);sub(/^[ \t]+|[ \t]+$/,"",data[colnum]);collen=length(data[colnum]);if(con=="="){if(collen==val){printf "%d-%d\n",arr[1],collen;count++}}else if(con==">"){if(collen>val){printf "%d-%d\n",arr[1],collen;count++}}else{if(collen<val){printf "%d-%d\n",arr[1],collen;count++}}}END{print count}')
	#fi
    fi
    if [ "$ll" = "" ]; then ll="0"; fi
#eval VHCAT | $AWK -F"$d" -v colnum=$a4 -v val=$fieldval '{split($0,arr,"[+]{2}");print arr[1]}'

#get the total number of lines that didn't match the num of fields
    tcnt=$(echo -e $ll | $AWK -F' ' '{print $NF}')

#truncate the list to 10 line numbers
    nlines=$(eval echo -e $ll | $AWK -F' ' '{$NF=""}1' | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS' | cut -d' ' -f1-10 | sed -e 's: :, :g')

#echo "TCNT= $tcnt,  TLIST=$tlist"
    if [ "$tcnt" = "" ]; then tcnt=0; fi
    ADDMSG "$a1 $a2[NR${condition}$a6]# $tcnt [ $nlines ...]"
    
    if [ "$tcnt" != "0" ]; then EXITCODE=1; fi
    IFS="$oldIFS"
else
    ADDMSG "$a1 INVALID DELIMETERS"
fi
DBG_TIMESTAMP "END f_chkfieldlen: "
#dbgPRINT "ARGS: label=$a2; d=$d; vals=$v1, $v2"
}


f_chkfieldlenfixed () {
    dbgPRINT "In f_chkfieldlenfixed : $1  subargs: $a1, $a2, $a3, $a4, $a5"
    DBG_TIMESTAMP "BEGIN f_chkfieldlenfixed : "
#check if delimeter is valid/supported
#CHKVALFIXED|EMPLOYERCODE|3,5|EMPTY,
#CHKVALFIXED|EMPLOYERCODE|3,5|EMPTY,
    read start1 width1 <<< $(echo "$a3" | $AWK -F',' '{print $1 " " $2}')
    let "tot=0"
    let "k=0"
    nlist=""
    fieldval="$a4"
    oldIFS="$IFS"
    IFS=$'\n'  
    if [ -z $RECORDNEW ]; then
	ll=$(eval VHCAT  | $AWK '{a=substr($0,start1,width1);sub(/^[ \t]+|[ \t]+$/,"",a);collen=length(a);if(con=="="){if(collen==val){printf "%d-%d\n",NR,collen;count++}}else if(con==">"){if(collen>val){printf "%d-%d\n",NR,collen;count++}}else{if(collen<val){printf "%d-%d\n",NR,collen;count++}}}END{print count}' start1="$start1" width1="$width1" val="$fieldval")
    else
	ll=$(VHCAT | $AWK '{split($0,arr,"[+]{2}");a=substr(arr[2],start1,width1);sub(/^[ \t]+|[ \t]+$/,"",a);collen=length(a);collen=length($colnum);if(con=="="){if(collen==val){printf "%d-%d\n",NR,collen;count++}}else if(con==">"){if(collen>val){printf "%d-%d\n",NR,collen;count++}}else{if(collen<val){printf "%d-%d\n",NR,collen;count++}}}END{print count}' start1="$start1" width1="$width1" val=$fieldval)
    fi
    if [ "$ll" = "" ]; then ll="0"; fi
#eval VHCAT | $AWK -F"$d" -v colnum=$a4 -v val=$fieldval '{split($0,arr,"[+]{2}");print arr[1]}'

#get the total number of lines that didn't match the num of fields
    tcnt=$(echo -e $ll | $AWK -F' ' '{print $NF}')

#truncate the list to 10 line numbers
    nlines=$(eval echo -e $ll | $AWK -F' ' '{$NF=""}1' | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS' | cut -d' ' -f1-10 | sed -e 's: :, :g')

#echo "TCNT= $tcnt,  TLIST=$tlist"
    if [ "$tcnt" = "" ]; then tcnt=0; fi
    ADDMSG "$a1 $a2[NR!=$a4]# $tcnt [ $nlines ...]"
    
    if [ "$tcnt" != "0" ]; then EXITCODE=1; fi
    IFS="$oldIFS"
DBG_TIMESTAMP "END f_chkfieldlenfixed: "
#dbgPRINT "ARGS: label=$a2; d=$d; vals=$v1, $v2"
}

f_chkrngnum ()
{
    dbgPRINT "In f_chkrngnum : $1  subargs: $a1, $a2, $a3, $a4, $a5, $a6"
DBG_TIMESTAMP "BEGIN f_chkrngnum: "
#check if delimeter is valid/supported
if [ ${DELIMETERS[$a3]} ]
then
    #VHCAT
    #col=$a4
    let "tot=0"
    let "k=0"
    nlist=""
    d="${DELIMETERS[$a3]}"
    fieldval="$a5"
#fieldval=($(echo $a5 | $AWK 'BEGIN{FS=","}{for(i=0;i<=NF;i++)print $i}'))
    oldIFS="$IFS"
    IFS=$'\n'  
    if [ -z $RECORDNEW ]; then
	if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
	#ll=$(eval VHCAT "${FILENAMES[0]}" | $AWK -F"${optencchar}${d}${optencchar}" 'NF!=val {lcnt++; printf "%d-%d\n",NR,NF} END {print lcnt}' val="$a3")
	    ll=$(eval VHCAT  | sed -e "s/${optencchar}//g" | $AWK -F"$d" '{sub(/^[ \t]+|[ \t]+$/,"",$colnum);collen=length($colnum);if(collen!=val){printf "%d-%d\n",NR,collen;count++}}END{print count}' val="$fieldval" colnum="$a4")
	else
	    ll=$(eval VHCAT  | $AWK -F"$d" '{sub(/^[ \t]+|[ \t]+$/,"",$colnum);collen=length($colnum);if(collen!=val){printf "%d-%d\n",NR,collen;count++}}END{print count}' val="$fieldval" colnum="$a4")
	fi
    else
	if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
  #mm=($(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v colnum=$a4 '{print $colnum}' | sort | uniq -c))
	    ll=$(VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$d" -v del="$d" -v colnum=$a4 -v val=$fieldval '{split($0,arr,"[+]{2}");split(arr[2],data,del);sub(/^[ \t]+|[ \t]+$/,"",data[colnum]);collen=length(data[colnum]);if(collen!=val){printf "%d-%d\n",arr[1],collen;count++}}END{print count}')
	else
	    ll=$(VHCAT | $AWK -F"$d" -v del="$d" -v colnum=$a4 -v val=$fieldval '{split($0,arr,"[+]{2}");split(arr[2],data,del);sub(/^[ \t]+|[ \t]+$/,"",data[colnum]);collen=length(data[colnum]);if(collen!=val){printf "%d-%d\n",arr[1],collen;count++}}END{print count}')
	fi
    fi
    if [ "$ll" = "" ]; then ll="0"; fi
#eval VHCAT | $AWK -F"$d" -v colnum=$a4 -v val=$fieldval '{split($0,arr,"[+]{2}");print arr[1]}'

#get the total number of lines that didn't match the num of fields
    tcnt=$(echo -e $ll | $AWK -F' ' '{print $NF}')

#truncate the list to 10 line numbers
    nlines=$(eval echo -e $ll | $AWK -F' ' '{$NF=""}1' | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS' | cut -d' ' -f1-10 | sed -e 's: :, :g')

#echo "TCNT= $tcnt,  TLIST=$tlist"
    if [ "$tcnt" = "" ]; then tcnt=0; fi
    ADDMSG "$a1 $a2[NR!=$a5]# $tcnt [ $nlines ...]"
    
    if [ "$tcnt" != "0" ]; then EXITCODE=1; fi
    IFS="$oldIFS"
else
    ADDMSG "$a1 INVALID DELIMETERS"
fi
DBG_TIMESTAMP "END f_chkrngnum: "
#dbgPRINT "ARGS: label=$a2; d=$d; vals=$v1, $v2"
}

#
#COLSUM|AMOUNT|PIPE|11
#
f_colsum () {
    dbgPRINT "In f_getcolsumdel: $1"
    dbgPRINT "In f_getcolsumdel ARGS: $a1, $a2, $a3, $a4"
    DBG_TIMESTAMP "BEGIN f_colsum: "
    if [ ${DELIMETERS[$a3]} ]
    then
	d="${DELIMETERS[$a3]}";
	col=$a4
	#echo "$a1 $a2 $a3 $a4"
	if [ -z $RECORDNEW ]; then
#|$AWK -F"$d" -v col="$col" '{sub(/^[ \t]+|[ \t]+$/,"",$col);sum+=$'$a4'} END {printf "%.2f",sum}')
	    tot=$(eval VHCAT | awk -F"$d" -v col="$col" -v optenc="$optencchar" 'BEGIN{
        arr["{"]=0;arr["A"]=1;arr["B"]=2;arr["C"]=3;arr["D"]=4;arr["E"]=5;arr["F"]=6;arr["G"]=7;arr["H"]=8;arr["I"]=9;arr["}"]=0;arr["J"]=-1;arr["K"]=-2;
        arr["L"]=-3;arr["M"]=-4;arr["N"]=-5;arr["O"]=-6;arr["P"]=-7;arr["Q"]=-8;arr["R"]=-9;sum=0}
        {
        sub(/^[ \t]+|[ \t]+$/,"",$col);
        sub(optenc,"",$col);
        colnum=$col;
        if(colnum !~ "[a-zA-Z}{#]"){sum=sum+colnum}
        else{
                if(colnum ~ "^[0-9].*([A-Z}{])"){
                        len=length(colnum);
                       pchar=substr(colnum,len,1)
                       if(arr['pchar']<0)
                      {
                       colnum=colnum*-1
                          abspchar=arr['pchar']*-1
                          newcolval=colnum abspchar
                        }
                       else{
                          colnum=colnum*1
                          newcolval=colnum arr['pchar']
                        }
                       colnum=newcolval
                        sum=sum+colnum
                   }
               }
        }
END{printf "%.2f",sum}'
	    )
	else
	    tot=$(eval VHCAT | awk -v del="$d" -v col="$col" -v optenc="$optencchar" 'BEGIN{
        arr["{"]=0;arr["A"]=1;arr["B"]=2;arr["C"]=3;arr["D"]=4;arr["E"]=5;arr["F"]=6;arr["G"]=7;arr["H"]=8;arr["I"]=9;arr["}"]=0;arr["J"]=-1;arr["K"]=-2;
        arr["L"]=-3;arr["M"]=-4;arr["N"]=-5;arr["O"]=-6;arr["P"]=-7;arr["Q"]=-8;arr["R"]=-9;sum=0;}
        {
        split($0,arr1,"[+]{2}");
        split(arr1[2],data,del);
        sub(/^[ \t]+|[ \t]+$/,"",data[col]);
        gsub(optencchar,"",data[col]);
        colnum=data[col];
        if(colnum !~ "[a-zA-Z}{#]"){sum=sum+colnum}
        else{
                if(colnum ~ "^[0-9].*([A-Z}{])"){
                        len=length(colnum);
                        pchar=substr(colnum,len,1)
                        if(arr['pchar']<0)
                        {
                          colnum=colnum*-1
                          abspchar=arr['pchar']*-1
                          newcolval=colnum abspchar
                        }
                        else{
                          colnum=colnum*1
                          newcolval=colnum arr['pchar']
                        }
                        colnum=newcolval
                        sum=sum+colnum
                   }
               }
        }END{printf "%.2f",sum}'
	)
	fi
	ADDMSG "$a1 $a2[$a4]# $tot"
    else
	ADDMSG "WARNING-$a1 Invalid delimeter [ $a3 ]# [$a1] DIRECTIVE IGNORED"
    fi
    DBG_TIMESTAMP "END f_colsum: "
	    }

#
#  RECORDIDENTFIXED|START|LEN|VAL
#  CTLTOTIDENTFIXED|START|LEN|VAL
#
f_recordidentfixed() {
dbgPRINT "TBD: In f_recordidentfixed: $1"
dbgPRINT "In f_recordidentfixed ARGS: $a1, $a2, $a3, $a4"
ADDMSG "$a1# TO BE IMPLEMENTED"
}

f_ctltotidentfixed() {
dbgPRINT "TBD: In f_ctltotidentfixed: $1"
dbgPRINT "In f_ctltotidentfixed ARGS: $a1, $a2, $a3, $a4"
#ADDMSG "$a1# TO BE IMPLEMENTED"
}

#
# FIXED LEN RECORD FUNCTIONS
#
# CHKLENFIXED|len
# CHKLENFIXED|800
#
f_chklenfixed() {
dbgPRINT "In f_lenfixed: $1"
DBG_TIMESTAMP "BEGIN f_chklenfixed: "
##VHCAT $ifile | $AWK 'length($0)!=137 {lcnt++; print NR} END {print lcnt}'
#ll=$(eval VHCAT "$ifile" | $AWK -F"$d" 'NF!=val {lcnt++; print NR} END {print lcnt}' val="$a2")
#ll=$(eval VHCAT | $AWK '{lent=length($0)-2;lent1=lent-1}{if(lent==len || lent1==len){lcnt++; print NR}} END {print lcnt}' len="$a2")
#Temoporary fix. Solution for fixed length need to be figured out.
if [ -z $RECORDNEW ]; then
#ll=$(eval VHCAT | $AWK '{sub("\r","",$0);lent=length($0);print lent}')
#echo "$ll"
#eval VHCAT
ll=$(eval VHCAT | $AWK '{sub("\r","",$0);lent=length($0);if(lent!=len){lcnt++; printf "%d-%d ",NR,lent}} END {print lcnt}' len="$a2")
#echo "First Condition"
else
ll=$(eval VHCAT | $AWK '{split($0,arr,"[+]{2}");sub("\r","",arr[2]);lent=length(arr[2]);if(lent!=len){lcnt++;printf "%d-%d ",arr[1],lent;}} END {print lcnt}' len="$a2")
#echo "Second Condition"
fi
#eval VHCAT
#echo "$ll"
if [ "$ll" = "" ]; then ll="0"; fi
tcnt=$(echo -e $ll | $AWK -F' ' '{print $NF}')
nlines=$(eval echo -e $ll | $AWK -F' ' '{$NF=""}1' | $HEAD -n 10 | $AWK 'ORS=(FNR%10)?FS:RS' | cut -d' ' -f1-10 | sed -e 's: :, :g')
if [ "$tcnt" = "" ]; then tcnt=0; fi
ADDMSG "$a1 [NF!=$a2]# $tcnt [ $nlines ...]"
if [ "$tcnt" != "0" ]; then EXITCODE=1; fi
let "conditioncnt = 0"
let "recordidentcnt = 0"
DBG_TIMESTAMP "END f_chklenfixed: "
}

#
#CHKVALFIXED|LABEL|start,len|Y,N,EMPTY
#CHKVALFIXED|LABEL|40,1|Y,N,EMPTY
#
f_chkvalfixed_m() {
dbgPRINT "In f_chkvalfixed: $1"
DBG_TIMESTAMP "BEGIN f_chkvalfixed: "
nlist=""
let "tot=0"
start1="";width1="";
read start1 width1 <<< $(echo "$a3" | $AWK -F',' '{print $1 " " $2}')
dbgPRINT "start= $start1,  width=$width1"
#echo "start= $start1,  width=$width1"
#test=$(cat ${FILENAMES[0]})
      #echo "FROM VHCAT $test"
      if [ "$a4" != "" ]
      then
	nv=$(echo "$a4" | $AWK -F',' '{print NF}')
	dbgPRINT "Number of values: $nv"
	for (( i=1; i<$nv+1; i++ ))
	do
	   val=$(echo "$a4" | $AWK -F',' '{print $pos}' pos=$i )
	if [ -z $RECORDNEW ]; then
	   if [ "$val" = "EMPTY" ]; then
		nn=$(eval VHCAT | $AWK '{fval=substr($0,start,width);sub(/^ */,"",fval); if (fval == "") cnt++ } END {print cnt}' start="$start1" width="$width1")
	   else
		nn=$(eval VHCAT | $AWK '{fval=substr($0,start,width);gsub(" ", "",fval);if (fval == val ) cnt++ } END {print cnt}' val="$val" start="$start1" width="$width1")
	   fi
	else
	#echo "FRom elxe of recordnew"
	   if [ "$val" = "EMPTY" ]; then
                nn=$(eval VHCAT | $AWK '{split($0,arr,"[+]{2}");fval=substr(arr[2],start,width);sub(/^ */,"",fval); if (fval == "") cnt++ } END {print cnt}' start="$start1" width="$width1")
           else
                nn=$(eval VHCAT | $AWK '{split($0,arr,"[+]{2}");fval=substr(arr[2],start,width);gsub(" ", "",fval);if (fval == val ) cnt++ } END {print cnt}' val="$val" start="$start1" width="$width1")
	   fi
        fi
	   #if [ "$val" = "EMPTY" ]; then
	   #    nn=$(VHCAT | $AWK '{fval=substr($0,start,width); sub(/^ */,"",fval);print fval}' start="$start" width="$width")
	   #else
	   #    nn=$(VHCAT | $AWK '{fval=substr($0,start,width); gsub(" ", "", fval);print fval}' val="$val" start="$start" width="$width")
	   #fi
	   dbgPRINT "VAL=$val, NN=$nn"
	   #echo "$nn"
	   if [ "$nn" = "" ]; then nn=0; fi
           nlist=`echo $nlist" "$nn`
	   let "tot = $tot + $nn"
	done
      fi
      ADDMSG "$a1 $a2[$a4]# $tot [$nlist]"
      DBG_TIMESTAMP "END f_chkvalfixed: "
}

f_chkvalfixed() {
dbgPRINT "In f_chkvalfixed: $1"
DBG_TIMESTAMP "BEGIN f_chkvalfixed: "
nlist=""
validresult=""
invalidresult=""
let "tot=0"

start1="";width1="";
read start1 width1 <<< $(echo "$a3" | $AWK -F',' '{print $1 " " $2}')
chkvalues=($(echo "$a4" | awk -F',' '{for(i=1;i<=NF;i++)print $i}'))
dbgPRINT "start= $start1,  width=$width1"
#echo "start= $start1,  width=$width1"
#test=$(cat ${FILENAMES[0]})
      #echo "FROM VHCAT $test"
OLDIFS="$IFS"
IFS=$'\n'
if [ -z $RECORDNEW ] ; then
    mm=($(VHCAT | $AWK '{fval=substr($0,start,width);sub(/^[ \t]+|[ \t]+$/,"",fval);count[fval]++} END { for(i in count){printf "%d %s\n",count[i],i;}}' start="$start1" width="$width1" | sort -g -r))
else
    mm=($(VHCAT | $AWK '{split($0,arr,"[+]{2}");fval=substr(arr[2],start,width);sub(/^[ \t]+|[ \t]+$/,"",fval);count[fval]++} END { for(i in count){printf "%d %s\n",count[i],i;}}' start="$start1" width="$width1" | sort -g -r))
fi
#echo "${mm[@]}"
if [ "$a4" != "" ]
then
    for (( i=0; i<${#mm[@]}; ((i=i+1)) ))
	  do
   #val=$(echo "$a5" | $AWK -F',' '{print $pos}' pos=$i )
   #if [ "$val" = "EMPTY" ]; then
   #nn=$(VHCAT | $AWK -F"$d" '!$colnum && $colnum != 0 {lcnt++} END {print lcnt}' colnum="$col")
   #else
   #	nn=$(VHCAT | $AWK -F"$d" '$colnum == val {lcnt++} END {print lcnt}' colnum="$col" val="$val")
   #fi
   #dbgPRINT "VAL=$val, NN=$nn"
   #if [ "$nn" = "" ]; then nn=0; fi
   #echo $i
   #fieldvalchk=`echo "${fieldval[$k]}" | grep "${mm[$j]}"`
   #if [ ! -z ${fieldvalchk} ]; then
   #    nlist=`echo $nlist" "${mm[$i]}`
   #else
  #( mod=${#mm[@]}%2))
   #if [ $mod -eq 1 ]; then
   #    nlist=`echo $nlist" "EMPTY:${mm[$i]},`
   #    let "tot = $tot + ${mm[$i]}"
   #    ((i=i-1))
   #else
   #    ((j=i+1))
   #    nlist=`echo $nlist" "${mm[$j]}:${mm[$i]},`
   #    let "tot = $tot + ${mm[$i]}"
   #fi
   #echo ${mm[$i]} | $AWK -F' ' '{printf "%s %s %s\n",$1,$2,$3}'
	#nlist+=`echo ${mm[$i]} | $AWK -F' ' '{if($2==""){printf "EMPTY:%s, ",$1;}else{printf "%s:%s, ",$2,$1;}}'`
	nlist+=`echo ${mm[$i]} | $AWK -F' ' '{if($2==""){printf "EMPTY:%s, ",$1;}else{for(q=2;q<=NF;q++){printf " %s",$q}printf ":%s, ",$1;}}'`
	#echo "$nlist"
	intval=`echo ${mm[$i]} | $AWK -F' ' '{printf "%d",$1}'`
	let "tot = $tot + $intval"
  # if [ $i -ne 0 ]; then
  # ((k=k/i))
  # fi
    done
    #echo "$nlist"
    #echo "$nlist"
    ##For check valid
    #nvlist=($(echo "$nlist" | awk -F',' '{for(i=1;i<NF;i++)print $i}'))
    #echo ${#nvlist[@]}
    #echo ${#chkvalues[@]}
    #echo "$nlist"
    chkval_invalid
    #echo "$invalidresult"
    #echo "$invalidsum"
    #invalidresult=$(echo "test" | awk '{split(nlist,arr,",");split(values,arr1," ");for(i in arr){split(arr[i],a,":");sub(/^[ \t]+|[ \t]+$/,"",a[1]);sub(/^[ \t]+|[ \t]+$/,"",a[2]);for(j in arr1){temp=arr1[j]":"a[2];if(arr1[j]==a[1]){delete arr[i]}}}} END{allsame=0;somesame=0;for(k in temparr){if(temparr[k]==1){printf "%s, ",k}}}' nlist="$nlist" values="$(echo ${chkvalues[@]})")
    #echo "$invalidresult"
    #echo "$invalidsum"
    #invalidresult=$(echo "$val" | awk '{split(nlist,arr,",");split(values,arr1," ");for(i in arr){split(arr[i],a,":");sub(/^[ \t]+|[ \t]+$/,"",a[1]);sub(/^[ \t]+|[ \t]+$/,"",a[2]);for(j in arr1){if(arr1[j]!=a[1]){temp[a[i]]}}}} END{for(k in temp){printf "%s, ",k}}' nlist="$nlist" values="$(echo ${chkvalues[@]})")
    #invalidsum="$(echo "$val" | awk '{split(nlist,arr,",");for(i in arr){split(arr[i],a,":");sub(/^[ \t]+|[ \t]+$/,"",a[1]);sub(/^[ \t]+|[ \t]+$/,"",a[2]);if($0!=a[1]){printf "SUM<%d<",a[2]}}}' nlist="$nlist")"

    #((total=validsum+invalidsum))
    ADDMSG "${a1} $a2[$a3][$a4]# $tot [ Valid:$validsum , Invalid:$invalidsum , Samples: {${nlistinvalid} ...} ]"
    #ADDMSG "${a1}VALID $a2[$a3][$a4]# $validsum [$nlistvalid]"
    #ADDMSG "${a1}INVALID $a2[$a3][$a4]# $invalidsum [$nlistinvalid]"
    IFS="$OLDIFS"

fi

DBG_TIMESTAMP "END f_chkvalfixed: "
}

#
#COLSUMFIXED|LABEL|start,len
#COLSUMFIXED|LABEL|40,10
##
f_colsumfixed () {
 	dbgPRINT "In f_getcolsumfixed: $1"
	DBG_TIMESTAMP "BEGIN f_colsumfixed: "
	start1="";width1="";
	read start1 width1 <<< $(echo "$a3" | $AWK -F',' '{print $1 " " $2}')
	if [[  $PUCHCHAR == "Y" ]]; then
	#tot=$(eval VHCAT | $AWK -v start="$start1" -v width="$width1" '{print substr($0,start,width)}')
	tot=$(eval VHCAT | $AWK -v start1="$start1" -v width1="$width1" \
	    'BEGIN{arr["{"]=0;arr["A"]=1;arr["B"]=2;arr["C"]=3;arr["D"]=4;arr["E"]=5;arr["F"]=6;arr["G"]=7;arr["H"]=8;arr["I"]=9;arr["}"]=0;arr["J"]=-1;arr["K"]=-2;arr["L"]=-3;arr["M"]=-4;arr["N"]=-5;arr["O"]=-6;arr["P"]=-7;arr["Q"]=-8;arr["R"]=-9}{colval=substr($0,start1,width1); \
sub(/^[ \t]+|[ \t]+$/,"",colval); \
if(colval ~ "^[0-9].*([A-Z}{])") \
{len=length(colval);pchar=substr(colval,len,1);if(arr[pchar]<0) \
{colval=colval*-1;abspchar=arr['pchar']*-1;newcolval=colval abspchar} \
else{colval=colval*1;newcolval=colval arr['pchar'];}colval=newcolval;} \
sum+=colval} \
END{print sum}')
	else
	tot=$(eval VHCAT | $AWK -v FIELDWIDTHS="$start1 $width1" '{sub(/^[ \t]+|[ \t]+$/,"",$2);sum+=$2; } END {printf("%.2f",sum)}')
	fi
	#echo $test
   	ADDMSG "$a1 $a2[$start1,$width1]# $tot"
	DBG_TIMESTAMP "END f_colsumfixed: "
}

f_chkdate(){
    #echo "Check Date Function"
    #seperator="$($AWK -F'|' '/CHKDATE/ {print $3}')"
    #colnum=$($AWK -F'|' '/CHKDATE/ {print $4}')
    #dateFormat="$($AWK -F'|' '/CHKDATE/ {print $5}')"
    DBG_TIMESTAMP "BEGIN f_chkdate: "
    seperator="${DELIMETERS[$a3]}"
    column=$a4
    dateFormat="$a5"
    fieldname="$a2"
    #echo "$seperator $column $dateFormat $fieldname"
    if [[ $OPTIONALLYENCFLG == "TRUE" ]]; then
	fileContents=("$(eval VHCAT | sed -e "s/${optencchar}//g" | $AWK -F"$seperator" -v colnum=$column 'BEGIN{ORS="\n";OFS=":"}!($colnum in array){z[$colnum]++;y[$colnum]=$colnum}END{for(i in y) {print i,z[i];}}')")
    else
	fileContents=("$(eval VHCAT | $AWK -F"$seperator" -v colnum=$column 'BEGIN{ORS="\n";OFS=":"}!($colnum in array){z[$colnum]++;y[$colnum]=$colnum}END{for(i in y) {print i,z[i];}}')")
    fi
    #ADDMSG "DATE# ${fileContents[@]}"
    #echo "${fileContents[@]}"
    checkValue "$fieldname" "$column"
    DBG_TIMESTAMP "END f_chkdate: "
}

f_chkdatefixed(){
    DBG_TIMESTAMP "BEGIN f_chkdatefixed: "
    column="$a3"
    colno=$(echo "$a3" | $AWK -F',' '{print $1}')
    fieldWidth=$(echo "$a3" | $AWK -F',' '{print $2}')
    dateFormat="$a4"
    fieldname="$a2"
    #echo "$fieldWidth $dateFormat $colno"
    if [ -z $RECORDNEW ]; then
	fileContents=($(eval VHCAT | $AWK -v fieldLength="$fieldWidth" -v colnum="$colno" 'BEGIN{OFS=":";ORS="\n"}!(substr($0,colnum,fieldLength) in array){$val=substr($0,colnum,fieldLength);z[$val]++;y[$val]=$val}END{for(i in y) {print i,z[i];}}'))
    else
	fileContents=($(eval VHCAT | $AWK '{split($0,arr,"[+]{2}");sub("\r","",arr[2]);print arr[2]}' | $AWK -v fieldLength="$fieldWidth" -v colnum="$colno" 'BEGIN{OFS=":";ORS="\n"}!(substr($0,colnum,fieldLength) in array){$val=substr($0,colnum,fieldLength);z[$val]++;y[$val]=$val}END{for(i in y) {print i,z[i];}}'))
    fi
    #fileContents=($(eval VHCAT | $AWK -v fieldLength="$fieldWidth" -v colnum="$colno" '{split($0,arr,"[+]{2}");sub("\r","",arr[2]}'))
    #echo "${fileContents[@]}"
    checkValue "$fieldname" "$column"
    DBG_TIMESTAMP "END f_chkdatefixed: "
}

f_cntjunkchar(){
    DBG_TIMESTAMP "BEGIN f_cntjunkchar: "
    beforecount=$(wc "${FILENAMES[0]}" | $AWK '{printf "%d",$3}')
    aftercount=$(tr -cd '\11\12\15\40-\176' < "${FILENAMES[0]}" | wc | $AWK '{printf "%d",$3}')
    ((junkchar=$beforecount-$aftercount))
    ADDMSG "JUNKCHARCNT# $junkchar"
    DBG_TIMESTAMP "END f_chtjunkchar: "
}

#f_chktoprec(){
#    
#}

#
# given a format and data, checks the validity of the data
#
declare -A NUMFORMATS=(
  [DDDDD]='^[0-9]\{5\}$'
  [DDDDD-dddd]='^[0-9]\{5\}\-[0-9]\{4\}$'
  [DDDDDDDDD]='^[0-9]\{9\}$'
  [DDD-DD-DDDD]='^[0-9]\{3\}\-[0-9]\{2\}\-[0-9]\{4\}$'
)

f_chknumber() {
    DBG_TIMESTAMP "BEGIN f_chknumber: "
  	nfmt="$a5"
	rexpr=${NUMFORMATS[$nfmt]}

	#echo "CHECKING .... FMT=$nfmt REGEX=$rexpr "
	# Be careful with sed; make sure we strip off leading and trailing spaces in the field
	tot=($(VHCAT | $AWK -F"$d" -v colnum=$a4 '{print $colnum}' | sed -n "s/^[ \t]*//;s/[ \t]*$//;"/$rexpr/!p"" | $AWK 'END{print FNR}'))
   	ADDMSG "$a1 $a2[$a4][$a5]# $tot"
    DBG_TIMESTAMP "END f_chknumber: "
}

declare -A PARSEFUNCS=( 
 [FLID]="f_flid"
 [LAYOUTNUM]="f_layoutnum"
 [HEADER]="f_header"
 [TRAILER]="f_trailer"
 [OPTENC]="f_optionallyenc"
 [PUCHCHAR]="f_puchchar"
 [RECORDIDENT]="f_recordident"
 [RECORDCONDITION]="f_recordcondition"
 [CTLTOTIDENT]="f_ctltotident"
 [CONTROLLINE]="f_controlline"
 [CHKNUMFIELDS]="f_chknumfields"
 [CHKVAL]="f_chkval"
 [COLSUM]="f_colsum"
 [RECORDIDENTFIXED]="f_recordidentfixed"
 [CTLTOTIDENTFIXED]="f_ctltotidentfixed"
 [VHCATSTRBUILD]="f_vhcatstrbuild"
 [CHKLENFIXED]="f_chklenfixed"
 [CHKVALFIXED]="f_chkvalfixed"
 [COLSUMFIXED]="f_colsumfixed"
 [CHKDATE]="f_chkdate"
 [CHKDATEFIXED]="f_chkdatefixed"
 [CHKZIP]="f_chknumber"
 [CHKSSN]="f_chknumber"
 [CHKFIELDLENGTH]="f_chkfieldlen"
 [CHKFIELDLENGTHFIXED]="f_chkfieldlenfixed"
 [CHKTOPREC]="f_chktoprec"
)

#
# MAIN - all checks done. Proceed with processing
#
#Version 1.0 , Generated on 2014-11-17 06:32:34
#f_cntjunkchar
ADDMSG "getFileStats BEGIN FILENAME# ${FILENAMES[0]}"

DBG_TIMESTAMP "BEGIN total lines: "
totlines=$($AWK 'END{print FNR}' "${FILENAMES[0]}")
ADDMSG "NUMLINES# $totlines"
DBG_TIMESTAMP "END total lines:"

DBG_TIMESTAMP "BEGIN size: "
size=$(cksum "${FILENAMES[0]}" | $AWK '{print $2}')
#size=$(ls -lt "${FILENAMES[0]}" | $AWK '{print $5}')
ADDMSG "SIZE# $size"
DBG_TIMESTAMP "END size: "

DBG_TIMESTAMP "BEGIN tstamp: "
tstamp=$(${STAT} -c %y "${FILENAMES[0]}" | $AWK '{print $1,substr($2,0,8)}')
ADDMSG "TIMESTAMP# $tstamp"
DBG_TIMESTAMP "END tstamp: "

DBG_TIMESTAMP "BEGIN chksum:  "
chksum=$(cksum "${FILENAMES[0]}" | $AWK '{print $1}')
ADDMSG "CKSUM# $chksum"
DBG_TIMESTAMP "END chksum:  "


DBG_TIMESTAMP "BEGIN hashkey: "
hashkey=$(${MD5} "${FILENAMES[0]}" | $AWK '{print $1}')
ADDMSG "HASHKEY# $hashkey"
DBG_TIMESTAMP "END hashkey: "

DBG_TIMESTAMP "BEGIN dupcnt: "
dupcnt=$(cat "${FILENAMES[0]}" | $AWK 'x[$0]++ {print $0}' | $AWK 'END{print FNR}')
duplines=$(cat "${FILENAMES[0]}" | $AWK 'x[$0]++ {print NR}'| head -10 | awk 'ORS=(FNR%10)?FS:RS')
ADDMSG "DUPRECORDS# $dupcnt [ $duplines ...]"
DBG_TIMESTAMP "END dupcnt: "

f_cntjunkchar
#DBG_TIMESTAMP "BEGIN duplines: "
#duplines=$(cat "${FILENAMES[0]}" | $AWK 'x[$0]++ {print NR}' | $HEAD -10 | $AWK 'ORS=(FNR%10)?FS:RS')
#DBG_TIMESTAMP "END duplines: "
#echo "Calling vcat function"
#eval VHCAT
#exit 1
#Junk Character Count

###IFS=$'\r\n' lineArray=($(grep -v "^#" $attrfile))


numlines="${#lineArray[@]}"
#let x=1
#dbgPRINT "TOTAL NUM LINES: $numlines"

for i in "${lineArray[@]}"
do
   tok=""
   tok=$(echo ${i} | $AWK -F'|' '{print $1}')
   #dbgPRINT "BEGIN: line=> ${i} ; tok=${tok}"
   #let x=x+1
   if [ $tok != "" ]
   then
   	if [ ${PARSEFUNCS[$tok]} ] 
   	then
 		GETARGS "${i}"
		${PARSEFUNCS[$tok]} "${i}"	
   	else
		echo "WARNING: Invalid directive, ignoring: ${i}"
   	fi
   fi
   #dbgPRINT "END"
done

#
# conditions to return FAIL
#   1. Num of expected fields and the num of actual fields don't match
#   2. 

#for i in "${MSGS[@]}"
#echo $cntlay
#if [ -z $recordidentflag ];then
#    ADDMSG "LAYOUT# $CURLAYOUT ${cntlay}"
#fi

ADDMSG "getFileStats END FILENAME# ${FILENAMES[0]}"
for ((i=0; i<$nmsgs; i++ ))
do
  #echo ${i}
  echo ${MSGS[$i]} | $AWK -F'#' '{printf "%50s# %s\n", $1, $2}'
  ## for spreadsheet format - if required in the future. should get rid of the delimiter at the end
  #echo ${MSGS[$i]} | $AWK -F'#' '{printf "%s#", $2}'
done
exit $EXITCODE
