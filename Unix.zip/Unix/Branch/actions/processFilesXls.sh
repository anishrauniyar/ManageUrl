#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: This script is the main action script for FMON

##########the given files specified in conf file###############
###Example Flags for processFile in conf file####################
####AIPCOPY=TRUE
####AIPFILEID=TRUE
####AIPSTATS=TRUE
####AIPIMPORT=TRUE
########################################################################

#############################################################################################################################################
#Usages : ./processFiles.sh -m """/data1/Clients/019 - Allied Benefit/data/201407/medical_claims.txt""|72|6478_1490113|UNK|UNKNOWN|CLAIMS"
#############################################################################################################################################

# Source main configuration file
source /data1/AIP/conf/main.conf
source /data1/AIP/conf/rlog.sh

###########################################################################
######################### Database Function Start #########################
###########################################################################
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
svn_pass=$($FMONCONFDIR/crypto -z $svn_pass)

###############Flags for sub-action script name
GET_FILEID_NAME="getFileId.sh"
GET_FILESTATS_NAME="getFileStats.sh"
IMPORT_FILE_NAME="importFile.sh"
IMPORT_CLT_NAME="importCtl.sh"
IMPORT_CTLFILE_NAME="importCtlFile.sh"
TOPRECORD_NAME="toprecords"
FMONCOPY_NAME="fmonCopy.sh"

#Function will insert basic information which will be useful for inventory.
function insertMainLog()
{
#echo "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" >> $LISTTMPDIR/importedinfo.txt
    local filename1=$(echo "${2}" | sed -e "s:':'':g")
    local fullpath1=$(echo "${12}" | sed -e "s:':'':g")
    local getstat1=$(echo "${13}" | sed -e "s:':'':g")
    local emid=$(echo "${20}" | sed -e "s:':'':g")
    local processfilepath1=$(echo "${17}" | sed -e "s:':'':g")
    local query=''
    systime=$(date "+%F %T")
    if [ -z "$1" ]; then
	query="INSERT INTO importdb.imp_main_log (fileid,filename,clientid,layoutid,datatype,file_size,file_date,file_hashkey,file_record_cnt,dup_record_cnt,status_of_import,fullpath,getstat,starttime,endtime,dmfileid,processfilepath,processstatus,cuttingfloor,empgrp,importserver,junk_char) VALUES(seq_imp_main_log.NEXTVAL,'"${filename1}"', '"$3"', '0' ,'UNKN', '"$6"' ,'"$7"' ,'"$8"','"$9"','"${10}"','"${11}"','"${fullpath1}"','"${getstat1}"','"${systime}"','"${systime}"','"${16}"','"${processfilepath1}"','"${18}"','"${19}"','"${emid}"','"$HOSTNAME"','"${junkchar}"')"
    else 
	query="INSERT INTO importdb.imp_main_log (fileid,filename,clientid,layoutid,datatype,file_size,file_date,file_hashkey,file_record_cnt,dup_record_cnt,status_of_import,fullpath,getstat,starttime,endtime,dmfileid,processfilepath,processstatus,cuttingfloor,empgrp,importserver,junk_char) VALUES('"$1"','"${filename1}"', '"$3"', '"$4"' ,'"$5"', '"$6"' ,'"$7"' ,'"$8"','"$9"','"${10}"','"${11}"','"${fullpath1}"','"${getstat1}"','"${systime}"','"${systime}"','"${16}"','"${processfilepath1}"','"${18}"','"${19}"','"${emid}"','"$HOSTNAME"','"${junkchar}"')"
    fi
#echo "$6"
#echo "$query"
#echo "Inserted into mainLog"
#allLogging "::::Inserted into main log"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
set define on;
commit;
exit;
EOF
else
    echo "DRYRUN Flag set as TRUE"
fi
}

#Function called after import script is called.
function updateLog()
{
processfilepath=$(echo "$1" | sed -e "s:':'':g")
local query="UPDATE IMPORTDB.imp_main_log set processfilepath='"$processfilepath"',processstatus='"$2"' where fileid='"$UFILEID"'"
#echo $query
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
set define on;
commit;
exit;
EOF
else
    echo "DRYRUN Flag set as TRUE"
fi
}

#Function runs DRL and MDR Reports
#function runReport()
#{
#schema="${IMPORTDB}${client_id}"
#echo $schema
#sqlBase="$BASEDIR/sql/"
#Check of the script exists.Else termnilate
#sqlFullPath=${sqlBase}pkg_aip_file_report.sql
#sqlexe="declare
#VBLQUERY varchar2(4000);
#VJOBNUM binary_integer ;
#begin
#VBLQUERY:= 'begin pkg_aip_file_report.exe_report(''"${UFILEID}_${dmfileid}"'') ; end ; ';
#DBMS_JOB.SUBMIT(JOB=>VJOBNUM,WHAT=>VBLQUERY,INSTANCE=>1);
#end;
#/
#"
#echo $sqlexe
#sqlplus -S "$schema/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$IMPORTDBSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
#SET LINES 32000;
#SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
#SET TERMOUT OFF;
#SET SERVEROUTPUT OFF;
#@$sqlFullPath;
#$sqlexe
#EOF
#query="declare
#VBLQUERY varchar2(4000);
#VJOBNUM binary_integer ;
#begin
#VBLQUERY:= 'begin pkg_aip_file_report.exe_report(''$1'') ; end ; ';
#--dbms_output.put_line(VBLQUERY);
#DBMS_JOB.SUBMIT(JOB=>VJOBNUM,WHAT=>VBLQUERY,INSTANCE=>1);
#COMMIT;
#end;
#/"
#echo $query
#sqlplus -S 'importDB/oracle@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=1521))(CONNECT_DATA=(SID=d2he)))' << EOF > /dev/null
#sqlplus -S utility/oracle << EOF >/dev/null
#sqlplus -S "$IMPORTDBUTILITY/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
#$query
#commit;
#EOF
#}

#Function which will updated all the unix log files to the database
function aip_manualrun_log()
{
INFO13=$(echo "${INFO13}" | sed -e "s:':'':g")
PTIME=$(date "+%F %T")
local query="INSERT INTO importdb.AIP_MANUALRUN_LOG(fmonid,processtime,fileid,errorcode,info7,info8,info9,info10,info11,info12,info13,info14,info15,info16,executed_by,processtype) VALUES('"$FMONID"', '"$PTIME"', '"$file_id"', '"$ECODE"','"${INFO7}"','"${INFO8}"','"${INFO9}"','"${INFO10}"','"${INFO11}"','"${INFO12}"','"${INFO13}"','"${INFO14}"','"${INFO15}"','"${INFO16}"','"${DUSER}"','"${processtype}"')"
#echo $query
#sqlplus -S 'importDB/oracle@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=1521))(CONNECT_DATA=(SID=d2he)))' <<EOF
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}


function checkFileIdReturn()
{
FILENAME=$(echo "${filename}" | sed -e "s:':'':g")
local sqlcheck="SELECT Sum(cnt) AS cnt FROM (
SELECT count(1) AS CNT FROM IMP_CLIENTPATTERNS
WHERE CLIENTID = '"$CLID"' AND aip_file_match('"$FILENAME"', PATTERN)=1
UNION all
SELECT count(1) AS CNT FROM IMP_CLIENTPATTERNS
WHERE CLIENTID = '"$CLID"' AND aip_file_match('"$FILENAME"', CTL_PATTERN)=1 )
"
#checkFileId=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))"
checkFileId=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
set define off;
$sqlcheck;
commit;
exit;
EOF
)
}

#Function which will update table in case processFile is called manually from dashboard initially
function updateLogDashBoardPre()
{
emfid=$(echo "${5}" | sed -e "s:':'':g")
query="UPDATE IMPORTDB.imp_main_log set process_type='"$1"',layoutid='"$2"',processstatus='RUNNING',datatype='"$4"',empgrp='"$5"' where fileid='"$6"'"
#echo $query
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
set define on;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#Function which will update table in case processFile is called manually from dashboard and error is occured
function updateLogDashBoardErr()
{
query="UPDATE IMPORTDB.imp_main_log set process_type='"$1"',processstatus='EXCEPTIONS',status_of_import='"$2"',process_type_detail='"$3"'  where fileid='"$4"'"
#echo $query
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
set define on;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}


#Function which will update table in case processFile is called manually from dashboard after completion
function updateLogDashBoardPost()
{
    processfilepath=$(echo "$4" | sed -e "s:':'':g")
    statofimp="$2"
    if [[ ${#statofimp} = 0 ]]; then
	query="UPDATE IMPORTDB.imp_main_log set process_type_detail='"$1"',getstat='"$3"',processfilepath='"$processfilepath"',processstatus='"$5"',cuttingfloor='"$6"',FILE_RECORD_CNT='"$numLine"' where fileid='"$7"'"
    else
	query="UPDATE IMPORTDB.imp_main_log set process_type_detail='"$1"',status_of_import='"$2"',getstat='"$3"',processfilepath='"$processfilepath"',processstatus='"$5"',cuttingfloor='"$6"',FILE_RECORD_CNT='"$numLine"' where fileid='"$7"'"
    fi
#echo $query
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
set define on;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#Function which will update table for control total files
function insertControlSta()
{
#query="UPDATE IMPORTDB.imp_main_log set status_of_import='"$1"' where fileid='"$UFILEID"'"
#echo $query
impdate=`date "+%F %T"`
local query2="DELETE FROM imp_vh_control_total where fileid='"$UFILEID"'"
local query="INSERT INTO imp_vh_control_total(clientid,fileid,ctlfilename,empname,importeddate,ctl_status,CTL_EXTRACT) VALUES ('"$CLID"','"$UFILEID"','"$filename"','"$EMPID"','"$impdate"','UNPROCESSED','Invalid cattr file')"
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
$query2;
$query;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#Function to insert control total information in the IMP_VH_CONTROL
function insertControlRecords()
{
#query=''
    local query1=''
    local query2="DELETE FROM imp_vh_control_total where fileid='"$1"'"
    sqlFullPath="$BASEDIR/sql/IMPORT_CTL_FILE.sql"
    local IFS=$'\n'
    for k in ${controlrecords[@]};do
    #read from_date to_date billed_amt allowed_amt paid_amt employee_amt employee_cnt member_cnt record_cnt <<< $(echo "$k" | awk -F'|' '{print $1 " " $2 " "$3 " " $4 " " $5 " " $6 " " $7 " " $8 " " $9}')
	from_date=$(echo "$k" | awk -F'|' '{print $2}' | sed 's:"::g')
	to_date=$(echo "$k" | awk -F'|' '{print $3}' | sed 's:"::g')
	billed_amt=$(echo "$k" | awk -F'|' '{printf $4}' | sed 's/[,$/]//g' | sed 's:"::g')
	allowed_amt=$(echo "$k" | awk -F'|' '{print $5}' | sed 's/[,$/]//g' | sed 's:"::g')
	paid_amt=$(echo "$k" | awk -F'|' '{print $6}' | sed 's/[,$/]//g' |sed 's:"::g')
	employee_amt=$(echo "$k" | awk -F'|' '{print $7}' | sed 's/[,$/]//g' | sed 's:"::g')
	employee_cnt=$(echo "$k" | awk -F'|' '{print $8}' | sed 's/[,$/]//g' | sed 's:"::g')
	member_cnt=$(echo "$k" | awk -F'|' '{print $9}' | sed 's/[,$/]//g' | sed 's:"::g')
	record_cnt=$(echo "$k" | awk -F'|' '{print $10}' | sed 's/[,$/]//g' | sed 's:"::g')
	ctl_src_fname=$(echo "$k" | awk -F'|' '{print $11}')
	if [ -z $ctl_src_fname ] ;then
	    ctl_src_fname="$3"
	fi
#query+="INSERT INTO imp_vh_control_total(clientid,fileid,ctlfilename, datafilename, importeddate, category,
# empname, payornname, fromdate, todate, billed_amt, allowed_amt, paid_amt, employee_amt, employee_cnt, member_cnt, record_cnt) 
#VALUES ('"$CLID"','"$1"','"$2"','"$ctl_src_fname"','"$4"','"$5"','"$6"','"$7"','"$from_date"','"$to_date"',
#to_number(nvl('"$billed_amt"',0)),to_number(nvl('"$allowed_amt"',0)),to_number(nvl('"$paid_amt"',0)),to_number(nvl('"$employee_amt"',0)),
#to_number(nvl('"$employee_cnt"',0)),to_number(nvl('"$member_cnt"',0)),to_number(nvl('"$record_cnt"','0'))); 
#"
	query1+="EXEC IMPORT_CTL_FILE('"$CLID"','"$1"','"$2"','"$ctl_src_fname"','"$5"','"$EMPID"','"$7"','"$from_date"','"$to_date"','"$billed_amt"','"$allowed_amt"','"$paid_amt"','"$employee_amt"','"$employee_cnt"','"$member_cnt"','"$record_cnt"');
"
    done
    echo "$query1"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
SET LINES 32000;
set define off;
$query2;
commit;
@$sqlFullPath;
$query1
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#Function to insert file status into log
function insert_file_stats()
{
local query1=`echo "${appQuery[@]}"`
#echo "$query1"
#echo 
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
$query1;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#Function to delete file status from log while calling from dashboard
function delete_file_stats()
{
local query2="delete FROM imp_file_stats_log WHERE fileid='"${UFILEID}_${dmfileid}"'"
#echo "$query1"
#echo 
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
$query2;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}


#Function which will updated all the unix log files to the database
function aip_dmfilelist_log()
{
    local filepath1=$(echo "${AIPDESTDIR}${PARENT}" | sed -e "s:':'':g")
    local filename1=$(echo "${filename}" | sed -e "s:':'':g")
    local aip_filename=$(echo "${aip_filename}" | sed -e "s:':'':g")
    local INFO13=$(echo "${INFO13}" | sed -e "s:':'':g")
    local INFO14=$(echo "${INFO14}" | sed -e "s:':'':g")
    local INFO15=$(echo "${INFO15}" | sed -e "s:':'':g") 
    local INFO16=$(echo "${INFO16}" | sed -e "s:':'':g")
    local INFO8=$(echo "${INFO8}" | sed -e "s:':'':g")
    local INFO9=$(echo "${INFO9}" | sed -e "s:':'':g")
    local INFO10=$(echo "${INFO10}" | sed -e "s:':'':g")
    local INFO11=$(echo "${INFO11}" | sed -e "s:':'':g")
    local INFO12=$(echo "${INFO12}" | sed -e "s:':'':g")
    local query=''
    etime1=$(date "+%F %T")
    if [[ ${#USER} = 0 ]]; then
	USER='service'
    fi
    if [[ $FILEALREADYEXISTSFLAG == 'TRUE' ]] ;then
	query="INSERT INTO importdb.aip_dmfilelist_log(fmonid,processtime,dmfile_id,client_id,path,filename,hashvalue,filedate,filesize,script,copyflag,errorcode,info7,info8,info9,info10,info11,info12,info13,info14,info15,info16,executed_by,endtime,aip_filename) VALUES('"$FMONID"', '"$PTIME"', '"$dmfileid"', '"$CLID"' ,'"${filepath1}"', '"$filename1"' ,'"$hashvalue"' ,'"$ODATE"','"$filesize"','"$SCRIPTS"','"$CPFLAG"','"$ECODE"','"${INFO7}"','"${INFO8}"','"${INFO9}"','"${INFO10}"','"${INFO11}"','"${INFO12}"','"${INFO13}"','"${INFO14}"','"${INFO15}"','"${INFO16}"','"${USER}_${HOSTNAME}"','"$etime1"','"$aip_filename"')"
    else
	query="INSERT INTO importdb.aip_dmfilelist_log(fmonid,processtime,dmfile_id,client_id,path,filename,hashvalue,filedate,filesize,script,copyflag,errorcode,info7,info8,info9,info10,info11,info12,info13,info14,info15,info16,executed_by,endtime) VALUES('"$FMONID"', '"$PTIME"', '"$dmfileid"', '"$CLID"' ,'"${filepath1}"', '"$filename1"' ,'"$hashvalue"' ,'"$ODATE"','"$filesize"','"$SCRIPTS"','"$CPFLAG"','"$ECODE"','"${INFO7}"','"${INFO8}"','"${INFO9}"','"${INFO10}"','"${INFO11}"','"${INFO12}"','"${INFO13}"','"${INFO14}"','"${INFO15}"','"${INFO16}"','"${USER}_${HOSTNAME}"','"$etime1"')"
    fi
#echo $query
#sqlplus -S 'importDB/oracle@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=1521))(CONNECT_DATA=(SID=d2he)))' <<EOF
#sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
set define off;
$query;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

function aip_main_det() 
{
local query="INSERT INTO importdb.imp_main_det_log(fileid,sublayoutid,filerecordcount) VALUES ('"$file_id"','"$sublayoutid"','"$layoutcnt"')"
#echo $query
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
$query;
commit;
exit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}
###########################################################################
######################### Database Function End   #########################
###########################################################################

declare -A DELIMETERS=(
 [TILD]='~'
 [FIXED]='\n'
 [FIXD]='\n'
 [PIPE]='|'
 [COMA]=','
 [COLN]=':'
 [TAB]='\t'
 [SCLN]=';'
 [DOLR]='$'
 [EXCL]='!'
 [CAPS]='^'
 [ATSI]='@'
 [HASH]='#'
)

#########################################################################
#Function which will generate cuttingfloor values
#########################################################################
function compareField()
{
    declare -A datalen=()
    if [ $# -eq 1 ]
    then
        #echo "Fixed Length"
        dataLeng=($(echo "$toprec" | awk -F':' '{print $2}'))
        for i in ${#dataLeng[@]}
        do
            datalen[$i]=$1
        done
        if [ ${#datalen[@]} -ne 1 ]
        then
            toprec=$(echo "SubStr$1-${dataLeng[@]} - Check")
        else
            if [ ${dataLeng[0]} -eq $1 ]
            then
                toprec=$(echo "SubStr$1-${dataLeng[@]} - OK")
            else
                toprec=$(echo "SubStr$1-${dataLeng[@]} - Check")
            fi
        fi
    else
	#echo "$toprec"
	#echo "dataLeng=($(echo "$toprec" | awk -F':' '{printf "%s",$1}' | sed -e 's:]::g' -e 's:\[::g'))"
        dataLeng=($(echo "$toprec" | awk -F':' '{printf "%s",$1}' | sed -e 's:]:}:g' -e 's:\[:{:g'))
	#echo "${dataLeng[@]}"
        for i in ${#dataLeng[@]}
        do
            datalen["$i"]=$2
        done
        if [ ${#datalen[@]} -ne 1 ]
        then
            toprec=$(echo "$1-${dataLeng[@]} - Check")
        else
	    #echo ${dataLeng[0]}
	    dtype=$(echo ${dataLeng[0]} | awk -F'-' '{print $1}' | sed -e 's/}//g' -e 's/{//g')
            val=$(echo ${dataLeng[0]} | awk -F'-' '{print $2}' | sed -e 's/}//g' -e 's/{//g')
	    echo "$dtype $deli"
	    if [[ ${#val} != 0 ]] && [[ $val == $2 ]] && [[ $dtype == "$deli" ]]
            then
		toprec=$(echo "$1$2-${dataLeng[@]} - OK" | sed -e 's:{:[:g' -e 's:\}:]:g')
            else
		toprec=$(echo "$1$2-${dataLeng[@]} - Check" | sed -e 's:{:[:g' -e 's:\}:]:g')
            fi
        fi
    fi
}

#########################################################################
################End for Cutting floor function
#########################################################################

#########################################################################
##################### Parsing Functions #################################
#########################################################################

#Tempory function
#Export svn files to current fmon directory
function svnExport()
{
#svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/DataResearch/AIP/attr/268.attr"
    if [[ $1 == "CATTR" ]]; then
	svn_url="$SVNLOCATIONCATTR/$cattrFilename"
	#svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/DataResearch/AIP/Control_Attribute_Scripts/$cattrFilename"
    else
	svn_url="$SVNLOCATIONATTR/$attrFilename"
	#svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/DataResearch/AIP/Attribute_Scripts/$attrFilename"
    fi
    #echo $svn_url
    #ATTRFULL="$LOGDIR/$FMONID/$attrFilename"
    #REVNO=$(svn info --username datadashboard --password innovation $svn_url | awk -F':' '/Revision/ {print $2}' | sed 's/[[:space:]]//g')
    if [ -f "$ATTRFULL" ]; then
	echo "File already exists. No need to checkout svn"
    else
	svn export --username $svn_user --password $svn_pass $svn_url --non-interactive "$ATTRFULL"
	echo "Pass svn"
    fi
}

###### Building local action list ####################
function buildLocalActionList()
{
    local IFS=$'\n'
    localactionList=($(awk -F':' '/^ACTION/ {print $2}' "${localactionFile}"))
}

#Check for local action is enable in conf file
function checkLocalActions(){
    if [[ $LOCALACTIONS == "TRUE" ]]; then
	localactionFile="${AIPDESTDIR}${ROOTPARENT}LOCALACTIONS"
	echo "$localactionFile"
	#echo "$ROOTPARENT"
	if [ -f "$localactionFile" ]; then
	    echo "Local actions file exists. Importing local actions"
	    buildLocalActionList
	    if [[ ${#localactionList[@]} != '0' ]];then
		echo "Local actions has ${#localactionList[@]} actions defined"
		for actions in ${localactionList[@]}
		do
		    echo "$DEFAULTACTIONDIR/$actions -f ${UFILEID}_${dmfileid}"
		    $DEFAULTACTIONDIR/$actions -f "${UFILEID}_${dmfileid}"
		done
	    else
		echo "Local actions file has 0 actions defined"
	    fi
	    #source "$localactionFile"
	else
	    echo "Local actions file not found"
	fi
    else
	echo "Local Actions flags is false in conf file"
    fi
}
#Parse the line of file list generated
function parseFileList(){
    #read client_id dmfileid hashvalue ODATE <<< $(echo "$line" | awk -F'|' '{print $2 " " $3 " " $4 " " $5}')
    client_id=`echo "$line" |  awk -F"|" '{print $2}'`
    fname=`echo "$line" |  awk -F"|" '{print $1}'`
    PARENT=`echo "$fname" | awk -F"/" 'BEGIN{i=1}{while(i<NF){printf "%s/",$i;i++}}'`
    ROOTPARENT=`echo "$fname" | awk -F"/" 'BEGIN{i=1}{while(i<4){printf "%s/",$i;i++}}'`
    export filename=`echo "$fname" |  awk -F"/" '{print $NF}'`
    #echo "$PARENT $line" 
    export dmfileid=`echo "$line" |  awk -F"|" '{print $3}'`
    export hashvalue=`echo "$line" |  awk -F"|" '{print $4}'`
    export FULLNAME="${AIPDESTDIR}${PARENT}${filename}"
    #export client_id;export filename;export dmfileid;export hashvalue
    export ODATE=`echo "$line" | awk -F"|" '{print $5}'`
    filesize=`echo "$line" | awk -F"|" '{print $6}'`
    CLID="$client_id"
    export CLID
}
#Parse the argument of dashboard
function parseDashboardArg(){
    MSTIME=`date "+%F %T"`
    FULLNAME="$(echo "$DASHBOARDARG" | awk -F'|' '{print $1}' | sed -e 's:\"::g')"
    #echo $FILENAME
    ROOTPARENT=`echo "$FULLNAME" | awk -F"/" 'BEGIN{i=1}{while(i<=4){printf "%s/",$i;i++}}'`
    filename=`echo "$FULLNAME" | awk -F'/' '{print $NF}'`
    #CLID=$(echo "$FULLNAME" | awk -F'/' '{print $4}'| awk -F'-' '{print $1}'| sed -e 's/\\//' -e 's/[[:space:]]//')
    file_id=`echo "$DASHBOARDARG" | awk -F'|' '{print $3}'`
    UFILEID=`echo $file_id | awk -F'_' '{print $1}'`
    dmfileid=`echo $file_id | awk -F'_' '{print $2}'`
    LYID=`echo "$DASHBOARDARG" | awk -F'|' '{print $2}'`
    EMPID=`echo "$DASHBOARDARG" | awk -F'|' '{print $4}'`
    curDir=`echo "$DASHBOARDARG" | awk -F'|' '{print $5}' | tr '[:upper:]' '[:lower:]'`
    DELIMI=`echo "$DASHBOARDARG" | awk -F"|" '{print $8}'` 
    IGNORE=`echo "$DASHBOARDARG" | awk -F"|" '{print $9}'`
    DUSER=`echo "$DASHBOARDARG" | awk -F"|" '{print $10}'`
    OLDLID=`echo "$DASHBOARDARG" | awk -F'|' '{print $11}'`
    IMPORTEXPFLAG=`echo "$DASHBOARDARG" | awk -F'|' '{print $12}' | sed -e 's/\"//g'`
    SN=`echo "$DASHBOARDARG" | awk -F'|' '{print $13}' | sed -e 's/\"//g'`
    DATEOVERRIDE=`echo "$DASHBOARDARG" | awk -F'|' '{print $14}' | sed -e 's/\"//g'`
    CLID=`echo "$DASHBOARDARG" | awk -F'|' '{print $15}' | sed -e 's/\"//g'`
    export CLID
    DELIMI=${DELIMETERS[$DELIMI]}
    #echo $DELIMI
    SKROWS=`echo "$DASHBOARDARG" | awk -F"|" '{print $7}'`
    datatype=`echo "$DASHBOARDARG" | awk -F'|' '{print $6}' | sed -e 's:\"::g'`
    #PARENT=`echo "$FULLNAME" | awk -F'/' 'BEGIN{i=1}{while(i<NF){printf "%s/",$i;i++}}'`
    PARENT=`echo "$FULLNAME" | awk -F'/' 'BEGIN{i=1}{while(i<NF-2){printf "%s/",$i;i++}}'`
    if [[ "$datatype" =~ "CONTROL" ]]; then
	echo "Control Total File Passed from dashboard"
    else
	attrFilename="${LYID}.attr"
	if [[ $SVNSCRIPTS == "TRUE" ]] && [[ $LYID != 1 ]]; then
            ATTRFULL="${LOGDIR}/$FMONID/$attrFilename"
            svnExport 'ATTR'
	else
            ATTRFULL="${ATTRDIR}/$attrFilename"
	fi
	controlline=$(awk -F'|' '/CONTROLLINE/{print $2}' "${ATTRFULL}")
    fi
    
    echo "Parse dashboard arg completed $datatype"
}

function cuttingFloor(){
    toprec=$($DEFAULTACTIONDIR/${TOPRECORD_NAME} "$FULLNAME")
    if [ -f "$ATTRFULL" ]; then
    #if [ -z "$ATTpRFULLPATH" ]; then
	INFO9="Attribute file found."
	echo "$INFO9"
	allLogging "::::$INFO9"
	controlline=$(awk -F'|' '/CONTROLLINE/{print $2}' "$ATTRFULL")
        deliStatus=($(awk -F'|' '/CHKNUMFIELDS/{print $3}' "$ATTRFULL"))
        fixedStatus=($(awk -F'|' '/CHKLENFIXED/{print $2}' "$ATTRFULL"))
	if [[ ${#deliStatus[@]} = 0 ]]
        then
            #echo ${fixedStatus[@]} "Fixed Status"
            #fieldLength=$fixedStatus
            compareField ${fixedStatus[0]}
        elif [[ ${#fixedStatus[@]} = 0 ]] ; then
            #fieldLength=$deliStatus
	    #echo ${deliStatus[@]} "Deli Status"
            deli=($(awk -F'|' '/CHKNUMFIELDS/{print $2}' "$ATTRFULL"))
            compareField ${deli[0]} ${deliStatus[0]}
        fi
    else
	INFO9="Attribute file not found"
	echo "$INFO9"
	allLogging "::::$INFO9"
    fi
}

#Check Single Line File
function checkSingleLineFile()
{
    read mC0 mC1 mC2 <<< $(wc "$FULLNAME" | awk '{print $1 " " $2 " " $3}')
    #numlineCnt=$(wc -l "$FULLNAME" | awk '{printf "%d", $1}')
    if [[ ${#mC2} != 0 ]]; then
	if [ $mC2 -ge 80000 ] && [ $mC0 -le 1 ]; then
	    INFO12="Line length exceed threashold value. It might be single line data file."
            echo -e "${RED}$INFO12${NOC}"
            INFO13="File not imported due to Line length exceed threashold value"
            INFO14="Moved to work/exceptions folder: File $fiilename $dmfileid |$numLine"
            insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "$INFO13" "${AIPDESTDIR}$PARENT" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$startTime" "$endTime" "$dmfileid" "" "" "$toprec" "$EMPID"
            aip_dmfilelist_log
            allLogging "::::$INFO12"
        #echo "Called dmfilelist insert LayoutMisMatchExp"
            #processFilePath="${AIPDESTDIR}${PARENT}"work/exceptions
            #chkFileExists "$processFilePath"
            #mv "$FULLNAME" "$processFilePath/${filename}"
            #STA="EXCEPTIONS"
            processExceptions
        #mv "$FULLNAME" "${AIPDESTDIR}${PARENT}"work/exceptions
            updateLog "$processFilePath" "$STA"
            allLogging "::::$INFO14"
            exit 0	
	fi
    fi
}

function processOverRideAttr()
{
    #Logic for overridefunction
    echo "LOGICS FOR OVERRIDE ACTIVE"
    OVERRIDEATTLOC="${LOGDIR}/$FMONID/OVERRIDEATTR"
    mkdir -p "${OVERRIDEATTLOC}"
    attrFilename="${UFILEID}_${CLID}_${LYID}.attr"
    ATTRFULL="${OVERRIDEATTLOC}/${attrFilename}"
    #echo "$ATTRFULL"
    #$JAVA_HOME/bin/java -jar $DASHBOARDUTILGEN -t A -c $FLMSSERVER:1521:d2he -u $FLMS -p $SPASSWORD -l $LYID -r $SN > "${ATTRFULL}"
    $JAVA_HOME/bin/java -jar $DASHBOARDUTILGEN -t A -c nveigerwork:1521:d2he -u $FLMS -p $SPASSWORD -l $LYID -r $SN > "${ATTRFULL}"
}

#Parse the attr file
function parseAttrFile()
{
    if [[ $FLID == '1' ]];then
	OPTENC=$(awk -F'|' '/OPTENC/ {print $2}' "$ATTRFULL")
	SKROWS=$(awk -F'|' '/HEADER/ {print $2}' "$ATTRFULL")
    fi
}

#Parse the output for getFileID.sh
#Sample Output: FLID|1|83|824|Trinity|ELIGIBILITIES|6251
function parseGetFileIdReturn()
{
    #read FLID LYID CLID EMPID DTYPE DELIMI SKROWS IGNORE OPTENC UFILEID <<< $(echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $2 " " $3 " " $4 " " $5 " " $6 " " $7 " " $8 " " $9 " " $10 " " $11}')
    attrFilename=$(echo $getFIDReturn | awk -F'|' '{printf "%s.attr",$3}')
    FLID=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $2}'| sed -e 's/[[:space:]]//g'`
#    echo $FLID
    #FLID=`echo $FLID | sed -e 's/[[:space:]]//g'`
    LYID=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $3}'`
    #CLID=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $4}'`
    EMPID=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $5}'`
    DTYPE=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $6}'`
    DELIMI=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $7}'`
    SKROWS=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $8}'`
    IGNORE=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $9}'`
    #manualflag=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $10}'`
    UFILEID=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $11}'`
    SN=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $12}'`
    DATEOVERRIDE=`echo "$getFIDReturn" | awk -F"|" '/FLID/ {print $13}'`
    #ATTRFULLPATH="${ATTRDIR}/$attrFilename"
    if [[ ${#SN} != 0 ]];then 
	processOverRideAttr
	parseAttrFile
    else
	if [[ $SVNSCRIPTS == "TRUE" ]] && [[ $LYID != 0 ]] && [[ $LYID != 1 ]] && [[ $FLID = 1 ]]; then
	    ATTRFULL="${LOGDIR}/$FMONID/$attrFilename"
	    svnExport 'ATTR'
	else
	    ATTRFULL="${ATTRDIR}/$attrFilename"
	fi
	DATEOVERRIDE=''
    fi
    checkSingleLineFile
    if  [[ $FLID == '1' ]] || [[ $FLID == '0' ]];then
	cuttingFloor
	echo "$toprec"
    fi
}
#Parse the output of getFileStats.sh
function parseGetStatsReturn()
{
    numLine=$(echo "$getFStatsReturn" | awk -F"#" '/^[[:space:]]+NUMLINES#/ {printf "%d\n",$2}' | sed -e 's/[[:space:]]//g')
    filesize=$(echo "$getFStatsReturn" | awk -F"#" '/^[[:space:]]+SIZE#/ {printf "%d\n",$2}' | sed -e 's/[[:space:]]//g')
    ckSum=$(echo "$getFStatsReturn" | awk -F"#" '/^[[:space:]]+CKSUM#/ {printf "%d\n",$2}' | sed -e 's/[[:space:]]//g')
    hashKey=$(echo "$getFStatsReturn" | awk -F"#" '/^[[:space:]]+HASHKEY#/ {printf "%s\n",$2}' | sed -e 's/[[:space:]]//g')
    junkchar=$(echo "$getFStatsReturn" | awk -F"#" '/^[[:space:]]+JUNKCHARCNT#/ {printf "%s\n",$2}' | sed -e 's/[[:space:]]//g')
    dupRec=$(echo "$getFStatsReturn" | awk -F"#" '/^[[:space:]]+DUPRECORDS#/ {printf "%s\n",$2}' | sed -e 's/[[:space:]]//2')
    OLDIFS="$IFS"
    declare -A statchk=()
    IFS=$'\n'
    statsallcontents=($(echo "$getFStatsReturn" | awk -F'#' 'BEGIN{fl=0}{if($1~/OPTENC/){fl=1}if(fl==1){print $0}}' | head -n -1 | tail -n +2))
    #colsum=($(echo "$getFStatsReturn" | awk  '/^[[:space:]]+COLSUM/ {print $0}'))
    #chkval=($(echo "$getFStatsReturn" | awk  '/^[[:space:]]+CHKVAL/ {print $0}'))
    layout=($(echo "$getFStatsReturn" | awk  '/^[[:space:]]+LAYOUT#/ {print $0}'))
    #chkdate=($(echo "$getFStatsReturn" | awk  '/^[[:space:]]+CHKDATE/ {print $0}'))
    #chknumfields=($(echo "$getFStatsReturn" | awk  '/^[[:space:]]+CHKNUMFIELDS/ {print $0}'))
    #echo "From parse ${chknumfields[@]}"
    #chklenfixed=($(echo "$getFStatsReturn" | awk  '/^[[:space:]]+CHKLENFIXED/ {print $0}'))
    IFS="$OLDIFS"
    #Check hash value of the file copied vs the hash value from dmlist
    if [ ! -z $hashvalue ] && [[ "$hashKey" != "$hashvalue" ]]; then
	INFO15="Hash value from DM list and local file mis match. File may be corrupted"
	echo "$INFO15"
    fi
    #echo "${colsum[0]}"
}

function checkFileList(){
    if [ -f "$TMPDIR/dmfile.$FMONID.flist" ];then
	fileList=($(cat "$TMPDIR/dmfile.$FMONID.flist"))
	if [ -z "${#fileList[@]}" ];then
	    INFO2="File List Empty. Nothing to copy. Exiting"
	    echo "$INFO2"
	    allLogging "::::$INFO2"
	    echo "File List Empty. Exiting" 2>&1 | tee -a $LOGDIR/fmon.log
	    exit 1
	else
	    OLDIFS="$IFS"
	    IFS=$'\n'
	    fileList=($(cat "$TMPDIR/dmfile.$FMONID.flist"))
	    IFS="$OLDIFS"
	    INFO2="File List found."
	    echo "$INFO2"
	    allLogging "::::$INFO2"
	fi
    fi
}
#########################################################################
##################### Parsing Functions ENDS#############################
#########################################################################
function infolayoutCheck()
{
    if [[ $DASHBOARD != "TRUE" ]]; then
	insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "$INFO13" "${AIPDESTDIR}$PARENT" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$startTime" "$endTime" "$dmfileid" "" "" "$toprec" "$EMPID"
	aip_dmfilelist_log
    fi
    allLogging "::::$INFO12"
	#echo "Called dmfilelist insert LayoutMisMatchExp"
	    #processFilePath="${AIPDESTDIR}${PARENT}"work/exceptions
	    #chkFileExists "$processFilePath"
	    #mv "$FULLNAME" "$processFilePath/${filename}"
	    #STA="EXCEPTIONS"
    processExceptions
	#mv "$FULLNAME" "${AIPDESTDIR}${PARENT}"work/exceptions
    if [[ $DASHBOARD == "TRUE" ]]; then
		#update_aip_dmfilelist_log
	aip_manualrun_log
	updateLogDashBoardPost "Moved from ${curDir} to $STA" "$INFO13" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$processFilePath" "$STA" "$toprec" "$UFILEID"
    fi
    updateLog "$processFilePath" "$STA" 
    allLogging "::::$INFO14"
    exit 0
}

function layoutCheck(){
#Check the field length or column number
    deliresult=($(echo "$getFStatsReturn" | awk -F'#' '/CHKNUMFIELDS/{print $2}' | awk -F' ' '{printf "%d",$1}'))
    fixedresult=($(echo "$getFStatsReturn" | awk -F'#' '/CHKLENFIXED/{print $2}' | awk -F' ' '{printf "%d",$1}'))
    layoutschecksum=$(echo "$getFStatsReturn" | awk -F'#' '/LAYOUT/{print $2}' | awk -F' ' 'BEGIN{SUM=0}{if($2!=0){SUM++}}END{print SUM}')
    #echo "Layout check sum : $layoutschecksum ${#deliresult[@]}"
    #fixedresult=$(echo "$getFStatsReturn" | awk -F'#' '/CHKLENFIXED/{print $2}' | awk -F' ' '{sum=sum+$1}END{printf "%d",sum}')
    #deliresult=$(echo "$getFStatsReturn" | awk -F'#' '/CHKNUMFIELDS/{print $2}' | awk -F' ' '{sum=sum+$1}END{printf "%d",sum}')
    if [[ ${#deliresult[@]} = 0 ]]
    then
	#((errPerc=${fixedresult}/${numLine}*100))
        checkLayout=$(echo ${fixedresult[@]} | grep "^0")
    else
        checkLayout=$(echo ${deliresult[@]} | grep "^0")
	#((errPerc=${deliresult}/${numLine}*100))
    fi
    if [[ $CHKLAYOUTMISMATCH == "TRUE" ]] ; then 
	echo "Calling checklayout function."
	if [[ $layoutschecksum == '0' ]]; then
	    INFO12="No data identified based on layout defined"
	    INFO13="File not imported due to layout mismatch error"
            INFO14="Moved to work/exceptions folder: File $fiilename $dmfileid |$numLine"
	    infolayoutCheck
	fi
	if [[ ${#checkLayout} = 0  ]]; then
            #if [ $errPerc -gt 2 ]; then
	    INFO12="Number for fields or Length in does not match."
	    echo -e "${RED}$INFO12${NOC}"
	    #endTime=$(date "+%F %T")
	    INFO13="File not imported due to layout mismatch error"
	    INFO14="Moved to work/exceptions folder: File $fiilename $dmfileid |$numLine"
	    infolayoutCheck
	else
	    INFO12="Number of fields or Length matched."
	    allLogging "::::$INFO12"
	    allLogging "::::$INFO14"
	fi
    else
	echo "Check Layout disabled"
    fi
}
#Combines queary to form complex queries
function appendQuery()
{
    appQuery[$j]=$1
    ((j=j+1))
}

function buildStatsQueryAll()
{
    declare -a appQuery=()
    j=1
    appendQuery "INSERT ALL"
#statsCheck="$1"
#echo "${statsCheck[@]}"
#It will insert the type checks performed for the raw data.
#OLDIFS="$IFS"
#IFS=$'\n'
#echo "${colsum[0]}"
#statsallcontents
    LAYOUTNUM=1
    for i in "${statsallcontents[@]}"
    do	
	#echo "$i"
	#fileStatsID="${fileID}_${file_id}"
	if [[ "$i" =~ "LAYOUT#" ]];then
	    LAYOUTNUM=$(echo "$i" | awk -F"#" '{print $2}' | awk '{printf "%s",$1}')
	else
	    local results1=$(echo "$i" | awk -F"#" '{printf "%s",$2}' | sed -e 's/[[:space:]]//g' | sed -e "s:':'':g")
	    local checkType=$(echo "$i" | awk -F"#" '{print $1}' | awk '{printf "%s",$1}')
	    local fieldName=$(echo "$i" | awk -F"#" '{print $1}' | awk '{printf "%s",$2}' | sed -e 's/\[.*//g')
	    if [[ "$i" =~ "CHKLENFIXED " ]] || [[ "$i" =~ "CHKNUMFIELDS " ]];then
		local checkDetails=$(echo "$i" | awk -F"#" '{print $1}' | awk '{print $2}' | sed -e "s:':'':g")
	    else
		local checkDetails=$(echo "$i" | awk -F"#" '{print $1}' | awk '{print $2}' | awk -F']' '{printf "%s]", $2}'| sed -e 's/]\|\[//g' | sed -e "s:':'':g")
	    fi
	#local checkDetails=$(echo $i | awk -F"#" '{print $1}' | awk '{print $2}' | awk -F']' '{printf "%s]", $2}')
	#echo "$results1" "$checkType" "$fieldName" "$checkDetails"
	    appendQuery " INTO imp_file_stats_log(fileid,layoutid,fieldname,checktype,checkdetail,result,sublayoutid) VALUES('"${UFILEID}_${dmfileid}"','"$LYID"','"$fieldName"','"$checkType"','"$checkDetails"','"$results1"','"$LAYOUTNUM"')
"	
	fi
    done
    appendQuery "SELECT 1 FROM DUAL "
    insert_file_stats
    unset appQuery
    unset j
#IFS="$OLDIFS"
}


function ins_aip_main_det()
{
    #$file_id"','"$sublayoutid"','"$layoutcnt
    #echo "ins_aip_main_det function"
    #j=1
    file_id="${UFILEID}_${dmfileid}"
    for i in "${layout[@]}"
    do
	#layoutcnt=$(echo "$i" | awk -F'#' '{print $2}' | awk '{printf "%s",$1}')
	layoutcnt=$(echo "$i" | awk -F"#" '{print $2}' | awk '{printf "%s",$2}' | sed -e 's/\[//g' -e 's/\]//g')
	sublayoutid=$(echo "$i" | awk -F"#" '{print $2}' | awk '{printf "%s",$1}' | sed -e 's/\[//g' -e 's/\]//g')
	#sublayoutid=$j
	#((j=j+1))
	aip_main_det
    done
}

function fmonCopy()
{
#Checks for AIPCOPY Flag.If set calls copyFiles script
    if [[ $AIPCOPY == "TRUE" ]]
    then
	#echo "CALLING copyFILES for file $filename"
	copyreshvm=0;copyresfilenot=0;copyfal=0;
	#$DEFAULTACTIONDIR/${FMONCOPY_NAME} -f "$line"
	#$DEFAULTACTIONDIR/${FMONCOPY_NAME} -f "$line"
	copyres=$($DEFAULTACTIONDIR/${FMONCOPY_NAME} -f "$line")
	#echo "$copyres"
	#$DEFAULTACTIONDIR/${FMONCOPY_NAME} -f "$line"
	copyresfilenot=$(echo "$copyres"| awk -F'|' '/File not found./ {print $1}')
	copyreshvm=$(echo "$copyres"| awk -F'|' '/Error HVNM :/ {print $1}')
	copyfal=$(echo "$copyres"| awk -F'|' '/Copy Faliure/ {print $1}')
	if [ -z "$copyresfilenot" ] && [ -z "$copyreshvm" ] && [ -z "$copyfal" ] ; then
	#if [ -f "$FULLNAME" ]; then
	    INFO7="File copied successfully"
	    CPFLAG="Y"
	else
	    INFO7="Error. File copy was not successful due to ${copyresfilenot}${copyreshvm}${copyfal}"
	    CPFLAG="N"
	    ECODE="COPYERR"
	    INFO13="Copy from eiger not successful"
	    aip_dmfilelist_log
	    #insertMainLog "$UFILEID" "$FNAME" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "${AIPDESTDIR}/$PARENT" "${WORKDIR}/${filename}${dmfileid}.stat" "$startTime" "$endTime" "$dmfileid" "$processFilePath" "$STA" "$toprec"
	    echo "$INFO7"
	    exit 0
	fi
	echo "$INFO7"
    else
	echo "AIPCOPY Flag Disabled in config file"
    fi
}

function trimString()
{
    #This function trims the passed string to a second argument
    echo "$1" | awk '{print substr($0,0,cutlen)}' cutlen="$2"
}

function compressFile()
{
    #First parameter file path. Compress the file
    #checkfile=$()
    if [[ $FILECOMPRESS == 'TRUE' ]] ; then
	gzip -f "$1"
    else
	echo "File Compression FALSE"
    fi
}

function uncompressFile()
{
    #Decompress the file given by the first parameter
    #echo "uncompress $1"
    filetypecheck=$(file "$1" | grep "gzip compressed data")
    if [[ ${#filetypecheck} != 0 ]] ; then
	gzip -d "$1"
    else
	echo "File Compression FALSE"
    fi
}

#Check if file exists already in the buckes. If yes, add dmfileid to the file
function chkFileExists()
{
    FILEALREADYEXISTSFLAG='FALSE'
    aip_filename=''
    if [ -f "${1}/${filename}" ] || [ -f "${1}/${filename}.gz" ]; then
	echo "File already exists in the bucket"
	#aip_filename="${filename}"
	aip_filename="${filename}-${dmfileid}"
	FILEALREADYEXISTSFLAG='TRUE'
    fi
    
}

#Function move files for different processes
function moveFiles(){
    if [[ ${#aip_filename} == '0' ]];then 
	mv "${FULLNAME}" "$processFilePath/${filename}"
	compressFile "$processFilePath/${filename}"
    else
	mv "${FULLNAME}" "$processFilePath/${aip_filename}"
        compressFile "$processFilePath/${aip_filename}"
    fi
}

#function for files while fileid is not generated
function processNoFileId()
{
    if [[ $DASHBOARD == "TRUE" ]]; then
	processFilePath="${PARENT}"work/unknown
    else
	processFilePath="${AIPDESTDIR}${PARENT}"work/unknown
    fi
    #echo "${PARENT}"
    cuttingFloor
    moveFiles
    #chkFileExists "$processFilePath"
    #mv "${FULLNAME}" "$processFilePath/${filename}"
    #compressFile "$processFilePath/${filename}"
    STA="UNKNOWN"
    #INFO13="File pattern not matched. FLMS returned unknown status"
    INFO14="Moved to work/unknown folder. File : $filename $dmfileid |$numLine"
    allLogging "::::$INFO14"
    #endTime=`date "+%F %T"`
    if [[ $DRYRUN == "FALSE" ]]; then
	echo "DRYRUN flag is false. Inserting info into database(imp_main_log)"
	insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "" "${AIPDESTDIR}$PARENT" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$startTime" "$endTime" "$dmfileid" "$processFilePath" "$STA" "$toprec" "$EMPID"
	aip_dmfilelist_log
    else
	echo "DRYRUN flag is true. Database operation skipped"
    fi
}

function processUnknown()
{
    echo "Moving file to work/unknown"
    STA="UNKNOWN"
    if [[ $DASHBOARD == "TRUE" ]]; then
        processFilePath="${PARENT}"work/unknown
    else
        processFilePath="${AIPDESTDIR}${PARENT}"work/unknown
    fi
    #processFilePath="${AIPDESTDIR}${PARENT}work/unknown"
    chkFileExists "$processFilePath"
    moveFiles
    #mv "$FULLNAME" "$processFilePath/${filename}"
    #compressFile "$processFilePath/${filename}"
    INFO13="File pattern not matched. FLMS returned unknown status"
    INFO14="Moved to work/unknown folder. File : $filename $dmfileid |$numLine"
    allLogging "::::$INFO14"
    #endTime=`date "+%F %T"`
    if [[ $DRYRUN == "FALSE" ]]; then
	echo "DRYRUN flag is false. Inserting info into database(imp_main_log)"
	insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "" "${AIPDESTDIR}$PARENT" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$startTime" "$endTime" "$dmfileid" "$processFilePath" "$STA" "$toprec" "$EMPID"
	aip_dmfilelist_log
    else
	echo "DRYRUN flag is true. Database operation skipped"
    fi
}

function processDontuse()
{
    echo "Moving file to work/donotuse"
    STA="DONOTUSE"
    if [[ $DASHBOARD == "TRUE" ]]; then
        processFilePath="${PARENT}"work/donotuse
    else
        processFilePath="${AIPDESTDIR}${PARENT}"work/donotuse
    fi
    #processFilePath="${AIPDESTDIR}${PARENT}work/donotuse"
    chkFileExists "$processFilePath"
    moveFiles
    #mv "$FULLNAME" "$processFilePath/${filename}"
    #compressFile "$processFilePath/${filename}"
    INFO13="File pattern set as do not use"
    INFO14="Moved to work/donotuse folder. File : $filename $dmfileid |$numLine"
    allLogging "::::$INFO14"
    #endTime=`date "+%F %T"`
    if [[ $DRYRUN == "FALSE" ]]; then
	echo "DRYRUN flag is false. Inserting info into database(imp_main_log)"
	insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "" "${AIPDESTDIR}$PARENT" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$startTime" "$endTime" "$dmfileid" "$processFilePath" "$STA" "$toprec" "$EMPID"
	aip_dmfilelist_log
    else
	echo "DRYRUN flag is true. Database operation skipped"
    fi
}

function processCtl()
{
#    echo "Moving file to work/ctl"
    STA="CONTROL"
    if [[ $DASHBOARD == "TRUE" ]]; then
        processFilePath="${PARENT}"work/ctl
    else
        processFilePath="${AIPDESTDIR}${PARENT}"work/ctl
    fi
    #processFilePath="${AIPDESTDIR}${PARENT}work/ctl"
    #echo "$processFilePath"
    numLine=$(awk 'END{print NR}' "$FULLNAME")
    cattrFilename="${LYID}.cattr"
    if [[ $SVNSCRIPTS == "TRUE" ]] && [[ $LYID != 1 ]]; then
        ATTRFULL="${LOGDIR}/$FMONID/$cattrFilename"
        svnExport 'CATTR'
    else
        ATTRFULL="$CATTRDIR/${LYID}.cattr"
    fi
    local IFS=$'\n'
    if [ -f "$ATTRFULL" ]; then
	INFO9="Control total attribute file found"
        ctlres="$($DEFAULTACTIONDIR/${IMPORT_CTLFILE_NAME} -f "$FULLNAME" -a "$ATTRFULL")"
	#echo "$DEFAULTACTIONDIR/${IMPORT_CTLFILE_NAME} -f $FULLNAME -a $ATTRFULL"
	controlrecords=($(echo "$ctlres" | awk -F'|' '/OUTPUT/ {print $0}'))
        echo "CONTROL TOTAL SCRIPT EXECUTED"
    else
	INFO9="Control total attribute file not found"
	#ctlres='OUTPUT||||'
    fi
    INFO10=''
   # CTL: Temp funtion call for test    
    #echo "Call control file" 
   #extractControlFile
#    ctrfileres=$($DEFAULTACTIONDIR/${IMPORT_CTLFILE_NAME} -f "$FULLNAME" -a ATTRIBUTE)
    chkFileExists "$processFilePath"
    moveFiles
    #mv "$FULLNAME" "$processFilePath/${filename}"
    #compressFile "$processFilePath/${filename}"
    #endTime=`date "+%F %T"`
    if [[ $DRYRUN == "FALSE" ]]; then
	echo "DRYRUN flag is false. Inserting info into database(imp_main_log)"
	if [[ $DASHBOARD != "TRUE" ]]; then
	    insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "" "${AIPDESTDIR}$PARENT" "" "$startTime" "$endTime" "$dmfileid" "$processFilePath" "$STA" "" "$EMPID"
	fi
	processdate=$(date "+%F %T")
	stats_of_imp=$(echo "$ctlres" | sed -e 's/OUTPUT//g' -e 's/|//g' -e 's/[[:space:]]//g' -e 's/^$/%/g')
    #echo "${stats_of_imp}"
	if [[ "$ctlres" =~ "Invalid TYPE defined or Corrupt CATTR File"  ]] || [[ "${stats_of_imp}" =~ '%' ]]; then
	    INFO13="Control Total file unprocessed"
	    echo $INFO13
	    insertControlSta
#    fi
#    if [[ "${stats_of_imp}" == '%' ]] || [[ "${stats_of_imp}" =~ 'Invalid' ]];then
	#updateControlSta "UNPROCESSED"
	#insertControlSta

	else
	    INFO13="Control Total file successfully processed"
	    insertControlRecords "$UFILEID" "$filename" "" "$processdate" "" "$EMPID" "$pay"
	#updateControlSta "PROCESSED"
	    echo $INFO13
	fi
	allLogging "::::$INFO13"
	INFO14="Moved to work/ctl folder. File : $filename $dmfileid| $numLine"
	allLogging "::::$INFO14"
	echo $INFO14
	if [[ $DASHBOARD != "TRUE" ]]; then
	    aip_dmfilelist_log
	fi
    else
	echo "DRYRUN flag is true. Database operation skipped"
    fi
}

function processExceptions()
{
    if [[ $DASHBOARD == "TRUE" ]]; then
	processFilePath="${PARENT}"work/exceptions
    else
	processFilePath="${AIPDESTDIR}${PARENT}"work/exceptions
    fi
    #echo "${PARENT}"
    chkFileExists "$processFilePath"
    moveFiles
    #mv "${FULLNAME}" "$processFilePath/${filename}"
    #compressFile "$processFilePath/${filename}"
    STA="EXCEPTIONS"
}

function processImport()
{
    INFO13="$filename imported successfully. $ROWS"
    echo -e "${ORANGE}[OK] $INFO1${NOC}"
    allLogging "::::$INFO13"
    extractControlLine
    if [[ $DASHBOARD == "TRUE" ]]; then
	processFilePath="${PARENT}"work/imported
    else
	processFilePath="${AIPDESTDIR}${PARENT}"work/imported
    fi
    chkFileExists "$processFilePath"
    moveFiles
    #mv "${FULLNAME}" "$processFilePath/${filename}"
    #gzip -f "$processFilePath/${filename}"
    #compressFile "$processFilePath/${filename}"
    STA="IMPORTED"
    if [[ $? = 0 ]]; then
	INFO14="Moved to work/imported folder. File : $filename $dmfileid |$numLine"
	echo "$INFO14"
	allLogging "::::$INFO14"
    else
	INFO14="Moving to work/imported folder failed"
	echo "$INFO14"
	allLogging "::::$INFO14"
    fi
    #gzip -9 "$processFilePath/${filename}"
    #if [ $? -eq 0 ]; then
    #	INFO15="Compression Successful"
    #else
    #	INFO15="File Compression was unsuccessful"
    #fi
    #echo "$INFO15"
}

function extractControlLine()
{
    if [[ ${#controlline} !=  0 ]] && [[ ${controlline} != 0 ]]; then
	cattrFilename="${LYID}.cattr"
	if [[ $SVNSCRIPTS == "TRUE" ]]; then
	    ATTRFULL="${LOGDIR}/$FMONID/$cattrFilename"
	    svnExport 'CATTR'
	else
	    ATTRFULL="$CATTRDIR/${LYID}.cattr"
	fi
	if [ -f "$ATTRFULL" ]; then
	    local IFS=$'\n'
	    controlrecords=($($DEFAULTACTIONDIR/${IMPORT_CLT_NAME} -f "$FULLNAME" -a "$ATTRFULL"))
	    echo "CONTROL TOTAL SCRIPT EXECUTED $controlrecords"
	    processdate=$(date "+%F %T")
	    if [[ "${controlrecords[@]}" =~ "Invalid" ]]; then
		echo "Control total file unprocessed"
		insertControlSta
	    else
	    #insertinto vhcon
		insertControlRecords "$UFILEID" "" "$filename" "$processdate" "" "" ""
	    fi
	fi
    fi
}

function processXls()
{
    INFO8="Procesing XLS File: $filename"
    allLogging "::::$INFO8"
    $DEFAULTACTIONDIR/xls2txt -d '|' -i "$FULLNAME" -o "${AIPDESTDIR}${PARENT}"
    #echo $? " Exit status of xls converter"
    if [ $? -ne 0 ]; then
	INFO13="Error : Conversion from xls to csv failed. Unsupported format"
	ECODE="Excel Conversion Failed"
	XLSFAILEDFLAG="Y"
	echo "$INFO13"
	#aip_dmfilelist_log
    fi
    #chkFileExists "${AIPDESTDIR}${PARENT}"work/xls2csv
    if [[ $DASHBOARD == "TRUE" ]]; then
        processFilePath="${PARENT}"work/xls2csv
    else
        processFilePath="${AIPDESTDIR}${PARENT}"work/xls2csv
    fi
    trimedfilename=$(echo "$filename")
    chkFileExists "$processFilePath"
    moveFiles
    #mv -f "$FULLNAME" "${AIPDESTDIR}${PARENT}"work/xls2csv/"${filename}"
    #if [[ $FILEALREADYEXISTSFLAG == 'TRUE' ]]; then
#	filename="$aip_filename"
 #   fi
  #  mv -f "$FULLNAME" "${processFilePath}/${filename}"
   # compressFile "$processFilePath/${filename}"
    INFO14="Moved to work/xls2csv folder. File : $filename $dmfileid"
    echo "$INFO14"
    allLogging "::::$INFO14"
    if [ -n "$XLSFAILEDFLAG" ]; then
	echo "XLSFAILED Flag"
	aip_dmfilelist_log
	exit 1
    fi
   #echo "AFter checking flag"
    local IFS=$'\n'
    xlsfiles=($(ls "${AIPDESTDIR}${PARENT}" | grep "${trimedfilename}*"))
    echo "Converted Files: ${#xlsfiles[@]}"
    if [[ ${#xlsfiles[@]} = 0 ]]; then
	INFO13="Error : Converted xls file not found or conversion unsucessful"
	ECODE="Excel Conversion Failed"
	echo "$INFO13"
	aip_dmfilelist_log
	exit 1
    fi
    for k in "${xlsfiles[@]}"
    do
	FULLNAME="${AIPDESTDIR}${PARENT}$k"
	echo "$FULLNAME"
	filename="$(echo "$FULLNAME" |  awk -F"/" '{print $NF}')"
	processDataFile
    done
    #echo "Afer checking converted files"
}

function deldataControl()
{
    query="delete from imp_vh_control_total@"$FLMSLINK" where fileid='"$UFILEID"'"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "${FLMS}/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >> /dev/null
$query;
commit;
exit;
EOF
else
    echo "DRYRUN Flag is set as TRUE"
fi
}

function deldataReimport()
{
    echo "For clearing data for reimport"
    CLIENTSCHEMA="AI0${CLID}"
    #Algo : Use the fileid passed as argument and query imp_main_det_log for scheme name
   # query="SELECT aischemaname||'|'||aitablename  FROM imp_main_det_log@FLMSDEV WHERE fileid='5148_1548401';"
query="DECLARE
    tempvar VARCHAR2(200);
    vquery VARCHAR2(200);
    BEGIN
    FOR files IN (SELECT *  FROM imp_main_det_log@"$FLMSLINK" WHERE fileid='"${file_id}"')
      LOOP
        tempvar:=files.AITABLENAME;
        BEGIN
          vquery:='delete from imp_main_det_log@"$FLMSLINK" WHERE fileid=''"${file_id}"'' AND AITABLENAME='''||tempvar||'''';
          BEGIN
            EXECUTE IMMEDIATE(vquery);
            EXCEPTION WHEN OTHERS THEN NULL;
          END;
          EXECUTE IMMEDIATE('DELETE FROM '||tempvar||'  WHERE fileid=''"${file_id}"''');
          EXCEPTION WHEN OTHERS THEN NULL;
        END;
      END LOOP;
    END;
"

    #echo "$query $$SPASSWORD ${CLIENTSCHEMA}"
    #sqlplus -S importdb/oracle <<EOF > /dev/null
if [[ $DRYRUN == "FALSE" ]]; then
    sqlplus -S "${CLIENTSCHEMA}/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$IMPORTDBSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF 
    $query
    /
    commit;
EOF
    echo "Done"
else
echo "DRYRUN Flag is set as TRUE"
fi
}

function processDashboard()
{
    #Moving the file to the original directrory
    echo "$FMONID"
    echo "Argment passed from dashboard is:"
    echo "$DASHBOARDARG"
    echo "Flag from dashboard $IMPORTEXPFLAG"
    if [[ $IMPORTEXPFLAG == "E" ]]; then
	processtype="Exceptions import"
	deldataReimport
    elif [[ $IMPORTEXPFLAG == "R" ]]; then
	processtype="Re import"
	echo "From reimport flag function"
	deldataReimport
    #elif [[ $IMPORTEXPFLAG == "C" ]]; then
	#processtype="CONTROL TOTAL"
    fi
    echo "processtype $processtype"
 #   echo "$FULLNAME" "${PARENT}/${filename}"
    if [[ $DRYRUN == "FALSE" ]]; then
	updateLogDashBoardPre "MANUAL" "$LYID" "$MSTIME" "$datatype" "$EMPID" "$UFILEID"
	#echo "updateLogDashBoardPre MANUAL $LYID $MSTIME $datatype $EMPID $UFILEID"
    else
	echo "DRYRUN flag is true. Dababase operation skipped"
    fi
    uncompressFile "${FULLNAME}.gz"
    mv "$FULLNAME" "${PARENT}${filename}"
    if [ $? -ne 0 ]; then
	STA="EXCEPTIONS"
	INFO16="Moving file was not successfull. Please check if file exits in that location or permission is correct"
	if [[ $DRYRUN == "FALSE" ]]; then
            updateLogDashBoardErr "MANUAL" "$INFO16" "Moved from ${curDir} to $STA"  "$UFILEID"
	    ECODE="CANNOT MOVE FILE"
	    aip_manualrun_log
	     #update_aip_dmfilelist_log
	else
            echo "DRYRUN flag is true. Dababase operation skipped"
	fi
        exit 1
    fi
    OLDFULLNAME="$FULLNAME"
    echo "Moving file completed"    
    if [[ "$datatype" =~ "CONTROL" ]] ; then
	#Process Control Total
	deldataControl
	FULLNAME="${PARENT}${filename}"
	processCtl
    else
	#Process data file
	if [[ ${#SN} != 0 ]];then
            processOverRideAttr
            parseAttrFile
	else
	    DATEOVERRIDE=''
	fi
	getFStatsReturn=$($DEFAULTACTIONDIR/${GET_FILESTATS_NAME} "${PARENT}${filename}" "${ATTRFULL}")
	echo "$getFStatsReturn" > "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}"
	echo "before parse stats function"
	parseGetStatsReturn
	FULLNAME="${PARENT}${filename}"
	cuttingFloor
	if [[ $DRYRUN == "FALSE" ]]; then
        #OLDIFS="$IFS"
        #IFS=$'\n'
	    delete_file_stats
	    buildStatsQueryAll
        #buildStatsQuerySum
        #buildStatsQueryVal
        #buildStatsQueryDate
        #buildStatsQueryFields
        #buildStatsQueryFixLen
        #statsCheck=($(echo "${chklenfix[@]}")
        #buildStatsQueryDate
	fi
    #if [[ $curDir == "unknown" ]]; then
	if [[ $IGNORE != "Y" ]]; then
	    echo "before layout check"
	    layoutCheck
	fi
    #fi
    #Insert data into det tables
	ins_aip_main_det
    #FULLNAME="$OLDFULLNAME"
	echo "$DEFAULTACTIONDIR/${IMPORT_FILE_NAME} -f "${PARENT}${filename}" -l "$LYID" -i "$file_id" -e "$EMPID" -s "$SKROWS" -d "$DELIMI" -o "$OPTENC" -t "$DATEOVERRIDE""
	OUTPUT=$($DEFAULTACTIONDIR/${IMPORT_FILE_NAME} -f "${PARENT}${filename}" -l "$LYID" -i "$file_id" -e "$EMPID" -s "$SKROWS" -d "$DELIMI" -o "$OPTENC" -t "$DATEOVERRIDE")
	echo $OUTPUT
	STATUS=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print $2}'`
	ROWS=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print $5}'`
	OUTPUT1=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print $2}'`
	OUTPUTERR=`echo "$OUTPUT" | awk '/ERROR/ {print $0}'`
	if [[ "$STATUS" == "SUCCESS" ]]; then
	    processImport
	#echo "$filename imported successfully "
	#processFilePath="${PARENT}/"work/imported
	#extractControlLine
	#chkFileExists "$processFilePath"
	#mv "${PARENT}/${filename}" "$processFilePath/${filename}"
	#STA="IMPORTED"
	#INFO14="Moved to work/imported folder. File : $filename $dmfileid |$numLine"
	#echo "$INFO14"
	#allLogging "::::$INFO14"
	#if [[ $RUNREPORT == "TRUE" ]]; then
        #    echo "Calling Run report"
        #    #runReport
        #    $DEFAULTACTIONDIR/runReport.sh -c "$CLID" -f "${UFILEID}_${dmfileid}" &
        #    echo "End Run Report"
        #fi
	else
	    echo "[Fail] Error Occured: $OUTPUT"
	#processFilePath="${PARENT}/"work/exceptions
	#echo "${PARENT}"
	#chkFileExists "$processFilePath"
	#mv "${PARENT}/${filename}" "$processFilePath/${filename}"
	#STA="EXCEPTIONS"
	    processExceptions
	    INFO13="Error Occured: $OUTPUTERR"
	    INFO13=$(trimString "$INFO13" 3999)
	    INFO14="Moved to work/exceptions folder. File : $filename $dmfileid |$numLine"
	    echo "$INFO14"
	    allLogging "::::$INFO14"
	fi
    fi
    METIME=`date "+%F %T"`
    echo "Time to post log to update"
    if [[ $DRYRUN == "FALSE" ]]; then
	updateLogDashBoardPost "Moved from ${curDir} to $STA" "" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$processFilePath" "$STA" "$toprec" "$UFILEID"
	#update_aip_dmfilelist_log
	aip_manualrun_log
    else
	echo "DRYRUN flag is true. Dababase operation skipped"
    fi
} &>> "$fmonIdLogDir/${filename}.${FMONID}.${dmfileid}.log.${CLID}"

function importData(){
 #Check layout function call
    if [[ $IGNORE == "N" ]]; then
	layoutCheck
    fi
    if [[ $DRYRUN == "FALSE" ]]; then
	echo "DRYRUN flag is false. Inserting info into database(imp_main_log). Calling importFile.sh"
	DELIMI=${DELIMETERS[$DELIMI]}
	#echo "$SKROWS" "$DELIMI"
	#echo "$filesize"
	insertMainLog "$UFILEID" "$filename" "$client_id" "$LYID" "$DTYPE" "$filesize" "$ODATE" "$hashvalue" "$numLine" "$dupRec" "" "${AIPDESTDIR}$PARENT" "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}" "$startTime" "" "$dmfileid" "" "" "$toprec" "$EMPID"
	ins_aip_main_det
	OUTPUT=$($DEFAULTACTIONDIR/${IMPORT_FILE_NAME} -f "$FULLNAME" -l "$LYID" -i "${UFILEID}_${dmfileid}" -e "$EMPID" -s "$SKROWS" -d "$DELIMI" -o "$OPTENC" -t "$DATEOVERRIDE")
	STATUS=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print $2}'`
        FID=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print $3}'`
        ROWS=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print $5}'`
	OUTPUT1=`echo "$OUTPUT" | awk -F"|" '/IMPORTSTATUS/ {print substr($0,1,999)}'`
	OUTPUTERR=`echo "$OUTPUT" | awk '/ERROR/ {print $0}'`
	echo "$OUTPUT"
	if [[ "$STATUS" == "SUCCESS" ]]; then
	    #INFO13="$filename imported successfully. $ROWS"
	    #echo "$INFO13"
	    #allLogging "::::$INFO13"
	    #processFilePath="${AIPDESTDIR}${PARENT}"work/imported
	    #extractControlLine
	    #chkFileExists "$processFilePath"
	    #mv "$FULLNAME" "$processFilePath/${filename}"
	    #STA="IMPORTED"
	    #INFO14="Moved to work/imported folder. File : $filename $dmfileid |$numLine"
	    #allLogging "::::$INFO14"
	    processImport
	    #insert_aip_main_det
	    #if [[ $RUNREPORT == "TRUE" ]]; then
	    #	echo "Calling Run report"
            #    #runReport
	    #    $DEFAULTACTIONDIR/runReport.sh -c "$CLID" -f "${UFILEID}_${dmfileid}" &
            #    echo "Report Run in Background"
            #fi
	else
	    INFO13="Error Occured: $OUTPUTERR"
	    INFO13=$(trimString "$INFO13" 3999)
	    #INFO13=$(echo "$INFO13" | awk '{print substr($0,)}')
	    echo "Error Occured: $OUTPUT"
	    allLogging "::::$INFO13"
	    #processFilePath="${AIPDESTDIR}${PARENT}"work/exceptions
	    #chkFileExists "$processFilePath"
	    #mv "$FULLNAME" "$processFilePath/${filename}"
	    #STA="EXCEPTIONS"
	    processExceptions
	    INFO14="Moved to work/exceptions folder. File : $filename $dmfileid |$numLine"
	    allLogging "::::$INFO14"
	fi
	updateLog "$processFilePath" "$STA" 
	aip_dmfilelist_log
    else
	echo "DRYRUN flag is enable. Not inserting into database"
    fi
    #echo "Moving file to work/imported"
}

function processDataFile()
{
    #Checks for AIPFILEID Flag.If set calls getFileId script
    if [[ $AIPFILEID == "TRUE" ]]; then
	checkFileIdReturn
	if [[ ${#checkFileId} != 0 ]] && [ ${checkFileId} -gt 1 ] ; then
	    MULTIPLELAYIDMATCH="TRUE"
	    echo "Multiple Layoutid match occured"
	    FLID='4'
	else
	    MULTIPLELAYIDMATCH="FALSE"
	    getFIDReturn=$($DEFAULTACTIONDIR/${GET_FILEID_NAME} "$FULLNAME" | grep "^FLID")
	    INFO9="CALLING getFileID for file $filename. Output: $getFIDReturn"
	    echo -e "${ORANGE}$INFO9${NOC}"
	    allLogging "::::$INFO9"
	    parseGetFileIdReturn
	    #parseAttrFile
	fi
    else
	INFO9="AIPFILEID Flag Disabled in config file"
	echo "$INFO9"
	allLogging "::::$INFO9"
    fi
    #Checks for AIPSTATS Flag.If set calls fileStats script
    if [[ $AIPSTATS == "TRUE" ]]
    then
        INFO10="CALLING getFileStats for file $filename"
	echo "$INFO10"
	allLogging "::::$INFO10"
	if [[ $FLID == '1' ]] || [[ $FLID == '0' ]] || [[ $FLID == '4' ]] || [[ $FLID == '3' ]];then
	    getFStatsReturn=$($DEFAULTACTIONDIR/${GET_FILESTATS_NAME} "$FULLNAME" "${ATTRFULL}")
	#echo "$DEFAULTACTIONDIR/${GET_FILESTATS_NAME} $FULLNAME ${ATTRFULL}"
	    echo "$getFStatsReturn" > "${WORKDIR}/${filename}.${dmfileid}.stat.${CLID}"
	    parseGetStatsReturn
	#echo $toprec
	fi
    else
	INFO10="AIPSTATS Flag Disabled in config file"
	echo "$INFO10"
	allLogging "::::$INFO10"
    fi
    #Check the FLID return for getFileID.
    if [[ $FLID == "0" ]]; then
	INFO11="FLID is 0. File returned UNKNOWN status"
	echo "$INFO11"
	allLogging "::::$INFO11"
	processUnknown
	#aip_dmfilelist_log
    elif [[ $FLID == "2" ]]; then
	INFO11="FLID is 2. File is Control Total"
	echo "$INFO11"
        allLogging "::::$INFO11"
	processCtl
	#aip_dmfilelist_log
    elif [[ $FLID == "3" ]]; then
	INFO11="FLID is 3. File is do not use file"
	echo "$INFO11"
        allLogging "::::$INFO11"
	processDontuse
    elif [[ $FLID == "4" ]]; then
        INFO11="FLID is 4. Multiple Layoutid match occured"
        INFO13="$INFO11"
        echo "$INFO11"
        allLogging "::::$INFO11"
	processNoFileId
        #aip_dmfilelist_log
    elif [[ $FLID == "1" ]]; then
	INFO11="FLID is 1. File is data file."
	echo "$INFO11"
        allLogging "::::$INFO11"
	if [[ $AIPIMPORT == "TRUE" ]]; then
	    #INFO12="CALLING importData function for $filename"
	    #echo "CALLING importData function for $filename"
	    #allLogging "::::$INFO12"
	    if [[ $DRYRUN == "FALSE" ]]; then
		#OLDIFS="$IFS"
		#IFS=$'\n'
		buildStatsQueryAll
		#buildStatsQuerySum
		#buildStatsQueryVal
		#buildStatsQueryDate
		#buildStatsQueryFields
		#buildStatsQueryFixLen
		#statsCheck=($(echo "${chklenfix[@]}")
		#buildStatsQueryDate
	    fi
	    importData
	else
	    #INFO12="AIPIMPORT Flaag Disabled in config file"
	    echo "AIPIMPORT Flaag Disabled in config file"
	    #allLogging "::::$INFO12"
	fi
    else
	INFO11="File Layout ID is invalid"
	INFO13="$INFO11"
	echo "$INFO11"
	allLogging "::::$INFO11"
	processNoFileId
	#aip_dmfilelist_log
    fi
}

#Scripts Start to get execute
#Check Weather file list exisits or not
#checkFileList
#For each line is the filelist 
#for line in "${fileList[@]}"
#do
#{
#echo "$line"
#Check weather this script is called by dashboard for manual import
while getopts ':m:' opts
do
    case $opts in
	m) DASHBOARD="TRUE"
	    DASHBOARDARG=\""$OPTARG"\"
	    MSTIME=`date "+%F %T"`
	   #export FMONID=`date +%Y%m%d%H%M%S`
	   #fmonIdLogDir="${LOGDIR}/$FMONID"
	   #"$fmonIdLogDir/${fileName}.${FMONID}.log"
	   #mkdir $fmonIdLogDir
	   #makeFileListDashBoard
	   #echo "${DASHBOARDARG}" >> "$fmonIdLogDir/manualflelist.${FMONID}.log"
	   #echo "${DASHBOARDFILELIST[@]}" > "$fmonIdLogDir/${FMONID}.log"
	   #exit 1
	    parseDashboardArg
	    ;;
    esac
done
#echo "before loop"
if [[ $DASHBOARD == "TRUE" ]]; then
    #echo "Before process dashboard functno"
    processDashboard
else
    
    line="$1"
    #fileName=`echo ${line} | awk -F'|' '{print $4}'`
    startTime=`date "+%F %T "`
    PTIME=`date "+%F %T"`
    echo -e "${GREEN}BEGIN | $fileName | $startTime${NOC}"
    #Prase the given list
    parseFileList
    echo "File List Parsed : $line"
    allLogging "::::File List Parsed : $line"
    echo "Starting Copy process for $filename"
    fmonCopy "$line"
#    echo "Creating directories ${AIPDESTDIR}${PARENT}work/{exceptions,unknown,imported,xls2csv,ctl,DONOTRUN}"
    mkdir -p "${AIPDESTDIR}${PARENT}"work/{exceptions,unknown,imported,xls2csv,ctl,donotuse}
    #chgrp aipgrp -R "${AIPDESTDIR}${PARENT}"work 
    #checkLocalActions
    #Checks for FILE TYPE Flag.
    echo "Checking File Type"
    fileExtn="${filename##*.}"
    echo "File Extension is: $fileExtn"
    case $fileExtn in
        xls|XLS|xlsx|XLSX) processXls $file ;;
	*) processDataFile $file ;;
    esac
    endTime=`date "+%F %T "`
    echo -e "${GREEN}END | $fileName | $endTime${NOC}"
    #aip_dmfilelist_log
fi
#} 2>&1 | tee -a $LOGDIR/${filename}${FMONID}.log
#done 

##############################################################
#After completing these processes.Check for local action file 
#in client directory and perform local action
##############################################################
echo "Calling Local Actions script"
checkLocalActions