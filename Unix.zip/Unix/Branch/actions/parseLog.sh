#!/bin/bash

#@Author:Aadesh Neupane
##Get the log file using start and end time
##awk -F'|' '"2014-09-02 01:00:00" < $2 && $2 <= "2014-09-02 02:00:00"' fmon_i81167\:log
#Takes this log file by default if no log file is passed
logFileName="/data1/AIP/logs/fmon_fmon:log"

function getStatsTotal()
{   
    if [ -z "$CLIENTID" ]; then	
	movRet=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -F'|' '/Moved/ {print $0}')
	copiedCnt=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -F'|' '/CPSUCCESS/ {print $0}'| wc -l)
	notCopiedCnt=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -F'|' '/HVNM/ {print $0}' | wc -l)
	clientName=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -F'|' '/hash value/ {print $9}' | awk -F'/' '{print $4}' | sort | uniq)
	dmlistArg=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -F'|' '/File List Parsed/ {print $0}')
    else
	movRet=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -v cid="$CLIENTID" -F'|' '/Moved/ {if($7==cid)print $0}')
	copiedCnt=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -v cid="$CLIENTID" -F'|' '/CPSUCCESS/ {if($7==cid)print $0}'| wc -l)
	notCopiedCnt=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -v cid="$CLIENTID" -F'|' '/HVNM/ {if($7==cid)print $0}' | wc -l)
	clientName=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -v cid="$CLIENTID" -F'|' '/hash value/ {if($7==cid)print $9}'| awk -F'/' '{print $4}' | sort | uniq)
	dmlistArg=$(awk -F'|' -v stime="$STIME" -v etime="$ETIME" 'stime < $2 && $2 <= etime' "$logFileName" | awk -v cid="$CLIENTID" -F'|' '/File List Parsed/ {if($7==cid)print $0}')
    fi
    clientId=$(echo "$clientName" | awk -F'-' '{print $1}' | sed 's/[[:space:]]//g')
    #detailLogname=`echo $STIME| sed -e 's/[[:space:]]//g' -e 's/://g' -e 's/-//g'`
    detailLogname="Inventory_${clientId}"
    #echo "$clientId"
    local IFS=$'\n'
    fullpath=($(echo "$dmlistArg" | awk -F'|' '{print $9}'| awk -F":" '{printf "/eiger%s\n",$6}' | sed -e 's/[[:space:]]//1'))
    dmfileid=($(echo "$dmlistArg" | awk -F'|' '{print $11}'))
    filedate=($(echo "$dmlistArg" | awk -F'|' '{print $13}'))
    filesize=($(echo "$dmlistArg" | awk -F'|' '{print $14}'))
    k=0
    {
    echo "Detailed Report for $clientName"
    echo "DM Fileid,Fullpath,Filename,File Date,File Size,File Status,Record Count"
    for z in "${fullpath[@]}"
    do
	filename=$(echo "${fullpath[$k]}" | awk -F'/' '{print $NF}')
	fileStatus=$(echo "$movRet" | grep "$filename ${dmfileid[$k]}" | awk -F'|' '{print $9}' | awk -F'.' '{print $1}' | awk -F'/' '{print $2}' | awk '{print $1}')
        nolines=$(echo "$movRet" |grep "$filename ${dmfileid[$k]}"|awk -F'|' '{print $10}' | sed -e 's/[[:space:]]//1')
	#echo $fileStatus
	case $fileStatus in
            'ctl') fileStatus='CONTROL TOTAL';;
	    'imported') fileStatus="IMPORTED";;
	    'unknown') fileStatus="UNKNOWN";;
	    'exceptions') fileStatus="EXCEPTIONS";;
	    'xls2csv') fileStatus="XLS";;
	esac
	echo "${dmfileid[$k]},${fullpath[$k]},$filename,${filedate[$k]},${filesize[$k]},$fileStatus,$nolines"
	((k=k+1))
    done  } > "/data1/AIP/temp/$detailLogname.xlsx"
    java -jar /data1/AIP/actions/InventoryReport.jar /data1/AIP/temp/$detailLogname.xlsx
    #echo "$fullpath $dmfileid $filedate $filesize"
    ((cntTot=copiedCnt+notCopiedCnt))
    #echo "Total Files: $cntTot"
    cntImp=$(echo "$movRet" | awk -F'|' '/imported/ {print $9}' | wc -l)
    cntUnk=$(echo "$movRet" | awk -F'|' '/unknown/ {print $9}' | wc -l)
    cntCtl=$(echo "$movRet" | awk -F'|' '/ctl/ {print $9}' | wc -l)
    cntExp=$(echo "$movRet" | awk -F'|' '/exceptions/ {print $9}' | wc -l)
    cntXls=$(echo "$movRet" | awk -F'|' '/xls2csv/ {print $9}'| wc -l)
    echo "$cntTot;$cntImp;$cntUnk;$cntCtl;$cntExp;$cntXls;$notCopiedCnt;$clientName"
    #echo "Imported: $cntImp" 
    #echo "Unknown: $cntUnk" 
    #echo "Control: $cntCtl" 
    #echo "Exception: $cntExp"
    #echo "Excel Files : $cntXls"
    #echo "Unprocessed Files: $notCopiedCnt"
    #echo "$clientName"
    #cntExl=$(
}


function USAGES(){
    echo "./parseLog.sh -s{start time} -e{end time} [-c Client id]"
    echo './parseLog.sh -s "2014-09-01 01:00:00" -e "2014-09-01 01:00:00" '
    echo './parseLog.sh -s "2014-09-01 01:00:00" -e "2014-09-01 01:00:00" -c "759" '
}

if [ $# -lt 3 ]; then
    USAGES
    exit 0
fi

while getopts ':l:s:e:c:' opts
do
    case $opts in
	l) logFileName="$OPTARG";;
	s) STIME="$OPTARG";;
	e) ETIME="$OPTARG";;
	c) CLIENTID="$OPTARG";;
	*) USAGES;;
    esac
done

getStatsTotal
#echo $STIME $ETIME $CLIENTID