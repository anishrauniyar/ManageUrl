#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: Script to execute Pre Cleanup Before Transfer in HI_T schema

source /data1/AIP/conf/main.conf

USAGE="
Utility to Cleanup HI_T Schema before Monthly Transfer
It truncate all the AI to HI configured tables for a client

Usage: runTransferPreCleanup.sh  -c <Clientid> -s <hiservername> -h <hischema> -u <username optional>
sh runTransferPreCleanup.sh  -c 100 -s nvscrubp3 -h HI0100001_T -u Aip
"
if [ $# -lt 8 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi

while getopts ":c:s:h:u" options
do
        case $options in
        "c")
        clientId="$OPTARG"
        ;;             
        "s")
        server="$OPTARG"
	;;
        "h")
        hischema="$OPTARG"
        ;;
        "u")
        username="$OPTARG"
        ;;
        ":")
        echo "No argument value for option $OPTARG"
        echo "$USAGE"
        exit;;
        *)
        echo "$USAGE"
        exit;;
        esac
done

SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
## Atributes used by oracle
echo $hischema
echo $server
echo $username

sqlBase="$BASEDIR/sql/"
#Check of the script exists.Else termnilate
sqlFullPath=${sqlBase}sp_aip_pretransfer_cleanup.sql

if [ ! -f "$sqlFullPath" ]
then
    INFO14="INFO15: Oracle Procedure not found for transfer not found"
    echo "$INFO15"
    exit 1
fi

echo $sqlFullPath

sqlexe="sp_aip_pretransfer_cleanup('"$clientId"','"$hischema"','"$server"','"$username"')"
echo $sqlexe
sqlplus -S "$hischema/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$server)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
@$sqlFullPath;
EXEC $sqlexe;
EXIT;
EOF

