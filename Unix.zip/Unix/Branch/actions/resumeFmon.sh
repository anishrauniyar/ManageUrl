#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: This is action script for resume 
##Algorithm
##When ever starting a new fmon process. Always check previous fmon was successful or not.
##That can be checked if previous filelist was empty or not

source /data1/AIP/conf/main.conf

sed -i '1d' $TMPDIR/resume/dmfile.$FMONID.flist.$FILETAG