 #!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description:Script that will get file level information from FLMS

source /data1/AIP/conf/main.conf

USAGE="
Usage: getFileId <filename>
       Examples
	 getFileId '/data1/Clients2/785\ -\ Western\ Health\ Advantage/data/201404/WORK/IMPORTED/pi_pharmacy_claims_file.txt'
"
#Output : FLID|1|166|759|DARDEN|CLAIMS|TAB|1|N|19720
#Output Description : FLID|FILE_TYPE|LAYOUT_ID|CLIENT_ID|EMP_GROUP|DATA_TYPE|DELIMENITOR|SKIP_ROW|IGNORE_CHECK|FILE_ID
if [ $# -lt 1 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi
#fileName="$1"
FULLNAME="$1"
if [ -z $CLID ];then 
    CLIENTID=$(echo "$FULLNAME" | awk -F'/' '{print $4}'| awk -F'-' '{print $1}'| sed -e 's/\\//' -e 's/[[:space:]]//')
else
    CLIENTID="$CLID"
fi
FILENAME=$(echo "$FULLNAME" | awk -F'/' '{print $NF}' | sed -e "s:':'':g")
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
sql="SELECT
A.FLID||'|'||seq_imp_main_log_testdmid.NEXTVAL||'|'||overrideParameter FROM (
SELECT 'FLID'||'|'||CASE WHEN FILETYPE='DATAFILE' THEN 1 WHEN FILETYPE='DONOTUSE' THEN 3 ELSE 2 END ||'|'||LAYOUTID||'|'||'"$CLIENTID"'||'|'||EMPLOYERGROUP||'|'
||DATATYPE||'|'||LAYOUTTYPEID||'|'||SKIPROW||'|'||IGNOREEXCEPTION||'|'||MANUALFLAG AS FLID,OverrideParameter||'|'||overriddendate||'|'||SN AS overrideParameter
FROM (
SELECT  A.CLIENTID,
        A.PATTERN,
        A.LAYOUTID,
        A.EMPLOYERGROUP,
        A.IGNOREEXCEPTION,
        B.PAYOR,
        UPPER(B.DATATYPE) DATATYPE,
        B.PUCHCHARFLAG,
        NVL(A.LAYOUTTYPEID,C.LAYOUTTYPEID) AS LAYOUTTYPEID,
        B.SKIPROW ,
        B.MANUALFLAG,
        A.FILETYPE,
        NVL(B.TRAILERSKIP,'0') TRAILERSKIP,
        A.SN,
        CASE
         WHEN A.isoverridden IS NULL
               THEN null
         WHEN A.isoverridden ='Y' THEN A.SN
        END   
        AS OverrideParameter ,
        A.overriddendate
         FROM
                (SELECT A.CLIENTID,
                        A.PATTERN,
                        A.LAYOUTID,
                        A.EMPLOYERGROUP,
                        NVL(A.IGNOREEXCEPTION,'N') AS IGNOREEXCEPTION,
                        B.LAYOUTTYPEID,
                        case when a.layoutid='3' then 'DONOTUSE' ELSE NVL(A.FILETYPE,'DATAFILE') END  AS FILETYPE,
                        A.SN,
                        A.isoverridden,
                        A.overriddendate         FROM   IMP_CLIENTPATTERNS A
                LEFT JOIN  TBL_FILEPATTERNS_LAYOUT B ON UPPER(A.DELIMITER)=UPPER(B.LAYOUTTYPE)
                        WHERE  CLIENTID = '"$CLIENTID"'
                        AND aip_file_match('"$FILENAME"', PATTERN)=1) A
                        LEFT JOIN IMP_LAYOUTS B
                                ON A.LAYOUTID = B.LAYOUTID
                        LEFT JOIN
                        (SELECT A.LAYOUTID,B.LAYOUTTYPEID FROM (SELECT LAYOUTID,MAX(LAYOUTTYPE) AS LAYOUTTYPE FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID) A LEFT JOIN
                          TBL_FILEPATTERNS_LAYOUT B ON UPPER(A.LAYOUTTYPE)=UPPER(B.LAYOUTTYPE)) C
                                ON A.LAYOUTID = C.LAYOUTID where b.layout_status='FINALIZED'
               UNION ALL
SELECT  A.CLIENTID,
        A.CTL_PATTERN,
        A.CTL_LAYOUTID,
        NULL EMPLOYERGROUP,
        NULL IGNOREEXCEPTION,
        B.PAYOR,
        UPPER(B.DATATYPE) DATATYPE,
        B.PUCHCHARFLAG,
        NULL  AS LAYOUTTYPEID,
        B.SKIPROW ,
        B.MANUALFLAG,
        C.SUBLAYOUTDESC,
        NVL(B.TRAILERSKIP,'0') TRAILERSKIP,
        A.SN,
CASE
         WHEN A.isoverridden IS NULL
               THEN null
         WHEN A.isoverridden ='Y' THEN A.SN
        END   
        AS OverrideParameter,
        A.overriddendate
FROM      IMP_CLIENTPATTERNS A
LEFT JOIN IMP_LAYOUTS B
  ON A.CTL_LAYOUTID=B.LAYOUTID
LEFT JOIN IMP_SUB_LAYOUTS c
  ON B.LAYOUTID=c.LAYOUTID
WHERE CLIENTID = '"$CLIENTID"'
AND aip_file_match('"$FILENAME"', CTL_PATTERN)=1 and b.layout_status='FINALIZED'
)
WHERE ROWNUM <2
UNION ALL
SELECT  'FLID|0|0|'||'"$CLIENTID"'||'|UNKN|UNKN|||N|N',NULL OVERRIDEPARAMETER FROM DUAL
)A WHERE ROWNUM <2
"
#echo "$sql"
##sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))"
#sqlplus -S importdb/oracle <<EOF

sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
SET DEFINE OFF;
$sql;
SET DEFINE ON;
EOF
exit
EOF
			
