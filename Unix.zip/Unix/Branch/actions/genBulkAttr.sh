#!/bin/bash
#Author:Aadesh Neuapne


#Get uniques layoutid from the oracle database 
sqlReturn="SELECT distinct layoutid  as layoutid FROM  imp_sub_layouts where  sublayoutdesc ='DATAFILE'"
OUTPUT=($(sqlplus -S "IMPORTDB/oracle @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=1521))(CONNECT_DATA=(SID=d2he)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
$sqlReturn;
EXIT;
EOF
))

#echo "${OUTPUT[0]}"
#test=( 1 2 3 4 5 6 7 8 9 10)
#for i in ${test[@]}
#do
i=147
    java -jar /data1/AIP/datadashboard/utilities/attr.jar $i > /data1/AIP/attr1/${i}.attr
#    echo `date "+%F %T"`
#done
