#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: This script is called from dashboard to import files from AIPFM

source /data1/AIP/conf/aipfm.conf
source /data1/AIP/conf/rlog.sh

SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
FILETAG="aipfm"

USAGES="./processAIPFM.sh -s <full file path>
        ./processAIPFM.sh -l <filelist>
"

#Insert the cron info into the table AIP_CRON_LOG
function aip_cron_log()
{	
    CLIENTID=$(echo "$CLIENTID" | sed -e "s/'//g")
    ECTIME=`date "+%F %T"`
    FMONTAG="${FILETAG}_${USER}_${HOSTNAME}"
    if [[ ${#USER} = 0 ]]; then 
	USER="service"
    fi
    if [[ $1 == "EARLY_EXIT" ]];then
	query="INSERT INTO aip_cron_log(fmonid,start_time,end_time,machine,executed_by,dmfile_list,client_id,info1,info2,info3,info4,info5,info6,info17,cronstarttime,cronendtime,fmontag) VALUES('"${FMONID}"', '"$STIME"', '"$ETIME"', '"$HOSTNAME"' ,'"$USER"', '"${TMPDIR}/dmfile.${FMONID}.flist.$FILETAG"' ,'"$CLIENTID"' ,'"$INFO1"','"$INFO2"','"$INFO3"','"${INFO4}"','"${INFO5}"','"${INFO6}"','"${INFO17}"','"$SCTIME"','"$ECTIME"','"$FMONTAG"')"
    else
	query="INSERT INTO aip_cron_log(fmonid,start_time,end_time,machine,executed_by,dmfile_list,client_id,info1,info2,info3,info4,info5,info6,info17,cronstarttime,cronendtime,fmontag) VALUES('"${FMONID}"', '"$STIME"', '"$ETIME"', '"$HOSTNAME"' ,'"$USER"', '"${TMPDIR}/dmfile.${FMONID}.flist.$FILETAG"' ,'"$CLIENTID"' ,'"$INFO1"','"$INFO2"','"$INFO3"','"${INFO4}"','"${INFO5}"','"${INFO6}"','"${INFO17}"','"$SCTIME"','','"$FMONTAG"')"
    fi
#echo $query
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
$query;
commit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#Functions update the cron_log end_time and info17
function update_cron_log()
{
query="UPDATE aip_cron_log set cronendtime='"$1"',info17='"$2"',info4='"$3"',info5='"$4"' where fmonid='"$FMONID"'"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
$query;
commit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

#
function insert_dmfilelist()
{
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
SET DEFINE OFF;
$appendquery
$appendsn
SET DEFINE ON; 
commit;
EOF
else
echo "DRYRUN Flag set as TRUE"
fi
}

############################################################################
################################Database Function End  #####################
############################################################################

#Function that checks oracle connection
function checkOracleConn()
{
#Define oracleHealth status as 2 at first
oracleHealth=2
sqlReturn="SELECT 1 AS ORCLEHEALTH FROM dual"
oracleHealth=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
$sqlReturn;
EXIT;
EOF
)
#echo "$oracleHealth from check oracle function"
oracleHealth=$(echo "$oracleHealth" | sed -e 's/[[:space:]]//g' -e 's/[[:blank:]]//g')
#oracleHealth=2
}

#Check svn server status
function svnStatusCheck()
{
    svn_user="datadashboard"
    svn_pass="innovation"
    svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/"
    svnstatus=$(svn info --username $svn_user --password $svn_pass $svn_url | grep "Revision")
    if [ -z "$svnstatus" ]; then
	echo "ERROR : SVN system down"
	exit 1
    else
        echo "SVN server link ok"
    fi
}

#Check /eiger mount point
function checkMountPoint()
{
    echo "Mount point"
    if mount | grep "10.48.6.226:/data1 on /eiger" > /dev/null ; then
	echo "/eiger is mounted "
    else
	echo "Error : /eiger not mounted"
	exit 1
    fi
}

###################################################################################################################################
###################################################################################################################################
###################################################Function to check Servers ends#################################################
###################################################################################################################################

function uncompressFile()
{
    #Decompress the file given by the first parameter
    #echo "uncompress $1"
    filetypecheck=$(file "$1" | grep "gzip compressed data")
    if [[ ${#filetypecheck} != 0 ]] ; then
	gzip -d "$1"
    else
	echo "File Compression FALSE"
    fi
}


function gen_dmfileid()
{
    query="select seq_aip_manualimport_dmfileid.NEXTVAL from dual"
dmfileid=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
SET DEFINE OFF;
$query;
SET DEFINE ON;
EOF
exit;
)
}

#function buildQuerySn()
#{
#    querysn=
#}

function genListManualRoute()
{
    FILETAG='AIPFM'
    #Function generates file list manually by using find for the specific folder
    ##LISTGENMANUALDB=TRUE
    if [[ $LISTGENMANUALDB == 'TRUE' ]];then
	#Call our AIP db for list
	echo "AIP DM called to get the list"
    else
	#find "$SCANDIR" -type f > $TMPDIR/dmfile.$FMONID.flist
	#head -n 5 $TMPDIR/dmfile.$FMONID.flist
	local IFS=$'\n'
	appendquery="INSERT ALL  "
	#appendsn="UPDATE imp_filemanager SET dmfileid='"$dmfileid"' WHERE sn='"$sn"'
	INFO6=''
	#echo "${FILELIST[@]}"
	for a in "${FILELIST[@]}"
	do
	    echo "$a"
	    sn=$(echo "$a" | awk -F'|' '{print $2}')
	    clientid=$(echo "$a" | awk -F'|' '{print $3}')
	    a=$(echo "$a" | awk -F'|' '{print $1}')
	    if [ -f "$a" ] ;then
		uncompressFile "$a"
		echo "File $a found"
		a=$(echo "$a" | sed 's:.gz$::g')
		filepath=$(echo "$a" | sed "s:$AIPCLIENTDIR::g")
                modfilepath=$(echo "$a" | sed "s:$AIPCLIENTDIR::g" | sed "s:':'':g")
                #clientid=$(echo "$filepath" | awk -F'/' '{print $3}' | awk -F'-' '{sub("[[:space:]]","",$0);printf "%s",$1}')
                filename=$(echo "$filepath" | awk -F'/' '{print $NF}')
                modfilename=$(echo "$filepath" | awk -F'/' '{print $NF}' | sed "s:':'':g")
		gen_dmfileid
		dmfileid=$(echo "$dmfileid" | awk '{sub("[[:space:]]","",$0);printf "A%d",$0}')
		hashvalue=$(md5sum "$a" | awk '{print $1}')
		filedate=$(stat -c %y "$a" | awk '{print $1,substr($2,0,8)}')
		filesize=$(ls -lt "$a" | awk '{print $5}')
		echo "$filepath|$clientid|$dmfileid|$hashvalue|$filedate|$filesize" >> "$TMPDIR/dmfile.$FMONID.flist.$FILETAG"
		appendquery+=" INTO imp_dmfilelist(clientid, fileid, destpath, filename, checksum, receiveddate, filesize, filedate, starttime, endtime, clientlist, dmfilename, fmonid) VALUES('"$clientid"','"$dmfileid"','"$modfilepath"','"$modfilename"','"$hashvalue"','"$filedate"','"$filesize"','','"$STIME"','"$ETIME"','"$clientid"','"$TMPDIR/dmfile.$FMONID.flist.$FILETAG"','"$FMONID"')  
"
		appendsn+="UPDATE imp_filemanager SET dmfileid='"$dmfileid"' WHERE sn='"$sn"';
"
	    else
		INFO6+="File not found. May be file upload was not successful for file $a
"
		echo "File not found. May be file upload was not successful for file $a"
	    fi
	done
	appendquery+="  SELECT 1 FROM DUAL;"
	#echo "$appendquery"
	#exit
	insert_dmfilelist
	export listGenerate
	if [ -f "$TMPDIR/dmfile.$FMONID.flist.$FILETAG" ];then
	    fileList=($(cat $TMPDIR/dmfile.$FMONID.flist.$FILETAG))
        fi
	#echo "${fileList[@]}"
    fi
}

###### Building action list ####################
function buildActionList()
{
    OLDIFS="$IFS"
    IFS=$'\n'
    actionList=($(awk -F':' '/^ACTION/ {print $2}' "${ACTIONDIR}/${ACTIONSLIST}"))
    IFS="$OLDIFS"
}

function parseString()
{
    local IFS='++'
    FILELIST=($(echo "$fileliststring"))
    #SN=($(echo "$fileliststring" | awk -F'|' '{print $2}'))
}

function parseFileList()
{
    local IFS=$'\n'
    FILELIST=($(cat "$filelistname"))
    #SN=($(cat "$filelistname" | awk -F'|' '{print $1}'))
}

#function chk4CompressedFiles()
#{
#    result=$(file "$1")
#    if [[ "$result" =~ 'gzip compressed data' ]]; then
#	gzip -d "$1"
#	filename=$(echo "$filename" | sed 's:.gz$::g')
#    fi
#}
 
main()
{
##Main Process Start for AIPFM
export FMONID=`date +%Y%m%d%H%M%S%N`
SCTIME=`date "+%Y%m%d %H:%M:%S"`
STIME="$SCTIME"
INFO1="Manually Started FMON Process $FMONID by AIPFM"
echo $INFO1
#Check oracle server status and eiger mount point
checkMountPoint
checkOracleConn
if [[ "$oracleHealth" == "1" ]]; then
    echo "Oralce Connection Successful"
else
    echo "Oracle Connection Unsuccessful.exiting"
    exit 1
fi

if [[ ${#FILELIST[@]} != 0 ]] ;then
    OLDIFS="$IFS"
    IFS=$'\n'
    genListManualRoute
    INFO2="File List found with ${#fileList[@]} records. Starting FMON Process"
    echo $INFO2
    #exit
    #Check config file for default actions folder
    if [[ ${#CUSTACTIONDIR} != 0 ]]
    then
	ACTIONDIR="$CUSTACTIONDIR" 
    else
        ACTIONDIR="$DEFAULTACTIONDIR"
    fi

#Load Global Actions File
    buildActionList
    if [[ -z "${actionList[@]}" ]]
	then
		#echo "Action List not found. Exiting" 2>&1 | tee -a $LOGDIR/fmon.lopg
	INFO3="Action list not found"
	echo "$INFO3"
	allLogging "::::$INFO3"
	INFO17="FMON Process ended with no action files"
	ECTIME=`date "+%F %T"`
	if [[ $resumeMode == "False" ]]; then
            aip_cron_log "EARLY_EXIT"
	fi
	exit 1
	else
		#echo "Action List created." 2>&1 | tee -a $LOGDIR/fmon.log
	INFO3="Action list found"
	echo "$INFO3"
        allLogging "::::$INFO3"
    fi
    #echo ${actionList[@]}
    CLIENTID=$( echo "${fileList[@]}" | awk -F"|" '{clientid[$2]++} END{for(i in clientid){printf "%s,",i}}' | sed 's:,$::g')
    aip_cron_log
    fmonIdLogDir="${LOGDIR}/$FMONID"
    #"$fmonIdLogDir/${fileName}.${FMONID}.log"
    mkdir -p $fmonIdLogDir
    export FILETAG
    for line in ${fileList[@]}
    do
	echo '---------------------------------------------------------------------'
	echo "$line"
	fname=`echo "$line" |  awk -F"|" '{print $1}'`
	clientid=`echo "$line" |  awk -F"|" '{print $2}'`
	export fileName=`echo "$fname" |  awk -F"/" '{print $NF}'`
	for actions in "${actionList[@]}"
	do
	#Run each actions for the file
	INFO4="BEGIN | $actions | `date "+%F %T"`"
        echo "$INFO4" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	allLogging "::::$INFO4"
	#sem -j4 --id 'AIP' -q "$ACTIONDIR/$actions" "$file"
	#echo "$file"
	#echo "$ACTIONDIR/$actions $line"
	"$ACTIONDIR/$actions" "$line" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	INFO5="END | $actions | `date "+%F %T"`"
        echo "$INFO5" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	allLogging "::::$INFO5"
	done
	#sem -j4 --id "$FMONID" -q "$DEFAULTACTIONDIR/processFiles.sh" -m "$line"
	#$DEFAULTACTIONDIR/processFiles.sh -m "$DASHBOARDLINE"
	echo '---------------------------------------------------------------------'
	echo ''
    done 
    #>> "$fmonIdLogDir/detaillog${FMONID}.log"
    #sem --wait --id "$FMONID"
else
    echo "Filelist Empty"
fi

INFO17="FMON Process ended $FMONID Successfully"
echo "$INFO17"
allLogging "::::$INFO17"
ECTIME=`date "+%F %T"`
#update cron log
update_cron_log "$ECTIME" "$INFO17" "$INFO4" "$INFO5"
}


if [ $# -lt 2 ]
then
    echo $USAGES
    exit
fi

while getopts ":s:l:?:" options
do
    case $options in
        "s") fileliststring="$OPTARG";parseString ;;
        "l") filelistname="$OPTARG";parseFileList ;;
        "?") echo $USAGES;exit ;;
    esac
done

#call main function
main "$@"
