#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: This is action script for resume 
##Resume tool for fmon
##Stand alone version

source /data1/AIP/conf/main.conf

##Algorithm
##Read the  given file list
##Extract FMONID 
##Use FMONID and populate the database
##Start fmon

USAGES="./resumeTool.sh -f <filelist>"

if [[ $# -lt 1 ]];then
    echo "$USAGES"
    exit
fi

while getopts "f:h" options
do
    case $options
	in
	f)fileListFullPath="$OPTARG"
	  filelistname=$(echo "$fileListFullPath" | awk -F'/' '{print $NF}');;
	h) echo "$USAGES";exit;;
    esac
done

#Function that updates resume field UPDATE AIP_CRON_LOG set info1=info1||' testing' where fmonid='20141013213013'
function update_cron_log_resume()
{
resumetext=$(date "+%F %T")
SPASSWORD=$(${FMONCONFDIR}/crypto -z "$PASSWORD")
query="UPDATE AIP_CRON_LOG set resume_status=resume_status||'Resumed at "$resumetext",' where fmonid='"$FMONID"'"
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >/dev/null
$query;
commit;
EOF
nnnnnnelse
 echo "DRYRUN Flag set as TRUE"
fi
}

###### Building action list ####################
function buildActionList()
{
    ACTIONDIR="$DEFAULTACTIONDIR"
    OLDIFS="$IFS"
    local IFS=$'\n'
    if [ -f "${ACTIONDIR}/ACTIONSLIST" ] ;then
	actionList=($(awk -F':' '/^ACTION/ {print $2}' "${ACTIONDIR}/ACTIONSLIST"))
    else
	echo "Action list not found"
    fi
}


function checkFileList()
{

    if [ ! -f "$fileListFullPath" ];then
	echo "File list not found"
    else
	local IFS=$'\n'
	fileList=($(cat "$fileListFullPath"))
	echo "Found ${#fileList[@]} files from that file list"
	filelistErr=`echo ${fileList[@]} | sed -n -e '/ERROR\|unknown/p'`
	if [[ ${#filelistErr} == 0 ]]; then
	    if [ -f "$TMPDIR/$filelistname" ];then
		echo "Taking backup of original filelist"
		cp "$TMPDIR/$filelistname" "${TMPDIR}/${filelistname}.bak"
	    else
		echo "Original File list not found"
	    fi
	    cp -f "$fileListFullPath" "$TMPDIR"
	    return 0
	else
	    echo "Invalid File list"
	    return 1
	fi
    fi    
}

#echo "$fileListFullPath"
#echo "$filelistname"

export FMONID=$(echo "$filelistname" | awk -F'.' '{print $2}')
export FILETAG=$(echo "$filelistname" | awk -F'.' '{print $NF}')
fmonIdLogDir="$LOGDIR/$FMONID"

if [[ $FILETAG == "AIPFM" ]]; then
    listGenerate="MANUAL"
    SCANDIR="/data1/AIPFM/Clients"
    AIPCLIENTDIR="/data1/AIPFM"
    
fi

if [[ ${#FMONID} == '0' ]] || [[ ${#FILETAG} == '0' ]]; then
    echo "Invalid file list. FMONID or FILETAG not present"
    echo "File List should be in following format dmfile.20150325050321174468507.flist.AIPFM"
else
    OLDIFS="$IFS"
    IFS=$'\n'
    checkFileList
    if [ $? -eq 0 ]; then
	buildActionList
	mkdir -p "$fmonIdLogDir"
	update_cron_log_resume
	for file in "${fileList[@]}"
	do
	    fname=`echo "$file" |  awk -F"|" '{print $1}'`
	    clientid=`echo "$file" |  awk -F"|" '{print $2}'`
	    export fileName=`echo "$fname" |  awk -F"/" '{print $NF}'`
	    for actions in "${actionList[@]}"
	    do
		#Run each actions for the file
		INFO4="BEGIN | $actions | `date "+%F %T"`"
		echo "$INFO4" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
		#sem -j4 --id 'AIP' -q "$ACTIONDIR/$actions" "$file"
		#echo "$ACTIONDIR/$actions $file"
		"$ACTIONDIR/$actions" "$file" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
		INFO5="END | $actions | `date "+%F %T"`"
		echo "$INFO5" 2>&1 | tee -a "$fmonIdLogDir/${fileName}.${FMONID}.log.${clientid}"
	    done
	    echo "---------------------------------------------------------------------------------------------------------------------------------------------- "
	done
    fi
fi
