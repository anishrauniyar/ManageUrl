#!/bin/bash
# @author: Aadesh Neupane
USAGES="./importCtl.sh -f FILENAME -a ATTRIBUTE"


#DEBUGPRT=1
let "controlidentcnt = 0"
let "conditioncnt = 0"

declare -a vhcatcommand=()

declare -A DELIMETERS=(
 [TILD]='~'
 [FIXED]='\n'
 [PIPE]='|'
 [COMA]=','
 [COLN]=':'
 [TAB]='\t'
 [SCLN]=';'
 [DOLR]='$'
 [EXCL]='!'
 [CAPS]='^'
 [ATSI]='@'
 [HASH]='#'
)

declare -A PARSEFUNCS=( 
[ALLOWED_AMT]="f_generic"
[BILLED_AMT]="f_generic"
[EMPLOYEE_AMT]="f_generic"
[EMPLOYEE_CNT]="f_generic"
[FROM_DATE]="f_generic"
[MEMBER_CNT]="f_generic"
[PAID_AMT]="f_generic"
[RECORD_CNT]="f_generic"
[SOURCE_FILE]="f_generic"
[TO_DATE]="f_generic"
[CONTROLIDENT]="f_controlident"
[CONTROLCONDITION]="f_controlcondition"
)

declare -a from_date=()
declare -a to_date=()
declare -a billed_amt=()
declare -a allowed_amt=()
declare -a paid_amt=()
declare -a employee_amt=()
declare -a employee_cnt=()
declare -a member_cnt=()
declare -a record_cnt=()



dbgPRINT () { if [ "$DEBUGPRT" = "1" ]; then echo "$@"; fi }

convertDate()
{
    if [[ "$1" != '0' ]] ; then
	local tempdate=$(echo "$1" | sed 's:"::g')
	convertedate=$(/data1/AIP/actions/convdate -d "$2"  -v "$tempdate")
	if [[ $? != 0 ]]; then
	    echo "Date conversion not successful"
	    convertedate="$tempdate"
	fi
    fi
}

convertNum()
{
    convnum=$(echo "$1" | sed 's:[$,]::g' | sed 's:"::g' | awk 'BEGIN{
	arr["{"]=0;arr["A"]=1;arr["B"]=2;arr["C"]=3;arr["D"]=4;arr["E"]=5;arr["F"]=6;arr["G"]=7;arr["H"]=8;arr["I"]=9;arr["}"]=0;arr["J"]=-1;arr["K"]=-2; 
	arr["L"]=-3;arr["M"]=-4;arr["N"]=-5;arr["O"]=-6;arr["P"]=-7;arr["Q"]=-8;arr["R"]=-9;sub(/^[ \t]+|[ \t]+$/,"",$0)}
	{
        colnum=$0
	if(length(colnum) == 0) print colnum;
	else if(colnum !~ "[a-zA-Z}{#]") print colnum;
	else {
		if(colnum ~ "^[0-9].*([A-Z}{])"){
			len=length(colnum);
			pchar=substr(colnum,len,1)
			j++
                        if(arr['pchar']<0)
                        {
                          colnum=colnum*-1
                          abspchar=arr['pchar']*-1
                          newcolval=colnum abspchar
                        }
                        else{
                          colnum=colnum*1
                          newcolval=colnum arr['pchar']
                        }
                        colnum=newcolval
                        print colnum
		}
		else{
                     print colnum }
	}
	}')
}


VHCAT()
{
    local cnt1=$conditioncnt
    #echo "$cnt1"
    local strand=''
    if [[ $conditioncnt == '0' ]];then
	eval VHCAT1
    else

	#echo "$str2"
	#echo "${vhcatcommand[2]}"
	#echo "${vhcatcommand[1]}"
	if [[ ${recordcond[0]} == "AND" ]]; then
	    while [[ $cnt1 -ge 1 ]]; do
		strand+=' | eval ${vhcatcommand['$cnt1']}'
		((cnt1=cnt1-1))
	    done
	    #eval VHCAT1 | eval "${vhcatcommand[1]}"
	    eval VHCAT1 "$strand"
	    #echo  "${vhcatcommand[1]}"
	elif [[ ${recordcond[0]} == "OR" ]]; then
	    #VHCAT1
	    #echo "$str3"
	    #eval "$str3"
	    #eval "${vhcatcommand[1]} ${FILENAMES[0]}"
	    local mainstr='awk "{arr[$0]++}END{for(i in arr){print i}}" <(eval VHCAT1)'
	    while [[ $cnt1 -ge 1 ]]; do
		#local str1=$(echo "'${vhcatcommand["$cnt1"]}'" | sed -e 's:arr\[1\]:NR:g' -e 's:arr\[2\]:$0:g' -e 's:split.*BLANKS:if(pat=="BLANKS:g' -e "s:^'::g" -e "s:'$::g")
		#echo "${vhcatcommand["$cnt1"]}"
		mainstr+=" <(${vhcatcommand["$cnt1"]} "$filename")"
		((cnt1=cnt1-1))
	    done
	    mainstr=$(echo "$mainstr" | sed "s:\"{:'{:g" | sed "s:}\":}':g")
	    #echo "$mainstr"
	    eval "$mainstr"
	    #eval VHCAT1
	    #awk '{arr[$0]++}END{for(i in arr){print i}}' <(eval VHCAT1) <(eval "$str3")
	else
	   echo "INVALID control condition"
	fi
    fi

}

VHCAT1()
{
    local IFS=$'\n'
    if [[ $attrtype == 'FIXED' ]] || [[ $attrtype == 'FIXD' ]]; then
	if [[ $condition == "!=" ]]; then
	    awk -v sp="$startpos" -v w="$width" -v pat="$patt" '{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp!=""){ans=$0;print ans}}else{if(substr($0,sp,w)!=pat){ans=$0;print ans}}}' "$filename"
	else
	    awk -v sp="$startpos" -v w="$width" -v pat="$patt" '{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp==""){ans=$0;print ans}}else{if(substr($0,sp,w)==pat){ans=$0;print ans}}}' "$filename"
	fi
    else
	if [[ $condition == "!=" ]]; then
	    awk -v colno="$col" -v pat="$patt" -F"$deliValue" '{if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno!=""){ans=$0;print ans}}else{if($colno!=pat){ans=$0;print ans}}}' "$filename"
	else
	    awk -v colno="$col" -v pat="$patt" -F"$deliValue" '{if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno==""){ans=$0;print ans}}else{if($colno==pat){ans=$0;print ans}}}' "$filename"
	fi
    fi
}

vhcatstrbuild()
{
    if [[ $attrtype == 'FIXED' ]] || [[ $attrtype == 'FIXD' ]]; then
	if [[ $condition == "!=" ]]; then
	    strbuildres=$(echo 'awk -v sp="'$startpos'" -v w="'$width'" -v pat="'$patt'" "{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp!=""){ans=$0;print ans}}else{if(substr($0,sp,w)!=pat){ans=$0;print ans}}}"')
	else
	    strbuildres=$(echo 'awk -v sp="'$startpos'" -v w="'$width'" -v pat="'$patt'" "{if(pat=="BLANKS"){temp=substr($0,sp,w);gsub("[[:space:]]","",temp);if(temp==""){ans=$0;print ans}}else{if(substr($0,sp,w)==pat){ans=$0;print ans}}}"')
	fi
    else
	if [[ $condition == "!=" ]]; then
	    strbuildres=$(echo 'awk -v colno="'$col'" -v pat="'$patt'" -F"'$deliValue'" "{if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno!=""){ans=$0;print ans}}else{if($colno!=pat){ans=$0;print ans}}}"')
	else
	    strbuildres=$(echo 'awk -v colno="'$col'" -v pat="'$patt'" -F"'$deliValue'" "{if(pat=="BLANKS"){gsub("[[:space:]]","",$colno);if($colno==""){ans=$0;print ans}}else{if($colno==pat){ans=$0;print ans}}}"')
	fi
    fi
    strbuildres=$(echo "$strbuildres" | sed -e "s:\"{:'{:g" -e "s:}}\":}}':g")
    #echo "$str $recordidentcnt"
    vhcatcommand[$controlidentcnt]="$strbuildres"
}


GETARGS(){
    a1=$(echo "$1" | awk -F'|' '{print $1}')
    a2=$(echo "$1" | awk -F'|' '{print $2}')
    a3=$(echo "$1" | awk -F'|' '{print $3}')
    a4=$(echo "$1" | awk -F'|' '{print $4}')
    a5=$(echo "$1" | awk -F'|' '{print $5}')
}




f_generic()
{
    local IFS=$'\n'
    local result=($(eval VHCAT))
    cnt=0
    #echo " $cnt ${result[@]}"
    if [[ $a2 == 'FIXED' ]] || [[ $a2 == 'FIXD' ]];then
	gstartpos=`echo $a3 | awk -F',' '{print $1}'`
	gwidth=`echo $a3 | awk -F',' '{print $2}'`
	gdateFormat="$a4"
	dbgPRINT "from generic function"
	for k in ${result[@]};do
	    #echo ${k:$startPos:$width} $colname
	    #echo "$val"
	    val=`echo $k | awk -v sp="$gstartpos" -v w="$gwidth" '{a=substr($0,sp,w);sub(/^[ \t]+|[ \t]+$/,"",a);print a}'`
	    addCtlRecord $val $a1
	    ((cnt=cnt+1))
	done
    else
	gdeli1="$a2"
	gdeliValue1=${DELIMETERS[$gdeli1]}
	gcolnum="$a3"
	gdateFormat="$a4"
	for k in ${result[@]};do
		#echo $cnt
	    val=`echo $k | awk -v coln=$gcolnum -F"$gdeliValue1" '{sub(/^[ \t]+|[ \t]+$/,"",$coln);print $coln}'`	   
	        #echo "$colname $val"
	    addCtlRecord $val $a1
	    ((cnt=cnt+1))
	done
    fi

}

f_controlident()
{
    dbgPRINT "BEGIN: From Control Indent"
    dbgPRINT "$a1 $a2 $a3 $a4 $a5 $a6"
    colname="$a1"
    attrtype="$a2"
    ((controlidentcnt=controlidentcnt+1))
    if [[ $attrtype == 'FIXED' ]] || [[ $attrtype == 'FIXD' ]]
    then
	startpos=$(echo $a3 | awk -F',' '{print $1}')
	width=$(echo $a3 | awk -F',' '{print $2}')
	condition="$a4"
	patt="$a5"
	vhcatstrbuild
    else
	deli="$a2"
	deliValue=${DELIMETERS[$deli]}
	col="$a3"
	condition="$a4"
	patt="$a5"
	vhcatstrbuild
    fi
    if [[ ${#condition} = 0 ]]; then
        echo "Invalid cattrfile"
        exit 1
    fi
    #dbgPRINT "$strbuildres"
    dbgPRINT "END: From Control Indent"
}

f_controlcondition()
{
    dbgPRINT "BEGIN: From Control Condition"
    dbgPRINT "$a1 $a2 $a3 $a4 $a5 $a6"
    recordcond[$conditioncnt]="$a2"
    ((conditioncnt=conditioncnt+1))
    dbgPRINT "END: From Control Condition"
}

#f_billedamt
#f_employeeamt
#f_employeecnt
#f_fromdate
#f_membercnt
#f_paidamt
#f_recordcnt
#f_sourcefile
#f_todate

addCtlRecord()
{
    #echo $1 $2
    #ctlrecords[$2]=$1
    #((i=i+1))
    #echo $cnt
    dbgPRINT "$1 $2"
    case $2 in
	'FROM_DATE') convertDate "$1" "$gdateFormat";from_date[$cnt]="$convertedate";;
	'TO_DATE') convertDate "$1" "$gdateFormat";to_date[$cnt]="$convertedate";;
	'BILLED_AMT') convertNum "$1";billed_amt[$cnt]="$convnum";;
	'ALLOWED_AMT') convertNum "$1";allowed_amt[$cnt]="$convnum";;
	'PAID_AMT') convertNum "$1";paid_amt[$cnt]="$convnum";;
	'EMPLOYEE_AMT') convertNum "$1";employee_amt[$cnt]="$convnum";;
	'EMPLOYEE_CNT') convertNum "$1";employee_cnt[$cnt]="$convnum";;
	'MEMBER_CNT') convertNum "$1";member_cnt[$cnt]="$convnum";;
	'RECORD_CNT') convertNum "$1";record_cnt[$cnt]="$convnum";;
    esac
}

if [ $# -lt 4 ]
then
    echo $USAGES
    exit
fi

while getopts ":f:a:?:" options
do
    case $options in
	"f") filename="$OPTARG"
	    if [ ! -f "$filename" ]
		then
		echo "Invalid. Source File not found"
		exit
	    fi;;
	"a") attfname="$OPTARG"
	    if [ ! -f "$attfname" ]
	    then
		echo "Invalid. Attribute File not found"
		exit
	    fi;;
	"?") echo $USAGES;exit ;;
    esac
done


INVALID=$(awk -F'|' '/INVALID/ {print $2}' "$attfname")

if [[ ${#INVALID} != '0' ]];then
    echo "Invalid. No mapping defined"
    exit
fi

declare -a lineArray=()
o_ifs=$IFS
IFS=$'\r\n' lineArray=($(grep -v "^#" $attfname))
IFS=$o_ifs

for i in "${lineArray[@]}"
do
   tok=""
   tok=$(echo ${i} | awk -F'|' '{print $1}')
   #dbgPRINT "BEGIN: line=> ${i} ; tok=${tok}"
   #let x=x+1
   if [ $tok != "" ]
   then
   	if [ ${PARSEFUNCS[$tok]} ] 
   	then
 		GETARGS "${i}"
		${PARSEFUNCS[$tok]} "${i}"	
   	else
		echo "WARNING: Invalid directive, ignoring: ${i}"
   	fi
   fi
   #dbgPRINT "END"
done

#VHCAT1
#parseCattr
#extractContents
#echo "${from_date[0]}"
#echo ${!ctlrecords[@]}
#echo ${ctlrecords[@]}
#echo "$from_date $to_date $billed_amt $allowed_amt $paid_amt $employee_amt $employee_cnt $member_cnt $record_cnt"
for((i=0;i<cnt;i++))
do
echo "OUTPUT|${from_date[$i]}|${to_date[$i]}|${billed_amt[$i]}|${allowed_amt[$i]}|${paid_amt[$i]}|${employee_amt[$i]}|${employee_cnt[$i]}|${member_cnt[$i]}|${record_cnt[$i]}"
#echo ${from_date[$i]}
done
#echo ${ctlrecords[$i]} ${ctlrecords[$i]} ${ctlrecords[]} ${ctlrecords[ALLOWED_AMT]} ${ctlrecords[PAID_AMT]} ${ctlrecords[EMPLOYEE_AMT]} ${ctlrecords[EMPLOYEE_CNT]} ${ctlrecords[MEMBER_CNT]} ${ctlrecords[RECORD_CNT]}
