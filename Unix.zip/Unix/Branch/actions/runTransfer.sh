#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: Script to execute Transfer Script from AI to HI Tables

source /data1/AIP/conf/main.conf

USAGE="
Utility to Transfer AI data to HI based on configurations

Usage: runTransfer.sh  -c <Clientid> -f <FileList> -h <hiserver> -s <HISchema>  -i <aipimportdb server> -r <transfer sn only for retransfer>
       Examples
        runTransfer.sh -c '019' -f '22_11,23_34' -h 'nvscrubp11' -s 'HI0019001_T' -i nveigerworkq1
        runTransfer.sh -c '019' -f '22_11,23_34' -h 'nvscrubp11' -s 'HI0019001_T' -i nveigerworkq1 -r 124
"
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)

getServerPara()
{
    local server=$(echo "$server" | tr [a-z] [A-Z])
    local sql="SELECT SVR_TCP_PORT||'|'||SVR_SID FROM aip_scrub_server_master WHERE svr_name='"$server"'"
    #echo "$sql"
    output=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
SET DEFINE OFF;
$sql;
SET DEFINE ON;
exit
EOF
)
SPORT=$(echo "$output" | awk -F'|' '{print $1}'| sed 's:[[:space:]]::g')
SID=$(echo "$output" | awk -F'|' '{print $2}' | sed 's:[[:space:]]::g')
echo "Server parameters from db : $SPORT $SID" >> "$LOGDIR/transfer.log"
}

if [ $# -lt 4 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi

echo "runTransfer.sh called ----------------------------------------------------------" >> "$LOGDIR/transfer.log"

while getopts ":c:f:h:s:i:r:" options
do
        case $options in
        "c")
        clientId="$OPTARG"
        ;;
        "f")
        FileID="$OPTARG"
        ;;
        "h")
        host="$OPTARG"
        ;;
	"s")
        schema="$OPTARG"
        ;;
        "i")
        importserver="$OPTARG"
	;;
        "r")
        transferSN="$OPTARG"
        ;;
        ":")
        echo "No argument value for option $OPTARG"
        echo "$USAGE"
        exit;;
        *)
        echo "$USAGE"
        exit;;
        esac
done



## Atributes used by oracle
#schema=$schema
server=$host
#echo $schema
#echo $server
echo "-------------------------------------------------------------------------------------------------------------------------" >> "$LOGDIR/transfer.log"
echo "Passed Parameters : -c $clientId -f $FileID -h $host -s $schema -i $importserver -t $transferSN" >> "$LOGDIR/transfer.log"
sqlBase="$BASEDIR/sql"
#Check of the script exists.Else termnilate
procedurename="sp_aip_hi_transfer"
overRiddenTransferScript="${sqlBase}/${clientId}_sp_aip_hi_transfer.sql"
if [ -f ${overRiddenTransferScript} ];then
    sqlFullPath="${overRiddenTransferScript}"
    procedurename="sp_aip_hi_transfer"
else
    sqlFullPath="${sqlBase}/sp_aip_hi_transfer.sql"
    procedurename="sp_aip_hi_transfer"
fi
echo "$sqlFullPath" >> "$LOGDIR/transfer.log"
if [ ! -f "$sqlFullPath" ]
then
    INFO14="INFO15: Oracle Procedure not found for transfer not found"
    echo "$INFO15"
    #export INFO14
    #allLogging "::::$INFO14"
    exit 1
fi
echo $sqlFullPath

# Check if retransferis requested 
if [ -z "$transferSN" ]
then 
 #echo full
 sqlexe="${procedurename}('"$clientId"','"$FileID"','"$importserver"','"$schema"')"
else
echo $transferSN
 sqlexe="${procedurename}('"$clientId"','"$FileID"','"$importserver"','"$schema"','"$transferSN"')"
fi 
echo $sqlexe
echo "$sqlexe" >> "$LOGDIR/transfer.log"
getServerPara "$server"
sqlplus -S "$schema/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$server)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF >> "$LOGDIR/transfer.log"
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
@$sqlFullPath;
EXEC $sqlexe;
EXIT;
EOF

if [ $? -eq 0 ];then
exit 0
else
exit 1
fi

