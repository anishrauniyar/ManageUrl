#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description:Script that will copy or move files for FMON

source /data1/AIP/conf/main.conf
source /data1/AIP/conf/rlog.sh

#LINK='TRUE'

usage()
{
    cat << EOF
Usage: `basename $0` [-l listfile]
EOF
}


#Check correct options are given to the script.
#echo "$listGenerate"

#Check weather the file list is generated manually
function checkListgenManual()
{
    if [[ $listGenerate == "MANUAL" ]]; then
	FHASH=""
    fi
}

function checkHash()
{
    if [ "$HASH" = "$FHASH" ]; then
	if [ -n "$1" ]; then
	    LOCATION="$1"
	fi
        #$LOG -p local6.info "FMON:$(basename $0)::::File:$LOCATION matches hash value"
	INFO6="File: $LOCATION matches hash value."
	ERR1=""
        #allLogging "::::File copied successfully.CPSUCCESS"
	#echo "$INFO6"
        echo "$AIPDESTDIR/$PAR1"
	mkdir -p "$AIPDESTDIR/$PAR1"
	#/bin/cp -p "$LOCATION" "$MAINDIR/$PAR1"
	if [[ $listGenerate == "MANUAL" ]]; then
	    /bin/mv "$LOCATION" "$AIPDESTDIR/$PAR1"
	    if [ $? -ne 0 ] ; then
		INFO6="File copy was not successful."
		ERR1="Error : Copy Faliure"
		    #echo "$ERR1"
	    fi
        else
	    if [[ $LINK == "TRUE" ]] ;then
		/bin/ln -s "$LOCATION" "$AIPDESTDIR/$PAR1"
	    else
		/bin/cp -p "$LOCATION" "$AIPDESTDIR/$PAR1"
	    fi
	    #${cpaction} "$LOCATION" "$MAINDIR/$PAR1"
	    if [ $? -ne 0 ] ; then
		INFO6="File copy was not successful."
		ERR1="Error : Copy Faliure"
		    #echo "$ERR1"
	    fi
	fi
	#INFO7="File: Copied to $MAINDIR/$PAR1 location"
	#allLogging "::::$INFO7"
        #echo "$INFO7"
	#CFLAG="Y"
    else
        #$LOG -p local6.info "FMON:$(basename $0)::::FILE:$LOCATION does not match hash"
	INFO6="File: $LOCATION does not matches hash value"
        #allLogging "::::$INFO6"
		#echo "$INFO6"
	#CFLAG="N"
	ERR1="Error HVNM : Hash Value Not Match"
	#INFO7="File: Not copied to $MAINDIR/$PAR1 location"
    fi

}

function checkFileExists()
{
            #LOCATION=`find "${AIPCOPYDIR}${PAR}" -name "$FILE"`
        #echo "$LOCATION"
        #if [ -z "$LOCATION" ] ; then
        #    INFO6="ERROR : File not found."
        #    ERR1="File not found."
        #else
        #    FHASH=`md5sum "$LOCATION" | awk '{print $1}'`
        #   if [[ $listGenerate == "MANUAL" ]]; then
        #       FHASH=""
        #    fi

    if [[ $AIPCOPYTRAVERSE == "FALSE" ]] ; then
	#"${AIPCOPYDIR}${PAR}" -name "$FILE"
	LOCATION="${AIPCOPYDIR}${PAR}${FILE}"
	if [ -f "$LOCATION" ] ; then
	    echo "File Exists"
	    FHASH=`md5sum "$LOCATION" | awk '{print $1}'`
	    #checkListgenManual
	    checkHash
        else
	    INFO6="ERROR : File not found."
            ERR1="File not found."
        fi
    else
	echo "Using Find command"
	local OLDIFS="$IFS"
	IFS=$'\n'
	#find "${AIPCOPYDIR}${PAR}" -name "$FILE"
	if [[  $AIPCOPYTRAVERSEOUT == "TRUE" ]] ; then
	    PARTEMP=$(echo "$fname" | awk -F"/" 'BEGIN{i=1}{while(i<NF-1){printf "%s/",$i;i++}}')
	    LOCATION=($(find "${AIPCOPYDIR}${PARTEMP}" -name "$FILE"))
	    #PAR1=`echo "$PARTEMP" | sed -e 's:/::1'`
	else
	    LOCATION=($(find "${AIPCOPYDIR}${PAR}" -name "$FILE"))
	fi
	#echo "${#LOCATION[@]}"
	#echo "${LOCATION[0]}"
	if [[ ${#LOCATION[@]} = 0 ]] ; then
	    INFO6="ERROR : File not found."
            ERR1="File not found."
	elif [[ ${#LOCATION[@]} = 1 ]] ; then
	    FHASH=`md5sum "$LOCATION" | awk '{print $1}'`
	    #checkListgenManual
	    checkHash
	    #echo "FROM second $FHASH $LOCATION"
	else
	    for loc in ${LOCATION[@]}
	    do
		#echo "$loc"
		#md5sum "$loc" 
		#echo "$HASH"
		FHASH=`md5sum "$loc" | awk '{print $1}'`
		#echo "$FHASH $HASH"
		#checkListgenManual
		checkHash "$loc"
		if [[ $ERR1 =~ "Error" ]];then
		    continue
		else
		    break
		fi
	    done
	fi
    fi

}

#Check if arguments are given to the script if not display usage info.
if [ $# -lt 1 ]; then
    usage
    exit
fi

while getopts ":l:f:" options
do
    case $options in
        "l")
            listfile="$OPTARG"
	#while read line
	#do
	#PAR=`echo $line| awk -F"|" '{print $3}'`
	#PAR1=`echo $line| awk -F"|" '{print $3}' | sed -e "s/Clients/$CLIENTS/g" | sed -e 's:/::1'`
	#FILE=`echo $line| awk -F"|" '{print $4}'`
	#HASH=`echo $line | awk -F"|" '{print $5}'`
	#LOCATION=`find "/eiger$PAR" -name "$FILE"`
	#if [[ $listGenerate == "MANUAL" ]]; then
	#    AIPCOPYDIR=""
	#fi
	#LOCATION=`find "${AIPCOPYDIR}${PAR}" -name "$FILE"`
        #FHASH=`md5sum "$LOCATION" | awk '{print $1}'`
	#if [[ $listGenerate == "MANUAL" ]]; then
        #    FHASH=""
        #fi
	#if [ "$HASH" = "$FHASH" ]; then
	#$LOG -p local6.info "FMON:$(basename $0)::::File:$LOCATION matches hash value"
	#INFO9="File:$LOCATION matches hash value"
	##allLogging "::::$INFO9"
	#echo "File:$LOCATION matches hash value"
	#mkdir -p "$CLIENTDIR/$PAR1"
	#/bin/cp -p "$LOCATION" "$CLIENTDIR/$PAR1"
	#echo "File: Copied to $CLIENTDIR/$PAR1 location"
	#else 
	#$LOG -p local6.info "FMON:$(basename $0)::::FILE:$LOCATION does not match hash"
	#INFO9="FILE:$LOCATION does not match hash"
	##allLogging "::::$INFO9"
	#echo "FILE:$LOCATION does not match hash"
	#fi
	#done < $listfile
            ;;
	"f")
	dmfilelistrec="$OPTARG"
	#echo "$dmfilelistrec"
	fname=`echo "$dmfilelistrec" |  awk -F"|" '{print $1}'`
	PAR=`echo "$fname" | awk -F"/" 'BEGIN{i=1}{while(i<NF){printf "%s/",$i;i++}}'`
        #export PARENT="$(echo $MAINDIR$PA | sed -e "s/Clients/$CLIENTS/g")"
	FILE=`echo "$fname" |  awk -F"/" '{print $NF}'`
        HASH=`echo "$dmfilelistrec" |  awk -F"|" '{print $4}'`
	#PAR=`echo $dmfilelistrec | awk -F"|" '{print $3}'`
        #FILE=`echo $dmfilelistrec | awk -F"|" '{print $4}'`
        #HASH=`echo $dmfilelistrec | awk -F"|" '{print $5}'`
        #LOCATION=`find "/eiger$PAR" -name "$FILE"`
	if [[ $listGenerate == "MANUAL" ]]; then
            #AIPCOPYDIR="/u05"
	    AIPCOPYDIR="$AIPCLIENTDIR"
        fi
	PAR1=`echo "$PAR" | sed -e 's:/::1'`
	checkFileExists 
	#LOCATION=`find "${AIPCOPYDIR}${PAR}" -name "$FILE"`
	#echo "$LOCATION"
	#if [ -z "$LOCATION" ] ; then
	#    INFO6="ERROR : File not found."
	#    ERR1="File not found."
	#else
        #    FHASH=`md5sum "$LOCATION" | awk '{print $1}'`
	#   if [[ $listGenerate == "MANUAL" ]]; then
	#	FHASH=""
        #    fi
	#echo $PAR
	#echo $PAR1
	#echo $LOCATION
	
	echo "${INFO6}|${ERR1}"
	allLogging "::::${INFO6}|${ERR1}"
	;;
	"?")
        echo "Invalid option $OPTARG"
        exit 1
	;;
        ":")
        echo "No argument value for option $OPTARG"
        exit
	;;
        *)
        usage
        exit
	;;
    esac
done 