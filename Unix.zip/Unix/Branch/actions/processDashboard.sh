#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: This script is called from dashboard to process exception and reimport files

source /data1/AIP/conf/main.conf

USAGES="./processDashboard.sh -s filepath|layoutid|fileid|employer|processstatus
        ./processDashboard.sh -l filelist
"

function parseString()
{
    local IFS='++'
    DASHBOARDLIST=($(echo "$fileliststring"))
}

function parseFileList()
{
    local IFS=$'\n'
    DASHBOARDLIST=($(cat "$filelistname" | sed 's:"::g'))
}

if [ $# -lt 2 ]
then
    echo $USAGES
    exit
fi

while getopts ":s:l:?:" options
do
    case $options in
        "s") fileliststring=\""$OPTARG"\";parseString ;;
        "l") filelistname="$OPTARG";parseFileList ;;
        "?") echo $USAGES;exit ;;
    esac
done

if [[ ${#DASHBOARDLIST[@]} != 0 ]] ;then
    OLDIFS="$IFS"
    IFS=$'\n'
    export FMONID=`date +%Y%m%d%H%M%S%N`
    fmonIdLogDir="${LOGDIR}/$FMONID"
    echo "$FMONID"
    #"$fmonIdLogDir/${fileName}.${FMONID}.log"
    mkdir $fmonIdLogDir
    export fmonIdLogDir
    echo "${DASHBOARDLIST[@]}"
    echo "File Name passed from dashboard is : $filelistname" >> "$fmonIdLogDir/detaillog${FMONID}.log"
    for DASHBOARDLINE in ${DASHBOARDLIST[@]}
    do
	echo '---------------------------------------------------------------------'
	echo "$DASHBOARDLINE"
	sem -j4 --id "$FMONID" -q "$DEFAULTACTIONDIR/processFiles.sh" -m "$DASHBOARDLINE"
	#$DEFAULTACTIONDIR/processFiles.sh -m "$DASHBOARDLINE"
	echo '---------------------------------------------------------------------'
	echo ''
    done >> "$fmonIdLogDir/detaillog${FMONID}.log"
    sem --wait --id "$FMONID"
else
    echo "Filelist Empty"
fi

