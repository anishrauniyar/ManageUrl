#!/bin/bash
# @author: Aadesh Neupane
USAGES="./importCtlFile.sh -f FILENAME -a ATTRIBUTE"

declare -A DELIMETERS=(
 [TILD]='~'
 [FIXED]='\n'
 [FIXD]='\n'
 [PIPE]='|'
 [COMA]=','
 [COLN]=':'
 [TAB]='\t'
 [SCLN]=';'
 [DOLR]='$'
 [EXCL]='!'
 [CAPS]='^'
 [ATSI]='@'
 [HASH]='#'
 [SPAC]=' '
 [EQUL]='='
)

declare -a from_date=()
declare -a to_date=()
declare -a billed_amt=()
declare -a allowed_amt=()
declare -a paid_amt=()
declare -a employee_amt=()
declare -a employee_cnt=()
declare -a member_cnt=()
declare -a record_cnt=()
declare -a sourcefname=()

#Flag to show the output
dbgPrintFlag=0
b1=0;b2=0;b3=0;b4=0;b5=0;b6=0;b7=0;b8=0;b9=0;b10=0

if [ $# -lt 4 ]
then
    echo $USAGES
    exit
fi

function dbgPrint()
{
#1'st argument is msg to be displayed 
#2nd argument is the value of msg
#1 -> All msg (Everything)
#2 -> Timing Mode
#3 -> Degub Mode
#4 -> Normal Mode
#5 -> Production Mode

    if [ "$dbgPrintFlag" = "$2" ] ; then
	echo "$1"
    fi
}

function VHCAT()
{
    ((SKIP=SKIP+1))
    tail -n +${SKIP} "${filename}"
#    dbgPrint $'\n'"tail -n +${SKIP} "${filename}"" 3
}

function GETARGS() {
 read a1 a2 a3 a4 a5 a6 <<< $(echo "$1" | awk -F'|' '{print $1 " " $2 " " $3 " " $4 " " $5 " " $6}')
}


function convertDate()
{
    if [[ "$1" != '0' ]] ; then
	local tempdate=$(echo "$1" | sed 's:"::g')
	convertedate=$(/data1/AIP/actions/convdate -d "$2"  -v "$tempdate")
	if [[ $? != 0 ]]; then
	    #echo "Date conversion not successful"
	    convertedate="$1"
	fi
    fi
}

function convertNum()
{
    convnum=$(echo "$1" | sed 's:[$,]::g' | sed 's:"::g' | awk 'BEGIN{
	arr["{"]=0;arr["A"]=1;arr["B"]=2;arr["C"]=3;arr["D"]=4;arr["E"]=5;arr["F"]=6;arr["G"]=7;arr["H"]=8;arr["I"]=9;arr["}"]=0;arr["J"]=-1;arr["K"]=-2; 
	arr["L"]=-3;arr["M"]=-4;arr["N"]=-5;arr["O"]=-6;arr["P"]=-7;arr["Q"]=-8;arr["R"]=-9;sub(/^[ \t]+|[ \t]+$/,"",$0)}
	{
        colnum=$0
	if(length(colnum) == 0) printf "%s",colnum;
	else if(colnum !~ "[a-zA-Z}{#]") printf "%s",colnum;
	else {
		if(colnum ~ "^[0-9].*([A-Z}{])"){
			len=length(colnum);
			pchar=substr(colnum,len,1)
			j++
                        if(arr['pchar']<0)
                        {
                          colnum=colnum*-1
                          abspchar=arr['pchar']*-1
                          newcolval=colnum abspchar
                        }
                        else{
                          colnum=colnum*1
                          newcolval=colnum arr['pchar']
                        }
                        colnum=newcolval
                        printf "%s",colnum
		}
		else{
                     printf "%s",colnum }
	}
	}')

}

function addCtlRecordH()
{
    #echo $1 $2 $a5
    #ctlrecords[$2]=$1
    #((i=i+1))
    #echo $cnt
    case $2 in
        'FROM_DATE') convertDate "$1" "$a5";from_date[$b1]="$convertedate";((b1=b1+1));;
        'TO_DATE') convertDate "$1" "$a5";to_date[$b2]="$convertedate";((b2=b2+1));;
        'BILLED_AMT') convertNum "$1";billed_amt[$b3]="$convnum";((b3=b3+1));;
        'ALLOWED_AMT') convertNum "$1";allowed_amt[$b4]="$convnum";((b4=b4+1));;
        'PAID_AMT') convertNum "$1";paid_amt[$b5]="$convnum";((b5=b5+1));;
        'EMPLOYEE_AMT') convertNum "$1";employee_amt[$b6]="$convnum";((b6=b6+1));;
        'EMPLOYEE_CNT') convertNum "$1";employee_cnt[$b7]="$convnum";((b7=b7+1));;
        'MEMBER_CNT') convertNum "$1";member_cnt[$b8]="$convnum";((b8=b8+1));;
        'RECORD_CNT') convertNum "$1";record_cnt[$b9]="$convnum";((b9=b9+1));;
	'SOURCE_FILE') sourcefname[${b10}]=$1;((b10=b10+1));;
    esac
}

function addCtlRecordV()
{
#    echo $1 $2 $a4
    #ctlrecords[$2]=$1
    #((i=i+1))
    #echo $cnt
    case $2 in
        'FROM_DATE') convertDate "$1" "$a4";from_date[$cnt]="$convertedate";;
        'TO_DATE') convertDate "$1" "$a4";to_date[$cnt]="$convertedate";;
        'BILLED_AMT') convertNum "$1";billed_amt[$cnt]="$convnum";;
        'ALLOWED_AMT') convertNum "$1";allowed_amt[$cnt]="$convnum";;
        'PAID_AMT') convertNum "$1";paid_amt[$cnt]="$convnum";;
        'EMPLOYEE_AMT') convertNum "$1";employee_amt[$cnt]="$convnum";;
        'EMPLOYEE_CNT') convertNum "$1";employee_cnt[$cnt]="$convnum";;
        'MEMBER_CNT') convertNum "$1";member_cnt[$cnt]="$convnum";;
        'RECORD_CNT') convertNum "$1";record_cnt[$cnt]="$convnum";;
	'SOURCE_FILE') sourcefname[$cnt]=$1;;
    esac
}

function readCattr()
{
    if [ -f "${attfname}" ] ; then
	OIFS="$IFS"
        CONTROLIDE=$(awk -F'|' '/CONTROLIDENT/ {print $2}' "$attfname")
	SKIP=$(awk -F'|' '/SKIP/ {print $2}' "$attfname")
	TYPE=$(awk -F'|' '/TYPE/ {print $2}' "$attfname")
	INVALID=$(awk -F'|' '/INVALID/ {print $2}' "$attfname")
#	echo "$CONTROLIDE $SKIP $TYPE"
	IFS=$'\n'
	attrArray=($(grep -v "^#" "$attfname" | tail -n +5))
	#grep -v "^#" "$attfname"
#	echo "${attrArray[@]}"
	IFS="$OIFS"
	dbgPrint "Cattr file parsed" 1
    else
	dbgPrint "Cattr file not found or Invalid cattr file" 1
	dbgPrint "Error: CATTR file not found" 3
    fi
}

function parseHdata()
{
    if [[ $a3 == "FIXED" ]] || [[ $a3 == "FIXD" ]]; then
	read stpos width <<< $(echo "$a4" | awk -F',' '{print $1 " " $2}')
	#echo $stpos $width
	ctldata=$(VHCAT | sed -n "${a2}p" | awk '{a=substr($0,sp,wid);print a}' sp="${stpos}" wid="${width}" | sed -e 's/[[:space:]]//g')
	#echo $ctldata $a1
	addCtlRecordH $ctldata $a1
    else
	if [ ${DELIMETERS[$a3]} ]
	then
	    deli="${DELIMETERS[$a3]}"
	    #echo $deli $a4
	    #VHCAT | sed -n "${a2}p"
	    ctldata=$(VHCAT | sed -n "${a2}p" | awk -F"$deli" '{print $val}' val="${a4}" | sed -e 's/[[:space:]]//g')
	    #echo $ctldata $a1
	    addCtlRecordH $ctldata $a1
	else
#	    echo "elase"
	    dbgPrint "Warning: Invalid delimeters" 3
	fi
    fi
}

function processH()
{
for i in ${attrArray[@]}
do
   tok=""
   tok=$(echo ${i} | awk -F'|' '{print $1}')
   #dbgPRINT "BEGIN: line=> ${i} ; tok=${tok}"
   #let x=x+1
   if [ $tok != "" ]
   then
       GETARGS ${i}
#       echo "parseHdata	$a1 $a2 $a3 $a4 $a5"
       parseHdata
   fi
done
}

function printResH()
{
    maxCntArr=($b1 $b2 $b3 $b4 $b5 $b6 $b7 $b8 $b9 ${b10})
    maxCnt=$(printf "%d\n" ${maxCntArr[@]} | sort -nr | head -n 1)
    for((i=0;i<maxCnt;i++))
    do
	echo "OUTPUT|${from_date[$i]}|${to_date[$i]}|${billed_amt[$i]}|${allowed_amt[$i]}|${paid_amt[$i]}|${employee_amt[$i]}|${employee_cnt[$i]}|${member_cnt[$i]}|${record_cnt[$i]}|${sourcefname[$i]}"
#	echo ${from_date[$i]}
   done
}

function parseVdata()
{
    ctllinecnt="$1"
    if [[ $a2 == "FIXED" ]]; then
	read stpos width <<< $(echo "$a3" | awk -F',' '{print $1 " " $2}')
 	#echo $stpos $width
	ctldata=$(echo "${ctllinecnt}" | awk '{a=substr($0,sp,wid);print a}' sp="${stpos}" wid="${width}" | sed -e 's/[[:space:]]//g')
	#echo $ctldata $a1
	addCtlRecordV $ctldata $a1
    else
	if [ ${DELIMETERS[$a2]} ]
	then
	    deli="${DELIMETERS[$a2]}"
 	    #echo $deli $a3
	    ctldata=$(echo "${ctllinecnt}" | awk -F"$deli" '{print $val}' val="${a3}" | sed -e 's/[[:space:]]//g')
	    #echo  $ctldata $a1
	    addCtlRecordV $ctldata $a1
	else
	    dbgPrint "Warning: Invalid delimeters" 3
	fi
    fi
}

function processV()
{
    cnt=0
    OIFS="$IFS"
    IFS=$'\n'
    ctlfilecnt=($(VHCAT))
    IFS="$OIFS"
    for j in "${ctlfilecnt[@]}"
    do
	for i in ${attrArray[@]}
	do
	    tok=""
	    tok=$(echo ${i} | awk -F'|' '{print $1}')
	    if [ $tok != "" ]
	    then
		GETARGS ${i}
		parseVdata "$j"		    
	    fi
	done
	    ((cnt=cnt+1))
    done
}

function printResV()
{
    for((i=0;i<cnt;i++))
    do
	echo "OUTPUT|${from_date[$i]}|${to_date[$i]}|${billed_amt[$i]}|${allowed_amt[$i]}|${paid_amt[$i]}|${employee_amt[$i]}|${employee_cnt[$i]}|${member_cnt[$i]}|${record_cnt[$i]}|${sourcefname[$i]}"
   done
}

while getopts ":f:a:?:" options
do
    case $options in
	"f") filename="$OPTARG"
	    if [ ! -f "$filename" ]
		then
		echo "Invalid. Source File not found"
		exit
	    fi;;
	"a") attfname="$OPTARG"
	    if [ ! -f "$attfname" ]
	    then
		echo "Invalid. Attribute File not found"
		exit
	    fi;;
	"?") echo $USAGES;exit ;;	
    esac
done
readCattr

if [[ ${#INVALID} != 0 ]]; then
    dbgPrint "Invalid mapping defined" 
else
#dbgPrint "${attrArray[@]}" 1
    if [[ $TYPE == "H" ]]; then
	processH
	printResH   
    elif [[ $TYPE == "V" ]]; then
	processV
	printResV
    else
	dbgPrint "Invalid TYPE defined or Corrupt CATTR File" 1
	dbgPrint "Error: Invalid TYPE defined" 3
    fi
fi