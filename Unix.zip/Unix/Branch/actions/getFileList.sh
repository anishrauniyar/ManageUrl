#!/bin/bash
#@Author:Aadesh Neupane

source /data1/AIPTEST/conf/main.conf

function USAGES(){
echo "./getFileList.sh -s <start time> -e <end time> -f <log file>"
echo "./getFileList.sh -s '20141009 00:00:00' -e '20141010 00:00:00' -f test.log"
}

#Check Arguments 
if [ $# -lt 2 ]; then
    USAGES
    exit 0
fi

while getopts ':s:e:f:' opts
do
    case $opts in
        f) logFileName="$OPTARG";;
        s) STIME="$OPTARG";;
        e) ETIME="$OPTARG";;
        *) USAGES;;
    esac
done

if [ -z "$STIME" ]; then
    STIME=$(cat ${BASEDIR}/time/names.time)
fi

if [ -z "$ETIME" ]; then
    ETIME=$(date "+%F %T")
    echo $ETIME > ${BASEDIR}/time/names.time
fi
filename=$(date +%Y%m%d%H%M%S)
echo "./getFileNames.sh -s "$STIME" -e "$ETIME" -o localfilelist.${filename}.${logFileName}"
./getFileNames.sh -s "$STIME" -e "$ETIME" -o localfilelist.${filename}.${logFileName}
find /eiger -newerat "$STIME" -and -not -newerat "$ETIME" | grep "/data" > ${TMPDIR}/dmfilelist.${filename}.${logFileName}
echo "List Generation completed"
