#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description:Script that imports records from data file

source /data1/AIP/conf/main.conf

#source /data1/AIP/FMON/scripts/n_log.sh
USAGE="
Usage: importFile.sh  <filename> <layoutid> <file_id> <EMPLOYERID>
       Examples
	importFile.sh -f 'fullFilePath' -l '39' -i '223_999' -e 'employer' -s '1' -d '|' -o 'N' -t 'YYYYMMDD'
"
###########################################################################################
###########################################################################################
###########################################################################################
svn_pass=$($FMONCONFDIR/crypto -z $svn_pass)
if [ $# -lt 1 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi
while getopts ":f:l:e:i:s:d:o:t:" options
do
        case $options in
        "f")
        fileName="$OPTARG"
        ;;
        "l")
        LyID="$OPTARG"
        ;;
        "i")
        file_ID="$OPTARG"
        ;;
        "e")
	empid="$OPTARG"
	;;
	"s")
	skrow="$OPTARG";;
	"d")
	deli="$OPTARG";;
	"o")
	optenc="$OPTARG";;
	"t")
	dateoverride="$OPTARG";;
        #echo "Invalid option $OPTARG"
        #usage
        #exit 1;;
        ":")
        echo "No argument value for option $OPTARG"
        echo "$USAGE"
        exit;;
        *)
        echo "$USAGE"
        exit;;
        esac
done

function svnExport()
{
#svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/DataResearch/AIP/attr/268.attr"
    #svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/DataResearch/datadashboard/warfile/AIP/Utilities/ScriptsVDI/AIP/sql/IP_${LyID}.sql"
    #svn_url="https://svn.datacenter.d2hawkeye.net/svn/d2svn/DataAnalytics/DataResearch/AIP/Import_Scripts/IP_${LyID}.sql"
    svn_url="$SVNLOCATIONIS/IP_${LyID}.sql"
    #echo $svn_url
    #ATTRFULL="$LOGDIR/$FMONID/IP_${LyID}.sql"
    REVNO=$(svn info --username $svn_user --password $svn_pass $svn_url | awk -F':' '/Revision/ {print $2}' | sed 's/[[:space:]]//g')
    if [ -f "$sqlFullPath" ]; then
	echo "Import script already exits. No need to checkout from svn"
    else
        svn export --username $svn_user --password $svn_pass $svn_url --non-interactive "$sqlFullPath" > /dev/null
        #echo "Pass svn"
    fi
}

#Function to update svn revision number 
function updateLog()
{

query="UPDATE IMPORTDB.imp_main_log set importscriptname='"$REVNO"' where fileid='"$UFILEID"'"
#echo $query
#sqlplus -S importdb/oracle <<EOF
if [[ $DRYRUN == "FALSE" ]]; then
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
$query;
commit;
EOF
else
    echo "DRYRUN Flag is set as TRUE"
fi
}


#fileName="$1"
if [ -z $CLID ];then
    clientId=$(echo "$fileName" | awk -F'/' '{print $4}'| awk -F'-' '{print $1}'| sed -e 's/\\//' -e 's/[[:space:]]//')
else
    clientId="$CLID"
fi
UFILEID=$(echo "$file_ID" | awk -F'_' '{print $1}')
#echo "$fileName"
#clientId=$(( 10#$clientId ))
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
#echo $skrow
#echo $deli
#let clientId=clientId+0
#echo $clientId

## Atributes used by oracle
schema="${IMPORTDB}${clientId}"
#echo $schema
sqlBase="$BASEDIR/sql/"
if [[ $SVNSCRIPTS == "TRUE" ]]; then
    #Check of the script exists.Else termnilate
    sqlFullPath="$LOGDIR/$FMONID/IP_${LyID}.sql"
    svnExport 
else
    sqlFullPath=${sqlBase}IP_${LyID}.sql
fi

if [ ! -f "$sqlFullPath" ]
then
    INFO14="INFO14: Oracle Procedure not found."
    echo "$INFO14"
    #export INFO14
    #allLogging "::::$INFO14"
    exit 1
fi
#echo $sqlFullPath
updateLog
sql="SELECT user from dual "
checklink=$(file "${fileName}" | grep "symbolic link to")
#ls -l "${fileName}"
if [[ $LINK == "TRUE" ]] && [[ ${#checklink} != 0 ]];then
    fileName=$(ls -l "${fileName}" | awk -F'->' '{gsub(/^[[:space:]]/,"",$2);print $2}' | sed -e "s:':'':g")
else
    fileName=$(echo "${fileName}" | sed -e "s:':'':g")
fi
empid=$(echo "${empid}" | sed -e "s:':'':g")
#sqlexe="IP_$LyID('"$fileName"','"$file_ID"','"$clientId"','"$empid"',"$skrow",'"$deli"','"$FLMSLINK"')"
if [[ ${#dateoverride} == '0' ]] && [[ ${#optenc} == '0' ]];then
    sqlexe="IP_$LyID(p_FilePath=> '"$fileName"', p_FileID=>'"$file_ID"',p_CLIENTID=>'"$clientId"',p_EMPGRP=>'"$empid"',p_skip=>'"$skrow"',p_delim=>'"$deli"',p_link=>'"$FLMSLINK"')"
elif [[ ${#dateoverride} != '0' ]] && [[ ${#optenc} == '0' ]];then
    sqlexe="IP_$LyID(p_FilePath=> '"$fileName"', p_FileID=>'"$file_ID"',p_CLIENTID=>'"$clientId"',p_EMPGRP=>'"$empid"',p_skip=>'"$skrow"',p_delim=>'"$deli"',p_link=>'"$FLMSLINK"',p_date=>'"$dateoverride"')"
elif [[ ${#dateoverride} == '0' ]] && [[ ${#optenc} != '0' ]];then
    sqlexe="IP_$LyID(p_FilePath=> '"$fileName"', p_FileID=>'"$file_ID"',p_CLIENTID=>'"$clientId"',p_EMPGRP=>'"$empid"',p_skip=>'"$skrow"',p_delim=>'"$deli"',p_link=>'"$FLMSLINK"',p_opt=>'"$optenc"')"
else
    sqlexe="IP_$LyID(p_FilePath=> '"$fileName"', p_FileID=>'"$file_ID"',p_CLIENTID=>'"$clientId"',p_EMPGRP=>'"$empid"',p_skip=>'"$skrow"',p_delim=>'"$deli"',p_link=>'"$FLMSLINK"',p_date=>'"$dateoverride"',p_opt=>'"$optenc"')"
fi
#EXEC IP_871(p_FilePath=> 'filePath', p_FileID=>'999_999',p_CLIENTID=>'999',p_EMPGRP=>'UNKN',p_skip=>'0',p_delim=>'|',p_link= >'flmsdevs')
echo "$sqlexe"
sqlReturn="SELECT 'IMPORTSTATUS'||'|'||CASE WHEN STATUS_OF_IMPORT='SUCCESS' THEN 'SUCCESS' ELSE 'FAILURE'||' '||STATUS_OF_IMPORT END||'|'||FILEID||'_'||DMFILEID ||'|'||FULLPATH||'|'||Nvl(IMPORT_RECORD_CNT,'0') AS RETURNSTATUS FROM IMP_MAIN_LOG@$FLMSLINK WHERE  FILEID||'_'||DMFILEID='"$file_ID"'"

#sqlReturn="SELECT IMPORT_RECORD_CNT||'|'||STATUS_OF_IMPORT AS RETURNCODE FROM importdb.IMP_MAIN_LOG WHERE  FILEID||'_'||DMFILEID='"$3"'"
if [[ $DRYRUN == "FALSE" ]]; then
#echo "$schema/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$IMPORTDBSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))"
OUTPUT=$(sqlplus -S "$schema/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$IMPORTDBSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
SET DEFINE OFF;
@$sqlFullPath;
EXEC $sqlexe;
$sqlReturn;
SET DEFINE ON;
EXIT;
EOF
)
#echo $OUTPUT
#export OUTPUT
echo $OUTPUT
else
echo "DRYRUN Flag is set as TRUE"
fi
