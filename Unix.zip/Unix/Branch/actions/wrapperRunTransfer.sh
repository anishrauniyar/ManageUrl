#!/bin/bash
#
#@Author:Aadesh Neupane
#Last Release Date:20/04/2015
#Version: 0.1.3
#
#
#Description: Script to execute Transfer Script from AI to HI Tables


source /data1/AIPTEST/conf/main.conf

USAGE="
Desc : runTransfer.sh wrapper

Usage: wrapperRunTransfer.sh  -f <ufileid_dmfileid>
       Examples:
       wrapperRunTransfer.sh -f '1234_164123'
"

if [ $# -lt 2 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi
while getopts ":f:" options
do
        case $options in
        "f")
        fileID="$OPTARG"
        ;;
        ":")
        echo "No argument value for option $OPTARG"
        echo "$USAGE"
        exit;;
        *)
        echo "$USAGE"
        exit;;
        esac
done
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)

function getTransferPara()
{
query=" SELECT DISTINCT clientid||'|'||fileid||'_'||dmfileid||'|'||HISERVERNAME||'|'||HISCHEMANAME||'|'||IMPORTSERVER FROM  
 aip_dashboard_transfer WHERE fileid||'_'||dmfileid='"$fileID"'
"
output=$(sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
$query;
EXIT;
EOF
)

clientid=$(echo "$output" | awk -F'|' '{print $1}')
fileid=$(echo "$output" | awk -F'|' '{print $2}')
host=$(echo "$output" | awk -F'|' '{print $3}')
schema=$(echo "$output" | awk -F'|' '{print $4}')
importserver=$(echo "$output" | awk -F'|' '{print $5}')
}

function insert_aip_localactions_log()
{
    INFO=$(echo "$INFO1 $INFO2" | sed "s:':'':g")
    query="INSERT INTO aip_localactions_log(fileid,action_script,info,status) VALUES('"$fileID"','wrapperRunTransfer.sh','"$INFO"','"$STATUS"')"
sqlplus -S "$FLMS/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$FLMSSERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF
set define off;
$query;
set define on;
commit;
exit;
EOF
}

#This function will return parameters for runTransfer script 
getTransferPara

#UFILEID=$(echo "$fileID" | awk -F'_' '{print $1}')
#dmfileid=$(echo "$fileID" | awk -F'_' '{print $2}')

# Check if retransferis requested 
if [[ ${#clientid} != 0 ]] && [[ ${#fileid} != 0 ]] && [[ ${#host} != 0 ]] && [[ ${#schema} != 0 ]] && [[ ${#importserver} != 0 ]]
then 
    INFO1="All parameters for auto transfer correctly set.
          Calling runTransfer.sh -c '"$clientid"' -f '"$fileID"' -h '"$host"' -s '"$schema"' -i '"$importserver"'"
    echo "$INFO1"
    $DEFAULTACTIONDIR/runTransfer.sh -c "$clientid" -f "$fileID" -h "$host" -s "$schema" -i "$importserver"
    if [ $? -eq 0 ];then
	INFO2="Transfere Successful. Script returned 0 exit status"
	echo "$INFO2"
	STATUS="SUCCESS"
    else
	INFO2="Transfer unsuccessful. Script returned non-zero status"
	echo "$INFO2"
	STATUS="EXCEPTION"
    fi
else
    INFO1="Parameters not correctly for auto transfer. -c '"$clientid"' -f '"$fileID"' -h '"$host"' -s '"$schema"' -i '"$importserver"'"
    echo "$INFO1"
    STATUS="EXCEPTION"
fi 

#Log the info to log
insert_aip_localactions_log



