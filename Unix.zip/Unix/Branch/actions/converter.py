#!/usr/bin/env python

#@author:Aadesh Neupane
import sys
import re
#deleminator="\t"

countZTBL_HI=0
nameZTBL_HI=[]
contentsZTBL_HI=[]
punchchar='N'

#Testing new module for extracting the ZTBL_HI info
def readZTBL_HI(contents,words):
	global countZTBL_HI
	countZTBL_HI=countZTBL_HI+1
	words=words.split(" ")
	words=words[2]
	words=words.split("_")
	words=words[1:]
	words='_'.join(words)
	words=words.strip()
	#print words
	global nameZTBL_HI
	nameZTBL_HI.append(str(words))
	#print contents
	global contentsZTBL_HI
	contentsZTBL_HI.append(contents)
	#return words

def readZTBL_HI_Contents(fileName):
	fieldContents=[]
	lineNo=1
	SLine=0
	CLine=0
	fp=open(fileName,'r')
	fp1=open(fileName,'r')
	wholeContents=fp1.read()
	wholeContents=wholeContents.split("\n")
	for words in fp.readlines():
		#contents.append(words)
		lineNo=lineNo+1
		if "CREATE TABLE ZTBL_HI_" in words.upper():
			name=words
			SLine=lineNo
			#print SLine
		if SLine !=0:
			if "--" in words:
				continue
			fieldContents.append(words)
			if words=="":
				contine
			if "NOLOGGING" in words:
				CLine=lineNo
				#print SLine,CLine
				#print wholeContents[SLine:CLine]
				readZTBL_HI(wholeContents[SLine:CLine],name)
				SLine=0	
				#print CLine
	fp.close()
	fp1.close()
	
def read_HI_Contents(fileName):
	lengthContents=[]
	lineNo=1
	SLine2=0
	CLine2=0
	fp=open(fileName,'r')
	fp1=open(fileName,'r')
	wholeContents=fp1.read()
	wholeContents=wholeContents.split("\n")
	for words in fp.readlines():
		#contents.append(words)
		lineNo=lineNo+1
		if "CREATE TABLE HI_" in words.upper():
			#word1=words.split(" ")
			word1=words.strip()
			word1=word1.split(" ")
			word1=word1[2]
			#print word1
			#print nameZTBL_HI
			if word1 in nameZTBL_HI:
				SLine2=lineNo
				#print SLine2
		#print words
		if SLine2 !=0:
			if "--" in words:
				continue
			words=words.strip("\t\n")
			#contents.append(words)
			if "NOLOGGING" in words:
				CLine2=lineNo
				#print SLine2
				#print CLine2
				lengthContents.append(wholeContents[SLine2:CLine2])
				SLine2=0
		#print lengthContents
	return lengthContents

	
def read_FixedLen_Contents(fileName):
	fixedLenContains=[]
	SLine3=0
	CLine3=0
	lineNo=1
	fp=open(fileName,'r')
	fp1=open(fileName,'r')
	wholeContents=fp1.read()
	wholeContents=wholeContents.split("\n")
	for words in fp.readlines():
		try:
			if "INSERT INTO ZTBL_HI_" in words.upper():
				SLine3=lineNo
				#print SLine3
			if SLine3!=0:
				if "--" in words:
					continue
				#fixedLenContains.append(words)
				if "--WHERE" in words or "WHERE TRIM" in words or "ZZZ_HI_" in words:
					CLine3=lineNo
					#print SLine3
					#print CLine3
					fixedLenContains.append(wholeContents[SLine3:CLine3])
					#print wholeContents[SLine3:CLine3]
					SLine3=0
		except:
			print "error"
		lineNo=lineNo+1
	#print fixedLenContains
	return fixedLenContains
	
#This functions processes the file and extracts the necessary information
def readScript(fileName):
	print fileName
	orgaContents=[]
	contents=[]
	lineNo=1
	SLine1=0
	CLine1=0
	fp=open(fileName,'r')
	fp1=open(fileName,'r')
	wholeContents=fp1.read()
	wholeContents=wholeContents.split("\n")
	for words in fp.readlines():
		#contents.append(words)
		lineNo=lineNo+1
		if "ORGANIZATION EXTERNAL" in words.upper():
			SLine1=lineNo
			#print SLine1
		if SLine1!=0:
			if "--" in words:
				continue
			if words=="":
				contine
			#print words	
			if "REJECT LIMIT UNLIMITED" in words.upper():
				CLine1=lineNo
				orgaContents.append(wholeContents[SLine1:CLine1])
				#print wholeContents[SLine1:CLine1]
				SLine1=0
				#print CLine1
		if "PUNCHCHAR" in words:
			global punchchar
			punchchar="Y"
		if "ISDATE" in words:
			#print words
			b=words.split("=")
			c=b[0].split(",")
			#print c
			if len(c)==4:
				c=c[3].split(",")
				c=c[0].split("'")
				dateType=c[2]
			else:
				c=c[1].split("'")
				#print c
				if len(c)==5:
					#print c[2]
					dateType=c[2]
				elif len(c)==4:
					dateType=c[1]
				else:
					dateType=c[1]
				#print dateType		
	#print fieldContents
	#print orgaContents
	#print len(fieldContents)
	#return orgaContents
	#print dateType
	try:
		return orgaContents,dateType
	except UnboundLocalError:
		print "Date type not define in the file"
		dateType="Default"
		return orgaContents,dateType

#This function gets the list and processes the list to find the fields,type and length

def stripContents(listContents):
	#print len(listContents)
	#print listContents[0]
	#print listContents
	i=0
	fieldsContents=[]
	typeContents=[]
	sizeContents=[]
	#print len(listContents)
	#if None in listContents:
	#	print "None"
	try:
		for data in listContents:
			#print data + "\n"
			data1=data.strip(' \t\n\r')
			if "\t" in data1:
				rdata=data1.split("\t")
			else:
				rdata=data1.split(" ")
			#fieldpos='_'.join(fieldpos)
			#print fieldpos
			#print rdata.pop()
			#print rdata[0]
			if i>=0 and i<(len(listContents)-8):
				if rdata[0]=="":
					continue
				if rdata[0]=="UDF1":
					#fieldsContents.pop()
					break
				fieldsContents.append(rdata[0])
				#print rdata[0]
				#typeContents.append(rdata[1])
				#print rdata[0]
				try: 
					r1data=rdata[1].split("(")
					#print rdata[1]
				except IndexError:
					continue
				r11data=r1data[0].split(",")
				#print r11data[0]
				typeContents.append(r11data[0])
				#if "DATE" not in r1data:
				#	r2data=r1data[1].split(")")
				#	sizeContents.append(r2data)
			
				try:
					r2data=r1data[1].split(")")
					r2data=r2data[0].split(",")
					sizeContents.append(r2data[0])
					#print r2data[0]
				except IndexError:
					sizeContents.append(10)
				#sizeContents.append(r2data[0])
			i=i+1	
		#print fieldsContents;print len(fieldsContents)
		#print typeContents;print len(typeContents)
		#print sizeContents;print len(sizeContents)
		sum=0
	except TypeError:
		print "Error " +data
	for a in sizeContents:
		try:
			sum=sum+int(a)
		except (TypeError,ValueError) as e:
			a=''.join(a)
			a=a.split(',')
			a=''.join(a[0:2])
			sum=sum+int(a)
		
	#print len(fieldsContents)
	return fieldsContents,typeContents,sizeContents,sum;

#This function gets the list and processes the list to find skip
def stripOrgContents(listContents):
	#print listContents
	for data in listContents:
		if type(data) is list:
			data=str(data)
			data=data.split("\\t")
		#print data
		if "\\t" not in data:
			data=''.join(data)
		data=data.split(",")
	for data1 in data:
		if "SKIP" in data1:
			#data=data.strip(" \t")
			#print data1
			data1=data1.split(" \r")
			#data=''.join(data)
			if len(data1)==7:
				skip=data1[6]
			else:	
				data1=str(data1)
				skip=data1[5]
				#print skip
			#print data[6]
		if "TERMINATED BY" in data1:
			data1=data1.split("\t\r")
			data1=''.join(data1)
			data1=data1.rsplit("\"")
			deleminator=data1[1]
			#print deleminator
	return skip,deleminator

#This function calculates the total sum for the fixed length

def calcTotalSum(fixedLenContents):
	sum=0
	modLContents=[]
	#fixedLenContents=fixedLenContents.split("\n")
	#print fixedLenContents
	for data in fixedLenContents:
		#print data
		data=data.strip("\t\r")
		#print data
		if "TRIM" in data:
			#print data
			data=data.rsplit(",")
			try:
				data=data[2].rsplit(")")
			except IndexError:
				continue
			#print data[0]
			data=''.join(data[0])
			data=int(data)
			#print data
			sum=sum+data
			modLContents.append(data)
	#print sum
	return sum,modLContents

def main():
	arg1=''
	try:
		arg1=sys.argv[1]
		if arg1=='-h':
			print "Uses : converter.py filename"
			exit()
			#readScript(arg1)
	except IndexError:
		print "Uses : converter.py filename"
		exit()
	#arg1=sys.argv[1]
	fileName=arg1
	#fileName=fileName[0:len(fileName)-4]
	modfier="Layout_"
	#cont=[]
	readZTBL_HI_Contents(fileName)
	lengthContents=read_HI_Contents(fileName)
	fixedLenContents=read_FixedLen_Contents(fileName)
	orgaContents,dateType=readScript(fileName)
	#cont.append(readScript(arg1))
	#print len(cont)
	#print len(contentsZTBL_HI[0])
	#print contentsZTBL_HI[1]
	#print lengthContents[1]
	#print len(orgaContents)
	#print str(len(fixedLenContents)) + "Fixed Len"
	#print len(dateType)
	#print nameZTBL_HI
	#fContents,tContents,lContents,sum=stripContents(lengthContents)
	skip,deleminator=stripOrgContents(orgaContents)
	j=0
	#print deleminator
	fpw=open(modfier+fileName+".csv","w")
	while j<len(nameZTBL_HI):
		fContents,tContents,lContents,sum=stripContents(lengthContents[j])
		print len(fContents);
		#print fContents
		print len(tContents);
		print len(lContents);
		#print deleminator
		fixdele=[];fixdele.append('\\n');fixdele1='\\'+fixdele[0];
		#print fixdele1
		if deleminator==fixdele1:
			#print "Fixed length content"
			totalSum,modLContents=calcTotalSum(fixedLenContents[j])
			#print modLContents
			fpw.write("FileName,"+fileName+"\nNo. of Fields,"+str(len(fContents)-8)+"\nTotal Length,"+str(sum)+"\nTotal Fixed Length,"+str(totalSum)+"\nSkip,"+str(skip)+"\nDelimenator,"+deleminator+"\nPunchChar,"+punchchar+"\n")
		else:
			#print "Else content"
			fpw.write("FileName,"+fileName+"\nNo. of Fields,"+str(len(fContents))+"\nTotal Length,"+str(sum)+"\nSkip,"+str(skip)+"\nDelimenator,"+deleminator+"\nPunchChar,"+punchchar+"\n")
		#print len(fContents)
		i=0
		while i<len(fContents):
			if deleminator==fixdele1:
				if "DATE" in tContents[i]:
					fpw.write(fContents[i]+","+tContents[i]+","+dateType+","+str(modLContents[i])+"\n")
				else:
					fpw.write(fContents[i]+","+tContents[i]+","+" "+","+str(modLContents[i])+"\n")
			else:
				if "DATE" in tContents[i]:
					fpw.write(fContents[i]+","+tContents[i]+","+dateType+","+str(lContents[i])+"\n")
				else:
					fpw.write(fContents[i]+","+tContents[i]+","+" "+","+str(lContents[i])+"\n")
			i=i+1
		j=j+1; #print totalSum
		fpw.write("\n")
	fpw.close()	
	#print fileName
	#print skip
	#print deleminator
	#print nameZTBL_HI
	#print contentsZTBL_HI
	#print fContents
	#print tContents
	#print lContents
	#print fixedLenContents[0]
	#print totalSum
	#fpw=open(modfier+fileName+".csv","w")
	#if deleminator=="\\n":
	#	fpw.write("FileName:"+fileName+"\nNo. of Fields:"+str(len(fContents)-8)+"\nTotal Length:"+str(sum)+"\nTotal Fixed Length:"+str(totalSum)+"\nSkip:"+str(skip)+"\nDelimenator:"+deleminator+"\n")
	#else:
	#	fpw.write("FileName:"+fileName+"\nNo. of Fields:"+str(len(fContents))+"\nTotal Length:"+str(sum)+"\nSkip:"+str(skip)+"\nDelimenator:"+deleminator+"\n")
	#i=0
	#print len(fContents)
	#print len(tContents)
	#print len(lContents)
	#print tContents
	#print dateType
 	#while i<len(fContents):
	#	if deleminator=="\\n":
	#		if "DATE" in tContents[i]:
	#			fpw.write(fContents[i]+","+tContents[i]+","+dateType+","+str(modLContents[i])+"\n")
	#		else:
	#			fpw.write(fContents[i]+","+tContents[i]+","+" "+","+str(modLContents[i])+"\n")
	#	else:
	#		if "DATE" in tContents[i]:
	#			fpw.write(fContents[i]+","+tContents[i]+","+dateType+","+str(lContents[i])+"\n")
	#		else:
	#			fpw.write(fContents[i]+","+tContents[i]+","+" "+","+str(lContents[i])+"\n")
	#	i=i+1
	#fpw.close()
	
if __name__=="__main__":
	main()
	
			
