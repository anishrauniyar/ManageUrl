#!/bin/bash
#OSENV="MACOSX"

if [ "$OSENV" = "MACOSX" ]
then
   AWK=/opt/local/bin/gawk
   GDATE=/opt/local/bin/gdate
else
   AWK=/bin/awk
   GDATE=/bin/date
fi

#source $CONF_FILE
source /data1/AIPTEST/conf/main.conf
set -B
shopt -s extglob
DBGPRINT=1
SPASSWORD=$($FMONCONFDIR/crypto -z $PASSWORD)
USAGEFULL="
"
USAGE="
Usage: getFileNames -s <starttime> -e <endtime> [-c <clientid>]
       Examples
	 ./getFileNames -s '20140301 12:00:00' -e '20140331 11:59:00'
	 ./getFileNames -s '20140301 12:00:00' -e '20140331 11:59:00' -c \"'522'\" -o filelist.txt
	 ./getFileNames.sh -s '20140301 12:00:00' -e '20140702 11:59:00' -f 'sigpha201212.txt' -o filelist.txt
	./getFileNames.sh -s '20140301 12:00:00' -e '20140702 11:59:00' -f \"'sigpha201212.txt','vdd00:wq01o.GLOBAL.hanes.clm.txt_20140612.0132.txt'\" -o filelist.txt
"
prtUSAGEFULL () {
   echo -e "$USAGEFULL $USAGE" >&2
}

dbgPRINT () { if [ "$DBGPRINT" = "1" ]; then echo "$@"; fi }

isDateValid() {
#  ${GDATE} -d "$1" +%s 2>1 >/dev/null
  date -d "$1" +%s 
  return $?
}

OPTS=$(getopt -o s:e:c:o:f: --long start:,end:,client:,out:,file:,help -- "$@")
if [ $? != 0 ] ; then echo "ERROR: Invalid options" ; echo -e >&2 "$USAGE" ; exit 1 ; fi
eval set -- "$OPTS"

#echo NUMOFARGS=$#
let "numargs = $# - 1"

while true; do
    case "$1" in
	-s | --start ) starttime=$2; shift 2 ;;
	-e | --end ) endtime=$2; shift 2;;
	-c | --client ) client="$2"; shift 2 ;;
	-o | --out ) outfile="$2"; shift 2 ;;
	-f | --file) filename="$2"; shift 2 ;;
	-- ) shift; break ;;
	--help | * )
	     prtUSAGEFULL; shift; exit 1 ;;
    esac
done

if [ "$numargs" -lt 4 ] ; then echo -e "$USAGE" >&2 ; exit 1 ; fi
# check for date validity here
isDateValid="$starttime"
if [ $? != 0 ] ; then echo "ERROR: Invalid start time: $starttime"; exit 1; fi
isDateValid="$endtime"
if [ $? != 0 ] ; then echo "ERROR: Invalid end time: $endtime"; exit 1; fi

#dbgPRINT "START:$starttime,  END:$endtime, CLIENT:$client,  OUT=$outfile"

if [ -z $client ] && [ -z $filename ]; then
	subquery=" AND 1=1 "
elif [ -z $client ] && [ ! -z $filename ];then
	fileName=$(echo $filename | tr '[:lower:]' '[:upper:]')
	subquery=" AND UPPER(FILENAME) IN ($fileName) "
else
 	subquery=" AND clientid in ($client ) "
fi


#Query shared by OAM team to get file list from datamanager

sqlbase="(SELECT clientid,
               clientname,
               sourceid,
               sourcename,
               root_fileid,
               root_filename,
               root_filesize,
               downloaddate,
               fileid,
               orgfilename,
               filename,
               filesize,
               CASE
                 WHEN updatedon > actualreceiveddate THEN updatedon
                 ELSE actualreceiveddate
               END AS destinationDate,
               actualreceiveddate,
               updatedon,
               destpath,
               source_clienttype,
               client_clienttype,
               is_duplicate,
               is_error,
               is_incomplete,
               is_zerokb,
               is_orphan,
               checksum
        FROM   (SELECT clientid,
                       clientname,
                       sourceid,
                       sourcename,
                       root_fileid,
                       root_filename,
                       root_filesize,
                       Nvl(actualreceiveddate, receiveddate)
                       downloaddate,
                       fileid,
                       filename                                      orgfilename
                       ,
                       Nvl(destfilename,
                       Nvl(changedname, filename)) filename,
                       filesize,
                       receiveddate,
                       actualreceiveddate,
                       updatedon,
                       sourcetype,
                       sourcepath,
                       destpath,
                       source_clienttype,
                       client_clienttype,
                       is_duplicate,
                       is_error,
                       is_incomplete,
                       CASE
                         WHEN is_downloaded = 'N'
                              AND is_incomplete != 'Y'
                              AND Nvl(filesize, 0) <= 0 THEN 'Y'
                         ELSE 'N'
                       END                                           is_zerokb,
                       CASE
                         WHEN is_downloaded = 'Y'
                              AND source_clienttype = 'PBM'
                              AND clientid = sourceid THEN 'Y'
                         ELSE 'N'
                       END                                           is_orphan,
                       checksum
                FROM   ((SELECT r.clientid,
                                r.clientname,
                                r.sourceid,
                                r.sourcename,
                                r.parentfile.fileid   root_fileid,
                                r.parentfile.filename root_filename,
                                r.parentfile.filesize root_filesize,
                                r.fileid,
                                r.filename,
                                r.filesize,
                                r.receiveddate,
                                r.actualreceiveddate,
                                r.updatedon           updatedOn,
                                r.sourcetype,
                                r.sourcepath,
                                r.destpath,
                                r.destfilename,
                                r.source_clienttype,
                                r.client_clienttype,
                                r.is_downloaded,
                                r.is_duplicate,
                                r.is_error,
                                r.is_incomplete,
                                r.changedname,
                                r.checksum
                         FROM   (SELECT Nvl(dl.clientid, r.sourceid)
                                        clientid,
                                        Nvl2(dl.clientid, Nvl(c2.clientname,
                                                          s2.clientname),
                                        Nvl(c1.clientname, s1.clientname))
                                        clientname,
                                        r.sourceid,
                                        Nvl(c1.clientname, s1.clientname)
                                        sourcename,
                                        CASE
                                          WHEN r.parentfileid IS NOT NULL
                                               AND r.parentfileid != r.fileid
                                        THEN
                                          Get_parentfile(r.fileid)
                                          ELSE Parentfile_type(r.sourceid,
                                               r.fileid,
                                               r.filename,
                                               r.filesize,
                                               r.receiveddate,
                                                      r.sourcetype,
                                               r.sourcepath,
                                               r.checksum,
                                               r.actualreceiveddate,
                                               r.destpath,
                                                      r.destfilename,
                                               r.destfilesize,
                                               r.destfiledate)
                                       END
                                        parentfile,
                                        r.fileid,
                                        r.filename,
                                        r.filesize,
                                        r.receiveddate,
                                        r.actualreceiveddate,
                                        r.mappedon updatedon,
                                        r.sourcetype,
                                        r.sourcepath,
                                        r.destpath,
                                        r.destfilename,
                                        Nvl2(c1.clientid, 'CLIENT',
                                        Nvl2(s1.clientid, 'PBM', 'Unknown')
                                        )
                                        source_clienttype,
                                        Nvl2(dl.clientid, Nvl2(c2.clientid,
                                                          'CLIENT',
                                                          Nvl2(s2.clientid,
                                                          'PBM',
                                                          'Unknown'
                                                          )),
                                        Nvl2(c1.clientid, 'CLIENT',
                                        Nvl2(s1.clientid, 'PBM', 'Unknown')
                                        )
                                        )
                                        client_clienttype,
                                        Nvl2(dl.fileid, 'Y', 'N')
                                        is_downloaded,
                                        Nvl2(dup.fileid, 'Y', 'N')
                                        is_duplicate
                                        ,
       Nvl2(err.fileid, 'Y', 'N')         is_error,
       'N'                                is_incomplete,
       dl.changedname,
       r.checksum
       FROM   oam_dmreceivedfiles@hawkeyeoam r,
       oam_dmdownloadedfiles@hawkeyeoam dl,
       oam_dmduplicatefiles@hawkeyeoam dup,
       oam_dmerroredfiles@hawkeyeoam err,
       oam_clients@hawkeyeoam c1,
       oam_datasources@hawkeyeoam s1,
       oam_clients@hawkeyeoam c2,
       oam_datasources@hawkeyeoam s2
       WHERE  r.fileid = dl.fileid(+)
       AND r.fileid = dup.fileid(+)
       AND r.fileid = err.fileid(+)
       AND r.sourceid = c1.clientid(+)
       AND r.sourceid = s1.clientid(+)
       AND dl.clientid = c2.clientid(+)
       AND dl.clientid = s2.clientid(+)
       AND ( r.fileid = r.parentfileid
              OR r.parentfileid IS NULL
              OR Nvl(r.filesize, 0) = 0
              OR dl.fileid IS NOT NULL
              OR dup.fileid IS NOT NULL
              OR err.fileid IS NOT NULL )) r)
       UNION ALL
       (SELECT i.sourceid                        clientid,
       Nvl(c3.clientname, s3.clientname) clientname,
       i.sourceid,
       Nvl(c3.clientname, s3.clientname) sourcename,
       i.fileid                          root_fileid,
       i.filename                        root_filename,
       i.filesize                        root_filesize,
       i.fileid,
       i.filename,
       i.destfilesize                    filesize,
       i.receiveddate,
       i.logdate                         actualreceiveddate,
       NULL                              updatedOn,
       i.sourcetype,
       i.sourcepath,
       i.destpath,
       i.destfilename,
       Nvl2(c3.clientid, 'CLIENT', Nvl2(s3.clientid, 'PBM', 'Unknown')
       )
                                 source_clienttype,
       Nvl2(c3.clientid, 'CLIENT', Nvl2(s3.clientid, 'PBM', 'Unknown')
       )
                                 client_clienttype,
       'N'                               is_downloaded,
       'N'                               is_duplicate,
       'N'                               is_error,
       'Y'                               is_incomplete,
       i.filename                        changedname,
       NULL                              checksum
       FROM   oam_dm_incompletereceivedfiles@hawkeyeoam i,
       oam_clients@hawkeyeoam c3,
       oam_datasources@hawkeyeoam s3
       WHERE  i.sourceid = c3.clientid(+)
       AND i.sourceid = s3.clientid(+)))))
WHERE DESTPATH LIKE '%\data\%'
	AND destinationdate>=To_Date('$starttime','YYYYMMDD HH24:MI:SS') AND destinationdate<To_Date('$endtime','YYYYMMDD HH24:MI:SS')
     	$subquery    
ORDER BY clientid,destinationdate";

clientlist=`echo $client | tr "'" " "|sed 's/ //g'`
#filelist=`echo $fileName | tr "'" " "|sed 's/ //g'`
filename=`echo $starttime | awk '{print $1$2}'`
#if outfile is not passed as argument initialize
outfile=${outfile:-"dmfile.$filename.list"}

#sqlSpoolDM="Select clientid||'|'||FILEID||'|'||REPLACE(destpath,'\','/')||'|'||FILENAME||'|'||CHECKSUM||'|'||to_char(destinationdate,'YYYY-MM-DD HH24:MI:SS')||'|'||FILESIZE||'|'||to_char(updatedon,'YYYYMMDD HH24:MI:SS') FLIST FROM ";
sqlSpoolDM="Select REPLACE(destpath,'\','/')||FILENAME||'|'||clientid||'|'||FILEID||'|'||CHECKSUM||'|'||to_char(destinationdate,'YYYY-MM-DD HH24:MI:SS')||'|'||FILESIZE||'|'||to_char(updatedon,'YYYYMMDD HH24:MI:SS') FLIST FROM ";
sqlInsert="INSERT INTO IMP_DMFILELIST
(
CLIENTID, FILEID, DESTPATH, FILENAME, CHECKSUM, RECEIVEDDATE, FILESIZE, FILEDATE, STARTTIME, ENDTIME, CLIENTLIST, DMFILENAME
)
Select 
clientid,FILEID,destpath,FILENAME,CHECKSUM,to_char(destinationdate,'YYYYMMDD HH24:MI:SS') RECEIVEDDATE,FILESIZE,to_char(updatedon,'YYYYMMDD HH24:MI:SS') FILEDATE,'$starttime' AS STARTTIME,'$endtime' AS ENDTIME ,'$clientlist' AS CLIENTLIST, '/data1/AIP/FMON/tmp/$outfile' AS DMFILENAME 
FROM ";

#echo $PATH
sql=$sqlSpoolDM$sqlbase;
echo $sql;
#sqlIn=$sqlInsert$sqlbase;
#echo $sql;

dbgPRINT "START:$starttime,  END:$endtime, CLIENT:$client,  OUT=$TMPDIR/$outfile"
#sqlplus -S 'importDB/oracle@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerwork)(PORT=1521))(CONNECT_DATA=(SID=d2he)))' << EOF > /dev/null
#sqlplus -S importdb/oracle << EOF > /dev/null 
sqlplus -S "$SCHEME/$SPASSWORD @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=$SERVER)(PORT=$SPORT))(CONNECT_DATA=(SID=$SID)))" <<EOF > /dev/null
SET LINES 32000;
SET ECHO OFF NEWP 0 SPA 0 PAGES 0 FEED OFF HEAD OFF TRIMS ON TAB OFF;
SET TERMOUT OFF;
SET SERVEROUTPUT OFF;
SPOOL "${TMPDIR}/$outfile";
$sql;
spool off;
$sqlIn;
commit;
EOF
exit
EOF




