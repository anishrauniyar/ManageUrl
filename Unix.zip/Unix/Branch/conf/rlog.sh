#!/bin/bash

# Generate FMONID

#FMONID=`date +%Y%m%d%H%M%S`

# logger location
#LOG="/usr/bin/logger"

# logging function
#export TAG="sysaip"
if [ -z $dmfileid ] ; then 
    dmfileid=NULL
fi

if [ -z $client_id ] ; then
    client_id=NULL
fi

function allLogging () {
$LOG -p local6.info "$FMONID|$dmfileid|$client_id|FMON:$(basename $0)|$*"
}
