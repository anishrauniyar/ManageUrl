function addAllOption(comboName, srcCombo, destCombo) {
	autoSelectCombo(comboName);
	addOption(srcCombo, destCombo);

}
function autoSelectCombo(srcCombo) {
	var sel1 = 0;
	var valueExist = true;
	var integerVal = document.getElementById(srcCombo).length;
	if (integerVal == 0) {
		valueExist = false;
	}

	for (sel1 = 0; sel1 < integerVal; sel1++) {
		document.getElementById(srcCombo).options[sel1].selected = true;
	}
	return valueExist;
}

function addOption(srcCombo, destCombo) {
	var arrValue = new Array();
	var arrText = new Array();
	var tmpValue = "";
	var tmpText = "";

	var isSelectionMade = 0;
	for ( var sel = 0; sel < srcCombo.length; sel++) {
		if (srcCombo.options[sel].selected) {
			isSelectionMade++;
			tmpValue = srcCombo[sel].value;
			tmpText = srcCombo[sel].text;
			arrValue.push(tmpValue);
			arrText.push(tmpText);
			var destComboCount = 0;
			if (destCombo.length > 0) {
				destComboCount = destCombo.length;
			}
			destCombo[destComboCount] = new Option(tmpText, tmpValue);
		}
	}

	if (isSelectionMade > 0) {
		removeOption(srcCombo, arrValue, arrText);
	}
}

function removeOption(combo, arrValue, arrText) {
	var tmpText = new Array();
	var tmpValue = new Array();

	var matched = false;

	for ( var i = combo.length - 1; i >= 0; i--) {
		matched = false;
		for ( var j = arrValue.length - 1; j >= 0; j--) {
			if (arrValue[j] == combo[i].value) {
				matched = true;
				arrValue.splice(j, 1);
			}
		}

		if (matched) {
			tmpValue[i] = "";
			tmpText[i] = "";
		} else {
			tmpValue[i] = combo[i].value;
			tmpText[i] = combo[i].text;
		}
		combo[i] = null;
	}
	var count = 0;

	for ( var k = 0; k < tmpValue.length; k++) {
		if (tmpValue[k] != "") {
			combo[count] = new Option(tmpText[k], tmpValue[k]);
			count++;
		}
	}
}