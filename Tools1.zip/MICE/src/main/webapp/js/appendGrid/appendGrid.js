/**
 * APPEND GRID
 */
var $j = jQuery.noConflict(); // for noConflict
/**
 * Shows the row order for appendGrid
 */
function showRowOrder() {
	var rowOrder = $j('#tblAppendGrid').appendGrid('getRowOrder');
	var result = '';
	for (var z = 0; z < rowOrder.length; z++) {
		if (z != 0)
			result += ',';
		result += rowOrder[z];
		$j('#tblAppendGrid').appendGrid('setCtrlValue', 'ColA', z, z);
	}
	// result += '';
	$j('#dispRowOrder').val(result);
}
/**
 * Main Function Parameters: Test Case,Test
 * Procedure,ExpectedResult,ActualResult and ReviewStatus
 */
$j(function() {
	// Initialize appendGrid
	$j('#tblAppendGrid').appendGrid(
			{
				caption : 'Test Cases',
				initRows : 1,
				columns : [ {
					name : 'TestCase',
					display : 'Test Case',
					type : 'text',
					ctrlAttr : {
						maxlength : 3000
					},
					ctrlCss : {
						width : '100%'
					}
				}, {
					name : 'TestProcedure',
					display : 'Test Procedure',
					type : 'text',
					ctrlAttr : {
						maxlength : 3000
					},
					ctrlCss : {
						width : '100%'
					}
				}, {
					name : 'ExpectedResult',
					display : 'Expected Result',
					type : 'text',
					ctrlAttr : {
						maxlength : 3000
					},
					ctrlCss : {
						width : '100%'
					}
				}, {
					name : 'ActualResult',
					display : 'Actual Result',
					type : 'text',
					ctrlAttr : {
						maxlength : 3000
					},
					ctrlCss : {
						width : '100%'
					}
				}, {
					name : 'ReviewStatus',
					display : 'Review Status',
					type : 'select',
					ctrlOptions : {
						0 : '{Choose}',
						1 : 'Pass',
						2 : 'Pending Verification'
					}
				}, ],
				afterRowAppended : function(caller, parentRowIndex,
						addedRowIndex) {
					for (var z = 0; z < addedRowIndex.length; z++) {
						var uniqueIndex = $j(caller).appendGrid(
								'getUniqueIndex', addedRowIndex[z]);
						$j(caller).appendGrid('setCtrlValue', 'ColB',
								addedRowIndex[z], uniqueIndex);
					}
					showRowOrder();
				},
				afterRowInserted : function(caller, parentRowIndex,
						addedRowIndex) {
					for (var z = 0; z < addedRowIndex.length; z++) {
						var uniqueIndex = $j(caller).appendGrid(
								'getUniqueIndex', addedRowIndex[z]);
						$j(caller).appendGrid('setCtrlValue', 'ColB',
								addedRowIndex[z], uniqueIndex);
					}
					showRowOrder();
				},
				afterRowSwapped : function(caller, oldRowIndex, newRowIndex) {
					showRowOrder();
				},
				afterRowRemoved : function(rowIndex) {
					showRowOrder();
				}
			});
});

/**
 * @Description : Loads the test cases
 * @param requestCode
 */
function loadTestCase(requestCode) {
	var issueType = getIssueTypeForEdit();
	//alert(issueType);
	if (issueType == CHANGE_REQUEST || issueType == PRODUCTION_INTEGRATION) {
		if (('#tblAppendGrid').length) {
			// alert("Request Code is "+requestCode);
			queryBeanPM.ajaxGetNewTestCases(requestCode, function(result) {
				// alert(result)
				$j('#tblAppendGrid').appendGrid('load', $j.parseJSON(result));
			});
		}
	}
}
