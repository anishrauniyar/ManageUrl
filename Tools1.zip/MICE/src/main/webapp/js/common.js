// JavaScript Document
//created by: Ram Sah, D2Hawkeye. Feb. 22, 2008
// function to validate email @author rsah, on Dec 26, 2007   
function isValidEmail(emailTf){
	var regexEmail = /^((([a-z]|[0-9]|!|#|$|%|&|'|\*|\+|\-|\/|=|\?|\^|_|`|\{|\||\}|~)+(\.([a-z]|[0-9]|!|#|$|%|&|'|\*|\+|\-|\/|=|\?|\^|_|`|\{|\||\}|~)+)*)@((((([a-z]|[0-9])([a-z]|[0-9]|\-){0,61}([a-z]|[0-9])\.))*([a-z]|[0-9])([a-z]|[0-9]|\-){0,61}([a-z]|[0-9])\.)[\w]{2,4}|(((([0-9]){1,3}\.){3}([0-9]){1,3}))|(\[((([0-9]){1,3}\.){3}([0-9]){1,3})\])))$/;
		if(!regexEmail.test(emailTf))                
			{
			return false;            
			}
		else
		{
		return true;        
		}   
} 

/******************** JS FUNCTIONS TO MANIPULATE COMBO OPTION VALUES ************/
function addSelectedValue(source,destination){
	sourceObj = $(source);
    destinationObj = $(destination);
    if(sourceObj.selectedIndex>=0)
    {
		destinationObj[destinationObj.length]=new Option(sourceObj.options[sourceObj.selectedIndex].text,sourceObj.options[sourceObj.selectedIndex].value);
		sourceObj.options[sourceObj.selectedIndex]=null;
    }
}
/**
 * 
 * @param source
 * @param destination
 * @return
 * @author Ramesh Raj Baral
 * @since Jun 16 2010
 * this method resets the values to source multiselect combo from destination
 */
function resetValues(source,destination){
	sourceObj = $(source);
    destinationObj = $(destination);
    var sourceIndex=sourceObj.options.length;
    var destinationIndex=destinationObj.options.length;
    if(destinationIndex>0){
    for(var i=destinationIndex-1;i>=0;i--)	{
    	var optn = document.createElement("OPTION");
    	optn.text = destinationObj.options[i].text;
    	optn.value = destinationObj.options[i].value;
    	sourceObj.options.add(optn);
    	destinationObj.options[i]=null;
    }
    }
}
/**
 * 
 * @param ackUsers
 * @return
 * @author Ramesh Raj Baral
 * Description:this method adds the acknowledge users to the dropdown while cloning a request
 * <li>get the user's entry from one select box,insert into another one</li>
 * <li>given the user's id is in the provided comma separated string</li>
 */
function loadAckUsers(source,destination,ackUsers){
	sourceObj = $(source);
    destinationObj = $(destination);
    if(ackUsers.length>0){
    var usersArr=ackUsers.split(",");
    var usersNameArr=new Array();
    for(var i=0;i<sourceObj.options.length;i++){
    	var userid=sourceObj.options[i].value;
    	var userName=sourceObj.options[i].text;
    	for(var j=0;j<usersArr.length;j++){
    		var ackUserID=usersArr[j];
    		if(userid==ackUserID){
    			usersNameArr[usersNameArr.length]=userName;
    			sourceObj.options[j]=null;
    		}	
    	}
    	
    }
    for(var i=0;i<usersArr.length;i++){
    	destinationObj[destinationObj.length]=new Option(usersNameArr[i],usersArr[i]);
    }
    }
}

/*
 * This function returns the filtered data in the view page in the table format
 * for excel export
 */
function getFilteredDataForExcel(tableData) {
	var rowData, colData, cellData, filteredData = '';
	for (i = 0; i < tableData.length; i++) {
		rowData = tableData[i];
		filteredData += "<tr>";
		for (j = 0; j < rowData.length; j++) {
			colData = rowData[j];
			for (k = 0; k < colData.length; k++) {
				cellData = colData[k];
				filteredData += "<td>" + cellData + "</td>";
			}
		}
		filteredData += "</tr>";
	}
	return filteredData;
}   

//Test commit
/*
 * This function moves single selected value from source multi combo to
 * destination multi combo
 */
function move(source, destination) {
	sourceObj = $(source);
	destinationObj = $(destination);
	if (sourceObj.selectedIndex >= 0) {
		destinationObj[destinationObj.length] = new Option(
				sourceObj.options[sourceObj.selectedIndex].text,
				sourceObj.options[sourceObj.selectedIndex].value);
		sourceObj.options[sourceObj.selectedIndex] = null;
	}
}

/*
 * This function moves the multi selected value from source multi combo to
 * destination multi combo
 */
function moveSelected(source, destination) {
	sourceObj = $(source);
	destinationObj = $(destination);
	var isSelected = false;
	for (var i = 0; i < sourceObj.length; i++) {
		if (sourceObj.options[i].selected) {
			destinationObj[destinationObj.length] = new Option(
					sourceObj.options[i].text, sourceObj.options[i].value);
			sourceObj.options[i] = null;
			i--;
			isSelected = true;
		}
	}
	if (!isSelected)
		alert("None selected.");
}

/*
 * This function moves all values from source multi combo to destination multi
 * combo
 */
function moveAll(source, destination) {
	sourceObj = $(source);
	destinationObj = $(destination);
	for (i = 0; i < sourceObj.length; i++) {
		destinationObj[destinationObj.length] = new Option(
				sourceObj.options[i].text, sourceObj.options[i].value);
		sourceObj.options[i] = null;
		i--;
	}
}

function moveUp(elem)
{
	elem=$(elem);	
	if(elem.selectedIndex==-1){alert('None selected.'); return;}
	if(elem.selectedIndex==0){alert('Top of list'); return;}
	
	var x=elem.selectedIndex;
	var tempstr=elem.options[x].text;
	var tempval=elem.options[x].value;
	
	elem.options[x].text=elem.options[x-1].text;
	elem.options[x].value=elem.options[x-1].value;
	
	elem.options[x-1].text=tempstr;
	elem.options[x-1].value=tempval;
	
	elem.selectedIndex=x-1;
}
function moveDown(elem)
{
	elem=$(elem);
	if(elem.selectedIndex==-1){alert('None selected.'); return;}
	if(elem.selectedIndex==elem.options.length-1){alert('Bottom of list'); return;}
	
	var x=elem.selectedIndex;
	var tempstr=elem.options[x].text;
	var tempval=elem.options[x].value;
	
	elem.options[x].text=elem.options[x+1].text;
	elem.options[x].value=elem.options[x+1].value;
	
	elem.options[x+1].text=tempstr;
	elem.options[x+1].value=tempval;
	
	elem.selectedIndex=x+1;
}

