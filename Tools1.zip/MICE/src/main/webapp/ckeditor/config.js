﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	config.uiColor = '#DDDDDD';
	//config.skin='office2003',
	config.toolbar = 'MyToolbar';
	config.resize_enabled=false;
	config.startupShowBorders=false;
	config.startupOutlineBlocks=false;
	config.toolbarCanCollapse = false;
	  // Disables the built-in spell checker while typing natively available in the browser (currently Firefox and Safari only).
	config.disableNativeSpellChecker=false,
	 // If enabled (true), turns on SCAYT (SpellCheckAsYouType) automatically after loading the editor.
	 // config.scayt_autoStartup = true;
	config.removePlugins = 'elementspath';
	config.colorButton_enableMore=false;
 
	config.toolbar_MyToolbar =
	[
		
	 	{ name: 'styles', items : [ 'Format' ] },
		{ name: 'basicstyles', items : [ 'Bold','Italic','Strike','Underline','-' ] },
		{ name: 'paragraph', items : [ 'NumberedList','BulletedList'] },
		{ name: 'colors', items : [ 'TextColor' ] },
		{ name: 'insert', items : [ 'Table', ] },
		{ name: 'clipboard', items : ['PasteText','Undo','Redo','RemoveFormat' ] }
		
		
	];
	
	CKEDITOR.on( 'dialogDefinition', function( ev )
			   {
			      // Take the dialog name and its definition from the event data.
			      var dialogName = ev.data.name;
			      var dialogDefinition = ev.data.definition;
			 
			      // Check if the definition is from the dialog we're
			      // interested in (the 'link' dialog).
			     
			    	  if (dialogName == 'table') {

			    	        dialogDefinition.removeContents('advanced');
			    	        var infoTab = dialogDefinition.getContents( 'info' );
			    	        
			    	         // Remove unnecessary widgets from the 'Link Info' tab.         
			    	         //infoTab.remove('txtBorder');
			    	      // infoTab.remove('txtHeight');
			    	       //  infoTab.remove('txtWidth');
			    	        infoTab.remove('txtCaption');
			    	         infoTab.remove('selHeaders');
			    	         infoTab.remove('txtSummary');
			    	         infoTab.remove('txtCellSpace');
			    	         infoTab.remove('txtCellPad');
			    	         
			    	    }
			      
			    	  
			   });
	
   


};
