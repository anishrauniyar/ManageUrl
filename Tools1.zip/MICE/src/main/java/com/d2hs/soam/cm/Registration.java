package com.d2hs.soam.cm;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import java.util.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.Date;
import java.io.ByteArrayInputStream;

import com.d2hs.soam.common.*;
import com.d2hs.soam.RequestBean;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;


public class Registration extends RequestBean{

    private String ClientName = null;
    private String ClientAddress = null;
    private String ClientCity=null;
    private String ClientZipCode=null;
    private String ClientContact=null;
    private String ClientEmail=null;
    private String ClientPhone=null;
    private String ClientComments=null;
    private String ClientStartDate=null;
    private String ClusterLead=null;
    
    private PreparedStatement myPS = null;
    private Statement stmt = null;
    private String errorStr = "No Error !";
    private int recPerPage = 50;


    public void setComment(String comment) {
        this.ClientComments = comment;
    }
     public void setClientName(String name) {
        this.ClientName =name;
    }

    public void setClientAddress(String address) {
        this.ClientAddress =address;
    }
    public void setClientCity(String city) {
        this.ClientCity =city;
    }
    public void setClientZipCode(String zip) {
        this.ClientZipCode =zip;
    }
    public void setClientConact(String contact) {
        this.ClientContact =contact;
    }
    public void setClientEmail(String email) {
        this.ClientEmail =email;
    }
     public void setClientPhone(String phone) {
        this.ClientPhone =phone;
    }
    public void setClientStartDate(String date) {
        this.ClientStartDate =date;
    }
    public String getClusterLead() {
		return ClusterLead;
	}
	public void setClusterLead(String clusterLead) {
		ClusterLead = clusterLead;
	}
	public int getRecPerPage() {
        return recPerPage;
    }

    public String getError() {
        return (errorStr);
    }
    public boolean checkClientName() {
        boolean retVal = true;
        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery("select ClientName from OAM_RM_CLIENTS where ClientName=" + SQLEncode(ClientName));
            while (myRS.next()) {
                retVal = false;
            }
        } catch (SQLException e) {
            retVal = false;
        }

        return (retVal);
    }
    public boolean checkDuplicateClientName(String ClientName) {
        boolean retVal = true;
        try {
            stmt = myConn.createStatement();
            strSQL="select count(*) from OAM_RM_CLIENTS where ClientName=" +SQLEncode(ClientName);
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            if(myRS.getInt(1)>0)
                 retVal = false;
        } catch (SQLException e) {
            System.out.println("Exception occurs"+e.getMessage());
            retVal = false;
        }
        catch (Exception e) {
            System.out.println("Exception occurs"+e.getMessage());
            retVal = false;
        }
        return (retVal);
    }
    public boolean insertClient() throws Exception {
        boolean retVal = true;
        String ClientID = "";
        int recCount = 0;
        PreparedStatement ps = null;
        String strSQL1 = "";
        Statement st = null;
        ClientID=  "";//getMaxID("OAM_RM_CLIENTS");
        System.out.println("Inside save");
        //System.out.println(this.ClientStartDate);
        
        
       // strSQL = "insert into  OAM_RM_CLIENTS (ClientID,ClientName,ClientFromDate,StreetAddress, City, ZipCode, ContactPerson,EMail, Phone, Comment) values(,?,?,?,?,?,?,?,?,?) "; //password=pwdencrypt(?)
        strSQL = "insert into  OAM_RM_CLIENTS (ClientID,ClientName,ClientFromDate,StreetAddress, City, ZipCode, ContactPerson,EMail, Phone,clusterlead, Comments) values ("+
                SQLEncode(ClientID)+","+
                SQLEncode(this.ClientName)+","+
                "to_date("+SQLEncode(this.ClientStartDate)+",'mm/dd/yyyy')"+","+
                SQLEncode(this.ClientAddress)+","+
                SQLEncode(this.ClientCity)+","+
                SQLEncode(this.ClientZipCode)+","+
                SQLEncode(this.ClientContact)+","+
                SQLEncode(this.ClientEmail)+","+
                SQLEncode(this.ClientPhone)+","+
                SQLEncode(this.ClusterLead)+","+
                SQLEncode(this.ClientComments)+")";
              
        //System.out.println(strSQL);
        try {
            /*
            myPS = myConn.prepareStatement(strSQL);
            myPS.setString(1, "");
            myPS.setString(2, this.ClientName);
            myPS.setDate(3, (Date)this.ClientStartDate.);
            myPS.setString(4, this.ClientAddress);
            myPS.setString(5, this.ClientCity);
            myPS.setString(6, this.ClientZipCode);
            myPS.setString(7, this.ClientContact);
            myPS.setString(8, this.ClientEmail);
            myPS.setString(9, this.ClientPhone);
            myPS.setString(10, this.ClientComments);
            strSQL1 = " select * from OAM_RM_CLIENTS where ClientName= '" + ClientName + "'";
            st = myConn.createStatement();
            recCount = myPS.executeUpdate();
            */
            st=myConn.createStatement();
            recCount=stmt.executeUpdate(strSQL);
             retVal=true;

        }
        catch (SQLException e) {
            System.out.print("@@@@@@@@@@"+e.toString());
        }
        /*try{
            String newClientID=  getMaxID("OAM_RM_CLIENTS");
            System.out.print("newClientID>>>>>>>>>"+newClientID);
            String strSQL2 = " update OAM_RM_CLIENTS set ClientID='"+newClientID+"' where ClientName = " + SQLEncode(ClientName);
            st.execute(strSQL2);
            retVal=true;
        }catch (SQLException e) {
            st.close();
            System.out.print("@@@@@@@@@@"+e.toString());
            throw new Exception("" + e);
        }*/
        return retVal;
    }
    public boolean updateClient(String ClientID) throws Exception {
        boolean retVal = true;
        int recCount=0;

        //System.out.println(this.ClientStartDate);
        
        Statement st = null;
        strSQL = "UPDATE OAM_RM_CLIENTS set"+
                " ClientName="+ SQLEncode(this.ClientName)+","+                
                " ClientFromDate="+ "to_date("+SQLEncode(this.ClientStartDate)+",'mm/dd/yyyy')"+","+
                " StreetAddress="+SQLEncode(this.ClientAddress)+","+
                " City="+ SQLEncode(this.ClientCity)+","+
                " ZipCode="+SQLEncode(this.ClientZipCode)+","+
                " ContactPerson= "+SQLEncode(this.ClientContact)+","+
                " EMail="+SQLEncode(this.ClientEmail)+","+
                " Phone="+SQLEncode(this.ClientPhone)+","+
                " clusterlead="+ SQLEncode(this.ClusterLead)+","+      
                " Comments="+SQLEncode(this.ClientComments)+"" +
                " Where ClientID="+SQLEncode(ClientID,1)+"";
        
        try {
            st=myConn.createStatement();
            st.execute(strSQL);
            retVal=true;
        }
        catch (SQLException e) {
            System.out.print("@@@@@@@@@@"+e.toString());
        }
        return retVal;
    }

    public void deleteClient(String ClientID) {
        String strSQL = "delete from OAM_RM_CLIENTS where ClientID =" + SQLEncode(ClientID,1) ;
        try {

            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
        }
    }
   /*public String getMaxID(String TableName){

    String s="";
	try{
		Statement stmnt=myConn.createStatement();
		ResultSet rs=stmnt.executeQuery("SELECT nvl(MAX(PKSource)+1,1) AS MaxID FROM "+TableName+"");
		while(rs.next()){
			s=rs.getString("MaxID");
            if(s.length()<=1){ s="00"+s;}
            else if (s.length()==2){ s="0"+s;}

		}
	}

	catch (Exception e){
		errorStr=" ERROR GETTING MAXIMUM ID : "+e.toString();
	}
   return s;
  } */

}