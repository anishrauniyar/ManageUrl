package com.d2hs.soam.pm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.directwebremoting.util.Logger;

import com.d2hawkeye.util.Constants;
import com.d2hs.soam.RequestBean;

public class ProjectTemplateManager extends RequestBean {
	private static Logger logger = Logger
			.getLogger(ProjectTemplateManager.class);
	private String strFilters = "";

	/**
	 * @Description : Filter for Project Templates
	 * @param fTemplateId
	 * @param fTemplateName
	 * @param fTemplateDesc
	 * @param fIssueTypeId
	 * @param fIssueTypeName
	 */
	public void filterProjectTemplates(String fTemplateId,
			String fTemplateName, String fTemplateDesc, String fIssueTypeId,
			String fIssueTypeName) {
		if (!fTemplateId.equals("")) {
			strFilters += " AND a.templateid LIKE '%"
					+ fTemplateId.replaceAll("'", "''").trim() + "%'";
		}
		if (!fTemplateName.equals("")) {
			strFilters += " AND lower(a.templatename) LIKE lower('%"
					+ fTemplateName.replaceAll("'", "''").trim() + "%')";
		}
		if (!fTemplateDesc.equals("")) {
			strFilters += " AND lower(a.description) LIKE lower('%"
					+ fTemplateDesc.replaceAll("'", "''").trim() + "%')";
		}
		if (!fIssueTypeName.equals("")) {
			strFilters += " AND lower(c.issuetypename) LIKE lower('%"
					+ fIssueTypeName.replaceAll("'", "''").trim() + "%')";
		}
	}
	
	public void setProjectTempId(String fTemplateId){
		if (!fTemplateId.equals("")) {
			strFilters += " AND a.templateid LIKE '"
					+ fTemplateId.replaceAll("'", "''").trim() + "'";
		}
	}

	/**
	 * @Description : Returns Project Templates with Issue Types
	 * @return
	 */
	public boolean getProjectTemplatesWithRequestType() {
		boolean result = false;
		strSQL = "" + "SELECT a.templateid, " + "       a.templatename, "
				+ "       a.description, " + "       b.issuetypeid, "
				+ "       c.issuetypename " + "FROM   "
				+ Constants.OAM_CR_PROJ_TEMP + " a "
				+ "       left join " + Constants.OAM_CR_PROJ_TEMP_ISSUETYPE
				+ " b " + "              ON a.templateid = b.templateid "
				+ "       left join " + Constants.OAM_CR_ISSUETYPE + " c "
				+ "              ON b.issuetypeid = c.issuetypeid "
				+ "WHERE  1 = 1 ";

		strSQL += strFilters;
		strSQL += " order by templateid";
		logger.info("Query to getProjectTemplatesWithRequestType " + strSQL);
		try {
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (SQLException e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getProjectTemplatesWithRequestType()<- "
							+ strSQL, e);
		}
		return result;
	}

	/**
	 * @Description : Gets list of projects that are not assigned to any project
	 *              templates
	 * @param templateId
	 * @return
	 */
	public boolean getNotAssignedProjectListForTemplate(String templateId) {
		boolean result = false;
		strSQL = "" + "SELECT a.projectid, " + "       a.projectname "
				+ "FROM   " + Constants.OAM_CR_PROJECTS + " a ";
		if (templateId != "") {
			strSQL += " WHERE  a.projectId NOT IN (SELECT b.projectId "
					+ " FROM   " + Constants.OAM_CR_PROJ_TEMP_REL + " b "
					+ "  WHERE  b.templateid = " + templateId + ")";
		}
		logger.info("Query to get assigned phase list for template is >>>>"
				+ strSQL);

		try {
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getNotAssignedProjectListForTemplate("
							+ templateId + ")<- " + strSQL, e);

		}
		return result;
	}

	/**
	 * @Description : Gets projects for the given template
	 * @param templateId
	 * @return
	 */
	public boolean getAssignedProjectListForTemplate(String templateId) {
		boolean result = false;
		strSQL = "" + "SELECT a.projectid, " + "       b.projectname "
				+ "FROM   " + Constants.OAM_CR_PROJ_TEMP_REL + " a "
				+ "       left join " + Constants.OAM_CR_PROJECTS + " b "
				+ "              ON a.projectid = b.projectid "
				+ "WHERE  a.templateid = " + templateId + " "
				+ "ORDER  BY a.projectorder ";
		try {
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getAssignedProjectListForTemplate("
							+ templateId + ")<- " + strSQL, e);
		}
		return result;
	}

	public boolean getIssueTypes() {
		boolean result = false;
		strSQL = "select * from " + Constants.OAM_CR_ISSUETYPE
				+ " where 1=1 order by ISSUETYPEID";
		try {
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out
					.println("\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getIssueType()<- "
							+ strSQL);
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * @Description : Adds project templates with projects and issue type
	 * @param templateName
	 * @param templateDesc
	 * @param projectIdList
	 * @param issueTypeId
	 * @param userId
	 * @return
	 */
	public String addTemplateAndProjectsWithIssueType(String templateName,
			String templateDesc, String[] projectIdList, String issueTypeId,
			String userId) {
		String isInserted = "false";
		String templateId = "";
		try {

			if (checkProjectTemplateForIssueType(issueTypeId)) {
				isInserted = "templateExists";
				return isInserted;
			}
			if (checkProjectTemplateName(templateName)) {
				isInserted = "templateNameExists";
				return isInserted;
			}

			addProjectTemplate(templateName, templateDesc, userId);
			templateId = getTemplateId(templateName);
			insertProjectsIntoTemplate(templateId, projectIdList);
			insertProjectTemplateForIssueType(templateId, issueTypeId);
			isInserted = "true";
		} catch (SQLException e) {
			deleteProjectTemplate(templateName);
			logger.error(
					"\nError:[default-war/com/d2hs/soam/pm/TemplateManager.java]->addTemplateAndProjectsWithIssueType()<- "
							+ strSQL, e);
		}

		return isInserted;
	}

	/**
	 * @Description : Checking is a Issue Type is alread
	 * @param issueTypeId
	 * @return
	 * @throws SQLException
	 */
	public boolean checkProjectTemplateForIssueType(String issueTypeId)
			throws SQLException {
		boolean templateFound = false;
		strSQL = "Select count(*) n from "
				+ Constants.OAM_CR_PROJ_TEMP_ISSUETYPE
				+ " where issueTypeId = " + issueTypeId + "";

		stmt = myConn.createStatement();
		myRS = stmt.executeQuery(strSQL);
		myRS.next();
		int count = Integer.parseInt(myRS.getString("n".trim()));
		if (count > 0) {
			templateFound = true;
		}
		closeStatement(stmt);
		return templateFound;
	}

	/**
	 * @Description : Checking is same template name already exists
	 * @param templateName
	 * @return
	 * @throws SQLException
	 */
	public boolean checkProjectTemplateName(String templateName)
			throws SQLException {
		boolean isInserted = false;
		strSQL = "Select count(*) n from " + Constants.OAM_CR_PROJ_TEMP
				+ " where upper(templatename) like '"
				+ templateName.toUpperCase() + "' ";

		stmt = myConn.createStatement();
		myRS = stmt.executeQuery(strSQL);
		myRS.next();
		int count = Integer.parseInt(myRS.getString("n".trim()));
		if (count > 0) {
			isInserted = true;
		}
		closeStatement(stmt);
		return isInserted;
	}

	/**
	 * @Description : Adds template information
	 * @param templateName
	 * @param templateDesc
	 * @param userId
	 * @throws SQLException
	 */
	public void addProjectTemplate(String templateName, String templateDesc,
			String userId) throws SQLException {
		strSQL = "insert into " + Constants.OAM_CR_PROJ_TEMP
				+ " (templatename,description,createdby,createdon,isdeleted)"
				+ " VALUES (" + SQLEncode(templateName) + ","
				+ SQLEncode(templateDesc) + "," + "'" + userId + "',"
				+ "sysdate" + "," + "'N'" + " )";
		stmt = myConn.createStatement();
		stmt.execute(strSQL);
		closeStatement(stmt);
	}

	/**
	 * @Description : Returns template id for the given template name
	 * @param templateName
	 * @return
	 * @throws SQLException
	 */
	public String getTemplateId(String templateName) throws SQLException {
		String templateId = "0";
		strSQL = "select templateId from " + Constants.OAM_CR_PROJ_TEMP
				+ " where upper(templatename) = '" + templateName.toUpperCase()
				+ "'";
		stmt = myConn.createStatement();

		myRS = stmt.executeQuery(strSQL);
		myRS.next();

		templateId = myRS.getString("templateId");
		closeStatement(stmt);
		return templateId;
	}

	/**
	 * @Description : Inserts template and issue type info
	 * @param templateID
	 * @param issueTypeId
	 * @throws SQLException
	 */
	public void insertProjectTemplateForIssueType(String templateID,
			String issueTypeId) throws SQLException {
		strSQL = "INSERT INTO " + Constants.OAM_CR_PROJ_TEMP_ISSUETYPE
				+ " (TEMPLATEID,ISSUETYPEID) VALUES (" + templateID + ","
				+ issueTypeId + ")";
		stmt = myConn.createStatement();
		stmt.execute(strSQL);
		closeStatement(stmt);
	}

	/**
	 * @Desription : Deletes project template for the given template name
	 * @param templateName
	 */
	public void deleteProjectTemplate(String templateName) {
		String query = "delete " + Constants.OAM_CR_PROJ_TEMP
				+ " where upper(templatename) = '" + templateName.toUpperCase()
				+ "' ";
		try {
			stmt = myConn.createStatement();
			stmt.execute(query);
		} catch (SQLException e) {
			logger.error(
					"[ProjectTemplateManager->deleteProjectTemplate] Could not delete project template "
							+ templateName + "-> " + query, e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					logger.error(
							"[ProjectTemplateManager->deleteProjectTemplate] Error closing statement!!!!",
							e);
				}
			}
		}

	}

	/**
	 * @Description : Updates project templates and projects
	 * @param templateId
	 * @param templateName
	 * @param templateDesc
	 * @param phaseIdList
	 * @return
	 */
	public boolean updateTemplateAndProjects(String templateId,
			String templateName, String templateDesc, String[] projectIdList) {
		boolean isUpdated = false;
		try {
			updateProjectTemplate(templateId, templateName, templateDesc);
			deleteProjectsFromTemplate(templateId);
			insertProjectsIntoTemplate(templateId, projectIdList);
			isUpdated = true;
		} catch (SQLException e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/pm/TemplateManager.java]->"
							+ "updateTemplateAndPhases(" + templateId + ","
							+ templateName + "," + templateDesc + ","
							+ projectIdList.length + ")<- " + strSQL, e);
		}

		return isUpdated;
	}

	/**
	 * @Description : Updates project template info
	 * @param templateId
	 * @param templateName
	 * @param templateDesc
	 * @throws SQLException
	 */
	public void updateProjectTemplate(String templateId, String templateName,
			String templateDesc) throws SQLException {
		strSQL = "UPDATE " + Constants.OAM_CR_PROJ_TEMP
				+ " SET TEMPLATENAME = " + SQLEncode(templateName)
				+ ", DESCRIPTION = " + SQLEncode(templateDesc)
				+ " WHERE TEMPLATEID = " + templateId + "";
		Statement stmnt = myConn.createStatement();
		stmnt.execute(strSQL);
	}

	/**
	 * @Description : Deletes projects from given template
	 * @param templateId
	 * @throws SQLException
	 */
	public void deleteProjectsFromTemplate(String templateId)
			throws SQLException {
		strSQL = "DELETE FROM " + Constants.OAM_CR_PROJ_TEMP_REL
				+ " WHERE TEMPLATEID = " + templateId + "";
		stmt = myConn.createStatement();
		stmt.execute(strSQL);
		closeStatement(stmt);
	}

	/**
	 * @Description : Inserts projects for the give template
	 * @param templateId
	 * @param phaseIdList
	 * @throws SQLException
	 */
	public void insertProjectsIntoTemplate(String templateId,
			String[] projectIdList) throws SQLException {
		stmt = myConn.createStatement();
		for (int i = 0; i < projectIdList.length; i++) {
			strSQL = " INSERT INTO " + Constants.OAM_CR_PROJ_TEMP_REL
					+ " (TEMPLATEID,PROJECTID,PROJECTORDER) " + " VALUES ("
					+ templateId + "," + projectIdList[i] + "," + (i + 1) + ")";
			stmt.addBatch(strSQL);
		}
		stmt.executeBatch();
		closeStatement(stmt);
	}

	public void closeStatement(Statement stmt) throws SQLException {
		if (stmt != null) {
			stmt.close();
		}
	}
}
