package com.d2hs.soam.data;

public class ProductionIntegrationCode {

    private String requestCode;
    private String accountManager;
    private String bussinessManager;
    private String wathamPM;
    private String nepalPM;
    private String clusterLead;
    private String requestDesc;
    private String impICETicketNum;
    private String processingMonth;
    private String handOverDate;
    //private String appReleasesToClientDate;
    private String accStrDetailsIncluded;
    private String addtionalComments;
    private String approvedBy;
    //private String remarks;
    private String targetCompDate;
    private String actualCompDate;
    private String approvedDate;

    public String getRequestCode() {
        return requestCode;
    }

    public void setRequestCode(String requestCode) {
        this.requestCode = requestCode;
    }

    public String getAccountManager() {
        return accountManager;
    }

    public void setAccountManager(String accountManager) {
        this.accountManager = accountManager;
    }

    public String getBussinessManager() {
        return bussinessManager;
    }

    public void setBussinessManager(String bussinessManager) {
        this.bussinessManager = bussinessManager;
    }

    public String getWathamPM() {
        return wathamPM;
    }

    public void setWathamPM(String wathamPM) {
        this.wathamPM = wathamPM;
    }

    public String getNepalPM() {
        return nepalPM;
    }

    public void setNepalPM(String nepalPM) {
        this.nepalPM = nepalPM;
    }

    public String getClusterLead() {
        return clusterLead;
    }

    public void setClusterLead(String clusterLead) {
        this.clusterLead = clusterLead;
    }

    public String getRequestDesc() {
        return requestDesc;
    }

    public void setRequestDesc(String requestDesc) {
        this.requestDesc = requestDesc;
    }

    public String getImpICETicketNum() {
        return impICETicketNum;
    }

    public void setImpICETicketNum(String impICETicketNum) {
        this.impICETicketNum = impICETicketNum;
    }

    public String getProcessingMonth() {
        return processingMonth;
    }

    public void setProcessingMonth(String processingMonth) {
        this.processingMonth = processingMonth;
    }

    public String getHandOverDate() {
        return handOverDate;
    }

    public void setHandOverDate(String handOverDate) {
        this.handOverDate = handOverDate;
    }

    /*public String getAppReleasesToClientDate() {
     return appReleasesToClientDate;
     }

     public void setAppReleasesToClientDate(String appReleasesToClientDate) {
     this.appReleasesToClientDate = appReleasesToClientDate;
     }
     */
    public String getAccStrDetailsIncluded() {
        return accStrDetailsIncluded;
    }

    public void setAccStrDetailsIncluded(String accStrDetailsIncluded) {
        this.accStrDetailsIncluded = accStrDetailsIncluded;
    }

    public String getAddtionalComments() {
        return addtionalComments;
    }

    public void setAddtionalComments(String addtionalComments) {
        this.addtionalComments = addtionalComments;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    /*public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
*/
    public String getTargetCompDate() {
        return targetCompDate;
    }

    public void setTargetCompDate(String targetCompDate) {
        this.targetCompDate = targetCompDate;
    }

    public String getActualCompDate() {
        return actualCompDate;
    }

    public void setActualCompDate(String actualCompDate) {
        this.actualCompDate = actualCompDate;
    }

    public String getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(String approvedDate) {
        this.approvedDate = approvedDate;
    }

    public void convertCodedInfo(ProductionIntegrationCode pic) {
        if (pic.accStrDetailsIncluded != null) {
            pic.accStrDetailsIncluded = pic.accStrDetailsIncluded.equalsIgnoreCase("1") ? "Yes" : "No";
        }
    }

}
