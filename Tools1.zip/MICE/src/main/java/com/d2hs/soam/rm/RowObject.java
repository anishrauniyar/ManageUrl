package com.d2hs.soam.rm;


public class RowObject {

    private String labelName="";
    private String columnName="";
    private int filterValue=0;
    private String sortValue="";

    private int columnType=1;//default String

    public RowObject(){

    }

    public void setLabelName(String val){
        this.labelName=val;
    }
    public String getLabelName(){
        return this.labelName;
    }

    public void setColumnName(String val){
        this.columnName=val;
    }
    public String getColumnName(){
        return this.columnName;
    }
    public void setFilterValue(int val){
        this.filterValue=val;
    }
    public int getFilterValue(){
        return this.filterValue;
    }
    public void setSortValue(String val){
        this.sortValue=val;
    }
    public String getSortValue(){
        return this.sortValue;
    }
    public void setColumnType(int val){
        this.columnType=val;
    }
    public int getColumnType(){
        return this.columnType;
    }

}
