package com.d2hs.soam.admin;

import com.d2hs.soam.ConnectionBean;
import com.d2hs.soam.RequestBean;
import com.d2hs.soam.conn.ConnectionParameters;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.d2hs.soam.conn.DBPoolManager;

public class Register extends RequestBean{

    public Register() {

     }

    public boolean checkValidDomain(String domain)
    {
     boolean result = false;

      strSQL = "select count(*) from ztbl_Domain where DomainName="+SQLEncode(domain);
       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.absolute(1);
                if(myRS.getInt(1)>0){
                    result=true;
                }

        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
  }
    //Changed By:Raju Thapa Shrestha,Mar 5,2008
    //Changes   :add method to get domain information for SSO intregation with OAM
    public boolean getDomains()
    {
     boolean result = false;

      strSQL = "select DomainID,DomainName,DomainLevel from ztbl_Domain where 1=1";
       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);            
                   result=true;
                
             

        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
  }
    //Changed By:Raju Thapa Shrestha,Mar 12,2008
    //Changes   :add method to check whether it is Non-Service Client Domain
    public boolean getNonServicesDomain(String NonServicesDomainID){
        boolean doesExist=false;
        strSQL="Select count(*) from ztbl_NonServicesDomain where DomainID ='" +NonServicesDomainID+"'";        
        try{
        	Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            myRS.absolute(1);
            if(myRS.getInt(1)>0){
                doesExist=true; 
            }
        }
        catch (Exception e) {
        	System.out.print("error"+e.getMessage());
        }
        return doesExist;
        }
    //Changed By:Raju Thapa Shrestha,Mar 5,2008
    //Changes   :add method to check whether user exits in domain for SSO intregation with OAM
    public boolean userExist(String loginname)
    {
     boolean doesExist = false;

      strSQL = "select count(*) from usr_Users where LoginName="+SQLEncode(loginname);
      
       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.absolute(1);
                if(myRS.getInt(1)>0){
                    doesExist=true;           
    	   	}   

        }
        catch(Exception e){
        	e.printStackTrace();
            System.out.print("error userExist"+e.getMessage());
        }
      return doesExist;
  }
  public boolean checkValidUser(String UserID, String LoginName, String Password){

	  boolean result = false;
   
      strSQL = "select count(*) from USR_USERS where UPPER(LoginName) =UPPER(?) "
	    + "and D2Pwd = return_hash('"+LoginName+"'||'"+Password+"','90A80378D3A539BD')";
         try
        {
              	PreparedStatement pstmt = this.myConn.prepareStatement(strSQL);
              	pstmt.setString(1, LoginName);
              	this.myRS = pstmt.executeQuery();
                  
              	if(this.moveNext()){
	                if(myRS.getInt(1)>0){
	                    result=true;
	                }
              	}
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
  } 
   public void setConnectionParameters(String DomainID){

       //System.out.println("From setConnectionParameters");
       DBPoolManager dbpm = DBPoolManager.getInstance();

       if(!dbpm.hasAlias(DomainID)) //Check if this domain already exists in connectionProperties map
       // Add it to the connectionProperties map
       {
           ConnectionParameters conParam = new ConnectionParameters();

           try{
               getConnectionParameters(DomainID);
               String dbServer = myRS.getString("DatabaseServer");
               String database = myRS.getString("DatabaseName");
               String dbUser = myRS.getString("DatabaseUserName");
               String dbPassword = myRS.getString("Password");

               String maxConn = myRS.getString("maxConn");
               String initSize = myRS.getString("initSize");
               String idleTimeOut = myRS.getString("idleTimeOut");
               String chkOutTimeOut = myRS.getString("checkoutTimeout");
               String maxChkOutTime = myRS.getString("maxCheckout");

               dbConnURL	= "jdbc:inetdae7:"
                                        + dbServer + ":1433?database=" + database;

               conParam.setDriver("com.inet.tds.TdsDriver");
               conParam.setUrl(dbConnURL);
               conParam.setUserName(dbUser);
               conParam.setPassword(dbPassword);
               conParam.setMaxConnection(maxConn);
               conParam.setInitialSize(initSize);
               conParam.setIdleTimeOut(idleTimeOut);
               conParam.setCheckOutTimeOut(chkOutTimeOut);
               conParam.setMaxCheckOutTime(maxChkOutTime);
               //DBPoolManager dbpm = DBPoolManager.getInstance();
               dbpm.addToConnectionProperties(DomainID, conParam);
               System.out.println("Trying to call addToConnectionProperties");
               //setDatabaseDetails(Server,Database,DatabaseUser,DatabasePassword);


           }catch(Exception e){

               System.out.println(e.getMessage());
           }
       }

    }
    public boolean getConnectionParameters(String DomainID){
       boolean result = false;

       strSQL = "select a.DatabaseServer, a.DatabaseName, a.DatabaseUserName, a.DataBasePassword as Password, b.initSize, b.maxConn, b.idleTimeOut, b.checkoutTimeout, b.maxCheckout from ztbl_Domain a, tbl_ConnectionParameters b where a.DomainID = b.DomainID and a.DomainID="+SQLEncode(DomainID);
       try
        {
               Statement stmt=myConn.createStatement();
               myRS=stmt.executeQuery(strSQL);
               myRS.next();
               result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
    }

   public boolean getSuperDBInfo(){
       boolean result = false;

       strSQL = "SELECT * FROM ztbl_Domain WHERE DomainLevel = 0 ";
       try
        {
               Statement stmt=myConn.createStatement();
               myRS=stmt.executeQuery(strSQL);
               myRS.next();
               result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }
    public boolean getDomainDetails(String DomainID){
      boolean result = false;
      strSQL = "select * from ztbl_Domain where DomainID="+SQLEncode(DomainID);
      try      {
                Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.next();
                result=true;
      }
        catch(Exception e){
            System.out.print("\nERROR "+e.toString()+"\n"+strSQL);
        }
      return result;

   }


}
