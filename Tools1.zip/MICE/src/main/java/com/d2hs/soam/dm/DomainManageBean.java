package com.d2hs.soam.dm;

import com.d2hs.soam.RequestBean;
import com.d2hs.soam.BaseBean;

import java.sql.*;

import com.d2hs.soam.RequestBean;
import com.d2hs.soam.common.TextEncoder;

   public class DomainManageBean extends RequestBean{

    protected String orderField	= "DomainName";
	protected String order		= "ASC";
	protected String strFilters	= "";

    public DomainManageBean(){

    }
    public String getOrderField() {
       return orderField;
    }

    public void setOrderField(String orderField) {
       this.orderField = orderField;
    }
    public String getOrder() {
       return order;
    }
    public void setOrder(String order) {
       this.order = order;
    }
    public void setDomainFilter(String fDomainName, String fContact, String fEmail){
       if(!fDomainName.equals("")){
	    	strFilters	+= " AND DomainName LIKE '%" + fDomainName.replaceAll("'","''").trim() + "%'";
	   }
       if(!fContact.equals("")){
	    	strFilters	+= " AND DomainContact LIKE '%" + fContact.replaceAll("'","''").trim() + "%'";
	   }
       if(!fEmail.equals("")){
	    	strFilters	+= " AND DomainEmail LIKE '%" + fEmail.replaceAll("'","''").trim() + "%'";
	   }
   }
   public boolean getAllDomains(String DomainID){

      boolean result = false;

      strSQL = "select * from ztbl_Domain where 1=1";

      if(!DomainID.equals("0")){
          strSQL=strSQL + "and DomainID="+SQLEncode(DomainID);
      }
      strSQL+=strFilters;
      strSQL+=" ORDER BY "+orderField+" "+order+"";

      try
        {
                Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.print("Exception error"+e.getMessage());
        }
      return result;

   }
    public boolean getDomainDetails(String DomainID){
      boolean result = false;
      strSQL = "select * from ztbl_Domain where DomainID="+SQLEncode(DomainID);
      try      {
                Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
      }
        catch(Exception e){
            System.out.print("\nERROR "+e.toString()+"\n"+strSQL);
        }
      return result;

   }
    public boolean createDataBase(String DataBaseName){

      boolean result = false;

      strSQL = "CREATE DATABASE'"+DataBaseName+"'";

      try
        {
               Statement stmt=myConn.createStatement();
               stmt.executeUpdate(strSQL);
               result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;

   }
       public boolean deleteDomain(String DomainID){
            return addEditDomainDetail(DomainID,"","","","","","","","","","","D");
       }

       public boolean addEditDomainDetail(String DomainID, String DomainName, String DomainLevel, String DatabaseServer,
                                      String DomainDatabase, String DatabaseUser, String DatabasePassword,
                                      String DomainDescription, String DomainContact, String DomainEmail, String DomainLogo, String AddEditDelete ){
           boolean result = false;
           try{
                Statement stmt=myConn.createStatement();
                strSQL = "sp_AddEditDeleteDomain " +
                            SQLEncode(DomainID) + "," +
                            SQLEncode(DomainName) + "," +
                            SQLEncode(DomainLevel,1) + "," +
                            SQLEncode(DatabaseServer) + "," +
                            SQLEncode(DomainDatabase) + "," +
                            SQLEncode(DatabaseUser) + "," +
                            SQLEncode(DatabasePassword) + "," +
                            SQLEncode(DomainDescription) + "," +
                            SQLEncode(DomainContact) + "," +
                            SQLEncode(DomainEmail) + "," +
                            SQLEncode(DomainLogo) + "," +
                            SQLEncode(AddEditDelete) ;
                System.out.println(strSQL);
                stmt.execute(strSQL);
               result=true;

               //NEW: INSERTING VALUES ONLY, WHILE TABLE ALREADY EXISTS IN MAIN DOMAIN.
               if(AddEditDelete.equalsIgnoreCase("I") && result)
               {
                   strSQL = "INSERT INTO tbl_ConnectionParameters (DomainID)  Select DomainID from ztbl_Domain where SeedDomainID = (Select MAX (SeedDomainID) from ztbl_Domain)";
                   stmt.executeUpdate(strSQL);
               }


           }
           catch(Exception e){e.printStackTrace();}
           return result;
       }

       public boolean removeDomainLogo(String DomainID){
           boolean result = false;
           try{
                Statement stmt=myConn.createStatement();
                strSQL = "UPDATE ztbl_Domain SET DomainLogo = NULL WHERE DomainID = " +
                            SQLEncode(DomainID) ;
                stmt.executeUpdate(strSQL);
                result=true;
           }
           catch(Exception e){}
           return result;
       }

    public boolean addDomainDetail_Old(String DomainID, String DomainName, String DomainLevel, String DatabaseServer,
                                   String DomainDatabase, String DatabaseUser, String DatabasePassword,
                                   String DomainDescription, String DomainContact, String DomainEmail, byte[] Logo ){

      boolean result = false;
      try
        {
               //Statement stmt=myConn.createStatement();
               //stmt.executeUpdate(strSQL);

                Statement stmnt=myConn.createStatement(ResultSet.TYPE_FORWARD_ONLY ,ResultSet.CONCUR_UPDATABLE);
                //ResultSet rsupd = stmnt.executeQuery("SELECT * FROM ztbl_Domain WHERE DomainID='" + (DomainID.equals("")?"":DomainID) + "'");
                ResultSet rsupd = stmnt.executeQuery("SELECT TOP 1 * FROM ztbl_Domain ");
                rsupd.moveToInsertRow();
                rsupd.updateString("DomainID",DomainID);
                rsupd.updateString("DomainName",DomainName);
                rsupd.updateInt("DomainLevel",1);
                rsupd.updateDate("CreatedDate",new java.sql.Date(System.currentTimeMillis()));
                rsupd.updateString("DatabaseServer",DatabaseServer);
                rsupd.updateString("DatabaseName",DomainDatabase);
                rsupd.updateString("DatabaseUserName",DatabaseUser);
                rsupd.updateString("DatabasePassword",DatabasePassword);
                rsupd.updateString("DomainDescription",DomainDescription);
                rsupd.updateString("DomainContact",DomainContact);
                rsupd.updateString("DomainEmail",DomainEmail);
                rsupd.updateBytes("DomainLogo",Logo);

		        rsupd.insertRow();
		        rsupd.moveToCurrentRow();
		        rsupd.close();
                result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }

    protected Connection mytempConn;
    public boolean checkDatabase(String ServerName,String DatabaseName,String UserName,String pwd) throws Exception
    {
        boolean retVal=false;
        String database="master";
        //Class.forName("macromedia.jdbc.MacromediaDriver");
        //String connectionURL = "jdbc:macromedia:sqlserver://"
        // + ServerName + ":1433;User=" + UserName + ";Password="
        //+ pwd + ";DatabaseName=" + database;
        //mytempConn = DriverManager.getConnection(connectionURL);
        Class.forName("com.inet.tds.TdsDriver");
        String connectionURL="jdbc:inetdae7:"
                               + ServerName +":1433?database= "+ DatabaseName;
		mytempConn = DriverManager.getConnection ( connectionURL,UserName,pwd);
        strSQL="select * from master.dbo.sysdatabases Where name='"+DatabaseName +"'";
        try{
        stmt=mytempConn.createStatement();
        myRS=stmt.executeQuery(strSQL);
        if(myRS.next())
         retVal=true;
        }catch(SQLException se){mess=se.getMessage();}
        mess="ok";
        mytempConn.close();
        return retVal;
   }
    public boolean checkServer(String ServerName,String UserName,String pwd) throws Exception
    {
        boolean retVal=false;
        String database="master";
       // Class.forName("macromedia.jdbc.MacromediaDriver");
        //String connectionURL = "jdbc:macromedia:sqlserver://"
        //+ ServerName + ":1433;User=" + UserName + ";Password="
        //+ pwd + ";DatabaseName=master";
        //mytempConn = DriverManager.getConnection(connectionURL);
        Class.forName("com.inet.tds.TdsDriver");
        String connectionURL="jdbc:inetdae7:"
                               + ServerName +":1433?database="+ database;
        System.out.print("connection"+connectionURL);
        System.out.print("UserName"+UserName);
        System.out.print("pwd"+pwd);
		mytempConn = DriverManager.getConnection (connectionURL,UserName,pwd);
        strSQL="select * from master.dbo.sysdatabases Where name='master'";
        try{
        stmt=mytempConn.createStatement();
        myRS=stmt.executeQuery(strSQL);
        if(myRS.next())
         retVal=true;
        }catch(SQLException se){mess=se.getMessage();}
        mess="ok";
        mytempConn.close();
        return retVal;
   }
    public boolean createDatabase(String ServerName,String DatabaseName,String UserName,String pwd)
    {
        boolean retVal=false;
        try{

        //Class.forName("macromedia.jdbc.MacromediaDriver");
        //String connectionURL = "jdbc:macromedia:sqlserver://"
        //+ ServerName + ":1433;User=" + UserName + ";Password="
        //+ pwd + ";DatabaseName=master";
        //mytempConn = DriverManager.getConnection(connectionURL);
        Class.forName("com.inet.tds.TdsDriver");
        String connectionURL="jdbc:inetdae7:"
                               + ServerName +":1433?database=master ";
		mytempConn = DriverManager.getConnection ( connectionURL,UserName,pwd);
        strSQL="CREATE database "+  DatabaseName ;
        stmt=mytempConn.createStatement();
        int rows=stmt.executeUpdate(strSQL);
        retVal=true;
        mytempConn.close();
        }catch(SQLException se){mess=se.getMessage();} catch (ClassNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        return retVal;
    }
    public boolean createTables(String ServerName,String DatabaseName,String UserName,String pwd)
    {
        boolean retVal=false;
        try{
        System.out.println("Before creating tables....");
        //Class.forName("macromedia.jdbc.MacromediaDriver");
        //String connectionURL = "jdbc:macromedia:sqlserver://"
        //+ ServerName + ":1433;User=" + UserName + ";Password="
        //+ pwd + ";DatabaseName=" + DatabaseName;
            int rows = 0;
        //mytempConn = DriverManager.getConnection(connectionURL);
        Class.forName("com.inet.tds.TdsDriver");
        String connectionURL="jdbc:inetdae7:"
                               + ServerName +":1433?database="+DatabaseName;
		mytempConn = DriverManager.getConnection ( connectionURL,UserName,pwd);
        stmt=mytempConn.createStatement();
        strSQL=getTableCreationString1();//System.out.println("Table 1 " + strSQL);
       rows=stmt.executeUpdate(strSQL);
       strSQL=getTableCreationString2();//System.out.println("Table 2 " + strSQL);
       rows=stmt.executeUpdate(strSQL);
       strSQL=getTableCreationString3(); //System.out.println("Table 3 " + strSQL);
       rows=stmt.executeUpdate(strSQL);
       strSQL=getTableCreationString4();//System.out.println("Table 4 " + strSQL);
       rows=stmt.executeUpdate(strSQL);
       strSQL=getTableCreationString5(); //System.out.println("Table 5 " + strSQL);
       rows=stmt.executeUpdate(strSQL);
       strSQL = getTableCreationString6(); //System.out.println("Table 6 " + strSQL);
       rows=stmt.executeUpdate(strSQL);    
       strSQL=getTableCreationString7(); // System.out.println("Table 7"+strSQL);
       rows=stmt.executeUpdate(strSQL);
       strSQL=getAlterTableString();
       rows=stmt.executeUpdate(strSQL);
      // System.out.println("alter table successful.........................");
        strSQL=getStoredProcedureString();//System.out.println("Proc 1 " + strSQL);
        rows=stmt.executeUpdate(strSQL);
        strSQL=getStoredProcedureString1();//System.out.println("Proc 2 " + strSQL);
        rows=stmt.executeUpdate(strSQL);
        strSQL=getStoredProcedureString2();//System.out.println("Proc 3 " + strSQL);
        rows=stmt.executeUpdate(strSQL);
        strSQL=getStoredProcedureString3();//System.out.println("Proc 4 " + strSQL);
        rows=stmt.executeUpdate(strSQL);

        strSQL=getInsertString(); //System.out.println("Insert " + strSQL);
        rows=stmt.executeUpdate(strSQL);
        strSQL=getInsertString1(); //System.out.println("Insert 1 " + strSQL);
        rows=stmt.executeUpdate(strSQL);
        //System.out.println("After creating tables....");
        retVal=true;
        mytempConn.close();
        }catch(SQLException se){se.printStackTrace();}
        catch (ClassNotFoundException e) {
          e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
       }
        return retVal;
    }

     public String getTableCreationString1(){
        String tblString="";

         String usr_Users=" CREATE TABLE [dbo].[usr_Users] (\n" +
                 "\t[UserID] [nvarchar] (50) ,\n" +
                 "\t[SeedUserID] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                 "\t[UserName] [nvarchar] (50)  NOT NULL ,\n" +
                 "\t[LoginName] [nvarchar] (50)  NULL ,\n" +
                 "\t[Password] [sql_variant] NULL ,\n" +
                 "\t[Email] [nvarchar] (50)  NULL ,\n" +
                 "\t[Level] [nvarchar] (50)  NULL ,\n" +
                 "\t[ChangePassword] [char] (1)  NOT NULL ,\n" +
                 "\t[UserStatus] [int] NULL \n" +
                 ") \n" +
                 "\n ";

        String OAM_RM_CLIENTS="\n" +
                "CREATE TABLE [dbo].[OAM_RM_CLIENTS] (\n" +
                "\t[ClientID] [varchar] (15)  NULL ,\n" +
                "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[ClientName] [varchar] (50)  NULL ,\n" +
                "\t[ClientFromDate] [smalldatetime] NULL ,\n" +
                "\t[StreetAddress] [varchar] (50)  NULL ,\n" +
                "\t[City] [varchar] (50)  NULL ,\n" +
                "\t[ZipCode] [varchar] (15)  NULL ,\n" +
                "\t[ContactPerson] [varchar] (50)  NULL ,\n" +
                "\t[EMail] [varchar] (50)  NULL ,\n" +
                "\t[Phone] [varchar] (50)  NULL ,\n" +
                "\t[Comment] [varchar] (255)  NULL \n" +
                ") ON [PRIMARY]\n" +
                "\n";

        String  OAM_RM_REQUEST_PHASE="\nCREATE TABLE [dbo].[OAM_RM_REQUEST_PHASE] (\n" +
                "\t[RequestPhaseCode] [varchar] (15)  NULL ,\n" +
                "\t[RequestPhaseDesc] [varchar] (50)  NULL ,\n" +
                "\t[PhaseOrder] [int] NULL \n" +
                ")\n ";

        String OAM_RM_REQUESTSTATUS="\nCREATE TABLE [dbo].[OAM_RM_REQUESTSTATUS] (\n" +
                "\t[StatusID] [varchar] (15) ,\n" +
                "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[StatusDesc] [varchar] (50)  NULL \n" +
                ") \n" +
                "\n ";

         String OAM_RM_REQUEST_TYPES="\nCREATE TABLE [dbo].[OAM_RM_REQUEST_TYPES] (\n" +
                 "\t[RequestTypeCode] [varchar] (15)  NOT NULL ,\n" +
                 "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                 "\t[RequestTypeDesc] [varchar] (50)  NULL ,\n" +
                 "\t[ProductID] [varchar] (15)  NULL ,\n" +
                 "\t[UserID] [varchar] (15)  NULL \n" +
                 ")\n  ";
         
	     //Modified date: March 13, 2008
	  	 //By: Niranjan Thapa
	  	 //Changes: OAM_RM_REQUEST_SEVERITY added for Request Severity
         String tbl_RequestSeverity="\nCREATE TABLE [dbo].[OAM_RM_REQUEST_SEVERITY] (\n" +
	         	"\t[SeverityID] [varchar] (15) NULL ,\n"+
	         	"\t[SeverityDesc] [varchar] (50) NULL ,\n"+
	         	"\t[SeverityOrder] [int] NULL \n"+ 
	         	")\n  "; 

       String OAM_RM_PRODUCTVERSION="\nCREATE TABLE [dbo].[OAM_RM_PRODUCTVERSION] (\n" +
               "\t[ApplicationVersionCode] [varchar] (15)  ,\n" +
               "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
               "\t[VersionName] [varchar] (200)  NULL ,\n" +
               "\t[ApplicationVersionDesc] [varchar] (50)  NULL ,\n" +
               "\t[VersionOrder] [int] NULL ,\n" +
               "\t[Active_YN] [char] (1)  NOT NULL ,\n" +
               "\t[ProductID] [varchar] (50)  NULL ,\n" +
               ") \n" +
               "\n" +
               "";
        String OAM_RM_REQUESTMANAGER="\nCREATE TABLE [dbo].[OAM_RM_REQUESTMANAGER] (\n" +
                "\t[RequestCode] [varchar] (15) NOT NULL ,\n" +
                "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[RequestTypeCode] [varchar] (15) NULL ,\n" +
                "\t[RequestingPerson] [varchar] (15) NULL ,\n" +
                "\t[StatusID] [varchar] (15) NULL ,\n" +
                "\t[AssignedTo] [varchar] (15) NULL ,\n" +
                "\t[ApplicationVersionCode] [varchar] (15) NULL ,\n" +
                "\t[EnteredBy] [varchar] (15) NULL ,\n" +
                "\t[ClientID] [varchar] (15) NULL ,\n" +
                "\t[RequestDate] [smalldatetime] NULL ,\n" +
                "\t[Requests] [varchar] (3000) NULL ,\n" +
                "\t[UploadedDocName] [varchar] (100) NULL ,\n" +
                "\t[UploadedDoc] [image] NULL ,\n" +
                "\t[ActionTaken] [varchar] (3000) NULL ,\n" +
                "\t[TargetCompDate] [smalldatetime] NULL ,\n" +
                "\t[ActualCompDate] [smalldatetime] NULL ,\n" +
                "\t[EnteredDate] [datetime] NULL ,\n" +
                "\t[RequestPriority] [int] NULL ,\n" +
                "\t[isCompleted] [char] (1) NULL ,\n" +
                "\t[documentCount] [int] NULL ,\n" +
                "\t[parentRequestCode] [varchar] (15) NULL ,\n" +
                "\t[ExpectedCompDate] [datetime] NULL ,\n" +
                "\t[RequestPhase] [varchar] (15) NULL ,\n" +
                "\t[DevCompDate] [datetime] NULL ,\n" +
                "\t[ProductID] [varchar] (50) NULL ,\n" +
                "\t[FixedInVersion] [varchar] (50) NULL \n" +                
                ")\n " ;
         String tbl_RequestManager_pk="\nALTER TABLE [dbo].[OAM_RM_REQUESTMANAGER] ADD \n" +
                 "\tCONSTRAINT [PK_tbl_RequestManager] PRIMARY KEY  CLUSTERED \n" +
                 "\t(\n" +
                 "\t\t[RequestCode]\n" +
                 "\t)   ON [PRIMARY] " ;


       tblString=usr_Users+OAM_RM_CLIENTS+ OAM_RM_REQUEST_PHASE+OAM_RM_REQUESTSTATUS+
                 OAM_RM_REQUEST_TYPES+tbl_RequestSeverity+OAM_RM_PRODUCTVERSION+OAM_RM_REQUESTMANAGER+tbl_RequestManager_pk;

        return tblString;
    }
     public String getTableCreationString2(){
          String tblString="";
         String OAM_RM_REQUESTMOREINFO="\nCREATE TABLE [dbo].[OAM_RM_REQUESTMOREINFO] (\n" +
                "\t[InfoID] [varchar] (15)  ,\n" +
                "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[RequestCode] [varchar] (15)  NULL ,\n" +
                "\t[PostedBy] [varchar] (15)  NULL ,\n" +
                "\t[ReplyTo] [varchar] (15)  NULL ,\n" +
                "\t[PostedMsg] [text]  NULL ,\n" +
                "\t[PostedDate] [smalldatetime] NULL \n" +
                ")\n";

        String OAM_RM_DETAIL="\n CREATE TABLE [dbo].[OAM_RM_DETAIL] (\n" +
                "\t[RequestCode] [varchar] (15)  NOt NULL ,\n" +
                "\t[RequestTitle] [varchar] (120)  NULL ,\n" +
                "\t[SourceID] [int] NULL ,\n" +
                "\t[Benefits] [text]  NULL ,\n" +
                "\t[Assumptions_Dependencies] [text]  NULL \n" +
                ")\n";
         String tbl_RequestManager_Detail_pk="\nALTER TABLE [dbo].[OAM_RM_DETAIL] ADD \n" +
                 "\tCONSTRAINT [PK_tbl_RequestManager_Detail] PRIMARY KEY  CLUSTERED \n" +
                 "\t(\n" +
                 "\t\t[RequestCode]\n" +
                 "\t)  ON [PRIMARY] \n" ;

        String OAM_RM_ASSIGNEE="\nCREATE TABLE [dbo].[OAM_RM_ASSIGNEE] (\n" +
                "\t[RequestCode] [varchar] (15)  NOT NULL ,\n" +
                "\t[UserID] [varchar] (15)  NOT NULL \n" +
                ")\n ";
    tblString= OAM_RM_REQUESTMOREINFO+OAM_RM_DETAIL+tbl_RequestManager_Detail_pk+OAM_RM_ASSIGNEE;
    return tblString;
     }
       public String getTableCreationString4(){
          String tblString="";
        String OAM_RM_MOREDOCUMENT="\nCREATE TABLE [dbo].[OAM_RM_MOREDOCUMENT] (\n" +
                "\t[DocumentCode] [int] IDENTITY (1, 1)  NOT NULL ,\n" +
                "\t[RequestCode] [varchar] (15)  NULL ,\n" +
                "\t[UploadedDocName] [varchar] (100)  NULL ,\n" +
                "\t[UploadedDoc] [image] NULL ,\n" +
                "\t[UploadedBy] [varchar] (15)  NULL ,\n" +
                "\t[UploadedOn] [smalldatetime] NULL ,\n" +
                "\t[DocType] [varchar] (100)  NULL \n" +
                ") \n" +
                "\n";


        String OAM_RM_ARCHIVE="\n" +
                "CREATE TABLE [dbo].[OAM_RM_ARCHIVE] (\n" +
                "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[RequestCode] [varchar] (15)  NULL ,\n" +
                "\t[RequestTypeCode] [varchar] (15)  NULL ,\n" +
                "\t[RequestingPerson] [varchar] (15)  NULL ,\n" +
                "\t[StatusID] [varchar] (15)  NULL ,\n" +
                "\t[AssignedTo] [varchar] (15)  NULL ,\n" +
                "\t[ApplicationVersionCode] [varchar] (15)  NULL ,\n" +
                "\t[EnteredBy] [varchar] (15)  NULL ,\n" +
                "\t[ClientID] [varchar] (15)  NULL ,\n" +
                "\t[RequestDate] [smalldatetime] NULL ,\n" +
                "\t[Requests] [text]  NULL ,\n" +
                "\t[UploadedDocName] [varchar] (100)  NULL ,\n" +
                "\t[UploadedDoc] [image] NULL ,\n" +
                "\t[ActionTaken] [text]  NULL ,\n" +
                "\t[TargetCompDate] [smalldatetime] NULL ,\n" +
                "\t[ActualCompDate] [smalldatetime] NULL ,\n" +
                "\t[EnteredDate] [datetime] NULL ,\n" +
                "\t[RequestPriority] [int] NULL ,\n" +
                "\t[isCompleted] [char] (1)  NULL ,\n" +
                "\t[documentCount] [int] NULL ,\n" +
                "\t[parentRequestCode] [varchar] (15)  NULL ,\n" +
                "\t[ExpectedCompDate] [datetime] NULL ,\n" +
                "\t[RequestPhase] [varchar] (15)  NULL ,\n" +
                "\t[ArchiveDate] [datetime] NULL ,\n" +
                "\t[UpdatedBy] [nvarchar] (100)  NULL ,\n" +
                "\t[UpdatedDate] [datetime] NULL ,\n" +
                "\t[DevCompDate] [datetime] NULL \n" +            
                ") \n" +
                "\n" ;

 tblString= OAM_RM_MOREDOCUMENT+OAM_RM_ARCHIVE;
           return tblString;
     }
 public String getTableCreationString5(){
          String tblString="";
        String tbl_RequestManagerAppearance="\nCREATE TABLE [dbo].[tbl_RequestManagerGUI] (\n" +
                "\t[AppID] [numeric](10, 0) IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[DomainID] [varchar] (50)  NULL ,\n" +
                "\t[CSSFileName] [varchar] (50)  NULL ,\n" +
                "\t[LogoFileName] [varchar] (50)  NULL \n" +
                ") \n";


        String tbl_UserAndRequest= "\nCREATE TABLE [dbo].[TMP_OAM_RM_USER_PRODUCT] (\n" +
                "\t[URID] [numeric](18, 0) IDENTITY (1, 1)  NOT NULL ,\n" +
                "\t[UserID] [varchar] (15)  NULL ,\n" +
                "\t[ProductID] [varchar] (50)  NULL ,\n" +
                "\t[InSwitchBoard] [int] NULL \n" +
                ") \n" ;
       String OAM_RM_REQUEST_SOURCE="\nCREATE TABLE [dbo].[OAM_RM_REQUEST_SOURCE] (\n" +
               "\t[id] [int] IDENTITY (1, 1) NOT NULL ,\n" +
               "\t[Source] [varchar] (1000)  NULL \n" +
               ")\n ";

      String OAM_RM_MESSAGE_RECEIVER= "\nCREATE TABLE [dbo].[OAM_RM_MESSAGE_RECEIVER] (\n" +
              "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
              "\t[ClientID] [varchar] (20)  NULL ,\n" +
              "\t[UserID] [varchar] (15)  NULL ,\n" +
              "\t[MsgTriggeredFor] [smallint] NULL ,\n" +
              "\t[PhaseOrRequest] [char] (1)  NULL ,\n" +
              "\t[PhaseRequestType] [varchar] (15)  NULL ,\n" +
              "\t[ToCC] [char] (10)  NULL \n" +
              ")\n" ;
      String OAM_RM_LABEL_NAME=" \n CREATE TABLE [dbo].[OAM_RM_LABEL_NAME] (\n" +
              "\t[LabelID] [varchar] (20)  NULL ,\n" +
              "\t[pksource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
              "\t[LabelName] [varchar] (200)  NULL ,\n" +
              "\t[ClientID] [varchar] (20)  NULL \n" +
              "\t )\n" ;



       tblString= tbl_RequestManagerAppearance+tbl_UserAndRequest+OAM_RM_REQUEST_SOURCE+OAM_RM_MESSAGE_RECEIVER+OAM_RM_LABEL_NAME;

        return tblString;
    }

       /**
        *  Desc: New function to add more tables.
        *  Tables OAM_RM_USER_PREFERENCES and OAM_RM_MOREDOCUMENTS1 were missing. Hence creating them as well.
        * @return tblString6
        */
       public String getTableCreationString6()
       {
           String tblString6 = null;
           String OAM_RM_USER_PREFERENCES =
                   "CREATE TABLE [dbo].[OAM_RM_USER_PREFERENCES] (\n" +
                   "\t[UserID] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,\n" +
                   "\t[PreferredClientID] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n" +
                   "\t[PreferredProductID] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL \n" +
                   ") ON [PRIMARY]\n";

           String OAM_RM_MOREDOCUMENTS1 =
                   "CREATE TABLE [dbo].[OAM_RM_MOREDOCUMENTS1] (\n" +
                   "\t[DocumentCode] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                   "\t[RequestCode] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n" +
                   "\t[UploadedDocName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n" +
                   "\t[UploadedDoc] [image] NULL ,\n" +
                   "\t[UploadedBy] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n" +
                   "\t[UploadedOn] [smalldatetime] NULL ,\n" +
                   "\t[DocType] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n" +
                   "\t[MsgId] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL \n" +
                   ") ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]\n";

           tblString6 = OAM_RM_USER_PREFERENCES + OAM_RM_MOREDOCUMENTS1;
           return tblString6;
       }
       /**@author Raju Thapa Shrestha,jan 23,2008
        *  Desc: New function to add more tables.
        *  Tables OAM_RM_MODULES and OAM_RM_PRODUCT_AREA are created.        
        */
       public String getTableCreationString7()
       {
           String tblString7 = null;
           String OAM_RM_MODULES=  
  				"CREATE TABLE [dbo].[OAM_RM_MODULES] (\n"+
  				"\t[ModuleID] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n"+
  				"\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
  				"\t[ProductID] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n"+
  				"\t[ModuleName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n"+
  				") ON [PRIMARY]\n";
           
           String OAM_RM_PRODUCT_AREA=
        	   	"CREATE TABLE [dbo].[OAM_RM_PRODUCT_AREA] (\n"+
        		"\t[ProductAreaID] [varchar] (15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n"+        		
        		"\t[ProductAreaDesc] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,\n"+
        		") ON [PRIMARY]\n";           

           tblString7 = OAM_RM_MODULES + OAM_RM_PRODUCT_AREA;
           return tblString7;
       }
       /**@author Raju Thapa Shrestha,jan 23,2008
        *  Desc: New function to alter tables.
        *  Tables OAM_RM_REQUESTMANAGER and OAM_RM_ARCHIVE are altered.        
        */
       public String getAlterTableString()
       {
    	   String tblString=null;
    	   //Modified date: March 13, 2008
    	   //By: Niranjan Thapa
    	   //Changes: Added a column "Severity" for the sevirity code from OAM_RM_REQUEST_SEVERITY
    	   //Changes: Added impact column
    	   String OAM_RM_REQUESTMANAGER=
    		   "ALTER TABLE OAM_RM_REQUESTMANAGER \n"+
    		   "\t ADD ModuleID varchar(15), \n"+
    		   "\t ProductArea varchar (15), \n"+
    		   "\t PhaseInject varchar (15),\n"+
    		   "\t EstimatedHours float NULL,\n"+
    		   "\t ActualHours float NULL,\n"+
    		   "\t LastUpdatedDate datetime NULL,\n "+
    		   "\t SourceID int NULL, \n"+
   	   		   "\t Severity varchar(15) NULL, \n"+
   	   		   "\t Impact varchar(2000) NULL \n";
    	   
    	   String OAM_RM_ARCHIVE=
    		   "ALTER TABLE OAM_RM_ARCHIVE \n"+
    			"\t ADD ProductID varchar(15),\n"+ 
    			"\t ModuleID varchar(15),\n"+
    			"\t ProductArea varchar (15),\n"+
    			"\t PhaseInject varchar (15),\n"+
    			"\t VersionFixed varchar(15),\n"+
    			"\t EstimatedHours float NULL,\n"+
    		    "\t ActualHours float NULL, \n"+
    		    "\t SourceID int NULL, \n"+
    	   		"\t Severity varchar(15) NULL, \n"+
    	   		"\t Impact varchar(2000) NULL \n";
    	   
	     tblString=OAM_RM_REQUESTMANAGER+OAM_RM_ARCHIVE;
	     return tblString;
       }
     public String getTableCreationString3(){
          String tblString3="";
          String OAM_RM_CUSTOM_FIELDS="\nCREATE TABLE [dbo].[OAM_RM_CUSTOM_FIELDS] (\n" +
                  "\t[FormID] [nvarchar] (20)  NOT NULL ,\n" +
                  "\t[ColumnID] [int] NOT NULL ,\n" +
                  "\t[LabelName] [nvarchar] (100)  NULL ,\n" +
                  "\t[ColumnName] [nvarchar] (100)NOT NULL ,\n" +
                  "\t[Filter] [int] NULL ,\n" +
                  "\t[Sort] [char] (2) NULL ,\n" +
                  "\t[ShowDetails] [nvarchar] (20) NULL ,\n" +
                  "\t[ColumnOrder] [int] NULL ,\n" +
                  "\t[ColumnType] [int] NULL ,\n" +
                  "\t[DefaultStatus] [nvarchar] (1) NULL ,\n" +
                  "\t[InactiveColumn] [varchar] (1) NULL \n" +
                  ") ";
         String OAM_RM_USER_CUSTOM_FIELDS="\nCREATE TABLE [dbo].[OAM_RM_USER_CUSTOM_FIELDS] (\n" +
                 "\t[FormID] [nvarchar] (50) NULL ,\n" +
                 "\t[UserID] [nvarchar] (15) NULL ,\n" +
                 "\t[ColumnID] [int] NULL ,\n" +
                 "\t[ActiveColumn] [nvarchar] (1) NULL \n" +
                 ") " ;
        String OAM_RM_PRODUCTS="\n CREATE TABLE [dbo].[OAM_RM_PRODUCTS] (\n" +
                "\t[ProductID] [varchar] (15) NOT NULL ,\n" +
                "\t[PKSource] [int] IDENTITY (1, 1) NOT NULL ,\n" +
                "\t[ProductName] [varchar] (50) NULL ,\n" +
                "\t[ClientID] [varchar] (15) NULL\n"+
                ")\n";
        String OAM_RM_REQUEST_LABELS="\nCREATE TABLE [dbo].[OAM_RM_REQUEST_LABELS] (\n" +
             "\t[LabelID] [varchar] (20)  NULL ,\n" +
             "\t[RequestID] [varchar] (20)  NULL ,\n" +
             "\t[ClientID] [varchar] (20)  NULL \n" +
             ")\n " ;
        String TMP_OAM_RM_USER_CLIENT="\n"+
               "CREATE TABLE [dbo].[TMP_OAM_RM_USER_CLIENT] (\n" +
               "\t[UCID] [numeric](18, 0) IDENTITY (1, 1)  NOT NULL ,\n" +
               "\t[UserID] [varchar] (15)  NULL ,\n" +
               "\t[ClientID] [varchar] (15)  NULL ,\n" +
               "\t[isAllRequestType] [char] (1)  NULL \n" +
               ") \n" ;

         tblString3=OAM_RM_CUSTOM_FIELDS+ OAM_RM_USER_CUSTOM_FIELDS+OAM_RM_PRODUCTS+OAM_RM_REQUEST_LABELS+TMP_OAM_RM_USER_CLIENT;
         return tblString3;
         }
     public String getStoredProcedureString(){

         String spString="";

         String sp_RequestManager="\nCREATE PROCEDURE sp_RequestManager       \n" +
               " @RequestingPerson VARCHAR(15),      \n" +
               " @ClientID VARCHAR(15),      \n" +
               " @RequestDate SMALLDATETIME,      \n" +
               " @Requests VARCHAR(3000),    \n" +
               " @RequestTypeID VARCHAR(15),    \n" +
               " @RelVersion VARCHAR(15),    \n" +
               " @ExpectedCompDate DATETIME,    \n" +
               " @RequestPriority VARCHAR(15)    \n" +
               "AS      \n" +
               " DECLARE @MaxID VARCHAR(15)      \n" +
               " DECLARE @NotStartedStatusCode VARCHAR(15)      \n" +
               " SELECT @NotStartedStatusCode=StatusID FROM OAM_RM_REQUESTSTATUS WHERE StatusDesc LIKE 'Not Started%'      \n" +
                " SELECT @MaxID='0001'      \n" +
               " IF(SELECT COUNT(RequestCode) FROM OAM_RM_REQUESTMANAGER)>0      \n" +
               "  SELECT @MaxID='000'+CONVERT(VARCHAR,(Max(PKSource)+1)) FROM OAM_RM_REQUESTMANAGER      \n" +
                " SELECT @MaxID AS RequestCode      \n" +
                " INSERT INTO OAM_RM_REQUESTMANAGER   \n" +
               "  (  \n" +
               " RequestCode,RequestTypeCode,RequestingPerson,StatusID,  \n" +
               " ApplicationVersionCode,ClientID,RequestDate,Requests,RequestPriority,documentCount,  \n" +
               " ExpectedCompDate  \n" +
               "  )  \n" +
               " VALUES      \n" +
               "  (       \n" +
               "  @MaxID,@RequestTypeID,@RequestingPerson,@NotStartedStatusCode,@RelVersion,     \n" +
               "  @ClientID,@RequestDate,@Requests,@RequestPriority,0,@ExpectedCompDate      \n" +
               "  )     ";


         spString=sp_RequestManager;


          return spString;
     }
       public String getStoredProcedureString1(){
           String spString1="";
           String sp_DeleteRequestDocument="\nCREATE PROCEDURE sp_DeleteRequestDocument  \n" +
                             "  @RequestCode VARCHAR(20),  \n" +
                             "  @DocumentCode INT  \n" +
                             " AS  \n" +
                             " IF @DocumentCode=0   \n" +
                             "  UPDATE OAM_RM_REQUESTMANAGER SET UploadedDoc=NULL, UploadedDocName=NULL  \n" +
                             "   WHERE RequestCode=@RequestCode  \n" +
                             " ELSE  \n" +
                             "  DELETE OAM_RM_MOREDOCUMENT WHERE DocumentCode=@DocumentCode  \n" +
                              " UPDATE OAM_RM_REQUESTMANAGER SET documentCount=documentCount-1 WHERE RequestCode=@RequestCode\n ";



           spString1= sp_DeleteRequestDocument;
            return spString1;
       }

       public String getStoredProcedureString2(){
           String spString2="";
       String sp_RequestMoreInfo="\n CREATE PROCEDURE sp_RequestMoreInfo\n" +
               " @RequestCode VARCHAR(15),\n" +
               " @PostedBy VARCHAR(15),\n" +
               " @ReplyTo VARCHAR(15),\n" +
               " @PostedMsg TEXT\n" +
               " AS\n" +
               " DECLARE @MaxID VARCHAR(15)\n" +
               " DECLARE @isCompStatus char(1)\n" +
               " SELECT @MaxID='0001'\n" +
               " IF(SELECT COUNT(PKSource) FROM OAM_RM_REQUESTMOREINFO)>0\n" +
               " SELECT @MaxID='000'+CONVERT(VARCHAR,(Max(PKSource)+1)) FROM OAM_RM_REQUESTMOREINFO\n" +
               " INSERT INTO OAM_RM_REQUESTMOREINFO VALUES \n" +
               " (@MaxID,@RequestCode,@PostedBy,@ReplyTo,@PostedMsg,getDate())\t\n" +
               " IF @ReplyTo<>NULL\n" +
               " BEGIN\n" +
               " UPDATE OAM_RM_REQUESTMANAGER SET isCompleted = 'r' \n" +
               " WHERE \n" +
               " RequestCode=@RequestCode AND \n" +
               " (isCompleted NOT IN ('y','p') or isCompleted IS NULL)\n" +
               " UPDATE OAM_RM_REQUESTMANAGER SET isCompleted = 's' \n" +
               " WHERE \n" +
               " RequestCode=@RequestCode AND isCompleted IN ('y','p')\n" +
               " END\n" +
               " Else\n" +
               " BEGIN\t\n" +
               " UPDATE OAM_RM_REQUESTMANAGER SET isCompleted = 'm' \n" +
               " WHERE \n" +
               " RequestCode=@RequestCode AND \n" +
               " (isCompleted NOT IN ('y','s') or isCompleted IS NULL)\t\n" +
               " UPDATE OAM_RM_REQUESTMANAGER SET isCompleted = 'p' \n" +
               " WHERE \n" +
               " RequestCode=@RequestCode AND isCompleted IN ('y','s')\n" +
               "END";
           spString2= sp_RequestMoreInfo;
            return spString2;

       }
       public String getStoredProcedureString3(){
           String spString3="";

       String sp_MarkRequestCompleted="\nCREATE PROCEDURE sp_MarkRequestCompleted \n" +
                " @RequestCode VARCHAR(15), \n" +
                " @EnggID VARCHAR(15), \n" +
                " @isComp CHAR(1) \n" +
                " AS \n" +
                " DECLARE @AssignedTo VARCHAR(15) \n" +
                " IF(SELECT COUNT(AssignedTo) FROM OAM_RM_REQUESTMANAGER WHERE RequestCode=@RequestCode)>0 \n" +
                " BEGIN \n" +
                " SELECT @AssignedTo=AssignedTo FROM OAM_RM_REQUESTMANAGER WHERE RequestCode=@RequestCode IF(@AssignedTo=@EnggID) \n" +
                " BEGIN \n" +
                " UPDATE OAM_RM_REQUESTMANAGER SET isCompleted=@isComp ,StatusID='0005', DevCompDate=CAST(CONVERT(char(8),GetDate(),112) as datetime) WHERE RequestCode=@RequestCode \n" +
                " UPDATE OAM_RM_REQUESTMANAGER SET isCompleted=@isComp ,StatusID='0005', DevCompDate=CAST(CONVERT(char(8),GetDate(),112) as datetime) WHERE parentRequestCode=@RequestCode \n" +
                " END \n" +
                "END";
        spString3= sp_MarkRequestCompleted;
            return spString3;
       }
       //Changed by	:Raju Thapa Shrestha,Jan 23,2008
       //Changes	:Inserting values in tbl_source      
    public String getInsertString(){

       String iString="";

       String insert_tbl_Source="\nInsert into OAM_RM_REQUEST_SOURCE values ('External')\n" +
                              "Insert into OAM_RM_REQUEST_SOURCE values ('Internal')";

        String insert_tbl_RequestStatus="\nInsert into OAM_RM_REQUESTSTATUS values ('0001', 'Not Started')\n" +
                "Insert into OAM_RM_REQUESTSTATUS values ('0002', 'Dropped')\n" +
                "Insert into OAM_RM_REQUESTSTATUS values ('0003', 'Closed')\n" +
                "Insert into OAM_RM_REQUESTSTATUS values ('0004', 'Assigned')\n" +
                "Insert into OAM_RM_REQUESTSTATUS values ('0005', 'Completed')\n" +
                "Insert into OAM_RM_REQUESTSTATUS values ('0006', 'In Progress')\n" +
                 "Insert into OAM_RM_REQUESTSTATUS values ('0007', 'Deferred')\n";
       String insert_tbl_Request_Phase="\nInsert into OAM_RM_REQUEST_PHASE values('001','Requirement','1')\n" +
                 "Insert into OAM_RM_REQUEST_PHASE values('002','Design','2')\n" +
                 "Insert into OAM_RM_REQUEST_PHASE values('003','Implementation','3')\n" +
                 "Insert into OAM_RM_REQUEST_PHASE values('004','Production','4')";
       //Added date: March 13, 2008
	   //By: Niranjan Thapa
	   //Changes: Added a column "Severity" for the sevirity code from OAM_RM_REQUEST_SEVERITY
       String insert_tbl_Request_Severity="\n insert into OAM_RM_REQUEST_SEVERITY values('0001','Critical',1)"+
	    	   "\ninsert into OAM_RM_REQUEST_SEVERITY values('0002','Major',2)\n"+
	    	   "\ninsert into OAM_RM_REQUEST_SEVERITY values('0003','Minor',3)\n"+
	    	   "\ninsert into OAM_RM_REQUEST_SEVERITY values('0004','Trivial',4)\n";
       
       //added by Raju Thapa Shrestha,Jan 31,2008
       String insert_tbl_ProductAreas="\nINSERT INTO OAM_RM_PRODUCT_AREA values('0001','Architecture')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0002','Completeness')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0003','Consistency')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0004','Data')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0005','Function')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0006','Integration')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0007','Logic')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0008','Performance')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0009','Platform')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0010','Redundant Code')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0011','Research')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0012','Standards')\n"+
       			"INSERT INTO OAM_RM_PRODUCT_AREA values('0013','User Interface')";

        iString=insert_tbl_Source+insert_tbl_RequestStatus+insert_tbl_Request_Phase+insert_tbl_ProductAreas+insert_tbl_Request_Severity;
        return iString;
    }
    /*Changed by:Raju Thapa Shrestha,Feb 22,2008
      Changes   : added update and insert string to add row for Product*/
    //Modified By: Niranjan Thapa Magar 
    //Date : March 14, 2008
    //Changes: Added impact column and Severity
    //Changes: Added Source,Mar 19,2008,Raju Thapa Shrestha 
    public String getInsertString1(){
        String iString="";
        String insert_ztbl_RMFormsColumns="\nINSERT into OAM_RM_CUSTOM_FIELDS values('R05','1','SN','RequestCode','1','i','Y','1','1','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','2','Type','RequestTypeDesc','1','a','Y','2','1','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','3','Date','RequestDate','1','b','Y','3','2','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','4','From','RequestingPerson','1','c','Y','4','1','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','5','Requests','Requests','1','p','y','5','1','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','6','Documents','Documents','0','no','y','6','1','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','7','Target','TargetCompDate','1','g','y','7','2','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','8','Status','StatusDesc','1','d','y','8','1','Y','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','9','Assigned To','EngineerDesc','1','e','y','9','1','Y','')\n" +                
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','10','Client','ClientName','1','j','Y','10','1','N','')\n" +
                "INSERT INTO OAM_RM_CUSTOM_FIELDS VALUES('R05','11','Product','ProductName','1','pr','y','11','1','N',' ')\n"+ //Modified for version 1.0.1.0
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','12','Phase','RequestPhase','1','x','Y','12','1','N','')\n" +
                "INSERT INTO OAM_RM_CUSTOM_FIELDS VALUES('R05','13','Module','ModuleName','1','m','y','13','1','N',' ')\n"+ 
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','14','Title','RequestTitle','1','l','Y','14','1','N','')\n" + //Modified for version 1.0.1.0
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','15','Rel #','ApplicationVersionDesc','1','f','Y','15','1','N','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','16','Priority','RequestPriority','1','r','Y','16','1','N','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','17','Dev Comp Date','DevCompDate','1','k','Y','17','2','N','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','18','Fixed In Version','FixedInVersion','1','z','Y','18','1','N','')\n" +
                "INSERT into OAM_RM_CUSTOM_FIELDS values('R05','19','Updated Date','requestupdatedDate','1','y','Y','19','2','N','')\n"+
                "INSERT INTO OAM_RM_CUSTOM_FIELDS VALUES('R05','20','Remarks','Remarks','1','rm','y','20','1','N',' ') \n "+ //Modified for version 1.0.1.0
                "INSERT INTO OAM_RM_CUSTOM_FIELDS VALUES('R05','21','Severity','SeverityDesc','1','sv','y','21','1','N',' ')\n"+ //Modified for version 1.0.1.0
        		"INSERT INTO OAM_RM_CUSTOM_FIELDS VALUES('R05','22','Impact','Impact','1','im','y','22','1','N',' ')\n"+ //Modified for version 1.0.1.0"
                "INSERT INTO OAM_RM_CUSTOM_FIELDS VALUES('R05','23','Source','Source','1','rs','y','23','1','N',' ')\n";
        
        	iString=insert_ztbl_RMFormsColumns;
           return iString;
       }

    public boolean createDefaultUser(String ServerName,String DatabaseName,String UserName,String pwd,String email){

        boolean retVal=false;
        try{

        //Class.forName("macromedia.jdbc.MacromediaDriver");
        //String connectionURL = "jdbc:macromedia:sqlserver://"
        //+ ServerName + ":1433;User=" + UserName + ";Password="
        //+ pwd + ";DatabaseName=" + DatabaseName;
        //mytempConn = DriverManager.getConnection(connectionURL);
        Class.forName("com.inet.tds.TdsDriver");
        String connectionURL="jdbc:inetdae7:"
                               + ServerName +":1433?database="+DatabaseName;
		mytempConn = DriverManager.getConnection (connectionURL,UserName,pwd);
        strSQL="DECLARE @MaxID INT " +
                "SELECT @MaxID=1 " +
                "IF(SELECT COUNT(UserID) FROM usr_Users)>0 " +
                " SELECT @MaxID=MAX(SeedUserID)+1 FROM usr_Users " +
                "INSERT INTO usr_Users VALUES ( " +
                " '000'+CONVERT(VARCHAR,@MaxID), " +
                "'Admin', " +
                "'Admin', " +
                "pwdencrypt('Admin')," +
                "'"+email+"', " +
                "'0', " +
                "'N', " +
                "'0' )";
        stmt=mytempConn.createStatement();
        stmt.executeUpdate(strSQL);
        retVal=true;
        mytempConn.close();
        }catch(SQLException se){mess=se.getMessage();}
        catch (ClassNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return retVal;
    }
    public static void main (String args[]){
           DomainManageBean dm= new DomainManageBean();
           try {System.out.println(dm.getTableCreationString1()+dm.getTableCreationString2()+dm.getTableCreationString7()+dm.getStoredProcedureString()+dm.getStoredProcedureString1()+dm.getInsertString()); }catch(Exception e){System.out.println(e.getMessage());};
    }

}
