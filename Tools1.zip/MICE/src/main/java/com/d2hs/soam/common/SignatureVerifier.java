package com.d2hs.soam.common;

import com.d2oam.sso.SSOHandler;

public class SignatureVerifier {

	public boolean verifySignature(String data, String signature) throws Exception{
		String filePath=SignatureVerifier.class.getResource("/com/d2hs/soam/common").getPath();		
		SSOHandler ssoHandler=new SSOHandler(filePath,"sso.d2oam.com.jks","sso.d2oam.com", "oamsso" );		
		return ssoHandler.verifySignature(data, signature);
	}
	
}
