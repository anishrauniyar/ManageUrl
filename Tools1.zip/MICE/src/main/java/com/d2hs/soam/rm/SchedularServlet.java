package com.d2hs.soam.rm;



import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.httpclient.HttpClient;


public class SchedularServlet extends HttpServlet {

	HttpSession session=null;
	public SchedularServlet(){
		
	}
	
	public void init(ServletConfig conf)throws ServletException{
		try{
			Schedular sc=new Schedular();
			new Thread(sc).start();			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
