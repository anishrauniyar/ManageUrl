package com.d2hs.soam.common;

//-----------------------------------------------------------------------------------

import java.io.IOException;

import java.security.Provider;
import java.security.Key;
import java.security.Security;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.BadPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Encoder;
import sun.misc.BASE64Decoder;

import org.bouncycastle.jce.provider.BouncyCastleProvider;


//-----------------------------------------------------------------------------------

/**
 * Encryption/decryption class.
 * 
 * @author Aashish Dutta Koirala
 */
public class Encryptor {
	
	/** Cipher object. */
	private Cipher rc4Cipher = null;
	
	/** Default key. */
	private Key defaultKey = null;
	
	/** Base-64 encoder. */
	private BASE64Encoder encoder = null;
	
	/** Base-64 decoder. */
	private BASE64Decoder decoder = null;

	//--------------------------------------------------------------------------------

	/**
	 * Creates a new instance of this object.
	 * 
	 * @throws NoSuchAlgorithmException No such algorithm.
	 * @throws NoSuchPaddingException No such padding method.
	 * @throws NoSuchProviderException No such provider.
	 */
	public Encryptor() throws NoSuchAlgorithmException, NoSuchPaddingException,
			NoSuchProviderException {
        Provider prov = Security.getProvider("BC");
        if (prov == null) {
            prov = new BouncyCastleProvider();
            Security.addProvider(prov);
        }
		this.rc4Cipher = Cipher.getInstance("RC4", "BC");
        byte[] randomBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7 };
        SecretKeySpec sks = new SecretKeySpec(randomBytes, "RC4");
        SecretKey sc = (SecretKey) sks;
        this.defaultKey = sc;
        this.encoder = new BASE64Encoder();
        this.decoder = new BASE64Decoder();
	}

	//--------------------------------------------------------------------------------

    /**
     * Encrypts the given data.
     *
     * @author Aashish Dutta Koirala
     * @param inputData Input data to encrypt.
     * @return Encrypted data.
     * @throws NoSuchAlgorithmException Algorithm not supported by provider.
     * @throws NoSuchPaddingException Padding not supported by provider.
     * @throws InvalidKeyException Invalid encryption key.
     * @throws IllegalBlockSizeException Illegal data block size.
     * @throws BadPaddingException Bad data block padding.
     */
    public byte[] encrypt(byte[] inputData)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		this.rc4Cipher.init(Cipher.ENCRYPT_MODE, this.defaultKey);
		return this.rc4Cipher.doFinal(inputData);
	}

	//--------------------------------------------------------------------------------

    /**
     * Decrypts the given data.
     *
     * @author Aashish Dutta Koirala
     * @param inputData Encrypted data to decrypt.
     * @return Decrypted plaintext data.
     * @throws NoSuchAlgorithmException Algorithm not supported by provider.
     * @throws NoSuchPaddingException Padding not supported by provider.
     * @throws InvalidKeyException Invalid decryption key.
     * @throws IllegalBlockSizeException Illegal data block size.
     * @throws BadPaddingException Bad data block padding.
     */
    public byte[] decrypt(byte[] inputData)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		this.rc4Cipher.init(Cipher.DECRYPT_MODE, this.defaultKey);
		return this.rc4Cipher.doFinal(inputData);
	}

	//--------------------------------------------------------------------------------

    /**
     * Encrypts the given text.
     *
     * @author Aashish Dutta Koirala
     * @param inputData Input text to encrypt.
     * @return Encrypted text.
     * @throws NoSuchAlgorithmException Algorithm not supported by provider.
     * @throws NoSuchPaddingException Padding not supported by provider.
     * @throws InvalidKeyException Invalid encryption key.
     * @throws IllegalBlockSizeException Illegal data block size.
     * @throws BadPaddingException Bad data block padding.
     */
    public String encryptText(String plainText)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] bytes = new byte[plainText.length()];
		for (int i = 0; i < bytes.length; i++)
			bytes[i] = (byte) ((plainText.charAt(i)) & 0xFF);
		byte[] enc = this.encrypt(bytes);
		String encryptedText = this.encoder.encode(enc);
		return encryptedText;
	}

	//--------------------------------------------------------------------------------

    /**
     * Decrypts the given text.
     *
     * @author Aashish Dutta Koirala
     * @param inputData Encrypted text to decrypt.
     * @return Decrypted text.
     * @throws NoSuchAlgorithmException Algorithm not supported by provider.
     * @throws NoSuchPaddingException Padding not supported by provider.
     * @throws InvalidKeyException Invalid decryption key.
     * @throws IllegalBlockSizeException Illegal data block size.
     * @throws BadPaddingException Bad data block padding.
     * @throws IOException I/O exception.
     */
    public String decryptText(String cipherText)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, IOException {
		byte[] enc = this.decoder.decodeBuffer(cipherText);
		byte[] dec = this.decrypt(enc);
		char[] text = new char[dec.length];
		for (int i = 0; i < text.length; i++)
			text[i] = (char) dec[i];
		String decryptedText = String.valueOf(text);
		return decryptedText;
	}
}