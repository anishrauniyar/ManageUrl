package com.d2hs.soam.um;

import com.d2hawkeye.util.CommonUtils;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.d2hs.soam.RequestBean;

import d2Systems.rm.User;
import d2Systems.rm.UserFilters;
import d2Systems.rm.UserPreference;
import d2Systems.rm.UserProject;

/**
 * Created by IntelliJ IDEA. User: phada Date: Dec 19, 2005 Time: 2:03:44 PM To
 * change this template use File | Settings | File Templates.
 *
 * Modifications: User Date Purpose Bhanu D2c 9, 10 Removed changedPassword and
 * checkOldPassword
 */
public class UserManager extends RequestBean {

    protected String orderField = "UserName";
    protected String order = "ASC";
    public String strFilters = "";
    private final static Logger logger = Logger.getLogger(UserManager.class);

    public String getOrderField() {
        return orderField;
    }

    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public UserManager() {

    }

    public void setfilterUser(String fFullName, String fLoginName, String fEmail) {
        if (!fFullName.equals("")) {
            strFilters += " AND lower(UserName) LIKE  lower('%" + fFullName.replaceAll("'", "''").trim() + "%')";
        }
        if (!fLoginName.equals("")) {
            strFilters += " AND lower(LoginName) LIKE lower('%" + fLoginName.replaceAll("'", "''").trim() + "%')";
        }
        if (!fEmail.equals("")) {
            strFilters += " AND lower(Email) LIKE lower( '%" + fEmail.replaceAll("'", "''").trim() + "%')";
        }
    }

    public boolean getAllUsers(String UserID) {
        boolean result = false;

        strSQL = "select * from usr_Users where 1=1 and oamstatus=1 ";
        if (!UserID.equals("0")) {
            strSQL = strSQL + "and UserID='" + UserID + "'";
        }
        strSQL += strFilters;
        strSQL += " ORDER BY " + orderField + " " + order + "";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getAllUserswithProductAccess(String ProductID) {
        boolean result = false;
        strSQL = "SELECT UserName, UserID FROM usr_Users WHERE "
                + " (UserID IN (SELECT UserID FROM TMP_OAM_RM_USER_PRODUCT "
                + " WHERE (ProductID = '" + ProductID + "')and oamusertypecode is not null)) ORDER BY UserName";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;

    }

    private String sqlForClientList = "Select * from OAM_RM_CLIENTS Order by ClientName";

    public TreeMap executeQueryForClientList() {
        TreeMap groupList = new TreeMap();
        ResultSet rs;
        PreparedStatement stm;
        groupList.clear();
        try {
            stm = myConn.prepareStatement(strSQL = sqlForClientList);
            rs = stm.executeQuery();
            while (rs.next()) {
                groupList.put(rs.getString("ClientID"), rs.getString("ClientName"));
            }
            rs.close();
            stm.close();
        } catch (Exception e) {
            strSQL += " " + e.getMessage();
        }
        return groupList;
    }

    /**
     * @author rsah, Feb. 25, 2008, to get list of clients in ascending order
     */
    public java.util.List executeQueryForClientList1() {
        Map resultMap = null;
        List result = null;
        ResultSet rs;
        PreparedStatement stm;
        try {
            stm = myConn.prepareStatement(strSQL = sqlForClientList);
            rs = stm.executeQuery();
            result = new ArrayList();
            while (rs.next()) {
                resultMap = new HashMap();
                resultMap.put("clientId", rs.getString("ClientId"));
                resultMap.put("clientName", rs.getString("ClientName"));
                result.add(resultMap);
            }
            rs.close();
            stm.close();
        } catch (Exception e) {
            strSQL += " " + e.getMessage();
        }
        return result;
    }

    public boolean getClientList() {
        return this.getClientList("");
    }

    public boolean getClientList(String clientID) {
        boolean result = false;

        strSQL = "Select * from OAM_RM_CLIENTS ";
        if (!clientID.trim().equals("")) {
            strSQL += " WHERE clientID=" + clientID;
        }
        strSQL += " Order by ClientName ";

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getAssignedProduct(String UserID) {
        return this.getAssignedProduct(UserID, "");
    }

    public boolean getAssignedProduct(String UserID, String ClientID) {
        boolean result = false;
        strSQL = "select a.URID, a.UserID, b.ProductName, a.ProductID from TMP_OAM_RM_USER_PRODUCT a "
                + "Left Join OAM_RM_PRODUCTS b on a.ProductID=b.ProductID"
                + " where a.UserID='" + UserID + "' ";
        if (!ClientID.trim().equals("")) {
            strSQL += " AND b.ClientID=" + ClientID;
        }
        strSQL += " Order by b.ProductName";

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getAssignedClient() {
        boolean result = false;
        strSQL = getAllClientsQry();
        strSQL += " order by lower(clientname)";
        // strSQL += " right join (select clientid,userid from tmp_oam_rm_user_client) t"
        // 	   +  "  on t.clientid = a.clientid where t.userid ='"+UserID+"' order by a.clientname";

        System.out.println("Assigned Client query is >>>>>>>>>>>>>>>>:" + strSQL);

        /* strSQL = "select a.UCID, a.UserID, b.ClientName, a.ClientID from TMP_OAM_RM_USER_CLIENT a " +
                "Left Join OAM_CLIENTS b on a.ClientID=b.ClientID" +
                " where a.UserID='"+UserID+"' Order by b.ClientName";*/
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.println("\nError:[default-war/com/d2hs/soam/um/UserManager.java]->getAssignedClient()<- " + strSQL);
            e.printStackTrace();
        }
        return result;
    }

    public boolean getDataSources() {
        boolean result = false;

        strSQL = "select * from oam_datasources where 1=1";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (SQLException e) {
            System.out.println("\nError:[default-war/com/d2hs/soam/um/UserManager.java]->getDataSources()<- " + strSQL);
            e.printStackTrace();
        }
        return result;
    }

    public boolean getPayorList() {
        boolean result = false;

        strSQL = " select DISTINCT  ( upper(vhpayorname) ) AS vhpayorname , vhpayorid from hr_global_vhpayors order by 1 asc ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (SQLException e) {
            System.out.println("\nError:[default-war/com/d2hs/soam/um/UserManager.java]->getDataSources()<- " + strSQL);
            e.printStackTrace();
        }
        return result;
    }

    public boolean getAllIssueType() {
        boolean result = false;
        strSQL = "SELECT issuetypeid,issuetypename,CRCODE from   oam_cr_issuetype WHERE isdeleted='N' order by issuetypeid";
        System.out.println("List All issue Type >>>>>>>>>>>>>>>>:" + strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getAllReprocessingReason() {
        boolean result = false;
        strSQL = "SELECT reasonid,REASONDESC from  oam_reprocessreasons WHERE isdeleted='N' order by 2";
        System.out.println("List All reprocessing >>>>>>>>>>>>>>>>:" + strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getAllDataType() {
        boolean result = false;
        strSQL = "SELECT datatypeid,datatypename from   oam_cr_datatype WHERE isdeleted='N' order by datatypeid";
        //System.out.println("List All data Type >>>>>>>>>>>>>>>>:"+strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public Map getIssueTypePhasesCR(String issueType, String pId) {
        Map hmap = new HashMap();
        String phaseCombo = "";
        int flag = 0;

        String strSQL = ""
                + "SELECT a.phaseid,a.phasename FROM oam_cr_phases a "
                + "left join oam_cr_template_phases b "
                + "ON b.phaseid=a.phaseid "
                + "left join oam_cr_template_issuetype c "
                + "ON c.templateid = b.templateid ";
        //+ "WHERE c.issuetypeid = 1 ORDER BY b.phaseorder";
        if (issueType.length() > 0) {
            strSQL += " WHERE c.issuetypeid = " + issueType + " ORDER BY b.phaseorder";
        }
        //System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);

        try {
            setAlias("RequestManager->SuperDomainDataBase");
            if (myConn == null) {
                this.makeConnection();
            }
            phaseCombo = "&nbsp; <select name='phase' id='phase' onchange='_phaseChangeEvent()'>";
            phaseCombo += "<option value=\"\">Please Choose</option>";
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                String phaseId = myRS.getString("phaseId");
                String phaseName = myRS.getString("phaseName");
                phaseCombo += "<OPTION VALUE=\"" + phaseId + "\" ";
                if (pId.length() == 0 && flag == 0) {
                    phaseCombo += " selected ";
                    flag++;
                }
                if (pId.length() > 0 && pId.equals(phaseId)) {
                    phaseCombo += " selected ";
                }

                phaseCombo += ">" + phaseName + "</OPTION>";
            }

            phaseCombo += "</select>";

            //System.out.println("PhaseCombo>>>>>>:" + phaseCombo);
            hmap.put("PhaseCombo", phaseCombo);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return hmap;
    }

    public Map getIssueTypePhasesCRJS(String issueType, String pId) {
        Map hmap = new HashMap();
        String phaseCombo = "";
        int flag = 0;

        String strSQL = ""
                + "SELECT a.phaseid,a.phasename FROM oam_cr_phases a "
                + "left join oam_cr_template_phases b "
                + "ON b.phaseid=a.phaseid "
                + "left join oam_cr_template_issuetype c "
                + "ON c.templateid = b.templateid ";
        //+ "WHERE c.issuetypeid = 1 ORDER BY b.phaseorder";
        if (issueType.length() > 0) {
            strSQL += " WHERE c.issuetypeid = " + issueType + " ORDER BY b.phaseorder";
        }
        System.out.println("Query >>>>>>>>>>>>>>>>>>" + strSQL);

        try {
            setAlias("RequestManager->SuperDomainDataBase");
            if (myConn == null) {
                this.makeConnection();
            }
            phaseCombo = "&nbsp; <select name='phase' id='phase' onchange='_phaseChangeEvent()'>";
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                String phaseId = myRS.getString("phaseId");
                String phaseName = myRS.getString("phaseName");
                phaseCombo += "<OPTION VALUE=\"" + phaseId + "\" ";
                if (pId.length() == 0 && flag == 0) {
                    phaseCombo += " selected ";
                    flag++;
                }
                if (pId.length() > 0 && pId.equals(phaseId)) {
                    phaseCombo += " selected ";
                }

                phaseCombo += ">" + phaseName + "</OPTION>";
            }

            phaseCombo += "</select>";

            //System.out.println("PhaseCombo>>>>>>:" + phaseCombo);
            hmap.put("PhaseCombo", phaseCombo);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.takeDown();
        }
        return hmap;
    }

    public Map getCombinedIssueTypePhasesCR(String issueType1, String issueType2, String pId, String projectId) {
        Map hmap = new HashMap();
        String phaseCombo = "";
        int flag = 0;

        String sql = "select count(1) from oam_rm_requestmanager where requestcode = " + projectId + " and phaseinject is not null";
        String strSQL = ""
                + "SELECT issuetypeid, "
                + "				        a.phaseid, "
                + "				        a.phasename, "
                + "				        b.phaseorder, "
                + "                d.phaseinject "
                + "				 FROM   oam_cr_phases a "
                + "				        left join oam_cr_template_phases b "
                + "				               ON b.phaseid = a.phaseid "
                + "				        left join oam_cr_template_issuetype c "
                + "				               ON c.templateid = b.templateid "
                + "                left join oam_rm_requestmanager d "
                + "                       ON c.issuetypeid=d.phaseinject AND d.phaseid=b.phaseid AND d.requestcode = " + projectId
                + "				 WHERE  c.issuetypeid =  " + issueType2
                + "				 ORDER  BY issuetypeid DESC, "
                + "				           phaseorder";
        //+ "WHERE c.issuetypeid = 1 ORDER BY b.phaseorder";
        /*if(issueType1.length()>0 && issueType2.length()>0){
		strSQL +=" WHERE c.issuetypeid in("+issueType1+","+issueType2+") ORDER BY b.phaseorder";
	}*/
        System.out.println("getCombinedIssueTypePhasesCR >>>>>>>>>>>>>>>>>>" + strSQL);
        int phaseInjectCount = 0;
        try {

            phaseCombo = "&nbsp; <select name='phase' id='phase'  onchange='_phaseChangeEvent()'>";

            setAlias("RequestManager->SuperDomainDataBase");
            if (myConn == null) {
                this.makeConnection();
            }
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(sql);
            if (myRS.next()) {
                phaseInjectCount = myRS.getInt(1);
            }
            myRS = stmt.executeQuery(strSQL);
            boolean found = false;
            while (myRS.next()) {
                String issueTypeId = myRS.getString("issuetypeid");
                String phaseId = myRS.getString("phaseId");
                String phaseName = myRS.getString("phaseName");
                String phaseInject = myRS.getString("phaseinject");
                phaseCombo += "<OPTION VALUE=\"" + issueTypeId + ":" + phaseId + "\" ";
                if (pId.length() == 0 && flag == 0) {
                    phaseCombo += " selected ";
                    flag++;
                }
                //System.out.println("phaseId is "+phaseId);

                if (phaseInjectCount == 0) {
                    //System.out.println("CASE I");
                    if (pId.length() > 0 && pId.equals(phaseId) && issueType1 != "1" && !found) {
                        phaseCombo += " selected ";
                        found = true;
                    }
                } else //System.out.println("CASE II");
                 if (pId.length() > 0 && phaseInject != null && phaseInject.equalsIgnoreCase(issueType1) && pId.equals(phaseId) && !found) {
                        //System.out.println("11111111111111111111");
                        phaseCombo += " selected ";
                        found = true;
                    } else if (pId.length() > 0 && pId.equals(phaseId) && !found) {
                        //System.out.println("22222222222222222222");
                        phaseCombo += " selected ";
                    }

                /*if(phaseInjectCount>0 && pId.length()>0 && phaseInject!=null && phaseInject.equalsIgnoreCase(issueType1) && pId.equals(phaseId) && !found){
						System.out.println("11111111111111111111");
						phaseCombo += " selected ";
						found = true;
					} 
					else if ( pId.length()>0 && phaseInject!=null && phaseInject.equalsIgnoreCase(issueType1) && pId.equals(phaseId) && !found){
						System.out.println("22222222222222222222");
						phaseCombo += " selected ";
						found = true;
					}
					
					else if(pId.length()>0 && pId.equals(phaseId) && !found){
						System.out.println("3333333333333333333333");
						phaseCombo += " selected ";
						//found = true;
						//found1 = true;
					}*/
                phaseCombo += ">" + phaseName + "</OPTION>";
            }

            phaseCombo += "</select>";

            //System.out.println("PhaseCombo>>>>>>:" + phaseCombo);
            hmap.put("PhaseCombo", phaseCombo);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return hmap;
    }

    /**
     * @param phaseId
     * @return phaseTarget for the given phaseid
     */
    public String getPhaseTarget(String phaseId, String requestCode) {
        if (phaseId == null || phaseId == "") {
            return "0";
        }
        /*strSQL = "select phasetarget from oam_cr_phases where phaseid="
				+ phaseId;*/
        strSQL = ""
                + "SELECT Bizdays_between(Nvl(Trunc(plog.logged), SYSDATE), Trunc(SYSDATE)) - 1 "
                + "       ||'/' "
                + "       ||Nvl(crp.phasetarget, '0') AS phasetarget "
                + "FROM   oam_rm_requestmanager_log plog "
                + "       left join oam_cr_phases crp "
                + "              ON plog.phaseid = crp.phaseid "
                + "WHERE  plog.logged = (SELECT Max(logged) "
                + "                      FROM   oam_rm_requestmanager_log "
                + "                      WHERE  requestcode = '" + requestCode + "') "
                + "       AND plog.requestcode = '" + requestCode + "'";
        logger.debug("[UserManager->getPhaseTarget] Query " + strSQL);
        String phaseTarget = "";
        try {
            setAlias("RequestManager->SuperDomainDataBase");
            if (myConn == null) {
                this.makeConnection();
            }
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            if (myRS.next()) {
                phaseTarget = myRS.getString(1);
            }
        } catch (Exception e) {
            logger.error("[UserManager->getPhaseTarget] " + strSQL, e);
        }
        return phaseTarget;
    }

    public Map getClientAppsCR(String clientId, String applicationId) {
        Map hmap = new HashMap();
        String ApplicationCombo = "";
        String strSQL = "select applicationid, applicationname from oam_clientapps ";
        if (clientId.length() > 0) {
            strSQL += " WHERE clientid = " + clientId + "";
        }
        //System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);

        try {

            ApplicationCombo = "&nbsp; <select name='appID' id='appID'>";
            ApplicationCombo += "<option value=\"\">Please Choose</option>";
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                String appId = myRS.getString("applicationId");
                String appName = myRS.getString("applicationName");
                ApplicationCombo += "<OPTION VALUE=\"" + appId + "\" ";
                if (applicationId.length() > 0 && appId.equals(applicationId)) {
                    ApplicationCombo += " selected ";
                }
                ApplicationCombo += ">" + appName + "(" + appId + ")" + "</OPTION>";
            }

            ApplicationCombo += "</select>";

            //System.out.println("Application Combo>>>>>>:" + ApplicationCombo);
            hmap.put("ApplicationCombo", ApplicationCombo);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return hmap;
    }

    public Map getReleaseTag(String applicationId, String releaseTag, String requestTypeId) {
        Map hmap = new HashMap();
        String releaseTagCombo = "";
        String strSQL_;

        if (CommonUtils.RequestCode.REPROCESSING.getRequestTypeId().equals(requestTypeId)) {
            strSQL_ = "select releasetagidbyapp  from ( "
                    + "Select releasetagidbyapp,applicationid,status,  row_number()"
                    + " over ( partition by applicationid , status order by status )  as row_num from cp_releasetagbyapp ) "
                    + " where row_num <=2";
            if (applicationId.length() > 0) {
                strSQL_ += " and  applicationid = '" + applicationId + "' and status  IN ( 'CURRENT','PROGRESS')";
            }
            strSQL_ += " union all Select 'FUTURE' from  dual";
        } else {
            strSQL_ = "Select releasetagidbyapp from cp_releasetagbyapp "
                    + "WHERE 1=1 ";
            if (applicationId.length() > 0) {
                strSQL_ += " and  applicationid = '" + applicationId + "' and status  IN ( 'CURRENT','PROGRESS')";
            }
            strSQL_ += " union all Select 'FUTURE' from  dual "; 
        }

        System.out.println("Query >>>>>>>>>>>>>>>>>>ReleaseTag>"+strSQL_);
        try {

            releaseTagCombo = "&nbsp; <select name='releaseTag' id='releaseTag' >";
            releaseTagCombo += "<option value=\"\">Please Choose</option>";

            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL_);
            while (myRS.next()) {
                String releasetagidbyapp = myRS.getString("releasetagidbyapp");
                //String appName = myRS.getString("releasetagidbyapp");
                releaseTagCombo += "<OPTION VALUE=\"" + releasetagidbyapp + "\" ";
                if (releaseTag.length() > 0 && releasetagidbyapp.equals(releaseTag)) {
                    releaseTagCombo += " selected ";
                }
                releaseTagCombo += ">" + releasetagidbyapp + "</OPTION>";
            }

            releaseTagCombo += "</select>";

            //System.out.println("Application Combo>>>>>>:" + ApplicationCombo);
            hmap.put("releaseTagCombo", releaseTagCombo);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return hmap;
    }

    public Map getAllComponent(String applicationid, String componentid) {
        Map hmap = new HashMap();
        String ApplicationCombo = "";
        String strSQL = "SELECT * FROM   oam_cr_defectcomponent ";
        if (applicationid.length() > 0) {
            strSQL += " WHERE DEFAPPID = " + applicationid + "";
        }
        //System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);

        try {

            ApplicationCombo = "&nbsp; <select name='defectComponent' id='defectComponent'>";
            ApplicationCombo += "<option value=\"\">Please Choose</option>";
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                String appId = myRS.getString("DEFCOMPONENTID");
                String appName = myRS.getString("DEFCOMPONENTNAME");
                ApplicationCombo += "<OPTION VALUE=\"" + appId + "\" ";
                if (componentid.length() > 0 && appId.equals(componentid)) {
                    ApplicationCombo += " selected ";
                }
                ApplicationCombo += ">" + appName + "</OPTION>";
            }

            ApplicationCombo += "</select>";

            //System.out.println("Application Combo>>>>>>:" + ApplicationCombo);
            hmap.put("defectComponentCombo", ApplicationCombo);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return hmap;
    }

    public Map getAllImpactedComponent(String applicationid, String componentid) {
        Map hmap = new HashMap();
        String ApplicationCombo = "";
        String strSQL = "SELECT * FROM   oam_cr_defectcomponent ";
        if (applicationid.length() > 0) {
            strSQL += " WHERE DEFAPPID = " + applicationid + "";
        }
        //System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);

        try {

            ApplicationCombo = "&nbsp; <select name='defectImpactedComponent' id='defectImpactedComponent'>";
            ApplicationCombo += "<option value=\"\">Please Choose</option>";
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                String appId = myRS.getString("DEFCOMPONENTID");
                String appName = myRS.getString("DEFCOMPONENTNAME");
                ApplicationCombo += "<OPTION VALUE=\"" + appId + "\" ";
                if (componentid.length() > 0 && appId.equals(componentid)) {
                    ApplicationCombo += " selected ";
                }
                ApplicationCombo += ">" + appName + "</OPTION>";
            }

            ApplicationCombo += "</select>";

            //System.out.println("Application Combo>>>>>>:" + ApplicationCombo);
            hmap.put("defectImpactComponentCombo", ApplicationCombo);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return hmap;
    }

    /* function:getUserListForClient
       Desc: Get the list of Users related to given Client
       Author: Richan Shrestha
       Parameter: clientID
       Result: Boolean that indicates the success/failure of database query */
    public boolean getUserListForClient(String clientId) {
        boolean result = false;
        strSQL = " SELECT UserName, UserID FROM usr_Users WHERE (UserID IN"
                + " (SELECT UserID FROM TMP_OAM_RM_USER_CLIENT WHERE (ClientID ='" + clientId + "'))) ORDER BY UserName";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    /* function: getNotAssignedUserListForProduct
    Desc: Gets the list of users of the client that are not assigned the given product
    Author: Richan Shrestha
    Parameter: clientID
    Parameter: ProductID
    Result: Boolean that indicates the success/failure of database query */
    public boolean getNotAssignedUserListForProduct(String clientId, String productCode) {
        boolean result = false;
        strSQL = " SELECT UserName, UserID FROM usr_Users WHERE (UserID IN "
                + " (SELECT UserID  FROM TMP_OAM_RM_USER_CLIENT WHERE  (UserID NOT IN "
                + " (SELECT  UserID FROM  TMP_OAM_RM_USER_PRODUCT WHERE "
                + " (ProductID = '" + productCode + "'))) AND (ClientID = '" + clientId + "'))) ORDER BY UserName";

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    /* function: getAssignedUserListForProduct
 Desc: Gets the list of users that are assigned the given product
 Author: Richan Shrestha
 Parameter: ProductID
 Result: Boolean that indicates the success/failure of database query */
    public boolean getAssignedUserListForProduct(String productCode) {
        boolean result = false;
        strSQL = " SELECT UserName, UserID FROM usr_Users WHERE (UserID IN "
                + " (SELECT UserID FROM  TMP_OAM_RM_USER_PRODUCT WHERE ("
                + " ProductID = '" + productCode + "'))) ORDER BY UserName";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    /* function:  isAssignedClient
    Desc: Checks if the preferred client is in the assigned client list
    Author: Anjana Shrestha
    Date: July 19, 2006
    Parameter: clientid
    Parameter: clientid
    Output: boolean that says whether the preferred client is in the assigned client list*/
    public boolean isAssignedClient(String userID, String clientid) {
        // System.out.println ("Hello");
        boolean result = false;
        String cid = "";
        strSQL = "select ClientID from TMP_OAM_RM_USER_CLIENT where ClientId = '" + clientid + "' and UserID = '" + userID + "' ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            if (moveNext()) {
                cid = getParam("ClientID");
            }
            if (clientid.equalsIgnoreCase(cid)) {
                result = true;
            }
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    /**
     * function: isAssignedProduct Desc: Checks if the preferred product is in
     * the assigned product list Author: Anjana Shrestha Date: July 19, 2006
     * Parameter: productid Parameter: productid Output: boolean that says
     * whether the preferred product is in the assigned product list
     */
    public boolean isAssignedProduct(String userID, String pid) {
        //  System.out.println ("Hello");
        boolean result = false;
        String proid = "";
        strSQL = "select ProductID from TMP_OAM_RM_USER_PRODUCT where ProductID = '" + pid + "' and UserID = '" + userID + "' ";

        //System.out.println("strlQSL:"+strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            if (moveNext()) {
                proid = getParam("ProductID");
            }
            if (pid.equalsIgnoreCase(proid)) {
                result = true;
            }
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public String getClientName(String ClientID) {
        String sql = "select ClientName from OAM_RM_CLIENTS where 1=1";
        if (!ClientID.equalsIgnoreCase("")) {
            sql = sql + " And ClientID='" + ClientID + "'";
        }

        String ClientName = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ClientName = rs.getString("ClientName");
            }
        } catch (Exception e) {
        }
        return ClientName;
    }

    public String getFirstClient(String UserID) {
        /*String sql="select a.* from OAM_RM_CLIENTS a left join TMP_OAM_RM_USER_CLIENT b on a.clientid=b.clientid where b.userid='"+UserID+"' AND " +
        		" ROWNUM=1 order by a.clientid desc";*/
        String sql = getAllClientsQry();
        sql += " left join TMP_OAM_RM_USER_CLIENT t on a.clientid=t.clientid where t.userid='" + UserID + "' AND ROWNUM=1 order by a.clientid desc";

        System.out.println("Query to get first client >>>>>>>>>>>>>>" + sql);
        String FirstClientID = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                FirstClientID = rs.getString("ClientID");
            }
        } catch (Exception e) {
            System.out.println("\nError:[default-war/com/d2hs/soam/um/UserManager.java]->getFirstClient( " + UserID + " )<- " + sql);
            e.printStackTrace();
        }
        return FirstClientID;

    }

    public boolean getNotAssignedClients(String UserID) {
        boolean result = false;
        /*strSQL = "select * from OAM_RM_CLIENTS a " +
              " where a.ClientID not in (Select ClientID from TMP_OAM_RM_USER_CLIENT c where c.UserID='"+UserID+"') Order by a.ClientName";*/
        strSQL = getAllClientsQry();
        strSQL += "  where a.ClientID not in (Select ClientID from TMP_OAM_RM_USER_CLIENT c where c.UserID='" + UserID + "') Order by a.ClientName";

        //System.out.println("Query for getNotAssignedClients is >>>>>>>>>>>> "+strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.println("\nError:[default-war/com/d2hs/soam/um/UserManager.java]->getNotAssignedClients( " + UserID + " )<- " + strSQL);
            e.printStackTrace();
        }
        return result;
    }

    public String getRequestTypeDesc(String RequestTypeCode) {
        String sql = "select RequestTypeDesc from OAM_RM_REQUEST_TYPES where 1=1";
        if (!RequestTypeCode.equalsIgnoreCase("")) {
            sql = sql + " And RequestTypeID='" + RequestTypeCode + "'";
        }

        String RequestTypeDesc = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                RequestTypeDesc = rs.getString("RequestTypeDesc");
            }
        } catch (Exception e) {
        }
        return RequestTypeDesc;
    }

    public boolean getRequestType(String ClientID) {
        boolean result = false;
        strSQL = "select * from OAM_RM_REQUEST_TYPES where 1=1";
        if (!ClientID.equalsIgnoreCase("")) {
            strSQL = strSQL + " And ClientID='" + ClientID + "'";
        }
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getProducts(String ClientID) {
        return this.getProducts(ClientID, "");
    }

    public boolean getProducts(String ClientID, String ProductID) {
        boolean result = false;
        strSQL = "select * from OAM_RM_PRODUCTS where 1=1";
        if (!ClientID.trim().equals("")) {
            strSQL = strSQL + " And ClientID='" + ClientID + "'";
        }
        if (!ProductID.trim().equals("")) {
            strSQL = strSQL + " And ProductID='" + ProductID + "'";
        }

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getProjects(String ProductID) {
        return this.getProjects(ProductID, "");
    }

    public boolean getProjects(String ProductID, String ProjectID) {
        boolean result = false;
        strSQL = "select * from OAM_RM_PROJECTS where 1=1";
        if (!ProductID.trim().equals("")) {
            strSQL += " And ProductID='" + ProductID + "'";
        }
        if (!ProjectID.trim().equals("")) {
            strSQL += " And ProjectID='" + ProjectID + "'";
        }
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public String getFirstProduct(String ClientID) {

        String sql = "select ProductID from OAM_RM_PRODUCTS where 1=1 and rownum=1 ";
        if (!ClientID.equalsIgnoreCase("")) {
            sql += " And ClientID='" + ClientID + "'";
        }

        String FirstProductCode = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                FirstProductCode = rs.getString("ProductID");
            }
        } catch (Exception e) {
        }
        return FirstProductCode;

    }

    public String getFirstProduct(String uid, String ClientID) {
        String sql = "select a.ProductID from OAM_RM_PRODUCTS a left join TMP_OAM_RM_USER_PRODUCT b on a.ProductID=b.ProductID where 1=1 and rownum=1 ";
        if (!ClientID.equalsIgnoreCase("")) {
            sql += " And ClientID='" + ClientID + "'";
        }
        if (!uid.equalsIgnoreCase("")) {
            sql += " And b.UserID='" + uid + "'";
        }

        String FirstProductCode = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                FirstProductCode = rs.getString("ProductID");
            }
        } catch (Exception e) {
        }
        return FirstProductCode;

    }

    public String getProductDesc(String ProductID) {
        String sql = "select ProductName from OAM_RM_PRODUCTS where 1=1";
        if (!ProductID.equalsIgnoreCase("")) {
            sql = sql + " And ProductID=" + ProductID + "";
        }

        String ProductName = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ProductName = rs.getString("ProductName");
            }
        } catch (Exception e) {
        }
        return ProductName;
    }

    public String getFirstRequestType(String ClientID) {
        String sql = "select RequestTypeID from OAM_RM_REQUEST_TYPES where 1=1 AND ROWNUM=1";
        if (!ClientID.equalsIgnoreCase("")) {
            sql = sql + " And ClientID='" + ClientID + "'";
        }

        String FirstRequestTypeCode = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                FirstRequestTypeCode = rs.getString("RequestTypeID");
            }
        } catch (Exception e) {
        }
        return FirstRequestTypeCode;

    }

    /* Function: isAssignedRequestsofUser
     Desc: Checks if the preferred product is assigned to user
     Author: Aanjana Shrestha
     Date: July 19, 2006
     Input para: user id and client id
     Returns boolean that says whether it is assigned or not

      public boolean isAssignedRequestsofUser(String UserID, String pid){
      boolean result = false;
      String proid = "";
      strSQL="Select ProductID from TMP_OAM_RM_USER_PRODUCT where UserID='"+UserID+"' and ProductID = ' +pid ";

       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
               myRS=stmt.executeQuery(strSQL);
               if (moveNext())
               {
                   proid = getParam("ProductID");
               }
               if (pid.equalsIgnoreCase(proid))
               {
                   result = true;
               }
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
    } */
    public boolean getAssignedRequestsofUser(String UserID, String ClientID) {
        boolean result = false;
        //strSQL = "select a.URID, a.UserID, a.RequestTypeCode, a.InSwitchBoard, b.RequestTypeDesc from TMP_OAM_RM_USER_PRODUCT a " +
        //      "Left Join (Select RequestTypeCode, RequestTypeDesc from OAM_RM_REQUEST_TYPES) b on a.RequestTypeCode=b.RequestTypeCode" +
        //    " where a.UserID='"+UserID+"' And b.ClientID'="+ClientID+"' Order by a.RequestTypeDesc";
        strSQL = "select a.URID, a.UserID, a.Productid, a.InSwitchBoard, b.ProductName from TMP_OAM_RM_USER_PRODUCT a Left "
                + " Join (Select ClientID, Productid, ProductName from OAM_RM_PRODUCTS) b on a.Productid=b.Productid "
                + " where b.ClientID= '" + ClientID + "'  ";
        if (!UserID.equals("")) {
            strSQL += " And a.UserID='" + UserID + "'";
        }
        strSQL += " Order by b.ProductName ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    /**
     *
     * getClientProducts UserManager Description
     * <li>returns the products associated with a client</li>
     *
     * @param ClientID
     * @return
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Jun 11, 2010
     *
     */
    public boolean getClientProducts(String ClientID) {
        boolean result = false;
        strSQL = "select distinct a.Productid,b.ProductName from TMP_OAM_RM_USER_PRODUCT a Left "
                + " Join (Select ClientID, Productid, ProductName from OAM_RM_PRODUCTS) b on a.Productid=b.Productid "
                + " where b.ClientID= '" + ClientID + "'  Order by b.ProductName";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }


    /*
    * Function: getUsers
    * Author: Anjana Shrestha
    * Date Created: July 05, 2006
    * Description: This function returns a list of users who have been assigned a product
    * Parameters: product code as String
    * Output: boolean
     */
    public boolean getUsers(String product_code) {
        boolean result = false;
        String strSQL = "select userid, username from ztbl_users where userID in (Select userID from tbl_usersandRequest where ProductID = '"
                + product_code + " ')";
        strSQL += " Order by username ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getClientsRequestTypes(String ProductID) {
        boolean result = false;
        strSQL = "select a.*,b.username from OAM_RM_REQUEST_TYPES a left join  usr_users b on a.userid=b.userid where 1=1 ";
        if (!ProductID.trim().equals("")) {
            strSQL += " AND ProductID='" + ProductID + "'";
        }
        strSQL += " order by RequestTypeDesc ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getRequestTypes() {
        boolean result = false;
        strSQL = "select * FROM OAM_RM_REQUEST_TYPES where 1=1 ";
        strSQL += " order by RequestTypeDesc ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }

        return result;
    }

    /**
     * author rsah, Jan. 30, 2008
     *
     * @param ProductID
     * @return
     */
    public boolean getProductRequestTypesUsers(String ProductID, String RequestTypeID) {
        boolean result = false;
        strSQL = "select a.UserID,b.username from OAM_RM_REQUEST_TYPES a left join  usr_users b on a.userid=b.userid where 1=1 ";
        if (!ProductID.equalsIgnoreCase("")) {
            strSQL += " AND ProductID='" + ProductID + "'";
        }
        if (!RequestTypeID.equalsIgnoreCase("")) {
            strSQL += " AND RequestTypeID='" + RequestTypeID + "'";
        }
        strSQL += " order by RequestTypeDesc ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getProjectRequestTypesUsers(String ProjectID, String RequestTypeID) {
        boolean result = false;
        strSQL = "select a.UserID,b.username from OAM_RM_REQUEST_TYPES a left join  usr_users b on a.userid=b.userid where 1=1 ";

        if (!ProjectID.equalsIgnoreCase("")) {
            strSQL += " AND ProjectID='" + ProjectID + "'";
        }

        if (!RequestTypeID.equalsIgnoreCase("")) {
            strSQL += " AND RequestTypeID='" + RequestTypeID + "'";
        }
        strSQL += " order by RequestTypeDesc ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getUserRole(String UserID) {
        boolean result = false;

        strSQL = "select * from oam_rm_userrole where UserID = '" + UserID + "'";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getTeamRole(String UserID) {
        boolean result = false;

        strSQL = "SELECT Count(1) as COUNT FROM oam_cr_manager_role  WHERE USERID='" + UserID + "'";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getUserInfoFromID(String UserID) {
        boolean result = false;

        strSQL = "select * from usr_Users where UserID = '" + UserID + "'";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            //myRS.next();
            result = true;

        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean deletePreAssign(String productID, String projectID, String requestTypeID) {

        boolean deleted = false;
        strSQL = "DELETE FROM OAM_RM_REQUEST_PREASSIGN WHERE 1=1 ";
        if (!productID.trim().equals("")) {
            strSQL += " AND ProductID='" + productID + "'";
        }
        if (!projectID.trim().equals("")) {
            strSQL += " AND projectID='" + projectID + "'";
        }
        if (!requestTypeID.trim().equals("")) {
            strSQL += " AND requestTypeID='" + requestTypeID + "'";
        }
        try {
            Statement st = myConn.createStatement();
            st.executeUpdate(strSQL);
            deleted = true;
        } catch (SQLException e) {
            System.out.println("Error:" + e);
        }

        return deleted;
    }

    public boolean selectPreAssign(String productID, String projectID, String requestTypeID, String assignedTo) {

        boolean selected = false;
        strSQL = "SELECT * FROM OAM_RM_REQUEST_PREASSIGN WHERE 1=1 ";

        if (!productID.trim().equals("")) {
            strSQL += " AND ProductID='" + productID + "'";
        }
        if (!projectID.trim().equals("")) {
            strSQL += " AND projectID='" + projectID + "'";
        }
        if (!requestTypeID.trim().equals("")) {
            strSQL += " AND requestTypeID='" + requestTypeID + "'";
        }
        if (!assignedTo.trim().equals("")) {
            strSQL += " AND assignedTo='" + assignedTo + "'";
        }

        try {
            Statement stmt = myConn.createStatement();
            myRS = stmt.executeQuery(strSQL);
            selected = true;
        } catch (SQLException e) {
            System.out.println("Error:" + e);
        }

        return selected;
    }

    public String getPreAssign(String productID, String projectID, String requestTypeID) {
        String userID = "";
        if (this.selectPreAssign(productID, projectID, requestTypeID, "")) {
            if (this.moveNext()) {
                userID = this.getParam("assignedTo").trim() + ":::" + this.getParam("isStatic").trim();
            }
        }
        return userID;
    }

    /**
     * Updated by
     *
     * @author Date Purpose Bhanu Date Dec 9, 10 To assign add static/dynamic
     * Preassign users.
     * @param productID
     * @param projectID
     * @param requestTypeID
     * @param assignedTo
     * @param actiontaken
     * @param isStatic
     * @return
     */
    public boolean insertPreAssign(String productID, String projectID, String requestTypeID, String assignedTo, String actiontaken, String isStatic) {
        boolean inserted = false;
        strSQL = "INSERT INTO OAM_RM_REQUEST_PREASSIGN "
                + "(productid,projectid,requesttypeid,assignedto,actiontaken,isStatic) VALUES(?,?,?,?,?,?)";

        if (isStatic == null || isStatic.equals("")) {
            isStatic = "N";
        } else {
            isStatic = "Y";
        }

        try {
            PreparedStatement pstmt = this.myConn.prepareStatement(strSQL);
            pstmt.setString(1, productID);
            pstmt.setString(2, projectID);
            pstmt.setString(3, requestTypeID);
            pstmt.setString(4, assignedTo);
            pstmt.setString(5, actiontaken.trim());
            pstmt.setString(6, isStatic);
            inserted = pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Error:" + e);
        }

        return inserted;
    }

    public boolean insertWatchList(String userID, String requestID) {

        boolean inserted = false;
        strSQL = "INSERT INTO OAM_RM_MYWATCHLIST "
                + "(userid,requestcode) VALUES(?,?)";
        try {
            PreparedStatement pstmt = this.myConn.prepareStatement(strSQL);
            pstmt.setString(1, userID);
            pstmt.setString(2, requestID);
            inserted = pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Error:" + e);
        }

        return inserted;
    }

    public boolean deleteWatchList(String userID, String requestID) {

        boolean deleted = false;
        strSQL = "DELETE FROM OAM_RM_MYWATCHLIST WHERE UserID=? AND RequestCode=?";
        try {
            PreparedStatement pstmt = this.myConn.prepareStatement(strSQL);
            pstmt.setString(1, userID);
            pstmt.setString(2, requestID);
            deleted = pstmt.execute();
        } catch (SQLException e) {
            System.out.println("Error:" + e);
        }

        return deleted;
    }

    public boolean getDataProvider() {

        boolean result = false;
        strSQL = "select ClientName||' ('||ClientID||') ' ClientName,ClientID from OAM_CLIENTS a Order by a.ClientName";
        System.out.println("getDataProvider():" + strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getDataSources(String userID) {

        boolean result = false;
        strSQL = "select ClientName||' ('||ClientID||') ' ClientName,ClientID from OAM_CLIENTS a";
        strSQL += " where clientID IN" + super.getAccesibleClients(userID);
        strSQL += "Order by a.ClientName";
        // System.out.println("quesy is >>>>>>>>>>> "+strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public String hasAccessTo(String userID, String requestCode) {
        /**
         * @modification:Ramesh Raj Baral
         * @since July 5 2010 Description:if the requestCode is in comma
         * separated form then split and append the requestcode in the query
         */
        strSQL = "select productID,projectID,requestTypeID from (SELECT * "
                + " FROM   oam_rm_requestmanager "
                + " UNION ALL "
                + " SELECT * "
                + " FROM   oam_rm_requestmanager_annal)  where requestcode='" + requestCode + "' or pksource='" + requestCode + "'";
        String multipleRequestString = "";
        if (requestCode.split(",") != null && requestCode.split(",").length > 0) {
            String[] codeArr = requestCode.split(",");
            for (int i = 0; i < codeArr.length; i++) {
                if (codeArr[i].trim().length() > 0) {
                    multipleRequestString += (i == 0) ? ("'" + codeArr[i] + "'") : (",'" + codeArr[i] + "'");
                }

            }
        }
        if (multipleRequestString.trim().length() > 0) {
            strSQL = "select productID,projectID,requestTypeID from (SELECT * "
                    + " FROM   oam_rm_requestmanager "
                    + " UNION ALL "
                    + " SELECT * "
                    + " FROM   oam_rm_requestmanager_annal) where requestcode IN (" + multipleRequestString + ") or pksource IN(" + multipleRequestString + ")";
        }
        String result = "0";
        boolean hasAccessToProduct = false;

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                result = "1";
                hasAccessToProduct = hasAccessToProduct(userID, myRS.getString("productID"));
            }
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        if (hasAccessToProduct) {
            result = "2";
        }
        return result;
    }

    public boolean hasAccessToProduct(String userID, String productID) {
        boolean result = false;
        strSQL = "select count(*) as count from TMP_OAM_RM_USER_PRODUCT where productid='" + productID + "' and userid='" + userID + "'";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                if (myRS.getInt("count") > 0) {
                    result = true;
                }
            }
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getRequestCodeDetails(String requestCode) {
        boolean result = false;
        strSQL = "select c.clientID,c.clientName,p.productID,p.productName,pr.projectID,pr.projectName,rt.requestTypeDesc,rm.requestcode"
                + " from (SELECT * "
                + " FROM   oam_rm_requestmanager "
                + " UNION ALL "
                + " SELECT * "
                + " FROM   oam_rm_requestmanager_annal) rm"
                + " LEFT JOIN OAM_RM_CLIENTS c ON rm.ClientID=c.clientID"
                + " LEFT JOIN OAM_RM_PRODUCTS p ON rm.productID=p.productID"
                + " LEFT JOIN OAM_RM_PROJECTS pr ON rm.projectID=pr.projectID"
                + " LEFT JOIN OAM_RM_REQUEST_TYPES rt ON rm.requesttypeID=rt.requesttypeID"
                + " where rm.requestcode='" + requestCode + "'";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public String getRequestTable(String requestCode) {
        String table = "";
        strSQL = "SELECT requestcode, "
                + "       'main' tablename "
                + "FROM   oam_rm_requestmanager "
                + "WHERE  requestcode IN ( '" + requestCode + "' ) "
                + "UNION "
                + "SELECT requestcode, "
                + "       'annal' tablename "
                + "FROM   oam_rm_requestmanager_annal "
                + "WHERE  requestcode IN ( '" + requestCode + "' ) ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                table = myRS.getString("tablename");
            }
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return table;
    }

    public String setProductCombo(String fromPage, String alias, String clientID, String userID, String currentProduct) {
        String productcombo = "";
        try {
            setAlias(alias);
            makeConnection();
            if (fromPage.equals("View")) {
                productcombo = "<select id=Product name=ProductID onChange=\"productChange()\" class=\"box1\"><option value=\"all\">Select Product</option>";
            } else {
                productcombo = "<select class=\"DataCellTD\" id=Product name=ProductID onChange=\"productChange()\" class=\"box1\"><option value=\"all\">Please Choose</option>";
            }
            if (!clientID.equalsIgnoreCase("")) {
                int productTypeCount = 0;
                String rid = "";
                if (getAssignedRequestsofUser(userID, clientID)) {
                    while (moveNext()) {
                        productTypeCount++;
                        rid = getParam("ProductID");

                        productcombo += "<OPTION VALUE=\"" + rid + "\"";
                        if (currentProduct != null) {
                            if (rid.equals(currentProduct)) {
                                productcombo += " selected";
                            }

                        }

                        productcombo += ">" + getParam("ProductName") + "</OPTION>";
                    }
                }
            }

            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        }
        productcombo += "</select>";
        return productcombo;
    }

    public boolean isSuperAdmin(String UserID) {
        boolean isSuperAdmin = false;
        strSQL = "select isSuperAdmin from oam_rm_userrole"
                + " where userid='" + UserID + "'";
        try {
            Statement stmt1 = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet myRS1 = stmt1.executeQuery(strSQL);
            myRS1.next();
            if (myRS1.getString("isSuperAdmin").equals("y")) {
                isSuperAdmin = true;
            }
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return isSuperAdmin;
    }

    public boolean getAssignedClient(String UserID, String AdminUserID) {
        boolean result = false;
        strSQL = "SELECT * "
                + "FROM   (SELECT clientid "
                + "        FROM   tmp_oam_rm_user_client "
                + "        WHERE  userid = '" + UserID + "' "
                + "        INTERSECT  "
                + "        SELECT clientid "
                + "        FROM   tmp_oam_rm_user_client "
                + "        WHERE  userid = '" + AdminUserID + "') a "
                + "       LEFT JOIN oam_rm_clients b "
                + "         ON a.clientid = b.clientid";

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    /**
     *
     * getUserPreference UserManager Description:Returns the user
     * settings/preference
     *
     * @param userID
     * @return
     * @return UserPreference
     * @author:Ramesh Raj Baral
     * @since:Jun 24, 2010
     *
     */
    public UserPreference getUserPreference(String userID) {
        UserPreference preference = new UserPreference();
        String sql = "SELECT pref.islightpage, "
                + "       pref.defaultlightfilter, "
                + "       preflite.filtername, "
                + "       preflite.filterid, "
                + "       preflite.reqtype, "
                + "       preflite.reqstatus, "
                + "       preflite.reqseverity, "
                + "       preflite.reqpriority, "
                + "       preflite.reqowner "
                + "FROM   oam_rm_user_preferences pref "
                + "       left join oam_rm_userpreferenceforlite preflite "
                + "         ON pref.userid = preflite.userid "
                + "WHERE  pref.userid = '" + userID + "' ";
        preference.setLight(false);
        try {
            if (myConn == null) {
                this.connectDB();
            }
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            int index = 0;
            UserFilters defaultFilter = new UserFilters();
            while (rs.next()) {
                if (index == 0) {
                    defaultFilter.setFilterID(rs.getString("defaultlightfilter"));
                    preference.setUserDefaultFilter(defaultFilter);
                    String islight = rs.getString("islightpage") == null ? "n" : rs.getString("islightpage");
                    preference.setLight(islight.equalsIgnoreCase("n") ? false : true);
                }
                UserFilters userFilter = new UserFilters();
                userFilter.setFilterID(rs.getString("filterid"));
                userFilter.setFilterName(rs.getString("filtername"));
                userFilter.setRequestOwner(rs.getString("reqowner"));
                userFilter.setRequestPriority(rs.getString("reqpriority"));
                userFilter.setRequestSeverity(rs.getString("reqseverity"));
                userFilter.setRequestStatus(rs.getString("reqstatus"));
                userFilter.setRequestType(rs.getString("reqtype"));
                if (userFilter.getFilterID().equals(defaultFilter.getFilterID())) {
                    preference.setUserDefaultFilter(userFilter);
                }
                preference.getUserFiltersList().add(userFilter);
                index++;
            }
        } catch (Exception ex) {
            System.out.println("exception getting user preference:" + ex.getMessage());
        } finally {
            this.takeDown();
        }
        UserFilters blankFilter = new UserFilters();
        preference.getUserFiltersList().add(0, blankFilter);
        return preference;
    }

    /**
     *
     * setRMHomePage queryBeanPM Description:set the home page-either light page
     * or normal page for a given user
     *
     * @param userID
     * @param islight
     * @return
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Jun 30, 2010
     *
     */
    public boolean setRMHomePage(String userID, String islight) {
        boolean inserted = false;
        String lightFlag = islight;
        String sql = "MERGE INTO oam_rm_user_preferences pref "
                + "USING (SELECT '" + userID + "' userid "
                + "       FROM   dual)pref1 "
                + "ON (pref1.userid=pref.userid) "
                + "WHEN matched THEN "
                + "  UPDATE SET islightpage = '" + lightFlag + "'"
                + "WHEN NOT matched THEN "
                + "  INSERT (userid,islightpage)"
                + "  VALUES ('" + userID + "','" + lightFlag + "')";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            stmt = myConn.createStatement();
            inserted = stmt.execute(sql);
        } catch (Exception ex) {
            System.out.println("Error in UserManager.setRMHomePage, >> :" + ex.getMessage());
        } finally {
            this.takeDown();
        }

        return inserted;
    }

    /**
     *
     * getUserAccessProjects UserManager Description:returns the project in
     * which this user has access to
     *
     * @param userID
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jul 2, 2010 if another user has set the project as favorite then
     * also retrieve it check the access level in query
     */
    public List getUserAccessProjects(String userID) {
        List projectsList = new ArrayList();

        String sql = "SELECT a.* "
                + "FROM   (SELECT projectid, "
                + "               Lead(projectid, 1, 0) over (ORDER BY projectid ASC, preferred "
                + "               DESC) AS "
                + "                      laterone, "
                + "               projectname, "
                + "               preferred "
                + "        FROM   (SELECT a.projectid, "
                + "                       a.projectname, "
                + "                       CASE "
                + "                         WHEN userid IS NULL "
                + "                               OR userid <> '" + userID + "' THEN 'N' "
                + "                         ELSE userid "
                + "                       END AS preferred "
                + "                FROM   (SELECT projectid, "
                + "                               projectname "
                + "                        FROM   oam_rm_projects prj "
                + "                        WHERE  prj.productid IN (SELECT productid "
                + "                                                 FROM   oam_rm_products "
                + "                                                 WHERE "
                + "                               clientid IN((SELECT tcl.clientid "
                + "                                            FROM   tmp_oam_rm_user_client tcl "
                + "                                                   inner join oam_rm_clients "
                + "                                                              cl "
                + "                                                     ON cl.clientid = "
                + "                                                        tcl.clientid "
                + "                                            WHERE  tcl.userid = '" + userID + "')) "
                + "                               AND productid IN (SELECT productid "
                + "                                                 FROM "
                + "                                   tmp_oam_rm_user_product tpr "
                + "                                                 WHERE  userid = '" + userID + "'))) a "
                + "                       left join oam_rm_preferredprojects pref "
                + "                         ON pref.projectid = a.projectid "
                + "                ORDER  BY a.projectid, "
                + "                          preferred DESC)) a "
                + "WHERE  a.projectid <> laterone ";

        try {
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                UserProject project = new UserProject();
                project.setProjectID(rs.getString("projectid"));
                project.setProjectName(rs.getString("projectname"));
                String preferred = rs.getString("preferred");
                project.setPreferred(preferred.equals(userID) ? true : false);
                projectsList.add(project);
            }

        } catch (Exception ex) {
            System.out.println("Exception getting projects  in which user has access to" + ex.getMessage());
        } finally {

        }
        return projectsList;
    }

    /**
     *
     * savePreferredProjects UserManager Description:inserts the preferred
     * projects for the given user
     *
     * @param userID
     * @param projectsID
     * @return
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Jul 2, 2010
     *
     */
    public boolean savePreferredProjects(String userID, String projectsID) {
        boolean inserted = false;
        boolean insertNewEntry = false;
        String strArray[] = projectsID.split(",");
        //String sql="call give_me_an_array(?,?)";
        String sql_del = "delete  oam_rm_preferredprojects where userid='" + userID + "' ";
        String sql_insert = "INSERT ALL";
        for (int i = 0; i < strArray.length; i++) {
            if (strArray[i].trim().length() > 0) {
                insertNewEntry = true;
                sql_insert += " INTO oam_rm_preferredprojects(userid,projectid) values('" + userID + "','" + strArray[i] + "') ";
            }
        }
        sql_insert += " SELECT *FROM DUAL";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmt = myConn.createStatement();
            stmt.execute(sql_del);
            inserted = true;
            if (insertNewEntry) {
                stmt.execute(sql_insert);
                inserted = true;
            }
            System.out.println("User preferred projects added");
        } catch (Exception ex) {
            System.out.println("Exception adding user preferred projects:" + ex.getMessage());
            System.out.println(ex.getStackTrace());
        }
        return inserted;
    }

    /**
     *
     * getUserPreferredProjects UserManager
     *
     * @param userID
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jul 2, 2010
     *
     */
    public List getUserPreferredProjects(String userID) {
        List prefProjList = new ArrayList();
        String sql = "select projectid from oam_rm_preferredprojects where userid='" + userID + "'";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                UserProject userProject = new UserProject();
                userProject.setProjectID(rs.getString("projectid"));
                prefProjList.add(userProject);
            }
        } catch (Exception ex) {
            System.out.println("Exception getting user preferred projects:" + ex.getMessage());
            System.out.println(ex.getStackTrace());
        } finally {
            try {
                this.takeDown();
            } catch (Exception ex) {
                System.out.println("Exception closing connection after userpreferred projects retrieved");
            }
        }
        return prefProjList;
    }

    /**
     * Description:Retrieve the user customized filters getUserCustomFilters
     * UserManager
     *
     * @param userID
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Aug 16, 2010
     *
     */
    public List getUserCustomFilters(String userID) {
        List filtersList = new ArrayList();
        String sql = "select *from oam_rm_userpreferenceforlite where userid='" + userID + "'";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                UserFilters userFilter = new UserFilters();
                userFilter.setFilterID(rs.getString("filterid"));
                userFilter.setFilterName(rs.getString("filtername"));
                userFilter.setRequestPriority(rs.getString("reqpriority"));
                userFilter.setRequestSeverity(rs.getString("reqseverity"));
                userFilter.setRequestStatus(rs.getString("reqstatus"));
                userFilter.setRequestType(rs.getString("reqtype"));
                userFilter.setRequestOwner(rs.getString("reqowner"));
                filtersList.add(userFilter);;
            }
        } catch (Exception ex) {
            System.out.println("Exception getting user custom filters:" + ex.getMessage());
            System.out.println(ex.getStackTrace());
        } finally {
            try {
                this.takeDown();
            } catch (Exception ex) {
                System.out.println("Exception closing connection for getting usercustomfilters:" + ex.getMessage());
            }
        }
        return filtersList;
    }

    /**
     * Description:This method updates the user customized filters
     * updateUserCustomFilters UserManager
     *
     * @param userID
     * @param userFilters
     * @param deletedFilters
     * @param defaultFilterID
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Aug 17, 2010
     *
     */
    public boolean updateUserCustomFilters(String userID, String userFilters, String deletedFilters, String defaultFilterID) {
        boolean inserted = false;
        boolean deletePreferredFilter = false;
        boolean noFiltersProvided = false;
        if (userFilters.trim().length() < 1) {
            noFiltersProvided = true;
        }
        String sql_delFilters = "DELETE oam_rm_userpreferenceforlite WHERE USERID='"
                + userID + "' and filterid in(" + deletedFilters + ")";
        String sql_updatePreferredFilter = "UPDATE oam_rm_user_preferences set DEFAULTLIGHTFILTER='0' where userid='"
                + userID + "'";
        if (noFiltersProvided) {
            /**
             * if user has no filters provided then delete his all filters and
             * also set the preferred filter to 0
             */

            try {
                if (myConn == null) {
                    this.connectDB();
                }
                Statement stmt = myConn.createStatement();
                stmt.executeQuery(sql_delFilters);
                stmt.executeQuery(sql_updatePreferredFilter);
            } catch (Exception ex) {
                System.out.println("Exception updating user custom filters--nofiltersprovided:"
                        + ex.getMessage());
                System.out.println(ex.getStackTrace());
            } finally {
                try {
                    this.takeDown();
                } catch (Exception ex) {
                    System.out
                            .println("Exception closing connection in updateusercustomFilter--nofilters provided:");
                    ex.printStackTrace();
                }
            }
        } else {
            String[] filtersArray = userFilters.split("&");
            String[] deletedFiltersArr = deletedFilters.split(",");
            if (deletedFiltersArr != null && deletedFiltersArr.length > 0) {
                for (int i = 0; i < deletedFiltersArr.length; i++) {
                    String deletedFilter = deletedFiltersArr[i].replaceAll("'",
                            "");
                    if (deletedFilter.equals(defaultFilterID)) {
                        deletePreferredFilter = true;
                    }
                }
            }
            List<UserFilters> userFiltersList = new ArrayList<UserFilters>();
            for (int i = 0; i < filtersArray.length; i++) {
                UserFilters userFilter = new UserFilters();
                String[] filterParams = filtersArray[i].split(",");
                if (filterParams != null) {
                    userFilter.setFilterID(filterParams[0]);
                    userFilter.setFilterName(filterParams[1]);
                    userFilter.setRequestOwner(filterParams[2]);
                    userFilter.setRequestPriority(filterParams[3]);
                    userFilter.setRequestSeverity(filterParams[4]);
                    userFilter.setRequestStatus(filterParams[5]);
                    userFilter.setRequestType(filterParams[6]);
                    userFiltersList.add(userFilter);
                }
            }
            if (userFiltersList != null && userFiltersList.size() > 0) {
                sql_delFilters = "DELETE oam_rm_userpreferenceforlite WHERE USERID='"
                        + userID
                        + "' and filterid in("
                        + deletedFilters + ")";
                try {
                    if (myConn == null) {
                        this.connectDB();
                    }
                    Statement stmt = myConn.createStatement();
                    for (UserFilters userFilter : userFiltersList) {
                        String sql = "MERGE INTO oam_rm_userpreferenceforlite pref "
                                + "USING (SELECT '"
                                + userFilter.getFilterID()
                                + "' filterid "
                                + "       FROM   dual)pref1 "
                                + "ON (pref1.filterid=pref.filterid) "
                                + " WHEN matched THEN "
                                + "  UPDATE SET filtername = '"
                                + userFilter.getFilterName()
                                + "',"
                                + "reqtype='"
                                + userFilter.getRequestType()
                                + "',reqstatus='"
                                + userFilter.getRequestStatus()
                                + "',"
                                + "reqseverity='"
                                + userFilter.getRequestSeverity()
                                + "',reqpriority='"
                                + userFilter.getRequestPriority()
                                + "',"
                                + "reqowner='"
                                + userFilter.getRequestOwner()
                                + "'"
                                + " WHEN NOT matched THEN "
                                + "  insert (userid,filtername,reqtype,reqstatus,reqseverity,reqpriority,reqowner)"
                                + "  VALUES ('"
                                + userID
                                + "','"
                                + userFilter.getFilterName()
                                + "','"
                                + userFilter.getRequestType()
                                + "',"
                                + "'"
                                + userFilter.getRequestStatus()
                                + "','"
                                + userFilter.getRequestSeverity()
                                + "','"
                                + userFilter.getRequestPriority()
                                + "',"
                                + "'"
                                + userFilter.getRequestOwner() + "')";
                        stmt.executeQuery(sql);
                    }
                    stmt.execute(sql_delFilters);
                    if (deletePreferredFilter) {
                        stmt.execute(sql_updatePreferredFilter);
                    }
                } catch (Exception ex) {
                    System.out
                            .println("Exception updating user custom filters:"
                                    + ex.getMessage());
                    System.out.println(ex.getStackTrace());
                } finally {
                    try {
                        this.takeDown();
                    } catch (Exception ex) {
                        System.out
                                .println("Exception closing connection in updateusercustomFilter:");
                        ex.printStackTrace();
                    }
                }

            }
        }

        return true;

    }

    /**
     *
     * Description:given the userid return his details UserManager
     *
     * @param userID
     * @return User Author:Ramesh Raj Baral
     * @since Aug 27, 2010
     */
    public User getUserDetails(String userID) {
        User user = null;
        strSQL = "select * from usr_Users where UserID = '" + userID.trim() + "'";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                user = new User();
                user.setLoginName(myRS.getString("loginname"));
                user.setUserName(myRS.getString("username"));
                user.setUserEmail(myRS.getString("email"));
            }

        } catch (Exception e) {
            System.out.print("error" + e.getMessage());
        } finally {
            this.takeDown();
        }

        return user;
    }

}
