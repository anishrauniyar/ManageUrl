package com.d2hs.soam;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;


import java.sql.*;
import java.io.*;
import java.util.*;
import java.net.*;
import java.text.SimpleDateFormat;


public abstract class BaseBean extends com.d2hs.soam.SqlBean
{

	protected String mess="base class defined";
	//protected ResultSet	myRS	= null;
	protected Statement	stmt	= null;
	//protected String strSQL		= "";
	protected String errorStr	= "";

    
	public BaseBean() {}

	public String getParam(String name)
    {
    	String id="";
	    try{
    	    id=myRS.getString(name);
            id = (id==null)?"":id;
	    }
        catch(SQLException se){mess=se.getMessage();}
	    return id;
    }

    public String getParameter(String name)
    {
    	String id="";
	    try{
    	    id=myRS.getString(name);
            id = (id==null)?"":id;
	    }
        catch(SQLException se){mess=se.getMessage();}
	    return id;
    }


    public String getParam(String name,String format) throws Exception
    {
	    String id="0";
    	if(format.equals("sdate"))
        {
	    	try
            {
		        id=String.valueOf(myRS.getDate(name));
        		if(!id.equals("null"))
		    	{
                    id=id.substring(0,10);
			        id=getFormattedDate(id);//convert it to dd/mm/yyyy
			    }
        		else
                    id="N/A";
		    }
            catch(SQLException se){mess=se.getMessage();}
	    }

    	else if(format.equals("int"))
        {
	    	try{
		        id=String.valueOf(myRS.getInt(name));
		    }
            catch(SQLException se){mess=se.getMessage();}
	    }

    	else if(format.equals("bool"))
        {
		    try{
    		    boolean temp=myRS.getBoolean(name);
	    	    id=(temp==true)?"y":"n";
		    }
            catch(SQLException se){mess=se.getMessage();}
	    }

    	if(id.equals("null"))
            id="";

    	return id;
    }



    //Date and Time
	public String getShortDate()
    {
	    String date = "";
    	java.util.Calendar cal = java.util.Calendar.getInstance();

	    date = Integer.toString( 1 + cal.get(java.util.Calendar.MONTH)) + "/" + Integer.toString(cal.get(java.util.Calendar.DATE)) + "/" + Integer.toString(cal.get(java.util.Calendar.YEAR));
	    //NOTE:= 1 is added to the MONTH because java returns 0 for January and so on
        // whereas we need 1 for     Jan and so on

        return (date);
	}


	//takes a date string of form yyyy-mm-dd and returns one of
	//the format mm/dd/yyyy
	public String getFormattedDate(String str) throws Exception
	{
    	SimpleDateFormat sdfInput =
                       new SimpleDateFormat( "yyyy-MM-dd" );
        SimpleDateFormat sdfOutput =
                       new SimpleDateFormat ( "MM/dd/yyyy" );

        java.util.Date date = sdfInput.parse( str );
        return sdfOutput.format( date ) ;
	}


	//returns time in the format hour:minute
	public String getShortTime()
    {
    	String time="";
	    java.util.Calendar cal=java.util.Calendar.getInstance();

	    time = Integer.toString(cal.get(java.util.Calendar.HOUR_OF_DAY)) + ":"+Integer.toString(cal.get(java.util.Calendar.MINUTE));

	    //NOTE:= 1 is added to the MONTH because java returns 0 for January and so
        // on whereas we need 1 for Jan and so on
	    return (time);
	}


    //General
	public String getbaseBeanMessage()
    {
	    return this.mess;
	}

	public String getSQL()
    {
	    return this.strSQL;
	}


    //Clean up process
	public void takeDown()
    {
		super.takeDown();
		this.mess="connection closed";
	}


	public boolean moveNext()
    {
		boolean retVal=false;
		try{

			retVal=myRS.next();
			}catch (SQLException se){mess=se.getMessage();}
		return retVal;
	}


    //String manipulation
	public String insertSpace(String s,int length)
	{
    	String retstr = new String();
	    String temp   = new String();

        if(s.length() > length)
	    {
		    int n = s.length()/length;
    		for(int i=0; i<=n; i++)
		    {
			    if(i<n)
			    {
                    temp=s.substring(i*length,i*length+length);
					retstr=retstr+temp+" ";
			    }
    			else
	    		{
                    temp=s.substring(i*length);
			        retstr=retstr+temp;
                }
		    }
	    }
	    else
        {
            retstr=s;
        }

    	return retstr;
	}


	public String truncate(String s,int length)
	{
	    String retstr=new String();
	    retstr=s;

        if(s.length()>length)
            retstr=s.substring(0,length);
	    return retstr;
	}
	public String getNextOrder(String selorderField,String field,String order)
	{
		if((field.indexOf(selorderField)>=0)&&order.equals("DESC"))
		{
			return "ASC";
		}
		else return("DESC");
	}

	public boolean getList(String sqlStr,String whatToList)
    {
		boolean flag = false;
		try{
			closeRecordSet();
			stmt = myConn.createStatement();
			myRS = stmt.executeQuery(sqlStr);
			flag = true;
			strSQL=sqlStr;
		}
		catch(SQLException sqlexception){
			errorStr = whatToList + " Listing Error : " + sqlexception;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return flag;
	}
    public String makeSQLCompatible(String data){
      if(data.equals("")){
          return "NULL";
      }
      else{
        return "'"+data.replace('\'','`')+"'";
      }
    }
     public String getSQLSubQuery(String s){
          if((s.indexOf(">")==0) || (s.indexOf("<")==0)){
              return(s);
          }
          else if(s.indexOf("-")>0){
              return(" BETWEEN " + s.substring(0,s.indexOf("-")) + " AND " + s.substring(s.indexOf("-")+1));
          }
          else{
              return("="+s);
          }
      }
     public String getDateRange(String d)
        {
            String delim="";
            String d1="";
            String d2="";
            String x="";
            d	= d.toLowerCase().replaceAll("between","").replaceAll("and","-");
            if(d.indexOf(">")>=0) {
                delim=">";
            }
            else if(d.indexOf("<")>=0) {
                delim="<";
            }
            else if(d.indexOf("-")>=0) {
                delim="-";
            }

            if(delim.length()>0){
                StringTokenizer st=new StringTokenizer(d,delim);
                while(st.hasMoreTokens()){
                    d2=st.nextElement().toString();
                    if(d1.length()==0){
                        d1=d2;
                    }
                }
            }
            else{
                d2=d;
                delim="=";
            }

            if(delim.equals("-")){
                x = " BETWEEN ('" + d1 + "') AND ('" + d2 + "')";
            }
            else {
                x = " " + delim + " '" + d2 + "'";
            }
            return x;
        }

    

	public boolean closeRecordSet()
    {
		boolean flag=false;
		try{
			if(myRS !=null){
				myRS.close();
				myRS = null;
			}
			flag=true;
		}
		catch(SQLException sqlexception){
			errorStr = "Recordset close error : " + sqlexception;
		}
		return flag;
	}

}

