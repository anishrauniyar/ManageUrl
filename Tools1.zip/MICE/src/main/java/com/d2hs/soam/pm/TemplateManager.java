package com.d2hs.soam.pm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.d2hs.soam.RequestBean;

public class TemplateManager extends RequestBean {
	private final static Logger logger = Logger.getLogger(TemplateManager.class);
	private String strFilters	= "";

	public void filterTemplates(String fTemplateId, String fTemplateName,String fTemplateDesc,String fIssueTypeId, String fIssueTypeName)
    {
	    if(!fTemplateId.equals(""))
	    {
			strFilters	+= " AND a.templateid LIKE '%" + fTemplateId.replaceAll("'","''").trim() + "%'";
		}
	    if(!fTemplateName.equals(""))
	    {
	        strFilters	+= " AND lower(a.templatename) LIKE lower('%" + fTemplateName.replaceAll("'","''").trim() + "%')";
	    }
	    if(!fTemplateDesc.equals(""))
	    {
	        strFilters	+= " AND lower(a.description) LIKE lower('%" + fTemplateDesc.replaceAll("'","''").trim() + "%')";
	    }
	    if(!fIssueTypeName.equals(""))
	    {
	        strFilters	+= " AND lower(c.issuetypename) LIKE lower('%" + fIssueTypeName.replaceAll("'","''").trim() + "%')";
	    }
    }
	
	public boolean getTemplatesWithRequestType() {
		boolean result = false;
		strSQL = ""
				+ "SELECT a.templateid, "
				+ "       a.templatename, "
				+ "       a.description, "
				+ "       b.issuetypeid, "
				+ "       c.issuetypename, "
				+ "       c.issuetypetarget "
				+ "FROM   oam_cr_templates a "
				+ "       left join oam_cr_template_issuetype b "
				+ "              ON a.templateid = b.templateid "
				+ "       left join oam_cr_issuetype c "
				+ "              ON b.issuetypeid = c.issuetypeid "
				+ "WHERE  1 = 1 ";
		
		strSQL += strFilters;
		strSQL += " order by templateid";
		System.out.println("Query for getting templates>>>>>>>>>>>>>>>"+strSQL);
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getTemplates()<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	
	/**
	 * @Description : Returns following template details
	 * 				 1. TemplateId
	 * 				 2.	TemplateName
	 * 				 3.	TemplateDesc
	 * 				 4. IssueTypeId	
	 * 				 5. IssueTypeName
	 * 				 6. Sums phasetarget for each template	
	 */
	public boolean getTemplatesDetails() {
		boolean result = false;
		strSQL = ""
				+ "SELECT a.templateid, "
				+ "       a.templatename, "
				+ "       a.description, "
				+ "       b.issuetypeid, "
				+ "       c.issuetypename, "
				+ "       c.issuetypetarget, "
				+ "       SUM(d.phasetarget) AS phasetarget "
				+ "FROM   oam_cr_templates a "
				+ "       left join oam_cr_template_issuetype b "
				+ "              ON a.templateid = b.templateid "
				+ "       left join oam_cr_issuetype c "
				+ "              ON b.issuetypeid = c.issuetypeid "
				+ "       left join oam_cr_template_phases c "
				+ "              ON a.templateid = c.templateid "
				+ "       left join oam_cr_phases d "
				+ "              ON c.phaseid = d.phaseid "
				+ "WHERE  1 = 1 "
				+ "GROUP  BY a.templateid, "
				+ "          a.templatename, "
				+ "          a.description, "
				+ "          b.issuetypeid, "
				+ "          c.issuetypename, "
				+ "          c.issuetypetarget";
		
		strSQL += strFilters;
		strSQL += " order by templateid";
		logger.debug("[TemplateManager.java->getTemplateDetails()] Query : "+strSQL);
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (SQLException e) {
			logger.error("[TemplateManager.java->getTemplateDetails()]"+ strSQL,e);
		}
		return result;
	}
	
	public void setTemplateId(String fTemplateId){
		if(!fTemplateId.equals(""))
	    {
			strFilters	+= " AND a.templateid LIKE '" + fTemplateId.replaceAll("'","''").trim() + "'";
		}
	}
	
	public boolean getNotAssignedPhaseListForTemplate(String templateId){
		boolean result =false;
		strSQL = ""
				+ "SELECT a.phaseid, "
				+ "       a.phasename "
				+ "FROM   oam_cr_phases a ";
		if(templateId!=""){
			strSQL +=" WHERE a.isdeleted='N' and a.phaseid NOT IN (SELECT b.phaseid "
				   + " FROM   oam_cr_template_phases b "
				   +"  WHERE   b.templateid = "+templateId+")";
		}
		System.out.println("Query to get assigned phase list for template is >>>>"+strSQL);
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getNotAssignedPhaseListForRequestType("+templateId+")<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean getAssignedPhaseListForTemplate(String templateId){
		boolean result =false;
		strSQL = ""
				+ "SELECT a.phaseid, "
				+ "       b.phasename "
				+ "FROM   oam_cr_template_phases a "
				+ "       left join oam_cr_phases b "
				+ "              ON a.phaseid = b.phaseid "
				+ "WHERE  a.templateid = "+templateId+" "
				+ "ORDER  BY a.phaseorder ";
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getAssignedPhaseListForTemplate("+templateId+")<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean getIssueTypes(){
		boolean result =false;
		strSQL = "select * from oam_cr_issuetype where 1=1 order by ISSUETYPEID";
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getIssueType()<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	public String addTemplateAndPhasesWithIssueType(String templateName,String templateDesc,String[] phaseIdList,String issueTypeId,String userId,String issueTypeTarget){
		String isInserted = "false";
		String templateId = "";
		try
        {
		  	
          if (checkTemplateForIssueType(issueTypeId))
          {
              isInserted = "templateExists";
              return isInserted;
          }
          if (checkTemplateName(templateName)){
        	  isInserted = "templateNameExists";
              return isInserted;
          }
          
          updateIssueTypeTarget(issueTypeId,issueTypeTarget);
          addTemplate(templateName,templateDesc,userId);
          templateId = getTemplateId(templateName);
          insertPhasesIntoTemplate(templateId, phaseIdList);
          insertTemplateForIssueType(templateId, issueTypeId);
          isInserted = "true";
      }
      catch (Exception e) 
      {
    	  //deleteTemplate(templateName);
    	  System.out.println("\nError:[default-war/com/d2hs/soam/pm/TemplateManager.java]->addTemplate()<- "+ strSQL);
		  e.printStackTrace();
      }
		
		return isInserted;
	}
	
	public boolean checkTemplateForIssueType(String issueTypeId) throws SQLException{
		boolean templateFound = false;
		strSQL = "Select count(*) n from oam_cr_template_issuetype where issueTypeId = "+issueTypeId+"";
		
		stmt=myConn.createStatement();
		myRS = stmt.executeQuery(strSQL);
		myRS.next();
        int count = Integer.parseInt(myRS.getString("n".trim()));
        //System.out.println ("Count is>>>>"+count);
        if (count > 0)
        {
        	templateFound = true;
        }
        closeStatement(stmt);
        return templateFound;
	}
	
	public boolean checkTemplateName(String templateName) throws SQLException{
		boolean isInserted = false;
		strSQL = "Select count(*) n from oam_cr_templates where upper(templatename) like '" +templateName.toUpperCase()+ "' ";
		
		stmt=myConn.createStatement();
		myRS = stmt.executeQuery(strSQL);
		myRS.next();
        int count = Integer.parseInt(myRS.getString("n".trim()));
        //System.out.println ("Count is>>>>"+count);
        if (count > 0)
        {
            isInserted = true;
        }
        closeStatement(stmt);
        System.out.println("Checking template Name >>>>>>>>>>>>>>>>:"+isInserted);
        return isInserted;
	}
	
	public void updateIssueTypeTarget(String issueTypeId, String issueTypeTarget)
			throws SQLException {
		strSQL = "update oam_cr_issuetype set issuetypetarget="
				+ issueTypeTarget + " where issueTypeId = " + issueTypeId;
		stmt = myConn.createStatement();
		stmt.execute(strSQL);
		closeStatement(stmt);
	}
	public void addTemplate(String templateName,String templateDesc,String userId) throws SQLException{
		 strSQL="insert into oam_cr_templates "+
                  " (templatename,description,createdby,createdon,isdeleted)"+
                  " VALUES (" + SQLEncode(templateName) + "," +
                           SQLEncode(templateDesc) + "," +"'"+ 
                           userId+"',"+
                           "sysdate"+","+
                           "'N'"+
                           " )" ;
		 stmt=myConn.createStatement();
		 stmt.execute(strSQL);
		 closeStatement(stmt);
	}
	
	public String getTemplateId(String templateName) throws SQLException {
		String templateId = "0";
		strSQL = "select templateId from oam_cr_templates where upper(templatename) = '"
				+ templateName.toUpperCase() + "'";
		stmt = myConn.createStatement();
		
		myRS = stmt.executeQuery(strSQL);
		myRS.next();
		
		templateId = myRS.getString("templateId");
		closeStatement(stmt);
		return templateId;
	}
	
	public void insertTemplateForIssueType(String templateID,String issueTypeId) throws SQLException{
		strSQL = "INSERT INTO OAM_CR_TEMPLATE_ISSUETYPE (TEMPLATEID,ISSUETYPEID) VALUES ("+templateID+","+issueTypeId+")";
		stmt = myConn.createStatement();
		stmt.execute(strSQL);
		closeStatement(stmt);
	}
	
	public void deleteTemplate(String templateName){
		String query = "delete oam_cr_templates where upper(templatename) = '" +templateName.toUpperCase()+ "' ";
		try
        {
			stmt=myConn.createStatement();  
			stmt.execute(query);
        }
		catch (Exception e) 
		{
			System.out.println("Could not delete template "+templateName+"-> "+query);
		}
		finally{
			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					System.out.println("Error closing statement!!!!");
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	public boolean updateTemplateAndPhases(String templateId,String templateName,String templateDesc,String[] phaseIdList,String IssueTypeId,String IssueTypeTarget){
		boolean isUpdated = false;
		try
        {
			updateTemplate(templateId,templateName,templateDesc);
			updateIssueTypeTarget(IssueTypeId, IssueTypeTarget);
			deletePhasesFromTemplate(templateId);
			insertPhasesIntoTemplate(templateId,phaseIdList);
			isUpdated = true;
        }
        catch (Exception e) 
        {
    	  System.out.println("\nError:[default-war/com/d2hs/soam/pm/TemplateManager.java]->" 
    			  			+"updateTemplateAndPhases("+templateId+","+templateName+","+templateDesc+","+phaseIdList.length+","+IssueTypeId+","+IssueTypeTarget+"->"+strSQL);
		  e.printStackTrace();
        }
		
		return isUpdated;
	}
	
	public void updateTemplate(String templateId,String templateName,String templateDesc) throws SQLException{
		strSQL = "UPDATE OAM_CR_TEMPLATES SET TEMPLATENAME = "+SQLEncode(templateName)+", DESCRIPTION = "+SQLEncode(templateDesc)+" WHERE TEMPLATEID = "+templateId+"";
		Statement stmnt=myConn.createStatement();
		stmnt.execute(strSQL);
	}
	
	public void deletePhasesFromTemplate(String templateId) throws SQLException{
		strSQL = "DELETE FROM OAM_CR_TEMPLATE_PHASES WHERE TEMPLATEID = "+templateId+"";
		stmt=myConn.createStatement();
		stmt.execute(strSQL);
		closeStatement(stmt);
	}
	
	
	public void insertPhasesIntoTemplate(String templateId,String[] phaseIdList) throws SQLException{
		stmt=myConn.createStatement();
		for(int i =0 ;i<phaseIdList.length;i++)
		{
      	  strSQL =" INSERT INTO OAM_CR_TEMPLATE_PHASES (TEMPLATEID,PHASEID,PHASEORDER) "+
				  " VALUES ("+templateId+","+phaseIdList[i]+","+(i+1)+")";
      	  stmt.addBatch(strSQL);
		}
		stmt.executeBatch();
		closeStatement(stmt);
	}
	
	public void closeStatement(Statement stmt) throws SQLException{
		if(stmt!=null){
			stmt.close();
		}
	}
}
