package com.d2hs.soam.rm.CMMI_Report;

import java.sql.*;
import java.io.*;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.util.*;
import java.text.*;

import com.d2hs.soam.BaseBean;





public class CMMIReport extends BaseBean {
	private String mess	= "";
	private String tableName	= "oam_rm_requestmanager";
		
	public boolean getUser(String uid) throws Exception
    {
        boolean retVal=false;
          strSQL="SELECT USERNAME FROM HEUSER.USR_USERS WHERE USERID='"+uid+"'";       
        try{
            stmt=myConn.createStatement();   
            myRS=stmt.executeQuery(strSQL);   
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getUser()"+se);mess=se.getMessage();}
        mess="ok";
        return retVal;                         
    }     
	public boolean getClients() throws Exception   
    {
        boolean retVal=false;
          strSQL="SELECT CLIENTID,CLIENTNAME FROM OAM_RM_CLIENTS ORDER BY CLIENTNAME";       
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getClients()<-"+se);mess=se.getMessage();}
        mess="ok";
        return retVal;                          
    }
	public boolean getProducts(String clientID) throws Exception   
    {
        boolean retVal=false;
          strSQL="SELECT PRODUCTID,PRODUCTNAME FROM OAM_RM_PRODUCTS WHERE CLIENTID='" + clientID + "' ORDER BY PRODUCTNAME";          
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);      
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getProducts()-->"+se);mess=se.getMessage();}
        mess="ok";
        return retVal;                          
    }
	public boolean getProjects(String productID) throws Exception   
    {
        boolean retVal=false;
          strSQL="SELECT PROJECTID,PROJECTNAME FROM OAM_RM_PROJECTS WHERE PRODUCTID='" + productID + "'";                 
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);           
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getProjects()-->"+se);mess=se.getMessage();}
        mess="ok";     
        return retVal;                                 
    }
	public boolean getProviders(String projectID,String userID) throws Exception   
    {
        boolean retVal=false;
          strSQL="select clientid as ProviderID,clientname as ProviderName from oam_clients where clientid in " +
          		"(select clientid from oam_dataclient_relations where projectid='"+projectID+"')";   
          strSQL +="and clientid IN " + super.getAccesibleClients(userID);
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);           
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getProviders()-->"+se);mess=se.getMessage();}
        mess="ok";     
        return retVal;                                 
    }
	public boolean getPostType() throws Exception   
    {
        boolean retVal=false;
          strSQL="SELECT REQUESTTYPEID,REQUESTTYPEDESC FROM OAM_RM_REQUEST_TYPES";                 
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);           
            retVal=true;
        }catch (SQLException se){
            System.out.println("\n getPostType()-->"+se);mess=se.getMessage();}
        mess="ok";     
        return retVal;                                 
    }
	/**
	 * @author rsah
	 * @Desc --> to get no. of request for age report
	 * @param f
	 * @param t
	 * @param cid
	 * @param prodid
	 * @param projid
	 * @return
	 * @throws Exception
	 */
	
	public boolean getNoOfRequests(String f,String t,String cid,String prodid,String projid) throws Exception
	{
		boolean retVal=false;
		strSQL="select REQUESTTYPEDESC,sum(count) count from(";
		strSQL+=(getNoOfRequestsQuery("oam_rm_requestmanager",f,t,cid,prodid,projid)
				+" UNION ALL "+getNoOfRequestsQuery("oam_rm_requestmanager_annal",f,t,cid,prodid,projid));
		strSQL+=") group by requesttypedesc";
       try{
           stmt=myConn.createStatement();               
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getNoOfRequests()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	} 
	
	public String getNoOfRequestsQuery(String tableName,String f,String t,String cid,String prodid,String projid){
		
        strSQL="select b.requesttypedesc,case when count(*) is null then 0 else count(*) end as" +
        		" count from "+tableName+" a inner join oam_rm_request_types b on a.REQUESTTYPEID = b.requesttypeid" +
        		" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " ;
       if(!cid.equals(""))
        {
       	
        strSQL+=" and a.clientid='"+cid+"'" ;
        }
       if(!prodid.equals(""))
       {
        strSQL+=" and a.productid='"+prodid+"' " ;
       }
       if(!projid.equals(""))
       {
       strSQL+=" and a.projectid='"+projid+"'";
       }
       strSQL+=" group by b.requesttypedesc";
        return strSQL;
		
	}
	
	/**
	 * @author rsah
	 * @param f
	 * @param t
	 * @param cid
	 * @param prodid
	 * @param projid
	 * @return
	 * @throws Exception
	 */
	
	public boolean getTitles(String versionid) throws Exception
	{
		boolean retVal=false;
		strSQL="select distinct(requesttitle) from(";
		strSQL+=(getTitleQuery("oam_rm_requestmanager",versionid)+" UNION ALL "+getTitleQuery("oam_rm_requestmanager_annal",versionid));
		strSQL+=") order by lower(requesttitle)";
       try{
           stmt=myConn.createStatement(); 
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){   
           System.out.println("\nError:getTitles()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	} 
	
	public String getTitleQuery(String tableName,String versionid){
        strSQL="select distinct(requesttitle) requesttitle from "+tableName+" where clientid in (select clientid from " +
 		"oam_rm_clients where clientname='D2Hawkeye') and productid in (select productid from oam_rm_products " +
 		"where productname='CMMI3') " +
 		"and detectedversion='"+versionid+"'"  ;
        return strSQL;
		
	}
	
	/**
	 * @author rsah
	 * @return
	 * @throws Exception
	 */
	
	public boolean getAuditVersion() throws Exception
	{
		boolean retVal=false;
         strSQL="select distinct (versiondesc),versionid from oam_rm_productversion" +
         		" where  productid in (select productid from oam_rm_products " +
         		"where productname='CMMI3') order by lower(versiondesc)" ;             
       try{
           stmt=myConn.createStatement();               
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getAuditVersion()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	}  
	/**
	 * @author rsah
	 * @Desc --> to get completed, completed+open, closed, closed+completed+open for age report
	 * @param f
	 * @param t
	 * @param cid
	 * @param prodid
	 * @param projid
	 * @return
	 * @throws Exception
	 */
	
	public boolean getAgeReportData(String f,String t,String cid,String prodid,String projid) throws Exception
	{
		boolean retVal=false;
		strSQL="select requesttypedesc,sum(COMPLETEDCOUNT) COMPLETEDCOUNT, " +
				" case when sum(COMPLETEDCOUNT)=0 then 0 else round(sum(COMPLETEDCOUNT* COMPLETED)/(sum(COMPLETEDCOUNT)),3) end as COMPLETED," +
				" sum(OPENCOMPLETEDCOUNT) OPENCOMPLETEDCOUNT, case when sum(OPENCOMPLETEDCOUNT)=0 then 0 else round(sum(OPENCOMPLETEDCOUNT* OPENCOMPLETED)/(sum(OPENCOMPLETEDCOUNT)),3) end as OPENCOMPLETED," +
				" sum(CLOSEDCOUNT) CLOSEDCOUNT, case when sum(CLOSEDCOUNT)=0 then 0 else round(sum(CLOSEDCOUNT* CLOSED)/(sum(CLOSEDCOUNT)),3) end as CLOSED," +
				" sum(OPENCOMPLETEDCLOSEDCOUNT) OPENCOMPLETEDCLOSEDCOUNT, case when sum(OPENCOMPLETEDCLOSEDCOUNT)=0 then 0 else round(sum(OPENCOMPLETEDCLOSEDCOUNT* OPENCOMPLETEDCLOSED)/(sum(OPENCOMPLETEDCLOSEDCOUNT)),3) end as OPENCOMPLETEDCLOSED from(";
		strSQL+=(getAgeReportDataQuery("oam_rm_requestmanager",f,t,cid,prodid,projid)
				+" UNION ALL "+getAgeReportDataQuery("oam_rm_requestmanager_annal",f,t,cid,prodid,projid));
		strSQL+=") group by REQUESTTYPEDESC";
		//strSQL=(getAgeReportDataQuery("oam_rm_requestmanager_all",f,t,cid,prodid,projid));
        System.out.println("getAgeReportData->"+strSQL);
        
       try{
           stmt=myConn.createStatement();                 
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getAgeReportData()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                 	
	} 
	
	public String getAgeReportDataQuery(String tableName,String f,String t,String cid,String prodid,String projid){
		strSQL="select requesttypedesc," +
		"(MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as CompletedCount, "+
      "case when MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 "+
      "then 0 else "+  
      "round((MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3)  end as Completed," +
      "(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as OpenCompletedCount, "+
      "case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 "+
      "then 0 else "+ 
      "round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3) "+ 
      "end as OpenCompleted," +
      "(MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as ClosedCount, "+
      "case when MAX(DECODE(STATUSDESC, 'Closed', CT, 0))=0 "+
      "then 0 else "+ 
      "round((MAX(DECODE(STATUSDESC, 'Closed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as Closed," +
      "(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as OpenCompletedClosedCount, "+
      "case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Closed', CT, 0))!=0 "+
       "then 0 else "+ 
       "round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0))+MAX(DECODE(STATUSDESC, 'Closed', Days, 0))) /(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as OpenCompletedClosed "+
       "FROM "+ 
"("+
"select * from "+ 
"("+
"select c.requesttypedesc,b.statusdesc,count(*) ct,sum(e.completedate-d.assigneddate) days "+
" from "+tableName+" a "+ 
"inner join oam_rm_requeststatus b on a.statusid=b.statusid "+ 
"inner join oam_rm_request_types c on a.requesttypeid=c.requesttypeid "+
"inner join "+
"( "+
"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where "+ 
"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') "+  
"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"group by requestcode"+
")d "+
"on a.requestcode=d.requestcode "+
"inner join "+
"("+
"select requestcode,max(lastupdateddate) completedate FROM OAM_RM_ARCHIVE where "+ 
"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Completed') "+ 
"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"group by requestcode"+
")e "+
"on a.requestcode=e.requestcode "+
"where 1=1";
if(!cid.equals(""))
{
 strSQL+=" and a.clientid='"+cid+"'";
}
if(!prodid.equals(""))
{
 strSQL+=" and a.productid='"+prodid+"'";      
}
if(!projid.equals(""))
{
strSQL+= " and a.projectid='"+projid+"'";
}
strSQL+=" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"and b.statusdesc in ('Completed','QC Completed') "+
"group by c.requesttypedesc,b.statusdesc"+ 
")"+
"union "+
"select * from "+
"("+
"select c.requesttypedesc,b.statusdesc,count(*)  ct,sum(e.closeddate-d.assigneddate) days "+
"from "+tableName+" a "+ 
"inner join oam_rm_requeststatus b on a.statusid=b.statusid "+ 
"inner join oam_rm_request_types c on a.requesttypeid=c.requesttypeid "+
"inner join "+
"("+
"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where "+ 
"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') "+ 
"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"group by requestcode"+
")d "+
"on a.requestcode=d.requestcode "+
"inner join "+
"("+
"select requestcode,max(lastupdateddate) closeddate FROM OAM_RM_ARCHIVE where "+ 
"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Closed') "+  
"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"group by requestcode"+
")e "+
"on a.requestcode=e.requestcode "+
"where 1=1" ;
if(!cid.equals(""))
{
strSQL+=" and a.clientid='"+cid+"'";
}
if(!prodid.equals(""))
{
strSQL+="and a.productid='"+prodid+"'";
}
if(!projid.equals(""))
{
strSQL+="and a.projectid='"+projid+"'";
}
strSQL+="and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"and b.statusdesc in ('Closed') "+
"group by c.requesttypedesc,b.statusdesc"+ 
") "+
"union "+
"select * from "+
"("+
"select c.requesttypedesc,'Open' as statusdesc,count(*)  ct,sum(to_date('"+t+"','mm/dd/yyyy')-d.assigneddate) days "+
"from "+tableName+" a "+ 
"inner join "+
"("+
"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where "+ 
"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') "+ 
"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"group by requestcode"+
")d "+
"on a.requestcode=d.requestcode " +
"inner join oam_rm_archive e " +
"on a.requestcode=e.requestcode " +
"inner join oam_rm_requeststatus b on e.statusid=b.statusid " +
"inner join oam_rm_request_types c on e.requesttypeid=c.requesttypeid "+
"where (e.requestcode,e.lastupdateddate) in " +
"( " +
"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE " +
"where trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
"group by requestcode " +
") " ;

if(!cid.equals(""))
{
strSQL+=" and e.clientid='"+cid+"'";
}
if(!prodid.equals(""))
{
strSQL+="and e.productid='"+prodid+"'";
}
if(!projid.equals(""))
{
strSQL+="and e.projectid='"+projid+"'";
}
strSQL+=" and trunc(e.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') "+
"and b.statusdesc in ('Not Started','Assigned','In Progress') "+
"group by c.requesttypedesc,b.statusdesc"+ 
")"+
") "+   
"group by requesttypedesc";
return strSQL;

}

	/**
	 * @author rsah
	 * @Desc --> to get age in phases for age report
	 * @param f
	 * @param t
	 * @param cid
	 * @param prodid
	 * @param projid
	 * @return   
	 * @throws Exception
	 */
	
	public boolean getAgeInPhases(String f,String t,String cid,String prodid,String projid) throws Exception
	{
		tableName="oam_rm_requestmanager_all";
		boolean retVal=false;
         strSQL="select " +
         		"c.requesttypedesc,round(avg(e.phaseinjecteddate-d.phasedetecteddate),3) days " +
         		"from "+tableName+" a " +
         		"inner join oam_rm_request_types c on a.requesttypeid=c.requesttypeid " +
         		"inner join (SELECT requestcode,min(lastupdateddate) phasedetecteddate FROM" +
         		" OAM_RM_ARCHIVE where phasedetected is not null and phasedetected!=0 " +
         		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"group by requestcode)d on a.requestcode=d.requestcode inner join " +
         		"(SELECT requestcode,min(lastupdateddate) phaseinjecteddate FROM OAM_RM_ARCHIVE where " +
         		"phaseinject is not null and phaseinject!=0 and trunc(lastupdateddate) between" +
         		" to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode)e " +
         		"on a.requestcode=e.requestcode where 1=1";
         		if(!cid.equals(""))
         		{
         			strSQL+= " and a.clientid='"+cid+"'";
         		}   
         		if(!prodid.equals(""))
         		{
         			strSQL+=" and a.productid='"+prodid+"'";
         		}
         		if(!projid.equals(""))
         		{
         		strSQL+=" and a.projectid='"+projid+"'";	
         		}
         		strSQL+=" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         				" and a.requesttypeid= (select requesttypeid from oam_rm_request_types where requesttypedesc like 'Defect') " +
         		" group by c.requesttypedesc"; 
         		
  
       try{
           stmt=myConn.createStatement();  
           System.out.println("SQL->"+strSQL);
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getAgeInPhases()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	}
	
		
	/**
	 * @author rsah
	 * @Desc --> to get major, minor, total for different statue in Audit report
	 * @param f
	 * @param t
	 * @param cid
	 * @param prodid
	 * @param projid
	 * @return   
	 * @throws Exception
	 */
	
	public boolean getAuditReport(String f,String t,String vid,String reqTitle,String fAuditVersion,String fTitle, String fMajorOpen, String fMinorOpen, String fTotalOpen,String fMajorCompleted,String fMinorCompleted,String fTotalCompleted,String fMajorClosed,String fMinorClosed,String fTotalClosed, String fMajorTotal,String fMinorTotal,String fTotalTotal,String fCompleted,String fOpenCompleted,String fClosed,String fOpenCompletedClosed,String fObservationOpen,String fObservationCompleted,String fObservationClosed,String fObservationTotal) throws Exception
	{
		tableName="oam_rm_requestmanager";
		boolean retVal=false;
         strSQL="select * " +
         		"from (SELECT   case when versionDesc is null then 'No Version' else versionDesc end as versionDesc " +
         		",case when REQUESTTITLE is null then 'No Title' else REQUESTTITLE end as REQUESTTITLE," +
         		" MAX(DECODE(STATUSDESC, 'Open', Major, 0)) MajorOpen," +
         		" MAX(DECODE(STATUSDESC, 'Open', Minor, 0)) MinorOpen, " +
         		" MAX(DECODE(STATUSDESC, 'Open', Other, 0))+MAX(DECODE(STATUSDESC, 'Open', Major, 0))+MAX(DECODE(STATUSDESC, 'Open', Minor, 0)) TotalOpen, " +
         		"                  MAX(DECODE(STATUSDESC, 'Completed', Major, 0)) MajorCompleted, " +
         		"                  MAX(DECODE(STATUSDESC, 'Completed', Minor, 0)) MinorCompleted," +
         		"                  MAX(DECODE(STATUSDESC, 'Completed', Other, 0))+MAX(DECODE(STATUSDESC, 'Completed', Major, 0))+MAX(DECODE(STATUSDESC, 'Completed', Minor, 0)) TotalCompleted, " +
         		"                  MAX(DECODE(STATUSDESC, 'Closed', Major, 0)) MajorClosed, " +
         		"                  MAX(DECODE(STATUSDESC, 'Closed', Minor, 0)) MinorClosed, " +
         		"                  MAX(DECODE(STATUSDESC, 'Closed', Other, 0))+MAX(DECODE(STATUSDESC, 'Closed', Major, 0))+MAX(DECODE(STATUSDESC, 'Closed', Minor, 0)) TotalClosed, " +
         		"                  MAX(DECODE(STATUSDESC, 'Open', Major, 0))+MAX(DECODE(STATUSDESC, 'Completed', Major, 0))+MAX(DECODE(STATUSDESC, 'Closed', Major, 0))+MAX(DECODE(STATUSDESC, 'Other', Major, 0)) MajorTotal, " +
         		"                  MAX(DECODE(STATUSDESC, 'Open', Minor, 0))+MAX(DECODE(STATUSDESC, 'Completed', Minor, 0))+MAX(DECODE(STATUSDESC, 'Closed', Minor, 0))+MAX(DECODE(STATUSDESC, 'Other', Minor, 0)) MinorTotal, " +
         		"                  MAX(DECODE(STATUSDESC, 'Open', Other, 0))+MAX(DECODE(STATUSDESC, 'Completed', Other, 0))+MAX(DECODE(STATUSDESC, 'Closed', Other, 0))+MAX(DECODE(STATUSDESC, 'Other', Other, 0)) + " +
         		"                  MAX(DECODE(STATUSDESC, 'Open', Major, 0))+MAX(DECODE(STATUSDESC, 'Completed', Major, 0))+MAX(DECODE(STATUSDESC, 'Closed', Major, 0))+MAX(DECODE(STATUSDESC, 'Other', Major, 0)) + " +
         		"                  MAX(DECODE(STATUSDESC, 'Open', Minor, 0))+MAX(DECODE(STATUSDESC, 'Completed', Minor, 0))+MAX(DECODE(STATUSDESC, 'Closed', Minor, 0))+MAX(DECODE(STATUSDESC, 'Other', Minor, 0)) TotalTotal " +
         		"    FROM (     SELECT  versionDesc,REQUESTTITLE,STATUSDESC," +
         		"                  MAX(DECODE(MODULENAME, 'Major', CT, 0)) Major, " +
         		"                  MAX(DECODE(MODULENAME, 'Minor', CT, 0)) Minor, " +
         		"                  MAX(DECODE(MODULENAME, 'Other', CT, 0)) Other " +
         		" FROM (SELECT  versionDesc,REQUESTTITLE,  MODULENAME, STATUSDESC,  SUM(CT) CT " +
         		"FROM ( SELECT PV.VersionDesc, RM.REQUESTTITLE ," +
         		"  case when  MD.MODULENAME like 'Major NCs' then 'Major' " +
         		"         when MD.MODULENAME like 'Minor NCs' then 'Minor' " +
         		"           else 'Other' end as ModuleName," +
         		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
         		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
         		"         when ST.STATUSDESC in ('Closed')  then 'Closed' " +
         		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, " +
         		"         COUNT(* ) AS CT FROM     (          SELECT   REQUESTCODE," +
         		"                   MAX(LASTUPDATEDDATE) M   FROM     OAM_RM_ARCHIVE " +
         		"          WHERE    1 = 1  AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy')  GROUP BY REQUESTCODE ) A " +
         		"       inner join   OAM_RM_ARCHIVE RM " +
         		" on rm.requestcode=a.requestcode and rm.lastupdateddate=a.m " +
         		"  left join  oam_rm_productversion PV  " +
         		" on RM.DETECTEDVERSION=PV.versionid " +
         		"   LEFT JOIN  OAM_RM_MODULES MD " +
         		" on RM.MODULEID=MD.MODULEID " +
         		"  LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"  ON RM.STATUSID = ST.STATUSID WHERE    A.REQUESTCODE = RM.REQUESTCODE " +
         		"                AND rm.clientid=(select clientid from oam_rm_clients where clientname like 'D2Hawkeye') and rm.productid=(select productid from oam_rm_products where productname like 'CMMI3') " +
         		" and trunc(rm.requestdate) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') GROUP BY PV.versionDesc," +
         		"RM.REQUESTTITLE, MD.MODULENAME, ST.STATUSDESC) GROUP BY " +
         		"versionDesc,REQUESTTITLE,MODULENAME ,STATUSDESC ) " +
         		"GROUP BY versionDesc,REQUESTTITLE,STATUSDESC ) " +
         		"GROUP BY versionDesc,REQUESTTITLE ORDER BY versionDesc,REQUESTTITLE )a " +
         		"full outer join (select case when versionDesc is null then 'No Version' else versionDesc end as versionDesc, " +
         		"                 case when REQUESTTITLE is null then 'No Title' else REQUESTTITLE end as REQUESTTITLE, " +
         		"  (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as CompletedCount, " +
         		"                  case when MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 " +
         		"                  then 0 else " +
         		"   round((MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3)  end as Completed, " +
         		"                  (MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as OpenCompletedCount, " +
         		"                  case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 " +
         		"                  then 0 else " +
         		"                  round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3) " +
         		"                  end as OpenCompleted, " +
         		"                  (MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as ClosedCount, " +
         		"                  case when MAX(DECODE(STATUSDESC, 'Closed', CT, 0))=0  " +
         		"                  then 0 else " +
         		"                  round((MAX(DECODE(STATUSDESC, 'Closed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as Closed, " +
         		"                  (MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as OpenCompletedClosedCount, " +
         		"                  case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Closed', CT, 0))!=0 " +
         		"                   then 0 else round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0))+MAX(DECODE(STATUSDESC, 'Closed', Days, 0))) /(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as OpenCompletedClosed " +
         		"                   FROM (select * from (select f.versiondesc,a.REQUESTTITLE,b.statusdesc,count(*) ct,sum(e.completedate-d.assigneddate) days " +
         		" from "+tableName+" a inner join oam_rm_requeststatus b on a.statusid=b.statusid " +
         		" inner join (SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
         		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
         		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode)d " +
         		"on a.requestcode=d.requestcode inner join (select requestcode,min(lastupdateddate) completedate FROM OAM_RM_ARCHIVE where " +
         		"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Completed') " +
         		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"group by requestcode)e " +
         		"on a.requestcode=e.requestcode left join oam_rm_productversion f on f.versionid=a.detectedversion " +
         		"where a.clientid=(select clientid from oam_rm_clients where clientname like 'D2Hawkeye') and a.productid=(select productid from oam_rm_products where productname like 'CMMI3') and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"and b.statusdesc in ('Completed','QC Completed') group by f.versionDesc,a.requesttitle,b.statusdesc) " +
         		"union " +
         		"select * from (select f.versionDesc,a.REQUESTTITLE,b.statusdesc,count(*)  ct,sum(e.closeddate-d.assigneddate) days " +
         		"from "+tableName+" a inner join oam_rm_requeststatus b on a.statusid=b.statusid " +
         		"inner join ( SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
         		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
         		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode )d " +
         		"on a.requestcode=d.requestcode inner join ( select requestcode,min(lastupdateddate) closeddate FROM OAM_RM_ARCHIVE where " +
         		"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Closed') " +
         		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode )e " +
         		"on a.requestcode=e.requestcode left join oam_rm_productversion f on f.versionid=a.detectedversion " +
         		"where a.clientid=(select clientid from oam_rm_clients where clientname like 'D2Hawkeye') and a.productid=(select productid from oam_rm_products where productname like 'CMMI3') and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"and b.statusdesc in ('Closed') group by f.versionDesc,a.requesttitle,b.statusdesc ) union " +
         		"select * from ( select f.versionDesc,a.REQUESTTITLE,'Open' as statusdesc,count(*)  ct,sum(to_date('"+t+"','mm/dd/yyyy')-d.assigneddate) days " +
         		"from "+tableName+" a  " +
         		"inner join ( SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
         		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
         		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode )d " +
         		"on a.requestcode=d.requestcode " +
         		"inner join oam_rm_archive e " +
         		"on a.requestcode=e.requestcode " +
         		"inner join oam_rm_requeststatus b on e.statusid=b.statusid " +
         		"left join oam_rm_productversion f on f.versionid=a.detectedversion " +
         		"where (e.requestcode,e.lastupdateddate) in " +
         		"( " +
         		"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE " +
         		"where trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"group by requestcode " +
         		") " +
         		"and e.clientid=(select clientid from oam_rm_clients where clientname like 'D2Hawkeye') and e.productid=(select productid from oam_rm_products where productname like 'CMMI3') and trunc(e.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"and b.statusdesc in ('Not Started','Assigned','In Progress') " +
         		"group by f.versionDesc,a.requesttitle,b.statusdesc ) ) group by versionDesc,REQUESTTITLE )b " +
         		"on a.REQUESTTITLE=b.REQUESTTITLE and a.versiondesc=b.versiondesc " +
         		"full outer join (SELECT   case when versionDesc is null then 'No Version' else versionDesc end as versionDesc, " +
         		"                  case when REQUESTTITLE is null then 'No Title' else REQUESTTITLE end as REQUESTTITLE, " +
         		"MAX(DECODE(STATUSDESC, 'Open', CT, 0)) ObservationOpen, " +
         		"                  MAX(DECODE(STATUSDESC, 'Completed', CT, 0)) ObservationCompleted, " +
         		"                  MAX(DECODE(STATUSDESC, 'Closed', CT, 0)) ObservationClosed, " +
         		"                  MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))+MAX(DECODE(STATUSDESC, 'Other', CT, 0)) ObservationTotal " +
         		"FROM (SELECT PV.versionDesc, RM.REQUESTTITLE , MD.MODULENAME," +
         		"     case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
         		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
         		"         when ST.STATUSDESC in ('Closed')  then 'Closed' " +
         		"         else 'Other' end  as STATUSDESC, " +
         		"         COUNT(* ) AS CT FROM     (SELECT   REQUESTCODE," +
         		"                  MAX(LASTUPDATEDDATE) M  FROM     OAM_RM_ARCHIVE " +
         		"  WHERE    1 = 1  AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy')  GROUP BY REQUESTCODE ) A " +
         		" inner join  OAM_RM_ARCHIVE RM on rm.requestcode=a.requestcode and rm.lastupdateddate=a.m" +
         		" left join oam_rm_productversion pv " +
         		" on pv.versionid=rm.detectedversion  LEFT JOIN  OAM_RM_MODULES MD " +
         		"  on RM.MODULEID=MD.MODULEID  LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"ON RM.STATUSID = ST.STATUSID WHERE    A.REQUESTCODE = RM.REQUESTCODE " +
         		"AND rm.clientid=(select clientid from oam_rm_clients where clientname like 'D2Hawkeye') and rm.productid=(select productid from oam_rm_products where productname like 'CMMI3') and MD.MODULENAME like 'Observations' " +
         		"and trunc(rm.requestdate) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') GROUP BY PV.versionDesc, RM.REQUESTTITLE, MD.MODULENAME, " +
         		"ST.STATUSDESC ) GROUP BY versionDesc,REQUESTTITLE )c on b.requesttitle=c.requesttitle" +
         		" and b.VersionDesc = c.VersionDesc" +
         		" where 1=1 " ;
         		if(!vid.equals(""))
         		{
         			strSQL+="and a.versiondesc like (select versiondesc from oam_rm_productversion where versionid ='"+vid+"') ";
         		}
         		if(!reqTitle.equals(""))
         		{
         		strSQL+= " and a.requesttitle like '"+reqTitle+"' " ;
         				
         		}
         		if(!fAuditVersion.equals(""))
         		{
         			strSQL+= " and lower(a.versiondesc) like lower('%"+fAuditVersion+"%')";
         		}
         		if(!fTitle.equals(""))
         		{
         		strSQL+= " and lower(a.requesttitle) like lower('%"+fTitle+"%') " ;         				
         		}
         		if(!fMajorOpen.equals(""))
         		{
         			fMajorOpen=fMajorOpen.trim();
         			strSQL+=" AND MajorOpen  "+ getSQLSubQuery(fMajorOpen);
            	}
         		if(!fMinorOpen.equals(""))
         		{
         			fMinorOpen=fMinorOpen.trim();
         			strSQL+=" AND MinorOpen  "+ getSQLSubQuery(fMinorOpen);     
            	}
         		if(!fTotalOpen.equals(""))
         		{
         			fTotalOpen=fTotalOpen.trim();
         			strSQL+=" AND TotalOpen  "+ getSQLSubQuery(fTotalOpen);     
            	}
         		if(!fMajorCompleted.equals(""))
         		{
         			fMajorCompleted=fMajorCompleted.trim();
         			strSQL+=" AND MajorCompleted  "+ getSQLSubQuery(fMajorCompleted);     
            	}
         		if(!fMinorCompleted.equals(""))
         		{
         			fMinorCompleted=fMinorCompleted.trim();
         			strSQL+=" AND MinorCompleted  "+ getSQLSubQuery(fMinorCompleted);     
            	}
         		if(!fTotalCompleted.equals(""))
         		{
         			fTotalCompleted=fTotalCompleted.trim();
         			strSQL+=" AND TotalCompleted  "+ getSQLSubQuery(fTotalCompleted);     
            	}
         		if(!fMajorClosed.equals(""))
         		{
         			fMajorClosed=fMajorClosed.trim();
         			strSQL+=" AND MajorClosed  "+ getSQLSubQuery(fMajorClosed);     
            	}
         		if(!fMinorClosed.equals(""))
         		{
         			fMinorClosed=fMinorClosed.trim();
         			strSQL+=" AND MinorClosed  "+ getSQLSubQuery(fMinorClosed);     
            	}
         		if(!fTotalClosed.equals(""))
         		{
         			fTotalClosed=fTotalClosed.trim();
         			strSQL+=" AND TotalClosed  "+ getSQLSubQuery(fTotalClosed);     
            	}
         		if(!fMajorTotal.equals(""))
         		{
         			fMajorTotal=fMajorTotal.trim();
         			strSQL+=" AND MajorTotal  "+ getSQLSubQuery(fMajorTotal);     
            	}
         		if(!fMinorTotal.equals(""))
         		{
         			fMinorTotal=fMinorTotal.trim();
         			strSQL+=" AND MinorTotal  "+ getSQLSubQuery(fMinorTotal);     
            	}
         		if(!fTotalTotal.equals(""))
         		{
         			fTotalTotal=fTotalTotal.trim();
         			strSQL+=" AND TotalTotal  "+ getSQLSubQuery(fTotalTotal);     
            	}
         		if(!fCompleted.equals(""))
         		{
         			fCompleted=fCompleted.trim();
         			strSQL+=" AND Completed  "+ getSQLSubQuery(fCompleted);     
            	}
         		if(!fOpenCompleted.equals(""))
         		{
         			fOpenCompleted=fOpenCompleted.trim();
         			strSQL+=" AND OpenCompleted  "+ getSQLSubQuery(fOpenCompleted);     
            	}
         		if(!fClosed.equals(""))
         		{
         			fClosed=fClosed.trim();
         			strSQL+=" AND Closed  "+ getSQLSubQuery(fClosed);     
            	}
         		if(!fOpenCompletedClosed.equals(""))
         		{
         			fOpenCompletedClosed=fOpenCompletedClosed.trim();
         			strSQL+=" AND OpenCompletedClosed  "+ getSQLSubQuery(fOpenCompletedClosed);     
            	}
         		if(!fObservationOpen.equals(""))
         		{
         			fObservationOpen=fObservationOpen.trim();
         			strSQL+=" AND ObservationOpen  "+ getSQLSubQuery(fObservationOpen);     
            	}
         		if(!fObservationCompleted.equals(""))
         		{
         			fObservationCompleted=fObservationCompleted.trim();
         			strSQL+=" AND ObservationCompleted  "+ getSQLSubQuery(fObservationCompleted);     
            	}
         		if(!fObservationClosed.equals(""))
         		{
         			fObservationClosed=fObservationClosed.trim();
         			strSQL+=" AND ObservationClosed  "+ getSQLSubQuery(fObservationClosed);     
            	}
         		if(!fObservationTotal.equals(""))
         		{
         			fObservationTotal=fObservationTotal.trim();
         			strSQL+=" AND ObservationTotal  "+ getSQLSubQuery(fObservationTotal);     
            	}

         		strSQL+= " order by a.versionDesc,a.REQUESTTITLE ";         		        
 


       try{     
           stmt=myConn.createStatement(); 
           System.out.println("getAuditReport()"+strSQL);
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getAuditReport()-->"+se);mess=se.getMessage();}    
       mess="ok";     
       return retVal;                        	
	}  
	
	public boolean getAllDefectsData(String f,String t,String cid,String prodid,String projid,String dataprovid) throws Exception
	{
		boolean retVal=false;
         strSQL="select SOURCEDESC," +   
         		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0))) as Open," +
         		"            (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as Completed, " +
         		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Other', CT, 0))) as Total " +
         		"from " +
         		"(" +
         		"SELECT  SOURCEDESC, STATUSDESC,  SUM(CT) CT " +
         		"FROM " +
         		"" +
         		"(" +
         		"SELECT " +
         		"         SE.SOURCEDESC, " +
         		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
         		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
         		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC,"+
         		"         COUNT(* ) AS CT " +
         		"FROM " +
         		"(" +
         		"SELECT   REQUESTCODE,MAX(LASTUPDATEDDATE) M " +
         		"          FROM     OAM_RM_ARCHIVE " +
         		"          WHERE    1 = 1 " +
         		" AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"         GROUP BY REQUESTCODE ) A " +
         		"        inner join " +
         		"         OAM_RM_ARCHIVE RM " +
         		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
         		"         LEFT JOIN OAM_RM_REQUEST_SOURCE SE " +
         		"           ON RM.SOURCEID = SE.SOURCEID " +
         		"         INNER JOIN OAM_RM_REQUEST_TYPES RT " +
         		"         on rt.REQUESTTYPEID=rm.REQUESTTYPEID " +
         		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"           ON RM.STATUSID = ST.STATUSID " +
         		"WHERE    A.REQUESTCODE = RM.REQUESTCODE AND UPPER(RT.REQUESTTYPEDESC)='DEFECT' ";
         if(!cid.equals(""))
  		{
  			strSQL+= " AND RM.CLIENTID = '"+cid+"'";
  		}
         if(!prodid.equals(""))
   		{
   			strSQL+= " AND RM.PRODUCTID = '"+prodid+"'";
   		}
         if(!projid.equals(""))
    		{
    			strSQL+= " AND RM.PROJECTID = '"+projid+"'";
    		}
         if(!dataprovid.equals(""))
 		{
 			strSQL+= " AND RM.DATAPROVIDERID = '"+dataprovid+"'";
 		}
         

         strSQL+=		"                   and RM.requesttypeid=(select requesttypeid from oam_rm_request_types where requesttypedesc like 'Defect') " +
         " and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"GROUP BY          SE.SOURCEDESC, " +
         		"         ST.STATUSDESC " +
         		"         order by SOURCEDESC,STATUSDESC " +
         		") GROUP BY SOURCEDESC,STATUSDESC ) " +
         		" GROUP BY SOURCEDESC"; 
  
           try{
           stmt=myConn.createStatement();  
           System.out.println("getAllDefectsData->"+strSQL);
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getAllDefectsData()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	}
	
	public boolean getDefectiveFixes(String f,String t,String cid,String prodid,String projid,String dataprovid) throws Exception
	{
		boolean retVal=false;
         strSQL="select b.sourcedesc,count(*) as defectivefix from oam_rm_archive a inner" +
         		" join oam_rm_request_source b on a.sourceid=b.sourceid where (requestcode,lastupdateddate) in " +
         		"( select requestcode,max(lastupdateddate)    from oam_rm_archive WHERE  requestcode IN ( select distinct(a.requestcode) " +
         		"      from oam_rm_archive a inner join oam_rm_archive b " +
         		"      on a.requestcode=b.requestcode " +
         		"      where a.lastupdateddate<b.lastupdateddate and a.statusid=(select statusid" +
         		" from oam_rm_requeststatus where statusdesc='Completed') " +
         		"      and b.statusid=(select statusid from oam_rm_requeststatus where" +
         		" statusdesc='Assigned') ";
         if(!cid.equals(""))
         {
        	 strSQL+= " AND a.CLIENTID = '"+cid+"'";
         }
         if(!prodid.equals(""))
         {
        	 strSQL+= " AND a.PRODUCTID = '"+prodid+"'";
         }
         if(!projid.equals(""))
         {
        	 strSQL+= " AND a.PROJECTID = '"+projid+"'";
         }
         if(!dataprovid.equals(""))
         {
        	 strSQL+= " AND a.DATAPROVIDERID = '"+dataprovid+"'";
         }
         
         strSQL+=		"      and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"      and trunc(a.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"      and trunc(b.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		")group by requestcode ) group by b.sourcedesc"; 
         try{
           stmt=myConn.createStatement(); 
           System.out.println("getDefectiveFixes->"+strSQL);
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getDefectiveFixes()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	}
	
	public boolean getDefectsBySeverity(String f,String t,String cid,String prodid,String projid,String dataprovid) throws Exception   
	{
		boolean retVal=false;
         strSQL="SELECT  SOURCEDESC," +
         		"                  MAX(DECODE(SEVERITYDESC, 'Critical', Open, 0)) CriticalOpen, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Critical', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Critical', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Critical', Other, 0)) CriticalTotal, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Major', Open, 0)) MajorOpen, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Major', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Major', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Major', Other, 0)) MajorTotal, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Minor', Open, 0)) MinorOpen, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Minor', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Minor', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Minor', Other, 0)) MinorTotal, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Trivial', Open, 0)) TrivialOpen, " +
         		"                  MAX(DECODE(SEVERITYDESC, 'Trivial', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Trivial', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Trivial', Other, 0)) TrivialTotal " +
         		"FROM (SELECT   SOURCEDESC,SEVERITYDESC, MAX(DECODE(STATUSDESC, 'Open', CT, 0)) Open, " +
         		"         MAX(DECODE(STATUSDESC, 'Completed', CT, 0)) Completed, " +
         		"         MAX(DECODE(STATUSDESC, 'Other', CT, 0)) Other " +
         		"    FROM ( SELECT  SOURCEDESC,  SEVERITYDESC, STATUSDESC,  SUM(CT) CT FROM " +
         		"( SELECT SE.SOURCEDESC, SV.SEVERITYDESC, " +
         		" case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
         		"     when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
         		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, " +
         		"         COUNT(* ) AS CT FROM     (SELECT   REQUESTCODE, " +
         		"        MAX(LASTUPDATEDDATE) M " +
         		"          FROM     OAM_RM_ARCHIVE " +
         		"          WHERE    1 = 1 " +
         		"  AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		" GROUP BY REQUESTCODE ) A " +
         		"     inner join " +
         		"   OAM_RM_ARCHIVE RM  on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
         		"   LEFT JOIN OAM_RM_REQUEST_SOURCE SE " +
         		"   ON RM.SOURCEID = SE.SOURCEID " +
         		"         INNER JOIN OAM_RM_REQUEST_SEVERITY SV " +
         		"         on RM.SEVERITYID=SV.SEVERITYID " +
         		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"           ON RM.STATUSID = ST.STATUSID " +
         		"WHERE    A.REQUESTCODE = RM.REQUESTCODE " ;
         if(!cid.equals(""))
         {
        	 strSQL+="AND rm.CLIENTID = '"+cid+"'";    
         }
         if(!prodid.equals(""))
         {
        	 strSQL+="AND rm.ProductID = '"+prodid+"'";
         }
         if(!projid.equals(""))
         {
        	 strSQL+="AND rm.ProjectID = '"+projid+"'";    
         }
         if(!dataprovid.equals(""))
         {
        	 strSQL+="AND rm.DATAPROVIDERID = '"+dataprovid+"'";    
         }

  strSQL+= 		"                   AND rm.REQUESTTYPEID =(select requesttypeid from oam_rm_request_types where requesttypedesc like 'Defect')  " +
         		"                   and trunc(rm.requestdate) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		" GROUP BY  SE.SOURCEDESC, SV.SEVERITYDESC, ST.STATUSDESC " +
         		") GROUP BY SOURCEDESC,SEVERITYDESC ,STATUSDESC " +
         		") GROUP BY SOURCEDESC,SEVERITYDESC) GROUP BY SOURCEDESC" +
         		" ORDER BY SOURCEDESC"; 
           try{
           stmt=myConn.createStatement();               
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getDefectsBySeverity()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                                	
	}
	public boolean getModuleSpecificStatusData(String f,String t,String cid,String prodid,String projid,String postid) throws Exception
	{
		tableName="oam_rm_requestmanager";
		boolean retVal=false;
         strSQL="select * from (" +
         		"select   case when modulename is null then 'No Module' else modulename end as   firstmodulename, " +
         		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0))) as Open, " +
         		"            (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as Completed, " +
         		"             (MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as Closed, " +
         		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Other', CT, 0))) as Total " +
         		"from" +
         		"(" +
         		"SELECT  modulename, STATUSDESC,  SUM(CT) CT " +
         		"FROM " +
         		"(" +
         		"SELECT       SE.modulename," +
         		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
         		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
         		"         when ST.STATUSDESC in ('Closed') then 'Closed' " +
         		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, " +
         		"         COUNT(* ) AS CT " +
         		"FROM " +
         		"(" +
         		"SELECT   REQUESTCODE,MAX(LASTUPDATEDDATE) M " +
         		"          FROM     OAM_RM_ARCHIVE " +
         		"          WHERE    1 = 1 " +
         		"                   AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"          GROUP BY REQUESTCODE ) A " +
         		"        inner join " +
         		"         OAM_RM_ARCHIVE RM " +
         		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
         		"         LEFT JOIN OAM_RM_modules SE " +
         		"           ON RM.MODULEID = SE.MODULEID " +
         		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"           ON RM.STATUSID = ST.STATUSID " +
         		"WHERE    A.REQUESTCODE = RM.REQUESTCODE ";
         if(!cid.equals(""))
         {
        	strSQL+="AND  RM.CLIENTID = '"+cid+"'";    
         }

        if(!prodid.equals(""))
        {
       	strSQL+="AND RM.PRODUCTID='"+prodid+"'";    
        }
        if(!projid.equals(""))
        {
       	strSQL+="AND RM.PROJECTID='"+projid+"'";    
        }
        if(!postid.equals(""))
        {
       	strSQL+="AND RM.requesttypeid='"+postid+"'";    
        }
        strSQL+= " and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') GROUP BY " +
         		"         SE.MODULENAME, " +
         		"         ST.STATUSDESC " +
         		"         order by MODULENAME,STATUSDESC ) GROUP BY MODULENAME,STATUSDESC " +
         		")  GROUP BY " +
         		"MODULENAME ) xx " +
         		"full outer join " +
         		"(" +
         		" select SECONDMODULENAME,sum(COMPLETEDCOUNT) COMPLETEDCOUNT," +
         		" case when sum(COMPLETEDCOUNT)=0 then 0 else round(sum(COMPLETEDCOUNT* AVGCOMPLETED)/(sum(COMPLETEDCOUNT)),3) end as AVGCOMPLETED, " +
         		"sum(OPENCOMPLETEDCOUNT) OPENCOMPLETEDCOUNT, case when sum(OPENCOMPLETEDCOUNT)=0 then 0 else round(sum(OPENCOMPLETEDCOUNT* OPENCOMPLETED)/(sum(OPENCOMPLETEDCOUNT)),3) end as OPENCOMPLETED, " +
         		"sum(CLOSEDCOUNT) CLOSEDCOUNT, case when sum(CLOSEDCOUNT)=0 then 0 else round(sum(CLOSEDCOUNT* AVGCLOSED)/(sum(CLOSEDCOUNT)),3) end as AVGCLOSED, " +
         		"sum(OPENCOMPLETEDCLOSEDCOUNT) OPENCOMPLETEDCLOSEDCOUNT, case when sum(OPENCOMPLETEDCLOSEDCOUNT)=0 then 0 else round(sum(OPENCOMPLETEDCLOSEDCOUNT* OPENCOMPLETEDCLOSED)/(sum(OPENCOMPLETEDCLOSEDCOUNT)),3) end as OPENCOMPLETEDCLOSED from( " +
         		getModuleSpecificStatusAgeQuery("oam_rm_requestmanager",f,t,cid,prodid,projid,postid)+
         		" UNION ALL "+
         		getModuleSpecificStatusAgeQuery("oam_rm_requestmanager_annal",f,t,cid,prodid,projid,postid)+         		
         		" )GROUP  BY SECONDMODULENAME"+
         		" ) yy on xx. firstmodulename = yy.secondmodulename " +
         		"left outer join " +
         		"(select modulename,sum(DEFECTIVEFIX)  DEFECTIVEFIX from( " +
         		getModuleSpecificStatusDefQuery("oam_rm_requestmanager",f,t,cid,prodid,projid,postid)+
         		" UNION ALL "+
         		getModuleSpecificStatusDefQuery("oam_rm_requestmanager_annal",f,t,cid,prodid,projid,postid)+
         		" ) GROUP  BY modulename ) zz " +
         		"on xx. firstmodulename=zz.modulename and " +
         		"yy.secondmodulename=zz.modulename";   
               
       try{
           stmt=myConn.createStatement();  
           System.out.println("getModuleSpecificStatusData->"+strSQL);
           myRS=stmt.executeQuery(strSQL);     
           retVal=true;
       }catch (SQLException se){   
           System.out.println("\nError:getModuleSpecificStatusData()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	} 
	
	public String getModuleSpecificStatusAgeQuery(String tableName,String f,String t,String cid,String prodid,String projid,String postid){
	
	String sql="select modulename as secondmodulename, " +
		"                (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as CompletedCount, " +
		"                  case when MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 " +
		"                  then 0 else " +
		"                  round((MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3)  end as avgCompleted, " +
		"                  (MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as OpenCompletedCount, " +
		"                  case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 " +
		"                  then 0 else " +
		"                  round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3) " +
		"                  end as OpenCompleted, " +
		"                  (MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as ClosedCount, " +
		"                  case when MAX(DECODE(STATUSDESC, 'Closed', CT, 0))=0 " +
		"                  then 0 else " +
		"                  round((MAX(DECODE(STATUSDESC, 'Closed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as avgClosed, " +
		"                  (MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as OpenCompletedClosedCount, " +
		"                  case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Closed', CT, 0))!=0 " +
		"                   then 0 else " +
		"                   round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0))+MAX(DECODE(STATUSDESC, 'Closed', Days, 0))) /(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as OpenCompletedClosed " +
		"                   FROM " +
		"( select * from " +
		"( select c.modulename,b.statusdesc,count(*) ct,sum(e.completedate-d.assigneddate) days " +
		"from "+tableName+" a " +
		"inner join" +
		" oam_rm_requeststatus b on a.statusid=b.statusid " +
		"inner join" +
		" oam_rm_modules c on a.moduleid=c.moduleid " +
		"inner join (" +
		"SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"group by requestcode )d " +
		"on a.requestcode=d.requestcode " +
		"inner join (" +
		"select requestcode,min(lastupdateddate) completedate FROM OAM_RM_ARCHIVE where " +
		"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Completed') " +
		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"group by requestcode )e " +
		"on a.requestcode=e.requestcode " +
		"where 1=1 ";
if(!cid.equals(""))
{
sql+="AND  a.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
sql+="AND  a.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
sql+="AND  a.PROJECTID = '"+projid+"'";    
}
if(!postid.equals(""))
{
sql+="AND  a.requesttypeid = '"+postid+"'";    
}
sql+=	" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"and b.statusdesc in ('Completed','QC Completed') " +
		"group by c.modulename,b.statusdesc ) " +
		"union " +
		"select * from (" +
		"select c.modulename,b.statusdesc,count(*)  ct,sum(e.closeddate-d.assigneddate) days " +
		"from "+tableName+" a " +
		"inner join oam_rm_requeststatus b on a.statusid=b.statusid " +
		"inner join oam_rm_modules c on a.moduleid=c.moduleid " +
		"inner join (" +
		"SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"group by requestcode )d on a.requestcode=d.requestcode " +
		"inner join (select requestcode,min(lastupdateddate) closeddate FROM OAM_RM_ARCHIVE where " +
		"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Closed') " +
		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"group by requestcode )e " +
		"on a.requestcode=e.requestcode " +
		"where 1=1";
if(!cid.equals(""))
{
sql+="AND  a.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
sql+="AND  a.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
sql+="AND  a.PROJECTID = '"+projid+"'";    
}
if(!postid.equals(""))
{
sql+="AND  a.requesttypeid = '"+postid+"'";    
}

sql+= " and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"and b.statusdesc in ('Closed') group by c.modulename,b.statusdesc ) " +
		"union " +
		"select * from ( " +    
		"select c.modulename,'Open' as statusdesc,count(*)  ct,sum((to_date('"+t+"','mm/dd/yyyy'))-d.assigneddate) days " +
		"from "+tableName+" a " +
		"inner join ( " +
		"SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode )d " +
		"on a.requestcode=d.requestcode inner join oam_rm_archive e on a.requestcode=e.requestcode " +
		"inner join oam_rm_requeststatus b on e.statusid=b.statusid " +
		"inner join oam_rm_modules c on e.moduleid=c.moduleid " +
		"where (e.requestcode, e.lastupdateddate) in ( " +
		"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE " +
		"where trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy')" +
				" group by requestcode ) ";
if(!cid.equals(""))
{
sql+="AND  e.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
sql+="AND  e.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
sql+="AND  e.PROJECTID = '"+projid+"'";    
}
if(!postid.equals(""))
{
sql+="AND  e.requesttypeid = '"+postid+"'";    
}
sql+=	"and trunc(e.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"and b.statusdesc in ('Not Started','Assigned','In Progress') group by c.modulename,b.statusdesc ) ) " +
		"group by modulename ";
	return sql;
	}
	
	public String getModuleSpecificStatusDefQuery(String tableName,String f,String t,String cid,String prodid,String projid,String postid){
		
	String sql="select b.modulename,count(*) as defectivefix from "+tableName+" a inner join oam_rm_modules b on a.moduleid=b.moduleid where requestcode in " +
		"( " +
		"      select distinct(a.requestcode) " +
		"      from oam_rm_archive a inner join oam_rm_archive b " +
		"      on a.requestcode=b.requestcode " +
		"      where a.lastupdateddate<b.lastupdateddate and a.statusid=(select statusid from oam_rm_requeststatus where statusdesc='Completed') " +
		"      and b.statusid=(select statusid from oam_rm_requeststatus where statusdesc='Assigned') ";
if(!cid.equals(""))
{
sql+="AND  a.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
sql+="AND  a.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
sql+="AND  a.PROJECTID = '"+projid+"'";    
}
if(!postid.equals(""))
{
sql+="AND  a.requesttypeid = '"+postid+"'";    
}
sql+=  	"   and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		" and trunc(a.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"and trunc(b.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') ) " +
		"group by b.modulename";
return sql;
	}

	
	/**
	 * @author rsah
	 * @ provider specific age report
	 */
	
	public boolean getProviderAgeReportData(String f,String t,String cid,String prodid,String projid,String postid,String fClientName,String fCompleted,String fOpenCompleted,String fClosed,String fOpenCompletedClosed,String fAgeInPhases , String userID) throws Exception
	{
		boolean retVal=false;
		 strSQL=" select * from (select clientname as firstclientname,clientid," +
		 		"                  (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as CompletedCount, " +
		 		"                  case when MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 " +
		 		"                 then 0 else " +
		 		"                  round((MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3)  end as Completed, " +
		 		"                  (MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as OpenCompletedCount, " +
		 		"                  case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 " +
		 		"                  then 0 else " +
		 		"                  round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))),3) " +
		 		"                  end as OpenCompleted, " +
		 		"                  (MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as ClosedCount, " +
		 		"                  case when MAX(DECODE(STATUSDESC, 'Closed', CT, 0))=0 " +
		 		"                  then 0 else " +
		 		"                  round((MAX(DECODE(STATUSDESC, 'Closed', Days, 0)))/(MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as Closed, " +
		 		"                  (MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as OpenCompletedClosedCount, " +
		 		"                  case when MAX(DECODE(STATUSDESC, 'Open', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Completed', CT, 0))=0 and MAX(DECODE(STATUSDESC, 'Closed', CT, 0))!=0 " +
		 		"                   then 0 else " +
		 		"                   round((MAX(DECODE(STATUSDESC, 'Open', Days, 0))+MAX(DECODE(STATUSDESC, 'Completed', Days, 0))+MAX(DECODE(STATUSDESC, 'Closed', Days, 0))) /(MAX(DECODE(STATUSDESC, 'Open', CT, 0))+MAX(DECODE(STATUSDESC, 'Completed', CT, 0))+MAX(DECODE(STATUSDESC, 'Closed', CT, 0))),3)  end as OpenCompletedClosed " +
		 		"                   FROM ( select * from ( " +
		 		"select c.clientname,b.statusdesc,c.clientid,count(*) ct,sum(e.completedate-d.assigneddate) days " +
		 		"from "+tableName+" a " +
		 		"inner join oam_rm_requeststatus b on a.statusid=b.statusid " +
		 		"inner join oam_clients c on a.dataproviderid=c.clientid " +
		 		"inner join (SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
		 		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode )d on a.requestcode=d.requestcode " +
		 		"inner join (select requestcode,min(lastupdateddate) completedate FROM OAM_RM_ARCHIVE where " +
		 		"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Completed') " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') group by requestcode )e " +
		 		"on a.requestcode=e.requestcode " +
		 		"where 1=1 ";
		 if(!cid.equals(""))
		  {
		 	strSQL+="AND  a.CLIENTID = '"+cid+"'";    
		  }
		  if(!prodid.equals(""))
		  {
		 	strSQL+="AND  a.PRODUCTID = '"+prodid+"'";    
		  }
		  if(!projid.equals(""))
		  {
		 	strSQL+="AND  a.PROJECTID = '"+projid+"'";    
		  }
		  if(!postid.equals(""))
		  {
		 	strSQL+="AND  a.requesttypeid = '"+postid+"'";    
		  }
		  strSQL+=" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"and b.statusdesc in ('Completed','QC Completed') " +
		 		"group by c.clientname,b.statusdesc,c.clientid )" +
		 		" union " +
		 		"select * from (select c.clientname,b.statusdesc,c.clientid, count(*)  ct,sum(e.closeddate-d.assigneddate) days " +
		 		"from "+tableName+" a " +
		 		"inner join oam_rm_requeststatus b on a.statusid=b.statusid " +
		 		"inner join oam_clients c on a.dataproviderid=c.clientid " +
		 		"inner join (SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
		 		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode )d " +
		 		"on a.requestcode=d.requestcode " +
		 		"inner join (select requestcode,min(lastupdateddate) closeddate FROM OAM_RM_ARCHIVE where " +
		 		"statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Closed') " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode )e on a.requestcode=e.requestcode " +
		 		"where 1=1 ";
		  if(!cid.equals(""))
		  {
		 	strSQL+="AND  a.CLIENTID = '"+cid+"'";    
		  }
		  if(!prodid.equals(""))
		  {
		 	strSQL+="AND  a.PRODUCTID = '"+prodid+"'";    
		  }
		  if(!projid.equals(""))
		  {
		 	strSQL+="AND  a.PROJECTID = '"+projid+"'";    
		  }
		  if(!postid.equals(""))
		  {
		 	strSQL+="AND  a.requesttypeid = '"+postid+"'";    
		  }
		  strSQL+=	" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"and b.statusdesc in ('Closed') " +
		 		"group by c.clientname,b.statusdesc,c.clientid ) " +
		 		"union " +
		 		"select * from ( select c.clientname,'Open' as statusdesc,c.clientid,count(*)  ct,sum((to_date('"+t+"','mm/dd/yyyy'))-d.assigneddate) days " +
		 		"from "+tableName+" a " +
		 		"inner join (SELECT requestcode,min(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE where " +
		 		"assignedto is not null and statusid=(select statusid from oam_rm_requeststatus where statusdesc like 'Assigned') " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode )d " +
		 		"on a.requestcode=d.requestcode " +
		 		"inner join oam_rm_archive e " +
		 		"on a.requestcode=e.requestcode " +
		 		"inner join oam_rm_requeststatus b on e.statusid=b.statusid " +
		 		"inner join oam_clients c on e.dataproviderid=c.clientid " +
		 		"where (e.requestcode,e.lastupdateddate) in (" +
		 		"SELECT requestcode,max(lastupdateddate) assigneddate FROM OAM_RM_ARCHIVE " +
		 		"where trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode ) ";
		  if(!cid.equals(""))
		  {
		 	strSQL+="AND  e.CLIENTID = '"+cid+"'";    
		  }
		  if(!prodid.equals(""))
		  {
		 	strSQL+="AND  e.PRODUCTID = '"+prodid+"'";    
		  }
		  if(!projid.equals(""))
		  {
		 	strSQL+="AND  e.PROJECTID = '"+projid+"'";    
		  }
		  if(!postid.equals(""))
		  {
		 	strSQL+="AND  e.requesttypeid = '"+postid+"'";    
		  }
		 	strSQL+=" and trunc(e.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"and b.statusdesc in ('Not Started','Assigned','In Progress') " +
		 		"group by c.clientname,b.statusdesc,c.clientid ) ) group by clientname,clientid ) a " +
		 		"left outer join " +
		 		"(select " +
		 		"c.clientname as secondclientname,round(avg(e.phaseinjecteddate-d.phasedetecteddate),3) ageinphases,count(*) ageinphasescount " +
		 		"from "+tableName+" a " +
		 		"inner join oam_clients c on a.dataproviderid=c.clientid " +
		 		"inner join (" +
		 		"SELECT requestcode,min(lastupdateddate) phasedetecteddate FROM OAM_RM_ARCHIVE where " +
		 		"phasedetected is not null and phasedetected!=0 " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode )d " +
		 		"on a.requestcode=d.requestcode left join ( " +
		 		"SELECT requestcode,min(lastupdateddate) phaseinjecteddate FROM OAM_RM_ARCHIVE where " +
		 		"phaseinject is not null and phaseinject!=0 " +
		 		"and trunc(lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		 		"group by requestcode )e " +
		 		"on a.requestcode=e.requestcode " +
		 		"where 1=1 ";
		 	 if(!cid.equals(""))
			  {
			 	strSQL+="AND  a.CLIENTID = '"+cid+"'";    
			  }
			  if(!prodid.equals(""))
			  {
			 	strSQL+="AND  a.PRODUCTID = '"+prodid+"'";       
			  }
			  if(!projid.equals(""))
			  {
			 	strSQL+="AND  a.PROJECTID = '"+projid+"'";    
			  }
			  if(!postid.equals(""))
			  {
			 	strSQL+="AND  a.requesttypeid = '"+postid+"'";    
			  }
			  strSQL+=" and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') " +
			  		"and to_date('"+t+"','mm/dd/yyyy') ";   
			  if(!postid.equals(""))
			  {
			 	strSQL+="AND  a.requesttypeid = '"+postid+"'";    
			  }
			  strSQL+=" and a.statusid not in (select statusid from oam_rm_requeststatus where statusdesc in ('Deferred','Dropped')) " +
		 		"group by c.clientname) b on a.firstclientname = b.secondclientname where 1=1";
			  if(!fClientName.equals(""))
	     		{
	     		strSQL+= " and lower(a.firstclientname) like lower('%"+fClientName+"%') " +
	     				"or lower(b.secondclientname) like lower('%"+fClientName+"%') ";   				
	     		}
			  if(!fCompleted.equals(""))
	     		{
				  fCompleted=fCompleted.trim();
	     		strSQL+= " and completed "+ getSQLSubQuery(fCompleted);  
	     		}
			  if(!fOpenCompleted.equals(""))
	     		{
				  fOpenCompleted=fOpenCompleted.trim();
	     		strSQL+= " and opencompleted "+ getSQLSubQuery(fOpenCompleted);  
	     		}
			  if(!fClosed.equals(""))
	     		{
				  fClosed=fClosed.trim();
	     		strSQL+= " and closed "+ getSQLSubQuery(fClosed);  
	     		}
			  if(!fOpenCompletedClosed.equals(""))
	     		{
				  fOpenCompletedClosed=fOpenCompletedClosed.trim();
	     		strSQL+= " and openCompletedClosed "+ getSQLSubQuery(fOpenCompletedClosed);  
	     		}
			  if(!fAgeInPhases.equals(""))
	     		{
				  fAgeInPhases=fAgeInPhases.trim();
	     		strSQL+= " and ageinphases "+ getSQLSubQuery(fAgeInPhases);  
	     		}
			  strSQL+= "AND  nvl(clientid,' ') IN"+ super.getAccesibleClients(userID);
			  strSQL+=" order by a.firstclientname,b.secondclientname";
			  System.out.println("SQL->"+strSQL);

        
       try{
           stmt=myConn.createStatement();                 
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getProviderAgeReportData()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                 	
	} 
	public boolean getProviderDefectsData(String f,String t,String cid,String prodid,String projid,String fClientName,String fOpen,String fCompleted,String fClosed,String fTotal,String fDefectiveFix,String fCriticalOpen,String fCriticalTotal,String fMajorOpen,String fMajorTotal,String fMinorOpen,String fMinorTotal,String fTrivialOpen,String fTrivialTotal,String userID) throws Exception
	{
		boolean retVal=false;
		strSQL="SELECT xx.OPEN,xx.COMPLETED,xx.CLOSED,xx.TOTAL,yy.*,zz.defectivefix, xx.clientid from (select case when  clientname is null then 'No Client' else " +
		"clientname end as clientname, clientid," +
		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0))) as Open, " +
		"            (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as Completed, " +
		"             (MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as Closed, " +
		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Other', CT, 0))) as Total " +
		"from " +
		"( SELECT  clientname, STATUSDESC, clientid, SUM(CT) CT " +
		"FROM ( SELECT " +
		"         SE.CLIENTNAME,SE.clientid," +
		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
		"         when ST.STATUSDESC in ('Closed') then 'Closed' " +
		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, " +
		"         COUNT(* ) AS CT FROM (SELECT   REQUESTCODE,MAX(LASTUPDATEDDATE) M " +
		"          FROM     OAM_RM_ARCHIVE           WHERE    1 = 1 " +
		"           AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"    GROUP BY REQUESTCODE ) A " +
		"        inner join " +
		"         OAM_RM_ARCHIVE RM " +
		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
		"         LEFT JOIN OAM_CLIENTS SE " +
		"           ON RM.DATAPROVIDERID = SE.CLIENTID " +
		"         INNER JOIN OAM_RM_REQUEST_TYPES RT " +
		"         on rt.REQUESTTYPEID=rm.REQUESTTYPEID " +
		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
		"           ON RM.STATUSID = ST.STATUSID " +
		"WHERE    A.REQUESTCODE = RM.REQUESTCODE AND UPPER(RT.REQUESTTYPEDESC)='DEFECT' ";
if(!cid.equals(""))
{
	strSQL+="AND  RM.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
	strSQL+="AND  RM.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
	strSQL+="AND  RM.PROJECTID = '"+projid+"'";    
}
strSQL+=	" and RM.requesttypeid=(select requesttypeid from oam_rm_request_types where requesttypedesc like 'Defect') " +
		"and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"GROUP BY          SE.CLIENTNAME,SE.clientid, " +
		"         ST.STATUSDESC " +
		"         order by CLIENTNAME,STATUSDESC ) GROUP BY " +
		"CLIENTNAME,STATUSDESC,clientid ) " +
		" GROUP BY CLIENTNAME,clientid) xx " +
		"full outer join " +
		"(SELECT  case when clientname is null then 'No Client'  else clientname end as clientname, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Critical', Open, 0)) CriticalOpen, " +
		"               MAX(DECODE(SEVERITYDESC, 'Critical', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Critical', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Critical', Other, 0)) CriticalTotal, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Major', Open, 0)) MajorOpen, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Major', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Major', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Major', Other, 0)) MajorTotal, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Minor', Open, 0)) MinorOpen, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Minor', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Minor', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Minor', Other, 0)) MinorTotal, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Trivial', Open, 0)) TrivialOpen, " +
		"                  MAX(DECODE(SEVERITYDESC, 'Trivial', Open, 0))+MAX(DECODE(SEVERITYDESC, 'Trivial', Completed, 0))+MAX(DECODE(SEVERITYDESC, 'Trivial', Other, 0)) TrivialTotal " +
		"FROM( " +
		"SELECT   CLIENTNAME,SEVERITYDESC, MAX(DECODE(STATUSDESC, 'Open', CT, 0)) Open, " +
		"         MAX(DECODE(STATUSDESC, 'Completed', CT, 0)) Completed, " +
		"         MAX(DECODE(STATUSDESC, 'Other', CT, 0)) Other " +
		"    FROM ( " +
		" SELECT  CLIENTNAME,  SEVERITYDESC, STATUSDESC,  SUM(CT) CT " +
		"FROM ( SELECT          SE.CLIENTNAME,          SV.SEVERITYDESC, " +
		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, " +
		"         COUNT(* ) AS CT FROM     ( " +
		"          SELECT   REQUESTCODE, " +
		"                   MAX(LASTUPDATEDDATE) M " +
		"          FROM     OAM_RM_ARCHIVE " +
		"          WHERE    1 = 1 " +
		"                   AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"         GROUP BY REQUESTCODE  ) A " +
		"          inner join " +
		"         OAM_RM_ARCHIVE RM " +
		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
		"         LEFT JOIN OAM_CLIENTS SE " +
		"           ON RM.DATAPROVIDERID = SE.CLIENTID " +
		"         INNER JOIN OAM_RM_REQUEST_SEVERITY SV " +
		"         on RM.SEVERITYID=SV.SEVERITYID " +
		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
		"           ON RM.STATUSID = ST.STATUSID " +
		"WHERE    A.REQUESTCODE = RM.REQUESTCODE ";
if(!cid.equals(""))
{
	strSQL+="AND  rm.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
	strSQL+="AND  rm.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
	strSQL+="AND  rm.PROJECTID = '"+projid+"'";    
}
strSQL+= " AND rm.REQUESTTYPEID = (select requesttypeid from oam_rm_request_types where requesttypedesc like 'Defect') " +
		"                   and trunc(rm.requestdate) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		" GROUP BY " +
		"         SE.CLIENTNAME, " +
		"          SV.SEVERITYDESC, " +
		"         ST.STATUSDESC ) GROUP BY CLIENTNAME,SEVERITYDESC ,STATUSDESC ) " +
		"GROUP BY CLIENTNAME,SEVERITYDESC ) GROUP BY CLIENTNAME " +
		"ORDER BY CLIENTNAME ) yy " +
		"on xx.clientname=yy.clientname " +
		"left outer join " +
		"( "+ getProviderDefectsDataQuery("oam_rm_requestmanager",f,t,cid,prodid,projid,fClientName,fOpen,fCompleted,fClosed,fTotal,fDefectiveFix,fCriticalOpen,fCriticalTotal,fMajorOpen,fMajorTotal,fMinorOpen,fMinorTotal,fTrivialOpen,fTrivialTotal) +
		" UNION ALL "+getProviderDefectsDataQuery("oam_rm_requestmanager_annal",f,t,cid,prodid,projid,fClientName,fOpen,fCompleted,fClosed,fTotal,fDefectiveFix,fCriticalOpen,fCriticalTotal,fMajorOpen,fMajorTotal,fMinorOpen,fMinorTotal,fTrivialOpen,fTrivialTotal)+" ) zz " +
		"on xx.clientname = zz.clientname " +
		"and yy.clientname=zz.clientname where 1=1";   
	if(!fClientName.equals(""))
	{
	strSQL+= " and lower(xx.clientname) like lower('%"+fClientName+"%') " +
			"or lower(yy.clientname) like lower('%"+fClientName+"%') " +
			"or lower(zz.clientname) like lower('%"+fClientName+"%')";     				
	}
	if(!fOpen.equals(""))
	{
		fOpen=fOpen.trim();
	strSQL+= " and open "+ getSQLSubQuery(fOpen);  
	}
	if(!fCompleted.equals(""))
	{
		fCompleted=fCompleted.trim();
	strSQL+= " and completed "+ getSQLSubQuery(fCompleted);  
	}
	if(!fClosed.equals(""))
	{
		fClosed=fClosed.trim();
	strSQL+= " and closed "+ getSQLSubQuery(fClosed);  
	}
	if(!fDefectiveFix.equals(""))
	{
		fDefectiveFix=fDefectiveFix.trim();
	strSQL+= " and defectivefix "+ getSQLSubQuery(fDefectiveFix);  
	}
	if(!fCriticalOpen.equals(""))
	{
		fCriticalOpen=fCriticalOpen.trim();
	strSQL+= " and criticalopen "+ getSQLSubQuery(fCriticalOpen);  
	}
	if(!fCriticalTotal.equals(""))
	{
		fCriticalTotal=fCriticalTotal.trim();
	strSQL+= " and criticaltotal "+ getSQLSubQuery(fCriticalTotal);  
	}
	if(!fMajorOpen.equals(""))
	{
		fMajorOpen=fMajorOpen.trim();
	strSQL+= " and majoropen "+ getSQLSubQuery(fMajorOpen);  
	}
	if(!fMajorTotal.equals(""))
	{
		fMajorTotal=fMajorTotal.trim();
	strSQL+= " and majortotal "+ getSQLSubQuery(fMajorTotal);  
	}
	if(!fMinorOpen.equals(""))
	{
		fMinorOpen=fMinorOpen.trim();
	strSQL+= " and minoropen "+ getSQLSubQuery(fMinorOpen);  
	}
	if(!fMinorTotal.equals(""))
	{
		fMinorTotal=fMinorTotal.trim();
	strSQL+= " and minortotal "+ getSQLSubQuery(fMinorTotal);  
	}
	if(!fTrivialOpen.equals(""))
	{
		fTrivialOpen=fTrivialOpen.trim();
	strSQL+= " and trivialopen "+ getSQLSubQuery(fTrivialOpen);  
	}
	if(!fTrivialTotal.equals(""))
	{
		fTrivialTotal=fTrivialTotal.trim();
	strSQL+= " and trivialtotal "+ getSQLSubQuery(fTrivialTotal);  
	}
	strSQL+= "AND  nvl(clientid,' ') IN"+ super.getAccesibleClients(userID);
	strSQL+=" order by yy.clientName";
           try{
           stmt=myConn.createStatement();  
           System.out.println("SQL->"+strSQL);
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;   
       }catch (SQLException se){  
           System.out.println("\nError:getProviderDefectsData()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                        	
	}
	
	public String getProviderDefectsDataQuery(String tableName,String f,String t,String cid,String prodid,String projid,String fClientName,String fOpen,String fCompleted,String fClosed,String fTotal,String fDefectiveFix,String fCriticalOpen,String fCriticalTotal,String fMajorOpen,String fMajorTotal,String fMinorOpen,String fMinorTotal,String fTrivialOpen,String fTrivialTotal ){
    String sql="select b.clientname as clientname,count(*) as defectivefix from "+tableName+" a inner join oam_clients b on a.dataproviderid=b.clientid where requestcode in " +
	"(       select distinct(a.requestcode) " +
	"      from oam_rm_archive a inner join oam_rm_archive b " +
	"      on a.requestcode=b.requestcode " +
	"      where a.lastupdateddate<b.lastupdateddate and a.statusid=(select statusid from oam_rm_requeststatus where statusdesc='Completed') " +
	"      and b.statusid=(select statusid from oam_rm_requeststatus where statusdesc='Assigned') ";
	if(!cid.equals(""))
	{
		sql+="AND  a.CLIENTID = '"+cid+"'";    
	}
	if(!prodid.equals(""))
	{
		sql+="AND  a.PRODUCTID = '"+prodid+"'";    
	}
	if(!projid.equals(""))
	{
		sql+="AND  a.PROJECTID = '"+projid+"'";    
	}
		sql+= "   and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"      and trunc(a.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"      and trunc(b.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') ) " +
		"group by b.clientname"; 
	
	
	 return sql;
		
	}
	
	public boolean getPostStatusReport(String f,String t,String cid,String prodid,String projid,String postid) throws Exception   
	{
		boolean retVal=false;
         strSQL="select statusdesc," +
         		"  (max(decode(sourcedesc,'Internal',CT,0))) as internal, " +
         		"  (max(decode(sourcedesc,'External',CT,0))) as External, " +
         		"   (max(decode(sourcedesc,'Internal',CT,0)))+ (max(decode(sourcedesc,'External',CT,0))) as total " +
         		"  from " +
         		"  ( " +
         		"select se.sourcedesc,st.statusdesc, COUNT(* ) AS CT " +
         		"from " +
         		"( " +
         		"SELECT   REQUESTCODE,MAX(LASTUPDATEDDATE) M " +
         		"          FROM     OAM_RM_ARCHIVE " +
         		"          WHERE    1 = 1 " +
         		"                   AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"          GROUP BY REQUESTCODE " +
         		") A " +
         		"        inner join          OAM_RM_ARCHIVE RM" +
         		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
         		"         LEFT JOIN OAM_RM_REQUEST_SOURCE SE " +
         		"           ON RM.SOURCEID = SE.SOURCEID " +
         		"         INNER JOIN OAM_RM_REQUEST_TYPES RT " +
         		"         on rt.REQUESTTYPEID=rm.REQUESTTYPEID " +
         		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"           ON RM.STATUSID = ST.STATUSID " +
         		"WHERE    A.REQUESTCODE = RM.REQUESTCODE  ";    
         if(!cid.equals(""))
		  {
		 	strSQL+="AND  RM.CLIENTID = '"+cid+"'";    
		  }
		  if(!prodid.equals(""))
		  {
		 	strSQL+="AND  RM.PRODUCTID = '"+prodid+"'";    
		  }
		  if(!projid.equals(""))
		  {
		 	strSQL+="AND  RM.PROJECTID = '"+projid+"'";    
		  }
		  if(!postid.equals(""))
		  {
		 	strSQL+="AND  RM.requesttypeid = '"+postid+"'";    
		  }
    
		  strSQL+=	"and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"GROUP BY " +
         		"         SE.SOURCEDESC," +
         		"         ST.STATUSDESC " +
         		"         order by SOURCEDESC,STATUSDESC " +
         		"         ) " +
         		"         group by statusdesc"; 		  
         try{
           stmt=myConn.createStatement();               
           System.out.println("PostStatus->"+strSQL);
           myRS=stmt.executeQuery(strSQL);  
           
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getPostStatusReport()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                                	
	}
	
	public boolean getDefectiveFixForPostStatus(String f,String t,String cid,String prodid,String projid,String postid) throws Exception   
	{
		boolean retVal=false;
		strSQL="select sum(INTERNAL) INTERNAL,sum(EXTERNAL) EXTERNAL,sum(TOTAL) TOTAL   from(";
		strSQL+=getDefectiveFixForPostStatusQuery("oam_rm_requestmanager",f,t,cid,prodid,projid,postid);
		strSQL+=" UNION ALL ";
		strSQL+=getDefectiveFixForPostStatusQuery("oam_rm_requestmanager_annal",f,t,cid,prodid,projid,postid);
		strSQL+=")";
		  System.out.println("DefectiveFixForPostStatus->"+strSQL);
         try{
           stmt=myConn.createStatement();
           System.out.println("Before execute");
           myRS=stmt.executeQuery(strSQL); 
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getDefectiveFixForPostStatus()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                                	
	}
	
	public String getDefectiveFixForPostStatusQuery(String tableName,String f,String t,String cid,String prodid,String projid,String postid) {
    strSQL="select " +
		"  (max(decode(sourcedesc,'Internal',CT,0))) as Internal, " +
		"  (max(decode(sourcedesc,'External',CT,0))) as External," +
		"   (max(decode(sourcedesc,'Internal',CT,0)))+ (max(decode(sourcedesc,'External',CT,0))) as total " +
		"  from   ( " +
		"select b.sourcedesc,count(*) as CT from "+tableName+" a inner join oam_rm_request_source b on a.sourceid=b.sourceid where requestcode in " +
		"( " +
		"      select distinct(a.requestcode) " +
		"      from oam_rm_archive a inner join oam_rm_archive b " +
		"      on a.requestcode=b.requestcode " +
		"      inner join "+tableName+" c on a.requestcode=c.requestcode " +
		"      where a.lastupdateddate<b.lastupdateddate and a.statusid=(select statusid from oam_rm_requeststatus where statusdesc='Completed') " +
		"      and b.statusid=(select statusid from oam_rm_requeststatus where statusdesc='Assigned') " +
		"      and c.statusid not in (select statusid from oam_rm_requeststatus where statusdesc='Dropped') " ;
if(!cid.equals(""))
{
	strSQL+="AND  a.CLIENTID = '"+cid+"'";    
}
if(!prodid.equals(""))
{
	strSQL+="AND  a.PRODUCTID = '"+prodid+"'";    
}
if(!projid.equals(""))
{
	strSQL+="AND  a.PROJECTID = '"+projid+"'";       
}
if(!postid.equals(""))
{
	strSQL+="AND  a.requesttypeid = '"+postid+"'";    
}		
strSQL+=  		"      and trunc(a.requestdate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"      and trunc(a.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
		"      and trunc(b.lastupdateddate) between to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') ) " +
		"group by b.sourcedesc " +
		") ";
return strSQL;     
}
	
	public boolean getPhaseDetectedReport(String f,String t,String cid,String prodid,String projid,String dataprovid,String postid) throws Exception   
	{
		boolean retVal=false;
		
		 strSQL="select requestphasedesc, " +
  		"            (MAX(DECODE(STATUSDESC, 'Open', internalsource, 0))) as InternalOpen, " +
  		"            (MAX(DECODE(STATUSDESC, 'Open', externalsource, 0))) as ExternalOpen, " +
  		"            (MAX(DECODE(STATUSDESC, 'Open', internalsource, 0)))  + (MAX(DECODE(STATUSDESC, 'Open', externalsource, 0)))  as totalopen, " +
  		"            (MAX(DECODE(STATUSDESC, 'Completed', internalsource, 0))) as InternalCompleted, " +
  		"             (MAX(DECODE(STATUSDESC, 'Completed', externalsource, 0))) as ExternalCompleted, " +
  		"             (MAX(DECODE(STATUSDESC, 'Completed', internalsource, 0)))  + (MAX(DECODE(STATUSDESC, 'Completed', externalsource, 0)))  as totalcompleted, " +
  		"            (MAX(DECODE(STATUSDESC, 'Closed', internalsource, 0))) as InternalClosed, " +
  		"            (MAX(DECODE(STATUSDESC, 'Closed', externalsource, 0))) as ExternalClosed, " +
  		"            (MAX(DECODE(STATUSDESC, 'Closed', internalsource, 0))) +(MAX(DECODE(STATUSDESC, 'Closed', externalsource, 0)))  as totalclosed, " +
  		"            (MAX(DECODE(STATUSDESC, 'Open', internalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', internalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', internalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Other', internalsource, 0))) as InternalTotal, " +
  		"            (MAX(DECODE(STATUSDESC, 'Open', externalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', externalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', externalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Other', externalsource, 0))) as ExternalTotal, " +
  		"             (MAX(DECODE(STATUSDESC, 'Open', internalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', internalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', internalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Other', internalsource, 0))) +(MAX(DECODE(STATUSDESC, 'Open', externalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', externalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', externalsource, 0)))+(MAX(DECODE(STATUSDESC, 'Other', externalsource, 0)))  as TotalTotal " +
  		"from " +
  		"( " +
  		"SELECT  requestphasedesc,STATUSDESC, " +
  		"            (MAX(DECODE(SOURCEDESC, 'Internal', CT, 0))) as internalsource, " +
  		"            (MAX(DECODE(SOURCEDESC, 'External', CT, 0))) as externalsource " +
  		" FROM " +
  		"( " +
  		"SELECT  requestphasedesc,SOURCEDESC, STATUSDESC,  SUM(CT) CT " +
  		"FROM (	select a.REQUESTPHASEDESC,b.SOURCEDESC,b.STATUSDESC,b.ct " +
  		" from  OAM_RM_REQUEST_PHASE a    inner join     oam_rm_products pd " +
                // The following line is edited by Bhanu april 16 2009         
  		// "  on (A.phasetype = pd.phasetype and pd.PRODUCTID = '"+prodid+"') OR a.REQUESTPHASEDESC like 'Product Audit'   left join " +
                "  on (A.phasetype = pd.phasetype and pd.PRODUCTID = '"+prodid+"')   left join " +
  		"( " +
  		"SELECT " +
  		"         ph.requestphasedesc,SE.SOURCEDESC, " +
  		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
  		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
  		"         when ST.STATUSDESC in ('Closed') then 'Closed' " +
  		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, " +
  		"         COUNT(* ) AS CT " +
  		"FROM " +
  		"( " +
  		"SELECT   REQUESTCODE,MAX(LASTUPDATEDDATE) M " +
  		"          FROM     OAM_RM_ARCHIVE " +
  		"          WHERE    1 = 1 " +
  		"                   AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
  		" GROUP BY REQUESTCODE ) A " +
  		"        inner join " +
  		"         OAM_RM_ARCHIVE RM " +
  		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
  		"         LEFT JOIN OAM_RM_REQUEST_SOURCE SE " +
  		"           ON RM.SOURCEID = SE.SOURCEID " +
  		"         INNER JOIN OAM_RM_REQUEST_TYPES RT " +
  		"         on rt.REQUESTTYPEID=rm.REQUESTTYPEID " +
  		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
  		"           ON RM.STATUSID = ST.STATUSID " +
  		"               inner JOIN OAM_RM_REQUEST_phase ph " +
  		"           ON  RM.phasedetected=ph.requestphaseid " +
  		" inner join oam_rm_products pd " +
  		"  on pd.phasetype = ph.phasetype and pd.PRODUCTID = '"+prodid+"' " +
  		"WHERE    A.REQUESTCODE = RM.REQUESTCODE " ;
  if(!cid.equals(""))
	  {  
	 	strSQL+="AND  RM.CLIENTID = '"+cid+"'";    
	  }
	  if(!prodid.equals(""))
	  {
	 	strSQL+="AND  RM.PRODUCTID = '"+prodid+"'";   
	 			    
	  }
	  if(!projid.equals(""))
	  {
	 	strSQL+="AND  RM.PROJECTID = '"+projid+"'";       
	  }
	  if(!dataprovid.equals(""))   
	  {
	 	strSQL+="AND  RM.DATAPROVIDERID = '"+dataprovid+"'";       
	  }
	  if(!postid.equals(""))
	  {
	 	strSQL+="AND  RM.requesttypeid = '"+postid+"'";       
	  }		
strSQL+=     		"and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
  		"GROUP BY         ph.requestphasedesc, " +
  		"        SE.SOURCEDESC," +
  		"         ST.STATUSDESC " +
  		"         order by requestphasedesc,SOURCEDESC,STATUSDESC ) b " +
  		" ON a.REQUESTPHASEDESC = b.REQUESTPHASEDESC " +
  		"    ) GROUP BY " +
  		"requestphasedesc,SOURCEDESC,STATUSDESC )" +
  		" group BY requestphasedesc,STATUSDESC ) GROUP BY requestphasedesc"; 

	try{       
           stmt=myConn.createStatement(); 
           System.out.println("SQL->"+strSQL);
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getPhaseDetectedReport()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                                   	
	}     
	
	public boolean getProviderSpecificStatusData(String f,String t,String cid,String prodid,String projid,String dataprovid,String fClientName,String fOpenRequest,String fCompletedRequest,String fClosedRequest,String fTotalRequest,String fOpenDefect,String fCompletedDefect,String fClosedDefect,String fTotalDefect,String fOpenIssue,String fCompletedIssue,String fClosedIssue,String fTotalIssue,String fTotal, String userID) throws Exception   
	{
		boolean retVal=false;
         strSQL="select * from " +
         		"(" +
         		"select clientname,clientid," +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Request',Open, 0))) as OpenRequest, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Request',Completed, 0))) as CompletedRequest, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Request',Closed, 0))) as ClosedRequest, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Request',Total, 0))) as TotalRequest, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Defect',Open, 0))) as OpenDefect, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Defect',Completed, 0))) as CompletedDefect, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Defect',Closed, 0))) as ClosedDefect, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Defect',Total, 0))) as TotalDefect, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Issue',Open, 0))) as OpenIssue, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Issue',Completed, 0))) as CompletedIssue, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Issue',Closed, 0))) as ClosedIssue, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Issue',Total, 0))) as TotalIssue, " +
         		"(MAX(DECODE(REQUESTTYPEDESC, 'Request',Total, 0)))+(MAX(DECODE(REQUESTTYPEDESC, 'Defect',Total, 0)))+(MAX(DECODE(REQUESTTYPEDESC, 'Issue',Total, 0))) as total " +
         		"from " +
         		"( " +
         		"select case when  clientname is null then 'No Client' else clientname end as clientname,requesttypedesc,clientid, " +
         		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0))) as Open, " +
         		"            (MAX(DECODE(STATUSDESC, 'Completed', CT, 0))) as Completed, " +
         		"             (MAX(DECODE(STATUSDESC, 'Closed', CT, 0))) as Closed, " +
         		"            (MAX(DECODE(STATUSDESC, 'Open', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Completed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Closed', CT, 0)))+(MAX(DECODE(STATUSDESC, 'Other', CT, 0))) as Total " +
         		"from " +
         		"( " +
         		"SELECT  clientname, requesttypedesc,STATUSDESC,clientid,  SUM(CT) CT " +
         		"FROM " +
         		"( " +
         		"SELECT          SE.CLIENTNAME,rt.requesttypedesc, " +
         		"         case when  ST.STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open' " +
         		"         when ST.STATUSDESC in ('Completed','QC Completed') then 'Completed' " +
         		"         when ST.STATUSDESC in ('Closed') then 'Closed' " +
         		"         else case when ST.STATUSDESC not in ('Dropped')  then 'Other' end end as STATUSDESC, SE.clientid, " +
         		"         COUNT(* ) AS CT " +
         		"FROM " +
         		"( " +
         		"SELECT   REQUESTCODE,MAX(LASTUPDATEDDATE) M " +
         		"          FROM     OAM_RM_ARCHIVE " +
         		"          WHERE    1 = 1 " +
         		"                   AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"          GROUP BY REQUESTCODE " +
         		") A " +
         		"        inner join " +
         		"         OAM_RM_ARCHIVE RM " +
         		"         on a.requestcode=rm.requestcode and rm.lastupdateddate=a.m " +
         		"         LEFT JOIN OAM_CLIENTS SE " +
         		"           ON RM.DATAPROVIDERID = SE.CLIENTID " +
         		"         INNER JOIN OAM_RM_REQUEST_TYPES RT " +
         		"         on rt.REQUESTTYPEID=rm.REQUESTTYPEID " +
         		"         LEFT JOIN OAM_RM_REQUESTSTATUS ST " +
         		"           ON RM.STATUSID = ST.STATUSID " +
         		"WHERE    A.REQUESTCODE = RM.REQUESTCODE ";
         		 if(!cid.equals(""))
       		  {  
       		 	strSQL+="AND  RM.CLIENTID = '"+cid+"'";    
       		  }
       		  if(!prodid.equals(""))
       		  {
       		 	strSQL+="AND  RM.PRODUCTID = '"+prodid+"'";    
       		  }
       		  if(!projid.equals(""))
       		  {
       		 	strSQL+="AND  RM.PROJECTID = '"+projid+"'";       
       		  }
       		  if(!dataprovid.equals(""))
       		  {
       		 	strSQL+="AND  RM.DATAPROVIDERID = '"+dataprovid+"'";       
       		  }
       		strSQL+=		"and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
         		"GROUP BY " +
         		"         SE.CLIENTNAME, " +
         		"         ST.STATUSDESC, " +
         		"         rt.requesttypedesc,SE.clientid " +
         		"         order by CLIENTNAME,requesttypedesc,STATUSDESC " +
         		") GROUP BY " +
         		"CLIENTNAME,requesttypedesc,STATUSDESC,clientid ) " +
         		" GROUP BY " +
         		"CLIENTNAME,requesttypedesc,clientid " +
         		")  group by clientname,clientid ) where 1=1 "; 
       		if(!fClientName.equals(""))
     		{
     		strSQL+= " and lower(clientname) like lower('%"+fClientName+"%') ";     				
     		}
  			if(!fOpenRequest.equals(""))
     		{   
  				fOpenRequest=fOpenRequest.trim();
     		strSQL+= " and openRequest "+ getSQLSubQuery(fOpenRequest);      
     		}
  			if(!fCompletedRequest.equals(""))
     		{   
  				fCompletedRequest=fCompletedRequest.trim();
     		strSQL+= " and completedRequest "+ getSQLSubQuery(fCompletedRequest);      
     		}  
  			if(!fClosedRequest.equals(""))
     		{   
  				fClosedRequest=fClosedRequest.trim();
     		strSQL+= " and closedRequest "+ getSQLSubQuery(fClosedRequest);      
     		}  
  			if(!fTotalRequest.equals(""))
     		{   
  				fTotalRequest=fTotalRequest.trim();
     		strSQL+= " and totalRequest "+ getSQLSubQuery(fTotalRequest);      
     		} 
  			if(!fOpenDefect.equals(""))
     		{   
  				fOpenDefect=fOpenDefect.trim();
     		strSQL+= " and openDefect "+ getSQLSubQuery(fOpenDefect);      
     		} 
  			if(!fCompletedDefect.equals(""))
     		{   
  				fCompletedDefect=fCompletedDefect.trim();
     		strSQL+= " and completedDefect "+ getSQLSubQuery(fCompletedDefect);      
     		}
  			if(!fClosedDefect.equals(""))
     		{   
  				fClosedDefect=fClosedDefect.trim();
     		strSQL+= " and closedDefect "+ getSQLSubQuery(fClosedDefect);      
     		}
  			if(!fTotalDefect.equals(""))
     		{   
  				fTotalDefect=fTotalDefect.trim();
     		strSQL+= " and totalDefect "+ getSQLSubQuery(fTotalDefect);      
     		} 
  			if(!fOpenIssue.equals(""))
     		{   
  				fOpenIssue=fOpenIssue.trim();
     		strSQL+= " and openIssue "+ getSQLSubQuery(fOpenIssue);      
     		} 
  			if(!fCompletedIssue.equals(""))
     		{   
  				fCompletedIssue=fCompletedIssue.trim();
     		strSQL+= " and completedIssue "+ getSQLSubQuery(fCompletedIssue);      
     		} 
  			if(!fClosedIssue.equals(""))
     		{   
  				fClosedIssue=fClosedIssue.trim();
     		strSQL+= " and closedIssue "+ getSQLSubQuery(fClosedIssue);      
     		} 
  			if(!fTotalIssue.equals(""))
     		{   
  				fTotalIssue=fTotalIssue.trim();
     		strSQL+= " and totalIssue "+ getSQLSubQuery(fTotalIssue);      
     		} 
  			if(!fTotal.equals(""))
     		{   
  				fTotal=fTotal.trim();
     		strSQL+= " and total "+ getSQLSubQuery(fTotal);  
     		
     		}  
  			
  			 strSQL+= "AND  nvl(clientid,' ') IN"+ super.getAccesibleClients(userID);
  			System.out.println("DEBUGING********"+strSQL);
         try{
           stmt=myConn.createStatement();               
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getProviderSpecificStatusData()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                                	
	}
	
	/**
	 * returns the Phase Injected Report for Request Manager Reports
	 * Added: Dinesh Bajracharya, 21 Oct 2009 
	 * */
	public boolean getPhaseInjectedReport(String f,String t,String cid,String prodid,String projid,String dataprovid,String postid) throws Exception   
	{
		boolean retVal=false;
		
		 
		 
		 strSQL = ""
			 + "SELECT   requestphasedesc, "
			 + "         (Max(Decode(statusdesc,'Open',internalsource, "
			 + "                                0)))                                                                                                                                                                    AS internalopen, "
			 + "         (Max(Decode(statusdesc,'Open',externalsource, "
			 + "                                0)))                                                                                                                                                                    AS externalopen, "
			 + "         (Max(Decode(statusdesc,'Open',internalsource, "
			 + "                                0))) + (Max(Decode(statusdesc,'Open',externalsource, "
			 + "                                                              0)))                                                         AS totalopen, "
			 + "         (Max(Decode(statusdesc,'Completed',internalsource, "
			 + "                                0)))                                                                                                                                                               AS internalcompleted, "
			 + "         (Max(Decode(statusdesc,'Completed',externalsource, "
			 + "                                0)))                                                                                                                                                               AS externalcompleted, "
			 + "         (Max(Decode(statusdesc,'Completed',internalsource, "
			 + "                                0))) + (Max(Decode(statusdesc,'Completed',externalsource, "
			 + "                                                              0)))                                               AS totalcompleted, "
			 + "         (Max(Decode(statusdesc,'Closed',internalsource, "
			 + "                                0)))                                                                                                                                                                  AS internalclosed, "
			 + "         (Max(Decode(statusdesc,'Closed',externalsource, "
			 + "                                0)))                                                                                                                                                                  AS externalclosed, "
			 + "         (Max(Decode(statusdesc,'Closed',internalsource, "
			 + "                                0))) + (Max(Decode(statusdesc,'Closed',externalsource, "
			 + "                                                              0)))                                                     AS totalclosed, "
			 + "         (Max(Decode(statusdesc,'Open',internalsource, "
			 + "                                0))) + (Max(Decode(statusdesc,'Completed',internalsource, "
			 + "                                                              0))) + (Max(Decode(statusdesc,'Closed',internalsource, "
			 + "                                                                                            0))) + (Max(Decode(statusdesc,'Other',internalsource, "
			 + "                                                                                                                          0))) AS internaltotal, "
			 + "         (Max(Decode(statusdesc,'Open',externalsource, "
			 + "                                0))) + (Max(Decode(statusdesc,'Completed',externalsource, "
			 + "                                                              0))) + (Max(Decode(statusdesc,'Closed',externalsource, "
			 + "                                                                                            0))) + (Max(Decode(statusdesc,'Other',externalsource, "
			 + "                                                                                                                          0))) AS externaltotal, "
			 + "         (Max(Decode(statusdesc,'Open',internalsource, "
			 + "                                0))) + (Max(Decode(statusdesc,'Completed',internalsource, "
			 + "                                                              0))) + (Max(Decode(statusdesc,'Closed',internalsource, "
			 + "                                                                                            0))) + (Max(Decode(statusdesc,'Other',internalsource, "
			 + "                                                                                                                          0))) + (Max(Decode(statusdesc,'Open',externalsource, "
			 + "                                                                                                                                                        0))) + (Max(Decode(statusdesc,'Completed',externalsource, "
			 + "                                                                                                                                                                                      0))) + (Max(Decode(statusdesc,'Closed',externalsource, "
			 + "                                                                                                                                                                                                                    0))) + (Max(Decode(statusdesc,'Other',externalsource, "
			 + "                                                                                                                                                                                                                                                  0))) AS totaltotal "
			 + "FROM     (SELECT   requestphasedesc, "
			 + "                   statusdesc, "
			 + "                   (Max(Decode(sourcedesc,'Internal',ct, "
			 + "                                          0))) AS internalsource, "
			 + "                   (Max(Decode(sourcedesc,'External',ct, "
			 + "                                          0))) AS externalsource "
			 + "          FROM     (SELECT   requestphasedesc, "
			 + "                             sourcedesc, "
			 + "                             statusdesc, "
			 + "                             Sum(ct) ct "
			 + "                    FROM     (SELECT a.requestphasedesc, "
			 + "                                     b.sourcedesc, "
			 + "                                     b.statusdesc, "
			 + "                                     b.ct "
			 + "                              FROM   oam_rm_injected_phase a "
			 + "                                     INNER JOIN oam_rm_products pd "
			 + "                                       ON (a.phasetype = pd.phasetype "
			 + "                                           AND pd.productid = '"+prodid+"') "
			 + "                                     LEFT JOIN (SELECT   ph.requestphasedesc, "
			 + "                                                         se.sourcedesc, "
			 + "                                                         CASE  "
			 + "                                                           WHEN st.statusdesc IN ('Not Started','Assigned','In Progress') "
			 + "                                                           THEN 'Open' "
			 + "                                                           WHEN st.statusdesc IN ('Completed','QC Completed') "
			 + "                                                           THEN 'Completed' "
			 + "                                                           WHEN st.statusdesc IN ('Closed') "
			 + "                                                           THEN 'Closed' "
			 + "                                                           ELSE CASE  "
			 + "                                                                  WHEN st.statusdesc NOT IN ('Dropped') "
			 + "                                                                  THEN 'Other' "
			 + "                                                                END "
			 + "                                                         END AS statusdesc, "
			 + "                                                         Count(* ) AS ct "
			 + "                                                FROM     (SELECT   requestcode, "
			 + "                                                                   Max(lastupdateddate) m "
			 + "                                                          FROM     oam_rm_archive "
			 + "                                                          WHERE    1 = 1 "
			 + "                                                                   AND trunc(LASTUPDATEDDATE) BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " 
			 + "                                                          GROUP BY requestcode) a "
			 + "                                                         INNER JOIN oam_rm_archive rm "
			 + "                                                           ON a.requestcode = rm.requestcode "
			 + "                                                              AND rm.lastupdateddate = a.m "
			 + "                                                         LEFT JOIN oam_rm_request_source se "
			 + "                                                           ON rm.sourceid = se.sourceid "
			 + "                                                         INNER JOIN oam_rm_request_types rt "
			 + "                                                           ON rt.requesttypeid = rm.requesttypeid "
			 + "                                                         LEFT JOIN oam_rm_requeststatus st "
			 + "                                                           ON rm.statusid = st.statusid "
			 + "                                                         INNER JOIN oam_rm_injected_phase ph "
			 + "                                                           ON rm.phaseinject = ph.requestphaseid "
			 + "                                                         INNER JOIN oam_rm_products pd "
			 + "                                                           ON pd.phasetype = ph.phasetype "
			 + "  and pd.PRODUCTID = '"+prodid+"' " 
			 + "                                                WHERE    a.requestcode = rm.requestcode ";

  if(!cid.equals(""))
	  {  
	 	strSQL+="AND  RM.CLIENTID = '"+cid+"'";    
	  }
	  if(!prodid.equals(""))
	  {
	 	strSQL+="AND  RM.PRODUCTID = '"+prodid+"'";   
	 			    
	  }
	  if(!projid.equals(""))
	  {
	 	strSQL+="AND  RM.PROJECTID = '"+projid+"'";       
	  }
	  if(!dataprovid.equals(""))   
	  {
	 	strSQL+="AND  RM.DATAPROVIDERID = '"+dataprovid+"'";       
	  }
	  if(!postid.equals(""))
	  {
	 	strSQL+="AND  RM.requesttypeid = '"+postid+"'";       
	  }		
strSQL+=     		"and trunc(rm.requestdate)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " +
  		"GROUP BY         ph.requestphasedesc, " +
  		"        SE.SOURCEDESC," +
  		"         ST.STATUSDESC " +
  		"         order by requestphasedesc,SOURCEDESC,STATUSDESC ) b " +
  		" ON a.REQUESTPHASEDESC = b.REQUESTPHASEDESC " +
  		"    ) GROUP BY " +
  		"requestphasedesc,SOURCEDESC,STATUSDESC )" +
  		" group BY requestphasedesc,STATUSDESC ) GROUP BY requestphasedesc"; 
	System.out.println("SQL->"+strSQL); 
	try{       
           stmt=myConn.createStatement();               
           myRS=stmt.executeQuery(strSQL);             
           retVal=true;
       }catch (SQLException se){
           System.out.println("\nError:getPhaseDetectedReport()-->"+se);mess=se.getMessage();}
       mess="ok";     
       return retVal;                                   	
	}  
	
	
	/**
	 * added to get all requestid whose time has been logged
	 * @param productID
	 * @return
	 * @throws Exception
	 */
	public boolean getAllRequestOfProduct(String productID) throws Exception   
    {
        boolean retVal=false;
          strSQL="SELECT distinct requestcode from oam_rm_request_TimeLogs";          
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);      
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getAllRequestOfProduct()-->"+se);mess=se.getMessage();}
        mess="ok";
        return retVal;                          
    }
	
	
	/**
	 * method to get all users who have access to the product
	 * @param productID
	 * @return
	 * @throws Exception
	 */
	public boolean getAllusers(String productID) throws Exception   
    {
        boolean retVal=false;
          strSQL="  SELECT distinct a.userid, b.loginname, b.username  FROM tmp_oam_rm_user_product  a join usr_users b  ON a.userid=b.userid where 1=1    ";   
          
          if(!productID.equals(""))
          {
        	  strSQL +=" and PRODUCTID = '"+productID+"'";
          }
          strSQL += "ORDER BY username ";
          System.out.println("getting users"+strSQL);
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);      
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getAllusers()-->"+se);mess=se.getMessage();}
        mess="ok";
        return retVal;                          
    }
		
	/**
	 * to get report of time log
	 * @param productID 
	 * @param f
	 * @param t
	 * @param allFT
	 * @param userid
	 * @param requestid
	 * @param allofSelected   .. if this true and requestid is seleced log of all the request related to this request is generated
	 * @return
	 */
	public boolean getReport(String productID, String f, String t, boolean allFT,String userid, String requestid, String allofSelected, String providerID)
	{
		boolean retVal=false;
		strSQL = ""
				+ "SELECT aa.*, "
				+ "       clients.clientname "
				+ "FROM   (SELECT a.userid, "
				+ "               b.username, "
				+ "               b.loginname, "
				+ "               a.requestcode, "
				+ "               c.requesttypeid, "
				+ "               a.devtime, "
				+ "               a.qctime, "
				+ "               a.loggedon, "
				+ "               c.dataproviderid "
				+ "        FROM   oam_rm_request_timelogs a "
				+ "               join usr_users b "
				+ "                 ON a.userid = b.userid "
				+ "               left join oam_rm_requestmanager c "
				+ "                      ON a.requestcode = c.requestcode)aa "
				+ "       left join oam_clients clients "
				+ "              ON aa.dataproviderid = clients.clientid "
				+ "WHERE  1 = 1";
		if(!allFT)
		{
		strSQL += " and trunc(loggedon)  BETWEEN to_date('"+f+"','mm/dd/yyyy') and to_date('"+t+"','mm/dd/yyyy') " ; 
		}
		if(!userid.equals(""))
		{
			strSQL +=" and userid = '"+userid+ "'";
		}
		
		
		if(allofSelected.equals("true") && !requestid.equals(""))
		{
			strSQL +=" and  requestcode in (";
			strSQL += ""
					+ "SELECT '"+requestid+"' AS requuestid "
					+ "FROM   dual "
					+ "UNION ALL "
					+ "(SELECT secondaryrequestcode "
					+ " FROM   oam_rm_requestrelations "
					+ " START WITH primaryrequestcode = '"+requestid+"'"
					+ " CONNECT BY PRIOR secondaryrequestcode = primaryrequestcode) )";
		}
		else if(!requestid.equals(""))
		{
			strSQL +=" and requestcode = '"+requestid+ "'";
		}
		
		if(!providerID.equals(""))
		{
			strSQL +=" and dataproviderid = '"+providerID+ "'";
		}
		
		strSQL +="order by loggedon desc ";
		//System.out.println("getting Report>>>>>"+ strSQL);
      try{
          stmt=myConn.createStatement();       
          myRS=stmt.executeQuery(strSQL);      
          retVal=true;
      }catch (SQLException se){
          System.out.println("\nError:getReport()-->"+se);mess=se.getMessage();}
      mess="ok";
      return retVal;  
	}
	
	public boolean getProviders() throws Exception   
    {
        boolean retVal=false;
          strSQL="select clientid as ProviderID,clientname as ProviderName from oam_clients"; 
          
        try{
            stmt=myConn.createStatement();       
            myRS=stmt.executeQuery(strSQL);           
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:getProviders()-->"+se);mess=se.getMessage();}
        mess="ok";     
        return retVal;                                 
    }
	
    public boolean getDataSources(String userID){
    	
        boolean result=false;
        strSQL = "select clientid as ProviderID,clientname as ProviderName from oam_clients a";
        strSQL+= " where clientid IN"+super.getAccesibleClients(userID);
        strSQL+=" and clientid not in (999) Order by a.ClientName";
       // System.out.println("quesy is >>>>>>>>>>> "+strSQL);
        try
          {
                  stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
      }
}
