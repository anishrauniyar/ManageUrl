package com.d2hs.soam.rm;

import com.d2hawkeye.util.CommonUtils;
import java.io.File;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.d2hs.soam.ConnectionBean;
import com.d2hs.soam.common.TextEncoder;
import com.d2hs.soam.data.ProductionIntegrationCode;
import com.verisk.ice.dao.DashboardFilterDAO;
import com.verisk.ice.dao.QuerySpecification;
import com.verisk.ice.design.IceTicketListType;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.RequestParamDTO;
import com.verisk.ice.utils.AppConstants;
import com.verisk.ice.utils.DAOUtils;
import com.verisk.ice.utils.DTOUtils;

import d2Systems.oam.SendMail;
import d2Systems.rm.RequestEmail;
import d2Systems.rm.RequestTemplate;
import d2Systems.rm.User;
import lombok.Getter;
import lombok.Setter;

public class QueryBean extends ConnectionBean {

    public Connection conn;
    public String mainEnggName = "";
    public String mainEnggEmail = "";
    public String reqPersonName = "";
    public String reqPersonEmail = "";
    private String preAssignedTo = "";
    private String preActionTaken = "";
    private String preStatus = "";
    private String preThresholdDays = "";
    private String fClientID = null;
    private String fRequestType = "";
    private String fRemarks = "";
    private String sqlForExcel = "";
    private String productID = "";
    private String projectID = "";
    private String employerGroup = "";
    private String appreleasedate = "";
    private String implementationtypeid = "";
    private String npm = "";
    private String processmonth = "";
    private String phasecompleteddate = "";
    private String defappname = "";

    @Setter
    @Getter
    private String integrationtype = "";
    
    
    @Setter
    @Getter
    private String parentrequesttype = "";

    @Setter
    @Getter
    private String applicationkickoffdate = "";

    @Setter
    @Getter
    private String releasetag = "";

    @Setter
    @Getter
    private String iceTicketListType;
    @Setter
    @Getter
    private String iceTicketListTypeUserId;
    @Setter
    @Getter
    private DashboardFilterDTO dashboardFilterDTO;

    public String getAppreleasedate() {
        return appreleasedate;
    }

    public String getPhasecompleteddate() {
        return phasecompleteddate;
    }

    public void setPhasecompleteddate(String phasecompleteddate) {
        this.phasecompleteddate = phasecompleteddate;
    }

    public String getProcessmonth() {
        return processmonth;
    }

    public void setProcessmonth(String processmonth) {
        this.processmonth = processmonth;
    }

    public void setAppreleasedate(String appreleasedate) {
        this.appreleasedate = appreleasedate;
    }

    public String getImplementationtypeid() {
        return implementationtypeid;
    }

    public void setImplementationtypeid(String implementationtypeid) {
        this.implementationtypeid = implementationtypeid;
    }

    public String getApplicationtype() {
        return applicationtype;
    }

    public void setApplicationtype(String applicationtype) {
        this.applicationtype = applicationtype;
    }

    private String applicationtype = "";

    public String getEmployerGroup() {
        return employerGroup;
    }

    public void setEmployerGroup(String employerGroup) {
        this.employerGroup = employerGroup;
    }

    public String getDefappname() {
        return defappname;
    }

    public void setDefappname(String defappname) {
        this.defappname = defappname;
    }

    private String FixedInVersion = "";

    protected String orderField = "";
    protected String order = "";
    protected String strFilters = "";

    // added 1 parameter
    protected String requestTypeCode = "";
    protected String viewLabel = "";
    protected String viewUserID = "";
    protected String requestUpdatedDate = "";
    protected boolean isInWatchList = false;
    protected String watchListUser = "";

    protected String issueTypeId = "";
    protected String issueTypeName = "";

    protected String phaseName = "";
    protected String projectName = "";
    protected String billable = "";

    public String getBillable() {
        return billable;
    }

    public void setBillable(String billable) {
        this.billable = billable;
    }

    protected boolean getFromArchive = false;
    /**
     * the requestcode that was sent in email
     */
    private String mailRequestCode = "";

    final static Logger logger = Logger.getLogger(QueryBean.class);

    public String getProductCode() {
        return productID;
    }

    public void setProductCode(String productCode) {
        productID = productCode;
    }

    public String getFixedInVersion() {
        return FixedInVersion;
    }

    public void setFixedInVersion(String fixedInVersion) {
        FixedInVersion = fixedInVersion;
    }

    public String getRequestUpdatedDate() {
        return requestUpdatedDate;
    }

    public void setRequestUpdatedDate(String requestUpdatedDate) {
        this.requestUpdatedDate = requestUpdatedDate;
    }

    public String getIssueTypeId() {
        return issueTypeId;
    }

    public void setIssueTypeId(String issueTypeId) {
        this.issueTypeId = issueTypeId;
    }

    public String getIssueTypeName() {
        return issueTypeName;
    }

    public void setIssueTypeName(String issueTypeName) {
        this.issueTypeName = issueTypeName;
    }

    public String getPhaseName() {
        return phaseName;
    }

    public void setPhaseName(String phaseName) {
        this.phaseName = phaseName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public QueryBean() {
    }

    public void setConnection() {
        conn = myConn;
    }

    private String requestCode = "";

    public void setRequestCode(String rc) {
        requestCode = rc;
    }

    public String getRequestCode() {
        return requestCode;
    }

    private String msgType = "";

    public void setMsgType(String s) {
        msgType = s;
    }

    private String conversionDate = "";

    public void setConversionDate(String conversionDate) {
        this.conversionDate = conversionDate;
    }

    private String requestTypeTargetDate = "";

    public void setRequestTypeTargetDate(String requestTypeTargetDate) {
        this.requestTypeTargetDate = requestTypeTargetDate;
    }

    public String getfClientID() {
        return fClientID;
    }

    public void setfClientID(String fClientID) {
        this.fClientID = fClientID;
    }

    // added 2 functions
    public String getrequestTypeCode() {
        return this.requestTypeCode;

    }

    public void setrequestTypeCode(String requestTypeCode) {
        this.requestTypeCode = requestTypeCode;
    }

    public String getviewLabel() {
        return this.viewLabel;

    }

    public void setviewLabel(String viewLabel) {
        this.viewLabel = viewLabel;
    }

    public String getViewUserID() {
        return viewUserID;
    }

    public void setViewUserID(String viewUserID) {
        this.viewUserID = viewUserID;
    }

    private String getSQLSubQuery(String s) {
        if ((s.indexOf(">") == 0) || (s.indexOf("<") == 0)) {
            return (s);
        } else if (s.indexOf("-") > 0) {
            return (" BETWEEN " + s.substring(0, s.indexOf("-")) + " AND " + s
                    .substring(s.indexOf("-") + 1));
        } else {
            return ("=" + s);
        }
    }

    /*
	 * Function name: getLabel Description: This function returns the label of a
	 * request, if it has any Author: Anjana Shrestha Date: July 18, 2006
	 * Parameter: String requestCode Output: void
     */
    public boolean getLabel(String requestCode) {

        String str = "Select LabelName from OAM_RM_LABEL_NAME a, OAM_RM_REQUEST_LABELS b where b.LabelID = a.LabelID and b.RequestCode = '"
                + requestCode + "'";
        return getList(str, "");

    }

    public void setSQLQuery(String aOrd, String sBy, String fRequestTypeDesc,
            String fRequestDate, String fRequestingPerson, String fStatusDesc,
            String fEngineerDesc, String fApplicationVersionDesc,
            String fTargetCompDate, String fActualCompDate, String SN,
            String fClientName, String fappID, String fappName, String fpayor, String fdataType, String fDataLayout, String fComments, String fProductDesc, String fProjectDesc,
            String fModule, String viewCompletedList, String fExpectedCompDate,
            String fRequestPhase, String fRequests, String fRemarks,
            String fActionTaken, String fRequestPriority, String fDevCompDate,
            String fDocType, String fRequestTitle, String fRequestSeverityDesc,
            String fImpact, String fSource, String fDetectedVersion,
            String fFixedVersion, String fSeverity, String fInjectedPhase,
            String fDetectedPhase, String fDataProvider,
            String fSoamRequestCode, String fActualHours,
            String fEstimatedHours, String fProductArea, String fSecondaryRequestType, String fPhaseNameText) {

        String sortOrder = aOrd;
        String sortBy = sBy;
        String statusXtraSQL = " NOT IN ('Dropped')";
        char flag = 'n';
        // Deferred=Pending
        if (viewCompletedList.equals("c")) {
            statusXtraSQL = " ='Closed'";
        } else if (viewCompletedList.equals("d")) {
            statusXtraSQL = " ='Dropped'";
        } else if (viewCompletedList.equals("p")) {
            statusXtraSQL = " ='Deferred'";
        } else if (viewCompletedList.equals("l")) // View Label
        {
            statusXtraSQL = " IS not Null";
        }
        if (viewCompletedList.equals("q")) {
            statusXtraSQL = "";
        } else {
            statusXtraSQL = " AND s.StatusDesc " + statusXtraSQL;
        }

        if (sortOrder == null || sortOrder.compareTo("d") != 0) {
            sortOrder = " ASC ";
        } else {
            sortOrder = " DESC nulls last ";
        }

        if (sortBy.compareTo("i") == 0) {
            sortBy = " t.PKSource ";
        } else if (sortBy.compareTo("cn") == 0) {
            sortBy = " t.ClientName ";
        } else if (sortBy.compareTo("ai") == 0) {
            sortBy = " t.APPID ";
        } else if (sortBy.compareTo("ap") == 0) {
            sortBy = " t.APPNAME ";
        } else if (sortBy.compareTo("p") == 0) {
            sortBy = " t.PAYER ";
        } else if (sortBy.compareTo("rt") == 0) {
            sortBy = " substr(t.RequestTitle,0,10) ";
        } else if (sortBy.compareTo("b") == 0) {
            sortBy = " To_Date(t.RequestDate, 'MM/DD/YYYY') ";
        } else if (sortBy.compareTo("rp") == 0) {
            sortBy = " t.REQUESTINGPERSONDESC ";
        } else if (sortBy.compareTo("bb") == 0) {
            sortBy = " To_Date(t.targetcompdate, 'MM/DD/YYYY') ";
        } else if (sortBy.compareTo("at") == 0) {
            sortBy = " t.User_Name ";
        } else if (sortBy.compareTo("s") == 0) {
            sortBy = " t.StatusDesc ";
        } else if (sortBy.compareTo("it") == 0) {
            sortBy = " t.IssueTypeName";
        } else if (sortBy.compareTo("pn") == 0) {
            sortBy = " t.PhaseName ";
        } else if (sortBy.compareTo("jn") == 0) {
            sortBy = " t.ProjectName ";
        } else if (sortBy.compareTo("dt") == 0) {
            sortBy = " t.datatype ";
        } else if (sortBy.compareTo("eg") == 0) {
            sortBy = " t.employergroup ";
        
         } else if (sortBy.compareTo("ig") == 0) {
        sortBy = " t.integrationtype ";
           }
         else if (sortBy.compareTo("dl") == 0) {
            sortBy = " t.datalayout ";
        } else if (sortBy.compareTo("cd") == 0) {
            sortBy = " To_Date(t.conversiondate, 'MM/DD/YYYY') ";
        } else if (sortBy.compareTo("tt") == 0) {
            sortBy = " To_Date(t.issueTypeTargetDate, 'MM/DD/YYYY') ";
        } else if (sortBy.compareTo("c") == 0) {
            sortBy = " substr(t.REMARKS,0,20) ";
        } else if (sortBy.compareTo("st") == 0) {
            sortBy = " SecondaryRequestType";
        } else if (sortBy.compareTo("ad") == 0) {
            sortBy = " To_Date(t.appreleasedate, 'MM/DD/YYYY') ";
        } else if (sortBy.compareTo("at") == 0) {
            sortBy = " t.applicationtype";
        } else if (sortBy.compareTo("P") == 0) {
            sortBy = " t.requestpriority";
        } else if (sortBy.compareTo("im") == 0) {
            sortBy = " t.implementationtypeid";
        } else if (sortBy.compareTo("AP") == 0) {
            sortBy = " t.defappname ";

        } else if (sortBy.compareTo("AK") == 0) {
            sortBy = " To_Date(t.applicationkickoffdate, 'MM/DD/YYYY') ";

        } else if (sortBy.compareTo("RT") == 0) {
            sortBy = "t.releasetag ";

        } else if (sortBy.compareTo("PR") == 0) {
            sortBy = "t.IssueTypeName ";

        } else {
            sortBy = " t.PKSource ";
        }

        String orderBy = " ORDER BY " + sortBy + sortOrder;
        // System.out.println ("Sort by: " + orderBy);

        String tableName = "OAM_RM_REQUESTMANAGER";
        String sqlp = "";
        String sqlp1 = "";

        strSQL = "SELECT  p.pksource, p.RequestCode,"
                + " CASE Nvl(p.processmonth,'N/A') "
                + "   WHEN '1' THEN 'January' "
                + "   WHEN '2' THEN 'February' "
                + "   WHEN '3' THEN 'March' "
                + "   WHEN '4' THEN 'April' "
                + "   WHEN '5' THEN 'May' "
                + "   WHEN '6' THEN 'June' "
                + "   WHEN '7' THEN 'July' "
                + "   WHEN '8' THEN 'August' "
                + "   WHEN '9' THEN 'September' "
                + "   WHEN '10' THEN 'October' "
                + "   WHEN '11' THEN 'November' "
                + "   WHEN '12' THEN 'December' "
                + "   ELSE 'N/A'  "
                + "   END AS processmonth, "
                + " it.IssueTypeName,pp.IssueTypeName as parentrequesttype,To_char (p.requestdate,'mm/dd/yyyy') AS requestdate,To_char (p.phasecompleteddate,'mm/dd/yyyy') AS phasecompleteddate,p.RequestingPerson,"
                + "CASE WHEN p.IS_CONVERTED IS NOT NULL THEN "
                + "(SELECT ISSUETYPENAME FROM oam_cr_issuetype aaa where aaa.issuetypeid=p.convrequesttypeid) "
                + " else '' END as SecondaryRequestType,"
                + sqlp
                + ""
                + " rp.UserName as RequestingPersonDesc,rp.email as ReqPersonEmail,c.ClientName,"
                + " p.Requests , p.REMARKS as Comments,"
                + " p.ActionTaken as Remarks,p.RequestTitle,s.StatusDesc,e.UserName AS User_Name,"
                + " To_char (nvl(p.targetcompdate2,p.targetcompdate),'mm/dd/yyyy') AS TargetCompDate,p.datatype as DataType,"
                 + " cr.datalayout as DataLayout,  p.RequestPriority,"
                + " e.UserID AS EnggID,p.isCompleted, Nvl(y.documentCount,0) AS documentCount,"
                + " nvl(p.employergroup,'N/A') as EmployerGroup,CASE when p.integrationtype IS NULL THEN 'N/A' WHEN p.integrationtype='-1' THEN 'N/A'  ELSE p.integrationtype END  integrationtype ,p.lastupdateddate as requestupdatedDate,p.Impact,Nvl(crp.PhaseName,'N/A') as PhaseName,Nvl(crpj.ProjectName,'N/A') as ProjectName,"
                + " CASE WHEN p.statusid <> '1' THEN '0/0' "
                + " ELSE '0/0' END AS phasetarget,"
                + "  Nvl(p.billable,'No') AS billable, "
                + " ( select nvl(listagg(applicationtype, ':') within group (order by APPLICATIONTYPEID),'N/A')  AS APPLICATIONTYPE from oam_cr_applicationtype WHERE APPLICATIONTYPEID IN ( select regexp_substr(p.applicationtype,'[^:]+', 1, level) from dual connect by regexp_substr(p.applicationtype, '[^:]+', 1, level) is not null)) AS applicationtype,"
                + " Nvl(calimplementationtype(itt.implementationtypeid),'N/A') AS implementationtypeid ,"
                + " def.defappname,p.releasetag "
                + // ",watch.requestCode as isInWatchList " +
                " FROM "
                + tableName
                + " p"
                + ""
                + sqlp1
                + ""
                + " LEFT JOIN (SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS ) e ON p.assignedTo=e.UserID "
                + " LEFT JOIN oam_cr_crmanager cr ON p.requestcode=cr.requestcode "
                + " LEFT JOIN OAM_RM_CLIENTS cl ON p.DataProviderID=cl.clientID "
                + " LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.Statusid=s.Statusid"
                + " LEFT JOIN OAM_CR_ISSUETYPE it ON p.RequestTypeid=it.IssueTypeId "
                + " LEFT JOIN OAM_CR_ISSUETYPE pp ON p.parentrequesttype=pp.IssueTypeId "
                + " LEFT JOIN oam_cr_plchmanager itt ON itt.requestcode = p.requestcode "
                + " LEFT JOIN (SELECT USERID, USERNAME,Email,OamStatus FROM USR_USERS "
                + " ) rp ON p.RequestingPerson=rp.UserID "
                + " LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + " LEFT JOIN (SELECT RequestCode,COUNT(1) AS documentCount FROM OAM_RM_MOREDOCUMENTS1 GROUP BY RequestCode) y ON p.RequestCode=y.RequestCode "
                + " LEFT JOIN OAM_CR_PHASES crp ON p.phaseid = crp.phaseid "
                + " LEFT JOIN OAM_CR_PROJECTS crpj ON p.projectid = crpj.projectid "
                + " left join (SELECT requestcode,  application, defappname FROM   oam_cr_defect left JOIN  oam_cr_defectapplication  ON application=defappid  ) def   ON p.requestcode = def.requestcode  "
                + " WHERE 1=1 ";

        if (!requestCode.equals("")) {
            strSQL += " AND p.RequestCode='" + requestCode + "'";
            strCountSQL += " AND p.RequestCode='" + requestCode + "'";
        }

        if (!msgType.equals("")) {
            if (msgType.equalsIgnoreCase("o")) {
                strSQL += " AND s.StatusDesc  like 'Open' ";
                strCountSQL += " AND s.StatusDesc  like 'Open' ";
            } else if (msgType.equalsIgnoreCase("y")) {
                strSQL += " AND s.StatusDesc  like 'Completed'  ";
                strCountSQL += " AND s.StatusDesc  like 'Completed' ";
            } else if (msgType.equalsIgnoreCase("d")) {
                strSQL += " AND s.StatusDesc  like 'Deferred'  ";
                strCountSQL += " AND s.StatusDesc  like 'Deferred' ";
            } else {
                strSQL += " AND p.isCompleted='" + msgType + "'";
                strCountSQL += " AND p.isCompleted='" + msgType + "'";
            }
        }

        strSQL += statusXtraSQL;
        strCountSQL += statusXtraSQL;        
        if (fRequestTypeDesc.length() > 0) {
            if (fRequestTypeDesc.charAt(0) == '!') // if search is based on NOT
            {
                fRequestTypeDesc = fRequestTypeDesc.substring(1);
                // System.out.println(fEngineerDesc);
                // luna
                strSQL += " AND UPPER(r.RequestTypeDesc) NOT LIKE '%"
                        + changeSQLText(fRequestTypeDesc).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(r.RequestTypeDesc) NOT LIKE '%"
                        + changeSQLText(fRequestTypeDesc).toUpperCase()
                        + "%' ESCAPE '!'";
            } else {
                strSQL += " AND UPPER(r.RequestTypeDesc) LIKE '%"
                        + changeSQLText(fRequestTypeDesc).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(r.RequestTypeDesc) LIKE '%"
                        + changeSQLText(fRequestTypeDesc).toUpperCase()
                        + "%' ESCAPE '!'";
            }
        }

        if (fSecondaryRequestType.length() > 0) {
            strSQL += " AND p.IS_CONVERTED IS NOT NULL and p.convrequesttypeid=" + fSecondaryRequestType;
            strCountSQL += " AND p.IS_CONVERTED IS NOT NULL and p.convrequesttypeid=" + fSecondaryRequestType;
        }

        if (fPhaseNameText.length() > 0) {
            strSQL += " AND UPPER(PhaseName) LIKE '%"
                    + changeSQLText(fPhaseNameText).toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(PhaseName) LIKE '%"
                    + changeSQLText(fPhaseNameText).toUpperCase()
                    + "%' ESCAPE '!'";
        }

        if (issueTypeName.length() > 0) {
            strSQL += " AND UPPER(it.IssueTypeName) LIKE '%"
                    + changeSQLText(issueTypeName).toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(it.IssueTypeName) LIKE '%"
                    + changeSQLText(issueTypeName).toUpperCase()
                    + "%' ESCAPE '!'";
        }

        if (parentrequesttype.length() > 0) {
            strSQL += " AND UPPER(pp.IssueTypeName) LIKE '%"
                    + changeSQLText(parentrequesttype).toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(pp.IssueTypeName) LIKE '%"
                    + changeSQLText(parentrequesttype).toUpperCase()
                    + "%' ESCAPE '!'";
        }

        if (phaseName.length() > 0) {
            strSQL += " AND UPPER(crp.phaseName) LIKE '%"
                    + changeSQLText(phaseName).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(crp.phaseName) LIKE '%"
                    + changeSQLText(phaseName).toUpperCase() + "%' ESCAPE '!'";
        }

        if (projectName != null && projectName.length() > 0) {
            strSQL += " AND UPPER(crpj.projectName) LIKE '%"
                    + changeSQLText(projectName).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(crpj.projectName) LIKE '%"
                    + changeSQLText(projectName).toUpperCase() + "%' ESCAPE '!'";
        }

        if (employerGroup != null && employerGroup.length() > 0) {
            strSQL += " AND UPPER(p.employergroup) LIKE '%"
                    + changeSQLText(employerGroup).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.employergroup) LIKE '%"
                    + changeSQLText(employerGroup).toUpperCase() + "%' ESCAPE '!'";
        }
        
        if (integrationtype != null && integrationtype.length() > 0) {
            strSQL += " AND UPPER(p.integrationtype) LIKE '%"
                    + changeSQLText(integrationtype).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.integrationtype) LIKE '%"
                    + changeSQLText(integrationtype).toUpperCase() + "%' ESCAPE '!'";
        }

        if (npm != null && npm.length() > 0) {
            strSQL += " AND UPPER(rpp.username) LIKE '%"
                    + changeSQLText(npm).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(rpp.username) LIKE '%"
                    + changeSQLText(npm).toUpperCase() + "%' ESCAPE '!'";
        }

        if (defappname != null && defappname.length() > 0) {
            strSQL += " AND UPPER(defappname) LIKE '%"
                    + changeSQLText(defappname).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(defappname) LIKE '%"
                    + changeSQLText(defappname).toUpperCase() + "%' ESCAPE '!'";
        }

        if (releasetag != null && releasetag.length() > 0) {
            strSQL += " AND UPPER(releasetag) LIKE '%"
                    + changeSQLText(releasetag).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(releasetag) LIKE '%"
                    + changeSQLText(releasetag).toUpperCase() + "%' ESCAPE '!'";
        }

        if (applicationkickoffdate.length() > 1) {
            strSQL += " AND Trunc(p.applicationkickoffdate) " + getDateRange(applicationkickoffdate);
            strCountSQL += " AND Trunc(p.applicationkickoffdate) "
                    + getDateRange(applicationkickoffdate);
        }

        if (processmonth != null && processmonth.length() > 0) {
            strSQL += " AND UPPER(p.processmonth) LIKE '"
                    + changeSQLText(processmonth).toUpperCase() + "' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.processmonth) LIKE '"
                    + changeSQLText(processmonth).toUpperCase() + "' ESCAPE '!'";
        }

        if (this.phasecompleteddate != null && phasecompleteddate.length() > 0) {
            strSQL += " AND Trunc(p.phasecompleteddate) " + getDateRange(phasecompleteddate);
            strCountSQL += " AND Trunc(p.phasecompleteddate) "
                    + getDateRange(phasecompleteddate);
        }

        if (billable != null && billable.length() > 0) {
            strSQL += " AND UPPER(p.billable) LIKE '%"
                    + changeSQLText(billable).toUpperCase() + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.billable) LIKE '%"
                    + changeSQLText(billable).toUpperCase() + "%' ESCAPE '!'";
        }

        if (appreleasedate != null && appreleasedate.length() > 0) {
            strSQL += " AND Trunc(p.appreleasedate) " + getDateRange(appreleasedate);
            strCountSQL += " AND Trunc(p.appreleasedate) "
                    + getDateRange(appreleasedate);
        }

        if (applicationtype != null && applicationtype.length() > 0) {
            strSQL += " AND UPPER(p.applicationtype) LIKE '%'||calcApplicationType('" + applicationtype + "')||'%' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.applicationtype) LIKE '% '||calcApplicationType('" + applicationtype + "')||'%' ESCAPE '!'";
        }

        if (implementationtypeid != null && implementationtypeid.length() > 0) {
            strSQL += " AND UPPER(itt.implementationtypeid) LIKE ''||calimplementationtypeid('" + implementationtypeid + "')||'' ESCAPE '!'";
            strCountSQL += " AND UPPER(itt.implementationtypeid) LIKE ''||calimplementationtypeid('" + implementationtypeid + "')||'' ESCAPE '!'";
        }

        if (issueTypeId != null && issueTypeId.length() > 0) {
            strSQL += " AND it.issueTypeId = '"
                    + issueTypeId.replaceAll("'", "''").trim() + "'";
        }
        if (fRequestDate.length() > 1) {
            strSQL += " AND Trunc(p.RequestDate) " + getDateRange(fRequestDate);
            strCountSQL += " AND Trunc(p.RequestDate) "
                    + getDateRange(fRequestDate);
        }
        if (conversionDate.length() > 1) {
            strSQL += " AND Trunc(p.conversionDate) " + getDateRange(conversionDate);
            strCountSQL += " AND Trunc(p.conversionDate) "
                    + getDateRange(conversionDate);
        }
        if (requestTypeTargetDate.length() > 1) {
            strSQL += " AND Trunc(Add_working_days(it.issuetypetarget, p.requestdate)) " + getDateRange(requestTypeTargetDate);
            strCountSQL += " AND Trunc(Add_working_days(it.issuetypetarget, p.requestdate)) "
                    + getDateRange(requestTypeTargetDate);
        }
        if (fRequestingPerson.length() > 0) {
            if (fRequestingPerson.charAt(0) == '!') // if search is based on NOT
            {
                fRequestingPerson = fRequestingPerson.substring(1);
                // System.out.println(fEngineerDesc);
                strSQL += " AND UPPER(rp.UserName) NOT LIKE '%"
                        + changeSQLText(fRequestingPerson).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(rp.UserName) NOT LIKE '%"
                        + changeSQLText(fRequestingPerson).toUpperCase()
                        + "%' ESCAPE '!'";
            } else {
                strSQL += " AND UPPER(rp.UserName) LIKE '%"
                        + changeSQLText(fRequestingPerson).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(rp.UserName) NOT LIKE '%"
                        + changeSQLText(fRequestingPerson).toUpperCase()
                        + "%' ESCAPE '!'";
            }
        }
        if (fStatusDesc.length() > 0) {
            if (fStatusDesc.charAt(0) == '!') // if search is based on NOT
            {
                fStatusDesc = fStatusDesc.substring(1);
                // System.out.println(fEngineerDesc);
                strSQL += " AND UPPER(s.StatusDesc) NOT LIKE '%"
                        + changeSQLText(fStatusDesc).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(s.StatusDesc) NOT LIKE '%"
                        + changeSQLText(fStatusDesc).toUpperCase()
                        + "%' ESCAPE '!'";
            } else {
                strSQL += " AND UPPER(s.StatusDesc) LIKE '%"
                        + changeSQLText(fStatusDesc).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(s.StatusDesc) NOT LIKE '%"
                        + changeSQLText(fStatusDesc).toUpperCase()
                        + "%' ESCAPE '!'";
            }
        }
        if (fEngineerDesc.length() > 0) {
            if (fEngineerDesc.charAt(0) == '!') // if search is based on NOT
            {
                fEngineerDesc = fEngineerDesc.substring(1);
                // System.out.println(fEngineerDesc);
                strSQL += " AND UPPER(e.UserName) NOT LIKE '%"
                        + changeSQLText(fEngineerDesc).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(e.UserName) NOT LIKE '%"
                        + changeSQLText(fEngineerDesc).toUpperCase()
                        + "%' ESCAPE '!'";
            } else {
                strSQL += " AND UPPER(e.UserName) LIKE '%"
                        + changeSQLText(fEngineerDesc).toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(e.UserName) LIKE '%"
                        + changeSQLText(fEngineerDesc).toUpperCase()
                        + "%' ESCAPE '!'";
            }
        }
    
        if (fTargetCompDate.length() > 1) {
            strSQL += " AND p.TargetCompDate " + getDateRange(fTargetCompDate);
            strCountSQL += " AND p.TargetCompDate "
                    + getDateRange(fTargetCompDate);
        }

        if (fActualCompDate.length() > 1) {
            strSQL += " AND p.ActualCompDate " + getDateRange(fActualCompDate);
            strCountSQL += " AND p.ActualCompDate "
                    + getDateRange(fActualCompDate);
        }

        if (fClientName.length() > 1) {
            strSQL += "  AND UPPER(c.ClientName) LIKE '%"
                    + changeSQLText(fClientName).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(c.ClientName) LIKE '%"
                    + changeSQLText(fClientName).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }

        if (fappID.length() > 1) {
            strSQL += "  AND UPPER(cc.applicationid) LIKE '%"
                    + changeSQLText(fappID).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(cc.applicationid) LIKE '%"
                    + changeSQLText(fappID).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }
        if (fappName.length() > 1) {
            strSQL += "  AND UPPER(cc.applicationname) LIKE '%"
                    + changeSQLText(fappName).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(cc.applicationname) LIKE '%"
                    + changeSQLText(fappName).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }
        if (fpayor.length() > 1) {
//			strSQL += "  AND UPPER(pl.VHPAYORNAME) LIKE '%"
//					+ changeSQLText(fpayor).trim().toUpperCase()
//					+ "%' ESCAPE '!'";
//			strCountSQL += " AND UPPER(pl.VHPAYORNAME) LIKE '%"
//					+ changeSQLText(fpayor).trim().toUpperCase()
//					+ "%' ESCAPE '!'";
            strSQL += "  AND UPPER(fun_aggregate(p.payorid)) LIKE '%"
                    + changeSQLText(fpayor).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(fun_aggregate(p.payorid)) LIKE '%"
                    + changeSQLText(fpayor).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }
        if (fdataType.length() > 1) {
            strSQL += "  AND UPPER(p.DataType) LIKE '%"
                    + changeSQLText(fdataType).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.DataType) LIKE '%"
                    + changeSQLText(fdataType).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }
        if (fDataLayout.length() > 1) {
            strSQL += "  AND UPPER(cr.datalayout) LIKE '%"
                    + changeSQLText(fDataLayout).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(cr.datalayout) LIKE '%"
                    + changeSQLText(fDataLayout).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }
        if (fComments.length() > 1) {
            strSQL += "  AND UPPER(p.REMARKS) LIKE '%"
                    + changeSQLText(fComments).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(p.REMARKS) LIKE '%"
                    + changeSQLText(fComments).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }

        
        if (fRemarks.length() > 1) {
            strSQL += "  AND UPPER(p.actionTaken) LIKE '%"
                    + changeSQLText(fRemarks).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += "  AND UPPER(p.actionTaken) LIKE '%"
                    + changeSQLText(fRemarks).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }

       

        if (SN.length() >= 1) {
            /**
             * added 1 line
             */
            SN = SN.trim();
            strSQL += " AND p.RequestCode  " + getSQLSubQuery(SN);
            strCountSQL += " AND p.RequestCode" + getSQLSubQuery(SN);
        }
      
        if (fRequests.length() > 0) {
            if (fRequests.charAt(0) == '!') {
                fRequests = fRequests.substring(1);
                // System.out.println(fRequests);
                strSQL += " AND UPPER(p.Requests) NOT LIKE '%"
                        + changeSQLText(fRequests).trim().toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(p.Requests) NOT LIKE '%"
                        + changeSQLText(fRequests).trim().toUpperCase()
                        + "%' ESCAPE '!'";
            } else {

                strSQL += " AND UPPER(p.Requests) LIKE '%"
                        + changeSQLText(fRequests).trim().toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(p.Requests) LIKE '%"
                        + changeSQLText(fRequests).trim().toUpperCase()
                        + "%' ESCAPE '!'";
            }
        }

      

        if (fRequestDate.length() > 1) {
            strSQL += " AND Trunc(p.RequestDate) " + getDateRange(fRequestDate);
            strCountSQL += " AND Trunc(p.RequestDate) "
                    + getDateRange(fRequestDate);
        }

    

        if (fRequestTitle.length() > 1) {

            if (fRequestTitle.charAt(0) == '!') {
                fRequestTitle = fRequestTitle.substring(1);

                strSQL += " AND UPPER(p.RequestTitle) NOT LIKE '%"
                        + changeSQLText(fRequestTitle).trim().toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(p.RequestTitle) NOT LIKE '%"
                        + changeSQLText(fRequestTitle).trim().toUpperCase()
                        + "%' ESCAPE '!'";
            } else {

                strSQL += " AND UPPER(p.RequestTitle) LIKE '%"
                        + changeSQLText(fRequestTitle).trim().toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(p.RequestTitle) LIKE '%"
                        + changeSQLText(fRequestTitle).trim().toUpperCase()
                        + "%' ESCAPE '!'";
            }

        }
        System.out.println("Priority->" + fRequestPriority);
        if (fRequestPriority.length() >= 1) {
            System.out.println("Priority->" + fRequestPriority);
            // System.out.println("Priority->"+changePriority(fRequestPriority).trim().toUpperCase());
            if (fRequestPriority.trim().equalsIgnoreCase("P")) {
                strSQL += " AND p.RequestPriority in (3,4,5)";
                strCountSQL += " AND p.RequestPriority in (3,4,5)";

            } else {
                strSQL += " AND UPPER(p.RequestPriority) like '%"
                        + changeSQLText(fRequestPriority).trim().toUpperCase()
                        + "%' ESCAPE '!'";
                strCountSQL += " AND UPPER(p.RequestPriority) like '%"
                        + changeSQLText(fRequestPriority).trim().toUpperCase()
                        + "%' ESCAPE '!'";
            }
        }

        if (fRequestSeverityDesc.length() >= 1) {
            strSQL += " AND UPPER(se.SeverityDesc) like '%"
                    + changeSQLText(fRequestSeverityDesc).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += " AND UPPER(se.SeverityDesc) like '%"
                    + changeSQLText(fRequestSeverityDesc).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }

        if (fSource.length() >= 1) {
            strSQL += "  AND UPPER(so.SourceDesc) LIKE '%"
                    + changeSQLText(fSource).trim().toUpperCase()
                    + "%' ESCAPE '!'";
            strCountSQL += "  AND UPPER(so.SourceDesc) LIKE '%"
                    + changeSQLText(fSource).trim().toUpperCase()
                    + "%' ESCAPE '!'";
        }

        if (fDocType.length() >= 1) {
            strSQL += " AND (technical.type like '%" + fDocType + "%'"
                    + " or requirement.type like '%" + fDocType + "%'"
                    + " or test.type like '%" + fDocType + "%'"
                    + " or others.type like '%" + fDocType + "%'" + ")";
            strCountSQL += " AND (technical.type like '%" + fDocType + "%'"
                    + " or requirement.type like '%" + fDocType + "%'"
                    + " or test.type like '%" + fDocType + "%'"
                    + " or others.type like '%" + fDocType + "%'" + ")";
        }

        // Removed Comment
        if (fClientID != null && fClientID.length() >= 1) {
            strSQL += " AND p.ClientID = '"
                    + fClientID.replaceAll("'", "''").trim() + "'";
        }

        // added 3 lines
        if (requestTypeCode.length() >= 1) {
            strSQL += " AND p.RequestTypeID = '" + requestTypeCode + "'";
        }

        if (!requestUpdatedDate.equals("")) {
            strSQL += " AND trunc(p.lastUpdatedDate) "
                    + getDateRange(requestUpdatedDate);
            strCountSQL += " AND trunc(p.lastUpdatedDate) "
                    + getDateRange(requestUpdatedDate);
        }
        if (!fSoamRequestCode.equals("")) {
            strSQL += " AND p.SoamRequestCode "
                    + getSQLSubQuery(fSoamRequestCode.trim());
            strCountSQL += " AND p.SoamRequestCode "
                    + getSQLSubQuery(fSoamRequestCode.trim());
        }

        // Skip the follow up requests
        if (!this.msgType.trim().equals("r")) {
            strSQL += " AND p.parentRequestCode IS NULL ";
            strCountSQL += " AND p.parentRequestCode IS NULL ";
        }

        //OVERVIEW FILTER
        if (iceTicketListType != null) {
            IceTicketListType iceTicketListTypeByName = CommonUtils.getIceTicketListTypeByName(iceTicketListType);

            if (iceTicketListTypeByName != null) {
                strSQL += iceTicketListTypeByName.getPredicateQueryAppender();
                strCountSQL += iceTicketListTypeByName.getPredicateQueryAppender();

                //ADDING FILTER PARAMETES IN QUERY
                DashboardFilterDAO dashboardFilterDAO = new DashboardFilterDAO();

                DashboardFilterDTO dashboardFilterDTO = dashboardFilterDAO.find(iceTicketListTypeUserId);
                if (dashboardFilterDTO != null) {

                    if (dashboardFilterDTO.getRequesttypeids() != null) {
                        strSQL = DAOUtils.addQueryForFilterOnSingleColumn(AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE, strSQL, dashboardFilterDTO.getRequesttypeids().get("ice"));
                        strCountSQL = DAOUtils.addQueryForFilterOnSingleColumn(AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE, strCountSQL, dashboardFilterDTO.getRequesttypeids().get("ice"));
                    }
                    
                    strSQL = DAOUtils.addQueryForFilterOnSingleColumn("p.clientid", strSQL, dashboardFilterDTO.getClientids());
                    strCountSQL = DAOUtils.addQueryForFilterOnSingleColumn("p.clientid", strCountSQL, dashboardFilterDTO.getClientids());
                    
                    strSQL = DAOUtils.addQueryForFilterOnSingleColumn("p.sourceid", strSQL, dashboardFilterDTO.getAppids());
                    strCountSQL = DAOUtils.addQueryForFilterOnSingleColumn("p.sourceid", strCountSQL, dashboardFilterDTO.getAppids());

                    if (dashboardFilterDTO.getDateRange() != null && !dashboardFilterDTO.getDateRange().trim().isEmpty()) {
                        DashboardFilterDTO.separateStartAndEndDateByDaterange(dashboardFilterDTO);
                        strSQL += " AND Trunc(p.requestdate) BETWEEN TO_DATE('" + dashboardFilterDTO.getStartdate() + "', 'mm/dd/yyyy') AND TO_DATE ('" + dashboardFilterDTO.getEnddate() + "', 'mm/dd/yyyy') ";
                        strCountSQL += " AND Trunc(p.requestdate) BETWEEN TO_DATE('" + dashboardFilterDTO.getStartdate() + "', 'mm/dd/yyyy') AND TO_DATE ('" + dashboardFilterDTO.getEnddate() + "', 'mm/dd/yyyy') ";
                    }
                }
                dashboardFilterDAO.takeDown();
                //END

                //MYTEAM
                if (iceTicketListTypeByName.toString().startsWith("MYTEAM")) { //Only apply userid filter for my team
                   /* strSQL += " AND p.assignedto IN ("
                            + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryIN(iceTicketListTypeUserId, "ICE")
                            + " ) ";*/
                    strSQL += " AND p.phaseid IN ("
                    		  + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryIN(iceTicketListTypeUserId, "ICE")
                            + " ) ";

                   /* strCountSQL += " AND p.assignedto IN ("
                            + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryIN(iceTicketListTypeUserId, "ICE")
                            + " ) ";*/
                    strCountSQL += " AND p.phaseid IN ("
                    		  + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryIN(iceTicketListTypeUserId, "ICE")
                            + " ) ";

                }
                //END

                //MYTICKET
                if (iceTicketListTypeByName.toString().startsWith("MYTICKET")) { //Only apply userid filter for my ticket or assigned to me
                    strSQL += " AND p.assignedto='" + iceTicketListTypeUserId + "' ";
                   /* strSQL += " AND p.phaseid IN ("
                            + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryIN(iceTicketListTypeUserId, "ICE")
                            + " ) ";*/
                    strCountSQL += " AND p.assignedto='" + iceTicketListTypeUserId + "' ";
                    /*strCountSQL += " AND p.phaseid IN ("
                            + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryIN(iceTicketListTypeUserId, "ICE")
                            + " ) ";*/
                }
                //END

            }
        }

        //END
        strSQL += " AND rp.UserName IS NOT null ";
        strCountSQL = "select count(*) as RecCount from (" + strSQL + ") a";

        String tempSQL_ = "WITH T AS (" + strSQL + " ) select * from (select row_number() over ( " + orderBy + ") as rn, t.* from  T t where   1=1 " + orderBy + " )";

        strSQL = tempSQL_;

    }

    public boolean getListOfLogOfChanges() {
        boolean flag = false;
        try {
            closeRecordSet();
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            // Statement stmt=myConn.createStatement();
            String sqlString = getSQLQuery();
            // System.out.println(sqlString);
            logRS = stmt.executeQuery(sqlString);
            flag = true;
        } catch (SQLException sqlexception) {
            errorStr = "Log listing Error : " + sqlexception;
        }
        return flag;
    }

    public void currentPageQuery(int currentPage) {
        String sqlcurPage = "select * from ( select a.*, ROWNUM rnum from ("
                + getSQLQuery() + ") a where ROWNUM <=" + (currentPage * 50)
                + " ) where rnum  > " + ((currentPage - 1) * 50);
        strSQL = sqlcurPage;

    }

    // @Added by rsah,Nov 13,2008
    // A new method to get list of Request Severity is added.
    public boolean getListOfRequestSeverity() throws Exception {
        return getList(
                "SELECT DISTINCT SeverityID,SeverityDesc,SeverityOrder FROM OAM_RM_REQUEST_SEVERITY ORDER BY SeverityOrder ASC",
                "SeverityRequests");
    }

    public boolean getListOfModifiers() {
        return getList(
                "select s.UserID as ID, s.UserName from usr_Users s, tbl_UserTypes t WHERE s.OAMUserTypeCode = t.UserTypeCode AND t.UserTypeDesc IN ('E&D','E&D [Admin]','ITEG','BI','BI [Admin]') AND s.OAMStatus=1 ORDER BY s.UserName",
                "Engineers");
    }

    // @Added by rsah,Nov 14,2008
    // A new method to get list of modules is added.
    public boolean getListOfModules(String ProductID) {

        strSQL = "SELECT DISTINCT ModuleID as ID,ModuleName as Module FROM OAM_RM_MODULES WHERE 1=1";
        if (!ProductID.equals("")) {
            strSQL += " AND ProductID='" + ProductID + "'";
        }
        strSQL += " ORDER BY ModuleName";
        return getList(strSQL, "Module");
    }

    // This method specifies whether there are entries in the usr_Users
    public boolean getListOfStaffs() {
        return getList(
                "SELECT UserName, loginname,UserID FROM usr_Users where oamstatus=1 ORDER BY UserName",
                "Staffs");
    }

    public boolean getListOfClients() {
        return getList(
                "SELECT ClientID,ClientName from OAM_RM_CLIENTS ORDER BY ClientName",
                "Clients");
    }

    public boolean getListOfRequestingPersons() throws Exception {
        return getList(
                "SELECT DISTINCT UserID as RequestingPersonID,UserName as RequestingPersonDesc FROM usr_Users WHERE ORDER BY UserName",
                "Requesting Person");
    }

    public boolean getSelectedProjectRequest(String RequestCode)
            throws Exception {
        return getList(
                "SELECT p.RequestCode,p.RequestTypeID,p.RequestDate,p.RequestingPerson,r.UserName as RequestingPersonDesc,p.Requests,p.ActionTaken,p.StatusID,p.AssignedTo,p.DetectedVersion,p.TargetCompDate,p.ActualCompDate,p.RequestPriority,p.ClientID,p.ExpectedCompDate,p.PhaseDetected FROM OAM_RM_REQUESTMANAGER p, (SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS UNION SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) r WHERE r.UserID=p.RequestingPerson AND p.RequestCode='"
                + RequestCode + "'", "Update Query ");
    }

    public boolean getListOfRequestType() throws Exception {
        return getList(
                "SELECT DISTINCT RequestTypeID,RequestTypeDesc FROM OAM_RM_REQUEST_TYPES ORDER BY RequestTypeDesc",
                "Request Type");
    }

    public boolean getRequestTypesForSwitchboard() throws Exception {
        return getList(
                "SELECT DISTINCT RequestTypeID,RequestTypeDesc,IncludeInSwitchboard FROM OAM_RM_REQUEST_TYPES WHERE IncludeInSwitchboard > 0 ORDER BY IncludeInSwitchboard, RequestTypeDesc ",
                "Request Type for Switchboard");
    }

    public boolean getListOfProjectStatus() throws Exception {
        return getList(
                "SELECT DISTINCT StatusID,StatusDesc FROM OAM_RM_REQUESTSTATUS ORDER BY StatusDesc",
                "Project Status Description");
    }

    public boolean getDetailsOfRequest(String RequestCode) throws Exception {
        return getList(
                "SELECT * FROM OAM_RM_REQUESTMANAGER WHERE RequestCode='"
                + RequestCode.replaceAll("'", "''").trim() + "'",
                "Request Details");
    }

    public boolean getRequestManagerMoreDocuments(String RequestCode)
            throws Exception {
        return getList(
                "SELECT doctype,DocumentCode,Trunc(Uploadedon) as UploadedOnDate FROM OAM_RM_MOREDOCUMENTS1 WHERE RequestCode='"
                + RequestCode + "' order by Uploadedon desc",
                "RequestManager More Documents");
    }

    /**
     * @desc Returns the request comment details along with any uploaded
     * document.
     * @author Anjana Shrestha
     * @date Nov 03, 2006
     * @param RequestCode
     * @param InfoID
     * @return String variable
     * @throws Exception
     *
     */
    public boolean getRequestMoreInfoDetail(String RequestCode, String InfoID)
            throws Exception {
        String str = "";
        if (InfoID.equals("")) {
            str = "SELECT r.*,u.UserName, d.documentcode,d.UploadedDocName FROM OAM_RM_REQUESTMOREINFO r "
                    + "left join OAM_RM_MOREDOCUMENTS1 d on r.infoid=d.MsgID,usr_Users u where u.UserID=r.PostedBy AND ReplyTo "
                    + "is NULL AND r.RequestCode='"
                    + RequestCode.replaceAll("'", "''").trim()
                    + "' ORDER BY r.PostedDate DESC";
        } else if (RequestCode.equals("")) {
            str = "SELECT r.*,u.UserName, d.documentcode,d.UploadedDocName FROM OAM_RM_REQUESTMOREINFO r "
                    + "left join OAM_RM_MOREDOCUMENTS1 d on r.infoid=d.MsgID, usr_Users u where u.UserID=r.PostedBy "
                    + "AND r.ReplyTo='"
                    + InfoID.replaceAll("'", "''").trim()
                    + "' ORDER BY r.PostedDate DESC";
        } else {
            str = "SELECT r.*,u.UserName, d.documentcode,d.UploadedDocName FROM OAM_RM_REQUESTMOREINFO r "
                    + "left join OAM_RM_MOREDOCUMENTS1 d on r.infoid=d.MsgID,usr_Users u where u.UserID=r.PostedBy "
                    + "AND r.InfoID='"
                    + InfoID.replaceAll("'", "''").trim()
                    + "' ORDER BY r.PostedDate DESC";
        }
        // System.out.println("The query is:::::" + str);
        return getList(str, "Request More Information");
    }

    public boolean getListOfRequestMoreInfo(String RequestCode, String InfoID)
            throws Exception {
        if (InfoID.equals("")) {
            return getList(
                    "SELECT r.*,u.UserName FROM OAM_RM_REQUESTMOREINFO r,usr_Users u where u.UserID=r.PostedBy AND ReplyTo is NULL AND r.RequestCode='"
                    + RequestCode.replaceAll("'", "''").trim()
                    + "' ORDER BY r.PostedDate DESC",
                    "Request More Information");
        } else if (RequestCode.equals("")) {
            return getList(
                    "SELECT r.*,u.UserName FROM OAM_RM_REQUESTMOREINFO r, usr_Users u where u.UserID=r.PostedBy AND r.ReplyTo='"
                    + InfoID.replaceAll("'", "''").trim()
                    + "' ORDER BY r.PostedDate DESC",
                    "Request More Information");
        } else {
            return getList(
                    "SELECT r.*,u.UserName FROM OAM_RM_REQUESTMOREINFO r,usr_Users u where u.UserID=r.PostedBy AND r.InfoID='"
                    + InfoID.replaceAll("'", "''").trim()
                    + "' ORDER BY r.PostedDate DESC",
                    "Request More Information");
        }
    }

    public String getStatusDesc(String StatusID) {
        String sqlString = "SELECT DISTINCT StatusDesc FROM OAM_RM_REQUESTSTATUS WHERE StatusID='"
                + StatusID.replaceAll("'", "''").trim() + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("StatusDesc");
            }
        }
        return retValue;
    }

    public String getRequestingPerson(String RequestingPersonID) {
        String sqlString = "SELECT UserName FROM usr_Users WHERE UserID='"
                + RequestingPersonID.replaceAll("'", "''").trim() + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("UserName");
            }

        }
        return retValue;
    }

    // added 1 function
    public String getRequestingPersonMail(String RequestingPersonID) {
        String sqlString = "SELECT Email FROM usr_Users WHERE UserID='"
                + RequestingPersonID.replaceAll("'", "''").trim() + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("Email");
            }

        }
        return retValue;

    }

    public String getApplicationVersionDesc(String ApplicationVersionCodeID) {
        String sqlString = "SELECT DISTINCT VersionDesc FROM OAM_RM_PRODUCTVERSION WHERE VersionID='"
                + ApplicationVersionCodeID.replaceAll("'", "''").trim() + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("VersionDesc");
            }

        }
        return retValue;
    }

    public String getClientName(String ClientID) {
        String sqlString = "select ClientName FROM OAM_RM_CLIENTS WHERE ClientID='"
                + ClientID.replaceAll("'", "''").trim() + "'";

        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("ClientName");
            }
        }
        return retValue;
    }

    /**
     * @param RequestTypeId
     * @return request type code for the given requesttypeid
     */
    public String getRequestCode(String RequestTypeId) {
        String sqlString = "SELECT crcode FROM oam_cr_issuetype WHERE issuetypeid ='"
                + RequestTypeId.replaceAll("'", "''").trim() + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("crcode");
            }
        }
        return retValue;
    }

    public String getStatusIDByName(String RequestStatus) {
        String sqlString = "SELECT DISTINCT StatusID FROM OAM_RM_REQUESTSTATUS WHERE UPPER(StatusDesc) like '"
                + RequestStatus.replaceAll("'", "''").trim().toUpperCase()
                + "' ESCAPE '\\'";
        String retValue = "0";

        if (getList(sqlString, "getStatusIDByName")) {
            while (moveNext()) {
                retValue = getData("StatusID");
            }
        }
        return retValue;
    }

    public void requestPreAssigned(String RequestTypeID) {
        // get the id of "not Started"
        this.preStatus = this.getStatusIDByName("Not Started");
        try {
            String sqlString = "SELECT * FROM OAM_RM_REQUEST_TYPES WHERE RequestTypeID='"
                    + RequestTypeID.replaceAll("'", "''").trim() + "'";
            if (getList(sqlString, "")) {
                while (moveNext()) {
                    preAssignedTo = getData("UserID");
                }
            }

        } catch (Exception e) {
        }
    }

    /*
	 * public void requestPreAssigned(String RequestTypeID) - old { try{ String
	 * sqlString =
	 * "SELECT * FROM tbl_RequestPreAssignmentParameters WHERE RequestTypeID='"
	 * + RequestTypeID.replaceAll("'","''").trim() + "'";
	 * if(getList(sqlString,"")) { while(moveNext()) { preAssignedTo =
	 * getData("AssignedTo"); preStatus = getData("RequestStatus");
	 * preActionTaken = getData("ActionTaken"); preThresholdDays=
	 * getData("ThresholdDays"); } } }catch(Exception e){} }
     */
    public String getPreAssignedTo() {
        return preAssignedTo;
    }

    public String getPreActionTaken() {
        return preActionTaken;
    }

    public String getRequestPriority(String a) {
        String retValue = "N/A";
        if (a != null && a.length() > 0) {
            char c = a.charAt(0);
            switch (c) {
                case '1':
                    retValue = "N/A";
                    break;
                case '2':
                    retValue = "N/A";
                    break;
                case '3':
                    retValue = "P";
                    break;
                case '4':
                    retValue = "P";
                    break;

                case '5':
                    retValue = "P";
                    break;

                default:
                    retValue = "N/A";
                    break;
            }
        }
        return retValue;
    }

    public int getMaxID() {
        int i = 0;
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("SELECT MAX(PKSource) AS MaxID FROM OAM_RM_REQUESTMANAGER");
            while (rs.next()) {
                i = rs.getInt("MaxID");
            }
        } catch (Exception e) {
            errorStr = " ERROR GETTING MAXIMUM ID : " + e.toString();
        }
        return i;
    }

    public String uploadDocument(String RequestCode, String UploadedDocName,
            byte[] UploadedDoc, String UploadedBy, String DocType,
            String MsgID, String tempLoc) throws Exception {
        String isInserted = "0";
        String baseLocation = "";
        String path = "";
        try {
            // baselocation/RM/YYYY/MM/DD/clientid_productid/requestcode/
            if (myConn == null || myConn.isClosed()) {
                this.makeConnection();
            }
            Statement stmt = myConn.createStatement();
            String appID = "";
            String clientsql = "select clientid from oam_rm_requestmanager where requestcode='"
                    + RequestCode + "'";
            ResultSet tempRS = stmt.executeQuery(clientsql);
            while (tempRS.next()) {
                appID += tempRS.getString("clientid");
            }

            String baseLocationQuery = "select PARAMETERVALUE baseLocation,  "
                    + " to_char(sysdate,'YYYY') yr, "
                    + " to_char(sysdate,'MM') mth, "
                    + " to_char(sysdate,'DD') day "
                    + " from config_fixedparameters where  parametername like 'documentBaseFilePathRM' ";

            tempRS = stmt.executeQuery(baseLocationQuery);
            while (tempRS.next()) {
                baseLocation = tempRS.getString("baseLocation");
                path = tempRS.getString("yr")
                        + System.getProperty("file.separator")
                        + tempRS.getString("mth")
                        + System.getProperty("file.separator")
                        + tempRS.getString("day")
                        + // System.getProperty("file.separator")+appID+
                        System.getProperty("file.separator") + RequestCode;
            }

            if (System.getProperty("file.separator").equalsIgnoreCase("\\")) {
                baseLocation = "C:\\OAM";
            }
            String fileLocation = baseLocation
                    + System.getProperty("file.separator") + path
                    + System.getProperty("file.separator") + UploadedDocName;

            File file = new File(baseLocation
                    + System.getProperty("file.separator") + path);
            boolean result = file.mkdirs();
            System.out.println("Directory created " + fileLocation + " is "
                    + result);

            // FileOutputStream fos = new FileOutputStream(fileLocation);
            // fos.write(UploadedDoc);
            File tempFile = new File(tempLoc);
            if (tempFile.renameTo(new File(fileLocation))) {
                System.out
                        .println("The file was moved successfully to the new folder");
            } else {
                System.out.println("The File was not moved.");
            }

            int byteLengthint = UploadedDoc.length;
            UploadedDoc = null;
            String byteLength = "";
            if (byteLengthint != 0) {
                if (byteLengthint > (1024 * 1024 * 1024)) {
                    byteLength = byteLengthint / (1024 * 1024 * 1024) + " GB";
                } else if (byteLengthint > (1024 * 1024)) {
                    byteLength = byteLengthint / (1024 * 1024) + " MB";
                } else if (byteLengthint > (1024)) {
                    byteLength = byteLengthint / (1024) + " KB";
                } else {
                    byteLength = byteLengthint + " B";
                }

            }
            System.out.println("TOP<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");

            String sql = "INSERT  INTO OAM_RM_MOREDOCUMENTS1"
                    + "(RequestCode,UploadedDocName,UploadedBy,doctype,MsgID,DocumentCode,UploadedOn,filepath,DOCSIZEVAR)"
                    + " VALUES(?,?,?,?,?,1,SYSDATE,?,?) ";
            PreparedStatement stmnt = this.myConn.prepareStatement(sql);
            stmnt.setString(1, RequestCode);
            stmnt.setString(2, UploadedDocName.replace('#', '_'));
            stmnt.setString(3, UploadedBy);
            stmnt.setString(4, DocType);
            stmnt.setString(5, MsgID);
            stmnt.setString(6, path);
            stmnt.setString(7, byteLength);
            stmnt.execute();

            stmt.execute("Update OAM_RM_REQUESTMANAGER SET documentCount=documentCount+1 WHERE RequestCode='"
                    + RequestCode + "'");
            // fos.close();
            stmnt.close();
            stmt.close();
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println("Error in document insert" + errorStr);
        }
        return isInserted;
    }

    public String uploadDocumentRM(String RequestCode, String UploadedDocName,
            String path, int byteLengthint, String UploadedBy, String DocType,
            String MsgID) throws Exception {
        String isInserted = "0";

        String byteLength = "";
        if (byteLengthint != 0) {
            if (byteLengthint > (1024 * 1024 * 1024)) {
                byteLength = byteLengthint / (1024 * 1024 * 1024) + " GB";
            } else if (byteLengthint > (1024 * 1024)) {
                byteLength = byteLengthint / (1024 * 1024) + " MB";
            } else if (byteLengthint > (1024)) {
                byteLength = byteLengthint / (1024) + " KB";
            } else {
                byteLength = byteLengthint + " B";
            }

        }

        String sql = "INSERT  INTO OAM_RM_MOREDOCUMENTS1"
                + "(RequestCode,UploadedDocName,UploadedBy,doctype,MsgID,DocumentCode,UploadedOn,filepath,DOCSIZEVAR)"
                + " VALUES(?,?,?,?,?,1,SYSDATE,?,?) ";
        try {
            PreparedStatement stmnt = this.myConn.prepareStatement(sql);
            stmnt.setString(1, RequestCode);
            stmnt.setString(2, UploadedDocName.replace('#', '_'));
            stmnt.setString(3, UploadedBy);
            stmnt.setString(4, DocType);
            stmnt.setString(5, MsgID);
            stmnt.setString(6, path);
            stmnt.setString(7, byteLength);
            stmnt.execute();
            Statement stmt = this.myConn.createStatement();
            stmt.execute("Update OAM_RM_REQUESTMANAGER SET documentCount=documentCount+1 WHERE RequestCode='"
                    + RequestCode + "'");

            stmnt.close();
            stmt.close();
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println("Error in document insert" + errorStr);
        }
        return isInserted;
    }

    public String getBaseLocationRM(String RequestCode) throws Exception {
        String baseLocation = "";
        try {
            // baselocation/RM/YYYY/MM/DD/clientid_productid/requestcode/
            if (myConn == null || myConn.isClosed()) {
                this.makeConnection();
            }
            Statement stmt = myConn.createStatement();
            String appID = "";
            String clientsql = "select clientid,productid from oam_rm_requestmanager where requestcode='"
                    + RequestCode + "'";
            ResultSet tempRS = stmt.executeQuery(clientsql);
            while (tempRS.next()) {
                appID += tempRS.getString("clientid");
                appID += "_" + tempRS.getString("productid");
            }

            String baseLocationQuery = "select PARAMETERVALUE baseLocation,  "
                    + " to_char(sysdate,'YYYY') yr, "
                    + " to_char(sysdate,'MM') mth, "
                    + " to_char(sysdate,'DD') day "
                    + " from config_fixedparameters where  parametername like 'documentBaseFilePathRM' ";

            tempRS = stmt.executeQuery(baseLocationQuery);
            while (tempRS.next()) {
                baseLocation = tempRS.getString("baseLocation");
            }
            tempRS.close();
            stmt.close();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println("Error in document insert" + errorStr);
        }
        return baseLocation;
    }

    public String getPathRM(String RequestCode) throws Exception {
        String path = "";
        try {

            if (myConn == null || myConn.isClosed()) {
                this.makeConnection();
            }
            Statement stmt = myConn.createStatement();
            String appID = "";
            String clientsql = "select clientid,productid from oam_rm_requestmanager where requestcode='"
                    + RequestCode + "'";
            ResultSet tempRS = stmt.executeQuery(clientsql);
            while (tempRS.next()) {
                appID += tempRS.getString("clientid");
                appID += "_" + tempRS.getString("productid");
            }

            String baseLocationQuery = "select PARAMETERVALUE baseLocation,  "
                    + " to_char(sysdate,'YYYY') yr, "
                    + " to_char(sysdate,'MM') mth, "
                    + " to_char(sysdate,'DD') day "
                    + " from config_fixedparameters where  parametername like 'documentBaseFilePathRM' ";

            tempRS = stmt.executeQuery(baseLocationQuery);
            while (tempRS.next()) {
                path = tempRS.getString("yr")
                        + System.getProperty("file.separator")
                        + tempRS.getString("mth")
                        + System.getProperty("file.separator")
                        + tempRS.getString("day")
                        + System.getProperty("file.separator") + appID
                        + System.getProperty("file.separator") + RequestCode;
            }
            tempRS.close();
            stmt.close();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println("Error in document insert" + errorStr);
        }
        return path;
    }

    /**
     * Function name: changeSQLText
     *
     * @desc Returns the meta characters with escape sequences.
     * @author Luna Gurung
     * @date Feb 05, 2007
     * @param s
     * @return String variable
     *
     */
    private String changeSQLText(String s) {
        if (s.trim().equals("")) {
            return ("NULL");
        } else {

            s = s.replaceAll("'", "''").trim();
            // s=s.replaceAll("\\[","[[]").trim();
            s = s.replaceAll("\\_", "!_").trim();
            s = s.replaceAll("\\%", "!%").trim();
            return s;
        }
    }

    /**
     * Function name: changePriority
     *
     * @desc Returns the requestpriority from database
     * @author Luna Gurung
     * @date Feb 05, 2007
     * @param s
     * @return String variable
     *
     */
    private String changePriority(String s) {
        String priority = null;
        if (s.trim().equals("")) {
            return ("NULL");
        } else {
            try {
                String stringqry = "SELECT distinct requestpriority FROM OAM_RM_REQUESTMANAGER WHERE case "
                        + "when requestpriority=1 then 'low'"
                        + "when requestpriority=2 then 'medium'"
                        + "when requestpriority=3 then 'high'"
                        + "when requestpriority=4 then 'urgent'"
                        + "when requestpriority=5 then 'P'"
                        + "else 'zz' "
                        + "end like  lower('%"
                        + s.trim().toUpperCase()
                        + "%' ) ESCAPE '!' ";
                System.out.println("P:" + stringqry);
                Statement stmt = myConn.createStatement();

                ResultSet tempRS = stmt.executeQuery(stringqry);
                if (tempRS.next()) {
                    priority = tempRS.getString("requestpriority");
                }

            } catch (SQLException sqlexception) {
                errorStr = "Project Request Entry error  : " + sqlexception;
            }
        }
        if (priority == null) {
            priority = "-1";
        }
        return priority;
    }

    private String getSQLEncodedData(String s) {
        if (s.trim().equals("")) {
            return ("NULL");
        } else {
            return ("'" + s.trim().replaceAll("'", "''") + "'");

        }
    }

    public void setCompleted(String requestCode) {
        try {
            Statement stmnt = this.myConn.createStatement();
            stmnt.execute("UPDATE OAM_RM_REQUESTMANAGER SET isCompleted='r' WHERE RequestCode='"
                    + requestCode + "'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setCompletedDate(String requestCode, String Phaseid) {
        ResultSet rs = null;
        int count = 0;
        try {
            if (myConn == null) {
                connectDB();
            }

            stmt = this.myConn.createStatement();
            String sq = "SELECT Count(*)  from oam_cr_phases WHERE phaseid=" + Phaseid + " AND statusid=4";
            String updatesq = "UPDATE OAM_RM_REQUESTMANAGER SET PHASECOMPLETEDDATE=null WHERE RequestCode='"
                    + requestCode + "'";

            System.out.println("sql:" + sq);
            rs = stmt.executeQuery(sq);
            if (rs.next()) {
                count = rs.getInt(1);

            }

            if (count > 0) {
                updatesq = "UPDATE OAM_RM_REQUESTMANAGER SET PHASECOMPLETEDDATE=sysdate WHERE RequestCode='"
                        + requestCode + "'";

            }
            stmt = this.myConn.createStatement();
            stmt.execute(updatesq);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String insertProjectRequest(String RequestingPerson,
            String Requests, String TargetCompDate, String ActualCompDate,
            String parentRequestCode, String StatusID, String isCompleted)
            throws Exception {

        String isInserted = "0";

        // requestedBy,newAction,newTargetDate,newActualDate,parentRequestCode,statusCode,complete
        try {
            // Statement stmt=myConn.createStatement();
            String sqlString = "{call SP_OAM_RM_REQUESTMANAGER (?,?,?,?,?,?,?,?)}";
            // System.out.println("Here goes the stored Procedure");

            System.out.println(RequestingPerson + "," + Requests + ","
                    + TargetCompDate + "," + ActualCompDate + ","
                    + parentRequestCode + "," + StatusID + "," + isCompleted);
            if (myConn == null) {
                this.connectDB();
            }
            CallableStatement stmt = this.myConn.prepareCall(sqlString);

            stmt.setString(1, RequestingPerson);
            stmt.setString(2, Requests);
            stmt.setString(3, TargetCompDate);
            stmt.setString(4, ActualCompDate);
            stmt.setString(5, parentRequestCode);
            stmt.setString(6, StatusID);
            stmt.setString(7, isCompleted);
            stmt.registerOutParameter(8, Types.VARCHAR);

            stmt.execute();
            // ResultSet rs = (ResultSet)stmt.getObject(1);

            // if(rs.next()){
            isInserted = stmt.getString(8);
            // System.out.println("This is the string i got: "+isInserted);
            // }
            strSQL = sqlString;
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return isInserted;
    }

    // Changed by: Raju Thapa Shrestha, Jan 25,2008
    // Changes : New parameters
    // ProductModule,ProductArea,RequestPhaseInject,EstimatedHours,LastUpdatedDate,RequestSource
    // are added.
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    // Author Changed:Richan Shrestha, Oct. 26 2007
    // Changes: A new parameter for PhaseDetected is added
    public String updateProjectRequestNew(String RequestID, String ClientID,
            String RequestDate, String RequestingPerson, String Requests,
            String RequestTypeID, String RelVersion, String ExpectedCompDate,
            String RequestPriority, String ProductID, String ProjectID,
            String ProductModule, String ProductArea, String AssignedTo,
            String RequestPhaseInject, String RequestPhase,
            String EstimatedHours, String LastUpdatedDate,
            String RequestSource, String RequestSeverity, String Impact,
            String DataProviderID, String VersionFixed) throws Exception {
        // String AssignedTo = "";

        String preExpectedCompDate = "";
        boolean e; // To check if an error has occured. If not, it writes to
        // Archive as well.
        e = false;
        try {

            // Changed by:Richan Shrestha, Sept. 27,2007
            requestPreAssigned(RequestTypeID);
            // System.out.println("AssignedTo-----> "+AssignedTo);
            // System.out.println("Preassigned-----> "+preAssignedTo);
            if (AssignedTo.equals("")) {
                AssignedTo = preAssignedTo;

            } else {
                preAssignedTo = AssignedTo;
                // this.preStatus=this.getStatusIDByName("Assigned");
            }
            // System.out.println("Preassigned-----> "+preAssignedTo);
            if (!preAssignedTo.equals("") && !preAssignedTo.trim().equals("1")) {
                this.preStatus = this.getStatusIDByName("Assigned");
            }

            preExpectedCompDate = "NULL";

            if (ExpectedCompDate != null) {
                preExpectedCompDate = getSQLEncodedData(ExpectedCompDate);
            }
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmnt = myConn.createStatement();

            ClientID = ClientID.trim().equals("") ? "0" : ClientID;
            RequestTypeID = RequestTypeID.trim().equals("") ? "0"
                    : RequestTypeID;
            RelVersion = RelVersion.trim().equals("") ? "0" : RelVersion;
            ProductID = ProductID.trim().equals("") ? "0" : ProductID;
            ProjectID = ProjectID.trim().equals("") ? "0" : ProjectID;
            ProductModule = ProductModule.trim().equals("") ? "0"
                    : ProductModule;
            ProductArea = ProductArea.trim().equals("") ? "0" : ProductArea;
            RequestPhaseInject = RequestPhaseInject.trim().equals("") ? "0"
                    : RequestPhaseInject;
            RequestPhase = RequestPhase.trim().equals("") ? "0" : RequestPhase;
            EstimatedHours = EstimatedHours.trim().equals("") ? "0"
                    : EstimatedHours;
            RequestSource = RequestSource.trim().equals("") ? "0"
                    : RequestSource;
            RequestSeverity = RequestSeverity.trim().equals("") ? "0"
                    : RequestSeverity;
            RequestPriority = RequestPriority.trim().equals("") ? "0"
                    : RequestPriority;
            preStatus = preStatus.trim().equals("") ? "0" : preStatus;
            DataProviderID = DataProviderID.trim().equals("") ? "0"
                    : DataProviderID;
            VersionFixed = VersionFixed.trim().equals("") ? "0" : VersionFixed;

            /*
			 * Date dt = new Date(); long dtl = dt.getTime(); java.sql.Date x =
			 * new java.sql.Date (dtl); SimpleDateFormat sdf = new
			 * SimpleDateFormat ("MM/dd/yyyy HH:mm:ss"); sdf.format(x);
			 * System.out.println("DATE IS............" + x);
             */
            String sqlString = "UPDATE OAM_RM_REQUESTMANAGER SET RequestingPerson = '"
                    + RequestingPerson
                    + "',"
                    + "ClientID="
                    + ClientID
                    + ","
                    + "RequestDate = sysdate ,"
                    + "Requests="
                    + getSQLEncodedData(Requests)
                    + ","
                    + "RequestTypeID="
                    + RequestTypeID
                    + ","
                    + "DetectedVersion="
                    + RelVersion
                    + ","
                    + "ExpectedCompDate= to_date("
                    + preExpectedCompDate
                    + ",'mm/dd/yyyy'),"
                    + "TargetCompDate= to_date("
                    + preExpectedCompDate
                    + ",'mm/dd/yyyy'),"
                    + "AssignedTo="
                    + getSQLEncodedData(AssignedTo)
                    + ","
                    + "ProductID="
                    + ProductID
                    + ","
                    + "ProjectID="
                    + ProjectID
                    + ","
                    + "ModuleID="
                    + ProductModule
                    + ","
                    + "ProductArea="
                    + ProductArea
                    + ","
                    + "PhaseInject="
                    + (RequestPhaseInject)
                    + ","
                    + "PhaseDetected="
                    + (RequestPhase)
                    + ","
                    + "EstimatedHours="
                    + (EstimatedHours)
                    + ","
                    + "LastUpdatedDate= sysdate ,"
                    + "SourceID="
                    + (RequestSource)
                    + ","
                    + "SeverityID="
                    + (RequestSeverity)
                    + ","
                    + "Impact="
                    + getSQLEncodedData(Impact)
                    + ","
                    + "DataProviderID='"
                    + DataProviderID
                    + "',"
                    + "FixedInVersion='"
                    + VersionFixed
                    + "',"
                    + "RequestPriority=" + (RequestPriority);
            if (!preStatus.equals("") && !preAssignedTo.equals("")) {
                sqlString += ",StatusID	= " + (preStatus) + "";
            }
            sqlString += " WHERE RequestCode ='" + RequestID + "'";
            strSQL = sqlString;
            System.out.println(strSQL);
            stmnt.execute(strSQL);

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            e = true;
            System.out.println("**********************"
                    + sqlexception.getMessage() + "...request length:"
                    + Requests.length());
        }

        if (!e) {
            archiveRequest(RequestID, RequestingPerson); // Also writing the
            // same values in
            // Archive
        }

        return AssignedTo;
    }

    public String updateProjectAllRequest(String RequestID, String RequestDate,
            String RequestingPerson, String RequestTypeID,
            String RequestPriority, String ClientID, String projectId, String SourceID, String EmployeeGroup,
            String RequestTitle, String DataProviderID, String dataType,
            String RequestPhase, String AssignedTo, String EstimatedHours,
            String targetCompDate, String actualCompDate, String ActualHours,
            String PhaseId, String issueTypeForCombinePhase, String PayorID, String statusID, String remarks, String targetCompDate2,
            String appReleasedToClientDate, String applicationType,
            String lastEditiedBy, String PrioritizedDate, String PrioritizedBy, String actualCompDate2,
            String team, String processmonth, String releaseTag, String cleancompletedatareciptdate,
            String legalcompletedate, String externalid, RequestParamDTO requestParamDTO)
            throws Exception {

        String sqlString = "UPDATE OAM_RM_REQUESTMANAGER SET "
                + " RequestingPerson =?," + "ClientID=?," + "ProjectID=?," + "RequestTypeID=?,"
                + " sourceid=?," + "requesttitle=?," + "dataproviderid=?,"
                + " dataType=?," + "AssignedTo=?," + "EstimatedHours=?,"
                + " phaseid=?," + "phaseinject=?, " + " statusid=?," + "remarks=?,"
                + " targetcompdate=?," + "targetcompdate2=?," + " actualcompdate=?,"
                + " RequestPriority=?," + "PayorID=?,"
                + " LastUpdatedDate= sysdate ," + " appreleasedate= ?," + " employerGroup= ?, applicationtype = ?, lasteditedby = ?,prioritizeddate=?, "
                + " prioritizedby =?, team =?, processmonth =?,actualcompdate2=?,releasetag=?,cleancompletedatareciptdate=?,legalcompletedate=? ,"
                + " externalid=?, "
                + " parenticeid=?, parentrequesttype=?, integrationtype=?, applicationkickoffdate=?, "
                + " link_type=?, link_ice_id=? "
                + " WHERE RequestCode =?";

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {

            if (requestParamDTO == null) {
                requestParamDTO = new RequestParamDTO();
            }

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement preStmt = myConn.prepareStatement(sqlString);

            preStmt.setString(1, RequestingPerson);
            preStmt.setString(2, ClientID);
            preStmt.setString(3, projectId);
            preStmt.setString(4, RequestTypeID);
            preStmt.setString(5, SourceID);
            preStmt.setString(6, RequestTitle);
            preStmt.setString(7, DataProviderID);
            preStmt.setString(8, dataType);
            preStmt.setString(9, AssignedTo);
            preStmt.setString(10, EstimatedHours);
            preStmt.setString(11, PhaseId);
            preStmt.setString(12, issueTypeForCombinePhase);
            preStmt.setString(13, statusID);
            preStmt.setString(14, remarks);
            if (targetCompDate.equalsIgnoreCase("")) {
                preStmt.setDate(15, null);
            } else {
                preStmt.setDate(
                        15,
                        new java.sql.Date((sdf.parse(targetCompDate).getTime())));
            }
            if (targetCompDate2.equalsIgnoreCase("")) {
                preStmt.setDate(16, null);
            } else {
                preStmt.setDate(
                        16,
                        new java.sql.Date((sdf.parse(targetCompDate2).getTime())));
            }

            if (actualCompDate.equalsIgnoreCase("")) {
                preStmt.setDate(17, null);
            } else {
                preStmt.setDate(
                        17,
                        new java.sql.Date((sdf.parse(actualCompDate).getTime())));
            }

            preStmt.setString(18, RequestPriority);
            preStmt.setString(19, PayorID);
            System.out.println("Update appReleasedToClientDate >>>>> " + appReleasedToClientDate);
            if (appReleasedToClientDate.equalsIgnoreCase("")) {
                preStmt.setDate(20, null);
            } else {
                preStmt.setDate(
                        20,
                        new java.sql.Date((sdf.parse(appReleasedToClientDate).getTime())));
            }
            preStmt.setString(21, EmployeeGroup);
            preStmt.setString(22, applicationType);
            preStmt.setString(23, lastEditiedBy);
            if (PrioritizedDate.equalsIgnoreCase("")) {
                preStmt.setDate(24, null);
            } else {
                preStmt.setDate(
                        24,
                        new java.sql.Date((sdf.parse(PrioritizedDate).getTime())));
            }
            preStmt.setString(25, PrioritizedBy);
            preStmt.setString(26, team);
            preStmt.setString(27, processmonth);
            if (actualCompDate2.equalsIgnoreCase("")) {
                preStmt.setDate(28, null);
            } else {
                preStmt.setDate(
                        28,
                        new java.sql.Date((sdf.parse(actualCompDate2).getTime())));
            }
            preStmt.setString(29, releaseTag);
            if (cleancompletedatareciptdate.equalsIgnoreCase("")) {
                preStmt.setDate(30, null);
            } else {
                preStmt.setDate(
                        30,
                        new java.sql.Date((sdf.parse(cleancompletedatareciptdate).getTime())));
            }
            if (legalcompletedate.equalsIgnoreCase("")) {
                preStmt.setDate(31, null);
            } else {
                preStmt.setDate(
                        31,
                        new java.sql.Date((sdf.parse(legalcompletedate).getTime())));
            }
            preStmt.setString(32, externalid);

            preStmt.setString(33, requestParamDTO.getParenticeid());
            preStmt.setString(34, requestParamDTO.getParentrequesttype());
            preStmt.setString(35, requestParamDTO.getIntegrationtype());
            preStmt.setDate(36, DTOUtils.convertSQLDate(requestParamDTO.getApplicationkickoffdate()));
            preStmt.setString(37, requestParamDTO.getLinkType());
            preStmt.setString(38, requestParamDTO.getLinkIceId());
            preStmt.setString(39, RequestID);
            preStmt.executeUpdate();
            //preStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return AssignedTo;
    }

    public String updateProjectRequestEditCR(String RequestID,
            String RequestDate, String RequestingPerson, String RequestTypeID,
            String RequestPriority, String ClientID, String SourceID,
            String RequestTitle, String DataProviderID, String datalayout,
            String dataType, String AMName, String reason, String billClient,
            String RequestPhase, String jiraid, String AssignedTo,
            String EstimatedHours, String impacts, String RequestSeverity,
            String problemDef, String changeSpecify, String ClientRequestDate,
            String ClientTargetDate, String ActualTargetDate,
            String targetCompDate, String actualCompDate, String ActualHours,
            String PhaseId, String clientpaid) throws Exception {
        // String AssignedTo = "";

        String preExpectedCompDate = "";
        boolean e; // To check if an error has occured. If not, it writes to
        // Archive as well.
        e = false;
        try {

            // Changed by:Richan Shrestha, Sept. 27,2007
            requestPreAssigned(RequestTypeID);
            // System.out.println("AssignedTo-----> "+AssignedTo);
            // System.out.println("Preassigned-----> "+preAssignedTo);
            if (AssignedTo.equals("")) {
                AssignedTo = preAssignedTo;

            } else {
                preAssignedTo = AssignedTo;
                // this.preStatus=this.getStatusIDByName("Assigned");
            }
            // System.out.println("Preassigned-----> "+preAssignedTo);
            if (!preAssignedTo.equals("") && !preAssignedTo.trim().equals("1")) {
                this.preStatus = this.getStatusIDByName("Assigned");
            }

            preExpectedCompDate = "NULL";

            if (myConn == null) {
                this.connectDB();
            }
            Statement stmnt = myConn.createStatement();

            ClientID = ClientID.trim().equals("") ? "0" : ClientID;
            RequestTypeID = RequestTypeID.trim().equals("") ? "0"
                    : RequestTypeID;

            RequestPhase = RequestPhase.trim().equals("") ? "0" : RequestPhase;
            EstimatedHours = EstimatedHours.trim().equals("") ? "0"
                    : EstimatedHours;
            /*
			 * RequestSource = RequestSource.trim().equals("") ? "0" :
			 * RequestSource;
             */
 /*
			 * RequestSeverity = RequestSeverity.trim().equals("") ? "0" :
			 * RequestSeverity;
             */
            RequestPriority = RequestPriority.trim().equals("") ? "0"
                    : RequestPriority;
            preStatus = preStatus.trim().equals("") ? "0" : preStatus;
            DataProviderID = DataProviderID.trim().equals("") ? "0"
                    : DataProviderID;
            // VersionFixed = VersionFixed.trim().equals("") ? "0" :
            // VersionFixed;

            /*
			 * Date dt = new Date(); long dtl = dt.getTime(); java.sql.Date x =
			 * new java.sql.Date (dtl); SimpleDateFormat sdf = new
			 * SimpleDateFormat ("MM/dd/yyyy HH:mm:ss"); sdf.format(x);
			 * System.out.println("DATE IS............" + x);
             */
            String sqlString = "UPDATE OAM_RM_REQUESTMANAGER SET RequestingPerson = '"
                    + RequestingPerson
                    + "',"
                    + "ClientID="
                    + ClientID
                    + ","
                    // + "RequestDate = sysdate ,"
                    + "impact="
                    + getSQLEncodedData(impacts)
                    + ","
                    + "RequestTypeID='"
                    + RequestTypeID
                    + "',"
                    + "sourceid='"
                    + SourceID
                    + "',"
                    + "requesttitle='"
                    + RequestTitle
                    + "',"
                    + "dataproviderid='"
                    + DataProviderID
                    + "',"
                    + "datalayout='"
                    + datalayout
                    + "',"
                    + "dataType='"
                    + dataType
                    + "',"
                    + "AMName='"
                    + AMName
                    + "',"
                    + "reason='"
                    + reason
                    + "',"
                    + "billClient='"
                    + billClient
                    + "',"
                    + "jiraid='"
                    + jiraid
                    + "',"
                    + "AssignedTo='"
                    + AssignedTo
                    + "',"
                    + "EstimatedHours='"
                    + EstimatedHours
                    + "',"
                    + "actualhours='"
                    + ActualHours
                    + "',"
                    + "problemDef="
                    + getSQLEncodedData(problemDef)
                    + ","
                    + "changeSpecify="
                    + getSQLEncodedData(changeSpecify)
                    + ","
                    + "ClientRequestDate= to_date('"
                    + ClientRequestDate
                    + "','mm/dd/yyyy'),"
                    + "ClientTargetDate= to_date('"
                    + ClientTargetDate
                    + "','mm/dd/yyyy'),"
                    + "ActualTargetDate= to_date('"
                    + ActualTargetDate
                    + "','mm/dd/yyyy'),"
                    + "phaseid='"
                    + PhaseId
                    + "',"
                    + "clientpaid='"
                    + clientpaid
                    + "',"
                    + "LastUpdatedDate= sysdate ,"
                    + "RequestPriority=" + (RequestPriority);
            if (!preStatus.equals("") && !preAssignedTo.equals("")) {
                sqlString += ",StatusID	= " + (preStatus) + "";
            }
            sqlString += " WHERE RequestCode ='" + RequestID + "'";
            strSQL = sqlString;
            System.out.println(strSQL);
            stmnt.execute(strSQL);

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            e = true;

        }

        if (!e) {
            archiveRequest(RequestID, RequestingPerson); // Also writing the
            // same values in
            // Archive
        }

        return AssignedTo;
    }

    public String updateProjectRequestNewCR(String RequestID,
            String RequestDate, String RequestingPerson, String RequestTypeID,
            String RequestPriority, String ClientID, String SourceID,
            String RequestTitle, String DataProviderID, String datalayout,
            String dataType, String AMName, String reason, String billClient,
            String RequestPhase, String jiraid, String AssignedTo,
            String EstimatedHours, String impacts, String RequestSeverity,
            String problemDef, String changeSpecify, String ClientRequestDate,
            String ClientTargetDate, String ActualTargetDate,
            String targetCompDate, String actualCompDate, String phaseId)
            throws Exception {
        // String AssignedTo = "";

        String preExpectedCompDate = "";
        boolean e; // To check if an error has occured. If not, it writes
        // totargetCompDate
        // Archive as well.
        e = false;
        try {

            // Changed by:Richan Shrestha, Sept. 27,2007
            requestPreAssigned(RequestTypeID);
            // System.out.println("AssignedTo-----> "+AssignedTo);
            // System.out.println("Preassigned-----> "+preAssignedTo);
            if (AssignedTo.equals("")) {
                AssignedTo = preAssignedTo;

            } else {
                preAssignedTo = AssignedTo;
                // this.preStatus=this.getStatusIDByName("Assigned");
            }
            // System.out.println("Preassigned-----> "+preAssignedTo);
            if (!preAssignedTo.equals("") && !preAssignedTo.trim().equals("1")) {
                this.preStatus = this.getStatusIDByName("Assigned");
            }

            preExpectedCompDate = "NULL";

            if (myConn == null) {
                this.connectDB();
            }
            Statement stmnt = myConn.createStatement();

            ClientID = ClientID.trim().equals("") ? "0" : ClientID;
            RequestTypeID = RequestTypeID.trim().equals("") ? "0"
                    : RequestTypeID;

            RequestPhase = RequestPhase.trim().equals("") ? "0" : RequestPhase;
            EstimatedHours = EstimatedHours.trim().equals("") ? "0"
                    : EstimatedHours;
            /*
			 * RequestSource = RequestSource.trim().equals("") ? "0" :
			 * RequestSource;
             */
 /*
			 * RequestSeverity = RequestSeverity.trim().equals("") ? "0" :
			 * RequestSeverity;
             */
            RequestPriority = RequestPriority.trim().equals("") ? "0"
                    : RequestPriority;
            preStatus = preStatus.trim().equals("") ? "0" : preStatus;
            DataProviderID = DataProviderID.trim().equals("") ? "0"
                    : DataProviderID;
            // VersionFixed = VersionFixed.trim().equals("") ? "0" :
            // VersionFixed;

            /*
			 * Date dt = new Date(); long dtl = dt.getTime(); java.sql.Date x =
			 * new java.sql.Date (dtl); SimpleDateFormat sdf = new
			 * SimpleDateFormat ("MM/dd/yyyy HH:mm:ss"); sdf.format(x);
			 * System.out.println("DATE IS............" + x);
             */
            String sqlString = "UPDATE OAM_RM_REQUESTMANAGER SET RequestingPerson = '"
                    + RequestingPerson
                    + "',"
                    + "ClientID="
                    + ClientID
                    + ","
                    + "RequestDate = sysdate ,"
                    + "impact="
                    + getSQLEncodedData(impacts)
                    + ","
                    + "RequestTypeID='"
                    + RequestTypeID
                    + "',"
                    + "sourceid='"
                    + SourceID
                    + "',"
                    + "requesttitle='"
                    + RequestTitle
                    + "',"
                    + "dataproviderid='"
                    + DataProviderID
                    + "',"
                    + "datalayout='"
                    + datalayout
                    + "',"
                    + "dataType='"
                    + dataType
                    + "',"
                    + "AMName='"
                    + AMName
                    + "',"
                    + "reason='"
                    + reason
                    + "',"
                    + "billClient='"
                    + billClient
                    + "',"
                    + "jiraid='"
                    + jiraid
                    + "',"
                    + "AssignedTo='"
                    + AssignedTo
                    + "',"
                    + "EstimatedHours='"
                    + EstimatedHours
                    + "',"
                    + "problemDef="
                    + getSQLEncodedData(problemDef)
                    + ","
                    + "changeSpecify="
                    + getSQLEncodedData(changeSpecify)
                    + ","
                    + "ClientRequestDate= to_date('"
                    + ClientRequestDate
                    + "','mm/dd/yyyy'),"
                    + "ClientTargetDate= to_date('"
                    + ClientTargetDate
                    + "','mm/dd/yyyy'),"
                    + "ActualTargetDate= to_date('"
                    + ActualTargetDate
                    + "','mm/dd/yyyy'),"
                    + "targetcompdate= to_date('"
                    + targetCompDate
                    + "','mm/dd/yyyy'),"
                    + "actualcompdate= to_date('"
                    + actualCompDate
                    + "','mm/dd/yyyy'),"
                    + "phaseid='"
                    + phaseId
                    + "',"
                    + "LastUpdatedDate= sysdate ,"
                    + "RequestPriority=" + (RequestPriority);
            if (!preStatus.equals("") && !preAssignedTo.equals("")) {
                sqlString += ",StatusID	= " + (preStatus) + "";
            }
            sqlString += " WHERE RequestCode ='" + RequestID + "'";
            strSQL = sqlString;
            System.out.println(strSQL);
            stmnt.execute(strSQL);

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            e = true;

        }

        if (!e) {
            archiveRequest(RequestID, RequestingPerson); // Also writing the
            // same values in
            // Archive
        }

        return AssignedTo;
    }

    public String insertProjectCRManager(String RequestID, String billClient,
            String AMName, String reason, String jiraid, String descOfProblem,
            String changeSpecify, String impacts, String datalayout,
            String ClientRequestDate, String ClientTargetDate,
            String ActualTargetDate, String clientpaid, String processmonth,
            String implementedbyimplservices, String implementationiceid) throws Exception {

        String sqlString = " INSERT INTO  oam_cr_crmanager (   requestcode, "
                + "  billable,	   accountmanager,       reasonch, 	    "
                + "  jiraid,       problemdef,        changespecify,         impact, "
                + "  datalayout,           clientrequestdate,         "
                + "  clienttargetdate,    actualtargetdate,           clientpaid,processmonth,implementedbyimplservices, implementationiceid ) "
                + "   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, RequestID);
            pStmt.setString(2, billClient);
            pStmt.setString(3, AMName);
            pStmt.setString(4, reason);
            pStmt.setString(5, jiraid);
            pStmt.setString(6, descOfProblem);
            pStmt.setString(7, changeSpecify);
            pStmt.setString(8, impacts);
            pStmt.setString(9, datalayout);

            if (ClientRequestDate.equalsIgnoreCase("")) {
                pStmt.setDate(10, null);
            } else {
                pStmt.setDate(
                        10,
                        new java.sql.Date((sdf.parse(ClientRequestDate)
                                .getTime())));
            }

            if (ClientTargetDate.equalsIgnoreCase("")) {
                pStmt.setDate(11, null);
            } else {
                pStmt.setDate(
                        11,
                        new java.sql.Date((sdf.parse(ClientTargetDate)
                                .getTime())));
            }

            if (ActualTargetDate.equalsIgnoreCase("")) {
                pStmt.setDate(12, null);
            } else {
                pStmt.setDate(
                        12,
                        new java.sql.Date((sdf.parse(ActualTargetDate)
                                .getTime())));
            }

            if (clientpaid.equalsIgnoreCase("")) {
                pStmt.setFloat(13, (Float) 0.0F);
            } else {
                pStmt.setFloat(13, Float.parseFloat(clientpaid));
            }
            pStmt.setString(14, processmonth);
            pStmt.setString(15, implementedbyimplservices);
            pStmt.setString(16, implementationiceid);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    public String updateProjectCRManager(String RequestID, String billClient,
            String AMName, String reason, String jiraid, String descOfProblem,
            String changeSpecify, String impacts, String datalayout,
            String ClientRequestDate, String ClientTargetDate,
            String ActualTargetDate, String clientpaid, String processmonth,
            String implementedbyimplservices, String implementationiceid) throws Exception {
        String sqlString = " update oam_cr_crmanager set  billable=?,"
                + " accountmanager=?," + " reasonch=?," + "  jiraid=?,"
                + " problemdef=?," + " changespecify=?," + " impact=?,"
                + "  datalayout=?," + " clientrequestdate=?,"
                + "  clienttargetdate=?," + "  actualtargetdate=?,"
                + " clientpaid=?, processmonth=?, implementedbyimplservices = ?, implementationiceid = ?" + " WHERE RequestCode =?";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, billClient);
            pStmt.setString(2, AMName);
            pStmt.setString(3, reason);
            pStmt.setString(4, jiraid);
            pStmt.setString(5, descOfProblem);
            pStmt.setString(6, changeSpecify);
            pStmt.setString(7, impacts);
            pStmt.setString(8, datalayout);

            if (ClientRequestDate.equalsIgnoreCase("")) {
                pStmt.setDate(9, null);
            } else {
                pStmt.setDate(
                        9,
                        new java.sql.Date((sdf.parse(ClientRequestDate)
                                .getTime())));
            }

            if (ClientTargetDate.equalsIgnoreCase("")) {
                pStmt.setDate(10, null);
            } else {
                pStmt.setDate(
                        10,
                        new java.sql.Date((sdf.parse(ClientTargetDate)
                                .getTime())));
            }

            if (ActualTargetDate.equalsIgnoreCase("")) {
                pStmt.setDate(11, null);
            } else {
                pStmt.setDate(
                        11,
                        new java.sql.Date((sdf.parse(ActualTargetDate)
                                .getTime())));
            }

            if (clientpaid.equalsIgnoreCase("")) {
                pStmt.setFloat(12, (Float) 0.0F);
            } else {
                pStmt.setFloat(12, Float.parseFloat(clientpaid));
            }
            pStmt.setString(13, processmonth);
            pStmt.setString(14, implementedbyimplservices);
            pStmt.setString(15, implementationiceid);
            pStmt.setString(16, RequestID);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    /**
     * @Description : Updates details related to Production Integration Code
     * @param RequestID
     * @param AMName
     * @param ba
     * @param wpm
     * @param npm
     * @param cl
     * @param requestDesc
     * @param implICETicketNum
     * @param processingMonth
     * @param handOverDate
     * @param appReleasedToClientDate
     * @param accStrDetailsIncluded
     * @param targetDate
     * @param addComments
     * @param approvedBy
     */
    public void updateProdIntDetails(ProductionIntegrationCode prodIntCode) {

        String sqlString = ""
                + "UPDATE oam_cr_pitmanager SET accountmanager=?, "
                + "             businessanalyst=?, "
                + "             wpm=?, "
                + "             npm=?, "
                + "             clusterlead=?, "
                + "             requestdescription=?, "
                + "             impliceticketnum=?, "
                + "             processingmonth=?, "
                + "             handoverdate=?, "
                //+ "             appreleasedtoclientdate=?, "
                + "             accstrdetailsincluded=?, "
                + "             addcomments=?, "
                + "             approvedby=?, "
                //+ "             remarks=?, "
                + "             targetcompdate=?, "
                + "             actualcompdate=?, "
                + "             approveddate=? "
                + "             WHERE requestcode = ?";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, prodIntCode.getAccountManager());
            pStmt.setString(2, prodIntCode.getBussinessManager());
            pStmt.setString(3, prodIntCode.getWathamPM());
            pStmt.setString(4, prodIntCode.getNepalPM());
            pStmt.setString(5, prodIntCode.getClusterLead());
            pStmt.setString(6, prodIntCode.getRequestDesc());
            pStmt.setString(7, prodIntCode.getImpICETicketNum());
            pStmt.setString(8, prodIntCode.getProcessingMonth());
            //hand over date
            if (prodIntCode.getHandOverDate().equalsIgnoreCase("")) {
                pStmt.setDate(9, null);
            } else {
                pStmt.setDate(9,
                        new java.sql.Date((sdf.parse(prodIntCode.getHandOverDate()).getTime())));
            }
            // appReleasedToClientDate
            /*if (prodIntCode.getAppReleasesToClientDate().equalsIgnoreCase(""))
				pStmt.setDate(10, null);
			else
				pStmt.setDate(10,
						new java.sql.Date((sdf.parse(prodIntCode.getAppReleasesToClientDate()).getTime())));*/
            pStmt.setString(10, prodIntCode.getAccStrDetailsIncluded());
            pStmt.setString(11, prodIntCode.getAddtionalComments());
            pStmt.setString(12, prodIntCode.getApprovedBy());
            //pStmt.setString(13, prodIntCode.getRemarks());
            // target comp date
            if (prodIntCode.getTargetCompDate().equalsIgnoreCase("")) {
                pStmt.setDate(13, null);
            } else {
                pStmt.setDate(13,
                        new java.sql.Date((sdf.parse(prodIntCode.getTargetCompDate()).getTime())));
            }
            //actual comp date
            if (prodIntCode.getActualCompDate().equalsIgnoreCase("")) {
                pStmt.setDate(14, null);
            } else {
                pStmt.setDate(14,
                        new java.sql.Date((sdf.parse(prodIntCode.getActualCompDate()).getTime())));
            }
            // Approval Date
            if (prodIntCode.getApprovedDate().equalsIgnoreCase("")) {
                pStmt.setDate(15, null);
            } else {
                pStmt.setDate(15,
                        new java.sql.Date((sdf.parse(prodIntCode.getApprovedDate()).getTime())));
            }
            pStmt.setString(16, prodIntCode.getRequestCode());
            pStmt.executeUpdate();

        } catch (Exception e) {
            logger.error("Error while updating Production Int Code ", e);
        }
    }

    public String updateDetailCarrierOutReach(String RequestID, String issues,
            String additionalValues, String fileNameConv,
            String responseFromVendor, String missingData,
            String missingDataMonth, String additionalComments)
            throws Exception {
        String sqlString = " update oam_cr_cormanager set  " + " dataissues=?,"
                + " descriptions=?," + " filenamingconvention=?,"
                + " vendorresponse=?," + " missingData=?, "
                + " missingMonth=?," + " additionalComments =?"
                + " WHERE RequestCode =?";
        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);
            pStmt.setString(1, issues);
            pStmt.setString(2, additionalValues);
            pStmt.setString(3, fileNameConv);
            pStmt.setString(4, responseFromVendor);
            pStmt.setString(5, missingData);
            pStmt.setString(6, missingDataMonth);
            pStmt.setString(7, additionalComments);
            pStmt.setString(8, RequestID);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    public String updateDetailRepManager(String RequestID, String AMName,
            String ba, String wpm, String npm, String cl, String reprocessValue,
            String reasonOfReprocessing,
            String billClient, // isbillable
            String reason,// reason for billed
            String billedMonth, String corActPlan, String approvedBy,
            String approvalDate,
            String pmhours) throws Exception {

        String sqlString = " update oam_cr_repmanager set"
                + "  accountmanager=?," + "  businessanalyst=?,wpm=?,"
                + "  npm=?, clusterlead=?,reprocessValue=?,  reasonreprocessing=?,  "
                + "  reasonbillable=?, " + "  billable=?, "
                + "  billedmonth=?, " + "  actionplan=?, " + "  approvedby=?, "
                + "  approvedate=?, pmhours=? " + "  WHERE RequestCode =?";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {
            if (myConn == null) {
                this.connectDB();
            }

            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, AMName);
            pStmt.setString(2, ba);
            pStmt.setString(3, wpm);
            pStmt.setString(4, npm);
            pStmt.setString(5, cl);
            pStmt.setString(6, reprocessValue);
            pStmt.setString(7, reasonOfReprocessing);
            pStmt.setString(8, reason);
            pStmt.setString(9, billClient);
            pStmt.setString(10, billedMonth);
            pStmt.setString(11, corActPlan);
            pStmt.setString(12, approvedBy);
            if (approvalDate.equalsIgnoreCase("")) {
                pStmt.setDate(13, null);
            } else {
                pStmt.setDate(13,
                        new java.sql.Date((sdf.parse(approvalDate).getTime())));
            }
            pStmt.setString(14, pmhours);
            pStmt.setString(15, RequestID);
            pStmt.executeUpdate();
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }
        return "";
    }

    public String updateDetailExrManager(String RequestID, String AMName,
            String ba, String wpm, String npm, String cl, String impSpecialist,
            String extractDetails,
            String billClient, // isbillable
            String reason,// reason for billed
            String billedMonth, String additionalComments,
            String approvedBy, String signedOffBy, String approvalDate,
            String implementedbyimplservices, String implementationiceid) throws Exception {

        String sqlString = " update oam_cr_exrmanager set"
                + "  accountmanager=?," + "  businessanalyst=?,wpm=?,"
                + "  npm=?, clusterlead=?,  " + "  impspecialist=?,  " + "  extractdetail=?,  "
                + "  billable=?, " + "  reasonbillable=?, "
                + "  billedmonth=?, " + "  additionalcomments=?, " + "  approvedby=?, " + "  signedoffby=?, "
                + "  approvedate=?, implementedbyimplservices = ?, implementationiceid = ? " + "  WHERE RequestCode =?";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {
            if (myConn == null) {
                this.connectDB();
            }

            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, AMName);
            pStmt.setString(2, ba);
            pStmt.setString(3, wpm);
            pStmt.setString(4, npm);
            pStmt.setString(5, cl);
            pStmt.setString(6, impSpecialist);
            pStmt.setString(7, extractDetails);
            pStmt.setString(8, billClient);
            pStmt.setString(9, reason);
            pStmt.setString(10, billedMonth);
            pStmt.setString(11, additionalComments);
            pStmt.setString(12, approvedBy);
            pStmt.setString(13, signedOffBy);
            if (approvalDate.equalsIgnoreCase("")) {
                pStmt.setDate(14, null);
            } else {
                pStmt.setDate(14,
                        new java.sql.Date((sdf.parse(approvalDate).getTime())));
            }
            pStmt.setString(15, implementedbyimplservices);
            pStmt.setString(16, implementationiceid);
            pStmt.setString(17, RequestID);
            pStmt.executeUpdate();
            System.out.println("update sucessfully.................");
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }
        return "";
    }

    public String updateDetailPayorManager(String RequestID,
            String clientsImpacted, String eigerPath, String isTestData,
            String testData, String effectiveDate, String layoutChangeReason,
            String OAMDetails, String fileNameConv, String controlTotals,
            String emailCommnuication, String issues, String additionalValues,
            String severityOfChang, String additionalComments,
            String targetDate, String dateOfComp, String signedOffBy, String prodatalocation,
            String billable, String AMName, String reason, String billedmonth,
            String approvedBy, String approvalDate, String billableAmount,
            String implementationType, String newAIPLayoutId, String oldAIPLayoutId)
            throws Exception {
        String sqlString = "update oam_cr_plchmanager " + " set impact=?,"
                + " eigerpath=?," + " istestdata=?," + " detailtestdata=?,"
                + "  productiondate=?," + " reasonchange=?," + " oamdetail=?,"
                + " filenamingconvention=?," + "  controltotal=?, "
                + "  emailcomm=?, " + "  issueidentified=?, "
                + "  dateofcompletion=?," + "  signedoffby=?, "
                + " additionalComments=?, prodatalocation=?,billable=?, accountmanager=?,"
                + " reasonbillable=?, billedmonth=?, approvedby = ? , approvedate = ?, billableamount = ?, implementationtypeid = ?,"
                + " aiplayoutidold = ?, aiplayoutidnew = ?" + "  WHERE RequestCode =?";

//		String sqlString1 = "update oam_cr_plchmanager " + " set impact="
//				+ clientsImpacted + "," + " eigerpath=" + eigerPath + ","
//				+ " istestdata=" + isTestData + "," + " detailtestdata="
//				+ testData + "," + " reasonchange=" + layoutChangeReason + ","
//				+ " oamdetail=" + OAMDetails + "," + " filenamingconvention="
//				+ fileNameConv + "," + "  controltotal=" + controlTotals + ", "
//				+ "  emailcomm=" + emailCommnuication + ", "
//				+ "  issueidentified=" + issues + ", "
//
//				+ "  signedoffby=" + signedOffBy + ", "
//				+ " additionalComments=" + additionalComments + ""
//				+ " prodatalocation=" + prodatalocation + ""
//				+ "  WHERE RequestCode =" + RequestID + "";
        System.out.println(">>>>>>>>>>>>>" + sqlString);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {
            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, clientsImpacted);
            pStmt.setString(2, eigerPath);
            pStmt.setString(3, isTestData);
            pStmt.setString(4, testData);
            if (effectiveDate.equalsIgnoreCase("")) {
                pStmt.setDate(5, null);
            } else {
                pStmt.setDate(5,
                        new java.sql.Date((sdf.parse(effectiveDate).getTime())));
            }
            pStmt.setString(6, layoutChangeReason);
            pStmt.setString(7, OAMDetails);
            pStmt.setString(8, fileNameConv);
            pStmt.setString(9, controlTotals);
            pStmt.setString(10, emailCommnuication);
            pStmt.setString(11, issues);
            if (dateOfComp.equalsIgnoreCase("")) {
                pStmt.setDate(12, null);
            } else {
                pStmt.setDate(12,
                        new java.sql.Date((sdf.parse(dateOfComp).getTime())));
            }

            pStmt.setString(13, signedOffBy);
            pStmt.setString(14, additionalComments);
            pStmt.setString(15, prodatalocation);
            pStmt.setString(16, billable);
            pStmt.setString(17, AMName);
            pStmt.setString(18, reason);
            pStmt.setString(19, billedmonth);
            pStmt.setString(20, approvedBy);
            if (approvalDate.equalsIgnoreCase("")) {
                pStmt.setDate(21, null);
            } else {
                pStmt.setDate(21,
                        new java.sql.Date((sdf.parse(approvalDate).getTime())));
            }
            pStmt.setLong(22, convertValueToLong(billableAmount));
            pStmt.setString(23, implementationType);
            pStmt.setString(24, oldAIPLayoutId);
            pStmt.setString(25, newAIPLayoutId);
            pStmt.setString(26, RequestID);
            pStmt.executeUpdate();
            System.out.println("DATA CHECKJAVA + " + approvedBy + " " + approvalDate);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    public String insertDetailRepManager(String RequestID, String AMName,
            String ba, String wpm, String npm, String cl,
            String reprocessValue,
            String reasonOfReprocessing,
            String billClient, // isbillable
            String reason,// reason for billed
            String billedMonth, String corActPlan, String approvedBy,
            String approvalDate,
            String pmhours) throws Exception {

        String sqlString = " INSERT INTO  oam_cr_repmanager (requestcode, "
                + "  accountmanager,businessanalyst,  wpm,  "
                + "  npm,clusterlead,reprocessValue, reasonreprocessing, billable, "
                + "  reasonbillable, billedmonth,         "
                + "  actionplan,approvedby, approvedate,pmhours ) "
                + "   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, RequestID);
            pStmt.setString(2, AMName);
            pStmt.setString(3, ba);
            pStmt.setString(4, wpm);
            pStmt.setString(5, npm);
            pStmt.setString(6, cl);
            pStmt.setString(7, reprocessValue);
            pStmt.setString(8, reasonOfReprocessing);
            pStmt.setString(9, billClient);
            pStmt.setString(10, reason);
            pStmt.setString(11, billedMonth);
            pStmt.setString(12, corActPlan);
            pStmt.setString(13, approvedBy);
            if (approvalDate.equalsIgnoreCase("")) {
                pStmt.setDate(14, null);
            } else {
                pStmt.setDate(14,
                        new java.sql.Date((sdf.parse(approvalDate).getTime())));
            }
            pStmt.setString(15, pmhours);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    public String insertDetailCarrierOutReach(String RequestID, String issues,
            String additionalValues, String fileNameConv,
            String responseFromVendor, String missingData,
            String missingDataMonth, String additionalComments)
            throws Exception {

        String sqlString = " INSERT INTO  oam_cr_cormanager (requestcode, "
                + "  dataissues,descriptions, filenamingconvention, "
                + "	 vendorresponse , missingData , missingMonth ,additionalComments) "
                + "   VALUES(?,?,?,?,?,?,?,?)";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, RequestID);
            pStmt.setString(2, issues);
            pStmt.setString(3, additionalValues);
            pStmt.setString(4, fileNameConv);
            pStmt.setString(5, responseFromVendor);
            pStmt.setString(6, missingData);
            pStmt.setString(7, missingDataMonth);
            pStmt.setString(8, additionalComments);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    public String insertDetailPayorManager(String RequestID,
            String clientsImpacted, String eigerPath, String isTestData,
            String testData, String effectiveDate, String layoutChangeReason,
            String OAMDetails, String fileNameConv, String controlTotals,
            String emailCommnuication, String issues, String additionalValues,
            String severityOfChang, String additionalComments,
            String targetDate, String dateOfComp, String signedOffBy, String prodatalocation,
            String billable, String AMName, String reason, String billedmonth,
            String approvedBy, String approvalDate, String billableAmount, String implementationType, String newAIPLayoutId, String oldAIPLayoutId)
            throws Exception {

        String sqlString = " INSERT INTO  oam_cr_plchmanager (   requestcode, "
                + "  impact, eigerpath, istestdata, detailtestdata , productiondate, "
                + "reasonchange, oamdetail, filenamingconvention, controltotal, emailcomm ,"
                + " issueidentified, dateofcompletion , signedoffby , additionalcomments, prodatalocation, billable, accountmanager, reasonbillable,billedmonth,approvedby,approvedate,billableAmount,implementationtypeid,aiplayoutidold,aiplayoutidnew) "
                + "   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        try {
            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, RequestID);
            pStmt.setString(2, clientsImpacted);
            pStmt.setString(3, eigerPath);
            pStmt.setString(4, isTestData);
            pStmt.setString(5, testData);
            if (effectiveDate.equalsIgnoreCase("")) {
                pStmt.setDate(6, null);
            } else {
                pStmt.setDate(6,
                        new java.sql.Date((sdf.parse(effectiveDate).getTime())));
            }
            pStmt.setString(7, layoutChangeReason);
            pStmt.setString(8, OAMDetails);
            pStmt.setString(9, fileNameConv);
            pStmt.setString(10, controlTotals);
            pStmt.setString(11, emailCommnuication);
            pStmt.setString(12, issues);
            if (dateOfComp.equalsIgnoreCase("")) {
                pStmt.setDate(13, null);
            } else {
                pStmt.setDate(13,
                        new java.sql.Date((sdf.parse(dateOfComp).getTime())));
            }

            pStmt.setString(14, signedOffBy);
            pStmt.setString(15, additionalComments);
            pStmt.setString(16, prodatalocation);
            pStmt.setString(17, billable);
            pStmt.setString(18, AMName);
            pStmt.setString(19, reason);
            pStmt.setString(20, billedmonth);
            pStmt.setString(21, approvedBy);
            if (approvalDate.equalsIgnoreCase("")) {
                pStmt.setDate(22, null);
            } else {
                pStmt.setDate(22,
                        new java.sql.Date((sdf.parse(approvalDate).getTime())));
            }
            pStmt.setLong(23, convertValueToLong(billableAmount));
            pStmt.setString(24, implementationType);
            pStmt.setString(25, oldAIPLayoutId);
            pStmt.setString(26, newAIPLayoutId);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    public Long convertValueToLong(String amount) {
        try {
            return Long.valueOf(amount);
        } catch (Exception ex) {
            return 0L;
        }
    }

    public String insertDetailExrManager(String RequestID, String AMName,
            String ba, String wpm, String npm, String cl, String impSpecialist,
            String extractDetails,
            String billClient, // isbillable
            String reason,// reason for billed
            String billedMonth, String additionalComments,
            String approvedBy, String signedOffBy, String approvalDate,
            String implementedbyimplservices, String implementationiceid) throws Exception {

        String sqlString = " INSERT INTO  oam_cr_exrmanager (requestcode, "
                + "  accountmanager,businessanalyst,  wpm,  "
                + "  npm,clusterlead, impspecialist,extractdetail, billable, "
                + "  reasonbillable, billedmonth,additionalcomments,         "
                + "  approvedby,signedoffby, approvedate, implementedbyimplservices, implementationiceid ) "
                + "   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?, ?)";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, RequestID);
            pStmt.setString(2, AMName);
            pStmt.setString(3, ba);
            pStmt.setString(4, wpm);
            pStmt.setString(5, npm);
            pStmt.setString(6, cl);
            pStmt.setString(7, impSpecialist);
            pStmt.setString(8, extractDetails);
            pStmt.setString(9, billClient);
            pStmt.setString(10, reason);
            pStmt.setString(11, billedMonth);
            pStmt.setString(12, additionalComments);
            pStmt.setString(13, approvedBy);
            pStmt.setString(14, signedOffBy);
            if (approvalDate.equalsIgnoreCase("")) {
                pStmt.setDate(15, null);
            } else {
                pStmt.setDate(15,
                        new java.sql.Date((sdf.parse(approvalDate).getTime())));
            }
            pStmt.setString(16, implementedbyimplservices);
            pStmt.setString(17, implementationiceid);
            pStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();

        }

        return "";
    }

    /**
     * @Description : Inserts details related to production intergration to
     * OAM_CR_PITMANAGER
     * @param RequestID
     * @param AMName
     * @param ba
     * @param wpm
     * @param npm
     * @param cl
     * @param requestDesc
     * @param implICETicketNum
     * @param handOverDate
     * @param appReleasedToClientDate
     * @param accStrDetailsIncluded
     * @param targetDate
     */
    public void insertProdIntDetails(ProductionIntegrationCode prodIntCode) {

        String sqlString = ""
                + "INSERT INTO oam_cr_pitmanager "
                + "            (requestcode, "
                + "             accountmanager, "
                + "             businessanalyst, "
                + "             wpm, "
                + "             npm, "
                + "             clusterlead, "
                + "             requestdescription, "
                + "             impliceticketnum, "
                + "             processingmonth, "
                + "             handoverdate, "
                //				+ "             appreleasedtoclientdate, "
                + "             accstrdetailsincluded, "
                + "             addcomments, "
                + "             approvedby, "
                //+ "             remarks, "
                + "             targetcompdate, "
                + "             actualcompdate, "
                + "             approveddate) "
                + "VALUES      (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        try {

            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(sqlString);

            pStmt.setString(1, prodIntCode.getRequestCode());
            pStmt.setString(2, prodIntCode.getAccountManager());
            pStmt.setString(3, prodIntCode.getBussinessManager());
            pStmt.setString(4, prodIntCode.getWathamPM());
            pStmt.setString(5, prodIntCode.getNepalPM());
            pStmt.setString(6, prodIntCode.getClusterLead());
            pStmt.setString(7, prodIntCode.getRequestDesc());
            pStmt.setString(8, prodIntCode.getImpICETicketNum());
            pStmt.setString(9, prodIntCode.getProcessingMonth());
            //hand over date
            if (prodIntCode.getHandOverDate().equalsIgnoreCase("")) {
                pStmt.setDate(10, null);
            } else {
                pStmt.setDate(10,
                        new java.sql.Date((sdf.parse(prodIntCode.getHandOverDate()).getTime())));
            }
            // appReleasedToClientDate
            /*if (prodIntCode.getAppReleasesToClientDate().equalsIgnoreCase(""))
				pStmt.setDate(11, null);
			else
				pStmt.setDate(11,
						new java.sql.Date((sdf.parse(prodIntCode.getAppReleasesToClientDate()).getTime())));*/
            pStmt.setString(11, prodIntCode.getAccStrDetailsIncluded());
            pStmt.setString(12, prodIntCode.getAddtionalComments());
            pStmt.setString(13, prodIntCode.getApprovedBy());
            //pStmt.setString(14, prodIntCode.getRemarks());
            // target comp date
            if (prodIntCode.getTargetCompDate().equalsIgnoreCase("")) {
                pStmt.setDate(14, null);
            } else {
                pStmt.setDate(14,
                        new java.sql.Date((sdf.parse(prodIntCode.getTargetCompDate()).getTime())));
            }
            //actual comp date
            if (prodIntCode.getActualCompDate().equalsIgnoreCase("")) {
                pStmt.setDate(15, null);
            } else {
                pStmt.setDate(15,
                        new java.sql.Date((sdf.parse(prodIntCode.getActualCompDate()).getTime())));
            }
            // Approval Date
            if (prodIntCode.getApprovedDate().equalsIgnoreCase("")) {
                pStmt.setDate(16, null);
            } else {
                pStmt.setDate(16,
                        new java.sql.Date((sdf.parse(prodIntCode.getApprovedDate()).getTime())));
            }
            pStmt.executeUpdate();
        } catch (Exception e) {
            logger.error("[Error]QueryBean->insertProdIntDetails: " + sqlString, e);
            e.printStackTrace();
        }
    }

    public void insertTestCases(String RequestId,
            Map<String, String> testCases, int count) {
        String query = "INSERT INTO OAM_CR_TESTCASES (REQUESTCODE,TESTDESCRIPTION,EXPECTEDRESULT,ACTUALRESULT,PASSFAIL)"
                + " VALUES (?,?,?,?,?)";

        try {
            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(query);
            for (int i = 0; i < count; i++) {
                if (testCases.get("testCaseDesc" + i) != null) {
                    pStmt.setString(1, RequestId);
                    pStmt.setString(2, testCases.get("testCaseDesc" + i));
                    pStmt.setString(3, testCases.get("expResult" + i));
                    pStmt.setString(4, testCases.get("actResult" + i));
                    pStmt.setString(5, testCases.get("passFail" + i));
                    pStmt.addBatch();
                }

            }
            pStmt.executeBatch();

        } catch (Exception e) {
            System.out.println("Error while inserting test cases " + query);
            e.printStackTrace();
        }
    }

    /**
     * @param RequestId
     * @param testCases : Contains key value for test cases
     * @param newTestCaseAry
     */
    public void insertNewTestCases(String RequestId, Map<String, String> testCases, String[] newTestCaseAry) {
        String query = "INSERT INTO OAM_CR_TESTCASES (REQUESTCODE,TESTDESCRIPTION,TESTPROCEDURE,EXPECTEDRESULT,ACTUALRESULT,PASSFAIL)"
                + " VALUES (?,?,?,?,?,?)";

        try {
            if (myConn == null) {
                this.connectDB();
            }
            PreparedStatement pStmt = myConn.prepareStatement(query);

            for (int i = 0; i < newTestCaseAry.length; i++) {
                if ((testCases.get("testCase" + newTestCaseAry[i]) != null) && (testCases.get("testCase" + newTestCaseAry[i]) != "")) {
                    pStmt.setString(1, RequestId);
                    pStmt.setString(2, testCases.get("testCase" + newTestCaseAry[i]));
                    pStmt.setString(3, testCases.get("testProc" + newTestCaseAry[i]));
                    pStmt.setString(4, testCases.get("expResult" + newTestCaseAry[i]));
                    pStmt.setString(5, testCases.get("actResult" + newTestCaseAry[i]));
                    pStmt.setString(6, testCases.get("reviewStatus" + newTestCaseAry[i]));
                    pStmt.addBatch();
                }
            }
            pStmt.executeBatch();

        } catch (Exception e) {
            System.out.println("Error while inserting test cases " + query);
            e.printStackTrace();
        }
    }

    public void updateTestCases(String RequestId,
            Map<String, String> testCases, int count) {
        String qry = "";
        try {
            Statement stmnt = myConn.createStatement();
            qry = "DELETE FROM OAM_CR_TESTCASES WHERE REQUESTCODE=" + RequestId;
            stmnt.execute(qry);
            insertTestCases(RequestId, testCases, count);
        } catch (SQLException sqlexception) {
            System.out.println("Error while updating test cases >>>>>" + qry);
        }
    }

    /**
     * @Description: Deletes testcases and then inserts
     * @param RequestId
     * @param testCases
     * @param newTestCaseAry
     */
    public void updateNewTestCases(String RequestId,
            Map<String, String> testCases, String[] newTestCaseAry) {
        String qry = "";
        try {
            Statement stmnt = myConn.createStatement();
            qry = "DELETE FROM OAM_CR_TESTCASES WHERE REQUESTCODE=" + RequestId;
            stmnt.execute(qry);
            insertNewTestCases(RequestId, testCases, newTestCaseAry);
        } catch (SQLException sqlexception) {
            System.out.println("Error while updating test cases >>>>>" + qry);
        }
    }

    public String updateAssignedToDataIssue(String RequestCode) {
        String sqlStr = "";
        String isInserted = "ok";
        sqlStr = "update a Set a.AssignedTo = b.BusinessIntID,a.StatusID = '0008'"
                + " FROM OAM_RM_REQUESTMANAGER a"
                + " LEFT JOIN tbl_ProductionManager b "
                + " ON a.ClientID = b.ProductionCode";
        sqlStr += " WHERE 1=1 AND b.BusinessIntID is not null and RequestCode='"
                + RequestCode + "'";
        strSQL += "<BR>" + sqlStr;
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    // Method to mark or unmark completed by enggineer
    // isComp = 'n' if it is marked as incomplete - default
    // isComp = 'y' if it is marked as completed
    // isComp = 'm' if enggineer posts a new message and no reply is posted
    public String markRequestCompleted(String RequestCode, String enggID,
            String isComp) {

        String isInserted = "0";
        boolean e = false;
        String sqlString = "{call sp_OAM_RM_MarkRequestCompleted (?,?,?)}";
        try {
            strSQL = sqlString;

            CallableStatement stmt = this.myConn.prepareCall(sqlString);
            stmt.setString(1, RequestCode);
            stmt.setString(2, enggID);
            stmt.setString(3, isComp);

            stmt.execute();
            isInserted = "1";
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Marking Error : " + sqlexception;
            e = true;
        }
        if (!e) {
            archiveRequest(RequestCode, enggID); // Also writing the same values
            // in Archive
        }
        return isInserted;
    }

    public String markRequestDropped(String RequestCode) throws Exception {
        String isInserted = "0";
        String droppedRequest = this.getStatusIDByName("Dropped");
        try {
            Statement stmnt = myConn.createStatement();
            strSQL = "Update OAM_RM_REQUESTMANAGER Set StatusID="
                    + droppedRequest + " WHERE RequestCode='" + RequestCode
                    + "'";
            // System.out.println("markRequestDropped-> "+strSQL);
            stmnt.execute(strSQL);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            isInserted = "1";
        }
        return isInserted;
    }

    public String deleteProjectRequest(String RequestCode) throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            String sqlString = "DELETE OAM_RM_REQUESTMANAGER WHERE RequestCode="
                    + RequestCode;
            stmnt.execute(sqlString);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String deleteProjectRequestBlank() throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            String sqlString = "DELETE OAM_RM_REQUESTMANAGER where RequestTypecode is null "
                    + " and requestcode not in (select requestcode from OAM_RM_ASSIGNEE)"
                    + " and requestcode not in (select requestcode from OAM_RM_MOREDOCUMENTS1)"
                    + " and requestcode not in (select requestcode from OAM_RM_REQUESTMOREINFO)";
            stmnt.execute(sqlString);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String insertNewObject(String whichObject, String objectValue)
            throws Exception {
        String isInserted = "ok";
        char c = whichObject.charAt(0);
        strSQL = "";
        String ov = objectValue.replaceAll("'", "''").trim().trim();
        switch (c) {
            case 'a':
                strSQL = "INSERT INTO OAM_RM_REQUEST_TYPES VALUES ('" + ov + "')";
                break;
            case 'b':
                strSQL = "INSERT INTO OAM_RM_REQUESTSTATUS VALUES ('" + ov + "')";
                break;
            case 'c':
                strSQL = "INSERT INTO tbl_Engineers VALUES ('" + ov + "')";
                break;
            case 'd':
                strSQL = "INSERT INTO OAM_RM_PRODUCTVERSION VALUES ('" + ov + "')";
                break;
            case 'e':
                strSQL = "INSERT INTO tbl_RequestingPerson VALUES ('" + ov + "')";
                break;
            case 'f':
                strSQL = "INSERT INTO OAM_RM_REQUEST_TYPES VALUES ('" + ov + "')";
                break;
            default:
                strSQL = "";
                break;
        }

        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(strSQL);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String insertNewVersion(String version, String ProductID)
            throws Exception {
        String isInserted = "ok";
        strSQL = "Select count(*) n from OAM_RM_PRODUCTVERSION where UPPER(VersionName) like '"
                + version.trim().toUpperCase()
                + "' and "
                + " ProductID like '"
                + ProductID + "'";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSQL);
            rs.next();
            int count = Integer.parseInt(rs.getString("n".trim()));
            // System.out.println (count);
            if (count > 0) {
                isInserted = "duplicate";
                return isInserted;
            } else if (count == 0) {
                strSQL = "\nDECLARE @MaxID INT\n"
                        + "SELECT @MaxID=1\n"
                        + "IF(SELECT COUNT(VersionID) FROM OAM_RM_PRODUCTVERSION)>0\n"
                        + "\tSELECT @MaxID=MAX(PKSource)+1 FROM OAM_RM_PRODUCTVERSION "
                        + "\nDECLARE @MaxVerID INT\n"
                        + "SELECT @MaxVerID=1\n"
                        + "IF(SELECT COUNT(VersionOrder) FROM OAM_RM_PRODUCTVERSION where ProductID='"
                        + ProductID
                        + "') >0\n"
                        + "\tSELECT @MaxVerID=MAX(VersionOrder)+1 FROM OAM_RM_PRODUCTVERSION "
                        + " INSERT INTO OAM_RM_PRODUCTVERSION (VersionID, VersionDesc,VersionName,  Active_YN, ProductID) VALUES ("
                        + "'000'+CONVERT(VARCHAR,@MaxID)," + SQLEncode(version)
                        + "," + SQLEncode(version) + "," + "'Y', " + "'"
                        + ProductID + "'" + ")";

                stmnt.execute(strSQL);
            }
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String getSQLData(String value) {

        if (!value.trim().equals("")) {
            return "'" + value.replaceAll("'", "''").trim() + "'";
        } else {
            return "NULL";
        }

    }

    public String updateFirstProjectALLRequest(String RequestID,
            String RequestDate, String RequestingPerson, String RequestTypeID,
            String RequestPriority, String ClientID, String SourceID, String EmployeeGroup, String projectId,
            String RequestTitle, String DataProviderID, String dataType,
            String RequestPhase, String AssignedTo, String EstimatedHours,
            String targetCompDate, String actualCompDate, String phaseId,
            String PayorID, String appReleasedToClientDate, String ApplicationType, String PrioritizedDate, String PrioritizedBy, String team, String processMonth,
            String releaseTag, String cleancompletedatareciptdate, String legalcompletedate, String externalid, RequestParamDTO requestParamDTO) throws Exception {

        try {

            if (requestParamDTO == null) {
                requestParamDTO = new RequestParamDTO();
            }

            ClientID = ClientID.trim().equals("") ? "0" : ClientID;
            RequestTypeID = RequestTypeID.trim().equals("") ? "0"
                    : RequestTypeID;
            RequestPhase = RequestPhase.trim().equals("") ? "0" : RequestPhase;
            EstimatedHours = EstimatedHours.trim().equals("") ? "0"
                    : EstimatedHours;
            RequestPriority = RequestPriority.trim().equals("") ? "0"
                    : RequestPriority;
            DataProviderID = DataProviderID.trim().equals("") ? "0"
                    : DataProviderID;

            String sqlString = "UPDATE OAM_RM_REQUESTMANAGER "
                    + "SET RequestingPerson = ?," + "ClientID= ?," + "ProjectID= ?,"
                    + " RequestDate = sysdate ," + "RequestTypeID=?,"
                    + " sourceid=?," + "requesttitle=?," + "dataproviderid=?,"
                    + " dataType=?," + "AssignedTo=?," + "EstimatedHours=?,"
                    + " targetcompdate= ?," + "actualcompdate= ?,"
                    + " phaseid=?," + "statusid='1',"
                    + " LastUpdatedDate= sysdate ," + "payorid=?,"
                    + " RequestPriority=?, " + " appreleasedate=?, " + "employerGroup=?, applicationtype = ?,"
                    + " prioritizeddate = ?, prioritizedby = ?,Team = ?, processmonth=?, releaseTag=?,"
                    + " cleancompletedatareciptdate=?,legalcompletedate=?, externalid=?, "
                    + " parenticeid=?, parentrequesttype=?, integrationtype=?, applicationkickoffdate=? "
                    + " WHERE RequestCode =?";

            System.out.println(strSQL);

            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            if (myConn == null) {
                this.connectDB();
            }
            // Statement stmnt = myConn.createStatement();
            PreparedStatement preStmt = myConn.prepareStatement(sqlString);

            preStmt.setString(1, RequestingPerson);
            preStmt.setString(2, ClientID);
            preStmt.setString(3, projectId);
            preStmt.setString(4, RequestTypeID);
            preStmt.setString(5, SourceID);
            preStmt.setString(6, RequestTitle);
            preStmt.setString(7, DataProviderID);
            preStmt.setString(8, dataType);
            preStmt.setString(9, AssignedTo);
            preStmt.setString(10, EstimatedHours);
            if (targetCompDate.equalsIgnoreCase("")) {
                preStmt.setDate(11, null);
            } else {
                preStmt.setDate(
                        11,
                        new java.sql.Date((sdf.parse(targetCompDate).getTime())));
            }

            if (actualCompDate.equalsIgnoreCase("")) {
                preStmt.setDate(12, null);
            } else {
                preStmt.setDate(
                        12,
                        new java.sql.Date((sdf.parse(actualCompDate).getTime())));
            }

            preStmt.setString(13, phaseId);
            preStmt.setString(14, PayorID);
            preStmt.setString(15, RequestPriority);
            System.out.println("appReleasedToClientDate >>>>>>>>>>>>>>>>>>>>>> " + appReleasedToClientDate);
            if (appReleasedToClientDate.equalsIgnoreCase("")) {
                preStmt.setDate(16, null);
            } else {
                preStmt.setDate(
                        16,
                        new java.sql.Date((sdf.parse(appReleasedToClientDate).getTime())));//VITTOOLS-450
            }
            preStmt.setString(17, EmployeeGroup);
            preStmt.setString(18, ApplicationType);
            if (PrioritizedDate.equalsIgnoreCase("")) {
                preStmt.setDate(19, null);
            } else {
                preStmt.setDate(19, new java.sql.Date((sdf.parse(PrioritizedDate).getTime())));//VITTOOLS-450
            }
            preStmt.setString(20, PrioritizedBy);
            preStmt.setString(21, team);
            preStmt.setString(22, processMonth);
            preStmt.setString(23, releaseTag);
            if (cleancompletedatareciptdate.equalsIgnoreCase("")) {
                preStmt.setDate(24, null);
            } else {
                preStmt.setDate(24, new java.sql.Date((sdf.parse(cleancompletedatareciptdate).getTime())));//VITTOOLS-450
            }

            if (legalcompletedate.equalsIgnoreCase("")) {
                preStmt.setDate(25, null);
            } else {
                preStmt.setDate(25, new java.sql.Date((sdf.parse(legalcompletedate).getTime())));//VITTOOLS-450
            }
            preStmt.setString(26, externalid);

            preStmt.setString(27, requestParamDTO.getParenticeid());
            preStmt.setString(28, requestParamDTO.getParentrequesttype());
            preStmt.setString(29, requestParamDTO.getIntegrationtype());
            preStmt.setDate(30, DTOUtils.convertSQLDate(requestParamDTO.getApplicationkickoffdate()));

            preStmt.setString(31, RequestID);
            preStmt.executeUpdate();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            sqlexception.printStackTrace();
        }

        return AssignedTo;
    }

    public String updateProjectRequest(String RequestCode,
            String RequestTypeID, String RequestDate, String RequestingPerson,
            String Requests, String ActionTaken, String StatusID,
            String AssignedTo, String ApplicationVersionCode,
            String TargetCompDate, String ActualCompDate,
            String RequestPriority, String ClientID, String RequestPhaseCode,
            String uid) {
        String sqlStr = "";
        String isInserted = "ok";
        String iscompleted = "n";
        String tempStatusCode = this.getStatusDesc("Completed");
        if (StatusID.equals(tempStatusCode)) {
            iscompleted = "y";
        }

        archiveRequest(RequestCode, uid);
        sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET " + "RequestDate='"
                + RequestDate + "',RequestingPerson='"
                + RequestingPerson.replaceAll("'", "''").trim()
                + "',Requests='" + Requests.replaceAll("'", "''").trim() + "'";

        sqlStr += ",RequestTypeID=" + SQLEncode(RequestTypeID);
        sqlStr += ",ActionTaken=" + SQLEncode(ActionTaken);
        sqlStr += ",StatusID=" + SQLEncode(StatusID);
        sqlStr += ",AssignedTo=" + SQLEncode(AssignedTo);
        sqlStr += ",DetectedVersion=" + SQLEncode(ApplicationVersionCode);
        sqlStr += ",TargetCompDate=" + SQLEncode(TargetCompDate);
        sqlStr += ",ActualCompDate=" + SQLEncode(ActualCompDate);
        sqlStr += ",RequestPriority=" + SQLEncode(RequestPriority);
        sqlStr += ",PhaseDetected=" + SQLEncode(RequestPhaseCode);
        sqlStr += ",isCompleted=" + SQLEncode(iscompleted);
        sqlStr += ",ClientID=" + SQLEncode(ClientID);
        sqlStr += ",LastUpdatedDate= sysdate ";

        sqlStr += " WHERE RequestCode='" + RequestCode + "'";

        strSQL += "<BR>" + sqlStr;
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String updateProjectRequestIsAdmin(String RequestCode,
            String RequestTypeID, String RequestDate, String RequestingPerson,
            String Requests, String uid, String StatusID) {
        String sqlStr = "";
        String isInserted = "ok";
        String iscompleted = "n";
        archiveRequest(RequestCode, uid);
        if (StatusID.equals("0010")) {
            iscompleted = "y";
        }
        sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET " + "RequestDate='"
                + RequestDate + "',RequestingPerson='"
                + RequestingPerson.replaceAll("'", "''").trim()
                + "',StatusID='" + StatusID + "',iscompleted='" + iscompleted
                + "',LastUpdatedDate= sysdate " + ",Requests='"
                + Requests.replaceAll("'", "''").trim() + "'";
        sqlStr += ",RequestTypeID=" + SQLEncode(RequestTypeID);

        sqlStr += " WHERE RequestCode='" + RequestCode + "'";

        strSQL = sqlStr;
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    // DELETES the document of passed Request Code and DocumentCode (if any)
    public String deleteRequestDocument(String RequestCode, String DocumentCode) {
        String sqlStr = "";
        String did = DocumentCode;
        if (did.equals("")) {
            did = "0";
        }
        String isInserted = "ok";
        sqlStr = "SP_OAM_RM_DELETEREQUESTDOC '" + RequestCode + "'," + did;
        strSQL = sqlStr;
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    // Inserts a new "Request More Information" record
    public String insertRequestMoreInfo(String RequestCode, String PostedBy,
            String ReplyTo, String PostedMsg) {

        String isInserted = "ok";

        String sqlStr = "{call SP_OAM_RM_REQUESTMOREINFO (?,?,?,?,?)}";

        try {
            CallableStatement stmt = this.myConn.prepareCall(sqlStr);
            stmt.setString(1, RequestCode);
            stmt.setString(2, PostedBy);
            stmt.setString(3, ReplyTo);
            stmt.setString(4, PostedMsg.trim());
            stmt.registerOutParameter(5, Types.VARCHAR);
            stmt.execute();
            isInserted = stmt.getString(5);
            Statement stmt1 = this.myConn.createStatement();
            sqlStr = "Update OAM_RM_REQUESTMANAGER Set ActionTaken='"
                    + PostedMsg + "' WHERE RequestCode='" + RequestCode + "'";
            // System.out.println(sqlStr);
            stmt1.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
            sqlexception.printStackTrace();
        }

        return isInserted;
    }

    // Mark the replies "READ" if the logged user is the Engineer to which
    // current request is assigned
    public String markRepliesRead(String RequestCode) {
        String isInserted = "ok";
        String sqlString = "{call sp_oam_rm_markrepliesread (?)}";

        strSQL = sqlString;
        try {
            CallableStatement stmt = this.myConn.prepareCall(sqlString);
            stmt.setString(1, RequestCode);
            stmt.execute();
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public void addMultipleAssignee(String ProjID, String multipleAssignee) {
        try {
            Statement stmnt = myConn.createStatement();
            StringTokenizer strtoken = new StringTokenizer(multipleAssignee,
                    ",");
            String sqlstr = "DELETE OAM_RM_ASSIGNEE WHERE RequestCode = '"
                    + ProjID + "'";
            stmnt.execute(sqlstr);
            while (strtoken.hasMoreTokens()) {
                String str = strtoken.nextToken();
                // stmnt.execute("insert into OAM_RM_ASSIGNEE values('"+ ProjID
                // +"', '"+ str +"')");
                // String sqlstr="sp_InsertMultipleAssignee '"+ ProjID +
                // "','"+str+"'";
                sqlstr = "insert into OAM_RM_ASSIGNEE values('" + ProjID
                        + "', '" + str + "')";
                stmnt.execute(sqlstr);
            }
        } catch (SQLException sqlexception) {
        }
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request with Request Code "ProjID"
    public boolean getRequestDetails(String ProjID) {
        String sql = "SELECT p.RequestCode,r.RequestTypeDesc,p.RequestDate,"
                + " p.RequestingPerson, p.actiontaken Benefits,p.RequestTitle, rp.UserName as RequestingPersonDesc,rp.email as ReqPersonEmail,"
                + " c.ClientName,p.Requests, p.ActionTaken,s.StatusDesc, e.UserName AS User_Name,e.email as enggEmail,"
                + " v.VersionDesc, p.TargetCompDate,p.ActualCompDate,p.devCompDate,p.RequestPriority, pt.ProductName,cl.ClientName as DataProvider,"
                + " e.UserID AS EnggID,p.isCompleted,Nvl(y.documentCount,0) AS documentCount,p.ExpectedCompDate,x.RequestPhaseDesc "
                + " FROM OAM_RM_REQUESTMANAGER p "
                + " LEFT OUTER JOIN usr_Users e ON p.assignedTo=e.UserID "
                + " LEFT OUTER JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + " LEFT OUTER JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID "
                + " LEFT OUTER JOIN OAM_RM_REQUEST_TYPES r ON p.RequestTypeID=r.RequestTypeID "
                + " LEFT OUTER JOIN usr_Users rp ON p.RequestingPerson=rp.UserID"
                + " LEFT OUTER JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + " LEFT JOIN OAM_CLIENTS cl ON p.DataProviderID=cl.clientID "
                + " LEFT OUTER JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + " LEFT JOIN OAM_RM_INJECTED_PHASE x1 ON x1.RequestPhaseID=p.phaseinject "
                + " LEFT OUTER JOIN OAM_RM_PRODUCTS pt on p.ProductID = pt.ProductID"
                + " LEFT JOIN (SELECT RequestCode,COUNT(*) AS documentCount FROM OAM_RM_MOREDOCUMENTS1 GROUP BY RequestCode) y ON y.RequestCode=p.RequestCode  "
                + " WHERE p.RequestCode= '" + ProjID + "'";
        return getList(sql, "Request Details");
    }

    public String getRequestTitle(String ProjID) {
        String sqlString = "SELECT RequestTitle FROM oam_rm_requestmanager WHERE RequestCode='"
                + ProjID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("RequestTitle");
            }
        }
        return retValue;
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request with Request Code "ProjID" in
    // HTML-Formatted String
    public String getFormattedRequestDetails(String ProjID) {
        String requestDetail = "";
        String OAMURL = getFixedParameter("OAM URL") + "/RM/";
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestCode = getData("RequestCode");
                String requestTypeDesc = getData("RequestTypeDesc");
                String requestDate = getOnlyDate(getData("RequestDate"), true);
                String requestingPerson = getData("RequestingPerson");
                reqPersonName = getData("RequestingPersonDesc");
                reqPersonEmail = getData("ReqPersonEmail");
                String clientName = getData("ClientName");
                String requests = TextEncoder.encode(getData("Requests"))
                        .replaceAll("\n", "<br>");
                String actionTaken = TextEncoder.encode(getData("ActionTaken"))
                        .replaceAll("\n", "<br>");
                String statusDesc = getData("StatusDesc");
                mainEnggName = getData("User_Name");
                mainEnggEmail = getData("enggEmail");
                String VersionDesc = getData("VersionDesc");
                String targetCompDate = getOnlyDate(getData("TargetCompDate"),
                        true);
                String actualCompDate = getOnlyDate(getData("ActualCompDate"),
                        true);
                String DevCompDate = getOnlyDate(getData("DevCompDate"), true);
                String requestPriority = getData("RequestPriority");
                String enggID = getData("EnggID");
                String isCompleted = getData("isCompleted");
                String documentCount = getData("documentCount");
                String RequestPhase = getData("cRequestPhaseDesc");
                String ExpectedCompDate = getOnlyDate(
                        getData("ExpectedCompDate"), true);

                String attch = "N/A";
                if (!(documentCount.equals("0") || documentCount.trim().equals(
                        ""))) {
                    attch = "<a href='" + OAMURL
                            + "RE/downloadAllFiles.jsp?pid=" + ProjID
                            + "'>Click here to download attachments</a>";
                }

                String requestPriorityDesc = "N/A";
                if (requestPriority.equals("1")) {
                    requestPriorityDesc = "N/A";
                } else if (requestPriority.equals("2")) {
                    requestPriorityDesc = "N/A";
                } else if (requestPriority.equals("3")) {
                    requestPriorityDesc = "P";
                } else if (requestPriority.equals("4")) {
                    requestPriorityDesc = "P";
                } else if (requestPriority.equals("5")) {
                    requestPriorityDesc = "P";
                }

                requestDetail = "<TABLE>"
                        + "<TR><TD>Request Date  </TD><TD>:&nbsp; "
                        + requestDate
                        + "</TR>"
                        + "<TR><TD>Requesting Person  </TD><TD>:&nbsp; "
                        + reqPersonName
                        + "</TR>"
                        + "<TR><TD>Client  </TD><TD>:&nbsp; "
                        + clientName
                        + "</TR>"
                        + "<TR><TD>Phase  </TD><TD>:&nbsp; "
                        + RequestPhase
                        + "</TR>"
                        + "<TR><TD>Request Type  </TD><TD>:&nbsp; "
                        + requestTypeDesc
                        + "</TR>"
                        + "<TR><TD>Description  </TD><TD>:&nbsp; "
                        + requests
                        + "</TR>"
                        + "<TR><TD>Action  </TD><TD>:&nbsp; "
                        + actionTaken
                        + "</TR>"
                        + "<TR><TD>Status  </TD><TD>:&nbsp; "
                        + statusDesc
                        + "</TR>"
                        + "<TR><TD>Assigned to</TD><TD>:&nbsp; "
                        + mainEnggName
                        + "</TR>"
                        + "<TR><TD>Rel. #  </TD><TD>:&nbsp; "
                        + VersionDesc
                        + "</TR>"
                        + "<TR><TD>Expected Compl. Date  </TD><TD>:&nbsp; "
                        + ExpectedCompDate
                        + "</TR>"
                        + "<TR><TD>Target Compl. Date  </TD><TD>:&nbsp; "
                        + targetCompDate
                        + "</TR>"
                        + // "<TR><TD>Actual Compl. Date  </TD><TD>:&nbsp; " +
                        // actualCompDate + "</TR>" +
                        "<TR><TD>Dev. Compl. Date  </TD><TD>:&nbsp; "
                        + DevCompDate
                        + "</TR>"
                        + "<TR><TD>Priority  </TD><TD>:&nbsp; "
                        + requestPriorityDesc
                        + "</TR>"
                        + "<TR><TD>Attachment  </TD><TD>:&nbsp; "
                        + attch
                        + "</TR>" + "</TABLE>";
            }
        }
        return requestDetail;
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request Message (more info) with Request Code
    // "requestCode"
    // And infocode of "infoCode"
    public boolean getRequestMoreInfoDetails(String requestCode, String infoCode) {
        String sql = "select InfoID,RequestCode,ReplyTo,UserID AS user_id,PostedMsg,userName AS "
                + " user_name,"
                + " Trunc(PostedDate) AS PostedDate "
                + " from OAM_RM_REQUESTMOREINFO a, usr_Users b "
                + " where a.PostedBy=b.userid ";
        if (!infoCode.trim().equals("")) {
            sql += " AND (InfoID='" + infoCode + "' or ReplyTo='" + infoCode
                    + "') ";
        }
        if (!requestCode.trim().equals("")) {
            sql += " AND RequestCode='" + requestCode + "'";
        }

        sql += " ORDER BY InfoID,RequestCode ";
        return getList(sql, "Request More Info Details");
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request Message (more info) with Request Code
    // "requestCode"
    // And infocode of "infoCode" in HTML-FORMATTED string
    public String getFormattedRequestMoreInfoDetails(String requestCode,
            String infoCode) {
        String moreInfoDetail = "";
        if (getRequestMoreInfoDetails(requestCode, infoCode)) {
            moreInfoDetail = "<TABLE BORDER=1>"
                    + "<TR><TD><B>&nbsp;S.No.</B></TD>"
                    + "<TD><B>&nbsp;Message</B></TD>"
                    + "<TD><B>&nbsp;Posted By</B></TD>"
                    + "<TD><B>&nbsp;Posted On</B></TD></TR>";
            int countSNo = 0;
            String bgcolor = "";
            while (moveNext()) {
                countSNo++;
                bgcolor = "";
                if (countSNo == 1) {
                    bgcolor = " BGCOLOR=yellow";
                }

                moreInfoDetail += "<TR " + bgcolor + "><TD ALIGN=RIGHT> "
                        + countSNo + ".&nbsp;</TD>" + "<TD>&nbsp;"
                        + getData("PostedMsg") + "</TD>" + "<TD>&nbsp;"
                        + getData("user_name") + "</TD>" + "<TD ALIGN=RIGHT>"
                        + getData("PostedDate") + "&nbsp;</TD></TR>";
            }

            String sql = "select InfoID,RequestCode,ReplyTo,UserID AS user_id,PostedMsg,userName AS "
                    + " user_name,CONVERT(VARCHAR,DATEPART(mm,PostedDate))+'/'+CONVERT(VARCHAR,DATEPART(dd,PostedDate))+'/'+CONVERT(VARCHAR,DATEPART(yy,PostedDate)) AS PostedDate "
                    + " from OAM_RM_REQUESTMOREINFO a, usr_Users b "
                    + " where a.PostedBy=b.userid AND NOT (InfoID<>'"
                    + infoCode
                    + "' or ReplyTo<>'"
                    + infoCode
                    + "') "
                    + " AND RequestCode='"
                    + requestCode
                    + "'"
                    + " ORDER BY InfoID,RequestCode ";

            if (getList(sql, "Request More Info Details")) {
                moreInfoDetail += "<TR><TD COLSPAN=4><B>&nbsp;Other messages:"
                        + "</B></TD></TR>";
                countSNo = 0;
                while (moveNext()) {
                    countSNo++;
                    moreInfoDetail += "<TR " + bgcolor + "><TD ALIGN=RIGHT> "
                            + countSNo + ".&nbsp;</TD>" + "<TD>&nbsp;"
                            + getData("PostedMsg") + "</TD>" + "<TD>&nbsp;"
                            + getData("user_name") + "</TD>"
                            + "<TD ALIGN=RIGHT>" + getData("PostedDate")
                            + "&nbsp;</TD></TR>";
                }
            }
            moreInfoDetail += "</TABLE>";
        }
        return moreInfoDetail;
    }

    // Jan 16, 2003 - new
    public String getFormattedRequestMoreInfoDetails(String PostedBy,
            String RequestCode, String PostedMsg) {
        String moreInfoDetail = "<TABLE BORDER=1>"
                + "<TR><TD><B>&nbsp;S.No.</B></TD>"
                + "<TD><B>&nbsp;Message</B></TD>"
                + "<TD><B>&nbsp;Posted By</B></TD>"
                + "<TD><B>&nbsp;Posted On</B></TD></TR>"
                + "<TR BGCOLOR=yellow><TD ALIGN=RIGHT> 1.&nbsp;</TD>"
                + "<TD>&nbsp;"
                + PostedMsg
                + "</TD>"
                + "<TD>&nbsp;"
                + PostedBy
                + "</TD>"
                + "<TD ALIGN=RIGHT>"
                + getOnlyDate(
                        new java.sql.Date(System.currentTimeMillis())
                        .toString(),
                        true) + "&nbsp;</TD></TR> ";

        if (getRequestMoreInfoDetails(RequestCode, "")) {
            moreInfoDetail += "<TR><TD COLSPAN=4><B>&nbsp;Previous messages:"
                    + "</B></TD></TR>";
            int countSNo = 0;
            String bgcolor = "";
            while (moveNext()) {
                countSNo++;
                moreInfoDetail += "<TR " + bgcolor + "><TD ALIGN=RIGHT> "
                        + countSNo + ".&nbsp;</TD>" + "<TD>&nbsp;"
                        + getData("PostedMsg") + "</TD>" + "<TD>&nbsp;"
                        + getData("user_name") + "</TD>" + "<TD ALIGN=RIGHT>"
                        + getData("PostedDate") + "&nbsp;</TD></TR>";
            }
        }

        moreInfoDetail += "</TABLE>";
        return moreInfoDetail;
    }

    // Jan 16, 2003 - modified
    // Get list of users with OAMStatus=1
    public boolean getAlreadyAssignedList(String ProjID) {
        return getList(
                "select RequestCode,a.UserID,UserName AS user_name,email from OAM_RM_ASSIGNEE a, usr_Users b WHERE a.UserID=b.userid AND RequestCode= '"
                + ProjID + "'", "List Of Assignee");
    }

    // Jan 16, 2003 - modified
    // Get list of users with OAMStatus=1
    public String getAlreadyAssignedPeople(String ProjID) {
        String retStr = "";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("Select b.UserName AS User_Name from OAM_RM_ASSIGNEE a,usr_Users b where a.RequestCode= '"
                            + ProjID + "'  AND a.UserID= b.UserID");
            while (rs.next()) {
                retStr = retStr + rs.getString("User_Name") + "<br>";
            }
        } catch (SQLException sqex) {
        }

        return retStr;
    }

    public Hashtable getIDOfAlreadyAssignedPeople(String ProjectID) {
        Hashtable enggLists = new Hashtable();

        String tempRequestCode = "x";
        String tempEnggList = "x";
        String rsRequestCode = "";

        if (getList(
                "SELECT a.RequestCode,b.UserID FROM OAM_RM_REQUESTMANAGER a LEFT JOIN OAM_RM_ASSIGNEE b ON a.RequestCode = b.RequestCode WHERE parentRequestCode='"
                + ProjectID + "' ORDER BY a.RequestCode", "")) {
            while (moveNext()) {
                rsRequestCode = getData("RequestCode");
                if (!tempRequestCode.equals(rsRequestCode)) {
                    enggLists.put(tempRequestCode, tempEnggList);
                    tempEnggList = "";
                    tempRequestCode = rsRequestCode;
                }
                tempEnggList += getData("UserID") + ",";
            }

            enggLists.put(tempRequestCode, tempEnggList);
        }
        return enggLists;
    }

    public String getParentAssignee(String ProjID) {
        String retStr = "";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("Select * from OAM_RM_REQUESTMANAGER where RequestCode= '"
                            + ProjID + "'");
            if (rs.next()) {
                retStr = rs.getString("AssignedTo");
            }
        } catch (Exception sqex) {
        }

        return retStr;
    }

    public boolean getFieldValue(String ProjID) {
        return getList(
                "Select * from OAM_RM_REQUESTMANAGER where RequestCode= '"
                + ProjID + "'", "List Of Field Values");
    }

    public void insertAssigneeToRequest(String followupCode, String newAssignee) {
        try {
            Statement stmnt = myConn.createStatement();
            StringTokenizer st = new StringTokenizer(newAssignee, ",");
            String sql = "";
            while (st.hasMoreTokens()) {
                sql = "INSERT INTO OAM_RM_ASSIGNEE VALUES ('" + followupCode
                        + "','" + st.nextToken().toString() + "')";
                stmnt.execute(sql);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * ****************** FOLLOW UPS
     * *************************************************
     */
    /**
     * OAM#112606 When a post reply request is completed with Target Date or
     * Actual Completion Date set, the post reply request still appears in
     * Assigned status.
     *
     * format the date before firing query
     *
     * @author Ramesh Raj Baral
     * @since July 21 2010
     */
    public void addUpdateFollowupRequest(String requestedBy,
            String requestCode, String followupCode, String newAction,
            String newTargetDate, String newActualDate, String newAssignee,
            String status, String isCompleted) {
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute("UPDATE OAM_RM_REQUESTMANAGER SET isCompleted='r' WHERE RequestCode='"
                    + requestCode + "'");
            if (followupCode.equals("")) { // Adding new follow up code
                String newCode = "000" + (getMaxID() + 1);
                String sql = "INSERT INTO OAM_RM_REQUESTMANAGER (RequestCode,RequestingPerson,"
                        + "RequestDate,Requests,TargetCompDate,ActualCompDate,"
                        + "documentCount,parentRequestCode,StatusID,isCompleted) VALUES ('"
                        + newCode
                        + "','"
                        + requestedBy
                        + "',sysdate,'"
                        + newAction.replaceAll("'", "''").trim()
                        + "',"
                        + SQLEncode(newTargetDate)
                        + ","
                        + SQLEncode(newActualDate)
                        + ",0,'"
                        + requestCode
                        + "','" + status + "','n')";
                System.out.print("QueryBean->addUpdateFollowupRequest" + sql);
                stmnt.execute(sql);
                StringTokenizer st = new StringTokenizer(newAssignee, ",");
                while (st.hasMoreTokens()) {
                    sql = "INSERT INTO OAM_RM_ASSIGNEE VALUES ('" + newCode
                            + "','" + st.nextToken().toString() + "')";
                    stmnt.execute(sql);
                }
            } else { // modifying existing follow up code
                String sql = "UPDATE OAM_RM_REQUESTMANAGER SET Requests = '"
                        + newAction.replaceAll("'", "''").trim()
                        + "', TargetCompDate = to_date("
                        + getSQLData(newTargetDate) + ",'mm/dd/yyyy'),"
                        + "ActualCompDate =to_date("
                        + getSQLData(newActualDate) + ",'mm/dd/yyyy')"
                        + ", StatusID='" + status + "', isCompleted='"
                        + isCompleted + "' WHERE RequestCode = '"
                        + followupCode + "'";
                System.out.print("QueryBean->addUpdateFollowupRequest" + sql);
                stmnt.execute(sql);
                sql = "DELETE OAM_RM_ASSIGNEE WHERE RequestCode = '"
                        + followupCode + "'";

                stmnt.execute(sql);
                StringTokenizer st = new StringTokenizer(newAssignee, ",");
                while (st.hasMoreTokens()) {
                    sql = "INSERT INTO OAM_RM_ASSIGNEE VALUES ('"
                            + followupCode + "','" + st.nextToken().toString()
                            + "')";
                    stmnt.execute(sql);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean getListOfFollowUps(String requestCode, String followupCode) {
        strSQL = "SELECT * FROM OAM_RM_REQUESTMANAGER WHERE parentRequestCode='"
                + requestCode + "'";
        if (!followupCode.equals("")) {
            strSQL += " AND RequestCode='" + followupCode + "'";
        }
        return getList(strSQL, "Follow ups");
    }

    private FollowupRequest[] followupList;

    public boolean setFollowups(String requestCode) {
        boolean retValue = false;
        int count = 0;
        int index = 0;
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("select count(RequestCode) AS recCount FROM OAM_RM_REQUESTMANAGER WHERE parentRequestCode='"
                            + requestCode + "'");
            if (rs.next()) {
                count = rs.getInt("recCount");
            }
            rs.close();

            if (count > 0) {
                followupList = new FollowupRequest[count];
                String sql = "SELECT p.RequestCode,p.RequestDate, rp.UserName as "
                        + "RequestingPersonDesc,"
                        + "p.Requests, p.TargetCompDate,"
                        + "p.ActualCompDate,p.RequestingPerson,e.UserName as  assgName FROM OAM_RM_REQUESTMANAGER p "
                        + "LEFT OUTER JOIN (SELECT USERID, USERNAME,Email,OAMstatus FROM USR_USERS) e ON p.assignedTo=e.UserID "
                        + "LEFT OUTER JOIN (SELECT USERID, USERNAME,Email,OAMstatus FROM USR_USERS ) rp ON p.RequestingPerson=rp.UserID "
                        + " WHERE   "
                        + " p.parentRequestCode='"
                        + requestCode
                        + "' ORDER BY p.RequestDate ";
                strSQL = sql;
                
               // System.out.println("sub:"+sql);
                rs = stmnt.executeQuery(sql);

                while (rs.next()) {
                    followupList[index] = new FollowupRequest();
                    followupList[index].setParams(rs.getString("RequestCode"),
                            rs.getString("RequestDate"),
                            rs.getString("RequestingPersonDesc"),
                            rs.getString("Requests"),
                             rs.getString("TargetCompDate"),
                            rs.getString("ActualCompDate"),
                            rs.getString("RequestingPerson"),
                            rs.getString("assgName"));
                    index++;
                }
                rs.close();
                retValue = true;
            }

        } catch (Exception sqex) {
            System.out
                    .println("exception setting request code for getting followups:"
                            + sqex);

        }

        return retValue;

    }

    public FollowupRequest[] getFollowups() {
        return followupList;
    }

    /**
     * ****************** FOLLOW UPS
     * *************************************************
     */
    private String makeDateSQL(String date) {
        if (date.equals("")) {
            return "NULL";
        } else {
            return "'" + date + "'";
        }
    }

    public void cleanup() throws Exception {
    }

    public void request2Concept(String RequestCode) throws Exception {
        try {
            Statement stmnt = myConn.createStatement(
                    ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
            stmnt.execute("sp_Request2Concept '" + RequestCode + "'");
        } catch (SQLException sqlexception) {
            errorStr = "Request 2 Concept transfer error: " + sqlexception;
        }
    }

    public boolean getListOfRequestPhases(String ProductID) throws Exception {
        return getList(
                "SELECT DISTINCT a.RequestPhaseID,a.RequestPhaseDesc,a.PhaseOrder FROM OAM_RM_REQUEST_PHASE a inner join OAM_RM_PRODUCTS b on a.phasetype=b.phasetype or a.phasetype is null where b.productid='"
                + ProductID + "' ORDER BY a.PhaseOrder ASC",
                "PhaseRequests");
    }

    public boolean getListOfRequestInjectedPhases(String ProductID)
            throws Exception {
        return getList(
                "SELECT DISTINCT a.RequestPhaseID,a.RequestPhaseDesc,a.PhaseOrder FROM OAM_RM_INJECTED_PHASE a inner join OAM_RM_PRODUCTS b on a.phasetype=b.phasetype or a.phasetype is null where b.productid='"
                + ProductID + "' ORDER BY a.PhaseOrder ASC",
                "InjectedPhaseRequests");
    }

    private boolean pullAll = true;

    public void setPullReceiversWithAll(boolean x) {
        pullAll = x;
    }

    public boolean getListOfMSGReceivers(int MsgTriggeredFor,
            String PhaseOrRequest, String clientName, String PhaseRequestType,
            String toCC) { // added one more paramter - clientName
        strSQL = "SELECT DISTINCT a.UserID,b.UserName,b.Email "
                + " FROM OAM_RM_MESSAGE_RECEIVER a,usr_Users b, OAM_RM_CLIENTS c "
                + // added one more table ztbl_Clients
                " WHERE MsgTriggeredFor="
                + MsgTriggeredFor
                + " AND a.UserID=b.UserID AND a.clientID in (Select clientID from OAM_RM_CLIENTS where clientName = '"
                + clientName + "') AND PhaseOrRequest='" + PhaseOrRequest; // added
        // two
        // more
        // conditons
        // a.clientID
        // =
        // c.clientID
        // AND
        // c.clientName
        // =
        // clientName

        if (pullAll) {
            strSQL += "' AND PhaseRequestType IN ('','" + PhaseRequestType
                    + "')";
        } else {
            strSQL += "' AND PhaseRequestType='" + PhaseRequestType + "'";
        }

        if (!toCC.equals("")) {
            strSQL += " AND ToCC='" + toCC + "'";
        }
        strSQL += " ORDER BY b.UserName";
        return getList(strSQL, "List of MSG Receivers");
    }

    public boolean getListOfAvailableReceivers(int MsgTriggeredFor,
            String PhaseOrRequest, String PhaseRequestType) {
        strSQL = "SELECT DISTINCT UserID,UserName,Email  FROM "
                + " usr_Users  " + " WHERE OAMStatus=1 AND UserID NOT IN ( "
                + " SELECT DISTINCT UserID FROM OAM_RM_MESSAGE_RECEIVER  "
                + " WHERE MsgTriggeredFor=" + MsgTriggeredFor
                + " AND PhaseOrRequest='" + PhaseOrRequest
                + "' AND PhaseRequestType='" + PhaseRequestType
                + "' ) ORDER BY UserName ";
        return getList(strSQL, "List of MSG Receivers");
    }

    public void deleteMSGReceivers(int MsgTriggeredFor, String PhaseOrRequest,
            String PhaseRequestType) {
        try {
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            strSQL = "DELETE OAM_RM_MESSAGE_RECEIVER WHERE MsgTriggeredFor="
                    + MsgTriggeredFor + " AND PhaseOrRequest='"
                    + PhaseOrRequest + "' AND PhaseRequestType='"
                    + PhaseRequestType + "'";
            stmt.execute(strSQL);
        } catch (Exception e) {
        }
    }

    public void insertMSGReceivers(String userID, int MsgTriggeredFor,
            String PhaseOrRequest, String PhaseRequestType, String toCC) {
        try {
            StringTokenizer st = new StringTokenizer(userID, ",");
            String uid = "";
            strSQL = "INSERT INTO OAM_RM_MESSAGE_RECEIVER (UserID,MsgTriggeredFor,PhaseOrRequest,"
                    + "PhaseRequestType,ToCC) VALUES (?,?,?,?,?) ";
            PreparedStatement ps = myConn.prepareStatement(strSQL);
            while (st.hasMoreTokens()) {
                ps.setString(1, st.nextToken().toString());
                ps.setInt(2, MsgTriggeredFor);
                ps.setString(3, PhaseOrRequest);
                ps.setString(4, PhaseRequestType);
                ps.setString(5, toCC);
                ps.execute();
            }
        } catch (Exception e) {

        }
    }

    // Changed by: Raju Thapa Shrestha, Jan 25,2008
    // Changes : New parameters
    // ProductID,ProductModule,ProductArea,PhaseInject,EstimatedHours,LastUpdatedDate,RequestSource
    // are added in SQl query.
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    public void archiveRequest(String RequestCode, String uid) {
        strSQL = "INSERT INTO OAM_RM_ARCHIVE"
                + "( RequestCode,PKSource,RequestTypeID,RequestingPerson,StatusID,AssignedTo,"
                + "DetectedVersion,ClientID,RequestDate,Requests,"
                + "ActionTaken,TargetCompDate,ActualCompDate,RequestPriority,"
                + "isCompleted,documentCount,parentRequestCode,ExpectedCompDate,PhaseInject,PhaseDetected,"
                + "ActualHours,EstimatedHours,UpdatedBy,LastUpdatedDate,DevCompDate,ProductID,ProjectID,ModuleID,ProductArea,SourceID,"
                + "SeverityID,Impact,DataProviderID,QC,FixedInVersion,requesttitle)"
                + "( SELECT RequestCode,PKSource,RequestTypeID,RequestingPerson,StatusID,AssignedTo,"
                + "DetectedVersion,ClientID,RequestDate,Requests,"
                + "ActionTaken,TargetCompDate,ActualCompDate,RequestPriority,"
                + "isCompleted,documentCount,parentRequestCode,ExpectedCompDate,PhaseInject,PhaseDetected,"
                + "ActualHours,EstimatedHours,'"
                + uid
                + "',SYSDATE,DevCompDate,ProductID,ProjectID,ModuleID,ProductArea,SourceID,"
                + "SeverityID,Impact,DataProviderID,QC,FixedInVersion,requesttitle"
                + " FROM OAM_RM_REQUESTMANAGER WHERE RequestCode='"
                + RequestCode + "')";
        try {
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            stmt.execute(strSQL);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public boolean getListOfPreRequestType() throws Exception {
        return getList(
                "SELECT DISTINCT RequestTypeID,RequestTypeDesc FROM OAM_RM_REQUEST_TYPES where Requesttypecode not in (select Requesttypecode from  tbl_RequestPreAssignmentParameters where RequesttypeCode is not null) ORDER BY RequestTypeDesc",
                "Request Type");
    }

    public boolean getRequestPreAssigned() {
        strSQL = "SELECT a.PKField,a.ActionTaken,a.ThresholdDays,b.Requesttypedesc,c.UserName FROM tbl_RequestPreAssignmentParameters a,OAM_RM_REQUEST_TYPES b,usr_Users c WHERE a.RequestTypeID=b.RequestTypeID and a.AssignedTo=c.Userid ORDER BY a.RequestTypeID";
        return getList(strSQL, "Request PreAssigned");
    }

    public boolean getRequestPreAssigned(String id) {
        strSQL = "SELECT * FROM tbl_RequestPreAssignmentParameters WHERE PKField="
                + id + " ORDER BY RequestTypeID";
        return getList(strSQL, "Request PreAssigned");
    }

    public void addEditDeleteRequestPreAssigned(String PKField,
            String RequestTypeID, String AssignedTo, String RequestStatus,
            String ActionTaken, String ThresholdDays, String Status) {
        try {
            Statement stmnt = myConn.createStatement();

            if (Status.equals("I")) { // Adding new

                String sql = "INSERT INTO tbl_RequestPreAssignmentParameters (RequestTypeID,AssignedTo,RequestStatus,ActionTaken,ThresholdDays) values ("
                        + SQLEncode(RequestTypeID)
                        + ","
                        + SQLEncode(AssignedTo)
                        + ","
                        + SQLEncode(RequestStatus)
                        + ","
                        + SQLEncode(ActionTaken)
                        + ","
                        + SQLEncode(ThresholdDays) + ")";
                stmnt.execute(sql);
            } else { // modifying existing
                String sql = "UPDATE tbl_RequestPreAssignmentParameters SET "
                        + "RequestTypeID=" + SQLEncode(RequestTypeID) + ","
                        + "AssignedTo=" + SQLEncode(AssignedTo) + ","
                        + "RequestStatus=" + SQLEncode(RequestStatus) + ","
                        + "ActionTaken=" + SQLEncode(ActionTaken) + ","
                        + "ThresholdDays=" + SQLEncode(ThresholdDays)
                        + " WHERE PKField =" + PKField;
                stmnt.execute(sql);

            }
        } catch (Exception e) {
        }
    }

    public String DeleteRequestPreAssigned(String id) throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            String sqlString = "DELETE tbl_RequestPreAssignmentParameters WHERE PKfield="
                    + id;
            stmnt.execute(sqlString);
        } catch (SQLException sqlexception) {
            errorStr = "Dlete Request Pre Assigned error  : " + sqlexception;
        }
        return isInserted;
    }

    public boolean getListOfSource() {
        return getList("SELECT * FROM OAM_RM_REQUEST_SOURCE ORDER BY id",
                "SourceDesc");
    }

    public void insertProjectRequestDetail(String RequestID, String SourceID,
            String RequestTitle, String Benefits,
            String Assumptions_Dependencies, String Status) {
        String sql = "";
        try {
            /*
			 * if(Status.equals("I")){ //Adding new
			 * if(!RequestID.trim().equals("")){
			 * sql="DELETE FROM OAM_RM_DETAIL WHERE RequestCode='"
			 * +RequestID+"'"; Statement stmnt1=myConn.createStatement();
			 * stmnt1.execute(sql); }
			 * 
			 * sql =
			 * "INSERT INTO OAM_RM_DETAIL (RequestCode,SourceID,RequestTitle, Benefits,Assumptions_Dependencies) values ('"
			 * + RequestID + "'," + SourceID + "," + SQLEncode(RequestTitle) +
			 * "," + SQLEncode(Benefits) + "," +
			 * SQLEncode(Assumptions_Dependencies) + ")";
			 * 
			 * 
			 * } else
             */
            { // modifying existing
                sql = "UPDATE OAM_RM_REQUESTMANAGER SET "
                        + // "SourceID="+ SourceID + "," +
                        "RequestTitle=" + SQLEncode(RequestTitle) + ","
                        + "ActionTaken=" + SQLEncode(Benefits) + ""
                        + // "Assumptions_Dependencies="+
                        // SQLEncode(Assumptions_Dependencies) + "," +
                        " WHERE RequestCode ='" + RequestID + "'";

            }
            strSQL = sql;

            Statement stmnt = myConn.createStatement();
            stmnt.execute(strSQL);

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    public void updatePMComment(String msgID, String RequestTypeID,
            String RequestID) {
        boolean e = false;
        String sqlString = "{call sp_oam_rm_pm_updatemsg (?,?,?)}";
        try {
            strSQL = sqlString;
            CallableStatement stmt = this.myConn.prepareCall(sqlString);
            stmt.setString(1, msgID);
            stmt.setString(2, RequestTypeID);
            stmt.setString(3, RequestID);

            stmt.execute();
        } catch (SQLException sqlexception) {
            errorStr = "Send comment from PM to RM-->Update msg : "
                    + sqlexception;
            e = true;
        }
    }

    public boolean listRequestDocument(String RequestCode) {

        strSQL = "SELECT p.RequestCode,r.RequestTypeDesc,p.RequestDate,p.RequestingPerson, "
                + "rp.UserName as RequestingPersonDesc,rp.email as ReqPersonEmail,c.ClientName,p.Requests, "
                + "p.ActionTaken,s.StatusDesc, e.UserName AS User_Name,e.email as enggEmail, "
                + "v.VersionDesc, p.TargetCompDate,p.ActualCompDate,p.RequestPriority, "
                + "e.UserID AS EnggID,p.isCompleted, Nvl(y.documentCount,0) AS documentCount, "
                + "p.ExpectedCompDate,x.RequestPhaseDesc,rd.RequestTitle,rd.benefits,rd.assumptions_dependencies,"
                + "so.SourceDesc,ud.DateUpdated,ud.ApprovedBy FROM OAM_RM_REQUESTMANAGER p "
                + "LEFT JOIN usr_Users e ON p.assignedTo=e.UserID "
                + "LEFT JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + "LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID "
                + "LEFT JOIN OAM_RM_REQUEST_TYPES r ON p.RequestTypeID=r.RequestTypeID "
                + "LEFT JOIN usr_Users rp ON p.RequestingPerson=rp.UserID "
                + "LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + "LEFT JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + " LEFT JOIN OAM_RM_INJECTED_PHASE x1 ON x1.RequestPhaseID=p.phaseinject "
                + "LEFT JOIN tbl_requestmanager_detail rd ON rd.RequestCode=p.Requestcode "
                + "LEFT JOIN tbl_source so ON so.id=rd.sourcecode "
                + "LEFT JOIN (SELECT RequestCode,COUNT(*) AS documentCount "
                + "FROM OAM_RM_MOREDOCUMENTS1 GROUP BY RequestCode) y "
                + "ON y.RequestCode=p.RequestCode "
                + "LEFT JOIN (SELECT RequestCode,UserName As ApprovedBy,MAX(LastUpdatedDate) AS DateUpdated FROM OAM_RM_ARCHIVE a LEFT JOIN usr_Users b ON a.UpdatedBy=b.UserID GROUP BY RequestCode,UserName) ud ON ud.RequestCode=p.RequestCode "
                + "WHERE p.requestcode='"
                + RequestCode
                + "' and  rp.OAMStatus=1 "
                + // "AND s.StatusDesc NOT IN ('Completed','Dropped','Pending') "+
                "AND p.parentRequestCode IS NULL ORDER BY p.PKSource DESC ";
        return getList(strSQL, "Request Document");
    }

    /**
     * @param projectID the projectID to set
     */
    public void setProjectID(String projectID) {
        this.projectID = projectID;
    }

    public String getProjectID() {
        System.out.println("ProjectID->" + projectID);
        System.out.println("ProjectID->" + this.projectID);
        return this.projectID;
    }

    /**
     * @return the isInWatchList
     */
    public boolean isInWatchList() {
        return isInWatchList;
    }

    /**
     * @param isInWatchList the isInWatchList to set
     */
    public void setInWatchList(boolean isInWatchList) {
        this.isInWatchList = isInWatchList;
    }

    /**
     * @return the watchListUser
     */
    public String getWatchListUser() {
        return watchListUser;
    }

    /**
     * @param watchListUser the watchListUser to set
     */
    public void setWatchListUser(String watchListUser) {
        this.watchListUser = watchListUser;
    }

    public void updateStatus(String status, String RequestCode) {
        String statusID = "";
        try {
            statusID = getStatusIDByName(status);

            String sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET ";
            sqlStr += " StatusID=" + getSQLData(statusID);
            sqlStr += ",LastUpdatedDate= sysdate ";
            sqlStr += " WHERE RequestCode IN (" + RequestCode + ")";
            // System.out.println(sqlStr);
            Statement stmt = myConn.createStatement();
            stmt.execute(sqlStr);

            StringTokenizer requestList = new StringTokenizer(RequestCode, ",");
            while (requestList.hasMoreTokens()) {
                String requestCode = requestList.nextToken();
                requestCode = removeChar(requestCode, '\'');
                MailingPeople(requestCode, status);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void MailingPeople(String requestCode, String status) {
        try {
            // System.out.println(status);
            Statement stmt = myConn.createStatement();
            String sqlStr = "";
            if (status.equals("Completed")) {
                sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET isCompleted='y' WHERE RequestCode ="
                        + requestCode;
                stmt.execute(sqlStr);
            }
            if (status.equals("Closed")) {
                sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET isCompleted='n' WHERE RequestCode ="
                        + requestCode;
                stmt.execute(sqlStr);
            }
            // System.out.println(sqlStr);
            sqlStr = "Select * from oam_rm_requestmanager where requestcode="
                    + requestCode;
            getList(sqlStr, "");
            String assignedTo = "";
            String requestingPerson = "";
            String clientID = "";
            String projectID = "";
            String productID = "";
            String documentCount = "";
            String statusID = "";

            ResultSet rs = stmt.executeQuery(sqlStr);
            while (rs.next()) {
                assignedTo = rs.getString("assignedTo") == null ? "" : rs
                        .getString("assignedTo");
                requestingPerson = rs.getString("requestingPerson") == null ? ""
                        : rs.getString("requestingPerson");
                clientID = rs.getString("clientID") == null ? "" : rs
                        .getString("clientID");
                projectID = rs.getString("projectID") == null ? "" : rs
                        .getString("projectID");
                productID = rs.getString("productID") == null ? "" : rs
                        .getString("productID");
                documentCount = rs.getString("documentCount") == null ? "" : rs
                        .getString("documentCount");
                statusID = rs.getString("statusID") == null ? "" : rs
                        .getString("statusID");
            }
            archiveRequest(requestCode, requestingPerson);
           // sendMail(requestCode, assignedTo, requestingPerson, statusID,
                //    clientID, projectID, productID, documentCount, "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   

    public String removeChar(String s, char c) {
        String r = "";
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) != c) {
                r += s.charAt(i);
            }
        }
        return r;
    }

    /**
     * Added by Bhanu, July 17 2008
     *
     * @param productName
     * @return list of projectID and projectname under the required product This
     * method receives productName and returns projects associated with the
     * product This method is used in following pages 1. SavePMCommetnToRM.jsp
     * --To list project Name and projectID in combo, used when comment in PM
     * are added as request in RM modified by rsah, Desc: IsClosed variable
     * added, Date: Feb 16, 2009 This method is commented by rsah, it is no more
     * needed.
     */
    /*
	 * public List fetchProjectsForCommentPMToRM(String productName) { ResultSet
	 * rs =null; boolean flag = false; List lsReturn=new ArrayList();
	 * if(productName==null || "".equals(productName)){
	 * productName="Data Analytics"; } strSQL =
	 * " select distinct PROJECTID,PROJECTNAME from oam_rm_projects where   productid = "
	 * + " ( " +
	 * " select productid from oam_rm_products where productName like '%"
	 * +productName+"%' " + " ) and (IsClosed  != 'Y' or IsClosed is null) " +
	 * " order by lower(PROJECTNAME) ";
	 * 
	 * try{ closeRecordSet();
	 * 
	 * 
	 * stmt = myConn.createStatement(); rs = stmt.executeQuery(strSQL);
	 * 
	 * 
	 * while(rs.next()){ HashMap tempHash=new HashMap(); int projectID=0; String
	 * projectName=""; projectID=rs.getInt("PROJECTID");
	 * projectName=rs.getString("PROJECTNAME");
	 * tempHash.put("projectID",projectID);
	 * tempHash.put("projectName",projectName); lsReturn.add(tempHash); }
	 * 
	 * flag = true; } catch(Exception sqlexception){ flag = false;
	 * System.out.println
	 * ("Error in QueryBean.fetchProjectsForCommentPMToRM >1< \n ie \n"
	 * +errorStr); }finally { try{ rs.close(); } catch(Exception sqlexception){
	 * System
	 * .out.println("Error in QueryBean.fetchProjectsForCommentPMToRM >2< \n ie \n"
	 * +sqlexception); }
	 * 
	 * } return lsReturn; }
     */
    /**
     * Added by Ram Kumar Sah, May 21, 2009
     *
     * @param clientid Desc: This method returns the project name and id
     * associated with selected client.
     * @return
     */
    public String getProjectForCommentPMToRM(String clientid) {
        ResultSet rs = null;
        String projectname = "";
        strSQL = "select projectname,projectid from oam_rm_projects where projectid in (select projectid from OAM_DATACLIENT_RELATIONS WHERE CLIENTID='"
                + clientid + "')";
        try {
            if (myConn == null) {
                connectDB();
            }
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);
            while (rs.next()) {
                projectname = rs.getString("Projectname") + "--"
                        + rs.getString("projectid");
            }
        } catch (Exception exception) {
            System.out
                    .println("Error in QueryBean.getProjectForCommentPMToRM()::"
                            + exception);
        }
        return projectname;
    }

    /**
     * Added by Ram Kumar Sah, June 04, 2009 Desc: It will return the assigned
     * NPM ID for the application.
     */
    public String getNPM(String appid) {
        ResultSet rs = null;
        String npm = "";
        strSQL = " select npmid from OAM_PRODUCTIONMANAGER where  APPID='"
                + appid + "' ";
        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);
            while (rs.next()) {
                npm = rs.getString("npmid");
            }
        } catch (SQLException exception) {
            System.out.println("strSQL::" + strSQL);
            System.out.println("Error in QueryBean.getNPM()::" + exception);
        }
        return npm;
    }

    /**
     * Added by Ram Kumar Sah, May 21, 2009
     *
     * @param projectid Desc: This method returns preassigned userid and
     * username for selected project and request type Desc: Method is of no use
     * now as the logic has been changed. Date: June 04, 2009.
     * @return
     */
    /*
	 * public String getAssigneeUsersForPMComments(String projectid,String
	 * requesttypeid) { if(requesttypeid==null ||
	 * requesttypeid.equalsIgnoreCase("") ) { requesttypeid="1"; } ResultSet rs=
	 * null; String usernameandid=""; strSQL=
	 * "select username,userid from usr_users where userid in (select assignedto from OAM_RM_REQUEST_PREASSIGN "
	 * +
	 * "WHERE PROJECTID='"+projectid+"' and REQUESTTYPEID='"+requesttypeid+"' )"
	 * ; try { stmt=myConn.createStatement(); rs=stmt.executeQuery(strSQL);
	 * while (rs.next()) {
	 * usernameandid=rs.getString("username")+"--"+rs.getString("userid"); } }
	 * catch (SQLException exception) {
	 * System.out.println("Error in QueryBean.getAssigneeUsersForPMComments()::"
	 * +exception); } return usernameandid; }
     */
    /**
     * Method Commented by Ram Kumar Sah, May 22, 2009 Desc: This method is no
     * more needed, logic has been changed. Desc : Logic again reverted. June
     * 04, 2009
     *
     * @param productName
     * @return
     */
    public List fetchAssigneeUsersForPMComments(String productName) {
        ResultSet rs = null;
        boolean flag = false;
        List lsReturn = new ArrayList();
        if (productName == null || "".equals(productName)) {
            productName = "Data Analytics";
        }
        strSQL = " select DISTINCT b.userid,b.username,b.loginname FROM tmp_oam_rm_user_product a inner join usr_users b ON a.userid=b.userid where "
                + " b.oamusertypecode IS NOT NULL and a.productid = "
                + " ( "
                + " select productid from oam_rm_products where productName like '%"
                + productName + "%' " + " ) " + " order by lower(b.username) ";

        try {
            closeRecordSet();

            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);

            while (rs.next()) {
                HashMap tempHash = new HashMap();
                int userid = 0;
                String userName = "";
                String loginName = "";
                userid = rs.getInt("userid");
                userName = rs.getString("username");
                loginName = rs.getString("loginname");
                tempHash.put("userID", userid);
                tempHash.put("userName", userName);
                tempHash.put("loginName", loginName);
                lsReturn.add(tempHash);
            }

            flag = true;
        } catch (Exception sqlexception) {
            flag = false;
            System.out
                    .println("Error in QueryBean.fetchProjectsForCommentPMToRM >1< \n ie \n"
                            + errorStr);
        } finally {
            try {
                rs.close();
            } catch (Exception sqlexception) {
                System.out
                        .println("Error in QueryBean.fetchProjectsForCommentPMToRM >2< \n ie \n"
                                + sqlexception);
            }
        }
        return lsReturn;
    }

    public void enterSchedularData(String RequestID, String ClientID,
            String RequestDate, String RequestingPerson, String Requests,
            String RequestTypeID, String RelVersion, String RequestPriority,
            String ProductID, String ProjectID, String ProductModule,
            String ProductArea, String AssignedTo, String RequestPhaseInject,
            String RequestPhase, String EstimatedHours, String RequestSource,
            String RequestSeverity, String DataProviderID, String StatusID,
            String RequestTitle, String SchedularName,
            String SchedularInterval, String SchedularDate) {
        System.out.println("I am inside enter data");
        String jobID = "";
        String sql = "{call sp_oam_rm_schedular (?,?,?,?)}";
        try {
            CallableStatement stmt = myConn.prepareCall(sql);
            stmt.setString(1, SchedularInterval);
            stmt.setString(2, SchedularName);
            stmt.setString(3, SchedularDate);
            stmt.registerOutParameter(4, Types.VARCHAR);
            System.out.println(SchedularInterval + SchedularName
                    + SchedularDate);
            stmt.execute();
            jobID = stmt.getString(4);
            Statement st = myConn.createStatement();
            sql = "insert into oam_rm_schedular values ('" + jobID + "','"
                    + RequestTypeID + "','" + RequestingPerson + "','"
                    + StatusID + "','" + AssignedTo + "','" + ClientID
                    + "',to_date('" + RequestDate + "','mm/dd/yy'),'"
                    + Requests + "','','" + RequestPriority + "','"
                    + RequestSeverity + "','" + EstimatedHours + "','"
                    + RequestPhaseInject + "','" + ProductArea + "','"
                    + ProductModule + "','','" + ProductID + "','" + ProjectID
                    + "','" + RelVersion + "','" + RequestPhase + "','"
                    + RequestSource + "','" + DataProviderID + "','"
                    + RequestTitle + "')";
            // System.out.println(sql);
            st.executeQuery(sql);
        } catch (Exception e) {
            System.out.println("Error from entering schedular. " + e);
        }

    }

    public void updateSchedularData(String SchedularID, String RequestID,
            String ClientID, String RequestDate, String RequestingPerson,
            String Requests, String RequestTypeID, String RelVersion,
            String RequestPriority, String ProductID, String ProjectID,
            String ProductModule, String ProductArea, String AssignedTo,
            String RequestPhaseInject, String RequestPhase,
            String EstimatedHours, String RequestSource,
            String RequestSeverity, String DataProviderID, String StatusID,
            String RequestTitle, String SchedularName,
            String SchedularInterval, String SchedularDate) {
        System.out.println("I am inside update data");
        try {
            Statement st = myConn.createStatement();

            String sql = "update oam_rm_schedular_detail set schedularname='"
                    + SchedularName + "'," + " rungapdays='"
                    + SchedularInterval + "'," + " nextrundate=to_date('"
                    + SchedularDate + "','mm/dd/yyyy hh24:mi:ss')"
                    + " where jobid='" + SchedularID + "'";

            // System.out.println(sql);
            st.executeQuery(sql);

            sql = "update oam_rm_schedular set RequestTypeID='" + RequestTypeID
                    + "'," + " RequestingPerson='" + RequestingPerson + "',"
                    + " StatusID='" + StatusID + "'," + " AssignedTo='"
                    + AssignedTo + "'," + " ClientID='" + ClientID + "',"
                    + " Requests='" + Requests + "'," + " RequestPriority='"
                    + RequestPriority + "'," + " SeverityID='"
                    + RequestSeverity + "'," + " EstimatedHours='"
                    + EstimatedHours + "'," + " PhaseInject='"
                    + RequestPhaseInject + "'," + " ProductArea='"
                    + ProductArea + "'," + " ModuleID='" + ProductModule + "',"
                    + " ProductID='" + ProductID + "'," + " ProjectID='"
                    + ProjectID + "'," + " DetectedVersion='" + RelVersion
                    + "'," + " PhaseDetected='" + RequestPhase + "',"
                    + " SourceID='" + RequestSource + "',"
                    + " DataProviderID='" + DataProviderID + "',"
                    + " RequestTitle='" + RequestTitle + "'" + " where jobid='"
                    + SchedularID + "'";
            System.out.println(sql);
            st.executeQuery(sql);
        } catch (Exception e) {
            System.out.println("Error from entering schedular. " + e);
        }

    }

    public boolean getListOfSchedules() {
        String str = " select * FROM oam_rm_schedular_detail order by jobid ";
        return getList(str, "");
    }

    public boolean deleteSchedule(String alias, String jobID) {
        boolean isDeleted = false;
        try {
            String sql = "delete from oam_rm_schedular_detail where jobID='"
                    + jobID + "'";
            setAlias(alias);
            makeConnection();
            Statement stmt = myConn.createStatement();
            stmt.executeQuery(sql);
            sql = "delete from oam_rm_schedular where jobID='" + jobID + "'";
            stmt.executeQuery(sql);
            isDeleted = true;
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.deleteSchedule"
                                + e);
            }
        }
        return isDeleted;
    }

    /**
     * Added by Bhanu Chalise, Aug 25, 2009 Desc: It will return the assigned
     * NPM ID for the client
     */
    public java.util.List getNPMforDataProviderId(String dataProviderId) {
        ResultSet rs = null;
        java.util.List emailofNpm = new ArrayList();
        strSQL = " select distinct b.userName userName , email email  from OAM_PRODUCTIONMANAGER a, usr_users b "
                + " where "
                + " a.npmid=b.userid "
                + " and npmid is not null "
                + " and  npmid >0 "
                + " and substr(appid, 0,3)='"
                + dataProviderId + "'";

        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);
            while (rs.next()) {
                String userEmail = rs.getString("userName") + "<"
                        + rs.getString("email") + ">";
                emailofNpm.add(userEmail);
            }
        } catch (SQLException exception) {
            System.out.println("Error in QueryBean.getNPMforDataProviderId()::"
                    + exception);
        }
        return emailofNpm;
    }

    public String findLastPhase(String IssuetypeCode) {
        ResultSet rs = null;
        String sqlString = "  SELECT phaseid FROM   oam_cr_template_phases  a, oam_cr_template_issuetype b , oam_cr_issuetype c  WHERE a.templateid =b.templateid AND    b.ISSUETYPEID=c.ISSUETYPEID   AND CRCODE='"
                + IssuetypeCode + "'  ORDER BY PHASEORDER asc  ";

        String retValue = "N/A";

        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(sqlString);
            while (rs.next()) {
                retValue = rs.getString("phaseid");
            }
        } catch (SQLException exception) {
            System.out.println("strSQL::" + strSQL);
            System.out.println("Error in QueryBean.getNPM()::" + exception);
        }
        return retValue;
    }

    public String getApplicationTypeNameInGroupByIdGroupByColon(String idGroupByColon) {
        ResultSet rs = null;
        String sqlString = "select nvl(listagg(APPLICATIONTYPE, ':') within group (order by APPLICATIONTYPEID),'N/A')  AS APPLICATIONTYPE "
                + "from oam_cr_applicationtype WHERE APPLICATIONTYPEID IN ( "
                + "select regexp_substr('" + idGroupByColon + "','[^:]+', 1, level) from dual "
                + "connect by regexp_substr('" + idGroupByColon + "', '[^:]+', 1, level) is not null "
                + ")";
        String retValue = "N/A";

        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(sqlString);
            if (rs.next()) {
                retValue = rs.getString("APPLICATIONTYPE");
            }
        } catch (SQLException exception) {
            System.out.println("strSQL::" + strSQL);
            System.out.println("Error in QueryBean.getApplicationTypeNameInGroupByIdGroupByColon()::" + exception);
        }
        return retValue;
    }

    public boolean isDeferredPhase(String phaseID) {
        ResultSet rs = null;
        boolean isDeferred = false;
        String sqlString = " SELECT Count(phasename) FROM oam_cr_phases"
                + " WHERE Upper(phasename) LIKE upper('%Deferred%') AND phaseid='" + phaseID + "'";

        System.out.println("Deferred SQL:" + sqlString);
        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(sqlString);
            if (rs.next()) {
                if (rs.getInt(1) > 0) {
                    isDeferred = true;
                }
            }
        } catch (SQLException exception) {
            System.out.println("strSQL::" + strSQL);
            System.out.println("Error in QueryBean isDeferredPhase()::" + exception);
        }
        return isDeferred;
    }

    public String getStatus(String phaseID) {
        ResultSet rs = null;
        String statusid = "1";
        String sqlString = "  SELECT statusid FROM  oam_cr_phases  WHERE  phaseid='" + phaseID + "'";

        System.out.println("Status SQL:" + sqlString);
        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(sqlString);
            if (rs.next()) {
                statusid = rs.getString(1);
            }
        } catch (SQLException exception) {
            System.out.println("strSQL::" + strSQL);
            System.out.println("Error in QueryBean getStatus()::" + exception);
        }
        return statusid;
    }

    public String findLastPhaseForCombine(String issueType1, String issueType2) {
        ResultSet rs = null;
        String sqlString = ""
                + "SELECT issuetypeid, "
                + "       a.phaseid, "
                + "       a.phasename, "
                + "       b.phaseorder "
                + "FROM   oam_cr_phases a "
                + "       left join oam_cr_template_phases b "
                + "              ON b.phaseid = a.phaseid "
                + "       left join oam_cr_template_issuetype c "
                + "              ON c.templateid = b.templateid "
                + "WHERE  c.issuetypeid = " + issueType1
                + "UNION ALL "
                + "SELECT issuetypeid, "
                + "       a.phaseid, "
                + "       a.phasename, "
                + "       b.phaseorder "
                + "FROM   oam_cr_phases a "
                + "       left join oam_cr_template_phases b "
                + "              ON b.phaseid = a.phaseid "
                + "       left join oam_cr_template_issuetype c "
                + "              ON c.templateid = b.templateid "
                + "WHERE  c.issuetypeid = " + issueType2
                + "ORDER  BY issuetypeid DESC, "
                + "          phaseorder";

        System.out.println("<<<<>>>>" + sqlString);

        String retValue = "N/A";

        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(sqlString);
            while (rs.next()) {
                retValue = rs.getString("phaseid");
            }
            System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> value " + retValue);
        } catch (SQLException exception) {
            System.out.println("strSQL::" + strSQL);
            System.out.println("Error in QueryBean.getNPM()::" + exception);
        }
        return retValue;
    }

    /**
     * Added by Bhanu Chalise, August 27, 2009 Desc: It will return the assigned
     * NPM IDs for the client.
     */
    public java.util.List getNpmUserIdsForClient(String clientId) {
        ResultSet rs = null;
        java.util.List npm = new java.util.ArrayList();
        strSQL = " select npmid from OAM_PRODUCTIONMANAGER where npmid is not null "
                + " and  substr(appid,0,3)='" + clientId + "' ";
        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);
            while (rs.next()) {
                String tt = rs.getString("npmid");
                npm.add(tt);
            }
        } catch (SQLException exception) {
            System.out.println("Error in QueryBean.getNpmUserIdsForClient()::"
                    + exception);
        }
        return npm;
    }

    /**
     *
     * Description: inserts the new request, its acknowledge users, its document
     * and other details insertNewRequestFromMail <li>insert new request from
     * the requestTemplate</li>
     *
     * @param requestTemplate
     * @return String Author:Ramesh Raj Baral
     * @throws Exception
     * @since Jun 8, 2010
     */
    public String insertNewRequestFromMail(RequestTemplate requestTemplate)
            throws Exception {
        String reqCode = "";
        String sqlString = "{call sp_oam_rm_addemailrequests (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
        try {
            if (myConn == null) {
                System.out.println("connection is null getting new connection");
                this.connectDB();
            }
            CallableStatement callableStatement = myConn.prepareCall(sqlString);
            callableStatement.setString(1, requestTemplate.getRequestingUser()
                    .getUserID());
            String trimmedRequestDesc = requestTemplate.getDescription();
            if (requestTemplate.getDescription() != null
                    && requestTemplate.getDescription().length() > 4000) {
                trimmedRequestDesc = requestTemplate.getDescription()
                        .substring(0, 3500);
            }
            callableStatement.setString(2, trimmedRequestDesc);
            callableStatement.setString(3, requestTemplate.getRequestType());
            callableStatement.setString(4, requestTemplate.getTargetDate());
            callableStatement.setString(5,
                    requestTemplate.getParentRequestCode());
            callableStatement.setString(6,
                    requestTemplate.getStatusID() == null ? ""
                            : requestTemplate.getStatusID());

            callableStatement.setString(7, requestTemplate.isCompleted() ? "y"
                    : "n");
            callableStatement.setString(8, requestTemplate.getClient());
            callableStatement.setString(9, requestTemplate.getProject());
            callableStatement.setString(10, requestTemplate.getProduct());
            callableStatement.setString(
                    11,
                    (requestTemplate.getArea() == null || requestTemplate
                    .getArea().length() < 1) ? "0" : requestTemplate
                            .getArea());
            callableStatement.setString(
                    12,
                    (requestTemplate.getModule() == null || requestTemplate
                    .getModule().length() < 1) ? "0" : requestTemplate
                            .getModule());
            callableStatement.setString(13, requestTemplate.getPriority());
            callableStatement.setString(14, requestTemplate.getRequestingUser()
                    .getUserID());
            callableStatement.setString(15, requestTemplate.getAssingedTo());
            callableStatement.setString(16,
                    requestTemplate.getSeverityID() == null ? "-1"
                            : requestTemplate.getSeverityID());

            callableStatement.setString(
                    17,
                    requestTemplate.getImpact() == null ? "" : requestTemplate
                            .getImpact());
            callableStatement
                    .setString(18,
                            (requestTemplate.getPhaseInjected() == null
                            || requestTemplate.getPhaseInjected()
                            .length() < 1 || requestTemplate
                            .getPhaseInjected()
                            .equalsIgnoreCase("null")) ? "0"
                            : requestTemplate.getPhaseInjected());
            callableStatement
                    .setString(19,
                            (requestTemplate.getPhaseDetected() == null
                            || requestTemplate.getPhaseDetected()
                            .length() < 1 || requestTemplate
                            .getPhaseDetected()
                            .equalsIgnoreCase("null")) ? "0"
                            : requestTemplate.getPhaseDetected());
            callableStatement
                    .setString(
                            20,
                            (requestTemplate.getVersionDetected() == null
                            || requestTemplate.getVersionDetected()
                            .length() < 1 || requestTemplate
                            .getVersionDetected().equalsIgnoreCase(
                                    "null")) ? "0" : requestTemplate
                                    .getVersionDetected());
            String trimmedRequestTitle = requestTemplate.getRequestTitle();
            if (requestTemplate.getRequestTitle() != null
                    && requestTemplate.getRequestTitle().length() > 300) {
                trimmedRequestTitle = requestTemplate.getRequestTitle()
                        .substring(0, 299);
            }
            callableStatement.setString(21, trimmedRequestTitle);
            callableStatement.setString(22, requestTemplate.getRequestEmail()
                    .getMessageID());
            if (requestTemplate.getRequestSource() == null
                    || requestTemplate.getRequestSource().trim().length() < 1) {
                requestTemplate.setRequestSource("2");// for internal source
            }
            callableStatement.setString(23, requestTemplate.getRequestSource());
            callableStatement.setString(24,
                    requestTemplate.getDataProvider() == null ? ""
                            : requestTemplate.getDataProvider());
            callableStatement.registerOutParameter(25, Types.VARCHAR);
            callableStatement.execute();
            reqCode = callableStatement.getString(25);
            requestTemplate.setRequestCode(reqCode);
            System.out.println("new request with code:" + reqCode
                    + "...was inserted");
            /**
             * insert the users to be acknowledged in table
             * OAM_RM_REQUEST_ACKNOWLEDGE
             */
            String sql_insertAckUsers = "INSERT ALL ";
            for (int i = 0; i < requestTemplate.getAcknowledgeUsers().size(); i++) {
                User ackUser = (User) requestTemplate.getAcknowledgeUsers()
                        .get(i);
                sql_insertAckUsers += "INTO OAM_RM_REQUEST_ACKNOWLEDGE (requestid, userid) "
                        + "VALUES ('"
                        + reqCode
                        + "','"
                        + ackUser.getUserID()
                        + "') ";

            }
            sql_insertAckUsers += " select * from dual";
            Statement ackUserStatement = myConn.createStatement();
            ackUserStatement.executeUpdate(sql_insertAckUsers);
            /**
             * if the request has attachment then insert them
             */
            if (requestTemplate.isHasAttachment()
                    && requestTemplate.getAttachments() != null
                    && requestTemplate.getAttachments().size() > 0) {
                PreparedStatement stmt;
                String sql_insertAttachments = "INSERT ALL ";
                for (int j = 0; j < requestTemplate.getAttachments().size(); j++) {
                    sql_insertAttachments += " INTO OAM_RM_MOREDOCUMENTS1(RequestCode,UploadedDocName,UploadedBy,doctype,MsgID,DocumentCode,UploadedOn)"
                            + " VALUES(?,?,?,?,?,1,SYSDATE) ";
                }
                sql_insertAttachments += " select *from dual";
                stmt = myConn.prepareStatement(sql_insertAttachments);
                int statementIndex = 0;
                for (int j = 0; j < requestTemplate.getAttachments().size(); j++) {
                    RequestAttachment requestAttachment = (RequestAttachment) requestTemplate
                            .getAttachments().get(j);
                    stmt.setString(statementIndex + 1,
                            requestTemplate.getRequestCode());
                    stmt.setString(statementIndex + 2, requestAttachment
                            .getFileName().replace('#', '_'));
                    stmt.setString(statementIndex + 3, requestTemplate
                            .getRequestingUser().getUserID());
                    stmt.setString(statementIndex + 4, "others");
                    stmt.setString(statementIndex + 5, "");
                    statementIndex += 5;
                }
                stmt.execute();
            }
        } catch (SQLException sqlEx) {
            System.out.println("Error inserting new request from mail:"
                    + sqlEx.getMessage());
        } finally {

            this.takeDown();
            // dbOracle.disconnect();
        }
        return reqCode;
    }

    /**
     *
     * updateProcessedMailsLog QueryBean
     *
     * @param requestEmail
     * @param updateStatus
     * @return void
     * @author:Ramesh Raj Baral
     * @since:Aug 11, 2010
     *
     */
    public void updateProcessedMailsLog(RequestEmail requestEmail,
            String updateStatus) {
        String sqlString = "{call sp_oam_rm_addemailrequestlog (?,?,?,?,?,?)}";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            CallableStatement callableStatement = myConn.prepareCall(sqlString);
            callableStatement.setString(1, requestEmail.getFromUser()
                    .getUserEmail());
            String trimmedMailBody = requestEmail.getMsgBody();
            String trimmedMailTitle = requestEmail.getMsgSubject();
            if (trimmedMailTitle.length() > 300) {
                trimmedMailTitle = trimmedMailTitle.substring(0, 299);
            }
            if (trimmedMailBody.length() > 3999) {
                trimmedMailBody = trimmedMailBody.substring(0, 3500);
            }
            callableStatement.setString(2, trimmedMailBody);
            callableStatement.setString(3, trimmedMailTitle);
            callableStatement.setString(4, updateStatus);
            callableStatement.setString(5, requestEmail.getMessageID());
            callableStatement.setString(6, "0");
            callableStatement.execute();

        } catch (Exception ex) {
            System.out.println("exception updating processed emails log");
        } finally {
            this.disconnectDB();
        }

    }

    public String getMailRequestCode() {
        return mailRequestCode;
    }

    public void setMailRequestCode(String mailRequestCode) {
        this.mailRequestCode = mailRequestCode;
    }

    /**
     * Description:Given the request code this method returns the available
     * followups of this request ready to be printed on the page
     * getFollowUpRequests queryBeanPM
     *
     * @param requestCode
     * @param userID
     * @return
     * @return String
     * @author:Ramesh Raj Baral
     * @since:Aug 18, 2010
     *
     */
    public String getFollowUpRequests(String requestCode, String userID,
            String isAdmin) {
        FollowupRequest[] followUpArray = null;
        String followupTags = "";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            this.setFollowups(requestCode);
            followUpArray = this.getFollowups();
        } catch (SQLException sqlex) {
            System.out.println("Exception getting followups for request:"
                    + sqlex.getMessage());
        } catch (Exception e) {
            System.out.println("Exception getting followups for:" + requestCode
                    + "..." + e.getMessage());
            e.printStackTrace();
        } finally {
            this.disconnectDB();
        }
        int sn = 1;
        for (int cf = 0; cf < followUpArray.length; cf++) {
            FollowupRequest followUpObj = (FollowupRequest) followUpArray[cf];
            boolean hasEditAccess = followUpObj.getReqPersonID().equals(userID)
                    || isAdmin.equalsIgnoreCase("y")
                    || followUpObj.getAssgPersonID().equals(userID);
            if (followUpObj != null) {
                if (hasEditAccess) {
                    followupTags += "<a onClick=followUp('" + requestCode
                            + "','edit','" + followUpObj.getRequestCode()
                            + "');return false;"
                            + "  style='cursor:hand;color:blue;'"
                            + " title='Double click to edit this follow up'>";

                }
                followupTags += sn + "#&nbsp;";
                followupTags += followUpObj.getRequests();
                followupTags += "<br/>&nbsp;&nbsp;&nbsp;&nbsp;Assg.To:"
                        + followUpObj.getAssgPersonDesc() + "</a>";
                followupTags += "<br/>&nbsp;&nbsp;&nbsp;&nbsp;Status:"
                        + followUpObj.getStatus() + "</a><br><br>";
                sn++;
            }

        }
        return followupTags;
    }

    /**
     * Description:Return the list of docs attached with this request
     * getRequestAttachments QueryBean
     *
     * @param requestCode
     * @return
     * @return Array
     * @author:Ramesh Raj Baral
     * @since:Aug 25, 2010
     *
     */
    public RequestAttachment[] getRequestAttachments(String requestCode) {
        RequestAttachment[] attachmentArray = null;
        List attachmentsList = new ArrayList();
        String sql = "select uploadeddocname,doctype from oam_rm_moredocuments1 where requestcode='"
                + requestCode + "'";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                RequestAttachment attachment = new RequestAttachment();
                attachment.setFileType(rs.getString("doctype"));
                attachment.setFileName(rs.getString("uploadeddocname"));
                attachmentsList.add(attachment);
            }
        } catch (SQLException sqlex) {
            System.out
                    .println("SQLException while getting attachment of a request:"
                            + sqlex.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.takeDown();
        }
        if (attachmentsList != null && attachmentsList.size() > 0) {
            attachmentArray = new RequestAttachment[attachmentsList.size()];
        }
        for (int i = 0; i < attachmentsList.size(); i++) {
            attachmentArray[i] = (RequestAttachment) attachmentsList.get(i);
        }
        return attachmentArray;
    }

    /**
     *
     * getRequestAttachmentDiv QueryBean
     *
     * @param requestCode
     * @return
     * @return String
     * @author:Ramesh Raj Baral
     * @since:Aug 25, 2010
     *
     */
    public String getRequestAttachmentDiv(String requestCode) {
        String divContent = "";
        int otherCount = 0;
        int testSpecCount = 0;
        int reqSpecCount = 0;
        int techSpecCount = 0;
        String otherDocs = "<ul>";
        String testSpecs = "<ul>";
        String techSpecs = "<ul>";
        String reqSpecs = "<ul>";
        RequestAttachment[] attachmentsArray = this
                .getRequestAttachments(requestCode);
        if (attachmentsArray != null && attachmentsArray.length > 0) {
            for (RequestAttachment attachment : attachmentsArray) {
                if (attachment.getFileType().equalsIgnoreCase("others")) {
                    otherCount++;
                    otherDocs += "<li>" + attachment.getFileName() + "</li>";
                } else if (attachment.getFileType().equalsIgnoreCase(
                        "Technical Specs")) {
                    techSpecCount++;
                    techSpecs += "<li>" + attachment.getFileName() + "</li>";
                } else if (attachment.getFileType().equalsIgnoreCase(
                        "Requirement Specs")) {
                    reqSpecCount++;
                    reqSpecs += "<li>" + attachment.getFileName() + "</li>";
                } else if (attachment.getFileType().equalsIgnoreCase(
                        "Test Specs")) {
                    testSpecCount++;
                    testSpecs += "<li>" + attachment.getFileName() + "</li>";
                }
            }
            otherDocs += "</ul>";
            testSpecs += "</ul>";
            techSpecs += "</ul>";
            reqSpecs += "</ul>";
        }
        if (otherCount > 0) {
            divContent += "<ul>Others(" + otherCount + ")";
            divContent += otherDocs;
            divContent += "</ul>";

        }
        if (techSpecCount > 0) {
            divContent += "<ul>Tech Specs(" + techSpecCount + ")";
            divContent += techSpecs;
            divContent += "</ul>";
        }
        if (reqSpecCount > 0) {
            divContent += "<ul>Requirement Specs(" + reqSpecCount + ")";
            divContent += reqSpecs;
            divContent += "</ul>";
        }
        if (testSpecCount > 0) {
            divContent += "<ul>Test Specs(" + testSpecCount + ")";
            divContent += testSpecs;
            divContent += "</ul>";
        }
        return divContent;
    }

    public void setGetFromArchive(boolean value) {
        getFromArchive = value;
    }

    /**
     * This returns list of area for a project
     *
     * @return
     */
    public List getListProductAreasForThisProject(String projectID) {
        List lsArea = new ArrayList();
        String strSql = "SELECT productareaid areaId,productareadesc areaName "
                + " FROM   OAM_RM_project_area_rel a,   OAM_RM_product_area b "
                + " WHERE a.PROJECTAREAID=b.productareaid "
                + " AND a.projectid='" + projectID + "'";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSql);
            while (rs.next()) {
                String areaId = rs.getString("areaId");
                String areaName = rs.getString("areaName");
                lsArea.add(areaId + ":::" + areaName);
            }
        } catch (Exception sqex) {
            System.out
                    .println("Error at QueryBean.getListProductAreasForThisProject"
                            + sqex);
        }

        return lsArea;
    }

    /**
     * This method returns users with with product access and combo of same
     * users for acknowdege in Pm- RM
     *
     * @param ProductID
     * @return users who has access this product
     */
    public List getProductUsersForThisProduct(String ProductID) {
        List productUsersToList = new ArrayList();
        String personObj = "";
        int i = 0;
        String productUserscombo = "<select name='copyToCombo' id='copyToCombo' multiple size=4 ondblclick=\"addSelectedValue('copyToCombo','selected_combo');\" style=\"width:100%\">";
        String strSql = "SELECT UserName, UserID,LoginName FROM usr_Users WHERE "
                + " (UserID IN (SELECT UserID FROM  TMP_OAM_RM_USER_PRODUCT "
                + " WHERE (ProductID = '"
                + ProductID
                + "')and oamusertypecode is not null)) ORDER BY UserName";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSql);
            while (rs.next()) {
                String userId = rs.getString("UserID");
                String userName = rs.getString("UserName");
                String loginName = rs.getString("LoginName");
                productUserscombo += "<OPTION VALUE=\"" + userId + "\" ";
                productUserscombo += ">" + userName + " (" + loginName
                        + ")</OPTION>";
                if (i == 0) {
                    personObj = "" + userId + ";;;" + userName + " ("
                            + loginName + ")";
                } else {
                    personObj += "::::" + userId + ";;;" + userName + " ("
                            + loginName + ")";
                }
                // productUsersToList.add(personObj);
                // Map productUsersTo=new HashMap();

                i++;
            }
        } catch (Exception sqex) {
            System.out
                    .println("Error at QueryBean.getProductUsersForThisProduct"
                            + sqex);
        }
        productUserscombo += "</select>";
        productUsersToList.add(personObj);
        productUsersToList.add(productUserscombo);
        return productUsersToList;
    }

    /**
     * This method returns version combobox
     *
     * @param ProductID
     * @return
     */
    public String getVersionForPMToRM(String ProductID) {

        int i = 0;
        String versionCombo = "<select name='RelVersion' id='RelVersion' style=\"width:100%\" bgcolor=\"#cccccc\" class=\"DataCell\">  "
                + " <OPTION VALUE=\"\" >Please select one</OPTION>";
        String strSql = "SELECT VERSIONID ID, VERSIONDESC LABEL FROM  OAM_RM_PRODUCTVERSION WHERE productid = '"
                + ProductID + "' order by upper(VERSIONDESC)";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSql);
            while (rs.next()) {
                String id = rs.getString("ID");
                String label = rs.getString("LABEL");
                versionCombo += "<OPTION VALUE=\"" + id + "\" ";
                versionCombo += ">" + label + "</OPTION>";

                i++;
            }

        } catch (Exception sqex) {
            System.out.println("Error at QueryBean.getVersionForPMToRM" + sqex);
        }
        versionCombo += "</select>";
        return versionCombo;
    }

    /**
     * This method saves acknowledge users from PM to RM.
     *
     * @param requestID
     * @param ccUsers
     * @return
     */
    public boolean saveRequestAcknowledgeUsersFromPM(String requestID,
            String ccUsers) {
        boolean result = true;
        try {

            Statement stmnt = myConn.createStatement();
            strSQL = "delete  OAM_RM_request_acknowledge where requestID='"
                    + requestID + "'";
            stmnt.execute(strSQL);

            if (!ccUsers.equals("")) {
                StringTokenizer sts = new StringTokenizer(ccUsers, "|");
                while (sts.hasMoreTokens()) {
                    String ccUserID = sts.nextElement().toString().trim();
                    if (ccUserID.length() > 0) {
                        strSQL = "insert into  OAM_RM_request_acknowledge values ('"
                                + requestID + "','" + ccUserID + "')";
                        stmnt.execute(strSQL);
                    }
                }
            }
        } catch (Exception e) {
            result = false;
            System.out
                    .println("Exception while saving the request acknowledge users");
            e.printStackTrace();
        } finally {
            this.closeRecordSet();
        }
        return result;
    }

    /**
     * this will update the time logged by user and return MAP containing
     * updated time
     *
     * @param messageID
     * @param devTime
     * @param qcTime
     * @param userID
     * @return
     */
    public Map updateLog(String messageID, String devTime, String qcTime,
            String wpmTime, String userID) {

        Map hmap = new HashMap();
        float devLog = 0;
        float qcLog = 0;
        float wpmLog = 0;
        if (devTime != null) {
            devLog = Float.parseFloat(devTime);
        }
        if (qcTime != null) {
            qcLog = Float.parseFloat(qcTime);
        }

        if (wpmTime != null) {
            wpmLog = Float.parseFloat(wpmTime);
        }
        boolean isUpdated = false;
        Statement stmnt = null;
        String strSQL = "insert into oam_cr_effortlogs(userid,messageid,devtime,qctime,wpmtime,loggedon) values('"
                + userID
                + "', '"
                + messageID
                + "', "
                + devLog
                + ", "
                + qcLog
                + "," + wpmLog + ",sysdate)";
        try {
            if (myConn == null) {

                this.connectDB();
            }
            stmnt = myConn.createStatement();
            stmnt.execute(strSQL);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.takeDown();
        }
        hmap = getLoggedHours(messageID, userID);
        return hmap;
    }

    /**
     * getting MAP of logged time by a user in a particlar requestID
     *
     * @param messageID
     * @param userID
     * @return
     */
    public Map getLoggedHours(String messageID, String userID) {
        Map hmap = new HashMap();
        Statement stmnt = null;
        String selectSQL = ""
                + "SELECT Nvl(Round(SUM(devtime), 2), 0) AS totaldev, "
                + "       Nvl(Round(SUM(qctime), 2), 0)  AS totalqc, "
                + "       Nvl(Round(SUM(wpmtime), 2), 0)  AS totalwpm "
                + "FROM   oam_cr_effortlogs " + "WHERE 1=1 and  messageid = '"
                + messageID + "'";
        try {
            if (myConn == null) {
                try {
                    this.connectDB();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            stmnt = myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(selectSQL);
            while (rs.next()) {
                hmap.put(("totalDevLog"), rs.getString("totaldev"));
                hmap.put(("totalQcLog"), rs.getString("totalqc"));
                hmap.put(("totalWpmLog"), rs.getString("totalwpm"));

            }

            selectSQL += " and userid ='" + userID + "'";

            stmnt = myConn.createStatement();
            rs = stmnt.executeQuery(selectSQL);
            while (rs.next()) {
                hmap.put(("indDevLog"), rs.getString("totaldev"));
                hmap.put(("indQcLog"), rs.getString("totalqc"));
                hmap.put(("indWpmLog"), rs.getString("totalwpm"));

            }
        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            this.takeDown();
        }
        return hmap;
    }

    public Vector getNPMAndCLeadAPPId(String appID) {
        ResultSet rs = null;
        Vector emailofNpmCL = new Vector();
        strSQL = " select distinct b.userName userName , email email  from OAM_PRODUCTIONMANAGER a, usr_users b "
                + " where "
                + " a.npmid=b.userid "
                + " and npmid is not null "
                + " and  npmid >0 " + " and appid='" + appID + "'";

        try {
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);
            while (rs.next()) {
                String userEmail = rs.getString("userName") + "<"
                        + rs.getString("email") + ">";
                emailofNpmCL.add(userEmail);
            }

            String sql = " select distinct b.userName userName , email email  from OAM_PRODUCTIONMANAGER a, usr_users b "
                    + " where "
                    + " a.BUSINESSINTID=b.userid "
                    + " and BUSINESSINTID is not null "
                    + " and  BUSINESSINTID >0 " + " and appid='" + appID + "'";

            stmt = myConn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String userEmail = rs.getString("userName") + "<"
                        + rs.getString("email") + ">";
                emailofNpmCL.add(userEmail);
            }

        } catch (SQLException exception) {
            System.out.println("Error in QueryBean.getNPMforDataProviderId()::"
                    + exception);
        }

        return emailofNpmCL;
    }

    public String getPayerName(String payerid) {
        ResultSet rs = null;
        String resultStr = "";

        strSQL = "SELECT  DISTINCT vhpayorname FROM hr_global_vhpayors "
                + " WHERE " + " vhpayorid ='" + payerid + "' ";
        // System.out.println(" getProjectForDailyHuddle -> sql is "+strSQL);
        try {
            if (myConn == null) {
                connectDB();
            }
            stmt = myConn.createStatement();
            rs = stmt.executeQuery(strSQL);
            if (rs.next()) {
                resultStr = rs.getString("VHPAYORNAME");
            }

        } catch (Exception exception) {
            System.out
                    .println("Error in QueryBean.getProjectForCommentPMToRM()::"
                            + exception);
        }
        return resultStr;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getNpm() {
        return npm;
    }

}
