package com.d2hs.soam.rm;

import java.util.Date;

public class DocDTO {
	private int documentCode;
	private String requestCode;
	private String uploadedDocName;
	private byte[] uploadedDoc;
	private Date uploadedOn;
	private String docType;
	private String msgID;
	private String tempLoc;

	public int getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(int documentCode) {
		this.documentCode = documentCode;
	}

	public String getRequestCode() {
		return requestCode;
	}

	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}

	public String getUploadedDocName() {
		return uploadedDocName;
	}

	public void setUploadedDocName(String uploadedDocName) {
		this.uploadedDocName = uploadedDocName;
	}

	public byte[] getUploadedDoc() {
		return uploadedDoc;
	}

	public void setUploadedDoc(byte[] uploadedDoc) {
		this.uploadedDoc = uploadedDoc;
	}

	public Date getUploadedOn() {
		return uploadedOn;
	}

	public void setUploadedOn(Date uploadedOn) {
		this.uploadedOn = uploadedOn;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getMsgID() {
		return msgID;
	}

	public void setMsgID(String msgID) {
		this.msgID = msgID;
	}

	public void setTempLoc(String tempLoc) {
		this.tempLoc = tempLoc;
	}

	public String getTempLoc() {
		return tempLoc;
	}

}
