package com.d2hs.soam.pm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.directwebremoting.util.Logger;

import com.d2hawkeye.util.Constants;
import com.d2hs.soam.RequestBean;

public class UserRoleManager extends RequestBean {

    private static Logger logger = Logger
            .getLogger(UserRoleManager.class);
    private String strFilters = "";

    /**
     * @Description : Filter for Project Templates
     * @param fTemplateId
     * @param fTemplateName
     * @param fTemplateDesc
     * @param fIssueTypeId
     * @param fIssueTypeName
     */
    public void filterProjectTemplates(String fIssueTypeId) {
        if (!fIssueTypeId.equals("")) {
            strFilters += " AND b.issuetypeid LIKE '%"
                    + fIssueTypeId.replaceAll("'", "''").trim() + "%'";
        }
    }

    public void setProjectTempId(String fTemplateId) {
        if (!fTemplateId.equals("")) {
            strFilters += " AND a.issuetypeid LIKE '"
                    + fTemplateId.replaceAll("'", "''").trim() + "'";
        }
    }

    /**
     * @Description : Returns Project Templates with Issue Types
     * @return
     */
    public boolean getTeam() {
        boolean result = false;
        strSQL = "SELECT d.id, "
                + "       d.name, "
                + "       d.application, "
                + "       Listagg (username, '; ') "
                + "         within GROUP (ORDER BY d.id) AS manager , "
                + "         Nvl(e.name,'NONE')  AS ParentTeam\n"
                + "FROM   (SELECT id,  "
                + "               name,                                 "
                + "               application,  "
                + "               b.userid,  "
                + "               c.username, "
                + "               a.parent_team AS pid  "
                + "        FROM   oam_cr_team a  "
                + "               left join oam_cr_manager_role b  "
                + "                      ON a.id = b.teamid  "
                + "               left join usr_users c  "
                + "                      ON b.userid = c.userid) d "
                + "               left JOIN oam_cr_team e "
                + "                      ON e.id = d.pid         "
                + "GROUP  BY d.id,  "
                + "          d.name,  "
                + "          d.application, "
                + "          e.name  "
                + "ORDER  BY d.name";

        //strSQL += strFilters;
        logger.info("Query to getProjectTemplatesWithRequestType " + strSQL);
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (SQLException e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getProjectTemplatesWithRequestType()<- "
                    + strSQL, e);
        }
        return result;
    }

    public boolean getTeam(String id) {
        boolean result = false;
        strSQL = "SELECT ID, NAME, APPLICATION, PARENT_TEAM FROM OAM_CR_TEAM where id=" + id;
        //strSQL += strFilters;
        System.out.println("strSQL:" + strSQL);
        logger.info("Query to getProjectTemplatesWithRequestType " + strSQL);
        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (SQLException e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getProjectTemplatesWithRequestType()<- "
                    + strSQL, e);
        }
        return result;
    }

    public boolean getTeamS() {
        boolean result = false;
        strSQL = "SELECT ID, NAME, APPLICATION, PARENT_TEAM FROM OAM_CR_TEAM";
        //strSQL += strFilters;
        System.out.println("strSQL:" + strSQL);
        logger.info("Query to getProjectTemplatesWithRequestType " + strSQL);
        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (SQLException e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getProjectTemplatesWithRequestType()<- "
                    + strSQL, e);
        }
        return result;
    }

    /**
     * @Description : Gets list of projects that are not assigned to any project
     * templates
     * @param templateId
     * @return
     */
    public boolean getNotAssignedProjectListForTemplate(String templateId) {
        boolean result = false;
        strSQL = "SELECT username, userid FROM usr_users WHERE oamstatus=1 ";
        if (templateId != "") {
            strSQL += "AND userid NOT IN (SELECT userid FROM oam_cr_user_role  WHERE teamid = " + templateId + ") ";
        }

        strSQL += " ORDER BY username ";
        logger.info("Query to get assigned user list for template is >>>>"
                + strSQL);

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getNotAssignedProjectListForTemplate("
                    + templateId + ")<- " + strSQL, e);

        }
        return result;
    }

    public boolean getNotAssignedManagerListForTemplate(String templateId) {
        boolean result = false;
        strSQL = "SELECT username, userid FROM usr_users WHERE oamstatus=1 ";
        if (templateId != "") {
            strSQL += "AND userid NOT IN (SELECT userid FROM oam_cr_manager_role  WHERE teamid = " + templateId + ") ";
        }

        if (templateId != "") {
            strSQL += "AND userid IN (SELECT userid FROM oam_cr_user_role  WHERE teamid = " + templateId + ") ";
        }

        strSQL += " ORDER BY username ";
        logger.info("Query to get assigned user list for template is >>>>"
                + strSQL);

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getNotAssignedProjectListForTemplate("
                    + templateId + ")<- " + strSQL, e);

        }
        return result;
    }

    /**
     * @Description : Gets projects for the given template
     * @param templateId
     * @return
     */
    public boolean getAssignedProjectListForTemplate(String templateId) {
        boolean result = false;
        strSQL = "SELECT username, userid FROM usr_users WHERE oamstatus=1 ";
        if (templateId != "") {
            strSQL += "AND userid  IN (SELECT userid FROM oam_cr_user_role  WHERE teamid = " + templateId + ") ";
        }

        strSQL += " ORDER BY username ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getAssignedProjectListForTemplate("
                    + templateId + ")<- " + strSQL, e);
        }
        return result;
    }

    public boolean getAssignedManagerListForTemplate(String templateId) {
        boolean result = false;
        strSQL = "SELECT username, userid FROM usr_users WHERE oamstatus=1 ";
        if (templateId != "") {
            strSQL += "AND userid  IN (SELECT userid FROM oam_cr_manager_role  WHERE teamid = " + templateId + ") ";
        }

        strSQL += " ORDER BY username ";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getAssignedProjectListForTemplate("
                    + templateId + ")<- " + strSQL, e);
        }
        return result;
    }

    public boolean getIssueTypes() {
        boolean result = false;
        strSQL = "select * from " + Constants.OAM_CR_ISSUETYPE
                + " where 1=1 and issuetypeid not in  ( SELECT DISTINCT issuetypeid from oam_cr_approved_users ) order by ISSUETYPEID";
        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            System.out
                    .println("\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getIssueType()<- "
                            + strSQL);
            e.printStackTrace();
        }
        return result;
    }

    /**
     * @Description : Checking is a Issue Type is alread
     * @param issueTypeId
     * @return
     * @throws SQLException
     */
    public boolean checkDuplicate(String name)
            throws SQLException {
        boolean templateFound = false;
        strSQL = "Select count(*) n from oam_cr_team where name= '" + name + "'";
        System.out.println("strSQL:" + strSQL);
        stmt = myConn.createStatement();
        myRS = stmt.executeQuery(strSQL);
        myRS.next();
        int count = Integer.parseInt(myRS.getString("n".trim()));
        if (count > 0) {
            templateFound = true;
        }
        closeStatement(stmt);
        return templateFound;
    }

    public boolean checkDuplicate(String name, String application)
            throws SQLException {
        boolean templateFound = false;
        strSQL = "Select count(*) n from oam_cr_team where name= '" + name + "' and application='" + application + "'";
        System.out.println("strSQL:" + strSQL);
        stmt = myConn.createStatement();
        myRS = stmt.executeQuery(strSQL);
        myRS.next();
        int count = Integer.parseInt(myRS.getString("n".trim()));
        if (count > 0) {
            templateFound = true;
        }
        closeStatement(stmt);
        return templateFound;
    }

    /**
     * @Description : Adds template information
     * @param templateName
     * @param templateDesc
     * @param userId
     * @throws SQLException
     */
    public void addProjectTemplate(String templateName, String templateDesc,
            String userId) throws SQLException {
        strSQL = "insert into  OAM_CR_APPROVED_USERS (issuetypeid,userid)"
                + " VALUES (" + SQLEncode(templateName) + ","
                + SQLEncode(templateDesc) + "," + "'" + userId + "',"
                + "sysdate" + "," + "'N'" + " )";
        stmt = myConn.createStatement();
        stmt.execute(strSQL);
        closeStatement(stmt);
    }

    public void addTeam(String templateName, String Application, String parentTeam) throws SQLException {
        strSQL = "insert into  oam_cr_team (name, application, parent_team)"
                + " VALUES (" + SQLEncode(templateName) + "," + SQLEncode(Application) + "," + SQLEncode(parentTeam) + ")";
        System.out.println("strSQL:" + strSQL);
        stmt = myConn.createStatement();
        stmt.execute(strSQL);
        closeStatement(stmt);
    }

    public void editTeam(String id, String templateName, String parentTeam) throws SQLException {
        strSQL = "update oam_cr_team set name=" + SQLEncode(templateName) + ",parent_team=" + parentTeam + " where id=" + id;
        System.out.println("strSQL:" + strSQL);
        stmt = myConn.createStatement();
        stmt.execute(strSQL);
        closeStatement(stmt);
    }

    /**
     * @Description : Updates project templates and projects
     * @param templateId
     * @param templateName
     * @param templateDesc
     * @param phaseIdList
     * @return
     */
    public boolean updateTemplateAndProjects(String templateId,
            String templateName, String templateDesc, String[] projectIdList) {
        boolean isUpdated = false;
        try {
            //updateProjectTemplate(templateId, templateName, templateDesc);
            //deleteProjectsFromTemplate(templateId);
            insertProjectsIntoTemplate(templateId, projectIdList);
            isUpdated = true;
        } catch (SQLException e) {
            e.printStackTrace();
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/pm/TemplateManager.java]->"
                    + "updateTemplateAndPhases(" + templateId + ","
                    + templateName + "," + templateDesc + ","
                    + projectIdList.length + ")<- " + strSQL, e);
        }

        return isUpdated;
    }

    /**
     * @Description : Deletes projects from given template
     * @param templateId
     * @throws SQLException
     */
    public void deleteTeam(String templateId)
            throws SQLException {
        strSQL = "DELETE FROM oam_cr_team WHERE id = " + templateId + "";
        stmt = myConn.createStatement();
        stmt.execute(strSQL);
        closeStatement(stmt);
    }

    /**
     * @Description : Inserts projects for the give template
     * @param templateId
     * @param phaseIdList
     * @throws SQLException
     */
    public void insertProjectsIntoTemplate(String templateId,
            String[] projectIdList) throws SQLException {
        stmt = myConn.createStatement();
        for (int i = 0; i < projectIdList.length; i++) {
            strSQL = " INSERT INTO oam_cr_approved_users (issuetypeid,userid) " + " VALUES ("
                    + templateId + "," + projectIdList[i] + ")";
            System.out.println("INSERT:" + strSQL);
            stmt.addBatch(strSQL);
        }
        stmt.executeBatch();
        closeStatement(stmt);
    }

    public void closeStatement(Statement stmt) throws SQLException {
        if (stmt != null) {
            stmt.close();
        }
    }

    public String addEditUsersToTeam(String teamId, String[] users, String Application) throws SQLException {
        stmt = myConn.createStatement();
        stmt.execute("Delete from oam_cr_user_role where teamid=" + teamId);
        closeStatement(stmt);

//        stmt = myConn.createStatement();
//        for (int i = 0; i < users.length; i++) {
//            strSQL = " Delete from oam_cr_user_role where teamid IN (SELECT id FROM oam_cr_team WHERE application='" + Application + "') AND userid =" + users[i];
//            System.out.println("DELETE:" + strSQL);
//            stmt.addBatch(strSQL);
//        }
//        stmt.executeBatch();
//        closeStatement(stmt);


        stmt = myConn.createStatement();
        for (int i = 0; i < users.length; i++) {
            strSQL = " insert into oam_cr_user_role (teamid,userid) " + " VALUES ("
                    + teamId + "," + users[i] + ")";
            System.out.println("INSERT:" + strSQL);
            stmt.addBatch(strSQL);
        }
        stmt.executeBatch();
        closeStatement(stmt);
        return "";
    }

    public String addEditManagersToTeam(String teamId, String[] users) throws SQLException {
        stmt = myConn.createStatement();
        stmt.execute("Delete from oam_cr_manager_role where teamid=" + teamId);
        closeStatement(stmt);

//        stmt = myConn.createStatement();
//        for (int i = 0; i < users.length; i++) {
//            strSQL = " Delete from oam_cr_manager_role where userid =" + users[i];
//            System.out.println("DELETE:" + strSQL);
//            stmt.addBatch(strSQL);
//        }
//        stmt.executeBatch();
//        closeStatement(stmt);


        stmt = myConn.createStatement();
        for (int i = 0; i < users.length; i++) {
            strSQL = " insert into oam_cr_manager_role (teamid,userid) " + " VALUES ("
                    + teamId + "," + users[i] + ")";
            System.out.println("INSERT:" + strSQL);
            stmt.addBatch(strSQL);
        }
        stmt.executeBatch();
        closeStatement(stmt);
        return "";
    }

    public boolean getNotAssignedPhaseListForTemplate(String templateId) {
        boolean result = false;
        strSQL = " SELECT * FROM (  SELECT To_Char(phaseid) AS phaseid,'ICE-'||phasename AS phasename FROM  oam_cr_phases  WHERE phaseid IN (SELECT phaseid From oam_cr_template_phases) AND ISDELETED='N' "
                + ")";
        if (templateId != "") {
            strSQL += " where phaseid NOT IN (SELECT phaseid FROM oam_cr_role_phase  WHERE teamid = " + templateId + ") ";
        }

        strSQL += " ORDER BY 2 ";
        logger.info("Query to get assigned phase list for template is >>>>"
                + strSQL);

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getNotAssignedPhaseListForTemplate("
                    + templateId + ")<- " + strSQL, e);

        }
        return result;
    }

    public boolean getAssignedPhaseListForTemplate(String templateId) {
        boolean result = false;
        strSQL = " SELECT * FROM (  SELECT To_Char(phaseid) AS phaseid,'ICE-'||phasename AS phasename FROM  oam_cr_phases  WHERE phaseid IN (SELECT phaseid From oam_cr_template_phases) AND ISDELETED='N' "
                + " )";
        if (templateId != "") {
            strSQL += " where phaseid  IN (SELECT phaseid FROM oam_cr_role_phase  WHERE teamid = " + templateId + ") ";
        }

        strSQL += " ORDER BY 2 ";
        logger.info("Query to get assigned phase list for template is >>>>"
                + strSQL);

        try {
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            result = true;
        } catch (Exception e) {
            logger.error(
                    "\nError:[default-war/com/d2hs/soam/tmp/TemplateManager.java]->getNotAssignedPhaseListForTemplate("
                    + templateId + ")<- " + strSQL, e);

        }
        return result;
    }

    public String addEditPhasesToTeam(String teamId, String[] phases) throws SQLException {
        stmt = myConn.createStatement();
        stmt.execute("Delete from oam_cr_role_phase where teamid=" + teamId);
        closeStatement(stmt);

        stmt = myConn.createStatement();
        for (int i = 0; i < phases.length; i++) {
            strSQL = " insert into oam_cr_role_phase (teamid,phaseid) " + " VALUES ("
                    + teamId + ",'" + phases[i] + "')";
            System.out.println("INSERT:" + strSQL);
            stmt.addBatch(strSQL);
        }
        stmt.executeBatch();
        closeStatement(stmt);
        return "";
    }

}
