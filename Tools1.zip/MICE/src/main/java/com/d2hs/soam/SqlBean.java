/**
 * ***********************************************************************************
 *
 * File       : sqlBean.java
 * Created by : Prajwal Raj Hada
 *
 * Functionality:
 *
 * Modifications:
 *
 *
 ************************************************************************************
 */
package com.d2hs.soam;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.d2hs.soam.conn.ConnectionParameters;
import com.d2hs.soam.conn.DBPoolManager;
//import javax.servlet.page

public class SqlBean {

    private static final int MAX_TRY_COUNT = 5;
    protected Connection myConn;
    //protected Connection lblConn;
    protected ResultSet myRS = null;
    protected int pageSize = 100;
    protected String strSQL = "";
    private String strDatabaseAlias = null;           // for connection pool
    protected String dbDriver = "";
    protected String dbConnURL = "";
    String XMLfilename = "";
    private String historyDB = "";
    protected String rulesDB = "";
    public static int connCount = 0;

    String alias = "";

    public SqlBean() {
    }

    public String getDriver() {
        return dbDriver;
    }

    public String getConnURL() {
        return dbConnURL;
    }


    /*public void makeConnection() throws Exception{
		Class.forName(dbDriver);
        try{
		    myConn = DriverManager.getConnection (dbConnURL, dbUser, dbPassword);
        } catch(Exception se){
            System.out.print(se);
            se.printStackTrace();
        }
	}*/
    /**
     * This simply calls the getConnection method of DBPoolManager and returns a
     * connection object Author: Anjana Date: Apr 03, 2007
     */
    public void makeConnection() throws Exception {
        //System.out.println("\nGetting connection from connection pool\n");

        DBPoolManager dbpm = DBPoolManager.getInstance();
        myConn = dbpm.getConnection(this.alias); //Alias = domain
        connCount++;
        System.out.println("Connection count is: " + connCount);
    }

    /*public void getConnection() throws Exception{  // This is simply the old makeConnection that makes connection the conventional way
		Class.forName(dbDriver);
        try{
		    myConn = DriverManager.getConnection (dbConnURL, dbUser, dbPassword);
        } catch(Exception se){
            System.out.print(se);
            se.printStackTrace();
        }
	} */
    public void setDataBaseName(String x) {
        this.alias = x;
    }

    public void setXMLfilename(String s) {
        XMLfilename = s + "\\WEB-INF\\classes\\ConnectionPoolManager.xml";
    }

    public void setDBConnection(String drv, String strConn) {
        this.dbDriver = drv;
        this.dbConnURL = strConn;
    }

    public void setDBConnection(String alias) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File(XMLfilename));

            Element svgElement = doc.getDocumentElement();
            NodeList nodeList = svgElement.getElementsByTagName("Alias");
            String url = "";
            String username = "";
            String password = "";

            for (int i = 0; i < nodeList.getLength(); i++) {
                Element textElement = (Element) nodeList.item(i);

                if (textElement.getAttribute("name").equals(alias)) {
                    dbDriver = textElement.getAttribute("driver");
                    url = textElement.getAttribute("url");
                    dbUser = textElement.getAttribute("username");
                    dbPassword = textElement.getAttribute("password");
                    dbConnURL = url;//+ ";User=" + username + ";Password=" + password;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDBInfo(String alias, String database, String userName, String password) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File(XMLfilename));

            Element svgElement = doc.getDocumentElement();
            NodeList nodeList = svgElement.getElementsByTagName("Alias");
            String url = "";

            for (int i = 0; i < nodeList.getLength(); i++) {
                Element textElement = (Element) nodeList.item(i);

                if (textElement.getAttribute("name").equals(alias)) {
                    dbDriver = textElement.getAttribute("driver");
                    url = textElement.getAttribute("url");
                    this.dbUser = userName;
                    this.dbPassword = password;
                    dbConnURL = url;//+database+";User=" + userName + ";Password=" + password;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cleanup() throws Exception {
        takeDown();
    }

    public  void takeDown() {
        {
            try {

                if (myRS != null) {
                    myRS.close();
                }
                myRS = null;
                if (myConn != null) {
                    myConn.close();
                    connCount--;
                    System.out.println("From TAKE DOWN: Connection is " + connCount);
                    myConn = null;
                }

            } catch (Exception e) {
                System.out.print("Unable to take down" + e);
            }
        }
    }

    public String getNextOrder(String selorderField, String field, String order) {
        if ((field.indexOf(selorderField) >= 0) && order.equals("DESC")) {
            return "ASC";
        } else {
            return ("DESC");
        }
    }

    public String executeQuerygetParameter(String fld) {
        String tmp = new String();
        try {
            tmp = myRS.getString(fld);
            tmp = (tmp == null) ? "" : tmp;
            //if(fld.compareToIgnoreCase("memberID")==0){
            //	if(this.encryptMemberID.equals("y"))
            //	tmp=d2Hawkeye.v351.MemEncode.encode(tmp);
            //}
        } catch (NullPointerException npd) {
            tmp = " ";
        } catch (Exception ex) {
            System.out.println("Exp getParameter(): " + fld + ex.toString());
            tmp = "";
        }
        return removeUnwantedCharacters(tmp);
    }

    public static String removeUnwantedCharacters(String p) {
        if (p == null || "".equals(p.trim())) {
            return "";
        }
        int pLen = p.length();
        int count = 0;
        char c;
        StringBuffer sb = new StringBuffer(pLen + 1);
        for (count = 0; count < pLen; count++) {
            c = p.charAt(count);
            switch (c) {
                case '\r':
                    sb.append("");
                    break;
                case '\t':
                    sb.append("");
                    break;
                case '\f':
                    sb.append("");
                    break;
                case '\n':
                    sb.append("");
                    break;
                default:
                    sb.append(c);
            }
        }
        return sb.toString();
    }

    public int getPageSize() {
        return this.pageSize;
    }

    String dataBaseName = "";
    String dbServer = "";
    String dbPassword = "";
    String dbUser = "";
    String isValid = "";
    String sessionUserID = "";
    String sessionCompanyID = "";
    String sessionUserName = "";
    String sessionFrontID = "";
    String sessionClientName = "";
    String sessionClientID = "";
    String sessionLogSeqNo = "";
    ConnectionParameters connParam = null;

    public String getDbUser() {
        return dbUser;
    }

    public String getDbPassword() {
        return dbPassword;
    }

    /**
     * Initializes its value of connParam to the passed instance
     *
     * @param cp
     */
    public void setDBParam(ConnectionParameters cp) {
        connParam = cp;
    }

    Boolean sessionHasFullAccess = null;

    public void setSessionParameters(HttpSession session) {

        this.alias = (String) (session.getAttribute("DomainID"));
        /*this.dataBaseName = (String) session.getAttribute("DataBaseName");
        this.dbServer     = (String) session.getAttribute("DatabaseServer");
        this.isValid      = (String) session.getAttribute("isValid");
        this.dbUser       = (String) session.getAttribute("dbUser");
        this.dbPassword   = (String) session.getAttribute("dbPassword");

        this.setPageSize(session);
		this.strDatabaseAlias = this.dbServer+"->"+this.dataBaseName;

        this.sessionUserID    = (String) session.getAttribute("UserID");
        this.sessionCompanyID = (String) session.getAttribute("CompanyID");
        this.sessionUserName = (String) session.getAttribute("User");
        this.sessionFrontID = (String) session.getAttribute("HawkeyeFrontID");
        this.sessionClientName = (String) session.getAttribute("ClientName");
        this.sessionClientID = (String) session.getAttribute("ClientID");
        this.sessionLogSeqNo = (String) session.getAttribute("LoginSeqNo");

		this.dbDriver = (String) session.getAttribute("dbDriver");
		this.dbConnURL = (String) session.getAttribute("dbConnURL");

		this.sessionHasFullAccess	= (Boolean) session.getAttribute("hasFullAccess");
		if(this.sessionHasFullAccess==null){
			this.sessionHasFullAccess	= new Boolean(false);
		} */

    }

    public void setPageSize(HttpSession psize) {
        String strPageSize = (String) (psize.getAttribute("RecPerPage"));
        try {
            if (strPageSize != null) {
                this.pageSize = Integer.valueOf(strPageSize).intValue();
            }
        } catch (Exception e) {
        }
    }

    public void setPageSize(int psize) {
        this.pageSize = psize;
    }

    public String getTime() {
        return "";
    }

    public String getMetaTags() {
        return "";
    }

    public void connectDB() throws Exception {
        setSuperDBconnection("RequestManager->SuperDomainDataBase");
        //connCount++;
    }

    public void setSuperDBconnection(String Alias) {
        // try {
        DBPoolManager dbpm = DBPoolManager.getInstance();
        myConn = dbpm.getConnection(Alias);
        connCount++;
        System.out.println("Connection count for super: " + connCount);

        // Add it to the connectionProperties map
        /*{
                ConnectionParameters conParam = new ConnectionParameters();
                DocumentBuilderFactory dbf =	DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(new File(XMLfilename));

                Element svgElement	= doc.getDocumentElement();
                NodeList nodeList 	= svgElement.getElementsByTagName("Alias");
                String url			= "";
                String username		= "";
                String password		= "";
                String database     = "";
                String server       = "";
                for(int i=0;i<nodeList.getLength();i++){
                    Element textElement = (Element)nodeList.item(i);

                    if(textElement.getAttribute("name").equals(Alias)){
                        //System.out.println(server+database+username+password);
                        server      =textElement.getAttribute("server");
                        database    =textElement.getAttribute("database");
                        username	= textElement.getAttribute("username");
                        password	= textElement.getAttribute("password");




                        //System.out.println ("User name and pwd: " + username + " " + password + "\n");
                        setDatabaseDetails(server, database, username, password);
                    }
                }
                //System.out.println("Set Super DB Connection");
            }

        }
        catch (Exception e) {




            e.printStackTrace();
        System.out.println("Set Super DB Connection Error");
        }*/
    }

    /**
     * @param parameterName
     * @return parameterValue from the given parameterName from
     * ice.config_fixedparameters
     */
    public String getFixedParameter(String parameterName) {
        String parameterValue = "";
        String strSQL2 = "SELECT ParameterValue FROM  config_fixedparameters where upper(ParameterName) ='" + parameterName.toUpperCase() + "'";
        try {
            if (myConn == null) {
                connectDB();
            }
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet myRS = stmt.executeQuery(strSQL2);
            if (myRS.next()) {
                parameterValue = myRS.getString("ParameterValue");
            }
            myRS.close();
            stmt.close();
        } catch (Exception e) {
            parameterValue = "Error:" + e;
            System.out.println("" + e);
        } finally {
            takeDown();
        }
        return (parameterValue);
    }

    public String SQLEncode(String val) {
        val = (val == null) ? "" : val.trim();
        if (val.equals("")) {
            return "NULL";
        } else {
            return "'" + val.replaceAll("'", "''") + "'";
        }
    }

    public String SQLEncode(String val, int dataType) {
        if (dataType == 1) { //NUMBER
            val = (val == null) ? "" : val;
            if (val.equals("")) {
                return "NULL";
            } else {
                return val;
            }
        } else {
            return SQLEncode(val);
        }
    }

    public String getMaxID(String TableName) {

        String s = "";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt.executeQuery("SELECT Nvl(MAX(PKSource)+1,1) AS MaxID FROM " + TableName + "");
            while (rs.next()) {
                s = rs.getString("MaxID");
                if (s.length() <= 1) {
                    s = "00" + s;
                } else if (s.length() == 2) {
                    s = "0" + s;
                }

            }
        } catch (Exception e) {
            //String errorStr=" ERROR GETTING MAXIMUM ID : "+e.toString();
        }
        return s;
    }

    /**
     * @return the alias
     */
    public String getAlias() {
        return alias;
    }

    /**
     * @param alias the alias to set
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }

    /*
	 * @param userid
	 * @return string to get accessible clients by users  used in requestmanager as dataprovider 
     */
    public String getAccesibleClients(String userID) {
        String finalSQL = "("
                + "SELECT distinct MIdomain.clientid "
                + "FROM   hawkeyeoam.oam_domainmiclients MIdomain "
                + "       inner join hawkeyeoam.oam_domainusers dusers "
                + "               ON MIdomain.domainid = dusers.domainid "
                + "                  AND dusers.userid = '" + userID + "' "
                + "union all select ' ' from dual"
                + ")";

        return finalSQL;
    }

}
