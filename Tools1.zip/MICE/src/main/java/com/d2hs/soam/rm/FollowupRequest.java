/***************************************************************************************

Filename: FollowupRequest.java

***************************************************************************************/
/**
 * @Modification: Ramesh Raj Baral
 * Added getters and setters
 */
package com.d2hs.soam.rm;

public class FollowupRequest{
	public String requestCode		= "";
	public String requestDate		= "";
	public String requestingPerson	= "";
	public String requests			= "";
	public String status			= "";
	public String targetCompDate	= "";
	public String actualCompDate	= "";
	public String isCompleted		= "";
	public String reqPersonID		= "";
	public String assgPersonID		= "";
	public String assgPersonDesc		= "";	
	
	public FollowupRequest(){
	
	}
	
	public FollowupRequest(String requestCode, String requestDate, String requestingPerson, 
				String requests, String status, String targetCompDate, 
				String actualCompDate, String isCompleted,String reqPersonID,
				String assgPersonID,String assgPersonDesc){
		setParams(requestCode, requestDate, requestingPerson, requests, 
					targetCompDate, actualCompDate, reqPersonID,
					 assgPersonDesc);
	
	}

	public void setParams(String requestCode, String requestDate, String requestingPerson, 
				String requests, String targetCompDate, 
				String actualCompDate, String reqPersonID,
				String assgPersonDesc){
		this.requestCode = requestCode;
		this.requestDate = requestDate;
		if(requestingPerson!=null){				
			this.requestingPerson = requestingPerson;
		}
		if(requests!=null){		
			this.requests = requests;
		}
	
		if(targetCompDate!=null){
			this.targetCompDate = targetCompDate;
		}
		if(actualCompDate!=null){		
			this.actualCompDate = actualCompDate;
		}
		
		if(reqPersonID!=null){				
			this.reqPersonID = reqPersonID;
		}
	
		if(assgPersonDesc!=null){				
			this.assgPersonDesc = assgPersonDesc;
		}	

	}

	public String getRequestCode() {
		return requestCode;
	}

	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}

	public String getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public String getRequestingPerson() {
		return requestingPerson;
	}

	public void setRequestingPerson(String requestingPerson) {
		this.requestingPerson = requestingPerson;
	}

	public String getRequests() {
		return requests;
	}

	public void setRequests(String requests) {
		this.requests = requests;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTargetCompDate() {
		return targetCompDate;
	}

	public void setTargetCompDate(String targetCompDate) {
		this.targetCompDate = targetCompDate;
	}

	public String getActualCompDate() {
		return actualCompDate;
	}

	public void setActualCompDate(String actualCompDate) {
		this.actualCompDate = actualCompDate;
	}

	public String getIsCompleted() {
		return isCompleted;
	}

	public void setIsCompleted(String isCompleted) {
		this.isCompleted = isCompleted;
	}

	public String getReqPersonID() {
		return reqPersonID;
	}

	public void setReqPersonID(String reqPersonID) {
		this.reqPersonID = reqPersonID;
	}

	public String getAssgPersonID() {
		return assgPersonID;
	}

	public void setAssgPersonID(String assgPersonID) {
		this.assgPersonID = assgPersonID;
	}

	public String getAssgPersonDesc() {
		return assgPersonDesc;
	}

	public void setAssgPersonDesc(String assgPersonDesc) {
		this.assgPersonDesc = assgPersonDesc;
	}
}

