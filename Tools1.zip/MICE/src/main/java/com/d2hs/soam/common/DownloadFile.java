package com.d2hs.soam.common;

import com.d2hs.soam.rm.queryBeanPM;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class DownloadFile extends HttpServlet {

    private String CONTENT_TYPE = "application/octet-stream";
//  private static final String CONTENT_TYPE = "application/x-msdownload";
    //The content type is set to appropriate one for the downloading purpose
    /**Initialize global variables*/
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    /**Process the HTTP Get request*/
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        com.d2hs.soam.rm.queryBeanPM db = new queryBeanPM();
        String RequestCode = request.getParameter("pid");
        String docID = request.getParameter("did").toString();
        if (request.getParameter("pid") != null) {
            try {
                //com.d2hs.soam.rm.queryBeanPM db=new queryBeanPM();
                HttpSession session = request.getSession(true);
                db.setSessionParameters(session);
                db.makeConnection();//db.connectDB();
                db.setConnection();
                String tableName = "OAM_RM_MOREDOCUMENTS1";
                String xtraSQL = "";
                xtraSQL = " AND DocumentCode=" + request.getParameter("did");

                Statement stmnt = db.conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                String sqlString = "SELECT UploadedDoc,UploadedDocName FROM " + tableName + " WHERE RequestCode='" + RequestCode.replaceAll("'", "''") + "'" + xtraSQL;
                ResultSet rs = stmnt.executeQuery(sqlString);
                response.setContentType(CONTENT_TYPE);
                //System.out.println(sqlString);
    	  		ArrayList list=new ArrayList();
	    	  	while(rs.next())
                {
	    	  		HashMap map=new HashMap();
                    Blob blobdoc = rs.getBlob("UploadedDoc");
	    	  		String fileName=rs.getString("UploadedDocName");
	    	  		map.put("blobdoc", blobdoc);
	    	  		map.put("fileName", fileName);
	    	  		list.add(map);
                }
	    	  	db.takeDown();
	    	  	 for(int i=0;i<list.size();i++)
	    	  	 {
	    	  		HashMap map= (HashMap) list.get(i);
	    	  		Blob blobdoc=(Blob) map.get("blobdoc");
	    	  		String fileName=(String) map.get("fileName");
	    	  	 byte b[] = blobdoc.getBytes(1, (new Long(blobdoc.length())).intValue());
                 
                 //System.out.print("fileName>>>>>"+fileName);
                 response.setHeader("Content-Disposition", "attachment; filename=".concat(fileName));
                 BufferedOutputStream bout = new BufferedOutputStream(response.getOutputStream());
                 bout.write(b);
                 bout.close();
	    	  	 }

            } catch (Exception e) {
                response.getWriter().println("An error has occured : ".concat(String.valueOf(String.valueOf(e.toString()))));
                System.out.println("\n\n\n Error from com.d2hs.soam.common.DownloadFile.doGet \n\n\n and it is " + e + " \n\n\n The requestcode and doc code are " + RequestCode+" and "+docID+"\n\n");
                e.printStackTrace(response.getWriter());
            } finally {
                db.takeDown();
            }
        }
    }

    /**Clean up resources*/
    public void destroy() {
    }
}
