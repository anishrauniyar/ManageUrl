package com.d2hs.soam.rm;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.d2hs.soam.RequestBean;

import d2Systems.rm.RequestTemplate;

public class RequestManager extends RequestBean{



    protected String orderField	= "";
    protected String order		= "Desc";

    public RequestManager(){

    }
    public String getOrderField() {
        return orderField;
    }

    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

   public boolean getAllRequests(String RequestCode){
      boolean result = false;
      strSQL = "Select a.*,b.UserID as PreAssigneTo,b.username from OAM_RM_REQUEST_TYPES a left join  usr_users b on a.userid=b.userid  where 1=1";
       if(!RequestCode.equals("0")){
          strSQL=strSQL + "and RequestTypeID='"+RequestCode+"'";
      }
      try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }
     public boolean updateRequestType(String RequestTypeCode,String RequestType,String UserID){
        boolean isInserted=false;
        try{
            Statement stmnt=myConn.createStatement();
            strSQL="UPDATE OAM_RM_REQUEST_TYPES SET RequestTypeDesc ='" +
            RequestType + "', UserID='"+ UserID +"' WHERE RequestTypeID='" + RequestTypeCode +"'";
            stmnt.execute(strSQL);
            isInserted=true;
        }
        catch (SQLException sqlexception) {
            errorStr="Update Request Type Error  : "+sqlexception;
        }
        return isInserted;
    }


    public TreeMap executeQueryForClientList(){
         String sqlForClientList	= "SELECT Distinct a.ClientID, b.ClientName FROM tbl_ClientAndRequest a " +
                                               "Left Join (Select ClientName, ClientID from OAM_RM_CLIENTS)b on a.ClientID=b.ClientID";

          TreeMap groupList = new TreeMap();
          ResultSet rs;
          PreparedStatement stm;
          groupList.clear();
          try{
              stm = myConn.prepareStatement(strSQL = sqlForClientList);
              rs = stm.executeQuery();
              while(rs.next()) {
                  groupList.put(rs.getString("ClientID"),rs.getString("ClientName"));
              }
              rs.close();
              stm.close();
          } catch(Exception e){
              strSQL += " "+e.getMessage();
          }
          return groupList;
    }

    public boolean getClientsRequestTypes(String ProductID){
      boolean result = false;
      strSQL = "select a.*,b.username from OAM_RM_REQUEST_TYPES a left join  usr_users b on a.userid=b.userid where 1=1 ";
        if(!ProductID.equalsIgnoreCase("")){strSQL+= " AND ProductID='"+ProductID +"'";}
         strSQL+= " order by RequestTypeDesc ";
         //System.out.println(strSQL);
      try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }
    public boolean getClientsProducts(String ClientID,String ProductID){
      boolean result = false;
      strSQL = "select * from OAM_RM_PRODUCTS  where 1=1 ";
        if(!ClientID.equalsIgnoreCase("")){strSQL+= " AND ClientID='"+ClientID +"'";}
        if(!ProductID.equalsIgnoreCase("")){strSQL+= " AND ProductID='"+ProductID +"'";}
         strSQL+= " order by ProductName ";
      try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }

    /* 
     * Changed by: Richan Shrestha (Sept 21,2007)
     * Description: Add a new Product of a Client and returns the new ProductID
     */
    public String addProducts(String ClientID,String Products,String PhaseType){
       String ProductID="";
       try{
    	   Statement stmnt=myConn.createStatement();
           strSQL="select count(*) cnt from oam_rm_products where ProductName like '"+Products+"' and clientid='"+ClientID+"'";
    	   myRS=stmnt.executeQuery(strSQL);
    	   myRS.next();
    	   if(myRS.getInt("cnt")>0)
    	   {
    		   ProductID="duplicate";
    	   }
    	   else
    	   {
    		   strSQL="insert into OAM_RM_PRODUCTS"+
                   " (ProductId,ProductName,ClientID,PhaseType)"+
                   " VALUES (" + SQLEncode(ProductID) + "," +
                            SQLEncode(Products) + ","+
                            SQLEncode(ClientID) + ","+
                            SQLEncode(PhaseType)+")" ;
    		   stmnt.execute(strSQL);
    		   strSQL="select sq_oam_rm_products.currval ProductID from dual";
    		   myRS=stmnt.executeQuery(strSQL);
        	   myRS.next();
        	   ProductID=myRS.getString("ProductID");
    	   }
         }
       catch (SQLException sqlexception) {
           errorStr="Insert Products Error  : "+sqlexception;
           ProductID="";
       }
       return ProductID;
   }
    
  public String updateProducts(String ClientID,String ProductID,String ProductName,String OldProductName,String PhaseType){
       String isInserted="false";
       try{
    	   Statement stmnt=myConn.createStatement();
           strSQL="select count(*) cnt from oam_rm_products where ProductName like '"+ProductName+"' and clientid='"+ClientID+"'";
    	   myRS=stmnt.executeQuery(strSQL);
    	   myRS.next();
    	   if(myRS.getInt("cnt")>0 && !OldProductName.equals(ProductName))
    	   {
    		   isInserted="duplicate";
    	   }
    	   else
    	   {
           strSQL="UPDATE OAM_RM_PRODUCTS SET "+
                   " ProductName = " + SQLEncode(ProductName) +
                   " ,PhaseType = " + SQLEncode(PhaseType) +
                   " Where ProductID="+SQLEncode(ProductID);
           System.out.println(strSQL);
           stmnt.execute(strSQL);
           isInserted="true";
    	   }
       }
       catch (SQLException sqlexception) {
           errorStr="Update Version Error  : "+sqlexception;
       }
       return isInserted;
   }


    public boolean getClientsRequestTypesNotAssigned(String ClientID, String UserID){
      boolean result = false;
      strSQL = "select * from OAM_RM_PRODUCTS where ClientID='"+ClientID+"' And ProductID Not in " +
              "(Select ProductID from TMP_OAM_RM_USER_PRODUCT where UserID='"+UserID+"') Order by ProductName";
      //System.out.println(strSQL);
      try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }

   public boolean getListOfVersions(String RequestTypeCode)
   {
      return getList(strSQL,"Version");
   }
   public void setVersionQuery(String ProductID, String fVersionName, String fVersionOrder){

      strSQL="SELECT DISTINCT VersionID as ID,VersionDesc as VersionName, VersionID, VersionOrder FROM OAM_RM_PRODUCTVERSION WHERE Active_YN = 'Y'";
      if(!ProductID.equals(""))
      {
          strSQL+=" AND ProductID='"+ProductID.replace('\'','`')+"'";
      }
      if(!fVersionName.equals(""))
      {
          strSQL+=" AND VersionDesc Like '%"+fVersionName.replace('\'','`')+"%'";
      }
      if(!fVersionOrder.equals(""))
      {
          strSQL+=" AND VersionOrder='"+fVersionOrder.replace('\'','`')+"'";
      }
      if(!orderField.equals("")){
          strSQL+=" ORDER BY "+orderField+" "+order;

      }
      //System.out.println(strSQL);
   }
   
   public String getMaxID(String ColumnName,String TableName){

	    String s="";
		try{
			Statement stmnt=myConn.createStatement();
			ResultSet rs=stmnt.executeQuery("SELECT nvl(MAX("+ColumnName+")+1,1) AS MaxID FROM "+TableName+"");
			while(rs.next()){
				s=rs.getString("MaxID");
			}
		}

		catch (Exception e){
			errorStr=" ERROR GETTING MAXIMUM ID : "+e.toString();
		}
	   return s;
	  }
   public String getMaxID(String TableName){

    String s="";
	try{
		Statement stmnt=myConn.createStatement();
		ResultSet rs=stmnt.executeQuery("SELECT nvl(MAX(PKSource)+1,1) AS MaxID FROM "+TableName+"");
		while(rs.next()){
			s=rs.getString("MaxID");
            if(s.length()<=1){ s="00"+s;}
            else if (s.length()==2){ s="0"+s;}

		}
	}

	catch (Exception e){
		errorStr=" ERROR GETTING MAXIMUM ID : "+e.toString();
	}
   return s;
  }
    public String addVersion(String VersionName,String ApplicationVersionDesc,String VersionOrder,String Active_YN,String ProductID){
         String isInserted="false";

          strSQL = "Select count(*) n from OAM_RM_PRODUCTVERSION where VersionDesc like '" +VersionName+ "' and "+
                 " ProductID like '" +ProductID+ "'";
          //System.out.println(strSQL);
       try{
           Statement stmnt=myConn.createStatement();
           ResultSet rs = stmnt.executeQuery(strSQL);
           rs.next();
           int count = Integer.parseInt(rs.getString("n".trim()));
           //System.out.println (count);
           if (count > 0)
           {
               isInserted = "duplicate";
               return isInserted;
           }
           else if (count == 0)
           {
        	   //java.util.Date d=new java.util.Date();
               //String ApplicationVersionCode="";
               //ApplicationVersionCode=getMaxID("OAM_RM_PRODUCTVERSION");
               strSQL="insert into OAM_RM_PRODUCTVERSION "+
                       " (VersionID,VersionDesc,VersionOrder,Active_YN,ProductID,CreatedDate)"+
                       " VALUES (''" + "," +
                                SQLEncode(ApplicationVersionDesc)+","+
                                SQLEncode(VersionOrder)+","+
                                SQLEncode(Active_YN)+","+
                                SQLEncode(ProductID)+","+
                                "sysdate)";
               //System.out.println(strSQL);
               stmnt.execute(strSQL);
               isInserted="true";
           }
       }
       catch (Exception sqlexception) {
           errorStr="Insert Version Error  : "+sqlexception;
           System.out.println(errorStr);
       }
       return isInserted;
   }
    public String updateVersion(String VersionCode,String VersionName,String ApplicationVersionDesc,String Active_YN){
       String isInserted="false";
       strSQL = "Select count(*) n from OAM_RM_PRODUCTVERSION where VersionDesc like '" +VersionName+ "' and "+
       " ProductID like (Select ProductID from OAM_RM_PRODUCTVERSION where VersionID = '" +VersionCode+ "')";

       try{
           Statement stmnt=myConn.createStatement();
           ResultSet rs = stmnt.executeQuery(strSQL);
           rs.next();
           int count = Integer.parseInt(rs.getString("n".trim()));
           //System.out.println (count);
           if (count > 0)
           {
               isInserted = "duplicate";
               return isInserted;
           }
           else if (count == 0)
           {
               String ApplicationVersionCode="";
               ApplicationVersionCode=getMaxID("OAM_RM_PRODUCTVERSION");
               strSQL="UPDATE OAM_RM_PRODUCTVERSION SET "+
                       //" VersionID = " + SQLEncode(VersionName) + ","+
                       " VersionDesc =" + SQLEncode(ApplicationVersionDesc) + ","+
                       " Active_YN =" + SQLEncode(Active_YN) + ""+
                       " Where VersionID="+SQLEncode(VersionCode);
               stmnt.execute(strSQL);
               isInserted="true";
           }
       }
       catch (SQLException sqlexception) {
           errorStr="Update Version Error  : "+sqlexception;
       }
       return isInserted;
   }

    public boolean getAllVersion(String VeriosnCode,String Active_YN){
       boolean result = false;
       strSQL = "select * from OAM_RM_PRODUCTVERSION where 1=1";
        if(!VeriosnCode.equals("")){
           strSQL=strSQL + " and VersionID='"+VeriosnCode+"'";
       }
        if(!Active_YN.equals("")){
           strSQL=strSQL + " and Active_YN='"+Active_YN+"'";
       }

       try
         {
                Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                 myRS=stmt.executeQuery(strSQL);
                 result=true;
         }
         catch(Exception e){
             System.out.print("error"+e.getMessage());
         }
       return result;
    }
   
    /**@author Raju Thapa Shrestha,jan 24,2008
     *  Desc: New functions relating to Product Modules were added.
     *  New functions are getListOfModules(),setModuleQuery(),addProductModule(),updateModule()and getAllModules().
     */
    public boolean getListOfModules()
    {
       return getList(strSQL,"Module");
    }
    
    public boolean getListOfProjects()
    {
       return getList(strSQL,"Project");
    }
    public void setModuleQuery(String ProductID, String fModuleDesc){

        strSQL="SELECT DISTINCT ModuleID as ID,ModuleName as Module FROM OAM_RM_MODULES WHERE 1=1";
        if(!ProductID.equals(""))
        {
            strSQL+=" AND ProductID='"+ProductID.replace('\'','`')+"'";
        }
        if(!fModuleDesc.equals(""))
        {
            strSQL+=" AND ModuleName Like '%"+fModuleDesc.replace('\'','`')+"%'";
        }      
        strSQL+= " order by ModuleName";
     }
    public void setProjectQuery(String ProductID, String fProjectName){

        strSQL="SELECT DISTINCT ProjectID as ID,ProjectName as Project FROM OAM_RM_PROJECTS WHERE 1=1 and (isClosed!='Y' or isClosed is null)";
        if(!ProductID.equals(""))
        {
            strSQL+=" AND ProductID="+ProductID+"";
        }
        if(!fProjectName.equals(""))
        {
            strSQL+=" AND ProjectName Like '%"+fProjectName.replace('\'','`')+"%'";
        }        
        strSQL+= " order by  ProjectName "; 
        System.out.println(strSQL);
     }
    public void setProjectQuery(String ProductID, String fProjectName,String getAll){

        strSQL="SELECT DISTINCT ProjectID as ID,ProjectName as Project,isClosed FROM OAM_RM_PROJECTS WHERE 1=1 ";
        if(!ProductID.equals(""))
        {
            strSQL+=" AND ProductID="+ProductID+"";
        }
        if(!fProjectName.equals(""))
        {
            strSQL+=" AND ProjectName Like '%"+fProjectName.replace('\'','`')+"%'";
        }        
        strSQL+= " order by  ProjectName "; 
        System.out.println(strSQL);
     }
    
    public String addProductModule(String ProductID,String ModuleName){
        String isInserted="false";

         strSQL = "Select count(*) n from OAM_RM_MODULES where ProductID like '" +ProductID+ "' and "+
                " ModuleName like '" +ModuleName+ "'";
         //System.out.println(strSQL);
      try{
          Statement stmnt=myConn.createStatement();
          ResultSet rs = stmnt.executeQuery(strSQL);
          rs.next();
          int count = Integer.parseInt(rs.getString("n".trim()));
         // System.out.println (count);
          if (count > 0)
          {
              isInserted = "duplicate";
              return isInserted;
          }
          else if (count == 0)
          {
              String ModuleCode="";
              ModuleCode=getMaxID("ModuleID","OAM_RM_MODULES");
              strSQL="insert into OAM_RM_MODULES "+
                      " (ModuleID,ProductID,ModuleName,udf1,udf2)"+
                      " VALUES (" + SQLEncode(ModuleCode) + "," +
                               SQLEncode(ProductID) + "," +                              
                               SQLEncode(ModuleName)+",'','')" ;
              stmnt.execute(strSQL);
              isInserted="true";
          }
      }
      catch (Exception sqlexception) {
          errorStr="Insert Module Error  : "+sqlexception;
          System.out.println(errorStr);
      }
      return isInserted;
    }
    
    public String addProject(String ProductID,String ProjectName,String ProjectStartDate,String ProjectDesc,String Phase){
        String isInserted="false";

         strSQL = "Select count(*) n from OAM_RM_PROJECTS where ProductID like '" +ProductID+ "' and "+
                " ProjectName like '" +ProjectName+ "'";
         //System.out.println(strSQL);
      try{
          Statement stmnt=myConn.createStatement();
          ResultSet rs = stmnt.executeQuery(strSQL);
          rs.next();
          int count = Integer.parseInt(rs.getString("n".trim()));
         // System.out.println (count);
          if (count > 0)
          {
              isInserted = "duplicate";
              return isInserted;
          }
          else if (count == 0)
          {
              String ProjectCode="";
              ProjectCode=getMaxID("ProjectID","OAM_RM_PROJECTS");
              //System.out.println(ProjectCode);
              strSQL="insert into OAM_RM_PROJECTS "+
                      " (ProjectID,ProductID,ProjectName,ProjectStartDate,ProjectDesc,PhaseID,CreatedDate,UpdatedDate)"+
                      " VALUES (" + SQLEncode(ProjectCode) + "," +
                               SQLEncode(ProductID) + "," +                              
                               SQLEncode(ProjectName)+"," +
                               "to_date("+SQLEncode(ProjectStartDate)+",'mm/dd/yyyy')"+","+
                               SQLEncode(ProjectDesc)+"," +
                               SQLEncode(Phase)+"," +
                               "sysdate,sysdate)" ;
              stmnt.execute(strSQL);
              strSQL="select sq_oam_rm_projects.currval ProjectID from dual";
              myRS=stmnt.executeQuery(strSQL);
              myRS.next();
              ProjectCode=myRS.getString("ProjectID");
              addProjectAreaToProject(SQLEncode(ProjectCode));
              isInserted="true";
          }
      }
      catch (Exception sqlexception) {
          errorStr="Insert Project Error  : "+sqlexception;
          System.out.println(errorStr);
      }
      return isInserted;
    }
    
    public boolean getAllProjects(String ProjectID){
        boolean result = false;
        strSQL = "select * from OAM_RM_PROJECTS where 1=1";
         if(!ProjectID.equals("")){
            strSQL +=" and ProjectID='"+ProjectID+"'";
        }
         //System.out.println (strSQL);
         strSQL += " order by projectName ";
        try
          {
                 Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
     }
    
    public String updateModule(String ModuleID,String ModuleName){        
        String isInserted="false";
        strSQL = "Select count(*) n from OAM_RM_MODULES where ModuleName like '" +ModuleName+ "' and "+
        " ProductID like (Select ProductID from OAM_RM_MODULES where ModuleID = '" +ModuleID+ "')"; 
        try{
            Statement stmnt=myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSQL);
            rs.next();
            int count = Integer.parseInt(rs.getString("n".trim()));
            if (count > 0)
            {              
                isInserted = "duplicate";
                return isInserted;
            }
            else if (count == 0)
            {
            
               // String ModuleID="";
               // ModuleID=getMaxID("OAM_RM_MODULES");
                strSQL="UPDATE OAM_RM_MODULES SET "+
                        " ModuleName = " + SQLEncode(ModuleName) + ""+                       
                        " Where ModuleID="+SQLEncode(ModuleID);
                stmnt.execute(strSQL);
                isInserted="true";
            }
        }
        catch (SQLException sqlexception) {
            errorStr="Update Request Manager Module, in RequestManager.updateModuele() Error  : "+sqlexception;
        }
        return isInserted;
    }

    public String updateProject(String ProjectID,String ProjectName,String ProjectStartDate,String ProjectDesc,String OldProject,String Phase,String PercentComp){
        String isInserted="false";
        strSQL = "Select count(*) n from OAM_RM_PROJECTS where ProjectName like '" +ProjectName+ "' and "+
        " ProductID like (Select ProductID from OAM_RM_PROJECTS where ProjectID = '" +ProjectID+ "')";
        //System.out.println (strSQL);
        try{
            Statement stmnt=myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSQL);
            rs.next();
            int count = Integer.parseInt(rs.getString("n".trim()));
            //System.out.println (count);
            if (count > 0 && !ProjectName.equals(OldProject))
            {              
                isInserted = "duplicate";
                return isInserted;
            }
            else 
            {
            
               // String ProjectID="";
               // ProjectID=getMaxID("OAM_RM_PROJECTS");
                strSQL="UPDATE OAM_RM_PROJECTS SET "+
                        " ProjectName = " + SQLEncode(ProjectName) + ","+  
                        " ProjectDesc = " + SQLEncode(ProjectDesc) + ","+
                        " ProjectStartDate = to_date("+SQLEncode(ProjectStartDate)+",'mm/dd/yyyy'),"+
                        " UpdatedDate =sysdate"+ "," +
                        " PhaseID = " + SQLEncode(Phase) +","+
                        " ProjectCompletion = " + SQLEncode(PercentComp) +
                        " Where ProjectID="+SQLEncode(ProjectID);
                //System.out.println (strSQL);
                stmnt.execute(strSQL);
                isInserted="true";
            }
        }
        catch (SQLException sqlexception) {
            errorStr="Update Project Error  : "+sqlexception;
        }
        return isInserted;
    }
    
    public boolean getListOfPhases()
    {
       strSQL="SELECT DISTINCT RequestPhaseID as ID,RequestPhaseDesc as Phase FROM OAM_RM_REQUEST_PHASE WHERE 1=1";
       return getList(strSQL,"Projectphase");
    }
    
    public boolean getAllModules(String ModuleID){
        boolean result = false;
        strSQL = "select * from OAM_RM_MODULES where 1=1";
         if(!ModuleID.equals("")){
            strSQL +=" and ModuleID='"+ModuleID+"'";
        }
         strSQL+=" order by modulename";
        try
          {
                 Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
     }

    public boolean getAllLabels(String LabelID,String ClientID){
        boolean result = false;
        strSQL = "select * from OAM_RM_LABEL_NAME where 1=1";
          if(!LabelID.equalsIgnoreCase("")){strSQL+=" AND LabelID="+SQLEncode(LabelID);}
          if(!ClientID.equalsIgnoreCase("")){strSQL+=" AND ClientID="+SQLEncode(ClientID);}
        strSQL+=" order by LabelName";
        try
          {
                  Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
     }
    public boolean getAllLabels(String LabelID,String ClientID,String ProductID){
      boolean result = false;
      strSQL = "select * from OAM_RM_LABEL_NAME where 1=1";
        if(!LabelID.equalsIgnoreCase("")){strSQL+=" AND LabelID="+SQLEncode(LabelID);}
        if(!ClientID.equalsIgnoreCase("")){strSQL+=" AND ClientID="+SQLEncode(ClientID);}
        if(!ProductID.equalsIgnoreCase("")){strSQL+=" AND ProductID="+SQLEncode(ProductID);}
      strSQL+=" order by LabelName";
      try
        {
                Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }

  public boolean addLabels(String LabelName,String ClientID,String ProductID,String UserID){
       boolean isInserted=false;
       try{
           Statement stmnt=myConn.createStatement();
           String LabelID="";
           LabelID=getMaxID("LabelID","OAM_RM_LABEL_NAME");
           strSQL="insert into OAM_RM_LABEL_NAME "+
                   " (LabelID,LabelName,ClientID,ProductID,UserID)"+
                   " VALUES ("+ SQLEncode(LabelID) + "," +
                            SQLEncode(LabelName) + "," +
                            SQLEncode(ClientID) + "," +
                            SQLEncode(ProductID) + "," +
                             SQLEncode(UserID)+")" ;
           stmnt.execute(strSQL);
           isInserted=true;
       }
       catch (SQLException sqlexception) {
           errorStr="Add Label Error  : "+sqlexception;
       }
       return isInserted;
   }
    public boolean editLabels(String LabelID,String LabelName){
         boolean isInserted=false;
         try{
             Statement stmnt=myConn.createStatement();
             strSQL="update OAM_RM_LABEL_NAME set "+
                      " LabelName = " + SQLEncode(LabelName) + " Where LabelID="+SQLEncode(LabelID);
             stmnt.execute(strSQL);
             isInserted=true;
         }
         catch (SQLException sqlexception) {
             errorStr="Update Label error: "+sqlexception;
         }
         return isInserted;
     }

      public boolean deleteLabels(String LabelID){
	          boolean isDeleted=false;
	          try{
	              Statement stmnt=myConn.createStatement();
	          String tempSQL="";
			  tempSQL="DELETE OAM_RM_LABEL_NAME where LabelID='"+LabelID+"'";
			  stmnt.execute(tempSQL);
			  tempSQL="DELETE OAM_RM_REQUEST_LABELS where LabelID='"+LabelID+"' ";
			  stmnt.execute(tempSQL);
	              isDeleted=true;
	          }
	          catch (SQLException sqlexception) {
	              errorStr="Delete Label error: "+sqlexception;
	          }
	          return isDeleted;
	      }


public boolean addRequestLabels(String LabelID,String RequestID,String ClientID){
       boolean isInserted=false;
       try{
           Statement stmnt=myConn.createStatement();
           String tempSQL="";
           tempSQL="Select count(LabelID) as count from  OAM_RM_REQUEST_LABELS where LabelID='"+LabelID+"' and RequestCode='"+RequestID+"'";
           //System.out.println(tempSQL);
           Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
           myRS=stmt.executeQuery(tempSQL);
           myRS.next();
            if (myRS.getInt("count") == 0)
            {
             strSQL="insert into OAM_RM_REQUEST_LABELS "+
                   " (LabelID,RequestCode)"+
                   " VALUES ("+ SQLEncode(LabelID) + "," +
                            SQLEncode(RequestID) + ")";
                             //SQLEncode(ClientID)+")" ;
             //System.out.println(strSQL);
               stmnt.execute(strSQL);
               isInserted=true;
            }
       }
       catch (SQLException sqlexception) {
           errorStr="Add Request Label Error  : "+sqlexception;
       }
       return isInserted;
   }
    public boolean deleteRequestLabels(String LabelID,String RequestID,String ClientID){
           boolean isInserted=false;
           try{
               Statement stmnt=myConn.createStatement();
               String tempSQL="";
               //tempSQL="Select count(LabelID) as count from  OAM_RM_REQUEST_LABELS where LabelID='"+LabelID+"' and RequestID='"+RequestID+"' and ClientID='"+ClientID+"'";
               tempSQL="DELETE OAM_RM_REQUEST_LABELS where RequestCode='"+RequestID+"' ";
               
               if(!LabelID.trim().equals(""))
            	   tempSQL += " AND LabelID='"+LabelID+"'  ";
               //System.out.print(tempSQL);
               stmnt.execute(tempSQL);

           }
           catch (SQLException sqlexception) {
               errorStr="Add Request Label Error  : "+sqlexception;
           }
           return isInserted;
       }

    public boolean getMessageTriggerType(){
        boolean result=false;
        strSQL = "select MsgID,MsgTriggerType from OAM_RM_MESSAGE_TRIGGER_TYPE ORDER BY MsgOrder ";
        
        try
          {
                  stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
      }

    public String setProjectCombo(String fromPage,String alias,String product,String selectedProject)
    {
    	String projectcombo="";
    	 Map reply = new HashMap();
    	try{
    		setAlias(alias);
    		makeConnection();
        
    		if(fromPage.equals("View"))
    			projectcombo="<select name=ProjectID class=\"box1\"><option value=\"all\">Select Project</option>";
    		else
    			projectcombo="<select class=\"DataCellTD\" name=ProjectID class=\"box1\"><option value=\"all\">Please Choose</option>";
	        if (!product.equalsIgnoreCase(""))
	        {
	        	int projectTypeCount=0;
	            String rid="";
	            setProjectQuery(product,"");
	            if(getListOfProjects()){
	                 while(moveNext())
	                 {
	                 	projectTypeCount++;
	                     rid = getParam("ID");
	
	                     projectcombo+="<OPTION VALUE=\""+rid+"\"";
	                     if(selectedProject!=null){
	                         if(rid.equals(selectedProject))
	                        	 projectcombo+=" selected";
	
	                     }
	
	                         projectcombo+=">"+getParam("Project")+"</OPTION>";
	                 }
	            }
	
	        
	        }
	       
	        takeDown();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	finally {
            try {
                takeDown();
            } catch (Exception e) {
                System.out.println("Error in take at down RequestManager.setProjectCombo, the error is " + e + " \n");

            }

        }
    	projectcombo+="</select>";
        return projectcombo;
    }
    
    public boolean getProductAreaDetails(String ClientID,String ProductID,String ProjectID){
        boolean result=false;
        strSQL = "select a.clientname,b.productname,c.projectname from oam_rm_clients a inner join oam_rm_products b on a.clientid=b.clientid inner join oam_rm_projects c on b.productid=c.productid " +
        		"where a.clientid='"+ClientID+"' and b.productid='"+ProductID+"' and c.projectid='"+ProjectID+"'";
        try
          {
                  stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
      }
    
    public boolean getProductAreas(String ProjectID){
        boolean result=false;
        strSQL = "select a.productareaid,a.productareadesc from OAM_RM_PRODUCT_AREA a INNER JOIN OAM_RM_PROJECT_AREA_REL b ON a.productareaid=b.projectareaid WHERE b.projectid='"+ProjectID+"' ORDER BY a.ProductAreaDesc ";
        
        try
          {
                  stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
      }
    
    public boolean getAvailableAreaListForProject(String ProjectID){
        boolean result=false;
        strSQL = "SELECT   A.PRODUCTAREAID, \n"+
        "          A.PRODUCTAREADESC \n"+
        " FROM     OAM_RM_PRODUCT_AREA A \n"+
        " WHERE    A.PRODUCTAREAID NOT IN (SELECT PROJECTAREAID \n"+
        "                                  FROM   OAM_RM_PROJECT_AREA_REL \n"+
        "                                  WHERE  PROJECTID = '"+ProjectID+"') \n"+
        " ORDER BY A.PRODUCTAREADESC \n";
        try
          {
                  stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
      }
    
    public boolean getSelectedAreaListForProject(String ProjectID){
        boolean result=false;
        strSQL = "SELECT   A.PRODUCTAREAID, \n"+
        "          A.PRODUCTAREADESC \n"+
        " FROM     OAM_RM_PRODUCT_AREA A \n"+
        " WHERE    A.PRODUCTAREAID IN (SELECT PROJECTAREAID \n"+
        "                                  FROM   OAM_RM_PROJECT_AREA_REL \n"+
        "                                  WHERE  PROJECTID = '"+ProjectID+"') \n"+
        " ORDER BY A.PRODUCTAREADESC \n";
        try
          {
                  stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.print("error"+e.getMessage());
          }
        return result;
      }
    
    public boolean addNewProductArea(String ProductArea)
    {
    	boolean result=false;
    	strSQL="insert into oam_rm_product_area values ('1','"+ProductArea+"','','','')";
    	try{
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	return result;
    	
    }
    
    public boolean deleteAreasForProject(String ProjectID)
    {
    	boolean result=false;
    	strSQL="delete oam_rm_project_area_rel where projectid='"+ProjectID+"'";
    	try{
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	return result;
    	
    }
    
    public boolean deleteAreaForProject(String ProjectID,String ProjectAreaID)
    {
    	boolean result=false;
    	strSQL="delete oam_rm_project_area_rel where projectid='"+ProjectID+"' and projectareaid='"+ProjectAreaID+"'";
    	System.out.println(strSQL);
    	try{
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	return result;
    	
    }
    
    public boolean insertAreaForProject(ArrayList AreaList,String ProjectID)
    {
    	boolean result=false;
    	int i=0;
    	try{
    		Statement st = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    		Iterator it=AreaList.iterator();
            while(it.hasNext()){
           	 i++;
           	 if ((i%200)==0){
           		 this.takeDown();
           		 try{
           		 this.makeConnection();
           		 }catch(Exception ex){
           			 System.out.println(ex);
           		 }
           	 }
           	       
           	 	String AreaID=it.next().toString();
                strSQL = "insert into OAM_RM_PROJECT_AREA_REL values('','" +ProjectID+ "','" + AreaID+ "' )";
                System.out.println("The sql is "+strSQL);
                st.execute(strSQL);
                
                
            }
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	return result;
    	
    }
    
    public boolean addProjectAreaToProject(String ProjectID)
    {
    	boolean result=false;
    	for(int i=1;i<=14;i++)
    	{
    	strSQL="insert into oam_rm_project_area_rel values ('1',"+ProjectID+",'"+i+"')";
    	try{
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	}
    	return result;
    	
    }
    
    public boolean closeProject(String alias,String UserID,String ProjectID){
    	boolean result=false;
    	strSQL="update oam_rm_projects set isClosed='Y',closeddate=sysdate,closedby='"+UserID+"' where projectid='"+ProjectID+"'";
    	//System.out.println(strSQL);
    	try{
    		setAlias(alias);
    		makeConnection();
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	finally{
    		takeDown();
    	}
    	return result;
    }
    
    public boolean getThresholdDays(String ProjectID){
    	boolean result=false;
    	strSQL="select ThresholdDays from oam_rm_projects where projectid='"+ProjectID+"'";
    	System.out.println(strSQL);
    	try{
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	return result;
    }
    
    public boolean updateThresholdDays(String ProjectID,String Days){
    	boolean result=false;
    	strSQL="update oam_rm_projects set ThresholdDays='"+Days+"' where projectid='"+ProjectID+"'";
    	System.out.println(strSQL);
    	try{
    		stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS=stmt.executeQuery(strSQL);
            result=true;
    	}
    	catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
    	return result;
    }
    
	public void setProjectForDataProviderQuery(String DataProviderID){
        strSQL="select b.projectid,b.projectname from oam_dataclient_relations a inner join oam_rm_projects b on a.projectid=b.projectid where a.clientid='"+DataProviderID+"' order by b.projectname ";
        System.out.println(strSQL);
     }
	
	/**
	 * 
	 * getAllStatus
	 * RequestManager
	 * Description:return the status detail available in db
	 * @return
	 * @return HashMap
	 * @author:Ramesh Raj Baral
	 * @since:Jun 21, 2010
	 *
	 */
	
	public HashMap getAllStatus(){
		String sql="select *from OAM_RM_REQUESTSTATUS where statusdesc NOT IN ( 'Closed', 'Dropped', 'Deferred' )";
		HashMap statusMap=new HashMap();
		try{
			if(myConn==null)
				this.connectDB();
			stmt=myConn.createStatement();
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				String statusCode=rs.getString("statusid");
				String statusDesc=rs.getString("statusdesc");
				statusMap.put(statusCode, statusDesc);
			}
		}catch(Exception ex){
			System.out.println("Exception getting All Status:"+ex.getMessage());
			System.out.println("Alias is:"+this.getAlias());
		}
		finally{
			this.takeDown();
		}
		return statusMap;
	}
	
	/**
	 * 
	 * getRequestTypes
	 * RequestManager
	 * Description:return all request types
	 * @return
	 * @return HashMap
	 * @author:Ramesh Raj Baral
	 * @since:Jun 21, 2010
	 *
	 */
	public HashMap getRequestTypes(){
		String sql="select *from OAM_RM_REQUEST_TYPES";
		HashMap typeMap=new HashMap();
		try{
			if(myConn==null)
				this.connectDB();
			stmt=myConn.createStatement();
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				String statusCode=rs.getString("requesttypeid");
				String statusDesc=rs.getString("requesttypedesc");
				typeMap.put(statusCode, statusDesc);
			}
		}catch(Exception ex){
			System.out.println("Exception getting All RequestTypes:"+ex.getMessage());
			System.out.println("Alias is:"+this.getAlias());
		}
		finally{
			this.takeDown();
		}
		//System.out.println("request types:"+typeMap.size());
		return typeMap;
	}
	
	/**
	 * 
	 * getRequestSeverity
	 * RequestManager
	 * Description:Return the severity details
	 * @return
	 * @return HashMap
	 * @author:Ramesh Raj Baral
	 * @since:Jun 21, 2010
	 *
	 */
	public HashMap getRequestSeverity(){
		String sql="select *from OAM_RM_REQUEST_SEVERITY";
		HashMap severityMap=new HashMap();
		try{
			if(myConn==null)
				this.connectDB();
			stmt=myConn.createStatement();
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next()){
				String statusCode=rs.getString("severityid");
				String statusDesc=rs.getString("severitydesc");
				severityMap.put(statusCode, statusDesc);
			}
		}catch(Exception ex){
			System.out.println("Exception getting All Severity:"+ex.getMessage());
			System.out.println("Alias is:"+this.getAlias());
		}
		finally{
			this.takeDown();
		}
		//System.out.println("request types:"+severityMap.size());
		return severityMap;
	}
	
}
