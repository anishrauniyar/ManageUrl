package com.d2hs.soam.cm;

import com.d2hs.soam.RequestBean;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.TreeMap;

import com.d2hs.soam.RequestBean;
import com.d2hs.soam.BaseBean;

import java.sql.*;
import java.util.TreeMap;

/**
 * Created by IntelliJ IDEA.
 * User: phada
 * Date: Dec 19, 2005
 * Time: 2:03:44 PM
 * To change this template use File | Settings | File Templates.
 */
   public class ClientManager extends RequestBean{
   protected String orderField	= "clientname";
   protected String order		= "ASC";
   private String strFilters	= "";

   public ClientManager(){

   }

    public String getOrderField() {
        return orderField;
    }

    public void setOrderField(String orderField) {
        this.orderField = orderField;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public void filterClients(String fClientName,String fContactName,String fEmail,String fStartDate, String fCluster)
    {
    if(!fClientName.equals("")){
		strFilters	+= " AND lower(ClientName) LIKE lower('%" + fClientName.replaceAll("'","''").trim() + "%')";
	}
    if(!fContactName.equals("")){
        strFilters	+= " AND lower( ContactPerson) LIKE lower('%" + fContactName.replaceAll("'","''").trim() + "%')";
    }
    if(!fEmail.equals("")){
        strFilters	+= " AND lower(Email) LIKE lower('%" + fEmail.replaceAll("'","''").trim() + "%')";
    }
    if(!fStartDate.equals("")){
        strFilters	+= " AND ClientFromDate " + getDateRange(fStartDate);
    }
    if(!fCluster.equals("")){
        strFilters	+= " AND lower( clusterlead ) LIKE lower('%" + fCluster.replaceAll("'","''").trim() + "%')";
    }

    }
    public boolean getAllClients(String ClientID){
      boolean result = false;
      strSQL = "select * from OAM_RM_CLIENTS a where 1=1 "; //old Query
     // strSQL = getAllClientsQry();

       if(!ClientID.equals("0")){
          strSQL=strSQL + "and ClientID="+SQLEncode(ClientID);
      }
      strSQL+=strFilters;
        strSQL+=" ORDER BY lower("+orderField+") "+order+"";
       //System.out.println("Query to get clients is >>>>>>>>>>>>>>>>>"+strSQL);
      try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                result=true;
        }
        catch(Exception e){
            System.out.println("\nError:[default-war/com/d2hs/soam/cm/ClientManager.java]->getAllClients( "+ClientID+" )<- "+strSQL);
        	e.printStackTrace();
        }
      return result;
   }
    private String sqlForClientList	= "SELECT ClientID,ClientName FROM OAM_RM_CLIENTS ORDER BY ClientName";

      /*
      public void setSQLForGroupListing(String userID){
          sqlForClientList	= "SELECT a.ClientID,a.ClientName from OAM_RM_CLIENTS a," +
                  " tbl_GroupAndUser b WHERE a.GroupID = b.GroupID AND b.UserID='" +
                  userID + "' ORDER BY a.GroupName";
      }
      */
    public TreeMap executeQueryForClientList(){
          TreeMap groupList = new TreeMap();
          ResultSet rs;
          PreparedStatement stm;
          groupList.clear();
          try{
              stm = myConn.prepareStatement(strSQL = sqlForClientList);
              rs = stm.executeQuery();
              while(rs.next()) {
                  groupList.put(rs.getString("ClientID"),rs.getString("ClientName"));
              }
              rs.close();
              stm.close();
          } catch(Exception e){
              strSQL += " "+e.getMessage();
          }
          return groupList;
    }

    
    public TreeMap executeQueryForCluster(){
        TreeMap groupList = new TreeMap();
        ResultSet rs;
        PreparedStatement stm;
        groupList.clear();
        String sqlForCluster	= "SELECT loginname,username from  usr_users ORDER BY username asc";
        try{
            stm = myConn.prepareStatement(strSQL = sqlForCluster);
            rs = stm.executeQuery();
            while(rs.next()) {
                groupList.put(rs.getString("loginname"),rs.getString("username"));
            }
            rs.close();
            stm.close();
        } catch(Exception e){
            strSQL += " "+e.getMessage();
        }
        return groupList;
  }
    
    public boolean getLeads(){
        boolean result = false;
        strSQL = "SELECT loginname,username from  usr_users ORDER BY username asc"; //old Query
     
          try
          {
                 Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                  myRS=stmt.executeQuery(strSQL);
                  result=true;
          }
          catch(Exception e){
              System.out.println("\nError:[default-war/com/d2hs/soam/cm/ClientManager.java]->getLeads( )<- "+strSQL);
          	e.printStackTrace();
          }
        return result;
     }

}
