package com.d2hs.soam.rm.CMMI_Report;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CMMIUtil {
	public String getFormattedDateWithMonthName(Date dateToFormat) throws Exception
	{
		String dt = null;
		try{	
		
			DateFormat formatter ;    
            formatter = new SimpleDateFormat("dd-MMM-yy hh:mm");                  
            dt = formatter.format(dateToFormat);
            //System.out.println("Today is " + s);  
             //return s;  
		} catch (Exception e)
		{
			System.out.println("Exception getFormattedDate:"+e);  
		} 
		
	  return dt;
	}
	public String getFormattedDate(Date dateToFormat) throws Exception
	{
		String dt = null;
		try{	
		
			DateFormat formatter ;    
            formatter = new SimpleDateFormat("MM/dd/yyyy");        
            dt = formatter.format(dateToFormat);
            //System.out.println("Today is " + s);
             //return s;
		} catch (Exception e)
		{
			System.out.println("Exception getFormattedDate:"+e);  
		} 
		
	  return dt;
	}
	
	public static String encodeText( String p){
		if ( p== null || "".equals(p.trim())) return "";
		int pLen = p.length();
		int count = 0;
		char c;
        StringBuffer sb = new StringBuffer( pLen+1);
		for(count=0; count < pLen; count++){
			c = p.charAt( count);

            switch(c){
				case '\'' : sb.append("&#39;"); break;	//Quote
				case '"' : sb.append("&#34;"); break;	//Double Quote
				case '<'  : sb.append("&lt;");  break;	//
				case '>'  : sb.append("&gt;");  break;
				case '&'  : sb.append("&amp;"); break;
				case '+'  : sb.append("&#43;"); break;	//plus
				case '-'  : sb.append("&#45;"); break;
				case '/'  : sb.append("&#47;"); break;
                case '\n'  : sb.append("<br>"); break;
				case '\r'  : sb.append(""); break;

				default: sb.append( c);
			}
		}
    String res=sb.toString();       
    return res;
    }	

}
