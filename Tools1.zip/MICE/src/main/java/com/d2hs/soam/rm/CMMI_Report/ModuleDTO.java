package com.d2hs.soam.rm.CMMI_Report;

public class ModuleDTO {

	private String moduleName;
	private int open;
	private int completed;
	private int closed;
	private int total;
	private int completedCount;
	private double avgCompleted;
	private int openCompletedCount;
	private double openCompleted;
	private int closedCount;
	private double avgClosed;
	private int openCompletedClosedCount;
	private double openCompletedClosed;	    
	private int defectiveFix;	

    
	public void setOpen(int s)
	{
		this.open=s;
	}
	public int getOpen()   
	{
		return this.open;
	}
	public void setComplpeted(int s)
	{
		this.completed=s;
	}
	public int getCompleted()
	{
		return this.completed;
	}
	public void setClosed(int s)
	{
		this.closed=s;
	}
	public int getClosed()
	{
		return this.closed;
	}
	public void setTotal(int s)
	{
		this.total=s;
	}
	public int getTotal()
	{
		return this.total;
	}
	
	public void setCompletedCount(int s)
	{
		this.completedCount=s;
	}
	public int getCompletedCount()
	{
		return this.completedCount;
	}
	
	public void setAvgCompleted(double s)
	{
		this.avgCompleted=s;
	}
	public double getAvgCompleted()
	{
		return this.avgCompleted;
	}
	public void setOpenCompletedCount(int s)
	{
		this.openCompletedCount=s;
	}
	public int getOpenCompletedCount()
	{
		return this.openCompletedCount;
	}
	public void setOpenCompleted(double s)
	{
		this.openCompleted=s;
	}
	public double getOpenCompleted()
	{
		return this.openCompleted;
	}
	public void setClosedCount(int s)
	{
		this.closedCount=s;
	}
	public int getClosedCount()
	{
		return this.closedCount;
	}
	public void setAvgClosed(double s)
	{
		this.avgClosed=s;
	}
	public double getAvgClosed()
	{
		return this.avgClosed;
	}
	public void setOpenCompletedClosedCount(int s)
	{
		this.openCompletedClosedCount=s;
	}
	public int getOpenCompletedClosedCount()
	{
		return this.openCompletedClosedCount;
	}
	public void setopenCompletedClosed(double s)
	{
		this.openCompletedClosed=s;
	}
	public double getopenCompletedClosed()
	{
		return this.openCompletedClosed;
	}
	public void setModuleName(String s)
	{
		this.moduleName=s;
	}
	public String getModuleName()
	{
		return this.moduleName;
	}
	
	public void setDefectiveFix(int s)
	{
		this.defectiveFix=s;
	}
	public int getDefectiveFix()
	{
		return this.defectiveFix;
	}	
	
	
}
