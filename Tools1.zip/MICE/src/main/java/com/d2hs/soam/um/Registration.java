package com.d2hs.soam.um;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import java.util.*;
import java.io.ByteArrayInputStream;
import java.util.*;
import java.io.ByteArrayInputStream;
import com.d2hs.soam.common.*;
import com.d2hs.soam.RequestBean;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;


public class Registration extends RequestBean {
    private String strSQL = null;
    private String userName = null;
    private String email = null;
    private String loginName = null;
    private String companyName = null;
    private String dataBaseName = null;
    private String password = null;
    private String oldPassword = null;
    private PreparedStatement myPS = null;
    private Statement stmt = null;
    private String errorStr = "No Error !";
    private String[] userID;
    private String strID = ""; //3.4.13
    private String ID = "";
    private String userTypeCode = "";
    private int userType = 0;
    private int companyID = 0;
    private String address = null;
    private String DBName = null;
    private int recPerPage = 50;
    private String comment = "";
    private String CSMName = "";
    private String CSMEmail = "";
    private String CSMAdmin = "";
    private String strWhere = " WHERE (1 = 1) ";
    private String employerID="";
    private String ChangePassword="";
    private int UserStatus=0;
    private int pageNo = 1;//default page is the first page
    private int currentRec = 0;//current record position (always before the first record to be read)
    private int tag = 1;
    private int frameCount = 1;

    private String Tbl_LogPattern = "[HawkeyeUser].HawkeyeLog.dbo.Tbl_Log_LogPattern";

    public void setComment(String comment) {
        this.comment = comment;
    }


    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setFrameCount(int frameCount) {
        this.frameCount = frameCount;
    }

    public int getFrameCount() {
        return frameCount;
    }

    public int getPageSize() {
        return pageSize;
    }

    public int getCurrentRec() {
        return currentRec;
    }

    public void setEmployerID(String s){
        this.employerID=s;
    }
    public String getEmployerID(){
        return this.employerID;
    }

    public String sendEmailToUser() {
        String msg = "";
        return msg;

    }
    public boolean moveNext() {
        if (tag < pageSize) {
            boolean tmp = false;
            try {
                tmp = myRS.next();
            } catch (SQLException ex) {
            }
            tag++;
            return tmp;
        } else {
            return false;
        }
    }

    public boolean moveNext(int all) {
        boolean tmp = false;
        try {
            tmp = myRS.next();
        } catch (SQLException ex) {
            tmp = false;
        }
        return tmp;
    }

    private String companyTypeCode = "";

    public void setCompanyTypeCode(String companyTypeCode) {
        this.companyTypeCode = companyTypeCode;
    }

    public String getCompanyTypeCode() {
        return this.companyTypeCode;
    }


    public void setUserID(String[] userID) {
        this.userID = userID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setLoginName(String a) {
        loginName = a;
    }

    public void setPassword(String a) {
        password = a;
    }

    public void setOldPassword(String a) {
        oldPassword = a;
    }

    public void setuserType(int userType) {
        this.userType = userType;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public void setDBName(String DBName) {
        this.DBName = DBName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setUserTypeCode(String utc) {
        this.userTypeCode = utc;
    }

    public int getUserType() {
        return userType;
    }

    public void setChangePassword(String value) {
         this.ChangePassword=value;
    }
    public void setUserStatus(int value) {
         this.UserStatus=value;
    }
    public String getUserTypeCode() {
        return userTypeCode;
    }

    public int getRecPerPage() {
        return recPerPage;
    }

    public String getError() {
        return (errorStr);
    }


    public void validSU() {
        userType = 0;
    }

    public boolean getUserDetail(String userID) {
        boolean retVal = false;
        try {
            stmt = myConn.createStatement();
            String sql = "select UserName,lvl,UserID,Email,LoginName,CSM_Admin from usr_Users where UserID='"+userID+"'";
            myRS = stmt.executeQuery(sql);
            retVal = myRS.next();
            if (retVal) {
                strID = myRS.getString("UserID");
                userName = myRS.getString("UserName");
                this.email = myRS.getString("Email");
                userType = myRS.getInt("lvl");
                CSMAdmin = myRS.getString("CSM_Admin");
            }
        } catch (SQLException e) {
            retVal = false;
            e.printStackTrace();
        }
        return retVal;
    }

    public boolean checkLoginName() {
        boolean retVal = true;
        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery("select LoginName from users where LoginName=" + SQLEncode(loginName));
            while (myRS.next()) {
                retVal = false;
            }
        } catch (SQLException e) {
            retVal = false;
        }

        return (retVal);
    }
    public boolean checkDuplicateLoginName(String loginName) {
        boolean retVal = true;
        try {
            stmt = myConn.createStatement();
            strSQL="select count(*) from usr_users where LoginName=" + SQLEncode(loginName);
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            if(myRS.getInt(1)>0)
                 retVal = false;
        } catch (SQLException e) {
            System.out.println("Exception occurs"+e.getMessage());
            retVal = false;
        }
        catch (Exception e) {
            System.out.println("Exception occurs"+e.getMessage());
            retVal = false;
        }
        return (retVal);
    }

    public boolean insertUser() throws Exception {
        boolean retVal = false;
        String userID = "";
        int recCount = 0;
        PreparedStatement ps = null;
        String strSQL1 = "";
        Statement st = null;

        strSQL = "insert into  usr_Users (UserName, LoginName,oamstatus, D2PWD,CHANGEPWD,  Email, lvl,  UserStatus) values(?,?,'1',return_hash('"+loginName+"'||'"+password+"','90A80378D3A539BD'),'N',?,?,?)"; //password=pwdencrypt(?)

        try {
            myPS = myConn.prepareStatement(strSQL);
            myPS.setString(1, userName);
            myPS.setString(2, this.loginName);
            myPS.setString(3, email);
            myPS.setInt(4, this.userType);
            myPS.setInt(5,this.UserStatus);
            st = myConn.createStatement();
            recCount = myPS.executeUpdate();
            retVal = true;
        }
        catch (SQLException e) {
            System.out.print("@@@@@@@@@@"+e.toString());
        }
     
        return retVal;
    }
    
    
    public boolean changePassword(String username,String userid, String pass) throws Exception {
        boolean retVal = false;
         strSQL="update usr_users set d2pwd=return_hash('"+username+"'||'"+pass+"','90A80378D3A539BD') where userID="+userid;
        // System.out.print("@@@@@@@@@@"+strSQL);
        try {
        	Statement st=myConn.createStatement();
        	st.execute(strSQL);
        	
            retVal = true;
        }
        catch (SQLException e) {
        	e.printStackTrace();
            System.out.print("@@@@@@@@@@"+e.toString());
        }
     
        return retVal;
    }

    public void updateUserRole(String UserID, String isSuperAdmin,String isProductAdmin,String isRequestAdmin){
    	strSQL="select count(*) as count from oam_rm_userrole where userid="+UserID;
    	try{
    	Statement st=myConn.createStatement();
    	ResultSet rs=st.executeQuery(strSQL);
    	while(rs.next()){
    		if(rs.getInt("count")==0)
    			strSQL="insert into oam_rm_userrole values('"+isRequestAdmin+"',"+UserID+",'"+isSuperAdmin+"','"+isProductAdmin+"')";
    		else
    			strSQL="update oam_rm_userrole set roleid= '"+isRequestAdmin+"',isSuperAdmin= '"+isSuperAdmin+"',isProductAdmin= '"+isProductAdmin+"' where userID="+UserID;
    	}
    	System.out.println(strSQL);
    	st.execute(strSQL);
    	}
    	catch (SQLException e) {
    		System.out.println("\nError:[default-war/com/d2hs/soam/um/Registration.java]->updateUserRole( "+UserID+","+isSuperAdmin+","+isProductAdmin+","+isRequestAdmin+")<- "+strSQL);
            System.out.print("@@@@@@@@@@@@"+e.toString());
    	}
    }
    		
     public boolean updateUser(String UserID, String UserName,
                                     String Email){

         boolean result = false;
         strSQL = "UPDATE usr_users SET " +
                    " UserName = " + SQLEncode(UserName) + "," +
                     " Email = " + SQLEncode(Email) ;
            
            strSQL += " WHERE UserID = " + SQLEncode(UserID);
            System.out.println ("Update user --" + strSQL);
         try
        {
               Statement stmt=myConn.createStatement();
               stmt.executeUpdate(strSQL);
               result=true;
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
    }

    public boolean updateUser() throws Exception {
        strSQL = "update usr_Users set UserName=?, Email=?, UserTypeCode=?, EmployerID=? where UserID=?"; //password=pwdencrypt(?)
        boolean retVal = true;
        int recCount = 0;
        try {
            myPS = myConn.prepareStatement(strSQL);
            myPS.setString(1, userName);
            myPS.setString(2, email);
            myPS.setString(3, this.userTypeCode);
            myPS.setString(4,this.employerID);
            myPS.setString(5, ID);

            recCount = myPS.executeUpdate();
            if (recCount > 0) {
                retVal = true;
            }
        } catch (SQLException e) {
            retVal = false;
            errorStr = "update users set userName='" + userName + "', email='" + email + "',employerid="+this.employerID+" where userID=" + ID + e;//e.getSQLState();
            System.out.println("error updating >>>>>>"+errorStr);
        }
        return (retVal);
    }

    public boolean changePassword(String userid, String password) throws Exception {
        boolean changed = false;
        String strTable = " (select top 3 Password from ztbl_LogPassword where UserID = '" + userid + "' order by DateStamp desc) as a ";
        String strSQL1 = " select count(*) as count from " + strTable + "  where pwdcompare(" + SQLEncode(password) + ",convert(nvarchar,[password]))=1";
        strSQL = "update usr_Users set password=pwdencrypt('" + password + "') where UserID='" + userid + "'"; //password=pwdencrypt(?)
        String strSQL2 = " update usr_Users set ChangePassword = 'n' where UserID = '" + userid + "'";
        String strSQL3 = " insert into ztbl_LogPassword(UserID,Password,DateStamp) values('"
        + userid + "',pwdencrypt(" + SQLEncode(password) + "),getDate())";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL1);
            rs.next();
            if (rs.getInt("count") == 0) {
                st.executeUpdate(strSQL);
                st.executeUpdate(strSQL2);
                st.execute(strSQL3);
                changed = true;
            }
        } catch (SQLException e) {
            System.out.println("Error:" + e);
        }

        return changed;
    }
    public void changePasswordBySU(String userid, String password) throws Exception {
        strSQL = "update usr_Users set password=pwdencrypt(" + SQLEncode(password) + ") where UserID='" + userid + "'"; //password=pwdencrypt(?)
        try {
            Statement st = myConn.createStatement();
            st.executeUpdate(strSQL);
        } catch (SQLException e) {
            System.out.println("" + e);
        }
    }
    public boolean changeSUPassword(String password, String user_id) throws Exception {
        boolean changed = false;
        strSQL = "update usr_Users set password=pwdencrypt(" + SQLEncode(password) + ") where UserID =  '" + user_id + "'"; //password=pwdencrypt(?)
        String strTable = " (select top 3 Password from ztbl_LogPassword where UserID =  '" + user_id + "' order by DateStamp desc) as a ";
        String strSQL1 = " select count(*) as count from " + strTable + " where pwdcompare(" + SQLEncode(password) + ",convert(nvarchar,[password]))=1";
        String strSQL2 = " update usr_Users set ChangePassword = 'n' where UserID =  '" + user_id + "'";
        String strSQL3 = " insert into ztbl_LogPassword(UserID,Password,DateStamp) values("
        + user_id + ",pwdencrypt(" + SQLEncode(password) + "),getDate())";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL1);
            rs.next();
            if (rs.getInt("count") == 0) {
                st.executeUpdate(strSQL);
                st.executeUpdate(strSQL2);
                st.execute(strSQL3);
                changed = true;
            }
        } catch (SQLException e) {
            System.out.println("" + e);

        }
        return changed;

    }
   

    public boolean showUser() {
        boolean retVal = false;
        try {
            strSQL = "select userID,userName,email,loginName,userType,companyID from users where userID='" + ID + "'";
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery(strSQL);
            retVal = true;
        } catch (SQLException e) {
            retVal = false;
        }

        return (retVal);
    }

    public String getData(String s) {
        String s1 = null;
        try {
            s1 = myRS.getString(s);
        } catch (SQLException sqlexception) {
            errorStr = "error occured while fetching data from resultset:" + sqlexception;
        }
        return s1;
    }


    public String getDataBaseName() {
        return dataBaseName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public int getCompanyID() {
        return companyID;
    }

    public String getUserID() {
        return ID;
    }

    public boolean showUsers() {
        boolean retVal = false;
        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery("select userID,userName,email,loginName,userType,companyID from users where companyID=" + companyID + " order by loginName");
            retVal = true;
        } catch (SQLException e) {
            retVal = false;
        }

        return (retVal);
    }


    public String getVal(String a) {
        String retVal = null;
        try {
            retVal = myRS.getString(a);
        } catch (SQLException e) {
            retVal = null;
            errorStr = "error occured during fetching records.";
        }
        return (retVal);
    }


    public void cleanup() {
    }

    public String getSQL() {
        return strSQL;
    }


    public boolean deleteUsers() {
        boolean retVal = true;
        strSQL = "delete from users where userID=";
        String strTmp = null;
        int recCount = 0;
        try {
            //stmt=myConn.createStatement();
            for (int i = 0; i < userID.length; i++) {
                strTmp = strSQL + " '" + userID[i] + "'";
                //recCount=recCount+stmt.executeUpdate(strTmp);
            }
        } catch (Exception e) {
            retVal = false;
            errorStr = "error occured during deleting user." + e;
        }
        return (retVal);
    }


    public boolean checkOldPassword(String userID1, String password) {
        boolean retVal = true;
        strSQL = "select count(UserID) as count from usr_Users where UserID='" + userID1 + "' and pwdcompare(" + SQLEncode(password) + ",convert(nvarchar,[password]))=1";
        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            if (myRS.getInt("count") > 0)
                return true;
            else
                return false;

        } catch (SQLException e) {
            System.out.println("Error while checking old password:" + e);
            return false;
        }


    }


    //codes for administrating company
    public void insertCompany(String appid,String servername, String dbusername, String dbpassword, String ClientID, String version)
    throws Exception {
        //        checkApplicationID();
        strSQL = "INSERT INTO ztbl_Applications (ApplicationID,ApplicationName,ClientID,DatabaseServerName,DatabaseName," +
        "DatabaseUserName,DatabasePassword,CompanyTypeCode,version) VALUES(" +
                SQLEncode(appid) + "," +
                SQLEncode(companyName) + "," +
                SQLEncode(ClientID) + "," +
                SQLEncode(servername) + "," +
                SQLEncode(DBName) + "," +
                SQLEncode(dbusername) + "," +
                SQLEncode(dbpassword) + "," +
                SQLEncode(companyTypeCode) + "," +
                SQLEncode(version) + ")";
        try {
            Statement st = myConn.createStatement();
            st.execute(strSQL);
            //            strSQL = " update ztbl_Applications set ApplicationID = SeedApplicationID where ApplicationName = '" + companyName + "'";
            //            st.execute(strSQL);
        } catch (SQLException e) {
            throw new Exception("" + e);
        }
    }

    public void checkApplicationID() throws Exception {
        CallableStatement cstmt;
        strSQL = "{ call sp_CheckApplicationID() }";
        cstmt = myConn.prepareCall(strSQL);
        cstmt.execute();
    }

    public void updateCompany(String companyid, String dbservername, String databasename, String databaseusername, String databasepassword, String version)
    throws Exception {
        strSQL = "update ztbl_Applications set version ='" + version + "',CompanyTypeCode ='" + companyTypeCode + "',ApplicationName ='" + companyName.replace(' ', '_').trim() + "',DatabaseServerName ='" + dbservername + "',DatabaseName ='" + databasename + "',DatabaseUserName ='" + databaseusername + "',DatabasePassword ='" + databasepassword + "' where ApplicationID ='" + companyid + "'";
        try {
            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
            throw new Exception("" + e);
        }
    }

    public boolean selectDatabaseNames() {
        boolean retVal = false;

        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery("sp_helpdb");
            retVal = true;
        } catch (SQLException se) {
            errorStr = "error occured while selecting database:" + se;
        }

        return retVal;
    }

    public boolean selectDatabaseNames(String dbsname, String username, String password) {
        boolean retVal = false;

        try {
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery("sp_helpdb");
            retVal = true;
        } catch (SQLException se) {
            errorStr = "error occured while selecting database:" + se;
        }

        return retVal;
    }

    public boolean getDatabaseNamesForIP(String ip, String username, String password) {
        String strSQL = "EXEC    sp_addlinkedserver    @server='server2', @srvproduct='', " +
        "@provider='SQLOLEDB', @datasrc='" + ip + "' " +
        //" go "+
        " exec sp_addlinkedsrvlogin 'server2', 'false', NULL, '" + username + "', '" + password + "' " +
        //" go "+
        " EXEC sp_serveroption 'server2', 'rpc out', 'true' ";
        // " go "+
        String strSQL2 = " select * from server2.master.dbo.sysdatabases  where name like '%%' ";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt.execute(strSQL);
            stmt.close();
            stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            return true;
        } catch (SQLException e) {
            System.out.println("erro while gettin databasenames ");
            e.printStackTrace();
        }
        return false;
    }

    public String getClientIDForApplication(String ip, String username, String password, String dbName,String param) {
        String tmpStr = "";
        String strSQL = "EXEC    sp_addlinkedserver    @server='server2', @srvproduct='', " +
        "@provider='SQLOLEDB', @datasrc='" + ip + "' " +
        " exec sp_addlinkedsrvlogin 'server2', 'false', NULL, '" + username + "', '" + password + "' " +
        " EXEC sp_serveroption 'server2', 'rpc out', 'true' ";
        String parm="";
        if(!param.equalsIgnoreCase("Client"))
            parm="ApplicationID";
        else
            parm="ClientID";

        String strSQL2 = " select "+parm+" from server2." + dbName + ".dbo.ztbl_Clients";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            if(param.equalsIgnoreCase("Client")){
                stmt.execute(strSQL);
                stmt.close();
                stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            }
            myRS = stmt.executeQuery(strSQL2);
            myRS.absolute(1);
            tmpStr = "" + myRS.getString(parm);

        } catch (SQLException e) {
            System.out.println("erro while gettin databasenames ");
            e.printStackTrace();
        }
        return tmpStr;
    }

    public void insertClientIfNotExists(String clientID, String clientName) {
        //First Check if this client exists
        if (isClientIDExists(clientID) == 0) {
            try {
                strSQL = "INSERT INTO ztbl_Clients (ClientID,ClientName) VALUES ('" + clientID +
                "','" + clientName.replaceAll("'", "''") + "')";
                Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                stmt.execute(strSQL);
            } catch (Exception e) {
            }
        }
    }

    public int isClientIDExists(String clientID) {
        int clientExists = 0;
        strSQL = " select COUNT(*) AS RecCount FROM ztbl_Clients WHERE ClientID='" + clientID + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.absolute(1);
            clientExists = myRS.getInt("RecCount");
        } catch (SQLException e) {
            System.out.println("erro while gettin databasenames ");
            e.printStackTrace();
            clientExists = -1;
        }
        return clientExists;
    }

    public void closeDatabaseNamesConnection() {
        String strSQL2 = " sp_dropserver 'server2','droplogins'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stmt.execute(strSQL2);
        } catch (SQLException e) {
            System.out.println("erro while gettin databasenames ");
            e.printStackTrace();
        }

    }

    public String getDBName() {
        String strDBName;
        strDBName = "n/a";
        try {
            strDBName = myRS.getString("name");
        } catch (SQLException se) {
            errorStr = "error occured while selecting database:" + se;
        }

        return strDBName;
    }


    public boolean getCompanyDetail(String s) {
        boolean flag = false;
        try {
            stmt = super.myConn.createStatement();
            myRS = stmt.executeQuery("select * from ztbl_Applications where ApplicationID='" + s+"'");
            myRS.next();
            myRS.absolute(1);
            flag = true;
        } catch (SQLException sqlexception) {
            errorStr = "error occured while listing company:" + sqlexception;
        }
        return flag;
    }

    public String getLoginName() {
        return loginName;
    }

    public String getUserID(String username) {
        String userID = "";

        String strSQL2 = " select UserID,UserName,LoginName,lvl,email from usr_Users where username='" + username + "'";

        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            if (myRS.next())
                userID = "" + myRS.getString("UserID");
        } catch (SQLException e) {
            System.out.println("error : no matchin username" + strSQL2);
        }
            return userID;

    }
    
    public String getUserIDByLoginname(String loginname) {
        String userID = "";

        String strSQL2 = " select UserID,UserName,LoginName,lvl,email from usr_Users where loginname='" + loginname + "'";

        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            if (myRS.next())
                userID = "" + myRS.getString("UserID");
        } catch (SQLException e) {
            System.out.println("error : no matchin username" + strSQL2);
        }
            return userID;

    }

    public void getUserInfoByName(String username) {
        String userid = this.getUserID(username);
        this.getUserInfo(userid);
    }

    public void getUserInfo(String userid) {
        strSQL = "SELECT  UserID, LoginName, UserName , email , ChangePassword,lvl,CSM_Admin  from usr_Users where UserID = '" + userid + "'";

        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.absolute(1);
            setEmail("" + myRS.getString("email"));
        } catch (SQLException e) {
        }

    }


    public void getUsers() {

        String strSQL = "SELECT UserID,UserName,LoginName,email,ChangePassword,lvl,CSM_Admin from usr_Users ORDER BY UserName";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.absolute(1);
        } catch (SQLException e) {
            System.out.println("error : " + e);
        }
    }

    /********* methods added by pawan for hawkeye2oam ************/

    public void getHawkeyeUsers(String groupID) {
        //String strSQL = "SELECT a.*,b.* FROM usr_Users a LEFT JOIN tbl_Hawkeye2OAM b ON a.user_id=b.HawkeyeUserID";
        String strSQL = "";
        if (groupID.equals("")) {
            strSQL = "SELECT  UserName,UserName,LoginName,email,lvl,OAMUserTypeCode,OAMStatus FROM usr_Users ORDER BY UserName";
        } else {
            strSQL = "select a.UserID,a.UserName,a.LoginName,a.Email,a.lvl,a.OAMUserTypeCode,a.OAMStatus from usr_Users a, ztbl_GroupAndUser b where a.UserID = b.UserID and b.GroupID='" + groupID + "'  ORDER BY a.OAMStatus DESC, a.LoginName, a.UserName";
        }

        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.absolute(1);
        } catch (SQLException e) {

        }
    }

    public boolean getListOfHawkeyeUserTypes(String UserID, String GroupID) {
        boolean retVal = false;
        //String strSQL	= "";
        if (UserID.trim().equals("")) {
            strSQL = "SELECT UserTypeCode,UserTypeDesc FROM HawkeyeOAM.dbo.tbl_UserTypes ORDER BY UserTypeDesc";
        } else {
            if (GroupID.trim().equals("")) {
                strSQL = "SELECT a.UserTypeCode,a.UserTypeDesc,b.OAMStatus FROM HawkeyeOAM.dbo.tbl_UserTypes a,usr_Users b WHERE a.UserTypeCode=b.OAMUserTypeCode AND b.UserName='" + UserID + "'";
            } else {
                strSQL = "SELECT DISTINCT a.UserTypeCode,a.UserTypeDesc,b.OAMStatus,c.GroupID FROM HawkeyeOAM.dbo.tbl_UserTypes a,usr_Users b ,ztbl_GroupAndUser c WHERE a.UserTypeCode=b.OAMUserTypeCode AND b.UserID=c.UserID AND c.GroupID='" + GroupID + "' AND b.UserID='" + UserID + "'";
            }
        }

        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            retVal = true;
        } catch (SQLException se) {
            retVal = false;
        }
        return (retVal);
    }

    public void assignOAMAccess(String allUserIDs, String allUserTypes, String allOAMStatus) {
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            /***********First set access of all users off *******************/
            //stmt.execute("UPDATE tbl_Hawkeye2OAM SET OAMStatus=0");
            stmt.execute("UPDATE usr_Users SET OAMStatus=0 WHERE OAMStatus=1");
            /****************************************************************/

            StringTokenizer uids = new StringTokenizer(allUserIDs, ",");
            StringTokenizer utypes = new StringTokenizer(allUserTypes, ",");
            StringTokenizer stats = new StringTokenizer(allOAMStatus, ",");
            //String strSQL			= "";

            while (stats.hasMoreElements()) {
                String uid = uids.nextElement().toString().trim();
                String utype = utypes.nextElement().toString().trim();
                String stat = stats.nextElement().toString().trim();
                /***************** NOW TURN ON OAM STATUS and set the user type ***/
                if (stat.equals("1")) {
                    strSQL = "UPDATE usr_Users SET OAMStatus=1, OAMUserTypeCode='" + utype + "' WHERE UserID = '" + uid + "'";
                    stmt.execute(strSQL);
                }
            }
        } catch (Exception e) {

        }
    }
    /*********Method added to check whether a user is member of certain group*******/
    // 3.4.12
    public boolean checkUserGroup(String userID, String groupName) {
        boolean retVal = false;
        strSQL = "SELECT 'Y' AS isMember FROM ztbl_GroupAndUser a, ztbl_Groups b "
        + " WHERE a.groupID=b.GroupID and a.UserID='" + userID + "' AND ltrim(rtrim(b.Groupname))='" + groupName + "'";


        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet myRS = stmt.executeQuery(strSQL);
            //myRS.absolute(1);
            retVal = myRS.next();
            myRS.close();
            stmt.close();
        } catch (SQLException e) {
            retVal = false;
        }
        return retVal;
    }


    /********* methods added by pawan for hawkeye2oam ************/


    public String getCompanyID(String companyname) {
        String companyID = null;

        String strSQL2 = " select * from ztbl_Applications where ApplicationName ='" + companyname + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            myRS.absolute(1);
            companyID =  myRS.getString("ApplicationID");
        } catch (SQLException e) {
            System.out.println("error : no matchin companyname");
            e.printStackTrace();
        }
        return companyID;
    }

    public void getCompanyInfos() {
        getCompanyInfos("");
    }

    public void getCompanyInfos(String userID) {

        strSQL = "select a.ApplicationID,a.ApplicationName,a.seedApplicationID," +
        "a.ClientID,a.DatabaseServerName,a.DatabaseName," +
        "a.DatabaseUserName,a.DatabasePassword,a.version,a.CompanyTypeCode" +
        " from ztbl_Applications a ";
        if (!userID.equals("")) {
            strSQL += " INNER JOIN ztbl_UserAndApplication b on a.ApplicationID=b.ApplicationID " +
            " WHERE b.UserID='" + userID + "' AND b.AllowAccess='Y'";
        }
        strSQL += " ORDER BY a.ApplicationName";
        try {

            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.absolute(1);
        } catch (SQLException e) {

        }
    }


    public String getCompanyName(String companyid) {
        String companyname = null;

        String strSQL2 = " select * from ztbl_Applications where ApplicationID='" + companyid + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            myRS.absolute(1);
            companyname = "" + myRS.getString("ApplicationName");
        } catch (SQLException e) {
            System.out.println("error : ");
            e.printStackTrace();
        }
        return companyname;
    }

    public boolean getDBInfo(String dbname) {
        boolean tmp = false;
        String strSQL2 = " select * from ztbl_Applications where DatabaseServerName='" + dbname + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            myRS.absolute(1);
            tmp = true;
        } catch (SQLException e) {
            System.out.println("error : ");
            e.printStackTrace();
        }
        return tmp;
    }


    public Vector getCompaniesForUser(String userid) {
        strSQL = "  select distinct b.ApplicationID, b.ApplicationName "
        + " from "
        + " ztbl_UserAndApplication as a, "
        + " ztbl_Applications b "
        + " where  (a.AllowAccess='y' and "
        + "        a.UserID = '" + userid + "' "
        + "        and a.ApplicationID = b.ApplicationID "
        + "        or( b.ApplicationID in ( "
        + "            select ApplicationID from ztbl_GroupAndApplication a join ztbl_GroupAndUser b on a.GroupID=b.GroupID  "
        + "          where  b.UserID='" + userid + "') "
        + "            and b.ApplicationID not in ( "
        + "           select ApplicationID from ztbl_UserAndApplication where UserID = '" + userid + "' and Upper(AllowAccess) = 'N' "
        + "             ))) "
        + " order by b.ApplicationName ";

        Vector v = new Vector();
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                v.add( myRS.getString("ApplicationID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("getCompaniesforuser" + strSQL);
        }
        return v;
    }

    public boolean listCompaniesForUser(String userid) {
        boolean retValue = false;
        //database structural change
        strSQL = "  select distinct b.ApplicationID, b.ApplicationName, CAST(MONTH(b.ProcessedDate) as varchar)+'-'+CAST(DATEPART(dd,b.ProcessedDate) as varchar)+'-'+SUBSTRING(CAST(YEAR(b.ProcessedDate) as varchar),3,2) AS ProcessedDate"
        + " from "
        + " ztbl_UserAndApplication as a, "
        + " ztbl_Applications b "
        + " where b.Version like '4.%' and "
        +  " a.AllowAccess='y' and "
        + "        (a.UserID = '" + userid + "' "
        + "        and a.ApplicationID = b.ApplicationID "
        + "        or( b.ApplicationID in ( "
        + "            select ApplicationID from ztbl_GroupAndApplication a join ztbl_GroupAndUser b on a.GroupID=b.GroupID  "
        + "          where  b.UserID='" + userid + "') "
        + "            and b.ApplicationID not in ( "
        + "           select ApplicationID from ztbl_UserAndApplication where UserID = '" + userid + "' and Upper(AllowAccess) = 'N' "
        + "             ))) "
        + " order by b.ApplicationName ";


        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            retValue = true;
        } catch (SQLException e) {
        }
        return retValue;
    }

    public boolean listCompaniesForUser(String userid, String orderColumn) {
        boolean retValue = false;
        //database structural change
        strSQL = "  select distinct b.version,b.ApplicationID, b.ApplicationName, b.ProcessedDate, CASE WHEN MONTH(b.ProcessedDate) < 10 THEN '0' ELSE '' END + CAST(MONTH(b.ProcessedDate) as varchar)+'-'+ CASE WHEN DATEPART(dd,b.ProcessedDate) < 10 THEN '0' ELSE '' END + CAST(DATEPART(dd,b.ProcessedDate) as varchar)+'-'+SUBSTRING(CAST(YEAR(b.ProcessedDate) as varchar),3,2) AS DisplayDate"
        + " from "
        + " ztbl_UserAndApplication as a, "
        + " ztbl_Applications b "
//        + " where  b.Version like '4.%' "
        + " where (1=1) "
        + " and (a.AllowAccess='y' and "
        + "        a.UserID = '" + userid + "' "
        + "        and a.ApplicationID = b.ApplicationID "
        + "        or( b.ApplicationID in ( "
        + "            select ApplicationID from ztbl_GroupAndApplication a join ztbl_GroupAndUser b on a.GroupID=b.GroupID  "
        + "          where  b.UserID='" + userid + "') "
        + "            and b.ApplicationID not in ( "
        + "           select ApplicationID from ztbl_UserAndApplication where UserID = '" + userid + "' and Upper(AllowAccess) = 'N' "
        + "             ))) "
        + " order by "+orderColumn;


        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            retValue = true;
        } catch (SQLException e) {
        }
        return retValue;
    }

    public boolean isViewableByUser(String userid, String companyid) {
        String strSQL = "SELECT count(*) as count from ztbl_UserAndApplication where UserID ='" + userid + "' and " +
        " ApplicationID = '" + companyid + "' and Upper(AllowAccess) = 'y' ";
        int count = 0;
        try {

            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);
            rs.next();
            count = rs.getInt("count");
            if (count > 0)
                return true;
            else
                return false;

        } catch (SQLException e) {
            System.out.println("" + e);
            e.printStackTrace();
            return false;
        }

    }

    public String getRightOfUser(String userid, String companyid) {
        strSQL = "SELECT UPPER(AllowAccess) AS AllowAccess from ztbl_UserAndApplication where UserID ='" + userid + "' and " +
        " ApplicationID = '" + companyid + "' ";
        String right = "";
        try {

            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);
            rs.next();
            right = rs.getString("AllowAccess");

        } catch (SQLException e) {
            System.out.println("" + e);
            e.printStackTrace();
        }
        return right;

    }


    public void updateRight(String userid, String companyID, String right) {
        try {
            Statement st = myConn.createStatement();

            strSQL = "update ztbl_UserAndApplication set AllowAccess = '" + right + "' where "
            + " UserID ='" + userid + "' and ApplicationID='" + companyID + "'";

            if (st.executeUpdate(strSQL) == 0) {
                strSQL = "INSERT INTO ztbl_UserAndApplication (UserID,ApplicationID,AllowAccess)" +
                " VALUES ('" + userid + "','" + companyID + "','" + right + "')";

                st.execute(strSQL);
            }
            //if the user is not allowed access to the front then
            //all of the security and misc rights of that user for the front
            //will be removed
            String sql = "";
            if (!right.toLowerCase().equals("y")) {
                //first remove the security framework
                sql = "delete from ztbl_SecurityLevelForUser where UserApplicationID = "
                + " (Select SeedUserApplicationID from ztbl_UserAndApplication where UserID='" + userid + "' "
                + " and ApplicationID='" + companyID + "')";

                st.execute(sql);

                //now remove any misc right
                sql = "delete from ztbl_RightsForUserAndApplication where UserApplicationID = "
                + " (Select SeedUserApplicationID from ztbl_UserAndApplication where UserID='" + userid + "' "
                + " and ApplicationID='" + companyID + "')";

                st.execute(sql);


            }
        } catch (SQLException e) {
            System.out.print("" + e);
        }
    }


    public void deleteRights(String userid) {
        String strSQL = "delete from ztbl_RightsForUser where UserID ='" + userid + "'";
        try {

            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
        }

    }


    //This function deletes user right and associated misc rights
    //of the user for that company
    public void deleteRights(String userid, String companyID) {
        //   String strSQL = "delete from ztbl_UserAndApplication where UserID ='"+userid+"' and ApplicationID='"+companyID+"'";
        //			DELETE FROM tbl_UserMiscRights where UserCompID in (select distinct [ID] from tbl_UserRights where [user_ID]=45 and company_id=39)
        //String strSQL1 = "DELETE FROM ztbl_RightsForUserAndApplication where UserApplicationID in (select distinct [UserApplicationID] from ztbl_UserAndApplication where [UserID]='"+userid+"' and ApplicationID='"+companyID+"')";
        String strSQL = "update ztbl_UserAndApplication set AllowAccess = 'N' where "
        + " UserID ='" + userid + "' and ApplicationID='" + companyID + "'";
        try {

            Statement st = myConn.createStatement();
            st.executeUpdate(strSQL);
        } catch (SQLException e) {
            System.out.print("" + e);
        }

    }


    public void deleteRightsForCompany(String companyid) {
        strSQL = "delete from tbl_UserRights where company_id =" + companyid;
        try {

            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
            strSQL = e.toString();
        }

    }


    public void addRights(String userid, String companyid) {

        String strSQL = " update ztbl_UserAndApplication set AllowAccess = 'Y' where UserID = '" + userid + "' and "
        + " ApplicationID  = '" + companyid + "' ";

        try {

            Statement st = myConn.createStatement();
            if (st.executeUpdate(strSQL) < 1) {
                strSQL = "insert into ztbl_UserAndApplication (UserID,ApplicationID)  values('" + userid +
                "','" + companyid + "')";
                st = myConn.createStatement();
                st.execute(strSQL);
            }
        } catch (SQLException e) {
            System.out.print("" + e + strSQL);
        }

        /*
        MiscRights temp = new MiscRights();
        temp.setDataBaseName(temp.getUserDatabaseName());
        Hashtable h = temp.getSections();
        Enumeration enu = h.keys();
        while(enu.hasMoreElements())
        {
            String id = (String) enu.nextElement();
            if(!temp.getDefaultAccess(id))
            {
                 temp.updateMR(userid,companyid,id,"N");
            }
            else
            {
                 temp.updateMR(userid,companyid,id,"Y");
            }
        }
         */
    }


    public String getUserNameFromId(String userid) {
        String uname = null;

        String strSQL2 = " select UserName from usr_Users where userid='" + userid + "'";

        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL2);
            myRS.absolute(1);
            uname = "" + myRS.getString("UserName");
        } catch (SQLException e) {
            System.out.println("error : no matchin username");
            e.printStackTrace();
        }
        return uname;
    }

    public boolean deleteUsers(String userid) {

        boolean isDelete = false;
        String strSQL = "delete from usr_Users where UserID ='" + userid + "'";
        try {

            Statement st = myConn.createStatement();
            st.execute(strSQL);
            isDelete = true;
        } catch (SQLException e) {
            System.out.println("" + e);
            strSQL = e.toString();
        }
        this.deleteRights(userid);
        return isDelete;
    }

    public void deleteCompanies(String companyid) {
        this.deleteRightsForCompany(companyid);
        strSQL = "delete from ztbl_Applications where ApplicationID ='" + companyid + "'";
        try {

            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
            System.out.println("" + e);
        }

    }

    public void changeCompanyDatabase(String companyid, String databasename) {
        strSQL = "update ztbl_Applications set DatabaseName ='" + databasename + "' where ApplicationID ='" + companyid + "'";
        try {
            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
            System.out.println(":" + e);


        }

    }

    public void changeCompanyServerAndDatabase(String companyid, String dbservername, String databasename, String databaseusername, String databasepassword) {
        strSQL = "update ztbl_Applications set DatabaseServerName ='" + dbservername + "',DatabaseName ='" + databasename + "',DatabaseUserName ='" + databaseusername + "',DatabasePassword ='" + databasepassword + "' where ApplicationID ='" + companyid + "'";
        try {
            Statement st = myConn.createStatement();
            st.execute(strSQL);
        } catch (SQLException e) {
            System.out.println(":" + e);


        }

    }

    public boolean checkOldSUPassword(String pass) {

        strSQL = "select count(UserID) as count from usr_Users where lvl= 0 and pwdcompare('" + pass + "',convert(nvarchar,[password]))=1";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);
            rs.next();
            if (rs.getInt("count") > 0)
                return true;
            else
                return false;
        } catch (SQLException e) {
            System.out.println("check su :" + e);
            return false;

        }
    }

    public void processChangePasswordStatus(String sy, String sn) {
        String sql1 = "",sql2 = "";
        try {
            Statement st = myConn.createStatement();
            if (sy.trim().length() > 1) {
                sql1 = " update usr_Users set ChangePassword = 'y' where UserID in (" + sy.substring(1, sy.lastIndexOf(",")) + ")";
                st.executeUpdate(sql1);
            }
            if (sn.trim().length() > 1) {
                sql2 = " update usr_Users set ChangePassword = 'n' where UserID in (" + sn.substring(1, sn.lastIndexOf(",")) + ")";
                st.executeUpdate(sql2);
            }

        } catch (Exception e) {

        }

    }

    // modified by : rajeev maskey
    // modified date: oct 22,2002
    // changes the super user status for any user
    public void processPowerUserStatus(String sy, String sn) {
        String sql1 = "",sql2 = "";
        try {
            Statement st = myConn.createStatement();
            if (sy.trim().length() > 1) {
                sql1 = " update usr_Users set lvl = 0 where UserID in (" + sy.substring(1, sy.lastIndexOf(",")) + ")";
                st.executeUpdate(sql1);
            }
            if (sn.trim().length() > 1) {
                sql2 = " update usr_Users set lvl = 1  where UserID in (" + sn.substring(1, sn.lastIndexOf(",")) + ")";
                st.executeUpdate(sql2);
            }

        } catch (Exception e) {

        }

    }

    public void processCSMAdminStatus(String sy, String sn) {
        String sql1 = "",sql2 = "";
        strSQL = "SQLs : ";
        if (sy.trim().length() > 1) {
            sql1 = " update usr_Users set CSM_Admin = 'y' where UserID in (" + sy.substring(1, sy.lastIndexOf(",")) + ")";
            strSQL += sql1;

        }
        if (sn.trim().length() > 1) {
            sql2 = " update usr_Users set CSM_Admin = 'n'  where UserID in (" + sn.substring(1, sn.lastIndexOf(",")) + ")";
            strSQL += "<BR>" + sql2;
        }
        try {
            if (!sql1.equals("")) {
                Statement st1 = myConn.createStatement();
                st1.executeUpdate(sql1);
                st1.close();
            }
            if (!sql2.equals("")) {
                Statement st2 = myConn.createStatement();
                st2.executeUpdate(sql2);
                st2.close();
            }
        } catch (Exception e) {
            errorStr = "ERROR : " + strSQL;
        }
    }

    public String getHawkeyeFrontID() {
        String id = null;
        try {
            String sql = "select * from ztbl_HawkeyeFrontID";
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            rs.next();
            id = rs.getString("HawkeyeFrontID");
        } catch (Exception e) {

        }
        return id;

    }

/*
  public int getID() {
    return ID;
  }
 */

    public String isCSMAdmin() {
        return (CSMAdmin == null) ? "n" : CSMAdmin;
    }

    public String getID() {
        return strID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /********* Returns number of users - 3.4.8 - not used ******************/
    public int getUserCount() {
        int recCount = 0;
        String strSQL = "SELECT COUNT(*) as UserCount from usr_Users";
        try {
            if (myRS != null) myRS.close();
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                recCount = myRS.getInt("UserCount");
            }

        } catch (SQLException e) {
        }
        return recCount;
    }

    public int getRecordCount() {
        boolean tmp = false;
        int retVal = 0;
        try {
            int j = myRS.getRow();
            tmp = myRS.last();
            retVal = myRS.getRow();
            myRS.absolute(j);
            if (retVal < 0) retVal = 0;
        } catch (SQLException se) {
        }
        return (retVal);
    }

    /*********** database field extraction from filter values **********/
    public String getSQLStringforAlias(String s, String val) {
        s = s.trim();
        if (s.equals("fUserName")) {
            return "UserName";
        } else if (s.equals("fLoginName")) {
            return "LoginName";
        } else if (s.equals("fEmail")) {
            return "email";
        } else if (s.equals("fcompany_name")) {
            return "company_name";
        } else if (s.equals("fdatabase_name")) {
            return "database_name";
        } else if (s.equals("fBlocked")) {
            if (val.toUpperCase().equals("LIKE '%Y%'")) {
                return "a.[UserID] IN (SELECT  userID from Ztbl_BlockedUsers GROUP BY userID HAVING count(userID) > '0')";
            } else if (val.toUpperCase().equals("LIKE '%N%'")) {
                return "a.[UserID] NOT IN (SELECT  userID from Ztbl_BlockedUsers GROUP BY userID HAVING count(userID) > '0')";
            } else
                return "(1 = 1)";

        } else if (s.equals("fCurrent")) {
            if (val.toUpperCase().equals("LIKE '%Y%'")) {
                return "a.[UserID] IN (SELECT userID from Ztbl_CurrentUsers) ";
            } else if (val.toUpperCase().equals("LIKE '%N%'")) {
                return "a.[UserID] NOT IN (SELECT userID from Ztbl_CurrentUsers) ";
            } else
                return "(1 = 1)";

        }
        return s.substring(1);
    }

    private boolean initAllowedKeys(javax.servlet.http.HttpSession session) {
        boolean flag = false;
        this.SUserID = (String) session.getAttribute("UserID");
        this.SCompanyID = (String) session.getAttribute("CompanyID");
        strSQL =
        "select distinct SecurityLevelCode,SecurityLevelDesc,SecurityLevelValue from( "
        /* Accessed from user level */
        + "  select  a.SecurityLevelCode,a.SecurityLevelDesc,b.SecurityLevelValue from "
        + "     ztbl_SecurityLevels a left  join ztbl_SecurityLevelForUser b "
        + "     on a.SecurityLevelCode=b.SecurityLevelCode "
        + "          where UserApplicationID in "
        + "            (select SeedUserApplicationID from ztbl_UserAndApplication "
        + "              where UserID =   '" + SUserID + "'      and ApplicationID =   '" + SCompanyID + "'     "
        + "            ) "
        + "          and Upper(AllowAccess) = 'Y' and SChemeID='1' "
        + "  union "
        /* Accessed from group level */
        + "  Select A,B,C  from  " /* Group sub query start*/
        + "  ( "
        + "  select  a.SecurityLevelCode,a.SecurityLevelDesc,b.SecurityLevelValue  from "
        + "     ztbl_SecurityLevels a left    join ztbl_SecurityLevelForGroup b "
        + "     on a.SecurityLevelCode=b.SecurityLevelCode "
        + "          where b.GroupApplicationID in "
        + "      	    ( select SeedGroupApplicationID from ztbl_GroupAndApplication "
        + "                where GroupID in "
        + "  	          (select GroupID from ztbl_GroupAndUser where UserID =   '" + SUserID + "'       ) "
        + "	              and ApplicationID =   '" + SCompanyID + "'     "
        + "              ) "
        + " 	  and Upper(AllowAccess) = 'Y' and SchemeID='1'"
        + " ) as SG(A,B,C) " /* group sub query table end */
        + " where "
        /* Exclude those blocked from user level */
        + "	 not exists "
        + "              (  select  a.SecurityLevelCode,a.SecurityLevelDesc,b.SecurityLevelValue from "
        + "                    ztbl_SecurityLevels a left  join ztbl_SecurityLevelForUser b "
        + "                    on a.SecurityLevelCode=b.SecurityLevelCode "
        + "                    where UserApplicationID in "
        + "                      (select SeedUserApplicationID from ztbl_UserAndApplication "
        + "                         where UserID =   '" + SUserID + "'      and ApplicationID =   '" + SCompanyID + "'  "
        + "                       ) "
        + "                  and Upper(AllowAccess) = 'N' "
        + "                  and a.SecurityLevelCode = SG.A "
        + "                  and a.SecurityLevelDesc = SG.B "
        + "                  and b.SecurityLevelValue= SG.C "
        + "                  and b.SchemeID='1'             "
        + "               ) "
        /* Exclude those blocked from group */
        + "          and not exists "
        + "           ( "
        + " 		   select  a.SecurityLevelCode,a.SecurityLevelDesc,b.SecurityLevelValue "
        + "         	     from ztbl_SecurityLevels a left   join ztbl_SecurityLevelForGroup b "
        + "                     on a.SecurityLevelCode=b.SecurityLevelCode "
        + "  		     where b.GroupApplicationID in "
        + "                       ( select SeedGroupApplicationID from ztbl_GroupAndApplication "
        + "                            where GroupID in "
        + "                            (select GroupID from ztbl_GroupAndUser where UserID =   '" + SUserID + "' )"
        + "                             and ApplicationID =   '" + SCompanyID + "' "
        + "                       ) and Upper(AllowAccess) = 'N' "
        + "                  and a.SecurityLevelCode = SG.A "
        + "                  and a.SecurityLevelDesc = SG.B "
        + "                  and b.SecurityLevelValue= SG.C "
        + "                  and b.SchemeID='1'             "
        + "           ) "
        + "  )  as a (SecurityLevelCode,SecurityLevelDesc,SecurityLevelValue) ";


        ResultSet rsSecurity;
        try {
            stmt = myConn.createStatement();
            rsSecurity = stmt.executeQuery(strSQL);
            String code, value;
            while (rsSecurity.next()) {
                code = rsSecurity.getString("SecurityLevelDesc");
                value = rsSecurity.getString("SecurityLevelValue");
                if (code != null && value != null) {
                    if (code.equalsIgnoreCase("PlanTypeCode")) {
                        PlanTypeList.add(value);
                    }
                    if (code.equalsIgnoreCase("HMOID")) {
                        HMOIDList.add(value);
                    }
                    if (code.equalsIgnoreCase("PCPTypeCode")) {
                        PCPTypeList.add(value);
                    }
                    if (code.equalsIgnoreCase("PCPID")) {
                        PCPList.add(value);
                    }
                }
            }
            rsSecurity.close();
            stmt.close();
            flag = true;

        } catch (Exception allEx) {
            strSQL += allEx.toString();
            allEx.printStackTrace();
        } finally {
            takeDown();
        }
        return flag;

    }

    private void initAllowedKeysInt(javax.servlet.http.HttpSession session) {
        Vector templist = new Vector();

        templist=(Vector) session.getAttribute("PlanTypeList");
        if(templist==null || templist.size()>0) {
            Enumeration enume=templist.elements();
            if(enume.hasMoreElements()) {
                while(enume.hasMoreElements())   {
                    String temp = getIntValue("ztbl_PlanTypes",(String)enume.nextElement());
                    if(!"".equals(temp))
                        intPlanTypeList.add(temp);
                }
            }
            enume = null;
        }

        templist=(Vector) session.getAttribute("HMOIDList");
        if(templist==null || templist.size()>0) {
            Enumeration enume=templist.elements();
            if(enume.hasMoreElements()) {
                while(enume.hasMoreElements())   {
                    String temp = getIntValue("ztbl_HMOs",(String)enume.nextElement());
                    if(!"".equals(temp))
                        intHMOIDList.add(temp);
                }
            }
            enume = null;
        }

        templist=(Vector) session.getAttribute("PCPTypeList");
        if(templist==null || templist.size()>0) {
            Enumeration enume=templist.elements();
            if(enume.hasMoreElements()) {
                while(enume.hasMoreElements())   {
                    String temp = getIntValue("ztbl_PCPTypes",(String)enume.nextElement());
                    if(!"".equals(temp))
                        intPCPTypeList.add(temp);
                }
            }
            enume = null;
        }

        templist=(Vector) session.getAttribute("PCPList");
        if(templist==null || templist.size()>0) {
            Enumeration enume=templist.elements();
            if(enume.hasMoreElements()) {
                while(enume.hasMoreElements())   {
                    String temp = getIntValue("ztbl_PCPs",(String)enume.nextElement());
                    if(!"".equals(temp))
                        intPCPList.add(temp);
                }
            }
            enume = null;
        }

    }

    public String getIntValue(String tableName, String strVal) {
        String intVal = "";
        String sqlStr = "";
        if(tableName.equals("ztbl_PlanTypes")){
            sqlStr = "SELECT intPlanTypeCode as intVal FROM ztbl_PlanTypes WHERE planTypeCode = '" + strVal + "' ";
        }else if(tableName.equals("ztbl_HMOs")){
            sqlStr = "SELECT intHMOID as intVal FROM ztbl_HMOs WHERE HMOID = '" + strVal + "' ";
        }else if(tableName.equals("ztbl_PCPTypes")){
            sqlStr = "SELECT intPCPTypeCode as intVal FROM ztbl_PCPTypes WHERE PCPTypeCode = '" + strVal + "' ";
        }else if(tableName.equals("ztbl_PCPs")){
            sqlStr = "SELECT intPCPID as intVal FROM ztbl_PCPs WHERE PCPID = '" + strVal + "' ";
        }

        try {
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sqlStr);
            while (rs.next()) {
                intVal = Integer.toString(rs.getInt("intVal"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return intVal;
    }

    /** vector with allowed plan types and so on*/
    Vector PlanTypeList = new Vector();
    Vector HMOIDList = new Vector();
    Vector PCPTypeList = new Vector();
    Vector PCPList = new Vector();
    Vector NonPlanTypeList = new Vector();
    Vector NonHMOIDList = new Vector();
    Vector NonPCPTypeList = new Vector();
    Vector NonPCPList = new Vector();
    String SUserID = "";
    String SCompanyID = "";

    Vector intPlanTypeList = new Vector();
    Vector intHMOIDList = new Vector();
    Vector intPCPTypeList = new Vector();
    Vector intPCPList = new Vector();
    Vector intNonPlanTypeList = new Vector();
    Vector intNonHMOIDList = new Vector();
    Vector intNonPCPTypeList = new Vector();
    Vector intNonPCPList = new Vector();

    public boolean setUCG(javax.servlet.http.HttpSession session) {
        //String groupID;
        boolean flag = false;
        this.SUserID = (String) session.getAttribute("UserID");
        this.SCompanyID = (String) session.getAttribute("CompanyID");
        initAllowedKeys(session);
        this.setSessionParameters(session);
        try {
            this.makeConnection();
        } catch (Exception e) {
        }
        NonPlanTypeList = getNotInLists(PlanTypeList, "NonPlanTypeList");
        NonHMOIDList = getNotInLists(HMOIDList, "NonHMOIDList");
        NonPCPTypeList = getNotInLists(PCPTypeList, "NonPCPTypeList");
        NonPCPList = getNotInLists(PCPList, "NonPCPList");
        session.setAttribute("PCPList", (Object) this.PCPList);
        session.setAttribute("PCPTypeList", (Object) this.PCPTypeList);
        session.setAttribute("HMOIDList", (Object) this.HMOIDList);
        session.setAttribute("PlanTypeList", (Object) this.PlanTypeList);
        session.setAttribute("NonPCPList", (Object) this.NonPCPList);
        session.setAttribute("NonPCPTypeList", (Object) this.NonPCPTypeList);
        session.setAttribute("NonHMOIDList", (Object) this.NonHMOIDList);
        session.setAttribute("NonPlanTypeList", (Object) this.NonPlanTypeList);

        return flag;
    }

    public boolean setUCGInt(javax.servlet.http.HttpSession session) {
        //String groupID;
        boolean flag = false;
        this.SUserID = (String) session.getAttribute("UserID");
        this.SCompanyID = (String) session.getAttribute("CompanyID");
        initAllowedKeysInt(session);
        this.setSessionParameters(session);
        try {
            this.makeConnection();
        } catch (Exception e) {
        }

        intNonPlanTypeList = getNotInListsInt(intPlanTypeList, "intNonPlanTypeList");
        intNonHMOIDList = getNotInListsInt(intHMOIDList, "intNonHMOIDList");
        intNonPCPTypeList = getNotInListsInt(intPCPTypeList, "intNonPCPTypeList");
        intNonPCPList = getNotInListsInt(intPCPList, "intNonPCPList");

        session.setAttribute("intPCPList", (Object) this.intPCPList);
        session.setAttribute("intPCPTypeList", (Object) this.intPCPTypeList);
        session.setAttribute("intHMOIDList", (Object) this.intHMOIDList);
        session.setAttribute("intPlanTypeList", (Object) this.intPlanTypeList);
        session.setAttribute("intNonPCPList", (Object) this.intNonPCPList);
        session.setAttribute("intNonPCPTypeList", (Object) this.intNonPCPTypeList);
        session.setAttribute("intNonHMOIDList", (Object) this.intNonHMOIDList);
        session.setAttribute("intNonPlanTypeList", (Object) this.intNonPlanTypeList);
        return flag;
    }

/*
        This method will return a vector containing not allowed pcps,hmos and so on
        for the purpose of 'NOT IN' clause in making SQL Queries


 */
    public Vector getNotInLists(Vector AllowedCodes, String type) {
        Vector templist = new Vector();
        if (type.equalsIgnoreCase("NonPCPList")) {
            strSQL = " select distinct pcpid from ztbl_pcps ";
        }
        if (type.equalsIgnoreCase("NonPCPTypeList")) {
            strSQL = " select distinct pcptypecode from ztbl_pcptypes ";
        }
        if (type.equalsIgnoreCase("NonHMOIDList")) {
            strSQL = " select distinct hmoid from ztbl_hmos ";
        }
        if (type.equalsIgnoreCase("NonPlanTypeList")) {
            strSQL = " select distinct plantypecode from ztbl_plantypes ";
        }

        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);

            while (rs.next()) {

                templist.add(rs.getString(1));

            }
            ((List) templist).removeAll((Collection) AllowedCodes);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("nonn error" + e);
        }

        return templist;
    }

    public Vector getNotInListsInt(Vector AllowedCodes, String type) {
        Vector templist = new Vector();
        if (type.equalsIgnoreCase("intNonPCPList")) {
            strSQL = " select distinct intpcpid from ztbl_pcps ";
        }
        if (type.equalsIgnoreCase("intNonPCPTypeList")) {
            strSQL = " select distinct intpcptypecode from ztbl_pcptypes ";
        }
        if (type.equalsIgnoreCase("intNonHMOIDList")) {
            strSQL = " select distinct inthmoid from ztbl_hmos ";
        }
        if (type.equalsIgnoreCase("intNonPlanTypeList")) {
            strSQL = " select distinct intplantypecode from ztbl_plantypes ";
        }

        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);

            while (rs.next()) {

                templist.add(rs.getString(1));

            }
            ((List) templist).removeAll((Collection) AllowedCodes);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("nonn error" + e);
        }

        return templist;
    }

    public int getPCPListSize() {
        return this.NonPCPList.size();
    }

    public int getPCPListSizeInt() {
        return this.intNonPCPList.size();
    }

    public int countAccessibleFourKeys() {
        return (this.PCPList.size() + this.PCPTypeList.size() + this.HMOIDList.size() + this.PlanTypeList.size());
    }

    public int countAccessibleFourKeysInt() {
        return (this.intPCPList.size() + this.intPCPTypeList.size() + this.intHMOIDList.size() + this.intPlanTypeList.size());
    }

    public boolean hasFullAccess(int totalCount_User) {
        boolean flag = false;

        int totalCount_DB = 0;
        strSQL = " select sum(total_rec) as totalCount from ( " +
        " select COUNT(*) from ztbl_HMOs union all " +
        " select COUNT(*) from ztbl_PCPs union all " +
        " select COUNT(*) from ztbl_PCPTypes union all " +
        " select COUNT(*) from ztbl_PlanTypes " +
        " ) as a(total_rec)";

        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);
            if (rs.next()) {
                totalCount_DB = rs.getInt("totalCount");
            }
            if (totalCount_DB == totalCount_User) {
                flag = true;
            }

        } catch (Exception e) {
            flag = false;
        }
        return flag;
    }

    public boolean isChangePasswordDue(String userID) {
        return isChangePasswordDue(userID, 0);
    }

    public boolean isChangePasswordDue(String userID, int i) {
        int checkDays = 90;
        if (i > 0)
            checkDays = i;
        this.strSQL = " select UserID from ztbl_LogPassword "
        + " group by UserID having UserID = '" + userID + "'  "
        + " and DATEDIFF(day,MAX(DateStamp),getDate()) >  " + checkDays;
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL);
            if (rs.next())
                return true;
        } catch (Exception e) {

        }
        return false;
    }

 public boolean deleteClientsForUser(String Userid){
    boolean result = false;
    try {
         Statement st = myConn.createStatement();
         strSQL = "DELETE FROM TMP_OAM_RM_USER_CLIENT WHERE UserID =" + SQLEncode(Userid);
         st.executeUpdate(strSQL);
        result = true;
        st.close();
    }
     catch(Exception e){System.out.println ("ERROR while trying to delete clients for user " + e.toString());}
    return result;
 }
 
 /*Function:deleteUsersForClient
  *Description: delete all the users of the selected client
  *Author:Richan Shrestha
  *Parameter:ClientId
  *Output: Boolean that indicates the success/failure of database operation
   */
 public boolean deleteUsersForClient(String clientId){
	    boolean result = false;
	    try {
	         Statement st = myConn.createStatement();
	         strSQL = "DELETE FROM TMP_OAM_RM_USER_CLIENT WHERE ClientID =" + SQLEncode(clientId);
	         st.executeUpdate(strSQL);
	        result = true;
	        st.close();
	    }
	     catch(Exception e){System.out.println ("ERROR while trying to delete users for client " + e.toString());}
	    return result;
	 }
 
 /*Function: deleteUsersForProduct
  *Description: delete all the users of the given product
  *Author:Richan Shrestha
  *Parameter: productId
  *Output: Boolean that indicates the success/failure of database operation
   */
 public boolean deleteUsersForProduct(String productCode){
	    boolean result = false;
	    try {
	         Statement st = myConn.createStatement();
	         strSQL = "Delete from TMP_OAM_RM_USER_PRODUCT WHERE ProductID ='"+productCode+"'";
	         st.executeUpdate(strSQL);
	        result = true;
	        st.close();
	    }
	     catch(Exception e){System.out.println ("ERROR while trying to delete users for product " + e.toString());}
	    return result;
	 }
 
public boolean deleteUser(String Userid){
    boolean result = false;
    try {
         Statement st = myConn.createStatement();
         strSQL = "DELETE FROM usr_Users WHERE UserID =" + SQLEncode(Userid) +" AND UserStatus<>0";
         st.executeUpdate(strSQL);
        result = true;
        st.close();
    }
    catch(Exception e){System.out.println ("ERROR while trying to delete user " + e.toString());}
    return result;
}

 public void insertClientForUser(String ClientId, String Userid) {
        String error = "insertion doesn't succeed";
        strSQL = "";
        try {
                Statement st = myConn.createStatement();
                if(!ClientId.trim().equals("")){
                    StringTokenizer ClientIdStr = new StringTokenizer(ClientId,"::");
                    while(ClientIdStr.hasMoreTokens()){
                        String sr = ClientIdStr.nextToken();
                        strSQL = "insert into TMP_OAM_RM_USER_CLIENT values('','" + Userid + "','" +sr+ "','N')";
                        st.execute(strSQL);
                    }
                }

        } catch (SQLException e) {
            e.printStackTrace();
        }
   }
 
 public void insertUserForClient(String userIdStr, String clientId) {
     String error = "insertion doesn't succeed";
     strSQL = "";
     try {
             Statement st = myConn.createStatement();
             if(!userIdStr.trim().equals("")){
                 StringTokenizer userIdList= new StringTokenizer(userIdStr,"::");
                 while(userIdList.hasMoreTokens()){
                     String usr = userIdList.nextToken();
                     strSQL = "insert into TMP_OAM_RM_USER_CLIENT values('" + usr + "','" +clientId+ "','N')";
                     st.execute(strSQL);
                 }
             }

     } catch (SQLException e) {
         e.printStackTrace();
     }
}
   public ResultSet getRequestTypeForClient(String clientID){
        ResultSet rs=null;
        String strSql = "";
        try {
                  Statement st = myConn.createStatement();
                  strSql = "Select * from tbl_ClientAndRequest where ClientID='"+clientID+"'";
                  rs=st.executeQuery(strSql);
        }catch (SQLException e) {
            e.printStackTrace();
        }
       return rs;
   }
   public boolean isSecurityUndefined(String userID, String applicationID) {

        int onZeroAccess = -1;

        strSQL
        = " select sum(TotalRecs) as OnZeroAccess from ( "
        + "    select count(*) from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_SecurityLevelForUser s, "
        + " [HawkeyeUser35].HawkeyeUser.dbo.ztbl_UserAndApplication ua "
        + "       where s.UserApplicationID = ua.SeedUserApplicationID "
        + "          and ua.ApplicationID = '" + applicationID + "'  "
        + "          and ua.UserID = '" + userID + "'  "
        + "          and s.SchemeID='1'"
        + "    union "
        + "    select count(*) from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_SecurityLevelForGroup s,"
        + " [HawkeyeUser35].HawkeyeUser.dbo.ztbl_GroupAndApplication ga, "
        + " [HawkeyeUser35].HawkeyeUser.dbo.ztbl_GroupAndUser gu "
        + "       where gu.GroupID = ga.GroupID and ga.SeedGroupApplicationID = s.GroupApplicationID "
        + "          and gu.UserID = '" + userID + "'  "
        + "          and ga.ApplicationID = '" + applicationID + "'  "
        + "          and s.SchemeID='1'"
        + " ) as a(TotalRecs) ";
        Statement st = null;
        ResultSet rt = null;
        try {
            st = myConn.createStatement();
            rt = st.executeQuery(strSQL);
            if (rt.next())
                onZeroAccess = rt.getInt("OnZeroAccess");
        } catch (Exception anyEx) {
            strSQL += " <BR>Exception : " + anyEx.toString();
        } finally {
            try {
                if (rt != null) rt.close();
                if (st != null) st.close();
            } catch (Exception ignoreEx) {
            }
        }
        return onZeroAccess == 0;
    }


    public boolean isViewableByGroupOfUser(String userID, String applicationID) {
        boolean retVal = false;
        strSQL = " select count(*) as count from ztbl_Applications where'" + applicationID + "' in( "
        + " select distinct(ApplicationID) from  ztbl_GroupAndApplication "
        + " where groupid in( "
        + " select distinct(groupid) from ztbl_GroupAndUser where userid='" + userID + "'"
        + " ))";
        try {
            Statement stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(strSQL);
            rs.next();
            int count = rs.getInt("count");
            if (count > 0)
                retVal = true;
        } catch (Exception e) {
            strSQL += e.toString();
        }
        return retVal;
    }


    /*exclude users acc. to supplied groupid*/
    public void getUsersForDiffLoginID(String groupID) {
        strSQL = " select distinct a.UserID,a.UserName,a.LoginName,a.lvl from usr_Users a " +
        " where a.userid not in" +
        " (select userid from ztbl_groupanduser where groupid=" + groupID + ")" +
        " order by a.UserName";


        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.absolute(1);
        } catch (SQLException e) {
            System.out.println("error");
            e.printStackTrace();
        }

    }

    public Hashtable getGroups() {
        strSQL = "select groupid,groupname from ztbl_Groups";
        Hashtable ht = new Hashtable();
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                ht.put(myRS.getString("groupname"), myRS.getString("groupid"));

            }

        } catch (SQLException e) {
            System.out.println("error");
            e.printStackTrace();
        }
        return ht;
    }

    public String getClientID(String ClientName) {
        String returnValue = "";
        strSQL = "select clientid from ztbl_clients where clientname='" + ClientName + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            returnValue = myRS.getString("clientid");
        } catch (SQLException e) {
            System.out.println("error");
            e.printStackTrace();
        }
        return returnValue;
    }

    public boolean getModules(String applicationRoot) {
        boolean hasRecord = false;
        String strSQL = "SELECT ModuleID,ModuleName,DisplayName,ApplicationURL, "
        + " Applicationroot, "
        + " case when [Allow] is null then 'Y' else [Allow] end as Allow "
        + " from ztbl_frontmodulesandclients where [Allow]='Y'"
        + " and ApplicationRoot='" + applicationRoot + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            myRS.absolute(1);
            hasRecord = true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return hasRecord;
    }

    //check whether the user falls on D2System group


    public boolean getUserCheckForD2(String UserID) {
        boolean isD2 = false;
        strSQL = " select distinct userid from ztbl_Groups a,ztbl_GroupAndUser b " +
        " where a.groupid=b.groupid and groupname like 'D2 Systems' " +
        " and  b.userid='" + UserID + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            if (myRS.next())
                isD2 = true;
        } catch (SQLException e) {
            System.out.println("error");
            e.printStackTrace();
        }
        return isD2;

    }

    public boolean getCompanyDetailForIC(String appName) {
        boolean flag = false;
        try {
            stmt = super.myConn.createStatement();
            strSQL = "select * from ztbl_applications a join ztbl_ICIntegration_MapICFronts b " +
            " on b.d2FrontApplicationID=a.applicationId where b.ICFrontName='" + appName + "'";
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            myRS.absolute(1);
            flag = true;
        } catch (SQLException sqlexception) {
            errorStr = "error occured while listing company:" + sqlexception;
        }
        return flag;
    }

    public String insertUserForIClaim(String userid, String username) throws Exception {
        String userID = "";
        strSQL = "insert into usr_Users( UserID,Loginname,UserName ) values('" + userid + "','" + username + "','" + username + "')";
        String strSQL1 = " select * from usr_Users where username = '" + username + "'";
        try {
            Statement st = myConn.createStatement();
            st.execute(strSQL);
            st.close();
            st = myConn.createStatement();

            String strSQL2 = " update usr_Users set UserID = SeedUserID where username = '" + username + "'";
            st.execute(strSQL2);

            ResultSet rs = st.executeQuery(strSQL1);
            rs.next();
            userID = rs.getString("UserID");
            rs.close();

        } catch (SQLException e) {
            throw new Exception("" + e);
        }
        return userID;
    }

    public String getGroupIdFromGroupName(String groupName) throws Exception {
        String groupid = "";
        String strSQL1 = " select groupid from ztbl_groups where groupname = '" + groupName + "'";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(strSQL1);
            rs.next();
            groupid = rs.getString("groupid");
            rs.close();
        } catch (SQLException e) {
            throw new Exception("" + e);
        }
        return groupid;

    }

    public void getSecurityAccessForIC(String level,String levelCode,HttpSession session){

        Vector temp=new Vector();
        String levelIdenitifier="";
        if(levelCode.equals("1")){
            temp=this.intPlanTypeList;
            levelIdenitifier="intPlanTypeList";
        }
        else if(levelCode.equals("2")){
            temp=this.intHMOIDList;
            levelIdenitifier="intHMOIDList";
        }
        else if(levelCode.equals("3")){
            temp=this.intPCPTypeList;
            levelIdenitifier="intPCPTypeList";
        }
        else if(levelCode.equals("4")){
            temp=this.intPCPList;
            levelIdenitifier="intPCPList";
        }
        if(level.trim().length()>0){
            if(level.indexOf("::")!=-1){
                StringTokenizer st=new StringTokenizer(level,"::");
                while(st.hasMoreTokens()){
                    String sCode=st.nextToken();
                    temp.add(sCode);
                }
            }
            else {
                temp.add(level);
            }
        }
        session.setAttribute(levelIdenitifier, (Object) temp);

    }

    public void getEmployerInfo()throws Exception{
        strSQL= " select EmployerID,EmployerName from ztbl_Employers order by employerName";
        try{
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            currentRec = 1;
            // myRS.absolute(currentRec);
        } catch (SQLException e) {
            System.out.println(" error : " + e);
        }
    }

    public boolean checkUserForGroup(String UserID,String groupname) {
        boolean isValidUser = false;
        strSQL = " select distinct userid from ztbl_Groups a,ztbl_GroupAndUser b " +
        " where a.groupid=b.groupid and groupname ='"+groupname+"'" +
        " and  b.userid='" + UserID + "'";
        try {
            Statement stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            myRS = stmt.executeQuery(strSQL);
            if (myRS.next())
                isValidUser = true;
        } catch (SQLException e) {
            System.out.println("error");
            e.printStackTrace();
        }
        return isValidUser;

    }

    public String getProcessedDate() throws Exception{
        String retVal="";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery("select DatePart(year,ProcessedDate) as processedYear from ztbl_hawkeyefrontid ");

            myRS.next();
            retVal=myRS.getString("processedYear");

        }catch(SQLException se){retVal=""; }
        return retVal.trim();

    }

//new sb layout

    private int rows=0;
    private int cols=0;

    public void getRowsColumnsForSwitchBoard(int size){
       if(size <= 2)
            rows=1;
        else rows=2;
        setRowsColumns(size,rows);
    }

    public void setRowsColumns(int size,int rows){
        int y=0;
        int rem=0;

        rem=size % rows;

       if(rem!=0)
           y=size+(rows-rem);
       else
           y=size;

       cols=y/rows;

       if(cols>4){
           rows=rows+1;
           setRowsColumns(size,rows);
       }

       this.rows=rows;
       this.cols=cols;

    }

    public int getRows(){
        return this.rows;
    }

    public int getColumns(){
        return this.cols;
    }


    public void InsertNew4SecurityKeys(String CompanyID,String UserID)throws Exception{
         Statement st=null;
         String strSQL1="";
         try{
         for(int i=4;i>=1;i--){
             this.str_optional="";
             st=myConn.createStatement();
             setParametersFor4KeyInsert(i);
             strSQL1="Insert into [HawkeyeUser35].HawkeyeUser.dbo.ztbl_SecurityLevelForGroup " +
                    "(GroupApplicationID,SecurityLevelCode,SecurityLevelValue,AllowAccess,SchemeID,AllowChild) " +
                    " " +
                    "Select GroupApplicationID,'"+i+"',a."+this.str_param+",'y',SchemeID,'y' from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_securityLevelForGroup slg, " +
                    "( " +
                    "Select "+this.str_param+" from "+this.str_table+" where "+this.str_param+" "+this.str_optional+" NOT IN " +
                    "( " +
                    "Select slg.SecurityLevelValue " +
                    "  " +
                    " from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_securityLevelForGroup slg, " +
                    "( " +
                    "Select seedGroupApplicationid groupApplicationID  from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_GroupAndApplication " +
                    "where groupId in " +
                    "( " +
                    "    select GroupId from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_GroupAndUser where userID='"+UserID+"' " +
                    ")  " +
                    "and  " +
                    "applicationId='"+CompanyID+"' " +
                    ")grApp " +
                    " " +
                    "where grApp.groupApplicationID=slg.GroupApplicationID " +
                    "and slg.SecurityLevelCode='"+i+"' " +
                    "and slg.AllowChild='y' " +
                    "))a " +
                    " " +
                    "where slg.AllowChild='y' " +
                    "and slg.SecurityLevelCode='"+i+"' " +
                    "group by GroupApplicationID,SchemeID,SecurityLevelCode,a."+this.str_param+"";
             st.execute(strSQL1);
             st.close();
         }

        for(int i=4;i>=1;i--){
            this.str_optional="";
            st=myConn.createStatement();
            setParametersFor4KeyInsert(i);
            strSQL1="Insert into [HawkeyeUser35].HawkeyeUser.dbo.ztbl_SecurityLevelForUser " +
                  "(UserApplicationID,SecurityLevelCode,SecurityLevelValue,AllowAccess,SchemeID,AllowChild) " +
                  " " +
                  "Select UserApplicationID,'"+i+"',a."+this.str_param+",'y',SchemeID,'y' from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_SecurityLevelForUser slu, " +
                  "( " +
                  "Select "+this.str_param+" from "+this.str_table+" where "+this.str_param+" "+this.str_optional+" NOT IN " +
                  "( " +
                  "Select slu.SecurityLevelValue " +
                  "  " +
                  " from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_SecurityLevelForUser slu, " +
                  "( " +
                  "Select seedUserApplicationID UserApplicationID  from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_UserAndApplication " +
                  "where  " +
                  " userID='"+UserID+"' " +
                  "and  " +
                  " applicationId='"+CompanyID+"' " +
                  ")urApp " +
                  " " +
                  "where urApp.UserApplicationID=slu.UserApplicationID " +
                  "and slu.SecurityLevelCode='"+i+"' " +
                  "and slu.AllowChild='y' " +
                  "))a " +
                  " " +
                  "where slu.AllowChild='y' " +
                  "and slu.SecurityLevelCode='"+i+"' " +
                  "group by UserApplicationID,SchemeID,SecurityLevelCode,a."+this.str_param+"";

            st.execute(strSQL1);
            st.close();
        }

         }catch(Exception e){
             if(st!=null)
                    st.close();
             System.out.println(" Security Insert Error "+e.getMessage()+"==="+strSQL1);
         }
    }

    public void setParametersFor4KeyInsert(int level){
        switch(level){
            case 4:
                 this.str_table=" ztbl_PlanTypes ";
                 this.str_param="planTypeCode";
                 break;
            case 3:
                  this.str_table=" ztbl_HMOs ";
                  this.str_param="HMOID";
                  break;
            case 2:
                  this.str_table=" ztbl_PCPTypes ";
                  this.str_param="PCPTypeCode";
                  this.str_optional=" IN (Select PCPTypeCode from ztbl_SunLifeTPA_Current ) and PCPTypeCode ";
                  break;
            case 1:
                  this.str_table=" ztbl_PCPs ";
                  this.str_param="PCPID";
                  break;
            default:
                   break;
        }
    }
    private String str_table="";
    private String str_param="";
    private String str_optional="";

    public void checkSecurityKeys(String applicationID,String UserID) throws Exception{
        boolean retVal=false;
        try{
        Statement st=myConn.createStatement();
        strSQL=" Select Case count(*) when 0 then 'N' else 'Y' end as recCount from ztbl_HawkeyeFrontID a,  " +
                " [HawkeyeUser35].HawkeyeUser.dbo.ztbl_ClientsFrontIDs b " +
                " where  " +
                " a.HawkeyeFrontID=b.HawkeyeFrontId " +
                " and  " +
                " b.applicationId='"+applicationID+"'";
       myRS=st.executeQuery(strSQL);
       myRS.next();
       if(myRS.getString("recCount").trim().equalsIgnoreCase("N"))
           retVal=true;
       if(retVal){
           strSQL=" Delete from [HawkeyeUser35].HawkeyeUser.dbo.ztbl_ClientsFrontIDs where applicationid='"+applicationID+"'";
           String strSQL1=" Insert into [HawkeyeUser35].HawkeyeUser.dbo.ztbl_ClientsFrontIDs "
                         +" select '"+applicationID+"',HawkeyeFrontID from ztbl_HawkeyeFrontID ";
           st.close();
           st=myConn.createStatement();
           st.execute(strSQL);
           st.execute(strSQL1);
           st.close();
           InsertNew4SecurityKeys(applicationID,UserID);
       }

    }catch(Exception e){
        System.out.println("securityerror"+e.getMessage());
    }
  }

    private int applicationServerID=0;
    private String applicationServerURL="http://www.d2hawkeye.com";
    private int applicationServerPriority;
    public boolean getApplicationServerInfo(String criteria){
        boolean retVal=false;
        try{
            String sql = "SELECT ASID,ASURL, ASPriority FROM ztbl_LB_APPServers WHERE Criteria='"+criteria+"'";
            this.makeConnection();
            stmt=myConn.createStatement();
            myRS = stmt.executeQuery(sql);
            retVal = myRS.next();
            if (retVal) {
                applicationServerID = myRS.getInt("ASID");
                applicationServerURL=myRS.getString("ASURL");
                applicationServerPriority=myRS.getInt("ASPriority");
            }
            stmt.close();
                } catch(Exception e){
                    System.out.println("Error Occurred::"+e);
                }
        return retVal;
    }
    public int getApplicationServerID(){
        return this.applicationServerID;
    }
    public String getApplicationServerURL(){
        return this.applicationServerURL;
    }
    public int getApplicationServerPriority(){
        return this.applicationServerPriority;

    }
    HttpSession HTTPSession=null;
    public HttpSession getSession(){
        return HTTPSession;
    }


    public boolean addUserSession(String userID, int ASID, String sessionID, Object HTTPSession)
    {
          boolean result = false;
          String sql = "insert into ztbl_LB_ActiveSessions(UserID, ASID, SessionID, HTTPSession) values(?,?,?,?)";
          try
          {

                  java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                  java.io.ObjectOutputStream oout = new java.io.ObjectOutputStream(baos);
                  oout.writeObject(HTTPSession);
                  this.makeConnection();
                  myPS=myConn.prepareStatement(sql);
                  myPS.setString(1,userID);
                  myPS.setInt(2,ASID);  //use appropriate ASID// fetch the name from peroerty file
                  myPS.setString(3,sessionID);
                  byte[] buf=baos.toByteArray();
                  ByteArrayInputStream bais =new ByteArrayInputStream(buf);
                  myPS.setBinaryStream(4,bais, buf.length);
                  result=myPS.execute ();
                  myPS.close();
                  oout.flush();
                  oout.close();

          }
          catch(Exception e){   System.out.println("Error Bijay::::");
                  System.out.println(result);
                  System.out.println(e);
              }
          finally
          {
              takeDown();
          }
           return result;
    }
    public Object retriveSession(String sessionID) throws Exception{
        java.io.ObjectInputStream objectIn=null;
        boolean retVal=false;
       try{
            String sql = "select UserID, ASID, HTTPSession from ztbl_LB_ActiveSessions where SessionID='"+sessionID+"'";
            this.makeConnection();
            stmt=myConn.createStatement();
            myRS = stmt.executeQuery(sql);
            retVal = myRS.next();
            if (retVal) {
                ID=myRS.getString("userID");

                byte[] buf = myRS.getBytes("HTTPSession");

                    if (buf != null) {
                     objectIn = new java.io.ObjectInputStream(
                        new java.io.ByteArrayInputStream(buf));
//                         obobjectIn.readObject();
                    }
            }
           stmt.close();
           myRS.close();
           sql="DELETE FROM ztbl_LB_ActiveSessions where userID='"+ID+"'";
           stmt=myConn.createStatement();
           stmt.execute(sql);
           stmt.close();
       }catch(Exception e){
        System.out.println("securityerror"+e.getMessage());
    }

        return objectIn.readObject();
    }

    public void setVersionTransitionInfo(HttpServletRequest request)throws Exception{
       try{
       PreparedStatement pstmt=null;
       HttpSession session=request.getSession();
       String UserID=session.getAttribute("UserID").toString();
       Enumeration enm=session.getAttributeNames();
       strSQL="insert into [HawkeyeUser35].HawkeyeUser.dbo.ztbl_UserVersionInfo values(?,?,?)";
       while(enm.hasMoreElements()){
           String sessionName=enm.nextElement().toString();
           Object sessionVal=session.getAttribute(sessionName);
           if(!sessionName.trim().equalsIgnoreCase("Logger")){
               pstmt= myConn.prepareStatement(strSQL);
               pstmt.setString(1,UserID);
               pstmt.setString(2,sessionName);
               pstmt.setObject(3,sessionVal);
               pstmt.execute();
           }
       }
           pstmt= myConn.prepareStatement(strSQL);
           pstmt.setString(1,UserID);
           pstmt.setString(2,"CompanyId");
           pstmt.setObject(3,request.getParameter("company_id"));
           pstmt.execute();

        pstmt.close();
       }catch(Exception e ){
       }
    }
     public String getAdminEmail(String uID){
      String result = "";
      strSQL = "select * from usr_Users where lvl='0' and UserID='"+uID+"'";
      try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.next();

                result=myRS.getString("Email");
        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
   }
     public void insertRequestTypeforUser(ArrayList Request, String UserID) {
        String error = "insertion doesn't succeed";
        String strSql = "";
        try {
                Statement st = myConn.createStatement();
                Iterator it=Request.iterator();
                while(it.hasNext()){
                    String rType=it.next().toString();
                    if(checkDuplicateRequestTypeforUser(UserID, rType)){
                         strSql = "insert into TMP_OAM_RM_USER_PRODUCT values('','" + UserID+ "','" +rType+ "',0 )";
                         st.execute(strSql);
                    }
                }
        } catch (SQLException e) {
            e.printStackTrace();
        }
   }
    
     /*
      * Function:insertUserForRequestType
      * Description: Assign List of Users to the product
      * Author:Richan Shrestha
      * Parameter:Arraylist of Users
      * Parameter:ProductID
      */
     public void insertUserForRequestType(ArrayList userList, String ProductID) {
         String error = "insertion doesn't succeed";
         String strSql = "";
         Statement st =null;
         int i=0;
         
         try {
        	 st = myConn.createStatement();    
                 Iterator it=userList.iterator();
                 while(it.hasNext()){
                	 i++;
                	 if ((i%200)==0){
                		 this.takeDown();
                		 try{
                		 this.makeConnection();
                		 st = myConn.createStatement();
                		 }catch(Exception ex){
                			 System.out.println(ex);
                		 }
                	 //closeRecordSet();
                	 //myConn.commit();
                     //st.close();
                	 //st=null;
                	 //String tempstr="begin\n execute immediate('ALTER SESSION SET CLOSE_CACHED_OPEN_CURSORS=true ');\n commit; \n end;";
                	 //st.execute(tempstr);
                	 //String tempstr="begin\n execute immediate('ALTER SESSION SET HOLD_CURSOR=NO, RELEASE_CURSOR=YES');\n commit; \n end;";
                	 //st.execute(tempstr);
                	 //st = myConn.createStatement();
                	 
                	 }
                	       
                	 String usrId=it.next().toString();
                     if(checkDuplicateRequestTypeforUser(usrId, ProductID)){
                          strSql = "insert into TMP_OAM_RM_USER_PRODUCT values('','" + usrId+ "'," +ProductID+ ",0 )";
                          //System.out.println("The sql is "+strSQL);
                          st.execute(strSql);
                          //Thread.sleep(100);
                     }
                 }
         } catch (SQLException e) {
             e.printStackTrace();
         } 
         /*catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/finally{
        	 try {
        		 st.close();
                 }
             catch (SQLException e) {
             e.printStackTrace();
         }
        	 
        	 
         }
    }
     
   public void deleteRequestTypeforUser( ArrayList Request, String UserID) {
        String error = "insertion doesn't succeed";
        String strSql = "";
        try {
                Statement st = myConn.createStatement();

                Iterator it=Request.iterator();
                while(it.hasNext()){
                   String rType=it.next().toString();
                   strSql ="Delete from TMP_OAM_RM_USER_PRODUCT where UserID='" + UserID+ "' And ProductID='"+rType+"'";
                    st.execute(strSql);
                }
        } catch (SQLException e) {
            e.printStackTrace();
        }
   }
     public boolean checkDuplicateRequestTypeforUser(String UserID, String Request) {
        boolean retVal = true;
        try {
            stmt = myConn.createStatement();
            strSQL="select count(*) from TMP_OAM_RM_USER_PRODUCT where UserID='" + UserID+ "' And ProductID='"+Request+"'";
            myRS = stmt.executeQuery(strSQL);
            myRS.next();
            if(myRS.getInt(1)>0)
                 retVal = false;
        } catch (SQLException e) {
            System.out.println("Exception occurs"+e.getMessage());
            retVal = false;
        }
        catch (Exception e) {
            System.out.println("Exception occurs"+e.getMessage());
            retVal = false;
        }
        return (retVal);
    }

}

