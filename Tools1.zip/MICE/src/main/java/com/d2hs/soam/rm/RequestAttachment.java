package com.d2hs.soam.rm;

/**
 * 
 * This class represents the object of the attachment
 * sent with the emails
 * 
 * FileName:RequestAttachment.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jul 16, 2010
 *
 */
public class RequestAttachment {

	private byte[] fileContent;
	private String fileName;
	private String fileType;//Technical,others,requirement specs etc
	
	public RequestAttachment(){
		
	}
	
	public byte[] getFileContent() {
		return fileContent;
	}
	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
}
