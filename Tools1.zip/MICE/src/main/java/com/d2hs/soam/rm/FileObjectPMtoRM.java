package com.d2hs.soam.rm;

public class FileObjectPMtoRM {
	String uploadeddocname="";
	String filepath="";
	String docsizeVar="";
	String sourceFile="";
	String destFile="";
	String msgId="";
	
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public String getUploadeddocname() {
		return uploadeddocname;
	}
	public void setUploadeddocname(String uploadeddocname) {
		this.uploadeddocname = uploadeddocname;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public String getDocsizeVar() {
		return docsizeVar;
	}
	public void setDocsizeVar(String docsizeVar) {
		this.docsizeVar = docsizeVar;
	}
	public String getSourceFile() {
		return sourceFile;
	}
	public void setSourceFile(String sourceFile) {
		this.sourceFile = sourceFile;
	}
	public String getDestFile() {
		return destFile;
	}
	public void setDestFile(String destFile) {
		this.destFile = destFile;
	}
	
	
}
