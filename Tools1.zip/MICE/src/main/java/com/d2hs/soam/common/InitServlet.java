package com.d2hs.soam.common;

import javax.servlet.http.HttpServlet;
import javax.servlet.ServletConfig;

public class InitServlet extends HttpServlet {

	private static String configDir = null;

	public void init(ServletConfig conf) {
		try {
			super.init(conf);
			configDir = this.getInitParameter("configDir");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static String getConfigDir() {
		return configDir;
	}
}