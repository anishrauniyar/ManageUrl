package com.d2hs.soam.conn;
/**
 * Created by IntelliJ IDEA.
 * User: rshah
 * Date: Dec 12, 2006
 * Time: 10:21:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class ConnectionParameters {


/**
 * Object that corresponds to
 * <Alias
 *   name="test-server->MDHawkeye_FMH2"
 *   driver="com.microsoft.jdbc.sqlserver.SQLServerDriver"
 *   url="jdbc:microsoft:sqlserver://test-server:1433;DBName=MDHawkeye_FMH2"
 *   username="sa"
 *   Pwd="adm"
 *   maxConn="20"
 *   idleTimeout="60"
 *   checkoutTimeout="60"
 *   maxCheckout="10"
 * >
 */

  private String name;
  private String driver;
  private String url;
  private String userName;
  private String Pwd;
  private int maxConnection = 0;// no limit
  private int idleTimeOut = -1;
  private int checkOutTimeOut = -1;
  private int maxCheckOutTime = -1;
  private int initialSize=-1;
  private String strValidationQuery = "";

  public ConnectionParameters() {
  }

  public String getValidationQuery(){
      String strQry = "";
      if(driver.equalsIgnoreCase("oracle.jdbc.driver.OracleDriver")) strQry = "Select 1 from dual";
      if(driver.equalsIgnoreCase("com.inet.tds.TdsDriver")) strQry = "SELECT 1";
      return strQry;
  }

  public ConnectionParameters(String name, String driver, String url,
                              String userName, String pass, int maxcon,
                              int idleTimeout, int checkout, int maxCheckout,int initialSize) {
    this.name = name;
    this.driver = driver;
    this.url = url;
    this.userName = userName;
    this.Pwd = pass;
    this.maxConnection = maxcon;
    this.idleTimeOut = idleTimeout;
    this.checkOutTimeOut = checkout;
    this.maxCheckOutTime = maxCheckout;
    this.initialSize=initialSize;
  }

    public int getInitialSize() {
        return initialSize;
    }

    public void setInitialSize(int initialSize) {
        this.initialSize = initialSize;
    }

    public void setInitialSize(String initialSize) {
         try {
        	 System.out.println("The  initial Size value is "+initialSize);
             if(initialSize!=null || !initialSize.trim().equals("")){
         	this.initialSize = Integer.parseInt(initialSize);
             }else {
             	this.initialSize = -1;
             }		 
    }
    catch  (NumberFormatException e){
    	System.out.println("error setting initial size ConnectionParameters.java]->0<-"+e);
      this.initialSize = 1;
    }
    }
    public int getCheckOutTimeOut() {
    return checkOutTimeOut;
  }

  public void setCheckOutTimeOut(int checkOutTimeOut) {
    this.checkOutTimeOut = checkOutTimeOut;
  }

  public void setCheckOutTimeOut(String checkOutTimeOut) {
    try {
    	System.out.println("The checkOut TimeOut value is "+checkOutTimeOut);
        if(checkOutTimeOut!=null || !checkOutTimeOut.trim().equals("")){
    	this.checkOutTimeOut = Integer.parseInt(checkOutTimeOut);
        }else {
        	this.checkOutTimeOut = -1;
        }	
    }
    catch  (NumberFormatException e){
    	System.out.println("error setting setCheckOutTimeOut ConnectionParameters.java]->1<-"+e);
      this.checkOutTimeOut = -1;
    }
  }

  public String getDriver() {
    return driver;
  }

  public void setDriver(String driver) {
    this.driver = driver;
  }

  public int getIdleTimeOut() {
    return idleTimeOut;
  }

  public void setIdleTimeOut(int idleTimeOut) {
    this.idleTimeOut = idleTimeOut;
  }

  public void setIdleTimeOut(String idleTimeOut) {
    try {
    	System.out.println("The idle TimeOut value is "+idleTimeOut);
        if(idleTimeOut!=null || !idleTimeOut.trim().equals("")){
    	this.idleTimeOut = Integer.parseInt(idleTimeOut);
        }else {
        	this.idleTimeOut = -1;
        }
    }
    catch  (NumberFormatException e){
    	System.out.println("Error setting setIdleTimeOut ConnectionParameters.java]->2<-"+e);
      this.idleTimeOut = -1;
    }
  }

  public int getMaxCheckOutTime() {
    return maxCheckOutTime;
  }

  public void setMaxCheckOutTime(int maxCheckOutTime) {
    this.maxCheckOutTime = maxCheckOutTime;
  }

  public void setMaxCheckOutTime(String maxCheckOutTime) {
    try {
    	System.out.println("The max CheckOut Time value is "+maxCheckOutTime);
        if(maxCheckOutTime!=null || !maxCheckOutTime.trim().equals("")){
    	this.maxCheckOutTime = Integer.parseInt(maxCheckOutTime);
        }else {
        	this.maxCheckOutTime = -1;
        }
    }
    catch  (NumberFormatException e){
    	System.out.println("Error Setting setMaxCheckOutTime ConnectionParameters.java]->3<-"+e);
      this.maxCheckOutTime = -1;
    }
  }

  public int getMaxConnection() {
    return maxConnection;
  }

  public void setMaxConnection(int maxConnection) {
    this.maxConnection = maxConnection;
  }

  public void setMaxConnection(String maxConnection) {
    try {
    	System.out.println("The max conection value is "+maxConnection);
        if(maxConnection!=null || !maxConnection.trim().equals("")){
    	this.maxConnection = Integer.parseInt(maxConnection);
        }else {
        	this.maxConnection = -1;
        }
        	
    }
    catch  (NumberFormatException e){
    	System.out.println("Error Setting Max Conn ConnectionParameters.java>>4<< " +
    			"\n The available max conection value is "+maxConnection+" " +
    			"\n and error is "+e);
      this.maxConnection = -1;
    }
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPassword() {
    return Pwd;
  }

  public void setPassword(String Pwd) {
    this.Pwd = Pwd;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

}
