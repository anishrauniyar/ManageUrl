/**
 * *************************************************************************************
 *
 * Filename: connectionBean.java
 * Creator : Pawan Shrestha
 * Date    : Oct. 1, 2002
 *
 * Description:
 * This class is inherited by various other classes to perform variuos operations to
 * the database. Methods of this class are used to connect to and disconnect from
 * a database.
 *
 * Modifications:
 * Date:					Changed by:					Description
 * Oct 22 2002 			Pawan K Shrestha			Methods for Date Formatting added
 *
 * Nov 18 2002 			Pawan K Shrestha			Method makeSQLData() added
 * for given data returns either
 * NULL if it is blank else
 * returns with quote if not a number
 * else returns the same data if a number
 *
 * Nov 20 2002 			Pawan K Shrestha			Common methods added
 *
 * Dec 09 2002				Pawan K Shrestha			Bean name changed from "sqlBean.java" to
 * "connectionBean.java"
 *
 * Apr 27 2003				Pawan K Shrestha			HawkeyeUser.dbo.tbl_users changed to
 * [HawkeyeUser].HawkeyeUser.dbo.usr_Users and
 * its field names corrected
 *
 **************************************************************************************
 */
package com.d2hs.soam;

import com.d2hs.soam.SqlBean;
import com.d2hs.soam.rm.QueryBean;

import java.sql.*;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

public abstract class ConnectionBean extends SqlBean {

    protected ResultSet logRS;
    protected ResultSet lblRS;

    /**
     * ****************** Variables for Record Paging ********************
     */
    private int recordCount = 0;      // total no of records
    private int pageCount = 1;      // total pages of records for a given max record
    private int recordSize = 0;      // no of records per page
    private int currentPage = 0;      // absolute no of current page
    private int pageRecord = 0;      // maximum record for current page
    /**
     * ****************** *************************** ********************
     */

    public Statement stmt;
    public String strSQL = "";
    public String strCountSQL = "";
    public String errorStr = "No Error !";
    final static Logger logger = Logger.getLogger(ConnectionBean.class);

    public ConnectionBean() {
    }
    /**
     * Epsilon is the limit set for smallest numbers to be dealt with. If the
     * absolute value of any number happens to fall shorter than epsilon, it
     * will be taken as zero.
     */
    private static double Epsilon = 0.001;
    /**
     * This is the string representation for any number which is smaller than
     * Epsilon in it's absolute magnitude. This is set to "0" here and there is
     * little reason for using anything else.
     */
    private static final String strNearZero = "0";

    public void connectDB() throws Exception {
        //setDataBaseName("MDHawkeye->HawkeyeOAM");
        setDataBaseName("RequestManager->SuperDomainDataBase");
        makeConnection();
    }

    public void setRecordSize(int rsSize) {
        recordSize = rsSize;
    }

    public int getPageCount() {
        if (recordCount > recordSize) {
            pageCount = (int) Math.ceil((double) recordCount / recordSize);
        }
        return pageCount;
    }

    public int getPageRecord(int curPage) {
        int pgCount = getPageCount();
        int rsCount = recordCount;
        int rsSize = recordSize;
        pageRecord = rsSize;

        if (pgCount > 1) {
            if (curPage == pgCount) {
                pageRecord = rsCount - ((pgCount - 1) * rsSize);
            }
        } else {
            pageRecord = rsCount;
        }
        return pageRecord;
    }

    public int getRecordCount() {
        String sqlCount = getSQLCountQuery();
        try {
            Statement st = myConn.createStatement();
            ResultSet rsCount = st.executeQuery(sqlCount);
            if (rsCount.next()) {
                recordCount = rsCount.getInt("RecCount");
            }
        } catch (Exception e) {
            errorStr = "Recordcount error : " + e.toString();
        }
        return recordCount;
    }

    public void setAbsolutePage(int curPage) {
        try {
            if (curPage > 1) {
                logRS.absolute((curPage - 1) * recordSize);
            }
        } catch (Exception e) {
            errorStr = "Record Absolute Error: " + e.toString();
        }

    }

    public String getSQLQuery() {
        return strSQL;
    }

    public String getSQLCountQuery() {
        return strCountSQL;
    }

    public void disconnectDB() {
        takeDown();
    }

    private String padZero(String val, int startIndex, int count) {
        String newNum = val.substring(startIndex, count);
        int zerosToPad = count - newNum.length();
        if (zerosToPad > 0) {
            for (int i = 0; i < zerosToPad; i++) {
                newNum += "0";
            }
        }
        return newNum;

    }

    private String getRoundedValueNew(String val, int place) {
        if (place < 1) {
            return "";
        }

        //check whether the decimal is less or equal to the desired place
        if (val.length() <= place) {
            return val;
        }

        String newNumber = "";
        char[] c = val.toCharArray();
        boolean addOne = false;
        int i = 0;
        int threshold = 5;
        for (i = val.length() - 1; i > 0; i--) {
            int tmpInt1 = new Integer(new String(c, i, 1)).intValue();
            int tmpInt2 = new Integer(new String(c, i - 1, 1)).intValue();
            if (i < val.length() - place) {
                threshold = 9;
            }
            if (addOne) {
                tmpInt1++;
            }
            if (tmpInt1 > threshold) {
                c[i] = '0';
                tmpInt2++;
                if (tmpInt2 < 9) {
                    c[i - 1] = new String("" + tmpInt2).charAt(0);
                    addOne = false;
                } else {
                    addOne = true;
                }
            } else {
                addOne = false;
            }
        }

        if (addOne) {
            int tmpInt1 = new Integer(new String(c, 0, 1)).intValue();
            c[0] = '0';
            newNumber = "1" + new String(c);
        } else {
            newNumber = new String(c);
        }
        return newNumber;

    }

    /**
     * set the Comma after every digits starting from the right e.g. "998234443"
     * to "998,234,443"
     *
     * @param val String representing integer value
     * @return String comma seperated standard formatted value
     */
    public String setCommas(String val) {
        int len, rem = 0;
        String str = "";

        len = val.length();
        //in case len is less than 3 or equal to 3
        if (len <= 3) {
            return val;
        }
        rem = len % 3;
        //in case rem not equal to zero
        if (rem != 0) {
            str = val.substring(0, rem);
        } else {
            str = val.substring(0, 3);
            rem = 3;
        }

        for (int i = rem; i <= len - 3; i += 3) {
            try {
                str = str + "," + val.substring(i, i + 3);
            } catch (StringIndexOutOfBoundsException sioobe) {
                System.out.println("Index exceeded");
            }
        }
        return str;
    }

    /**
     * Manipulates the Data to return in the comma seperated standard format
     * e.g. "23444.33483473847" to "23,444.334" if place is 3
     *
     * @param val String representing numeric value
     * @param place no of place after decimal to have the value rounded
     * @return String comma seperated standard formatted value
     */
    public String manipulateData(String val, int place) {
        return manipulateData(val, place, "");
    }

    /**
     * Manipulates the Data to return in the comma seperated standard format
     * along with the tag e.g. "23444.33483473847" to "$23,444.334" if place is
     * 3 and tag is "$"
     *
     * @param val String representing numeric value
     * @param place no of place after decimal to have the value rounded
     * @param tag to be added to the result spring e.g. "$", "%"
     * @return String comma seperated standard formatted value
     */
    public String manipulateData(String val, int place, String tag) {
        String str1, str2, str3 = "", retString = "0.00";
        String Value = val;

        //checking if the val is empty or null
        if (Value == null || Value == "" || Value.equals("0.0")) {
            if (tag == "%") {
                return "0.00%";
            } else {
                return tag + "0.00";
            }
        }

        int i = Value.indexOf(".");
        if (i < 0) {
            return setCommas(Value);
        }

        Value += "0000000000";
        int expPos = Value.indexOf("E");
        if (expPos > 0) {
            str3 = Value.substring(expPos);
        }

        str1 = Value.substring(0, i);
        int negPos = str1.indexOf("-");
        if (negPos > -1) {
            str1 = str1.substring(negPos + 1);
        }

        if ((Value.length() - i) > place) {
            str2 = val.substring(i + 1);
        } else {
            str2 = Value.substring(i + 1);
        }

        //System.out.println(str2);
        if (place == 0) {
            retString = setCommas(str1);
        } else {
            String str2_1 = getRoundedValueNew(str2, place);
            //System.out.println(str2_1);
            int beginIndex = 0;
            if (str2_1.length() > str2.length()) {
                try {
                    long lng = new Long(str1).longValue() + 1;
                    str1 = "" + lng;
                } catch (Exception e) {
                    str1 = "1";
                }
                beginIndex = 1;
            }
            //retString = setCommas(str1)+"."+getRoundedValue(str2,place)+str3;
            retString = setCommas(str1) + "." + padZero(str2_1, beginIndex, place) + str3;
        }

        if (negPos > -1) {
            if (tag.equals("%")) {
                return "<font color=#ff0000>-" + retString + tag + "</font>";
            } else if (tag.equals("$")) {
                return "<font color=#ff0000>(" + tag + retString + ")</font>";
            } else {
                return "(" + tag + retString + ")";
            }

        } else if (tag.equals("%")) {
            return retString + tag;
        } else {
            return tag + retString;
        }
    }

    public String getData(String s) {
        String s1 = "";
        try {
            s1 = logRS.getString(s);
            if (s1 != null) {
                //s1 = s1.replace('`','\'').replaceAll("<","&lt;").replaceAll(">","&gt;");
                s1 = s1.replace('`', '\'');//.replaceAll("<","&lt;").replaceAll(">","&gt;");
            } else {
                s1 = "";
            }

        } catch (SQLException sqlexception) {
            errorStr = "Resultset error : " + sqlexception;
        }

        return s1;
    }

    public String getDataWithoutPara(String s, String color) {
        String s1 = "";
        try {
            s1 = logRS.getString(s);
            if (s1 != null) {
                String table = "<table><tr><td valign='center'><font color='" + color + "'>:&nbsp;</td><td><font color='" + color + "'>" + s1 + "</td></tr></table>";
                s1 = table;
                //s1 = s1.replace('`','\'').replaceAll("<","&lt;").replaceAll(">","&gt;");
                //s1 = s1+"   ";
                //s1 = s1.replaceFirst("<p>","");//.replaceAll("<","&lt;").replaceAll(">","&gt;");
                // s1 = s1.replace("</p>","");
            } else {
                s1 = "";
            }

        } catch (SQLException sqlexception) {
            errorStr = "Resultset error : " + sqlexception;
        }

        return s1;
    }

    public String getData(String s, boolean HTMLTagOn) {
        String s1 = "";
        try {
            s1 = logRS.getString(s);
            if (s1 != null) {
                s1 = s1.replace('`', '\'');
            } else {
                s1 = "";
            }
        } catch (SQLException sqlexception) {
            errorStr = "Resultset error : " + sqlexception;
        }

        return s1;
    }

    /**
     * returms numeric value for the related field name from the ResultSet,
     * comma seperated and rounded at the position specified e.g.
     * getData("total",2) returns "1,234,567.93" [for the numeric field only]
     *
     * @param fld String representing the FieldName
     * @param decimalPlaces no of digits after decimal
     * @return String Formatted Numeric Field value from the ResultSet
     */
    public String getData(String fld, int decimalPlaces) {
        String tmp = new String();
        float fTmp;

        try {
            tmp = logRS.getString(fld);
            fTmp = new Float(tmp).floatValue();
            fTmp = Math.abs(fTmp);
            if (fTmp <= Epsilon) {
                tmp = strNearZero;
            }
        } catch (NumberFormatException nfe) {
            tmp = "0";
        } catch (NullPointerException npd) {
            tmp = "0";
        } catch (Exception ex) {
            System.out.println("Exp getParameter(,): " + fld + ex.toString());
            tmp = "";
        }
        int i = tmp.indexOf(".");

        if (i < 0) {
            tmp = tmp + ".000000000000";
        } else {
            tmp = tmp + "000000000000";
        }

        return (manipulateData(tmp, decimalPlaces));
    }

    /**
     * returms numeric value for the related field name from the ResultSet,
     * comma seperated and rounded at the position specified along with the tag
     * e.g. getData("total",2,"%") returns "43.93%" or getData("total",2,"$")
     * returns "$4,343,343.93"
     *
     * @param fld String representing the FieldName
     * @param decimalPlaces no of digits after decimal
     * @param tag e.g. "%", "$"
     * @return String Formatted Numeric Field value from the ResultSet along
     * with the tag
     */
    public String getData(String fld, int decimalPlaces, String tag) {
        String tmp = new String();
        float fTmp;
        try {
            tmp = logRS.getString(fld);
            fTmp = new Float(tmp).floatValue();
            fTmp = Math.abs(fTmp);
            if (fTmp <= Epsilon) {
                tmp = strNearZero;
            }
        } catch (NumberFormatException nfe) {
            tmp = "0";
        } catch (NullPointerException npd) {
            tmp = "0";
        } catch (Exception ex) {
            System.out.println("Exp getParameter(,): " + fld + ex.toString());
            tmp = "0";
        }

        if (tag == "%") {
            tmp = Float.valueOf(tmp).floatValue() * 100 + "";
        }

        int i = tmp.indexOf(".");
        if (i < 0) {
            tmp = tmp + ".000000000000";
        } else {
            tmp = tmp + "000000000000";
        }
        return (manipulateData(tmp, decimalPlaces, tag));
    }

    public boolean moveNext() {
        boolean tmp = false;
        try {
            tmp = logRS.next();
        } catch (SQLException ex) {
        }
        return tmp;
    }

    public boolean moveFirst() {
        boolean tmp = false;
        try {
            tmp = logRS.first();
        } catch (SQLException ex) {
        }
        return tmp;
    }

    public String getSortOrder(String sortByFromQuery, String sortOrderFromQuery, String thisSortBy) {
        String thisSortOrder = "a";
        if (thisSortBy.equals(sortByFromQuery)) {   //checking if the previously ordered column is the same one clicked now.
            // if both the columns are same, then do nothing but just toggle the ascending/descending orders
            if (sortOrderFromQuery.length() == 0) {
                thisSortOrder = "a"; //set it as ascending
            } else if (sortOrderFromQuery.charAt(0) == 'a') {
                thisSortOrder = "d";
            } else if (sortOrderFromQuery.charAt(0) == 'd') {
                thisSortOrder = "a";
            }
        }
        if (!thisSortBy.equals(sortByFromQuery)) //checking if the sorted columns are different
        {
            if (thisSortBy.equalsIgnoreCase("b") || thisSortBy.equalsIgnoreCase("k") || thisSortBy.equalsIgnoreCase("g") || thisSortBy.equalsIgnoreCase("y"))//if the column clicked now is that of date, it is sorted in descending order initially
            {
                thisSortOrder = "d";
            }
        }
        return thisSortOrder;
    }

    public boolean getList(String sqlStr, String whatToList) {

        boolean flag = false;
        //logger.trace("getList->" + whatToList + ": " + sqlStr);
        try {
            closeRecordSet();
            if (myConn == null || myConn.isClosed()) {
                connectDB();
            }
            stmt = myConn.createStatement();
            logRS = stmt.executeQuery(sqlStr);

            flag = true;
            strSQL = sqlStr;
        } catch (SQLException sqlexception) {
            errorStr = whatToList + " Listing Error : " + sqlexception.getMessage();
            logger.error("ERROR QUERY > " + sqlStr);
            logger.error(errorStr);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return flag;
    }

    public boolean insertItem(String sqlStr, String whatToList) {

        //System.out.println("DEBUG ::::::::::::::::::::: \n" + sqlStr);
        boolean flag = false;
        //System.out.println("getList->"+whatToList+": "+this.strSQL);
        try {
            closeRecordSet();
            if (myConn == null || myConn.isClosed()) {
                connectDB();
            }
            stmt = myConn.createStatement();
            stmt.execute(sqlStr);
            flag = true;

        } catch (SQLException sqlexception) {
            errorStr = whatToList + " Listing Error : " + sqlexception;
            System.out.println(errorStr);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return flag;
    }

    public boolean closeRecordSet() {
        boolean flag = false;
        try {
            if (logRS != null) {
                logRS.close();
                logRS = null;
            }
            flag = true;
        } catch (SQLException sqlexception) {
            errorStr = "Recordset close error : " + sqlexception;
        }
        return flag;
    }

    public String getDateRange(String d) {
        String delim = "";
        String d1 = "";
        String d2 = "";
        String x = "";
        d = d.toLowerCase().replaceAll("between", "").replaceAll("and", "-");
        if (d.indexOf(">") >= 0) {
            delim = ">";
        } else if (d.indexOf("<") >= 0) {
            delim = "<";
        } else if (d.indexOf("-") >= 0) {
            delim = "-";
        }

        if (delim.length() > 0) {
            StringTokenizer st = new StringTokenizer(d, delim);
            while (st.hasMoreTokens()) {
                d2 = st.nextElement().toString();
                if (d1.length() == 0) {
                    d1 = d2;
                }
            }
        } else {
            d2 = d;
            delim = "=";
        }

        if (delim.equals("-")) {
            x = " BETWEEN to_date('" + d1 + "','mm/dd/yy') AND to_date('" + d2 + "','mm/dd/yy')";
        } else {
            x = " " + delim + " to_date('" + d2 + "','mm/dd/yy')";
        }
        return x;
    }

    public String getOnlyDateY2(String dt) {
        if (dt == null) {
            return "";
        } else if (dt.trim().length() > 0) {
            StringTokenizer st = new StringTokenizer(dt, " ");
            return (formatDateY2(st.nextElement().toString()));
        } else {
            return "";
        }
    }

    public String formatDateY2(String dt) {
        String x = dt;
        String y = "";
        String m = "";
        String d = "";
        if (dt.indexOf("-") > 0) {
            StringTokenizer st = new StringTokenizer(dt, "-");
            int count = 0;
            while (st.hasMoreTokens()) {
                if (count == 0) {
                    y = st.nextElement().toString().substring(2);
                } else if (count == 1) {
                    m = st.nextElement().toString();
                } else if (count == 2) {
                    d = st.nextElement().toString();
                }
                count++;
            }
            x = m + "/" + d + "/" + y;
        }
        return x;
    }

    public String formatDate(String dt, boolean removeInitialZeroOfDayAndMonth) {
        String x = dt;
        String y = "";
        String m = "";
        String d = "";
        if (dt.indexOf("-") > 0) {
            StringTokenizer st = new StringTokenizer(dt, "-");
            int count = 0;
            while (st.hasMoreTokens()) {
                if (count == 0) {
                    y = st.nextElement().toString();
                } else if (count == 1) {
                    m = st.nextElement().toString();
                } else if (count == 2) {
                    d = st.nextElement().toString();
                }
                count++;
            }

            if (removeInitialZeroOfDayAndMonth) {
                x = removeFirstZero(m) + "/" + removeFirstZero(d) + "/" + y;
            } else {
                x = m + "/" + d + "/" + y;
            }
        }
        return x;
    }

    public String removeFirstZero(String num) {
        String s = num;
        if (num.length() == 2) {
            if (num.charAt(0) == '0') {
                s = new StringBuffer("").append(num.charAt(1)).toString();
            }
        }
        return s;
    }

    public String getOnlyDate(String dt, boolean removeInitialZeroOfDayAndMonth) {
        if (dt.length() > 0) {
            StringTokenizer st = new StringTokenizer(dt, " ");
            return (formatDate(st.nextElement().toString(), removeInitialZeroOfDayAndMonth));
        } else {
            return "";
        }
    }

    public String makeSQLData(String data, boolean isNumber) {
        if (data.equals("")) {
            return "NULL";
        } else if (isNumber) {
            return data.replace('\'', '`');
        } else {
            return "'" + data.replace('\'', '`') + "'";
        }
    }

    public static void main(String[] args) {
        String test = "<p>this is testing<p></p>";
        test = test.replaceFirst("<p>", "");
        System.out.println(test);
        //System.out.println(test.replace("<p>", ""));
    }
}
