/**
 *    10/12/2003  Nilesh  send mail to new user.
 * --------------------------------------------------------------------------------
 */
package com.d2hs.soam.common;

import java.util.Date;
import java.util.Properties;
import java.util.Vector;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.mail.*;
import javax.mail.internet.*;

public class SendMail {

    public SendMail() {
        InternetAddress[] temp = new InternetAddress[qcEmails.length];
        int realQcNum = 0;
        for (int i = 0; i < qcEmails.length; i++) {

            try {
                if ((qcEmails[i]).indexOf("N/A") == -1) {
                    temp[realQcNum] = new InternetAddress(qcEmails[i]);
                    realQcNum++;
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        qcAddList = new InternetAddress[realQcNum];
        for (int i = 0; i < realQcNum; i++) {
            try {
                qcAddList[i] = temp[i];
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
    private boolean hasCCAddr = false;
    private InternetAddress[] ccAddrList;
    private String errString = "";
    private String host = "smtpnj.d2hawkeye.net";
    /**
     * List of qc persons.
     */
    private String[] qcEmails = {"raju.kc@verscend.com"};
    private InternetAddress[] qcAddList;
    private boolean isQC = true;

    public String getError() {
        return errString;
    }

    public void setSMTPHost(String smtp) {
    //host	= smtp;
    }

    public String getSMTPHost() {
        return host;
    }

    public void setCCAddresses(Vector ccAddr) {
        try {
            hasCCAddr = true;
            ccAddrList = new InternetAddress[ccAddr.size()];
            for (int i = 0; i < ccAddrList.length; i++) {
                ccAddrList[i] = new InternetAddress(ccAddr.elementAt(i).toString());
            }
        } catch (Exception e) {
            errString = e.toString();
        }

    }

    public boolean send(String from, String to, String msgSubject, String msgText) {
    	 if (isQC()) {
    		 Vector to1=new Vector();
    		 to1.add("raju.kc@verscend.com");
    		 Vector ccs=new Vector();
    		 ccs.add("raju.kc@verscend.com");
             return  sendQC(from, to1, ccs, msgSubject, msgText);
         }
        boolean msgSend = false;

        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.transport.protocol", "smtp");
        Session session = Session.getDefaultInstance(props, null);

        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            InternetAddress[] address = {new InternetAddress(to)};
            msg.setRecipients(Message.RecipientType.TO, address);

            //add cc addresses
            if (hasCCAddr) {
                msg.setRecipients(Message.RecipientType.CC, ccAddrList);
            }

            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            Transport.send(msg);
            hasCCAddr = false;
        } catch (Exception e) {
            errString = e.toString();
        }

        return msgSend;
    }


    public boolean sendQC(String from, Vector to, Vector ccs, String msgSubject, String msgText) {
        boolean msgSend = false;

        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.transport.protocol", "smtp");

        Session session = Session.getDefaultInstance(props, null);
        String intended = "----------------------------<br><br><b>To::</b> ";
        try {
            InternetAddress[] toList = new InternetAddress[to.size()];
            for (int i = 0; i < toList.length; i++) {
                intended += to.elementAt(i).toString() + ",";
            }
            
            // create message object, fill required and optional parameters and send.
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipients(Message.RecipientType.TO, new InternetAddress[]{new InternetAddress("raju.kc@verscend.com")});
            intended += " <br/><b>CC::</b>";
            
            //add cc addresses
            if (ccs != null) {
                InternetAddress[] ccList = new InternetAddress[ccs.size()];
                for (int i = 0; i < ccList.length; i++) {
                    ccList[i] = new InternetAddress(ccs.elementAt(i).toString());
                    intended += ccList[i].getAddress() + ",";
                }
            }
            msg.setRecipients(Message.RecipientType.CC, qcAddList);
            intended += "<br/>----------------------------------------------<br><br><b>Orginal Mail::</b><br>";

            msgText = intended + msgText;
            msgSubject = "[ICE QC] " + msgSubject;

            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            Transport.send(msg);
            msgSend = true;
            hasCCAddr = false;
        } catch (Exception e) {
            System.out.println("\nError:[default-war/d2Systems/oam/SendMail.java]->2<-" + e);
            errString = e.toString();
        }

        return msgSend;
    }

    public boolean sendList(String xmlFileName, String from, String sub, String msg) {
        try {
            SendMail mail = new SendMail();
            FileReader xmlFileReader = new FileReader(xmlFileName);
            BufferedReader xmlFileBReader = new BufferedReader(xmlFileReader);

            String fileLine = "";
            String toName = "";
            String toEmail = "";
            boolean success = true;

            do {
                fileLine = xmlFileBReader.readLine();
                if (fileLine.indexOf("<file>") == -1 && fileLine.indexOf("</file>") == -1) {
                    toName = fileLine.substring(fileLine.indexOf("<name>") + 6, fileLine.indexOf("</name>"));
                    toEmail = fileLine.substring(fileLine.indexOf("<email>") + 7, fileLine.indexOf("</email>"));
                    System.out.println("Name: " + toName + " Email: " + toEmail);
                    mail.send(from, toName + "<" + toEmail + ">", sub, msg);
                }
            } while (fileLine.indexOf("</file>") == -1);
            return success;
        } catch (FileNotFoundException err) {
            System.out.println(err);
            return false;
        } catch (IOException err) {
            System.out.println(err);
            return false;
        }
    }

    /**
     * @param isQC the isQC to set
     */
    public void setQC(boolean isQC) {
        this.isQC = isQC;
    }

    /**
     * @return the isQC
     */
    public boolean isQC() {
        return isQC;
    }
}
