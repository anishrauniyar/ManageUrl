package com.d2hs.soam.rm;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import com.d2hs.soam.ConnectionBean;



/**
 * Created by IntelliJ IDEA.
 * User: phada
 * Date: Jan 27, 2006
 * Time: 10:13:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class customForm extends ConnectionBean {

    ArrayList rowObjectList=new ArrayList();

    //Changed by:Raju Thapa Shrestha,Feb 22,2008
    //Changes   :added Order By in SQL query 
    public boolean getActiveColumn()
   {
   	  strSQL= ""
   			+ "select a.LabelName as LabelName,a.ColumnName as ColumnName,a.ColumnID as ColumnID, "
   			+ "               Nvl((select Distinct ActiveColumn from oam_cr_user_custom_fields b "
   			+ "               where a.ColumnID=b.ColumnID and b.UserID='"+userID+"' and a.FormID=b.FormID),a.DefaultStatus) "
   			+ "               as ActiveColumn from oam_cr_custom_fields a "
   			+ "               where a.FormID='"+formID+"' "
   			+ "               Order By a.ColumnOrder";    
	return getList(strSQL,"Request Manager Columns");
   }
    public String formID;
    public String userID;
    private String requestTypeID;

    public String getFormID() {
        return formID;
    }

    public void setFormID(String formID) {
        this.formID = formID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setRequestTypeID(String requestTypeDesc) {
    	this.requestTypeID=getID(requestTypeDesc);
	}
    
    public String getID(String requestTypeDesc){
    	String ID="";
    	if(requestTypeDesc.equals("")) requestTypeDesc="Request"; 
    	try{
    		strSQL="select requestTypeID from oam_rm_request_types where UPPER(requestTypeDesc)=UPPER('"+requestTypeDesc+"')";
    		//System.out.println(strSQL+"Executing");
    		if(myConn==null)
    			this.connectDB();
    		Statement st=myConn.createStatement();
    		//System.out.println("*******************Get id query is:"+strSQL);
    		myRS =st.executeQuery(strSQL);
    		while(myRS.next())
    		{
    			ID=myRS.getString("requestTypeID");
    		}
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	return(ID);
    }

	public String getRequestTypeID() {
		return requestTypeID;
	}

	public void displayFormColumn(javax.servlet.http.HttpServletRequest request) throws Exception {
        try {
            int col=0;

            Statement stmnt=myConn.createStatement();
            strSQL="delete oam_cr_user_custom_fields "+
            "where  UserID='"+userID+"'"; 
            //System.out.println(strSQL);
            stmnt.executeUpdate(strSQL);

            String colFieldName="";
            for (Enumeration e = request.getParameterNames() ; e.hasMoreElements() ;) {
                 colFieldName=e.nextElement().toString();
                 if(colFieldName.startsWith("col")) {
                	 //System.out.println(colFieldName);
                 col=Integer.parseInt(colFieldName.substring("col".length(),colFieldName.length()));



                    strSQL="insert INTO oam_cr_user_custom_fields "+
                    "values('"+formID+"','"+userID+"',"+col+",'"+request.getParameter(colFieldName)+"')";
                    //System.out.println(strSQL);
                    stmnt.executeUpdate(strSQL);

                }
            }
        }
        catch (Exception e) {
            throw e;
        }
    }
    public void resetForm(javax.servlet.http.HttpServletRequest request) throws Exception {
        try {
            Statement stmnt=myConn.createStatement();
            strSQL="delete oam_cr_user_custom_fields "+
            " where FormID='"+formID+"' and "+
            " UserID='"+userID+"'";
            stmnt.executeUpdate(strSQL);
        }
        catch (Exception e) {
            throw e;
        }

    }
    public RowObject[] executeFormQueryNew()  throws Exception {
        //where if the columns to be set for a user (replaced by the default status where NULL ) are set to active OR ActiveColumn = 'Y'
        // basically, getting the columns that the user has selected to be displayed by customizing them.
          strSQL="Select a.LabelName as LabelName,a.ColumnName as ColumnName, "+
                  "Nvl(a.Filter,1) as Filter,Nvl(a.Sort,1) as Sort, "+
                  "Nvl(a.ShowDetails,'') as ShowDetails,a.ColumnOrder as ColumnOrder,a.ColumnType as ColumnType "+
                  "from OAM_RM_CUSTOM_FIELDS a "+
                  "where Nvl((select Distinct ActiveColumn from OAM_RM_USER_CUSTOM_FIELDS b "+
                  "where a.ColumnID=b.ColumnID and b.UserID='"+userID+"' and a.FormID=b.FormID and a.requestTypeID=b.requestTypeID),a.DefaultStatus) ='Y' "+
                  "and a.requestTypeID='"+requestTypeID+"' "+
                  "and a.FormID='"+formID+"' ";
          strSQL+=" order by a.columnOrder desc ";
          System.out.println(strSQL+"Executing");
          
          try{
        	  //System.out.println(strSQL+"Executing");
              Statement stmnt = myConn.createStatement();
              myRS = stmnt.executeQuery(strSQL);
              
              RowObject rb=null;
              int count=0;
              while(myRS.next()){

                  rb=new RowObject();
                  rb.setLabelName(myRS.getString("LabelName"));
                  rb.setColumnName(myRS.getString("ColumnName"));
                  rb.setFilterValue(myRS.getInt("Filter"));
                  rb.setSortValue(myRS.getString("Sort"));
                  rb.setColumnType(myRS.getInt("ColumnType"));
                  rowObjectList.add(count,rb);
                  count++;                  
                  //System.out.println(strSQL+"Executed");
              }
              myRS.close();
             // stmnt.close();
          }catch(Exception e){
              e.printStackTrace();throw e;
          }
          //System.out.println("Custom Foprm open");
          //return rowObjectList.toArray();
          RowObject [] rowobjects = new RowObject[ rowObjectList.size()];
          rowobjects = (RowObject []) rowObjectList.toArray( rowobjects);
          //System.out.println("Custom Foprm end");
          return rowobjects;
      }
    
    public RowObject[] executeFormQueryNew_CR()  throws Exception {
        //where if the columns to be set for a user (replaced by the default status where NULL ) are set to active OR ActiveColumn = 'Y'
        // basically, getting the columns that the user has selected to be displayed by customizing them.
          strSQL=" Select a.LabelName as LabelName,a.ColumnName as ColumnName, "+
                  " Nvl(a.Filter,1) as Filter,Nvl(a.Sort,1) as Sort, "+
                  " Nvl(a.ShowDetails,'') as ShowDetails,a.ColumnOrder as ColumnOrder,a.ColumnType as ColumnType "+
                  "from oam_cr_custom_fields a "+
                  "where Nvl((select Distinct ActiveColumn from oam_cr_user_custom_fields b "+
                  "where a.ColumnID=b.ColumnID and b.UserID='"+userID+"' and a.FormID=b.FormID),a.DefaultStatus) ='Y' "+
                  "and a.FormID='"+formID+"' ";
          strSQL+=" order by a.columnOrder desc ";

          //System.out.println("Query >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>?"+strSQL);
          try{
              Statement stmnt = myConn.createStatement();
              myRS = stmnt.executeQuery(strSQL);

              RowObject rb=null;
              int count=0;
              while(myRS.next()){

                  rb=new RowObject();
                  rb.setLabelName(myRS.getString("LabelName"));
                  rb.setColumnName(myRS.getString("ColumnName"));
                  rb.setFilterValue(myRS.getInt("Filter"));
                  rb.setSortValue(myRS.getString("Sort"));
                  rb.setColumnType(myRS.getInt("ColumnType"));
                  rowObjectList.add(count,rb);
                  count++;

              }
              myRS.close();
             // stmnt.close();
          }catch(Exception e){
              e.printStackTrace();throw e;
          }
          //return rowObjectList.toArray();
          RowObject [] rowobjects = new RowObject[ rowObjectList.size()];
          rowobjects = (RowObject []) rowObjectList.toArray( rowobjects);
          return rowobjects;
      }

    /**
     * 
     * getColumnsForLightPage
     * customForm
     * Description:
     * <li>returns the default columns for the light page</li>
     * @return
     * @return RowObject[]
     * @author:Ramesh Raj Baral
     * @since:Jun 28, 2010
     *
     */
    public RowObject[] getColumnsForLightPage(){
    	List rowObjectList=new ArrayList();
    	String sql="SELECT DISTINCT a.labelname            AS labelname, "
		    		+ "                a.columnname           AS columnname, "
		    		+ "                a.columnid             AS colid, "
		    		+ "                Nvl(a.filter, 1)       AS filter, "
		    		+ "                Nvl(a.sort, 1)         AS sort, "
		    		+ "                Nvl(a.showdetails, '') AS showdetails, "
		    		+ "                a.columnorder          AS columnorder, "
		    		+ "                a.columntype           AS columntype "
		    		+ " FROM   oam_rm_custom_fields a "
		    		+ " WHERE  "
		    		+ " a.columnid BETWEEN 1 AND 4 "
		    		+ " OR a.columnid BETWEEN 6 AND 9 "
		    		+ " OR a.columnid = '33' "
		    		+ " OR a.columnid = '13' "
		    		+ " OR a.columnid = '60' "
		    		+ " OR a.columnid = '65' "
		    		+ " OR a.columnid = '66' "
		    		+ " ORDER  BY a.columnorder ";
    	try{
      	  
            Statement stmnt = myConn.createStatement();
            myRS = stmnt.executeQuery(sql);
            RowObject rb=null;
            int i=0;
            while(myRS.next()){
            	rb=new RowObject();
                rb.setLabelName(myRS.getString("labelname"));
                rb.setColumnName(myRS.getString("columnname"));
                rb.setFilterValue(myRS.getInt("filter"));
                rb.setSortValue(myRS.getString("sort"));
                rb.setColumnType(myRS.getInt("columntype"));
                rowObjectList.add(i,rb);
                i++;
               
            }
            myRS.close();

        }catch(Exception e){
            e.printStackTrace();
            
        }
        RowObject[] rowObjectArr=new RowObject[rowObjectList.size()];
        for(int i=0;i<rowObjectList.size();i++){
        	rowObjectArr[i]=(RowObject)rowObjectList.get(i);
        }
    	return rowObjectArr;
    }

    
   /**
    *  Description:
     * <li>returns the columns for the light page</li>
    * getCustomizeColumns
    * customForm
    * @param userID
    * @return
    * @return List
    * @author:Ramesh Raj Baral
    * @since:Aug 13, 2010
    *
    */
 /*   public List getCustomizeColumns(String userID){
    	List customFieldsList=new ArrayList();
    	
    	String sql="SELECT DISTINCT a.labelname            AS labelname, "
		    		+ "                a.columnname           AS columnname, "
		    		+ "                a.columnid             AS colid, "
		    		+ "                Nvl(a.filter, 1)       AS filter, "
		    		+ "                Nvl(a.sort, 1)         AS sort, "
		    		+ "                Nvl(a.showdetails, '') AS showdetails, "
		    		+ "                a.columnorder          AS columnorder, "
		    		+ "                a.columntype           AS columntype "
		    		+ " FROM   oam_rm_custom_fields a "
		    		+ " WHERE  "
		    		+ " a.columnid BETWEEN 1 AND 4 "
		    		+ " OR a.columnid BETWEEN 6 AND 9 "
		    		+ " OR a.columnid = '33' "
		    		+ " OR a.columnid = '13' "
		    		+ " OR a.columnid = '60' "
		    		+ " ORDER  BY a.columnorder ";
    	try{
      	  
            Statement stmnt = myConn.createStatement();
            myRS = stmnt.executeQuery(sql);
            UserCustomFields customFields=null;
            int i=0;
            while(myRS.next()){
            	customFields=new UserCustomFields();
            	customFields.setColID(myRS.getString("colid"));
            	customFields.setColumnName(myRS.getString("columnname"));
            	customFields.setLabelName(myRS.getString("labelname"));
            	customFieldsList.add(customFields);
            	customFields.setSelected(false);
            }
            myRS.close();

        }catch(Exception e){
            e.printStackTrace();
            
        }
       return customFieldsList;
    }*/
}
