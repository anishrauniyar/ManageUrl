package com.d2hs.soam.rm;

import com.d2hs.soam.ConnectionBean;
import com.d2hs.soam.common.TextEncoder;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.lang.String;

public class Preference extends ConnectionBean
{
  public Connection conn;
    /* Function name: checkClientPreference
    Description: This function checks if the user has a preferred client in which case the check mark is not shown
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the user has preferred client*/
    public String checkClientPreference(String userID)
    {
        String cid = "";
        String str = "Select PreferredClientID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "'";
        if(getList(str, ""))
            {if (moveNext())
                {cid = getData("PreferredClientID");


            }}
            return cid;
    }
    
    /* Function name: checkIssueTypePreference
    Description: This function checks if the user has a preferred issueType in which case the check mark is not shown
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the user has preferred issueType*/
    public String checkIssueTypePreference(String userID)
    {
        String issueTypeId = "";
        String str = "Select PREFERREDISSUETYPEID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "'";
        if(getList(str, ""))
            {if (moveNext())
                {issueTypeId = getData("PREFERREDISSUETYPEID");


            }}
            return issueTypeId;
    }

    /* Function name: checkProductPreference
    Description: This function checks if the user has a preferred product in which case the check mark is not shown
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the user has preferred client */
    public String checkProductPreference(String userID, String cid)
    {
        String pid = "n";
        String str = "Select PreferredProductID from OAM_RM_USER_PREFERENCES where PreferredClientID = '" +cid + "' and UserID = '" +userID+ "'";
        if(getList(str, ""))
            {if (moveNext())
                {pid = getData("PreferredProductID");
            }}
            return pid;
    }
    
    public String checkProjectPreference(String userID,String ClientID,String ProductID)
    {
        String pid = "n";
        String str = "Select PreferredProjectID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "' and PreferredClientID = '" +ClientID + "' and PreferredProductID = '" +ProductID + "'";
        if(getList(str, ""))
            {if (moveNext())
                {pid = getData("PreferredProjectID");
            }}
            return pid;
    }

    /* Function name: setPreferredClient
    Description: This function checks if the user has a preferred client. If yes, the preferred client is changed otherwise it is inserted
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the operation was successful*/
    public boolean setPreferredClient (String userID, String clientid)
    {
        boolean bool = false;

        String str = "Insert into OAM_RM_USER_PREFERENCES Select '" +userID+ "', NULL, NULL,NULL, NULL, NULL,NULL FROM DUAL where not exists (select UserID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "')";
        
        try
        {
            Statement stmnt=myConn.createStatement();
            stmnt.execute(str);
            
            str =" Update OAM_RM_USER_PREFERENCES Set PreferredClientID = '" +clientid+ "', PreferredProductID = NULL,PreferredProjectID=NULL where userID = '" +userID+ "'";
            stmnt.execute(str);
            bool = true;
        }
        catch (Exception e) {}
        //System.out.println (str);
        return bool;
    }
    
    /* Function name: setPreferredIssueType
    Description: This function checks if the user has a preferred issueType. If yes, the preferred issueType is changed otherwise it is inserted
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the operation was successful*/
    public boolean setPreferredIssueType (String userID, String issueTypeId)
    {
        boolean bool = false;

        String str = "Insert into OAM_RM_USER_PREFERENCES Select '" +userID+ "', NULL, NULL,NULL, NULL, NULL,NULL FROM DUAL where not exists (select UserID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "')";
        
        try
        {
            Statement stmnt=myConn.createStatement();
            stmnt.execute(str);
            
            str =" Update OAM_RM_USER_PREFERENCES Set PreferredIssueTypeId = '" +issueTypeId+ "', PreferredProductID = NULL,PreferredProjectID=NULL where userID = '" +userID+ "'";
            stmnt.execute(str);
            bool = true;
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
        System.out.println (str);
        
        return bool;
    }

    /* Function name: setPreferredProduct
    Description: This function checks if the user has a preferred client. If yes, the preferred client is changed otherwise it is inserted
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the operation was successful */
    public boolean setPreferredProduct (String userID, String cid, String pid)
    {
        boolean bool = false;

        String str = "Insert into OAM_RM_USER_PREFERENCES Select '" +userID+ "', NULL, NULL, NULL, NULL, NULL FROM DUAL where not exists (select UserID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "')";        
        try
        {
            Statement stmnt=myConn.createStatement();
            stmnt.execute(str);
            str =" Update OAM_RM_USER_PREFERENCES Set PreferredClientID = '" +cid+ "',PreferredProductID = '" +pid+ "',PreferredProjectID=NULL where userID = '" +userID+ "'";
            stmnt.execute(str);
            bool = true;
        }
        catch (Exception e) {}
        //System.out.println (str);
        return bool;
    }
    
    /* Function name: setPreferredProduct
    Description: This function checks if the user has a preferred client. If yes, the preferred client is changed otherwise it is inserted
    Date: July 19, 2006
    Parameter: userid
    Output: boolean that indicates whether the operation was successful */
    public boolean setPreferredProject (String userID, String cid, String pid, String ProjectID)
    {
        boolean bool = false;

        String str = "Insert into OAM_RM_USER_PREFERENCES Select '" +userID+ "', NULL, NULL, NULL, NULL, NULL FROM DUAL where not exists (select UserID from OAM_RM_USER_PREFERENCES where UserID = '" +userID+ "')";
        
        try
        {
            Statement stmnt=myConn.createStatement();
            stmnt.execute(str);
            
            str =" Update OAM_RM_USER_PREFERENCES Set PreferredClientID = '" +cid+ "',PreferredProductID = '" +pid+ "',PreferredProjectID = '" +ProjectID+ "' where userID = '" +userID+ "'";
            stmnt.execute(str);
            bool = true;
        }
        catch (Exception e) {}
        //System.out.println (str);
        return bool;
    }
    
    public String getFormattedDate(Date dateToFormat) throws Exception
	{
		String dt = null;
		try{	
		
			DateFormat formatter ;    
            formatter = new SimpleDateFormat("MM/dd/yyyy");        
            dt = formatter.format(dateToFormat);
            //System.out.println("Today is " + s);
             //return s;
		} catch (Exception e)
		{
			System.out.println("Exception getFormattedDate:"+e);  
		} 
		
	  return dt;
	}
    
    public String getBeforeDate()
    {
    	Calendar cal = Calendar.getInstance();
  	    int yearstoDrecrment = -2;
  	    cal.add(Calendar.YEAR, yearstoDrecrment);
  	    Date date= cal.getTime();
  	    String beforeDate = null;
		try {
			beforeDate = getFormattedDate(date);
			System.out.println("vivek vivek test"+beforeDate);
		} catch (Exception e) {
			e.printStackTrace();
		}
  	    return beforeDate;
    }
}
