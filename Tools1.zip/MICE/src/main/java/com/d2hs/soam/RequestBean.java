package com.d2hs.soam;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.TreeMap;


public class RequestBean extends BaseBean{


   public RequestBean(){


   }
   
   public String getAllClientsQry(){
	   return "SELECT CLIENTID,CLIENTNAME FROM OAM_RM_CLIENTS ";
	    		  }
   
   public boolean getDomainInfo(String Domainname){

      boolean result = false;

      strSQL = "select a.DomainID, a.DomainName, a.DomainLevel, a.DatabaseName,a.DatabaseUserName, a.DataBasePassword as Password, a.DomainLogo, a.DomainEmail " +
              "from ztbl_Domain a where DomainName="+SQLEncode(Domainname);
       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.next();
                result=true;

        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
  }
  public boolean getUserInfo(String LoginName,String Password)
  {
     boolean result = false;

      strSQL = "select * from usr_Users where LoginName ="+SQLEncode(LoginName);
       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.next();
                result=true;

        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
  }
  //Changed By:Raju Thapa Shrestha,Mar 5,2008
  //Changes	  :add method to get user information for SSO intregation with OAM
  public boolean getUserInfoWithoutPwd(String LoginName)
  {
     boolean result = false;

      strSQL = "select * from usr_Users where LoginName ="+SQLEncode(LoginName);
       try
        {
               Statement stmt=myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                myRS=stmt.executeQuery(strSQL);
                myRS.next();
                result=true;

        }
        catch(Exception e){
            System.out.print("error"+e.getMessage());
        }
      return result;
  }
  public String getSuperDomainDatabase(){
        return "RequestManagerAdmin";
  }
  public String getSuperDomainDatabaseUserName(){
        return "sa";
  }
  public String getSuperDomainDatabasePassword(){
        return "d2hs";
  }

 


}
