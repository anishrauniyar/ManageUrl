package com.d2hs.soam.conn;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.servlet.http.HttpServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import java.util.*;
import java.io.*;
import java.sql.Connection;

/**
 * Created by IntelliJ IDEA.
 * User: rshah
 * Date: Dec 12, 2006
 * Time: 10:37:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class DBPoolInitializer extends HttpServlet {

    String XMLfilename = "";

     public void init(ServletConfig conf) {
		try {
			super.init(conf);
			ServletContext context = this.getServletContext();
			String xmlFileName = context.getInitParameter("XMLFileName");
			this.XMLfilename = context.getRealPath(xmlFileName);
			System.out.println("Configure file--->"+this.XMLfilename);
	
			DBPoolManager dbpm = DBPoolManager.getInstance();
			dbpm.setAlias(setDBConnection("RequestManager->SuperDomainDataBase"));
		} catch (Exception ex) {
			System.out
					.println("Error initializing Connection Pool DBPoolInitializer.java>>0<<"
							+ ex);
		}
	}

    public void destroy(){
        DBPoolManager dbpm = DBPoolManager.getInstance();
        try{
        dbpm.closeAllConnection();
        }catch(Exception ex){
            System.out.println("Error closing Connection Pool DBPoolInitializer.java>>1<<"+ex);
        }
    }


    	public Map setDBConnection(String alias){
            Map dbConnProp=new HashMap();
            try {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(new File(XMLfilename));

                Element svgElement	= doc.getDocumentElement();
                NodeList nodeList 	= svgElement.getElementsByTagName("Alias");
                String dbDriver = "";
                String dbUser = "";
                String dbPassword = "";
                String dbConnURL = "";
                String maxConn = "";
                String initSize = "";
                String idleTimeOut = "";
                String maxChkOutTime = "";
           
                ConnectionParameters conParam=new ConnectionParameters();
                for(int i=0;i<nodeList.getLength();i++){
                    Element textElement = (Element)nodeList.item(i);

                    if(textElement.getAttribute("name").equals(alias)){
                        dbDriver	= textElement.getAttribute("driver");                       
                        dbUser	= textElement.getAttribute("username");
                        dbPassword	= textElement.getAttribute("password");                        
                        maxConn = textElement.getAttribute("maxConn");
                        initSize = textElement.getAttribute("initSize");
                        idleTimeOut = textElement.getAttribute("idleTimeOut");
                        maxChkOutTime = textElement.getAttribute("maxCheckout");
                        dbConnURL	= textElement.getAttribute("url");
                        conParam.setDriver(dbDriver);
                        conParam.setUrl(dbConnURL);
                        conParam.setUserName(dbUser);
                        conParam.setPassword(dbPassword);
                        conParam.setMaxConnection(maxConn);
                        conParam.setInitialSize(initSize);
                        conParam.setIdleTimeOut(idleTimeOut);
                        conParam.setMaxCheckOutTime(maxChkOutTime);
                        dbConnProp.put(alias, conParam); //Putting the alias and ConnectionParameter Object
                    }                   
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return dbConnProp;
    }
   

}
