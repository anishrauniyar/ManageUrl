package com.d2hs.soam.rm.CMMI_Report;

public class StatusDTO {

	private String clientName;
	private int openRequest;
	private int completedRequest;
	private int closedRequest;
	private int totalRequest;
	
	private int openDefect;
	private int completedDefect;
	private int closedDefect;
	private int totalDefect;
	
	private int openIssue;
	private int completedIssue;
	private int closedIssue;
	private int totalIssue;
	private int total;
	

	public void setClientName(String s)
	{
		this.clientName=s;
	}
	public String getClientName()
	{
		return this.clientName;
	} 
	public void setOpenRequest(int s)
	{
		this.openRequest=s;
	}
	public int getOpenRequest()   
	{
		return this.openRequest;
	}
	public void setComplpetedRequest(int s)
	{
		this.completedRequest=s;
	}
	public int getCompletedRequest()
	{
		return this.completedRequest;
	}
	public void setClosedRequest(int s)
	{
		this.closedRequest=s;
	}
	public int getClosedRequest()
	{
		return this.closedRequest;
	}
	public void setTotalRequest(int s)
	{
		this.totalRequest=s;
	}
	public int getTotalRequest()
	{
		return this.totalRequest;
	}

	
	public void setOpenDefect(int s)
	{
		this.openDefect=s;
	}
	public int getOpenDefect()   
	{
		return this.openDefect;
	}
	public void setComplpetedDefect(int s)
	{
		this.completedDefect=s;
	}
	public int getCompletedDefect()
	{
		return this.completedDefect;
	}
	public void setClosedDefect(int s)
	{
		this.closedDefect=s;
	}
	public int getClosedDefect()
	{
		return this.closedDefect;
	}
	public void setTotalDefect(int s)
	{
		this.totalDefect=s;
	}
	public int getTotalDefect()
	{
		return this.totalDefect;
	}
	
	public void setOpenIssue(int s)
	{
		this.openIssue=s;
	}
	public int getOpenIssue()   
	{
		return this.openIssue;
	}
	public void setComplpetedIssue(int s)
	{
		this.completedIssue=s;
	}
	public int getCompletedIssue()
	{
		return this.completedIssue;
	}
	public void setClosedIssue(int s)
	{
		this.closedIssue=s;
	}
	public int getClosedIssue()
	{
		return this.closedIssue;
	}
	public void setTotalIssue(int s)
	{
		this.totalIssue=s;
	}
	public int getTotalIssue()
	{
		return this.totalIssue;
	}
	public void setTotal(int s)
	{
		this.total=s;
	}
	public int getTotal()
	{
		return this.total;
	}
	
	
	
}
