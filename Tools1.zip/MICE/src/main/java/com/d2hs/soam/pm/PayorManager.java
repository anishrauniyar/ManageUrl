package com.d2hs.soam.pm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.d2hs.soam.RequestBean;

public class PayorManager extends RequestBean {
	
	private String strFilters	= "";


	
	public void filterPayor(String fPayorId,String fPayorName,String fPayorCode)
    {
	    if(!fPayorId.equals(""))
	    {
			strFilters	+= " AND VHPAYORID LIKE '%" + fPayorId.replaceAll("'","''").trim() + "%'";
		}
	    if(!fPayorName.equals(""))
	    {
	        strFilters	+= " AND lower(VHPAYORNAME) LIKE lower('%" + fPayorName.replaceAll("'","''").trim() + "%')";
	    }
	    if(!fPayorCode.equals(""))
	    {
	        strFilters	+= " AND lower(SHORTNAME) LIKE lower('%" + fPayorCode.replaceAll("'","''").trim() + "%')";
	    }
	   
    }
	
	
	
	public boolean getPayor() {
		boolean result = false;
		strSQL = "select VHPAYORID, upper (VHPAYORNAME) as VHPAYORNAME , SHORTNAME from hr_global_vhpayors where 1=1 ";
		strSQL += strFilters;
		strSQL += " order by VHPAYORNAME";
		//System.out.println("Query >>>>>>>>>>>>>>>"+strSQL);
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/pm/PayorManager.java]->getPayor()<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	public String addPayor(String payorName, String payorCode, String userId){
		String isInserted = "false";
		strSQL = "Select count(*) n from hr_global_vhpayors where upper(VHPAYORNAME) like '" +payorName.toUpperCase()+ "' ";
        //System.out.println(strSQL);
        try
        {
          Statement stmnt=myConn.createStatement();
          ResultSet rs = stmnt.executeQuery(strSQL);
          rs.next();
          int count = Integer.parseInt(rs.getString("n".trim()));
          System.out.println ("Count is>>>>"+count);
          if (count > 0)
          {
              isInserted = "duplicate";
              return isInserted;
          }
          else if (count == 0)
          {
              strSQL="insert into hr_global_vhpayors "+
                      " (VHPAYORNAME,SHORTNAME,ADDEDDATE)"+
                      " VALUES (" + SQLEncode(payorName) + "," + SQLEncode(payorCode) + ",sysdate )" ;
              stmnt.execute(strSQL);
              isInserted="true";
          }
      }
      catch (Exception e) 
      {
    	  System.out.println("\nError:[default-war/com/d2hs/soam/pm/PayorManager.java]->addPayor("+payorName+")<- "+ strSQL);
		  e.printStackTrace();
      }
	  return isInserted;
	}
	
	public String updatePayor(String payorId,String payorName, String payorCode){
		String isUpdated = "false";
		strSQL = "Select count(*) n from hr_global_vhpayors where upper(VHPAYORNAME) like '" +payorName.toUpperCase()+ "' ";
		
		try
		{
			Statement stmnt=myConn.createStatement();
            ResultSet rs = stmnt.executeQuery(strSQL);
            rs.next();
            int count = Integer.parseInt(rs.getString("n".trim()));
            System.out.println ("Count is>>>>"+count);
            if (count > 0)
            {
            	isUpdated = "duplicate";
            	return isUpdated;
            }
            else if (count == 0)
            {
            	strSQL="update hr_global_vhpayors set "+
                        " VHPAYORNAME = " + SQLEncode(payorName) + ","+                         
                        " Where VHPAYORID="+SQLEncode(payorId);
            	stmnt.execute(strSQL);
            	isUpdated="true";
            }
	    }
	    catch (SQLException e) 
	    {
	      System.out.println("\nError:[default-war/com/d2hs/soam/pm/PayerManager.java]->updatePayer("+payorId+","+payorName+")<- "+ strSQL);
		  e.printStackTrace();
	    }
		return isUpdated;
	}
}
