/***************************************************************************************

Filename: NewReportBean.java

**************************************************************************************/

package com.d2hs.soam.rm;

import java.sql.Connection;

import com.d2hs.soam.ConnectionBean;

public class NewReportBean extends ConnectionBean
{

    String qry = "";
    public Connection conn;

    public boolean getDetails(String client_id,String product_id,String project_id,String requesttype_id)
    {
    	qry="select distinct cl.clientname,pr.productname,prj.projectname,rt.requesttypedesc from oam_rm_clients cl" +
    			" left join oam_rm_products pr on cl.clientid=pr.clientid" +
    			" left join oam_rm_projects prj on pr.productid=prj.productid" +
    			" ,oam_rm_request_types rt" +
    			" where 1=1 and rownum=1";
    	if(!client_id.equals(""))
			qry+=" and cl.Clientid='"+ client_id+"'";
		if(!product_id.equals(""))
    		qry+=" and pr.Productid='"+ product_id+"'";
    	if(!project_id.equals(""))
    		qry+=" and prj.Projectid='"+ project_id+"'";
    	if(!requesttype_id.equals(""))
    		qry+=" and rt.RequestTypeid='"+ requesttype_id+"'";
    	//System.out.println("Query-->"+qry);
    	return getList(qry,"");
    }
    public boolean getSeverityReport(String from_date,String to_date,String client_id,String product_id,String project_id,String requesttype_id)
    {
    	qry="SELECT   severitydesc, MAX(DECODE(STATUSDESC, 'Open', CT, 0)) Open,                                               \n"+
    	"         (MAX(DECODE(STATUSDESC, 'Closed or Completed', CT,0 ))+MAX(DECODE(STATUSDESC, 'Open', CT, 0))) Total     \n"+
    	"    FROM                                                                                                          \n"+
    	"                                                                                                                  \n"+
    	"(SELECT  severitydesc,  STATUSDESC,  SUM(CT) CT                                                                   \n"+
    	"FROM                                                                                                              \n"+
    	"(                                                                                                                 \n"+
    	"                                                                                                                  \n"+
    	"SELECT                                                                                                            \n"+
    	"         severitydesc,                                                                                            \n"+
    	"         case when  STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open'                            \n"+
    	"         else 'Closed or Completed' end  as STATUSDESC,                                                           \n"+
    	"         COUNT(* ) AS CT                                                                                          \n"+
    	"         FROM                                                                                                     \n"+
    	"         (                                                                                                        \n"+
    	"         SELECT DISTINCT st.statusdesc,se.severitydesc,a.requestcode                                              \n"+
    	"                                                                                                                  \n"+
    	"          FROM     (                                                                                              \n"+
    	"                                                                                                                  \n"+
    	"  SELECT RequestCode, max (lastUpdatedDate) m from OAM_RM_ARCHIVE                                                 \n"+
    	"  where 1=1 ";
    	if(!client_id.equals(""))
			qry+=" and Clientid='"+ client_id+"'";
		if(!product_id.equals(""))
			qry+=" and Productid='"+ product_id+"'";
		if(!project_id.equals(""))
			qry+=" and Projectid='"+ project_id+"'";
		if(!requesttype_id.equals(""))
			qry+=" and RequestTypeid='"+ requesttype_id+"'";
		qry+=" AND trunc(to_date(LASTUPDATEDDATE)) BETWEEN trunc(TO_DATE('"+ from_date+"','mm/dd/yyyy'))"+
     	" AND trunc(TO_DATE('"+ to_date+"','mm/dd/yyyy'))"+
     	" GROUP BY requestcode ORDER BY requestcode) a,\n"+
    	"  OAM_RM_REQUESTMANAGER rm,OAM_RM_ARCHIVE ar                                                                      \n"+
    	"  left join oam_rm_request_severity se ON ar.severityid=se.severityid                                             \n"+
    	"  left join oam_rm_requeststatus st ON ar.statusid=st.statusid                                                    \n"+
    	"  WHERE a.requestcode=ar.requestcode  AND a.m = ar.lastUpdatedDate                                                \n"+
    	"  AND a.requestcode=rm.requestcode             \n";
    	if(!client_id.equals(""))
			qry+=" and RM.Clientid='"+ client_id+"'";
		if(!product_id.equals(""))
			qry+=" and RM.Productid='"+ product_id+"'";
		if(!project_id.equals(""))
			qry+=" and RM.Projectid='"+ project_id+"'";
		if(!requesttype_id.equals(""))
			qry+=" and RM.RequestTypeid='"+ requesttype_id+"'";
    	qry+="  AND rm.statusid!=(SELECT statusid FROM oam_rm_requeststatus WHERE statusdesc='Dropped')                        \n"+
    	"AND To_Date(rm.RequestDate) BETWEEN TO_DATE('"+ from_date+"','mm/dd/yyyy') AND TO_DATE('"+ to_date+"','mm/dd/yyyy')\n"+
    	"  )                                                                                                               \n"+
    	" GROUP BY statusdesc, severitydesc                                                                                \n"+
    	" )                                                                                                                \n"+
    	" GROUP BY                                                                                                         \n"+
    	"  severitydesc,STATUSDESC                                                                                         \n"+
    	")                                                                                                                 \n"+
    	" GROUP BY                                                                                                         \n"+
    	"severitydesc                                                                                                      \n";

    	//System.out.println("Query-->"+qry);
    	return getList(qry,"");
    }
    
    public int getAllSeverity()
    {
    	int count=0;
    	try{
    		qry= "select count(*) as count from OAM_RM_REQUEST_SEVERITY";
    		stmt=myConn.createStatement();
    		myRS=stmt.executeQuery(qry);
    		myRS.next();
    		count=myRS.getInt("count");
    		qry = "select SeverityDesc from OAM_RM_REQUEST_SEVERITY";
    		//System.out.println("Query-->"+qry);
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
    	getList(qry,"");
        return count;
    	
    }
    
    public boolean getPhaseReport(String from_date,String to_date,String client_id,String product_id,String project_id,String requesttype_id)
    {
    	qry="SELECT   requestphasedesc, MAX(DECODE(STATUSDESC, 'Open', CT, 0)) Open,                                               \n"+
    	"         (MAX(DECODE(STATUSDESC, 'Closed or Completed', CT,0 ))+MAX(DECODE(STATUSDESC, 'Open', CT, 0))) Total     \n"+
    	"    FROM                                                                                                          \n"+
    	"                                                                                                                  \n"+
    	"(SELECT  requestphasedesc,  STATUSDESC,  SUM(CT) CT                                                                   \n"+
    	"FROM                                                                                                              \n"+
    	"(                                                                                                                 \n"+
    	"                                                                                                                  \n"+
    	"SELECT                                                                                                            \n"+
    	"         requestphasedesc,                                                                                            \n"+
    	"         case when  STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open'                            \n"+
    	"         else 'Closed or Completed' end  as STATUSDESC,                                                           \n"+
    	"         COUNT(* ) AS CT                                                                                          \n"+
    	"         FROM                                                                                                     \n"+
    	"         (                                                                                                        \n"+
    	"         SELECT DISTINCT st.statusdesc,ph.requestphasedesc,a.requestcode                                              \n"+
    	"                                                                                                                  \n"+
    	"          FROM     (                                                                                              \n"+
    	"                                                                                                                  \n"+
    	"  SELECT RequestCode, max (lastUpdatedDate) m from OAM_RM_ARCHIVE                                                 \n"+
    	"  where 1=1 ";
    	if(!client_id.equals(""))
			qry+=" and Clientid='"+ client_id+"'";
		if(!product_id.equals(""))
			qry+=" and Productid='"+ product_id+"'";
		if(!project_id.equals(""))
			qry+=" and Projectid='"+ project_id+"'";
		if(!requesttype_id.equals(""))
			qry+=" and RequestTypeid='"+ requesttype_id+"'";
		qry+=" AND trunc(to_date(LASTUPDATEDDATE)) BETWEEN trunc(TO_DATE('"+ from_date+"','mm/dd/yyyy'))"+
     	" AND trunc(TO_DATE('"+ to_date+"','mm/dd/yyyy'))"+ 
     	" GROUP BY requestcode ORDER BY requestcode) a,\n"+
    	"  OAM_RM_REQUESTMANAGER rm,OAM_RM_ARCHIVE ar                                                                      \n"+
    	"  left join oam_rm_request_phase ph ON ar.PhaseDetected=ph.RequestPhaseID                                             \n"+
    	"  left join oam_rm_requeststatus st ON ar.statusid=st.statusid                                                    \n"+
    	"  WHERE a.requestcode=ar.requestcode  AND a.m = ar.lastUpdatedDate                                                \n"+
    	"  AND a.requestcode=rm.requestcode             \n";
    	if(!client_id.equals(""))
			qry+=" and RM.Clientid='"+ client_id+"'";
		if(!product_id.equals(""))
			qry+=" and RM.Productid='"+ product_id+"'";
		if(!project_id.equals(""))
			qry+=" and RM.Projectid='"+ project_id+"'";
		if(!requesttype_id.equals(""))
			qry+=" and RM.RequestTypeid='"+ requesttype_id+"'";
    	qry+="  AND rm.statusid!=(SELECT statusid FROM oam_rm_requeststatus WHERE statusdesc='Dropped')                        \n"+
    	"AND To_Date(rm.RequestDate) BETWEEN TO_DATE('"+ from_date+"','mm/dd/yyyy') AND TO_DATE('"+ to_date+"','mm/dd/yyyy')\n"+
    	"  )                                                                                                               \n"+
    	" GROUP BY statusdesc, requestphasedesc                                                                                \n"+
    	" )                                                                                                                \n"+
    	" GROUP BY                                                                                                         \n"+
    	"  requestphasedesc,STATUSDESC                                                                                         \n"+
    	")                                                                                                                 \n"+
    	" GROUP BY                                                                                                         \n"+
    	"requestphasedesc                                                                                                      \n";

    	//System.out.println("Query-->"+qry);
    	return getList(qry,"");

    }
    
    public int getAllPhase()
    {
    	int count=0;
    	try{
    		qry= "select count(*) as count from OAM_RM_REQUEST_PHASE";
    		stmt=myConn.createStatement();
    		myRS=stmt.executeQuery(qry);
    		myRS.next();
    		count=myRS.getInt("count");
    		qry = "select RequestPhaseDesc from OAM_RM_REQUEST_PHASE";
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
    	getList(qry,"");
        return count;
    	
    }
    
    public boolean getDataReport(String from_date,String to_date,String client_id,String product_id,String project_id,String requesttype_id)
    {
    	qry="SELECT  CLIENTNAME,MAX(DECODE(REQUESTTYPEDESC, 'Request', Open, NULL)) RequestOpen,"+
                  " MAX(DECODE(REQUESTTYPEDESC, 'Request', Completed, NULL)) RequestCompleted,"+
                  " MAX(DECODE(REQUESTTYPEDESC, 'Defect', Open, NULL)) DefectOpen,"+
                  " MAX(DECODE(REQUESTTYPEDESC, 'Defect', Completed, NULL)) DefectCompleted,"+
                  " MAX(DECODE(REQUESTTYPEDESC, 'Issue', Open, NULL)) IssueOpen," +
                  " MAX(DECODE(REQUESTTYPEDESC, 'Issue', Completed, NULL)) IssueCompleted"+
                  " FROM("+
                  " SELECT   CLIENTNAME,Requesttypedesc, MAX(DECODE(STATUSDESC, 'Open', CT, NULL)) Open,"+
                  " MAX(DECODE(STATUSDESC, 'Completed', CT, NULL)) Completed"+
                  " FROM ("+
                  " SELECT  CLIENTNAME,  REQUESTTYPEDESC, STATUSDESC,  SUM(CT) CT"+
                  " FROM"+
                  " ("+
                  " SELECT"+
                  " clientname,"+
                  " REQUESTTYPEDESC,"+
                  " case when  STATUSDESC in ('Not Started','Assigned','In Progress') then 'Open'"+
                  " when STATUSDESC in ('Completed','QC Completed') then 'Completed'"+
                  " else 'Deferred,Dropped or Close' end  as STATUSDESC,"+
                  " COUNT(*) AS CT"+
                  " FROM     " +
                  " (SELECT DISTINCT st.statusdesc,se.clientname,rt.requesttypedesc,a.requestcode FROM     (" +
                  " SELECT   REQUESTCODE,"+
                  " MAX(LASTUPDATEDDATE) M"+
                  " FROM     OAM_RM_ARCHIVE"+
                  " WHERE    1 = 1";
    	if(!client_id.equals(""))
				qry+=" AND CLIENTID='"+ client_id+"'";
		if(!product_id.equals(""))
				qry+=" AND ProductID='"+ product_id+"'";
		if(!project_id.equals(""))
				qry+=" and PROJECTID='"+ project_id+"'";
		if(!requesttype_id.equals(""))
				qry+=" AND REQUESTTYPEID='"+ requesttype_id+"'";
		qry+=" AND trunc(to_date(LASTUPDATEDDATE)) BETWEEN trunc(TO_DATE('"+ from_date+"','mm/dd/yyyy'))"+
		         	" AND trunc(TO_DATE('"+ to_date+"','mm/dd/yyyy'))"+
		         	" GROUP BY REQUESTCODE) A,"+
		         	" OAM_RM_REQUESTMANAGER RM,OAM_RM_ARCHIVE ar"+
		         	" LEFT JOIN OAM_CLIENTS SE"+
		         	"           ON AR.DATAPROVIDERID = SE.CLIENTID"+
		         	" INNER JOIN OAM_RM_REQUEST_TYPES RT"+
		         	" on rt.REQUESTTYPEID=AR.REQUESTTYPEID"+
		         	" LEFT JOIN OAM_RM_REQUESTSTATUS ST"+
		         	"           ON AR.STATUSID = ST.STATUSID"+
		         	" WHERE    A.REQUESTCODE = AR.REQUESTCODE AND a.m = ar.lastUpdatedDate";
		if(!client_id.equals(""))
				qry+=" AND RM.CLIENTID='"+ client_id+"'";
		if(!product_id.equals(""))
				qry+=" AND RM.ProductID='"+ product_id+"'";
		if(!project_id.equals(""))
				qry+=" and RM.PROJECTID='"+ project_id+"'";
		if(!requesttype_id.equals(""))
				qry+=" AND RM.REQUESTTYPEID='"+ requesttype_id+"'";         	
		qry+=" AND A.REQUESTCODE = RM.REQUESTCODE AND rm.statusid!=(SELECT statusid FROM oam_rm_requeststatus WHERE statusdesc='Dropped')\n" +
		" AND To_Date(rm.RequestDate) BETWEEN TO_DATE('"+ from_date+"','mm/dd/yyyy') AND TO_DATE('"+ to_date+"','mm/dd/yyyy') )\n"+
				"GROUP BY"+
		         	" clientname,"+
		         	" REQUESTTYPEDESC,"+
		         	" STATUSDESC"+
		         	" order by CLIENTNAME,REQUESTTYPEDESC ,STATUSDESC"+
		         	" ) GROUP BY"+
		         	" CLIENTNAME,REQUESTTYPEDESC ,STATUSDESC"+
		         	" ORDER BY CLIENTNAME"+
		         	" )"+
		         	" GROUP BY CLIENTNAME,Requesttypedesc"+
		         	" ORDER BY CLIENTNAME,Requesttypedesc"+
		         	" )"+
		         	" GROUP BY CLIENTNAME"+
		         	" ORDER BY CLIENTNAME";
		//System.out.println("Query-->"+qry);
    	return getList(qry,"");
    }
    
    public String getReportContent(String from_date,String to_date,String client_id,String product_id,String project_id,String requesttype_id,String report_type)
    {
    	int[] opencount;
    	int[] completedcount;
    	int[] totalcount;
    	int totalcompleted=0;
    	int totaltotal=0;
    	String tbl_contents="";
        if(report_type.equals("Severity"))
        {
        	
        	String[] severities;
        	int i=0;
        	int count=getAllSeverity();
        	count++; // It also includes the requests with no severity so increment by 1
        	severities=new String[count];
        	opencount=new int[count];
        	totalcount=new int[count];

        	while(moveNext())
        	{
        		severities[i]=(String)(getData("SeverityDesc"));
        		i++;
        	}
        	severities[i]=""; // To set the no severity as blank
        	if (getSeverityReport(from_date,to_date,client_id,product_id,project_id,requesttype_id))
              {
        		int totalOpen=0;
        		int totalTotal=0;
        		tbl_contents += "\n<TABLE cellspacing = \"1\" cellpadding = \"5\"  border = \"1\">\n" +
						          	  "        <TR>\n" +
						          	  "        <TD class = \"DataCell\"><B> Severity\n" +
						          	  "        <TD class = \"DataCell\"><B> Open </TD>\n" +
						          	  "        <TD class = \"DataCell\"><B> Total </TD></TR>\n";
                  while(moveNext())
                  {
                	String Severity=getData("SeverityDesc");  
                  	String RequestOpen=getData("Open");
                  	String RequestTotal=getData("Total");
                  	for(int j=0;j<count;j++)
                	{
                		if(severities[j].trim().equals(Severity))
                		{
                			i=j;
                			break;
                		}
                	}
                  	opencount[i]+=Integer.parseInt(RequestOpen);
                  	totalcount[i]+=Integer.parseInt(RequestTotal);
                  }
                  for(int j=0;j<count;j++)
              		{	
              	  		if(severities[j].equals("")) severities[j]="Other";
              	  		{
		                	tbl_contents += "        <TR>\n" +
					  		"        <TD class = \"DataCell\"><B>"+severities[j]+" </TD>\n"+
				  	  		"        <TD class = \"DataCell\">"+opencount[j]+" </TD>\n" +
					  		"        <TD class = \"DataCell\">"+totalcount[j]+" </TD>\n";
		                	totalOpen+=opencount[j];
		                	totalTotal+=totalcount[j];
		               	}
              		}
                  	tbl_contents += "        <TR>\n" +
			  						"        <TD class = \"DataCell\"><B>Total </TD>\n"+
		  	  						"        <TD class = \"DataCell\"><B>"+totalOpen+" </TD>\n" +
			  						"        <TD class = \"DataCell\"><B>"+totalTotal+" </TD></TR>\n";
                  	tbl_contents+="\n</TABLE>";
              }

        }
        else if(report_type.equals("Phase"))
        {
        	String[] phases;
        	int i=0;
        	int count=getAllPhase();
        	count++; // It also includes the requests with no severity so increment by 1
        	opencount=new int[count];
        	completedcount=new int[count];
        	totalcount=new int[count];
        	phases=new String[count];

        	while(moveNext())
        	{
        		phases[i]=(String)(getData("RequestPhaseDesc"));
        		i++;
        	}
        	phases[i]=""; // To set the no severity as blank
        	if (getPhaseReport(from_date,to_date,client_id,product_id,project_id,requesttype_id))
              {
        		
        		int totalOpen=0;
        		int totalTotal=0;
        		tbl_contents += "\n<TABLE cellspacing = \"1\" cellpadding = \"5\"  border = \"1\">\n" +
						          	  "        <TR>\n" +
						          	  "        <TD class = \"DataCell\"><B> Severity\n" +
						          	  "        <TD class = \"DataCell\"><B> Open </TD>\n" +
						          	  "        <TD class = \"DataCell\"><B> Total </TD></TR>\n";
                  while(moveNext())
                  {
                	String Phase=getData("RequestPhaseDesc");  
                  	String RequestOpen=getData("Open");
                  	String RequestTotal=getData("Total");
                  	for(int j=0;j<count;j++)
                	{
                		if(phases[j].trim().equals(Phase))
                		{
                			i=j;
                			break;
                		}
                	}
                  	opencount[i]+=Integer.parseInt(RequestOpen);
                  	totalcount[i]+=Integer.parseInt(RequestTotal);
                  }
                  for(int j=0;j<count;j++)
              		{	
              	  		if(phases[j].equals("")) phases[j]="Other";
              	  		{
		                	tbl_contents += "        <TR>\n" +
					  		"        <TD class = \"DataCell\"><B>"+phases[j]+" </TD>\n"+
				  	  		"        <TD class = \"DataCell\">"+opencount[j]+" </TD>\n" +
					  		"        <TD class = \"DataCell\">"+totalcount[j]+" </TD>\n";
		                	totalOpen+=opencount[j];
		                	totalTotal+=totalcount[j];
		               	}
              		}
                  	tbl_contents += "        <TR>\n" +
			  						"        <TD class = \"DataCell\"><B>Total </TD>\n"+
		  	  						"        <TD class = \"DataCell\"><B>"+totalOpen+" </TD>\n" +
			  						"        <TD class = \"DataCell\"><B>"+totalTotal+" </TD></TR>\n";
                  	tbl_contents+="\n</TABLE>";
              }

        }
        else if(report_type.equals("Data Report"))
        {
        	if (getDataReport(from_date,to_date,client_id,product_id,project_id,requesttype_id))
            {
        		int totalRequestOpen=0;
        		int totalRequestCompleted=0;
        		int totalDefectOpen=0;
        		int totalDefectCompleted=0;
        		int totalIssueOpen=0;
        		int totalIssueCompleted=0;
        		tbl_contents += "\n<TABLE cellspacing = \"1\" cellpadding = \"5\"  border = \"1\">\n" +
          	  	"        <TR>\n" +
          	  	"        <TD class = \"DataCell\" rowspan=2><B> DataProvider\n" +
          	  	"        <TD class = \"DataCell\" colspan=2><B> Requests </TD>\n" +
          	  	"        <TD class = \"DataCell\" colspan=2><B> Defects </TD>\n" +
          	  	"        <TD class = \"DataCell\" colspan=2><B> Issues </TD>\n" +
          	  	"		 </TR>\n" +	
          	  	"        <TR>\n" +
          	  	"        <TD class = \"DataCell\"><B> Open </TD>\n" +
          	  	"        <TD class = \"DataCell\"><B> Completed </TD>\n" +
          	  	"        <TD class = \"DataCell\"><B> Open </TD>\n" +
          	  	"        <TD class = \"DataCell\"><B> Completed </TD>\n" +
          	  	"        <TD class = \"DataCell\"><B> Open </TD>\n" +
          	  	"        <TD class = \"DataCell\"><B> Completed </TD></TR>\n";
        		while(moveNext())
                {
        			String clientname=getData("ClientName").equals("")?"Other":getData("ClientName");       			
                	String RequestOpen=getData("RequestOpen").equals("")?"0":getData("RequestOpen");
                	String RequestCompleted=getData("RequestCompleted").equals("")?"0":getData("RequestCompleted");
                	String DefectOpen=getData("DefectOpen").equals("")?"0":getData("DefectOpen");
                	String DefectCompleted=getData("DefectCompleted").equals("")?"0":getData("DefectCompleted");
                	String IssueOpen=getData("IssueOpen").equals("")?"0":getData("IssueOpen");
                	String IssueCompleted=getData("IssueCompleted").equals("")?"0":getData("IssueCompleted");
                	tbl_contents += "        <TR>\n" +
				  		"        <TD class = \"DataCell\"><B>"+clientname+" </TD>\n"+
			  	  		"        <TD class = \"DataCell\">"+RequestOpen+" </TD>\n" +
				  		"        <TD class = \"DataCell\">"+RequestCompleted+" </TD>\n"+
				  		"        <TD class = \"DataCell\">"+DefectOpen+" </TD>\n"+
				  		"        <TD class = \"DataCell\">"+DefectCompleted+" </TD>\n"+
				  		"        <TD class = \"DataCell\">"+IssueOpen+" </TD>\n"+
				  		"        <TD class = \"DataCell\">"+IssueCompleted+" </TD>\n";
                	totalRequestOpen+=Integer.parseInt(RequestOpen);
            		totalRequestCompleted+=Integer.parseInt(RequestCompleted);
            		totalDefectOpen+=Integer.parseInt(DefectOpen);
            		totalDefectCompleted+=Integer.parseInt(DefectCompleted);
            		totalIssueOpen+=Integer.parseInt(IssueOpen);
            		totalIssueCompleted+=Integer.parseInt(IssueCompleted);
                }
        		tbl_contents += "        <TR>\n" +
		  		"        <TD class = \"DataCell\"><B>Total</TD>\n"+
	  	  		"        <TD class = \"DataCell\"><B>"+totalRequestOpen+" </TD>\n" +
		  		"        <TD class = \"DataCell\"><B>"+totalRequestCompleted+" </TD>\n"+
		  		"        <TD class = \"DataCell\"><B>"+totalDefectOpen+" </TD>\n"+
		  		"        <TD class = \"DataCell\"><B>"+totalDefectCompleted+" </TD>\n"+
		  		"        <TD class = \"DataCell\"><B>"+totalIssueOpen+" </TD>\n"+
		  		"        <TD class = \"DataCell\"><B>"+totalIssueCompleted+" </TD>\n";
        		tbl_contents+="\n</TABLE>";
            }
        }
        
    	return tbl_contents;
    }
    public void cleanup() throws Exception
	{
	}


}