package com.d2hs.soam.rm;

import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Vector;

import javax.mail.NoSuchProviderException;

import com.d2hs.soam.ConnectionBean;
import d2Systems.oam.SendMail;

import d2Systems.rm.EmailRequestAdder;

public class Schedular extends ConnectionBean implements Runnable{

	//test t1=new test();
	public Schedular()
	{
		try{
			 //this.setDBConnection("MDHawkeye->HawkeyeOAM");
			
             
		}
		catch (Exception e){
			e.printStackTrace();
		}
		finally{
			
		}
	}
	public void run(){
		
		try{
		while (true){
			checkStatus();
			//scanEmailsForRequests();
			Thread.sleep(5*60*1000);
		}
	}
		catch(Exception e){
			System.out.println("Exception: "+ e);
		}
		finally{
			
		}
	}
	
	public void checkStatus(){
		System.out.println("I am inside RM scheduler"); 
		String sql="Select jobID,to_char(nextrundate+rungapdays,'yyyy-mm-dd hh24:mi:ss') as nextrundate,case when nextrundate<sysdate then 1 " +
		//" when lastRundate is null then 1" +
		" else 0 " +
		" end as run from oam_rm_schedular_detail";
		ResultSet rs=null;
		try{
			this.connectDB();
			Statement stmt=myConn.createStatement();
			rs=stmt.executeQuery(sql);
			ArrayList list=new ArrayList();
			
			while(rs.next())
			{
				String jobID=rs.getString("jobID");
				String nextrunDate=rs.getString("nextrunDate");
				String run=rs.getString("run");
				HashMap map=new HashMap();
				map.put("jobID", jobID);
				map.put("nextrunDate", nextrunDate);
				map.put("run", run);
				list.add(map);
			}
			this.disconnectDB();
			System.out.println("list"+list.size());
			
			for(int i=0;i<list.size();i++)
			{
				HashMap map=new HashMap();
				map=(HashMap)list.get(i);
				String jobID=(String)map.get("jobID");
				String nextrunDate=(String)map.get("nextrunDate");
				String run=(String)map.get("run");
				if(run.equals("1"))
				{
					System.out.println("I have to be executed");
					if(enterNewRequest(jobID))
					{
						this.connectDB();
						sql="Update oam_rm_schedular_detail set lastRunDate=sysdate,nextrundate=to_date('"+nextrunDate+"','yyyy-mm-dd hh24:mi:ss') where jobID='"+jobID+"'";
						System.out.println("SQL-->"+sql);
						Statement stmt1=myConn.createStatement();
						stmt1.executeQuery(sql);
						this.disconnectDB();
					}
					
				}
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{

			try{
				 this.disconnectDB();
	             
			}
			catch (Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public boolean enterNewRequest(String jobID)
	{
		boolean isInserted=false;
                QueryBean qryBean= new QueryBean();
                queryBeanPM qryBean1=new queryBeanPM();
		try{
			this.connectDB();
			String sql="Select * from oam_rm_schedular where jobid='"+jobID+"'";
			System.out.println(sql);
			Statement st=myConn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				String RequestTypeID	= rs.getString("REQUESTTYPEID")==null?"1":rs.getString("REQUESTTYPEID"); 
			    String ProductID		= rs.getString("PRODUCTID")==null?"":rs.getString("PRODUCTID");
			    String ProjectID		= rs.getString("PROJECTID")==null?"":rs.getString("PROJECTID");
				String RequestingPerson	= rs.getString("REQUESTINGPERSON")==null?"":rs.getString("REQUESTINGPERSON");
				String Requests			= rs.getString("REQUESTS")==null?"":rs.getString("REQUESTS");
				String ClientID			= rs.getString("CLIENTID")==null?"":rs.getString("CLIENTID");
			    String ProductModule	= rs.getString("MODULEID")==null?"0":rs.getString("MODULEID");
				String DetectedVersion  = rs.getString("DETECTEDVERSION")==null?"0":rs.getString("DETECTEDVERSION");
				String RequestPriority	= rs.getString("REQUESTPRIORITY")==null?"0":rs.getString("REQUESTPRIORITY");
				String RequestPhaseInject= rs.getString("PHASEINJECT")==null?"0":rs.getString("PHASEINJECT");
				String RequestPhaseDetect= rs.getString("PHASEDETECTED")==null?"0":rs.getString("PHASEDETECTED");
				String ProductArea		= rs.getString("PRODUCTAREA")==null?"0":rs.getString("PRODUCTAREA");
				String AssignedTo       = rs.getString("ASSIGNEDTO")==null?"":rs.getString("ASSIGNEDTO");
				String SourceID			= rs.getString("SOURCEID")==null?"0":rs.getString("SOURCEID");
				String RequestTitle 	= rs.getString("REQUESTTITLE")==null?"":rs.getString("REQUESTTITLE");
				String EstimatedHours	= rs.getString("ESTIMATEDHOURS")==null?"0":rs.getString("ESTIMATEDHOURS");
				String RequestSeverity	= rs.getString("SEVERITYID")==null?"0":rs.getString("SEVERITYID");
				String DataProviderID   = rs.getString("DATAPROVIDERID")==null?"0":rs.getString("DATAPROVIDERID");
				String Status			= rs.getString("STATUSID")==null?"0":rs.getString("STATUSID");
				String RequestDate		="";
				String TargetCompDate 	="";
				String Impact			="";
				String LastUpdatedDate	="";
				String Benefits			="";
				String Assumptions_Dependencies ="";
				String FixedVersion="";
				
				String D2HawkeyeOAMName	= "ICE";
				String OAMDomainEmail="<oam@verscend.com>";
				String SMTPHostAddress	= "smtp.datacenter.d2hawkeye.net";
				
					
					qryBean.connectDB();
					String RequestCode=qryBean.insertProjectRequest(RequestingPerson,"","","","","","");
					qryBean.updateProjectRequestNew(RequestCode,ClientID,RequestDate,RequestingPerson,Requests,RequestTypeID,DetectedVersion,TargetCompDate,RequestPriority,ProductID,ProjectID,ProductModule,ProductArea,AssignedTo,RequestPhaseInject,RequestPhaseDetect,EstimatedHours,LastUpdatedDate,SourceID,RequestSeverity,Impact,DataProviderID,FixedVersion);
					Status="I";
					qryBean.insertProjectRequestDetail(RequestCode, SourceID, RequestTitle, Benefits, Assumptions_Dependencies, Status);
					
					
					qryBean1.connectDB();
					
					SendMail mail=new SendMail();
					String from		= D2HawkeyeOAMName + OAMDomainEmail;
					String msgSubject	= "New request #" + RequestCode +" : "+  RequestTitle;
					String mailMsg		= "New request <BR><br><B>Request #:" + RequestCode + "</B><BR>" +
				                          "<BR><hr>" +
											qryBean1.getFormattedRequestDetails(RequestCode,"") + " <BR>Thank you<BR>";
					
					boolean doSendMail	= true;
					int intMsgTriggeredFor=1;
					String PhaseOrRequest="r";
					String PhaseRequestType	= RequestTypeID;

					Vector toList=new Vector();

					qryBean1.setPullProductsAll(true);
					if(ProjectID.equals("")) //
					{
						qryBean1.setPullReceiversWithAll(false);
					}
					//ADD PRE ASSIGNED DEVELOPER
					if(!AssignedTo.equals("")){
						System.out.println(qryBean1.getEngineerName(AssignedTo)+"<"+qryBean1.getEngineerEmail(AssignedTo)+">");
						toList.addElement(qryBean1.getEngineerName(AssignedTo)+"<"+qryBean1.getEngineerEmail(AssignedTo)+">");
					}
					if(qryBean1.getListOfMSGReceivers(ClientID,ProjectID,intMsgTriggeredFor,PhaseOrRequest,ProductID,"t")){
				       
						while(qryBean1.moveNext()){
							System.out.println(qryBean1.getData("Username") + "<" + qryBean1.getData("Email") + ">");
							toList.addElement(qryBean1.getData("Username") + "<" + qryBean1.getData("Email") + ">");
						}
					}

					Vector ccList=new Vector();
					if(qryBean1.getListOfMSGReceivers(ClientID,ProjectID,intMsgTriggeredFor,PhaseOrRequest,ProductID,"c")){
						while(qryBean1.moveNext()){
							System.out.println(qryBean1.getData("Username") + "<" + qryBean1.getData("Email") + ">");
							ccList.addElement(qryBean1.getData("Username") + "<" + qryBean1.getData("Email") + ">");
						}
					}
					System.out.println("I am in sendmail");

					if(ClientID.equals("") || ProductID.equals("") || RequestCode.equals("")){
						mail.sendQC(from, toList, ccList, msgSubject, mailMsg);
					} else { 
						mail.send(from,toList,ccList,msgSubject,mailMsg,from);
					}	
					
					isInserted=true;
		            
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
                finally {
                try{
                    qryBean.disconnectDB();
                    qryBean1.disconnectDB();
                    this.disconnectDB();
                }catch(Exception ee){
                System.out.println("Error while closing connection in com.d2hs.soam.rm.Schedular.enterNewRequest \n it is "+ ee);
                }
                }
                
		return isInserted;
	}
	
	/**
	 * 
	 * scanEmailsForRequests
	 * Schedular
	 * <description>call the thread to add requests from email</description>
	 * @return void
	 * @author:Ramesh Raj Baral
	 * @since:Jun 15, 2010
	 *
	 */
	public static void scanEmailsForRequests(){
		EmailRequestAdder eRequestAdder;
		try {
			eRequestAdder = new EmailRequestAdder();
			eRequestAdder.scanAndInsertFromEmail();
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException while reading emails for requests:"+e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException while reading emails for requests:"+e.getMessage());
		} catch (SQLException e) {
			System.out.println("SQLException while reading emails for requests:"+e.getMessage());
		}
		catch(NoSuchProviderException e){
			System.out.println("NoSuchProviderException while reading emails for requests:"+e.getMessage());
		}
		catch(Exception e){
			System.out.println("Exception while reading emails for requests:"+e.getMessage());
		}
		
	}
	
	
}

