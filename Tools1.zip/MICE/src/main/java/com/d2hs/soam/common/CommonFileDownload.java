/* FileName: CommonFileDownload.java
 * Date 			Changed by 			Description
 * Jan 13 2014  		Binay Shakya		Downloaded files cannot be downloaded once they are deleted
 * 
 * */
package com.d2hs.soam.common;

import javax.servlet.*;

import javax.servlet.http.*;

import com.d2hs.soam.rm.QueryBean;


import java.io.*;
import java.net.URL;
import java.sql.*;

public class CommonFileDownload extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3510007502682711551L;
	private String CONTENT_TYPE = "application/octet-stream";
    
	String columnNameForDocName = "";
	String columnNameForDocId = "";
	String xtraSQL = "";
	String tableName = "";
	String baseFileLocationDB = "";
	String baseFileLocation = "";
	String prefixfileLocation = "";
	String fullfileName = "";
	String fileName = "";
	 
	
	/** Initialize global variables */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	/** Process the HTTP Get request */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		QueryBean db = new QueryBean();

		/**
		 * Must send these values for file download in rm requestcode is must,
		 * but in oam it is not necessary. The module must be in caps The
		 * documentid is must in all the cases, tablename could have been asked
		 * but it'll display the name so is hidden
		 */
		String module = request.getParameter("module").toString();
		String documentId = request.getParameter("docid").toString();
		String requestCode = request.getParameter("requestcode");
		String pmDocName = request.getParameter("docname");

		
		// System.out.println("File download 1");
		if ("RM".equals(module)) {
			System.out.println("Inside download file RM 1");
			if (requestCode == null) {
				System.out
						.print("File download cannot be done, all required parameters not passed, "
								+ " \n Request code is must for Request Manager to download file");
				return;
			}
			columnNameForDocName = "UploadedDocName";
			columnNameForDocId = "DocumentCode";
			xtraSQL = " and RequestCode='" + requestCode.replaceAll("'", "''")
					+ "' ";
			tableName = "OAM_RM_MOREDOCUMENTS1";
			baseFileLocationDB = "documentBaseFilePathRM";
		}

	
		try {
			System.out.println("Inside download file  2");
			HttpSession session = request.getSession(true);
			db.setSessionParameters(session);
			db.makeConnection();
			db.setConnection();
			System.out.println("Inside download file  3");
			Statement stmnt = db.conn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);

			String sqlString = "select parametervalue from config_fixedparameters where  parametername like '"
					+ baseFileLocationDB + "'";
			System.out.println("The sql string is " + sqlString);
			 System.out.println("File download 3.1");
			ResultSet rs1 = stmnt.executeQuery(sqlString);
			 System.out.println("File download 3.2");
			rs1.next(); 
			 System.out.println("File download 3.3");
			baseFileLocation = rs1.getString("parametervalue");
			 System.out.println("File download 3.4");
			rs1.close();
			System.out.println("File download 4");

			sqlString = "SELECT filepath," + columnNameForDocName
					+ " as docname FROM " + tableName + " WHERE "
					+ columnNameForDocId + "=" + documentId + "   "+ xtraSQL;
			 System.out.println("The sql string is " + sqlString);
			ResultSet rs = stmnt.executeQuery(sqlString);

			System.out.println("File download 5");
			if(rs.next()){
				prefixfileLocation = rs.getString("filepath");

				fileName = rs.getString("docname");
				fullfileName = baseFileLocation + "/" + prefixfileLocation + "/"
						+ fileName;

			}
			else{
				fullfileName = "";
			}
			
			System.out.println("The fullfileName string is " + fullfileName);
			db.takeDown();

			 System.out.println("File download 6");	
			

			 System.out.println("File name string is " + fileName);
			
			ServletOutputStream out = response.getOutputStream();
			if(getFileSep().equalsIgnoreCase("\\"))
				fullfileName="C:\\OAM"+getFileSep()+prefixfileLocation+getFileSep()+fileName;
			System.out.println("File download 7---->>>>"+fullfileName);
			File ff = new File(fullfileName);
			if ( !ff.exists() ) {
				//response.sendError(0,"File "+ ff.getName()+" not found");
				String output = "<HTML> "+
								"<HEAD> "+
								"<title>ICE:: Document missing</TITLE> "+
								"</HEAD> "+
								"<BODY> " +
								"<CENTER style='color:red;'> "+
									"Sorry, but the document you are trying to download "+
									"is missing. <BR>Please <a "+
									"href=\"mailto:_VITTechOps@verscend.com?subject=Document+download+missing\">contact</a> Admin"+
								"</CENTER> "+
							"</BODY> "+
						"</HTML>";
				out.println(output);
			    return ;
			}
			
			response.setContentType(CONTENT_TYPE);
			response.setHeader("Content-Disposition", "attachment; filename=\""
					+ fileName + "\"");
			int size=4096;
			
			try{
				int bytesRead, byteWritten=0;
				BufferedInputStream bis=new BufferedInputStream(new FileInputStream(ff));
				byte[] buf = new byte[size]; 
			    while ((bytesRead = bis.read(buf)) != -1) {
					out.write(buf, 0, bytesRead);
					byteWritten+=bytesRead;
					
			    	}
			   
				out.close();
				System.out.println("total bytes written is " +byteWritten);
			}
				catch(IOException e)
				{
					System.out.println("Unable to Open Stream");
					
				}
		
			} catch (Exception e) {
			response.getWriter().println(
					"An error has occured : ".concat(String.valueOf(String
							.valueOf(e.toString()))));
			System.out
					.println("\n Error while file download with documentid > "
							+ documentId
							+ " from com.d2hawkeye.common.CommonFileDownload.java "
							+ "\n and it is \n " + e);
			e.printStackTrace(response.getWriter());
		} finally {
			db.takeDown();
		}
	}
	public String getFileSep() {
		String fileSep="/";
	    String osType=System.getProperty("os.name").toLowerCase(); 
	    
	    if(osType!=null && osType.toLowerCase().contains("linux")){
	    	fileSep="/";
	    	
	    }
	    else if (osType!=null && osType.toLowerCase().contains("windows")){
	    	fileSep="\\";
	    	
	    }else 
	    {
	    	fileSep="/";
	    	
	    }
	   
	    return fileSep;
	    }

	/** Clean up resources */
	public void destroy() {
	}
	


}
