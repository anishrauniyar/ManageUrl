package com.d2hs.soam.conn;

import org.apache.commons.dbcp.BasicDataSource;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.d2hs.soam.conn.ConnectionParameters;

/**
 * Created by IntelliJ IDEA.
 * User: rshah
 * Date: Dec 12, 2006
 * Time: 10:17:14 AM
 *
 * It requires a hash map containing connection pool alias names as keys and
 * connection parameters as the corresponding values. It stores the connections in hash map
 * with keys as alias names. It the datasource having the alias name already present in the hash map
 * it simply return it, otherwise it creates new data source, adds to the hasmap and returns.
 * */

public final class DBPoolManager {

     private static final int MAX_TRY_COUNT = 5;
     private Map connectionProperties = null;
     /**
     * stores its own instance, Createde when the class is loaded by class loader.
     * */
    private static DBPoolManager dbpm = null;
    /*static{
       dbpm = new DBPoolManager();
    }*/
     /**
     * @return instance of ConnectionPoolManager
     */
    public static synchronized DBPoolManager getInstance() {
    	if (dbpm == null)
    		dbpm = new DBPoolManager();
    	return dbpm;
    }
    /***
     * store the CreatedDate data sources
     */
    private Map dataSources = new HashMap();

    /**
     *  This class cannot be instantiated
     */
    private DBPoolManager() {}


     /**
     * @param alias hashmap containing the Alias and connection parameters pairs
     */
    public void setAlias(Map alias) {
        this.connectionProperties = alias;
    }

    /**
     * Adding database info of alias in Connection Properties
     * @param alias
     * @param cp
     */
    public void addToConnectionProperties (String alias, ConnectionParameters cp)
    {
        System.out.println("Adding to connection properties");
        if (connectionProperties == null)
        {
            connectionProperties = new HashMap();
        }
        connectionProperties.put(alias, cp);
    }

    public Map getAlias(){
        return this.connectionProperties ;
    }

    @SuppressWarnings("deprecation")
	public Connection getConnection(String Alias) {
        String strAlias = Alias;
        Connection con = null;
        boolean isClosed = true;
        int tryCount = 0;

        /* checking if connection properties hashmap is set or not */
        if (this.connectionProperties == null) {
            System.out.println(
                    "Connection properties not set. It must be present to create the connection.");
            return null;
        }
        /* When strAlias is not found then we create new connection pool */
        if (!this.connectionProperties.containsKey(strAlias)) {
            System.out.println("No such alias key: " +
                    strAlias);

            // insert method here to add ConnectionParameters Object to connectionProperties map

        }
        /* checking if connection properties hashmap has the alias name as key or not */
        if (!this.connectionProperties.containsKey(strAlias)) {
            System.out.println("no such alias key: " +
                    strAlias);
            return null;
        }
        /* checking if datasource is already Created */
        if (this.dataSources.containsKey(strAlias)) {
             System.out.println("Pool Exists\n");
            BasicDataSource bds = (BasicDataSource)this.dataSources.get(strAlias);
            int maxTryCount = bds.getNumActive()+bds.getNumIdle()+5;
            try {
            		while( isClosed && tryCount < maxTryCount){
                    tryCount++;
                    con = bds.getConnection();
                    isClosed = con.isClosed();
                }
                con.setAutoCommit(true);
                if(isClosed)
                    System.out.println("\n******************************"
               +"\n******************************"
               +"\n******************************"
               + "\n Invalid Connection returned for "+strAlias+ " @ Try Count of "+tryCount+"\n"
               +"\n******************************"
               +"\n******************************"
               +"\n******************************");
            } catch  (Exception e){
                System.out.println("Error while getting connection :try count:" +tryCount+" DBPoolManager.java]->0<-"+e);
                return null;
            }
            return con;
        }
        /* datasource is not Created, so creating it */
         System.out.println("Pool DOES NOT Exists\n");
       ConnectionParameters cps = (ConnectionParameters)this.connectionProperties.get(strAlias);
        try {
            BasicDataSource bds = new BasicDataSource();
            bds.setDriverClassName(cps.getDriver());
            bds.setUrl(cps.getUrl());
            bds.setUsername(cps.getUserName());
            bds.setPassword(cps.getPassword());
            bds.setInitialSize(cps.getInitialSize());
            bds.setMaxActive(cps.getMaxConnection());
           
            if (cps.getMaxCheckOutTime() > -1) {
               bds.setMaxWait(cps.getMaxCheckOutTime()*1000);  // 1000* is for the millisecs (60 sec!)
            }

            bds.setTimeBetweenEvictionRunsMillis(5*60*1000); 
            if (cps.getIdleTimeOut() > -1) {
                 bds.setMinEvictableIdleTimeMillis(cps.getIdleTimeOut()*1000); // 1000* is for the millisecs (x sec!)
            }

            String strQry = cps.getValidationQuery();
            if(!strQry.equalsIgnoreCase("")){
                bds.setValidationQuery(strQry);               
            }
            bds.setRemoveAbandoned(true);
            bds.setRemoveAbandonedTimeout(25*1);//30 secs 
            dataSources.put(strAlias, bds);

            while (isClosed && tryCount < MAX_TRY_COUNT) {
                tryCount++;
                con = bds.getConnection();
                isClosed = con.isClosed();
            }
        } catch  (Exception e){
            System.out.println("count:" + tryCount+" DBPoolManager.java]->1<- " +
            		" \n Alias is "+strAlias+" " +
            		" \n and error is " +
            		" \n"+e);
            e.printStackTrace();
            con = null;
        }
        return con;
    }

    /**
     * remove the connection named aliasName from the pool
     * @param aliasName
     * @throws Exception
     */

       public void removeConnection(String aliasName) throws Exception {
        String strAlias = aliasName.toUpperCase();
        boolean isClosed = false;
        BasicDataSource ds = (BasicDataSource)this.dataSources.get(strAlias);
        if(ds!=null){
           ds.close();
            isClosed= true;
           System.out.println("Closing connections related to :"+aliasName+" from pool");
        }

        if(isClosed){
            if(this.dataSources.containsKey(strAlias)){
                this.dataSources.remove(strAlias);
                System.out.println("Removing :"+aliasName+" from connection pool");
            }

            if (this.connectionProperties.containsKey(strAlias)){
                this.connectionProperties.remove(strAlias);
                System.out.println("Removing :"+strAlias+" from connection properties");
            }
        }
    }

    /**
     * Checking if the connectionProperties Map already has entry for the domain. If yes, don't add to map otherwise add
     * Author: Anjana
     * Date: April 3, 2007
     * @param domainid
     * @return
     */
    public boolean hasAlias(String domainid)
    {
        if (connectionProperties == null)
            return false;
        else
            return (connectionProperties.containsKey(domainid));

    }

    /**
     * Close the connection in the pool before destroying the object (called from servlet)
     * @throws Exception
     */

    public void closeAllConnection() throws Exception{

        if (dataSources != null && dataSources.size() > 0) {

        Iterator itr = dataSources.keySet().iterator();
        while (itr.hasNext()) {
            String alias = itr.next().toString();
            BasicDataSource dbs = (BasicDataSource) dataSources.get(alias);
            try{
            dbs.close();
            System.out.println("*==>Closing Connection Pool : " + alias );
            } catch(Exception e){
            System.out.println("Exception>>>>"+e);
            }

        }
        }
        dbpm= null;

    }
}
