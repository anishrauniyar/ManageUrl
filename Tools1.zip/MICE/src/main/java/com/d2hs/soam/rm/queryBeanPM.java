package com.d2hs.soam.rm;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.d2hawkeye.util.Base64Encoder;
import com.d2hawkeye.util.CommonUtils;
import com.d2hawkeye.util.CommonUtils.RequestCode;
import com.d2hawkeye.util.Constants;
import com.d2hawkeye.util.velocity.MailMessageGenerator;
import com.d2hawkeye.util.velocity.MailMessageModel;
import com.d2hawkeye.util.velocity.MailMessagePOJO;
import com.d2hawkeye.util.velocity.RequestMailMessage;
import com.d2hawkeye.util.velocity.TestCase;
import com.d2hawkeye.util.velocity.VelocityUtils;
import com.d2hs.soam.ConnectionBean;
import com.d2hs.soam.common.TextEncoder;
import com.d2hs.soam.data.ProductionIntegrationCode;
import com.d2hs.soam.um.UserManager;
import com.verisk.ice.dao.ActivityUpdateDAO;
import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.DefectDAO;
import com.verisk.ice.dao.EstimateDAO;
import com.verisk.ice.dao.LayoutAnalysisDAO;
import com.verisk.ice.model.ActivityUpdateDTO;
import com.verisk.ice.model.DefectDTO;
import com.verisk.ice.model.EstimateDTO;
import com.verisk.ice.model.LayoutAnalysisDTO;
import com.verisk.ice.utils.AppConstants;

import d2Systems.oam.SendMail;
import d2Systems.rm.RequestTemplate;
import d2Systems.rm.User;
import d2Systems.rm.UserFilters;
import d2Systems.rm.UserPreference;
import d2Systems.rm.UserProject;
import d2Systems.rm.UserRequest;
import java.util.Calendar;

public class queryBeanPM extends ConnectionBean {

    public Connection conn;
    public String mainEnggName = "";
    public String mainEnggEmail = "";
    public String reqPersonName = "";
    public String reqPersonEmail = "";
    private String preAssignedTo = "";
    private String preActionTaken = "";
    private String preStatus = "";
    private String preThresholdDays = "";
    private String tempRemarks = "";
    private String request_tablename = "";
    String fileSep = System.getProperty(File.separator);
    final static Logger logger = Logger.getLogger(queryBeanPM.class);
    /**
     * to trace how many records exactly found in backend
     */
    private int maxRecordsFound = 0;

    private String filterForLitePage = "  req.clientid IN (SELECT clientid  FROM   tmp_oam_rm_user_client "
            + " WHERE  userid = 'useridVar')"
            + " AND req.productid IN (SELECT productid FROM   tmp_oam_rm_user_product "
            + " WHERE  userid = 'useridVar') "
            + " AND req.parentrequestcode IS NULL AND statusdesc"
            + " IN ( 'Open', 'Completed', 'Assigned','Not Started','QC Completed' ) ";
    private String filterForLessNumbers = " order by  requestdate desc";

    public queryBeanPM() {
    }

    public void setConnection() {
        conn = myConn;
    }

    private String requestCode = "";

    public void setRequestCode(String rc) {
        requestCode = rc;
    }

    public String getRequestCode() {
        return requestCode;
    }

    private String msgType = "";

    public void setMsgType(String s) {
        msgType = s;
    }

    private String getSQLSubQuery(String s) {
        if ((s.indexOf(">") == 0) || (s.indexOf("<") == 0)) {
            return (s);
        } else if (s.indexOf("-") > 0) {
            return (" BETWEEN " + s.substring(0, s.indexOf("-")) + " AND " + s
                    .substring(s.indexOf("-") + 1));
        } else {
            return ("=" + s);
        }
    }

    public void setSQLQuery(String aOrd, String sBy, String fRequestTypeDesc,
            String fRequestDate, String fRequestingPerson, String fStatusDesc,
            String fEngineerDesc, String fApplicationVersionDesc,
            String fTargetCompDate, String fActualCompDate, String SN,
            String fClientName, String viewCompletedList,
            String fExpectedCompDate, String fRequestPhase, String fRequests,
            String fActionTaken, String fRequestPriority, String fDevCompDate,
            String fDocType) {
        String sortOrder = aOrd;
        String sortBy = sBy;
        String statusXtraSQL = " NOT IN ('Closed','Dropped','Deferred')";
        // Deferred=Pending
        if (viewCompletedList.equals("c")) {
            statusXtraSQL = " ='Closed'";
        } else if (viewCompletedList.equals("d")) {
            statusXtraSQL = " ='Dropped'";
        } else if (viewCompletedList.equals("p")) {
            statusXtraSQL = " ='Deferred'";
        }
        if (viewCompletedList.equals("q")) {
            statusXtraSQL = "";
        } else {
            statusXtraSQL = " AND s.StatusDesc " + statusXtraSQL;
        }

        if (sortOrder == null || sortOrder.compareTo("d") != 0) {
            sortOrder = " ASC ";
        } else {
            sortOrder = " DESC ";
        }

        if (sortBy.compareTo("b") == 0) {
            sortBy = " p.RequestDate ";
        } else if (sortBy.compareTo("a") == 0) {
            sortBy = " r.RequestTypeDesc ";
        } else if (sortBy.compareTo("c") == 0) {
            sortBy = " rp.UserName ";
        } else if (sortBy.compareTo("d") == 0) {
            sortBy = " s.StatusDesc ";
        } else if (sortBy.compareTo("e") == 0) {
            sortBy = " e.UserName ";
        } else if (sortBy.compareTo("f") == 0) {
            sortBy = " v.VersionDesc ";
        } else if (sortBy.compareTo("g") == 0) {
            sortBy = " p.TargetCompDate ";
        } else if (sortBy.compareTo("h") == 0) {
            sortBy = " p.ActualCompDate ";
        } else if (sortBy.compareTo("i") == 0) {
            sortBy = " p.PKSource ";
        } else if (sortBy.compareTo("j") == 0) {
            sortBy = " c.ClientName ";
        } else if (sortBy.compareTo("j") == 0) {
            sortBy = " p.ExpectedCompDate ";
        } else if (sortBy.compareTo("x") == 0) {
            sortBy = " x.RequestPhaseDesc ";
        } else if (sortBy.compareTo("p") == 0) {
            sortBy = " p.Requests ";
        } else if (sortBy.compareTo("q") == 0) {
            sortBy = " p.ActionTaken ";
        } else if (sortBy.compareTo("r") == 0) {
            sortBy = " p.RequestPriority ";
        } else if (sortBy.compareTo("k") == 0) {
            sortBy = " p.DevCompDate ";
        } else {
            sortBy = " p.PKSource ";
        }

        String orderBy = " ORDER BY " + sortBy + sortOrder;

        String tableName = "OAM_RM_REQUESTMANAGER";
        String sqlp = "";
        String sqlp1 = "";
        if (!requestCode.equals("")) {
            tableName = "OAM_RM_ARCHIVE";
            sqlp = "p.UpdatedBy,convert(varchar,DatePart(mm,p.UpdatedDate)) + '/' + convert(varchar,DatePart(dd,p.UpdatedDate)) + '/' + convert(varchar,DatePart(yy,p.UpdatedDate)) as UpdatedDate,up.UserName as UpdatedPerson,";
            sqlp1 = " LEFT JOIN usr_Users up ON p.UpdatedBy=up.UserID ";
        }

        strSQL = "SELECT p.RequestCode,"
                + "nvl(technical.num,0) AS technicalCount, "
                + "nvl(technical.type,0) AS technicaltype, "
                + "nvl(requirement.num,0) AS requirementCount,  "
                + "nvl(requirement.type,0) AS requirementtype,"
                + "nvl(others.num,0) AS othersCount, "
                + "nvl(others.type,0) AS otherstype, "
                + "nvl(test.num,0) AS testCount, "
                + "nvl(test.type,0) AS testtype, "
                + "r.RequestTypeDesc,p.RequestDate,p.RequestingPerson,"
                + sqlp
                + ""
                + " rp.UserName as RequestingPersonDesc,rp.email as ReqPersonEmail,c.ClientName,p.Requests,"
                + " p.ActionTaken,s.StatusDesc, e.UserName AS User_Name,e.email as enggEmail,v.VersionDesc,"
                + " p.TargetCompDate,p.requesttitle,p.ActualCompDate,p.RequestPriority,"
                + " e.UserID AS EnggID,p.isCompleted, nvl(y.documentCount,0) AS documentCount,p.ExpectedCompDate,x.RequestPhaseDesc,p.DevCompDate "
                + " FROM "
                + tableName
                + " p"
                + ""
                + sqlp1
                + ""
                + " LEFT JOIN (SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS "
                + " UNION"
                + " SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) e ON p.assignedTo=e.UserID "
                + " LEFT JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + " LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID"
                + " LEFT JOIN OAM_RM_REQUEST_TYPES r ON p.RequestTypeID=r.RequestTypeID "
                + " LEFT JOIN (SELECT USERID, USERNAME,Email,OamStatus FROM USR_USERS "
                + " UNION"
                + " SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) rp ON p.RequestingPerson=rp.UserID "
                + " LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + " LEFT JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='Technical Specs' Group by requestcode, doctype) as technical(code,type,num) "
                + "ON p.RequestCode = technical.code "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='Requirement Specs' Group by requestcode, doctype) as requirement(code,type,num)"
                + "ON p.RequestCode = requirement.code "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='others' Group by requestcode, doctype) as others(code,type,num)"
                + "ON p.RequestCode = others.code "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='Test Specs' Group by requestcode, doctype) as test(code,type,num)"
                + "ON p.RequestCode = test.code "
                + " LEFT JOIN (SELECT RequestCode,COUNT(*) AS documentCount FROM OAM_RM_MOREDOCUMENTS1 GROUP BY RequestCode) y ON y.RequestCode=p.RequestCode "
                + " WHERE 1=1 ";

        // AND LTrim(RTrim(r.RequestTypeDesc))<>'' ";
        // This cannot be done because while tranferring from concept 2 request
        // this comes as null
        strCountSQL = "SELECT COUNT(*) as RecCount " + " FROM "
                + tableName
                + " p"
                + " LEFT JOIN usr_Users e ON p.assignedTo=e.UserID "
                + " LEFT JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + " LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID"
                + " LEFT JOIN OAM_RM_REQUEST_TYPES r ON p.RequestTypeID=r.RequestTypeID "
                + " LEFT JOIN usr_Users rp ON p.RequestingPerson=rp.UserID "
                + " LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='Technical Specs' Group by requestcode, doctype) as technical(code,type,num) "
                + "ON p.RequestCode = technical.code "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='Requirement Specs' Group by requestcode, doctype) as requirement(code,type,num)"
                + "ON p.RequestCode = requirement.code "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='others' Group by requestcode, doctype) as others(code,type,num)"
                + "ON p.RequestCode = others.code "
                + "LEFT JOIN (select requestcode, doctype , count(*) from OAM_RM_MOREDOCUMENTS1 "
                + "where   doctype='Test Specs' Group by requestcode, doctype) as test(code,type,num)"
                + "ON p.RequestCode = test.code "
                + " LEFT JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + " WHERE 1=1 ";// AND LTrim(RTrim(r.RequestTypeDesc))<>'' ";

        if (!requestCode.equals("")) {
            strSQL += " AND p.RequestCode='" + requestCode + "'";
            strCountSQL += " AND p.RequestCode='" + requestCode + "'";
        }

        if (!msgType.equals("")) {
            if (msgType.equalsIgnoreCase("o")) {
                strSQL += " AND (p.isCompleted =' ' or p.iscompleted is null or p.iscompleted='n' or p.iscompleted='r' or p.iscompleted='m') ";
                strCountSQL += " AND (p.isCompleted =' ' or p.iscompleted is null or p.iscompleted='n' or p.iscompleted='r' or p.iscompleted='m')";
            } else if (msgType.equalsIgnoreCase("y")) {
                strSQL += " AND (p.isCompleted ='y' or p.iscompleted='p') ";
                strCountSQL += " AND (p.isCompleted ='y' or p.iscompleted='p')";
            } else {
                strSQL += " AND p.isCompleted='" + msgType + "'";
                strCountSQL += " AND p.isCompleted='" + msgType + "'";
            }
        }

        strSQL += statusXtraSQL;
        strCountSQL += statusXtraSQL;
        if (fRequestTypeDesc.length() > 1) {
            strSQL += " AND r.RequestTypeDesc = '"
                    + fRequestTypeDesc.replaceAll("'", "''").trim() + "' ";
            strCountSQL += " AND r.RequestTypeDesc = '"
                    + fRequestTypeDesc.replaceAll("'", "''").trim() + "' ";
        }
        if (fRequestDate.length() > 1) {
            strSQL += " AND p.RequestDate " + getDateRange(fRequestDate);
            strCountSQL += " AND p.RequestDate " + getDateRange(fRequestDate);
        }
        if (fRequestingPerson.length() > 1) {
            strSQL += " AND rp.UserName LIKE '%"
                    + fRequestingPerson.replaceAll("'", "''").trim() + "%' ";
            strCountSQL += " AND rp.UserName LIKE '%"
                    + fRequestingPerson.replaceAll("'", "''").trim() + "%' ";
        }
        if (fStatusDesc.length() > 1) {
            strSQL += " AND s.StatusDesc LIKE '%"
                    + fStatusDesc.replaceAll("'", "''").trim() + "%' ";
            strCountSQL += " AND s.StatusDesc LIKE '%"
                    + fStatusDesc.replaceAll("'", "''").trim() + "%' ";
        }
        if (fEngineerDesc.length() > 1) {
            strSQL += " AND e.UserName LIKE '%"
                    + fEngineerDesc.replaceAll("'", "''").trim() + "%' ";
            strCountSQL += " AND e.UserName LIKE '%"
                    + fEngineerDesc.replaceAll("'", "''").trim() + "%' ";
        }
        if (fApplicationVersionDesc.length() > 1) {
            strSQL += " AND v.VersionDesc LIKE '%"
                    + fApplicationVersionDesc.replaceAll("'", "''").trim()
                    + "%' ";
            strCountSQL += " AND v.VersionDesc LIKE '%"
                    + fApplicationVersionDesc.replaceAll("'", "''").trim()
                    + "%' ";
        }
        if (fTargetCompDate.length() > 1) {
            strSQL += " AND p.TargetCompDate " + getDateRange(fTargetCompDate);
            strCountSQL += " AND p.TargetCompDate "
                    + getDateRange(fTargetCompDate);
        }

        if (fActualCompDate.length() > 1) {
            strSQL += " AND p.ActualCompDate " + getDateRange(fActualCompDate);
            strCountSQL += " AND p.ActualCompDate "
                    + getDateRange(fActualCompDate);
        }

        if (fClientName.length() > 1) {
            strSQL += "  AND c.ClientName LIKE '%"
                    + fClientName.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND c.ClientName LIKE '%"
                    + fClientName.replaceAll("'", "''").trim() + "%'";
        }

        if (fExpectedCompDate.length() > 1) {
            strSQL += " AND p.ExpectedCompDate "
                    + getDateRange(fExpectedCompDate);
            strCountSQL += " AND p.ExpectedCompDate "
                    + getDateRange(fExpectedCompDate);
        }

        if (SN.length() > 1) {
            strSQL += " AND p.RequestCode  " + getSQLSubQuery(SN.trim());
            strCountSQL += " AND p.RequestCode" + getSQLSubQuery(SN.trim());
        }
        if (fRequestPhase.length() > 1) {
            strSQL += " AND x.RequestPhaseDesc LIKE '%"
                    + fRequestPhase.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND x.RequestPhaseDesc LIKE '%"
                    + fRequestPhase.replaceAll("'", "''").trim() + "%'";
        }
        if (fRequests.length() > 1) {
            strSQL += " AND p.Requests LIKE '%"
                    + fRequests.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND p.Requests LIKE '%"
                    + fRequests.replaceAll("'", "''").trim() + "%'";
        }

        if (fActionTaken.length() > 1) {
            strSQL += " AND p.ActionTaken LIKE '%"
                    + fActionTaken.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND p.ActionTaken LIKE '%"
                    + fActionTaken.replaceAll("'", "''").trim() + "%'";
        }
        if (fDevCompDate.length() > 1) {
            strSQL += " AND p.DevCompDate " + getDateRange(fDevCompDate);
            strCountSQL += " AND p.DevCompDate " + getDateRange(fDevCompDate);

        }

        if (fRequestPriority.length() >= 1) {
            strSQL += " AND p.RequestPriority = '"
                    + fRequestPriority.replaceAll("'", "''").trim() + "'";
            strCountSQL += " AND p.RequestPriority = '"
                    + fRequestPriority.replaceAll("'", "''").trim() + "'";
        }

        if (fDocType.length() >= 1) {

            strSQL += " AND (technical.type like '%" + fDocType + "%'"
                    + " or requirement.type like '%" + fDocType + "%'"
                    + " or test.type like '%" + fDocType + "%'"
                    + " or others.type like '%" + fDocType + "%'" + ")";
            strCountSQL += " AND (technical.type like '%" + fDocType + "%'"
                    + " or requirement.type like '%" + fDocType + "%'"
                    + " or test.type like '%" + fDocType + "%'"
                    + " or others.type like '%" + fDocType + "%'" + ")";
        }
        // Skip the follow up requests
        strSQL += " AND p.parentRequestCode IS NULL";
        strCountSQL += " AND p.parentRequestCode IS NULL";

        strSQL += orderBy;
    }

    public void setSQLQuery_Detail(String aOrd, String sBy,
            String fRequestTypeDesc, String fRequestDate,
            String fRequestingPerson, String fStatusDesc, String fEngineerDesc,
            String fApplicationVersionDesc, String fTargetCompDate,
            String fActualCompDate, String SN, String fClientName,
            String viewCompletedList, String fExpectedCompDate,
            String fRequestPhase, String fRequests, String fActionTaken,
            String fRequestPriority, String fDevCompDate, String fRequestTitle) {
        String sortOrder = aOrd;
        String sortBy = sBy;
        String statusXtraSQL = " NOT IN ('Closed','Dropped','Deferred')";
        // Deferred= Pending
        if (viewCompletedList.equals("c")) {
            statusXtraSQL = " ='Closed'";
        } else if (viewCompletedList.equals("d")) {
            statusXtraSQL = " ='Dropped'";
        } else if (viewCompletedList.equals("p")) {
            statusXtraSQL = " ='Deferred'";
        }
        if (viewCompletedList.equals("q")) {
            statusXtraSQL = "";
        } else {
            statusXtraSQL = " AND s.StatusDesc " + statusXtraSQL;
        }

        if (sortOrder == null || sortOrder.compareTo("d") != 0) {
            sortOrder = " ASC ";
        } else {
            sortOrder = " DESC ";
        }

        if (sortBy.compareTo("b") == 0) {
            sortBy = " p.RequestDate ";
        } else if (sortBy.compareTo("a") == 0) {
            sortBy = " r.RequestTypeDesc ";
        } else if (sortBy.compareTo("c") == 0) {
            sortBy = " rp.UserName ";
        } else if (sortBy.compareTo("d") == 0) {
            sortBy = " s.StatusDesc ";
        } else if (sortBy.compareTo("e") == 0) {
            sortBy = " e.UserName ";
        } else if (sortBy.compareTo("f") == 0) {
            sortBy = " v.VersionDesc ";
        } else if (sortBy.compareTo("g") == 0) {
            sortBy = " p.TargetCompDate ";
        } else if (sortBy.compareTo("h") == 0) {
            sortBy = " p.ActualCompDate ";
        } else if (sortBy.compareTo("i") == 0) {
            sortBy = " p.PKSource ";
        } else if (sortBy.compareTo("j") == 0) {
            sortBy = " c.ClientName ";
        } else if (sortBy.compareTo("j") == 0) {
            sortBy = " p.ExpectedCompDate ";
        } else if (sortBy.compareTo("x") == 0) {
            sortBy = " x.RequestPhaseDesc ";
        } else if (sortBy.compareTo("p") == 0) {
            sortBy = " p.Requests ";
        } else if (sortBy.compareTo("q") == 0) {
            sortBy = " p.ActionTaken ";
        } else if (sortBy.compareTo("r") == 0) {
            sortBy = " p.RequestPriority ";
        } else if (sortBy.compareTo("k") == 0) {
            sortBy = " p.DevCompDate ";
        } else if (sortBy.compareTo("y") == 0) {
            sortBy = " p.RequestTitle ";
        } else {
            sortBy = " p.PKSource ";
        }

        String orderBy = " ORDER BY " + sortBy + sortOrder;

        String tableName = "OAM_RM_REQUESTMANAGER";
        String sqlp = "";
        String sqlp1 = "";
        if (!requestCode.equals("")) {
            tableName = "OAM_RM_ARCHIVE";
            sqlp = "p.UpdatedBy,convert(varchar,DatePart(mm,p.UpdatedDate)) + '/' + convert(varchar,DatePart(dd,p.UpdatedDate)) + '/' + convert(varchar,DatePart(yy,p.UpdatedDate)) as UpdatedDate,up.UserName as UpdatedPerson,";
            sqlp1 = " LEFT JOIN (SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS UNION SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) up ON p.UpdatedBy=up.UserID ";
        }

        strSQL = "SELECT p.RequestCode,r.RequestTypeDesc,p.RequestDate,p.RequestingPerson,"
                + sqlp
                + ""
                + " rp.UserName as RequestingPersonDesc,rp.email as ReqPersonEmail,c.ClientName,p.Requests,"
                + " p.ActionTaken,p.requesttitle,s.StatusDesc, e.UserName AS User_Name,e.email as enggEmail,v.VersionDesc,"
                + " p.TargetCompDate,p.ActualCompDate,p.RequestPriority,"
                + " e.UserID AS EnggID,p.isCompleted, nvl(y.documentCount,0) AS documentCount,p.ExpectedCompDate,x.RequestPhaseDesc,p.DevCompDate "
                + " FROM "
                + tableName
                + " p"
                + ""
                + sqlp1
                + ""
                + " LEFT JOIN (SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS UNION SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) e ON p.assignedTo=e.UserID "
                + " LEFT JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + " LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID"
                + " LEFT JOIN (SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS UNION SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) rp ON p.RequestingPerson=rp.UserID "
                + " LEFT JOIN usr_Users rp ON p.RequestingPerson=rp.UserID "
                + " LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + " LEFT JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + " LEFT JOIN (SELECT RequestCode,COUNT(*) AS documentCount FROM OAM_RM_MOREDOCUMENTS1 GROUP BY RequestCode) y ON y.RequestCode=p.RequestCode "
                + " WHERE 1=1 ";

        // AND LTrim(RTrim(r.RequestTypeDesc))<>'' ";
        // This cannot be done because while tranferring from concept 2 request
        // this comes as null
        strCountSQL = "SELECT COUNT(*) as RecCount "
                + " FROM "
                + tableName
                + " p"
                + " LEFT JOIN usr_Users e ON p.assignedTo=e.UserID "
                + " LEFT JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + " LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID"
                + " LEFT JOIN OAM_RM_REQUEST_TYPES r ON p.RequestTypeID=r.RequestTypeID "
                + " LEFT JOIN usr_Users rp ON p.RequestingPerson=rp.UserID "
                + " LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + " LEFT JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + " WHERE 1=1 ";// AND LTrim(RTrim(r.RequestTypeDesc))<>'' ";

        if (!requestCode.equals("")) {
            strSQL += " AND p.RequestCode='" + requestCode + "'";
            strCountSQL += " AND p.RequestCode='" + requestCode + "'";
        }

        if (!msgType.equals("")) {
            if (msgType.equalsIgnoreCase("o")) {
                strSQL += " AND (p.isCompleted =' ' or p.iscompleted is null or p.iscompleted='n' or p.iscompleted='r' or p.iscompleted='m') ";
                strCountSQL += " AND (p.isCompleted =' ' or p.iscompleted is null or p.iscompleted='n' or p.iscompleted='r' or p.iscompleted='m')";
            } else if (msgType.equalsIgnoreCase("y")) {
                strSQL += " AND (p.isCompleted ='y' or p.iscompleted='p') ";
                strCountSQL += " AND (p.isCompleted ='y' or p.iscompleted='p')";
            } else {
                strSQL += " AND p.isCompleted='" + msgType + "'";
                strCountSQL += " AND p.isCompleted='" + msgType + "'";
            }
        }

        strSQL += statusXtraSQL;
        strCountSQL += statusXtraSQL;
        if (fRequestTypeDesc.length() > 1) {
            strSQL += " AND r.RequestTypeDesc = '"
                    + fRequestTypeDesc.replaceAll("'", "''").trim() + "' ";
            strCountSQL += " AND r.RequestTypeDesc = '"
                    + fRequestTypeDesc.replaceAll("'", "''").trim() + "' ";
        }
        if (fRequestDate.length() > 1) {
            strSQL += " AND p.RequestDate " + getDateRange(fRequestDate);
            strCountSQL += " AND p.RequestDate " + getDateRange(fRequestDate);
        }
        if (fRequestingPerson.length() > 1) {
            strSQL += " AND rp.UserName LIKE '%"
                    + fRequestingPerson.replaceAll("'", "''").trim() + "%' ";
            strCountSQL += " AND rp.UserName LIKE '%"
                    + fRequestingPerson.replaceAll("'", "''").trim() + "%' ";
        }
        if (fStatusDesc.length() > 1) {
            strSQL += " AND s.StatusDesc LIKE '%"
                    + fStatusDesc.replaceAll("'", "''").trim() + "%' ";
            strCountSQL += " AND s.StatusDesc LIKE '%"
                    + fStatusDesc.replaceAll("'", "''").trim() + "%' ";
        }
        if (fEngineerDesc.length() > 1) {
            strSQL += " AND e.UserName LIKE '%"
                    + fEngineerDesc.replaceAll("'", "''").trim() + "%' ";
            strCountSQL += " AND e.UserName LIKE '%"
                    + fEngineerDesc.replaceAll("'", "''").trim() + "%' ";
        }
        if (fApplicationVersionDesc.length() > 1) {
            strSQL += " AND v.VersionDesc LIKE '%"
                    + fApplicationVersionDesc.replaceAll("'", "''").trim()
                    + "%' ";
            strCountSQL += " AND v.VersionDesc LIKE '%"
                    + fApplicationVersionDesc.replaceAll("'", "''").trim()
                    + "%' ";
        }
        if (fTargetCompDate.length() > 1) {
            strSQL += " AND p.TargetCompDate " + getDateRange(fTargetCompDate);
            strCountSQL += " AND p.TargetCompDate "
                    + getDateRange(fTargetCompDate);
        }

        if (fActualCompDate.length() > 1) {
            strSQL += " AND p.ActualCompDate " + getDateRange(fActualCompDate);
            strCountSQL += " AND p.ActualCompDate "
                    + getDateRange(fActualCompDate);
        }

        if (fClientName.length() > 1) {
            strSQL += "  AND c.ClientName LIKE '%"
                    + fClientName.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND c.ClientName LIKE '%"
                    + fClientName.replaceAll("'", "''").trim() + "%'";
        }

        if (fExpectedCompDate.length() > 1) {
            strSQL += " AND p.ExpectedCompDate "
                    + getDateRange(fExpectedCompDate);
            strCountSQL += " AND p.ExpectedCompDate "
                    + getDateRange(fExpectedCompDate);
        }

        if (SN.length() > 1) {
            strSQL += " AND p.RequestCode  " + getSQLSubQuery(SN.trim());
            strCountSQL += " AND p.RequestCode" + getSQLSubQuery(SN.trim());
        }
        if (fRequestPhase.length() > 1) {
            strSQL += " AND x.RequestPhaseDesc LIKE '%"
                    + fRequestPhase.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND x.RequestPhaseDesc LIKE '%"
                    + fRequestPhase.replaceAll("'", "''").trim() + "%'";
        }
        if (fRequests.length() > 1) {
            strSQL += " AND p.Requests LIKE '%"
                    + fRequests.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND p.Requests LIKE '%"
                    + fRequests.replaceAll("'", "''").trim() + "%'";
        }

        if (fActionTaken.length() > 1) {
            strSQL += " AND p.ActionTaken LIKE '%"
                    + fActionTaken.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND p.ActionTaken LIKE '%"
                    + fActionTaken.replaceAll("'", "''").trim() + "%'";
        }
        if (fDevCompDate.length() > 1) {
            strSQL += " AND p.DevCompDate " + getDateRange(fDevCompDate);
            strCountSQL += " AND p.DevCompDate " + getDateRange(fDevCompDate);
        }

        if (fRequestTitle.length() > 1) {
            strSQL += " AND p.RequestTitle LIKE '%"
                    + fRequestTitle.replaceAll("'", "''").trim() + "%'";
            strCountSQL += " AND p.RequestTitle LIKE '%"
                    + fRequestTitle.replaceAll("'", "''").trim() + "%'";
        }

        if ((fRequestPriority).toLowerCase().compareTo("low") == 0) {
            fRequestPriority = "1";
        } else if ((fRequestPriority).toLowerCase().compareTo("medium") == 0) {
            fRequestPriority = "2";
        } else if ((fRequestPriority).toLowerCase().compareTo("high") == 0) {
            fRequestPriority = "3";
        } else if ((fRequestPriority).toLowerCase().compareTo("urgent") == 0) {
            fRequestPriority = "4";
        }

        if (fRequestPriority.length() >= 1) {
            strSQL += " AND p.RequestPriority = '"
                    + fRequestPriority.replaceAll("'", "''").trim() + "'";
            strCountSQL += " AND p.RequestPriority = '"
                    + fRequestPriority.replaceAll("'", "''").trim() + "'";
        }

        // Skip the follow up requests
        strSQL += " AND p.parentRequestCode IS NULL";
        strCountSQL += " AND p.parentRequestCode IS NULL";

        strSQL += "AND rp.UserName IS NOT null";
        strSQL += orderBy;
    }

    public boolean getListOfLogOfChanges() {
        boolean flag = false;
        try {
            closeRecordSet();
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            // Statement stmt=myConn.createStatement();
            String sqlString = getSQLQuery();
            logRS = stmt.executeQuery(sqlString);
            flag = true;
        } catch (SQLException sqlexception) {
            errorStr = "Log listing Error : " + sqlexception;
        }
        return flag;
    }

    public boolean getListOfModifiers() {
        return getList(
                "select s.UserID as ID, s.UserName from usr_Users s, tbl_UserTypes t WHERE s.OAMUserTypeCode = t.UserTypeCode AND t.UserTypeDesc IN ('E&D','E&D [Admin]','ITEG','BI','BI [Admin]')  ORDER BY s.UserName",
                "Engineers");
    }

    // This method specifies whether there are entries in the usr_Users
    public boolean getListOfStaffs() {
        return getList(
                "SELECT DISTINCT UserID, UserName FROM usr_Users ORDER BY UserName ",
                "Staffs");
    }

    /*
     * Author:Richan Shrestha, Oct. 30 2007
     * 
     * @param:ProductID
     * 
     * @Description:Get the List of Users related to the Product
     * 
     * @Return:Success/Failure of QueryStatement
     */
    public boolean getProductUsers(String ProductID) {
        strSQL = "SELECT UserName,loginname, UserID FROM usr_Users WHERE "
                + " (UserID IN (SELECT UserID FROM TMP_OAM_RM_USER_PRODUCT "
                + " WHERE (ProductID = '" + ProductID
                + "')and oamusertypecode is not null)) ORDER BY UserName";
        return getList(strSQL, "ProductUsers");
    }

    /*
     * Author:Dinesh Bajracharya, Nov 16 2009
     * 
     * @Description:Get the List of All Users
     * 
     * @Return:Success/Failure of QueryStatement
     */
    /**
     * @author: Ram Gautam, Sept 12 ,2012 Description: adding the Email Group
     * with users on Acknowledgement
     */
    public boolean getAllUsers() {
        strSQL = "SELECT UserName, loginname,UserID FROM usr_users where oamstatus=1"
                + " ORDER BY UserName";

        return getList(strSQL, "AllUsers");
    }

    public boolean getAllUsers(String Type) {
        strSQL = "SELECT * FROM TABLE(FN_get_userInfo('" + Type + "')) ORDER BY 1";

        return getList(strSQL, "AllUsersType");
    }

    public boolean getAllPrioritizedUsers(String Type) {
        strSQL = "SELECT a.USERID,b.USERNAME FROM OAM_CR_PRIORITIZED_USERS a, USR_USERS b WHERE  a.USERID = b.USERID AND a.ISSUETYPEID ='" + Type + "' ORDER  BY a.USERID";

        return getList(strSQL, "AllPrioritizesUsersType");
    }

    public boolean getPhasesForIssueType(String issueTypeId) {
        strSQL = "" + "SELECT a.phaseid,a.phasename FROM oam_cr_phases a "
                + "left join oam_cr_template_phases b "
                + "ON b.phaseid=a.phaseid "
                + "left join oam_cr_template_issuetype c "
                + "ON c.templateid = b.templateid ";
        // + "WHERE c.issuetypeid = 1 ORDER BY b.phaseorder";
        if (issueTypeId.length() > 0) {
            strSQL += " WHERE c.issuetypeid = " + issueTypeId
                    + " ORDER BY b.phaseorder";
        }
        // System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);
        return getList(strSQL, "Phases for IssueType");
    }

    public boolean getProjectForIssueType(String issueTypeId) {
        if (issueTypeId.length() == 0) {
            issueTypeId = "1";
        }
        strSQL = " select a.projectid,a.projectname FROM  OAM_CR_PROJECTS a, "
                + " oam_cr_proj_temp_issuetype b,"
                + " oam_cr_proj_temp_rel c "
                + " WHERE a.projectid=c.projectid "
                + " AND c.templateid =b.templateid "
                + " AND b.issuetypeid='" + issueTypeId + "'	ORDER BY projectid ";

        // System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);
        return getList(strSQL, "Projects for IssueType");
    }

    public boolean getComponentForApplication(String applicationID) {
        if (applicationID.length() == 0) {
            applicationID = "1";
        }
        strSQL = "SELECT * FROM   oam_cr_defectcomponent where IS_DELETED='N' and defappid= '" + applicationID + "'	ORDER BY DEFCOMPONENTNAME  ";

        // System.out.println("Query >>>>>>>>>>>>>>>>>>"+strSQL);
        return getList(strSQL, "Component for Application");
    }

    public boolean getClientApplications(String clientId) {
        strSQL = "select applicationid, applicationname from oam_clientapps "
                + "WHERE 1=1 and inProduction='Y'  ";
        if (clientId.length() > 0) {
            strSQL += " and  clientid = " + clientId + "";
        }
        System.out.println("Query >>>>>>>>>>>>>>>>>>" + strSQL);
        return getList(strSQL, "Application for Client");
    }

    public boolean getApplicationsReleaseTag(String clientId) {
        strSQL = "Select releasetagidbyapp from cp_releasetagbyapp "
                + "WHERE 1=1  and status = 'CURRENT' ";
        if (clientId.length() > 0) {
            strSQL += " and  applicationid = '" + clientId + "'";
        }
        strSQL += " union all Select 'FUTURE' from  dual ";
        System.out.println("Query >>>>>>>>>>>>>>>>>>" + strSQL);
        return getList(strSQL, "Application for Client");
    }

    public boolean getApplicationInfo(String appId, String userType) {
        strSQL = "SELECT USERNAME FROM USR_USERS WHERE USERID = (SELECT "
                + userType + " from oam_productionmanager where appid = '"
                + appId + "') ";
        // System.out.println("Query ??????????????????????????????? "+strSQL);
        return getList(strSQL, "Getting Application Info");
    }
    
    public boolean getAssigneeInfo(String clientid, String userType) {
        strSQL = "SELECT userid, USERNAME FROM USR_USERS WHERE loginname = ( SELECT clusterlead FROM oam_rm_clients where clientid = '"
                + clientid + "') ";
        // System.out.println("Query ??????????????????????????????? "+strSQL);
        return getList(strSQL, "Getting Assignee Info");
    }
    
    public boolean getLead(String assigneeid) {
        strSQL = "SELECT userid, USERNAME FROM USR_USERS WHERE userid = (  SELECT distinct leadid FROM oam_cr_user_lead_map WHERE userid = '"
                + assigneeid + "') ";
         System.out.println("Query ??????????????????????????????? "+strSQL);
        return getList(strSQL, "Getting Lead Info");
    }

    /**
     * @date 2015.10.12
     * @author : rkc(i81324)
     * @purpose : - to get email address of Business Analyst Waltham PM Nepal PM
     * Clustered Lead
     * @param appId
     * @return
     */
    public boolean getCCEmailForBA_WPM_NPM_CL(String appId) {

        strSQL = "SELECT EMAIL FROM USR_USERS WHERE USERID = (SELECT csaid from oam_productionmanager where appid = '" + appId + "')  UNION ALL "
                + "SELECT EMAIL FROM USR_USERS WHERE USERID = (SELECT accid from oam_productionmanager where appid = '" + appId + "')  UNION ALL "
                + "SELECT EMAIL FROM USR_USERS WHERE USERID = (SELECT npmid from oam_productionmanager where appid = '" + appId + "')  UNION ALL "
                + "SELECT EMAIL FROM USR_USERS WHERE USERID = (SELECT amid from oam_productionmanager where appid = '" + appId + "')  UNION ALL "
                + "SELECT EMAIL FROM USR_USERS WHERE USERID = (SELECT businessintid from oam_productionmanager where appid = '" + appId + "')";

        /*
         SELECT EMAIL FROM USR_USERS WHERE (USERID) In (
         SELECT userid FROM oam_productionmanager
         unpivot
         (
         userid
         for user_id in (csaid, accid, npmid, amid, businessintid)

         )  
         WHERE appid = '111-001'
         )
         */
        System.out.println(queryBeanPM.class.getName() + "#getCCEmailForBA_WPM_NPM_CL()->SQL=" + strSQL);
        return getList(strSQL, "Getting Email Address for Business Analyst,Waltham PM,Nepal PM,Clustered Lead");
    }

    public boolean getUsernameForBA_WPM_NPM_CL(String appId) {
        strSQL = "SELECT (SELECT USERNAME FROM USR_USERS WHERE USERID = (SELECT csaid from oam_productionmanager where appid = '" + appId + "')) ba,"
                + "(SELECT USERNAME FROM USR_USERS WHERE USERID = (SELECT accid from oam_productionmanager where appid = '" + appId + "'))  wpm ,"
                + "(SELECT USERNAME FROM USR_USERS WHERE USERID = (SELECT npmid from oam_productionmanager where appid = '" + appId + "')) npm,"
                + "(SELECT USERNAME FROM USR_USERS WHERE USERID = (SELECT businessintid from oam_productionmanager where appid = '" + appId + "')) cl FROM  dual";
        System.out.println(queryBeanPM.class.getName() + "#getUsernameForBA_WPM_NPM_CL()->SQL=" + strSQL);
        return getList(strSQL, "Getting Username for Business Analyst,Waltham PM,Nepal PM,Clustered Lead");
    }

    public boolean getAppIdFromClientId(String clientId) {
        strSQL = "select applicationid, applicationname from oam_clientapps  WHERE clientid = '" + clientId + "'";
        System.out.println(queryBeanPM.class.getName() + "#getAppIdFromClientId()->SQL=" + strSQL);
        return getList(strSQL, "Get App ID From Client Id");
    }

    /*
     * Author:Richan Shrestha, Oct. 30 2007
     * 
     * @param:ProductID
     * 
     * @Description:Get the List of Users Not related to the Product
     * 
     * @Return:Success/Failure of QueryStatement
     */
    public boolean getNonProductUsers(String ProductID) {
        strSQL = "SELECT UserName,loginname,UserID FROM usr_Users WHERE "
                + " (UserID NOT IN (SELECT UserID FROM TMP_OAM_RM_USER_PRODUCT "
                + " WHERE (ProductID = '" + ProductID
                + "'))) AND OAMUSERTYPECODE is not null ORDER BY UserName";
        return getList(strSQL, "NonProductUsers");
    }

    // @author Raju Thapa Shrestha
    // A new method to get list of modules is added.
    public boolean getListOfModules(String ProductID) {

        strSQL = "SELECT DISTINCT ModuleID as ID,ModuleName as Module FROM OAM_RM_MODULES WHERE 1=1";
        if (!ProductID.equals("")) {
            strSQL += " AND ProductID='" + ProductID + "'";
        }
        strSQL += " ORDER BY ModuleName";
        return getList(strSQL, "Module");
    }

    public boolean getListOfVersions(String ProductID) {

        strSQL = "SELECT DISTINCT VersionID as ID,VersionDesc as Version, VersionOrder FROM OAM_RM_PRODUCTVERSION WHERE UPPER(Active_YN) = 'Y'";
        if (!ProductID.equals("")) {
            strSQL += " AND ProductID='" + ProductID + "'";
        }
        strSQL += " ORDER BY VersionDesc Desc";
        // System.out.println(strSQL);
        return getList(strSQL, "Version");
    }

    public boolean getListOfClients() {
        return getList(
                "SELECT ClientID,ClientName from OAM_RM_CLIENTS ORDER BY ClientName",
                "Clients");
    }

    public boolean getListOfRequestingPersons() throws Exception {
        return getList(
                "SELECT DISTINCT UserID as RequestingPersonID,UserName as RequestingPersonDesc FROM usr_Users  ORDER BY UserName",
                "Requesting Person");
    }

    // Changed by : Raju Thapa Shrestha,Jan 28,2008
    // Changes :
    // ModuleID,ProductArea,PhaseInject,EstimatedHours,ActualHours,LastUpdatedDate
    // are added.
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    public boolean getSelectedProjectRequest(String RequestCode, String userID)
            throws Exception {

        String sql = "select * from (SELECT  p.RequestCode, p.requestingperson , p.clientid ,  p.requestdate ,   p.requests ,     p.requesttypeid,     p.sourceid , p.projectid ,"
                + "      p.requesttitle ,       p.dataproviderid ,p.payorid ,               p.datatype ,    "
                + "      p.assignedto ,       p.estimatedhours ,    "
                + "     p.targetcompdate ,p.targetcompdate2 ,      p.lastupdateddate , p.actualcompdate  ,     p.requestpriority, p.applicationtype, p.lasteditedby, p.prioritizeddate, p.prioritizedby, p.convrequesttypeid, p.actualcompdate2  ,     "
                + " p.statusid,  p.phaseid,    r.username  AS RequestingPersonDesc, p.remarks , p.appreleasedate, p.employerGroup, p.team, p.processmonth,p.releasetag,p.cleancompletedatareciptdate,p.legalcompletedate,"
                + " p.externalid, p.parenticeid, p.parentrequesttype,  p.integrationtype , p.applicationkickoffdate, p.link_type, p.link_ice_id "
                + "  FROM OAM_RM_REQUESTMANAGER p,(SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS ) r  "
                + "WHERE r.UserID=p.RequestingPerson AND p.RequestCode='"
                + RequestCode + "' ) cross join (";

        sql += ""
                + "SELECT * "
                + "FROM   (SELECT Nvl(Round(SUM(devtime), 2), 0) AS totaldev, "
                + "               Nvl(Round(SUM(qctime), 2), 0)  AS totalqc, "
                + "               Nvl(Round(SUM(wpmtime), 2), 0)  AS totalwpm "
                + "        FROM   oam_cr_effortlogs "
                + "        WHERE  messageid = '"
                + RequestCode
                + "') a "
                + "       cross join (SELECT Nvl(Round(SUM(devtime), 2), 0) AS indDev, "
                + "                          Nvl(Round(SUM(qctime), 2), 0)  AS indQC, "
                + "                          Nvl(Round(SUM(wpmtime), 2), 0)  AS indWPM "
                + "                   FROM   oam_cr_effortlogs "
                + "                   WHERE  messageid = '" + RequestCode + "'"
                + "                          AND userid = '" + userID + "') ) ";

        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        return getList(sql, "Update Query ");
    }

    public boolean getSelectedProjectRequestDetails(String RequestCode)
            throws Exception {

        String sql = "select * from (SELECT  p.RequestCode, p.requestingperson , p.clientid ,  p.requestdate ,   p.requests ,    Nvl(decode(CONVREQUESTTYPEID,0,null,CONVREQUESTTYPEID),requesttypeid)  as requesttypeid ,p.convrequesttypeid,     p.sourceid ,"
                + "      p.requesttitle ,       p.dataproviderid ,p.payorid ,               p.datatype ,    "
                + "      p.assignedto ,       p.estimatedhours ,    "
                + "     p.targetcompdate ,      p.lastupdateddate, p.lasteditedby, p.actualcompdate  ,     p.requestpriority,      "
                + " p.statusid,  p.phaseid,    r.username  AS RequestingPersonDesc, p.remarks  FROM OAM_RM_REQUESTMANAGER p,(SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS) r  "
                + "WHERE r.UserID=p.RequestingPerson AND p.RequestCode='"
                + RequestCode + "' )  ";

        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        return getList(sql, "Update Query ");
    }

    public boolean getRequestTypesID(String RequestCode)
            throws Exception {

        String sql = "select * from (SELECT  p.RequestCode,   decode(CONVREQUESTTYPEID,0,null,CONVREQUESTTYPEID)  as convrequesttypeid, requesttypeid  FROM OAM_RM_REQUESTMANAGER p,(SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS ) r  "
                + "WHERE r.UserID=p.RequestingPerson AND p.RequestCode='"
                + RequestCode + "' )  ";

        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        return getList(sql, "Update Query ");
    }

    public boolean checkForUser(String userId) throws Exception {
        String sql = "" + "SELECT Count(1) as count FROM " + " "
                + "oam_rm_requestmanager a " + "left join usr_users b "
                + "ON a.requestingperson=b.userid "
                + "left join usr_deletedusers c "
                + "ON a.requestingperson=c.userid "
                + "where a.requestingperson ='" + userId + "'";

        // System.out.println("Checking for user >>>>>>>>>>>>>>>>>>>> "+sql);
        if (this.myConn == null) {
            this.makeConnection();
        }
        Statement stmnt = myConn.createStatement();
        ResultSet rs = stmnt.executeQuery(sql);
        while (rs.next()) {
            if (rs.getInt("count") > 0) {
                return true;
            }
        }
        stmnt.close();
        rs.close();
        return false;
    }

    public boolean getReprocessingRequest(String RequestCode) throws Exception {
        String sql = "select * from oam_cr_repmanager where requestcode = "
                + RequestCode;
        return getList(sql, "Get ReprocessingRequest ");
    }

    public boolean getExtractRequest(String RequestCode) throws Exception {
        String sql = "select * from oam_cr_exrmanager where requestcode = "
                + RequestCode;
        return getList(sql, "Get Extract Request ");
    }

    public boolean getProductionIntCodeRequest(String RequestCode) throws Exception {
        String sql = "select * from oam_cr_pitmanager where requestcode = "
                + RequestCode;
        return getList(sql, "Get Production Integration Code");
    }

    public boolean getChangeRequest(String RequestCode) throws Exception {

        String sql = "select * from oam_cr_crmanager where requestcode = "
                + RequestCode;

        // System.out.println("Get Change Request>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+sql);
        return getList(sql, "Get Change Request ");
    }

    public boolean isProductionApplication(String RequestCode) throws Exception {

        String sql = " SELECT Count(*) FROM  oam_cr_defect a WHERE application IN (SELECT defappid from oam_cr_defectapplication WHERE Upper(defappname)='PRODUCTION' AND is_deleted='N') and requestcode= " + RequestCode;

        System.out.println("Get Production Application>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        //return getList(sql, "Is Converted Request ");
        boolean flag = false;
        if (this.myConn == null) {
            this.makeConnection();
        }
        Statement stmnt = myConn.createStatement();
        ResultSet rs = stmnt.executeQuery(sql);
        while (rs.next()) {
            if (rs.getInt(1) > 0) {
                flag = true;
            }
        }
        stmnt.close();
        rs.close();
        return flag;
    }

    public boolean isConvertedRequest(String RequestCode) throws Exception {

        String sql = " SELECT Count(*) FROM   oam_rm_requestmanager WHERE requestcode= " + RequestCode
                + " AND Upper(is_converted)=Upper('Y')";

        System.out.println("Get Change Request>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        //return getList(sql, "Is Converted Request ");
        boolean flag = false;
        if (this.myConn == null) {
            this.makeConnection();
        }
        Statement stmnt = myConn.createStatement();
        ResultSet rs = stmnt.executeQuery(sql);
        while (rs.next()) {
            if (rs.getInt(1) > 0) {
                flag = true;
            }
        }
        stmnt.close();
        rs.close();
        return flag;
    }

    /**
     * @added by bpupadhyay 2015-09-29
     */
    public boolean isExistInCRManager(String RequestCode) throws Exception {
        String sql = "SELECT Count(*) FROM oam_cr_crmanager WHERE requestcode= " + RequestCode;
        boolean flag = false;
        if (this.myConn == null) {
            this.makeConnection();
        }
        System.out.println("Get Is Existed>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        Statement stmnt = myConn.createStatement();
        ResultSet rs = stmnt.executeQuery(sql);
        while (rs.next()) {
            if (rs.getInt(1) > 0) {
                flag = true;
            }
        }
        stmnt.close();
        rs.close();
        return flag;
    }

    public boolean isExistInSubRequestManager(String RequestCode, String requestTypeId) throws Exception {
        String table = null;
        for (RequestCode code : CommonUtils.RequestCode.values()) {
            if (code.getRequestTypeId().equals(requestTypeId)) {
                table = code.getDbTblName();
                break;
            }
        }
        boolean flag = false;
        if (table != null && !table.trim().isEmpty()) {
            String sql = "SELECT Count(*) FROM " + table + " WHERE requestcode= " + RequestCode;
            try {
                if (this.myConn == null) {
                    this.makeConnection();
                }
                System.out.println("isExistInSubRequestManager>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
                Statement stmnt = myConn.createStatement();
                ResultSet rs = stmnt.executeQuery(sql);
                while (rs.next()) {
                    if (rs.getInt(1) > 0) {
                        flag = true;
                    }
                }
                stmnt.close();
                rs.close();
            } catch (Exception e) {
            } finally {
                this.takeDown();
            }
        }
        return flag;
    }

    public boolean updateIsConvertedRequest(String RequestCode, String previousRequestTypeId, String convertedRequestType, String userId) throws Exception {
        System.out.println("Id=" + convertedRequestType + " Code=" + RequestCode);
        boolean updated = false;
        String updateIsConvertedFlag = "update oam_rm_requestmanager set is_converted='Y', convrequesttypeid=?,"
                + " conversiondate=sysdate, phaseid= ? where requestCode = ?";
        String newPhaseId = "";
        if (getPhasesForIssueType(convertedRequestType)) {
            if (moveNext()) {
                newPhaseId = getData("phaseid");
            }
        }
        try {
            if (this.myConn == null) {
                setAlias("RequestManager->SuperDomainDataBase");
                this.makeConnection();
            }
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(updateIsConvertedFlag);
            ps.setString(1, convertedRequestType);
            ps.setString(2, newPhaseId);
            ps.setString(3, RequestCode);
            ps.executeUpdate();
            updated = true;
            if (DAOFactory.INSTANCE.getIsActivityUpdateEnable()) {
                /*INSERT ACTIVITY LOG BEFORE SEND MAIL*/
                ActivityUpdateDTO activityUpdateDTO = new ActivityUpdateDTO();
                activityUpdateDTO.setPksource(String.valueOf(Integer.valueOf(RequestCode.substring(3))));
                activityUpdateDTO.setUsername(getEngineerName(userId));
                activityUpdateDTO.setDetail("Converted from " + CommonUtils.getRequestTitleById(previousRequestTypeId) + " to " + CommonUtils.getRequestTitleById(convertedRequestType));
                System.out.println("Inserting Log=>" + activityUpdateDTO.getDetail());
                ActivityUpdateDAO activityUpdateDAO = new ActivityUpdateDAO();
                activityUpdateDAO.insert(activityUpdateDTO);
                activityUpdateDAO.takeDown();
                /*FINISHED ACTIVITY LOG SAVED*/
            }
        } catch (SQLException ex) {
            myConn.rollback();
            logger.error("queryBeanPM->updateIsConvertedRequest(" + RequestCode
                    + ")", ex);
        } finally {
            this.takeDown();
        }

        return updated;
    }

    public boolean getEXRRequest(String RequestCode) throws Exception {
        String sql = "select * from oam_cr_exrmanager where requestcode = "
                + RequestCode;
        return getList(sql, "Get ExtractRequest ");
    }

    public boolean getPayorManagementRequest(String RequestCode)
            throws Exception {

        String sql = "WITH t AS  (SELECT aa.*,bb.payorid   "
                + " FROM (select a.*,b.username as signedoffbyusername from oam_cr_plchmanager a"
                + " left join usr_users b   on a.signedoffby=b.userid   where requestcode ="
                + RequestCode
                + ") aa,"
                + " oam_rm_requestmanager  bb   WHERE aa.requestcode=bb.requestcode     )   "
                + "     SELECT * FROM t left join       (SELECT DISTINCT vhpayorid, Upper( vhpayorname) AS payorname "
                + " FROM hr_global_vhpayors     )b     ON t.payorid=b.vhpayorid";

        System.out.println("Get Payor Management Request>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + sql);
        return getList(sql, "Get Payor Management Request");
    }

    public boolean getCarrierOutRequest(String RequestCode) throws Exception {

        String sql = "select * from oam_cr_cormanager where requestcode = "
                + RequestCode;

        // System.out.println("Get Carrier Out Reach Request>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+sql);
        return getList(sql, "Get Payor Management Request");
    }

    public boolean getTestCases(String RequestCode) {
        String sql = ""
                + "SELECT TESTDESCRIPTION,EXPECTEDRESULT,ACTUALRESULT,PASSFAIL FROM OAM_CR_TESTCASES  WHERE "
                + "REQUESTCODE = " + RequestCode + " order by testid";
        // System.out.println("Getting test case query>>>>>>>>>>>>>"+sql);
        return getList(sql, "Test Case");
    }

    public boolean getLastRequest(String RequestingPerson, String ClientID)
            throws Exception {

        // System.out.println(">>>>>>>>>>>>>>>>>>.");
        // System.out.println("select * from (select * from OAM_RM_REQUESTMANAGER Where RequestingPerson="+RequestingPerson+" and ClientId="+ClientID+" order by RequestCode desc) where rownum<2");
        return getList(
                "select * from (select * from OAM_RM_REQUESTMANAGER Where RequestingPerson='"
                + RequestingPerson + "' and ClientId=" + ClientID
                + " order by RequestCode desc) where rownum<2",
                "Last Request");
        // return
        // getList("select top 1 * from OAM_RM_REQUESTMANAGER Where RequestingPerson="+RequestingPerson+" and ClientId="+ClientID+" order by RequestCode desc","Last Request");
    }

    public boolean getListOfRequestType() throws Exception {
        return getList(
                "SELECT DISTINCT RequestTypeID,RequestTypeDesc FROM OAM_RM_REQUEST_TYPES ORDER BY RequestTypeDesc",
                "Request Type");
    }

    public boolean getRequestTypesForSwitchboard() throws Exception {
        return getList(
                "SELECT DISTINCT RequestTypeID,RequestTypeDesc,IncludeInSwitchboard FROM OAM_RM_REQUEST_TYPES WHERE IncludeInSwitchboard > 0 ORDER BY IncludeInSwitchboard, RequestTypeDesc ",
                "Request Type for Switchboard");
    }

    public boolean getDetailsOfRequest(String RequestCode) throws Exception {
        return getList(
                "SELECT * FROM OAM_RM_REQUESTMANAGER WHERE RequestCode='"
                + RequestCode + "'", "Request Details");
    }

    public boolean getRequestManagerMoreDocuments(String RequestCode)
            throws Exception {
        String documentLength = "";
        return getList(
                "SELECT doctype, DocumentCode, "
                + /* " LENGTH(uploadeddoc) docLength, " + */ " (SELECT PARAMETERVALUE FROM config_fixedparameters WHERE PARAMETERNAME LIKE 'documentBaseFilePathRM')  baseRmlocation, "
                + " filepath,"
                + " UploadedDocName, "
                + " u.UserName UploadedBy, to_char(Uploadedon,'YYYY') || '/' ||  to_char(Uploadedon,'MM') || '/' || to_char(Uploadedon,'DD')   "
                + " UploadedOnDate FROM OAM_RM_MOREDOCUMENTS1 a, "
                + " (SELECT USERID, USERNAME FROM USR_USERS) u "
                + " where u.UserID = a.UploadedBy and RequestCode='"
                + RequestCode + "' order by Uploadedon desc",
                "RequestManager More Documents");
    }

    public boolean getListOfRequestMoreInfo(String RequestCode, String InfoID)
            throws Exception {
        if (InfoID.equals("")) {
            return getList(
                    "SELECT r.*,u.UserName FROM OAM_RM_REQUESTMOREINFO r,usr_Users u where u.UserID=r.PostedBy AND ReplyTo is NULL AND r.RequestCode='"
                    + RequestCode + "' ORDER BY r.PostedDate DESC",
                    "Request More Information");
        } else if (RequestCode.equals("")) {
            return getList(
                    "SELECT r.*,u.UserName FROM OAM_RM_REQUESTMOREINFO r,usr_Users u where u.UserID=r.PostedBy AND r.ReplyTo='"
                    + InfoID + "' ORDER BY r.PostedDate DESC",
                    "Request More Information");
        } else {
            return getList(
                    "SELECT r.*,u.UserName FROM OAM_RM_REQUESTMOREINFO r,usr_Users u where u.UserID=r.PostedBy AND r.InfoID='"
                    + InfoID + "' ORDER BY r.PostedDate DESC",
                    "Request More Information");
        }
    }

    public String getStatusDesc(String StatusID) {
        String sqlString = "SELECT DISTINCT StatusDesc FROM OAM_RM_REQUESTSTATUS WHERE StatusID='"
                + StatusID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("StatusDesc");
            }
        }
        return retValue;
    }

    public String getRequestingPerson(String RequestingPersonID) {
        String sqlString = "SELECT UserName FROM usr_Users WHERE UserID='"
                + RequestingPersonID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("UserName");
            }

        }
        return retValue;
    }

    public String getApplicationVersionDesc(String ApplicationVersionCodeID) {
        String sqlString = "SELECT DISTINCT VersionDesc FROM OAM_RM_PRODUCTVERSION WHERE VersionID="
                + ApplicationVersionCodeID + "";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("VersionDesc");
            }

        }
        return retValue;
    }

    public String getClientName(String ClientID) {
        String sqlString = "select ClientName FROM OAM_RM_CLIENTS WHERE ClientID='"
                + ClientID + "'";

        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("ClientName");
            }
        }
        return retValue;
    }

    public String getICEClientName(String ClientID) {
        String sqlString = "select ClientName FROM OAM_RM_CLIENTS WHERE ClientID='"
                + ClientID + "'";

        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("ClientName");
            }
        }
        return retValue;
    }

    public String getRequestType(String RequestTypeCode) {
        String sqlString = "SELECT DISTINCT ISSUETYPENAME FROM oam_cr_issuetype WHERE ISSUETYPEID="
                + RequestTypeCode + "";
        String retValue = "N/A";
        if (getList(sqlString, "getRequestType")) {
            while (moveNext()) {
                retValue = getData("ISSUETYPENAME");
            }
        }

        return retValue;
    }

    public String findLastPhase(String IssuetypeCode) {
        String sqlString = "  SELECT phaseid FROM   oam_cr_template_phases  a, oam_cr_template_issuetype b , oam_cr_issuetype c  WHERE a.templateid =b.templateid AND    b.ISSUETYPEID=c.ISSUETYPEID   AND CRCODE='"
                + IssuetypeCode + "'  ORDER BY PHASEORDER asc  ";

        String retValue = "N/A";
        if (getList(sqlString, "getListOfPhase")) {
            while (moveNext()) {
                retValue = getData("phaseid");
            }
        }

        return retValue;
    }

    public String findLastPhaseByRequestTypeId(String Issuetypeid) {
        String sqlString = "  SELECT phaseid FROM   oam_cr_template_phases  a, oam_cr_template_issuetype b , oam_cr_issuetype c  WHERE a.templateid =b.templateid AND    b.ISSUETYPEID=c.ISSUETYPEID   AND c.ISSUETYPEID='"
                + Issuetypeid + "'  ORDER BY PHASEORDER asc  ";

        String retValue = "N/A";
        if (getList(sqlString, "getListOfPhase")) {
            while (moveNext()) {
                retValue = getData("phaseid");
            }
        }

        return retValue;
    }

    public String findFirstPhaseByRequestTypeId(String Issuetypeid) {
        String sqlString = "  SELECT phaseid FROM   oam_cr_template_phases  a, oam_cr_template_issuetype b , oam_cr_issuetype c  WHERE a.templateid =b.templateid AND    b.ISSUETYPEID=c.ISSUETYPEID   AND c.ISSUETYPEID='"
                + Issuetypeid + "'  ORDER BY PHASEORDER asc  ";

        String retValue = "N/A";
        if (getList(sqlString, "getListOfPhase")) {
            if (moveNext()) {
                retValue = getData("phaseid");
            }
        }

        return retValue;
    }

    public String getStatus(String phaseID) {
        String sqlString = "SELECT statusid FROM  oam_cr_phases  WHERE  phaseid='" + phaseID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "getStatus")) {
            while (moveNext()) {
                retValue = getData("statusid");
            }
        }
        return retValue;
    }

    public String findFirstPhaseOnUI(String IssuetypeCode) {
        String sqlString = "  SELECT phaseid FROM   oam_cr_template_phases  a, oam_cr_template_issuetype b , oam_cr_issuetype c  WHERE a.templateid =b.templateid AND    b.ISSUETYPEID=c.ISSUETYPEID   AND CRCODE='"
                + IssuetypeCode + "'  ORDER BY PHASEORDER asc  ";

        String retValue = "N/A";
        if (getList(sqlString, "getListOfPhase")) {
            if (moveNext()) {
                retValue = getData("phaseid");
            }
        }

        return retValue;
    }

    public String getPhaseDesc(String phaseID) {
        String sqlString = " SELECT phasename FROM  oam_cr_phases  where phaseid='"
                + phaseID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "getPhaseDesc")) {
            while (moveNext()) {
                retValue = getData("phasename");
            }
        }

        return retValue;
    }

    public String getRequestTypeCode(String RequestTypeDesc) {
        String sqlString = "SELECT DISTINCT RequestTypeID FROM OAM_RM_REQUEST_TYPES WHERE RequestTypeDesc='"
                + RequestTypeDesc + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("RequestTypeID");
            }
        }
        return retValue;
    }

    public boolean getRequestTypeCodeandDescFromProductId(String productid) {
        String sqlString = "SELECT RequestTypeID, RequestTypeDesc FROM OAM_RM_REQUEST_TYPES WHERE ProductID='"
                + productid + "' order by RequestTypeDesc asc";
        /*
         * try { if (logRS)return false; } catch (SQLException e) {} return
         * true;
         */

        strCountSQL += sqlString;
        return getList(sqlString, "");

    }

    /*
     * Function: getRequestTypeCodeFromRequestID Desc: Returns the
     * RequestTypeCode from a request type Author: Anjana Shrestha Created Date:
     * July 25, 2006 Input parameter: Request Code Output: Boolean that says
     * whether the query was successful or not
     */
    public boolean getRequestTypeCodeFromRequestID(String requestid) {
        String sqlString = "SELECT RequestTypeID FROM OAM_RM_REQUESTMANAGER WHERE RequestCode='"
                + requestid + "'";
        return getList(sqlString, "");

    }

    /*
     * Function: getProductfromClientID Desc: Returns the ProductCodes of a
     * client Author: Anjana Shrestha Created Date: July 25, 2006 Input
     * parameter: Client ID Output: Boolean that says whether the query was
     * successful or not
     */
    public boolean getProductfromClientID(String clientid) {
        String sqlString = "SELECT ProductID, ProductName FROM OAM_RM_PRODUCTS WHERE ClientID='"
                + clientid + "' order by ProductName";
        return getList(sqlString, "");

    }

    /*
     * Function: getProductDesc Desc: Returns the ProductName from a product id
     * Author: Anjana Shrestha Created Date: July 26, 2006 Input parameter:
     * Product ID Output: Boolean that says whether the query was successful or
     * not
     */
    public boolean getProductDesc(String productid) {
        String sqlString = "SELECT ProductName FROM OAM_RM_PRODUCTS WHERE ProductID='"
                + productid + "'";
        return getList(sqlString, "");

    }

    public void requestPreAssigned(String RequestTypeID) {
        try {
            String sqlString = "SELECT * FROM tbl_RequestPreAssignmentParameters WHERE RequestTypeID='"
                    + RequestTypeID + "'";
            if (getList(sqlString, "")) {
                while (moveNext()) {
                    preAssignedTo = getData("AssignedTo");
                    preStatus = getData("RequestStatus");
                    preActionTaken = getData("ActionTaken");
                    preThresholdDays = getData("ThresholdDays");
                }
            }
        } catch (Exception e) {
        }
    }

    public String getPreAssignedTo() {
        return preAssignedTo;
    }

    public String getPreActionTaken() {
        return preActionTaken;
    }

    public String getRequestPriority(String a) {
        String retValue = "N/A";
        if (a != null && a.length() > 0) {
            char c = a.charAt(0);
            switch (c) {
                case '1':
                    retValue = "";
                    break;
                case '2':
                    retValue = "";
                    break;
                case '3':
                    retValue = "P";
                    break;
                case '4':
                    retValue = "P";
                    break;
                case '5':
                    retValue = "P";
                    break;
                default:
                    retValue = "N/A";
                    break;
            }
        }
        return retValue;
    }

    public int getMaxID() {
        int i = 0;
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("SELECT MAX(PKSource) AS MaxID FROM OAM_RM_REQUESTMANAGER");
            while (rs.next()) {
                i = rs.getInt("MaxID");
            }
        } catch (Exception e) {
            errorStr = " ERROR GETTING MAXIMUM ID : " + e.toString();
        }
        return i;
    }

    public String getFileSep() {
        String osType = System.getProperty("os.name").toLowerCase();

        if (osType != null && osType.toLowerCase().contains("linux")) {
            fileSep = "/";
            /*
             * System.out.println(" \\ System is " + osType +
             * " and fileSeparator is " + fileSep);
             */
        } else if (osType != null && osType.toLowerCase().contains("windows")) {
            fileSep = "\\";
            System.out.println("System is " + osType + " and fileSeparator is "
                    + fileSep);
        } else {
            fileSep = "/";
            System.out.println(osType + " OS type is not supported");
        }
        System.out.println(" \\ System is " + osType + " and fileSeparator is "
                + fileSep);
        return fileSep;
    }

    public String uploadDocument(String RequestCode, String UploadedDocName,
            byte[] UploadedDoc, String UploadedBy, String DocType)
            throws Exception {
        String isInserted = "0";
        String baseLocation = "";
        String path = "";
        try {
            // baselocation/RM/YYYY/MM/DD/clientid_productid/requestcode/
            Statement stmt = myConn.createStatement();
            String appID = "";
            String clientsql = "select clientid,productid from oam_rm_requestmanager where requestcode='"
                    + RequestCode + "'";
            ResultSet tempRS = stmt.executeQuery(clientsql);
            while (tempRS.next()) {
                appID += tempRS.getString("clientid");
                appID += "_" + tempRS.getString("productid");
            }
            String baseLocationQuery = "select PARAMETERVALUE baseLocation,  "
                    + " to_char(sysdate,'YYYY') yr, "
                    + " to_char(sysdate,'MM') mth, "
                    + " to_char(sysdate,'DD') day "
                    + " from config_fixedparameters where  parametername like 'documentBaseFilePathRM' ";

            tempRS = stmt.executeQuery(baseLocationQuery);

            while (tempRS.next()) {
                baseLocation = tempRS.getString("baseLocation");
                path = tempRS.getString("yr") + getFileSep()
                        + tempRS.getString("mth") + getFileSep()
                        + tempRS.getString("day") + getFileSep() + appID
                        + getFileSep() + RequestCode;
            }
            File file = new File(baseLocation + getFileSep() + path);
            boolean result = file.mkdirs();
            String fileLocation = baseLocation + getFileSep() + path
                    + getFileSep() + UploadedDocName;
            System.out.println("Directory created " + fileLocation + " is "
                    + result);
            FileOutputStream fos = new FileOutputStream(fileLocation);
            fos.write(UploadedDoc);
            int byteLengthint = UploadedDoc.length;
            String byteLength = "";
            if (byteLengthint != 0) {
                if (byteLengthint > (1024 * 1024 * 1024)) {
                    byteLength = byteLengthint / (1024 * 1024 * 1024) + " GB";
                } else if (byteLengthint > (1024 * 1024)) {
                    byteLength = byteLengthint / (1024 * 1024) + " MB";
                } else if (byteLengthint > (1024)) {
                    byteLength = byteLengthint / (1024) + " KB";
                } else {
                    byteLength = byteLengthint + " B";
                }

            }

            String sql = "INSERT  INTO OAM_RM_MOREDOCUMENTS1 "
                    + "(RequestCode,UploadedDocName,UploadedBy,doctype,documentcode,UploadedOn,filepath,DOCSIZEVAR)"
                    + " VALUES(?,?,?,?,1,SYSDATE,?,?) ";
            PreparedStatement stmnt = this.myConn.prepareStatement(sql);
            System.out.println("Before inserting the doc");
            stmnt.setString(1, RequestCode);
            stmnt.setString(2, UploadedDocName.replace('#', '_'));
            stmnt.setString(3, UploadedBy);
            stmnt.setString(4, DocType);
            stmnt.setString(5, path);
            stmnt.setString(6, byteLength);
            stmnt.execute();

            strSQL = "select SQ_OAM_RM_MOREDOCUMENTS1.currval docid from dual";
            if (getList(strSQL, "")) {
                while (moveNext()) {
                    isInserted = getData("docid");
                }
            }

            Statement stmt1 = this.myConn.createStatement();
            // System.out.println("After inserting the doc");
            stmt1.execute("Update OAM_RM_REQUESTMANAGER SET documentCount=documentCount+1 WHERE RequestCode='"
                    + RequestCode + "'");

            stmnt.close();
            stmt1.close();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println(errorStr);
            sqlexception.printStackTrace();
        }
        return isInserted;
    }

    public String uploadDocumentRM(String RequestCode, String UploadedDocName,
            String path, int byteLengthint, String UploadedBy, String DocType)
            throws Exception {
        String isInserted = "0";
        String byteLength = "";
        if (byteLengthint != 0) {
            if (byteLengthint > (1024 * 1024 * 1024)) {
                byteLength = byteLengthint / (1024 * 1024 * 1024) + " GB";
            } else if (byteLengthint > (1024 * 1024)) {
                byteLength = byteLengthint / (1024 * 1024) + " MB";
            } else if (byteLengthint > (1024)) {
                byteLength = byteLengthint / (1024) + " KB";
            } else {
                byteLength = byteLengthint + " B";
            }

        }

        String sql = "INSERT  INTO OAM_RM_MOREDOCUMENTS1 "
                + "(RequestCode,UploadedDocName,UploadedBy,doctype,documentcode,UploadedOn,filepath,DOCSIZEVAR)"
                + " VALUES(?,?,?,?,1,SYSDATE,?,?) ";
        try {
            PreparedStatement stmnt = this.myConn.prepareStatement(sql);
            System.out.println("Before inserting the doc");
            stmnt.setString(1, RequestCode);
            stmnt.setString(2, UploadedDocName.replace('#', '_'));
            stmnt.setString(3, UploadedBy);
            stmnt.setString(4, DocType);
            stmnt.setString(5, path);
            stmnt.setString(6, byteLength);
            stmnt.execute();

            strSQL = "select SQ_OAM_RM_MOREDOCUMENTS1.currval docid from dual";
            if (getList(strSQL, "")) {
                while (moveNext()) {
                    isInserted = getData("docid");
                }
            }

            Statement stmt1 = this.myConn.createStatement();
            // System.out.println("After inserting the doc");
            stmt1.execute("Update OAM_RM_REQUESTMANAGER SET documentCount=documentCount+1 WHERE RequestCode='"
                    + RequestCode + "'");

            stmnt.close();
            stmt1.close();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println(errorStr);
            sqlexception.printStackTrace();
        }
        return isInserted;
    }

    public String getBaseLocationRM(String RequestCode) throws Exception {
        String baseLocation = "";
        try {
            // baselocation/RM/YYYY/MM/DD/clientid_productid/requestcode/
            Statement stmt = myConn.createStatement();
            String appID = "";
            String clientsql = "select clientid,productid from oam_rm_requestmanager where requestcode='"
                    + RequestCode + "'";
            ResultSet tempRS = stmt.executeQuery(clientsql);
            while (tempRS.next()) {
                appID += tempRS.getString("clientid");
                appID += "_" + tempRS.getString("productid");
            }
            String baseLocationQuery = "select PARAMETERVALUE baseLocation,  "
                    + " to_char(sysdate,'YYYY') yr, "
                    + " to_char(sysdate,'MM') mth, "
                    + " to_char(sysdate,'DD') day "
                    + " from config_fixedparameters where  parametername like 'documentBaseFilePathRM' ";

            tempRS = stmt.executeQuery(baseLocationQuery);

            while (tempRS.next()) {
                baseLocation = tempRS.getString("baseLocation");

            }
            tempRS.close();
            stmt.close();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println(errorStr);
            sqlexception.printStackTrace();
        }
        return baseLocation;
    }

    public String getPathRM(String RequestCode) throws Exception {
        String path = "";
        try {
            // baselocation/RM/YYYY/MM/DD/clientid_productid/requestcode/
            Statement stmt = myConn.createStatement();
            String appID = "";
            String clientsql = "select clientid from oam_rm_requestmanager where requestcode='"
                    + RequestCode + "'";
            ResultSet tempRS = stmt.executeQuery(clientsql);
            while (tempRS.next()) {
                appID += tempRS.getString("clientid");
            }
            String baseLocationQuery = "select PARAMETERVALUE baseLocation,  "
                    + " to_char(sysdate,'YYYY') yr, "
                    + " to_char(sysdate,'MM') mth, "
                    + " to_char(sysdate,'DD') day "
                    + " from config_fixedparameters where  parametername like 'documentBaseFilePathRM' ";

            tempRS = stmt.executeQuery(baseLocationQuery);

            while (tempRS.next()) {
                path = tempRS.getString("yr") + getFileSep()
                        + tempRS.getString("mth") + getFileSep()
                        + tempRS.getString("day") + getFileSep() + appID
                        + getFileSep() + RequestCode;
            }
            tempRS.close();
            stmt.close();

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
            System.out.println(errorStr);
            sqlexception.printStackTrace();
        }
        return path;
    }

    private String getSQLEncodedData(String s) {
        if (s.trim().equals("")) {
            return ("NULL");
        } else {
            return ("'" + s.trim().replaceAll("'", "''") + "'");
        }
    }

    public String insertProjectRequest(String ClientID, String RequestDate,
            String RequestingPerson, String Requests, String RequestTypeID,
            String RelVersion, String ExpectedCompDate, String RequestPriority)
            throws Exception {
        String isInserted = "0";
        try {

            Statement stmnt = myConn.createStatement();
            String sqlString = "SP_OAM_RM_REQUESTMANAGER '" + RequestingPerson
                    + "'," + getSQLEncodedData(ClientID) + ","
                    + getSQLEncodedData(RequestDate) + ","
                    + getSQLEncodedData(Requests.replaceAll("'", "''").trim())
                    + "," + getSQLEncodedData(RequestTypeID) + ","
                    + getSQLEncodedData(RelVersion) + ","
                    + getSQLEncodedData(ExpectedCompDate) + ","
                    + getSQLEncodedData(RequestPriority);
            strSQL = sqlString;
            if (getList(sqlString, "")) {
                while (moveNext()) {
                    isInserted = getData("RequestCode");
                }
            }
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String updateProjectRequestNew(String RequestID, String ClientID,
            String RequestDate, String RequestingPerson, String Requests,
            String RequestTypeID, String RelVersion, String ExpectedCompDate,
            String RequestPriority) throws Exception {
        String AssignedTo = "";
        String preExpectedCompDate = "";
        try {
            // archiveRequest(RequestID,"");
            requestPreAssigned(RequestTypeID);
            AssignedTo = preAssignedTo;
            preExpectedCompDate = "NULL";
            // if(!preThresholdDays.equals("")){
            // preExpectedCompDate = "DateAdd(dd," + preThresholdDays + "," +
            // getSQLEncodedData(RequestDate) + ")";
            // }
            // else
            // {
            preExpectedCompDate = SQLEncode(ExpectedCompDate);
            // }
            Statement stmnt = myConn.createStatement();
            String sqlString = "UPDATE OAM_RM_REQUESTMANAGER SET RequestingPerson = '"
                    + RequestingPerson
                    + "',"
                    + "ClientID="
                    + SQLEncode(ClientID)
                    + ","
                    + "RequestDate="
                    + SQLEncode(RequestDate)
                    + ","
                    + "Requests="
                    + SQLEncode(Requests)
                    + ","
                    + "RequestTypeID="
                    + SQLEncode(RequestTypeID)
                    + ","
                    + "DetectedVersion="
                    + SQLEncode(RelVersion)
                    + ","
                    + "ExpectedCompDate="
                    + preExpectedCompDate
                    + ","
                    + "TargetCompDate="
                    + preExpectedCompDate
                    + ","
                    + "AssignedTo="
                    + SQLEncode(preAssignedTo)
                    + ","
                    + "ActionTaken="
                    + SQLEncode(preActionTaken)
                    + ","
                    + "LastUpdatedDate= sysdate, "
                    + "RequestPriority="
                    + SQLEncode(RequestPriority);
            if (!preStatus.equals("")) {
                sqlString += ",StatusID	= " + SQLEncode(preStatus) + "";
            }
            sqlString += " WHERE RequestCode ='" + RequestID + "'";
            strSQL = sqlString;
            stmnt.execute(strSQL);

        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return preAssignedTo;
    }

    public String updateAssignedToDataIssue(String RequestCode) {
        String sqlStr = "";
        String isInserted = "ok";
        sqlStr = "update a Set a.AssignedTo = b.BusinessIntID,a.StatusID = '0008'"
                + " FROM OAM_RM_REQUESTMANAGER a"
                + " LEFT JOIN tbl_ProductionManager b "
                + " ON a.ClientID = b.ProductionCode";
        sqlStr += " WHERE 1=1 AND b.BusinessIntID is not null and RequestCode='"
                + RequestCode + "'";
        strSQL += "<BR>" + sqlStr;
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    // Method to mark or unmark completed by enggineer
    // isComp = 'n' if it is marked as incomplete - default
    // isComp = 'y' if it is marked as completed
    // isComp = 'm' if enggineer posts a new message and no reply is posted
    public String markRequestCompleted(String RequestCode, String enggID,
            String isComp) {

        String isInserted = "0";
        String sqlString = "{call sp_OAM_RM_MarkRequestCompleted (?,?,?)}";
        try {
            strSQL = sqlString;

            CallableStatement stmt = this.myConn.prepareCall(sqlString);
            stmt.setString(1, RequestCode);
            stmt.setString(2, enggID);
            stmt.setString(3, isComp);

            stmt.execute();
            isInserted = "1";
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Marking Error : " + sqlexception;
        }
        return isInserted;
    }

    public String markRequestDropped(String RequestCode) throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            strSQL = "Update OAM_RM_REQUESTMANAGER Set StatusID='0003' WHERE RequestCode='"
                    + RequestCode + "'";
            stmnt.execute(strSQL);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String deleteProjectRequest(String RequestCode) throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            String sqlString = "DELETE OAM_RM_REQUESTMANAGER WHERE RequestCode="
                    + RequestCode;
            stmnt.execute(sqlString);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String deleteProjectRequestBlank() throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            String sqlString = "DELETE OAM_RM_REQUESTMANAGER where RequestTypeID is null "
                    + " and requestcode not in (select requestcode from OAM_RM_ASSIGNEE)"
                    + " and requestcode not in (select requestcode from OAM_RM_MOREDOCUMENTS1)"
                    + " and requestcode not in (select requestcode from OAM_RM_REQUESTMOREINFO)";
            stmnt.execute(sqlString);
        } catch (SQLException sqlexception) {
            errorStr = "Project Request Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String insertNewObject(String whichObject, String objectValue)
            throws Exception {
        String isInserted = "ok";
        char c = whichObject.charAt(0);
        strSQL = "";
        String ov = objectValue.replaceAll("'", "''").trim().trim();
        switch (c) {
            case 'a':
                strSQL = "INSERT INTO OAM_RM_REQUEST_TYPES VALUES ('" + ov + "')";
                break;
            case 'b':
                strSQL = "INSERT INTO OAM_RM_REQUESTSTATUS VALUES ('" + ov + "')";
                break;
            case 'c':
                strSQL = "INSERT INTO tbl_Engineers VALUES ('" + ov + "')";
                break;
            case 'd':
                strSQL = "INSERT INTO OAM_RM_PRODUCTVERSION VALUES ('" + ov + "')";
                break;
            case 'e':
                strSQL = "INSERT INTO tbl_RequestingPerson VALUES ('" + ov + "')";
                break;
            case 'f':
                strSQL = "INSERT INTO OAM_RM_REQUEST_TYPES VALUES ('" + ov + "')";
                break;
            default:
                strSQL = "";
                break;
        }

        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(strSQL);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public String getSQLData(String value) {

        if (!value.trim().equals("")) {
            return "'" + value.replaceAll("'", "''").trim() + "'";
        } else {
            return "NULL";
        }

    }

    // Changed by:Raju Thapa Shrestha,Jan 28,2008
    // Changes :New parameters
    // ProductModule,ProductArea,RequestPhaseInject,EstimatedHours,ActualHoursLastUpdatedDate
    // are added.
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    public String updateProjectRequest(String RequestCode,
            String RequestTypeCode, String RequestDate,
            String RequestingPerson, String Requests, String ActionTaken,
            String StatusID, String AssignedTo, String ApplicationVersionCode,
            String TargetCompDate, String ActualCompDate,
            String RequestPriority, String ClientID, String RequestPhaseCode,
            String uid, String ProductID, String ProjectID,
            String ProductModule, String RequestPhaseInject,
            String ProductArea, String EstimatedHours, String ActualHours,
            String LastUpdatedDate, String SourceID, String RequestSeverity,
            String Impact, String DataProviderID, String qcPerson) {
        return updateProjectRequest(RequestCode, RequestTypeCode, RequestDate,
                RequestingPerson, Requests, ActionTaken, StatusID, AssignedTo,
                ApplicationVersionCode, TargetCompDate, ActualCompDate,
                RequestPriority, ClientID, RequestPhaseCode, uid, ProductID,
                ProjectID, "", ProductModule, RequestPhaseInject, ProductArea,
                EstimatedHours, "", LastUpdatedDate, SourceID, RequestSeverity,
                Impact, DataProviderID, qcPerson, "");
    }

    public String updateProjectRequest(String RequestCode,
            String RequestTypeCode, String RequestDate,
            String RequestingPerson, String Requests, String ActionTaken,
            String StatusID, String AssignedTo, String ApplicationVersionCode,
            String TargetCompDate, String ActualCompDate,
            String RequestPriority, String ClientID, String RequestPhaseCode,
            String uid, String ProductID, String ProjectID, String FixVersion,
            String ProductModule, String RequestPhaseInject,
            String ProductArea, String EstimatedHours, String ActualHours,
            String LastUpdatedDate, String SourceID, String RequestSeverity,
            String Impact, String DataProviderID, String qcPerson,
            String requestTitle) {

        String sqlStr = "";
        String isInserted = "ok";
        String iscompleted = "n";
        QueryBean queryBean = new QueryBean();
        queryBean.setAlias(this.getAlias());
        // System.out.println("This is the alias->updateProjectRequest"+this.getAlias());
        String temp = "0";
        String temp1 = "0";
        try {
            queryBean.makeConnection();
            temp = queryBean.getStatusIDByName("Completed");
            temp1 = queryBean.getStatusIDByName("QC Completed");
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            queryBean.takeDown();
        }

        ClientID = ClientID.trim().equals("") ? "0" : ClientID;
        RequestTypeCode = RequestTypeCode.trim().equals("") ? "0"
                : RequestTypeCode;
        ApplicationVersionCode = ApplicationVersionCode.trim().equals("") ? "0"
                : ApplicationVersionCode;
        ProductID = ProductID.trim().equals("") ? "0" : ProductID;
        ProjectID = ProjectID.trim().equals("") ? "0" : ProjectID;
        ProductModule = ProductModule.trim().equals("") ? "0" : ProductModule;
        ProductArea = ProductArea.trim().equals("") ? "0" : ProductArea;
        RequestPhaseInject = RequestPhaseInject.trim().equals("") ? "0"
                : RequestPhaseInject;
        RequestPhaseCode = RequestPhaseCode.trim().equals("") ? "0"
                : RequestPhaseCode;
        EstimatedHours = EstimatedHours.trim().equals("") ? "0"
                : EstimatedHours;
        SourceID = SourceID.trim().equals("") ? "0" : SourceID;
        RequestSeverity = RequestSeverity.trim().equals("") ? "0"
                : RequestSeverity;
        RequestPriority = RequestPriority.trim().equals("") ? "0"
                : RequestPriority;
        preStatus = preStatus.trim().equals("") ? "0" : preStatus;
        DataProviderID = DataProviderID.trim().equals("") ? "0"
                : DataProviderID;
        if (StatusID.equals(temp) && !temp.equals("0")) {
            iscompleted = "y";
        } else if (StatusID.equals(temp1) && !temp1.equals("0")) {
            iscompleted = "y";
        }

        sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET "
                + // "RequestDate='" + RequestDate +
                " RequestingPerson='"
                + RequestingPerson.replaceAll("'", "''").trim()
                + "',Requests='" + Requests.replaceAll("'", "''").trim() + "'";
        sqlStr += ",ProductID=" + getSQLData(ProductID);
        sqlStr += ",REQUESTTITLE=" + getSQLData(requestTitle);
        sqlStr += ",ProjectID=" + getSQLData(ProjectID);
        sqlStr += ",RequestTypeID=" + getSQLData(RequestTypeCode);
        sqlStr += ",ActionTaken=" + getSQLData(ActionTaken);
        sqlStr += ",StatusID=" + getSQLData(StatusID);
        sqlStr += ",AssignedTo=" + getSQLData(AssignedTo);
        sqlStr += ",DetectedVersion=" + getSQLData(ApplicationVersionCode);
        sqlStr += ",TargetCompDate= to_date(" + getSQLData(TargetCompDate)
                + ",'mm/dd/yyyy')";
        sqlStr += ",ActualCompDate= to_date(" + getSQLData(ActualCompDate)
                + ",'mm/dd/yyyy')";
        sqlStr += ",RequestPriority=" + getSQLData(RequestPriority);
        sqlStr += ",PhaseDetected=" + getSQLData(RequestPhaseCode);
        sqlStr += ",isCompleted=" + getSQLData(iscompleted);
        sqlStr += ",ClientID=" + getSQLData(ClientID);
        sqlStr += ",FixedInVersion=" + getSQLData(FixVersion);
        sqlStr += ",ModuleID=" + getSQLData(ProductModule);
        sqlStr += ",PhaseInject=" + getSQLData(RequestPhaseInject);
        sqlStr += ",ProductArea=" + getSQLData(ProductArea);
        sqlStr += ",EstimatedHours=" + getSQLData(EstimatedHours);
        sqlStr += ",ActualHours=" + getSQLData(ActualHours);
        sqlStr += ",LastUpdatedDate=sysdate";
        sqlStr += ",SourceID=" + getSQLData(SourceID);
        sqlStr += ",SeverityID=" + getSQLData(RequestSeverity);
        sqlStr += ",DataProviderID=" + getSQLData(DataProviderID);
        sqlStr += ",QC=" + getSQLData(qcPerson);
        sqlStr += ",Impact=" + getSQLData(Impact);
        if (StatusID.equals(temp)) {
            sqlStr += ",DevCompDate=sysdate";
            // System.out.println("-------True");
        }

        sqlStr += " WHERE RequestCode='" + RequestCode + "'";
        // System.out.println(sqlStr);
        strSQL += "<BR>" + sqlStr;

        // System.out.println("QueryBeanPM->updateProjectRequest: "+sqlStr);
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
            if (requestTitle.trim().length() > 0)
				;
            // stmnt.execute(sql_updateTitle);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        if (isInserted.equals("ok")) {
            archiveRequest(RequestCode, uid);
        }
        return isInserted;
    }

    public String updateProjectRequestIsAdmin(String RequestCode,
            String RequestTypeCode, String RequestDate,
            String RequestingPerson, String Requests, String uid,
            String StatusID, String assignedTo, String requestTitle) {
        String sqlStr = "";
        String isInserted = "ok";
        String iscompleted = "n";

        QueryBean queryBean = new QueryBean();
        // System.out.println("This is the alias->updateProjectRequestIsAdmin"+this.getAlias());
        queryBean.setAlias(this.getAlias());
        String temp = "0";
        try {
            queryBean.makeConnection();
            temp = queryBean.getStatusIDByName("Completed");
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            queryBean.takeDown();
        }

        if (StatusID.equals(temp) && !temp.equals("0")) {
            iscompleted = "y";
        }
        sqlStr = "UPDATE OAM_RM_REQUESTMANAGER SET "
                + // "RequestDate='" + RequestDate +
                " RequestingPerson='"
                + RequestingPerson.replaceAll("'", "''").trim()
                + "',StatusID='" + StatusID + "',iscompleted='" + iscompleted
                + "',AssignedTo='" + assignedTo.replaceAll("'", "''").trim()
                + "',LastUpdatedDate= sysdate " + ",Requests='"
                + Requests.replaceAll("'", "''").trim() + "'";
        sqlStr += ",RequestTypeID=" + getSQLData(RequestTypeCode);

        sqlStr += " WHERE RequestCode='" + RequestCode + "'";

        strSQL = sqlStr;

        // System.out.println("QueryBeanPM->updateProjectRequestIsAdmin: "+sqlStr);
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
            // System.out.println("UPDATE : " + sqlStr);
            if (requestTitle.trim().length() > 0)
				;
            // stmnt.execute(sql_updateTitle);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        if (isInserted.equals("ok")) {
            archiveRequest(RequestCode, uid);
        }

        return isInserted;
    }

    // DELETES the document of passed Request Code and DocumentCode (if any)
    public String deleteRequestDocument(String RequestCode, String DocumentCode) {
        String did = DocumentCode;
        if (did.equals("")) {
            did = "0";
        }
        String isInserted = "ok";
        String sqlStr = "{call SP_OAM_RM_DELETEREQUESTDOC (?,?)}";

        try {
            CallableStatement stmt = this.myConn.prepareCall(sqlStr);
            stmt.setString(1, RequestCode);
            stmt.setString(2, DocumentCode);
            stmt.execute();
            isInserted = "1";
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    // Inserts a new "Request More Information" record
    public String insertRequestMoreInfo(String RequestCode, String PostedBy,
            String ReplyTo, String PostedMsg) {
        String sqlStr = "";
        String isInserted = "ok";
        if (ReplyTo.equals("")) {
            ReplyTo = "NULL";
        } else {
            ReplyTo = "'" + ReplyTo + "'";
        }
        sqlStr = "SP_OAM_RM_REQUESTMOREINFO '" + RequestCode + "','" + PostedBy
                + "'," + ReplyTo + ",'"
                + PostedMsg.replaceAll("'", "''").trim() + "'";
        strSQL = sqlStr;
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute(sqlStr);
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    // Mark the replies "READ" if the logged user is the Engineer to which
    // current request is assigned
    public String markRepliesRead(String RequestCode) {
        String isInserted = "ok";
        String sqlString = "{call sp_oam_rm_markrepliesread (?)}";

        strSQL = sqlString;
        try {
            CallableStatement stmt = this.myConn.prepareCall(sqlString);
            stmt.setString(1, RequestCode);
            stmt.execute();
        } catch (SQLException sqlexception) {
            isInserted = "Object Entry error  : " + sqlexception;
        }
        return isInserted;
    }

    public void addMultipleAssignee(String ProjID, String multipleAssignee) {
        try {
            Statement stmnt = myConn.createStatement();
            StringTokenizer strtoken = new StringTokenizer(multipleAssignee,
                    ",");
            String sqlstr = "DELETE OAM_RM_ASSIGNEE WHERE RequestCode = '"
                    + ProjID + "'";
            stmnt.execute(sqlstr);
            while (strtoken.hasMoreTokens()) {
                String str = strtoken.nextToken();
                // stmnt.execute("insert into OAM_RM_ASSIGNEE values('"+ ProjID
                // +"', '"+ str +"')");
                // String sqlstr="sp_InsertMultipleAssignee '"+ ProjID +
                // "','"+str+"'";
                sqlstr = "insert into OAM_RM_ASSIGNEE values('" + ProjID
                        + "', '" + str + "')";
                stmnt.execute(sqlstr);
            }
        } catch (SQLException sqlexception) {
        }
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request with Request Code "ProjID"
    // Changed by :Raju Thapa Shrestha,Jan 31,2008
    // Changes : Add
    // RequestPhaseInject,ProductModule,ProductArea,EstimatedHours,ActualHours,RequestSource
    // parameters
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    public boolean getRequestDetails(String RequestCode) {
        String sql = ""
                + "SELECT p.requestcode, "
                + "       p.requestdate, "
                + "       p.requesttypeid, "
                + "       p.requests, "
                + "       p.requestingperson, "
                + "       rp.username             AS RequestingPersonDesc, "
                + "       rp.email                AS ReqPersonEmail, "
                + "       c.clientname, "
                + "       e.username              AS User_Name, "
                + "       e.email                 AS enggEmail, "
                + "       p.requestpriority, "
                + "       e.userid                AS EnggID, "
                + "       p.iscompleted, "
                + "       Nvl(y.documentcount, 0) AS documentCount, "
                + "       p.expectedcompdate, "
                + "       p.devcompdate, "
                + "       p.targetCompDate, "
                + "       p.targetCompDate2, "
                + "       p.appreleasedate,  "
                + "       p.ACTUALCOMPDATE, "
                + "       p.estimatedhours, "
                + "       p.employerGroup, "
                + "       p.actualhours, "
                + "       p.sourceid, "
                + "       p.clientid, "
                + "       p.remarks,"
                + "       p.applicationtype, "
                + "       p.prioritizeddate, "
                + "       p.prioritizedby, "
                + "       p.actualcompdate2, "
                + "       p.convrequesttypeid, "
                + "       p.releasetag, "
                + "       p.externalid, "
                + "       p.parenticeid, "
                + "       p.parentrequesttype, "
                + "       p.integrationtype, "
                + "       p.applicationkickoffdate, "
                + "       p.link_type, "
                + "       p.link_ice_id, "
                + "       p.cleancompletedatareciptdate, "
                + "       p.legalcompletedate, "
                + "       cr_it_sec.issuetypename  as secondaryType, "
                + "       nvl(p.projectid,0) as projectid ,"
                + "       cr_it.issuetypename, " + "       cr_it.crcode, "
                + "       cr_ph.phasename, "
                + "       p.phaseid, "
                //  + "       ds.clientname           AS datasource, "
                + "       p.datatype         AS datatype, "
                + "       p.processmonth         AS processmonth, "
                + "       t.defname as team, "
                + "       p.REQUESTTITLE , "
                + "       Upper(vp.vhpayorname) AS payorname"
                + " FROM   oam_rm_requestmanager p "
                + "       left outer join usr_users e "
                + "                    ON p.assignedto = e.userid "
                + "       left outer join usr_users rp "
                + "                    ON p.requestingperson = rp.userid "
                + "       left outer join oam_rm_clients c "
                + "                    ON p.clientid = c.clientid "
                + "       left join (SELECT requestcode, "
                + "                         Count(*) AS documentCount "
                + "                  FROM   oam_rm_moredocuments1 "
                + "                  GROUP  BY requestcode) y "
                + "              ON y.requestcode = p.requestcode "
                + "       left outer join oam_cr_issuetype cr_it "
                + "                    ON cr_it.issuetypeid = p.requesttypeid "
                + "       left outer join oam_cr_issuetype cr_it_sec "
                + "                    ON cr_it_sec.issuetypeid = p.convrequesttypeid "
                + "       left outer join oam_cr_phases cr_ph "
                + "                    ON cr_ph.phaseid = p.phaseid "
                + "       left outer join hr_global_vhpayors vp "
                + "                    ON vp.vhpayorid=p.payorid "
                + "       left outer join oam_cr_defectteam t "
                + "                    ON t.defid=p.team "
                + "			WHERE  p.requestcode = '" + RequestCode + "'";

        strSQL = sql;
        System.out.println("Getting Request Details for Mail >>>>>>>>>>>>>>>>>>" + strSQL);
        return getList(sql, "Request Details QueryBeanPM->getRequestDetails");
    }

    public String getRequestTitle(String ProjID) {
        String sqlString = "SELECT RequestTitle FROM oam_rm_requestmanager WHERE RequestCode='"
                + ProjID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("RequestTitle");
            }
        }
        return retValue;
    }

    public String getPostReplyCount(String followup, String parentcode) {
        String sqlString = "SELECT  REQUESTCODE FROM oam_rm_requestmanager WHERE "
                + "PARENTREQUESTCODE='"
                + parentcode + "' order by requestcode  asc";
        String retValue = "N/A";
        int count = 0;
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("requestcode");
                count++;
                if (retValue.equalsIgnoreCase(followup)) {
                    break;
                }
            }
        }
        return "" + count;
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request with Request Code "ProjID" in
    // HTML-Formatted String
    // Changed: Anjana Shrestha
    // Date: Oct 04, 2006
    // Chnage Description: Changed in order to get the Product Description as
    // well.
    // Changed by :Raju Thapa Shrestha,Jan 31,2008
    // Changes : Add
    // RequestPhaseInject,ProductModule,ProductArea,EstimatedHours,ActualHours,RequestSource
    // parameters
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    /**
     * @author D2HS\rbaral incorporate the request url in the email
     * @throws Exception
     * @since July 5 2010
     */
    public String getFormattedRequestDetails(String ProjID, String domainName)
            throws Exception {
        String requestDetail = "";
        String OAMURL = getFixedParameter("ICE URL");
        String isChangedrequestPriority = "";
        String isChangeddocumentCount = "";
        String isChangedEstimatedHours = "";
        String isChangedAssignedTo = "";

        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestCode = checkEmptyAndNull(getData("RequestCode"));
                String requestDate = checkEmptyAndNull(getOnlyDate(
                        getData("RequestDate"), true));
                reqPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                reqPersonEmail = checkEmptyAndNull(getData("ReqPersonEmail"));
                String requestPriority = checkEmptyAndNull(getData("RequestPriority"));
                String clientName = checkEmptyAndNull(getData("ClientName"));
                mainEnggName = checkEmptyAndNull(getData("User_Name"));
                mainEnggEmail = checkEmptyAndNull(getData("enggEmail"));
                String issueType = checkEmptyAndNull(getData("issuetypename"));
                String secondaryType = checkEmptyAndNull(getData("secondaryType"));
                String issueTypeCode = checkEmptyAndNull(getData("crcode"));
                String AppID = checkEmptyAndNull(getData("AppID"));
                String phase = checkEmptyAndNull(getData("phasename"));
                String dataSource = checkEmptyAndNull(getData("datasource"));
                String dataType = checkEmptyAndNull(getData("datatype"));
                String documentCount = getData("documentCount");
                String EstimatedHours = getData("EstimatedHours");
                String payer = checkEmptyAndNull(getData("payorname"));
                String targetCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate"), true));
                String targetCompDate2 = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate2"), true));
                String requestTitle = checkEmptyAndNull(getData("REQUESTTITLE"));
                Base64Encoder encoder = new Base64Encoder();
                String requestUrl = "";
                /*
                 * String requestUrl = OAMURL +
                 * "/RE/ListProjectRequest_Lighter.jsp?userView=" +
                 * encoder.encode(requestCode);
                 */
                requestUrl = "<a href=" + OAMURL + "/index.jsp>Go To ICE</a>";
                System.out.println("request url is:" + requestUrl);
                String attch = "N/A";
                if (!(documentCount.equals("0") || documentCount.trim().equals(
                        ""))) {
                    attch = "<a href='" + OAMURL
                            + "/RE/downloadAllFiles.jsp?pid=" + ProjID
                            + "&domain=" + domainName
                            + "'>Click here to download attachments</a>";
                }

                String requestPriorityDesc = "";
                if (requestPriority.equals("3")) {
                    requestPriorityDesc = "P";
                } else if (requestPriority.equals("4")) {
                    requestPriorityDesc = "P";
                } else if (requestPriority.equals("5")) {
                    requestPriorityDesc = "P";
                } else {
                    requestPriorityDesc = "N/A";
                }

                requestDetail = "<TABLE>"
                        + "<TR><TD>Request Date  </TD><TD>:&nbsp; "
                        + requestDate + "</TR>"
                        + "<TR><TD>Requesting Person  </TD><TD>:&nbsp; "
                        + reqPersonName + "</TR>";
                // Client Name

                //if (!issueTypeCode.equalsIgnoreCase("PMG")) {
                requestDetail += "<TR><TD>Client  </TD><TD>:&nbsp; "
                        + clientName + "</TR>";
                requestDetail += "<TR><TD>App ID  </TD><TD>:&nbsp; "
                        + AppID + " </TR>";
                requestDetail += "<TR><TD>Request Title  </TD><TD>:&nbsp; "
                        + requestTitle + " </TR>";

                //}
                requestDetail += "<TR><TD>Payer  </TD><TD>:&nbsp; "
                        + payer + " </TR>";

                requestDetail += "<TR><TD>Data Type  </TD><TD>:&nbsp; "
                        + dataType + " </TR>";
                // Issue Type
                requestDetail += "<TR><TD>Request Type</TD><TD>:&nbsp; "
                        + issueType + "</TR><TR";
                if (!secondaryType.equalsIgnoreCase("N/A")) {
                    requestDetail += "<TR><TD>Converted Request Type</TD><TD>:&nbsp; "
                            + secondaryType + "</TR><TR";
                }
                // Phase
                requestDetail += "><TD>Current Phase</TD><TD>:&nbsp; " + phase
                        + "</TR><TR";
                // Assigned To
                if (!isChangedAssignedTo.equals("")) {
                    requestDetail += " bgcolor='#ABCDEF' ";
                }
                requestDetail += "><TD>Assigned to</TD><TD>:&nbsp; "
                        + mainEnggName + "</TR><TR";
                // Request Priority
                if (!isChangedrequestPriority.equals("")) {
                    requestDetail += " bgcolor='#ABCDEF' ";
                }
                requestDetail += "><TD>Priority  </TD><TD>:&nbsp; "
                        + requestPriorityDesc + "</TR><TR";
                // Estimated hours
                if (!isChangedEstimatedHours.equals("")) {
                    requestDetail += " bgcolor='#ABCDEF' ";
                }
                requestDetail += "><TD>Estimated Hours  </TD><TD>:&nbsp; "
                        + EstimatedHours + "</TR>";
                /*requestDetail += "<TR><TD>Target Date  </TD><TD>:&nbsp; "
                 + targetCompDate + "</TR>";*/

                if (issueTypeCode.equalsIgnoreCase("CHR"))// For Change Request
                {
                    System.out
                            .println("Getting change request contents for request id "
                                    + ProjID);
                    requestDetail += addChangeRequestContentForMail(ProjID);
                } else if (issueTypeCode.equalsIgnoreCase("PMG"))// For Payor
                // Management
                {
                    System.out
                            .println("Getting payor mgmt contents for request id "
                                    + ProjID);
                    requestDetail += addPayorMgmtContentForMail(ProjID);

                    //if is converted true then add CR mail message
                    if (isConvertedRequest(ProjID)) {
                        requestDetail += "<tr><td><hr></td><td><hr></td></tr>" + addChangeRequestContentForMailPM2CR(ProjID, targetCompDate2) + "<tr><td><hr></td><td><hr></td></tr>";
                    }
                } else if (issueTypeCode.equalsIgnoreCase("REP"))// For
                // Reprocessing
                {
                    System.out
                            .println("Getting reprocessing contents for request id "
                                    + ProjID);
                    requestDetail += addReprocessingContentForMail(ProjID);
                } else if (issueTypeCode.equalsIgnoreCase("COR"))// For Carrier
                // Out Reach
                {
                    System.out
                            .println("Getting carrier out reach contents for request id "
                                    + ProjID);
                    requestDetail += addCORContentForMail(ProjID);
                } else if (issueTypeCode.equalsIgnoreCase("EXR") || issueTypeCode.equalsIgnoreCase("CAW"))// For Carrier
                // Out Reach
                {
                    System.out
                            .println("Getting Extract request id "
                                    + ProjID);
                    requestDetail += addEXRCAWContentForMail(ProjID);

                    //if is converted true then add CR mail message
                    if (issueTypeCode.equalsIgnoreCase("CAW") && isConvertedRequest(ProjID)) {
//                                            String mailMsg  = addChangeRequestContentForMail(ProjID);
//                                            System.out.println("MailMessage=" + mailMsg);
                        /*
                         * Skip Message For :
                         * Billable Client RegEx : <TR><TD>Bill Client <\/TD><TD>:.*?<\/TR>
                         * Account Manager RegEx : <TR><TD>Account Manager <\/TD><TD>:.*?<\/TR>
                         * Reason RegEx : <TR><TD>Reason <\/TD><TD>:.*?<\/TR>
                         */
                        requestDetail += "<tr><td><hr></td><td><hr></td></tr>";
//                                            mailMsg = mailMsg.replaceAll("<TR><TD>Bill Client <\\/TD><TD>:.*?<\\/TR>|<TR><TD>Account Manager <\\/TD><TD>:.*?<\\/TR>|<TR><TD>Reason <\\/TD><TD>:.*?<\\/TR>", "");
//                                            System.out.println("FormatMailMessage=" + mailMsg);
                        requestDetail += addChangeRequestContentForMailCAW2CR(ProjID, targetCompDate2);
                        requestDetail += "<tr><td><hr></td><td><hr></td></tr>";
                    }//end

                }
                // Attachments
                if (!isChangeddocumentCount.equals("")) {
                    requestDetail += " bgcolor='#ABCDEF' ";
                }
                requestDetail += "<TR><TD>Attachment  </TD><TD>:&nbsp; "
                        + attch + "</TR>";

                requestDetail += "<TR><TD>ICE URL  </TD><TD>:&nbsp; "
                        + requestUrl + "</TR>";
                requestDetail += " </TABLE>";
            }
        }
        System.out.println("msg:" + requestDetail);
        return requestDetail;
    }

    public String getFormattedRequestDetailsForSubTaskI(String parentcode, String ProjID, String color)
            throws Exception {
        String requestDetail = "";
        String requestCode = this.getPostReplyCount(ProjID, parentcode);
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {

                String requestdate = checkEmptyAndNull(getOnlyDate(
                        getData("REQUESTDATE"), true));
                String reqPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String requests = checkEmptyAndNull(getDataWithoutPara("requests", color));

                requestDetail = "<TR><TD><font color='" + color + "'>Follow up #</font></TD><TD><font color='" + color + "'>:&nbsp; "
                        + requestCode + "</font></TR>";

                requestDetail += "<TR><TD><font color='" + color + "'>Request Date  </font></TD><TD><font color='" + color + "'>:&nbsp; "
                        + requestdate + "</font></TD></TR>";

                requestDetail += "<TR><TD><font color='" + color + "'>Requesting Person  </font></TD><TD><font color='" + color + "'>:&nbsp; "
                        + reqPersonName + "</font></TD></TR>";
                requestDetail += "<TR><TD><font color='" + color + "'>Action  </font></TD><TD><font color='" + color + "'>"
                        + requests.trim() + "</font></TD></TR>";

            }
        }

        return requestDetail;
    }

    public String getFormattedRequestDetailsForSubTaskII(String parentcode, String requestcode, String ProjID)
            throws Exception {
        String requestDetail = "";
        String requestCode = this.getPostReplyCount(requestcode, parentcode);
        requestCode += ".";
        requestCode += this.getPostReplyCount(ProjID, requestcode);

        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestdate = checkEmptyAndNull(getOnlyDate(
                        getData("REQUESTDATE"), true));
                String reqPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String requests = checkEmptyAndNull(getDataWithoutPara("requests", "red"));

                requestDetail = "<TR><TD><font color='red'> Follow up # </font> </TD><TD><font color='red'>:&nbsp; "
                        + requestCode + "</font></TD> </TR>";

                requestDetail += "<TR><TD><font color='red'>Request Date  </font></TD><TD><font color='red'>:&nbsp; "
                        + requestdate + "</font></TD></TR>";

                requestDetail += "<TR><TD><font color='red'>Requesting Person  </font></TD><TD> <font color='red'>:&nbsp; "
                        + reqPersonName + "</font></TD></TR>";
                requestDetail += "<TR><TD><font color='red'>Action  </font></TD><TD> <font color='red'>"
                        + requests.trim() + "</font></TD></TR>";

            }
        }

        return requestDetail;
    }

    public String getFormattedRequestDetailsForSubTask(String ProjID, String assignee, String reporter)
            throws Exception {
        String requestDetail = "";

        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestCode = checkEmptyAndNull(getData("RequestCode"));
                String reqPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String clientName = checkEmptyAndNull(getData("ClientName"));
                String mainEnggName = checkEmptyAndNull(getData("User_Name"));
                String phasename = checkEmptyAndNull(getData("phasename"));
                String issueType = checkEmptyAndNull(getData("issuetypename"));
                String issueTypeCode = checkEmptyAndNull(getData("crcode"));
                String AppID = checkEmptyAndNull(getData("AppID"));
                String dataType = checkEmptyAndNull(getData("datatype"));
                String payer = checkEmptyAndNull(getData("payorname"));
                String requesttitle = checkEmptyAndNull(getData("requesttitle"));
                String targetCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate"), true));
                String actualCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("ACTUALCOMPDATE"), true));

                requestDetail = "<TR><TD>Request ID  </TD><TD>:&nbsp; "
                        + requestCode + "</TR>"
                        + "<TR><TD>Request Type</TD><TD>:&nbsp; "
                        + issueType + "</TR>";

                requestDetail += "<TR><TD>Client  </TD><TD>:&nbsp; "
                        + clientName + "</TR>";
                requestDetail += "<TR><TD>App ID  </TD><TD>:&nbsp; "
                        + AppID + " </TR>";

                requestDetail += "<TR><TD>Payer  </TD><TD>:&nbsp; "
                        + payer + " </TR>";
                if (issueTypeCode.equalsIgnoreCase("PMG")) {
                    requestDetail += "<TR><TD>Data Type  </TD><TD>:&nbsp; "
                            + dataType + " </TR>";
                }
                requestDetail += "<TR><TD>Phase  </TD><TD>:&nbsp; "
                        + phasename + " </TR>";

                requestDetail += "<TR><TD>Requesting Person  </TD><TD>:&nbsp; "
                        + reqPersonName + "</TR>";

                requestDetail += "<TR><TD>Assigned to</TD><TD>:&nbsp; "
                        + mainEnggName + "</TR>";
                requestDetail += "<TR><TD>Request Title</TD><TD>:&nbsp; "
                        + requesttitle + "</TR>";
                requestDetail += "<TR><TD>Target Date  </TD><TD>:&nbsp; "
                        + targetCompDate + "</TR>";
                requestDetail += "<TR><TD>Actual Comp Date  </TD><TD>:&nbsp; "
                        + actualCompDate + "</TR>";

            }
        }
        System.out.println("msgsubtask:" + requestDetail);
        return requestDetail;
    }

    /**
     * @param projectId
     * @return Change Request Content for Sending Email from
     * ice.oam_cr_crmanager
     * @throws Exception
     */
    public String addChangeRequestContentForMail(String projectId)
            throws Exception {
        String changeRequestContent = "";

        String datalayout = "";
        String amname = "";
        String reason = "";
        String billclient = "";
        String jiraid = "";
        String problemdef = "";
        String changespecify = "";
        String clientpaid = "";
        String clientrequestdate = "";
        String clienttargetdate = "";
        String actualtargetdate = "";
        String Impact = "";
        String payorname = "";
        String processmonth = "";

        if (getChangeRequest(projectId)) {
            if (moveNext()) {
                processmonth = checkEmptyAndNull(getData("processmonth"));
                datalayout = checkEmptyAndNull(getData("datalayout"));
                amname = checkEmptyAndNull(getData("accountmanager"));
                reason = checkEmptyAndNull(getData("reasonch"));
                billclient = checkEmptyAndNull(getData("billable"));
                jiraid = checkEmptyAndNull(getData("jiraid"));
                problemdef = checkEmptyAndNull(getData("problemdef"));
                changespecify = checkEmptyAndNull(getData("changespecify"));
                clientpaid = checkEmptyAndNull(getData("clientpaid"));
                clientrequestdate = checkEmptyAndNull(getOnlyDate(
                        getData("clientrequestdate"), true));
                clienttargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("clienttargetdate"), true));
                actualtargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("actualtargetdate"), true));
                Impact = checkEmptyAndNull(getData("impact"));// for impact

            }
        }

        changeRequestContent += "<TR><TD>Expected Application Posting Date </TD><TD>:&nbsp; "
                + processmonth + "</TR>";
        changeRequestContent += "<TR><TD>Data Layout </TD><TD>:&nbsp; "
                + datalayout + "</TR>"
                + "<TR><TD>Bill Client </TD><TD>:&nbsp; " + billclient
                + "</TR>";
        if (billclient.equalsIgnoreCase("No")) {
            changeRequestContent += "<TR><TD>Account Manager </TD><TD>:&nbsp; "
                    + amname + "</TR>" + "<TR><TD>Reason </TD><TD>:&nbsp; "
                    + reason + "</TR>";
        }
        changeRequestContent += "<TR><TD>Jira Ticket </TD><TD>:&nbsp; "
                + jiraid + "</TR>"
                + "<TR><TD>Problem Defination </TD><TD>:&nbsp; " + problemdef
                + "</TR>" + "<TR><TD>Change Specification </TD><TD>:&nbsp; "
                + changespecify + "</TR>"
                + "<TR><TD>Client Paid </TD><TD>:&nbsp; " + clientpaid
                + "</TR>" + "<TR><TD>Client Request Date </TD><TD>:&nbsp; "
                + clientrequestdate + "</TR>"
                + "<TR><TD>Client Target Date </TD><TD>:&nbsp; "
                + clienttargetdate + "</TR>"
                + "<TR><TD>Actual Target Date </TD><TD>:&nbsp; "
                + actualtargetdate + "</TR>"
                + "<TR><TD>Impact </TD><TD>:&nbsp; " + Impact + "</TR>";

        return changeRequestContent;
    }

    public String addChangeRequestContentForMailPM2CR(String projectId, String targetCompDate2)
            throws Exception {
        String changeRequestContent = "";

        String datalayout = "";
        String amname = "";
        String reason = "";
        String billclient = "";
        String jiraid = "";
        String problemdef = "";
        String changespecify = "";
        String clientpaid = "";
        String clientrequestdate = "";
        String clienttargetdate = "";
        String actualtargetdate = "";
        String Impact = "";
        String payorname = "";
        String processmonth = "";

        if (getChangeRequest(projectId)) {
            if (moveNext()) {
                processmonth = getMonth(getData("processmonth"));
                datalayout = checkEmptyAndNull(getData("datalayout"));
                amname = checkEmptyAndNull(getData("accountmanager"));
                reason = checkEmptyAndNull(getData("reasonch"));
                billclient = checkEmptyAndNull(getData("billable"));
                jiraid = checkEmptyAndNull(getData("jiraid"));
                problemdef = checkEmptyAndNull(getData("problemdef"));
                changespecify = checkEmptyAndNull(getData("changespecify"));
                clientpaid = checkEmptyAndNull(getData("clientpaid"));
                clientrequestdate = checkEmptyAndNull(getOnlyDate(
                        getData("clientrequestdate"), true));
                clienttargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("clienttargetdate"), true));
                actualtargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("actualtargetdate"), true));
                Impact = checkEmptyAndNull(getData("impact"));// for impact

            }
        }

        changeRequestContent += "<TR><TD>Expected Application Posting Date </TD><TD>:&nbsp; "
                + processmonth + "</TR>";
        changeRequestContent += "<TR><TD>Data Layout </TD><TD>:&nbsp; "
                + datalayout + "</TR>"
                + "<TR><TD>Bill Client </TD><TD>:&nbsp; " + billclient
                + "</TR>";
        if (billclient.equalsIgnoreCase("No")) {
            changeRequestContent += "<TR><TD>Account Manager </TD><TD>:&nbsp; "
                    + amname + "</TR>" + "<TR><TD>Reason </TD><TD>:&nbsp; "
                    + reason + "</TR>";
        }
        changeRequestContent += "<TR><TD>Jira Ticket </TD><TD>:&nbsp; "
                + jiraid + "</TR>"
                + "<TR><TD>Problem Defination </TD><TD>:&nbsp; " + problemdef
                + "</TR>" + "<TR><TD>Change Specification </TD><TD>:&nbsp; "
                + changespecify + "</TR>"
                + "<TR><TD>Client Paid </TD><TD>:&nbsp; " + clientpaid
                + "</TR>" + "<TR><TD>Client Request Date </TD><TD>:&nbsp; "
                + clientrequestdate + "</TR>"
                + "<TR><TD>Client Target Date </TD><TD>:&nbsp; "
                + targetCompDate2 + "</TR>"
                + "<TR><TD>Actual Target Date </TD><TD>:&nbsp; "
                + actualtargetdate + "</TR>"
                + "<TR><TD>Impact </TD><TD>:&nbsp; " + Impact + "</TR>";

        return changeRequestContent;
    }

    public String addChangeRequestContentForMailCAW2CR(String projectId, String targetCompDate2)
            throws Exception {
        String changeRequestContent = "";

        String datalayout = "";
        String amname = "";
        String reason = "";
        String billclient = "";
        String jiraid = "";
        String problemdef = "";
        String changespecify = "";
        String clientpaid = "";
        String clientrequestdate = "";
        String clienttargetdate = "";
        String actualtargetdate = "";
        String Impact = "";
        String payorname = "";
        String processmonth = "";

        if (getChangeRequest(projectId)) {
            if (moveNext()) {
                processmonth = getMonth(getData("processmonth"));
                datalayout = checkEmptyAndNull(getData("datalayout"));
                amname = checkEmptyAndNull(getData("accountmanager"));
                reason = checkEmptyAndNull(getData("reasonch"));
                billclient = checkEmptyAndNull(getData("billable"));
                jiraid = checkEmptyAndNull(getData("jiraid"));
                problemdef = checkEmptyAndNull(getData("problemdef"));
                changespecify = checkEmptyAndNull(getData("changespecify"));
                clientpaid = checkEmptyAndNull(getData("clientpaid"));
                clientrequestdate = checkEmptyAndNull(getOnlyDate(
                        getData("clientrequestdate"), true));
                clienttargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("clienttargetdate"), true));
                actualtargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("actualtargetdate"), true));
                Impact = checkEmptyAndNull(getData("impact"));// for impact

            }
        }

        changeRequestContent += "<TR><TD>Expected Application Posting Date </TD><TD>:&nbsp; "
                + processmonth + "</TR>";
        changeRequestContent += "<TR><TD>Data Layout </TD><TD>:&nbsp; "
                + datalayout + "</TR>";
        changeRequestContent += "<TR><TD>Jira Ticket </TD><TD>:&nbsp; "
                + jiraid + "</TR>"
                + "<TR><TD>Problem Defination </TD><TD>:&nbsp; " + problemdef
                + "</TR>" + "<TR><TD>Change Specification </TD><TD>:&nbsp; "
                + changespecify + "</TR>"
                + "<TR><TD>Client Paid </TD><TD>:&nbsp; " + clientpaid
                + "</TR>" + "<TR><TD>Client Request Date </TD><TD>:&nbsp; "
                + clientrequestdate + "</TR>"
                + "<TR><TD>Client Target Date </TD><TD>:&nbsp; "
                + targetCompDate2 + "</TR>"
                + "<TR><TD>Actual Target Date </TD><TD>:&nbsp; "
                + actualtargetdate + "</TR>"
                + "<TR><TD>Impact </TD><TD>:&nbsp; " + Impact + "</TR>";

        return changeRequestContent;
    }

    /**
     * @param projectId
     * @return PayorManagement Contents for Sending Email From
     * ice.oam_cr_plchmanager
     * @throws Exception
     */
    public String addPayorMgmtContentForMail(String projectId) throws Exception {
        String payorMgmtContent = "";

        String clientsImpacted = "";
        String eigerPath = "";
        String isTestData = "";
        String testDataDetails = "";
        String effectiveDate = "";
        String layoutChangeReason = "";
        String OAMDetails = "";
        String fileNameConv = "";
        String controlTotals = "";
        String emailCommunication = "";
        String issueDetails = "";
        String dateOfComp = "";
        String signedOffBy = "";
        String additionalComments = "";
        String signedOffByUserName = "";
        String payorname = "";
        String prodatalocation = "";

        if (getPayorManagementRequest(projectId)) {
            if (moveNext()) {
                clientsImpacted = checkEmptyAndNull(getData("impact"));
                eigerPath = checkEmptyAndNull(getData("eigerpath"));
                isTestData = checkEmptyAndNull(getData("istestdata"));
                testDataDetails = checkEmptyAndNull(getData("detailtestdata"));
                prodatalocation = checkEmptyAndNull(getData("prodatalocation"));
                effectiveDate = checkEmptyAndNull(getOnlyDate(
                        getData("productiondate"), true));
                layoutChangeReason = checkEmptyAndNull(getData("reasonchange"));
                OAMDetails = checkEmptyAndNull(getData("oamdetail"));
                fileNameConv = checkEmptyAndNull(getData("filenamingconvention"));
                controlTotals = checkEmptyAndNull(getData("controltotal"));
                emailCommunication = checkEmptyAndNull(getData("emailcomm"));
                issueDetails = checkEmptyAndNull(getData("issueidentified"));
                dateOfComp = checkEmptyAndNull(getOnlyDate(
                        getData("dateofcompletion"), true));
                signedOffBy = checkEmptyAndNull(getData("signedoffby"));
                signedOffByUserName = checkEmptyAndNull(getData("signedoffbyusername"));
                additionalComments = checkEmptyAndNull(getData("additionalComments"));
                //payorname = checkEmptyAndNull(getData("payorname"));
            }
        }

        payorMgmtContent += "<TR><TD>Clients Impacted </TD><TD>:&nbsp; "
                + clientsImpacted + "</TR>"
                + "<TR><TD>Layout Location </TD><TD>:&nbsp; " + eigerPath + "</TR>"
                + "<TR><TD>Is Test Data </TD><TD>:&nbsp; " + isTestData
                + "</TR>";
        if (isTestData.equalsIgnoreCase("Y")) {
            payorMgmtContent += "<TR><TD>Test Data Details </TD><TD>:&nbsp; "
                    + testDataDetails + "</TR>";
        }
        payorMgmtContent += "<TR><TD>Production Data Location </TD><TD>:&nbsp; "
                + prodatalocation + "</TR>"
                + "<TR><TD>Effective Date </TD><TD>:&nbsp; "
                + effectiveDate + "</TR>"
                + "<TR><TD>Layout Change Reason </TD><TD>:&nbsp; "
                + layoutChangeReason + "</TR>"
                + "<TR><TD>Oam Details </TD><TD>:&nbsp; " + OAMDetails
                + "</TR>" + "<TR><TD>File Name Convention </TD><TD>:&nbsp; "
                + fileNameConv + "</TR>"
                + "<TR><TD>Control Totals </TD><TD>:&nbsp; " + controlTotals
                + "</TR>" + "<TR><TD>Email Communication </TD><TD>:&nbsp; "
                + emailCommunication + "</TR>"
                + "<TR><TD>Issue Details </TD><TD>:&nbsp; " + issueDetails
                + "</TR>" + "<TR><TD>Date of Completion </TD><TD>:&nbsp; "
                + dateOfComp + "</TR>"
                + "<TR><TD>Signed off by </TD><TD>:&nbsp; "
                + signedOffByUserName + "</TR>"
                + "<TR><TD>Additional Comments </TD><TD>:&nbsp; "
                + additionalComments + "</TR>";

        return payorMgmtContent;
    }

    /**
     * @param projectId
     * @return Reprocessing Contents For Sending Mail From ice.oam_cr_repmanager
     * @throws Exception
     */
    public String addReprocessingContentForMail(String projectId)
            throws Exception {
        String reProcessingContent = "";

        String amname = "";
        String ba = "";
        String wpm = "";
        String npm = "";
        String cl = "";
        String addreasonOfReprocess = "";
        String reasonOfReprocess = "";
        String billclient = "";
        String reason = "";
        String billedMonth = "";
        String corActPlan = "";
        String approvedBy = "";
        String approvalDate = "";

        if (getReprocessingRequest(projectId)) {
            if (moveNext()) {
                amname = checkEmptyAndNull(getData("accountmanager"));
                ba = checkEmptyAndNull(getData("businessanalyst"));
                wpm = checkEmptyAndNull(getData("wpm"));
                npm = checkEmptyAndNull(getData("npm"));
                cl = checkEmptyAndNull(getData("clusterlead"));
                addreasonOfReprocess = checkEmptyAndNull(getData("reasonreprocessing"));
                reasonOfReprocess = checkEmptyAndNull(getData("reprocessvalue"));
                billclient = checkEmptyAndNull(getData("billable"));
                reason = checkEmptyAndNull(getData("reasonbillable"));
                billedMonth = getMonth(getData("billedmonth"));
                corActPlan = checkEmptyAndNull(getData("actionplan"));
                approvedBy = checkEmptyAndNull(getData("approvedby"));
                approvalDate = checkEmptyAndNull(getOnlyDate(
                        getData("approvedate"), true));
            }
        }

        if (!approvedBy.equalsIgnoreCase("N/A")) {
            approvedBy = this.getEngineerName(approvedBy);
        }

        reProcessingContent += "<TR><TD>Business Analyst </TD><TD>:&nbsp; "
                + ba + "</TR>" + "<TR><TD>Waltham PM </TD><TD>:&nbsp; " + wpm
                + "</TR>" + "<TR><TD>Nepal PM </TD><TD>:&nbsp; " + npm
                + "</TR>" + "<TR><TD>Cluster Lead </TD><TD>:&nbsp; " + cl
                + "</TR>"
                + "<TR><TD>Reason of Reprocess </TD><TD>:&nbsp; " + reasonOfReprocess
                + "</TR>"
                + "<TR><TD>Additional details for Reprocessing </TD><TD>:&nbsp; "
                + addreasonOfReprocess + "</TR>"
                + "<TR><TD>Bill Client </TD><TD>:&nbsp; " + billclient
                + "</TR>";
        if (billclient.equalsIgnoreCase("No")) {
            reProcessingContent += "<TR><TD>Account Manager </TD><TD>:&nbsp; "
                    + amname + "</TR>" + "<TR><TD>Reason </TD><TD>:&nbsp; "
                    + reason + "</TR>";
        } else if (billclient.equalsIgnoreCase("Yes")) {
            reProcessingContent += "<TR><TD>Billed Month </TD><TD>:&nbsp; "
                    + billedMonth + "</TR>";
        }
        reProcessingContent += "<TR><TD>Corrective Action Plan </TD><TD>:&nbsp; "
                + corActPlan
                + "</TR>"
                + "<TR><TD>Approved By </TD><TD>:&nbsp; "
                + approvedBy
                + "</TR>"
                + "<TR><TD>Approval Date </TD><TD>:&nbsp; "
                + approvalDate + "</TR>";

        return reProcessingContent;
    }

    /**
     * @param projectId
     * @return Carrier Out Reach Contents for Sending Mail from
     * ice.oam_cr_cormanager
     * @throws Exception
     */
    public String addCORContentForMail(String projectId) throws Exception {
        String corContent = "";

        String missingData = "";
        String missingDataMonth = "";
        String fileNameConv = "";
        String issueDetails = "";
        String additionalValues = "";
        String responseFromVendor = "";
        String additionalComments = "";

        if (getCarrierOutRequest(projectId)) {
            if (moveNext()) {
                missingData = checkEmptyAndNull(getData("missingdata"));
                missingDataMonth = getMonth(getData("missingmonth"));
                fileNameConv = checkEmptyAndNull(getData("filenamingconvention"));
                issueDetails = checkEmptyAndNull(getData("dataissues"));
                additionalValues = checkEmptyAndNull(getData("descriptions"));
                responseFromVendor = checkEmptyAndNull(getData("vendorresponse"));
                additionalComments = checkEmptyAndNull(getData("additionalComments"));
            }
        }

        corContent += "<TR><TD>Missing Data </TD><TD>:&nbsp; " + missingData
                + "</TR>";
        if (missingData.equalsIgnoreCase("Y")) {
            corContent += "<TR><TD>Missing Data Month </TD><TD>:&nbsp; "
                    + missingDataMonth + "</TR>";
        }
        corContent += "<TR><TD>File Name Convention </TD><TD>:&nbsp; "
                + fileNameConv + "</TR>"
                + "<TR><TD>Issue Details </TD><TD>:&nbsp; " + issueDetails
                + "</TR>" + "<TR><TD>Additional Values </TD><TD>:&nbsp; "
                + additionalValues + "</TR>"
                + "<TR><TD>Response From Vendor </TD><TD>:&nbsp; "
                + responseFromVendor + "</TR>"
                + "<TR><TD>Additional Comments </TD><TD>:&nbsp; "
                + additionalComments + "</TR>";

        return corContent;
    }

    /**
     * @param projectId
     * @return Reprocessing Contents For Sending Mail From ice.oam_cr_repmanager
     * @throws Exception
     */
    public String addEXRCAWContentForMail(String projectId)
            throws Exception {
        String content = "";

        String amname = "";
        String ba = "";
        String wpm = "";
        String npm = "";
        String cl = "";
        String details = "";
        String billclient = "";
        String reason = "";
        String billedMonth = "";
        String approvedBy = "";
        String signedBy = "";
        String approvalDate = "";

        if (getEXRRequest(projectId)) {
            if (moveNext()) {
                amname = checkEmptyAndNull(getData("accountmanager"));
                ba = checkEmptyAndNull(getData("businessanalyst"));
                wpm = checkEmptyAndNull(getData("wpm"));
                npm = checkEmptyAndNull(getData("npm"));
                cl = checkEmptyAndNull(getData("clusterlead"));
                details = checkEmptyAndNull(getData("EXTRACTDETAIL"));
                billclient = checkEmptyAndNull(getData("billable"));
                reason = checkEmptyAndNull(getData("reasonbillable"));
                billedMonth = getMonth(getData("billedmonth"));
                approvedBy = checkEmptyAndNull(getData("approvedby"));
                signedBy = checkEmptyAndNull(getData("SIGNEDOFFBY"));
                approvalDate = checkEmptyAndNull(getOnlyDate(
                        getData("approvedate"), true));
            }
        }

        if (!approvedBy.equalsIgnoreCase("N/A")) {
            approvedBy = this.getEngineerName(approvedBy);
        }
        if (!signedBy.equalsIgnoreCase("N/A")) {
            signedBy = this.getEngineerName(signedBy);
        }

        content += "<TR><TD>Business Analyst </TD><TD>:&nbsp; "
                + ba + "</TR>" + "<TR><TD>Waltham PM </TD><TD>:&nbsp; " + wpm
                + "</TR>" + "<TR><TD>Nepal PM </TD><TD>:&nbsp; " + npm
                + "</TR>" + "<TR><TD>Cluster Lead </TD><TD>:&nbsp; " + cl
                + "</TR>" + "<TR><TD>Details </TD><TD>:&nbsp; "
                + details + "</TR>"
                + "<TR><TD>Bill Client </TD><TD>:&nbsp; " + billclient
                + "</TR>";
        if (billclient.equalsIgnoreCase("No")) {
            content += "<TR><TD>Account Manager </TD><TD>:&nbsp; "
                    + amname + "</TR>" + "<TR><TD>Reason </TD><TD>:&nbsp; "
                    + reason + "</TR>";
        } else if (billclient.equalsIgnoreCase("Yes")) {
            content += "<TR><TD>Billed Month </TD><TD>:&nbsp; "
                    + billedMonth + "</TR>";
        }
        content += "<TR><TD>Approved by </TD><TD>:&nbsp; "
                + approvedBy
                + "</TR>"
                + "<TR><TD>Signed off by </TD><TD>:&nbsp; "
                + signedBy
                + "</TR>"
                + "<TR><TD>Approval Date </TD><TD>:&nbsp; "
                + approvalDate + "</TR>";

        return content;
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request Message (more info) with Request Code
    // "requestCode"
    // And infocode of "infoCode"
    public boolean getRequestMoreInfoDetails(String requestCode, String infoCode) {
        String sql = "select InfoID,RequestCode,ReplyTo,UserID AS user_id,PostedMsg,userName AS "
                + " user_name,TRUNC(PostedDate) AS PostedDate "
                + " from OAM_RM_REQUESTMOREINFO a, usr_Users b "
                + " where a.PostedBy=b.userid ";
        if (!infoCode.trim().equals("")) {
            sql += " AND (InfoID='" + infoCode + "' or ReplyTo='" + infoCode
                    + "') ";
        }
        if (!requestCode.trim().equals("")) {
            sql += " AND RequestCode='" + requestCode + "'";
        }

        sql += " ORDER BY InfoID,RequestCode ";
        return getList(sql, "Request More Info Details");
    }

    // Jan 16, 2003 - new
    // Gives details of a Project Request Message (more info) with Request Code
    // "requestCode"
    // And infocode of "infoCode" in HTML-FORMATTED string
    public String getFormattedRequestMoreInfoDetails(String requestCode,
            String infoCode) {
        String moreInfoDetail = "";
        if (getRequestMoreInfoDetails(requestCode, infoCode)) {
            moreInfoDetail = "<TABLE BORDER=1>"
                    + "<TR><TD><B>&nbsp;S.No.</B></TD>"
                    + "<TD><B>&nbsp;Message</B></TD>"
                    + "<TD><B>&nbsp;Posted By</B></TD>"
                    + "<TD><B>&nbsp;Posted On</B></TD></TR>";
            int countSNo = 0;
            String bgcolor = "";
            while (moveNext()) {
                countSNo++;
                bgcolor = "";
                if (countSNo == 1) {
                    bgcolor = " BGCOLOR=yellow";
                }

                moreInfoDetail += "<TR " + bgcolor + "><TD ALIGN=RIGHT> "
                        + countSNo + ".&nbsp;</TD>" + "<TD>&nbsp;"
                        + getData("PostedMsg") + "</TD>" + "<TD>&nbsp;"
                        + getData("user_name") + "</TD>" + "<TD ALIGN=RIGHT>"
                        + getData("PostedDate") + "&nbsp;</TD></TR>";
            }

            String sql = "select InfoID,RequestCode,ReplyTo,UserID AS user_id,PostedMsg,userName AS "
                    + " user_name,CONVERT(VARCHAR,DATEPART(mm,PostedDate))+'/'+CONVERT(VARCHAR,DATEPART(dd,PostedDate))+'/'+CONVERT(VARCHAR,DATEPART(yy,PostedDate)) AS PostedDate "
                    + " from OAM_RM_REQUESTMOREINFO a, usr_Users b "
                    + " where a.PostedBy=b.userid AND NOT (InfoID<>'"
                    + infoCode
                    + "' or ReplyTo<>'"
                    + infoCode
                    + "') "
                    + " AND RequestCode='"
                    + requestCode
                    + "'"
                    + " ORDER BY InfoID,RequestCode ";

            if (getList(sql, "Request More Info Details")) {
                moreInfoDetail += "<TR><TD COLSPAN=4><B>&nbsp;Other messages:"
                        + "</B></TD></TR>";
                countSNo = 0;
                while (moveNext()) {
                    countSNo++;
                    moreInfoDetail += "<TR " + bgcolor + "><TD ALIGN=RIGHT> "
                            + countSNo + ".&nbsp;</TD>" + "<TD>&nbsp;"
                            + getData("PostedMsg") + "</TD>" + "<TD>&nbsp;"
                            + getData("user_name") + "</TD>"
                            + "<TD ALIGN=RIGHT>" + getData("PostedDate")
                            + "&nbsp;</TD></TR>";
                }
            }
            moreInfoDetail += "</TABLE>";
        }
        return moreInfoDetail;
    }

    // Jan 16, 2003 - new
    public String getFormattedRequestMoreInfoDetails(String PostedBy,
            String RequestCode, String PostedMsg) {
        String moreInfoDetail = "<TABLE BORDER=1>"
                + "<TR><TD><B>&nbsp;S.No.</B></TD>"
                + "<TD><B>&nbsp;Message</B></TD>"
                + "<TD><B>&nbsp;Posted By</B></TD>"
                + "<TD><B>&nbsp;Posted On</B></TD></TR>"
                + "<TR BGCOLOR=yellow><TD ALIGN=RIGHT> 1.&nbsp;</TD>"
                + "<TD>&nbsp;"
                + PostedMsg
                + "</TD>"
                + "<TD>&nbsp;"
                + PostedBy
                + "</TD>"
                + "<TD ALIGN=RIGHT>"
                + getOnlyDate(
                        new java.sql.Date(System.currentTimeMillis())
                        .toString(),
                        true) + "&nbsp;</TD></TR> ";

        if (getRequestMoreInfoDetails(RequestCode, "")) {
            moreInfoDetail += "<TR><TD COLSPAN=4><B>&nbsp;Previous messages:"
                    + "</B></TD></TR>";
            int countSNo = 0;
            String bgcolor = "";
            while (moveNext()) {
                countSNo++;
                moreInfoDetail += "<TR " + bgcolor + "><TD ALIGN=RIGHT> "
                        + countSNo + ".&nbsp;</TD>" + "<TD>&nbsp;"
                        + getData("PostedMsg") + "</TD>" + "<TD>&nbsp;"
                        + getData("user_name") + "</TD>" + "<TD ALIGN=RIGHT>"
                        + getData("PostedDate") + "&nbsp;</TD></TR>";
            }
        }

        moreInfoDetail += "</TABLE>";
        return moreInfoDetail;
    }

    // Jan 16, 2003 - modified
    // Get list of users with OAMStatus=1
    public boolean getAlreadyAssignedList(String ProjID) {
        return getList(
                "select RequestCode,a.UserID,UserName AS user_name,email from OAM_RM_ASSIGNEE a, usr_Users b WHERE a.UserID=b.userid AND RequestCode= '"
                + ProjID + "'", "List Of Assignee");
    }

    // Jan 16, 2003 - modified
    // Get list of users with OAMStatus=1
    public String getAlreadyAssignedPeople(String ProjID) {
        String retStr = "";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("Select b.UserName AS User_Name from OAM_RM_ASSIGNEE a,usr_Users b where a.RequestCode= '"
                            + ProjID + "'  AND a.UserID= b.UserID");
            while (rs.next()) {
                retStr = retStr + rs.getString("User_Name") + "<br>";
            }
        } catch (SQLException sqex) {
        }

        return retStr;
    }

    public Hashtable getIDOfAlreadyAssignedPeople(String ProjectID) {
        Hashtable enggLists = new Hashtable();

        String tempRequestCode = "x";
        String tempEnggList = "x";
        String rsRequestCode = "";

        if (getList(
                "SELECT a.RequestCode,b.UserID FROM OAM_RM_REQUESTMANAGER a LEFT JOIN OAM_RM_ASSIGNEE b ON a.RequestCode = b.RequestCode WHERE parentRequestCode='"
                + ProjectID + "' ORDER BY a.RequestCode", "")) {
            while (moveNext()) {
                rsRequestCode = getData("RequestCode");
                if (!tempRequestCode.equals(rsRequestCode)) {
                    enggLists.put(tempRequestCode, tempEnggList);
                    tempEnggList = "";
                    tempRequestCode = rsRequestCode;
                }
                tempEnggList += getData("UserID") + ",";
            }

            enggLists.put(tempRequestCode, tempEnggList);
        }
        return enggLists;
    }

    public String getParentAssignee(String ProjID) {
        String retStr = "";
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery("Select * from OAM_RM_REQUESTMANAGER where RequestCode= '"
                            + ProjID + "'");
            if (rs.next()) {
                retStr = rs.getString("AssignedTo");
            }
        } catch (Exception sqex) {
        }

        return retStr;
    }
    
    public String getLeadName(String assigneeid) {
        String retStr = "";
        
        strSQL = "SELECT userid, USERNAME,email FROM USR_USERS WHERE userid = (  SELECT distinct leadid FROM oam_cr_user_lead_map WHERE userid = '"
                + assigneeid + "') ";
       
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery(strSQL);
            if (rs.next()) {
                retStr = rs.getString("USERNAME");
            }
        } catch (Exception sqex) {
        }

        return retStr;
    }
    
    public String getLeadEmail(String assigneeid) {
        String retStr = "";
        
        strSQL = "SELECT userid, USERNAME,email FROM USR_USERS WHERE userid = (  SELECT distinct leadid FROM oam_cr_user_lead_map WHERE userid = '"
                + assigneeid + "') ";
       
        try {
            Statement stmnt = myConn.createStatement();
            ResultSet rs = stmnt
                    .executeQuery(strSQL);
            if (rs.next()) {
                retStr = rs.getString("email");
            }
        } catch (Exception sqex) {
        }

        return retStr;
    }
    
    
    public void getLeadWithEmail(String assigneeid) {
        /**
         * extra query
         */
    	 strSQL = "SELECT userid, USERNAME,email FROM USR_USERS WHERE userid = (  SELECT distinct leadid FROM oam_cr_user_lead_map WHERE userid = '"
                 + assigneeid + "') ";
    	 

        System.out.println("email for other template >>>>>>>>>>>>>>>>>"
                + strSQL);
        getList(strSQL,
                "Getting email for Lead....");

    }
    

    public boolean getFieldValue(String ProjID) {
        return getList(
                "Select * from OAM_RM_REQUESTMANAGER where RequestCode= '"
                + ProjID + "'", "List Of Field Values");
    }

    /**
     * ****************** FOLLOW UPS
     * *************************************************
     */
    public void addUpdateFollowupRequest(String requestedBy,
            String requestCode, String followupCode, String newAction,
            String newTargetDate, String newActualDate, String newAssignee,
            String status, String isCompleted) {
        try {
            Statement stmnt = myConn.createStatement();
            stmnt.execute("UPDATE OAM_RM_REQUESTMANAGER SET isCompleted='n' WHERE RequestCode='"
                    + requestCode + "'");
            if (followupCode.equals("")) { // Adding new follow up code
                String newCode = "000" + (getMaxID() + 1);
                String sql = "INSERT INTO OAM_RM_REQUESTMANAGER (RequestCode,RequestingPerson,"
                        + "RequestDate,Requests,TargetCompDate,ActualCompDate,"
                        + "documentCount,parentRequestCode,StatusID,isCompleted) VALUES ('"
                        + newCode
                        + "','"
                        + requestedBy
                        + "',getDate(),'"
                        + newAction.replaceAll("'", "''").trim()
                        + "',"
                        + makeDateSQL(newTargetDate)
                        + ","
                        + makeDateSQL(newActualDate)
                        + ",0,'"
                        + requestCode
                        + "','" + status + "','n')";
                System.out.println("SQL1INSERT=" + sql);
                stmnt.execute(sql);

                StringTokenizer st = new StringTokenizer(newAssignee, ",");
                while (st.hasMoreTokens()) {
                    sql = "INSERT INTO OAM_RM_ASSIGNEE VALUES ('" + newCode
                            + "','" + st.nextToken().toString() + "')";
                    stmnt.execute(sql);
                }
            } else { // modifying existing follow up code

                String sql = "UPDATE OAM_RM_REQUESTMANAGER SET Requests = ?,  TargetCompDate = ? ,ActualCompDate = ? ,StatusID=? , isCompleted= ?  WHERE RequestCode = ? ";
                System.out.println("SQL1UPDATE=" + sql);
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                PreparedStatement preStmt = myConn.prepareStatement(sql);
                preStmt.setString(1, newAction.replaceAll("'", "''").trim());
                if (newTargetDate.equalsIgnoreCase("")) {
                    preStmt.setDate(2, null);
                } else {
                    preStmt.setDate(
                            2,
                            new java.sql.Date((sdf.parse(newTargetDate).getTime())));
                }
                if (newActualDate.equalsIgnoreCase("")) {
                    preStmt.setDate(3, null);
                } else {
                    preStmt.setDate(
                            3,
                            new java.sql.Date((sdf.parse(newActualDate).getTime())));
                }
                preStmt.setString(4, status);
                preStmt.setString(5, isCompleted);
                preStmt.setString(6, followupCode);
                preStmt.executeUpdate();

                System.out.println("update post:" + sql);
                sql = "DELETE OAM_RM_ASSIGNEE WHERE RequestCode = '"
                        + followupCode + "'";
                stmnt.execute(sql);
                StringTokenizer st = new StringTokenizer(newAssignee, ",");
                while (st.hasMoreTokens()) {
                    sql = "INSERT INTO OAM_RM_ASSIGNEE VALUES ('"
                            + followupCode + "','" + st.nextToken().toString()
                            + "')";
                    stmnt.execute(sql);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean getListOfFollowUps(String requestCode, String followupCode) {
        strSQL = "SELECT * FROM OAM_RM_REQUESTMANAGER WHERE parentRequestCode='"
                + requestCode + "'";
        if (!followupCode.equals("")) {
            strSQL += " AND RequestCode='" + followupCode + "'";
        }
        return getList(strSQL, "Follow ups");
    }

    /**
     * ****************** FOLLOW UPS
     * *************************************************
     */
    private String makeDateSQL(String date) {
        if (date.equals("")) {
            return "NULL";
        } else {
            return "'" + date + "'";
        }
    }

    public void cleanup() throws Exception {
    }

    public void request2Concept(String RequestCode) throws Exception {
        try {
            Statement stmnt = myConn.createStatement(
                    ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
            stmnt.execute("sp_Request2Concept '" + RequestCode + "'");
        } catch (SQLException sqlexception) {
            errorStr = "Request 2 Concept transfer error: " + sqlexception;
        }
    }

    /*
     * Function: getListOfRequestPhases Description: It returns the list of
     * request phases depending on the user and the status the request is in
     * now. Author: No idea Modified by Anjana Modification Date: July 31, 2006
     * Parameters: user, phase Output: boolean that says if the query was
     * successful
     */
    public boolean getListOfProjectStatus(String user, String phase)
            throws Exception {
        String[] requestStatus = {"Not Started", "Dropped", "Closed",
            "Assigned", "Completed", "In Progress", "Deferred",
            "QC Completed", "Pending Verification"};
        String temp = "Not Started";
        getList("SELECT StatusDesc FROM OAM_RM_REQUESTSTATUS where StatusID="
                + phase, "QueryBeanPM->getListOfProjectStatus");

        if (this.moveNext()) {
            String tempSubQuery = "";
            temp = this.getData("StatusDesc");

            if (user.equalsIgnoreCase("admin")) {
                if (temp.equalsIgnoreCase(requestStatus[0])
                        || temp.equalsIgnoreCase(requestStatus[5])) // if phase
                // is not
                // started
                // or in
                // progress
                { // it can be assigned, dropped or deferred //('0001', '0002',
                    // '0004', '0006', '0007')
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[0]
                            + "', '" + requestStatus[1] + "', '"
                            + requestStatus[3] + "', '" + requestStatus[5]
                            + "', '" + requestStatus[6] + "', '"
                            + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[3])) // if phase
                // is
                // assigned,
                // it can be
                // reassigned,
                // dropped,
                // deferred
                // or
                // completed
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[1]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[4] + "', '" + requestStatus[6]
                            + "', '" + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[1])) // if phase
                // is
                // dropped,
                // it can be
                // opened
                // (assigned)
                // or in
                // progress
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[3]
                            + "', '" + requestStatus[4] + "', '"
                            + requestStatus[1] + "', '" + requestStatus[8]
                            + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[4])
                        || temp.equalsIgnoreCase(requestStatus[7])) // if status
                // is
                // complete
                // or QC
                // complete,
                // it can be
                // closed,
                // QC
                // completed
                // or
                // reopened
                // (assigned)
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[3]
                            + "', '" + requestStatus[2] + "', '"
                            + requestStatus[1] + "', '" + requestStatus[4]
                            + "','" + requestStatus[7] + "', '"
                            + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[6])) // if status
                // is
                // deferred,
                // it can be
                // dropped
                // or
                // reopened
                // (assigned)
                // or in
                // progress
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[1]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[5] + "', '" + requestStatus[6]
                            + "', '" + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[2])) // if status
                // is
                // closed,
                // it can be
                // reopened
                // (assigned)
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[2]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[1] + "', '" + requestStatus[8]
                            + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[8])) // if status
                // is
                // pending
                // verification,
                // it can be
                // assigned,
                // dropped,
                // deferred
                // or
                // completed
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[1]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[5] + "', '" + requestStatus[6]
                            + "', '" + requestStatus[8] + "','"
                            + requestStatus[2] + "')";
                }
            } else if (user.equalsIgnoreCase("requestingperson")) {
                if (temp.equalsIgnoreCase(requestStatus[0])
                        || temp.equalsIgnoreCase(requestStatus[3])
                        || temp.equalsIgnoreCase(requestStatus[5])) // if phase
                // is not
                // started,
                // assigned
                // or in
                // progress
                {
                    // it can be dropped,closed
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[1]
                            + "', '" + temp + "','" + requestStatus[4] + "', '"
                            + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[1])) // if phase
                // is
                // dropped,
                // it can be
                // opened
                // (assigned)
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[1]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[4])
                        || temp.equalsIgnoreCase(requestStatus[7])) // if status
                // is
                // complete
                // or QC
                // complete,
                // it can be
                // closed,
                // QC
                // completed
                // or
                // reopened
                // (assigned)
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[2]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[4] + "', '" + requestStatus[7]
                            + "', '" + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[2])) // if status
                // is
                // closed,
                // it can be
                // reopened
                // (assigned)
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[2]
                            + "', '" + requestStatus[3] + "', '"
                            + requestStatus[8] + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[6])) // if status
                // is
                // deferred,
                // the same
                // status
                // only
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[6]
                            + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[8])) // if status
                // is
                // pending
                // verification,
                // the same
                // status
                // and
                // opened
                // only
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[1]
                            + "', '" + requestStatus[8] + "','"
                            + requestStatus[2] + "')";
                }
            }

            if (user.equalsIgnoreCase("assignee")) {

                if (temp.equalsIgnoreCase(requestStatus[3])
                        || temp.equalsIgnoreCase(requestStatus[5])) // if phase
                // is
                // assigned
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[4]
                            + "', '" + requestStatus[8] + "','" + temp + "')";// it
                    // can
                    // be
                    // deferred
                    // or
                    // assigned
                } else if (temp.equalsIgnoreCase(requestStatus[4])) // if phase
                // is
                // completed
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[4]
                            + "')";
                } /*
                 * else if (temp.equalsIgnoreCase(requestStatus[6])) //if phase
                 * is deferred // it can be assigned or completed {
                 * tempSubQuery=
                 * " AND StatusDesc in ('"+requestStatus[3]+"','"+requestStatus
                 * [4]+"','"+requestStatus[6]+"')"; }
                 */ else if (temp.equalsIgnoreCase(requestStatus[1])
                        || temp.equalsIgnoreCase(requestStatus[2])
                        || temp.equalsIgnoreCase(requestStatus[6])) // if status
                // is
                // dropped
                // or
                // closed,
                // the
                // assignee
                // can view
                // only that
                {
                    tempSubQuery = " AND StatusDesc in ('" + temp + "')";
                } else if (temp.equalsIgnoreCase(requestStatus[8])) // if status
                // is
                // pending
                // verification,
                // the same
                // status
                // only
                {
                    tempSubQuery = " AND StatusDesc in ('" + requestStatus[8]
                            + "')";
                }

            }

            return getList(
                    "SELECT DISTINCT StatusID,StatusDesc FROM OAM_RM_REQUESTSTATUS WHERE 1=1 "
                    + tempSubQuery + " ORDER BY StatusDesc",
                    "Project Status Description");
        }
        return false;
    }

    public boolean getListOfRequestPhases(String ProductID) throws Exception {
        return getList(
                "SELECT DISTINCT a.RequestPhaseID,a.RequestPhaseDesc,a.PhaseOrder FROM OAM_RM_REQUEST_PHASE a inner join OAM_RM_PRODUCTS b on a.phasetype=b.phasetype or a.phasetype is null where b.productid='"
                + ProductID + "' ORDER BY a.PhaseOrder ASC",
                "PhaseRequests");
    }

    public boolean getListOfRequestInjectedPhases(String ProductID)
            throws Exception {
        return getList(
                "SELECT DISTINCT a.RequestPhaseID,a.RequestPhaseDesc,a.PhaseOrder FROM OAM_RM_INJECTED_PHASE a inner join OAM_RM_PRODUCTS b on a.phasetype=b.phasetype or a.phasetype is null where b.productid='"
                + ProductID + "' ORDER BY a.PhaseOrder ASC",
                "InjectedPhaseRequests");
    }

    // @author Raju Thapa Shrestha,Mar 13,2008
    // A new method to get list of Request Severity is added.
    public boolean getListOfRequestSeverity() throws Exception {
        return getList(
                "SELECT DISTINCT SeverityID,SeverityDesc,SeverityOrder FROM OAM_RM_REQUEST_SEVERITY ORDER BY SeverityOrder ASC",
                "SeverityRequests");
    }

    // @author Raju Thapa Shrestha
    // A new method to get list of product areas is added.
    public boolean getListOfProductAreas() throws Exception {
        return getList(
                "SELECT DISTINCT ProductAreaID,ProductAreaDesc FROM OAM_RM_PRODUCT_AREA ORDER BY ProductAreaDesc",
                "ProductAreas");
    }

    public boolean getListOfProductAreas(String ProjectID) throws Exception {
        if (ProjectID.equals("all")) {
            ProjectID = "";
        }
        return getList(
                "SELECT   A.PRODUCTAREAID, \n"
                + "          A.PRODUCTAREADESC \n"
                + " FROM     OAM_RM_PRODUCT_AREA A \n"
                + " WHERE    A.PRODUCTAREAID IN (SELECT PROJECTAREAID \n"
                + "                                  FROM   OAM_RM_PROJECT_AREA_REL \n"
                + "                                  WHERE  PROJECTID = '"
                + ProjectID + "') \n"
                + " ORDER BY A.PRODUCTAREADESC \n",
                "Project Specific ProductArea");
    }

    /*
     * Function: count - Returns the count of records in a record set Author:
     * Anjana Shrestha Date: July 31, 2006 Parameter: None Return: integer count
     */
    public int count() {
        int count = 0;
        while (moveNext()) {
            // System.out.println ("The count is....." + count);
            count++;
        }
        try {
            logRS.beforeFirst();
        } catch (SQLException e) {
            System.out.println("Error on moving to record before first");
        }
        return count;

    }

    private boolean pullAll = true;
    private boolean pullAllProduct = false;

    public void setPullReceiversWithAll(boolean x) {
        pullAll = x;
    }

    public void setPullProductsAll(boolean x) {
        pullAllProduct = x;
    }

    public boolean getListOfMSGReceivers(String ClientID, String ProjectID,
            int MsgTriggeredFor, String PhaseOrRequest, String ProductID,
            String toCC) {

        strSQL = "SELECT DISTINCT a.UserID,b.UserName,b.Email,b.loginname "
                + " FROM OAM_RM_MESSAGE_RECEIVER a,usr_Users b "
                + " WHERE MsgTriggeredFor=" + MsgTriggeredFor
                + " AND a.UserID=b.UserID AND PhaseOrRequest='"
                + PhaseOrRequest + "'";
        String strSQL1 = "";
        /*
         * if(pullAll){ strSQL += "' AND PhaseRequestType IN ('','" +
         * PhaseRequestType + "')"; }
         */
        if (!ClientID.equals("")) {
            strSQL += " AND ClientID='" + ClientID + "'";
        }
        if (!toCC.equals("")) {
            strSQL += " AND ToCC='" + toCC + "'";
        }
        if (!ProductID.equals("") && !pullAllProduct) {
            strSQL += " AND ProductID='" + ProductID + "'";
        } else if (!ProductID.equals("") && pullAllProduct) {
            strSQL += " AND (ProductID='" + ProductID + "' OR ProductID='-1')";
        }

        if (!ProjectID.equals("")) {
            strSQL1 = strSQL + " AND PhaseRequestType='" + ProjectID + "'";
        } else {
            strSQL1 = strSQL;
        }

        if (!ProjectID.equals("-1") && pullAll) {
            strSQL = strSQL + " AND PhaseRequestType='-1' UNION " + strSQL1;
        } else if (ProjectID.equals("") && !pullAll) {
            strSQL = strSQL1 + " AND PhaseRequestType='-1'";
        } else {
            strSQL = strSQL1;
        }

        strSQL += " ORDER BY UserName";
        System.out.println("Getting " + toCC
                + " list for >>>>>>>>>>>>>>>>>>>>>" + strSQL);
        return getList(strSQL, "List of MSG Receivers");
    }

    public boolean getListOfMSGReceivers(String phaseId, String toCC) {
        strSQL = "" + "SELECT DISTINCT a.userid, "
                + "                b.username, " + "                b.email, "
                + "                b.loginname "
                + "FROM   oam_cr_message_receiver a, " + "       usr_users b "
                + "WHERE  a.userid = b.userid ";

        if (!phaseId.equals("")) {
            strSQL += "       AND a.phaseid = " + phaseId + " ";
        }
        if (!toCC.equals("")) {
            strSQL += "       AND a.tocc = '" + toCC + "' ";
        }
        strSQL += " ORDER  BY b.username";

        System.out.println("Query to get tos/ccs is >>>>>>>>>>>>>>>>" + strSQL);
        return getList(strSQL, "List of MSG Receivers");
    }

    public boolean getListOfAvailableReceivers(String ClientID,
            String ProductID, int MsgTriggeredFor, String PhaseOrRequest,
            String PhaseRequestType) {
        strSQL = "SELECT DISTINCT UserID,UserName,Email,loginname  FROM "
                + " usr_Users  " + " WHERE oamstatus=1 and UserID NOT IN ( "
                + " SELECT DISTINCT UserID FROM OAM_RM_MESSAGE_RECEIVER  "
                + " WHERE MsgTriggeredFor=" + MsgTriggeredFor
                + " AND PhaseOrRequest='" + PhaseOrRequest
                + "' AND PhaseRequestType='" + PhaseRequestType
                + "' AND ClientID='" + ClientID + "' AND ProductID='"
                + ProductID + "' ) ";
        // strSQL+="' AND PhaseRequestType='" + PhaseRequestType +"'";
        strSQL += "ORDER BY UserName ";
        // System.out.println(strSQL);
        return getList(strSQL, "List of MSG Receivers");
    }

    public boolean getListOfAvailableReceivers(String phaseId) {
        strSQL = "" + "SELECT DISTINCT userid, " + "                username, "
                + "                email, " + "                loginname "
                + "FROM   usr_users " + "WHERE  oamstatus = 1 ";
        if (phaseId != "-1" && phaseId != "") {
            strSQL += "       AND userid NOT IN (SELECT DISTINCT userid "
                    + "                          FROM   oam_cr_message_receiver "
                    + "                          WHERE  phaseid = " + phaseId
                    + ") ";
        }
        strSQL += "ORDER  BY username";
        System.out
                .println("Query to get list of available receivers is >>>>>>>>>>>>>>>>>>"
                        + strSQL);
        return getList(strSQL, "List of MSG Receivers");
    }

    public void deleteMSGReceivers(String ClientID, String ProductID,
            int MsgTriggeredFor, String PhaseOrRequest, String PhaseRequestType) {
        try {
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            strSQL = "DELETE OAM_RM_MESSAGE_RECEIVER WHERE MsgTriggeredFor="
                    + MsgTriggeredFor + " AND PhaseOrRequest='"
                    + PhaseOrRequest + "' AND PhaseRequestType='"
                    + PhaseRequestType + "' AND ClientID='" + ClientID
                    + "' AND ProductID=" + ProductID;
            System.out.println(strSQL);
            stmt.execute(strSQL);
        } catch (Exception e) {
            System.out
                    .println("\nError:[default-war/com/d2hs/soam/rm/queryBeamPM.java]->deleteMSGReceivers"
                            + "( "
                            + ClientID
                            + ","
                            + ProductID
                            + ","
                            + MsgTriggeredFor
                            + ","
                            + PhaseOrRequest
                            + ","
                            + PhaseRequestType + " " + ")<- " + strSQL);
            e.printStackTrace();
        }
    }

    public void deleteMSGReceivers(String phaseId) {
        try {
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            strSQL = "DELETE OAM_CR_MESSAGE_RECEIVER WHERE PHASEID = "
                    + phaseId + "";
            System.out.println("Delete receviers query >>>>>>>>>>>>>>>>"
                    + strSQL);
            stmt.execute(strSQL);
        } catch (Exception e) {
            System.out.println("Error while deleting receivers!!!!");
            e.printStackTrace();
        }
    }

    public void insertMSGReceivers(String ClientID, String ProductID,
            String userID, int MsgTriggeredFor, String PhaseOrRequest,
            String PhaseRequestType, String toCC) {
        try {
            StringTokenizer st = new StringTokenizer(userID, ",");
            String uid = "";
            strSQL = "INSERT INTO OAM_RM_MESSAGE_RECEIVER (ClientID,ProductID,UserID,MsgTriggeredFor,PhaseOrRequest,"
                    + "PhaseRequestType,ToCC) VALUES (?,?,?,?,?,?,?) ";
            PreparedStatement ps = myConn.prepareStatement(strSQL);
            while (st.hasMoreTokens()) {
                ps.setString(1, ClientID);
                ps.setString(2, ProductID);
                ps.setString(3, st.nextToken().toString());
                ps.setInt(4, MsgTriggeredFor);
                ps.setString(5, PhaseOrRequest);
                ps.setString(6, PhaseRequestType);
                ps.setString(7, toCC);
                ps.execute();
            }
        } catch (Exception e) {
            System.out
                    .println("\nError:[default-war/com/d2hs/soam/rm/queryBeamPM.java]->insertMSGReceivers"
                            + "( "
                            + ClientID
                            + ","
                            + ProductID
                            + ","
                            + MsgTriggeredFor
                            + ","
                            + PhaseOrRequest
                            + ","
                            + PhaseRequestType + " " + ")<- " + strSQL);
            e.printStackTrace();
        }
    }

    public void insertMSGReceivers(String userID, String phaseId, String toCC) {
        try {
            StringTokenizer st = new StringTokenizer(userID, ",");
            strSQL = "INSERT INTO OAM_CR_MESSAGE_RECEIVER (PHASEID,USERID,TOCC) VALUES(?,?,?) ";
            PreparedStatement ps = myConn.prepareStatement(strSQL);
            while (st.hasMoreTokens()) {
                ps.setString(1, phaseId);
                ps.setString(2, st.nextToken().toString());
                ps.setString(3, toCC);
                ps.execute();
            }
        } catch (Exception e) {
            System.out.println("Error Inserting message receivers!!!!!");
            e.printStackTrace();
        }
    }

    /**
     * gettting the Selected or avaliable client of given message group id
     *
     * @param messageGrpId
     * @return
     */
    public java.util.List getEmailMessaging(String condition, int messageGrpId) {
        java.util.List ls = new ArrayList();
        String userSql = "SELECT users.userid||':::'||users.username||'['||users.loginname||']'||':::'"
                + "|| Nvl2(msguser.messagingid, 'S', 'A')  strResult, users.userid"
                + " FROM    (SELECT username, "
                + "       loginname, "
                + "       userid "
                + " FROM   usr_users "
                + " WHERE  OAMStatus=1 "
                + " ORDER  BY username)  users "
                + " left join oam_cr_messaging_users msguser "
                + " ON users.userid = msguser.userid AND messagingid ="
                + messageGrpId + " order by Upper(username)";

        if (condition.equalsIgnoreCase("myUsers")) {
            strSQL = userSql;
        }
        try {
            if (myConn == null) {
                this.connectDB();
            }
            stmt = myConn.createStatement();
            myRS = stmt.executeQuery(strSQL);
            while (myRS.next()) {
                ls.add(myRS.getString("strResult"));
            }
        } catch (Exception e) {
            System.out
                    .println("Error getting users/clients for email manager ");
            e.printStackTrace();
        } finally {
            this.takeDown();
        }

        return ls;
    }

    public boolean getListOfMessageGroup() {
        return getList(
                "select messagingid,messagegrpname from OAM_CR_EMAIL_MESSAGING_DETAIL order by messagegrpname ",
                "MessageGroup on ICE");

    }

    public boolean getPhasesCheckBoxes(int messageGrpId) {

        /*
         * String query = "SELECT 	  c.phaseid, " + "       c.description, " +
         * "       d.isphaseinout " + "FROM   oam_cr_phases c " +
         * "       left join (SELECT phaseid, " +
         * "                         isphaseinout " +
         * "                  FROM   oam_cr_email_messaging " +
         * "                  WHERE  messagingid = '"+messageGrpId+"') d " +
         * "              ON c.phaseid = d.phaseid" + " ORDER BY c.phasename, "
         * + " isphaseinout";
         */

 /*
         * String query = "" +
         * "SELECT a.phaseid,a.description,b.isphaseinout,c.templateid,d.issuetypeid,e.issuetypename FROM "
         * + "oam_cr_phases a " + "left join (SELECT phaseid, " +
         * "                         isphaseinout " +
         * "                  FROM   oam_cr_email_messaging " +
         * "                  WHERE  messagingid = '"+messageGrpId+"') b " +
         * "              ON a.phaseid = b.phaseid " +
         * "left join oam_cr_template_phases c " + "ON a.phaseid=c.phaseid " +
         * "left join oam_cr_template_issuetype d " +
         * "ON c.templateid = d.templateid " + "left join oam_cr_issuetype e " +
         * "ON d.issuetypeid = e.issuetypeid " +
         * "ORDER BY e.issuetypename,phaseid";
         */
        String query = ""
                + "SELECT a.phaseid, "
                + "       a.description, "
                + "       b.isphaseinout, "
                + "       c.templateid, "
                + "       d.issuetypeid, "
                + "       e.issuetypename "
                + "FROM   oam_cr_phases a "
                + "       left join oam_cr_template_phases c "
                + "              ON a.phaseid = c.phaseid "
                + "       left join (SELECT phaseid, "
                + "                         templateid, "
                + "                         isphaseinout "
                + "                  FROM   oam_cr_email_messaging "
                + "                  WHERE  messagingid = '"
                + messageGrpId
                + "') b "
                + "              ON a.phaseid = b.phaseid AND c.templateid=b.templateid "
                + " " + "       left join oam_cr_template_issuetype d "
                + "              ON c.templateid = d.templateid "
                + "       left join oam_cr_issuetype e "
                + "              ON d.issuetypeid = e.issuetypeid "
                + "ORDER  BY e.issuetypename, " + "          phaseid";

        System.out.println("Getting Phases Check Box query >>>>>>>>>>>>>> "
                + query);
        return getList(query, "Phase CheckBox on Message Group");

    }

    // Sets the recordset with list of Phases
    public boolean getListOfPhases() {
        return getList(
                "select p.PhaseCode,p.PhaseDesc,p.logPhaseOrder from OAM_PM_PHASES p ORDER BY p.PhaseOrder ASC ",
                "Phases");
    }

    public String addEmailManager(String[] phaseInOut, String[] phaseCode,
            String[] templateCode, String[] issueTypeCode, int messageGrpId) {
        String isInserted = "0";
        if (myConn == null) {
            try {
                this.connectDB();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        try {

            StringBuffer phasein = new StringBuffer("");
            StringBuffer phaseco = new StringBuffer("");
            StringBuffer templateco = new StringBuffer("");
            StringBuffer issuetypeco = new StringBuffer("");

            for (int i = 0; i < phaseInOut.length; i++) {
                phasein.append(phaseInOut[i]);
                phasein.append(',');
                phaseco.append(phaseCode[i]);
                phaseco.append(',');
                templateco.append(templateCode[i]);
                templateco.append(',');
                issuetypeco.append(issueTypeCode[i]);
                issuetypeco.append(',');
            }
            String phaseInOutString = phasein.toString();
            String phaseCodeString = phaseco.toString();
            String templateCodeString = templateco.toString();
            String issueTypeCodeString = issuetypeco.toString();

            System.out.println("phaseInOutString >>>>>>>> " + phaseInOutString);
            System.out.println("phaseCodeString >>>>>>>> " + phaseCodeString);
            System.out.println("templateCodeString >>>>>>>> "
                    + templateCodeString);
            System.out.println("issueTypeCodeString >>>>>>>> "
                    + issueTypeCodeString);

            java.sql.CallableStatement mystmt = myConn
                    .prepareCall("{call sp_AddEditEmailMessage(?,?,?,?,?)}");
            mystmt.setString(1, phaseInOutString);
            mystmt.setString(2, phaseCodeString);
            mystmt.setString(3, templateCodeString);
            mystmt.setString(4, issueTypeCodeString);
            mystmt.setInt(5, messageGrpId);
            int check = mystmt.executeUpdate();
            mystmt.close();
            // if(check==1)
            isInserted = "OK";

        } catch (SQLException sqlexception) {
            System.out.println("\nError:AddEditEmail Message" + sqlexception);
            errorStr = "Add Edit Email Manager: " + sqlexception;
        }
        return isInserted;
    }

    public boolean checkDubMessageGrp(String messagmessageGrpName,
            String messagGrpId) {
        boolean duplicate = false;
        try {
            ResultSet tempRS;
            if (myConn == null) {
                this.connectDB();
            }
            String strSql = "";
            if (messagGrpId.equals("0")) {
                strSql = "select count(*) count from OAM_cr_EMAIL_MESSAGING_DETAIL "
                        + " where lower(messagegrpname) like lower('"
                        + messagmessageGrpName + "')";
            }
            if (!messagGrpId.equals("0")) {
                strSql = "select count(*) count from OAM_cr_EMAIL_MESSAGING_DETAIL "
                        + " where ( messagingid !='"
                        + messagGrpId
                        + "'"
                        + " and lower(messagegrpname) = lower('"
                        + messagmessageGrpName + "')) ";
            }
            Statement stmt = myConn.createStatement();
            tempRS = stmt.executeQuery(strSql);
            int count = 0;
            while (tempRS.next()) {
                count = Integer.parseInt(tempRS.getString("count"));
            }
            if (count > 0) {
                duplicate = true;
            }
        } catch (Exception e) {
            System.out
                    .println("\nError[queryBean.java]:Check Dublicate MessageGroup->1<- "
                            + e);
        } finally {
            this.takeDown();
        }
        return duplicate;
    }

    public String addMessageGrp(int messageGrpId,
            String[] users, String messageGrpName, String userId,
            List previouslyCheckedUsers) {

        String isInserted = "0";
        String userID;
        if (myConn == null) {
            try {
                this.connectDB();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            StringBuffer user = new StringBuffer("");

            if (users != null) {
                for (int i = 0; i < users.length; i++) {
                    user.append(users[i]);
                    user.append(',');

                }
            }
            if (messageGrpId != 0) {
                Statement stmt = myConn.createStatement();

                for (int i = 0; i < previouslyCheckedUsers.size(); i++) {
                    userID = (String) previouslyCheckedUsers.get(i);
                    strSQL = " delete oam_cr_messaging_users where  messagingid = '"
                            + messageGrpId + "'  and userID='" + userID + "'";
                    stmt.executeUpdate(strSQL);
                }
            }

            String usersString = user.toString();
            // System.out.println("ClientString:"+clientsString);
            // System.out.println("usersString:"+usersString);

            // ArrayDescriptor arrDesc =
            // ArrayDescriptor.createDescriptor("T_VARCHAR2_ARRAY", myConn);
            // java.sql.Array sqlArrayClients = new oracle.sql.ARRAY(arrDesc,
            // myConn, clients);
            // java.sql.Array sqlArrayUsers = new oracle.sql.ARRAY(arrDesc,
            // myConn, users);
            // {call sp_AddEditEmailMessage(?,?,?)}
            java.sql.CallableStatement mystmt = myConn
                    .prepareCall("{call sp_AddEditMessGrp(?,?,?,?)}");
            mystmt.setInt(1, messageGrpId);
            mystmt.setString(2, usersString);
            mystmt.setString(3, messageGrpName);
            mystmt.setString(4, userId);
            int check = mystmt.executeUpdate();
            mystmt.close();
            // if(check==1)
            isInserted = "OK";
        } catch (SQLException sqlexception) {
            System.out
                    .println("\nError:[queryBean.java]-><-Add Edit messageGrp"
                            + sqlexception);
            errorStr = "Add Edit Message Group: " + sqlexception;
        }
        return isInserted;
    }

    /**
     * Getting the mail recipents form messaging group
     *
     * @param fromPhaseId
     * @param toPhaseId
     * @param clientd
     */
    public void getEmailRecipentsFromMsgGrp(String fromPhaseId,
            String toPhaseId, String requestTypeId, String clientId) {
        /**
         * extra query
         */
        strSQL = ""
                + "SELECT DISTINCT usrs.username, "
                + "                usrs.email, "
                + "                msgphase.phaseid "
                + "FROM   oam_cr_messaging_clients msgcl "
                + "       left join oam_cr_messaging_users msgusr "
                + "              ON msgcl.messagingid = msgusr.messagingid "
                + "       left join oam_cr_email_messaging msgphase "
                + "              ON msgcl.messagingid = msgphase.messagingid "
                + "       inner join (SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   usr_users "
                + "                   WHERE   "
                + "                           oamstatus = 1 "
                + "                   UNION "
                + "                   SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   user_email_group "
                + "                   ORDER  BY username) usrs "
                + "               ON usrs.userid = msgusr.userid "
                + "WHERE  msgcl.clientid = '"
                + clientId
                + "' AND msgphase.issuetypeid = '"
                + requestTypeId
                + "' "
                + "       AND ( ( msgphase.phaseid = '"
                + fromPhaseId
                + "' "
                + "               AND Lower(isphaseinout) IN ( 'out', 'both' ) ) "
                + "              OR ( msgphase.phaseid = '"
                + toPhaseId
                + "' "
                + "                   AND Lower(isphaseinout) IN ( 'in', 'both' ) ) )";

        System.out.println("email template >>>>>>>>>>>>>>>>>" + strSQL);
        getList(strSQL, "Getting the mail recipents form messaging group");

    }

    public void getEmailRecipentsFromMsgGrpOAMPM(String clientId) {
        /**
         * extra query
         */
        strSQL = "" + "SELECT DISTINCT usrs.username, "
                + "                usrs.email "
                + "FROM   oam_pm_messaging_clients msgcl "
                + "       left join oam_cr_messaging_users msgusr "
                + "              ON msgcl.messagingid = msgusr.messagingid "
                + "       left join oam_cr_email_messaging msgphase "
                + "              ON msgcl.messagingid = msgphase.messagingid "
                + "       inner join (SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   usr_users "
                + "                   WHERE   "
                + "                           oamstatus = 1 "
                + "                   UNION "
                + "                   SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   requestmanager.user_email_group "
                + "                   ORDER  BY username) usrs "
                + "               ON usrs.userid = msgusr.userid "
                + "WHERE  msgcl.clientid = '" + clientId + "'";

        System.out.println("email change request template >>>>>>>>>>>>>>>>>"
                + strSQL);
        getList(strSQL, "Getting the mail recipents form messaging group");

    }

    public void getEmailRecipentsFromMsgGrpOAMPMType(String message) {
        /**
         * extra query
         */
        strSQL = "" + "SELECT DISTINCT usrs.username, "
                + "                usrs.email "
                + "FROM  oam_cr_email_messaging_detail msgdetail left join  oam_cr_messaging_users msgusr "
                + "              ON msgdetail.messagingid = msgusr.messagingid "
                + "       inner join (SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   usr_users "
                + "                   WHERE   "
                + "                           oamstatus = 1 "
                + "                   ORDER  BY username) usrs "
                + "               ON usrs.userid = msgusr.userid "
                + "WHERE  msgdetail.messagegrpname = 'ICE-" + message.trim()
                + "'";

        System.out.println("email for other template >>>>>>>>>>>>>>>>>"
                + strSQL);
        getList(strSQL,
                "Getting the mail recipents form messaging group for other");

    }

    public void getEmailRecipentsFromMsgGrpPayor() {
        /**
         * extra query
         */
        strSQL = "" + "SELECT DISTINCT usrs.username, "
                + "                usrs.email, "
                + "                msgphase.phaseid "
                + "FROM   oam_cr_messaging_clients msgcl "
                + "       left join oam_cr_messaging_users msgusr "
                + "              ON msgcl.messagingid = msgusr.messagingid "
                + "       left join oam_cr_email_messaging msgphase "
                + "              ON msgcl.messagingid = msgphase.messagingid "
                + "       inner join (SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   usr_users "
                + "                   WHERE  oamusertypecode IS NOT NULL "
                + "                          AND oamstatus = 1 "
                + "                   UNION "
                + "                   SELECT username, "
                + "                          loginname, "
                + "                          userid, "
                + "                          email "
                + "                   FROM   user_email_group "
                + "                   ORDER  BY username) usrs "
                + "               ON usrs.userid = msgusr.userid "
                + " WHERE  msgphase.issuetypeid = '2' ";

        System.out.println("email for payor template >>>>>>>>>>>>>>>>>"
                + strSQL);
        getList(strSQL,
                "Getting the mail recipents for payor form messaging group");

    }

    // Changed by:Raju Thapa Shrestha,Jan 28,2008
    // Changes :New parameters
    // ProductID,ProductModule,ProductArea,PhaseInject,EstimatedHours,ActualHoursLastUpdatedDate,VersionFixed
    // are added.
    // Changes : Severity is added,Mar 13,2008
    // Changes : Impact is added,Mar 14,2008
    public void archiveRequest(String RequestCode, String uid) {
        strSQL = "INSERT INTO OAM_RM_ARCHIVE"
                + "( RequestCode,RequestTypeID,RequestingPerson,StatusID,AssignedTo,"
                + "DetectedVersion,ClientID,RequestDate,Requests,"
                + "ActionTaken,TargetCompDate,ActualCompDate,RequestPriority,"
                + "isCompleted,documentCount,parentRequestCode,ExpectedCompDate,PhaseDetected,UpdatedBy,UpdatedDate,DevCompDate,"
                + "ModuleID,PhaseInject,ProductArea,EstimatedHours,ActualHours,ProductID,VersionFixed,SourceID,Severity,Impact,requesttitle)"
                + "( SELECT RequestCode,RequestTypeID,RequestingPerson,StatusID,AssignedTo,"
                + "DetectedVersion,ClientID,RequestDate,Requests,"
                + "ActionTaken,TargetCompDate,ActualCompDate,RequestPriority,"
                + "isCompleted,documentCount,parentRequestCode,ExpectedCompDate,PhaseDetected,'"
                + uid
                + "',getDate(),DevCompDate,"
                + "ModuleID,PhaseInject,ProductArea,EstimatedHours,ActualHours,ProductID,FixedInVersion,SourceID,Severity,Impact,requesttitle"
                + " FROM OAM_RM_REQUESTMANAGER WHERE RequestCode='"
                + RequestCode + "')";
        try {
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            stmt.execute(strSQL);
        } catch (Exception e) {
        }
    }

    public boolean getListOfPreRequestType() throws Exception {
        return getList(
                "SELECT DISTINCT RequestTypeID,RequestTypeDesc FROM OAM_RM_REQUEST_TYPES where RequestTypeID not in (select RequestTypeID from  tbl_RequestPreAssignmentParameters where RequestTypeID is not null) ORDER BY RequestTypeDesc",
                "Request Type");
    }

    public boolean getRequestPreAssigned() {
        strSQL = "SELECT a.PKField,a.ActionTaken,a.ThresholdDays,b.Requesttypedesc,c.UserName FROM tbl_RequestPreAssignmentParameters a,OAM_RM_REQUEST_TYPES b,usr_Users c WHERE a.RequestTypeID=b.RequestTypeID and a.AssignedTo=c.Userid ORDER BY a.RequestTypeID";
        return getList(strSQL, "Request PreAssigned");
    }

    public boolean getRequestPreAssigned(String id) {
        strSQL = "SELECT * FROM tbl_RequestPreAssignmentParameters WHERE PKField="
                + id + " ORDER BY RequestTypeID";
        return getList(strSQL, "Request PreAssigned");
    }

    public void addEditDeleteRequestPreAssigned(String PKField,
            String RequestTypeCode, String AssignedTo, String RequestStatus,
            String ActionTaken, String ThresholdDays, String Status) {
        try {
            Statement stmnt = myConn.createStatement();

            if (Status.equals("I")) { // Adding new

                String sql = "INSERT INTO tbl_RequestPreAssignmentParameters (RequestTypeID,AssignedTo,RequestStatus,ActionTaken,ThresholdDays) values ("
                        + SQLEncode(RequestTypeCode)
                        + ","
                        + SQLEncode(AssignedTo)
                        + ","
                        + SQLEncode(RequestStatus)
                        + ","
                        + SQLEncode(ActionTaken)
                        + ","
                        + SQLEncode(ThresholdDays) + ")";
                stmnt.execute(sql);
            } else { // modifying existing
                String sql = "UPDATE tbl_RequestPreAssignmentParameters SET "
                        + "RequestTypeID=" + SQLEncode(RequestTypeCode) + ","
                        + "AssignedTo=" + SQLEncode(AssignedTo) + ","
                        + "RequestStatus=" + SQLEncode(RequestStatus) + ","
                        + "ActionTaken=" + SQLEncode(ActionTaken) + ","
                        + "ThresholdDays=" + SQLEncode(ThresholdDays)
                        + " WHERE PKField =" + PKField;
                stmnt.execute(sql);

            }
        } catch (Exception e) {
        }
    }

    public String DeleteRequestPreAssigned(String id) throws Exception {
        String isInserted = "0";
        try {
            Statement stmnt = myConn.createStatement();
            String sqlString = "DELETE tbl_RequestPreAssignmentParameters WHERE PKfield="
                    + id;
            stmnt.execute(sqlString);
        } catch (SQLException sqlexception) {
            errorStr = "Dlete Request Pre Assigned error  : " + sqlexception;
        }
        return isInserted;
    }

    public boolean getListOfSource() {
        return getList(
                "SELECT * FROM OAM_RM_REQUEST_SOURCE ORDER BY SourceID desc",
                "Source");
    }

    public void insertProjectRequestDetail(String RequestID, String SourceID,
            String RequestTitle, String Benefits,
            String Assumptions_Dependencies, String Status) {
        String sql = "";
        /*
         * if(Status.equals("I")){ //Adding new sql =
         * "INSERT INTO OAM_RM_DETAIL (RequestCode,SourceID,RequestTitle, Benefits,Assumptions_Dependencies) values ('"
         * + RequestID + "'," + SourceID + "," + SQLEncode(RequestTitle) + "," +
         * SQLEncode(Benefits) + "," + SQLEncode(Assumptions_Dependencies) +
         * ")";
         * 
         * 
         * } else
         */
        { // modifying existing
            sql = "UPDATE OAM_RM_REQUESTMANAGER SET "
                    + // "SourceID="+ SQLEncode(SourceID) + "," +
                    "ActionTaken=" + SQLEncode(Benefits) + ""
                    + // "Assumptions_Dependencies="+
                    // SQLEncode(Assumptions_Dependencies) + "" +
                    " WHERE RequestCode ='" + RequestID + "'";

        }

        // System.out.println(sql);
        strSQL = sql;
        try {

            Statement stmnt = myConn.createStatement();
            stmnt.execute(strSQL);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public boolean listRequestDocument(String RequestCode) {

        strSQL = "SELECT p.RequestCode,r.RequestTypeDesc,p.RequestDate,p.RequestingPerson, "
                + "rp.UserName as RequestingPersonDesc,rp.email as ReqPersonEmail,c.ClientName,p.Requests, "
                + "p.ActionTaken,s.StatusDesc, e.UserName AS User_Name,e.email as enggEmail, "
                + "v.VersionDesc, p.TargetCompDate,p.ActualCompDate,p.RequestPriority, "
                + "e.UserID AS EnggID,p.isCompleted, nvl(y.documentCount,0) AS documentCount, "
                + "p.ExpectedCompDate,x.RequestPhaseDesc,p.RequestTitle,p.actiontaken benefits,"
                + "so.source,ud.DateUpdated,ud.ApprovedBy FROM OAM_RM_REQUESTMANAGER p "
                + "LEFT JOIN usr_Users e ON p.assignedTo=e.UserID "
                + "LEFT JOIN OAM_RM_PRODUCTVERSION v ON p.DetectedVersion=v.VersionID "
                + "LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.StatusID=s.StatusID "
                + "LEFT JOIN OAM_RM_REQUEST_TYPES r ON p.RequestTypeID=r.RequestTypeID "
                + "LEFT JOIN usr_Users rp ON p.RequestingPerson=rp.UserID "
                + "LEFT JOIN OAM_RM_CLIENTS c ON p.ClientID=c.clientID "
                + "LEFT JOIN OAM_RM_REQUEST_PHASE x ON x.RequestPhaseID=p.PhaseDetected "
                + "LEFT JOIN tbl_source so ON so.id=rd.sourcecode "
                + "LEFT JOIN (SELECT RequestCode,COUNT(*) AS documentCount "
                + "FROM OAM_RM_MOREDOCUMENTS1 GROUP BY RequestCode) y "
                + "ON y.RequestCode=p.RequestCode "
                + "LEFT JOIN (SELECT RequestCode,UserName As ApprovedBy,MAX(UpdatedDate) AS DateUpdated FROM OAM_RM_ARCHIVE a LEFT JOIN usr_Users b ON a.UpdatedBy=b.UserID GROUP BY RequestCode,UserName) ud ON ud.RequestCode=p.RequestCode "
                + "WHERE p.requestcode='" + RequestCode + "'  "
                + // "AND s.StatusDesc NOT IN ('Completed','Dropped','Pending') "+
                "AND p.parentRequestCode IS NULL ORDER BY p.PKSource DESC ";
        return getList(strSQL, "Request Document");
    }

    public String getEngineerName(String EngineerID) {
        String sqlString = "SELECT UserName FROM usr_Users WHERE UserID='"
                + EngineerID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("UserName");
            }
        }
        return retValue;
    }

    /*
     * added by Ram Gautam,12 Sept, 2012 Description: get the usernamd and Email
     * address of given Group Email Id
     */
    public String getGroupEmailDetail(String GrpEmailId) {
        String sqlString = "select  USERNAME||':::' ||EMAIL GrpEmail FROM user_email_group WHERE UserID='"
                + GrpEmailId + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("GrpEmail");
            }
        }
        return retValue;
    }

    public String getEngineerEmail(String EngineerID) {
        String sqlString = "SELECT Email FROM usr_Users WHERE UserID='"
                + EngineerID + "'";
        String retValue = "N/A";
        if (getList(sqlString, "")) {
            while (moveNext()) {
                retValue = getData("Email");
            }
        }
        return retValue;
    }

    /*
     * public void takeDown() { try { if (conn!= null) conn.close(); } catch
     * (Exception e) { System.out.println
     * ("Error in closing connection conn in QueryBeanPM.java");
     * e.printStackTrace(); }
     * 
     * super.takeDown();
     * 
     * }
     */
    public boolean checkLabelStatus(String requestCode, String ClientID) {
        return checkLabelStatus(requestCode, ClientID, "");
    }

    public boolean checkLabelStatus(String requestCode, String ClientID,
            String ProductID) {
        boolean result = false;

        strSQL = "select a.* , CASE WHEN b.LABELID IS NULL THEN '  ' ELSE 'CHECKED' END   IS_CHECKED"
                + " from OAM_RM_LABEL_NAME a left join OAM_RM_REQUEST_LABELS b"
                + " on a.LABELID = b.LABELID"
                + " and b.RequestCode='"
                + requestCode + "' WHERE 1=1";
        if (!ClientID.equalsIgnoreCase("")) {
            strSQL += " and a.ClientID='" + ClientID + "' ";
        }
        if (!ProductID.equalsIgnoreCase("")) {
            strSQL += " and a.ProductID='" + ProductID + "' ";
        }
        strSQL += " ORDER BY a.LabelName";
        try {
            System.out.println(strSQL);
            Statement stmt = myConn.createStatement(
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            logRS = stmt.executeQuery(strSQL);

            result = true;
        } catch (Exception e) {
            System.out
                    .println("\nError:[default-war/d2Systems/oam/queryBeanPM.java]->21<-"
                            + e);
            e.printStackTrace();
            System.out.print("error" + e.getMessage());
        }
        return result;
    }

    public boolean getImageFiles(String requestId) {
        String sqlString = "select DOCUMENTCODE, REQUESTCODE, UPLOADEDDOCNAME  from OAM_RM_MOREDOCUMENTS1 "
                + " where REQUESTCODE='"
                + requestId
                + "' AND ( upper(UPLOADEDDOCNAME) like '%.PNG' or "
                + " upper(UPLOADEDDOCNAME) like '%.JPG' OR upper(UPLOADEDDOCNAME) like '%.JPEG' OR "
                + " upper(UPLOADEDDOCNAME) like '%.GIF' OR upper(UPLOADEDDOCNAME) like '%.BMP')"
                + " order by uploadedon desc"; // bmp, tga

        // System.out.println(sqlString);
        List l = new ArrayList();
        if (getList(sqlString, "")) {
            return true;
        } else {
            return false;
        }
        // return (String[]) l.toArray(new String[l.size()]);
    }

    public void moveBeforeFirst() {
        try {
            logRS.beforeFirst();
        } catch (SQLException ex) {
            System.out
                    .println("\nError:[default-war/d2Systems/oam/connectionBean.java]->Moving before first<-"
                            + ex);
        }
    }

    public boolean getChangesonRequestDetails(String RequestCode) {
        String sql = " SELECT * FROM ( \n"
                + "SELECT \n"
                + " CASE WHEN p.REQUESTTYPEID!=Q.REQUESTTYPEID OR (p.REQUESTTYPEID IS NULL AND q.REQUESTTYPEID IS NOT NULL) OR (p.REQUESTTYPEID IS NOT NULL AND q.REQUESTTYPEID IS NULL) THEN 1 END AS REQUESTTYPEID, \n"
                + " CASE WHEN p.REQUESTINGPERSON!=Q.REQUESTINGPERSON OR (p.REQUESTINGPERSON IS NULL AND q.REQUESTINGPERSON IS NOT NULL) OR (p.REQUESTINGPERSON IS NOT NULL AND q.REQUESTINGPERSON IS NULL) THEN 1 END AS REQUESTINGPERSON, \n"
                + " CASE WHEN p.STATUSID!=Q.STATUSID OR (p.STATUSID IS NULL AND q.STATUSID IS NOT NULL) OR (p.STATUSID IS NOT NULL AND q.STATUSID IS NULL) THEN 1 END AS STATUSID, \n"
                + " CASE WHEN p.ASSIGNEDTO!=Q.ASSIGNEDTO OR (p.ASSIGNEDTO IS NULL AND q.ASSIGNEDTO IS NOT NULL) OR (p.ASSIGNEDTO IS NOT NULL AND q.ASSIGNEDTO IS NULL) THEN 1 END AS ASSIGNEDTO, \n"
                + " CASE WHEN p.CLIENTID!=Q.CLIENTID OR (p.CLIENTID IS NULL AND q.CLIENTID IS NOT NULL) OR (p.CLIENTID IS NOT NULL AND q.CLIENTID IS NULL) THEN 1 END AS CLIENTID, \n"
                + " CASE WHEN p.REQUESTS not like q.REQUESTS OR (p.REQUESTS IS NULL AND q.REQUESTS IS NOT NULL) OR (p.REQUESTS IS NOT NULL AND q.REQUESTS IS NULL) THEN 1 END AS REQUESTS, \n"
                + " CASE WHEN p.ACTIONTAKEN not like Q.ACTIONTAKEN OR (p.ACTIONTAKEN IS NULL AND q.ACTIONTAKEN IS NOT NULL) OR (p.ACTIONTAKEN IS NOT NULL AND q.ACTIONTAKEN IS NULL) THEN 1 END AS ACTIONTAKEN, \n"
                + " CASE WHEN p.TARGETCOMPDATE!=Q.TARGETCOMPDATE OR (p.TARGETCOMPDATE IS NULL AND q.TARGETCOMPDATE IS NOT NULL) OR (p.TARGETCOMPDATE IS NOT NULL AND q.TARGETCOMPDATE IS NULL) THEN 1 END AS TARGETCOMPDATE, \n"
                + " CASE WHEN p.ACTUALCOMPDATE!=Q.ACTUALCOMPDATE OR (p.ACTUALCOMPDATE IS NULL AND q.ACTUALCOMPDATE IS NOT NULL) OR (p.ACTUALCOMPDATE IS NOT NULL AND q.ACTUALCOMPDATE IS NULL) THEN 1 END AS ACTUALCOMPDATE, \n"
                + " CASE WHEN p.REQUESTPRIORITY!=Q.REQUESTPRIORITY OR (p.REQUESTPRIORITY IS NULL AND q.REQUESTPRIORITY IS NOT NULL) OR (p.REQUESTPRIORITY IS NOT NULL AND q.REQUESTPRIORITY IS NULL) THEN 1 END AS REQUESTPRIORITY, \n"
                + " CASE WHEN p.DOCUMENTCOUNT!=Q.DOCUMENTCOUNT OR (p.DOCUMENTCOUNT IS NULL AND q.DOCUMENTCOUNT IS NOT NULL) OR (p.DOCUMENTCOUNT IS NOT NULL AND q.DOCUMENTCOUNT IS NULL) THEN 1 END AS DOCUMENTCOUNT, \n"
                + " CASE WHEN p.EXPECTEDCOMPDATE!=Q.EXPECTEDCOMPDATE OR (p.EXPECTEDCOMPDATE IS NULL AND q.EXPECTEDCOMPDATE IS NOT NULL) OR (p.EXPECTEDCOMPDATE IS NOT NULL AND q.EXPECTEDCOMPDATE IS NULL) THEN 1 END AS EXPECTEDCOMPDATE, \n"
                + " CASE WHEN p.SEVERITYID!=Q.SEVERITYID OR (p.SEVERITYID IS NULL AND q.SEVERITYID IS NOT NULL) OR (p.SEVERITYID IS NOT NULL AND q.SEVERITYID IS NULL) THEN 1 END AS SEVERITYID, \n"
                + " CASE WHEN p.IMPACT!=Q.IMPACT OR (p.IMPACT IS NULL AND q.IMPACT IS NOT NULL) OR (p.IMPACT IS NOT NULL AND q.IMPACT IS NULL) THEN 1 END AS IMPACT, \n"
                + " CASE WHEN p.ACTUALHOURS!=Q.ACTUALHOURS OR (p.ACTUALHOURS IS NULL AND q.ACTUALHOURS IS NOT NULL) OR (p.ACTUALHOURS IS NOT NULL AND q.ACTUALHOURS IS NULL) THEN 1 END AS ACTUALHOURS, \n"
                + " CASE WHEN p.ESTIMATEDHOURS!=Q.ESTIMATEDHOURS OR (p.ESTIMATEDHOURS IS NULL AND q.ESTIMATEDHOURS IS NOT NULL) OR (p.ESTIMATEDHOURS IS NOT NULL AND q.ESTIMATEDHOURS IS NULL) THEN 1 END AS ESTIMATEDHOURS, \n"
                + " CASE WHEN p.PHASEINJECT!=Q.PHASEINJECT OR (p.PHASEINJECT IS NULL AND q.PHASEINJECT IS NOT NULL) OR (p.PHASEINJECT IS NOT NULL AND q.PHASEINJECT IS NULL) THEN 1 END AS PHASEINJECT, \n"
                + " CASE WHEN p.PRODUCTAREA!=Q.PRODUCTAREA OR (p.PRODUCTAREA IS NULL AND q.PRODUCTAREA IS NOT NULL) OR (p.PRODUCTAREA IS NOT NULL AND q.PRODUCTAREA IS NULL) THEN 1 END AS PRODUCTAREA, \n"
                + " CASE WHEN p.MODULEID!=Q.MODULEID OR (p.MODULEID IS NULL AND q.MODULEID IS NOT NULL) OR (p.MODULEID IS NOT NULL AND q.MODULEID IS NULL) THEN 1 END AS MODULEID, \n"
                + " CASE WHEN p.FIXEDINVERSION!=Q.FIXEDINVERSION OR (p.FIXEDINVERSION IS NULL AND q.FIXEDINVERSION IS NOT NULL) OR (p.FIXEDINVERSION IS NOT NULL AND q.FIXEDINVERSION IS NULL) THEN 1 END AS FIXEDINVERSION, \n"
                + " CASE WHEN p.PRODUCTID!=Q.PRODUCTID OR (p.PRODUCTID IS NULL AND q.PRODUCTID IS NOT NULL) OR (p.PRODUCTID IS NOT NULL AND q.PRODUCTID IS NULL) THEN 1 END AS PRODUCTID, \n"
                + " CASE WHEN p.PROJECTID!=Q.PROJECTID OR (p.PROJECTID IS NULL AND q.PROJECTID IS NOT NULL) OR (p.PROJECTID IS NOT NULL AND q.PROJECTID IS NULL) THEN 1 END AS PROJECTID, \n"
                + " CASE WHEN p.DETECTEDVERSION!=Q.DETECTEDVERSION OR (p.DETECTEDVERSION IS NULL AND q.DETECTEDVERSION IS NOT NULL) OR (p.DETECTEDVERSION IS NOT NULL AND q.DETECTEDVERSION IS NULL) THEN 1 END AS DETECTEDVERSION, \n"
                + " CASE WHEN p.PHASEDETECTED!=Q.PHASEDETECTED OR (p.PHASEDETECTED IS NULL AND q.PHASEDETECTED IS NOT NULL) OR (p.PHASEDETECTED IS NOT NULL AND q.PHASEDETECTED IS NULL) THEN 1 END AS PHASEDETECTED, \n"
                + " CASE WHEN p.DATAPROVIDERID!=Q.DATAPROVIDERID OR (p.DATAPROVIDERID IS NULL AND q.DATAPROVIDERID IS NOT NULL) OR (p.DATAPROVIDERID IS NOT NULL AND q.DATAPROVIDERID IS NULL) THEN 1 END AS DATAPROVIDERID, \n"
                + " CASE WHEN p.SOURCEID!=Q.SOURCEID OR (p.SOURCEID IS NULL AND q.SOURCEID IS NOT NULL) OR (p.SOURCEID IS NOT NULL AND q.SOURCEID IS NULL) THEN 1 END AS SOURCEID \n"
                + " from oam_rm_archive p,oam_rm_archive q \n"
                + " where p.pksource<q.pksource  \n"
                + " and p.requestcode=q.requestcode and " + " p.requestcode='"
                + RequestCode + "' \n" + " ORDER BY P.PKSOURCE DESC \n"
                + " ) WHERE rownum=1 ";
        // System.out.println("SQL is -->"+ sql);
        return getList(sql, "Changes on Request");
    }

    public void setTempRemarks(String tempRemarks) {
        this.tempRemarks = tempRemarks;
    }

    public String getTempRemarks() {
        return tempRemarks;
    }

    public String changeRequestType(String alias, String requestType,
            String RequestPhaseInjectCode) {
        String phaseinjectedcombo = "";
        Map reply = new HashMap();
        try {
            setAlias(alias);
            makeConnection();
            phaseinjectedcombo = "<tr><td class=\"DataCell\">&nbsp;Phase Injected</td>";
            phaseinjectedcombo += "<td class=\"DataCell\" colspan=3>&nbsp;";

            phaseinjectedcombo += "<select name=RequestPhaseInjectCode><OPTION VALUE=\"\">Please Choose</OPTION>";
            if (getListOfRequestPhases("")) {
                while (moveNext()) {
                    String pic = getData("RequestPhaseID");
                    phaseinjectedcombo += "<OPTION VALUE=\"" + pic + "\" ";
                    if (RequestPhaseInjectCode != null) {
                        if (pic.equals(RequestPhaseInjectCode)) {
                            phaseinjectedcombo += "selected";
                        }
                    }
                    phaseinjectedcombo += ">" + getData("RequestPhaseDesc")
                            + "</OPTION>";
                }
            } else {
                phaseinjectedcombo += "<option value=\"\">---------------------------</option>";
            }

            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBeanPM.changeRequestType"
                                + e);
            }
        }
        phaseinjectedcombo += "</select></td></tr>";

        return phaseinjectedcombo;
    }

    public Map clientChange(String fromPage, String alias, String clientID,
            String userID, String currentProduct) {
        Map hmap = new HashMap();
        String productcombo = "";
        String projectcombo = "";
        String modulecombo = "";
        String assignedTocombo = "";
        String versionDetectedcombo = "";
        String productUserscombo = "";
        String otherUserscombo = "";
        String versionFixedcombo = "";
        String labelcombo = "";
        String PhaseInjectedCombo = "";
        String PhaseDetectedCombo = "";
        String ProductAreaCombo = "";
        UserManager umSQL = new UserManager();
        try {
            setAlias(alias);
            makeConnection();
            umSQL.setAlias(alias);
            productcombo = "<select id=ProductID name=ProductID onChange=\"productChange()\" ><option value=\"\">Please Choose</option>";
            if (!clientID.equalsIgnoreCase("")) {
                int productTypeCount = 0;
                String rid = "";

                umSQL.makeConnection();
                if (umSQL.getAssignedRequestsofUser(userID, clientID)) {
                    while (umSQL.moveNext()) {
                        productTypeCount++;
                        rid = umSQL.getParam("ProductID");

                        productcombo += "<OPTION VALUE=\"" + rid + "\"";
                        if (currentProduct != null) {
                            if (rid.equals(currentProduct)) {
                                productcombo += " selected";
                            }

                        }

                        productcombo += ">" + umSQL.getParam("ProductName")
                                + "</OPTION>";
                    }
                }
                umSQL.takeDown();
            }

            productcombo += "</select>";
            projectcombo = "<select name=ProjectID id=ProjectID><option value=\"\">Please Choose</option></select>";
            modulecombo = "<select name = \"ProductModule\"><option value=\"\">Please Choose</option></select>";
            assignedTocombo = "<select name=AssignedTo id='AssignedTo'><option value=\"\">Please Choose</option></select><font size='2' color='#FF0000'>*</font>";
            versionDetectedcombo = "<select name = \"RelVersion\" id=\"RelVersion\"><option value=\"\">Please Choose</option></select>";
            productUserscombo = "<select name=copyToCombo multiple size=3 onclick=\"CheckSingleSelect()\"><option value=\"\">Please Choose</option></select>";
            otherUserscombo = "<select name=cpyToCombo multiple size=3 onclick=\"CheckSingleSelection()\"><option value=\"\">Please Choose</option></select>";
            versionFixedcombo = "<select name = FixVersion><option value=>Please choose </option></select>";
            labelcombo = "<p style=\"font-weight:bold;\">Labels:</p>";
            labelcombo += "<script language = \"javascript\">document.getElementById(\"lbldiv\").style.height = 0;</script>";
            labelcombo += "<div id = \"lbldiv1\" style = \"text-align: center; vertical-align:center; font-weight: bold\">N/A</div>";
            PhaseInjectedCombo = "<select name = RequestPhaseInjectCode><option value=>Please choose </option></select>";
            PhaseDetectedCombo = "<select name = RequestPhaseCode><option value=>Please choose </option></select>";
            ProductAreaCombo += "<select name=ProductArea ><OPTION VALUE=\"\">Please Choose</OPTION></SELECT>";
            hmap.put("productcombo", productcombo);
            hmap.put("projectcombo", projectcombo);
            hmap.put("modulecombo", modulecombo);
            hmap.put("assignedTocombo", assignedTocombo);
            hmap.put("versionDetectedcombo", versionDetectedcombo);
            hmap.put("productUserscombo", productUserscombo);
            hmap.put("otherUserscombo", otherUserscombo);
            hmap.put("versionFixedcombo", versionFixedcombo);
            hmap.put("labelcombo", labelcombo);
            hmap.put("PhaseInjectedCombo", PhaseInjectedCombo);
            hmap.put("PhaseDetectedCombo", PhaseDetectedCombo);
            hmap.put("ProductAreaCombo", ProductAreaCombo);
            hmap.put("ProductUsersToList", "");
            hmap.put("OtherUsersToList", "");

            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                umSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.clientChange"
                                + e);
            }
        }
        return hmap;
    }

    public Map productChange(String fromPage, String alias, String client,
            String RequestCode, String product, String selectedProject,
            String ProductModule, String RelVersion, String FixVersion,
            String AssignedTo, String RequestPhaseInject,
            String RequestPhaseDetect) {
        Map hmap = new HashMap();
        String projectcombo = "";
        String modulecombo = "";
        String assignedTocombo = "";
        String versionDetectedcombo = "";
        String productUserscombo = "";
        String otherUserscombo = "";
        String versionFixedcombo = "";
        String labelcombo = "";
        String PhaseInjectedCombo = "";
        String PhaseDetectedCombo = "";
        String ProductAreaCombo = "";

        List productUsersToList = new ArrayList<String>();
        List otherUsersToList = new ArrayList<String>();

        RequestManager rmSQL = new RequestManager();
        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();

            projectcombo = "<select name=\"ProjectID\"  id=\"ProjectID\" onChange=\"projectChange()\"><option value=\"\">Please Choose</option>";
            if (!product.equalsIgnoreCase("")) {
                int projectTypeCount = 0;
                String rid = "";
                rmSQL.setProjectQuery(product, "");
                if (rmSQL.getListOfProjects()) {
                    while (rmSQL.moveNext()) {
                        projectTypeCount++;
                        rid = rmSQL.getParam("ID");

                        projectcombo += "<OPTION VALUE=\"" + rid + "\"";
                        if (selectedProject != null) {
                            if (rid.equals(selectedProject)) {
                                projectcombo += " selected";
                            }

                        }

                        projectcombo += ">" + rmSQL.getParam("Project")
                                + "</OPTION>";
                    }
                }

            }

            rmSQL.takeDown();
            projectcombo += "</select>";
            if (!product.equals("")) {
                modulecombo = "<select name = \"ProductModule\">"
                        + "<option value=\"\">Please Choose</option>";
                String pm = "";
                if (getListOfModules(product)) {

                    while (moveNext()) {
                        pm = getData("ID");
                        modulecombo += "<OPTION VALUE=\"" + pm + "\" ";
                        if (ProductModule != null) {
                            if (pm.equals(ProductModule)) {
                                modulecombo += " selected";
                            }
                        }
                        modulecombo += ">"
                                + TextEncoder.encode(getData("Module"))
                                + "</OPTION>";
                    }
                }
            } else {
                modulecombo += "<select>";
                modulecombo += "<option value=\"0\">-----------------------</option></select>";
            }

            assignedTocombo = "<select name=AssignedTo id='AssignedTo'>";
            assignedTocombo += "<option value=\"\">Please Choose</option>";
            if (getProductUsers(product)) {
                while (moveNext()) {

                    String loingNameDesc = "(" + getData("loginname") + ")";
                    String ids = getData("UserID");
                    assignedTocombo += "<OPTION VALUE=\"" + ids + "\" ";
                    if (ids.equals(AssignedTo)) {
                        assignedTocombo += " selected";
                        // System.out.println("***************************comparing assigned to:"+AssignedTo+"............combo:"+ids);
                    }
                    assignedTocombo += ">" + getData("UserName")
                            + loingNameDesc + "</OPTION>";

                }
            } else {
                assignedTocombo += "<option value=\"0\">-----------------------</option>";
            }
            assignedTocombo += "</select><font size='2' color='#FF0000'>*</font>";

            if (!product.equals("")) {
                versionDetectedcombo = "<select name = \"RelVersion\" id=\"RelVersion\">";
                versionDetectedcombo += "<option value=\"\">Please Choose</option>";
                String vd = "";
                if (getListOfVersions(product)) {

                    while (moveNext()) {
                        vd = getData("ID");
                        versionDetectedcombo += "<OPTION VALUE=\"" + vd + "\" ";
                        if (RelVersion != null && !RelVersion.equals("")) {
                            // System.out.println("*******************88comparing versions:"+vd+"........combo:"+RelVersion);
                            if (vd.equals(RelVersion)) {
                                versionDetectedcombo += " selected";
                            }
                        } else if (getData("Version").trim().equals("N/A")
                                || getData("Version").trim().equalsIgnoreCase(
                                "NA")) {
                            versionDetectedcombo += " selected";
                        }
                        versionDetectedcombo += ">"
                                + TextEncoder.encode(getData("Version"))
                                + "</OPTION>";
                    }
                }
                versionDetectedcombo += "</select>";
            } else {
                versionDetectedcombo += "<select name = \"RelVersion\" id=\"RelVersion\">";
                versionDetectedcombo += "<option value=\"0\">-----------------------</option></select>";
            }

            productUserscombo = "<select name=copyToCombo multiple size=3 onclick=\"CheckSingleSelect()\">";
            if (getAllUsers()) {
                while (moveNext()) {
                    String userNameDesc = getData("UserName");
                    String loginNameDesc = "(" + getData("loginname") + ")";
                    if (!userNameDesc.equals("admin")) {
                        String ids = getData("UserID");
                        productUserscombo += "<OPTION VALUE=\"" + ids + "\" ";
                        productUserscombo += ">" + userNameDesc + loginNameDesc
                                + "</OPTION>";
                        Map productUsersTo = new HashMap();
                        productUsersTo.put("id", ids);
                        productUsersTo
                                .put("name", userNameDesc + loginNameDesc);
                        productUsersToList.add(productUsersTo);
                    }
                }
            } else {
                productUserscombo += "<option value=\"0\">---------------------------</option>";
            }
            productUserscombo += "</select>";
            otherUserscombo = "<select name=cpyToCombo multiple size=3 onclick=\"CheckSingleSelection()\">";

            if (getNonProductUsers(product)) {
                while (moveNext()) {
                    String userNameDesc = getData("UserName");
                    String loginNameDesc = "(" + getData("loginname") + ")";
                    if (!userNameDesc.equals("admin")) {
                        String ids = getData("UserID");
                        otherUserscombo += "<OPTION VALUE=\"" + ids + "\" ";
                        otherUserscombo += ">" + userNameDesc + loginNameDesc
                                + "</OPTION>";
                        Map otherUsersTo = new HashMap();
                        otherUsersTo.put("id", ids);
                        otherUsersTo.put("name", userNameDesc + loginNameDesc);
                        otherUsersToList.add(otherUsersTo);

                    }
                }
            } else {
                otherUserscombo += "<option value=\"0\">---------------------------</option>";
            }
            otherUserscombo += "</select>";

            versionFixedcombo = "<select name = FixVersion>";
            versionFixedcombo += "<option value=>Please choose </option>";
            if (getListOfVersions(product)) {
                while (moveNext()) {
                    String ids = getData("ID");
                    versionFixedcombo += "<OPTION VALUE=\"" + ids + "\" ";
                    if (FixVersion != null) {
                        if (ids.equals(FixVersion)) {
                            versionFixedcombo += " selected";
                        }
                    }
                    versionFixedcombo += ">" + getData("Version") + "</OPTION>";
                }
            } else {
                versionFixedcombo += "<option value=\"0\">---------------------------</option>";
            }
            versionFixedcombo += "</select>";

            labelcombo = "<p style=\"font-weight:bold;\">Labels:</p>";
            String lid = "";
            int labelcount = 0;
            if (checkLabelStatus(RequestCode, client, product)) {
                labelcombo += "<div id = \"lbldiv\" style = \"overflow:auto; height:100px;\" >";
                while (moveNext()) {
                    labelcount++;
                    lid = getData("LABELID");
                    String ischecked = getData("IS_CHECKED");

                    labelcombo += "<input type=\"checkbox\" name=\"chklbl_"
                            + lid + "\" value=" + lid;
                    labelcombo += "  " + ischecked;
                    labelcombo += " >"
                            + TextEncoder.encode(getData("LabelName")) + "<BR>";

                }
                labelcombo += "</div>";
            }
            if (labelcount == 0) {
                labelcombo += "<script language = \"javascript\">document.getElementById(\"lbldiv\").style.height = 0;</script>";
                labelcombo += "<div id = \"lbldiv1\" style = \"text-align: center; vertical-align:center; font-weight: bold\">N/A</div>";
            }

            PhaseInjectedCombo += "<select id=\"RequestPhaseInjectCode\" name=RequestPhaseInjectCode>";
            PhaseInjectedCombo += "<OPTION VALUE=\"\">Please Choose</OPTION>";
            String phaseinjectcode = "";
            if (getListOfRequestInjectedPhases(product)) {
                while (moveNext()) {
                    phaseinjectcode = getData("RequestPhaseID");
                    PhaseInjectedCombo += "<OPTION VALUE=\"" + phaseinjectcode
                            + "\" ";
                    if (RequestPhaseInject != null) {
                        if (phaseinjectcode.equals(RequestPhaseInject)) {
                            PhaseInjectedCombo += "selected";
                        }
                    }

                    PhaseInjectedCombo += ">" + getData("RequestPhaseDesc")
                            + "</OPTION>";
                }
            } else {
                PhaseInjectedCombo += "<option value=\"\">---------------------------</option>";
            }
            PhaseInjectedCombo += "</select>";

            PhaseDetectedCombo += "<select name=RequestPhaseCode>";
            PhaseDetectedCombo += "<OPTION VALUE=\"\">Please Choose</OPTION>";
            String phasedetectcode = "";
            if (getListOfRequestPhases(product)) {
                while (moveNext()) {
                    phasedetectcode = getData("RequestPhaseID");
                    PhaseDetectedCombo += "<OPTION VALUE=\"" + phasedetectcode
                            + "\" ";
                    if (RequestPhaseDetect != null) {
                        if (phasedetectcode.equals(RequestPhaseDetect)) {
                            PhaseDetectedCombo += "selected";
                        }
                    }

                    PhaseDetectedCombo += ">" + getData("RequestPhaseDesc")
                            + "</OPTION>";
                }
            } else {
                PhaseDetectedCombo += "<option value=\"\">---------------------------</option>";
            }
            PhaseDetectedCombo += "</select>";
            ProductAreaCombo += "<select name=ProductArea ><OPTION VALUE=\"\">Please Choose</OPTION></SELECT>";
            hmap.put("projectcombo", projectcombo);
            hmap.put("modulecombo", modulecombo);
            hmap.put("assignedTocombo", assignedTocombo);
            hmap.put("versionDetectedcombo", versionDetectedcombo);
            hmap.put("productUserscombo", productUserscombo);
            hmap.put("otherUserscombo", otherUserscombo);
            hmap.put("versionFixedcombo", versionFixedcombo);
            hmap.put("labelcombo", labelcombo);
            hmap.put("PhaseInjectedCombo", PhaseInjectedCombo);
            hmap.put("PhaseDetectedCombo", PhaseDetectedCombo);
            hmap.put("ProductAreaCombo", ProductAreaCombo);
            hmap.put("ProductUsersToList", productUsersToList);
            hmap.put("OtherUsersToList", otherUsersToList);
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.productChange"
                                + e);
            }
        }
        return hmap;
    }

    public Map ccUserList(String fromPage, String alias, String requestType) {
        Map hmap = new HashMap();
        String assignedTocombo = "";
        String signoffTocombo = "";
        String approvedBycombo = "";
        String priorityByCombo = "";
        //List productUsersToList = new ArrayList<String>();
        RequestManager rmSQL = new RequestManager();
        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();

            assignedTocombo = "&nbsp; <select name='AssignedTo' id='AssignedTo'>";
            assignedTocombo += "<option value=\"\">Please Choose</option>";

            signoffTocombo = "&nbsp; <select name='signedOffBy' id='signedOffBy'>";
            signoffTocombo += "<option value=\"\">Please Choose</option>";

            if (getAllUsers()) {
                while (moveNext()) {
                    String userNameDesc = getData("UserName");
                    String loginNameDesc = "(" + getData("loginname") + ")";
                    if (!userNameDesc.equals("admin")) {
                        String ids = getData("UserID");

                        assignedTocombo += "<OPTION VALUE=\"" + ids + "\" ";
                        assignedTocombo += ">" + userNameDesc + loginNameDesc
                                + "</OPTION>";
                        signoffTocombo += "<OPTION VALUE=\"" + ids + "\" ";
                        signoffTocombo += ">" + userNameDesc + loginNameDesc
                                + "</OPTION>";

                        /* Map productUsersTo = new HashMap();
                        productUsersTo.put("id", ids);
                        productUsersTo
                                .put("name", userNameDesc + loginNameDesc);
                        productUsersToList.add(productUsersTo);*/
                    }
                }
            } else {
                assignedTocombo += "<option value=\"0\">---------------------------</option>";
                signoffTocombo += "<option value=\"0\">---------------------------</option>";
            }
            assignedTocombo += "</select>";
            signoffTocombo += "</select>";

            approvedBycombo = "&nbsp; <select name='approvedBy' id='approvedBy'>";
            approvedBycombo += "<option value=\"\">Please Choose</option>";

            // priorityByCombo = "&nbsp; <select name='approvedBy' id='approvedBy'>";
            // priorityByCombo += "<option value=\"\">Please Choose</option>";
            if (getAllUsers(requestType)) {
                while (moveNext()) {
                    String userNameDesc = getData("UserName");
                    String loginNameDesc = "(" + getData("loginname") + ")";
                    if (!userNameDesc.equals("admin")) {
                        String ids = getData("UserID");

                        approvedBycombo += "<OPTION VALUE=\"" + ids + "\" ";
                        approvedBycombo += ">" + userNameDesc + loginNameDesc
                                + "</OPTION>";
                    }
                }
            } else {
                approvedBycombo += "<option value=\"0\">---------------------------</option>";
            }

            approvedBycombo += "</select>";

            priorityByCombo = "&nbsp; <select name='PrioritizedBy' id='PrioritizedBy'>";
            priorityByCombo += "<option value=\"-1\">Please Choose</option>";

            if (getAllPrioritizedUsers(requestType)) {
                while (moveNext()) {
                    String userName = getData("UserName");
                    String ids = getData("UserID");

                    priorityByCombo += "<OPTION VALUE=\"" + ids + "\" ";
                    priorityByCombo += ">" + userName
                            + "</OPTION>";

                }
            } else {
                priorityByCombo += "<option value=\"0\">---------------------------</option>";
            }

            priorityByCombo += "</select>";

            // System.out.println("pdrd:" + assignedTocombo);
            hmap.put("AssignedTocombo", assignedTocombo);
            hmap.put("SignoffTocombo", signoffTocombo);
            hmap.put("ApprovedBycombo", approvedBycombo);
            // hmap.put("ProductUsersToList", productUsersToList);
            hmap.put("PriorityByCombo", priorityByCombo);
            rmSQL.takeDown();
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.productChange"
                                + e);
            }
        }
        return hmap;
    }

    public Map getIssueTypePhases(String issueType, String pId, String alias) {
        Map hmap = new HashMap();
        String phaseCombo = "";
        int flag = 0;
        RequestManager rmSQL = new RequestManager();
        System.out.println("CAlled>>>>>>>>>>>>>>>>>>>>>>>>");
        System.out.println("Phase id is >>>>>>>>>>>>>>" + pId);
        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();
            phaseCombo = "&nbsp; <select name='phase' id='phase'>";
            phaseCombo += "<option value=\"\">Please Choose</option>";
            if (getPhasesForIssueType(issueType)) {
                while (moveNext()) {
                    String phaseId = getData("phaseId");
                    String phaseName = getData("phaseName");
                    phaseCombo += "<OPTION VALUE=\"" + phaseId + "\" ";
                    if (pId.length() == 0 && flag == 0) {
                        phaseCombo += " selected ";
                        flag++;
                    }
                    if (pId.length() > 0 && pId.equals(phaseId)) {
                        phaseCombo += " selected ";
                    }

                    phaseCombo += ">" + phaseName + "</OPTION>";
                }
            } else {
                phaseCombo += "<option value=\"0\">---------------------------</option>";
            }
            phaseCombo += "</select>";
            hmap.put("PhaseCombo", phaseCombo);
            rmSQL.takeDown();
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.getPhasesForIssueType"
                                + e);
            }
        }
        return hmap;
    }

    public Map getIssueTypeProject(String issueType, String pId, String alias) {
        Map hmap = new HashMap();
        String projectCombo = "";
        int flag = 0;
        RequestManager rmSQL = new RequestManager();
        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();
            projectCombo = "&nbsp; <select name='projectId' id='projectId'>";
            projectCombo += "<option value=\"\">Please Choose</option>";
            if (getProjectForIssueType(issueType)) {
                while (moveNext()) {
                    String PROJECTID = getData("PROJECTID");
                    String PROJECTNAME = getData("PROJECTNAME");
                    projectCombo += "<OPTION VALUE=\"" + PROJECTID + "\" ";

                    if (pId.length() > 0 && pId.equals(PROJECTID)) {
                        projectCombo += " selected ";
                    }

                    projectCombo += ">" + PROJECTNAME + "</OPTION>";
                }
            } else {
                projectCombo += "<option value=\"0\">---------------------------</option>";
            }
            projectCombo += "</select>";
            hmap.put("ProjectCombo", projectCombo);
            rmSQL.takeDown();
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.getPhasesForIssueType"
                                + e);
            }
        }
        return hmap;
    }

    public Map getComponent(String appid, String componentid, String alias) {
        Map hmap = new HashMap();
        String defectComponentCombo = "";
        String defectComponentCombo1 = "";
        String defectImpactComponentCombo = "";
        int flag = 0;
        RequestManager rmSQL = new RequestManager();
        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();

            defectComponentCombo += "<option value=\"\">Please Choose</option>";
            if (this.getComponentForApplication(appid)) {
                while (moveNext()) {
                    String defcomponentid = getData("defcomponentid");
                    String defcomponentname = getData("defcomponentname");
                    defectComponentCombo += "<OPTION VALUE=\"" + defcomponentid + "\" ";

                    if (componentid.length() > 0 && componentid.equals(defcomponentid)) {
                        defectComponentCombo += " selected ";
                    }

                    defectComponentCombo += ">" + defcomponentname + "</OPTION>";
                }
            } else {
                defectComponentCombo += "<option value=\"0\">---------------------------</option>";
            }
            defectComponentCombo += "</select>";
            defectComponentCombo1 = "&nbsp; <select name='defectComponent' id='defectComponent'>" + defectComponentCombo;
            defectImpactComponentCombo = "&nbsp; <select name='defectImpactedComponent' id='defectImpactedComponent'>" + defectComponentCombo;
            hmap.put("defectComponentCombo", defectComponentCombo1);
            hmap.put("defectImpactComponentCombo", defectImpactComponentCombo);
            rmSQL.takeDown();
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.getPhasesForIssueType"
                                + e);
            }
        }
        return hmap;
    }

    public Map getClientApps(String clientId, String applicationId,
            String alias, String addOrEdit) {
        Map hmap = new HashMap();
        String ApplicationCombo = "";
        RequestManager rmSQL = new RequestManager();
        System.out.println("Client id from getClientApplications is ??????????"
                + clientId);
        System.out.println("Client id from getClientApplications is ??????????"
                + applicationId);
        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();
            ApplicationCombo = "&nbsp; <select name='appID' id='appID' onchange=\"getAppInfo('"
                    + addOrEdit + "','" + alias + "')\">";
            ApplicationCombo += "<option value=\"\">Please Choose</option>";
            if (getClientApplications(clientId)) {
                while (moveNext()) {
                    String appId = getData("applicationId");
                    String appName = getData("applicationName");
                    ApplicationCombo += "<OPTION VALUE=\"" + appId + "\" ";
                    if (applicationId.length() > 0
                            && appId.equals(applicationId)) {
                        ApplicationCombo += " selected ";
                    }
                    ApplicationCombo += ">" + appName + "(" + appId + ")"
                            + "</OPTION>";
                }
            } else {
                ApplicationCombo += "<option value=\"0\">---------------------------</option>";
            }
            ApplicationCombo += "</select>";

            System.out.println("Application Combo>>>>>>:" + ApplicationCombo);
            hmap.put("ApplicationCombo", ApplicationCombo);
            rmSQL.takeDown();
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.getClientApplications"
                                + e);
            }
        }
        return hmap;
    }

    public Map getAppInfo(String appId, String alias) {
        Map hmap = new HashMap();
        String am = "";
        String ba = "";
        String wpm = "";
        String npm = "";
        String cl = "";

        String releaseTagCombo = "";
        System.out.println("Getting application info for app id " + appId);
        System.out.println("Alias name >>>>>>>>>>>>>>" + alias);
        RequestManager rmSQL = new RequestManager();

        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();

            releaseTagCombo = "&nbsp; <select name='releaseTag' id='releaseTag' >";
            releaseTagCombo += "<option value=\"\">Please Choose</option>";

            if (getApplicationsReleaseTag(appId)) {
                while (moveNext()) {
                    String Id = getData("releasetagidbyapp");
                    String Name = getData("releasetagidbyapp");
                    releaseTagCombo += "<OPTION VALUE=\"" + Id + "\" ";

                    releaseTagCombo += ">" + Name + "</OPTION>";
                }
            } else {
                releaseTagCombo += "<option value=\"0\">---------------------------</option>";
            }
            releaseTagCombo += "</select>";

            if (getApplicationInfo(appId, "amid")) {
                while (moveNext()) {
                    am = getData("username");
                }
            }

            if (getApplicationInfo(appId, "csaid")) {
                while (moveNext()) {
                    ba = getData("username");
                }
            }
            if (getApplicationInfo(appId, "accid")) {
                while (moveNext()) {
                    wpm = getData("username");

                }
            }
            if (getApplicationInfo(appId, "npmid")) {
                while (moveNext()) {
                    npm = getData("username");
                }
            }
            if (getApplicationInfo(appId, "businessintid")) {
                while (moveNext()) {
                    cl = getData("username");
                }
            }

            hmap.put("am", am);
            hmap.put("ba", ba);
            hmap.put("wpm", wpm);
            hmap.put("npm", npm);
            hmap.put("cl", cl);
            hmap.put("releaseTagCombo", releaseTagCombo);
            rmSQL.takeDown();
            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.getAppInfo"
                                + e);
            }
        }
        return hmap;
    }
    
    
    
    public Map getAssignee(String clientid, String alias) {
        Map hmap = new HashMap();
        String assignee = "";
        String assigneeto = "";
        
        String leadid = "";
        String leadname = "";

        System.out.println("Getting application info for clientid " + clientid);
         RequestManager rmSQL = new RequestManager();

        try {
            setAlias(alias);
            makeConnection();
            rmSQL.setAlias(alias);
            rmSQL.makeConnection();

      
            if (getAssigneeInfo(clientid, "")) {
                while (moveNext()) {
                	assignee = getData("username");
                	assigneeto = getData("userid");
                }
            }
            
            
            if (getLead(assigneeto)) {
                while (moveNext()) {
                	leadname = getData("username");
                	leadid = getData("userid");
                }
            }
            
            
            hmap.put("assignee", assignee);
            hmap.put("assigneeto", assigneeto);
            
            hmap.put("leadid", leadid);
            hmap.put("leadname", leadname);
            
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.getAppInfo"
                                + e);
            }
        }
        return hmap;
    }

    public Map projectChange(String fromPage, String alias, String Product,
            String RequestType, String project, String ProductArea) {
        Map hmap = new HashMap();
        String ProductAreaCombo = "";
        UserManager umSQL = new UserManager();
        try {
            setAlias(alias);
            makeConnection();
            ProductAreaCombo += "<select name=ProductArea >";
            ProductAreaCombo += "<OPTION VALUE=\"\">Please Choose</OPTION>";
            String Areacode = "";
            if (getListOfProductAreas(project)) {
                while (moveNext()) {
                    Areacode = getData("ProductAreaID");
                    ProductAreaCombo += "<OPTION VALUE=\"" + Areacode + "\" ";
                    if (ProductArea != null) {
                        if (Areacode.equals(ProductArea)) {
                            ProductAreaCombo += "selected";
                        }
                    }

                    ProductAreaCombo += ">" + getData("ProductAreaDesc")
                            + "</OPTION>";
                }

            } else {
                ProductAreaCombo += "<option value=\"\">---------------------------</option>";
            }
            if (!fromPage.equals("Update")) {

                umSQL.setAlias(alias);
                umSQL.makeConnection();
                if (Product.equals("all")) {
                    Product = "1";
                }
                if (project.equals("all")) {
                    project = "1";
                }
                String strPreAssignednStatic = umSQL.getPreAssign(Product,
                        project, RequestType);

                String strArrPreAssignednStatic[] = new String[2];
                String PreAssignedUserID = "";
                String isStatic = "";
                String assignedTocombo = "";

                if (strPreAssignednStatic != null
                        && !"".equals(strPreAssignednStatic.trim())) {
                    strArrPreAssignednStatic = strPreAssignednStatic
                            .split(":::");
                    PreAssignedUserID = strArrPreAssignednStatic[0].trim();
                    isStatic = strArrPreAssignednStatic[1].trim();
                }

                /*
                 * For IT product , productid(508) the default asignee is
                 * displayed and is not allowed to change whle in other case the
                 * asignee is allowed to chosen Modified by Bhanu June 6,09
                 * Updated to make preassign as static
                 */
                if (PreAssignedUserID != null && !"".equals(PreAssignedUserID)
                        && ("Y").equals(isStatic)) {
                    assignedTocombo = "<INPUT TYPE='hidden' NAME='AssignedTo' VALUE="
                            + PreAssignedUserID
                            + ">"
                            + getRequestingPerson(PreAssignedUserID);
                } else {
                    assignedTocombo = "<select name=AssignedTo id='AssignedTo'>";
                    assignedTocombo += "<option value=\"\">Please Choose</option>";
                    if (getProductUsers(Product)) {
                        while (moveNext()) {
                            String loginNameDesc = "(" + getData("loginname")
                                    + ")";
                            String ids = getData("UserID");
                            assignedTocombo += "<OPTION VALUE=\"" + ids + "\" ";
                            if (ids.equals(PreAssignedUserID)) {
                                assignedTocombo += " selected";
                            }
                            assignedTocombo += ">" + getData("UserName")
                                    + loginNameDesc + "</OPTION>";
                        }
                    } else {
                        assignedTocombo += "<option value=\"0\">-----------------------</option>";
                    }
                    assignedTocombo += "</select><font size='2' color='#FF0000'>*</font>";
                }
                umSQL.takeDown();
                hmap.put("AssignedTocombo", assignedTocombo);

            }
            hmap.put("ProductAreaCombo", ProductAreaCombo);

            takeDown();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                umSQL.takeDown();
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.projectChange"
                                + e);
            }
        }
        return hmap;
    }

    public Map dataProviderChange(String fromPage, String alias,
            String project, String DataProviderID) {
        Map hmap = new HashMap();
        String projectcombo = "";
        RequestManager rmSQL = new RequestManager();
        try {

            rmSQL.setAlias(alias);
            rmSQL.makeConnection();

            projectcombo = "<select id=ProjectID name=ProjectID onChange=\"projectChange()\"><option value=\"\">Please Choose</option>";

            int projectTypeCount = 0;
            String rid = "";
            rmSQL.setProjectForDataProviderQuery(DataProviderID);
            if (rmSQL.getListOfProjects()) {
                while (rmSQL.moveNext()) {
                    projectTypeCount++;
                    rid = rmSQL.getParam("PROJECTID");

                    projectcombo += "<OPTION VALUE=\"" + rid + "\"";
                    if (project != null) {
                        if (rid.equals(project)) {
                            projectcombo += " selected";
                        }

                    }

                    projectcombo += ">" + rmSQL.getParam("PROJECTNAME")
                            + "</OPTION>";
                }
            }

            projectcombo += "</select>";
            hmap.put("projectcombo", projectcombo);

            rmSQL.takeDown();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rmSQL.takeDown();

            } catch (Exception e) {
                System.out
                        .println("Error in closing connection in QueryBean.projectChange"
                                + e);
            }
        }
        return hmap;
    }

    public String getProjectName(String ProjectID) {
        String sql = "select ProjectName from OAM_RM_PROJECTS where 1=1";
        if (!ProjectID.equalsIgnoreCase("")) {
            sql = sql + " And ProjectID=" + ProjectID + "";
        }

        String ProjectName = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                ProjectName = rs.getString("ProjectName");
            }
        } catch (Exception e) {
        }
        return ProjectName;
    }

    public String getCRProjectName(String ProjectID) {
        String sql = "select ProjectName from " + Constants.OAM_CR_PROJECTS + " where 1=1";

        String ProjectName = "";
        if (ProjectID.equalsIgnoreCase("0")) {
            return "N/A";
        }

        if (!ProjectID.equalsIgnoreCase("")) {
            sql = sql + " And ProjectID=" + ProjectID + "";
        }

        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) {
                ProjectName = rs.getString("ProjectName");
            }
        } catch (Exception e) {
        }
        return ProjectName;
    }

    public boolean getSchedularDetails(String SchedularID) {
        String str = " select a.schedularname,a.rungapdays,to_char(a.nextrundate,'mm/dd/yyyy hh24:mi:ss') as nextrundate,b.* FROM oam_rm_schedular_detail a inner join oam_rm_schedular b on a.jobid=b.jobid where a.jobID='"
                + SchedularID + "'";
        // System.out.println(str);
        return getList(str, "Schedular Detail");
    }

    public boolean isClosedProject(String ProjectID) {
        String sql = "select isClosed from OAM_RM_PROJECTS where 1=1";
        if (!ProjectID.equalsIgnoreCase("")) {
            sql = sql + " And ProjectID=" + ProjectID + "";
        }
        boolean result = false;
        String isClosed = "";
        try {
            Statement st = myConn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            rs.next();
            isClosed = rs.getString("isClosed");
            if (isClosed.equals("Y")) {
                result = true;
            }

        } catch (Exception e) {
        }
        return result;
    }

    public String getThresholdDate(String alias, String project) {
        String TargetEndDate = "";
        String sql = "";

        try {
            project = project == null ? "" : project.trim();
            if ("".equalsIgnoreCase(project) || "all".equalsIgnoreCase(project)
                    || project == null) {
                return "";
            } else {
                setAlias(alias);
                makeConnection();
                sql = " select case when thresholddays>0 then "
                        + " to_char((sysdate+thresholddays),'mm/dd/yyyy') "
                        + " end targetdate from OAM_RM_PROJECTS where 1=1";
                if (!project.equalsIgnoreCase("")) {
                    sql = sql + " And ProjectID=" + project + "";
                }
                Statement st = myConn.createStatement();
                ResultSet rs = st.executeQuery(sql);
                rs.next();
                TargetEndDate = rs.getString("targetdate");
                rs.close();
            }
        } catch (Exception e) {
            System.out
                    .println("The query has error, from queryBeanPN.getThreshlodDate is "
                            + sql + " \n");
            e.printStackTrace();

        } finally {
            try {
                takeDown();
            } catch (Exception e) {
                System.out
                        .println("Error in take at down queryBeanPN.getThreshlodDate, the error is "
                                + e + " \n");

            }

        }

        return TargetEndDate;
    }

    public boolean getRequestDetail(String RequestCode) throws Exception {
        return getList(
                "SELECT p.RequestCode,p.RequestTypeID,p.RequestDate,p.RequestingPerson,r.UserName as RequestingPersonDesc,"
                + "p.Requests,p.ActionTaken,p.StatusID,p.AssignedTo,p.DetectedVersion,p.TargetCompDate,p.ActualCompDate,"
                + "p.RequestPriority,p.ClientID,p.ExpectedCompDate,p.PhaseDetected as RequestPhase,p.ProductID,p.ModuleID,p.ProductArea,"
                + "p.PhaseInject,p.EstimatedHours,p.ActualHours,p.LastUpdatedDate,p.SourceID,p.actiontaken benefits,p.FixedInVersion,p.SeverityID,"
                + "p.Impact,p.ActualHours,p.ProjectID,p.DataProviderID,p.qc  FROM OAM_RM_REQUESTMANAGER p ,(SELECT USERID, USERNAME,email,oamStatus FROM USR_USERS UNION SELECT USERID, USERNAME,email,oamStatus FROM USR_DELETEDUSERS) r  "
                + "WHERE r.UserID=p.RequestingPerson AND p.RequestCode='"
                + RequestCode + "'", "Update Query ");
    }

    public boolean sendMessage(String RequestID, String from, String domain,
            String message, String docIds, String userId) {
        try {
            String ClientID = "";
            String ProductID = "";
            String ProjectID = "";
            String AssignedTo = "";
            String requesttitle = "";
            String requestingPerson = "";
            if (getSelectedProjectRequest(RequestID, userId)) {
                if (moveNext()) {
                    ClientID = getData("ClientID");
                    ProductID = getData("ProductID");
                    ProjectID = getData("ProjectID");
                    AssignedTo = getData("AssignedTo");
                    requesttitle = getData("requesttitle");
                    requestingPerson = getData("requestingPerson");
                }
            }
            SendMail mail = new SendMail();

            String msgSubject = "Request #" + RequestID + " " + requesttitle
                    + " : " + message;
            String mailMsg = "Request #:" + RequestID + "</B><BR>" + "<BR><hr>"
                    + getFormattedMailDetails(RequestID, docIds)
                    + " <BR>Thank you<BR>";

            int intMsgTriggeredFor = 1;
            String PhaseOrRequest = "r";

            Vector toList = new Vector();

            setPullProductsAll(true);
            if (ProjectID.equals("")) //
            {
                setPullReceiversWithAll(false);
            }

            // ADD REQUESTING PERSON
            if (!requestingPerson.equals("")) {
                toList.addElement(getEngineerName(requestingPerson) + "<"
                        + getEngineerEmail(requestingPerson) + ">");
            }

            // ADD PRE ASSIGNED DEVELOPER
            if (!AssignedTo.equals("")) {
                System.out.println(getEngineerName(AssignedTo) + "<"
                        + getEngineerEmail(AssignedTo) + ">");
                toList.addElement(getEngineerName(AssignedTo) + "<"
                        + getEngineerEmail(AssignedTo) + ">");
            }
            if (getListOfMSGReceivers(ClientID, ProjectID, intMsgTriggeredFor,
                    PhaseOrRequest, ProductID, "t")) {

                while (moveNext()) {
                    System.out.println(getData("Username") + "<"
                            + getData("Email") + ">");
                    toList.addElement(getData("Username") + "<"
                            + getData("Email") + ">");
                }
            }

            Vector ccList = new Vector();
            if (getListOfMSGReceivers(ClientID, ProjectID, intMsgTriggeredFor,
                    PhaseOrRequest, ProductID, "c")) {
                while (moveNext()) {
                    System.out.println(getData("Username") + "<"
                            + getData("Email") + ">");
                    ccList.addElement(getData("Username") + "<"
                            + getData("Email") + ">");
                }
            }

            // ADD Document Adder
            if (!userId.equals("")) {
                ccList.addElement(getEngineerName(userId) + "<"
                        + getEngineerEmail(userId) + ">");
            }

            System.out.println("I am inside mail send" + from);
            System.out.println("I am inside mail send" + mailMsg);

            mail.send(from, toList, ccList, msgSubject, mailMsg, from);

        } catch (Exception e) {
            System.out.println("Error while sending email. THe error is->"
                    + e.toString());
        }
        return true;
    }

    // Oct 8, 2009
    // Gives details of a Mail that have been added in the request in
    // HTML-Formatted String
    public String getFormattedMailDetails(String requestcode, String docIds) {
        String mailDetail = "";
        String OAMURL = getFixedParameter("OAM URL") + "/RM";
        String sql = "select documentcode,uploadeddocname,b.username uploadedby,to_char(uploadedon,'mm/dd/yyyy') uploadedon,doctype from oam_rm_moredocuments1 a inner join usr_users b on a.uploadedby=b.userid where documentcode in ("
                + docIds + ")";
        System.out.println(sql);
        mailDetail = "<TABLE border=1 cellspacing=1 cellpadding=1>"
                + "<TR><TD><B>Document Name </TD><TD><B>UploadedBy</TD><TD><B>UploadedOn</TD><TD><B>DocumentType</TD></TR>";
        String attch = "<a href='" + OAMURL + "/RE/downloadAllFiles.jsp?pid="
                + requestcode + ">Click here to download attachments</a>";
        if (getList(sql, "Mail Details QueryBeanPM")) {
            while (moveNext()) {
                String documentCode = getData("documentcode");
                String uploadedDocName = getData("uploadeddocname");
                String uploadedBy = getData("uploadedby");
                String uploadedOn = getData("uploadedon");
                String docType = getData("doctype");
                mailDetail += "<TR><TD>" + uploadedDocName + "</TD><TD>"
                        + uploadedBy + "</TD><TD>" + uploadedOn + "</TD><TD>"
                        + docType + "</TD></TR>";

            }
        }
        mailDetail += "</TABLE>";
        mailDetail += "Attachment  :&nbsp; <a href='" + OAMURL
                + "/RE/downloadAllFiles.jsp?pid=" + requestcode
                + "'>Click here to download attachments</a>";
        return mailDetail;
    }

    /**
     *
     * getTemplateDetails queryBeanPM this method returns the detail of a given
     * template
     *
     * @param templateID
     * @return
     * @return Map
     * @author:Ramesh Raj Baral
     * @since:Jun 10, 2010
     *
     */
    public Map getTemplateDetails(String alias, String templateID) {
        Map templateMap = new HashMap();
        RequestTemplate requestTemplate = new RequestTemplate();
        String sql = "SELECT *FROM OAM_RM_TEMPLATES WHERE TEMPLATEID='"
                + templateID + "'";
        System.out.println("get template detail query:" + sql);
        String productcombo = "<select id=ProductID name=ProductID onChange=\"productChange()\" ><option value=\"\">Please Choose</option>";
        String modulecombo = "<select name = \"ProductModule\"><option value=\"\">Please Choose</option>";
        String projectcombo = "<select id=ProjectID name=ProjectID onChange=\"projectChange()\"><option value=\"\">Please Choose</option>";
        String assignedTocombo = "<select name=AssignedTo id='AssignedTo'><option value=\"\">Please Choose</option>";
        String versionDetectedcombo = "<select name = \"RelVersion\" id=\"RelVersion\"><option value=\"\">Please Choose</option>";
        String productUserscombo = "<select name=copyToCombo multiple size=3 onclick=\"CheckSingleSelect()\">";
        String versionFixedcombo = "<select name = FixVersion><option value=>Please choose </option>";
        String PhaseInjectedCombo = "<select id=\"RequestPhaseInjectCode\" name=RequestPhaseInjectCode><OPTION VALUE=\"\">Please Choose</OPTION>";
        String PhaseDetectedCombo = "<select name=RequestPhaseCode><OPTION VALUE=\"\">Please Choose</OPTION>";
        String ProductAreaCombo = "<select name=ProductArea id='ProductArea' ><OPTION VALUE=\"\">Please Choose</OPTION>";
        List productUsersToList = new ArrayList<String>();
        List otherUsersToList = new ArrayList<String>();
        try {
            this.setAlias(alias);
            this.makeConnection();
            Statement stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (getAllUsers()) {
                while (moveNext()) {
                    String userNameDesc = getData("UserName");
                    if (!userNameDesc.equals("admin")) {
                        String ids = getData("UserID");
                        productUserscombo += "<OPTION VALUE=\"" + ids + "\" ";
                        productUserscombo += ">" + userNameDesc + "</OPTION>";
                        Map productUsersTo = new HashMap();
                        productUsersTo.put("id", ids);
                        productUsersTo.put("name", userNameDesc);
                        productUsersToList.add(productUsersTo);
                    }
                }
            } else {
                productUserscombo += "<option value=\"0\">---------------------------</option>";
            }
            productUserscombo += "</select>";
            String otherUserscombo = "<select name=cpyToCombo multiple size=3 onclick=\"CheckSingleSelection()\">";
            RequestManager rmSQL = new RequestManager();
            this.setAlias(alias);
            while (rs.next()) {
                requestTemplate = new RequestTemplate(templateID,
                        rs.getString("templatename"));
                requestTemplate.setProject(rs.getString("project") == null ? ""
                        : rs.getString("project"));
                requestTemplate.setProduct(rs.getString("product"));
                requestTemplate.setArea(rs.getString("area") == null ? "" : rs
                        .getString("area"));
                String ackUsers = rs.getString("acknowledgeusers") == null ? ""
                        : rs.getString("acknowledgeusers");
                String trustedUsers = rs.getString("trustedusers") == null ? ""
                        : rs.getString("trustedusers");
                List trustUserList = new ArrayList();
                templateMap.put("trustedusersraw", trustedUsers);
                templateMap.put("ackusersraw", ackUsers);
                if (trustedUsers.split(",") != null) {
                    User user;
                    String[] trustUsersArr = trustedUsers.split(",");
                    for (int i = 0; i < trustUsersArr.length; i++) {
                        user = new User();
                        user.setUserID(trustUsersArr[i]);
                        trustUserList.add(user);
                    }
                }
                requestTemplate.setTrustedUsers(trustUserList);
                List ackUserList = new ArrayList();
                if (ackUsers.split(",") != null) {
                    User user;
                    String[] ackUsersArr = ackUsers.split(",");
                    for (int i = 0; i < ackUsersArr.length; i++) {
                        user = new User();
                        user.setUserID(ackUsersArr[i]);
                        ackUserList.add(user);
                    }
                }
                requestTemplate.setAcknowledgeUsers(ackUserList);
                requestTemplate
                        .setAssingedTo(rs.getString("assignedto") == null ? ""
                                : rs.getString("assignedto"));
                requestTemplate.setClient(rs.getString("client"));
                requestTemplate.setEstimatedHours(rs
                        .getString("estimatedhours") == null ? "" : rs
                        .getString("estimatedhours"));
                requestTemplate.setModule(rs.getString("modules") == null ? ""
                        : rs.getString("modules"));
                requestTemplate
                        .setPhaseDetected(rs.getString("phasedetected") == null ? ""
                                : rs.getString("phasedetected"));
                requestTemplate
                        .setPhaseInjected(rs.getString("phaseinjected") == null ? ""
                                : rs.getString("phaseinjected"));
                requestTemplate
                        .setPriority(rs.getString("priority") == null ? "" : rs
                                .getString("priority"));
                requestTemplate.setProduct(rs.getString("product") == null ? ""
                        : rs.getString("product"));
                requestTemplate.setProject(rs.getString("project") == null ? ""
                        : rs.getString("project"));
                requestTemplate
                        .setRequestSource(rs.getString("requestsource") == null ? ""
                                : rs.getString("requestsource"));
                requestTemplate.setRequestType(rs.getString("requesttype"));
                requestTemplate
                        .setSeverityID(rs.getString("severity") == null ? ""
                                : rs.getString("severity"));
                requestTemplate.setTemplateID(rs.getString("templateid"));
                requestTemplate.setTemplateName(rs.getString("templatename"));
                requestTemplate.setTrustedUserFilter(rs.getString(
                        "trusteduserfilter").equalsIgnoreCase("y") ? true
                        : false);
                requestTemplate.setVersionDetected(rs
                        .getString("versiondetected") == null ? "" : rs
                        .getString("versiondetected"));
                requestTemplate.setAddedBy(rs.getString("addedby") == null ? ""
                        : rs.getString("addedby"));
                /**
                 * format the date before sending to the view
                 */
                DateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
                String formattedDate = "";
                if (rs.getDate("targetdate") != null) {
                    formattedDate = formatter.format(rs.getDate("targetdate"))
                            .toString();
                }
                requestTemplate.setTargetDate(formattedDate);
                System.out
                        .println("*******************template details initialized:");
            }

            if (!requestTemplate.getProduct().equalsIgnoreCase("")) {
                String rid = requestTemplate.getProject();
                if (this.getProjects(requestTemplate.getProduct())) {
                    String projectid, projectname;
                    while (moveNext()) {
                        projectid = getData("ID");
                        projectname = getData("Project");
                        projectcombo += "<OPTION VALUE=\"" + projectid + "\"";
                        if (requestTemplate.getProject() != null) {
                            if (rid.equals(requestTemplate.getProject())) {
                                projectcombo += " selected";
                            }

                        }
                        projectcombo += ">" + projectname + "</OPTION>";

                    }
                }
            }
            projectcombo += "</select>";
            if (!requestTemplate.getProduct().equals("")) {
                modulecombo = "<select name = \"ProductModule\">"
                        + "<option value=\"\">Please Choose</option>";
                String pm = "";
                if (getListOfModules(requestTemplate.getProduct())) {
                    while (moveNext()) {
                        pm = getData("ID");
                        modulecombo += "<OPTION VALUE=\"" + pm + "\" ";
                        if (requestTemplate.getModule() != null) {
                            if (pm.equals(requestTemplate.getModule())) {
                                modulecombo += " selected";
                            }
                        }
                        modulecombo += ">"
                                + TextEncoder.encode(getData("Module"))
                                + "</OPTION>";
                    }
                }
            } else {
                modulecombo += "<select>";
                modulecombo += "<option value=\"0\">-----------------------</option></select>";
            }

            assignedTocombo = "<select name=AssignedTo id='AssignedTo'>";
            assignedTocombo += "<option value=\"\">Please Choose</option>";
            if (getProductUsers(requestTemplate.getProduct())) {
                while (moveNext()) {
                    String loginNameDesc = "(" + getData("UserName") + ")";
                    String ids = getData("UserID");
                    assignedTocombo += "<OPTION VALUE=\"" + ids + "\" ";
                    if (ids.equals(requestTemplate.getAssingedTo())) {
                        assignedTocombo += " selected";
                    }
                    assignedTocombo += ">" + getData("UserName")
                            + loginNameDesc + "</OPTION>";

                }
            } else {
                assignedTocombo += "<option value=\"0\">-----------------------</option>";
            }
            assignedTocombo += "</select>";

            if (!requestTemplate.getProduct().equals("")) {
                versionDetectedcombo = "<select name = \"RelVersion\" id=\"RelVersion\">";
                versionDetectedcombo += "<option value=\"\">Please Choose</option>";
                String vd = "";
                if (getListOfVersions(requestTemplate.getProduct())) {

                    while (moveNext()) {
                        vd = getData("ID");
                        versionDetectedcombo += "<OPTION VALUE=\"" + vd + "\" ";
                        if (requestTemplate.getVersionDetected() != null
                                && !requestTemplate.getVersionDetected()
                                .equals("")) {
                            if (vd.equals(requestTemplate.getVersionDetected())) {
                                versionDetectedcombo += " selected";
                            }
                        } else if (getData("Version").trim().equals("N/A")
                                || getData("Version").trim().equalsIgnoreCase(
                                "NA")) {
                            versionDetectedcombo += " selected";
                        }
                        versionDetectedcombo += ">"
                                + TextEncoder.encode(getData("Version"))
                                + "</OPTION>";
                    }
                }
                versionDetectedcombo += "</select>";
            } else {
                versionDetectedcombo += "<select name = \"RelVersion\" id=\"RelVersion\">";
                versionDetectedcombo += "<option value=\"0\">-----------------------</option></select>";
            }

            /*
             * productUserscombo=
             * "<select name=copyToCombo multiple size=3 onclick=\"CheckSingleSelect()\">"
             * ; if (getAllUsers()) { while(moveNext()) { String userNameDesc =
             * getData("UserName"); if(!userNameDesc.equals("admin")) { String
             * ids = getData("UserID");
             * productUserscombo+="<OPTION VALUE=\""+ids+"\" ";
             * productUserscombo+=">"+userNameDesc+"</OPTION>"; Map
             * productUsersTo=new HashMap(); productUsersTo.put("id", ids);
             * productUsersTo.put("name", userNameDesc);
             * productUsersToList.add(productUsersTo); } } } else {
             * productUserscombo
             * +="<option value=\"0\">---------------------------</option>"; }
             * productUserscombo+="</select>";
             */
            otherUserscombo = "<select name=cpyToCombo multiple size=3 onclick=\"CheckSingleSelection()\">";

            if (getNonProductUsers(requestTemplate.getProduct())) {
                while (moveNext()) {
                    String userNameDesc = getData("UserName");
                    if (!userNameDesc.equals("admin")) {
                        String ids = getData("UserID");
                        otherUserscombo += "<OPTION VALUE=\"" + ids + "\" ";
                        otherUserscombo += ">" + userNameDesc + "</OPTION>";
                        Map otherUsersTo = new HashMap();
                        otherUsersTo.put("id", ids);
                        otherUsersTo.put("name", userNameDesc);
                        otherUsersToList.add(otherUsersTo);

                    }
                }
            } else {
                otherUserscombo += "<option value=\"0\">---------------------------</option>";
            }
            otherUserscombo += "</select>";

            PhaseInjectedCombo += "<OPTION VALUE=\"\">Please Choose</OPTION>";
            String phaseinjectcode = "";
            if (getListOfRequestInjectedPhases(requestTemplate.getProduct())) {
                while (moveNext()) {
                    phaseinjectcode = getData("RequestPhaseID");
                    PhaseInjectedCombo += "<OPTION VALUE=\"" + phaseinjectcode
                            + "\" ";
                    if (requestTemplate.getPhaseInjected() != null) {
                        if (phaseinjectcode.equals(requestTemplate
                                .getPhaseInjected())) {
                            PhaseInjectedCombo += "selected";
                        }
                    }

                    PhaseInjectedCombo += ">" + getData("RequestPhaseDesc")
                            + "</OPTION>";
                }
            } else {
                PhaseInjectedCombo += "<option value=\"\">---------------------------</option>";
            }
            PhaseInjectedCombo += "</select>";

            PhaseDetectedCombo += "<OPTION VALUE=\"\">Please Choose</OPTION>";
            String phasedetectcode = "";
            if (getListOfRequestPhases(requestTemplate.getProduct())) {
                while (moveNext()) {
                    phasedetectcode = getData("RequestPhaseID");
                    PhaseDetectedCombo += "<OPTION VALUE=\"" + phasedetectcode
                            + "\" ";
                    if (requestTemplate.getPhaseDetected() != null) {
                        if (phasedetectcode.equals(requestTemplate
                                .getPhaseDetected())) {
                            PhaseDetectedCombo += "selected";
                        }
                    }

                    PhaseDetectedCombo += ">" + getData("RequestPhaseDesc")
                            + "</OPTION>";
                }
            } else {
                PhaseDetectedCombo += "<option value=\"\">---------------------------</option>";
            }
            PhaseDetectedCombo += "</select>";
            if (getProjectAreas(requestTemplate.getProject())) {
                String areacode, areaname;
                while (moveNext()) {
                    areacode = getData("areaid");
                    ProductAreaCombo += "<OPTION VALUE=\"" + areacode + "\" ";
                    if (requestTemplate.getArea() != null) {
                        if (areacode.equals(requestTemplate.getArea())) {
                            ProductAreaCombo += "selected";
                        }
                    }

                    ProductAreaCombo += ">" + getData("areaname") + "</OPTION>";
                }
            } else {
                PhaseDetectedCombo += "<option value=\"\">---------------------------</option>";
            }
            ProductAreaCombo += "</SELECT>";

            productcombo = "<select id=ProductID name=ProductID onChange=\"productChange()\" ><option value=\"\">Please Choose</option>";
            if (!requestTemplate.getClient().equalsIgnoreCase("")) {
                String rid = "";
                UserManager umSQL = new UserManager();
                umSQL.setAlias(alias);
                umSQL.makeConnection();
                if (umSQL.getClientProducts(requestTemplate.getClient())) {
                    while (umSQL.moveNext()) {
                        rid = umSQL.getParam("ProductID");
                        productcombo += "<OPTION VALUE=\"" + rid + "\"";
                        if (requestTemplate.getProduct() != null) {
                            if (rid.equals(requestTemplate.getProduct())) {
                                productcombo += " selected";
                            }
                        }
                        productcombo += ">" + umSQL.getParam("ProductName")
                                + "</OPTION>";
                    }
                }
                umSQL.takeDown();
            }
            productcombo += "</select>";

            templateMap.put("projectcombo", projectcombo);
            templateMap.put("modulecombo", modulecombo);
            templateMap.put("assignedTocombo", assignedTocombo);
            templateMap.put("versionDetectedcombo", versionDetectedcombo);
            templateMap.put("productUserscombo", productUserscombo);
            templateMap.put("otherUserscombo", otherUserscombo);
            templateMap.put("versionFixedcombo", versionFixedcombo);
            templateMap.put("PhaseInjectedCombo", PhaseInjectedCombo);
            templateMap.put("PhaseDetectedCombo", PhaseDetectedCombo);
            templateMap.put("ProductAreaCombo", ProductAreaCombo);
            templateMap.put("productcombo", productcombo);
            templateMap.put("ProductUsersToList", productUsersToList);
            templateMap.put("OtherUsersToList", otherUsersToList);
            templateMap.put("estimatedhours",
                    requestTemplate.getEstimatedHours());
            templateMap.put("templatename", requestTemplate.getTemplateName());
            templateMap.put("project", requestTemplate.getProject());
            templateMap.put("product", requestTemplate.getProduct());
            templateMap.put("area", requestTemplate.getArea());
            templateMap.put("client", requestTemplate.getClient());
            templateMap.put("trusteduserfilter",
                    requestTemplate.isTrustedUserFilter());
            templateMap.put("assignedto", requestTemplate.getAssingedTo());
            templateMap.put("acknowledgeusers",
                    requestTemplate.getAcknowledgeUsers());
            templateMap.put("priority", requestTemplate.getPriority());
            templateMap.put("source", requestTemplate.getRequestSource());
            templateMap.put("requesttype", requestTemplate.getRequestType());
            templateMap.put("versiondet", requestTemplate.getVersionDetected());
            templateMap
                    .put("phaseinjected", requestTemplate.getPhaseInjected());
            templateMap
                    .put("phasedetected", requestTemplate.getPhaseDetected());
            templateMap.put("severity", requestTemplate.getSeverityID());
            templateMap.put("targetdate", requestTemplate.getTargetDate());
            templateMap.put("module", requestTemplate.getModule());
            templateMap.put("targetversion",
                    requestTemplate.getTargetedVersion());
            templateMap.put("addedby", requestTemplate.getAddedBy());

            this.takeDown();
        } catch (Exception e) {
            System.out.println("exception getting template details:"
                    + e.getMessage());
        }
        return templateMap;
    }

    /**
     *
     * getProjects queryBeanPM <li>to get the projects of a given product</li>
     *
     * @param productid
     * @return
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Jun 11, 2010
     *
     */
    public boolean getProjects(String productid) {
        if (!productid.equals("")) {
            String sql = "SELECT DISTINCT ProjectID as ID,ProjectName as Project FROM OAM_RM_PROJECTS WHERE 1=1 and (isClosed!='Y' or isClosed is null) AND ProductID='"
                    + productid + "' order by  ProjectName";
            return getList(sql, "projects");
        }
        return false;
    }

    /**
     *
     * getProjectAreas queryBeanPM <li>to get the projectareas given the
     * projectid</li>
     *
     * @param projectid
     * @return
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Jun 11, 2010
     *
     */
    public boolean getProjectAreas(String projectid) {
        if (!projectid.equals("")) {
            String sql = "SELECT productid, " + "       prj.projectid, "
                    + "       prj.projectname, "
                    + "       rel.projectareaid as areaid, "
                    + "       ar.productareadesc as areaname "
                    + " FROM   oam_rm_project_area_rel rel "
                    + "       inner join oam_rm_projects prj "
                    + "         ON prj.projectid = rel.projectid "
                    + "       inner join oam_rm_product_area ar "
                    + "         ON ar.productareaid = rel.projectareaid "
                    + " WHERE  prj.projectid =" + projectid;
            return getList(sql, "projectarea");
        }
        return false;
    }

    /**
     *
     * setUserSettings queryBeanPM Description: <li>Sets the user settings to
     * backend</li>
     *
     * @param params
     * @return void
     * @author:Ramesh Raj Baral
     * @since:Jun 21, 2010
     *
     */
    public void setUserSettings(String[] params) {
        String userID = params[0];
        String defaultlightfilter = params[1];
        String sql = "MERGE INTO oam_rm_user_preferences pref "
                + "USING (SELECT '" + userID + "' userid "
                + "       FROM   dual)pref1 "
                + "ON (pref1.userid=pref.userid) " + "WHEN matched THEN "
                + "  UPDATE SET defaultlightfilter='" + defaultlightfilter
                + "' " + "WHEN NOT matched THEN "
                + "  INSERT (userid,islightpage,defaultlightfilter)"
                + "  VALUES ('" + userID + "','n','" + defaultlightfilter
                + "')";
        // System.out.println("merge query:"+sql);
        try {
            this.connectDB();
            stmt = myConn.createStatement();
            stmt.execute(sql);
        } catch (Exception ex) {
            System.out.println("exception upserting user settings:"
                    + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("user settings saved");
    }

    /**
     *
     * getSelectedRequests queryBeanPM Description: returns the request details,
     * whose ids are sent as the parameter
     *
     * @param requestIDs
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jun 21, 2010
     *
     */
    public List getSelectedRequests(String userID, String requestIDs) {
        maxRecordsFound = 0;
        String requests[];
        String validRequests = "";
        String parentRequestCodes = "";
        List requestsList = new ArrayList();
        List notExitingRequestsList = new ArrayList();
        List validRequestsList = new ArrayList();
        String[] validRequestTokens = null;

        if (requestIDs.split(",") != null) {
            Pattern pat = Pattern.compile("[0-9]*");
            Matcher mat;
            requests = requestIDs.split(",");
            for (int i = 0; i < requests.length; i++) {
                String requestID = requests[i].trim();
                /**
                 * remove unnecessary characters if any present in the request
                 * token if this token contains such invalid characters then
                 * discard the token some invalid characters-&,",',or any such
                 * characters
                 */
                mat = pat.matcher(requestID);
                if (mat.matches()) {
                    requestsList.add(requestID.trim());
                } else {
                    // invalid requestid submitted
                }

            }

            if (userID.trim().length() < 1) {
                // this means that the user is already having access to thse
                // requests
                // donot need to check the access of the user to this request
                for (int i = 0; i < requestsList.size(); i++) {
                    if (i == 0) {
                        validRequests = "'"
                                + Integer.parseInt(requestsList.get(i)
                                        .toString()) + "'";
                    } else {
                        validRequests += ",'"
                                + Integer.parseInt(requestsList.get(i)
                                        .toString()) + "'";
                    }

                }
            } else {
                validRequestsList = this.getUserAccessedRequests(userID,
                        requestsList);

                for (int i = 0; i < validRequestsList.size(); i++) {
                    UserRequest request = new UserRequest();
                    request = (UserRequest) validRequestsList.get(i);
                    if (request.isExists() && request.isAccess()) {
                        if (i == 0) {
                            validRequests = "'"
                                    + Integer
                                    .parseInt(request.getRequestCode())
                                    + "'";
                        } else {
                            validRequests += ",'"
                                    + Integer
                                    .parseInt(request.getRequestCode())
                                    + "'";
                        }
                    }
                }

            }

        }
        String sql_countQuery = "SELECT COUNT(*) AS TOTALCOUNT FROM(";
        String sql = "SELECT DISTINCT a.requestcode, "
                + "                a.requestingperson, "
                + "                a.requesttitle, "
                + "                a.requests, "
                + "                a.requestdate, "
                + "                a.targetcompdate, "
                + "                a.clientid, "
                + "                a.productid, "
                + "                a.projectid, "
                + "                a.severityid, "
                + "                a.requesttypeid, "
                + "                a.iscompleted, "
                + "                a.statusdesc, "
                + "                a.requesttitle, "
                + "                a.clientname, "
                + "                a.productname, "
                + "                a.projectname, "
                + "                a.severitydesc, "
                + "                a.requesttypedesc, "
                + "                a.assignedto, "
                + "                a.requesttypedesc, "
                + "                a.requestpriority, "
                + "                a.documentcount, "
                + "                a.productarea, "
                + "                a.inwatch, "
                + "                a.docs, "
                + "				a.phaseinjecteddesc,"
                + "				a.phasedetecteddesc,"
                + "                CASE "
                + "                  WHEN request.parentrequestcode IS NULL THEN 'N' "
                + "                  ELSE request.parentrequestcode "
                + "                END hasfollowups "
                + "FROM   (SELECT req.*, "
                + "               stat.statusdesc, "
                + "               cl.clientname, "
                + "               prod.productname, "
                + "               proj.projectname, "
                + "               sev.severitydesc, "
                + "               types.requesttypedesc, "
                + "				phasedet.requestphasedesc phasedetecteddesc, "
                + "				phaseinj.requestphasedesc phaseinjecteddesc, "
                + "               CASE "
                + "                 WHEN docs.doctype IS NULL THEN 'N' "
                + "                 ELSE 'Y' "
                + "               END               docs, "
                + "               watch.requestcode AS inwatch "
                + "        FROM   oam_rm_requestmanager req "
                + "               inner join oam_rm_requeststatus stat "
                + "                 ON stat.statusid = req.statusid "
                + "               inner join oam_rm_clients cl "
                + "                 ON cl.clientid = req.clientid "
                + "               inner join oam_rm_products prod "
                + "                 ON prod.productid = req.productid "
                + "               left join oam_rm_projects proj "
                + "                 ON proj.projectid = req.projectid "
                + "               left join oam_rm_request_severity sev "
                + "                 ON sev.severityid = req.severityid "
                + "               inner join oam_rm_request_types types "
                + "                 ON req.requesttypeid = types.requesttypeid "
                + "               left join oam_rm_mywatchlist watch "
                + "                 ON watch.requestcode = req.requestcode "
                + "               left join oam_rm_moredocuments1 docs "
                + "                 ON docs.requestcode = req.requestcode "
                + "				left join oam_rm_request_phase phaseinj"
                + "				on phaseinj.requestphaseid=req.phaseinject"
                + "				left join oam_rm_request_phase phasedet"
                + "				on req.phasedetected=phasedet.requestphaseid";
        if (validRequests.trim().length() > 0) {
            sql += " WHERE REQUESTCODE IN(" + validRequests + ")";
            sql += " OR PKSOURCE  IN(" + validRequests + ")";
            sql_countQuery += sql + ")a ";
            sql += " AND ROWNUM<500)a ";
            sql += " left join oam_rm_requestmanager request ";
            sql_countQuery += " left join oam_rm_requestmanager request ";
            sql += "  ON request.parentrequestcode = a.requestcode ";
            sql_countQuery += " ON request.parentrequestcode = a.requestcode )";
        } else if (validRequestsList != null && validRequestsList.size() > 0) {// request
            // were
            // present
            // or
            // not
            // accessible
            // to
            // the
            // user
            return validRequestsList;
        } else {
            /**
             * if user has no request code but only presses enter key in quick
             * jump field then get defult requests for this user
             */
            System.out
                    .println("user provided no request code populating default list");
            UserPreference userPreference = new UserPreference();
            requestsList = this.getUsersAllRequestDetails(userID,
                    userPreference);
            return requestsList;
        }
        try {

            this.connectDB();
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            UserRequest request;
            requestsList = new ArrayList();
            while (rs.next()) {
                request = new UserRequest();
                request.setRequestCode(rs.getString("requestcode"));
                String ackUsers = "";// rs.getString("acknowledgeusers");
                String requestingUserID = rs.getString("requestingperson");
                User requestingUser = new User();
                requestingUser.setUserID(requestingUserID);
                request.setRequestingUser(requestingUser);
                request.setAddedBy(requestingUserID);
                request.setRequestTitle(rs.getString("requesttitle"));
                request.setDescription(rs.getString("requests") == null ? ""
                        : rs.getString("requests"));
                String requestDate = rs.getString("requestdate") == null ? ""
                        : rs.getString("requestdate");
                if (requestDate.length() > 0) {
                    requestDate = requestDate.split(" ")[0];
                }
                request.setRequestDate(requestDate);
                String targetDate = rs.getString("targetcompdate") == null ? ""
                        : rs.getString("targetcompdate");
                if (targetDate.length() > 0) {
                    targetDate = targetDate.split(" ")[0];
                }
                request.setTargetDate(targetDate);
                request.setClientName(rs.getString("clientname"));
                request.setClient(rs.getString("clientid"));
                request.setProductName(rs.getString("productname"));
                request.setProduct(rs.getString("productid"));
                request.setProjectName(rs.getString("projectname") == null ? ""
                        : rs.getString("projectname"));
                request.setProject(rs.getString("projectid") == null ? "" : rs
                        .getString("projectid"));
                request.setStatusID(rs.getString("statusdesc") == null ? ""
                        : rs.getString("statusdesc"));
                request.setPriority(rs.getString("requestpriority") == null ? ""
                        : rs.getString("requestpriority"));
                request.setSeverityID(rs.getString("severityid") == null ? ""
                        : rs.getString("severityid"));
                request.setSeverityName(rs.getString("severitydesc") == null ? ""
                        : rs.getString("severitydesc"));
                request.setRequestType(rs.getString("requesttypeid"));
                request.setRequestTypeName(rs.getString("requesttypedesc"));
                request.setAssingedTo(rs.getString("assignedto"));
                String hasFollowUps = rs.getString("hasfollowups") == null ? "N"
                        : rs.getString("hasfollowups");
                request.setHasFollowUps(hasFollowUps.equalsIgnoreCase("N") ? false
                        : true);
                String isCompletedString = rs.getString("iscompleted") == null ? "n"
                        : rs.getString("iscompleted");
                boolean isCompleted = isCompletedString.equalsIgnoreCase("y") ? true
                        : false;
                request.setCompleted(isCompleted);
                String reqCompCode = rs.getString("iscompleted") == null ? "n"
                        : rs.getString("iscompleted");
                request.setReqCompCode(reqCompCode);
                request.setAssignedToUser(this.getUserDetails(request
                        .getAssingedTo()));
                boolean inWatch = (rs.getString("inwatch") == null || rs
                        .getString("inwatch").trim().length() < 1) ? false
                        : true;
                request.setInWatchList(inWatch);
                boolean hasAttachment = rs.getString("docs") == null ? false
                        : rs.getString("docs").equalsIgnoreCase("N") ? false
                        : true;
                request.setHasAttachment(hasAttachment);
                request.setPhaseDetected(rs.getString("phasedetecteddesc") == null ? ""
                        : rs.getString("phasedetecteddesc"));
                request.setPhaseInjected(rs.getString("phaseinjecteddesc") == null ? ""
                        : rs.getString("phaseinjecteddesc"));
                request.setAccess(true);
                requestsList.add(request);
            }

            rs = stmt.executeQuery(sql_countQuery);
            if (rs.next()) {
                maxRecordsFound = rs.getInt("totalcount");
            }

        } catch (Exception ex) {
            System.out.println("the request retrieve query is:" + sql);
            System.out.println("the request to retrieve count query is:"
                    + sql_countQuery);
            System.out
                    .println("Exception occured while getting comma separated request details:"
                            + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("number of requests retrieved:"
                + requestsList.size());
        return requestsList;

    }

    /**
     *
     * getUsersAllRequestDetails queryBeanPM Description: return the List of
     * requests if the user has set preferred projects then retrieved from the
     * preferred projects else retrieve from all the proejcts in which the user
     * has access to
     *
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jun 22, 2010
     *
     */
    public List getUsersAllRequestDetails(String userID,
            UserPreference userPreference) {
        List requestsList = new ArrayList();
        UserFilters userFilter = (UserFilters) userPreference
                .getUserDefaultFilter();
        String reqOwner = (userFilter.getRequestOwner() == null || userFilter
                .getRequestOwner().equals("0")) ? "" : userFilter
                .getRequestOwner();
        String reqPriority = (userFilter.getRequestPriority() == null || userFilter
                .getRequestPriority().equals("0")) ? "" : userFilter
                .getRequestPriority();
        String reqSeverity = (userFilter.getRequestSeverity() == null || userFilter
                .getRequestSeverity().equals("0")) ? "" : userFilter
                .getRequestSeverity();
        String reqStatus = (userFilter.getRequestStatus() == null || userFilter
                .getRequestStatus().equals("0")) ? "" : userFilter
                .getRequestStatus();
        String reqType = (userFilter.getRequestType() == null || userFilter
                .getRequestType().equals("0")) ? "" : userFilter
                .getRequestType();
        String sql = "select b.* from( SELECT DISTINCT a.requestcode, "
                + "                a.requestingperson, "
                + "                a.requesttitle, "
                + "                a.requests, "
                + "                a.requestdate, "
                + "                a.targetcompdate, "
                + "                a.clientid, "
                + "                a.productid, "
                + "                a.projectid, "
                + "                a.severityid, "
                + "                a.iscompleted, "
                + "                a.statusdesc, "
                + "                a.clientname, "
                + "                a.productname, "
                + "                a.projectname, "
                + "                a.severitydesc, "
                + "                a.requesttypeid, "
                + "                a.assignedto, "
                + "                a.requesttypedesc, "
                + "                a.requestpriority, "
                + "                a.documentcount, "
                + "                a.productarea, "
                + "                a.inwatch, "
                + "                a.docs, "
                + "					a.phaseinjecteddesc,"
                + "					a.phasedetecteddesc,"
                + "                  a.dataproviderid,"
                + "                CASE "
                + "                  WHEN request.parentrequestcode IS NULL THEN 'N' "
                + "                  ELSE request.parentrequestcode "
                + "                END hasfollowups "
                + "FROM  (SELECT b.* "
                + "       FROM   (SELECT watch.requestcode    AS inwatch, "
                + "                      req.requestcode      requestcode, "
                + "                      req.pksource         pksource, "
                + "                      req.requesttypeid    requesttypeid, "
                + "                      req.requestingperson requestingperson, "
                + "                      req.statusid         statusid, "
                + "                      req.assignedto       assignedto, "
                + "                      req.clientid         clientid, "
                + "                      req.requestdate      requestdate, "
                + "                      req.requests         requests, "
                + "                      req.targetcompdate   targetcompdate, "
                + "                      req.requestpriority  requestpriority, "
                + "                      req.iscompleted      iscompleted, "
                + "                      req.documentcount    documentcount, "
                + "                      req.severityid       severityid, "
                + "                      req.phaseinject      phaseinject, "
                + "                      req.productarea      productarea, "
                + "                      req.productid        productid, "
                + "                      req.projectid        projectid, "
                + "                      prod.productname, "
                + "                      proj.projectname, "
                + "                      req.requestingperson username, "
                + "                      stat.statusdesc, "
                + "                      req.requesttitle, "
                + "                      cl.clientname, "
                + "                      sev.severitydesc, "
                + "                      types.requesttypedesc, "
                + "					phasedet.requestphasedesc phasedetecteddesc,"
                + "   				phaseinj.requestphasedesc phaseinjecteddesc,"
                + "                  oamclient.clientid          dataproviderid,"
                + "                       CASE "
                + "                         WHEN docs.doctype IS NULL THEN 'N' "
                + "                         ELSE 'Y' "
                + "                       END                  docs "
                + "               FROM   "
                + request_tablename
                + " req "
                + "                      inner join oam_rm_requeststatus stat "
                + "                        ON stat.statusid = req.statusid "
                + "                      inner join oam_rm_clients cl "
                + "                        ON cl.clientid = req.clientid "
                + "                      inner join oam_rm_products prod "
                + "                        ON prod.productid = req.productid "
                + "                      inner join oam_rm_request_types types "
                + "                        ON req.requesttypeid = types.requesttypeid "
                + "                      left join oam_rm_projects proj "
                + "                        ON proj.projectid = req.projectid "
                + "                      left join oam_rm_request_severity sev "
                + "                        ON sev.severityid = req.severityid "
                + "                      left join oam_rm_mywatchlist watch "
                + "                        ON watch.requestcode = req.requestcode "
                + "                       left join oam_rm_moredocuments1 docs "
                + "                         ON docs.requestcode = req.requestcode "
                + "							left join oam_rm_request_phase phaseinj"
                + "							on phaseinj.requestphaseid=req.phaseinject"
                + "							left join oam_rm_request_phase phasedet"
                + "							on req.phasedetected=phasedet.requestphaseid"
                + "                          left join oam_clients oamclient ON"
                + "                          oamclient.clientid=req.dataproviderid";

        String fil = filterForLitePage.replaceAll("useridVar", userID);
        if (!(reqType.equals("0") || reqType.trim().length() < 1)) {
            fil += " AND req.REQUESTTYPEID='" + reqType + "'";
        }
        if (!(reqStatus.equals("0") || reqStatus.trim().length() < 1)) {
            fil += " AND req.STATUSID='" + reqStatus + "'";
        }
        if (!(reqPriority.equals("0") || reqPriority.trim().length() < 1)) {
            fil += " AND req.REQUESTPRIORITY='" + reqPriority + "'";
        }
        if (!(reqSeverity.equals("0") || reqSeverity.trim().length() < 1)) {
            fil += " AND req.SEVERITYID='" + reqSeverity + "'";
        }
        if (!(reqOwner.equals("0") || reqOwner.trim().length() < 1)) {
            if (reqOwner.equals("1")) {
                fil += " AND req.assignedto='" + userID + "'";
            } else if (reqOwner.equals("2")) {
                fil += " AND req.requestingperson='" + userID + "'";
            } else if (reqOwner.equals("3")) {
                fil += " AND (req.requestingperson='" + userID
                        + "' OR req.assignedto='" + userID + "')";
            }

        }

        sql += " WHERE" + fil;

        String preferredProjectIDS = "";
        UserManager userManager = new UserManager();
        List preferredProjectsList = userManager
                .getUserPreferredProjects(userID);
        if (preferredProjectsList != null && preferredProjectsList.size() > 0) {
            for (int i = 0; i < preferredProjectsList.size(); i++) {
                UserProject userProject = (UserProject) preferredProjectsList
                        .get(i);
                preferredProjectIDS += (i == 0) ? ("'"
                        + userProject.getProjectID() + "'") : (",'"
                        + userProject.getProjectID() + "'");
            }
        }
        // System.out.println("preferred projects:"+preferredProjectIDS);
        if (preferredProjectIDS.length() > 0) {
            sql += "AND proj.projectid in(" + preferredProjectIDS + ")";
        }
        sql += " order by requestdate desc)b )a ";
        sql += " left join " + request_tablename + " request ";
        sql += " ON request.parentrequestcode = a.requestcode ";

        String sql_countQuery = "SELECT COUNT(*)AS TOTALCOUNT FROM(" + sql
                + ")b)countQuery";
        // System.out.println("search parameters were:reqowner"+reqOwner+"..prior:"+reqPriority+"..sever:"+reqSeverity+"..stat:"+reqStatus+"...reqtype:"+reqType);
        // System.out.println("count query:"+sql_countQuery);
        try {
            this.connectDB();
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql_countQuery);
            while (rs.next()) {
                maxRecordsFound = rs.getString("totalcount") == null ? 0
                        : Integer.parseInt(rs.getString("totalcount"));
            }
            if (maxRecordsFound > 500) {
                // if count is less than 500 then donot consider this filter
                sql += filterForLessNumbers;
                sql += ")b where  ROWNUM <= 500 ";
            } else {
                sql += " ORDER  BY requestdate DESC)b where  ROWNUM <= 500 ";
            }

            System.out
                    .println("*******************************populatess default requests query:"
                            + sql);
            rs = stmt.executeQuery(sql);
            UserRequest request;
            while (rs.next()) {
                // System.out.println("inside while loop ");
                request = new UserRequest();
                request.setRequestCode(rs.getString("requestcode"));
                String ackUsers = "";
                List ackUsersList = new ArrayList();
                if (ackUsers.length() > 0 && ackUsers.split(",").length > 0) {
                    String ackUsersArr[] = ackUsers.split(",");
                    User user;
                    for (int i = 0; i < ackUsersArr.length; i++) {
                        user = new User();
                        user.setUserID(ackUsersArr[i]);
                        ackUsersList.add(user);
                    }

                }
                request.setAcknowledgeUsers(ackUsersList);
                User user = new User();
                user.setUserID(rs.getString("requestingperson"));
                request.setAddedBy(user.getUserID());
                request.setRequestingUser(user);
                request.setRequestTitle(rs.getString("requesttitle"));
                request.setDescription(rs.getString("requests") == null ? ""
                        : rs.getString("requests"));
                String requestDate = rs.getString("requestdate") == null ? ""
                        : rs.getString("requestdate");
                if (requestDate.length() > 0) {
                    requestDate = requestDate.split(" ")[0];
                }
                request.setRequestDate(requestDate);
                request.setClient(rs.getString("clientname"));
                request.setProduct(rs.getString("productid"));
                request.setProject(rs.getString("projectid"));
                request.setProductName(rs.getString("productname"));
                request.setProjectName(rs.getString("projectname"));
                request.setStatusID(rs.getString("statusdesc") == null ? ""
                        : rs.getString("statusdesc"));
                request.setPriority(rs.getString("requestpriority") == null ? ""
                        : rs.getString("requestpriority"));
                request.setSeverityName(rs.getString("severitydesc") == null ? ""
                        : rs.getString("severitydesc"));
                request.setSeverityID(rs.getString("severityid") == null ? ""
                        : rs.getString("severityid"));
                request.setDocumentCount(rs.getInt("documentcount"));
                // request.setActionTaken(rs.getString("actiontaken"));
                request.setAssingedTo(rs.getString("assignedto"));
                request.setRequestType(rs.getString("requesttypeid") == null ? ""
                        : rs.getString("requesttypeid"));
                request.setRequestTypeName(rs.getString("requesttypedesc") == null ? ""
                        : rs.getString("requesttypedesc"));
                user = this.getUserDetails(request.getAssingedTo());
                request.setAssignedToUser(user);
                String targetDate = rs.getString("targetcompdate") == null ? ""
                        : rs.getString("targetcompdate");
                if (targetDate.length() > 0) {
                    targetDate = targetDate.split(" ")[0];
                }
                request.setTargetDate(targetDate);
                request.setCompleted((rs.getString("iscompleted") == null ? "N"
                        : rs.getString("iscompleted").charAt(0)).toString()
                        .equalsIgnoreCase("y") ? true : false);
                boolean inWatch = (rs.getString("inwatch") == null || rs
                        .getString("inwatch").trim().length() < 1) ? false
                        : true;
                request.setInWatchList(inWatch);
                String reqCompCode = rs.getString("iscompleted") == null ? "n"
                        : rs.getString("iscompleted");
                request.setReqCompCode(reqCompCode);
                boolean isCompleted = reqCompCode.equalsIgnoreCase("y") ? true
                        : false;
                request.setCompleted(isCompleted);
                String hasFollowUp = rs.getString("hasfollowups") == null ? "N"
                        : rs.getString("hasfollowups");
                request.setHasFollowUps(hasFollowUp.equalsIgnoreCase("N") ? false
                        : true);
                request.setPhaseDetected(rs.getString("phasedetecteddesc") == null ? ""
                        : rs.getString("phasedetecteddesc"));
                request.setPhaseInjected(rs.getString("phaseinjecteddesc") == null ? ""
                        : rs.getString("phaseinjecteddesc"));
                boolean hasAttachments = rs.getString("docs") == null ? false
                        : (rs.getString("docs").equalsIgnoreCase("N") ? false
                        : true);
                request.setHasAttachment(hasAttachments);

                requestsList.add(request);
            }

        } catch (Exception ex) {
            System.out
                    .println("Exception occured while getting request details:"
                            + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("number of requests retrieved:"
                + requestsList.size());
        return requestsList;

    }

    /**
     *
     * getUserDetails queryBeanPM Description:returns the user detail given the
     * userid
     *
     * @param userID
     * @return
     * @return User
     * @author:Ramesh Raj Baral
     * @since:Jun 22, 2010
     *
     */
    public User getUserDetails(String userID) {
        User user = new User();
        String sql = "SELECT *FROM USR_USERS WHERE USERID='" + userID + "'";
        /*
         * try{ //this.connectDB(); stmt=myConn.createStatement(); ResultSet
         * rs=stmt.executeQuery(sql); while(rs.next()){ user=new User();
         * user.setUserID(userID); user.setLoginName(rs.getString("loginname"));
         * user.setUserEmail(rs.getString("email"));
         * user.setUserName(rs.getString("username"));
         * 
         * } }catch(Exception ex){
         * System.out.println("exception getting user details"+ex.getMessage());
         * }
         */
        user.setUserID(userID);
        user.setUserName("Test User");
        return user;
    }

    /**
     *
     * getRequestsInWatchList queryBeanPM Description: retrieve the user's
     * request that are in his watch list
     *
     * @param userID
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jun 23, 2010
     *
     */
    public List getRequestsInWatchList(String userID) {
        maxRecordsFound = 0;
        List watchList = new ArrayList();
        String commaSeparatedReqIDs = "";
        String sql = "SELECT REQUESTCODE FROM OAM_RM_MYWATCHLIST WHERE USERID='"
                + userID + "'";
        try {
            this.connectDB();
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                if (commaSeparatedReqIDs.length() < 1) {
                    commaSeparatedReqIDs += rs.getString("requestcode");
                } else {
                    commaSeparatedReqIDs += "," + rs.getString("requestcode");
                }

            }
        } catch (Exception ex) {
            System.out.println("Exception getting the requests in watch list:"
                    + ex.getMessage());
        } finally {
            this.takeDown();
        }
        // System.out.println("getting watched request query:"+sql);
        if (commaSeparatedReqIDs.trim().length() > 0) {
            watchList = this.getSelectedRequests("", commaSeparatedReqIDs);
        }
        // System.out.println("no of requests in watchlist for:"+userID+"..........are:"+watchList.size());
        return watchList;
    }

    /**
     *
     * getUserAccessedRequests queryBeanPM <li>this method checks if the given
     * user has access to the requests provided in the commaseparated requestids
     * </li>
     *
     * @param userID
     * @param requestIDSList
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:June 23 , 2010
     *
     */
    public List getUserAccessedRequests(String userID, List requestIDSList) {
        maxRecordsFound = 0;
        List accessList = new ArrayList();
        UserRequest request;
        String sql_union = "";
        for (int i = 0; i < requestIDSList.size(); i++) {
            if (i > 0) {
                sql_union += "	UNION ";
            }
            sql_union += "	 SELECT  to_number('"
                    + requestIDSList.get(i).toString()
                    + "') request_code FROM   dual ";

        }
        String sql = "SELECT DISTINCT request_code, "
                + "                b.pksource, "
                + "                b.requestcode, "
                + "                b.productid, " + "                CASE "
                + "                  WHEN b.requestcode IS NULL THEN 'N' "
                + "                  ELSE 'E' " + "                END exist, "
                + "                CASE "
                + "                  WHEN c.productid IS NULL THEN 'N' "
                + "                  ELSE 'Y' " + "                END AS acc "
                + "FROM   (" + sql_union + ") a "
                + "       left join oam_rm_requestmanager b "
                + "         ON a.request_code = to_number(b.requestcode) "
                + "       left join (SELECT productid "
                + "                  FROM   tmp_oam_rm_user_product "
                + "                  WHERE  userid = '" + userID + "') c "
                + "         ON b.productid = c.productid ";

        String sql_countQuery = "SELECT COUNT(*)AS TOTALCOUNT FROM(" + sql
                + ")countQuery";
        try {
            this.connectDB();
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                request = new UserRequest();
                request.setProduct(rs.getString("productid"));
                request.setRequestCode(rs.getString("request_code"));
                request.setPkSource(rs.getString("pksource"));
                String access = rs.getString("acc");
                request.setAccess(access.equalsIgnoreCase("Y") ? true : false);
                String exists = rs.getString("exist");
                request.setExists(exists.equalsIgnoreCase("E") ? true : false);
                if (!request.isExists()) {
                    System.out
                            .println("********************not existing request code:"
                                    + request.getRequestCode());
                }
                if (!request.isAccess()) {
                    System.out
                            .println("**************************not accessible request:"
                                    + request.getRequestCode());
                }
                accessList.add(request);
            }
            rs = stmt.executeQuery(sql_countQuery);
            while (rs.next()) {
                maxRecordsFound = rs.getString("totalcount") == null ? 0
                        : Integer.parseInt(rs.getString("totalcount"));
            }
        } catch (Exception ex) {
            System.out
                    .println("Exception checking access of the given requests in quick jump search:"
                            + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("accessiblity check requests:" + accessList.size());
        return accessList;
    }

    /**
     *
     * getSearchRequestDetails queryBeanPM Description: <li>returns the requests
     * that match the given search criteria-type,severity,status,priority</li>
     *
     * @param userID
     * @param userFilter
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jun 24, 2010 OAM#112687 -only retrieve the projects that are in
     * user's preference,if the user preference is set OAM#113284-severity
     * fields should not be displayed in lite page
     *
     */
    public List getSearchRequestDetails(String userID, UserFilters userFilter) {
        List searchRequests = new ArrayList();
        List userPrefProjectslist = new ArrayList();
        UserManager userManager = new UserManager();
        String reqOwner = (userFilter.getRequestOwner() == null || userFilter
                .getRequestOwner().equals("0")) ? "" : userFilter
                .getRequestOwner();
        String reqPriority = (userFilter.getRequestPriority() == null || userFilter
                .getRequestPriority().equals("0")) ? "" : userFilter
                .getRequestPriority();
        String reqSeverity = (userFilter.getRequestSeverity() == null || userFilter
                .getRequestSeverity().equals("0")) ? "" : userFilter
                .getRequestSeverity();
        String reqStatus = (userFilter.getRequestStatus() == null || userFilter
                .getRequestStatus().equals("0")) ? "" : userFilter
                .getRequestStatus();
        String reqType = (userFilter.getRequestType() == null || userFilter
                .getRequestType().equals("0")) ? "" : userFilter
                .getRequestType();
        /**
         * if user has some project set in his preference then consider the
         * request of this projects only
         */
        // String
        // sql_userPrefProjects="select projectid from OAM_RM_PREFERREDPROJECTS where userid='"+userID+"'";
        String sql = "select b.* from( SELECT DISTINCT a.requestcode, "
                + "                a.requestingperson, "
                + "                a.requesttitle, "
                + "                a.requests, "
                + "                a.requestdate, "
                + "                a.targetcompdate, "
                + "                a.clientid, "
                + "                a.productid, "
                + "                a.projectid, "
                + "                a.severityid, "
                + "                a.requesttypeid, "
                + "                a.iscompleted, "
                + "                a.statusdesc, "
                + "                a.clientname, "
                + "                a.productname, "
                + "                a.projectname, "
                + "                a.severitydesc, "
                + "                a.requesttypedesc, "
                + "                a.assignedto, "
                + "                a.requestpriority, "
                + "                a.documentcount, "
                + "                a.productarea, "
                + "                a.inwatch, "
                + "				a.phaseinjecteddesc,"
                + "				a.phasedetecteddesc,"
                + "                  a.dataproviderid,"
                + "                CASE "
                + "                  WHEN request.parentrequestcode IS NULL THEN 'N' "
                + "                  ELSE request.parentrequestcode "
                + "                END hasfollowups, "
                + "                a.docs "
                + "FROM   (SELECT b.* "
                + "        FROM   (SELECT watch.requestcode    AS inwatch, "
                + "                       req.requestcode      requestcode, "
                + "                       req.pksource         pksource, "
                + "                       req.requesttypeid    requesttypeid, "
                + "                       req.requestingperson requestingperson, "
                + "                       req.statusid         statusid, "
                + "                       req.assignedto       assignedto, "
                + "                       req.clientid         clientid, "
                + "                       req.requestdate      requestdate, "
                + "                       req.requests         requests, "
                + "                       req.targetcompdate   targetcompdate, "
                + "                       req.requestpriority  requestpriority, "
                + "                       req.iscompleted      iscompleted, "
                + "                       req.documentcount    documentcount, "
                + "                       req.severityid       severityid, "
                + "                       req.phaseinject      phaseinject, "
                + "                       req.productarea      productarea, "
                + "                       req.productid        productid, "
                + "                       req.projectid        projectid, "
                + "                       prod.productname, "
                + "                       proj.projectname, "
                + "                       req.requestingperson username, "
                + "                       stat.statusdesc, "
                + "                       req.requesttitle, "
                + "                       cl.clientname, "
                + "                       sev.severitydesc, "
                + "                       types.requesttypedesc, "
                + "					phasedet.requestphasedesc phasedetecteddesc,"
                + "					phaseinj.requestphasedesc phaseinjecteddesc,"
                + "                    oamclient.clientid          dataproviderid,"
                + "                       CASE "
                + "                         WHEN docs.doctype IS NULL THEN 'N' "
                + "                         ELSE 'Y' "
                + "                       END                  docs "
                + "                FROM   oam_rm_requestmanager req "
                + "                       inner join oam_rm_requeststatus stat "
                + "                         ON stat.statusid = req.statusid "
                + "                       inner join oam_rm_clients cl "
                + "                         ON cl.clientid = req.clientid "
                + "                       inner join oam_rm_products prod "
                + "                         ON prod.productid = req.productid "
                + "                       inner join oam_rm_request_types types "
                + "                         ON req.requesttypeid = types.requesttypeid "
                + "                       left join oam_rm_projects proj "
                + "                         ON proj.projectid = req.projectid "
                + "                       left join oam_rm_request_severity sev "
                + "                         ON sev.severityid = req.severityid "
                + "                       left join oam_rm_mywatchlist watch "
                + "                         ON watch.requestcode = req.requestcode "
                + "                       left join oam_rm_moredocuments1 docs "
                + "                         ON docs.requestcode = req.requestcode "
                + "						left join oam_rm_request_phase phaseinj"
                + "						on phaseinj.requestphaseid=req.phaseinject"
                + "						left join oam_rm_request_phase phasedet"
                + "						on req.phasedetected=phasedet.requestphaseid"
                + "                         left join oam_clients oamclient ON"
                + "                         oamclient.clientid=req.dataproviderid";

        String filter = filterForLitePage.replaceAll("useridVar", userID);
        sql += " WHERE " + filter;
        // concatenate the search parameters only if the parameters are not set
        // to "All"
        if (reqType.length() > 0 && !reqType.equals("0")) {
            sql += "   AND req.requesttypeid = '" + reqType + "' ";
        }
        if (reqStatus.length() > 0 && !reqStatus.equals("0")) {
            sql += "   AND req.statusid = '" + reqStatus + "' ";
        }
        if (reqPriority.length() > 0 && !reqPriority.equals("0")) {
            sql += "   AND req.requestpriority = '" + reqPriority + "' ";
        }
        if (reqSeverity.length() > 0 && !reqSeverity.equals("0")) {
            sql += "   AND req.severityid = '" + reqSeverity + "' ";
        }
        if (!(reqOwner.equals("0") || reqOwner.trim().length() < 1)) {
            if (reqOwner.equals("1")) {
                sql += " AND req.assignedto='" + userID + "'";
            } else if (reqOwner.equals("2")) {
                sql += " AND req.requestingperson='" + userID + "'";
            } else if (reqOwner.equals("3")) {
                sql += " AND (req.requestingperson='" + userID
                        + "' OR req.assignedto='" + userID + "')";
            }

        }
        userPrefProjectslist = userManager.getUserPreferredProjects(userID);
        if (userPrefProjectslist != null && userPrefProjectslist.size() > 0) {
            sql += " AND req.projectid IN(";
            for (int i = 0; i < userPrefProjectslist.size(); i++) {
                UserProject userProject = (UserProject) userPrefProjectslist
                        .get(i);
                sql += (i == 0) ? ("'" + userProject.getProjectID() + "'")
                        : ((",'" + userProject.getProjectID() + "'"));
            }
            sql += ")";
        }
        sql += " )b )a ";
        sql += " left join oam_rm_requestmanager request ";
        sql += " ON request.parentrequestcode = a.requestcode ";
        String sql_countQuery = "SELECT COUNT(*) AS TOTALCOUNT FROM(" + sql
                + ")b)countquery";
        // System.out.println("search parameters were:reqowner"+reqOwner+"..prior:"+reqPriority+"..sever:"+reqSeverity+"..stat:"+reqStatus+"...reqtype:"+reqType);
        // System.out.println("count query:"+sql_countQuery);
        try {
            this.connectDB();
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql_countQuery);
            System.out.println("*************countquery\n" + sql_countQuery);
            while (rs.next()) {
                maxRecordsFound = rs.getString("totalcount") == null ? 0
                        : Integer.parseInt(rs.getString("totalcount"));
            }
            if (maxRecordsFound > 500) {
                // if count is less than 500 then donot consider this filter
                System.out
                        .println("***************max records greater than 500:...."
                                + maxRecordsFound);
                sql += filterForLessNumbers;
                sql += ")b where  ROWNUM <= 500 ";
            } else {
                // sql+=" ORDER  BY requestdate DESC)b where  ROWNUM <= 500 ";
                System.out
                        .println("***********************max records less than or equal to 500:..."
                                + maxRecordsFound);
                sql += " ORDER  BY requestdate DESC)b ";
            }
            // System.out.println("query to retrieve requests by search parameters is:"+sql);
            rs = stmt.executeQuery(sql);
            UserRequest request;
            while (rs.next()) {
                // System.out.println("inside while loop ");
                request = new UserRequest();
                request.setRequestCode(rs.getString("requestcode"));
                String ackUsers = "";// rs.getString("acknowledgeusers");
                List ackUsersList = new ArrayList();
                if (ackUsers.length() > 0 && ackUsers.split(",").length > 0) {
                    String ackUsersArr[] = ackUsers.split(",");
                    User user;
                    for (int i = 0; i < ackUsersArr.length; i++) {
                        user = new User();
                        user.setUserID(ackUsersArr[i]);
                        ackUsersList.add(user);
                    }

                }
                request.setAcknowledgeUsers(ackUsersList);
                User user = new User();
                user.setUserID(rs.getString("requestingperson"));
                request.setAddedBy(user.getUserID());
                request.setRequestingUser(user);
                request.setRequestTitle(rs.getString("requesttitle"));
                request.setDescription(rs.getString("requests") == null ? ""
                        : rs.getString("requests"));
                String requestDate = rs.getString("requestdate") == null ? ""
                        : rs.getString("requestdate");
                if (requestDate.length() > 0) {
                    requestDate = requestDate.split(" ")[0];
                }
                request.setRequestDate(requestDate);
                request.setClient(rs.getString("clientname") == null ? "" : rs
                        .getString("clientname"));
                request.setProduct(rs.getString("productid"));
                request.setProject(rs.getString("projectid") == null ? "" : rs
                        .getString("projectid"));
                request.setProductName(rs.getString("productname"));
                request.setProjectName(rs.getString("projectname") == null ? ""
                        : rs.getString("projectname"));
                request.setStatusID(rs.getString("statusdesc"));
                request.setPriority(rs.getString("requestpriority") == null ? ""
                        : rs.getString("requestpriority"));
                request.setRequestType(rs.getString("requesttypeid"));
                request.setRequestTypeName(rs.getString("requesttypedesc"));
                /**
                 * set blank severity for the request type request
                 */
                if (!request.getRequestType().equals("1")) {
                    request.setSeverityID(rs.getString("severityid") == null ? ""
                            : rs.getString("severityid"));
                    request.setSeverityName(rs.getString("severitydesc") == null ? ""
                            : rs.getString("severitydesc"));
                } else {
                    request.setSeverityID("");
                    request.setSeverityName("");
                }

                request.setDocumentCount(rs.getInt("documentcount"));
                // request.setActionTaken(rs.getString("actiontaken"));
                request.setAssingedTo(rs.getString("assignedto"));
                user = this.getUserDetails(request.getAssingedTo());
                String targetDate = rs.getString("targetcompdate") == null ? ""
                        : rs.getString("targetcompdate");
                if (targetDate.length() > 0) {
                    targetDate = targetDate.split(" ")[0];
                }
                request.setTargetDate(targetDate);
                String reqCompCode = rs.getString("iscompleted") == null ? "n"
                        : rs.getString("iscompleted");
                request.setReqCompCode(reqCompCode);
                boolean isCompleted = reqCompCode.equalsIgnoreCase("y") ? true
                        : false;
                request.setCompleted(isCompleted);
                // request.setCompleted((rs.getString("iscompleted")==null?"N":rs.getString("iscompleted").charAt(0)).toString().equalsIgnoreCase("y")?true:false);
                boolean inWatch = (rs.getString("inwatch") == null || rs
                        .getString("inwatch").trim().length() < 1) ? false
                        : true;
                request.setInWatchList(inWatch);
                String hasFollowUps = rs.getString("hasfollowups") == null ? "N"
                        : rs.getString("hasfollowups");
                request.setHasFollowUps(hasFollowUps.equalsIgnoreCase("N") ? false
                        : true);
                boolean hasAttachments = rs.getString("docs") == null ? false
                        : (rs.getString("docs").equalsIgnoreCase("N") ? false
                        : true);
                request.setHasAttachment(hasAttachments);
                request.setPhaseDetected(rs.getString("phasedetecteddesc") == null ? ""
                        : rs.getString("phasedetecteddesc"));
                request.setPhaseInjected(rs.getString("phaseinjecteddesc") == null ? ""
                        : rs.getString("phaseinjecteddesc"));
                searchRequests.add(request);
            }
            rs = stmt.executeQuery(sql_countQuery);
            while (rs.next()) {
                maxRecordsFound = rs.getString("totalcount") == null ? 0
                        : Integer.parseInt(rs.getString("totalcount"));
            }
        } catch (Exception ex) {
            System.out
                    .println("Exception occured while getting request details:"
                            + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("number of requests retrieved:"
                + searchRequests.size());

        return searchRequests;
    }

    /**
     *
     * insertNewRequestTemplate QueryBean
     *
     * @return
     * @return boolean
     * @author:Ramesh Raj Baral
     * @since:Jun 9, 2010
     *
     */
    public boolean insertNewRequestTemplate(String[] paramArray) {
        // System.out.println("parameters sent:"+paramArray.length);
        boolean inserted = false;
        String templateID = paramArray[20];// templateid non zero for update
        // case
        String templateName = paramArray[19];
        String sourceID = paramArray[18];
        String dataProviderID = paramArray[17];
        String severity = paramArray[16];
        String reqSource = paramArray[15];
        String estimHours = paramArray[14];
        String phaseDet = paramArray[13];
        String phaseInject = paramArray[12];
        String assignTo = paramArray[11];
        String area = paramArray[10];
        String module = paramArray[9];
        String project = paramArray[8];
        String product = paramArray[7];
        String priority = paramArray[6];
        String targetDate = paramArray[5];
        String relVersion = paramArray[4];
        String reqTypeName = paramArray[3];
        String requestTypeID = paramArray[2];
        String requestingPerson = paramArray[1];
        String clientID = paramArray[0];
        String ackUsers = paramArray[21];
        String trustedUsers = paramArray[22];
        String trustedUserFilter = paramArray[23];
        String versionDet = "0";
        String targetVersion = paramArray[24];

        String sql_insertTemplate = "INSERT INTO OAM_RM_TEMPLATES(templatename,trusteduserfilter,requestsource,"
                + "client,product,project,requesttype,modules,area,assignedto,acknowledgeusers,"
                + "versiondetected,targetdate,priority,estimatedhours,targetedversion,"
                + "phaseinjected,phasedetected,severity,trustedusers) values("
                + SQLEncode(templateName)
                + ",'"
                + trustedUserFilter
                + "','"
                + sourceID
                + "',"
                + "'"
                + clientID
                + "','"
                + product
                + "','"
                + project
                + "','"
                + requestTypeID
                + "','"
                + module
                + "','"
                + area
                + "',"
                + "'"
                + assignTo
                + "','"
                + ackUsers
                + "','"
                + relVersion
                + "',to_date('"
                + targetDate
                + "','mm/dd/yy'),'"
                + priority
                + "',"
                + "'"
                + estimHours
                + "','"
                + targetVersion
                + "','"
                + phaseInject
                + "','"
                + phaseDet
                + "','"
                + severity
                + "','" + trustedUsers + "')";

        String sql_updateTemplate = "UPDATE OAM_RM_TEMPLATES SET templatename="
                + SQLEncode(templateName) + ",project='" + project
                + "',product='" + product + "',client='" + clientID
                + "',requesttype='" + requestTypeID + "',modules='" + module
                + "'" + ",area='" + area + "',assignedto='" + assignTo
                + "',priority='" + priority + "',estimatedhours='" + estimHours
                + "'," + "phaseinjected='" + phaseInject + "',phasedetected='"
                + phaseDet + "',severity='" + severity + "',requestsource='"
                + sourceID + "',trustedusers='" + trustedUsers
                + "',acknowledgeusers='" + ackUsers + "',versiondetected='"
                + relVersion + "',targetedversion='" + targetVersion
                + "',trusteduserfilter='" + trustedUserFilter
                + "',targetdate=to_date('" + targetDate
                + "','mm/dd/yy') where templateid='" + templateID + "'";

        try {
            this.connectDB();
            Statement statement = myConn.createStatement();
            if (templateID.equalsIgnoreCase("0")) {
                /**
                 * if still the user has sent duplicate name then donot insert
                 * it
                 */
                System.out
                        .println("templat insert query:" + sql_insertTemplate);
                String sql_searchTemplate = "SELECT *FROM OAM_RM_TEMPLATES WHERE TEMPLATENAME="
                        + SQLEncode(templateName) + "";
                ResultSet rs = statement.executeQuery(sql_searchTemplate);
                boolean duplicateFound = false;
                while (rs.next()) {
                    duplicateFound = true;
                }
                if (!duplicateFound) {
                    statement.executeQuery(sql_insertTemplate);
                    inserted = true;
                } else {
                    return false;
                }
            } else {
                System.out.println("template update query:"
                        + sql_updateTemplate);
                statement.executeQuery(sql_updateTemplate);
                inserted = true;
            }

        } catch (SQLException e) {
            System.out.println("exception while inserting/updating template:"
                    + e.getMessage());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            this.takeDown();
        }
        System.out.println("template inserted:" + inserted);
        return inserted;
    }

    /**
     *
     * getUserRequestDetails queryBeanPM Description: <li>returns the details of
     * the request whose id is provided</li>
     *
     * @param reqCode
     * @return
     * @return UserRequest
     * @author:Ramesh Raj Baral
     * @since:Jun 25, 2010
     *
     */
    public UserRequest getUserRequestDetails(String reqCode) {
        UserRequest request = new UserRequest();
        /**
         * handle the validity of this request code before executing the query
         */
        Pattern pat = Pattern.compile("[0-9]*");
        Matcher mat;
        /**
         * remove unnecessary characters if any present in the request token if
         * this token contains such invalid characters then discard the token
         * some invalid characters-&,",',or any such characters
         */
        /**
         * TODO check if the user has access to this project/product
         */
        mat = pat.matcher(reqCode);
        if (mat.matches()) {
            request.setValid(true);
        } else {
            request.setValid(false);
            System.out
                    .println("request code was invalid so returning blank userrequest******************");
            return request;
        }

        String sql = "SELECT watch.requestcode AS inwatch, " + "       req.*, "
                + "       clientname, " + "       productname, "
                + "       projectname, " + "       statusdesc, "
                + "       requestpriority, " + "       severitydesc, "
                + "       documentcount, " + "       usr.username, "
                + "       stat.statusdesc, " + "       req.requesttitle, "
                + "       cl.clientname, " + "       prod.productname, "
                + "       proj.projectname, " + "       sev.severitydesc, "
                + "       types.requesttypedesc, "
                + "       ack.userid        AS ackuser, " + "       usr.email "
                + "		FROM   oam_rm_requestmanager req "
                + "       inner join oam_rm_requeststatus stat "
                + "         ON stat.statusid = req.statusid "
                + "       inner join oam_rm_clients cl "
                + "         ON cl.clientid = req.clientid "
                + "       inner join oam_rm_products prod "
                + "         ON prod.productid = req.productid "
                + "       left join oam_rm_request_acknowledge ack "
                + "         ON ack.requestid = req.requestcode "
                + "       left join oam_rm_projects proj "
                + "         ON proj.projectid = req.projectid "
                + "       left join oam_rm_request_severity sev "
                + "         ON sev.severityid = req.severityid "
                + "       inner join oam_rm_request_types types "
                + "         ON req.requesttypeid = types.requesttypeid "
                + "       inner join usr_users usr "
                + "         ON usr.userid = req.requestingperson "
                + "       left join oam_rm_mywatchlist watch "
                + "         ON watch.requestcode = req.requestcode "
                + "		WHERE  req.requestcode = '" + reqCode + "' "
                + "        OR req.pksource = '" + reqCode + "' ";

        System.out.println("sql>>>>>" + sql);
        try {
            this.connectDB();
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            List ackUsersList = new ArrayList();
            int index = 0;
            while (rs.next()) {
                String ackUsers = rs.getString("ackuser") == null ? "" : rs
                        .getString("ackuser");
                if (ackUsers.length() > 0) {
                    User user = new User();
                    user.setUserID(ackUsers);
                    if (user.getUserID().trim().length() > 0) {
                        ackUsersList.add(user);
                    }
                }

                /**
                 * the info below are same in each row if there are multiple
                 * rows
                 */
                if (index == 0) {
                    request.setRequestCode(rs.getString("requestcode"));
                    request.setAcknowledgeUsers(ackUsersList);
                    User user = new User();
                    user.setUserID(rs.getString("requestingperson"));
                    user.setUserName(rs.getString("username"));
                    user.setUserEmail(rs.getString("email"));
                    request.setAddedBy(user.getUserID());
                    request.setRequestingUser(user);
                    request.setRequestTitle(rs.getString("requesttitle"));
                    request.setDescription(rs.getString("requests") == null ? ""
                            : rs.getString("requests"));
                    String requestDate = rs.getString("requestdate") == null ? ""
                            : rs.getString("requestdate");
                    if (requestDate.length() > 0) {
                        requestDate = requestDate.split(" ")[0];
                    }
                    request.setRequestDate(requestDate);
                    request.setClientName(rs.getString("clientname"));
                    request.setClient(rs.getString("clientid"));
                    request.setProduct(rs.getString("productid"));
                    request.setProject(rs.getString("projectid"));
                    request.setProductName(rs.getString("productname"));
                    request.setProjectName(rs.getString("projectname"));
                    request.setStatusID(rs.getString("statusdesc"));
                    request.setRequestSource(rs.getString("sourceid"));
                    request.setPriority(rs.getString("requestpriority") == null ? ""
                            : rs.getString("requestpriority"));
                    request.setSeverityID(rs.getString("severityid"));
                    request.setSeverityName(rs.getString("severitydesc") == null ? ""
                            : rs.getString("severitydesc"));
                    request.setDocumentCount(rs.getInt("documentcount"));
                    request.setActionTaken(rs.getString("actiontaken"));
                    request.setAssingedTo(rs.getString("assignedto"));
                    request.setRequestType(rs.getString("requesttypeid"));
                    request.setRequestTypeName(rs.getString("requesttypedesc"));
                    request.setDataProvider(rs.getString("dataproviderid"));
                    request.setArea(rs.getString("productarea"));
                    request.setDataProvider(rs.getString("dataproviderid"));
                    request.setVersionDetected(rs.getString("detectedversion"));
                    request.setPhaseDetected(rs.getString("phasedetecteddesc") == null ? ""
                            : rs.getString("phasedetecteddesc"));
                    request.setPhaseInjected(rs.getString("phaseinjecteddesc") == null ? ""
                            : rs.getString("phaseinjecteddesc"));
                    request.setModule(rs.getString("moduleid") == null ? ""
                            : rs.getString("moduleid"));
                    user = this.getUserDetails(request.getAssingedTo());
                    request.setAssignedToUser(user);
                    String targetDate = rs.getString("targetcompdate") == null ? ""
                            : rs.getString("targetcompdate");
                    if (targetDate.length() > 0) {
                        targetDate = targetDate.split(" ")[0];
                    }
                    request.setTargetDate(targetDate);
                    String reqCompCode = rs.getString("iscompleted") == null ? "n"
                            : rs.getString("iscompleted");
                    request.setReqCompCode(reqCompCode);
                    boolean isCompleted = reqCompCode.equalsIgnoreCase("y") ? true
                            : false;
                    request.setCompleted(isCompleted);
                    // request.setCompleted((rs.getString("iscompleted")==null?"N":rs.getString("iscompleted").charAt(0)).toString().equalsIgnoreCase("y")?true:false);
                    boolean inWatch = (rs.getString("inwatch") == null || rs
                            .getString("inwatch").trim().length() < 1) ? false
                            : true;
                    request.setInWatchList(inWatch);
                    String hasFollowUps = rs.getString("hasfollowups") == null ? "N"
                            : rs.getString("hasfollowups");
                    request.setHasFollowUps(hasFollowUps.equalsIgnoreCase("N") ? false
                            : true);
                }
                index++;
                /**
                 * TODO we can have some mechanism for the document to show as
                 * the link
                 */

            }
            request.setAcknowledgeUsers(ackUsersList);
        } catch (Exception ex) {
            System.out
                    .println("Exception occured while getting single request detail:"
                            + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out
                .println("the request being returned is valid***************:"
                        + request.isValid() + "ackuserslist:"
                        + request.getAcknowledgeUsers().size());
        return request;

    }

    /**
     *
     * getAllUsersMap queryBeanPM Description:get all the user's details
     *
     * @return
     * @return HashMap
     * @author:Ramesh Raj Baral
     * @since:Jun 30, 2010
     *
     */
    public HashMap getAllUsersMap() {
        HashMap usersMap = new HashMap();
        String sql = "SELECT * " + " FROM   (SELECT userid, "
                + "               loginname, " + "               username, "
                + "               email, " + "               oamstatus, "
                + "               oamusertypecode "
                + "        FROM   usr_users usr " + "        UNION "
                + "        SELECT userid, " + "               loginname, "
                + "               username, " + "               email, "
                + "               oamstatus, "
                + "               oamusertypecode "
                + "        FROM   usr_deletedusers dusr)a "
                + " WHERE  a.oamusertypecode IS NOT NULL ";
        try {
            if (myConn == null) {
                this.connectDB();
            }
            stmt = myConn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                User user = new User();
                user.setUserID(rs.getString("userid"));
                user.setLoginName(rs.getString("loginname"));
                user.setUserEmail(rs.getString("email"));
                user.setUserName(rs.getString("username"));
                usersMap.put(user.getUserID(), user);
            }
        } catch (Exception ex) {
            System.out.println("exception getting details of allusers:"
                    + ex.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("all users map has size of:" + usersMap.size());
        return usersMap;

    }

    /**
     *
     * getNonAccessibleRequestsList queryBeanPM Description: <li>given the user
     * sent valid requests tokens and the existing requests in OAM-RM from them,
     * </li> <li>this method returns the one which do not exist in OAM-RM</li>
     *
     * @param requestTokens
     * @param validRequestsList
     * @return
     * @return List
     * @author:Ramesh Raj Baral
     * @since:Jul 8, 2010
     *
     */
    public List getNotExistingRequests(String[] requestTokens,
            List validRequestsList) {
        List notExistingRequetsList = new ArrayList();
        boolean isExisting = false;
        for (int i = 0; i < requestTokens.length; i++) {
            String requestCode = requestTokens[i];
            for (int j = 0; j < validRequestsList.size(); j++) {
                UserRequest request = (UserRequest) validRequestsList.get(j);
                if (request.getRequestCode().equals(requestCode)) {
                    isExisting = true;
                    break;
                }
            }
            if (!isExisting) {
                UserRequest notExistingRequest = new UserRequest();
                notExistingRequest.setRequestCode(requestCode);
                notExistingRequest.setExists(false);
                notExistingRequetsList.add(notExistingRequest);
                // System.out.println("adding:"+requestCode+"..to non accessible list");
            }
        }
        return notExistingRequetsList;
    }

    public int getMaxRecordsFound() {
        return maxRecordsFound;
    }

    public void setMaxRecordsFound(int maxRecordsFound) {
        this.maxRecordsFound = maxRecordsFound;
    }

    public String getRequest_tablename() {
        return request_tablename;
    }

    public void setRequest_tablename(String request_tablename) {
        this.request_tablename = request_tablename;
    }

    /**
     * This method returns file size in bytes
     *
     * @param absoluteFilepath
     * @return
     */
    public String getFileLength(String absoluteFilepath) {
        File ff = new File(absoluteFilepath);
        String filesize = "";
        if (ff.exists() && ff.canRead()) {
            filesize = ff.length() + "";
        }
        return filesize;

    }

    public String checkEmptyAndNull(String input) {
        if (input == null || input.isEmpty() || input.equalsIgnoreCase("-1")) {
            return "N/A";
        } else {
            return input;
        }
    }

    public String getMonth(String input) {
        if (input == null || input.isEmpty() || input.equalsIgnoreCase("-1")) {
            return "N/A";
        } else if (input.equalsIgnoreCase("1")) {
            return "January";
        } else if (input.equalsIgnoreCase("2")) {
            return "February";
        } else if (input.equalsIgnoreCase("3")) {
            return "March";
        } else if (input.equalsIgnoreCase("4")) {
            return "April";
        } else if (input.equalsIgnoreCase("5")) {
            return "May";
        } else if (input.equalsIgnoreCase("6")) {
            return "June";
        } else if (input.equalsIgnoreCase("7")) {
            return "July";
        } else if (input.equalsIgnoreCase("8")) {
            return "August";
        } else if (input.equalsIgnoreCase("9")) {
            return "September";
        } else if (input.equalsIgnoreCase("10")) {
            return "October";
        } else if (input.equalsIgnoreCase("11")) {
            return "November";
        } else if (input.equalsIgnoreCase("12")) {
            return "December";
        } else if (input.equalsIgnoreCase("13")) {
            return "1Q";
        } else if (input.equalsIgnoreCase("14")) {
            return "2Q";
        } else if (input.equalsIgnoreCase("15")) {
            return "3Q";
        } else if (input.equalsIgnoreCase("16")) {
            return "4Q";
        } else {
            return "N/A";
        }
    }

    public String extractRequestPriorityDescForEmail(String requestPriority) {
        if (requestPriority != null && requestPriority.matches("[3-5]")) {
            return "P";
        }
        return "N/A";
    }

    public String getDecorateICEURL(String url) {
        java.util.Calendar calendar = Calendar.getInstance();
        return "<a href=" + url + "/index.jsp style='text-decoration: none; color: #3498db;'><strong>Verscend ICE</strong></a><br> Copyright &copy " + calendar.get(Calendar.YEAR) + " Verscend";
    }

    /*
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get request detail for mail message
     */
    public String getFormattedRequestMessageForNew(String ProjID, String domainName, MailMessagePOJO oldMessagePOJO, String userId)
            throws Exception {
        RequestMailMessage mailMessage = new RequestMailMessage();
        MailMessageGenerator generator = new MailMessageGenerator();
        String OAMURL = getFixedParameter("ICE URL");
        String documentCount = "";
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestCodee = checkEmptyAndNull(getData("RequestCode"));
                String requestDate = checkEmptyAndNull(getOnlyDate(
                        getData("RequestDate"), true));
                reqPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                reqPersonEmail = checkEmptyAndNull(getData("ReqPersonEmail"));
                String requestPriority = checkEmptyAndNull(getData("RequestPriority"));
                String clientName = checkEmptyAndNull(getData("ClientName"));
                mainEnggName = checkEmptyAndNull(getData("User_Name"));
                mainEnggEmail = checkEmptyAndNull(getData("enggEmail"));
                String issueType = checkEmptyAndNull(getData("issuetypename"));
                String secondaryType = checkEmptyAndNull(getData("secondaryType"));
                String issueTypeCode = checkEmptyAndNull(getData("crcode"));
                String employerGroup = checkEmptyAndNull(getData("employerGroup"));
                String AppID = checkEmptyAndNull(getData("AppID"));
                String externalid = getData("externalid");
                String projectName = checkEmptyAndNull(getCRProjectName(getData("projectid")));
                String phase = checkEmptyAndNull(getData("phasename"));
                String dataSource = checkEmptyAndNull(getData("datasource"));
                String dataType = checkEmptyAndNull(getData("datatype"));
                documentCount = getData("documentCount");
                String EstimatedHours = getData("EstimatedHours");
                String payer = checkEmptyAndNull(getData("payorname"));
                String remarks = checkEmptyAndNull(getData("remarks"));
                String targetCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate"), true));
                String targetCompDate2 = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate2"), true));
                String actualCompDate2 = checkEmptyAndNull(getOnlyDate(
                        getData("actualcompdate2"), true));
                String appReleasesToClientDate = checkEmptyAndNull(getOnlyDate(
                        getData("appreleasedate"), true));
                String requestTitle = checkEmptyAndNull(getData("REQUESTTITLE"));
                String convertedRequestTypeId = getData("CONVREQUESTTYPEID");
                String applicationTypeid = checkEmptyAndNull(getData("applicationtype"));
//                String prioritizeddate = checkEmptyAndNull(getOnlyDate(
//                        getData("prioritizeddate"), true));
                //String prioritizedby = checkEmptyAndNull(getData("prioritizedby"));
                String processmonth = checkEmptyAndNull(getMonth(getData("processmonth")));
                String team = checkEmptyAndNull(getData("team"));

                String releaseTag = checkEmptyAndNull(getData("releasetag"));
                String dateOfCleanAndCompleteDataReceipt = checkEmptyAndNull(getOnlyDate(
                        getData("cleancompletedatareciptdate"), true));
                String dateOfLegalsCompleted = checkEmptyAndNull(getOnlyDate(
                        getData("legalcompletedate"), true));

                oldMessagePOJO.getNewRequestParamDTO().setParenticeid(getData("Parenticeid"));
                oldMessagePOJO.getNewRequestParamDTO().setParentrequesttype(getData("Parentrequesttype"));
                oldMessagePOJO.getNewRequestParamDTO().setIntegrationtype(getData("Integrationtype"));
                oldMessagePOJO.getNewRequestParamDTO().setApplicationkickoffdate(getOnlyDate(getData("Applicationkickoffdate"), true));
                oldMessagePOJO.getNewRequestParamDTO().setLinkIceId(getData("link_ice_id"));
                oldMessagePOJO.getNewRequestParamDTO().setLinkType(getData("link_type"));
//                System.out.println("NEW Line Type:>>>>" + oldMessagePOJO.getNewRequestParamDTO().getLinkType());
//                System.out.println("NEW Line Ice Id:>>>>" + oldMessagePOJO.getNewRequestParamDTO().getLinkIceId());

//                if (!prioritizedby.equalsIgnoreCase("N/A")) {
//                    prioritizedby = this.getEngineerName(prioritizedby);
//                }
                Base64Encoder encoder = new Base64Encoder();
                String requestUrl = "";
                /*
                 * String requestUrl = OAMURL +
                 * "/RE/ListProjectRequest_Lighter.jsp?userView=" +
                 * encoder.encode(requestCode);
                 */
                java.util.Calendar calendar = Calendar.getInstance();

                requestUrl = getDecorateICEURL(OAMURL);
//                System.out.println("request url is:" + requestUrl + " app release date : " + appReleasesToClientDate);
                String attch = "N/A";
                if (!(documentCount.equals("0") || documentCount.trim().equals(
                        ""))) {
                    attch = "<a href='" + OAMURL
                            + "/RE/downloadAllFiles.jsp?pid=" + ProjID
                            + "&domain=" + domainName
                            + "' style='text-decoration: none; color: #3498db;'>Click here to download attachments</a>";
                }

                //String requestPriorityDesc = extractRequestPriorityDescForEmail(requestPriority);

                /*   String ba = "";
                String wpm = "";
                String npm = "";
                String cl = "";
                 */
 /*  if (getUsernameForBA_WPM_NPM_CL(AppID)) {
                    if (moveNext()) {
                        ba = checkEmptyAndNull(getData("ba"));
                        wpm = checkEmptyAndNull(getData("wpm"));
                        npm = checkEmptyAndNull(getData("npm"));
                        cl = checkEmptyAndNull(getData("cl"));
                    }
                }*/
                mailMessage.setDearPerson(mainEnggName);
                mailMessage.setDocumentDownloadLink(attch);
                mailMessage.setRequestCode(requestCodee);
                ArrayList<MailMessageModel> messageModels = new ArrayList<MailMessageModel>();
                ArrayList<MailMessageModel> convertedMessageModels = new ArrayList<MailMessageModel>();

                if (oldMessagePOJO.getOperationType() == 1) {
                    generator.getLogBuilder().append(" created ");
                    generator.setIsSkipLog(true);
                }
                if (!generator.isIsSkipLog()) {
                    boolean isChangePhase = oldMessagePOJO.getPhase() != null && !phase.equalsIgnoreCase(oldMessagePOJO.getPhase());
                    boolean isChangeAssignee = oldMessagePOJO.getMainEnggName() != null && !mainEnggName.equalsIgnoreCase(oldMessagePOJO.getMainEnggName());
                    if (isChangePhase) {
//                        generator.setIsSkipLog(true);
                        generator.getLogBuilder().append(" changed the phase from ").append(oldMessagePOJO.getPhase())
                                .append(" to ").append(phase).append(AppConstants.INSTANCE.ACTIVITY_UPDATE_PRIMARY_SECONDARY_MESSAGE_SPLITTER).append(" updated fields ");
                    } else if (isChangeAssignee) {
//                        generator.setIsSkipLog(true);
                        generator.getLogBuilder().append(" changed the assignee from ").append(oldMessagePOJO.getMainEnggName())
                                .append(" to ").append(mainEnggName).append(AppConstants.INSTANCE.ACTIVITY_UPDATE_PRIMARY_SECONDARY_MESSAGE_SPLITTER).append(" updated fields ");
                    } else {
                        generator.getLogBuilder().append(" updated fields ");
                    }
                }

                messageModels.add(generator.mailMessageGenerator("Request Date", requestDate, oldMessagePOJO.getRequestDate()));
                messageModels.add(generator.mailMessageGenerator("Requesting Person", reqPersonName, oldMessagePOJO.getReqPersonName()));
                boolean isDefect = issueTypeCode.equalsIgnoreCase(RequestCode.DEFECT.getRequestCode());
                boolean isReprocessing = issueTypeCode.equalsIgnoreCase(RequestCode.REPROCESSING.getRequestCode());
                boolean isVenderMgmt = issueTypeCode.equalsIgnoreCase(RequestCode.VENDOR_MANAGEMENT.getRequestCode());
                boolean isExtract = issueTypeCode.equalsIgnoreCase(RequestCode.EXTRACT_REQUEST.getRequestCode());
                boolean isDataAnalysisReq = issueTypeCode.equalsIgnoreCase(RequestCode.DATA_ANALYSIS_REQUEST.getRequestCode());
                boolean isLayoutAnalysis = issueTypeCode.equalsIgnoreCase(RequestCode.LAYOUT_ANALYSIS.getRequestCode());
                boolean isEstimate = issueTypeCode.equalsIgnoreCase(RequestCode.ESTIMATE.getRequestCode());
                // if (!isDefect) {
                messageModels.add(generator.mailMessageGenerator("Client", clientName, oldMessagePOJO.getClientName()));
                // messageModels.add(generator.mailMessageGenerator("App ID", AppID, oldMessagePOJO.getAppID()));
                if (issueTypeCode.equalsIgnoreCase("PMG") || issueTypeCode.equalsIgnoreCase("CHR") || issueTypeCode.equalsIgnoreCase("COR") || issueTypeCode.equalsIgnoreCase("EXR") || issueTypeCode.equalsIgnoreCase("CAW") || issueTypeCode.equalsIgnoreCase("PIT")) {
                    messageModels.add(generator.mailMessageGenerator("Employer Group", employerGroup, oldMessagePOJO.getEmployerGroup()));
                }
                if (!isDefect) {
                    messageModels.add(generator.mailMessageGenerator("Project Name", projectName, oldMessagePOJO.getProjectName()));
                }

                // }

                /*if (isReleaseTagShow(issueTypeCode)) {
                    messageModels.add(generator.mailMessageGenerator("Release Tag", releaseTag, oldMessagePOJO.getReleaseTag()));
                }*/
                messageModels.add(generator.mailMessageGenerator("Request Title", requestTitle, oldMessagePOJO.getRequestTitle()));
                /* if (!isDefect) {
                    if (!(RequestCode.DATA_ANALYSIS_REQUEST.getRequestCode().equalsIgnoreCase(issueTypeCode)
                            || RequestCode.REPROCESSING.getRequestCode().equalsIgnoreCase(issueTypeCode)
                            || RequestCode.EXTRACT_REQUEST.getRequestCode().equalsIgnoreCase(issueTypeCode))) {
                 */ payer = RequestCode.PRODUCTION_INTEGRATION.getRequestCode().equalsIgnoreCase(issueTypeCode) ? checkEmptyAndNull(getAggregatePayorNameForRequestCode(requestCodee)) : payer;
                if (!isReprocessing && !isExtract && !isDataAnalysisReq && !isDefect) {
                    messageModels.add(generator.mailMessageGenerator("Payer", payer, oldMessagePOJO.getPayer()));
                    messageModels.add(generator.mailMessageGenerator("Data Type", dataType, oldMessagePOJO.getDataType()));
                }
                /*    }
                }
                 */ messageModels.add(generator.mailMessageGenerator("Request Type", issueType, oldMessagePOJO.getIssueType()));
                if (!secondaryType.equalsIgnoreCase("N/A")) {
                    messageModels.add(generator.mailMessageGenerator("Secondary Request Type", secondaryType, secondaryType));
                }
                messageModels.add(generator.mailMessageGenerator("Current Phase", phase, oldMessagePOJO.getPhase()));
                if (oldMessagePOJO.getPhase() != null && !phase.equalsIgnoreCase(oldMessagePOJO.getPhase())) {
                    messageModels.add(new MailMessageModel("Previous Phase", oldMessagePOJO.getPhase(), "currentEdit", null));
                    Map<String, String> phaseChangeTrackDetail = getPhaseChangeTrackDetail(requestCodee);
                    if (phaseChangeTrackDetail != null) {
                        messageModels.add(generator.mailMessageGenerator("Last Phase Changed On", phaseChangeTrackDetail.get("logged"), null));
                        messageModels.add(generator.mailMessageGenerator("Last Phase Changed By", phaseChangeTrackDetail.get("username"), null));
                    }
                }
                messageModels.add(generator.mailMessageGenerator("Assigned to", mainEnggName, oldMessagePOJO.getMainEnggName()));
//                messageModels.add(generator.mailMessageGenerator("Priority", requestPriorityDesc, oldMessagePOJO.getRequestPriorityDesc()));
//                messageModels.add(generator.mailMessageGenerator("Prioritized Date", prioritizeddate, oldMessagePOJO.getPrioritizeddate()));
//                messageModels.add(generator.mailMessageGenerator("Prioritized By", prioritizedby, oldMessagePOJO.getPrioritizedby()));
                //messageModels.add(generator.mailMessageGenerator("Estimated Hours", EstimatedHours, oldMessagePOJO.getEstimatedHours()));
                messageModels.add(generator.mailMessageGenerator("Target Date", targetCompDate2 == null || "N/A".equalsIgnoreCase(targetCompDate2) ? targetCompDate : targetCompDate2, oldMessagePOJO.getTargetDate()));

                if (isDateofCleanAndDateOfLegalsShow(issueTypeCode)) {
                    messageModels.add(generator.mailMessageGenerator("Date of Clean and Complete Data Receipt", dateOfCleanAndCompleteDataReceipt, oldMessagePOJO.getDateOfCleanAndCompleteDataReceipt()));
                    messageModels.add(generator.mailMessageGenerator("Date of Legals Completed", dateOfLegalsCompleted, oldMessagePOJO.getDateOfLegalsCompleted()));
                }

                /* if (!isDefect) {
                    messageModels.add(generator.mailMessageGenerator("Business Analyst", ba, null));
                    messageModels.add(generator.mailMessageGenerator("Waltham PM", wpm, null));
                    messageModels.add(generator.mailMessageGenerator("Nepal PM", npm, null));
                    messageModels.add(generator.mailMessageGenerator("Cluster Lead", cl, null));
                    String applicationType = checkEmptyAndNull(getApplicationTypeNameInGroupByIdGroupByColon(applicationTypeid));
                    messageModels.add(generator.mailMessageGenerator("Application Type", applicationType, oldMessagePOJO.getApplicationType()));
                    if (applicationType.equals(oldMessagePOJO.getApplicationType())) {
                        System.out.println("same:" + applicationType + "::" + oldMessagePOJO.getApplicationType());
                    } else {
                        System.out.println("differ:" + applicationType + "::" + oldMessagePOJO.getApplicationType());
                    }
                }*/
                if (!isDefect) {
                    String applicationType = checkEmptyAndNull(getApplicationTypeNameInGroupByIdGroupByColon(applicationTypeid));
                    messageModels.add(generator.mailMessageGenerator("Application Type", applicationType, oldMessagePOJO.getApplicationType()));
                    if (applicationType.equals(oldMessagePOJO.getApplicationType())) {
                        System.out.println("same:" + applicationType + "::" + oldMessagePOJO.getApplicationType());
                    } else {
                        System.out.println("differ:" + applicationType + "::" + oldMessagePOJO.getApplicationType());
                    }
                }

                messageModels.add(generator.mailMessageGenerator("External Ticket ID", externalid, oldMessagePOJO.getExternalid()));
                if (!isReprocessing && !isVenderMgmt && !isLayoutAnalysis && !isEstimate && !isDefect) {
                    messageModels.add(generator.mailMessageGenerator("Application Kickoff Date", oldMessagePOJO.getNewRequestParamDTO().getApplicationkickoffdate(), oldMessagePOJO.getOldRequestParamDTO().getApplicationkickoffdate()));
                }
                System.out.println("Converted Request Type ID=" + convertedRequestTypeId);
                if (issueTypeCode.equalsIgnoreCase("CHR"))// For Change Request
                {
                    //messageModels.add(genenrator.mailMessageGenerator("Estimated Application Delivery Date", appReleasesToClientDate, oldMessagePOJO.getAppReleasesToClientDate()));
                    addChangeRequestContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO, false, targetCompDate2);
                } else if (issueTypeCode.equalsIgnoreCase("PMG")) { // For Payor Management
                    messageModels.add(generator.mailMessageGenerator("Estimated Application Delivery Date", appReleasesToClientDate, oldMessagePOJO.getAppReleasesToClientDate()));
                    addPayorMgmtContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO, convertedMessageModels, targetCompDate2, false);
                    //if is converted true then add CR mail message
                    if (isConvertedRequest(ProjID) && CommonUtils.RequestCode.PRODUCTION_INTEGRATION.getRequestTypeId().equals(convertedRequestTypeId)) {
                        addProductionIntegrationContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, true, targetCompDate2);
                        convertedMessageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, getMonth((oldMessagePOJO.getProcessmonth()))));
                        mailMessage.setIsConverted(true);
                    } else {
                        messageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, getMonth((oldMessagePOJO.getProcessmonth()))));
                    }

                } else if (issueTypeCode.equalsIgnoreCase("REP"))// For  Reprocessing
                {
                    addReprocessingContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO);
                } else if (issueTypeCode.equalsIgnoreCase("COR"))// For Carrier Out Reach //Vendor Management
                {
                    addCORContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO);
                    if (isConvertedRequest(ProjID)) {
                        if (CommonUtils.RequestCode.CHANGE_REQUEST.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addChangeRequestContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, false, targetCompDate2);
                        } else if (CommonUtils.RequestCode.IMPLEMENTATION_SERVICES.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addPayorMgmtContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, convertedMessageModels, targetCompDate2, true);
                            convertedMessageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, this.getMonth(oldMessagePOJO.getProcessmonth())));
                        } else if (CommonUtils.RequestCode.PRODUCTION_INTEGRATION.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addProductionIntegrationContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, true, targetCompDate2);
                            convertedMessageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, getMonth((oldMessagePOJO.getProcessmonth()))));
                        }
                        mailMessage.setIsConverted(true);
                    }
                } else if (issueTypeCode.equalsIgnoreCase("EXR") || issueTypeCode.equalsIgnoreCase("CAW")) { // For Carrier  Out Reach and Extract Request
                    addEXRCAWContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO, issueTypeCode, convertedMessageModels, targetCompDate2, actualCompDate2, false);
                    if ("CAW".equalsIgnoreCase(issueTypeCode)) {
                        if (isConvertedRequest(ProjID) && CommonUtils.RequestCode.CHANGE_REQUEST.getRequestTypeId().equals(convertedRequestTypeId)) {
                            convertedMessageModels.add(generator.mailMessageGenerator("Payer", payer, oldMessagePOJO.getPayer()));
                            convertedMessageModels.add(generator.mailMessageGenerator("Data Type", dataType, oldMessagePOJO.getDataType()));
                            addChangeRequestContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, true, targetCompDate2);
                            mailMessage.setIsConverted(true);
                        }
                    }
                } else if (issueTypeCode.equalsIgnoreCase("PIT")) { //Production Integration
                    //messageModels.add(genenrator.mailMessageGenerator("Estimated Application Delivery Date", appReleasesToClientDate, oldMessagePOJO.getAppReleasesToClientDate()));
                    addProductionIntegrationContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO);
                } else if (issueTypeCode.equalsIgnoreCase(RequestCode.LAYOUT_ANALYSIS.getRequestCode())) { //Layout Analysis
                    addLayoutAnalysisContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO, issueTypeCode, convertedMessageModels, targetCompDate2);
                    if (isConvertedRequest(ProjID)) {
                        if (CommonUtils.RequestCode.IMPLEMENTATION_SERVICES.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addPayorMgmtContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, convertedMessageModels, targetCompDate2, true);
                            convertedMessageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, this.getMonth(oldMessagePOJO.getProcessmonth())));

                        }
                        mailMessage.setIsConverted(true);
                    }
                } else if (issueTypeCode.equalsIgnoreCase(RequestCode.ESTIMATE.getRequestCode())) {
                    addEstimateContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO, issueTypeCode, convertedMessageModels, targetCompDate2);
                    mailMessage.setIsConverted(isConvertedRequest(ProjID));
                    if (isConvertedRequest(ProjID)) {
                        if (CommonUtils.RequestCode.CHANGE_REQUEST.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addChangeRequestContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, false, targetCompDate2);
                        } else if (CommonUtils.RequestCode.IMPLEMENTATION_SERVICES.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addPayorMgmtContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, convertedMessageModels, targetCompDate2, true);
                            convertedMessageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, this.getMonth(oldMessagePOJO.getProcessmonth())));
                        } else if (CommonUtils.RequestCode.DATA_ANALYSIS_REQUEST.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addEXRCAWContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, issueTypeCode, convertedMessageModels, targetCompDate2, actualCompDate2, true);
                        } else if (CommonUtils.RequestCode.EXTRACT_REQUEST.getRequestTypeId().equals(convertedRequestTypeId)) {
                            addEXRCAWContentForMailNew(ProjID, convertedMessageModels, generator, oldMessagePOJO, issueTypeCode, convertedMessageModels, targetCompDate2, actualCompDate2, true);
                        }
                        mailMessage.setIsConverted(true);
                    }
                } else if (issueTypeCode.equalsIgnoreCase(RequestCode.DEFECT.getRequestCode())) {
                    boolean isProduction = false;

                    /*    if (isProductionApplication(ProjID)) {
                        isProduction = true;
                        messageModels.add(generator.mailMessageGenerator("Client", clientName, oldMessagePOJO.getClientName()));
                        messageModels.add(generator.mailMessageGenerator("App ID", AppID, oldMessagePOJO.getAppID()));
                        messageModels.add(generator.mailMessageGenerator("Release Tag", releaseTag, oldMessagePOJO.getReleaseTag()));

                    }*/
                    addDefectContentForMailNew(ProjID, messageModels, generator, oldMessagePOJO, issueTypeCode, convertedMessageModels, targetCompDate2);
                    // if (isProduction) {
                    messageModels.add(generator.mailMessageGenerator("Team", team, oldMessagePOJO.getTeam()));
                    messageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, oldMessagePOJO.getProcessmonth()));
                    // }

                    mailMessage.setIsConverted(false);
                }

                /*   if (!isReleaseTagShow(issueTypeCode) && isReleaseTagShow(CommonUtils.getRequestTypeCodeById(convertedRequestTypeId))) {
                    convertedMessageModels.add(generator.mailMessageGenerator("Release Tag", releaseTag, oldMessagePOJO.getReleaseTag()));
                }*/
                if (!isDateofCleanAndDateOfLegalsShow(issueTypeCode) && isDateofCleanAndDateOfLegalsShow(CommonUtils.getRequestTypeCodeById(convertedRequestTypeId))) {
                    convertedMessageModels.add(generator.mailMessageGenerator("Date of Clean and Complete Data Receipt", dateOfCleanAndCompleteDataReceipt, oldMessagePOJO.getDateOfCleanAndCompleteDataReceipt()));
                    convertedMessageModels.add(generator.mailMessageGenerator("Date of Legals Completed", dateOfLegalsCompleted, oldMessagePOJO.getDateOfLegalsCompleted()));
                }

                messageModels.add(generator.mailMessageGenerator("Remarks", remarks, oldMessagePOJO.getRemarks()));

//                if (oldMessagePOJO.getOperationType() != 1) {
//                    if (this.getSelectedProjectRequest(ProjID, userId)) {
//                        if (this.moveNext()) {
//                            List<MailMessageModel> timeLogs = new ArrayList<MailMessageModel>();
//                            //work log
//                            String totalDevHours = this.getData("TOTALDEV");
//                            String totalQCHours = this.getData("TOTALQC");
//                            String totalWPMHours = this.getData("totalwpm");
//                            timeLogs.add(new MailMessageModel("Developer", totalDevHours, null, null));
//                            timeLogs.add(new MailMessageModel("QC", totalQCHours, null, null));
//                            timeLogs.add(new MailMessageModel("WPM", totalWPMHours, null, null));
//                            mailMessage.setTimeLogs(timeLogs);
//                        }
//                    }
//                }
                if (RequestCode.CHANGE_REQUEST.getRequestCode().equalsIgnoreCase(issueTypeCode)
                        || RequestCode.PRODUCTION_INTEGRATION.getRequestCode().equalsIgnoreCase(issueTypeCode)) {
                    if (this.getTestCases(ProjID)) {
                        List<TestCase> testCases = new ArrayList<TestCase>();
                        int row = 0;
                        while (this.moveNext()) {
                            String testCaseDesc = this.getData("TESTDESCRIPTION");
                            String expResult = this.getData("EXPECTEDRESULT");
                            String actResult = this.getData("ACTUALRESULT");
                            String passFail = this.getData("PASSFAIL");
                            if (passFail.equals("1")) {
                                passFail = "Pass";
                            } else {
                                passFail = "Pending Verification";
                            }
                            testCases.add(new TestCase(++row, testCaseDesc, expResult, actResult, passFail, null));
                        }
                        mailMessage.setTestCases(testCases);
                    }
                }
                mailMessage.setIceURL(requestUrl);
                mailMessage.setMailMessageModels(messageModels);
                mailMessage.setConvertedMessageModels(convertedMessageModels);
                // only for edit
                if (oldMessagePOJO.getOperationType() != 1) {
                    messageModels.add(generator.mailMessageGeneratorForTwoValues("Ice Link", oldMessagePOJO.getNewRequestParamDTO().getLinkType(),
                            oldMessagePOJO.getNewRequestParamDTO().getLinkIceId(), oldMessagePOJO.getOldRequestParamDTO().getLinkType(), oldMessagePOJO.getOldRequestParamDTO().getLinkIceId()));
                }
            }
        }

        VelocityContext velocityContext = new VelocityContext();
        velocityContext.put("req", mailMessage);
        if (oldMessagePOJO.getOperationType() != 1) {
            if (!documentCount.equalsIgnoreCase(oldMessagePOJO.getDocumentCount()) && oldMessagePOJO.getDocumentCount() != null) {
                velocityContext.put("documentCountChange", "currentEdit");
            }
        }

        VelocityUtils velocityUtils = new VelocityUtils();
        velocityUtils.initVelocityConfiguration();
        String message = velocityUtils.prepareMessage("requestMailMessageTemplate.vsl", velocityContext);
        if (DAOFactory.INSTANCE.getIsActivityUpdateEnable()) {
            /*INSERT ACTIVITY LOG BEFORE SEND MAIL*/
            ActivityUpdateDTO activityUpdateDTO = new ActivityUpdateDTO();
            activityUpdateDTO.setPksource(String.valueOf(Integer.valueOf(ProjID)));
            activityUpdateDTO.setUsername(getEngineerName(userId));
            activityUpdateDTO.setDetail(generator.getLogBuilder().toString());
            System.out.println("Inserting Log=>" + activityUpdateDTO.getDetail());
            ActivityUpdateDAO activityUpdateDAO = new ActivityUpdateDAO();
            activityUpdateDAO.insert(activityUpdateDTO);
            activityUpdateDAO.takeDown();
            /*FINISHED ACTIVITY LOG SAVED*/
        }

        return message != null ? message : "";
    }

    private boolean isDateofCleanAndDateOfLegalsShow(String issueTypeCode) {
        return RequestCode.IMPLEMENTATION_SERVICES.getRequestCode().equalsIgnoreCase(issueTypeCode)
                || RequestCode.PRODUCTION_INTEGRATION.getRequestCode().equalsIgnoreCase(issueTypeCode);
    }

    private boolean isReleaseTagShow(String issueTypeCode) {
        return !RequestCode.DEFECT.getRequestCode().equalsIgnoreCase(issueTypeCode);
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get changes request detail for mail message
     */
    public void addChangeRequestContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, boolean isCARConverted, String targetCompDate2)
            throws Exception {
        String datalayout = "";
        String amname = "";
        String reason = "";
        String billclient = "";
        String jiraid = "";
        String problemdef = "";
        String changespecify = "";
        String clientpaid = "";
        String clientrequestdate = "";
        String clienttargetdate = "";
        String actualtargetdate = "";
        String Impact = "";
        String processmonth = "";
        String implementedbyimplservices = "";
        String implementationiceid = "";
        if (getChangeRequest(projectId)) {
            if (moveNext()) {
                processmonth = checkEmptyAndNull(getMonth(getData("processmonth")));
                datalayout = checkEmptyAndNull(getData("datalayout"));
                amname = checkEmptyAndNull(getData("accountmanager"));
                reason = checkEmptyAndNull(getData("reasonch"));
                billclient = checkEmptyAndNull(getData("billable"));
                //jiraid = checkEmptyAndNull(getData("jiraid"));
                problemdef = checkEmptyAndNull(getData("problemdef"));
                changespecify = checkEmptyAndNull(getData("changespecify"));
                clientpaid = checkEmptyAndNull(getData("clientpaid"));
                clientrequestdate = checkEmptyAndNull(getOnlyDate(
                        getData("clientrequestdate"), true));
                clienttargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("clienttargetdate"), true));
                actualtargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("actualtargetdate"), true));
                Impact = checkEmptyAndNull(getData("impact"));// for impact
                implementedbyimplservices = checkEmptyAndNull(getData("implementedbyimplservices"));
                implementationiceid = checkEmptyAndNull(getData("implementationiceid"));

            }
        }
        messageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, oldMessagePOJO.getChangeRequestPOJO().getProcessmonth()));
        messageModels.add(generator.mailMessageGenerator("Data Layout", datalayout, oldMessagePOJO.getChangeRequestPOJO().getDatalayout()));
        if (!isCARConverted) {
            messageModels.add(generator.mailMessageGenerator("Implemented By Implementation Services", implementedbyimplservices, oldMessagePOJO.getChangeRequestPOJO().getImplementedbyimplservices()));
            if ("Yes".equalsIgnoreCase(implementedbyimplservices)) {
                messageModels.add(generator.mailMessageGenerator("Implementation ICE ID", implementationiceid, oldMessagePOJO.getChangeRequestPOJO().getImplementationiceid()));
            }
        }
        //messageModels.add(generator.mailMessageGenerator("Jira Ticket", jiraid, oldMessagePOJO.getChangeRequestPOJO().getJiraid()));
        messageModels.add(generator.mailMessageGenerator("Bill Client", billclient, oldMessagePOJO.getChangeRequestPOJO().getBillclient()));
        if (billclient.equalsIgnoreCase("No")) {
            messageModels.add(generator.mailMessageGenerator("Account Manager", amname, oldMessagePOJO.getChangeRequestPOJO().getAmname()));
            messageModels.add(generator.mailMessageGenerator("Reason", reason, oldMessagePOJO.getChangeRequestPOJO().getReason()));
        }
        messageModels.add(generator.mailMessageGenerator("Problem Defination", problemdef, oldMessagePOJO.getChangeRequestPOJO().getProblemdef()));
        messageModels.add(generator.mailMessageGenerator("Change Specification", changespecify, oldMessagePOJO.getChangeRequestPOJO().getChangespecify()));
        messageModels.add(generator.mailMessageGenerator("Client Paid", clientpaid, oldMessagePOJO.getChangeRequestPOJO().getClientpaid()));
        messageModels.add(generator.mailMessageGenerator("Date of Client Request", clientrequestdate, oldMessagePOJO.getChangeRequestPOJO().getClientrequestdate()));
        messageModels.add(generator.mailMessageGenerator("Client Target Date", isConvertedRequest(projectId) ? targetCompDate2 : clienttargetdate, oldMessagePOJO.getChangeRequestPOJO().getClienttargetdate()));
        messageModels.add(generator.mailMessageGenerator("Actual Target Date", actualtargetdate, oldMessagePOJO.getChangeRequestPOJO().getActualtargetdate()));
        messageModels.add(generator.mailMessageGenerator("Impacted Fields", Impact, oldMessagePOJO.getChangeRequestPOJO().getImpact()));
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get changes request detail for mail message
     */
    public void addProductionIntegrationContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, boolean isCARConverted, String targetCompDate2)
            throws Exception {
        String datalayout = "";
        String amname = "";
        String reason = "";
        String billclient = "";
        String jiraid = "";
        String problemdef = "";
        String changespecify = "";
        String clientpaid = "";
        String clientrequestdate = "";
        String clienttargetdate = "";
        String actualtargetdate = "";
        String Impact = "";
        String processmonth = "";
        String implementedbyimplservices = "";
        String implementationiceid = "";
        if (getChangeRequest(projectId)) {
            if (moveNext()) {
                processmonth = checkEmptyAndNull(getMonth(getData("processmonth")));
                datalayout = checkEmptyAndNull(getData("datalayout"));
                amname = checkEmptyAndNull(getData("accountmanager"));
                reason = checkEmptyAndNull(getData("reasonch"));
                billclient = checkEmptyAndNull(getData("billable"));
                jiraid = checkEmptyAndNull(getData("jiraid"));
                problemdef = checkEmptyAndNull(getData("problemdef"));
                changespecify = checkEmptyAndNull(getData("changespecify"));
                clientpaid = checkEmptyAndNull(getData("clientpaid"));
                clientrequestdate = checkEmptyAndNull(getOnlyDate(
                        getData("clientrequestdate"), true));
                clienttargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("clienttargetdate"), true));
                actualtargetdate = checkEmptyAndNull(getOnlyDate(
                        getData("actualtargetdate"), true));
                Impact = checkEmptyAndNull(getData("impact"));// for impact
                implementedbyimplservices = checkEmptyAndNull(getData("implementedbyimplservices"));
                implementationiceid = checkEmptyAndNull(getData("implementationiceid"));

            }
        }
        // messageModels.add(generator.mailMessageGenerator("Processing Month", processmonth, oldMessagePOJO.getChangeRequestPOJO().getProcessmonth()));
        messageModels.add(generator.mailMessageGenerator("Data Layout", datalayout, oldMessagePOJO.getChangeRequestPOJO().getDatalayout()));
        if (!isCARConverted) {
            messageModels.add(generator.mailMessageGenerator("Implemented By Implementation Services", implementedbyimplservices, oldMessagePOJO.getChangeRequestPOJO().getImplementedbyimplservices()));
            if ("Yes".equalsIgnoreCase(implementedbyimplservices)) {
                messageModels.add(generator.mailMessageGenerator("Implementation ICE ID", implementationiceid, oldMessagePOJO.getChangeRequestPOJO().getImplementationiceid()));
            }
        }
        messageModels.add(generator.mailMessageGenerator("Jira Ticket", jiraid, oldMessagePOJO.getChangeRequestPOJO().getJiraid()));
        messageModels.add(generator.mailMessageGenerator("Bill Client", billclient, oldMessagePOJO.getChangeRequestPOJO().getBillclient()));
        if (billclient.equalsIgnoreCase("No")) {
            messageModels.add(generator.mailMessageGenerator("Account Manager", amname, oldMessagePOJO.getChangeRequestPOJO().getAmname()));
            messageModels.add(generator.mailMessageGenerator("Reason", reason, oldMessagePOJO.getChangeRequestPOJO().getReason()));
        }
        messageModels.add(generator.mailMessageGenerator("Problem Defination", problemdef, oldMessagePOJO.getChangeRequestPOJO().getProblemdef()));
        messageModels.add(generator.mailMessageGenerator("Change Specification", changespecify, oldMessagePOJO.getChangeRequestPOJO().getChangespecify()));
        messageModels.add(generator.mailMessageGenerator("Client Paid", clientpaid, oldMessagePOJO.getChangeRequestPOJO().getClientpaid()));
        messageModels.add(generator.mailMessageGenerator("Date of Client Request", clientrequestdate, oldMessagePOJO.getChangeRequestPOJO().getClientrequestdate()));
        messageModels.add(generator.mailMessageGenerator("Client Target Date", isConvertedRequest(projectId) ? targetCompDate2 : clienttargetdate, oldMessagePOJO.getChangeRequestPOJO().getClienttargetdate()));
        messageModels.add(generator.mailMessageGenerator("Actual Target Date", actualtargetdate, oldMessagePOJO.getChangeRequestPOJO().getActualtargetdate()));
        messageModels.add(generator.mailMessageGenerator("Impacted Fields", Impact, oldMessagePOJO.getChangeRequestPOJO().getImpact()));
    }

    public String getImplementationTypeNameById(String id) {
        String query = "SELECT IMPLEMENTATIONTYPE FROM OAM_CR_IMPLEMENTATIONTYPE WHERE IMPLEMENTATIONTYPEID='" + id + "'";
        if (getList(query, "queryBeanPM#getImplementationTypeNameById()")) {
            if (moveNext()) {
                return getData("IMPLEMENTATIONTYPE");
            }
        }
        return "";
    }

    public String getApplicationTypeNameInGroupByIdGroupByColon(String idGroupByColon) {
//            String query = "SELECT APPLICATIONTYPE FROM OAM_CR_APPLICATIONTYPE WHERE APPLICATIONTYPEID='" + id +"'";
        String sqlQuery = "select listagg(APPLICATIONTYPE, ':') within group (order by APPLICATIONTYPEID)  AS APPLICATIONTYPE "
                + "from oam_cr_applicationtype WHERE APPLICATIONTYPEID IN ( "
                + "select regexp_substr('" + idGroupByColon + "','[^:]+', 1, level) from dual "
                + "connect by regexp_substr('" + idGroupByColon + "', '[^:]+', 1, level) is not null "
                + ")";
        if (getList(sqlQuery, "queryBeanPM#getApplicationTypeNameById()")) {
            if (moveNext()) {
                return getData("APPLICATIONTYPE");
            }
        }
        return "";
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get payor management detail for mail message
     */
    public void addPayorMgmtContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, ArrayList<MailMessageModel> convertedMessageModels, String targetCompDate2, boolean isConverted) throws Exception {

        String clientsImpacted = "";
        String eigerPath = "";
        String isTestData = "";
        String testDataDetails = "";
        String effectiveDate = "";
        String layoutChangeReason = "";
        String OAMDetails = "";
        String fileNameConv = "";
        String controlTotals = "";
        String emailCommunication = "";
        String issueDetails = "";
        String dateOfComp = "";
        String signedOffBy = "";
        String additionalComments = "";
        String signedOffByUserName = "";
        String prodatalocation = "";
        String billclient = "";
        String amname = "";
        String reason = "";
        String billedMonth = "";
        String billableAmount = "";
        String approvedBy = "";
        String approvalDate = "";
        String implementationType = "";
        String newAIPLayoutId = "";
        String oldAIPLayoutId = "";

        if (getPayorManagementRequest(projectId)) {
            if (moveNext()) {
                clientsImpacted = checkEmptyAndNull(getData("impact"));
                eigerPath = checkEmptyAndNull(getData("eigerpath"));
                isTestData = checkEmptyAndNull(getData("istestdata"));
                testDataDetails = checkEmptyAndNull(getData("detailtestdata"));
                prodatalocation = checkEmptyAndNull(getData("prodatalocation"));
                effectiveDate = checkEmptyAndNull(getOnlyDate(
                        getData("productiondate"), true));
                layoutChangeReason = checkEmptyAndNull(getData("reasonchange"));
                //OAMDetails = checkEmptyAndNull(getData("oamdetail"));
                fileNameConv = checkEmptyAndNull(getData("filenamingconvention"));
                controlTotals = checkEmptyAndNull(getData("controltotal"));
                emailCommunication = checkEmptyAndNull(getData("emailcomm"));
                issueDetails = checkEmptyAndNull(getData("issueidentified"));
                dateOfComp = checkEmptyAndNull(getOnlyDate(
                        getData("dateofcompletion"), true));
                signedOffBy = checkEmptyAndNull(getData("signedoffby"));
                signedOffByUserName = checkEmptyAndNull(getData("signedoffbyusername"));
                additionalComments = checkEmptyAndNull(getData("additionalComments"));
                billclient = checkEmptyAndNull(getData("billable"));
                amname = checkEmptyAndNull(getData("accountmanager"));
                reason = checkEmptyAndNull(getData("reasonbillable"));
                billedMonth = checkEmptyAndNull(getMonth(getData("billedmonth")));
                billableAmount = checkEmptyAndNull(getData("billableamount"));
                approvedBy = checkEmptyAndNull(getData("approvedby"));
                approvalDate = checkEmptyAndNull(getOnlyDate(
                        getData("approvedate"), true));
                implementationType = getData("implementationtypeid");
                newAIPLayoutId = checkEmptyAndNull(getData("aiplayoutidnew"));
                oldAIPLayoutId = checkEmptyAndNull(getData("aiplayoutidold"));
            }
        }

        implementationType = checkEmptyAndNull(getImplementationTypeNameById(implementationType));

        if (!approvedBy.equalsIgnoreCase("N/A")) {
            approvedBy = this.getEngineerName(approvedBy);
        }
        messageModels.add(generator.mailMessageGenerator("Implementation Type", implementationType, oldMessagePOJO.getPayorMgmtPOJO().getImplementationType()));
        messageModels.add(generator.mailMessageGenerator("Old AIP Layout ID", oldAIPLayoutId, oldMessagePOJO.getPayorMgmtPOJO().getOldAIPLayoutId()));
        messageModels.add(generator.mailMessageGenerator("New AIP Layout ID", newAIPLayoutId, oldMessagePOJO.getPayorMgmtPOJO().getNewAIPLayoutId()));

        messageModels.add(generator.mailMessageGenerator("Bill Client", billclient, oldMessagePOJO.getPayorMgmtPOJO().getBillclient()));
        if (billclient.equalsIgnoreCase("No")) {
            messageModels.add(generator.mailMessageGenerator("Account Manager", amname, oldMessagePOJO.getPayorMgmtPOJO().getAmname()));
            messageModels.add(generator.mailMessageGenerator("Reason", reason, oldMessagePOJO.getPayorMgmtPOJO().getReason()));
        } else if (billclient.equalsIgnoreCase("Yes")) {
            messageModels.add(generator.mailMessageGenerator("Billed Month", billedMonth, oldMessagePOJO.getPayorMgmtPOJO().getBilledMonth()));
            messageModels.add(generator.mailMessageGenerator("Billable Amount($)", billableAmount, oldMessagePOJO.getPayorMgmtPOJO().getBillableAmount()));
        }
        messageModels.add(generator.mailMessageGenerator("Clients Impacted", clientsImpacted, oldMessagePOJO.getPayorMgmtPOJO().getClientsImpacted()));
        messageModels.add(generator.mailMessageGenerator("Layout Location", eigerPath, oldMessagePOJO.getPayorMgmtPOJO().getEigerPath()));
        messageModels.add(generator.mailMessageGenerator("Is Test Data", "Y".equalsIgnoreCase(isTestData) ? "Yes" : "No", oldMessagePOJO.getPayorMgmtPOJO().getIsTestData() != null ? "Y".equalsIgnoreCase(oldMessagePOJO.getPayorMgmtPOJO().getIsTestData()) ? "Yes" : "No" : null));
        if (isTestData.equalsIgnoreCase("Y")) {
            messageModels.add(generator.mailMessageGenerator("Test Data Details", testDataDetails, oldMessagePOJO.getPayorMgmtPOJO().getTestDataDetails()));
        }
        messageModels.add(generator.mailMessageGenerator("Production Data Location", prodatalocation, oldMessagePOJO.getPayorMgmtPOJO().getProdatalocation()));
        messageModels.add(generator.mailMessageGenerator("Effective Date", effectiveDate, oldMessagePOJO.getPayorMgmtPOJO().getEffectiveDate()));
        if (!isConverted) {
            messageModels.add(generator.mailMessageGenerator("Reason of Layout Change", layoutChangeReason, oldMessagePOJO.getPayorMgmtPOJO().getLayoutChangeReason()));
        }
        //messageModels.add(generator.mailMessageGenerator("Oam Details", OAMDetails, oldMessagePOJO.getPayorMgmtPOJO().getOAMDetails()));
        messageModels.add(generator.mailMessageGenerator("File Name Convention", fileNameConv, oldMessagePOJO.getPayorMgmtPOJO().getFileNameConv()));
        messageModels.add(generator.mailMessageGenerator("Control Totals", controlTotals, oldMessagePOJO.getPayorMgmtPOJO().getControlTotals()));
        messageModels.add(generator.mailMessageGenerator("Email Communication", emailCommunication, oldMessagePOJO.getPayorMgmtPOJO().getEmailCommunication()));
        messageModels.add(generator.mailMessageGenerator("Issue Details", issueDetails, oldMessagePOJO.getPayorMgmtPOJO().getIssueDetails()));
        messageModels.add(generator.mailMessageGenerator("Date of Completion", dateOfComp, oldMessagePOJO.getPayorMgmtPOJO().getDateOfComp()));
        if (!isConverted) {
            messageModels.add(generator.mailMessageGenerator("Approved By", approvedBy, oldMessagePOJO.getPayorMgmtPOJO().getApprovedBy()));
        }
        if (!isConverted) {
            messageModels.add(generator.mailMessageGenerator("Approval Date", approvalDate, oldMessagePOJO.getPayorMgmtPOJO().getApprovalDate()));
        }

        messageModels.add(generator.mailMessageGenerator("Signed off by", signedOffByUserName, oldMessagePOJO.getPayorMgmtPOJO().getSignedOffByUserName()));
        if (!isConverted) {
            messageModels.add(generator.mailMessageGenerator("Additional Comments", additionalComments, oldMessagePOJO.getPayorMgmtPOJO().getAdditionalComments()));
        }
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get reprocessing request detail for mail message
     */
    public void addReprocessingContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO)
            throws Exception {
        String amname = "";
        String addreasonOfReprocess = "";
        String reasonOfReprocess = "";
        String billclient = "";
        String reason = "";
        String billedMonth = "";
        String corActPlan = "";
        String approvedBy = "";
        String approvalDate = "";
        String pmhours = "";

        if (getReprocessingRequest(projectId)) {
            if (moveNext()) {
                amname = checkEmptyAndNull(getData("accountmanager"));
                addreasonOfReprocess = checkEmptyAndNull(getData("reasonreprocessing"));
                reasonOfReprocess = checkEmptyAndNull(getData("reprocessvalue"));
                billclient = checkEmptyAndNull(getData("billable"));
                reason = checkEmptyAndNull(getData("reasonbillable"));
                billedMonth = getMonth(getData("billedmonth"));
                corActPlan = checkEmptyAndNull(getData("actionplan"));
                approvedBy = checkEmptyAndNull(getData("approvedby"));
                approvalDate = checkEmptyAndNull(getOnlyDate(
                        getData("approvedate"), true));
                pmhours = checkEmptyAndNull(getData("pmhours"));
            }
        }

        if (!approvedBy.equalsIgnoreCase("N/A")) {
            approvedBy = this.getEngineerName(approvedBy);
        }
        messageModels.add(generator.mailMessageGenerator("Reason of Reprocess", reasonOfReprocess, oldMessagePOJO.getReprocessingPOJO().getReasonOfReprocess()));
        messageModels.add(generator.mailMessageGenerator("Additional details for Reprocessing", addreasonOfReprocess, oldMessagePOJO.getReprocessingPOJO().getAddreasonOfReprocess()));
        messageModels.add(generator.mailMessageGenerator("Bill Client", billclient, oldMessagePOJO.getReprocessingPOJO().getBillclient()));
        if (billclient.equalsIgnoreCase("No")) {
            messageModels.add(generator.mailMessageGenerator("Account Manager", amname, oldMessagePOJO.getReprocessingPOJO().getAmname()));
//                        messageModels.add(genenrator.mailMessageGenerator("Reason", reason, oldMessagePOJO.getReprocessingPOJO().getReason()));
        } else if (billclient.equalsIgnoreCase("Yes")) {
            messageModels.add(generator.mailMessageGenerator("Billed Month", billedMonth, oldMessagePOJO.getReprocessingPOJO().getBilledMonth()));
        }
        messageModels.add(generator.mailMessageGenerator("Payer Management Hours", pmhours, oldMessagePOJO.getReprocessingPOJO().getPmhours()));
        messageModels.add(generator.mailMessageGenerator("Corrective Action Plan", corActPlan, oldMessagePOJO.getReprocessingPOJO().getCorActPlan()));
        messageModels.add(generator.mailMessageGenerator("Approved By", approvedBy, oldMessagePOJO.getReprocessingPOJO().getApprovedBy()));
        messageModels.add(generator.mailMessageGenerator("Approval Date", approvalDate, oldMessagePOJO.getReprocessingPOJO().getApprovalDate()));
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get carrier outreach detail for mail message
     */
    public void addCORContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO) throws Exception {
        String corContent = "";

        String missingData = "";
        String missingDataMonth = "";
        String fileNameConv = "";
        String issueDetails = "";
        String additionalValues = "";
        String responseFromVendor = "";
        String additionalComments = "";

        if (getCarrierOutRequest(projectId)) {
            if (moveNext()) {
                missingData = checkEmptyAndNull(getData("missingdata"));
                missingDataMonth = getMonth(getData("missingmonth"));
                fileNameConv = checkEmptyAndNull(getData("filenamingconvention"));
                issueDetails = checkEmptyAndNull(getData("dataissues"));
                additionalValues = checkEmptyAndNull(getData("descriptions"));
                responseFromVendor = checkEmptyAndNull(getData("vendorresponse"));
                additionalComments = checkEmptyAndNull(getData("additionalComments"));
            }
        }
        System.out.println("Missing Data:" + checkEmptyAndNull(parseYesNoIfNotMatchReturnNull(missingData)));
        System.out.println("Missing Data1:" + parseYesNoIfNotMatchReturnNull(oldMessagePOJO.getCarrierPOJO().getMissingData()));

        messageModels.add(generator.mailMessageGenerator("Missing Data", checkEmptyAndNull(parseYesNoIfNotMatchReturnNull(missingData)), parseYesNoIfNotMatchReturnNull(oldMessagePOJO.getCarrierPOJO().getMissingData())));
        if (missingData.equalsIgnoreCase("Y")) {
            messageModels.add(generator.mailMessageGenerator("Missing Data Month", missingDataMonth, oldMessagePOJO.getCarrierPOJO().getMissingDataMonth()));
        }
        messageModels.add(generator.mailMessageGenerator("File Name Convention", fileNameConv, oldMessagePOJO.getCarrierPOJO().getFileNameConv()));
        messageModels.add(generator.mailMessageGenerator("Issue Details", issueDetails, oldMessagePOJO.getCarrierPOJO().getIssueDetails()));
        messageModels.add(generator.mailMessageGenerator("Additional Values", additionalValues, oldMessagePOJO.getCarrierPOJO().getAdditionalValues()));
        messageModels.add(generator.mailMessageGenerator("Response From Vendor", responseFromVendor, oldMessagePOJO.getCarrierPOJO().getResponseFromVendor()));
        messageModels.add(generator.mailMessageGenerator("Additional Comments", additionalComments, oldMessagePOJO.getCarrierPOJO().getAdditionalComments()));
    }

    public String parseYesNoIfNotMatchReturnNull(String s) {
        int val = 0;
        if (s != null) {
            if (s.equals("Y")) {
                val = 1;
            }
        }

        switch (val) {
            case 1:
                return "Yes";
            case 0:
                return "No";
        }
        return null;
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get extract or custom adhoc detail for mail message
     */
    public void addEXRCAWContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, String issueTypeCode, ArrayList<MailMessageModel> convertedMessageModels, String targetCompDate2, String actualCompDate2, boolean isConverted)
            throws Exception {
        String content = "";

        String amname = "";
        String details = "";
        String billclient = "";
        String reason = "";
        String billedMonth = "";
        String approvedBy = "";
        String signedBy = "";
        String approvalDate = "";
        String implSpecial = "";
        String implementedbyimplservices = "";
        String implementationiceid = "";
        if (getEXRRequest(projectId)) {
            if (moveNext()) {
                amname = checkEmptyAndNull(getData("accountmanager"));
                details = checkEmptyAndNull(getData("EXTRACTDETAIL"));
                billclient = checkEmptyAndNull(getData("billable"));
                reason = checkEmptyAndNull(getData("reasonbillable"));
                billedMonth = getMonth(getData("billedmonth"));
                implSpecial = checkEmptyAndNull(getData("impspecialist"));
                approvedBy = checkEmptyAndNull(getData("approvedby"));
                signedBy = checkEmptyAndNull(getData("SIGNEDOFFBY"));
                approvalDate = checkEmptyAndNull(getOnlyDate(
                        getData("approvedate"), true));
                implementedbyimplservices = checkEmptyAndNull(getData("implementedbyimplservices"));
                implementationiceid = checkEmptyAndNull(getData("implementationiceid"));
            }
        }
        //Target Completion Date
        //Actual Completion Date
        if (!approvedBy.equalsIgnoreCase("N/A")) {
            approvedBy = this.getEngineerName(approvedBy);
        }
        if (!signedBy.equalsIgnoreCase("N/A")) {
            signedBy = this.getEngineerName(signedBy);
        }
        messageModels.add(generator.mailMessageGenerator("Details", details, oldMessagePOJO.getExtractCAdhocPOJO().getDetails()));
        messageModels.add(generator.mailMessageGenerator("Bill Client", billclient, oldMessagePOJO.getExtractCAdhocPOJO().getBillclient()));
        if (billclient.equalsIgnoreCase("No")) {
            messageModels.add(generator.mailMessageGenerator("Account Manager", amname, oldMessagePOJO.getExtractCAdhocPOJO().getAmname()));
            messageModels.add(generator.mailMessageGenerator("Reason", reason, oldMessagePOJO.getExtractCAdhocPOJO().getReason()));
        } else if (billclient.equalsIgnoreCase("Yes")) {
            messageModels.add(generator.mailMessageGenerator("Billed Month", billedMonth, oldMessagePOJO.getExtractCAdhocPOJO().getBilledMonth()));
        }
        if ("Yes".equalsIgnoreCase(implementedbyimplservices)) {
            messageModels.add(generator.mailMessageGenerator("Implemented By Implementation Services", implementedbyimplservices, oldMessagePOJO.getExtractCAdhocPOJO().getImplementedbyimplservices()));
            messageModels.add(generator.mailMessageGenerator("Implementation ICE ID", implementationiceid, oldMessagePOJO.getExtractCAdhocPOJO().getImplementationiceid()));
        } else if ("No".equalsIgnoreCase(implementedbyimplservices)) {
            messageModels.add(generator.mailMessageGenerator("Implemented By Implementation Services", implementedbyimplservices, oldMessagePOJO.getExtractCAdhocPOJO().getImplementedbyimplservices()));
        }
        messageModels.add(generator.mailMessageGenerator("Implementation Specialist", implSpecial, oldMessagePOJO.getExtractCAdhocPOJO().getImplSpecial()));
        messageModels.add(generator.mailMessageGenerator("Approved by", approvedBy, oldMessagePOJO.getExtractCAdhocPOJO().getApprovedBy()));
        if (isConverted) {
            messageModels.add(generator.mailMessageGenerator("Target Completion Date", targetCompDate2, oldMessagePOJO.getTargetCompDate2()));
            messageModels.add(generator.mailMessageGenerator("Actual Completion Date", actualCompDate2, oldMessagePOJO.getActualCompDate2()));
        }
        messageModels.add(generator.mailMessageGenerator("Signed off by", signedBy, oldMessagePOJO.getExtractCAdhocPOJO().getSignedBy()));
        messageModels.add(generator.mailMessageGenerator("Approval Date", approvalDate, oldMessagePOJO.getExtractCAdhocPOJO().getApprovalDate()));

    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get request detail for subtask I for mail message
     */
    public void getFormattedRequestDetailsForSubTaskINew(String parentcode, String ProjID, String styleClass, ArrayList<MailMessageModel> messageModels, String prevActionText)
            throws Exception {
        String requestCodee = this.getPostReplyCount(ProjID, parentcode);
        MailMessageGenerator generator = new MailMessageGenerator();
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {

                String requestdate = checkEmptyAndNull(getOnlyDate(
                        getData("REQUESTDATE"), true));
                String requestPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String requests = checkEmptyAndNull(getData("requests"));
                messageModels.add(new MailMessageModel("Follow up #", requestCodee, styleClass, null));
                messageModels.add(new MailMessageModel("Request Date", requestdate, styleClass, null));
                messageModels.add(new MailMessageModel("Requesting Person", requestPersonName, styleClass, null));
                if (prevActionText != null && !prevActionText.trim().isEmpty() && !checkEmptyAndNull(prevActionText).equalsIgnoreCase(requests)) {
                    messageModels.add(generator.mailMessageGeneratorFollowUp("Modified Comment", splitRequestMessagePTag(requests.trim()), splitRequestMessagePTag(prevActionText.trim())));
                    messageModels.add(new MailMessageModel("Previous Comment", splitRequestMessagePTag(prevActionText.trim()), styleClass, null));
                } else {
                    messageModels.add(new MailMessageModel("Action", splitRequestMessagePTag(requests.trim()), styleClass, null));
                }

            }
        }

    }

    public boolean isApplicationTypeShow(String requestCode) {
        return RequestCode.CHANGE_REQUEST.getRequestCode().equalsIgnoreCase(requestCode)
                || RequestCode.IMPLEMENTATION_SERVICES.getRequestCode().equalsIgnoreCase(requestCode)
                || RequestCode.DATA_ANALYSIS_REQUEST.getRequestCode().equalsIgnoreCase(requestCode)
                || RequestCode.REPROCESSING.getRequestCode().equalsIgnoreCase(requestCode);
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.09
     * @purpose - to get production integration request detail for mail message
     */
    public void addProductionIntegrationContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO)
            throws Exception {

        ProductionIntegrationCode nPIC = new ProductionIntegrationCode();
        if (getProductionIntCodeRequest(projectId)) {
            if (moveNext()) {
                nPIC.setAccountManager(getData("accountmanager"));
                nPIC.setRequestDesc(getData("requestdescription"));
                nPIC.setImpICETicketNum(getData("impliceticketnum"));
                nPIC.setProcessingMonth(checkEmptyAndNull(getMonth(getData("processingmonth"))));
                nPIC.setHandOverDate(getOnlyDate(getData("handoverdate"), true));
                nPIC.setAccStrDetailsIncluded(getData("accstrdetailsincluded"));
                nPIC.setAddtionalComments(getData("addcomments"));
                nPIC.setApprovedBy(getData("approvedby"));
                //nPIC.setRemarks(getData("remarks"));
                nPIC.setTargetCompDate(getOnlyDate(getData("targetcompdate"), true));
                nPIC.setActualCompDate(getOnlyDate(getData("actualcompdate"), true));
                nPIC.setApprovedDate(getOnlyDate(getData("approveddate"), true));
            }
        }

        if (!checkEmptyAndNull(nPIC.getApprovedBy()).equalsIgnoreCase("N/A")) {
            nPIC.setApprovedBy(this.getEngineerName(nPIC.getApprovedBy()));
        }
        nPIC.convertCodedInfo(nPIC);
        messageModels.add(generator.mailMessageGeneratorWithCheck("Account Manager", nPIC.getAccountManager(), oldMessagePOJO.getProductionIntegrationCodePOJO().getAccountManager()));
        messageModels.add(generator.mailMessageGenerator("Integration Type", oldMessagePOJO.getNewRequestParamDTO().getIntegrationtype(),
                oldMessagePOJO.getOldRequestParamDTO().getIntegrationtype()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Request Description", nPIC.getRequestDesc(), oldMessagePOJO.getProductionIntegrationCodePOJO().getRequestDesc()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Implementation ICE Ticket Numbers", nPIC.getImpICETicketNum(), oldMessagePOJO.getProductionIntegrationCodePOJO().getImpICETicketNum()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Processing Month", nPIC.getProcessingMonth(), oldMessagePOJO.getProductionIntegrationCodePOJO().getProcessingMonth()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Hand Over Date", nPIC.getHandOverDate(), oldMessagePOJO.getProductionIntegrationCodePOJO().getHandOverDate()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Target Completion Date", nPIC.getTargetCompDate(), oldMessagePOJO.getProductionIntegrationCodePOJO().getTargetCompDate()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Actual Completion Date", nPIC.getActualCompDate(), oldMessagePOJO.getProductionIntegrationCodePOJO().getActualCompDate()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Account Structure Details Included", nPIC.getAccStrDetailsIncluded(), oldMessagePOJO.getProductionIntegrationCodePOJO().getAccStrDetailsIncluded()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Additional Comment", nPIC.getAddtionalComments(), oldMessagePOJO.getProductionIntegrationCodePOJO().getAddtionalComments()));
        //messageModels.add(genenrator.mailMessageGeneratorWithCheck("Remarks", nPIC.getRemarks(), oldMessagePOJO.getProductionIntegrationCodePOJO().getRemarks()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Approved By", nPIC.getApprovedBy(), oldMessagePOJO.getProductionIntegrationCodePOJO().getApprovedBy()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Approval Date", nPIC.getApprovedDate(), oldMessagePOJO.getProductionIntegrationCodePOJO().getApprovedDate()));

    }

    public void addLayoutAnalysisContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, String issueTypeCode, ArrayList<MailMessageModel> convertedMessageModels, String targetCompDate2)
            throws Exception {
        LayoutAnalysisDAO layoutAnalysisDAO = new LayoutAnalysisDAO();
        LayoutAnalysisDTO layoutAnalysisDTO = layoutAnalysisDAO.find(projectId);
        layoutAnalysisDAO.takeDown();
        messageModels.add(generator.mailMessageGeneratorWithCheck("Account Manager", layoutAnalysisDTO.getAccountmanager(), oldMessagePOJO.getLayoutAnalysisDTO().getAccountmanager()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Request Description", layoutAnalysisDTO.getRequestdescription(), oldMessagePOJO.getLayoutAnalysisDTO().getRequestdescription()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Layout Location", layoutAnalysisDTO.getEigerpath(), oldMessagePOJO.getLayoutAnalysisDTO().getEigerpath()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Reason of Layout Change", layoutAnalysisDTO.getReasonchange(), oldMessagePOJO.getLayoutAnalysisDTO().getReasonchange()));
        if (!generator.checkEmptyAndNull(layoutAnalysisDTO.getApprovedby()).equalsIgnoreCase("N/A")) {
            layoutAnalysisDTO.setApprovedby(this.getEngineerName(layoutAnalysisDTO.getApprovedby()));
        }
        if (!generator.checkEmptyAndNull(oldMessagePOJO.getLayoutAnalysisDTO().getApprovedby()).equalsIgnoreCase("N/A")) {
            oldMessagePOJO.getLayoutAnalysisDTO().setApprovedby(this.getEngineerName(oldMessagePOJO.getLayoutAnalysisDTO().getApprovedby()));
        }
//        messageModels.add(generator.mailMessageGeneratorWithCheck("Approved By", layoutAnalysisDTO.getApprovedby(), oldMessagePOJO.getLayoutAnalysisDTO().getApprovedby()));
//        messageModels.add(generator.mailMessageGeneratorWithCheck("Approval Date", layoutAnalysisDTO.getApprovedate(), oldMessagePOJO.getLayoutAnalysisDTO().getApprovedate()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Additional Comments", layoutAnalysisDTO.getAdditionalcomments(), oldMessagePOJO.getLayoutAnalysisDTO().getAdditionalcomments()));
    }

    public void addEstimateContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, String issueTypeCode, ArrayList<MailMessageModel> convertedMessageModels, String targetCompDate2)
            throws Exception {
        EstimateDAO estimateDAO = new EstimateDAO();
        EstimateDTO estimateDTO = estimateDAO.find(projectId);
        estimateDAO.takeDown();
        messageModels.add(generator.mailMessageGeneratorWithCheck("Account Manager", estimateDTO.getAccountmanager(), oldMessagePOJO.getEstimateDTO().getAccountmanager()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Request Description", estimateDTO.getRequestdescription(), oldMessagePOJO.getEstimateDTO().getRequestdescription()));
        //messageModels.add(generator.mailMessageGeneratorWithCheck("Billable Amount($)", estimateDTO.getBillableamount(), oldMessagePOJO.getEstimateDTO().getBillableamount()));
        if (!generator.checkEmptyAndNull(estimateDTO.getApprovedby()).equalsIgnoreCase("N/A")) {
            estimateDTO.setApprovedby(this.getEngineerName(estimateDTO.getApprovedby()));
        }
        if (!generator.checkEmptyAndNull(oldMessagePOJO.getEstimateDTO().getApprovedby()).equalsIgnoreCase("N/A")) {
            oldMessagePOJO.getEstimateDTO().setApprovedby(this.getEngineerName(oldMessagePOJO.getEstimateDTO().getApprovedby()));
        }
//        messageModels.add(generator.mailMessageGeneratorWithCheck("Approved By", estimateDTO.getApprovedby(), oldMessagePOJO.getEstimateDTO().getApprovedby()));
//        messageModels.add(generator.mailMessageGeneratorWithCheck("Approval Date", estimateDTO.getApprovedate(), oldMessagePOJO.getEstimateDTO().getApprovedate()));
    }

    public void addDefectContentForMailNew(String projectId, ArrayList<MailMessageModel> messageModels, MailMessageGenerator generator, MailMessagePOJO oldMessagePOJO, String issueTypeCode, ArrayList<MailMessageModel> convertedMessageModels, String targetCompDate2)
            throws Exception {
        DefectDAO defectDAO = new DefectDAO();
        DefectDTO defectDTO = defectDAO.find(projectId);
        defectDAO.takeDown();
        messageModels.add(generator.mailMessageGeneratorWithCheck("Application", defectDTO.getApplicationName(), oldMessagePOJO.getDefectDTO().getApplicationName()));
        messageModels.add(generator.mailMessageGeneratorWithCheck("Component", defectDTO.getComponentName(), oldMessagePOJO.getDefectDTO().getComponentName()));
        if (isProductionApplication(projectId)) {
            messageModels.add(generator.mailMessageGeneratorWithCheck("Category", defectDTO.getCategoryName(), oldMessagePOJO.getDefectDTO().getCategoryName()));
        }
        messageModels.add(generator.mailMessageGeneratorWithCheck("Request Description", defectDTO.getRequestdescription(), oldMessagePOJO.getDefectDTO().getRequestdescription()));
//        messageModels.add(generator.mailMessageGenerator("Parent ICE ID", oldMessagePOJO.getNewRequestParamDTO().getParenticeid(), oldMessagePOJO.getOldRequestParamDTO().getParenticeid()));
//
//        messageModels.add(generator.mailMessageGenerator("Parent Request Type",
//                CommonUtils.getRequestTitleById(oldMessagePOJO.getNewRequestParamDTO().getParentrequesttype()),
//                CommonUtils.getRequestTitleById(oldMessagePOJO.getOldRequestParamDTO().getParentrequesttype())));

        if (isProductionApplication(projectId)) {
            messageModels.add(generator.mailMessageGeneratorWithCheck("Root Cause", defectDTO.getRootCause(), oldMessagePOJO.getDefectDTO().getRootCause()));
            messageModels.add(generator.mailMessageGeneratorWithCheck("Sub Type", defectDTO.getSubTypeName(), oldMessagePOJO.getDefectDTO().getSubTypeName()));
        }
    }

    private String splitRequestMessagePTag(String requests) {
        return requests.trim();
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get request detail for subtask II for mail message
     */
    public void getFormattedRequestDetailsForSubTaskIINew(String parentcode, String requestcode, String ProjID, String styleClass, ArrayList<MailMessageModel> messageModels, String prevActionText)
            throws Exception {
        String requestCodee = this.getPostReplyCount(requestcode, parentcode);
        requestCodee += ".";
        requestCodee += this.getPostReplyCount(ProjID, requestcode);
        MailMessageGenerator generator = new MailMessageGenerator();
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestdate = checkEmptyAndNull(getOnlyDate(
                        getData("REQUESTDATE"), true));
                String requestPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String requests = checkEmptyAndNull(getData("requests"));
                messageModels.add(new MailMessageModel("Follow up #", requestCodee, styleClass, null));
                messageModels.add(new MailMessageModel("Request Date", requestdate, styleClass, null));
                messageModels.add(new MailMessageModel("Requesting Person", requestPersonName, styleClass, null));
                if (prevActionText != null && !prevActionText.trim().isEmpty() && !checkEmptyAndNull(prevActionText).equalsIgnoreCase(requests)) {
                    messageModels.add(generator.mailMessageGeneratorFollowUp("Modified Comment", splitRequestMessagePTag(requests.trim()), splitRequestMessagePTag(prevActionText.trim())));
                    messageModels.add(new MailMessageModel("Previous Comment", splitRequestMessagePTag(prevActionText.trim()), styleClass, null));
                } else {
                    messageModels.add(generator.mailMessageGeneratorFollowUp("Action", splitRequestMessagePTag(requests.trim()), null));
                }
            }
        }

    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get request detail for subtask for mail message
     */
    public void getFormattedRequestDetailsForSubTaskNew(String ProjID, String assignee, String reporter, String styleClass, ArrayList<MailMessageModel> messageModels)
            throws Exception {
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestCodee = checkEmptyAndNull(getData("RequestCode"));
                String requestPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String clientName = checkEmptyAndNull(getData("ClientName"));
                String mainEnggiName = checkEmptyAndNull(getData("User_Name"));
                String phasename = checkEmptyAndNull(getData("phasename"));
                String issueType = checkEmptyAndNull(getData("issuetypename"));
                String issueTypeCode = checkEmptyAndNull(getData("crcode"));
                String AppID = checkEmptyAndNull(getData("AppID"));
                String dataType = checkEmptyAndNull(getData("datatype"));
                String payer = checkEmptyAndNull(getData("payorname"));
                String requesttitle = checkEmptyAndNull(getData("requesttitle"));
                String targetCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate"), true));
                String actualCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("ACTUALCOMPDATE"), true));
                messageModels.add(new MailMessageModel("Request ID", requestCodee, styleClass, null));
                messageModels.add(new MailMessageModel("Request Type", issueType, styleClass, null));
                messageModels.add(new MailMessageModel("Client", clientName, styleClass, null));
                messageModels.add(new MailMessageModel("App ID", AppID, styleClass, null));
                messageModels.add(new MailMessageModel("Payer", payer, styleClass, null));
                if (issueTypeCode.equalsIgnoreCase("PMG")) {
                    messageModels.add(new MailMessageModel("Data Type", dataType, styleClass, null));
                }
                messageModels.add(new MailMessageModel("Phase", phasename, styleClass, null));
                messageModels.add(new MailMessageModel("Requesting Person", requestPersonName, styleClass, null));
                messageModels.add(new MailMessageModel("Assigned to", mainEnggiName, styleClass, null));
                messageModels.add(new MailMessageModel("Request Title", requesttitle, styleClass, null));
                messageModels.add(new MailMessageModel("Target Date", targetCompDate, styleClass, null));
                messageModels.add(new MailMessageModel("Actual Comp Date", actualCompDate, styleClass, null));

            }
        }

    }

    /**
     * @author rkc
     * @date 2015.10.26
     * @purpose - to aggregate payor_name by id with special character (:)
     */
    public String getAggregatePayorNameForRequestCode(String requestCode) {
        requestCode = requestCode != null ? requestCode.replaceAll("'", "") : requestCode;
        String sqlString = "SELECT fun_aggregate(payorid) VHPAYORNAME FROM oam_rm_requestmanager a WHERE requestcode='" + requestCode + "'";
        if (getList(sqlString, "getAggregatePayorNameForRequestCode")) {
            if (moveNext()) {
                return getData("VHPAYORNAME");
            }
        }
        return "";
    }

    /**
     * Generate target date string by adding defaul days + current date
     *
     * @param reqType
     * @return
     */
    public String getTargetDateByRequestType(String reqType) {
        String sqlString = "SELECT To_Char( (add_working_days (c.issuetypetarget,sysdate)), 'MM/DD/YYYY') AS TARGET "
                + //                                " c.issuetypetarget " +
                " FROM   oam_cr_templates a  "
                + " left join oam_cr_template_issuetype b  "
                + " ON a.templateid = b.templateid  "
                + " left join oam_cr_issuetype c  "
                + " ON b.issuetypeid = c.issuetypeid  "
                + " left join oam_cr_template_phases c  "
                + " ON a.templateid = c.templateid  "
                + " left join oam_cr_phases d  "
                + " ON c.phaseid = d.phaseid "
                + " WHERE  1 = 1 and b.issuetypeid = " + reqType + " GROUP BY "
                + " c.issuetypetarget";
        if (getList(sqlString, "getTargetDateByRequestType")) {
            if (moveNext()) {
                return getData("TARGET");

            }
        }
        return "";
    }

    //i81324
    public String getUsernameByUserId(String userId) {
        String sql = "SELECT USERNAME FROM USR_USERS WHERE USERID='" + userId + "'";
        if (this.getList(sql, "user name by userid")) {
            if (this.moveNext()) {
                return this.getData("USERNAME");
            }
        }
        return "";
    }

    //i81324
    public void updateSyncDataFromFollowUpRequest(String phaseId, String assignTo, String targetDate, String parentRequestCode, String lastEditedBy, Map<String, String> params) {
        System.out.println("Update for SYNC PHASEID=" + phaseId + ",assignTo=" + assignTo + ",targetDate=" + targetDate + ",ParenRequestCode=" + parentRequestCode);
        try {
            String requestTypeId = "";
            String is_converted = "";
            String updateSQL = "UPDATE OAM_RM_REQUESTMANAGER SET PHASEID=?, ASSIGNEDTO=?, TARGETCOMPDATE=?, STATUSID=?, LASTEDITEDBY = ? , LINK_TYPE = ?, LINK_ICE_ID = ? WHERE REQUESTCODE=?";
            strSQL = "SELECT TARGETCOMPDATE2,REQUESTTYPEID,is_converted FROM OAM_RM_REQUESTMANAGER WHERE REQUESTCODE='" + parentRequestCode + "'";
            if (getList(strSQL, "Getting targetDate2")) {
                if (this.moveNext()) {
                    String targetDateComp2 = this.getData("TARGETCOMPDATE2");
                    requestTypeId = getData("REQUESTTYPEID");
                    is_converted = getData("is_converted");
                    System.out.println("TargetDateCOmp2= " + targetDateComp2 + ", RequestTypeId=" + requestTypeId);
                    if (targetDateComp2 != null && !targetDateComp2.trim().isEmpty()) {
                        System.out.println("Update with targetdatecomp2....");
                        updateSQL = "UPDATE OAM_RM_REQUESTMANAGER SET PHASEID=?, ASSIGNEDTO=?,TARGETCOMPDATE2=?, STATUSID=?, LASTEDITEDBY = ?,LINK_TYPE=?, LINK_ICE_ID=? WHERE REQUESTCODE=?";
                    }
                }
            }
            String statusID = "";
            statusID = getStatus(phaseId);

            System.out.println("Update SQL = " + updateSQL + " Status =" + statusID);
            PreparedStatement ps = myConn.prepareStatement(updateSQL);
            ps.setString(1, phaseId);
            ps.setString(2, assignTo);
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            if (targetDate.equalsIgnoreCase("")) {
                ps.setDate(3, null);
            } else {
                ps.setDate(3, new java.sql.Date((sdf.parse(targetDate).getTime())));
            }
            ps.setInt(4, Integer.valueOf(statusID));
            ps.setString(5, lastEditedBy);
            ps.setString(6, params.get("link_type"));
            ps.setString(7, params.get("link_ice_id"));
            ps.setString(8, parentRequestCode);
            ps.executeUpdate();
            if (CommonUtils.RequestCode.CHANGE_REQUEST.getRequestTypeId().equals(requestTypeId) && !targetDate.trim().isEmpty()) {
                String updateSQL1 = "UPDATE oam_cr_crmanager SET  CLIENTTARGETDATE = ? WHERE REQUESTCODE = ?";
                PreparedStatement cRPS = myConn.prepareStatement(updateSQL1);
                cRPS.setDate(1, new java.sql.Date((sdf.parse(targetDate).getTime())));
                cRPS.setString(2, parentRequestCode);
                cRPS.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean getRequestDetailForFollowUpByRequestCode(String requestCode) {
        strSQL = "SELECT REQUESTTYPEID,PHASEID,ASSIGNEDTO,TO_CHAR(Nvl (TARGETCOMPDATE2,TARGETCOMPDATE), 'MM/DD/YYYY') AS TARGETDATE, CONVREQUESTTYPEID, LINK_TYPE, LINK_ICE_ID "
                + " FROM oam_rm_requestmanager WHERE REQUESTCODE='" + requestCode + "'";
        return getList(strSQL, "IssueType Id for Request Code");
    }

    /**
     * @author (i81324-rkc)
     * @type added
     * @date 2015.10.05
     * @purpose - to get request detail for subtask for mail message
     */
    public void getFormattedRequestDetailsForSubTaskNew(String ProjID,
            String assignee,
            String reporter,
            String styleClass,
            ArrayList<MailMessageModel> messageModels,
            String prevPhaseId, String prevTargetDate, String prevAssignToId, StringBuilder logBuilder
    )
            throws Exception {
        if (getRequestDetails(ProjID)) {
            if (moveNext()) {
                String requestCodee = checkEmptyAndNull(getData("RequestCode"));
                String requestPersonName = checkEmptyAndNull(getData("RequestingPersonDesc"));
                String clientName = checkEmptyAndNull(getData("ClientName"));
                String mainEnggiName = checkEmptyAndNull(getData("User_Name"));
                String phasename = checkEmptyAndNull(getData("phasename"));
                String issueType = checkEmptyAndNull(getData("issuetypename"));
                String secondaryType = checkEmptyAndNull(getData("secondaryType"));
                String issueTypeCode = checkEmptyAndNull(getData("crcode"));
                String AppID = checkEmptyAndNull(getData("AppID"));
                String dataType = checkEmptyAndNull(getData("datatype"));
                String payer = checkEmptyAndNull(getData("payorname"));
                String requesttitle = checkEmptyAndNull(getData("requesttitle"));
                String targetCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate"), true));
                String targetCompDate2 = checkEmptyAndNull(getOnlyDate(
                        getData("targetCompDate2"), true));

                if (prevTargetDate != null && prevTargetDate.length() > 4) {
                    // 03/02/2010
                    if (prevTargetDate.charAt(0) == '0') {
                        prevTargetDate = prevTargetDate.substring(1, prevTargetDate.length());
                        if (prevTargetDate.charAt(2) == '0') {
                            prevTargetDate = prevTargetDate.substring(0, 2) + prevTargetDate.substring(3, prevTargetDate.length());
                        }
                    } else if (prevTargetDate.charAt(3) == '0') {
                        prevTargetDate = prevTargetDate.substring(0, 3) + prevTargetDate.substring(4, prevTargetDate.length());
                    }
                }
                if (targetCompDate2 != null && !"N/A".equalsIgnoreCase(targetCompDate2)) {
                    targetCompDate = targetCompDate2;
                }

                MailMessageGenerator generator = new MailMessageGenerator();

                System.out.println("TargetDate = " + targetCompDate + " PrevTargetDate = " + prevTargetDate);

                String actualCompDate = checkEmptyAndNull(getOnlyDate(
                        getData("ACTUALCOMPDATE"), true));

                messageModels.add(new MailMessageModel("Request ID", requestCodee, styleClass, null));
                messageModels.add(new MailMessageModel("Request Type", issueType, styleClass, null));
                if (!secondaryType.equalsIgnoreCase("N/A")) {
                    messageModels.add(new MailMessageModel("Secondary Request Type", secondaryType, styleClass, null));
                }
                messageModels.add(new MailMessageModel("Client", clientName, styleClass, null));
                //messageModels.add(new MailMessageModel("App ID", AppID, styleClass, null));
                messageModels.add(new MailMessageModel("Payer", payer, styleClass, null));
                if (issueTypeCode.equalsIgnoreCase("PMG")) {
                    messageModels.add(new MailMessageModel("Data Type", dataType, styleClass, null));
                }

                prevPhaseId = checkEmptyAndNull(getPhaseDesc(prevPhaseId));
                prevAssignToId = checkEmptyAndNull(getUsernameByUserId(prevAssignToId));
                boolean isSkipLog = false;
                if (prevPhaseId != null && !prevPhaseId.equalsIgnoreCase(phasename)) {
                    messageModels.add(new MailMessageModel("Current Phase", phasename, "currentEdit", null));
                    messageModels.add(new MailMessageModel("Previous Phase", prevPhaseId, "currentEdit", null));

                    if (!isSkipLog) {
                        logBuilder.setLength(0);
                        logBuilder.append(" changed the phase to ").append(phasename)
                                .append(AppConstants.INSTANCE.ACTIVITY_UPDATE_PRIMARY_SECONDARY_MESSAGE_SPLITTER);
                        isSkipLog = true;
                    }

                    generator.mailMessageGenerator("Current Phase", phasename, prevPhaseId);

                    Map<String, String> phaseChangeTrackDetail = getPhaseChangeTrackDetail(requestCodee);
                    if (phaseChangeTrackDetail != null) {
                        messageModels.add(new MailMessageModel("Last Phase Changed On", phaseChangeTrackDetail.get("logged"), null, null));
                        messageModels.add(new MailMessageModel("Last Phase Changed By", phaseChangeTrackDetail.get("username"), null, null));
                    }
                } else {
                    messageModels.add(new MailMessageModel("Phase", phasename, styleClass, null));
                }
                messageModels.add(new MailMessageModel("Requesting Person", requestPersonName, styleClass, null));

                if (prevAssignToId != null && !prevAssignToId.equalsIgnoreCase(mainEnggiName)) {
                    messageModels.add(new MailMessageModel("Assigned to", mainEnggiName, "currentEdit", null));
                    if (!isSkipLog) {
                        logBuilder.setLength(0);
                        logBuilder.append(" changed the assignee to ").append(mainEnggiName)
                                .append(AppConstants.INSTANCE.ACTIVITY_UPDATE_PRIMARY_SECONDARY_MESSAGE_SPLITTER);
//                        isSkipLog = true;
                    }
                    generator.mailMessageGenerator("Assigned to", mainEnggiName, prevAssignToId);
                } else {
                    messageModels.add(new MailMessageModel("Assigned to", mainEnggiName, styleClass, null));
                }
                messageModels.add(new MailMessageModel("Request Title", requesttitle, styleClass, null));

                if (prevTargetDate != null && !checkEmptyAndNull(prevTargetDate).equalsIgnoreCase(targetCompDate)) {
                    messageModels.add(new MailMessageModel("Target Date", targetCompDate, "currentEdit", null));
                    generator.mailMessageGenerator("Target Date", targetCompDate, prevTargetDate);
                } else {
                    messageModels.add(new MailMessageModel("Target Date", targetCompDate, styleClass, null));
                }
                messageModels.add(new MailMessageModel("Actual Comp Date", actualCompDate, styleClass, null));
                logBuilder.append(generator.getLogBuilder().toString());
            }
        }

    }

    //added by bhuwan
    //to determine phase change detail
    public Map<String, String> getPhaseChangeTrackDetail(String requestCode) {
        String query = "SELECT TO_CHAR(logged, 'mm/dd/yyyy') as logged,  "
                + "       username,  "
                + "       phasename,p.phaseid  "
                + "FROM   "
                + "( "
                + "SELECT * FROM   "
                + "(SELECT *  "
                + "        FROM   (SELECT phaseid,  "
                + "                       logged,  "
                + "                       requestcode  "
                + "                FROM   oam_rm_requestmanager_log  "
                + "                WHERE  requestcode = '" + requestCode + "'  "
                + "                ORDER  BY logged DESC)  "
                + "        WHERE  ROWNUM < 3  ORDER BY logged ASC   ) WHERE ROWNUM < 2 "
                + "            ) "
                + "         a  "
                + "       inner join (SELECT lasteditedby,  "
                + "                          requestcode  "
                + "                   FROM   oam_rm_requestmanager  "
                + "                   WHERE  requestcode = '" + requestCode + "') b  "
                + "               ON a.requestcode = b.requestcode  "
                + "       inner join (SELECT username,  "
                + "                          userid  "
                + "                   FROM   usr_users) c  "
                + "               ON                                "
                + "                   REGEXP_SUBSTR( b.lasteditedby, '^\\d*', 1, 1) "
                + "                = c.userid  "
                + "       inner join (SELECT phaseid,  "
                + "                          phasename  "
                + "                   FROM   oam_cr_phases) p  "
                + "               ON p.phaseid = a.phaseid";
        System.out.println("last Phase:" + query);
        if (getList(query, "CommonDAO#getPhaseChangeTrackDetail()")) {
            if (moveNext()) {
                Map<String, String> phaseTrackDetail = new HashMap<String, String>();
                phaseTrackDetail.put("logged", getData("logged"));
                phaseTrackDetail.put("username", getData("username"));
                phaseTrackDetail.put("phasename", getData("phasename"));
                phaseTrackDetail.put("phaseid", getData("phaseid"));
                return phaseTrackDetail;
            }
        }
        return null;
    }

    /*
    
    Normal Tips:
    -Alawys take down connection in every jsp page if any bean which used ConnectionBean
    Ajax Call Method
    -------------------
    Note for dwr call from javascript to any method
    1. We must close database connection
     */
    /**
     * Generate target date string by adding defaul days + current date
     *
     * @param reqType
     * @return
     */
    public String ajaxGetTargetDateByRequestType(String reqType) {
        try {
            if (myConn == null || myConn.isClosed()) {
                setAlias("RequestManager->SuperDomainDataBase");
                this.makeConnection();
            }
            String sqlString = "SELECT To_Char( (add_working_days (c.issuetypetarget,sysdate)), 'MM/DD/YYYY') AS TARGET "
                    + " FROM   oam_cr_templates a  "
                    + " left join oam_cr_template_issuetype b  "
                    + " ON a.templateid = b.templateid  "
                    + " left join oam_cr_issuetype c  "
                    + " ON b.issuetypeid = c.issuetypeid  "
                    + " left join oam_cr_template_phases c  "
                    + " ON a.templateid = c.templateid  "
                    + " left join oam_cr_phases d  "
                    + " ON c.phaseid = d.phaseid "
                    + " WHERE  1 = 1 and b.issuetypeid = " + reqType + " GROUP BY "
                    + " c.issuetypetarget";
            PreparedStatement ps = myConn.prepareStatement(sqlString);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("TARGET");
            }
        } catch (Exception e) {
            System.out.println("ERROR : #ajaxGetTargetDateByRequestType()" + e.getMessage());
        } finally {
            this.takeDown();
        }
        return "";
    }

    public String ajaxGetPrioritizedByRequestType(String reqType) {
        String option = "<option value='-1'>Please Choose</option>";
        try {
            if (myConn == null || myConn.isClosed()) {
                setAlias("RequestManager->SuperDomainDataBase");
                this.makeConnection();
            }
            String sqlString = "SELECT a.USERID,b.USERNAME FROM OAM_CR_PRIORITIZED_USERS a, USR_USERS b WHERE  a.USERID = b.USERID AND a.ISSUETYPEID ='" + reqType + "' ORDER  BY a.USERID";
            PreparedStatement ps = myConn.prepareStatement(sqlString);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                option += "<option value='" + rs.getString("USERID") + "'>" + rs.getString("USERNAME") + "</option>";
            }
        } catch (Exception e) {
            System.out.println("ERROR : #ajaxGetPrioritizedByRequestType()" + e.getMessage());
        } finally {
            this.takeDown();
        }
        System.out.println("Priority->user" + option);
        return option;
    }

    public String ajaxGetNewTestCases(String RequestCode) {
        JSONArray jsonArray = new JSONArray();
        String query = "select testdescription,testprocedure,expectedresult,actualresult,passfail from oam_cr_testcases where requestcode ="
                + RequestCode + " order by testid";
        try {
            if (myConn == null || myConn.isClosed()) {
                setAlias("RequestManager->SuperDomainDataBase");
                this.makeConnection();
            }
            PreparedStatement pStmt = myConn.prepareStatement(query);
            ResultSet rs = pStmt.executeQuery();
            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("TestCase", rs.getString("testdescription"));
                obj.put("TestProcedure", rs.getString("testprocedure"));
                obj.put("ExpectedResult", rs.getString("expectedresult"));
                obj.put("ActualResult", rs.getString("actualresult"));
                obj.put("ReviewStatus", rs.getInt("passfail"));
                jsonArray.add(obj);
            }
        } catch (Exception e) {
            logger.error("[queryBeanPM->getNewTestCases(" + RequestCode + ")]", e);
            e.printStackTrace();
        } finally {
            this.takeDown();
        }
        return jsonArray.toString();
    }
}
