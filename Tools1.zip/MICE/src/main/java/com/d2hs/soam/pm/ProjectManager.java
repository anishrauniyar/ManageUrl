package com.d2hs.soam.pm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.d2hawkeye.util.Constants;
import com.d2hs.soam.RequestBean;

public class ProjectManager extends RequestBean {

	private static Logger logger = Logger.getLogger(ProjectManager.class);
	private static final String PROJECT_ID = "projectId";
	private String strFilters = "";

	/**
	 * @Description : Filter for Projects
	 * @param fProjectId
	 * @param fProjectName
	 * @param fProjectDescription
	 * @param fProjectDetails
	 */
	public void filterProjects(String fProjectId, String fProjectName,
			String fProjectDescription, String fProjectDetails) {
		if (!fProjectId.equals("")) {
			strFilters += " AND projectid LIKE '%"
					+ fProjectId.replaceAll("'", "''").trim() + "%'";
		}
		if (!fProjectName.equals("")) {
			strFilters += " AND lower(ProjectName) LIKE lower('%"
					+ fProjectName.replaceAll("'", "''").trim() + "%')";
		}
		if (!fProjectDescription.equals("")) {
			strFilters += " AND lower(Description) LIKE lower('%"
					+ fProjectDescription.replaceAll("'", "''").trim() + "%')";
		}
		if (!fProjectDetails.equals("")) {
			strFilters += " AND lower(ProjectDetails) LIKE lower('%"
					+ fProjectDetails.replaceAll("'", "''").trim() + "%')";
		}
	}
	
	public void setProjectID(String fProjectId) {
		if (!fProjectId.equals("")) {
			strFilters += " AND projectid LIKE '"
					+ fProjectId.replaceAll("'", "''").trim() + "'";
		}
		
	}

	/**
	 * @Description : Gets all the projects details from table Constants.OAM_CR_PROJECTS
	 */
	public boolean getProjects() {
		boolean result = false;
		strSQL = "select * from " + Constants.OAM_CR_PROJECTS + " where 1=1 ";
		strSQL += strFilters;
		strSQL += " order by " + PROJECT_ID;

		try {
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (SQLException e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->getProjects()<-"
							+ strSQL, e);
		}
		return result;
	}
	
	/**
	 * @Description : Gets all the projects details from table Constants.OAM_CR_PROJECTS
	 */
	public boolean getProjects(String RequestType) {
		boolean result = false;
		strSQL = " select a.projectid,a.projectname FROM  OAM_CR_PROJECTS a, " 
                + " oam_cr_proj_temp_issuetype b,"
                + " oam_cr_proj_temp_rel c "
                + " WHERE a.projectid=c.projectid "
                + " AND c.templateid =b.templateid "
                + " AND b.issuetypeid='"+RequestType+"'	ORDER BY projectid ";


		try {
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (SQLException e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->getProjects()<-"
							+ strSQL, e);
		}
		return result;
	}

	/**
	 * @Description : Adds project to Constants.OAM_CR_PROJECTS table [Duplicate
	 *              projectname not allowed]
	 * @param projectName
	 * @param projectDescription
	 * @param projectDetail
	 * @param userId
	 * @return
	 */
	public String addProject(String projectName, String projectDescription,
			String projectDetail, String userId) {
		
		System.out.println("projectName:"+projectName);
		System.out.println("projectDescription:"+projectDescription);
		System.out.println("projectDetail:"+projectDetail);
		System.out.println("userId:"+userId);
		
		String isInserted = "false";
		strSQL = "Select count(*) n from " + Constants.OAM_CR_PROJECTS
				+ " where upper(projectname) like '" + projectName.toUpperCase()
				+ "' ";
		try {
			Statement stmnt = myConn.createStatement();
			ResultSet rs = stmnt.executeQuery(strSQL);
			rs.next();
			int count = Integer.parseInt(rs.getString("n".trim()));
			if (count > 0) {
				isInserted = "duplicate";
				return isInserted;
			} else if (count == 0) {
				strSQL = "insert into "
						+ Constants.OAM_CR_PROJECTS
						+ " (projectname,description,projectdetails,createdby,createdon,isdeleted)"
						+ " VALUES (" + SQLEncode(projectName) + ","
						+ SQLEncode(projectDescription) + ","
						+ SQLEncode(projectDetail) + "," + "'" + userId + "',"
						+ "sysdate" + "," + "'N'" + " )";
				stmnt.execute(strSQL);
				isInserted = "true";
			}
		} catch (SQLException e) {
			logger.error(
					"\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->addProject("
							+ projectName + "," + projectDescription + ","
							+ projectDetail + ")<- " + strSQL, e);
		}
		return isInserted;
	}

	/**
	 * @Description : Updates project from Constants.OAM_CR_PROJECTS table 
	 * @param projectId
	 * @param projectName
	 * @param projectDescription
	 * @param projectDetail
	 * @return
	 */
	public String updateProject(String projectId, String projectName,
			String projectDescription, String projectDetail){
		String isUpdated = "false";
		try
		{
			Statement stmnt=myConn.createStatement();
             strSQL="update "+Constants.OAM_CR_PROJECTS+" set "+
                        " ProjectName = " + SQLEncode(projectName) + ","+  
                        " Description = " + SQLEncode(projectDescription) + ","+
                        " ProjectDetails = " + SQLEncode(projectDetail) + 
                        " Where ProjectId="+SQLEncode(projectId);
            	stmnt.execute(strSQL);
            	isUpdated="true";
           
	    }
	    catch (SQLException e) 
	    {
	    	logger.error(
					"\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->updateProject("
							+ projectId + "," + projectName + ","
							+ projectDescription + "," + projectDetail + ")<- "
							+ strSQL, e);
	    }
		return isUpdated;
	}
}
