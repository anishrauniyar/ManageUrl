package com.d2hs.soam.common;

import java.util.StringTokenizer;

public class TextEncoder{

	/**
	* Returns an HTML encoded string by replacing single quote, double quote,
	* less than, greater than and ampersand signs to "&" and "#" combinations.
	* @param  p  	the raw un-encoded string
	* @return      	the HTML encoded string
	*/
	public static String encode( String p ){
		if ( p == null || "".equals(p.trim())){
			return "";
		}

		int pLen  		= p.length();
		int count 		= 0;
		char c;
		StringBuffer sb = new StringBuffer( pLen+1 );

		for( count = 0; count < pLen; count++ ){
			c = p.charAt( count );
			switch(c){
				case '\'' :{//Single quote
					sb.append("&#39;");
					break;
				}

				case '\"' :{//Double quote
					sb.append("&#34;");
					break;
				}

				case '<'  :{//Less than
					sb.append("&lt;");
					break;
				}

				case '>'  :{//Greater than
					sb.append("&gt;");
					break;
				}

				case '&'  :{//Ampersand
					sb.append("&amp;");
					break;
				}

				default   : {
					sb.append( c);
				}
			}
		}
		return replaceString(sb.toString(),"\n","<BR>");
	}

	/**
	* Returns a JavaScript encoded string by replacing slash, single quote, double quote,
	* preceeded by an extra slash
	* @param  p  	the raw un-encoded string
	* @return      	the JavaScript encoded string
	*/
	public static String encodeJS( String p){
		if ( p== null || "".equals(p.trim())){
			return "";
		}

		int pLen  		= p.length();
		int count 		= 0;
		char c;
		StringBuffer sb = new StringBuffer( pLen+1);

		for(count=0; count < pLen; count++){
			c = p.charAt( count);
			switch(c){

				case '\'' :{//Quote
					sb.append("\\\'");
					break;
				}
                case '\\' :{//slash
					sb.append("\\\\");
					break;
				}
				case '\"' :{//Double Quote
					sb.append("\\\"");
					break;
				}

				default   :{
					sb.append( c);
				}
			}
		}
		return sb.toString();
	}

	/**
	* Returns a string where each capital letters is padded with one space to its left
	* e.g a string "DoctorDrivenSystem" is returned as "Doctor Driven System"
	* @param  p  	the raw string
	* @return      	the processed string
	*/
 	public static String replaceCapBySpaceAndCap( String p)	{
		if ( p== null || "".equals(p.trim())){
			return "";
		}

		int  pLen  		= p.length();
		int  count 		= 0;
		char c;
		int  i;
		StringBuffer sb = new StringBuffer( pLen+1);

		for(count=0; count < pLen; count++){
			c 			= p.charAt( count);
			i 			= (int) c;
			if(i >= 65 && i <= 90){
				sb.append(" ");
			}

			sb.append(c);
		}
		return sb.toString().trim();
    }

	/**
	* Returns a string whose all spaces are removed
	* e.g a string "Doctor Driven System" is returned as "DoctorDrivenSystem"
	* @param  p  	the raw string
	* @return      	the processed string
	*/
	public static String removeAllSpaces(String p){
		if ( p== null || "".equals(p.trim())){
			return "";
		}

        StringTokenizer st = new StringTokenizer(p," ");
		StringBuffer    sb = new StringBuffer();
		while( st.hasMoreTokens()){
        	sb.append(st.nextElement().toString());
        }

	    return sb.toString();
     }

	/**
	* Returns a string with the specified replacement done.
	* This method replaces all string pattern "search" in a string
	* by a replacement string "replace"
	* @param  stringText  	the raw string
	* @param  search  		the string pattern to be searched
	* @param  replace  		the string used for replacement
	* @return      			the string where all occurence of "search" are replaced by "replace"
	*/
    public static String replaceString(String stringText,String search,String replace){
		StringBuffer sb 	= new StringBuffer();
		int a 				= 0;
		int b;
		int searchLength 	= search.length();
		while((b = stringText.indexOf(search,a)) != -1) {
		   sb.append(stringText.substring(a,b));
		   sb.append(replace);
		   a 	= b + searchLength;
		}

		if(a < stringText.length()) {
		   sb.append(stringText.substring(a));
		}
		return sb.toString();
 	}

    public static String SQLEncode(String val){
        val = (val==null)?"":val.trim();
        if(val.equals("")){
            return "NULL";
        }
        else{
            return "'" + val.replaceAll("'","''") + "'";
        }
    }

    public static String SQLEncode(String val, int dataType){
        if(dataType ==1){ //NUMBER
            val = (val==null)?"":val;
            if(val.equals("")){
                return "NULL";
            }
            else{
                return val;
            }
        }
        else {
           return SQLEncode(val);
        }
    }
    
    /**
     * Returns a string with the specified replacement done.
     * @param p
     * @return
     */
        public static String htmlEncode( String p ){
    		if ( p == null || "".equals(p.trim())){
    			return "";
    		}

    		int pLen  		= p.length();
    		int count 		= 0;
    		char c;
    		StringBuffer sb = new StringBuffer( pLen+1 );

    		for( count = 0; count < pLen; count++ ){
    			c = p.charAt( count );
    			switch(c){
    				case '\'' :{//Single quote
    					sb.append("&#39;");
    					break;
    				}

    				case '\"' :{//Double quote
    					sb.append("&#34;");
    					break;
    				}

    				case '<'  :{//Less than
    					sb.append("&lt;");
    					break;
    				}

    				case '>'  :{//Greater than
    					sb.append("&gt;");
    					break;
    				}

    				case '&'  :{//Ampersand
    					sb.append("&amp;");
    					break;
    				}

    				default   : {
    					sb.append( c);
    				}
    			}
    		}
    		return sb.toString();
    	}
} // end of class
