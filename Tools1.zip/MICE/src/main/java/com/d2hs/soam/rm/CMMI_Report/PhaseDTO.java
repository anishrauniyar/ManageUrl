package com.d2hs.soam.rm.CMMI_Report;

public class PhaseDTO {
	
	private String requestPhaseDesc;
	private int internalOpen;
	private int externalOpen;
	private int totalOpen;
	private int internalCompleted;
	
	private int externalCompleted;
	private int totalCompleted;
	private int internalClosed;
	private int externalClosed;
	
	private int totalClosed;
	private int internalTotal;
	private int externalTotal;
	private int totalTotal;   
	private int total;
	

	public void setRequestPhaseDesc(String s)
	{
		this.requestPhaseDesc=s;
	}
	public String getRequestPhaseDesc()
	{
		return this.requestPhaseDesc;
	} 
	
	public void setInternalOpen(int s)
	{
		this.internalOpen=s;
	}
	public int getInternalOpen()   
	{
		return this.internalOpen;
	}
	
	public void setExternalOpen(int s)
	{
		this.externalOpen=s;
	}
	public int getExternalOpen()   
	{
		return this.externalOpen;
	}
	
	public void setTotalOpen(int s)
	{
		this.totalOpen=s;
	}
	public int getTotalOpen()   
	{
		return this.totalOpen;
	}
	
	public void setInternalCompleted(int s)
	{
		this.internalCompleted=s;
	}
	public int getInternalCompleted()   
	{
		return this.internalCompleted;
	}
	
	public void setExternalCompleted(int s)
	{
		this.externalCompleted=s;
	}
	public int getExternalCompleted()   
	{
		return this.externalCompleted;
	}
	
	public void setTotalCompleted(int s)
	{
		this.totalCompleted=s;
	}
	public int getTotalCompleted()   
	{
		return this.totalCompleted;
	}
	
	public void setInternalClosed(int s)
	{
		this.internalClosed=s;
	}
	public int getInternalClosed()   
	{
		return this.internalClosed;
	}
	
	public void setExternalClosed(int s)
	{
		this.externalClosed=s;
	}
	public int getExternalClosed()   
	{
		return this.externalClosed;
	}
	
	public void setTotalClosed(int s)
	{
		this.totalClosed=s;
	}
	public int getTotalClosed()   
	{
		return this.totalClosed;
	}
	
	public void setInternalTotal(int s)
	{
		this.internalTotal=s;
	}
	public int getInternalTotal()   
	{
		return this.internalTotal;
	}
	
	public void setExternalTotal(int s)
	{
		this.externalTotal=s;
	}
	public int getExternalTotal()   
	{
		return this.externalTotal;
	}
	
	public void setTotalTotal(int s)
	{
		this.totalTotal=s;
	}
	public int getTotalTotal()   
	{
		return this.totalTotal;
	}
	
	public void setTotal(int s)
	{
		this.total=s;
	}
	public int getTotal()   
	{
		return this.total;
	}

}
