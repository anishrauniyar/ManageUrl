package com.d2hs.soam.pm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.d2hs.soam.RequestBean;

public class PhaseManager extends RequestBean {
	
	private String strFilters	= "";

	public void filterPhases(String fPhaseId,String fPhaseName,String fPhaseDescription,String fPhaseStatus,String fPhaseTarget)
    {
	    if(!fPhaseId.equals(""))
	    {
			strFilters	+= " AND phaseid LIKE '%" + fPhaseId.replaceAll("'","''").trim() + "%'";
		}
	    if(!fPhaseName.equals(""))
	    {
	        strFilters	+= " AND lower(PhaseName) LIKE lower('%" + fPhaseName.replaceAll("'","''").trim() + "%')";
	    }
	    if(!fPhaseDescription.equals(""))
	    {
	        strFilters	+= " AND lower(Description) LIKE lower('%" + fPhaseDescription.replaceAll("'","''").trim() + "%')";
	    }
	    if(!fPhaseStatus.equals(""))
	    {
	        strFilters	+= " AND lower(STATUSDESC) LIKE lower('%" + fPhaseStatus.replaceAll("'","''").trim() + "%')";
	    }
	    if(!fPhaseTarget.equals(""))
	    {
	    	strFilters	+= " AND lower(fPhaseTarget) LIKE lower('%" + fPhaseTarget.replaceAll("'","''").trim() + "%')";
	    }
    }
	
	public void setPhaseID(String fPhaseId)
    {
	    if(!fPhaseId.equals(""))
	    {
			strFilters	+= " AND phaseid LIKE '" + fPhaseId.replaceAll("'","''").trim() + "'";
		}
	    
    }
	
	
	
	public boolean getPhases() {
		boolean result = false;
		strSQL = "select a.*,b.statusdesc from oam_cr_phases a,oam_rm_requeststatus b where 1=1 AND a.statusid=b.statusid and isdeleted='N' ";
		strSQL += strFilters;
		strSQL += " order by phaseid";
		System.out.println("Query >>>>>>>>>>>>>>>"+strSQL);
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->getPhases()<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean getPhases(String issueType) {
		boolean result = false;
		String strSQL = ""
			+ "SELECT a.phaseid,a.phasename FROM oam_cr_phases a "
			+ "left join oam_cr_template_phases b "
			+ "ON b.phaseid=a.phaseid "
			+ "left join oam_cr_template_issuetype c "
			+ "ON c.templateid = b.templateid ";
			//+ "WHERE c.issuetypeid = 1 ORDER BY b.phaseorder";
	if(issueType.length()>0){
		strSQL +=" WHERE c.issuetypeid = "+issueType+" ORDER BY b.phaseorder";
	}
		System.out.println("Query >>>>>>>>>>>>>>>"+strSQL);
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->getPhases()<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	
	public boolean getStatus(){
		boolean result =false;
		strSQL = "select * from oam_rm_requeststatus where 1=1 and statusid <> '5' order by statusid";
		try 
		{
			stmt = myConn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			myRS = stmt.executeQuery(strSQL);
			result = true;
		} catch (Exception e) {
			System.out.println("\nError:[default-war/com/d2hs/soam/tmp/PhaseManager.java]->getStatus()<- "+ strSQL);
			e.printStackTrace();
		}
		return result;
	}
	
	
	
	public String addPhase(String phaseName,String phaseDescription,String phaseDetail,String phaseStatus,String phaseTarget,String userId){
		String isInserted = "false";
		strSQL = "Select count(*) n from oam_cr_phases where upper(phasename) like '" +phaseName.toUpperCase()+ "' ";
        //System.out.println(strSQL);
        try
        {
          Statement stmnt=myConn.createStatement();
          ResultSet rs = stmnt.executeQuery(strSQL);
          rs.next();
          int count = Integer.parseInt(rs.getString("n".trim()));
          System.out.println ("Count is>>>>"+count);
          if (count > 0)
          {
              isInserted = "duplicate";
              return isInserted;
          }
          else if (count == 0)
          {
              strSQL="insert into oam_cr_phases "+
                      " (phasename,description,phasedetails,statusid,phasetarget,createdby,createdon,isdeleted)"+
                      " VALUES (" + SQLEncode(phaseName) + "," +
                               SQLEncode(phaseDescription) + "," +                              
                               SQLEncode(phaseDetail) + "," +
                               SQLEncode(phaseStatus) + "," +
                               SQLEncode(phaseTarget) + "," + "'"+
                               userId+"',"+
                               "sysdate"+","+
                               "'N'"+
                               " )" ;
              stmnt.execute(strSQL);
              isInserted="true";
          }
      }
      catch (Exception e) 
      {
    	  System.out.println("\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->addPhase("+phaseName+","+phaseDescription+","+phaseDetail+")<- "+ strSQL);
		  e.printStackTrace();
      }
	  return isInserted;
	}
	
	public String updatePhase(String phaseId,String phaseName,String phaseDescription,String phaseDetail,String phaseStatus, String phaseTarget){
		String isUpdated = "false";
		//strSQL = "Select count(*) n from oam_cr_phases where upper(phasename) like '" +phaseName.toUpperCase()+ "' ";
		
		try
		{
			Statement stmnt=myConn.createStatement();
             strSQL="update oam_cr_phases set "+
                        " PhaseName = " + SQLEncode(phaseName) + ","+  
                        " Description = " + SQLEncode(phaseDescription) + ","+
                        " PhaseTarget = " + SQLEncode(phaseTarget) + ","+
                        " PhaseDetails = " +SQLEncode(phaseDetail)+","+
                        " statusid = " +SQLEncode(phaseStatus)+
                        " Where PhaseId="+SQLEncode(phaseId);
            	stmnt.execute(strSQL);
            	isUpdated="true";
           
	    }
	    catch (SQLException e) 
	    {
	      System.out.println("\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->updatePhase("+phaseId+","+phaseName+","+phaseDescription+","+phaseDetail+")<- "+ strSQL);
		  e.printStackTrace();
	    }
		return isUpdated;
	}
	
	public String deletePhase(String phaseId,String deletedBy){
		String isUpdated = "false";
		
		try
		{
			Statement stmnt=myConn.createStatement();
             strSQL="update oam_cr_phases set "+
                    " CREATEDBY = "+SQLEncode(deletedBy)+ ","+  
                      " ISDELETED = 'Y' "+
                        " Where PhaseId="+SQLEncode(phaseId);
            	stmnt.execute(strSQL);
            	isUpdated="true";
           
	    }
	    catch (SQLException e) 
	    {
	      System.out.println("\nError:[default-war/com/d2hs/soam/pm/PhaseManager.java]->deletePhase("+phaseId+")<- "+ strSQL);
		  e.printStackTrace();
	    }
		return isUpdated;
	}
}
