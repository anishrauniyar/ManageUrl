package com.d2hawkeye.common.connectionpool.dbcp;

import java.util.*;
import org.apache.commons.dbcp.*;

public class ConnectionPoolMonitor {
  private HashMap dataSources = null;
  private BasicDataSource currentSource=null;
  private String currentAlias = null;

//  private ConnectionPoolMonitor monitor = null;

  public ConnectionPoolMonitor() {
    // to do
//    this.dataSources = ConnectionPoolManagerFactory.getConnectionPoolManager().getConnectionPoolMonitor().dataSources;
  }
  public ConnectionPoolMonitor(HashMap dataSources){
    this.dataSources = dataSources;
  }

  public Iterator getAliasNames(){
    return this.dataSources.keySet().iterator();
  }
/* for Max Active */
  public int getMaxActive(String alias){
    return this.getMaxActive(this.getBasicDataSource(alias));
  }
  private int getMaxActive(BasicDataSource bds){
    if(bds == null){
      return -1;
    }
    return bds.getMaxActive();
  }
  /* for Max Idle */
  public int getMaxIdle(String alias){
    return this.getMaxIdle(this.getBasicDataSource(alias));
  }
  private int getMaxIdle(BasicDataSource bds){
    if(bds == null){
      return -1;
    }
    return bds.getMaxIdle();
  }
  /* for Max Wait */
  public long getMaxWait(String alias){
    return this.getMaxWait(this.getBasicDataSource(alias));
  }
  private long getMaxWait(BasicDataSource bds){
    if(bds == null){
      return -1;
    }
    return bds.getMaxWait();
  }
  /* for Min Idle */
  public int getMinIdle(String alias){
    return this.getMinIdle(this.getBasicDataSource(alias));
  }
  private int getMinIdle(BasicDataSource bds){
    if(bds == null){
      return -1;
    }
    return bds.getMinIdle();
  }
  /* for Num Active */
  public int getNumActive(String alias){
    return this.getNumActive(this.getBasicDataSource(alias));
  }
  private int getNumActive(BasicDataSource bds){
    if(bds == null){
      return -1;
    }
    return bds.getNumActive();
  }
  /* for Num Idle */
  public int getNumIdle(String alias){
    return this.getNumIdle(this.getBasicDataSource(alias));
  }
  private int getNumIdle(BasicDataSource bds){
    if(bds == null){
      return -1;
    }
    return bds.getNumIdle();
  }

  private BasicDataSource getBasicDataSource(String alias){
    alias = alias.trim().toUpperCase();
    if(alias.equalsIgnoreCase(this.currentAlias)){
      return this.currentSource;
    }
    if(!this.dataSources.containsKey(alias)){
      System.out.println("Error: No such alias exist - "+alias);
      return null;
    }
    this.currentSource = (BasicDataSource)this.dataSources.get(alias);
    this.currentAlias = alias;
    return this.currentSource;
  }
  /*
  public static void main(String[] args) {
    ConnectionPoolMonitor connectionPoolMonitor1 = new ConnectionPoolMonitor();
  }*/

}
