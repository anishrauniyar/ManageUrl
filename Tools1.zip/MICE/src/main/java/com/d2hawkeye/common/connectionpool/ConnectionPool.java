/**
 * File: ConnectionPool.java
 * @author Raj K Gaire
 * @version 3.2
 * @since April 19, 2004
 * Description:
 *  A servlet for connection pool with dbcp
 *  Modified:
 *  Sn:			Date:					By:				Comments:
 *
 * */
package com.d2hawkeye.common.connectionpool;

import javax.servlet.*;
import javax.servlet.http.*;


/**
 * <p>Title: Connection Pool servlet</p>
 * <p>Description: The servlet load the xml file, creates the aliases and assigns to ConnectionPoolManager.</p>
 * @author Raj K Gaire
 * @version 1.0
 */

public class ConnectionPool
    extends HttpServlet {

  public ConnectionPool() {
  }

  public void init(ServletConfig conf) {
	System.out.println("\\n\n\n\n\n=============================================\n\n\n\n");
	System.out.println("Loading Connecction Pool");
	System.out.println("\\n\n\n\n\n=============================================\n\n\n\n");
    String xmlFileName = conf.getInitParameter("XMLFileName");
    xmlFileName = conf.getServletContext().getRealPath(xmlFileName);
    ConnectionPoolXMLParser parser = new ConnectionPoolXMLParser();
    parser.loadDocument(xmlFileName);

    ConnectionPoolManagerFactory factory = ConnectionPoolManagerFactory.getInstance();
    factory.setConnectionPoolType(ConnectionPoolManagerFactory.CONNECTION_DBCP);
    factory.loadConnectionPoolManager(parser.getAllAlias());
    System.out.println("XML Connection Pool Managere Loaded");
    System.out.println("XML File=" + xmlFileName);
  }
}