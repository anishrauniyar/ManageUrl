package com.d2hawkeye.common.connectionpool;

import java.util.*;

import com.d2hawkeye.common.connectionpool.dbcp.DBCPConnectionPoolManager;

public class ConnectionPoolManagerFactory {
  private static HashMap connectionPools = new HashMap();
  private static ConnectionPoolManager defaultCPM = null;
  private static ConnectionPoolManagerFactory factory;
  private int connectionType=-1;

  public static final int CONNECTION_DBCP = 1;
  public static final int CONNECTION_DEFAULT = 1;

  private ConnectionPoolManagerFactory() {
  }
  public static ConnectionPoolManagerFactory getInstance(){
    if(factory==null)
      factory = new ConnectionPoolManagerFactory();
    return factory;
  }
  public void setConnectionPoolType(int type){
    this.connectionType = type;
  }
  /**
   * Loads Default ConnectionPoolManager from hashmpa of alias.
   * This method is called by ConnectionPool Servlet.
   * 
   * @param alias a Hashmap that contains aliase name as key and connection properties paramter. 
   * @author Shankar R. Uprety
   */
  public void loadConnectionPoolManager(HashMap alias){
	  DBCPConnectionPoolManager dcpm = new DBCPConnectionPoolManager();
      dcpm.setAlias(alias);
      defaultCPM = dcpm;
      System.out.println("Loading Connection Pool Alias");
      Iterator itr=alias.keySet().iterator();
      while(itr.hasNext()){
    	  String name=(String)itr.next();
    	  System.out.println("Loaded Alias::"+name);
      }
  }

  public ConnectionPoolManager getConnectionPoolManager(HashMap alias){
    ConnectionPoolManager cpm = (ConnectionPoolManager)connectionPools.get(alias);
    if(cpm!=null){
      return cpm;
    }
    switch(this.connectionType){
      case CONNECTION_DBCP:
        DBCPConnectionPoolManager dcpm = new DBCPConnectionPoolManager();
        dcpm.setAlias(alias);
        cpm = dcpm;
        break;
      default:
        dcpm = new DBCPConnectionPoolManager();
        dcpm.setAlias(alias);
        cpm = dcpm;
        break;
    }
    connectionPools.put(alias, cpm);
    return cpm;
  }
  public ConnectionPoolManager getConnectionPoolManager(){
    if(this.defaultCPM==null){
      defaultCPM = this.getConnectionPoolManager(new HashMap());
    }
    return defaultCPM;
  }
}
