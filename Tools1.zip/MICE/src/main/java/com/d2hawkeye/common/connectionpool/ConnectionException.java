package com.d2hawkeye.common.connectionpool;

public class ConnectionException extends java.sql.SQLException {
  public ConnectionException() {
  }
  public ConnectionException(String s) {
    super(s);
  }
  public ConnectionException(Exception t) {
    super(t.getMessage());
  }
  /*
  public static void main(String[] args) {
    ConnectionException connectionException1 = new ConnectionException();
  }
*/
}
