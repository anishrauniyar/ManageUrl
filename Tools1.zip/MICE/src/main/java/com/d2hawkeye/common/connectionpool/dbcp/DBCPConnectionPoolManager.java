package com.d2hawkeye.common.connectionpool.dbcp;

import java.util.*;
import java.sql.*;
import javax.sql.DataSource;
import com.d2hawkeye.common.connectionpool.ConnectionException;
import com.d2hawkeye.common.connectionpool.ConnectionParameters;
import org.apache.commons.dbcp.BasicDataSource;

public class DBCPConnectionPoolManager implements com.d2hawkeye.common.connectionpool.ConnectionPoolManager {
    /**
     * stores its own instance, created when the class is loaded by class loader.
     * */
    /**
     * stores the connection parameters.
     * */
    private HashMap connectionProperties = null;
    /***
     * store the created data sources
     */
    private HashMap dataSources = new HashMap();

    public DBCPConnectionPoolManager() {}

    /**
         * @param alias hashmap containing the aliasname and connection parameters pairs
     */
    public void setAlias(HashMap alias) {
      this.connectionProperties = alias;
    }

    /**
     *
     * @return true if alias is not null
     */
    public boolean isAliasSet() {
      return (this.connectionProperties != null);
    }

    /**
     *
     * @param aliasName it should be present in connectionProperties hashmap
     * @return datasource if it is not aleady created, creates and returns it
     */
    public Connection getConnection(String aliasName) throws  ConnectionException {
      System.out.println("getting connetion");
      String strAlias = aliasName.toUpperCase();
      String errorString = "";
      Connection con = null;
      /* checking if datasource is already created */
      if (this.dataSources.containsKey(strAlias)) {
        DataSource ds = (DataSource)this.dataSources.get(strAlias);
        try{
          con = ds.getConnection();
          while(con.isClosed()){
            con = ds.getConnection();
          }
          return con;
        }catch (SQLException e){
System.out.println("\nError:[default-war/com/d2hawkeye/common/connectionpool/dbcp/DBCPConnectionPoolManager.java]->0<-"+e);
          throw new ConnectionException(e);
        }
      }
      /* checking if connection properties hashmap is set or not */
      if (this.connectionProperties == null) {
        errorString =
            "Connection properties not set. It must be present to create the connection.";
        System.out.println(errorString);
        throw new ConnectionException("ERROR: " + errorString);
      }
          /* checking if connection properties hashmap has the alias name as key or not */
      if (!this.connectionProperties.containsKey(strAlias)) {
        errorString = "no such alias key: " + strAlias;
        System.out.println(errorString);
        throw new ConnectionException("ERROR: " + errorString);
      }
      /* datasource is not created, so creating it */
      ConnectionParameters cps = (ConnectionParameters)this.connectionProperties.
          get(strAlias);
      return this.getNewConnection(strAlias, cps);
    }

    public Connection getConnection(ConnectionParameters cps) throws ConnectionException{
      System.out.println("getting connetion for "+cps.getUrl());
      String strAlias = cps.getUrl().toUpperCase();
      try{
        return this.getConnection(strAlias);
      }catch (ConnectionException ce){
System.out.println("\nError:[default-war/com/d2hawkeye/common/connectionpool/dbcp/DBCPConnectionPoolManager.java]->1<-"+ce);}
      return this.getNewConnection(strAlias, cps);
    }

    private Connection getNewConnection(String strAlias, ConnectionParameters cps) throws ConnectionException{
      System.out.println("getting new connetion");
      DataSource bds = this.getNewConnection(cps);
      Connection con;
      try{
        con = bds.getConnection();
      }catch (SQLException e){
System.out.println("\nError:[default-war/com/d2hawkeye/common/connectionpool/dbcp/DBCPConnectionPoolManager.java]->2<-"+e);
        e.printStackTrace();
        throw new ConnectionException(e);
      }
      this.connectionProperties.put(strAlias, cps);
      this.dataSources.put(strAlias, bds);
      return con;
    }

    private DataSource getNewConnection(ConnectionParameters cps) throws ConnectionException{
      System.out.println("creating new datasource");
      BasicDataSource bds = new BasicDataSource();
      bds.setDriverClassName(cps.getDriver());
      bds.setUrl(cps.getUrl());
      bds.setUsername(cps.getUserName());
      bds.setPassword(cps.getPassword());
      bds.setTimeBetweenEvictionRunsMillis(cps.getTimeBetweenEvictionRunsMillis());
      bds.setMinEvictableIdleTimeMillis(cps.getMinEvictableIdleTimeMillis());
      
      if (cps.getIdleTimeOut() > -1) {
        bds.setMaxIdle(cps.getIdleTimeOut());
      }
      if (cps.getMaxCheckOutTime() > -1) {
        bds.setMaxWait(cps.getMaxCheckOutTime());
      }
      bds.setMaxActive(0);
      return bds;
    }
  }

