package com.d2hawkeye.common.connectionpool;

import java.sql.*;
public interface ConnectionPoolManager {
  Connection getConnection(String alias) throws ConnectionException;
  Connection getConnection(ConnectionParameters param)  throws ConnectionException;
}