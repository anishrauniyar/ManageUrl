/*
 * Date : 2015-04-13
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

import com.d2hawkeye.util.MapObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author i81324
 */
public class MailMessageGenerator {

    private static final Logger logger = LoggerFactory.getLogger(MailMessageGenerator.class);

    private final StringBuilder logBuilder = new StringBuilder();
    private boolean isSkipLog = false;

    public MailMessageModel mailMessageGenerator(String label, String value, String old) {
        logger.info("LABEL=" + label + ",NEW_VALUE=" + value + ",OLD_VALUE=" + old);
        if (old != null) {
            if (isNotNullEmpty(old).equalsIgnoreCase(isNotNullEmpty(value))) {
                return new MailMessageModel(label, checkEmptyAndNull(value), null, null);
            } else {
                appendLog(label, value, old);
                return new MailMessageModel(label, checkEmptyAndNull(value), "currentEdit", null);
            }
        }
        return new MailMessageModel(label, checkEmptyAndNull(value), null, null);
    }

    public String isNotNullEmpty(String s) {
        return s != null ? s.trim() : "";
    }

    public MailMessageModel mailMessageGeneratorFollowUp(String label, String value, String old) {
        logger.info("LABEL=" + label + ",NEW_VALUE=" + value + ",OLD_VALUE=" + old);
        if (old != null) {
            return isNotNullEmpty(old).equalsIgnoreCase(isNotNullEmpty(value)) ? new MailMessageModel(label, checkEmptyAndNull(value), "followRedText", null) : new MailMessageModel(label, checkEmptyAndNull(value), "currentEdit followRedText", null);
        }
        return new MailMessageModel(label, checkEmptyAndNull(value), "followRedText", null);
    }

    public MailMessageModel mailMessageGeneratorForTwoValues(String label, String value1, String value2, String old1, String old2) {
        logger.info("LABEL=" + label + ",NEW_VALUE_1=" + value1 + ",OLD_VALUE_1=" + old1);
        logger.info("LABEL=" + label + ",NEW_VALUE_2=" + value2 + ",OLD_VALUE_2=" + old2);
        if (old1 != null && old2 != null) {
            //System.out.println("111111");
            if (isNotNullEmpty(old1).equalsIgnoreCase(isNotNullEmpty(value1))
                    && isNotNullEmpty(old2).equalsIgnoreCase(isNotNullEmpty(value2))) {
                //System.out.println("222222222");
                if(value1.isEmpty() && value2.isEmpty()){
                    //System.out.println("3333333333");
                    return new MailMessageModel(label, checkEmptyAndNull("N/A"), null, null);
                }
                //System.out.println("4444444");
                return new MailMessageModel(label, checkEmptyAndNull(value1 + " " + value2), null, null);
            } else{
                //System.out.println("5555555");
                return new MailMessageModel(label, checkEmptyAndNull(value1 + " " + value2), "currentEdit", null);
            }
        }
        //System.out.println("6666666666");
        return new MailMessageModel(label, checkEmptyAndNull(value1 + " " + value2), null, null);
    }

    public String checkEmptyAndNull(String input) {
        if (input == null || input.isEmpty() || input.equalsIgnoreCase("-1")) {
            return "N/A";
        } else {
            return input;
        }
    }

    public MailMessageModel mailMessageGeneratorWithCheck(String label, String value, String old) {
        logger.info("LABEL=" + label + ",NEW_VALUE=" + value + ",OLD_VALUE=" + old);
        if (old != null) {
            if (isNotNullEmpty(old).equalsIgnoreCase(isNotNullEmpty(value))) {
                return new MailMessageModel(label, checkEmptyAndNull(value), null, null);
            } else {
                appendLog(label, checkEmptyAndNull(value), checkEmptyAndNull(old));
                return new MailMessageModel(label, checkEmptyAndNull(value), "currentEdit", null);
            }

        }
        return new MailMessageModel(label, checkEmptyAndNull(value), null, null);
    }

    public StringBuilder getLogBuilder() {
        return logBuilder;
    }

    public void setIsSkipLog(boolean isSkipLog) {
        this.isSkipLog = isSkipLog;
    }

    public boolean isIsSkipLog() {
        return isSkipLog;
    }

    private void appendLog(String label, String currentValue, String oldValue) {
        if (!isSkipLog) {
            logBuilder.append(label).append("(")
                    .append(MapObjectUtils.getN_AIfEmptyString(oldValue))
                    .append("=>")
                    .append(MapObjectUtils.getN_AIfEmptyString(currentValue))
                    .append("), ");
        }
    }

}
