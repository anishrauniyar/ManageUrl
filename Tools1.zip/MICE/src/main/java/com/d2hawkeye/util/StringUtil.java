package com.d2hawkeye.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class StringUtil {
	private static String[] months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	private StringUtil() {
  }
  public static String replaceChar(String s, char c, char b){
    if(s==null)
      return null;
    String ss="";
    for(int i=0; i<s.length(); i++){
      char ch = s.charAt(i);
      ss += (ch==c)?b:ch;
    }
    return ss;
  }
  /**
   * Date: May 29, 2007
   * Convert Clob to String
   * @author akhanal
   * @param cl clob value
   * @return string equivalent of the clob value
   * @throws java.io.IOException
   * @throws java.sql.SQLException
   */
  public static String ClobToString(java.sql.Clob cl) throws java.io.IOException, java.sql.SQLException 
  {
    if (cl == null) 
      return  "";
    StringBuffer strOut = new StringBuffer();
    String aux;
	java.io.BufferedReader br = new java.io.BufferedReader(cl.getCharacterStream());

    while ((aux=br.readLine())!=null)
           strOut.append(aux);
    return strOut.toString();
  }
  /**
   * this method will return the java.util.date to
   * compatible string format
   * @param dateString
   * @return
   * @author rbaral
   */
  public static String getCompatibleDate(Date dateString){
	//Wed Jan 27 11:19:50 GMT+05:45 2010
	  String newDateString="";
	  String dateArray[]=dateString.toString().split(" ");
	  if(dateArray.length>5){
		  newDateString=dateArray[2]+"-"+dateArray[1]+"-"+dateArray[dateArray.length-1];
	  }
	  else if(dateString.toString().split("-").length>2){
		  //2010-01-28
		  dateArray=dateString.toString().split("-");
		  newDateString=dateArray[dateArray.length-1]+"-"+months[Integer.parseInt(dateArray[1])-1]+"-"+dateArray[0];
	  }
	  //System.out.println("dateParam:"+dateString);
	  //System.out.println("dateString:"+newDateString);
	  return newDateString;
  }
  /**
   * <li>this method will return the simpledate format date from the given string,if appropriate</li>
   * <li>ex:string 2010-02-10 to a java.util.Date object</li>
   * 
   * @param dateString
   * @return
   * @author rbaral
 * @throws ParseException 
   */
  public static Date getCompatibleDateElement(String dateString) throws ParseException{
	  DateFormat dateFormat=new SimpleDateFormat("dd-MMM-yyyy");
	  Date dateObject=null;
	  System.out.println("compatibledatelementparam:"+dateString);
	  if(dateString.split("-").length>2){
		  dateObject=dateFormat.parse(dateString);
	  }
	  System.out.println("compatibledateelement from:"+dateString);
	  return dateObject;
  }
  /**
   * <li>get the revenue month for this month</li>
   * <li>this will be the list of string returning two preceeding and two succeeding month relative to this month</li>
   * StringUtil
   * @return
   * List
   * @author rbaral
   * @throws ParseException 
   * @since Feb 9 2010
   * 
   */
  public static List getRevenueMonth() throws ParseException{
	  List revenueList=new ArrayList();
	  Calendar cal=Calendar.getInstance();
	  cal.setTime(new Date());
	  cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)-2);
	  revenueList.add(0,months[cal.get(Calendar.MONTH)]+"-"+cal.get(Calendar.YEAR));
	  cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
	  revenueList.add(1,months[cal.get(Calendar.MONTH)]+"-"+cal.get(Calendar.YEAR));
	  cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
	  revenueList.add(2,months[cal.get(Calendar.MONTH)]+"-"+cal.get(Calendar.YEAR));
	  cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
	  revenueList.add(3,months[cal.get(Calendar.MONTH)]+"-"+cal.get(Calendar.YEAR));
	  cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)+1);
	  revenueList.add(4,months[cal.get(Calendar.MONTH)]+"-"+cal.get(Calendar.YEAR));
	  return revenueList;
  }
  
  public static String getTimeStamp(){
  DateFormat formatter=new SimpleDateFormat("MM:dd:HH:mm:ss:ms");
	String dateString=formatter.format((new Date()));
	return dateString;
  }
}