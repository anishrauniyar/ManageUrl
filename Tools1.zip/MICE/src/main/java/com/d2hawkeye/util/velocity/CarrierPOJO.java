/*
 * Date : 2015-04-15
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class CarrierPOJO {

    private String missingData;
    private String missingDataMonth;
    private String fileNameConv;
    private String issueDetails;
    private String additionalValues;
    private String responseFromVendor;
    private String additionalComments;

    public String getMissingData() {
        return missingData;
    }

    public void setMissingData(String missingData) {
        this.missingData = missingData;
    }

    public String getMissingDataMonth() {
        return missingDataMonth;
    }

    public void setMissingDataMonth(String missingDataMonth) {
        this.missingDataMonth = missingDataMonth;
    }

    public String getFileNameConv() {
        return fileNameConv;
    }

    public void setFileNameConv(String fileNameConv) {
        this.fileNameConv = fileNameConv;
    }

    public String getIssueDetails() {
        return issueDetails;
    }

    public void setIssueDetails(String issueDetails) {
        this.issueDetails = issueDetails;
    }

    public String getAdditionalValues() {
        return additionalValues;
    }

    public void setAdditionalValues(String additionalValues) {
        this.additionalValues = additionalValues;
    }

    public String getResponseFromVendor() {
        return responseFromVendor;
    }

    public void setResponseFromVendor(String responseFromVendor) {
        this.responseFromVendor = responseFromVendor;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }
    
}
