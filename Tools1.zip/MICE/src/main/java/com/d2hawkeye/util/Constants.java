package com.d2hawkeye.util;

public interface Constants {

	/*
	 * PROJECT MANAGER TABLES
	 */
	String OAM_CR_PROJECTS = "oam_cr_projects";
	String OAM_CR_PROJ_TEMP = "oam_cr_proj_temp"; // templates information ONLY for Projects
	String OAM_CR_PROJ_TEMP_ISSUETYPE = "oam_cr_proj_temp_issuetype"; // template and issue type info for Projects
	String OAM_CR_PROJ_TEMP_REL	= "oam_cr_proj_temp_rel"; // template and projects info

	/*
	 * ISSUE TYPE TABLE
	 */
	String OAM_CR_ISSUETYPE = "oam_cr_issuetype";

}
