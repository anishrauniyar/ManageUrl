package com.d2hawkeye.util;

import java.util.*;
import java.io.*;
public class QueryTokenizer {
  public static final String TOKEN_SEPARATOR = "GO";
  public static Vector tokenize(String s) {
    Vector v = new Vector();
    BufferedReader bis = new BufferedReader(new StringReader(s));// new java.io.StringBufferInputStream(s);
    try{
      boolean av = true;
      String scriptLet = "";
      do{
        String aLine = bis.readLine();
        if(aLine == null){
          av = false;
        }else{
          if(TOKEN_SEPARATOR.equalsIgnoreCase(aLine.trim())){
             if(!scriptLet.trim().equalsIgnoreCase("")){
               v.add(scriptLet);
               scriptLet = "";
             }
          }else{
            scriptLet += aLine + "\n";
          }
        }
      }while(av);
    }catch (Exception e){
System.out.println("\nError:[default-war/com/d2hawkeye/util/QueryTokenizer.java]->0<-"+e);
      System.out.println(e);
    }
    return v;
  }
}