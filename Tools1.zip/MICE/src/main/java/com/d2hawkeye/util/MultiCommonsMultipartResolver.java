package com.d2hawkeye.util;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
/**
 * inspired from
 * http://dhruba.name/2008/12/27/implementing-single-and-multiple-file-multipart-uploads-using-spring-25/
 * modified by:
 * @author Ramesh Raj Baral
 * @since Jan 11 2010
 */
import javax.servlet.ServletContext;

import org.apache.commons.fileupload.FileItem;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
public class MultiCommonsMultipartResolver extends CommonsMultipartResolver {

	 public MultiCommonsMultipartResolver() {
	    }

	    public MultiCommonsMultipartResolver(ServletContext servletContext) {
	        super(servletContext);
	    }

	    @Override
	    @SuppressWarnings("unchecked")
	    protected MultipartParsingResult parseFileItems(List fileItems, String encoding) {
	        Map multipartFiles = new HashMap();
	        Map multipartParameters = new HashMap();

	        // Extract multipart files and multipart parameters.
	        for (Iterator it = fileItems.iterator(); it.hasNext();) {
	            FileItem fileItem = (FileItem) it.next();
	            if (fileItem.isFormField()) {
	                String value = null;
	                if (encoding != null) {
	                    try {
	                        value = fileItem.getString(encoding);
	                    } catch (UnsupportedEncodingException ex) {
	                        if (logger.isWarnEnabled()) {
	                            logger.warn("Could not decode multipart item '" + fileItem.getFieldName()
	                                    + "' with encoding '" + encoding + "': using platform default");
	                        }
	                        value = fileItem.getString();
	                    }
	                } else {
	                    value = fileItem.getString();
	                }
	                String[] curParam = (String[]) multipartParameters.get(fileItem.getFieldName());
	                if (curParam == null) {
	                    // simple form field
	                    multipartParameters.put(fileItem.getFieldName(), new String[] { value });
	                } else {
	                    // array of simple form fields
	                    String[] newParam = StringUtils.addStringToArray(curParam, value);
	                    multipartParameters.put(fileItem.getFieldName(), newParam);
	                }
	            } else {
	                // multipart file field
	                CommonsMultipartFile file = new CommonsMultipartFile(fileItem);
	                logger.info("filename:"+file.getOriginalFilename());
	                /**
	                 * if the filename is blank-donot add it to the map
	                 * @author Ramesh Raj Baral
	                 * @since Jan 11 2010,5:24 pm
	                 * 
	                 */
	                if(StringUtils.hasLength(file.getOriginalFilename())){
	                /**
	                 * modified by Ramesh Raj Baral
	                 * in addition the following lines are commented
	                 */
	                	/**if (multipartFiles.put(file,fileItem.getName()) != null) {
	                    throw new MultipartException("Multiple files for field name [" + file.getName()
	                            + "] found - not supported by MultipartResolver");
	                }*/
	                	/**
	                	 * TODO
	                	 * if the filename is already present then rename it if this is a unique entry(determine by size,String)
	                	 */
	                	Iterator iter=multipartFiles.values().iterator();
	                	while(iter.hasNext()){
	                		CommonsMultipartFile tfile =(CommonsMultipartFile)iter.next();
	                		if(tfile.equals(file)){
	                			System.out.println("duplicate entry");
	                		}
	                		else{
	                			System.out.println("unique entry:"+tfile.getName());
	                		}
	                	}
	                	multipartFiles.put(fileItem.getName(),file);
	                }
	                else{
	                	logger.info("empty or invalid filename submitted:"+file.getOriginalFilename());
	                }
	                if (logger.isDebugEnabled()) {
	                    logger.debug("Found multipart file [" + file.getName() + "] of size " + file.getSize()
	                            + " bytes with original filename [" + file.getOriginalFilename() + "], stored "
	                            + file.getStorageDescription());
	                }
	            }
	        }
	        return new MultipartParsingResult(multipartFiles, multipartParameters);
	    }

	}


