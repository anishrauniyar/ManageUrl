/*
 * Date : 2015-11-24
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class TestCase {

    private int rowIndex;
    private String caseDescription;
    private String expectedResult;
    private String actualResult;
    private String passFail;
    private String styleClass;

    public TestCase(int rowIndex, String caseDescription, String expectedResult, String actualResult, String passFail, String styleClass) {
        this.rowIndex = rowIndex;
        this.caseDescription = caseDescription;
        this.expectedResult = expectedResult;
        this.actualResult = actualResult;
        this.passFail = passFail;
        this.styleClass = styleClass;
    }

    public TestCase() {
    }

    public int getRowIndex() {
        return rowIndex;
    }

    public void setRowIndex(int rowIndex) {
        this.rowIndex = rowIndex;
    }

    public String getCaseDescription() {
        return caseDescription;
    }

    public void setCaseDescription(String caseDescription) {
        this.caseDescription = caseDescription;
    }

    public String getExpectedResult() {
        return expectedResult;
    }

    public void setExpectedResult(String expectedResult) {
        this.expectedResult = expectedResult;
    }

    public String getActualResult() {
        return actualResult;
    }

    public void setActualResult(String actualResult) {
        this.actualResult = actualResult;
    }

    public String getPassFail() {
        return passFail;
    }

    public void setPassFail(String passFail) {
        this.passFail = passFail;
    }

    public String getStyleClass() {
        return styleClass;
    }

    public void setStyleClass(String styleClass) {
        this.styleClass = styleClass;
    }

    
}
