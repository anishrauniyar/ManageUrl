/*
 * Created At : 2015-09-29
 * Author: rkc
 * Email : rkc
 */
package com.d2hawkeye.util;

import java.util.Arrays;

/**
 *
 * @author i81324
 */
public class MapObjectUtils {

    public static String mapStringWithNotNull(String s) {
        return s == null ? "" : s;
    }

    public static String getN_AIfEmptyString(String s) {
        return s == null ? "N/A" : s.trim().isEmpty() ? "N/A" : s;
    }

    public static String[] mapStringArrayWithNotNull(String[] s) {
        return s == null ? new String[]{} : s;
    }

    public static String convertArrayToColonString(String[] array) {
        String s = "";
        if (array != null) {
            for (int i = 0; i < array.length; i++) {
                if (i < array.length - 1) {
                    s += array[i] + ":";
                } else {
                    s += array[i];
                }
            }
        }
        return s;
    }

    public static String getN_AIfEmptyArrayElseString(String[] clientIds) {
        return clientIds == null ? "N/A" : clientIds.length > 0 ? Arrays.toString(clientIds) : "N/A";
    }
}
