/*
 * Date : 2015-04-15
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

import com.d2hs.soam.data.ProductionIntegrationCode;
import com.verisk.ice.model.DefectDTO;
import com.verisk.ice.model.EstimateDTO;
import com.verisk.ice.model.LayoutAnalysisDTO;
import com.verisk.ice.model.RequestParamDTO;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author i81324
 */
public class MailMessagePOJO {

    private int operationType = 0;
    /*
     0- edit
     1- new
     */
    private String requestCode;
    private String requestDate;
    private String reqPersonName;
    private String clientName;
    private String AppID;
    private String requestTitle;
    private String payer;
    private String dataType;
    private String issueType;
    private String phase;
    private String mainEnggName;
    private String requestPriorityDesc;
    private String EstimatedHours;
    private String documentCount;
    private String projectName;
    private String employerGroup;
    private String appReleasesToClientDate;
    private String ba;
    private String wpm;
    private String npm;
    private String cl;
    private String targetDate;
    private String remarks;
    private String applicationType;
    private String prioritizeddate;
    private String prioritizedby;
    private String targetCompDate2;
    private String actualCompDate2;
    private String processmonth;
    private String team;
    private String externalid;

    @Getter
    @Setter
    private String releaseTag;

    @Getter
    @Setter
    private String dateOfCleanAndCompleteDataReceipt;

    @Getter
    @Setter
    private String dateOfLegalsCompleted;

    private ChangeRequestPOJO changeRequestPOJO;
    private PayorMgmtPOJO payorMgmtPOJO;
    private ReprocessingPOJO reprocessingPOJO;
    private CarrierPOJO carrierPOJO;
    private ExtractCAdhocPOJO extractCAdhocPOJO;
    private ProductionIntegrationCode productionIntegrationCodePOJO;
    private LayoutAnalysisDTO layoutAnalysisDTO;
    private EstimateDTO estimateDTO;

    @Setter
    @Getter
    private DefectDTO defectDTO;

    @Getter
    private final RequestParamDTO oldRequestParamDTO = new RequestParamDTO();

    @Getter
    private final RequestParamDTO newRequestParamDTO = new RequestParamDTO();

    public MailMessagePOJO(int operationType) {
        this.operationType = operationType;
        this.changeRequestPOJO = new ChangeRequestPOJO();
        this.payorMgmtPOJO = new PayorMgmtPOJO();
        this.reprocessingPOJO = new ReprocessingPOJO();
        this.carrierPOJO = new CarrierPOJO();
        this.extractCAdhocPOJO = new ExtractCAdhocPOJO();
        this.productionIntegrationCodePOJO = new ProductionIntegrationCode();
        this.layoutAnalysisDTO = new LayoutAnalysisDTO();
        this.estimateDTO = new EstimateDTO();
        this.defectDTO = new DefectDTO();
    }

    public MailMessagePOJO() {
        this.changeRequestPOJO = new ChangeRequestPOJO();
        this.payorMgmtPOJO = new PayorMgmtPOJO();
        this.reprocessingPOJO = new ReprocessingPOJO();
        this.carrierPOJO = new CarrierPOJO();
        this.extractCAdhocPOJO = new ExtractCAdhocPOJO();
        this.layoutAnalysisDTO = new LayoutAnalysisDTO();
        this.estimateDTO = new EstimateDTO();
    }

    public String getRequestCode() {
        return requestCode;
    }

    public void setRequestCode(String requestCode) {
        this.requestCode = requestCode;
    }

    public String getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(String requestDate) {
        this.requestDate = requestDate;
    }

    public String getReqPersonName() {
        return reqPersonName;
    }

    public void setReqPersonName(String reqPersonName) {
        this.reqPersonName = reqPersonName;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getAppID() {
        return AppID;
    }

    public void setAppID(String AppID) {
        this.AppID = AppID;
    }

    public String getRequestTitle() {
        return requestTitle;
    }

    public void setRequestTitle(String requestTitle) {
        this.requestTitle = requestTitle;
    }

    public String getPayer() {
        return payer;
    }

    public void setPayer(String payer) {
        this.payer = payer;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public String getMainEnggName() {
        return mainEnggName;
    }

    public void setMainEnggName(String mainEnggName) {
        this.mainEnggName = mainEnggName;
    }

    public String getRequestPriorityDesc() {
        return requestPriorityDesc;
    }

    public void setRequestPriorityDesc(String requestPriorityDesc) {
        this.requestPriorityDesc = requestPriorityDesc;
    }

    public String getEstimatedHours() {
        return EstimatedHours;
    }

    public void setEstimatedHours(String EstimatedHours) {
        this.EstimatedHours = EstimatedHours;
    }

    public ChangeRequestPOJO getChangeRequestPOJO() {
        return changeRequestPOJO;
    }

    public void setChangeRequestPOJO(ChangeRequestPOJO changeRequestPOJO) {
        this.changeRequestPOJO = changeRequestPOJO;

    }

    public PayorMgmtPOJO getPayorMgmtPOJO() {
        return payorMgmtPOJO;
    }

    public void setPayorMgmtPOJO(PayorMgmtPOJO payorMgmtPOJO) {
        this.payorMgmtPOJO = payorMgmtPOJO;
    }

    public ReprocessingPOJO getReprocessingPOJO() {
        return reprocessingPOJO;
    }

    public void setReprocessingPOJO(ReprocessingPOJO reprocessingPOJO) {
        this.reprocessingPOJO = reprocessingPOJO;
    }

    public CarrierPOJO getCarrierPOJO() {
        return carrierPOJO;
    }

    public void setCarrierPOJO(CarrierPOJO carrierPOJO) {
        this.carrierPOJO = carrierPOJO;
    }

    public ExtractCAdhocPOJO getExtractCAdhocPOJO() {
        return extractCAdhocPOJO;
    }

    public void setExtractCAdhocPOJO(ExtractCAdhocPOJO extractCAdhocPOJO) {
        this.extractCAdhocPOJO = extractCAdhocPOJO;
    }

    public String getDocumentCount() {
        return documentCount;
    }

    public void setDocumentCount(String documentCount) {
        this.documentCount = documentCount;
    }

    public int getOperationType() {
        return operationType;
    }

    public ProductionIntegrationCode getProductionIntegrationCodePOJO() {
        return productionIntegrationCodePOJO;
    }

    public void setProductionIntegrationCodePOJO(ProductionIntegrationCode productionIntegrationCodePOJO) {
        this.productionIntegrationCodePOJO = productionIntegrationCodePOJO;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getAppReleasesToClientDate() {
        return appReleasesToClientDate;
    }

    public void setAppReleasesToClientDate(String appReleasesToClientDate) {
        this.appReleasesToClientDate = appReleasesToClientDate;
    }

    public String getBa() {
        return ba;
    }

    public void setBa(String ba) {
        this.ba = ba;
    }

    public String getWpm() {
        return wpm;
    }

    public void setWpm(String wpm) {
        this.wpm = wpm;
    }

    public String getNpm() {
        return npm;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getCl() {
        return cl;
    }

    public void setCl(String cl) {
        this.cl = cl;
    }

    public String getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(String targetDate) {
        this.targetDate = targetDate;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setEmployerGroup(String employerGroup) {
        this.employerGroup = employerGroup;
    }

    public String getEmployerGroup() {
        return employerGroup;
    }

    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {
        this.applicationType = applicationType;
    }

    public LayoutAnalysisDTO getLayoutAnalysisDTO() {
        return layoutAnalysisDTO;
    }

    public void setLayoutAnalysisDTO(LayoutAnalysisDTO layoutAnalysisDTO) {
        this.layoutAnalysisDTO = layoutAnalysisDTO;
    }

    public void setEstimateDTO(EstimateDTO estimateDTO) {
        this.estimateDTO = estimateDTO;
    }

    public EstimateDTO getEstimateDTO() {
        return estimateDTO;
    }

    public String getPrioritizeddate() {
        return prioritizeddate;
    }

    public void setPrioritizeddate(String prioritizeddate) {
        this.prioritizeddate = prioritizeddate;
    }

    public String getPrioritizedby() {
        return prioritizedby;
    }

    public void setPrioritizedby(String prioritizedby) {
        this.prioritizedby = prioritizedby;
    }

    public String getTargetCompDate2() {
        return targetCompDate2;
    }

    public void setTargetCompDate2(String targetCompDate2) {
        this.targetCompDate2 = targetCompDate2;
    }

    public String getActualCompDate2() {
        return actualCompDate2;
    }

    public void setActualCompDate2(String actualCompDate2) {
        this.actualCompDate2 = actualCompDate2;
    }

    public String getProcessmonth() {
        return processmonth;
    }

    public void setProcessmonth(String processmonth) {
        this.processmonth = processmonth;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    public String getExternalid() {
        return externalid;
    }

    public void setExternalid(String externalid) {
        this.externalid = externalid;
    }

}
