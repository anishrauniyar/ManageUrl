/*
 * Date : 2015-04-15
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class ChangeRequestPOJO {

    private String processmonth;
    private String datalayout;
    private String billclient;
    private String amname;
    private String reason;
    private String jiraid;
    private String problemdef;
    private String changespecify;
    private String clientpaid;
    private String clientrequestdate;
    private String clienttargetdate;
    private String actualtargetdate;
    private String Impact;
    private String implementedbyimplservices;
    private String implementationiceid;

    public String getProcessmonth() {
        return processmonth;
    }

    public void setProcessmonth(String processmonth) {
        this.processmonth = processmonth;
    }

    public String getDatalayout() {
        return datalayout;
    }

    public void setDatalayout(String datalayout) {
        this.datalayout = datalayout;
    }

    public String getBillclient() {
        return billclient;
    }

    public void setBillclient(String billclient) {
        this.billclient = billclient;
    }

    public String getAmname() {
        return amname;
    }

    public void setAmname(String amname) {
        this.amname = amname;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getJiraid() {
        return jiraid;
    }

    public void setJiraid(String jiraid) {
        this.jiraid = jiraid;
    }

    public String getProblemdef() {
        return problemdef;
    }

    public void setProblemdef(String problemdef) {
        this.problemdef = problemdef;
    }

    public String getChangespecify() {
        return changespecify;
    }

    public void setChangespecify(String changespecify) {
        this.changespecify = changespecify;
    }

    public String getClientpaid() {
        return clientpaid;
    }

    public void setClientpaid(String clientpaid) {
        this.clientpaid = clientpaid;
    }

    public String getClientrequestdate() {
        return clientrequestdate;
    }

    public void setClientrequestdate(String clientrequestdate) {
        this.clientrequestdate = clientrequestdate;
    }

    public String getClienttargetdate() {
        return clienttargetdate;
    }

    public void setClienttargetdate(String clienttargetdate) {
        this.clienttargetdate = clienttargetdate;
    }

    public String getActualtargetdate() {
        return actualtargetdate;
    }

    public void setActualtargetdate(String actualtargetdate) {
        this.actualtargetdate = actualtargetdate;
    }

    public String getImpact() {
        return Impact;
    }

    public void setImpact(String Impact) {
        this.Impact = Impact;
    }

    public String getImplementedbyimplservices() {
        return implementedbyimplservices;
    }

    public void setImplementedbyimplservices(String implementedbyimplservices) {
        this.implementedbyimplservices = implementedbyimplservices;
    }

    public String getImplementationiceid() {
        return implementationiceid;
    }

    public void setImplementationiceid(String implementationiceid) {
        this.implementationiceid = implementationiceid;
    }
    
    
    
}
