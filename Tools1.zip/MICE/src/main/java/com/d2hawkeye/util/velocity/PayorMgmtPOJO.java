/*
 * Date : 2015-04-15
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class PayorMgmtPOJO {

    private String clientsImpacted;
    private String eigerPath;
    private String isTestData;
    private String testDataDetails;
    private String prodatalocation;
    private String effectiveDate;
    private String layoutChangeReason;
    private String OAMDetails;
    private String fileNameConv;
    private String controlTotals;
    private String emailCommunication;
    private String issueDetails;
    private String dateOfComp;
    private String signedOffByUserName;
    private String additionalComments;
    private String billclient;
    private String amname;
    private String reason;
    private String billedMonth;
    private String billableAmount;
    private String approvedBy;
    private String approvalDate;
    private String implementationType;
    private String newAIPLayoutId;
    private String oldAIPLayoutId;

    private ChangeRequestPOJO changeRequestPOJO;

    public String getClientsImpacted() {
        return clientsImpacted;
    }

    public void setClientsImpacted(String clientsImpacted) {
        this.clientsImpacted = clientsImpacted;
    }

    public String getEigerPath() {
        return eigerPath;
    }

    public void setEigerPath(String eigerPath) {
        this.eigerPath = eigerPath;
    }

    public String getIsTestData() {
        return isTestData;
    }

    public void setIsTestData(String isTestData) {
        this.isTestData = isTestData;
    }

    public String getTestDataDetails() {
        return testDataDetails;
    }

    public void setTestDataDetails(String testDataDetails) {
        this.testDataDetails = testDataDetails;
    }

    public String getProdatalocation() {
        return prodatalocation;
    }

    public void setProdatalocation(String prodatalocation) {
        this.prodatalocation = prodatalocation;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getLayoutChangeReason() {
        return layoutChangeReason;
    }

    public void setLayoutChangeReason(String layoutChangeReason) {
        this.layoutChangeReason = layoutChangeReason;
    }

    public String getOAMDetails() {
        return OAMDetails;
    }

    public void setOAMDetails(String OAMDetails) {
        this.OAMDetails = OAMDetails;
    }

    public String getFileNameConv() {
        return fileNameConv;
    }

    public void setFileNameConv(String fileNameConv) {
        this.fileNameConv = fileNameConv;
    }

    public String getControlTotals() {
        return controlTotals;
    }

    public void setControlTotals(String controlTotals) {
        this.controlTotals = controlTotals;
    }

    public String getEmailCommunication() {
        return emailCommunication;
    }

    public void setEmailCommunication(String emailCommunication) {
        this.emailCommunication = emailCommunication;
    }

    public String getIssueDetails() {
        return issueDetails;
    }

    public void setIssueDetails(String issueDetails) {
        this.issueDetails = issueDetails;
    }

    public String getDateOfComp() {
        return dateOfComp;
    }

    public void setDateOfComp(String dateOfComp) {
        this.dateOfComp = dateOfComp;
    }

    public String getSignedOffByUserName() {
        return signedOffByUserName;
    }

    public void setSignedOffByUserName(String signedOffByUserName) {
        this.signedOffByUserName = signedOffByUserName;
    }

    public String getAdditionalComments() {
        return additionalComments;
    }

    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    public ChangeRequestPOJO getChangeRequestPOJO() {
        return changeRequestPOJO;
    }

    public void setChangeRequestPOJO(ChangeRequestPOJO changeRequestPOJO) {
        this.changeRequestPOJO = changeRequestPOJO;
    }

    public String getBillclient() {
        return billclient;
    }

    public void setBillclient(String billclient) {
        this.billclient = billclient;
    }

    public String getAmname() {
        return amname;
    }

    public void setAmname(String amname) {
        this.amname = amname;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getBilledMonth() {
        return billedMonth;
    }

    public void setBilledMonth(String billedMonth) {
        this.billedMonth = billedMonth;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public String getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(String approvalDate) {
        this.approvalDate = approvalDate;
    }

    public String getBillableAmount() {
        return billableAmount;
    }

    public void setBillableAmount(String billableAmount) {
        this.billableAmount = billableAmount;
    }

    public String getImplementationType() {
        return implementationType;
    }

    public void setImplementationType(String implementationType) {
        this.implementationType = implementationType;
    }

    public String getNewAIPLayoutId() {
        return newAIPLayoutId;
    }

    public void setNewAIPLayoutId(String newAIPLayoutId) {
        this.newAIPLayoutId = newAIPLayoutId;
    }

    public String getOldAIPLayoutId() {
        return oldAIPLayoutId;
    }

    public void setOldAIPLayoutId(String oldAIPLayoutId) {
        this.oldAIPLayoutId = oldAIPLayoutId;
    }

}
