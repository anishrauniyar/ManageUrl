/*
 * Date : 2015-10-14
 * Author : Bhuwan Prasad Upadhyay (i81324)
 */
package com.d2hawkeye.util;

import com.verisk.ice.design.IceTicketListType;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author i81324
 */
public class CommonUtils {

    public enum SessionAttributes {
        UserID, DomainName
    }

    public static String[] seperateCommaStringToArray(String s) {
        if (s != null) {
            return s.split(",");
        }
        return new String[]{};
    }

    public static IceTicketListType getIceTicketListTypeByName(String name) {
        try {
            for (IceTicketListType iceTicketListType : IceTicketListType.values()) {
                if (iceTicketListType.toString().equals(name)) {
                    return iceTicketListType;
                }
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
            return null;
        }
        return null;
    }

    public static String getIceTicketListTypeTitleByName(String name) {
        try {
            for (IceTicketListType iceTicketListType : IceTicketListType.values()) {
                if (iceTicketListType.toString().equals(name)) {
                    return iceTicketListType.getTableHeaderTitle();
                }
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
            return "";
        }
        return "";
    }

    public static boolean isAdminPanelRight(HttpServletRequest request) {
        if (request == null || request.getSession() == null) {
            return false;
        }
        String Admin = (String) request.getSession().getAttribute("isAdmin");
        String SuperAdmin = (String) request.getSession().getAttribute("isProductAdmin");
        String ProductAdmin = (String) request.getSession().getAttribute("isSuperAdmin");
        return "y".equalsIgnoreCase(Admin) || "y".equalsIgnoreCase(SuperAdmin) || "y".equalsIgnoreCase(ProductAdmin);
    }

    public static String getIceTicketListTypeCombo(String name) {
        StringBuilder comboBoxOptions = new StringBuilder();
        comboBoxOptions.append("<option>ALL</option>");
        for (IceTicketListType iceTicketListType : IceTicketListType.values()) {
            if (iceTicketListType.isShowInComboBox()) {
                if (iceTicketListType.toString().equals(name)) {
                    comboBoxOptions.append("<option value='")
                            .append(iceTicketListType.name()).append("' selected='true'>")
                            .append(iceTicketListType.getTableHeaderTitle())
                            .append("</option>");
                } else {
                    comboBoxOptions.append("<option value='")
                            .append(iceTicketListType.name()).append("'>")
                            .append(iceTicketListType.getTableHeaderTitle())
                            .append("</option>");
                }
            }
        }
        return comboBoxOptions.toString();
    }

    public enum RequestCode {

        /*
            Place exact table name for each request 
         */
        CHANGE_REQUEST("CHR", "Change Request", "1", "oam_cr_crmanager"),
        IMPLEMENTATION_SERVICES("PMG", "Implementation Services", "2", "oam_cr_plchmanager"),
        REPROCESSING("REP", "Client Question – Query Request", "3", "oam_cr_repmanager"),
        VENDOR_MANAGEMENT("COR", "Client Question - Environment Issues", "4", "oam_cr_cormanager"),
        EXTRACT_REQUEST("EXR", "Client Question - Auditor questions", "5", "oam_cr_exrmanager"),
        DATA_ANALYSIS_REQUEST("CAW", "Measure/Data Analysis", "6", "oam_cr_exrmanager"),
        PRODUCTION_INTEGRATION("PIT", "Client Question - Generic", "7", "oam_cr_pitmanager"),
        LAYOUT_ANALYSIS("LAN", "Client Tracker Item", "8", "oam_cr_lamanager"),
        ESTIMATE("EST", "Internal - External Training", "9", "oam_cr_estmanager"),
        DEFECT("DEF", "Defect", "10", "oam_cr_defect");

        private final String requestCode;
        private final String requestTitle;
        private final String requestTypeId;
        private final String dbTblName;

        private RequestCode(String requestCode, String requestTitle, String requestTypeId, String dbTblName) {
            this.requestCode = requestCode;
            this.requestTitle = requestTitle;
            this.requestTypeId = requestTypeId;
            this.dbTblName = dbTblName;
        }

        public String getRequestCode() {
            return requestCode;
        }

        public String getRequestTitle() {
            return requestTitle;
        }

        public String getRequestTypeId() {
            return requestTypeId;
        }

        public String getDbTblName() {
            return dbTblName;
        }

    }

    public static String getRequestTitle(String requestCode) {
        for (RequestCode rc : RequestCode.values()) {
            if (rc.getRequestCode().equalsIgnoreCase(requestCode)) {
                return rc.getRequestTitle();
            }
        }
        return "N/A";
    }

    public static String getRequestTypeCodeById(String id) {
        for (RequestCode rc : RequestCode.values()) {
            if (rc.getRequestTypeId().equalsIgnoreCase(id)) {
                return rc.getRequestCode();
            }
        }
        return "";
    }

    public static RequestCode getRequestTypeById(String id) {
        for (RequestCode rc : RequestCode.values()) {
            if (rc.getRequestTypeId().equalsIgnoreCase(id)) {
                return rc;
            }
        }
        return null;
    }

    public static String getRequestTitleById(String id) {
        for (RequestCode rc : RequestCode.values()) {
            if (rc.getRequestTypeId().equalsIgnoreCase(id)) {
                return rc.getRequestTitle();
            }
        }
        return "N/A";
    }

    public static String getRequestType(String requestCode) {
        System.out.println("inside...getRequestType:" + requestCode);
        for (RequestCode rc : RequestCode.values()) {
            if (rc.requestTypeId.equalsIgnoreCase(requestCode)) {
                return rc.getRequestTitle();
            }
        }
        return "N/A";
    }

    public static String convertMultiSelectString(String[] selections) {
        String rs = "";
        if (selections != null) {
            for (int cnt = 0; cnt < selections.length; cnt++) {
                rs += selections[cnt];
                if (cnt != selections.length - 1) {
                    rs += ":";
                }
            }
        }
        return rs;
    }

    public static String lastEditedUserIdResolver(String newUserId, String lastEditedUserId) {
        /*
             23424:34756
             II      I
             II - Last second user id which update phase
             I - Last first user id which update phase   
         */
        String[] split = lastEditedUserId.split(":");
        if (split != null) {
            if (split.length < 2) {
                if (!split[0].trim().isEmpty()) {
                    newUserId = split[0] + ":" + newUserId;
                }
            } else {
                newUserId = split[1] + ":" + newUserId;
            }
        }
        return newUserId;
    }

    public static String defineIssueTypeIdFromRequestLikeName(String fIssueTypeName) {
        if (fIssueTypeName != null && fIssueTypeName.trim().isEmpty()) {
            return "";
        }
        for (RequestCode code : RequestCode.values()) {
            if (Pattern.compile(Pattern.quote(fIssueTypeName),
                    Pattern.CASE_INSENSITIVE).matcher(code.getRequestTitle()).find()) {
                return code.getRequestTypeId();
            }
        }
        return "";
    }
}
