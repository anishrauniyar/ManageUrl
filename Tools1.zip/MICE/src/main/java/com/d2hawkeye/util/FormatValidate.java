package com.d2hawkeye.util;

import java.text.DateFormat;
import java.text.ParseException;

public class FormatValidate {
  private FormatValidate() {
  }
  public static boolean isEmpty(String data) {
    return (data == null) | ("".equals(data.trim()));
  }

  public static boolean isDate(String data) {
//    System.out.println("Date validation : "+data);
    if (isEmpty(data)) {
      return true;
    }
    DateFormat df = DateFormat.getInstance();
    try {
      df.parse(data);
      return true;
    }
    catch  (ParseException e){
System.out.println("\nError:[default-war/com/d2hawkeye/util/FormatValidate.java]->0<-"+e);}
    String separator = null;
    if (data.indexOf("/") != -1) {
      separator = "/";
    }
    else if (data.indexOf("-") != -1) {
      separator = "-";
    }
    if (separator == null) {
      return false;
    }
    java.util.StringTokenizer st = new java.util.StringTokenizer(data, separator);
    if (st.countTokens() != 3) {
      return false;
    }
    boolean toRet = true;
    for (int i = 0; i < st.countTokens() && toRet; i++) {
      String s = st.nextToken();
      toRet &= isInteger(s);
    }
    return toRet;
  }

  public static boolean isString(String data) {
    if (isEmpty(data)) {
      return true;
    }
    return! (isMoney(data) || isDouble(data) || isInteger(data));
  }

  public static boolean isMoney(String data) {
//    System.out.println("Money validation : "+data);
    String mon = data;
    mon = mon.replace('$', ' ');
    mon = mon.replaceAll(",", "");
    return isDouble(mon);
  }

  public static boolean isInteger(String data) {
//    System.out.println("checking "+data+" for integer type");
    if (isEmpty(data)) {
      return true;
    }
    try {
      Integer.parseInt(data);
//      System.out.println(data + " is an integer data");
    }
    catch  (Exception e){
System.out.println("\nError:[default-war/com/d2hawkeye/util/FormatValidate.java]->1<-"+e);
      return false;
    }
    return true;
  }

  public static boolean isDouble(String data) {
    if (isEmpty(data)) {
      return true;
    }
    try {
      Double.parseDouble(data);
//      System.out.println(data + " is a double data");
    }
    catch  (NumberFormatException e){
System.out.println("\nError:[default-war/com/d2hawkeye/util/FormatValidate.java]->2<-"+e);
      return false;
    }
    return true;
  }

}