package com.d2hawkeye.util;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * This is an utility class that performs formatting
 * on plain values retrieved by database queries.  
 * 
 * @author Dinesh Bajracharya
 *
 */
public class Format {

	public static final int NUMBER_CURRENY = 1;
	public static final int NUMBER_COUNT = 2;
	public static final int NUMBER_PERCENT = 3;

	private Format()	{}
	
	public static String getFormattedNumber(long value, int format)	{
		String returnStr = value + "";
		try	{
			if(format == NUMBER_CURRENY)	{
				returnStr = NumberFormat.getCurrencyInstance().format(value);
				returnStr = returnStr.substring(0, returnStr.indexOf(".")); //remove cents
			}
			else if(format == NUMBER_COUNT)	{
				returnStr = NumberFormat.getNumberInstance().format(value);
			}
			else if(format == NUMBER_PERCENT)	{
				returnStr = NumberFormat.getPercentInstance().format((double)value/100);
			}
		}
		catch(Exception ex)	{
			System.out.println("..exception at getFormattedNumber(value, format) in com.d2oam.salespipeline.utility.Format :" + ex.getMessage());
		}
		return returnStr;
	}
	
	public static String getFormattedDate(Date date, String datePattern)	{
		String returnStr = "";
		if(date != null)	{
			try	{
				DateFormat dateFormat = new SimpleDateFormat(datePattern);
				returnStr = dateFormat.format(date);
			}
			catch(Exception ex)	{
				System.out.println("..exception at getFormattedDate(date, pattern) in com.d2oam.salespipeline.utility.Format :" + ex.getMessage());
			}
		}
		return returnStr;
	}
	
	public static void main(String[] args)	{
		System.out.println(getFormattedDate(new Date(), "MM/dd/yyyy hh:mm:ssa"));
	}
}
