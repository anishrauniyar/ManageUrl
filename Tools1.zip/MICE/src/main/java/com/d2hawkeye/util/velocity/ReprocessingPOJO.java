/*
 * Date : 2015-04-15
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class ReprocessingPOJO {

    private String ba;
    private String wpm;
    private String npm;
    private String cl;
    private String reasonOfReprocess;
    private String addreasonOfReprocess;
    private String billclient;
    private String amname;
    private String reason;
    private String billedMonth;
    private String corActPlan;
    private String approvedBy;
    private String approvalDate;
    private String pmhours;

    public String getBa() {
        return ba;
    }

    public void setBa(String ba) {
        this.ba = ba;
    }

    public String getWpm() {
        return wpm;
    }

    public void setWpm(String wpm) {
        this.wpm = wpm;
    }

    public String getPmhours() {
        return pmhours;
    }

    public void setPmhours(String pmhours) {
        this.pmhours = pmhours;
    }
    
    public String getNpm() {
        return npm;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getCl() {
        return cl;
    }

    public void setCl(String cl) {
        this.cl = cl;
    }

    public String getReasonOfReprocess() {
        return reasonOfReprocess;
    }

    public void setReasonOfReprocess(String reasonOfReprocess) {
        this.reasonOfReprocess = reasonOfReprocess;
    }

    public String getAddreasonOfReprocess() {
        return addreasonOfReprocess;
    }

    public void setAddreasonOfReprocess(String addreasonOfReprocess) {
        this.addreasonOfReprocess = addreasonOfReprocess;
    }

    public String getBillclient() {
        return billclient;
    }

    public void setBillclient(String billclient) {
        this.billclient = billclient;
    }

    public String getAmname() {
        return amname;
    }

    public void setAmname(String amname) {
        this.amname = amname;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getBilledMonth() {
        return billedMonth;
    }

    public void setBilledMonth(String billedMonth) {
        this.billedMonth = billedMonth;
    }

    public String getCorActPlan() {
        return corActPlan;
    }

    public void setCorActPlan(String corActPlan) {
        this.corActPlan = corActPlan;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public String getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(String approvalDate) {
        this.approvalDate = approvalDate;
    }
    
    
}
