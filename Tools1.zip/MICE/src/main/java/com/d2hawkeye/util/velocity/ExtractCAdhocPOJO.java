/*
 * Date : 2015-04-15
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class ExtractCAdhocPOJO {

    private String ba;
    private String wpm;
    private String npm;
    private String cl;
    private String details;
    private String billclient;
    private String amname;
    private String reason;
    private String billedMonth;
    private String approvedBy;
    private String signedBy;
    private String implSpecial;
    private String approvalDate;
    private String implementedbyimplservices;
    private String implementationiceid;
    private ChangeRequestPOJO changeRequestPOJO;

    public String getBa() {
        return ba;
    }

    public void setBa(String ba) {
        this.ba = ba;
    }

    public String getWpm() {
        return wpm;
    }

    public void setWpm(String wpm) {
        this.wpm = wpm;
    }

    public String getNpm() {
        return npm;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getCl() {
        return cl;
    }

    public void setCl(String cl) {
        this.cl = cl;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getBillclient() {
        return billclient;
    }

    public void setBillclient(String billclient) {
        this.billclient = billclient;
    }

    public String getAmname() {
        return amname;
    }

    public void setAmname(String amname) {
        this.amname = amname;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getBilledMonth() {
        return billedMonth;
    }

    public void setBilledMonth(String billedMonth) {
        this.billedMonth = billedMonth;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public String getSignedBy() {
        return signedBy;
    }

    public void setSignedBy(String signedBy) {
        this.signedBy = signedBy;
    }

    public String getApprovalDate() {
        return approvalDate;
    }

    public void setApprovalDate(String approvalDate) {
        this.approvalDate = approvalDate;
    }

    public ChangeRequestPOJO getChangeRequestPOJO() {
        return changeRequestPOJO;
    }

    public void setChangeRequestPOJO(ChangeRequestPOJO changeRequestPOJO) {
        this.changeRequestPOJO = changeRequestPOJO;
    }

    public String getImplSpecial() {
        return implSpecial;
    }

    public void setImplSpecial(String implSpecial) {
        this.implSpecial = implSpecial;
    }

    public String getImplementedbyimplservices() {
        return implementedbyimplservices;
    }

    public void setImplementedbyimplservices(String implementedbyimplservices) {
        this.implementedbyimplservices = implementedbyimplservices;
    }

    public String getImplementationiceid() {
        return implementationiceid;
    }

    public void setImplementationiceid(String implementationiceid) {
        this.implementationiceid = implementationiceid;
    }

}
