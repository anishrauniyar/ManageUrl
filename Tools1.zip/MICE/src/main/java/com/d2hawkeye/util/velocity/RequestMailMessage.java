/*
 * Date : 2015-04-10
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author i81324
 */
public class RequestMailMessage {

    private String dearPerson;
    private String requestCode;
    private ArrayList<MailMessageModel> mailMessageModels = new ArrayList<MailMessageModel>();
    private String documentDownloadLink;
    private String iceURL;
    private boolean isConverted;
    private ArrayList<MailMessageModel> convertedMessageModels = new ArrayList<MailMessageModel>();
    private List<MailMessageModel> timeLogs;
    private List<TestCase> testCases;

    public RequestMailMessage() {
    }

    public ArrayList<MailMessageModel> getMailMessageModels() {
        return mailMessageModels;
    }

    public void setMailMessageModels(ArrayList<MailMessageModel> messageModels) {
        this.mailMessageModels = messageModels;
    }

    public String getDearPerson() {
        return dearPerson;
    }

    public void setDearPerson(String dearPerson) {
        this.dearPerson = dearPerson;
    }

    public String getRequestCode() {
        return requestCode;
    }

    public void setRequestCode(String requestCode) {
        this.requestCode = requestCode;
    }

    public String getDocumentDownloadLink() {
        return documentDownloadLink;
    }

    public void setDocumentDownloadLink(String documentDownloadLink) {
        this.documentDownloadLink = documentDownloadLink;
    }

    public String getIceURL() {
        return iceURL;
    }

    public void setIceURL(String iceURL) {
        this.iceURL = iceURL;
    }

    public boolean isIsConverted() {
        return isConverted;
    }

    public void setIsConverted(boolean isConverted) {
        this.isConverted = isConverted;
    }

    public ArrayList<MailMessageModel> getConvertedMessageModels() {
        return convertedMessageModels;
    }

    public void setConvertedMessageModels(ArrayList<MailMessageModel> convertedMessageModels) {
        this.convertedMessageModels = convertedMessageModels;
    }

    public List<MailMessageModel> getTimeLogs() {
        return timeLogs;
    }

    public void setTimeLogs(List<MailMessageModel> timeLogs) {
        this.timeLogs = timeLogs;
    }

    public void setTestCases(List<TestCase> testCases) {
        this.testCases = testCases;
    }

    public List<TestCase> getTestCases() {
        return testCases;
    }

}
