package com.d2hawkeye.util;

import java.util.Vector;
import java.util.Iterator;
public class StringTokenizer {
  Vector tokens = new Vector();
  String s;
  String delim;
  public StringTokenizer(String s, String delim) {
    String str = new String(s);
    int end=-1, delLen = delim.length();
    do{
      end = str.indexOf(delim);
      if(end!=-1){
        tokens.add(str.substring(0, end));
        str = str.substring(end+delLen, str.length());
      }else{
        tokens.add(str);
      }
    }while(end!=-1);
  }

  public Iterator getTokens(){
    return tokens.iterator();
  }

}