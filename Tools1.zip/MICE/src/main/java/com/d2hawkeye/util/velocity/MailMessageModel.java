/*
 * Date : 2015-04-13
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

/**
 *
 * @author i81324
 */
public class MailMessageModel {

    private String label;
    private String value;
    private String styleClass;
    private String javaScriptCode;

    public MailMessageModel() {
    }

    public MailMessageModel(String label, String value, String styleClass, String javaScriptCode) {
        this.label = label;
        this.value = value;
        this.styleClass = styleClass;
        this.javaScriptCode = javaScriptCode;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getStyleClass() {
        return styleClass;
    }

    public void setStyleClass(String styleClass) {
        this.styleClass = styleClass;
    }

    public String getJavaScriptCode() {
        return javaScriptCode;
    }

    public void setJavaScriptCode(String javaScriptCode) {
        this.javaScriptCode = javaScriptCode;
    }
}
