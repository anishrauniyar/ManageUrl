/*
 * Date : 2015-04-09
 * Author : Bhuwan Prasad Upadhyay
 */
package com.d2hawkeye.util.velocity;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Properties;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author i81324
 */
public class VelocityUtils {

    private VelocityEngine velocityEngine;
    Logger logger = LoggerFactory.getLogger(VelocityUtils.class);

    public VelocityUtils() {
    }

    public void initVelocityConfiguration() {
        try {
            Properties props = new Properties();
            props.load(getClass().getClassLoader().getResourceAsStream("velocity.properties"));
            velocityEngine = new VelocityEngine(props);
        } catch (IOException ex) {
            logger.error(ex.getMessage());
        }
    }

    public String prepareMessage(String templateName, VelocityContext velocityContext) {
        try {
            StringWriter writer = new StringWriter();
            velocityEngine.mergeTemplate(templateName, "utf-8", velocityContext, writer);
            return writer.toString();
        } catch (Exception ex) {
            logger.error(ex.getMessage());
        }
        return "";
    }
}
