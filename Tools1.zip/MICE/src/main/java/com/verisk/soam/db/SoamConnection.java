/*
 * Date : 2016-05-02 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.soam.db;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class SoamConnection {
    
}
