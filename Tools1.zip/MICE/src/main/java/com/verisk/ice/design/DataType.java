/*
 * Date : 2016-02-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.design;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum DataType {
    NUMBER, VARCHAR2, DATE, CHAR, FLOAT,INTEGER
}
