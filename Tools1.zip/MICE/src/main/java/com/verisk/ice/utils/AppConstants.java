/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.utils;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum AppConstants {
    INSTANCE;
    public int[] DEFAULT_ROWS = new int[]{10, 20};
    public String ACTIVITY_UPDATE_PRIMARY_SECONDARY_MESSAGE_SPLITTER = "@sec@";
    public String SQL_REQUESTYPEID_COLUMN_CASE = "Nvl(CASE WHEN p.convrequesttypeid=0 THEN NULL ELSE p.convrequesttypeid END, p.requesttypeid)";
}
