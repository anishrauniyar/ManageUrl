/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.RemainderDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RemainderWrapper {

    private PageSwitcherDTO pageSwitcherDTO;
    private List<RemainderDTO> remainders;
}
