/*
 * Date : 2016-02-08
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import com.verisk.ice.design.DBDefination;
import com.verisk.ice.design.DataType;
import com.verisk.ice.utils.DTOUtils;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class RequestManagerDTO {

    @DBDefination(columnName = "requestcode", dataType = DataType.VARCHAR2)
    private String requestcode;
    @DBDefination(columnName = "pksource", dataType = DataType.NUMBER)
    private String pksource;
    @DBDefination(columnName = "requesttypeid", dataType = DataType.NUMBER)
    private String requesttypeid;
    @DBDefination(columnName = "requestingperson", dataType = DataType.VARCHAR2)
    private String requestingperson;
    @DBDefination(columnName = "statusid", dataType = DataType.NUMBER)
    private String statusid;
    @DBDefination(columnName = "assignedto", dataType = DataType.VARCHAR2)
    private String assignedto;
    @DBDefination(columnName = "clientid", dataType = DataType.VARCHAR2)
    private String clientid;
    @DBDefination(columnName = "requestdate", dataType = DataType.DATE)
    private String requestdate;
    @DBDefination(columnName = "requests", dataType = DataType.VARCHAR2)
    private String requests;
    @DBDefination(columnName = "actiontaken", dataType = DataType.VARCHAR2)
    private String actiontaken;
    @DBDefination(columnName = "targetcompdate", dataType = DataType.DATE)
    private String targetcompdate;
    @DBDefination(columnName = "actualcompdate", dataType = DataType.DATE)
    private String actualcompdate;
    @DBDefination(columnName = "requestpriority", dataType = DataType.NUMBER)
    private String requestpriority;
    @DBDefination(columnName = "iscompleted", dataType = DataType.CHAR)
    private String iscompleted;
    @DBDefination(columnName = "documentcount", dataType = DataType.NUMBER)
    private String documentcount;
    @DBDefination(columnName = "parentrequestcode", dataType = DataType.VARCHAR2)
    private String parentrequestcode;
    @DBDefination(columnName = "expectedcompdate", dataType = DataType.DATE)
    private String expectedcompdate;
    @DBDefination(columnName = "devcompdate", dataType = DataType.DATE)
    private String devcompdate;
    @DBDefination(columnName = "qc", dataType = DataType.VARCHAR2)
    private String qc;
    @DBDefination(columnName = "severityid", dataType = DataType.VARCHAR2)
    private String severityid;
    @DBDefination(columnName = "impact", dataType = DataType.VARCHAR2)
    private String impact;
    @DBDefination(columnName = "lastupdateddate", dataType = DataType.DATE)
    private String lastupdateddate;
    @DBDefination(columnName = "actualhours", dataType = DataType.FLOAT)
    private String actualhours;
    @DBDefination(columnName = "estimatedhours", dataType = DataType.FLOAT)
    private String estimatedhours;
    @DBDefination(columnName = "phaseinject", dataType = DataType.NUMBER)
    private String phaseinject;
    @DBDefination(columnName = "productarea", dataType = DataType.NUMBER)
    private String productarea;
    @DBDefination(columnName = "moduleid", dataType = DataType.NUMBER)
    private String moduleid;
    @DBDefination(columnName = "fixedinversion", dataType = DataType.NUMBER)
    private String fixedinversion;
    @DBDefination(columnName = "productid", dataType = DataType.INTEGER)
    private String productid;
    @DBDefination(columnName = "projectid", dataType = DataType.NUMBER)
    private String projectid;
    @DBDefination(columnName = "detectedversion", dataType = DataType.NUMBER)
    private String detectedversion;
    @DBDefination(columnName = "phasedetected", dataType = DataType.NUMBER)
    private String phasedetected;
    @DBDefination(columnName = "dataproviderid", dataType = DataType.VARCHAR2)
    private String dataproviderid;
    @DBDefination(columnName = "soamrequestcode", dataType = DataType.VARCHAR2)
    private String soamrequestcode;
    @DBDefination(columnName = "requesttitle", dataType = DataType.VARCHAR2)
    private String requesttitle;
    @DBDefination(columnName = "datatype", dataType = DataType.VARCHAR2)
    private String datatype;
    @DBDefination(columnName = "sourceid", dataType = DataType.VARCHAR2)
    private String sourceid;
    @DBDefination(columnName = "phaseid", dataType = DataType.VARCHAR2)
    private String phaseid;
    @DBDefination(columnName = "remarks", dataType = DataType.VARCHAR2)
    private String remarks;
    @DBDefination(columnName = "payorid", dataType = DataType.VARCHAR2)
    private String payorid;
    @DBDefination(columnName = "is_converted", dataType = DataType.VARCHAR2)
    private String is_converted;
    @DBDefination(columnName = "targetcompdate2", dataType = DataType.DATE)
    private String targetcompdate2;
    @DBDefination(columnName = "appreleasedate", dataType = DataType.DATE)
    private String appreleasedate;
    @DBDefination(columnName = "phasechange", dataType = DataType.DATE)
    private String phasechange;
    @DBDefination(columnName = "conversiondate", dataType = DataType.DATE)
    private String conversiondate;
    @DBDefination(columnName = "employergroup", dataType = DataType.VARCHAR2)
    private String employergroup;
    @DBDefination(columnName = "applicationtype", dataType = DataType.VARCHAR2)
    private String applicationtype;
    @DBDefination(columnName = "lasteditedby", dataType = DataType.VARCHAR2)
    private String lasteditedby;
    @DBDefination(columnName = "prioritizeddate", dataType = DataType.DATE)
    private String prioritizeddate;
    @DBDefination(columnName = "prioritizedby", dataType = DataType.VARCHAR2)
    private String prioritizedby;
    @DBDefination(columnName = "convrequesttypeid", dataType = DataType.VARCHAR2)
    private String convrequesttypeid;
    @DBDefination(columnName = "actualcompdate2", dataType = DataType.DATE)
    private String actualcompdate2;

    public static RequestManagerDTO getDefaultRequestManager(String userId) {
        RequestManagerDTO requestManagerDTO = new RequestManagerDTO();
        requestManagerDTO.setRequestdate(DTOUtils.getCurrentDateIntoString());
        requestManagerDTO.setRequestingperson(userId);
        return requestManagerDTO;
    }
}
