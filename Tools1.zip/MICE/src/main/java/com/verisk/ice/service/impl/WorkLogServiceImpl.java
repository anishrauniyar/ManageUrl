/*
 * Date : 2016-04-08 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.worklog.WorkLogDAO;
import com.verisk.ice.model.worklog.WorkLogDTO;
import com.verisk.ice.service.WorkLogService;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WorkLogServiceImpl implements WorkLogService {

    private static final Logger LOG = LoggerFactory.getLogger(WorkLogServiceImpl.class.getName());

    @Override
    public void saveWorkLog(WorkLogDTO workLogDTO) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(workLogDTO));
        }
        WorkLogDAO workLogDAO = new WorkLogDAO();
        WorkLogDTO.parseTimeSpentIfNeccessary(workLogDTO);
        workLogDAO.insert(workLogDTO);
        workLogDAO.takeDown();
    }

    @Override
    public List<Map<String, String>> getWorkLogHistory(String requestCode) {
        WorkLogDAO workLogDAO = new WorkLogDAO();
        List<Map<String, String>> workLogDTOs = workLogDAO.getWorkLogHistory(requestCode);
        workLogDAO.takeDown();
        return workLogDTOs;
    }

}
