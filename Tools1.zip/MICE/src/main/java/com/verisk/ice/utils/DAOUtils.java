/*
 * Date : 2016-02-01
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.utils;

import com.verisk.ice.model.FilterKey;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class DAOUtils {

    public enum SqlFetchType {
        LAZY, EGER;
    }

    public static boolean isOnlyEmptyElements(String[] array) {
        if (array != null && array.length >= 1) {
            return array[0] == null || array[0].trim().isEmpty();
        }
        return true;
    }

    public static String addQueryForFilterOnSingleColumn(String column, String rootQuery, String[] filterArray) {
        if (filterArray != null) {
            if (isOnlyEmptyElements(filterArray)) {
                return rootQuery;
            }
            for (int i = 0; i < filterArray.length; i++) {
                String value = filterArray[i];
                if (i == 0) {
                    rootQuery += " AND ( " + column + "='" + value + "'";
                } else if (value != null && !value.trim().isEmpty()) {
                    rootQuery += " OR " + column + "='" + value + "'";
                }

                if (i == filterArray.length - 1) {
                    rootQuery += " ) ";
                }
            }
        }
        return rootQuery;
    }

    public static String addQueryForFilterOnDateRange(String column, String rootQuery, String dateRange) {
        if (dateRange != null && !dateRange.trim().isEmpty()) {
            String[] dates = dateRange.split(" - ");
            if (dates.length == 2) {
                rootQuery += " AND Trunc(" + column + ") BETWEEN TO_DATE('" + dates[0] + "', 'mm/dd/yyyy') AND TO_DATE ('" + dates[1] + "', 'mm/dd/yyyy') ";
            }
        }
        return rootQuery;
    }

    public static String addQueryForFilterOnMultipleColumn(String rootQuery, List<FilterKey> filterKeys) {
        if (filterKeys != null) {
            for (FilterKey filterKey : filterKeys) {
                if (FilterKey.isValueIsNotEmpty(filterKey)) {
                    rootQuery += " AND ( Upper(" + filterKey.getKey() + ") LIKE '%" + filterKey.getValue().trim().toUpperCase() + "%' ) ";
                }
            }

        }
        return rootQuery;
    }

    public static String addQueryForFilterOnMultipleColumn(String rootQuery, Map<String, String> filterKeys) {
        if (filterKeys != null) {
            for (Map.Entry<String, String> filterKey : filterKeys.entrySet()) {
                if (ObjectUtil.isNotEmptyAndNull(filterKey.getKey()) && ObjectUtil.isNotEmptyAndNull(filterKey.getValue())) {
                    if (filterKey.getKey().equals("phaseid")) {
                        rootQuery += " AND ( Upper(" + filterKey.getKey() + ") ='" + filterKey.getValue().trim().toUpperCase() + "' ) ";
                    } else {
                        rootQuery += " AND ( Upper(" + filterKey.getKey() + ") LIKE '%" + filterKey.getValue().trim().toUpperCase() + "%' ) ";
                    }
                }
            }

        }
        return rootQuery;
    }

}
