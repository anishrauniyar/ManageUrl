/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import com.d2hawkeye.util.MapObjectUtils;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author i81324
 */
public class EstimateDTO {

    public enum DBColumns {

        ESTID, REQUESTCODE, ACCOUNTMANAGER, APPROVEDBY, APPROVEDATE, BILLABLEAMOUNT, REQUESTDESCRIPTION

    }

    private String estid;
    private String requestcode;
    private String accountmanager;
    private String approvedby;
    private String approvedate;
    private String billableamount;
    private String requestdescription;

    public static EstimateDTO initObjectByHttpRequest(HttpServletRequest request) {
        EstimateDTO estimateDTO = new EstimateDTO();
        if (request == null) {
            return estimateDTO;
        }
        estimateDTO.setAccountmanager(MapObjectUtils.mapStringWithNotNull(request.getParameter("accountmanager")));
        estimateDTO.setApprovedate(MapObjectUtils.mapStringWithNotNull(request.getParameter("approvalDate")));
        estimateDTO.setApprovedby(MapObjectUtils.mapStringWithNotNull(request.getParameter("approvedBy")));
        estimateDTO.setRequestcode(MapObjectUtils.mapStringWithNotNull(request.getParameter("ProjectID")));
        estimateDTO.setBillableamount(MapObjectUtils.mapStringWithNotNull(request.getParameter("billableAmount")));
        estimateDTO.setRequestdescription(MapObjectUtils.mapStringWithNotNull(request.getParameter("requestDescription")));
        return estimateDTO;
    }

    public EstimateDTO() {
    }

    public EstimateDTO(EstimateDTO estimateDTO) {
        this.accountmanager = estimateDTO.accountmanager;
        this.billableamount = estimateDTO.billableamount;
        this.approvedate = estimateDTO.approvedate;
        this.approvedby = estimateDTO.approvedby;
        this.requestcode = estimateDTO.requestcode;
        this.estid = estimateDTO.estid;
        this.requestdescription = estimateDTO.requestdescription;
    }

    public String getEstid() {
        return estid;
    }

    public void setEstid(String estid) {
        this.estid = estid;
    }

    public String getRequestcode() {
        return requestcode;
    }

    public void setRequestcode(String requestcode) {
        this.requestcode = requestcode;
    }

    public String getAccountmanager() {
        return accountmanager;
    }

    public void setAccountmanager(String accountmanager) {
        this.accountmanager = accountmanager;
    }

    public String getApprovedby() {
        return approvedby;
    }

    public void setApprovedby(String approvedby) {
        this.approvedby = approvedby;
    }

    public String getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(String approvedate) {
        this.approvedate = approvedate;
    }

    public String getBillableamount() {
        return billableamount;
    }

    public void setBillableamount(String billableamount) {
        this.billableamount = billableamount;
    }

    public String getRequestdescription() {
        return requestdescription;
    }

    public void setRequestdescription(String requestdescription) {
        this.requestdescription = requestdescription;
    }

}
