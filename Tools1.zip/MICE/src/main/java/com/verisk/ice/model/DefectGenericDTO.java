/*
 * Date : 2016-02-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */

package com.verisk.ice.model;

import com.verisk.ice.design.DBDefination;
import com.verisk.ice.design.DataType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Raju
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DefectGenericDTO {

    @DBDefination(columnName = "defid", dataType = DataType.VARCHAR2)
    private String defid;
    @DBDefination(columnName = "defname", dataType = DataType.VARCHAR2)
    private String defname;

}
