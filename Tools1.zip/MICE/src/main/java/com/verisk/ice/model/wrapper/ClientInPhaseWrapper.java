/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.ClientInPhaseDTO;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ClientInPhaseWrapper {

    private PageSwitcherDTO pageSwitcherDTO;
    private List<ClientInPhaseDTO> clientInPhases;
}
