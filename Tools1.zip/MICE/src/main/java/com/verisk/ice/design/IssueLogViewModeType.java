/*
 * Date : 2016-00-21 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.design;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum IssueLogViewModeType {
    list, export;
}
