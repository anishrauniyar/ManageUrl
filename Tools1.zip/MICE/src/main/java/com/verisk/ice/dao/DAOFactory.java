/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.google.gson.Gson;
import com.verisk.ice.dao.phaseswitch.PhaseSwitchDAO;
import com.verisk.ice.dao.worklog.WorkLogDAO;
import lombok.Getter;

/**
 *
 * @author i81324
 */
@Getter
public enum DAOFactory {

    INSTANCE;
    /*
        Implementating singleton for DAO Pool
     */
    private final LayoutAnalysisDAO layoutAnalysisDAO;
    private final EstimateDAO estimateDAO;
    private final ActivityUpdateDAO activityUpdateDAO;
    private final IceTicketAssignDAO iceTicketAssignDAO;
    private final DefectDAO defectDAO;
    private final DefectApplicationDAO defectApplicationDAO;
    private final DefectComponentDAO defectComponentDAO;
    private final DefectCategoryDAO defectCategoryDAO;
    private final DefectTeamDAO defectTeamDAO;
    private final DefectSubTypeDAO defectSubTypeDAO;
    private final FactsAndStatsDAO factsAndStatsDAO;
    private final IceTicketListDAO iceTicketListDAO;
    private final OamTicketListDAO oamTicketListDAO;
    private final Gson json;
    private final Boolean isActivityUpdateEnable = Boolean.TRUE;
    private final Boolean isLogEnable = Boolean.FALSE;

    private final OamDAO oamDAO;
    private final IceDAO iceDAO;
    private final UILayoutDAO uiLayoutDAO;
    private final IssueLogDAO issueLogDAO;
    private final DashboardFilterDAO dashboardFilterDAO;
    private final PhaseSwitcherDAO phaseSwitcherDAO;
    private final PhaseSwitchDAO phaseSwitchDAO;
    private final WorkLogDAO workLogDAO;

    private DAOFactory() {
        this.layoutAnalysisDAO = new LayoutAnalysisDAO();
        this.estimateDAO = new EstimateDAO();
        this.activityUpdateDAO = new ActivityUpdateDAO();
        this.iceTicketAssignDAO = new IceTicketAssignDAO();
        this.json = new Gson();
        this.defectDAO = new DefectDAO();
        this.defectApplicationDAO = new DefectApplicationDAO();
        this.defectComponentDAO = new DefectComponentDAO();
        this.defectCategoryDAO = new DefectCategoryDAO();
        this.defectTeamDAO = new DefectTeamDAO();
        this.defectSubTypeDAO = new DefectSubTypeDAO();

        this.factsAndStatsDAO = new FactsAndStatsDAO();
        this.iceTicketListDAO = new IceTicketListDAO();
        this.oamTicketListDAO = new OamTicketListDAO();
        this.oamDAO = new OamDAO();
        this.uiLayoutDAO = new UILayoutDAO();
        this.iceDAO = new IceDAO();
        this.issueLogDAO = new IssueLogDAO();
        this.dashboardFilterDAO = new DashboardFilterDAO();
        this.phaseSwitcherDAO = new PhaseSwitcherDAO();
        this.phaseSwitchDAO = new PhaseSwitchDAO();
        this.workLogDAO = new WorkLogDAO();
    }

    
}
