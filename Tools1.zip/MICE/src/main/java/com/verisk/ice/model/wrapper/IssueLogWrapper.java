/*
 * Date : 2016-00-21 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.IssueLogDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class IssueLogWrapper {

    private List<IssueLogDTO> issueLogDTOs;
    private PageSwitcherDTO pageSwitcherDTO;
    private Map<String, String> counts;
}
