/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.FactsAndStatsDTO;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.wrapper.FactsAndStatsWrapper;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class FactsAndStatsDAO extends ConnectionBean implements CrudDAO<FactsAndStatsDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(FactsAndStatsDTO entity) {
        String SQL = "INSERT INTO OAM_CR_FACTSANDSTATS  "
                + " (data, is_deleted)"
                + " VALUES (?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, entity.getData());
            ps.setString(2, entity.getIsDeleted());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void update(String id, FactsAndStatsDTO entity) {
        String SQL = "UPDATE OAM_CR_FACTSANDSTATS  "
                + " SET data = ?, is_deleted = ? WHERE id=?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, entity.getData());
            ps.setString(2, entity.getIsDeleted());
            ps.setString(3, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public FactsAndStatsDTO find(String id) {
        FactsAndStatsDTO factsAndStatsDTO = new FactsAndStatsDTO();
        String sql = "SELECT * FROM OAM_CR_FACTSANDSTATS WHERE  id='" + id + "'";
        if (getList(sql, "FactsAndStatsDAO#find(" + id + ")")) {
            if (moveNext()) {
                factsAndStatsDTO.setId(getData("id"));
                factsAndStatsDTO.setData(getData("data"));
                factsAndStatsDTO.setIsDeleted(getData("is_deleted"));
            }
        }
        return factsAndStatsDTO;
    }

    public FactsAndStatsWrapper findAllFactsAndStats(DashboardFilterWrapper dashboardFilterWrapper, String searchKey) {
        FactsAndStatsWrapper factsAndStatsWrapper = new FactsAndStatsWrapper();
        if (dashboardFilterWrapper != null && dashboardFilterWrapper.getPageSwitcherDTO() != null) {
            searchKey = (searchKey == null) ? "" : searchKey.toUpperCase();
            String rootQuery = " SELECT ROWNUM AS ROWNO ,  a.* "
                    + " FROM OAM_CR_FACTSANDSTATS a WHERE UPPER(a.DATA) LIKE '%" + searchKey + "%' AND IS_DELETED = 'N'";
            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";
            String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
            PageSwitcherDTO pageSwitcherDTO = dashboardFilterWrapper.getPageSwitcherDTO();
            if (getList(countQuery, "FactsAndStatsDAO#findAllFactsAndStats(countQuery)")) {
                if (moveNext()) {
                    pageSwitcherDTO.setTotal(getData("TOTAL"));
                }
            }
            long startRow = 1L + (pageSwitcherDTO.getPageNo() - 1) * pageSwitcherDTO.getRowNo();
            long endRow = pageSwitcherDTO.getPageNo() * pageSwitcherDTO.getRowNo();
            actualFetchQuery += "  WHERE   b.ROWNO >= " + startRow + " AND b.ROWNO <= " + endRow;

            if (getList(actualFetchQuery, "FactsAndStatsDAO#findAllFactsAndStats(actualFetchQuery)")) {
                List<FactsAndStatsDTO> factsAndStatsDTOs = new ArrayList<>();
                while (moveNext()) {
                    factsAndStatsDTOs.add(new FactsAndStatsDTO(getData("ID"), getData("data"), getData("is_deleted")));
                }
                factsAndStatsWrapper.setFactsAndStats(factsAndStatsDTOs);
                factsAndStatsWrapper.setPageSwitcherDTO(pageSwitcherDTO);
            }
        }
        return factsAndStatsWrapper;
    }

    public List<FactsAndStatsDTO> findAll(Map<String, String> filters) {
        List<FactsAndStatsDTO> factsAndStatsDTOs = new ArrayList<>();
        String sql = "SELECT * FROM OAM_CR_FACTSANDSTATS WHERE 1=1 ";
        if (filters != null) {
            sql += " AND DATA LIKE '%" + filters.get("fData") + "%'";
        }
        if (getList(sql, "FactsAndStatsDAO#findAll()")) {
            while (moveNext()) {
                factsAndStatsDTOs.add(new FactsAndStatsDTO(getData("id"), getData("data"), getData("is_deleted")));
            }
        }
        return factsAndStatsDTOs;
    }

    public boolean delete(String id) {
        String insertSQL = "DELETE FROM  OAM_CR_FACTSANDSTATS WHERE id = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return true;
    }
}
