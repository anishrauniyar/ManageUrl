/*
 * Date : 2016-00-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.ListColumnDTO;
import com.verisk.ice.model.phaseswitch.PhaseDetail;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class IceDAO extends ConnectionBean {

    public List<ListColumnDTO> findListColumn(String userId) {
        String sql = "SELECT A.LABELNAME AS LABELNAME,A.COLUMNNAME AS COLUMNNAME,A.COLUMNID AS COLUMNID, "
                + " NVL((SELECT DISTINCT ACTIVECOLUMN FROM OAM_CR_USER_CUSTOM_FIELDS B "
                + " WHERE A.COLUMNID=B.COLUMNID AND B.USERID='" + userId + "' AND A.FORMID=B.FORMID),A.DEFAULTSTATUS) "
                + " AS ACTIVECOLUMN FROM OAM_CR_CUSTOM_FIELDS A "
                + " WHERE A.FORMID='R05'  "
                + " ORDER BY A.COLUMNORDER";
        if (getList(sql, "IceDAO#findListColumn()")) {
            List<ListColumnDTO> columnDTOs = new ArrayList<>();
            while (moveNext()) {
                columnDTOs.add(new ListColumnDTO(getData("LABELNAME"), getData("COLUMNNAME"), getData("COLUMNID"), getData("ACTIVECOLUMN")));
            }
            return columnDTOs;
        }
        return Collections.emptyList();
    }

    public void findPhasesByRequestCode(String requestCode) {
        String sql = "SELECT a.phaseid,a.phasename FROM oam_cr_phases a "
                + "left join oam_cr_template_phases b "
                + "ON b.phaseid=a.phaseid "
                + "left join oam_cr_template_issuetype c "
                + "ON c.templateid = b.templateid "
                + " WHERE c.issuetypeid =  ORDER BY b.phaseorder";
    }

    public List<PhaseDetail> findPhaseDetailByRequestTypeIds(String[] requestTypeIds) {
        List<PhaseDetail> phasesList = new ArrayList<>();
        if (requestTypeIds == null) {
            return phasesList;
        }
        String sql = "SELECT a.phaseid,a.phasename, d.issuetypeid, d.issuetypename,a.statusid FROM oam_cr_phases a "
                + "left JOIN oam_cr_template_phases b  "
                + "ON a.phaseid=b.phaseid  "
                + "left JOIN oam_cr_template_issuetype c  "
                + "ON b.templateid=c.templateid  "
                + "left JOIN oam_cr_issuetype d  "
                + "ON c.issuetypeid=d.issuetypeid  "
                + "WHERE d.issuetypeid IN ( ";
        for (int i = 0; i < requestTypeIds.length; i++) {
            if (i < requestTypeIds.length - 1) {
                sql += requestTypeIds[i] + ", ";
            } else {
                sql += requestTypeIds[i] + " ) AND a.isdeleted = 'N'";
            }
        }
        sql += "ORDER BY b.phaseorder";
        if (getList(sql, "IceDAO#findPhaseDetailByRequestTypeIds()")) {
            while (moveNext()) {
                phasesList.add(new PhaseDetail(getData("phaseid"), getData("phasename"), getData("issuetypeid"), getData("issuetypename"), getData("statusid")));
            }
        }
        return phasesList;
    }

    public List<Map<String, String>> findEmailUserDetailByPhaseId(String phaseId) {
        List<Map<String, String>> userList = new ArrayList<>();
        String sql = "SELECT USERID, USERNAME, EMAIL FROM USR_USERS WHERE USERID IN (  "
                + "SELECT USERID FROM  OAM_CR_USER_ROLE TEAM, OAM_CR_ROLE_PHASE PHASE  "
                + "WHERE TEAM.TEAMID=PHASE.TEAMID AND PHASEID='" + phaseId + "'"
                + ")";
        if (getList(sql, "IceDAO#findEmailUserDetailByPhaseId()")) {
            if (moveNext()) {
                Map<String, String> userDetail = new HashMap<>();
                userDetail.put("userid", getData("USERID"));
                userDetail.put("username", getData("USERNAME"));
                userDetail.put("email", getData("EMAIL"));
                userList.add(userDetail);
            }
        }
        return userList;
    }

    public Set<String> findEmailAddressByPhaseId(String phaseId) {
        Set<String> userList = new HashSet<>();
        String sql = "SELECT EMAIL FROM USR_USERS WHERE USERID IN (  "
                + "SELECT USERID FROM  OAM_CR_USER_ROLE TEAM, OAM_CR_ROLE_PHASE PHASE  "
                + "WHERE TEAM.TEAMID=PHASE.TEAMID AND PHASEID='" + phaseId + "'"
                + ")";
        if (getList(sql, "IceDAO#findEmailAddressByPhaseId()")) {
            if (moveNext()) {
                userList.add(getData("EMAIL"));
            }
        }
        return userList;
    }

    public void setVectorTOEmailAddressAssignedToAndRequestingPerson(Vector toEmail, String requestCode) {
        String sql = "SELECT DISTINCT usr.email, usr.username FROM "
                + "OAM_RM_REQUESTMANAGER rm, USR_USERS usr "
                + "WHERE REQUESTCODE='" + requestCode + "' AND (usr.userid = rm.REQUESTINGPERSON OR usr.userid=rm.ASSIGNEDTO)";
        if (getList(sql, "IceDAO#getToEmailAddress()")) {
            while (moveNext()) {
                String toUser = getData("username") + "<" + getData("email") + ">";
                if (!toEmail.contains(toUser)) {
                    toEmail.addElement(toUser);
                }
            }
        }
    }

    public void setVectorCCEmailAddressByPhaseIds(Vector ccEmail, String prevPhaseId, String currentPhaseId) {
        String sql = "SELECT DISTINCT EMAIL, USERNAME FROM USR_USERS WHERE USERID IN ( "
                + "SELECT USERID FROM  OAM_CR_USER_ROLE TEAM, OAM_CR_ROLE_PHASE PHASE "
                + "WHERE TEAM.TEAMID=PHASE.TEAMID AND PHASEID IN ( '" + prevPhaseId + "', '" + currentPhaseId + "') )";
        if (getList(sql, "IceDAO#getToEmailAddress()")) {
            while (moveNext()) {
                String ccUser = getData("username") + "<" + getData("email") + ">";
                if (!ccEmail.contains(ccUser)) {
                    ccEmail.addElement(ccUser);
                }
            }
        }
    }

    public List<Map<String, String>> getAllUsersBySearchKey(String searchKey) {
        List<Map<String, String>> allUsersList = new ArrayList<>();
        searchKey = searchKey != null ? searchKey.trim().toUpperCase() : "";
        String query = "SELECT UserName, loginname,UserID FROM usr_Users where OAMUSERTYPECODE is not null"
                + " AND oamstatus=1 AND Upper(UserName) LIKE '%" + searchKey + "%'"
                + " ORDER BY UserName";
        if (getList(query, "IceDAO#getAllUsersBySearchKey()")) {
            while (moveNext()) {
                Map<String, String> map = new HashMap<>();
                map.put("userid", getData("UserID"));
                map.put("username", getData("UserName"));
                allUsersList.add(map);
            }
        }
        return allUsersList;
    }

    public List<Map<String, String>> findMyIceTeamUsers(String userId) {
        List<Map<String, String>> managerTeamUsers = new ArrayList<>();
        String sql = "SELECT u.userid as userid, u.username as username"
                + " FROM usr_users u "
                + " where u.userid IN ("
                + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryIN(userId, "ICE")
                + " ) AND  u.userid !='" + userId + "'"
                + "  ORDER BY u.username ";

        if (getList(sql, "IceDAO#findMyTeamUsers()")) {
            while (moveNext()) {
                Map<String, String> object = new HashMap<>();
                object.put("userid", getData("userid"));
                object.put("name", getData("username"));
                managerTeamUsers.add(object);
            }
        }
        return managerTeamUsers;
    }

    public List<Map<String, String>> getAllUser() {
        String sql = "SELECT username,  "
                + "       loginname,  "
                + "       userid  "
                + "FROM   usr_users  "
                + "WHERE  oamstatus = 1  "
                + "ORDER  BY username ";
        List<Map<String, String>> allUsersList = new ArrayList<>();
        if (getList(sql, "IceDAO#getAllUser()")) {
            while (moveNext()) {
                Map<String, String> map = new HashMap<>();
                map.put("userid", getData("UserID"));
                map.put("username", getData("UserName"));
                allUsersList.add(map);
            }
        }
        return allUsersList;
    }

    public Map<String, String> findUserProfile(String userId) {
        Map<String, String> userProfile = new HashMap<>();
        String sql = "SELECT iceteam.id          AS TeamId,  "
                + "       iceteam.name        AS TeamName,  "
                + "       iceteam.application AS Application,  "
                + "       usrrole.userid,  "
                + "       usr.username,  "
                + "       usr.email, "
                + "       (CASE WHEN  manager.teamid IS NULL  THEN 'TEAM_USER' ELSE  'TEAM_MANAGER' END) AS TEAMROLE "
                + "FROM   oam_cr_team iceteam  "
                + "       left join oam_cr_user_role usrrole  "
                + "              ON usrrole.teamid = iceteam.id  "
                + "       left join usr_users usr  "
                + "              ON usr.userid = usrrole.userid "
                + "       left JOIN oam_cr_manager_role manager "
                + "              ON usrrole.teamid = manager.teamid "
                + "WHERE  usrrole.userid = '" + userId + "'  "
                + "       AND iceteam.application IN ( 'ICE' )  "
                + "       AND iceteam.is_deleted = 'N'       "
                + " GROUP BY  iceteam.id,iceteam.name,iceteam.application,usrrole.userid,usr.username,usr.email,( CASE  "
                + "           WHEN manager.teamid IS NULL THEN 'TEAM_USER'  "
                + "           ELSE 'TEAM_MANAGER'  "
                + "         END )";
        if (getList(sql, "IceDAO#findUserProfile()->sql")) {
            if (moveNext()) {
                HashSet<String> teamIds = new HashSet<>();

                String teamId = getData("teamid");
                String teamName = getData("teamname");
                String teamRole = getData("teamrole");
                teamIds.add(teamId);

                userProfile.put("application", getData("application"));
                userProfile.put("userid", getData("userid"));
                userProfile.put("username", getData("username"));
                userProfile.put("email", getData("email"));

                while (moveNext()) {
                    String temp = getData("teamid");
                    if (!teamIds.contains(temp)) {
                        teamId += "/" + temp;
                        teamName += "/" + getData("teamname");
                        teamRole += "/" + getData("teamrole");
                        teamIds.add(temp);
                    }
                }

                userProfile.put("teamid", teamId);
                userProfile.put("teamname", teamName);
                userProfile.put("teamrole", teamRole);
            } else {
                String userSQL = " select userid, username, email from usr_users where userid='" + userId + "'";
                if (getList(userSQL, "IceDAO#findUserProfile()->userSQL")) {
                    if (moveNext()) {
                        userProfile.put("teamid", "N/A");
                        userProfile.put("teamname", "N/A");
                        userProfile.put("application", "N/A");
                        userProfile.put("userid", getData("userid"));
                        userProfile.put("username", getData("username"));
                        userProfile.put("email", getData("email"));
                        userProfile.put("teamrole", "N/A");
                        //userProfile.put("lastQueryTime", new SimpleDateFormat("mm/dd/yyyy hh:MM:ss").format(new Date()));
                    }
                }
            }
        }
        return userProfile;
    }

    public List<Map<String, String>> findMyTeamTree(String userid) {
        List<Map<String, String>> teamList = new ArrayList<>();
        String sql = "SELECT u.userid AS userid,  "
                + "       u.username AS username,  "
                + "       m.teamid AS managerteamid,  "
                + "       mteam.name AS managerteamname, "
                + "       mteam.parent_team AS managerparentteam, "
                + "       uteam.id AS userteamid,  "
                + "       uteam.name AS userteamname  "
                + " FROM   (SELECT username,  "
                + "               userid  "
                + "        FROM   usr_users  "
                + "        WHERE  oamstatus = 1  "
                + "               AND userid IN ( "
                + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryIN(userid, "ICE")
                + "               )  "
                + "        ORDER  BY username) u  "
                + "       left join oam_cr_manager_role m  "
                + "              ON m.userid = u.userid  "
                + "       left join oam_cr_team mteam  "
                + "              ON mteam.id = m.teamid "
                + "       left JOIN oam_cr_user_role urole "
                + "       ON urole.userid = u.userid "
                + "       left join oam_cr_team uteam  "
                + "              ON uteam.id = urole.teamid         "
                + " ORDER  BY uteam.name,mteam.name ";
        if (getList(sql, "IceDAO#findMyTeamTree()")) {
            while (moveNext()) {
                teamList.add(new HashMap<String, String>() {
                    {
                        put("userid", getData("userid"));
                        put("username", getData("username"));
                        put("managerteamid", getData("managerteamid"));
                        put("managerteamname", getData("managerteamname"));
                        put("managerparentteam", getData("managerparentteam"));
                        put("userteamid", getData("userteamid"));
                        put("userteamname", getData("userteamname"));
                    }
                });
            }
        }
        return teamList;
    }

    public List<String> loadIceLinkIds(String filterKey) {
        List<String> list = new ArrayList<>();
        if (filterKey != null) {
            String sql = "SELECT DISTINCT PKSOURCE FROM oam_rm_requestmanager WHERE Upper(PKSOURCE)"
                    + " LIKE '%" + filterKey.toUpperCase() + "%' AND ROWNUM <11 ORDER BY PKSOURCE";
            if (getList(sql, "IceDAO#loadIceLinkIds()")) {
                while (moveNext()) {
                    list.add(getData("PKSOURCE"));
                }
            }
        }
        return list;
    }
}
