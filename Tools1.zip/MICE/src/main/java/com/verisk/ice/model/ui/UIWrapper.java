/*
 * Date : 2016-00-11 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class UIWrapper {

    private UILayout ui;

    public void setDefaultValue(UIWrapper wrapper) {
        if (wrapper != null) {
            
        }
    }
}
