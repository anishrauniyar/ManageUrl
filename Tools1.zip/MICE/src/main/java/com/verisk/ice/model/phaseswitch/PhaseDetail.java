/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PhaseDetail {

    private String phaseid;
    private String phasename;
    private String issuetypeid;
    private String issuetypename;
    private String statusid;

}
