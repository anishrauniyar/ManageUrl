/*
 * Date : 2016-05-19 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.team;

import com.verisk.ice.model.wrapper.TicketListWrapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TeamUserDTO {

    private String userId;
    private String userName;
    private String userTeamRole;
    private TicketListWrapper ticketListWrapper;

}
