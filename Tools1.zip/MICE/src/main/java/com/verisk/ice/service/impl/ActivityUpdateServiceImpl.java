/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.ActivityUpdateDAO;
import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.model.ActivityUpdateDTO;
import com.verisk.ice.model.wrapper.ActivityUpdateWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.service.ActivityUpdateService;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

public class ActivityUpdateServiceImpl implements ActivityUpdateService {

    private static final Logger LOG = LoggerFactory.getLogger(ActivityUpdateServiceImpl.class.getName());

    @Override
    public ActivityUpdateWrapper findActivityUpdates(DashboardFilterWrapper dashboardFilterWrapper) {
        ActivityUpdateDAO activityUpdateDAO = new ActivityUpdateDAO();
        DashboardFilterWrapper.setDefaultPageSwitcherIfNeccessary(dashboardFilterWrapper);
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(dashboardFilterWrapper));
        }
        ActivityUpdateWrapper activityUpdateWrapper = activityUpdateDAO.findAllLatestActivityUpdate(dashboardFilterWrapper);
        activityUpdateDAO.takeDown();
        return activityUpdateWrapper;
    }

    @Override
    public void saveSkipActivityUpdate(String activityUpdateId, String userId) {
        ActivityUpdateDAO activityUpdateDAO = new ActivityUpdateDAO();
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info("Activity Skip for UserId=" + userId);
        }
        activityUpdateDAO.skipActivityUpdate(activityUpdateId, userId);
        activityUpdateDAO.takeDown();
    }

    @Override
    public List<ActivityUpdateDTO> findAllHistoryLogByRequestCode(Map<String, String> historyFilterWrapper) {
        ActivityUpdateDAO activityUpdateDAO = new ActivityUpdateDAO();
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(historyFilterWrapper));
        }
        List<ActivityUpdateDTO> activityUpdateDTOs = activityUpdateDAO.findAllHistoryLogByRequestCode(historyFilterWrapper);
        activityUpdateDAO.takeDown();
        return activityUpdateDTOs;
    }

}
