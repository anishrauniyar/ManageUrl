/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao.phaseswitch;

import com.d2hs.soam.ConnectionBean;
import com.d2hs.soam.rm.queryBeanPM;
import com.verisk.ice.dao.OamDAO;
import com.verisk.ice.legacy.LegacyBeanPool;
import com.verisk.ice.model.phaseswitch.DragDropInfo;
import com.verisk.ice.model.phaseswitch.DragDropInfoOAM;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class PhaseSwitchDAO extends ConnectionBean {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    public boolean changeDragDropInfo(DragDropInfo dragDropInfo, String loggedUserId) {
        String insertSQL = "UPDATE OAM_RM_REQUESTMANAGER SET phaseid = ?, statusid=?, assignedto=?, lasteditedby = ?,"
                + " phasechange=sysdate, remarks=remarks || ' ' || ? WHERE requestcode = ? ";
        queryBeanPM queryBeanPM = new queryBeanPM();
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);

            String statusId = queryBeanPM.getStatus(dragDropInfo.getDataDropZone().getDataDropZonePhaseId());

            System.out.println("PhaseSwitchDAO.changeDragDropInfo()=>REQUESTCODE=" + dragDropInfo.getDataDragItem().getDataDragItemRequestCode()
                    + " UPDATE_PHASEID=" + dragDropInfo.getDataDropZone().getDataDropZonePhaseId()
                    + " UPDATE_STATUSID=" + statusId);

            ps.setString(1, dragDropInfo.getDataDropZone().getDataDropZonePhaseId());
            ps.setString(2, statusId);
            ps.setString(3, dragDropInfo.getAssignee());
            ps.setString(4, loggedUserId);
            ps.setString(5, dragDropInfo.getRemarks());
            ps.setString(6, dragDropInfo.getDataDragItem().getDataDragItemRequestCode());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("PhaseSwitchDAO.changePhase()->ERR:" + e.getMessage());
        } finally {
            queryBeanPM.takeDown();
        }
        return false;
    }

    public boolean changeDragDropInfoOAM(DragDropInfoOAM dragDropInfoOAM) {
        String updateSQL = "UPDATE oam_productionmanager SET phasecode = ?, assignedto=? WHERE appid = ? ";
        OamDAO oamDAO = new OamDAO();
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(updateSQL);

            System.out.println("PhaseSwitchDAO.changeDragDropInfoOAM()=>APPID=" + dragDropInfoOAM.getDataDragItem().getDataDragItemAppId()
                    + " UPDATE_PHASECODE=" + dragDropInfoOAM.getDataDropZone().getDataDropZonePhaseCode()
                    + " PHASECODE=" + dragDropInfoOAM.getDataDragItem().getDataDragItemPhaseCode());

            ps.setString(1, dragDropInfoOAM.getDataDropZone().getDataDropZonePhaseCode());
            ps.setString(2, dragDropInfoOAM.getAssignee());
            ps.setString(3, dragDropInfoOAM.getDataDragItem().getDataDragItemAppId());
            ps.executeUpdate();

            Map<String, String> messageObject = new HashMap<>();
            messageObject.put("COMMENTS", "Phase change: from "
                    + oamDAO.findOamPhaseDescByPhaseCode(dragDropInfoOAM.getDataDragItem().getDataDragItemPhaseCode()) + " to "
                    + oamDAO.findOamPhaseDescByPhaseCode(dragDropInfoOAM.getDataDropZone().getDataDropZonePhaseCode()));
            messageObject.put("POSTEDBY", dragDropInfoOAM.getSessionUserId());
            messageObject.put("APPID", dragDropInfoOAM.getDataDragItem().getDataDragItemAppId());
            messageObject.put("CLIENTID", dragDropInfoOAM.getDataDragItem().getDataDragItemClientId());
            messageObject.put("ASSIGNEDTO", dragDropInfoOAM.getAssignee());
            oamDAO.insertLogOnOAMValueChange(messageObject);
            return true;
        } catch (Exception e) {
            System.out.println("PhaseSwitchDAO.changePhase()->ERR:" + e.getMessage());
        } finally {
            oamDAO.takeDown();
        }
        return false;
    }

}
