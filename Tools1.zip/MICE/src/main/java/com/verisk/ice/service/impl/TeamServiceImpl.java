/*
 * Date : 2016-05-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.TeamDAO;
import com.verisk.ice.model.team.TeamDTO;
import com.verisk.ice.model.wrapper.ParamFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import com.verisk.ice.service.TeamService;
import com.verisk.ice.service.TicketListService;
import com.verisk.ice.utils.ValidateUtility;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TeamServiceImpl implements TeamService {

    private static final Logger LOG = LoggerFactory.getLogger(TeamServiceImpl.class.getName());

    @Override
    public List<TeamDTO> findMyTeamDetails(String userid, String application) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info("TeamServiceImpl#findMyTeamDetails(" + userid + "," + application + ")");
        }
        TeamDAO teamDAO = new TeamDAO();
        List<TeamDTO> teamDTOs = teamDAO.findTeamsDetailByUserIdAndApp(userid, application);
        teamDAO.takeDown();
        return teamDTOs;
    }

    @Override
    public TicketListWrapper findMyTeamUserTicketsOfUpForGrabs(ParamFilterWrapper paramFilterWrapper) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(paramFilterWrapper));
        }

        try {
            ValidateUtility.isNotNull(paramFilterWrapper);
            ValidateUtility.isNotNull(paramFilterWrapper.getParam());
            ValidateUtility.isNotNull(paramFilterWrapper.getDashboardFilterDTO());
            ValidateUtility.isNotNull(paramFilterWrapper.getParam().get("userid"));
            ValidateUtility.isNotNull(paramFilterWrapper.getParam().get("teamid"));
            ValidateUtility.isNotNull(paramFilterWrapper.getParam().get("application"));
            ValidateUtility.isNotNull(paramFilterWrapper.getParam().get("ticketListType"));
        } catch (Exception ex) {
            return new TicketListWrapper();
        }

        TicketListService ticketListService = new TicketListServiceImpl();
        TicketListFilterWrapper ticketListFilterWrapper = new TicketListFilterWrapper();

        Map<String, String> coreQueryFilterKeys = new HashMap<>();
        coreQueryFilterKeys.put("teamId", paramFilterWrapper.getParam().get("teamid"));
        
        if (!paramFilterWrapper.getParam().get("ticketListType").startsWith("UNASSIGNED")) {
            paramFilterWrapper.getDashboardFilterDTO().setUserid(paramFilterWrapper.getParam().get("userid"));
        }
        
        ticketListFilterWrapper.setCoreQueryfilterKeys(coreQueryFilterKeys);
        ticketListFilterWrapper.setDashboardFilter(paramFilterWrapper.getDashboardFilterDTO());
        return ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, paramFilterWrapper.getParam().get("ticketListType"), paramFilterWrapper.getParam().get("application"));
    }

}
