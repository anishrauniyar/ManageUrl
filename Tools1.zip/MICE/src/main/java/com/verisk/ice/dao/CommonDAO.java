/*
 * Date : 2015-12-02
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hawkeye.util.CommonUtils;
import static com.d2hawkeye.util.CommonUtils.RequestCode.*;
import com.d2hawkeye.util.MapObjectUtils;
import com.d2hs.soam.ConnectionBean;
import com.d2hs.soam.rm.QueryBean;
import com.d2hs.soam.rm.queryBeanPM;
import com.verisk.ice.design.UIFieldNames;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author i81324
 */
public final class CommonDAO extends ConnectionBean {

    public String getSingleSelectComboBoxForImplementationType(String selectedValue) {
        StringBuilder sb = new StringBuilder();
        sb.append("<select id='").append(UIFieldNames.ImplementationType.getField()).append("' name='")
                .append(UIFieldNames.ImplementationType.getField()).append("'>");
        sb.append("<option value='-1'>Please Choose</option>");
        String query = "SELECT IMPLEMENTATIONTYPEID, IMPLEMENTATIONTYPE FROM  oam_cr_implementationType WHERE ISDELETED='N' ORDER BY IMPLEMENTATIONTYPEID asc";
        if (getList(query, "CommonDAO#getSingleSelectComboBoxForImplementationType()")) {
            while (moveNext()) {
                String id = getData("IMPLEMENTATIONTYPEID");
                if (selectedValue != null) {
                    if (selectedValue.equalsIgnoreCase(id)) {
                        sb.append("<option value='").append(id).append("' selected='true'>").append(getData("IMPLEMENTATIONTYPE")).append("</option>");
                    } else {
                        sb.append("<option value='").append(id).append("'>").append(getData("IMPLEMENTATIONTYPE")).append("</option>");
                    }
                } else {
                    sb.append("<option value='").append(id).append("'>").append(getData("IMPLEMENTATIONTYPE")).append("</option>");
                }
            }
        }
        sb.append("</select>");
        return sb.toString();
    }

    public String getSingleSelectComboBoxForPrioritizedby(String selectedValue, String issueTypeId) {
        StringBuilder sb = new StringBuilder();
        sb.append("<select id='").append(UIFieldNames.PrioritizedBy.getField()).append("' name='")
                .append(UIFieldNames.PrioritizedBy.getField()).append("'>");
        sb.append("<option value='-1'>Please Choose</option>");
        String query = "SELECT a.USERID,b.USERNAME FROM OAM_CR_PRIORITIZED_USERS a, USR_USERS b WHERE  a.USERID = b.USERID AND a.ISSUETYPEID ='" + issueTypeId + "' ORDER  BY a.USERID";
        if (getList(query, "CommonDAO#getSingleSelectComboBoxForPrioritizedby()")) {
            while (moveNext()) {
                String id = getData("USERID");
                if (selectedValue != null) {
                    if (selectedValue.equalsIgnoreCase(id)) {
                        sb.append("<option value='").append(id).append("' selected='true'>").append(getData("USERNAME")).append("</option>");
                    } else {
                        sb.append("<option value='").append(id).append("'>").append(getData("USERNAME")).append("</option>");
                    }
                } else {
                    sb.append("<option value='").append(id).append("'>").append(getData("USERNAME")).append("</option>");
                }
            }
        }
        sb.append("</select>");
        return sb.toString();
    }

    public boolean PrioritizedbyUser(String selectedValue, String issueTypeId) {
        String query = "SELECT a.USERID,b.USERNAME FROM OAM_CR_PRIORITIZED_USERS a, USR_USERS b WHERE  a.USERID = b.USERID AND a.ISSUETYPEID ='" + issueTypeId + "' ORDER  BY a.USERID";
        if (getList(query, "CommonDAO#getSingleSelectComboBoxForPrioritizedby()")) {
            while (moveNext()) {
                String id = getData("USERID");
                if (selectedValue != null) {
                    if (selectedValue.equalsIgnoreCase(id)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public String getMultiSelectComboBoxForApplicationType(String selectedValue) {
        StringBuilder sb = new StringBuilder();
        sb.append("<select id='").append(UIFieldNames.ApplicationType.getField()).append("' name='")
                .append(UIFieldNames.ApplicationType.getField()).append("' data-placeholder='Please Select' style='width:350px;' multiple='multiple' class='chzn-selecter'>");
        sb.append("<option value='-1' >Please Choose</option>");
        String query = "SELECT APPLICATIONTYPEID, APPLICATIONTYPE FROM OAM_CR_APPLICATIONTYPE WHERE upper(ISDELETED)='N' ORDER BY APPLICATIONTYPEID asc";
        if (selectedValue == null) {
            selectedValue = "";
        }
        List<String> selectedChoices = Arrays.asList(selectedValue.split(":"));
        if (getList(query, "CommonDAO#getMultiSelectComboBoxForImplementationType()")) {
            while (moveNext()) {
                String id = getData("APPLICATIONTYPEID");
                if (selectedChoices.contains(id)) {
                    sb.append("<option value='").append(id).append("' selected='true'>").append(getData("APPLICATIONTYPE")).append("</option>");
                } else {
                    sb.append("<option value='").append(id).append("'>").append(getData("APPLICATIONTYPE")).append("</option>");
                }
            }
        }
        sb.append("</select>");
        return sb.toString();
    }

    public void insertOrUpdateConvertedRequestToCR(String requestCode, queryBeanPM qryBeanPM, QueryBean qryBean, HttpServletRequest request) throws Exception {
        String _datalayout = MapObjectUtils.mapStringWithNotNull(request.getParameter("datalayout"));
        String _ClientRequestDate = MapObjectUtils.mapStringWithNotNull(request.getParameter("ClientRequestDate"));
        String _ClientTargetDate = MapObjectUtils.mapStringWithNotNull(request.getParameter("ClientTargetDate"));
        String _ActualTargetDate = MapObjectUtils.mapStringWithNotNull(request.getParameter("ActualTargetDate"));
        String _billClient = MapObjectUtils.mapStringWithNotNull(request.getParameter("billClient"));
        String _AMName = MapObjectUtils.mapStringWithNotNull(request.getParameter("AMName"));
        String _reason = MapObjectUtils.mapStringWithNotNull(request.getParameter("reason"));
        String _jiraid = MapObjectUtils.mapStringWithNotNull(request.getParameter("jiraid"));
        String _descOfProblem = MapObjectUtils.mapStringWithNotNull(request.getParameter("descOfProblem"));
        String _impacts = MapObjectUtils.mapStringWithNotNull(request.getParameter("descOfProject1"));
        String _changeSpecify = MapObjectUtils.mapStringWithNotNull(request.getParameter("descOfProject2"));
        String _clientpaid = MapObjectUtils.mapStringWithNotNull(request.getParameter("clientpaid"));
        String _processmonth = MapObjectUtils.mapStringWithNotNull(request.getParameter("processmonth"));
        String implementedbyimplservices = MapObjectUtils.mapStringWithNotNull(request.getParameter(UIFieldNames.implementedByImplementationServices.getField()));
        String implementationiceid = MapObjectUtils.mapStringWithNotNull(request.getParameter(UIFieldNames.ImplementationICEID.getField()));
        if (qryBeanPM.isExistInCRManager(requestCode)) {
            qryBean.updateProjectCRManager(requestCode, _billClient, _AMName, _reason, _jiraid,
                    _descOfProblem, _changeSpecify, _impacts, _datalayout,
                    _ClientRequestDate, _ClientTargetDate, _ActualTargetDate, _clientpaid, _processmonth, implementedbyimplservices, implementationiceid);
        } else {
            qryBean.insertProjectCRManager(requestCode, _billClient, _AMName, _reason, _jiraid,
                    _descOfProblem, _changeSpecify, _impacts, _datalayout,
                    _ClientRequestDate, _ClientTargetDate, _ActualTargetDate, _clientpaid, _processmonth, implementedbyimplservices, implementationiceid);
        }
    }

    public String getConvertedPageTitle(String RequestTypeID) {
        StringBuilder htmlCode = new StringBuilder();
        htmlCode.append("<div style='float: right' id='convertBtnId'>");
        if (IMPLEMENTATION_SERVICES.getRequestTypeId().equals(RequestTypeID)) {
            htmlCode.append("<div class='icon'>")
                    .append("<select name='requestConvertedInto' id='requestConvertedInto'>")
                    .append("<option value='").append(PRODUCTION_INTEGRATION.getRequestTypeId()).append("'>").append(PRODUCTION_INTEGRATION.getRequestTitle()).append("</option>")
                    .append("</select>")
                    .append("<a onclick='showConvertedRequestContentsHandle();billClientFunc();observeCharacterCountEvent(null);'><img  src='../images/convert_icon.png'  align=middle border=0></a>")
                    .append("</div>");
        } else if (DATA_ANALYSIS_REQUEST.getRequestTypeId().equals(RequestTypeID)) {
            htmlCode.append("<div class='icon'>")
                    .append("<select name='requestConvertedInto' id='requestConvertedInto'>")
                    .append("<option value='").append(CHANGE_REQUEST.getRequestTypeId()).append("'>").append(CHANGE_REQUEST.getRequestTitle()).append("</option>")
                    .append("</select>")
                    .append("<a onclick='showConvertedRequestContentsHandle();billClientFunc();observeCharacterCountEvent(null);'><img  src='../images/convert_icon.png'  align=middle border=0></a>")
                    .append("</div>");
        } else if (LAYOUT_ANALYSIS.getRequestTypeId().equals(RequestTypeID)) {
            htmlCode.append("<div class='icon'>")
                    .append("<select name='requestConvertedInto' id='requestConvertedInto'>")
                    .append("<option value='").append(IMPLEMENTATION_SERVICES.getRequestTypeId()).append("'>").append(IMPLEMENTATION_SERVICES.getRequestTitle()).append("</option>")
                    .append("</select>")
                    .append("<a onclick='showConvertedRequestContentsHandle();billClientFunc();observeCharacterCountEvent(null);'><img  src='../images/convert_icon.png'  align=middle border=0></a>")
                    .append("</div>");
        } else if (ESTIMATE.getRequestTypeId().equals(RequestTypeID)) {
            htmlCode.append("<div class='icon'>")
                    .append("<select name='requestConvertedInto' id='requestConvertedInto'>")
                    .append("<option value='").append(CHANGE_REQUEST.getRequestTypeId()).append("'>").append(CHANGE_REQUEST.getRequestTitle()).append("</option>")
                    .append("<option value='").append(IMPLEMENTATION_SERVICES.getRequestTypeId()).append("'>").append(IMPLEMENTATION_SERVICES.getRequestTitle()).append("</option>")
                    .append("<option value='").append(EXTRACT_REQUEST.getRequestTypeId()).append("'>").append(EXTRACT_REQUEST.getRequestTitle()).append("</option>")
                    .append("<option value='").append(DATA_ANALYSIS_REQUEST.getRequestTypeId()).append("'>").append(DATA_ANALYSIS_REQUEST.getRequestTitle()).append("</option>")
                    .append("</select>")
                    .append("<a onclick='showConvertedRequestContentsHandle();billClientFunc();observeCharacterCountEvent(null);'><img  src='../images/convert_icon.png'  align=middle border=0></a>")
                    .append("</div>");
        } else if (VENDOR_MANAGEMENT.getRequestTypeId().equals(RequestTypeID)) {
            htmlCode.append("<div class='icon'>")
                    .append("<select name='requestConvertedInto' id='requestConvertedInto'>")
                    .append("<option value='").append(CHANGE_REQUEST.getRequestTypeId()).append("'>").append(CHANGE_REQUEST.getRequestTitle()).append("</option>")
                    .append("<option value='").append(IMPLEMENTATION_SERVICES.getRequestTypeId()).append("'>").append(IMPLEMENTATION_SERVICES.getRequestTitle()).append("</option>")
                    .append("<option value='").append(PRODUCTION_INTEGRATION.getRequestTypeId()).append("'>").append(PRODUCTION_INTEGRATION.getRequestTitle()).append("</option>")
                    .append("</select>")
                    .append("<a onclick='showConvertedRequestContentsHandle();billClientFunc();observeCharacterCountEvent(null);'><img  src='../images/convert_icon.png'  align=middle border=0></a>")
                    .append("</div>");
        }
        htmlCode.append("</div>");
        return htmlCode.toString();
    }

    public void insertOrUpdateConvertedRequestToIMPL(String requestCode, queryBeanPM qryBeanPM, QueryBean qryBean, Map<String, String> values) throws Exception {

        if (qryBeanPM.isExistInSubRequestManager(requestCode, IMPLEMENTATION_SERVICES.getRequestTypeId())) {
            qryBean.updateDetailPayorManager(requestCode,
                    values.get("clientsImpacted"),
                    values.get("eigerPath"),
                    values.get("isTestData"),
                    values.get("testData"),
                    values.get("effectiveDate"),
                    values.get("layoutChangeReason"),
                    values.get("OAMDetails"),
                    values.get("fileNameConv"),
                    values.get("controlTotals"),
                    values.get("emailCommnuication"),
                    values.get("issues"),
                    values.get("additionalValues"),
                    values.get("severityOfChange"),
                    values.get("additionalComments"),
                    values.get("targetDate"),
                    values.get("dateOfComp"),
                    values.get("signedOffBy"),
                    values.get("prodatalocation"),
                    values.get("billClient"),
                    values.get("AMName"),
                    values.get("reason"),
                    values.get("billedMonth"),
                    values.get("approvedBy"),
                    values.get("approvalDate"),
                    values.get("billableAmount"),
                    values.get("ImplementationType"),
                    values.get("newAIPLayoutID"),
                    values.get("oldAIPLayoutID")
            );

        } else {
            qryBean.insertDetailPayorManager(
                    requestCode,
                    values.get("clientsImpacted"),
                    values.get("eigerPath"),
                    values.get("isTestData"),
                    values.get("testData"),
                    values.get("effectiveDate"),
                    values.get("layoutChangeReason"),
                    values.get("OAMDetails"),
                    values.get("fileNameConv"),
                    values.get("controlTotals"),
                    values.get("emailCommnuication"),
                    values.get("issues"),
                    values.get("additionalValues"),
                    values.get("severityOfChange"),
                    values.get("additionalComments"),
                    values.get("targetDate"),
                    values.get("dateOfComp"),
                    values.get("signedOffBy"),
                    values.get("prodatalocation"),
                    values.get("billClient"),
                    values.get("AMName"),
                    values.get("reason"),
                    values.get("billedMonth"),
                    values.get("approvedBy"),
                    values.get("approvalDate"),
                    values.get("billableAmount"),
                    values.get("ImplementationType"),
                    values.get("newAIPLayoutID"),
                    values.get("oldAIPLayoutID")
            );
        }
    }

    public void insertOrUpdateConvertedRequestToExtractRequestORDataAnalysis(String requestCode, CommonUtils.RequestCode code, queryBeanPM qryBeanPM, QueryBean qryBean, Map<String, String> values) throws Exception {
        if (qryBeanPM.isExistInSubRequestManager(requestCode, code.getRequestTypeId())) {
            qryBean.updateDetailExrManager(
                    requestCode,
                    values.get("AMName"),
                    values.get("ba"),
                    values.get("wpm"),
                    values.get("npm"),
                    values.get("cl"),
                    values.get("impSpecialist"),
                    values.get("extractDetails"),
                    values.get("billClient"),
                    values.get("reason"),
                    values.get("billedMonth"),
                    values.get("additionalComments"),
                    values.get("approvedBy"),
                    values.get("signedOffBy"),
                    values.get("approvalDate"),
                    values.get("implementedbyimplservices"),
                    values.get("implementationiceid")
            );
        } else {
            qryBean.insertDetailExrManager(
                    requestCode,
                    values.get("AMName"),
                    values.get("ba"),
                    values.get("wpm"),
                    values.get("npm"),
                    values.get("cl"),
                    values.get("impSpecialist"),
                    values.get("extractDetails"),
                    values.get("billClient"),
                    values.get("reason"),
                    values.get("billedMonth"),
                    values.get("additionalComments"),
                    values.get("approvedBy"),
                    values.get("signedOffBy"),
                    values.get("approvalDate"),
                    values.get("implementedbyimplservices"),
                    values.get("implementationiceid")
            );
        }

    }

    public Map<String, String> setMapForConvertedImplementationService(HttpServletRequest request) {
        Map<String, String> values = new HashMap<String, String>();
        values.put("clientsImpacted", MapObjectUtils.mapStringWithNotNull(request.getParameter("clientsImpacted")));
        values.put("eigerPath", "");
        values.put("isTestData", MapObjectUtils.mapStringWithNotNull(request.getParameter("isTestData")));
        values.put("testData", MapObjectUtils.mapStringWithNotNull(request.getParameter("testData")));
        values.put("effectiveDate", MapObjectUtils.mapStringWithNotNull(request.getParameter("effectiveDate")));
        values.put("layoutChangeReason", "");
        values.put("OAMDetails", MapObjectUtils.mapStringWithNotNull(request.getParameter("OAMDetails")));
        values.put("fileNameConv", MapObjectUtils.mapStringWithNotNull(request.getParameter("fileNameConv")));
        values.put("controlTotals", MapObjectUtils.mapStringWithNotNull(request.getParameter("controlTotals")));
        values.put("emailCommnuication", MapObjectUtils.mapStringWithNotNull(request.getParameter("emailCommnuication")));
        values.put("issues", MapObjectUtils.mapStringWithNotNull(request.getParameter("issues")));
        values.put("additionalValues", "");
        values.put("severityOfChange", MapObjectUtils.mapStringWithNotNull(request.getParameter("severityOfChange")));
        values.put("additionalComments", "");
        values.put("targetDate", MapObjectUtils.mapStringWithNotNull(request.getParameter("targetDate")));
        values.put("dateOfComp", MapObjectUtils.mapStringWithNotNull(request.getParameter("dateOfComp")));
        values.put("signedOffBy", MapObjectUtils.mapStringWithNotNull(request.getParameter("signedOffBy")));
        values.put("prodatalocation", MapObjectUtils.mapStringWithNotNull(request.getParameter("prodatalocation")));
        values.put("billClient", MapObjectUtils.mapStringWithNotNull(request.getParameter("billClient")));
        values.put("AMName", MapObjectUtils.mapStringWithNotNull(request.getParameter("AMName")));
        values.put("reason", MapObjectUtils.mapStringWithNotNull(request.getParameter("reason")));
        values.put("billedMonth", MapObjectUtils.mapStringWithNotNull(request.getParameter("billedMonth")));
        values.put("approvedBy", "");
        values.put("approvalDate", "");
        values.put("billableAmount", MapObjectUtils.mapStringWithNotNull(request.getParameter("billableAmount")));
        values.put("ImplementationType", MapObjectUtils.mapStringWithNotNull(request.getParameter("implementationtype")));
        values.put("newAIPLayoutID", MapObjectUtils.mapStringWithNotNull(request.getParameter("newAIPLayoutID")));
        values.put("oldAIPLayoutID", MapObjectUtils.mapStringWithNotNull(request.getParameter("oldAIPLayoutID")));
        return values;
    }

    public Map<String, String> setMapForConvertedExtractRequestORDataAnalysis(HttpServletRequest request) {
        Map<String, String> values = new HashMap<String, String>();
        values.put("AMName", MapObjectUtils.mapStringWithNotNull(request.getParameter("AMName")));
        values.put("ba", MapObjectUtils.mapStringWithNotNull(request.getParameter("ba")));
        values.put("wpm", MapObjectUtils.mapStringWithNotNull(request.getParameter("wpm")));
        values.put("npm", MapObjectUtils.mapStringWithNotNull(request.getParameter("npm")));
        values.put("cl", MapObjectUtils.mapStringWithNotNull(request.getParameter("cl")));
        values.put("impSpecialist", MapObjectUtils.mapStringWithNotNull(request.getParameter("impSpecialist")));
        values.put("extractDetails", MapObjectUtils.mapStringWithNotNull(request.getParameter("extractDetails")));
        values.put("billClient", MapObjectUtils.mapStringWithNotNull(request.getParameter("billClient")));
        values.put("reason", MapObjectUtils.mapStringWithNotNull(request.getParameter("reason")));
        values.put("billedMonth", MapObjectUtils.mapStringWithNotNull(request.getParameter("billedMonth")));
        values.put("additionalComments", MapObjectUtils.mapStringWithNotNull(request.getParameter("additionalComments")));
        values.put("approvedBy", MapObjectUtils.mapStringWithNotNull(request.getParameter("approvedBy")));
        values.put("signedOffBy", MapObjectUtils.mapStringWithNotNull(request.getParameter("signedOffBy")));
        values.put("approvalDate", MapObjectUtils.mapStringWithNotNull(request.getParameter("approvalDate")));
        values.put("implementedbyimplservices", MapObjectUtils.mapStringWithNotNull(request.getParameter("implementedByImplementationServices")));
        values.put("implementationiceid", MapObjectUtils.mapStringWithNotNull(request.getParameter("ImplementationICEID")));
        return values;
    }

}
