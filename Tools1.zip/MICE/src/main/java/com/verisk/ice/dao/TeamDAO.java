/*
 * Date : 2016-05-19 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.team.TeamDTO;
import com.verisk.ice.model.team.TeamPhaseDTO;
import com.verisk.ice.model.team.TeamUserDTO;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class TeamDAO extends ConnectionBean {

    public List<TeamDTO> findTeamsDetailByUserIdAndApp(String userId, String application) {
        List<TeamDTO> teamDTOs = new ArrayList<>();
        String teamSQL = "SELECT * FROM oam_cr_user_role urole "
                + "INNER JOIN oam_cr_team team "
                + "ON urole.teamid = team.id                      "
                + "WHERE urole.userid='" + userId + "' AND team.application IN (" + application + ") "
                + "ORDER BY PARENT_TEAM DESC";
        if (getList(teamSQL, "TeamDAO#findTeamsByUserId()->teamSQL")) {
            TeamDAO teamDAO = new TeamDAO();
            while (moveNext()) {
                TeamDTO teamDTO = new TeamDTO();
                teamDTO.setTeamId(getData("ID"));
                teamDTO.setTeamName(getData("NAME"));
                teamDTO.setParentTeam(getData("PARENT_TEAM"));
                teamDTO.setApplication(getData("APPLICATION"));
                teamDTO.setTeamUserDTOs(teamDAO.findUsersDetailByTeamId(teamDTO.getTeamId()));
                teamDTO.setTeamPhaseDTOs(teamDAO.findPhasesDetailByTeamId(teamDTO.getTeamId(), teamDTO.getApplication()));
                teamDTOs.add(teamDTO);
            }
            teamDAO.takeDown();
        }
        return teamDTOs;
    }

    public List<TeamUserDTO> findUsersDetailByTeamId(String teamId) {
        List<TeamUserDTO> teamUserDTOs = new ArrayList<>();
        String teamUsersSQL = "SELECT  "
                + "   DISTINCT urole.userid AS userid, "
                + "   usr.username AS username, "
                + "   CASE WHEN m.userid IS NULL THEN '' ELSE 'TEAM_MANAGER' END AS userrole "
                + "FROM oam_cr_user_role urole  "
                + "left JOIN  oam_cr_manager_role m "
                + "ON m.userid=urole.userid AND m.teamid=urole.teamid "
                + "left JOIN usr_users usr "
                + "ON usr.userid=urole.userid "
                + "WHERE urole.teamid='" + teamId + "' "
                + "ORDER BY  USERROLE ASC ,USERNAME ASC ";
        if (getList(teamUsersSQL, "TeamDAO#findUsersDetailByTeamId()->teamUsersSQL")) {
            while (moveNext()) {
                TeamUserDTO teamUserDTO = new TeamUserDTO();
                teamUserDTO.setUserId(getData("userid"));
                teamUserDTO.setUserName(getData("username"));
                teamUserDTO.setUserTeamRole(getData("userrole"));
                teamUserDTOs.add(teamUserDTO);
            }
        }
        return teamUserDTOs;
    }

    public List<TeamPhaseDTO> findPhasesDetailByTeamId(String teamId, String application) {
        List<TeamPhaseDTO> teamPhaseDTOs = new ArrayList<>();
        String teamPhasesSQL = "";
        if ("ICE".equalsIgnoreCase(application)) {
            teamPhasesSQL = "SELECT DISTINCT p.phaseid AS phaseid, phase.phasename as phasename  "
                    + " FROM oam_cr_role_phase p, oam_cr_team t,oam_cr_phases phase "
                    + " WHERE p.teamid=t.id AND p.phaseid=phase.phaseid AND t.application IN ('ICE') "
                    + " AND p.teamid='" + teamId + "'  "
                    + " GROUP BY p.phaseid,phase.phasename  "
                    + " ORDER BY  phase.phasename,p.phaseid ";
        } else if ("OAM".equalsIgnoreCase(application)) {
            teamPhasesSQL = "SELECT DISTINCT p.phaseid AS phaseid, phase.phasedesc AS phasename  "
                    + " FROM oam_cr_role_phase p, oam_cr_team t, oam_pm_phases phase "
                    + " WHERE p.teamid=t.id AND p.phaseid=phase.phasecode AND t.application IN ('OAM') "
                    + " AND p.teamid='" + teamId + "'  "
                    + " GROUP BY p.phaseid,phase.phasedesc  "
                    + " ORDER BY  phase.phasedesc,p.phaseid";
        }
        if (getList(teamPhasesSQL, "TeamDAO#findPhasesDetailByTeamId()->teamPhasesSQL")) {
            while (moveNext()) {
                TeamPhaseDTO teamPhaseDTO = new TeamPhaseDTO();
                teamPhaseDTO.setPhaseId(getData("phaseid"));
                teamPhaseDTO.setPhaseName(getData("phasename"));
                teamPhaseDTOs.add(teamPhaseDTO);
            }
        }
        return teamPhaseDTOs;
    }

}
