/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Request {
    
    private String requestcode;
    private String requesttitle;
    private String requesttypeid;
    private String phaseid;
    private String assignee;
    private String assigneeName;
    private String clientname;
    private String targetCompDate;
    private String priority;
}
