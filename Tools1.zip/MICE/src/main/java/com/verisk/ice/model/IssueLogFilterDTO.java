/*
 * Date : 2016-00-15 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class IssueLogFilterDTO {

    private String userId;
    private String[] clientIds;
    private boolean enableFollowUpMessage;
    private boolean completed;
    private boolean deferred;
    private String dateRange;

    public static boolean checkIsEnableFollowUpMessage(String message) {
        return "on".equalsIgnoreCase(message);
    }
    
    public static boolean checkIsCompleted(String message) {
        return "on".equalsIgnoreCase(message);
    }
    
    
    public static boolean checkIsDeferred(String message) {
        return "on".equalsIgnoreCase(message);
    }
}
