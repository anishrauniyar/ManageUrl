/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import com.verisk.ice.utils.ValidateUtility;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DragDropInfoOAM {

    private String assignee;
    private String remarks;
    private DataDropZoneOAM dataDropZone;
    private DataDragItemOAM dataDragItem;
    private String sessionUserId;

    public static boolean isValidDragDropPhaseSwitchConstraints(DragDropInfoOAM dragDropInfo) {
        try {
            ValidateUtility.isNotNull(dragDropInfo);
            ValidateUtility.isNotNull(dragDropInfo.getDataDragItem());
            ValidateUtility.isNotNull(dragDropInfo.getDataDropZone());
            ValidateUtility.isNotNull(dragDropInfo.getDataDragItem().getDataDragItemPhaseCode());
            ValidateUtility.isNotNull(dragDropInfo.getDataDragItem().getDataDragItemAppId());
            ValidateUtility.isNotNull(dragDropInfo.getDataDropZone().getDataDropZonePhaseCode());
            //DRAG AND DROP RESTRICTION CONTRAINTS
            if (dragDropInfo.getDataDragItem().getDataDragItemPhaseCode().equals(dragDropInfo.getDataDropZone().getDataDropZonePhaseCode())) {
                return false;
            }
            //END
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
