/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import com.verisk.ice.service.TicketListService;
import com.verisk.ice.service.impl.TicketListServiceImpl;
import java.util.Map;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/ticketList")
@Produces(MediaType.APPLICATION_JSON)
public class RESTTicketList {

    @POST
    @Path("/all")
    public TicketListWrapper allTicketList(@QueryParam("type") String type, @QueryParam("app") String app, TicketListFilterWrapper ticketListFilterWrapper) {
        TicketListService ticketListService = new TicketListServiceImpl();
        return ticketListService.findTicketList(ticketListFilterWrapper, type, app);
    }

    @POST
    @Path("/prepareForQuickEdit")
    public Map<String, Object> prepareForQuickEdit(@QueryParam("type") String type, @QueryParam("app") String app, String requestCode) {
        TicketListService ticketListService = new TicketListServiceImpl();
        return ticketListService.prepareForQuickEdit(requestCode, type, app);
    }
}
