/*
 * Date : 2016-02-22
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.design.IceTicketListType;
import com.verisk.ice.design.TicketListDAO;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import com.verisk.ice.utils.DAOUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class IceTicketListDAO extends ConnectionBean implements TicketListDAO {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public TicketListWrapper findAll(TicketListFilterWrapper ticketListFilterWrapper, String type) {
        TicketListWrapper ticketListWrapper = new TicketListWrapper();
        IceTicketListType ticketListType = IceTicketListType.valueOf(type);
        ticketListWrapper.setTableHeaderTitle(ticketListType.getTableHeaderTitle());
        ticketListWrapper.setTableColumnKeyLabel(ticketListType.getTableColumnKeyLabel());
        if (ticketListFilterWrapper != null && ticketListFilterWrapper.getPageSwitcherDTO() != null && ticketListFilterWrapper.getDashboardFilter() != null && ticketListType != null) {
            String rootQuery = ticketListRootQueryGenerator(ticketListType, ticketListFilterWrapper);
            /*APPEND FILTERS*/
            if (ticketListFilterWrapper.getFilterKeys() != null) {
                rootQuery = DAOUtils.addQueryForFilterOnMultipleColumn(rootQuery, ticketListFilterWrapper.getFilterKeys());
            }

            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";
            String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
            PageSwitcherDTO pageSwitcherDTO = ticketListFilterWrapper.getPageSwitcherDTO();
            if (getList(countQuery, "IceTicketListDAO#findAll(countQuery)")) {
                if (moveNext()) {
                    pageSwitcherDTO.setTotal(getData("TOTAL"));
                }
            }
            long startRow = 1L + (pageSwitcherDTO.getPageNo() - 1) * pageSwitcherDTO.getRowNo();
            long endRow = pageSwitcherDTO.getPageNo() * pageSwitcherDTO.getRowNo();
            actualFetchQuery += "  WHERE   b.ROWNO >= " + startRow + " AND b.ROWNO <= " + endRow;

            if (getList(actualFetchQuery, "IceTicketListDAO#findAll(actualFetchQuery)")) {
                List<Map<String, String>> list = new ArrayList<>();
                while (moveNext()) {
                    list.add(ticketListResultExtract(ticketListType));
                }
                ticketListWrapper.setList(list);
                ticketListWrapper.setPageSwitcherDTO(pageSwitcherDTO);
            }
        }
        return ticketListWrapper;
    }

    @Override
    public TicketListWrapper findAllWithoutPagination(TicketListFilterWrapper ticketListFilterWrapper, String type) {
        TicketListWrapper ticketListWrapper = new TicketListWrapper();
        IceTicketListType ticketListType = IceTicketListType.valueOf(type);
        ticketListWrapper.setTableHeaderTitle(ticketListType.getTableHeaderTitle());
        ticketListWrapper.setTableColumnKeyLabel(ticketListType.getTableColumnKeyLabel());
        if (ticketListFilterWrapper != null && ticketListFilterWrapper.getDashboardFilter() != null && ticketListType != null) {
            String rootQuery = ticketListRootQueryGenerator(ticketListType, ticketListFilterWrapper);
            /*APPEND FILTERS*/
            if (ticketListFilterWrapper.getFilterKeys() != null) {
                rootQuery = DAOUtils.addQueryForFilterOnMultipleColumn(rootQuery, ticketListFilterWrapper.getFilterKeys());
            }

            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";
            String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
            PageSwitcherDTO pageSwitcherDTO = new PageSwitcherDTO();
            if (getList(countQuery, "IceTicketListDAO#findAll(countQuery)")) {
                if (moveNext()) {
                    pageSwitcherDTO.setTotal(getData("TOTAL"));
                }
            }
//            long startRow = 1L + (pageSwitcherDTO.getPageNo() - 1) * pageSwitcherDTO.getRowNo();
//            long endRow = pageSwitcherDTO.getPageNo() * pageSwitcherDTO.getRowNo();
//            actualFetchQuery += "  WHERE   b.ROWNO >= " + startRow + " AND b.ROWNO <= " + endRow;

            if (getList(actualFetchQuery, "IceTicketListDAO#findAll(actualFetchQuery)")) {
                List<Map<String, String>> list = new ArrayList<>();
                while (moveNext()) {
                    list.add(ticketListResultExtract(ticketListType));
                }
                ticketListWrapper.setList(list);
                ticketListWrapper.setPageSwitcherDTO(pageSwitcherDTO);
            }
        }
        return ticketListWrapper;
    }

    private String ticketListRootQueryGenerator(IceTicketListType ticketListType, TicketListFilterWrapper ticketListFilterWrapper) {
        if (ticketListType != null) {
            String query = " SELECT ROWNUM AS ROWNO ,  a.* "
                    + " FROM ( " + ticketListType.getRootQueryByTicketListType(ticketListType, ticketListFilterWrapper) + " ) a WHERE 1=1 ";
            return query;
        }
        return "";
    }

    private Map<String, String> ticketListResultExtract(IceTicketListType ticketListType) {
        Map<String, String> map = new LinkedHashMap<>();
        if (ticketListType != null) {
            for (Map.Entry<String, String> entry : ticketListType.getTableColumnKeyLabel().entrySet()) {
                map.put(entry.getKey(), getData(entry.getKey()));
            }
        }
        return map;
    }

    @Override
    public String count(DashboardFilterDTO dashboardFilterDTO, String type) {
        IceTicketListType ticketListType = IceTicketListType.valueOf(type);
        if (dashboardFilterDTO != null && ticketListType != null) {
            String rootQuery = ticketListRootQueryGenerator(ticketListType, new TicketListFilterWrapper(null, dashboardFilterDTO, null, null));
            String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
            if (getList(countQuery, "IceTicketListDAO#count(countQuery)")) {
                if (moveNext()) {
                    return getData("TOTAL");
                }
            }
        }
        return "0";
    }

    @Override
    public String countQuery(DashboardFilterDTO dashboardFilterDTO, String type) {
        IceTicketListType ticketListType = IceTicketListType.valueOf(type);
        if (dashboardFilterDTO != null && ticketListType != null) {
            String rootQuery = ticketListRootQueryGenerator(ticketListType, new TicketListFilterWrapper(null, dashboardFilterDTO, null, null));
            String countQuery = "( SELECT '" + type + "='||  Count(1) AS TOTAL FROM ( " + rootQuery + " ) b )";
            return countQuery;
        }
        return "";
    }

    @Override
    public void takeDown() {
        super.takeDown();
    }

    @Override
    public Map<String, Object> findQuickEditRequestTemplate(String requestCode) {
        return null;
    }

    public Map<String, String> findCountMap(String sql) {
        Map<String, String> countMap = new HashMap<>();
        if (getList(sql, "IceTicketListDAO#findCountMap()")) {
            while (moveNext()) {
                String total = getData("TOTAL");
                String[] split = total.split("=");
                if (split.length == 2) {
                    countMap.put(split[0], split[1]);
                }
            }
        }
        return countMap;
    }

}
