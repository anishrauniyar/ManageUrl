/*
 * Date : 2016-02-08
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */

package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.DefectDTO;
import com.verisk.ice.model.RequestManagerDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DefectWrapper {

    private RequestManagerDTO requestManagerDTO;
    private DefectDTO defectDTO;
}
