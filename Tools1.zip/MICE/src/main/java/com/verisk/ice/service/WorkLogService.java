/*
 * Date : 2016-04-08 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service;

import com.verisk.ice.model.worklog.WorkLogDTO;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface WorkLogService {

    void saveWorkLog(WorkLogDTO workLogDTO);

    List<Map<String, String>> getWorkLogHistory(String requestCode);
}
