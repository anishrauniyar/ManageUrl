/*
 * Date : 2016-05-19 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.team;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TeamDTO {

    private String teamId;
    private String teamName;
    private String parentTeam;
    private String application;
    private List<TeamUserDTO> teamUserDTOs;
    private List<TeamPhaseDTO> teamPhaseDTOs;

}
