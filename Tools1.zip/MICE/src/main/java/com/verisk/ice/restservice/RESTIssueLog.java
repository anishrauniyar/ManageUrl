/*
 * Date : 2016-00-21 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.model.wrapper.IssueLogFilterWrapper;
import com.verisk.ice.model.wrapper.IssueLogWrapper;
import com.verisk.ice.service.IssueLogService;
import com.verisk.ice.service.impl.IssueLogServiceImpl;
import javax.ws.rs.POST;

import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/issuelog")
@Produces(MediaType.APPLICATION_JSON)
public class RESTIssueLog {

    @Path("/all")
    @POST
    public IssueLogWrapper findAll(IssueLogFilterWrapper issueLogFilterWrapper) {
        IssueLogService issueLogService = new IssueLogServiceImpl();
        return issueLogService.findAll(issueLogFilterWrapper);
    }
}
