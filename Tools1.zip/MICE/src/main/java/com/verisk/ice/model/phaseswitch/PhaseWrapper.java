/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import com.verisk.ice.model.PageSwitcherDTO;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PhaseWrapper {

    private String requestTypeId;
    private String dataDropZonePhaseId;
    private String dataDropZonePhaseName;
    private List<Request> requestList;
    private PageSwitcherDTO pageSwitcherDTO;
    private String statusid;
}
