/*
 * Date : 2016-00-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao;

import com.d2hawkeye.util.MapObjectUtils;
import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.FollowUpIssueLog;
import com.verisk.ice.model.IssueLogDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.wrapper.IssueLogFilterWrapper;
import com.verisk.ice.model.wrapper.IssueLogWrapper;
import com.verisk.ice.utils.DAOUtils;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.jsoup.Jsoup;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class IssueLogDAO extends ConnectionBean {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    private static final String ISSUE_LOG_FETCH_QUERY = ""
            + "SELECT p.requestcode, p.lastupdateddate,p.externalid, it.IssueTypeName AS \"Request Type\", "
            + "       CASE "
            + "           WHEN p.IS_CONVERTED IS NOT NULL THEN "
            + "                  (SELECT ISSUETYPENAME "
            + "                   FROM oam_cr_issuetype aaa "
            + "                   WHERE aaa.issuetypeid=p.convrequesttypeid) "
            + "           ELSE '' "
            + "       END AS \"Secondary Request Type\", "
            + "       To_char (p.requestdate,'mm/dd/yyyy') AS \"Data Opened\" , "
            + "      c.ClientName AS \"Client Name\", "
            + "        nvl(p.employergroup,'N/A') AS \"Group\", "
            + "         fun_aggregate(p.payorid) AS Payer, "
            + "      p.RequestTitle AS Description, "
            + "       s.StatusDesc AS status, "
            + "      CASE "
            + "        WHEN p.RequestPriority=5 THEN 'P' "
            + "        ELSE 'N/A' "
            + "        END AS Priority, "
            + "       Nvl(To_char (p.appreleasedate,'mm/dd/yyyy'),' ') AS \"Application Release Date\", "
            + "        Nvl(crp.PhaseName,'N/A') AS \"Data Ops Status\", "
            + "       To_char (nvl(p.targetcompdate2,p.targetcompdate),'mm/dd/yyyy') AS \"Target Date\", "
            + "       p.pksource AS \"ICE#\", "
            + " ( SELECT listagg(t.name, ',') WITHIN GROUP(ORDER BY t.name) teamnames FROM"
            + "     oam_cr_team t, oam_cr_role_phase ph WHERE t.id=ph.teamid "
            + "     AND t.application IN ('ICE') AND ph.PHASEID=p.phaseid"
            + " ) as HighLevelOwnerShip,"
            + " ( SELECT listagg(usr.username, ',') WITHIN GROUP(ORDER BY usr.username) teamnames FROM oam_cr_team t, "
            + "     oam_cr_role_phase ph, oam_cr_manager_role m, usr_users usr "
            + "     WHERE  t.id=ph.teamid AND t.application IN ('ICE')  AND m.teamid=t.id  AND usr.userid=m.userid AND ph.PHASEID=p.phaseid"
            + " ) as IndividualTaskOwner "
            + "FROM OAM_RM_REQUESTMANAGER p "
            + "LEFT JOIN "
            + "  (SELECT USERID, "
            + "          USERNAME"
            + "   FROM USR_USERS where oamstatus=1) e ON p.assignedTo=e.UserID "
            + "LEFT JOIN OAM_RM_REQUESTSTATUS s ON p.Statusid=s.Statusid "
            + "LEFT JOIN OAM_CR_ISSUETYPE it ON p.RequestTypeid=it.IssueTypeId "
            + "LEFT JOIN hr_global_vhpayors pl ON pl.vhpayorid=p.PAYORID "
            + "LEFT JOIN OAM_CLIENTS c ON p.ClientID=c.clientID "
            + "LEFT JOIN oam_clientapps cc ON p.sourceid=cc.applicationid "
            + "LEFT JOIN OAM_CR_PHASES crp ON p.phaseid = crp.phaseid "
            + "WHERE 1=1 "
            + "  AND p.parentRequestCode IS NULL AND s.statusdesc NOT IN ( 'Dropped' ) ";

    private static final String FOLLOWUP_REQUEST_QUERY = "SELECT p.requestcode, p.Requests, To_char (p.requestdate,'mm/dd/yyyy') as requestdate  FROM OAM_RM_REQUESTMANAGER p WHERE p.parentRequestCode=? ORDER BY p.RequestDate";

    public IssueLogWrapper findIssueLogByIssueLogFilterWrapper(IssueLogFilterWrapper issueLogFilterWrapper) {
        IssueLogWrapper issueLogWrapper = new IssueLogWrapper();
        if (issueLogFilterWrapper != null && issueLogFilterWrapper.getIssueLogFilterDTO() != null) {
            String query = ISSUE_LOG_FETCH_QUERY;
            IssueLogFilterWrapper.parseClientIdNamesIfNeccessary(issueLogFilterWrapper);
            query = DAOUtils.addQueryForFilterOnSingleColumn("p.ClientID", query, issueLogFilterWrapper.getIssueLogFilterDTO().getClientIds());
            query = DAOUtils.addQueryForFilterOnDateRange("p.requestdate", query, issueLogFilterWrapper.getIssueLogFilterDTO().getDateRange());

            //IS COMPLETED
            if (!issueLogFilterWrapper.getIssueLogFilterDTO().isCompleted()
                    && !issueLogFilterWrapper.getIssueLogFilterDTO().isDeferred()) {
                query = query + " AND (p.statusid NOT IN ( '4', '2')) ";
            } else if (!issueLogFilterWrapper.getIssueLogFilterDTO().isCompleted()) {
                query = query + " AND (p.statusid != '4') ";
            } else if (!issueLogFilterWrapper.getIssueLogFilterDTO().isDeferred()) {
                query = query + " AND (p.statusid != '2') ";
            }

            query += "  ORDER BY p.lastupdateddate DESC";

            String rootQuery = " SELECT ROWNUM AS ROWNO ,  a.* "
                    + " FROM ( " + query + " ) a WHERE 1=1 ";
            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";

            /*
                Pagination disable for export in xls
             */
            if (issueLogFilterWrapper.isNotXLSExportMode()) {
                String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
                PageSwitcherDTO pageSwitcherDTO = issueLogFilterWrapper.getPageSwitcherDTO();
                if (getList(countQuery, "IssueLogDAO#findIssueLogByIssueLogFilterWrapper(countQuery)")) {
                    if (moveNext()) {
                        pageSwitcherDTO.setTotal(getData("TOTAL"));
                    }
                }

                String statusCountFetchQuery = " SELECT Count(1) as count , STATUS FROM ( " + rootQuery + " ) b GROUP BY STATUS";
                Map<String, String> countsMap = new HashMap<>();
                if (getList(statusCountFetchQuery, "IssueLogDAO#findIssueLogByIssueLogFilterWrapper(statusCountFetchQuery)")) {
                    while (moveNext()) {
                        countsMap.put(getData("STATUS"), getData("COUNT"));
                    }
                }
                issueLogWrapper.setCounts(countsMap);
                long startRow = 1L + (pageSwitcherDTO.getPageNo() - 1) * pageSwitcherDTO.getRowNo();
                long endRow = pageSwitcherDTO.getPageNo() * pageSwitcherDTO.getRowNo();
                actualFetchQuery += "  WHERE   b.ROWNO >= " + startRow + " AND b.ROWNO <= " + endRow;
            } else if (issueLogFilterWrapper.getEnableSubFollowsWithComments() != null) { //If export xls mode enable the sort comments list by requestcode
                Collections.sort(issueLogFilterWrapper.getEnableSubFollowsWithComments(), IssueLogFilterWrapper.COMPARATOR_ENABLE_FOLLOWUP);
            }

            if (getList(actualFetchQuery, "IssueLogDAO#findIssueLogByIssueLogFilterWrapper(actualFetchQuery)")) {
                List<IssueLogDTO> records = new ArrayList<>();
                while (moveNext()) {
                    IssueLogDTO issueLogDTO = new IssueLogDTO();
                    String requestCode = getData("requestcode");
                    issueLogDTO.setRequestType(getData("Request Type"));
                    issueLogDTO.setDateOpened(getData("Data Opened"));
                    issueLogDTO.setGroup(getData("Group"));
                    issueLogDTO.setPayer(getData("Payer"));
                    issueLogDTO.setDescription(getData("Description"));
                    issueLogDTO.setStatus(getData("status"));
                    issueLogDTO.setPriority(getData("Priority"));
                    issueLogDTO.setAppTargetDate(getData("Target Date"));
                    issueLogDTO.setHighLevelOwnerShip(getData("HighLevelOwnerShip"));
                    issueLogDTO.setDataOpsStatus(getData("Data Ops Status"));
                    issueLogDTO.setIndividualTaskOwner(getData("IndividualTaskOwner"));
                    issueLogDTO.setICE(getData("ICE#"));
                    issueLogDTO.setOAM("");
                    issueLogDTO.setExternalID(getData("externalid"));
                    issueLogDTO.setImplCompletionDate("");
                    issueLogDTO.setRequestCode(requestCode);
                    if (issueLogFilterWrapper.getIssueLogFilterDTO().isEnableFollowUpMessage()) {
                        appendFollowUpRequestV3(issueLogDTO, requestCode, issueLogFilterWrapper);
                    }
                    records.add(issueLogDTO);
                }
                issueLogWrapper.setIssueLogDTOs(records);
                issueLogWrapper.setPageSwitcherDTO(issueLogFilterWrapper.getPageSwitcherDTO());
            }
        }
        return issueLogWrapper;
    }

    private void appendFollowUpRequestV3(IssueLogDTO issueLogDTO, String requestCode, IssueLogFilterWrapper issueLogFilterWrapper) {
        try {
            StringBuilder followUpMessageCombiner = new StringBuilder();
            //followUpMessageCombiner.append(issueLogDTO.getDescription());

            setConnection();
            myConn.setAutoCommit(true);
            /*FECTHING FIRST LEVEL FOLLOW UP*/
            PreparedStatement firstLevelPs = myConn.prepareStatement(FOLLOWUP_REQUEST_QUERY);
            firstLevelPs.setString(1, requestCode);
            ResultSet firstLevelRs = firstLevelPs.executeQuery();
            int firstFollowUpCount = 0;
            List<FollowUpIssueLog> followUpIssueLogs = new ArrayList<>();
            while (firstLevelRs.next()) {
                FollowUpIssueLog firstFollowUpIssueLog = new FollowUpIssueLog();
                String firstLevelFollowUpRequestCode = firstLevelRs.getString("REQUESTCODE");
                String firstFollowUpMessage = Jsoup.parse(MapObjectUtils.mapStringWithNotNull(firstLevelRs.getString("REQUESTS"))).text();
                firstFollowUpIssueLog.setFollowUpType("FIRST");
                firstFollowUpIssueLog.setFollowUpLabel("# " + (++firstFollowUpCount));
                firstFollowUpIssueLog.setDescription(firstFollowUpMessage);
                firstFollowUpIssueLog.setRequestDate(firstLevelRs.getString("REQUESTDATE"));

                if (!issueLogFilterWrapper.isNotXLSExportMode()) { //Add comments for xls export
                    Map<String, String> followUpComment = IssueLogFilterWrapper.getFollowUpCommentByBinarySearch(issueLogFilterWrapper.getEnableSubFollowsWithComments(), firstLevelFollowUpRequestCode);

                    if (followUpComment != null) {

                        if (followUpComment.get("enable").equalsIgnoreCase("true")) {
                            followUpMessageCombiner.append(" ");
                            followUpMessageCombiner.append(firstFollowUpIssueLog.getRequestDate()).append(" : ").append(firstFollowUpIssueLog.getDescription());

                        }
                        String firstFollowUpcomment = followUpComment.get("comment");
                        followUpMessageCombiner.append(" ");
                        followUpMessageCombiner.append(firstFollowUpcomment);
                    }
                }
                firstFollowUpIssueLog.setRequestCode(firstLevelFollowUpRequestCode);
                firstFollowUpIssueLog.setParentRequestCode(requestCode);

                followUpIssueLogs.add(firstFollowUpIssueLog);

                /*FECTHING SECOND LEVEL FOLLOW UP*/
                PreparedStatement secondLevelPs = myConn.prepareStatement(FOLLOWUP_REQUEST_QUERY);

                secondLevelPs.setString(1, firstLevelFollowUpRequestCode);
                ResultSet secondLevelRs = secondLevelPs.executeQuery();
                int secondFollowUpCount = 0;
                while (secondLevelRs.next()) {
                    String secondLevelFollowUpRequestCode = secondLevelRs.getString("REQUESTCODE");
                    String secondFollowUpMessage = Jsoup.parse(MapObjectUtils.mapStringWithNotNull(secondLevelRs.getString("REQUESTS"))).text();
                    FollowUpIssueLog secondFollowUpIssueLog = new FollowUpIssueLog();
                    secondFollowUpIssueLog.setFollowUpType("SECOND");
                    secondFollowUpIssueLog.setFollowUpLabel("# " + firstFollowUpCount + "." + (++secondFollowUpCount));
                    secondFollowUpIssueLog.setDescription(secondFollowUpMessage);
                    secondFollowUpIssueLog.setRequestDate(secondLevelRs.getString("REQUESTDATE"));
                    if (!issueLogFilterWrapper.isNotXLSExportMode()) { //Add comments for xls export
                        Map<String, String> followUpComment = IssueLogFilterWrapper.getFollowUpCommentByBinarySearch(issueLogFilterWrapper.getEnableSubFollowsWithComments(), secondLevelFollowUpRequestCode);
                        if (followUpComment != null) {
                            if (followUpComment.get("enable").equalsIgnoreCase("true")) {
                                followUpMessageCombiner.append(" ");
                                followUpMessageCombiner.append(secondFollowUpIssueLog.getRequestDate()).append(" : ").append(secondFollowUpIssueLog.getDescription());

                            }
                            String secondFollowUpcomment = followUpComment.get("comment");
                            followUpMessageCombiner.append(" ");
                            followUpMessageCombiner.append(secondFollowUpcomment);
                        }
                    }
                    secondFollowUpIssueLog.setRequestCode(secondLevelFollowUpRequestCode);
                    secondFollowUpIssueLog.setParentRequestCode(firstLevelFollowUpRequestCode);
                    followUpIssueLogs.add(secondFollowUpIssueLog);
                }
                secondLevelRs.close();
                secondLevelPs.close();
            }
            firstLevelRs.close();
            firstLevelPs.close();
            issueLogDTO.setFollowUpIssueLogs(followUpIssueLogs);
            if (!issueLogFilterWrapper.isNotXLSExportMode()) { //Combine all message in description if xls export mode is enable
                issueLogDTO.setClientNotes(followUpMessageCombiner.toString());
            }
        } catch (Exception ex) {
            System.out.println("com.verisk.ice.dao.IssueLogDAO.appendFollowUpRequest()->" + ex.getMessage());
        }

    }

}
