/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class DashboardFilterDTO {

    public static void separateStartAndEndDateByDaterange(DashboardFilterDTO dashboardFilter) {
        if (dashboardFilter.getDateRange() != null) {
            String[] dates = dashboardFilter.getDateRange().split(" - ");
            if (dates.length == 2) {
                System.out.println("Start Date " + dates[0] + " End Date " + dates[1]);
                dashboardFilter.setStartdate(dates[0]);
                dashboardFilter.setEnddate(dates[1]);
            } else {
                dashboardFilter.setStartdate("");
                dashboardFilter.setEnddate("");
            }
        }
    }

    public static Map<String, String[]> initMapIfNeccessary(Map<String, String[]> map) {
        if (map == null || map.isEmpty()) {
            return new HashMap<String, String[]>() {
                {
                    put("ice", new String[]{});
                    //put("oam", new String[]{});
                }
            };
        }
        return map;
    }

    private String filterid;
    private String userid;
    private Map<String, String[]> requesttypeids;
    private String[] clientids;
    private String[] appids;
    private String dateRange;
    private String startdate;
    private String enddate;
    private String teamRole;

}
