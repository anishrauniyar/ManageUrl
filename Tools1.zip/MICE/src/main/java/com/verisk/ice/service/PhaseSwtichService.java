/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service;

import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.phaseswitch.DragDropInfo;
import com.verisk.ice.model.phaseswitch.DragDropInfoOAM;
import com.verisk.ice.model.phaseswitch.OamPhaseSwitchWrapper;
import com.verisk.ice.model.phaseswitch.PhaseSwitchFilterWrapper;
import com.verisk.ice.model.phaseswitch.PhaseSwitchWrapper;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface PhaseSwtichService {

    List<PhaseSwitchWrapper> findPhaseSwitchWrapperWithoutPagination(PhaseSwitchFilterWrapper phaseSwitchFilterWrapper);

    OamPhaseSwitchWrapper findOamPhaseSwitchWrapperWithoutPagination(DashboardFilterDTO dashboardFilterDTO);

    void changeDragDropInfo(DragDropInfo dragDropInfo, HttpServletRequest request);

    void changeDragDropInfoOAM(DragDropInfoOAM dragDropInfo, HttpServletRequest request);

    List<Map<String, String>> getAllUser();

    List<Map<String, String>> findIceRequestTypesWithCount(DashboardFilterDTO dashboardFilterDTO);
}
