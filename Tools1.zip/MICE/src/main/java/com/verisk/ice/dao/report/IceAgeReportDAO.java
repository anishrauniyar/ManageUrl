/*
 * Date : 2016-06-06 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao.report;

import com.d2hs.soam.ConnectionBean;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class IceAgeReportDAO extends ConnectionBean {

    private static final String AGE_REPORT_SQL = "SELECT issuetypename,PHASENAME,Round(avg(days),2) AS days  FROM "
            + "  (SELECT phasename, ISSUETYPENAME,REQUESTDATE,  Round(phasechange-logged,3) AS days   FROM "
            + "  (SELECT issuetypename,toPhase.phasename ,REQUESTDATE ,logged,   lead (logged) over (PARTITION BY pksource order BY logged) "
            + "  AS phasechange "
            + "  FROM  oam_rm_requestmanager_log Log "
            + "  left JOIN oam_cr_issuetype iss "
            + "  ON Log.requesttypeid=iss.issuetypeid "
            + "  left join oam_cr_phases toPhase "
            + "  ON Log.phaseid=toPhase.phaseid "
            + "  WHERE Log.phaseid IS NOT NULL "
            + "  AND Log.logged IS NOT NULL  "
            + "  AND  Trunc(logged) >= Trunc(SYSDATE-60) "
            + "  AND issuetypename IS NOT NULL ) "
            + "  WHERE  phasechange IS NOT NULL ) "
            + "  GROUP BY  PHASENAME,issuetypename "
            + "  ORDER BY issuetypename,PHASENAME";

    private static final String AGE_REPORT_BY_ID = "SELECT * FROM ("
            + " SELECT pksource,clientid,issuetypename,PHASENAME,Round(avg(days),3) AS days  FROM "
            + " (SELECT pksource,clientid, phasename, ISSUETYPENAME,REQUESTDATE,  "
            + " (Round(phasechange-logged,5)-non_business_days(logged,phasechange)) AS days FROM "
            + " ( SELECT pksource,clientid, issuetypename,toPhase.phasename ,REQUESTDATE ,logged,"
            + " lead (logged) over (PARTITION BY pksource order BY logged) AS phasechange "
            + " FROM  oam_rm_requestmanager_log Log "
            + " left JOIN oam_cr_issuetype iss "
            + " ON Log.requesttypeid=iss.issuetypeid "
            + " left join oam_cr_phases toPhase "
            + " ON Log.phaseid=toPhase.phaseid "
            + " WHERE Log.phaseid IS NOT NULL "
            + " AND Log.logged IS NOT NULL  "
            + " AND  Trunc(logged) >= Trunc(SYSDATE-60) "
            + " AND issuetypename IS NOT NULL ) "
            + " WHERE  phasechange IS NOT NULL ) "
            + " GROUP BY  pksource,clientid, PHASENAME,issuetypename "
            + " ORDER BY pksource desc )";

    public List<Map<String, String>> findAgeReport() {
        List<Map<String, String>> list = new ArrayList<>();
        if (getList(AGE_REPORT_SQL, "IceAgeReportDAO#findAgeReport()")) {
            while (moveNext()) {
                list.add(new HashMap<String, String>() {
                    {
                        put("issuetypename", getData("issuetypename"));
                        put("phasename", getData("phasename"));
                        put("days", getData("days"));
                    }
                });
            }
        }
        return list;
    }

    public List<Map<String, String>> findAgeReportById(String id) {
        List<Map<String, String>> list = new ArrayList<>();
        String sql = AGE_REPORT_BY_ID;
        if (id != null && !id.trim().isEmpty()) {
            sql += " WHERE PKSOURCE = '" + id + "'";
        } else {
            sql += " WHERE ROWNUM <= 50 ";
        }
        if (getList(sql, "IceAgeReportDAO#findAgeReportById()")) {
            while (moveNext()) {
                list.add(new HashMap<String, String>() {
                    {
                        put("pksource", getData("pksource"));
                        put("clientid", getData("clientid"));
                        put("issuetypename", getData("issuetypename"));
                        put("phasename", getData("phasename"));
                        put("days", getData("days"));
                    }
                });
            }
        }
        return list;
    }

}
