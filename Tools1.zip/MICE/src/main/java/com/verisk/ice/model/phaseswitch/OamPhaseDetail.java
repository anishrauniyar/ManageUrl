/*
 * Date : 2016-05-20 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import com.verisk.ice.model.wrapper.TicketListWrapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OamPhaseDetail {

    private String phaseCode;
    private String phaseOrder;
    private String phaseName;
    private TicketListWrapper ticketListWrapper;
}
