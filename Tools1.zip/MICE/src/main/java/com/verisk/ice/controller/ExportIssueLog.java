/*
 * Date : 2016-00-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.controller;

import com.d2hawkeye.util.MapObjectUtils;
import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.IceDAO;
import com.verisk.ice.dao.IssueLogDAO;
import com.verisk.ice.model.wrapper.IssueLogFilterWrapper;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jxls.area.Area;
import org.jxls.builder.AreaBuilder;
import org.jxls.builder.xls.XlsCommentAreaBuilder;
import org.jxls.common.CellRef;
import org.jxls.common.Context;
import org.jxls.transform.Transformer;
import org.jxls.transform.poi.PoiTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class ExportIssueLog extends HttpServlet {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportIssueLog.class.getName());

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        staticXLSExportV2(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Export Issue Log";
    }

    private void staticXLSExportV2(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        IceDAO iceDAO = new IceDAO();
        IssueLogDAO issueLogDAO = new IssueLogDAO();

        String[] clientIdNames = MapObjectUtils.mapStringArrayWithNotNull(request.getParameterValues("clientIds"));
        String[] clientNames = new String[clientIdNames.length];
        for (int i = 0; i < clientIdNames.length; i++) {
            String[] split = clientIdNames[i].split("@");
            clientNames[i] = split[1];
        }
        String issueLogFilterWrapperString = MapObjectUtils.mapStringWithNotNull(request.getParameter("issueLogFilterWrapper"));

        LOGGER.info("IssueLogFilterWrapper=" + issueLogFilterWrapperString + " Clients = " + Arrays.toString(clientNames));

        IssueLogFilterWrapper issueLogFilterWrapper = DAOFactory.INSTANCE.getJson().fromJson(issueLogFilterWrapperString, IssueLogFilterWrapper.class);

        OutputStream os = response.getOutputStream();

        try (InputStream is = IssueLogFileUtil.INSTANCE.getInputStreamForIssueLogStaticXLSTemplate()) {
            issueLogFilterWrapper.setNotXLSExportMode(false);
            String fileName = "IssueLog_" + System.currentTimeMillis() + ".xlsx";
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            Context context = new Context();
            Calendar calender = Calendar.getInstance();
            String today = (calender.get(Calendar.MONTH) + 1) + "/" + calender.get(Calendar.DAY_OF_MONTH) + "/" + calender.get(Calendar.YEAR);
            context.putVar("today", today);
            context.putVar("client", MapObjectUtils.getN_AIfEmptyArrayElseString(clientNames));
            context.putVar("dateRange", MapObjectUtils.getN_AIfEmptyString(issueLogFilterWrapper.getIssueLogFilterDTO().getDateRange()));
            context.putVar("records", issueLogDAO.findIssueLogByIssueLogFilterWrapper(issueLogFilterWrapper).getIssueLogDTOs());

            Transformer transformer = PoiTransformer.createTransformer(is, os);
            AreaBuilder areaBuilder = new XlsCommentAreaBuilder(transformer);
            List<Area> xlsAreaList = areaBuilder.build();
            Area xlsArea = xlsAreaList.get(0);

            xlsArea.applyAt(new CellRef("Report!A4"), context);
            transformer.write();

            // JxlsHelper helper = JxlsHelper.getInstance();
            // helper.setAreaBuilder(areaBuilder)
            // helper.processTemplate(is, os, context);
            is.close();

        } catch (Exception ex) {
            System.out.println("com.verisk.ice.controller.ExportIssueLog.doPost()" + ex.getMessage());
        } finally {
            iceDAO.takeDown();
            issueLogDAO.takeDown();
            if (os != null) {
                os.flush();
                os.close();
            }

        }
    }
}
