/*
 * Date : 2016-01-26
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.DashboardFilterDTO;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ParamFilterWrapper {

    private Map<String, String> param;
    private DashboardFilterDTO dashboardFilterDTO;
}
