/*
 * Date : 2016-05-17 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.model.wrapper.ParamFilterWrapper;
import com.verisk.ice.service.TeamService;
import com.verisk.ice.service.impl.TeamServiceImpl;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/teams")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RESTTeam {

    @POST
    @Path("/myTeamDetail")
    public Object findMyTeamDetails(Map<String, String> param) {
        TeamService teamService = new TeamServiceImpl();
        return teamService.findMyTeamDetails(param.get("userid"), param.get("application"));
    }

    @POST
    @Path("/myTeamUserIceTickets")
    public Object findMyTeamUserTicketsOfUpForGrabs(ParamFilterWrapper paramFilterWrapper) {
        TeamService teamService = new TeamServiceImpl();
        return teamService.findMyTeamUserTicketsOfUpForGrabs(paramFilterWrapper);
    }
}
