/*
 * Date : 2016-00-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.execption;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@AllArgsConstructor
public class UnsuccessfulExportException extends Exception {

    private final String message;

}
