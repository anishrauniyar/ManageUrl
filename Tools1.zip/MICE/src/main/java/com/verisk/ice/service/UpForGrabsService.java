/*
 * Date : 2016-05-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service;

import com.verisk.ice.model.upforgrabs.UpForGrabsSwitchWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface UpForGrabsService {
    
    UpForGrabsSwitchWrapper findUpForGrabsSwitchWrapperICE(DashboardFilterWrapper dashboardFilterWrapper);
    
    UpForGrabsSwitchWrapper findUpForGrabsSwitchWrapperOAM(DashboardFilterWrapper dashboardFilterWrapper);
}
