/*
 * Date : 2016-04-08 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.worklog;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class WorkLogDTO {

    /*
        By default timespent in minute
     */
    private String timespent;
    private String logdate;
    private String comments;
    private String userid;
    private String requestcode;
    private String prevPhaseId;
    private String newPhaseId;

    public static WorkLogDTO parseTimeSpentIfNeccessary(WorkLogDTO workLogDTO) {
        //5w4d4h6m
        if (workLogDTO != null && workLogDTO.getTimespent() != null) {
            double workTimeMinute = Double.valueOf(workLogDTO.getTimespent()) * 60;
            System.out.println("WorkTimeInMinute=" + workTimeMinute);
            workLogDTO.setTimespent(String.valueOf(Math.round(workTimeMinute)));

            /* 
            //
            try {

                double workTimeMinute = Double.valueOf(workLogDTO.getTimespent());
                workLogDTO.setTimespent(String.valueOf(Math.round(workTimeMinute)));

            } catch (Exception e) {

                double week = getValueByPeriodPattern(TimeSpentPeroid.WEEK_PERIOD.getPattern(), workLogDTO.getTimespent());
                double day = getValueByPeriodPattern(TimeSpentPeroid.DAY_PERIOD.getPattern(), workLogDTO.getTimespent());
                double hour = getValueByPeriodPattern(TimeSpentPeroid.HOUR_PERIOD.getPattern(), workLogDTO.getTimespent());
                double minute = getValueByPeriodPattern(TimeSpentPeroid.MINUTE_PERIOD.getPattern(), workLogDTO.getTimespent());
                System.out.println("W=" + week + " D=" + day + " H=" + hour + " M=" + minute);
                double workTimeMinute = (week * 5 * 8 * 60) + (day * 8 * 60) + (hour * 60) + minute;
                System.out.println("WorkTimeInMinute=" + workTimeMinute);
                workLogDTO.setTimespent(String.valueOf(Math.round(workTimeMinute)));

            }
            System.out.println("RoundMinute=" + workLogDTO.getTimespent());
             */
        }
        return workLogDTO;
    }

    public static double getValueByPeriodPattern(Pattern pattern, String s) {
        if (s == null) {
            return 0;
        } else {
            Matcher matcher = pattern.matcher(s);
            String periodValue = "0";
            if (matcher.find()) {
                periodValue = matcher.group();
                periodValue = periodValue.substring(0, periodValue.length() - 1);
            }
            return Double.valueOf(periodValue);
        }

    }

    public enum TimeSpentPeroid {
        WEEK_PERIOD(Pattern.compile("(\\d+[W|w])|(\\d+\\.\\d+[W|w])|(\\.\\d+[W|w])")),
        DAY_PERIOD(Pattern.compile("(\\d+[D|d])|(\\d+\\.\\d+[D|d])|(\\.\\d+[D|d])")),
        HOUR_PERIOD(Pattern.compile("(\\d+[H|h])|(\\d+\\.\\d+[H|h])|(\\.\\d+[H|h])")),
        MINUTE_PERIOD(Pattern.compile("(\\d+[M|m])|(\\d+\\.\\d+[M|m])|(\\.\\d+[M|m])"));

        @Getter
        private final Pattern pattern;

        private TimeSpentPeroid(Pattern pattern) {
            this.pattern = pattern;
        }
    }

//    public static void main(String[] args) {
//        WorkLogDTO workLogDTO = new WorkLogDTO();
//        workLogDTO.setTimespent("4.5w 4D .3H .20M");
//        WorkLogDTO.parseTimeSpentIfNeccessary(workLogDTO);
//        workLogDTO.setTimespent(".5w");
//        WorkLogDTO.parseTimeSpentIfNeccessary(workLogDTO);
//        workLogDTO.setTimespent("34.45W");
//        WorkLogDTO.parseTimeSpentIfNeccessary(workLogDTO);
//    }
    
    public static WorkLogDTO initByRequestParams(HttpServletRequest request) {
        WorkLogDTO workLogDTO = new WorkLogDTO();
        workLogDTO.setLogdate(request.getParameter("workLogDate"));
        workLogDTO.setTimespent(request.getParameter("workLogDTOTimespent"));
        workLogDTO.setComments(request.getParameter("workLogDTOComments"));
        return workLogDTO;
    }
}
