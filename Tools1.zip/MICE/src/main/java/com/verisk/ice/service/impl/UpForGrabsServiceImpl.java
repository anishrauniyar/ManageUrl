/*
 * Date : 2016-05-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.IceDAO;
import com.verisk.ice.dao.OamDAO;
import com.verisk.ice.design.IceTicketListType;
import com.verisk.ice.design.OamTicketListType;
import com.verisk.ice.model.upforgrabs.UpForGrabsMyTeam;
import com.verisk.ice.model.upforgrabs.UpForGrabsSwitchWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import com.verisk.ice.service.TicketListService;
import com.verisk.ice.service.UpForGrabsService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UpForGrabsServiceImpl implements UpForGrabsService {

    private static final Logger LOG = LoggerFactory.getLogger(UpForGrabsServiceImpl.class.getName());

    @Override
    public UpForGrabsSwitchWrapper findUpForGrabsSwitchWrapperICE(DashboardFilterWrapper dashboardFilterWrapper) {

        UpForGrabsSwitchWrapper upForGrabsSwitchWrapper = new UpForGrabsSwitchWrapper();
        TicketListFilterWrapper ticketListFilterWrapper = new TicketListFilterWrapper();

        TicketListService ticketListService = new TicketListServiceImpl();
        IceDAO iceDAO = new IceDAO();

        ticketListFilterWrapper.setDashboardFilter(dashboardFilterWrapper.getDashboardFilter());
        ticketListFilterWrapper.setPageSwitcherDTO(dashboardFilterWrapper.getPageSwitcherDTO());
        upForGrabsSwitchWrapper.setAssignedToMe(ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, IceTicketListType.USER_ICE_TICKET_UP_FOR_GRABS.toString(), "ice"));
        if ("TEAM_MANAGER".equals(dashboardFilterWrapper.getDashboardFilter().getTeamRole())) {
            List<UpForGrabsMyTeam> grabsMyTeams = new ArrayList<>();
            List<Map<String, String>> teamUsers = iceDAO.findMyIceTeamUsers(dashboardFilterWrapper.getDashboardFilter().getUserid());
            for (Map<String, String> teamUser : teamUsers) {
                dashboardFilterWrapper.getDashboardFilter().setUserid(teamUser.get("userid"));
                UpForGrabsMyTeam teamUserInfo = new UpForGrabsMyTeam();
                teamUserInfo.setUserid(teamUser.get("userid"));
                teamUserInfo.setName(teamUser.get("name"));
                TicketListWrapper listWrapper = ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, IceTicketListType.USER_ICE_TICKET_UP_FOR_GRABS.toString(), "ice");
                teamUserInfo.setListWrapper(listWrapper);
                grabsMyTeams.add(teamUserInfo);
            }
            upForGrabsSwitchWrapper.setAssignedToMyTeamUsers(grabsMyTeams);
        } else {
            upForGrabsSwitchWrapper.setUpForGrabsTicketListWrapper(ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, IceTicketListType.UP_FOR_GRABS_ICE.toString(), "ice"));
        }
        iceDAO.takeDown();
        return upForGrabsSwitchWrapper;
    }

    @Override
    public UpForGrabsSwitchWrapper findUpForGrabsSwitchWrapperOAM(DashboardFilterWrapper dashboardFilterWrapper) {

        UpForGrabsSwitchWrapper upForGrabsSwitchWrapper = new UpForGrabsSwitchWrapper();
        TicketListFilterWrapper ticketListFilterWrapper = new TicketListFilterWrapper();

        TicketListService ticketListService = new TicketListServiceImpl();
        OamDAO oamDAO = new OamDAO();
        final String requestedUserId = dashboardFilterWrapper.getDashboardFilter().getUserid();

        ticketListFilterWrapper.setDashboardFilter(dashboardFilterWrapper.getDashboardFilter());
        ticketListFilterWrapper.setPageSwitcherDTO(dashboardFilterWrapper.getPageSwitcherDTO());
        upForGrabsSwitchWrapper.setAssignedToMe(ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, OamTicketListType.USER_OAM_TICKET_UP_FOR_GRABS.toString(), "oam"));
        if ("TEAM_MANAGER".equals(dashboardFilterWrapper.getDashboardFilter().getTeamRole())) {
            List<UpForGrabsMyTeam> grabsMyTeams = new ArrayList<>();
            List<Map<String, String>> teamUsers = oamDAO.findMyOamTeamUsers(dashboardFilterWrapper.getDashboardFilter().getUserid());
            
            teamUsers.add(new HashMap<String, String>() {
                {
                    put("userid", requestedUserId);
                    put("name", "Unassigned");
                }
            });
            
            for (Map<String, String> teamUser : teamUsers) {
                dashboardFilterWrapper.getDashboardFilter().setUserid(teamUser.get("userid"));
                UpForGrabsMyTeam teamUserInfo = new UpForGrabsMyTeam();
                
                teamUserInfo.setName(teamUser.get("name"));
                
                TicketListWrapper listWrapper;
                if (!"Unassigned".equals(teamUser.get("name"))) {
                    teamUserInfo.setUserid(teamUser.get("userid"));
                    listWrapper = ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, OamTicketListType.USER_OAM_TICKET_UP_FOR_GRABS.toString(), "oam");
                } else {
                    listWrapper = ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, OamTicketListType.UNASSIGNED_OAM_TICKET_UP_FOR_GRABS.toString(), "oam");
                }

                teamUserInfo.setListWrapper(listWrapper);
                grabsMyTeams.add(teamUserInfo);
            }
            upForGrabsSwitchWrapper.setAssignedToMyTeamUsers(grabsMyTeams);
        } else {
            upForGrabsSwitchWrapper.setUpForGrabsTicketListWrapper(ticketListService.findTicketListWithoutPagination(ticketListFilterWrapper, OamTicketListType.UP_FOR_GRABS_OAM.toString(), "oam"));
        }
        oamDAO.takeDown();
        return upForGrabsSwitchWrapper;
    }

}
