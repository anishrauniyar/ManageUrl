/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.DefectApplicationDTO;
import com.verisk.ice.model.DefectComponentDTO;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author i81324
 */
public final class DefectComponentDAO extends ConnectionBean implements CrudDAO<DefectComponentDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final DefectComponentDTO entity) {
        String insertSQL = "INSERT INTO OAM_CR_DEFECTCOMPONENT "
                + "(defcomponentname, defappid)"
                + " VALUES (?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getDefcomponentname());
            ps.setString(2, entity.getDefappid());
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public void update(String id, DefectComponentDTO entity) {
        String insertSQL = "UPDATE OAM_CR_DEFECTCOMPONENT SET "
                + "defcomponentname = ? "
                + "WHERE defcomponentid = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getDefcomponentname());
            ps.setString(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public DefectComponentDTO find(String id) {
    	DefectComponentDTO defectComponentDTO = new DefectComponentDTO();
        String sql = "SELECT * FROM OAM_CR_DEFECTCOMPONENT WHERE IS_DELETED='N'and defcomponentid='" + id + "'";
        if (getList(sql, "DefectComponentDAO#find(" + id + ")")) {
            if (moveNext()) {
            	defectComponentDTO.setDefappid(getData("defappid"));
            	defectComponentDTO.setDefcomponentid(getData("defcomponentid"));
            	defectComponentDTO.setDefcomponentname(getData("defcomponentname"));
            }
        }
        return defectComponentDTO;
    }

    public List<DefectComponentDTO> findAll(Map<String, String> filters) {
        List<DefectComponentDTO> defectComponentDTO = new ArrayList<>();
        String sql = "SELECT * FROM OAM_CR_DEFECTCOMPONENT WHERE 1=1 and IS_DELETED='N'and defappid="+filters.get("fDefAppId");
        if (filters != null) {
            sql += " AND defcomponentname LIKE '%" + filters.get("fComponentName") + "%'";
        }
        System.out.println("Filter:"+sql);
        if (getList(sql, "DefectComponentDAO#findAll()")) {
            while (moveNext()) {
            	defectComponentDTO.add(new DefectComponentDTO(getData("defappid"), getData("defcomponentid"), getData("defcomponentname")));
            }
        }
        return defectComponentDTO;
    }

    public boolean isDuplicateByAppName(String componentName) {
        String sql = "SELECT * FROM OAM_CR_DEFECTCOMPONENT WHERE  defcomponentname='" + componentName + "' ";
        if (getList(sql, "DefectComponentDAO#isDuplicateByAppName()")) {
            if (moveNext()) {
                return true;
            }
        }
        return false;
    }
    

    public boolean delete(String id) {
    	 String insertSQL = "UPDATE OAM_CR_DEFECTCOMPONENT SET "
                 + "is_deleted = ? "
                 + "WHERE defcomponentid = ?";
         try {
             setConnection();
             myConn.setAutoCommit(true);
             PreparedStatement ps = myConn.prepareStatement(insertSQL);
             ps.setString(1,"Y");
             ps.setString(2, id);
             ps.executeUpdate();
         } catch (Exception e) {
             //e.printStackTrace();
         }
         
         return true;
     }
}
