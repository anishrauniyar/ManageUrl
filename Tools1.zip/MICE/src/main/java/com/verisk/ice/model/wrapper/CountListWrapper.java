/*
 * Date : 2016-02-03
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.CountListDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CountListWrapper {

    private PageSwitcherDTO pageSwitcherDTO;
    /**
     * list of array with size 2 (array[0]->id & array[1]->description)
     */
    private List<CountListDTO> popupList;
}
