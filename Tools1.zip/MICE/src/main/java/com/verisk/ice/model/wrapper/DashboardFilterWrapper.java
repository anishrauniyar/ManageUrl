/*
 * Date : 2016-01-26
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DashboardFilterWrapper {

    public static void setDefaultPageSwitcherIfNeccessary(DashboardFilterWrapper dashboardFilterWrapper) {
        if (dashboardFilterWrapper != null && dashboardFilterWrapper.getPageSwitcherDTO() == null) {
            dashboardFilterWrapper.setPageSwitcherDTO(new PageSwitcherDTO());
        }
    }

    private PageSwitcherDTO pageSwitcherDTO;
    private DashboardFilterDTO dashboardFilter;
}
