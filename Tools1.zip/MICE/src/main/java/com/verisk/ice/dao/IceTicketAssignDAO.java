/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.IceTicketAssignDTO;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.wrapper.IceTicketAssignWrapper;
import com.verisk.ice.utils.DAOUtils;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class IceTicketAssignDAO extends ConnectionBean {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    public IceTicketAssignWrapper findAllICETicketAssignByUserId(DashboardFilterWrapper dashboardFilterWrapper) {
        IceTicketAssignWrapper activityUpdateWrapper = new IceTicketAssignWrapper();
        if (dashboardFilterWrapper != null && dashboardFilterWrapper.getPageSwitcherDTO() != null && dashboardFilterWrapper.getDashboardFilter() != null) {
            String rootQuery = rootQueryByUserId(dashboardFilterWrapper.getDashboardFilter().getUserid());
            //ADDING FILTER PARAMETES IN QUERY
            /*
                AND it.issuetypeid     
                AND c.clientid IS NOT NULL   
                AND cc.applicationid IS NOT NULL  
                AND Trunc(p.requestdate) 
                BETWEEN TO_DATE ('11/26/2015', 'mm/dd/yyyy') AND TO_DATE ('11/27/2015', 'mm/dd/yyyy')      
             */
            if (dashboardFilterWrapper.getDashboardFilter().getRequesttypeids() != null) {
                rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("it.issuetypeid", rootQuery, dashboardFilterWrapper.getDashboardFilter().getRequesttypeids().get("ice"));
            }
            //rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("c.clientid", rootQuery, dashboardFilterWrapper.getDashboardFilter().getClientids());
            rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("p.sourceid", rootQuery, dashboardFilterWrapper.getDashboardFilter().getAppids());
            if (dashboardFilterWrapper.getDashboardFilter().getDateRange() != null && !dashboardFilterWrapper.getDashboardFilter().getDateRange().trim().isEmpty()) {
                DashboardFilterDTO.separateStartAndEndDateByDaterange(dashboardFilterWrapper.getDashboardFilter());
                rootQuery += " AND Trunc(p.requestdate) BETWEEN TO_DATE('" + dashboardFilterWrapper.getDashboardFilter().getStartdate() + "', 'mm/dd/yyyy') AND TO_DATE ('" + dashboardFilterWrapper.getDashboardFilter().getEnddate() + "', 'mm/dd/yyyy') ";
            }
            //END
            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";
            String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
            PageSwitcherDTO pageSwitcherDTO = dashboardFilterWrapper.getPageSwitcherDTO();
            if (getList(countQuery, "ICETicketAssignDAO#findAllICETicketAssignByUserId(countQuery)")) {
                if (moveNext()) {
                    pageSwitcherDTO.setTotal(getData("TOTAL"));
                }
            }
            long startRow = 1L + (pageSwitcherDTO.getPageNo() - 1) * pageSwitcherDTO.getRowNo();
            long endRow = pageSwitcherDTO.getPageNo() * pageSwitcherDTO.getRowNo();
            actualFetchQuery += "  WHERE   b.ROWNO >= " + startRow + " AND b.ROWNO <= " + endRow;

            if (getList(actualFetchQuery, "ICETicketAssignDAO#findAllICETicketAssignByUserId(actualFetchQuery)")) {
                List<IceTicketAssignDTO> iceTicketAssignDTOs = new ArrayList<>();
                while (moveNext()) {
                    iceTicketAssignDTOs.add(new IceTicketAssignDTO(getData("pksource"), getData("issuetypename"), getData("AppName"), getData("clientname")));
                }
                activityUpdateWrapper.setIceTicketAssigns(iceTicketAssignDTOs);
                activityUpdateWrapper.setPageSwitcherDTO(pageSwitcherDTO);
            }
        }
        return activityUpdateWrapper;
    }

    private String rootQueryByUserId(String userId) {
        String query = "SELECT RANK() OVER (ORDER  BY p.pksource DESC nulls last) ROWNO ,"
                + "       p.requestcode,  "
                + "       p.pksource,  "
                + "       it.issuetypename,       "
                + "       To_char (p.requestdate, 'mm/dd/yyyy')  "
                + "       AS requestdate,  "
                + "       p.requestingperson,  "
                + "       rp.username  "
                + "       AS RequestingPersonDesc,  "
                + "       c.clientname,  "
                + "       cc.applicationid  "
                + "       AS AppID,  "
                + "       cc.applicationname  "
                + "       AS AppName,  "
                + "       p.requesttitle,  "
                + "       s.statusdesc,  "
                + "       e.userid,  "
                + "       e.username  "
                + "       AS User_Name,  "
                + "       To_char (Nvl(p.targetcompdate2, p.targetcompdate), 'mm/dd/yyyy')  "
                + "       AS  "
                + "       TargetCompDate,  "
                + "       To_char (p.actualcompdate, 'mm/dd/yyyy')  "
                + "       AS ActualCompDate,  "
                + "       p.requestpriority,  "
                + "       Nvl(crp.phasename, 'N/A')  "
                + "       AS PhaseName  "
                + "         "
                + "FROM   oam_rm_requestmanager p  "
                + "       left join (SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_users  "
                + "                  UNION  "
                + "                  SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_deletedusers) e  "
                + "              ON p.assignedto = e.userid  "
                + "       left join oam_clients cl  "
                + "              ON p.dataproviderid = cl.clientid  "
                + "       left join oam_rm_requeststatus s  "
                + "              ON p.statusid = s.statusid  "
                + "       left join oam_cr_issuetype it  "
                + "              ON p.requesttypeid = it.issuetypeid  "
                + "       left join (SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_users  "
                + "                  UNION  "
                + "                  SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_deletedusers) rp  "
                + "              ON p.requestingperson = rp.userid  "
                + "       left join oam_clients c  "
                + "              ON p.clientid = c.clientid  "
                + "       left join oam_clientapps cc  "
                + "              ON p.sourceid = cc.applicationid  "
                + "       left join oam_productionmanager npm  "
                + "              ON p.sourceid = npm.appid  "
                + "       left join (SELECT userid,  "
                + "                         username  "
                + "                  FROM   usr_users  "
                + "                  UNION  "
                + "                  SELECT userid,  "
                + "                         username  "
                + "                  FROM   usr_deletedusers) rpp  "
                + "              ON rpp.userid = npm.npmid  "
                + "       left join oam_cr_phases crp  "
                + "              ON p.phaseid = crp.phaseid  "
                + "WHERE  1 = 1  "
                + "       AND s.statusdesc NOT IN ( 'Dropped' )  "
                + "       AND e.userid ='" + userId + "'  "
                + "       AND p.parentrequestcode IS NULL  "
                + "       AND rp.username IS NOT NULL  ";
        return query;
    }
}
