/*
 * Date : 2016-02-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */

package com.verisk.ice.model;

import com.verisk.ice.design.DBDefination;
import com.verisk.ice.design.DataType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DefectApplicationDTO {

    @DBDefination(columnName = "defappid", dataType = DataType.VARCHAR2)
    private String defappid;
    @DBDefination(columnName = "defappname", dataType = DataType.VARCHAR2)
    private String defappname;
    @DBDefination(columnName = "shortname", dataType = DataType.VARCHAR2)
    private String shortname;
}
