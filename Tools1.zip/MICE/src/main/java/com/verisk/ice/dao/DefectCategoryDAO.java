/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.DefectCategoryDTO;
import com.verisk.ice.model.DefectComponentDTO;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;



public final class DefectCategoryDAO extends ConnectionBean implements CrudDAO<DefectCategoryDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final DefectCategoryDTO entity) {
        String insertSQL = "INSERT INTO OAM_CR_DEFECTCOMPONENT "
                + "(defcomponentname, defappid)"
                + " VALUES (?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            //ps.setString(1, entity.getDefcomponentname());
            //ps.setString(2, entity.getDefappid());
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public void update(String id, DefectCategoryDTO entity) {
        String insertSQL = "UPDATE OAM_CR_DEFECTCOMPONENT SET "
                + "defcomponentname = ? "
                + "WHERE defcomponentid = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            //ps.setString(1, entity.getDefcomponentname());
           // ps.setString(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

  
    public DefectCategoryDTO find(String id) {
    	DefectCategoryDTO defectCategoryDTO = new DefectCategoryDTO();
        String sql = "SELECT * FROM OAM_CR_DEFECTCATEGORY WHERE IS_DELETED='N' ORDER BY DEFCATEGORYNAME ASC";
        if (getList(sql, "DefectCategoryDAO#find(" + id + ")")) {
            if (moveNext()) {
            	defectCategoryDTO.setDefcategoryid(getData("DEFCATEGORYID"));
            	defectCategoryDTO.setDefcategoryname(getData("DEFCATEGORYNAME"));
            	//defectCategoryDTO.setDefcomponentid(getData("defcomponentid"));
            	//defectCategoryDTO.setDefcomponentname(getData("defcomponentname"));
            }
        }
        return defectCategoryDTO;
    }
    
    public List<DefectCategoryDTO> findAll(Map<String, String> filters) {
        List<DefectCategoryDTO> defectCategoryDTO = new ArrayList<>();
        String sql = "SELECT * FROM OAM_CR_DEFECTCATEGORY WHERE IS_DELETED='N' ORDER BY DEFCATEGORYNAME ASC";
         if (filters != null) {
            sql += " AND DEFCATEGORYNAME LIKE '%" + filters.get("fDEFCATEGORYNAME") + "%'";
        }
        System.out.println("Filter:"+sql);
        if (getList(sql, "DefectCategoryDAO#findAll()")) {
            while (moveNext()) {
            	defectCategoryDTO.add(new DefectCategoryDTO(getData("DEFCATEGORYID"), getData("DEFCATEGORYNAME")));
            	
            }
        }
        return defectCategoryDTO;
    }



    /*public boolean isDuplicateByAppName(String componentName) {
        String sql = "SELECT * FROM OAM_CR_DEFECTCOMPONENT WHERE  defcomponentname='" + componentName + "' ";
        if (getList(sql, "DefectComponentDAO#isDuplicateByAppName()")) {
            if (moveNext()) {
                return true;
            }
        }
        return false;
    }
    

    public boolean delete(String id) {
    	 String insertSQL = "UPDATE OAM_CR_DEFECTCOMPONENT SET "
                 + "is_deleted = ? "
                 + "WHERE defcomponentid = ?";
         try {
             setConnection();
             myConn.setAutoCommit(true);
             PreparedStatement ps = myConn.prepareStatement(insertSQL);
             ps.setString(1,"Y");
             ps.setString(2, id);
             ps.executeUpdate();
         } catch (Exception e) {
             //e.printStackTrace();
         }
         
         return true;
     }*/
}
