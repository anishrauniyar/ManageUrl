/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.DefectDTO;
import com.verisk.ice.utils.DTOUtils;
import java.sql.PreparedStatement;

/**
 *
 * @author i81324
 */
public final class DefectDAO extends ConnectionBean implements CrudDAO<DefectDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final DefectDTO entity) {
        String insertSQL = "INSERT INTO OAM_CR_DEFECT "
                + "( requestcode, application, component, impactedcomponent, requestdescription,category,subtype,rootcause)"
                + " VALUES (?, ?, ?, ?, ?,?,?,?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getRequestcode());
            ps.setString(2, entity.getApplication());
            ps.setString(3, entity.getComponent());
            ps.setString(4, entity.getImpactedcomponent());
            ps.setString(5, entity.getRequestdescription());
            ps.setString(6, entity.getCategory());
            ps.setString(7, entity.getSubType());
            ps.setString(8, entity.getRootCause());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(String requestCode, DefectDTO entity) {
        String insertSQL = "UPDATE OAM_CR_DEFECT SET "
                + "application = ?, component = ?, impactedcomponent = ?, requestdescription = ?, category = ?, subtype = ?, rootcause = ?  "
                + "WHERE requestcode = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getApplication());
            ps.setString(2, entity.getComponent());
            ps.setString(3, entity.getImpactedcomponent());
            ps.setString(4, entity.getRequestdescription());
            ps.setString(5, entity.getCategory());
            ps.setString(6, entity.getSubType());
            ps.setString(7, entity.getRootCause());
            ps.setString(8, requestCode);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public DefectDTO find(String requestCode) {
        DefectDTO defectDTO = new DefectDTO();
        //String sql = "SELECT DEFID, REQUESTCODE, APPLICATION, COMPONENT, IMPACTEDCOMPONENT, REQUESTDESCRIPTION,DEFAPPNAME FROM OAM_CR_DEFECT d left JOIN OAM_CR_DEFECTAPPLICATION a ON  a.DEFAPPID=d.APPLICATION  WHERE d.requestcode='"+requestCode+"'";
        String sql = ""
        		+ "SELECT d.defid, "
        		+ "       requestcode, "
        		+ "       application, "
        		+ "       component, "
        		+ "       category, "
        		+ "       subtype, "
        		+ "       rootcause, "
        		+ "       impactedcomponent, "
        		+ "       requestdescription, "
        		+ "       defappname, "
        		+ "       b.defcomponentname, "
        		+ "       e.defcategoryname, "
        		+ "       f.defname as defsubtypename, "
        		+ "       c.defcomponentname AS impactcomponentname "
        		+ "FROM   oam_cr_defect d "
        		+ "       left join oam_cr_defectapplication a "
        		+ "              ON a.defappid = d.application "
        		+ "       left JOIN  oam_cr_defectcomponent b "
        		+ "              ON b.defcomponentid = d.component "
        		+ "       left JOIN  oam_cr_defectcomponent c "
        		+ "              ON c.defcomponentid = d.impactedcomponent "
        		+ "       left JOIN  oam_cr_defectcategory e "
        		+ "              ON e.defcategoryid = d.category "
        		+ "       left JOIN  oam_cr_defectsubtype f "
        		+ "              ON f.defid = d.subtype "
        		+ "WHERE  d.requestcode = '"+requestCode+"'";
        
        System.out.println("defectListing......."+sql);
        if (getList(sql, "DefectDAO#find(" + requestCode + ")")) {
            if (moveNext()) {
                defectDTO.setApplication(getData("application"));
                defectDTO.setComponent(getData("component"));
                defectDTO.setImpactedcomponent(getData("impactedcomponent"));
                defectDTO.setDefid(getData("defid"));
                defectDTO.setRequestcode(getData("requestcode"));
                defectDTO.setApplicationName(getData("defappname"));
                defectDTO.setRequestdescription(DTOUtils.ifNullRetrunEmptyString(getData("requestdescription")));
                defectDTO.setComponentName(getData("defcomponentname"));
                defectDTO.setImpactedcomponentName(getData("impactcomponentname"));
                defectDTO.setCategory(getData("category"));
                defectDTO.setSubType(getData("subtype"));
                defectDTO.setRootCause(getData("rootcause"));
                defectDTO.setCategoryName(getData("defcategoryname"));
                defectDTO.setSubTypeName(getData("defsubtypename"));
            }
        }
        return defectDTO;
    }

}
