/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.ActivityUpdateDTO;
import com.verisk.ice.model.wrapper.ActivityUpdateWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.PageSwitcherDTO;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class ActivityUpdateDAO extends ConnectionBean implements CrudDAO<ActivityUpdateDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(ActivityUpdateDTO entity) {
        String SQL = "INSERT INTO OAM_CR_ACTIVITYUPDATE "
                + " ( loggedtime,pksource, detail, username)"
                + " VALUES (SYSDATE, ?, ?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, entity.getPksource());
            ps.setString(2, entity.getDetail());
            ps.setString(3, entity.getUsername());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void update(String id, ActivityUpdateDTO entity) {
    }

    @Override
    public ActivityUpdateDTO find(String id) {
        return null;
    }

    public ActivityUpdateWrapper findAllLatestActivityUpdate(DashboardFilterWrapper dashboardFilterWrapper) {
        ActivityUpdateWrapper activityUpdateWrapper = new ActivityUpdateWrapper();
        if (dashboardFilterWrapper != null && dashboardFilterWrapper.getPageSwitcherDTO() != null) {
            String rootQuery = " SELECT RANK() OVER (ORDER BY LOGGEDTIME DESC ) ROWNO ,  a.*, "
                    + "       CASE "
                    + "              WHEN ( SYSDATE - loggedtime)*86400 < 15 THEN  ' just now' "
                    + "              WHEN ( SYSDATE - loggedtime)*86400 < 60 THEN round((SYSDATE - loggedtime)*86400) ||' seconds ago' "
                    + "              WHEN ( SYSDATE - loggedtime)*1440 < 60 THEN round((SYSDATE - loggedtime)*1440)  ||' minutes ago' "
                    + "              WHEN ( SYSDATE - loggedtime)*24 < 24 THEN round((SYSDATE - loggedtime)*24) ||' hours ago' "
                    + "              WHEN ( SYSDATE - loggedtime)*1 < 5 THEN round(SYSDATE - loggedtime) ||' days ago' "
                    + "              ELSE to_char(loggedtime,'DD/Mon/YYYY HH24:MI') "
                    + "       END timeelapsed,"
                    + " Nvl( SubStr( REGEXP_SUBSTR(detail,"
                    + "                '[^@]+@'),0,Length (REGEXP_SUBSTR(detail,"
                    + "                '[^@]+@'))-1 ),detail) AS description "
                    + " FROM OAM_CR_ACTIVITYUPDATE a WHERE  Upper(a.detail) LIKE '%CHANGED THE PHASE%' and ( a.SKIPUSERIDS NOT LIKE '%:" + dashboardFilterWrapper.getDashboardFilter().getUserid() + "%' OR a.SKIPUSERIDS IS NULL )";
            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";
            String countQuery = "SELECT Count(*) TOTAL FROM ( " + rootQuery + " ) b";
            PageSwitcherDTO pageSwitcherDTO = dashboardFilterWrapper.getPageSwitcherDTO();
            if (getList(countQuery, "ActivityUpdateDAO#findAllLatestActivityUpdate(countQuery)")) {
                if (moveNext()) {
                    pageSwitcherDTO.setTotal(getData("TOTAL"));
                }
            }
            long startRow = 1L + (pageSwitcherDTO.getPageNo() - 1) * pageSwitcherDTO.getRowNo();
            long endRow = pageSwitcherDTO.getPageNo() * pageSwitcherDTO.getRowNo();
            actualFetchQuery += "  WHERE   b.ROWNO >= " + startRow + " AND b.ROWNO <= " + endRow;

            if (getList(actualFetchQuery, "ActivityUpdateDAO#findAllLatestActivityUpdate(actualFetchQuery)")) {
                List<ActivityUpdateDTO> activityUpdateDTOs = new ArrayList<>();
                while (moveNext()) {
                    activityUpdateDTOs.add(new ActivityUpdateDTO(getData("ACTIVITYUPDATEID"), getData("LOGGEDTIME"), getData("description"), getData("timeelapsed"), getData("USERNAME"), getData("PKSOURCE")));
                }
                activityUpdateWrapper.setActivityUpdates(activityUpdateDTOs);
                activityUpdateWrapper.setPageSwitcherDTO(pageSwitcherDTO);
            }

            System.out.println("IceTicketListType#findAllLatestActivityUpdate()=>" + rootQuery);
        }
        return activityUpdateWrapper;
    }

    public void skipActivityUpdate(String activityUpdateId, String userId) {
        String SQL = "UPDATE OAM_CR_ACTIVITYUPDATE SET SKIPUSERIDS=SKIPUSERIDS || ':' || ? WHERE ACTIVITYUPDATEID=? ";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, userId);
            ps.setString(2, activityUpdateId);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public List<ActivityUpdateDTO> findAllHistoryLogByRequestCode(Map<String, String> historyFilterWrapper) {
        List<ActivityUpdateDTO> activityUpdateDTOs = new ArrayList<>();
        if (historyFilterWrapper != null && historyFilterWrapper.get("requestCode") != null) {
            String pksource = historyFilterWrapper.get("requestCode").substring(3);
            String rootQuery = " SELECT RANK() OVER (ORDER BY LOGGEDTIME DESC ) ROWNO ,  a.* "
                    + " FROM OAM_CR_ACTIVITYUPDATE a WHERE  a.PKSOURCE = '" + pksource + "'";
            String actualFetchQuery = " SELECT * FROM ( " + rootQuery + " ) b";

            if (getList(actualFetchQuery, "ActivityUpdateDAO#findAllHistoryLogByRequestCode(actualFetchQuery)")) {

                while (moveNext()) {
                    activityUpdateDTOs.add(new ActivityUpdateDTO(getData("ACTIVITYUPDATEID"), getData("LOGGEDTIME"), getData("detail"),
                            /*getData("timeelapsed")*/ "", getData("USERNAME"), getData("PKSOURCE")));
                }

            }
        }
        return activityUpdateDTOs;
    }

}
