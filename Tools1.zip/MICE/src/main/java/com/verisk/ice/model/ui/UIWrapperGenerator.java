/*
 * Date : 2016-00-12 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.UILayoutDAO;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum UIWrapperGenerator {

    INTANCE;

    private final UISpecification[] defectLeftSideFieldSpecifications = new UISpecification[]{
        UISpecification.requestDate
    };

    private final UILayoutDAO uILayoutDAO;

    private UIWrapperGenerator() {
        this.uILayoutDAO = DAOFactory.INSTANCE.getUiLayoutDAO();
    }

    private UIWrapper newEmptyWrapper(UISpecification[] leftSideFieldSpecifications, UISpecification[] rightSideFieldSpecifications) {
        UIWrapper wrapper = new UIWrapper();

        UILayout layout = new UILayout();

        /*Fill Left Side Fields*/
        List<UIField> leftFields = new ArrayList<>();
        fillUIFieldList(leftFields, leftSideFieldSpecifications);

        /*Fill Right Side Fields*/
        List<UIField> rightFields = new ArrayList<>();
        fillUIFieldList(rightFields, rightSideFieldSpecifications);

        /*Fill Up Data*/
        layout.setLeftSide(leftFields);
        layout.setRightSide(rightFields);

        wrapper.setUi(layout);

        return wrapper;
    }

    private void fillUIFieldList(List<UIField> uIFields, UISpecification[] specifications) {
        for (UISpecification spec : specifications) {
            UIField field = new UIField();

            field.setUniqueId(spec.toString());
            field.setLabel(spec.getLabel());
            field.setType(spec.getType().toString());

            if (spec.getType().equals(UIFieldType.singleSelect) && spec.isRefreshDefaultValues()) {
                field.setDefaultValues(uILayoutDAO.findAllOptionsBySQLQuery(spec.getDefaultValuesFetchSQLQuery()));
            }
            uIFields.add(field);
        }
    }

    public UIWrapper emptyDefectWrapper() {
        return newEmptyWrapper(defectLeftSideFieldSpecifications, defectLeftSideFieldSpecifications);
    }
}
