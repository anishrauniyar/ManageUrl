/*
 * Date : 2016-00-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.wrapper;

import com.verisk.ice.model.FilterKey;
import com.verisk.ice.model.IssueLogFilterDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class IssueLogFilterWrapper {

    public static void setDefaultPageSwitcherIfNeccessary(IssueLogFilterWrapper issueLogFilterWrapper, PageSwitcherDTO.PageSwitcherDTOType pageSwitcherDTOType) {
        if (issueLogFilterWrapper != null && issueLogFilterWrapper.getPageSwitcherDTO() == null) {
            issueLogFilterWrapper.setPageSwitcherDTO(PageSwitcherDTO.getInstanceOfPageSwitcherDTO(pageSwitcherDTOType));
        }
    }

    public static final Comparator<Map<String, String>> COMPARATOR_ENABLE_FOLLOWUP = new Comparator<Map<String, String>>() {
        @Override
        public int compare(Map<String, String> o1, Map<String, String> o2) {
            return o1.get("requestCode").compareTo(o2.get("requestCode"));
        }
    };

    public static void parseClientIdNamesIfNeccessary(IssueLogFilterWrapper issueLogFilterWrapper) {
        if (issueLogFilterWrapper != null && issueLogFilterWrapper.getIssueLogFilterDTO() != null && issueLogFilterWrapper.getIssueLogFilterDTO().getClientIds() != null) {
            String[] clientIdNames = issueLogFilterWrapper.getIssueLogFilterDTO().getClientIds();
            String[] clientIds = new String[clientIdNames.length];
//            String[] clientNames = new String[clientIdNames.length];
            for (int i = 0; i < clientIdNames.length; i++) {
                String[] split = clientIdNames[i].split("@");
                clientIds[i] = split[0];
//                clientNames[i] = split[1];
            }
            issueLogFilterWrapper.getIssueLogFilterDTO().setClientIds(clientIds);
        }
    }
    private boolean isNotXLSExportMode = true;
    private IssueLogFilterDTO issueLogFilterDTO;
    private List<FilterKey> filterKeys;
    private PageSwitcherDTO pageSwitcherDTO;

//    /*
//        Key - pick request code to show
//        Value - comment for individual followup
//     */
    private List<Map<String, String>> enableSubFollowsWithComments;
    private String logViewMode;

    public static Map<String, String> getFollowUpCommentByBinarySearch(List<Map<String, String>> enableSubFollowsWithComments, String key) {
        try {
            if (enableSubFollowsWithComments == null || key == null) {
                return null;
            }
            Map<String, String> searchKey = new HashMap<>();
            searchKey.put("requestCode", key);
            int index = Collections.binarySearch(enableSubFollowsWithComments, searchKey, COMPARATOR_ENABLE_FOLLOWUP);
            if (index < 0) {
                return null;
            }
            return enableSubFollowsWithComments.get(index);
        } catch (Exception e) {
            System.out.println("com.verisk.ice.model.wrapper.IssueLogFilterWrapper.getFollowUpCommentByBinarySearch()->" + e.getMessage());
            return null;
        }
    }
}
