/*
 * Date : 2016-00-15 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Setter
@Getter
public class IssueLogDTO {
    
    private String RequestType;
    private String DateOpened;
    private String Group;
    private String Payer;
    private String externalID;
    private String Description;
    private String ClientNotes;
    private String Status;
    private String Priority;
    private String AppTargetDate;
    private String HighLevelOwnerShip;
    private String DataOpsStatus;
    private String IndividualTaskOwner;
    private String ICE;
    private String OAM;    
    private String ImplCompletionDate;
    private String followUpType = "PRIMARY";
    private String followUpLabel;
    private String requestCode;
    private List<FollowUpIssueLog> followUpIssueLogs;
    
    public static IssueLogDTO getIssueLogDTOForFollowUp() {
        IssueLogDTO data = new IssueLogDTO();
        data.setRequestType("");
        data.setDateOpened("");
        data.setGroup("");
        data.setPayer("");
        data.setDescription("");
        data.setStatus("");
        data.setPriority("");
        data.setAppTargetDate("");
        data.setHighLevelOwnerShip("");
        data.setDataOpsStatus("");
        data.setIndividualTaskOwner("");
        data.setICE("");
        data.setOAM("");
        data.setExternalID("");
        data.setImplCompletionDate("");
        data.setClientNotes("");
        return data;
    }
}
