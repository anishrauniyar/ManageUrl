/*
 * Date : 2016-00-08 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao;

import com.d2hawkeye.util.velocity.MailMessageModel;
import com.d2hawkeye.util.velocity.RequestMailMessage;
import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.phaseswitch.OamPhaseDetail;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class OamDAO extends ConnectionBean {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    public List<String[]> findAllOamLabelIdAndLabelName() {
        String sql = "SELECT * FROM hawkeyeoam.oam_messagelabel WHERE ISDELETED = 'N'";
        List<String[]> list = new ArrayList<>();
        if (getList(sql, "OamDAO#findAllOamLabelIdAndLabelName()")) {
            while (moveNext()) {
                list.add(new String[]{getData("LABELID"), getData("MESSAGE")});
            }
        }
        return list;
    }

    public List<Map<String, String>> findMyOamTeamUsers(String userId) {
        List<Map<String, String>> managerTeamUsers = new ArrayList<>();
        String sql = "SELECT u.userid as userid, u.username as username"
                + " FROM usr_users u "
                + " where u.userid IN ("
                + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryIN(userId, "OAM")
                + " ) AND  u.userid !='" + userId + "'"
                + "  ORDER BY u.username ";

        if (getList(sql, "OamDAO#findMyOamTeamUsers()")) {
            while (moveNext()) {
                Map<String, String> object = new HashMap<>();
                object.put("userid", getData("userid"));
                object.put("name", getData("username"));
                managerTeamUsers.add(object);
            }
        }
        return managerTeamUsers;
    }

    public boolean changeAssignee(Map<String, String> changeObj) {
        boolean isSuccess = false;
        String sql = "UPDATE oam_productionmanager SET assignedto = ? WHERE appid=?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(sql);
            ps.setString(1, changeObj.get("assignedto"));
            ps.setString(2, changeObj.get("appid"));
            ps.executeUpdate();

            Map<String, String> messageObject = new HashMap<>();
            messageObject.put("COMMENTS", "Assignee changed - Phase: " + changeObj.get("phase"));
            messageObject.put("POSTEDBY", changeObj.get("seesionUserId"));
            messageObject.put("APPID", changeObj.get("appid"));
            messageObject.put("CLIENTID", changeObj.get("client"));
            messageObject.put("ASSIGNEDTO", changeObj.get("assignedto"));
            this.insertLogOnOAMValueChange(messageObject);
            isSuccess = true;
        } catch (Exception e) {
            //e.printStackTrace();
        }
        return isSuccess;
    }

    public List<OamPhaseDetail> findOamPhasesLazy() {
        List<OamPhaseDetail> oamPhaseDetails = new ArrayList<>();
        String sql = "SELECT DISTINCT PHASECODE, PHASEORDER, PHASEDESC FROM oam_pm_phases ORDER BY PHASEORDER  ASC";
        if (getList(sql, "OamDAO#findOamPhases()")) {
            while (moveNext()) {
                OamPhaseDetail oamPhaseDetail = new OamPhaseDetail();
                oamPhaseDetail.setPhaseCode(getData("PHASECODE"));
                oamPhaseDetail.setPhaseName(getData("PHASEDESC"));
                oamPhaseDetail.setPhaseOrder(getData("PHASEORDER"));
                oamPhaseDetails.add(oamPhaseDetail);
            }
        }
        return oamPhaseDetails;
    }

    public String findOamPhaseDescByPhaseCode(String phaseCode) {
        String sql = "SELECT DISTINCT PHASEDESC FROM oam_pm_phases where PHASECODE='" + phaseCode + "'";
        if (getList(sql, "OamDAO#findOamPhaseDescByPhaseCode(" + phaseCode + ")")) {
            if (moveNext()) {
                return getData("PHASEDESC");
            }
        }
        return "N/A";
    }

    public boolean insertLogOnOAMValueChange(Map<String, String> messageObject) {
        boolean isSuccess = false;
        String insertSQL = "insert into OAM_PRODUCTIONMANAGERMESSAGES ( COMMENTS,  POSTEDBY, POSTEDON,CLIENTID, APPID, LABELID, ASSIGNEDTO, STATUS, UPDATEDON)"
                + " VALUES (?, ? , SYSDATE,?, ?, '720', ?,'8', SYSDATE)";
        System.out.println("INSERT OAM:" + insertSQL);
        System.out.println("INSERT OAM:" + messageObject.get("COMMENTS") + ":" + messageObject.get("POSTEDBY") + ":" + (messageObject.get("APPID")).substring(0, 3));
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, messageObject.get("COMMENTS"));
            ps.setString(2, messageObject.get("POSTEDBY"));
            ps.setString(3, messageObject.get("CLIENTID"));
            ps.setString(4, messageObject.get("APPID"));
            ps.setString(5, messageObject.get("ASSIGNEDTO"));
            ps.executeUpdate();
            isSuccess = true;
        } catch (Exception e) {
            System.out.println("com.verisk.ice.dao.OamDAO.insertLogOnOAMValueChange()->" + e.getMessage());
        } finally {

        }
        return isSuccess;
    }

    public void setVectorTOEmailAddressAssignedTo(Vector sendMail_ToList, String appId) {
        String sql = "SELECT DISTINCT usr.email, usr.username FROM "
                + "OAM_RM_REQUESTMANAGER rm, USR_USERS usr "
                + "WHERE REQUESTCODE='" + appId + "' AND (usr.userid = rm.REQUESTINGPERSON OR usr.userid=rm.ASSIGNEDTO)";
        if (getList(sql, "IceDAO#getToEmailAddress()")) {
            while (moveNext()) {
                String toUser = getData("username") + "<" + getData("email") + ">";
                if (!sendMail_ToList.contains(toUser)) {
                    sendMail_ToList.addElement(toUser);
                }
            }
        }
    }

    public Map<String, String> appendMessageModels(RequestMailMessage mailMessage, Map<String, String> values) {
        Map<String, String> map = new HashMap<>();
        String sql = "SELECT p.appid,  "
                + "       app.applicationname,  "
                + "       p.phasecode,  "
                + "       phase.phasedesc,  "
                + "       To_char(p.targetdate, 'MM/DD/YYYY') AS targetdate,  "
                + "       Substr(Trim(p.comment_), 0, 60)     AS commentdesc,  "
                + "       p.assignedto                        AS assigneeid,  "
                + "       rp.username                         AS assignee  "
                + "FROM   oam_productionmanager p  "
                + "       left join oam_pm_phases phase  "
                + "              ON p.phasecode = phase.phasecode  "
                + "       left join oam_clientapps app  "
                + "              ON p.appid = app.applicationid  "
                + "       left join (SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_users  "
                + "                  UNION  "
                + "                  SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_deletedusers) rp  "
                + "              ON p.assignedto = rp.userid  "
                + "WHERE  1 = 1  "
                + "       AND inproduction = 'Y'  "
                + "       AND p.appid = '" + values.get("appid") + "'  "
                + "ORDER  BY appid ASC ";
        System.out.println("PRE-Phase:" + values.get("prevPhaseCode"));
        String prevPhaseDesc = checkEmptyAndNull(findOamPhaseDescByPhaseCode(values.get("prevPhaseCode")));
        if (getList(sql, "OamDAO#appendMessageModels()")) {
            if (moveNext()) {
                map.put("applicationname", getData("applicationname"));
                map.put("phasecode", getData("phasecode"));
                map.put("phasedesc", getData("phasedesc"));
                map.put("assigneeid", getData("assigneeid"));
                if ("N/A".equals(prevPhaseDesc)) {
                    prevPhaseDesc = map.get("phasedesc");
                }
                mailMessage.setDearPerson(checkEmptyAndNull(getData("assignee")));
                mailMessage.getMailMessageModels().add(new MailMessageModel("Application ID", checkEmptyAndNull(getData("appid")), null, null));
                mailMessage.getMailMessageModels().add(new MailMessageModel("Application Name", checkEmptyAndNull(map.get("applicationname")), null, null));
                mailMessage.getMailMessageModels().add(new MailMessageModel("Target Date", checkEmptyAndNull(getData("targetdate")), null, null));
                mailMessage.getMailMessageModels().add(new MailMessageModel("Previous Phase", checkEmptyAndNull(prevPhaseDesc), null, null));
                mailMessage.getMailMessageModels().add(new MailMessageModel("Current Phase", checkEmptyAndNull(map.get("phasedesc")), null, null));
            }
        }
        return map;
    }

    public String checkEmptyAndNull(String input) {
        if (input == null || input.isEmpty() || input.equalsIgnoreCase("-1")) {
            return "N/A";
        } else {
            return input;
        }
    }

}
