/*
 * Date : 2016-00-23 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class FollowUpIssueLog {
    
    private String followUpType;
    private String followUpLabel;
    private String requestCode;
    private String parentRequestCode;
    private String description;
    private String requestDate;
}
