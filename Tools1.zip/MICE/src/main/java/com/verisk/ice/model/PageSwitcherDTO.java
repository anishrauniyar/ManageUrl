/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PageSwitcherDTO {

	public enum PageSwitcherDTOType {
		DASHBOARD_VIEW, TABLE_LIST_VIEW, GRID_LIST_VIEW;

	}

	private int pageNo = 1;
	private int rowNo = 10;
	private String total;
	private int[] defaultRows = new int[] { 10, 20, 30, 40, 50 };

	public static PageSwitcherDTO getInstanceOfPageSwitcherDTO(PageSwitcherDTOType pageSwitcherDTOType) {
		if (pageSwitcherDTOType == null) {
			return new PageSwitcherDTO();
		}
		switch (pageSwitcherDTOType) {
		case DASHBOARD_VIEW:
			return new PageSwitcherDTO();
		case TABLE_LIST_VIEW:
			return new PageSwitcherDTO(1, 50, null, new int[] { 50, 100, 150, 200, 250, 300 });
		case GRID_LIST_VIEW:
			return new PageSwitcherDTO(1, 20, null, new int[] { 20, 40, 60, 80, 100, 120 });
		}
		return new PageSwitcherDTO();
	}

}
