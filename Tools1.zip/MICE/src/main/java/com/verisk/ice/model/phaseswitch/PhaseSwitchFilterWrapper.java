/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PhaseSwitchFilterWrapper {

    private DashboardFilterDTO dashboardFilter;
    /*
        'requesttypeid@phase' -> respective page switch DTO
     */
    private Map<String, PageSwitcherDTO> pageSwitcherDTOMapByRequestTypeIdAndPhase;

    private boolean byme;
    private boolean byteam;

    public static boolean isPageSwitcherDTOMapIsNotLoaded(PhaseSwitchFilterWrapper phaseSwitchFilterWrapper) {
        return phaseSwitchFilterWrapper == null || phaseSwitchFilterWrapper.getPageSwitcherDTOMapByRequestTypeIdAndPhase() == null;
    }

    public static String genKeyByRequestTypeIdAndPhaseId(String requesttypeid, String phaseid) {
        return "R_" + requesttypeid + "_P_" + phaseid;
    }
}
