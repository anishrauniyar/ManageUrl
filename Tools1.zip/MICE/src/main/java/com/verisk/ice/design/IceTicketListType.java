/*
 * Date : 2016-02-29
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.design;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.QuerySpecification;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.utils.AppConstants;
import com.verisk.ice.utils.DAOUtils;

import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum IceTicketListType {

    /*
    Note: Before change enum constants please see the method #getRootQueryByTicketListType(...)
    Warnning:
        -> OVERALL
        -> MYTICKET
        -> MYTEAM
    - Starting these word enum  are use carefully here
    - help: please see the method : getRootQueryByTicketListType(...) for 
     */
    //
    APPLY_FILTER_IN_LANDING_PAGE("All With Filter", "", "", true),
    /*OVERALL*/
    OVERALL_ICE("All Tickets", "", "", false),
    OVERALL_ICE_OPEN("All Open Tickets", " AND p.statusid = '1' ", "", true),
    OVERALL_ICE_COMPLETED("All Completed Tickets", " AND p.statusid = '4' ", "", true),
    OVERALL_ICE_PAST_DUE("All Past Due Tickets", " AND TRUNC(Nvl(p.targetcompdate2, p.targetcompdate)) < TRUNC(SYSDATE)  AND p.statusid = '1' ", "", true),
    OVERALL_ICE_DUE_TODAY("All Due Today Tickets", " AND TRUNC(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(SYSDATE)  AND p.statusid = '1' ", "", true),
    OVERALL_ICE_CURRENT_AT_RISK("All Current At Risk Tickets", " AND (Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(ADD_WORKING_DAYS('1', SYSDATE))   or Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(ADD_WORKING_DAYS('2', SYSDATE)))  AND p.statusid = '1' ", "", true),
    OVERALL_ICE_FUTURE("All Future Tickets", " AND  Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) > TRUNC(ADD_WORKING_DAYS('2', SYSDATE)) AND p.statusid = '1' ", "", true),
    /*MYTEAM*/
    MYTEAM_PAST_DUE("My Team Past Due Tickets", " AND TRUNC(Nvl(p.targetcompdate2, p.targetcompdate)) < TRUNC(SYSDATE) AND p.statusid = '1'  ", "", true),
    MYTEAM_DUE_TODAY("My Team Due Today Tickets", " AND TRUNC(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(SYSDATE) AND p.statusid = '1' ", "", true),
    MYTEAM_TOTAL("My Team Total Tickets", " AND p.statusid = '1' ", "", true),
    MYTEAM_CURRENT_AT_RISK("My Team Current At Risk Tickets", " AND (Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(ADD_WORKING_DAYS('1', SYSDATE)) or Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(ADD_WORKING_DAYS('2', SYSDATE))) AND p.statusid = '1' ", "", true),
    MYTEAM_FUTURE("My Team Future Tickets", " AND  Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) > TRUNC(ADD_WORKING_DAYS('2', SYSDATE)) AND p.statusid = '1' ", "", true),
    /*MYTICKET*/
    MYTICKET_ICE_OPEN("My Open Tickets", " AND p.statusid = '1' ", "", true),
    MYTICKET_ICE_PAST_DUE("My Past Due Tickets", " AND TRUNC(Nvl(p.targetcompdate2, p.targetcompdate)) < TRUNC(SYSDATE)  AND p.statusid = '1' ", "", true),
    MYTICKET_ICE_DUE_TODAY("My Due Today Tickets", " AND TRUNC(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(SYSDATE)  AND p.statusid = '1' ", "", true),
    MYTICKET_ICE_CURRENT_AT_RISK("My Current At Risk Tickets", " AND (Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(ADD_WORKING_DAYS('1', SYSDATE)) or Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) = TRUNC(ADD_WORKING_DAYS('2', SYSDATE)))   AND p.statusid = '1' ", "", true),
    MYTICKET_ICE_FUTURE("My Future Tickets", " AND Trunc(Nvl(p.targetcompdate2, p.targetcompdate)) > TRUNC(ADD_WORKING_DAYS('2', SYSDATE))   AND p.statusid = '1' ", "", true),
    /*OTHERS*/
    MYTICKET_PHASE_SWITCH("My Tickets for Phase Switch", " AND p.statusid = '1' ", "", false),
    MYTEAM_PHASE_SWITCH("My Team Tickets for Phase Switch", " AND p.statusid = '1' ", "", false),
    UP_FOR_GRABS_ICE("Tickets for Up For Grabs", " AND p.statusid = '1' ", "  ORDER  BY t.targetcompdate ASC nulls last, t.priority ASC nulls last, t.pksource DESC nulls last  ", false),
    USER_ICE_TICKET_UP_FOR_GRABS("My Open Tickets", " AND p.statusid = '1' ", "  ORDER  BY t.targetcompdate ASC nulls last, t.priority ASC nulls last, t.pksource DESC nulls last  ", false),
    UNASSIGNED_ICE_TICKET_UP_FOR_GRABS("My Unassigned Open Tickets", " AND p.statusid = '1' ", "  ORDER  BY t.targetcompdate ASC nulls last, t.priority ASC nulls last, t.pksource DESC nulls last  ", false);

    @Getter
    private final String tableHeaderTitle;
    @Getter
    private final Map<String, String> tableColumnKeyLabel;
    @Getter
    private final String predicateQueryAppender;
    @Getter
    private final String orderBy;
    @Getter
    private final boolean isShowInComboBox;

    private IceTicketListType(String tableHeaderTitle, String predicateQueryAppender, String orderBy, boolean isShowInComboBox) {
        this.tableHeaderTitle = tableHeaderTitle;
        this.predicateQueryAppender = predicateQueryAppender;
        this.orderBy = orderBy;
        this.isShowInComboBox = isShowInComboBox;
        this.tableColumnKeyLabel = new LinkedHashMap<String, String>() {
            {
                put("requestcode", "Request Code");
                put("requesttitle", "Request Title");
                put("requestdate", "Request Date");
                //put("RequestingPersonDesc", "Requesting Person");
                put("issuetypename", "Request Type");
                put("clientname", "Client");
                put("PhaseName", "Phase");
                put("USER_NAME", "Assigned To");
                put("TargetCompDate", "Target Date");
                put("requesttypeid", "Request Type Id");
                put("phaseid", "Phase Id");
                put("EnggID", "Assignee");
                put("priority", "priority");
            }
        };
    }

    public String getRootQueryByTicketListType(IceTicketListType ticketListType, TicketListFilterWrapper ticketListFilterWrapper) {
        String rootQuery = "SELECT p.pksource,p.requestcode, "
                + "       it.issuetypename,  "
                + "       To_char (p.requestdate, 'mm/dd/yyyy')  "
                + "       AS requestdate,  "
                /* + "       p.requestingperson,  "*/
                + "       CASE  "
                + "         WHEN p.is_converted IS NOT NULL THEN (SELECT issuetypename  "
                + "                                               FROM   oam_cr_issuetype aaa  "
                + "                                               WHERE  "
                + "         aaa.issuetypeid = p.convrequesttypeid)  "
                + "         ELSE ''  "
                + "       END  "
                + "       AS SecondaryRequestType,  "
                + " CASE RequestPriority "
                + " WHEN 3 THEN 'P' "
                + " WHEN 4 THEN 'P' "
                + " WHEN 5 THEN 'P' "
                + "  ELSE '' "
                + "  END AS priority, "
                /* + "       rp.username  "
                + "       AS RequestingPersonDesc,  "*/
                + "       Nvl(c.clientname,'N/A') clientname ,  "
             //   + "       cc.applicationid  "
             //   + "       AS AppID,  "
             //   + "       cc.applicationname  "
             //   + "       AS AppName,  "
                + "       p.requests,  "
                + "       Nvl(p.requesttitle,'N/A') requesttitle,  "
                + "       e.username  "
                + "       AS User_Name,   "
                + "       To_char (Nvl(p.targetcompdate2, p.targetcompdate), 'mm/dd/yyyy')  "
                + "       AS  "
                + "       TargetCompDate,  "
                + "       e.userid  "
                + "       AS EnggID,  "
                + "       Nvl(crp.phasename, 'N/A')  "
                + "       AS PhaseName,  "
                + "       crp.phaseid AS phaseid,  "
                + " " + AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE + " AS requesttypeid  "
                + "FROM   oam_rm_requestmanager p  "
                + "       left join (SELECT userid,  "
                + "                         username,  "
                + "                         email,  "
                + "                         oamstatus  "
                + "                  FROM   usr_users  where oamstatus=1) e  "
                + "              ON p.assignedto = e.userid  "
                + "       left join oam_rm_requeststatus s  "
                + "              ON p.statusid = s.statusid  "
                + "       left join oam_cr_issuetype it  "
                + "              ON p.requesttypeid = it.issuetypeid  "
                + "       left join oam_rm_clients c  "
                + "              ON p.clientid = c.clientid  "
              //  + "       left join oam_clientapps cc  "
              //  + "              ON p.sourceid = cc.applicationid         "
                + "       left join oam_cr_phases crp  "
                + "              ON p.phaseid = crp.phaseid  "
                + " WHERE  1 = 1  "
                + "       AND s.statusdesc NOT IN ( 'Dropped' )  "
                + "       AND p.parentrequestcode IS NULL  "
                + ticketListType.getPredicateQueryAppender();

        //ADDING DASHBOARD FILTER PARAMETES IN QUERY
        if (ticketListFilterWrapper.getDashboardFilter().getRequesttypeids() != null) {

            rootQuery = DAOUtils.addQueryForFilterOnSingleColumn(AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE, rootQuery, ticketListFilterWrapper.getDashboardFilter().getRequesttypeids().get("ice"));
        }
        rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("p.clientid", rootQuery, ticketListFilterWrapper.getDashboardFilter().getClientids());
       // rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("p.sourceid", rootQuery, ticketListFilterWrapper.getDashboardFilter().getAppids());
        if (ticketListFilterWrapper.getDashboardFilter().getDateRange() != null && !ticketListFilterWrapper.getDashboardFilter().getDateRange().trim().isEmpty()) {
            DashboardFilterDTO.separateStartAndEndDateByDaterange(ticketListFilterWrapper.getDashboardFilter());
            rootQuery += " AND Trunc(p.requestdate) BETWEEN TO_DATE('" + ticketListFilterWrapper.getDashboardFilter().getStartdate() + "', 'mm/dd/yyyy') AND TO_DATE ('" + ticketListFilterWrapper.getDashboardFilter().getEnddate() + "', 'mm/dd/yyyy') ";
        }
        //END

        //MYTEAM AND UP_FOR_GRABS =>Phase Mapping
        if (ticketListType.toString().startsWith("MYTEAM")
                || ticketListType.toString().startsWith("UP_FOR_GRABS")) {
            rootQuery += " AND p.phaseid IN ("
                    + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryIN(ticketListFilterWrapper.getDashboardFilter().getUserid(), "ICE")
                    + " ) ";
        }
        //END

        //MYTEAM AND UP_FOR_GRABS => Team User Mapping
        /*if (ticketListType.toString().startsWith("MYTEAM")
                || ticketListType.toString().startsWith("UP_FOR_GRABS")) {
            rootQuery += " AND p.assignedto IN ("
                    + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryIN(ticketListFilterWrapper.getDashboardFilter().getUserid(), "ICE")
                    + " ) ";
        }*/
        //END
        //MYTICKET
        if (ticketListType.toString().startsWith("MYTICKET")) {
            rootQuery += " AND p.assignedto='" + ticketListFilterWrapper.getDashboardFilter().getUserid() + "' ";
        }

        //USER_ICE_TICKET_UP_FOR_GRABS
        if (ticketListType.toString().startsWith("USER_ICE_TICKET_UP_FOR_GRABS")) {
            rootQuery += " AND p.assignedto='" + ticketListFilterWrapper.getDashboardFilter().getUserid() + "' ";
            if (ticketListFilterWrapper.getCoreQueryfilterKeys() != null) {
                String teamId = ticketListFilterWrapper.getCoreQueryfilterKeys().get("teamId");
                rootQuery += " AND p.phaseid IN ( "
                        + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryINByTeamId(teamId, "ICE")
                        + ") ";
            }
        }

        //UNASSIGNED_ICE_TICKET_UP_FOR_GRABS
        if (ticketListType.toString().startsWith("UNASSIGNED_ICE_TICKET_UP_FOR_GRABS")) {

            if (ticketListFilterWrapper.getCoreQueryfilterKeys() != null) {
                String teamId = ticketListFilterWrapper.getCoreQueryfilterKeys().get("teamId");
                rootQuery += " AND ( p.assignedto IS NULL OR  p.assignedto NOT IN ("
                        + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryINByTeamId(teamId, "ICE")
                        + " ) ) ";
                rootQuery += " AND p.phaseid  IN ( "
                        + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryINByTeamId(teamId, "ICE")
                        + ") ";
            }
        }

        if (ticketListType.getOrderBy().trim().length() > 0) {
            rootQuery = " WITH T AS (" + rootQuery + " ) select * from (select row_number() over ( " + ticketListType.getOrderBy() + ") as rn, t.* from  T t where   1=1 " + ticketListType.getOrderBy() + " )";

            // rootQuery += ticketListType.getOrderBy();
        }
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            System.out.println("IceTicketListType#getRootQueryByTicketListType()=>" + ticketListType + ">>>>>" + rootQuery);
        }
        System.out.println("IceTicketListType#getRootQueryByTicketListType()=>" + ticketListType + ">>>>>" + rootQuery);
        return rootQuery;
    }
}
