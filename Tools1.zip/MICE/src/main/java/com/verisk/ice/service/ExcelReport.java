/*
 * Date : 2016-06-07 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service;

import java.util.Map;
import org.jxls.area.Area;
import org.jxls.common.Context;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface ExcelReport {

    void dumpTicketsFlowReport(Context context, Area xlsArea);
    
    void dumpIceAgeReport(Context context, Area xlsArea);
    
    void dumpIceAgeReportById(Context context, Area xlsArea, Map<String, String> params);
}
