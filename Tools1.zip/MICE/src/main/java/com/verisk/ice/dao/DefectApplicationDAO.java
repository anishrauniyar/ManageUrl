/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.DefectApplicationDTO;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author i81324
 */
public final class DefectApplicationDAO extends ConnectionBean implements CrudDAO<DefectApplicationDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final DefectApplicationDTO entity) {
        String insertSQL = "INSERT INTO OAM_CR_DEFECTAPPLICATION "
                + "(defappname, shortname)"
                + " VALUES (?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getDefappname());
            ps.setString(2, entity.getShortname());
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public void update(String id, DefectApplicationDTO entity) {
        String insertSQL = "UPDATE OAM_CR_DEFECTAPPLICATION SET "
                + "defappname = ?, shortname = ? "
                + "WHERE defappid = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getDefappname());
            ps.setString(2, entity.getShortname());
            ps.setString(3, id);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public DefectApplicationDTO find(String id) {
        DefectApplicationDTO defectApplicationDTO = new DefectApplicationDTO();
        String sql = "SELECT * FROM OAM_CR_DEFECTAPPLICATION WHERE IS_DELETED='N' and defappid='" + id + "' order by defappname asc";
        if (getList(sql, "DefectApplicationDAO#find(" + id + ")")) {
            if (moveNext()) {
                defectApplicationDTO.setDefappid(getData("defappid"));
                defectApplicationDTO.setDefappname(getData("defappname"));
                defectApplicationDTO.setShortname(getData("shortname"));
            }
        }
        return defectApplicationDTO;
    }

    public List<DefectApplicationDTO> findAll(Map<String, String> filters) {
        List<DefectApplicationDTO> applicationDTOs = new ArrayList<>();
        String sql = "SELECT * FROM OAM_CR_DEFECTAPPLICATION WHERE 1=1 and IS_DELETED='N' ";
        if (filters != null) {
            sql += " AND defappname LIKE '%" + filters.get("fDefAppName") + "%'";
        }
        
        sql += " order by defappname asc ";
        
        if (getList(sql, "DefectApplicationDAO#findAll()")) {
            while (moveNext()) {
                applicationDTOs.add(new DefectApplicationDTO(getData("defappid"), getData("defappname"), getData("shortname")));
            }
        }
        return applicationDTOs;
    }

    public boolean isDuplicateByAppName(String appName) {
        String sql = "SELECT * FROM OAM_CR_DEFECTAPPLICATION WHERE IS_DELETED='N' and defappname='" + appName + "'";
        if (getList(sql, "DefectApplicationDAO#isDuplicateByAppName()")) {
            if (moveNext()) {
                return true;
            }
        }
        return false;
    }
    
    public boolean delete(String id) {
   	 String insertSQL = "UPDATE OAM_CR_DEFECTAPPLICATION SET "
                + "is_deleted = ? "
                + "WHERE defappid = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1,"Y");
            ps.setString(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
        
        return true;
    }
}
