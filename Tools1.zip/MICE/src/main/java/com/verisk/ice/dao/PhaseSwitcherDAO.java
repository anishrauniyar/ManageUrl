/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.CardsDTO;
import com.verisk.ice.model.ColumnsDTO;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.KanbanPhaseBoards;
import com.verisk.ice.model.PhaseSwitcherDTO;
import com.verisk.ice.restservice.RESTDashboard;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author i80983
 */
public class PhaseSwitcherDAO extends ConnectionBean {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    public List<PhaseSwitcherDTO> getPhases(DashboardFilterDTO dashboardFilterDTO) {
        String[] iceRequestTypAry = dashboardFilterDTO.getRequesttypeids().get(RESTDashboard.ICE_ABBR);
        String userId = dashboardFilterDTO.getUserid();

        if (iceRequestTypAry.length > 0) {
            List<PhaseSwitcherDTO> phaseSwitcherDTOList = new ArrayList<>();
            for (String iceTicket : iceRequestTypAry) {
                PhaseSwitcherDTO phaseSwitcherDTO = new PhaseSwitcherDTO();

                String sql1 = ""
                        + "WITH t AS ( "
                        + "SELECT A.PHASEID,c.phasename,b.issuetypename ,a.requestcode,a.requesttitle,a.is_converted "
                        + "FROM oam_rm_requestmanager a "
                        + "left JOIN oam_cR_issuetype b "
                        + "ON a.requesttypeid=b.issuetypeid "
                        + "left JOIN oam_cr_phases c "
                        + "ON a.phaseid=c.phaseid "
                        + "WHERE a.assignedto=" + userId + " AND a.requesttypeid=" + iceTicket + " AND is_converted IS NULL "
                        + "UNION ALL "
                        + "SELECT A.PHASEID,c.phasename,b.issuetypename ,a.requestcode,a.requesttitle,a.is_converted "
                        + "FROM oam_rm_requestmanager a "
                        + "left JOIN oam_cR_issuetype b "
                        + "ON a.convrequesttypeid=b.issuetypeid "
                        + "left JOIN oam_cr_phases c "
                        + "ON a.phaseid=c.phaseid "
                        + "WHERE a.assignedto=" + userId + " AND a.convrequesttypeid=" + iceTicket + " AND is_converted='Y' "
                        + ") SELECT t.issuetypename,t.phaseid,t.phasename,Count(t.requestcode),t.is_converted, "
                        + "listagg(t.requestcode||'-'||Nvl(REPLACE ( t.requesttitle , ',' , ' '	),'N/A'),',') within GROUP (ORDER BY t.requestcode) AS requests "
                        + "FROM t WHERE t.phaseid IN (SELECT a.phaseid FROM oam_cr_phases a "
                        + "left JOIN oam_cr_template_phases b "
                        + "ON a.phaseid=b.phaseid "
                        + "left JOIN oam_cr_template_issuetype c "
                        + "ON b.templateid=c.templateid "
                        + "left JOIN oam_cr_issuetype d "
                        + "ON c.issuetypeid=d.issuetypeid "
                        + "WHERE d.issuetypeid=" + iceTicket
                        + ") GROUP BY t.phaseid,t.phasename,t.issuetypename,t.is_converted";

                System.out.println("PhaseSwitcherDTO#getPhase#SQL1 " + sql1);
                List<ColumnsDTO> columnsDTOList = new ArrayList<>();
                if (getList(sql1, "PhaseSwitcherDTO#getPhase#SQL1")) {
                    while (moveNext()) {
                        phaseSwitcherDTO.setName(getData("ISSUETYPENAME"));
                        ColumnsDTO columnDTO = new ColumnsDTO();
                        columnDTO.setId(getData("PHASEID"));
                        columnDTO.setName(getData("PHASENAME"));

                        //get CardsList
                        List<CardsDTO> cardsDTOList = new ArrayList<>();
                        String[] requestDetails = getData("REQUESTS").split(",");
                        for (String request : requestDetails) {
                            String[] cardDetails = request.split("-");
                            CardsDTO card = new CardsDTO();
                            card.setTitle(cardDetails[0]);//request id
                            card.setDetails(cardDetails[1]);//request details
                            cardsDTOList.add(card);
                        }
                        columnDTO.setCards(cardsDTOList);

                        columnsDTOList.add(columnDTO);
                    }
                }
                
                if (columnsDTOList.size() > 0) {
                    String sql2 = ""
                            + "SELECT * FROM oam_cr_phases a "
                            + "left JOIN oam_cr_template_phases b "
                            + "ON a.phaseid=b.phaseid "
                            + "left JOIN oam_cr_template_issuetype c "
                            + "ON b.templateid=c.templateid "
                            + "left JOIN oam_cr_issuetype d "
                            + "ON c.issuetypeid=d.issuetypeid "
                            + "WHERE d.issuetypeid=" + iceTicket + " AND a.phaseid NOT IN ( "
                            + "SELECT phaseid FROM oam_rm_requestmanager WHERE assignedto=" + userId + " AND requesttypeid=" + iceTicket + " AND is_converted IS NULL AND phaseid IS NOT NULL UNION ALL "
                            + "SELECT phaseid FROM oam_rm_requestmanager WHERE assignedto=" + userId + " AND convrequesttypeid=" + iceTicket + " AND is_converted='Y' AND phaseid IS NOT NULL)";

                    System.out.println("PhaseSwitcherDTO#getPhase#SQL2 " + sql2);
                    if (getList(sql2, "PhaseSwitcherDTO#getPhase#SQL2")) {
                        while (moveNext()) {
                            ColumnsDTO columnDTO = new ColumnsDTO();
                            columnDTO.setId(getData("PHASEID"));
                            columnDTO.setName(getData("PHASENAME"));
                            List<CardsDTO> cardsDTOList = new ArrayList<>();
                            columnDTO.setCards(cardsDTOList);
                            columnsDTOList.add(columnDTO);
                        }
                    }
                } else {
                    String sql3 = "select issuetypename from oam_cr_issuetype where issuetypeid=" + iceTicket;
                    if (getList(sql3, "PhaseSwitcherDTO#getPhase#SQL3")) {
                        if (moveNext()) {
                            phaseSwitcherDTO.setName(getData("ISSUETYPENAME"));
                        }
                    }
                }

                phaseSwitcherDTO.setNumberOfColumns(columnsDTOList.size());
                phaseSwitcherDTO.setColumns(columnsDTOList);
                phaseSwitcherDTOList.add(phaseSwitcherDTO);
            }
            return phaseSwitcherDTOList;
        }
        return null;
    }

    public void updatePhases(KanbanPhaseBoards kanbanPhaseBoards) {
        if (kanbanPhaseBoards.getKanbanPhaseBoard().size() > 0) {
            for (PhaseSwitcherDTO phaseSwitcherDTO : kanbanPhaseBoards.getKanbanPhaseBoard()) {
                if (phaseSwitcherDTO.getColumns().size() > 0) {
                    try {
                        setConnection();
                        List<String> updateQrys = generateUpdatePhasesQry(phaseSwitcherDTO);
                        Statement s = myConn.createStatement();
                        for (String updateQry : updateQrys) {
                            s.addBatch(updateQry);
                        }
                        s.executeBatch();
                        System.out.println("Successfully Updated!!!!");
                    } catch (Exception ex) {
                        System.out.println(ex.getMessage());
                    } finally {
                        this.takeDown();
                    }
                }
            }
        }

    }

    public List<String> generateUpdatePhasesQry(PhaseSwitcherDTO phaseSwitcherDTO) {
        List<String> updateQrys = new ArrayList<>();
        for (ColumnsDTO column : phaseSwitcherDTO.getColumns()) {
            if (column.isUpdateFlag()) {
                System.out.println("Update phaseid: " + column.getName() + "(" + column.getId() + ")");
                List<CardsDTO> cards = column.getCards();
                StringBuilder sb = new StringBuilder();
                if (cards.size() > 0) {
                    sb.append("update oam_rm_requestmanager set phaseid='").append(column.getId()).append("' where requestcode in (");
                    for (CardsDTO card : column.getCards()) {
                        sb.append("'").append(card.getTitle()).append("'" + ",");
                    }
                    sb.deleteCharAt(sb.length() - 1);
                    sb.append(") ");
                    updateQrys.add(sb.toString());
                }
            }
        }
        return updateQrys;
    }

}
