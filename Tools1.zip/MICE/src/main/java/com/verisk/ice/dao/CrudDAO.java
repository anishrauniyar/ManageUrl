/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

/**
 *
 * @author i81324
 * @param <T>
 */
public interface CrudDAO<T> {

    void insert(T entity);

    void update(String requestCode, T entity);

    T find(String requestCode);
    
   // boolean delete(String id);
}
