/*
 *
 * Date : 2016-00-04 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.design;

import com.verisk.ice.dao.IceTicketListDAO;
import com.verisk.ice.dao.OamTicketListDAO;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class TicketListFactory {


    private TicketListFactory() {
    }

    public static TicketListDAO getTicketListDAO(String app) throws IllegalArgumentException {
        if ("ice".equals(app)) {
            return new IceTicketListDAO();
        } else if ("oam".equals(app)) {
            return new OamTicketListDAO();
        }
        throw new IllegalArgumentException("Not find TicketListDAO for type : " + app);
    }

}
