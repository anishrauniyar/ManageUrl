/*
 * Date : 2016-00-21 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model;

import com.verisk.ice.utils.ObjectUtil;
import com.verisk.ice.utils.ValidateUtility;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class FilterKey {

    private String key;
    private String value;
    private String type;

    public static boolean isValueIsNotEmpty(FilterKey filterKey) {
        ValidateUtility.isNotNull(filterKey);
        return ObjectUtil.isNotEmptyAndNull(filterKey.getKey()) && ObjectUtil.isNotEmptyAndNull(filterKey.getValue());
    }
}
