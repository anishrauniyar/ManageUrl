/*
 * Date : 2016-02-22
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.design.TicketListDAO;
import com.verisk.ice.design.TicketListFactory;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.verisk.ice.service.TicketListService;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class TicketListServiceImpl implements TicketListService {

    private static final Logger LOG = LoggerFactory.getLogger(TicketListServiceImpl.class.getName());

    public TicketListServiceImpl() {
    }

    @Override
    public TicketListWrapper findTicketList(TicketListFilterWrapper ticketListFilterWrapper, String type, String app) {
        TicketListFilterWrapper.setDefaultPageSwitcherIfNeccessary(ticketListFilterWrapper, PageSwitcherDTO.PageSwitcherDTOType.TABLE_LIST_VIEW);
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(ticketListFilterWrapper));
        }
        TicketListDAO ticketListDAO = TicketListFactory.getTicketListDAO(app);
        TicketListWrapper ticketListWrapper = ticketListDAO.findAll(ticketListFilterWrapper, type);
        ticketListDAO.takeDown();
        return ticketListWrapper;
    }

    @Override
    public TicketListWrapper findTicketListGrid(TicketListFilterWrapper ticketListFilterWrapper, String type, String app) {
        TicketListFilterWrapper.setDefaultPageSwitcherIfNeccessary(ticketListFilterWrapper, PageSwitcherDTO.PageSwitcherDTOType.GRID_LIST_VIEW);
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(ticketListFilterWrapper));
        }
        TicketListDAO ticketListDAO = TicketListFactory.getTicketListDAO(app);
        TicketListWrapper ticketListWrapper = ticketListDAO.findAll(ticketListFilterWrapper, type);
        ticketListDAO.takeDown();
        return ticketListWrapper;
    }

    @Override
    public String findCount(DashboardFilterDTO dashboardFilterDTO, String type, String app) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(dashboardFilterDTO));
        }
        TicketListDAO ticketListDAO = TicketListFactory.getTicketListDAO(app);
        String count = ticketListDAO.count(dashboardFilterDTO, type);
        ticketListDAO.takeDown();
        return count;
    }

    @Override
    public Map<String, Object> prepareForQuickEdit(String requestCode, String type, String app) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info("RequestCode=" + requestCode + " Type=" + type + " App=" + app);
        }
        TicketListDAO ticketListDAO = TicketListFactory.getTicketListDAO(app);
        Map<String, Object> map = ticketListDAO.findQuickEditRequestTemplate(requestCode);
        ticketListDAO.takeDown();
        return map;
    }

    @Override
    public TicketListWrapper findTicketListWithoutPagination(TicketListFilterWrapper ticketListFilterWrapper, String type, String app) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(ticketListFilterWrapper));
        }
        TicketListDAO ticketListDAO = TicketListFactory.getTicketListDAO(app);
        TicketListWrapper ticketListWrapper = ticketListDAO.findAllWithoutPagination(ticketListFilterWrapper, type);
        ticketListDAO.takeDown();
        return ticketListWrapper;
    }

}
