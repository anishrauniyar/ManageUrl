/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.service;

import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.wrapper.FactsAndStatsWrapper;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface FactsAndStatsService {

    FactsAndStatsWrapper findFactsAndStats(DashboardFilterWrapper dashboardFilterWrapper, String searchKey);

}
