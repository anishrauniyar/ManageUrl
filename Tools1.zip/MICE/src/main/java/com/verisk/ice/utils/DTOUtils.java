/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.utils;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author i81324
 */
public final class DTOUtils {
    
    public static final SimpleDateFormat SQL_DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
    public static final SimpleDateFormat DATABASE_DATE_COLUMN_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final String MAP_KEY_SPLITER = "@k@";
    
    public static java.sql.Date convertSQLDate(String dateString) {
        try {
            return new java.sql.Date(SQL_DATE_FORMAT.parse(dateString).getTime());
        } catch (Exception ex) {
            return null;
        }
    }
    
    public static Long convertStringToLong(String number) {
        try {
            return Long.valueOf(number);
        } catch (Exception e) {
            return 0L;
        }
    }
    
    public static String convertDBDateToString(String dateString) {
        try {
            return SQL_DATE_FORMAT.format(DATABASE_DATE_COLUMN_DATE_FORMAT.parse(dateString));
        } catch (Exception e) {
            return "";
        }
    }
    
    public static String converSQLDateStringByJavaDate(Date date) {
        try {
            return SQL_DATE_FORMAT.format(date);
        } catch (Exception e) {
            return "";
        }
    }
    
    public static String getCurrentDateIntoString() {
        return SQL_DATE_FORMAT.format(new Date());
    }
    
    public static String joinByColon(String[] ids) {
        if (ids == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ids.length; i++) {
            if (i != ids.length - 1) {
                sb.append(ids[i]).append(":");
            } else {
                sb.append(ids[i]);
            }
        }
        return sb.toString();
    }
    
    public static String joinByColonForMap(Map<String, String[]> ids) {
        if (ids == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String[]> map : ids.entrySet()) {
            sb.append(MAP_KEY_SPLITER);
            sb.append(map.getKey());
            sb.append(MAP_KEY_SPLITER);
            sb.append(joinByColon(map.getValue()));
        }
        return sb.toString();
    }
    
    public static String[] splitToArrayByColon(String colonString) {
        if (colonString != null) {
            return colonString.split(":");
        }
        return new String[]{};
    }
    
    public static Map<String, String[]> splitToMapByColon(String colonString) {
        if (colonString != null) {
            Map<String, String[]> map = new HashMap<>();
            String[] keyValuePair = colonString.split(MAP_KEY_SPLITER);
            if (keyValuePair.length >= 3) {
                for (int i = 1; i < keyValuePair.length - 1; i++) {
                    String key = keyValuePair[i];
                    String value = keyValuePair[++i];
                    map.put(key, value.split(":"));
                }
            }
            return map;
        }
        return Collections.emptyMap();
    }
    
    public static String getCommaSeperatedString(String[] ary) {
        if (ary.length > 0) {
            StringBuilder commaSpeStringBuilder = new StringBuilder();
            
            for (String n : ary) {
                commaSpeStringBuilder.append("'").append(n.replace("'", "\\'")).append("',");
                // can also do the following
                // nameBuilder.append("'").append(n.replace("'", "''")).append("',");
            }
            
            commaSpeStringBuilder.deleteCharAt(commaSpeStringBuilder.length() - 1);
            
            return commaSpeStringBuilder.toString();
        } else {
            return "";
        }
    }
    
    public static String ifNullRetrunEmptyString(String data) {
        return data == null ? "" : data;
    }
    
}
