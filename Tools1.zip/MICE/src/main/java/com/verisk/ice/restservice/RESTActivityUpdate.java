/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.model.ActivityUpdateDTO;
import com.verisk.ice.model.wrapper.ActivityUpdateWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.service.ActivityUpdateService;
import com.verisk.ice.service.impl.ActivityUpdateServiceImpl;
import java.util.List;
import java.util.Map;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/activityUpdate")
@Produces(MediaType.APPLICATION_JSON)
public class RESTActivityUpdate {

    @POST
    @Path("/all")
    public ActivityUpdateWrapper allActivities(DashboardFilterWrapper dashboardFilterWrapper) {
        ActivityUpdateService activityUpdateService = new ActivityUpdateServiceImpl();
        return activityUpdateService.findActivityUpdates(dashboardFilterWrapper);
    }

    @POST
    @Path("/allHistoryLog")
    public List<ActivityUpdateDTO> allHistoryLog(Map<String, String> historyFilterWrapper) {
        ActivityUpdateService activityUpdateService = new ActivityUpdateServiceImpl();
        return activityUpdateService.findAllHistoryLogByRequestCode(historyFilterWrapper);
    }

    @POST
    @Path("/skipActivityUpdate")
    public void skipActivityUpdate(Map<String, String> dataFromRequest) {
        if (dataFromRequest != null) {
            ActivityUpdateService activityUpdateService = new ActivityUpdateServiceImpl();
            activityUpdateService.saveSkipActivityUpdate(dataFromRequest.get("activityUpdateId"), dataFromRequest.get("userId"));
        }
    }
}
