/*
 * Date : 2016-05-18 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
public class RequestParamDTO {

    private String parenticeid;
    private String parentrequesttype;
    private String integrationtype;
    private String applicationkickoffdate;
    private String linkType;
    private String linkIceId;
    
}
