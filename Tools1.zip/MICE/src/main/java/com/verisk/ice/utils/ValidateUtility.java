/*
 * Date : 2016-00-21 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.utils;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class ValidateUtility {

    public static void isNotNull(Object o) {
        if (o == null) {
            throw new IllegalArgumentException("Null object.");
        }
    }

    public static void isNotNullObjects(Object... objects) {
        isNotNull(objects);
        for (Object obj : objects) {
            isNotNull(obj);
        }
    }
}
