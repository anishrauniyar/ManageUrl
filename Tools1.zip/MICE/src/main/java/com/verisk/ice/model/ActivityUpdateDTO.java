/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ActivityUpdateDTO {

    private String activityupdateid;
    private String loggedtime;
    private String detail;
    private String activeLiveTime;
    private String username;
    private String pksource;

}
