/*
 * Date : 2016-05-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service;

import com.verisk.ice.model.team.TeamDTO;
import com.verisk.ice.model.wrapper.ParamFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import java.util.List;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface TeamService {

    List<TeamDTO> findMyTeamDetails(String userid, String application);

    public TicketListWrapper findMyTeamUserTicketsOfUpForGrabs(ParamFilterWrapper paramFilterWrapper);
}
