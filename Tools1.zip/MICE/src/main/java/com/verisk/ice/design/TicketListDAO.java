/*
 *
 * Date : 2016-00-03 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.design;

import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface TicketListDAO {

    TicketListWrapper findAll(TicketListFilterWrapper ticketListFilterWrapper, String type);

    TicketListWrapper findAllWithoutPagination(TicketListFilterWrapper ticketListFilterWrapper, String type);

    String count(DashboardFilterDTO dashboardFilterDTO, String type);
    
    String countQuery(DashboardFilterDTO dashboardFilterDTO, String type);

    void takeDown();

    Map<String, Object> findQuickEditRequestTemplate(String requestCode);
}
