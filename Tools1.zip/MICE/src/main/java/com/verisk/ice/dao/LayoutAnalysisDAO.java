/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.LayoutAnalysisDTO;
import com.verisk.ice.utils.DTOUtils;
import java.sql.PreparedStatement;

/**
 *
 * @author i81324
 */
public final class LayoutAnalysisDAO extends ConnectionBean implements CrudDAO<LayoutAnalysisDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final LayoutAnalysisDTO entity) {
        String insertSQL = "INSERT INTO oam_cr_lamanager "
                + "( requestcode, eigerpath, reasonchange, additionalcomments, accountmanager, approvedby, approvedate, requestdescription )"
                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getRequestcode());
            ps.setString(2, entity.getEigerpath());
            ps.setString(3, entity.getReasonchange());
            ps.setString(4, entity.getAdditionalcomments());
            ps.setString(5, entity.getAccountmanager());
            ps.setString(6, entity.getApprovedby());
            ps.setDate(7, DTOUtils.convertSQLDate(entity.getApprovedate()));
            ps.setString(8, entity.getRequestdescription());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(String requestCode, LayoutAnalysisDTO entity) {
        String insertSQL = "UPDATE oam_cr_lamanager SET "
                + "eigerpath = ?, reasonchange = ?, additionalcomments = ?, accountmanager = ?, approvedby = ?, approvedate = ?, requestdescription = ? "
                + "WHERE requestcode = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getEigerpath());
            ps.setString(2, entity.getReasonchange());
            ps.setString(3, entity.getAdditionalcomments());
            ps.setString(4, entity.getAccountmanager());
            ps.setString(5, entity.getApprovedby());
            ps.setDate(6, DTOUtils.convertSQLDate(entity.getApprovedate()));
            ps.setString(7, entity.getRequestdescription());
            ps.setString(8, requestCode);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public LayoutAnalysisDTO find(String requestCode) {
        LayoutAnalysisDTO analysisDTO = new LayoutAnalysisDTO();
        String sql = "SELECT * FROM OAM_CR_LAMANAGER WHERE  REQUESTCODE='" + requestCode + "'";
        if (getList(sql, "LayoutAnalysisDAO#find(" + requestCode + ")")) {
            if (moveNext()) {
                analysisDTO.setAccountmanager(getData(LayoutAnalysisDTO.DBColumns.ACCOUNTMANAGER.toString()));
                analysisDTO.setAdditionalcomments(getData(LayoutAnalysisDTO.DBColumns.ADDITIONALCOMMENTS.toString()));
                analysisDTO.setApprovedate(getOnlyDate(getData(LayoutAnalysisDTO.DBColumns.APPROVEDATE.toString()), true));
                analysisDTO.setApprovedby(getData(LayoutAnalysisDTO.DBColumns.APPROVEDBY.toString()));
                analysisDTO.setEigerpath(getData(LayoutAnalysisDTO.DBColumns.EIGERPATH.toString()));
                analysisDTO.setLaid(getData(LayoutAnalysisDTO.DBColumns.LAID.toString()));
                analysisDTO.setReasonchange(getData(LayoutAnalysisDTO.DBColumns.REASONCHANGE.toString()));
                analysisDTO.setRequestcode(getData(LayoutAnalysisDTO.DBColumns.REQUESTCODE.toString()));
                analysisDTO.setRequestdescription(getData(LayoutAnalysisDTO.DBColumns.REQUESTDESCRIPTION.toString()));
            }
        }
        return analysisDTO;
    }

}
