/*
 * Date : 2016-06-07 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.dao.report.IceAgeReportDAO;
import com.verisk.ice.dao.report.TicketFlowReportDAO;
import java.util.List;
import java.util.Map;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/reports")
@Produces(MediaType.APPLICATION_JSON)
public class RESTReport {

    @POST
    @Path("iceage")
    public List<Map<String, String>> findIceAgeReport() {
        IceAgeReportDAO iceAgeReportDAO = new IceAgeReportDAO();
        List<Map<String, String>> list = iceAgeReportDAO.findAgeReport();
        iceAgeReportDAO.takeDown();
        return list;
    }

    @POST
    @Path("iceagebyid")
    public List<Map<String, String>> findIceAgeReport(String pkSourceId) {
        IceAgeReportDAO iceAgeReportDAO = new IceAgeReportDAO();
        List<Map<String, String>> list = iceAgeReportDAO.findAgeReportById(pkSourceId);
        iceAgeReportDAO.takeDown();
        return list;
    }

    @POST
    @Path("ticketflow")
    public Map<String, Object> findTicketFlow() {
        TicketFlowReportDAO ticketFlowReportDAO = new TicketFlowReportDAO();
        Map<String, Object> map = ticketFlowReportDAO.findTicketFlow();
        ticketFlowReportDAO.takeDown();
        return map;
    }

}
