/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.AppIdDTO;
import com.verisk.ice.model.ClientDTO;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.utils.AppConstants;
import com.verisk.ice.utils.DAOUtils;
import static com.verisk.ice.utils.DTOUtils.*;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class DashboardFilterDAO extends ConnectionBean implements CrudDAO<DashboardFilterDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(DashboardFilterDTO entity) {
        String SQL = "INSERT INTO OAM_CR_DASHBOARDFILTER "
                + " (userid, requesttypeids, clientids, appids, startdate, enddate )"
                + " VALUES (?, ?, ?, ?, ?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, entity.getUserid());
            ps.setString(2, joinByColonForMap(entity.getRequesttypeids()));
            ps.setString(3, joinByColon(entity.getClientids()));
            ps.setString(4, joinByColon(entity.getAppids()));
            ps.setDate(5, convertSQLDate(entity.getStartdate()));
            ps.setDate(6, convertSQLDate(entity.getEnddate()));
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void update(String id, DashboardFilterDTO entity) {
        String SQL = "UPDATE OAM_CR_DASHBOARDFILTER SET "
                + " requesttypeids = ?, clientids = ?, appids = ?, startdate = ?, enddate = ?  "
                + " WHERE USERID = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, joinByColonForMap(entity.getRequesttypeids()));
            ps.setString(2, joinByColon(entity.getClientids()));
            ps.setString(3, joinByColon(entity.getAppids()));
            ps.setDate(4, convertSQLDate(entity.getStartdate()));
            ps.setDate(5, convertSQLDate(entity.getEnddate()));
            ps.setString(6, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public DashboardFilterDTO find(String id) {
        DashboardFilterDTO dashboardFilterDTO = new DashboardFilterDTO();
        dashboardFilterDTO.setUserid(id);
        String sql = "SELECT * FROM OAM_CR_DASHBOARDFILTER WHERE  USERID='" + id + "'";
        if (getList(sql, "DashboardFilterDAO#find(" + id + ")")) {
            if (moveNext()) {
                dashboardFilterDTO.setFilterid(getData("FILTERID"));
                dashboardFilterDTO.setUserid(getData("USERID"));
                dashboardFilterDTO.setRequesttypeids(DashboardFilterDTO.initMapIfNeccessary(splitToMapByColon(getData("REQUESTTYPEIDS"))));
                dashboardFilterDTO.setClientids(splitToArrayByColon(getData("CLIENTIDS")));
                dashboardFilterDTO.setAppids(splitToArrayByColon(getData("APPIDS")));
                dashboardFilterDTO.setStartdate(convertDBDateToString(getData("STARTDATE")));
                dashboardFilterDTO.setEnddate(convertDBDateToString(getData("ENDDATE")));
                String dateRange = dashboardFilterDTO.getStartdate().trim().length() > 0 && dashboardFilterDTO.getStartdate().trim().length() > 0
                        ? dashboardFilterDTO.getStartdate() + " - " + dashboardFilterDTO.getEnddate() : "";
                dashboardFilterDTO.setDateRange(dateRange);
            }
        }
        dashboardFilterDTO.setRequesttypeids(DashboardFilterDTO.initMapIfNeccessary(dashboardFilterDTO.getRequesttypeids()));
        return dashboardFilterDTO;
    }

    public boolean isExistByUserId(String id) {
        String sql = "SELECT * FROM OAM_CR_DASHBOARDFILTER WHERE  USERID='" + id + "'";
        if (getList(sql, "DashboardFilterDAO#isExistByUserId(" + id + ")")) {
            if (moveNext()) {
                return true;
            }
        }
        return false;
    }

    public List<AppIdDTO> findAppIdsByClient(DashboardFilterDTO dashboardFilter) {
        if (dashboardFilter != null) {
            String rootQuery = "select applicationid, applicationname, clientid from oam_clientapps where inProduction='Y'";
            rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("clientid", rootQuery, dashboardFilter.getClientids());
            rootQuery += " order by applicationid asc ";
            if (getList(rootQuery, "DashboardFilterDAO#findAppIdsByClient()")) {
                List<AppIdDTO> appIdDTOs = new ArrayList<>();
                while (moveNext()) {
                    appIdDTOs.add(new AppIdDTO(getData("applicationid"), getData("applicationname"), getData("clientid")));
                }
                return appIdDTOs;
            }
        }
        return new ArrayList<>();
    }

    public List<ClientDTO> findClients(DashboardFilterDTO dashboardFilter) {
        if (dashboardFilter != null) {
            String sql = QuerySpecification.INSTANCE.getClientsAllQuery() + " order by lower(clientname)";
            if (getList(sql, "DashboardFilterDAO#findClients()")) {
                List<ClientDTO> clientDTOs = new ArrayList<>();
                while (moveNext()) {
                    clientDTOs.add(new ClientDTO(getData("ClientID"), getData("ClientName")));
                }
                return clientDTOs;
            }
        }
        return Collections.emptyList();
    }

    public boolean changeAssignee(String requestCode, String userId) {
        String SQL = "UPDATE OAM_RM_REQUESTMANAGER SET ASSIGNEDTO = ? WHERE REQUESTCODE = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, userId);
            ps.setString(2, requestCode);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean changePriorityToHigh(String requestCode, String userId) {
        String SQL = "UPDATE OAM_RM_REQUESTMANAGER SET REQUESTPRIORITY = ?, PRIORITIZEDBY = ?, PRIORITIZEDDATE = SYSDATE WHERE REQUESTCODE = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, "5");
            ps.setString(2, userId);
            ps.setString(3, requestCode);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Map<String, String>> findIceRequestTypes(String userId) {
        if (userId != null) {
            String rootQuery = "SELECT Count(1) AS count, " + AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE + " AS requesttypeid ,"
                    + " i.issuetypename AS issuetypename FROM OAM_RM_REQUESTMANAGER p, "
                    + " oam_cr_issuetype i   WHERE i.issuetypeid = " + AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE + " AND p.assignedto ='" + userId + "' "
                    + " AND p.parentRequestCode IS NULL AND p.requesttypeid IS NOT NULL AND p.statusid = '1' "
                    + " GROUP BY " + AppConstants.INSTANCE.SQL_REQUESTYPEID_COLUMN_CASE + ", i.issuetypename ";
            if (getList(rootQuery, "DashboardFilterDAO#findIceRequestTypes()")) {
                List<Map<String, String>> requestTypes = new ArrayList<>();
                while (moveNext()) {
                    Map<String, String> map = new HashMap<>();
                    map.put("id", getData("requesttypeid"));
                    map.put("name", getData("issuetypename"));
                    map.put("count", getData("count"));
                    requestTypes.add(map);
                }
                return requestTypes;
            }
        }
        return new ArrayList<>();
    }

}
