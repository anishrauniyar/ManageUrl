/*
 * Date : 2016-02-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */

package com.verisk.ice.model;

import com.verisk.ice.design.DBDefination;
import com.verisk.ice.design.DataType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DefectComponentDTO {

    @DBDefination(columnName = "defappid", dataType = DataType.VARCHAR2)
    private String defappid;
    @DBDefination(columnName = "defcomponentid", dataType = DataType.VARCHAR2)
    private String defcomponentid;
    @DBDefination(columnName = "defcomponentname", dataType = DataType.VARCHAR2)
    private String defcomponentname;
}
