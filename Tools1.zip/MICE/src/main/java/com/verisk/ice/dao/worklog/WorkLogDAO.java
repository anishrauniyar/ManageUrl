/*
 * Date : 2016-04-08 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao.worklog;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.worklog.WorkLogDTO;
import com.verisk.ice.utils.DTOUtils;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class WorkLogDAO extends ConnectionBean {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    public void insert(WorkLogDTO entity) {
        String SQL = "INSERT INTO USER_WORK_LOG "
                + " (timespent,logdate,entrydate,comments,userid,requestcode, prev_phase_id, current_phase_id)"
                + " VALUES (?, ?, SYSDATE, ?, ?, ?, ?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(SQL);
            ps.setString(1, entity.getTimespent());
            ps.setDate(2, DTOUtils.convertSQLDate(entity.getLogdate()));
            ps.setString(3, entity.getComments());
            ps.setString(4, entity.getUserid());
            ps.setString(5, entity.getRequestcode());
            ps.setString(6, entity.getPrevPhaseId());
            ps.setString(7, entity.getNewPhaseId());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public List<Map<String, String>> getWorkLogHistory(String requestCode) {
        List<Map<String, String>> workLogDTOs = new ArrayList<>();
        String sql = "select ph.phasename AS phasename, Sum(Round((wl.timespent/60),3)) AS timeinhour from user_work_log wl  "
                + "left join oam_cr_phases ph                       "
                + "on ph.phaseid = wl.prev_phase_id "
                + "WHERE wl.requestcode='" + requestCode + "'                                                         "
                + " group by phasename order by phasename ";
        if (getList(sql, "WorkLogDAO#getWorkLogHistory()")) {
            while (moveNext()) {
                workLogDTOs.add(new HashMap<String, String>() {
                    {
                        //put("date", getData("date"));
                        put("phasename", getData("phasename"));
                        put("timeinhour", getData("timeinhour"));
                    }
                });
            }
        }
        return workLogDTOs;
    }

}
