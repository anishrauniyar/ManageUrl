/*
 * Date : 2016-00-11 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum UIFieldType {
    palinText,
    singleSelect,
    datePicker,
    textArea,
    input
}
