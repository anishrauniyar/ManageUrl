/*
 * Date : 2016-06-07 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.design;

import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum ReportType {
    ICE_AGE_REPORT("iceAgeReport.xlsx", "IceAgeReport"),
    ICE_AGE_REPORT_BY_ID("iceAgeReportById.xlsx", "IceAgeReportById"),
    TICKETS_FLOW_REPORT("ticketFlowReport.xlsx", "TicketsFlowReport");

    @Getter
    private final String xlsxFileName;
    @Getter
    private final String reportName;

    private ReportType(String xlsxFileName, String reportName) {
        this.xlsxFileName = xlsxFileName;
        this.reportName = reportName;
    }

}
