/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.DefectGenericDTO;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;



public final class DefectSubTypeDAO extends ConnectionBean implements CrudDAO<DefectGenericDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final DefectGenericDTO entity) {
        String insertSQL = "INSERT INTO OAM_CR_DEFECTCOMPONENT "
                + "(defcomponentname, defappid)"
                + " VALUES (?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            //ps.setString(1, entity.getDefcomponentname());
            //ps.setString(2, entity.getDefappid());
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

    @Override
    public void update(String id, DefectGenericDTO entity) {
        String insertSQL = "UPDATE OAM_CR_DEFECTCOMPONENT SET "
                + "defcomponentname = ? "
                + "WHERE defcomponentid = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            //ps.setString(1, entity.getDefcomponentname());
           // ps.setString(2, id);
            ps.executeUpdate();
        } catch (Exception e) {
            //e.printStackTrace();
        }
    }

  
    public DefectGenericDTO find(String id) {
    	DefectGenericDTO defectCategoryDTO = new DefectGenericDTO();
    	 String sql = "SELECT * FROM oam_cr_defectSubType WHERE IS_DELETED='N' ORDER BY DEFNAME ASC";
         if (getList(sql, "DefectCategoryDAO#find(" + id + ")")) {
            if (moveNext()) {
            	defectCategoryDTO.setDefid(getData("defid"));
            	defectCategoryDTO.setDefname(getData("defname"));
            	//defectCategoryDTO.setDefcomponentid(getData("defcomponentid"));
            	//defectCategoryDTO.setDefcomponentname(getData("defcomponentname"));
            }
        }
        return defectCategoryDTO;
    }
    
    public List<DefectGenericDTO> findAll(Map<String, String> filters) {
        List<DefectGenericDTO> defectCategoryDTO = new ArrayList<>();
        String sql = "SELECT * FROM oam_cr_defectSubType WHERE IS_DELETED='N' ORDER BY DEFNAME ASC";
         if (filters != null) {
            sql += " AND DEFNAME LIKE '%" + filters.get("fDEFNAME") + "%'";
        }
        System.out.println("Filter:"+sql);
        if (getList(sql, "DefectSubTypeDAO#findAll()")) {
            while (moveNext()) {
            	defectCategoryDTO.add(new DefectGenericDTO(getData("defid"), getData("defname")));
            	
            }
        }
        return defectCategoryDTO;
    }



    /*public boolean isDuplicateByAppName(String componentName) {
        String sql = "SELECT * FROM OAM_CR_DEFECTCOMPONENT WHERE  defcomponentname='" + componentName + "' ";
        if (getList(sql, "DefectComponentDAO#isDuplicateByAppName()")) {
            if (moveNext()) {
                return true;
            }
        }
        return false;
    }
    

    public boolean delete(String id) {
    	 String insertSQL = "UPDATE OAM_CR_DEFECTCOMPONENT SET "
                 + "is_deleted = ? "
                 + "WHERE defcomponentid = ?";
         try {
             setConnection();
             myConn.setAutoCommit(true);
             PreparedStatement ps = myConn.prepareStatement(insertSQL);
             ps.setString(1,"Y");
             ps.setString(2, id);
             ps.executeUpdate();
         } catch (Exception e) {
             //e.printStackTrace();
         }
         
         return true;
     }*/
}
