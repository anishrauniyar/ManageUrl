/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.utils;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class AbbrevConstants {

    public static final String ICE_ABBR = "ice";
    public static final String OAM_ABBR = "oam";
}
