/*
 * Date : 2016-01-22
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.legacy;

import com.d2hs.soam.rm.queryBeanPM;
import com.d2hs.soam.um.UserManager;
import d2Systems.oam.SendMail;
import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
public enum LegacyBeanPool {

    INSTANCE;

    private final queryBeanPM queryBeanPM;
    private final UserManager userManager;
    private final SendMail sendMail;

    private LegacyBeanPool() {
        queryBeanPM = new queryBeanPM();
        userManager = new UserManager();
        sendMail = new SendMail();
    }

}
