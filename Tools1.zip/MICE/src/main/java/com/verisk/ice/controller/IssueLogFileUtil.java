/*
 * Date : 2016-00-15 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.controller;

import java.io.InputStream;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum IssueLogFileUtil {
    INSTANCE;

    public static final String DYNAMIC_XLS_RESOURCE = "issueLogDynamicTemplate.xlsx";
    public static final String STATIC_XLS_RESOURCE = "issueLogStaticTemplate.xlsx";

    public InputStream getInputStreamForIssueLogDynamicXLSTemplate() {
        return getClass().getClassLoader().getResourceAsStream(DYNAMIC_XLS_RESOURCE);
    }

    public InputStream getInputStreamForIssueLogStaticXLSTemplate() {
        return getClass().getClassLoader().getResourceAsStream(STATIC_XLS_RESOURCE);
    }
}
