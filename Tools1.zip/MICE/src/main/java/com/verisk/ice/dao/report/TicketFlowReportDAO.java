/*
 * Date : 2016-06-06 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao.report;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.utils.DTOUtils;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class TicketFlowReportDAO extends ConnectionBean {

    enum ColumnHeaders {
        issuetypename, phase, week1_o, week1_c, week1_n, week2_o, week2_c, week2_n, week3_o, week3_c, week3_n, week4_o, week4_c, week4_n;
    }

    private static final Logger LOG = LoggerFactory.getLogger(TicketFlowReportDAO.class.getName());

    public Map<String, Object> findTicketFlow() {
        Map<String, Object> rootMap = new HashMap<>();
        List<Map<String, String>> list = new ArrayList<>();
        if (getList(ticketFlowSQLGenByDateRange(rootMap), "TicketFlowReportDAO#findTicketFlow()")) {
            while (moveNext()) {
                Map<String, String> map = new HashMap<>();
                for (ColumnHeaders header : ColumnHeaders.values()) {
                    String data = getData(header.toString());
                    map.put(header.toString(), data == null || data.trim().isEmpty() ? "0" : data);
                }
                map.put("week1_b", String.valueOf(Integer.valueOf(map.get("week1_o")) + Integer.valueOf(map.get("week1_n")) - Integer.valueOf(map.get("week1_c"))));
                map.put("week2_b", String.valueOf(Integer.valueOf(map.get("week2_o")) + Integer.valueOf(map.get("week2_n")) - Integer.valueOf(map.get("week2_c"))));
                map.put("week3_b", String.valueOf(Integer.valueOf(map.get("week3_o")) + Integer.valueOf(map.get("week3_n")) - Integer.valueOf(map.get("week3_c"))));
                map.put("week4_b", String.valueOf(Integer.valueOf(map.get("week4_o")) + Integer.valueOf(map.get("week4_n")) - Integer.valueOf(map.get("week4_c"))));
                list.add(map);
            }
        }
        rootMap.put("list", list);
        return rootMap;
    }

    public String ticketFlowSQLGenByDateRange(Map<String, Object> rootMap) {
        StringBuilder builder = new StringBuilder();
        Calendar endCalendar = Calendar.getInstance();
        if (endCalendar.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY) {
            int diff = Calendar.SATURDAY - endCalendar.get(Calendar.DAY_OF_WEEK);
            diff--;
            endCalendar.add(Calendar.DAY_OF_WEEK, -diff);
        }

        Map<String, String> reportTimeWindow = new HashMap<>();

        Calendar weekStartCalendar = Calendar.getInstance();
        weekStartCalendar.setTime(endCalendar.getTime());

        //WEEK-1 to WEEK-4 timeframe
        for (int i = 4; i >= 1; i--) {
            weekStartCalendar.add(Calendar.WEEK_OF_MONTH, -1);
            weekStartCalendar.add(Calendar.DAY_OF_WEEK, 1);

            reportTimeWindow.put("week" + i + "start", DTOUtils.converSQLDateStringByJavaDate(weekStartCalendar.getTime()));
            reportTimeWindow.put("week" + i + "end", DTOUtils.converSQLDateStringByJavaDate(endCalendar.getTime()));

            LOG.info("Week-" + i + ":Date=>START=" + reportTimeWindow.get("week" + i + "start") + ", END=" + reportTimeWindow.get("week" + i + "end"));

            weekStartCalendar.add(Calendar.DAY_OF_WEEK, -1);
            endCalendar.add(Calendar.WEEK_OF_MONTH, -1);
        }
        rootMap.put("reportTimeWindow", reportTimeWindow);
        builder.append("SELECT * FROM ( ");

        //WEEK-1
        builder.append("SELECT aaaa.*, '1' AS counter FROM ")
                .append("(SELECT * FROM ( ")
                .append("SELECT * FROM ( ")
                .append("SELECT * from( ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'1' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week1start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week1end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append("UNION all ")
                .append("SELECT issuetypename,fromPhase.phasename \"Phase\"  ,'2' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases fromPhase ")
                .append("ON Log.fromphaseid=fromPhase.phaseid ")
                .append("WHERE fromphaseid IS not NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week1start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week1end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,fromPhase.phasename ")
                .append("UNION ALL ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'3' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week1start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week1end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append(") aa ")
                .append(") ")
                .append("pivot ( Max (cnt) ")
                .append("FOR num IN (1 open, 2 CLOSE, 3 new)) ")
                .append(") bb ")
                .append(") aaaa ");

        //WEEK-2
        builder.append("UNION ALL ")
                .append("SELECT bbbb.*, '2' AS counter FROM ")
                .append("(SELECT * FROM ( ")
                .append("SELECT * FROM ( ")
                .append("SELECT * from( ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'1' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week2start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week2end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append("UNION all ")
                .append("SELECT issuetypename,fromPhase.phasename \"Phase\"  ,'2' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases fromPhase ")
                .append("ON Log.fromphaseid=fromPhase.phaseid ")
                .append("WHERE fromphaseid IS not NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week2start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week2end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,fromPhase.phasename ")
                .append("UNION ALL ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'3' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week2start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week2end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append(") aa ")
                .append(") ")
                .append("pivot ( Max (cnt) ")
                .append("FOR num IN (1 open, 2 CLOSE, 3 new)) ")
                .append(") bb ")
                .append(") bbbb ");

        //WEEK-3
        builder.append("UNION ALL ")
                .append("SELECT cccc.*, '3' AS counter FROM ")
                .append("(SELECT * FROM ( ")
                .append("SELECT * FROM ( ")
                .append("SELECT * from( ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'1' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week3start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week3end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append("UNION all ")
                .append("SELECT issuetypename,fromPhase.phasename \"Phase\"  ,'2' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases fromPhase ")
                .append("ON Log.fromphaseid=fromPhase.phaseid ")
                .append("WHERE fromphaseid IS not NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week3start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week3end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,fromPhase.phasename ")
                .append("UNION ALL ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'3' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week3start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week3end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append(") aa ")
                .append(") ")
                .append("pivot ( Max (cnt) ")
                .append("FOR num IN (1 open, 2 CLOSE, 3 new)) ")
                .append(") bb ")
                .append(") cccc ");

        //WEEK-4
        builder.append("UNION ALL ")
                .append("SELECT dddd.*, '4' AS counter FROM ")
                .append("(SELECT * FROM ( ")
                .append("SELECT * FROM ( ")
                .append("SELECT * from( ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'1' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week4start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week4end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append("UNION all ")
                .append("SELECT issuetypename,fromPhase.phasename \"Phase\"  ,'2' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases fromPhase ")
                .append("ON Log.fromphaseid=fromPhase.phaseid ")
                .append("WHERE fromphaseid IS not NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week4start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week4end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,fromPhase.phasename ")
                .append("UNION ALL ")
                .append("SELECT issuetypename,toPhase.phasename \"Phase\",'3' AS num, Count(1)  AS cnt ")
                .append("FROM  oam_rm_requestmanager_log Log ")
                .append("left JOIN oam_cr_issuetype iss ")
                .append("ON Log.requesttypeid=iss.issuetypeid ")
                .append("left join oam_cr_phases toPhase ")
                .append("ON Log.phaseid=toPhase.phaseid ")
                .append("WHERE Log.phaseid IS NOT NULL ")
                .append("AND  Trunc(logged)>=Trunc(To_date('").append(reportTimeWindow.get("week4start")).append("','MM/dd/yyyy'))")
                .append("AND  Trunc(logged)<=Trunc(To_date('").append(reportTimeWindow.get("week4end")).append("','MM/dd/yyyy'))")
                .append("GROUP BY issuetypename,toPhase.phasename ")
                .append(") aa ")
                .append(") ")
                .append("pivot ( Max (cnt) ")
                .append("FOR num IN (1 open, 2 CLOSE, 3 new)) ")
                .append(") bb ")
                .append(") dddd ");
        //ALL
        builder.append(") ")
                .append("pivot (max (OPEN) AS O,  max(CLOSE) AS C  , max(new)  AS N ")
                .append("FOR counter IN (1 week1, 2 week2 ,  3 week3, 4 week4 )) ")
                .append("");
        return builder.toString();

    }
}
