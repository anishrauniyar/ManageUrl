/*
 * Date : 2016-00-12 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class UIFieldModel {
    
}
