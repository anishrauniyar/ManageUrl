/*
 * Date : 2016-01-21
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.restservice;

import com.d2hawkeye.util.CommonUtils;
import com.d2hawkeye.util.CommonUtils.RequestCode;
import com.d2hawkeye.util.velocity.MailMessagePOJO;
import com.d2hs.soam.rm.queryBeanPM;
import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.dao.DashboardFilterDAO;
import com.verisk.ice.dao.IceDAO;
import com.verisk.ice.dao.IceTicketListDAO;
import com.verisk.ice.dao.OamTicketListDAO;
import com.verisk.ice.design.IceTicketListType;
import com.verisk.ice.design.OamTicketListType;
import com.verisk.ice.model.AppIdDTO;
import com.verisk.ice.model.ClientDTO;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.service.MailSender;
import com.verisk.ice.service.impl.MailSenderImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/dashboard")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RESTDashboard {

    private static final Logger LOG = LoggerFactory.getLogger(RESTDashboard.class.getName());

    public static final String ICE_ABBR = "ice";
   // public static final String OAM_ABBR = "oam";

    @POST
    @Path("/counts")
    public Map<String, Map<String, String>> findCounts(final DashboardFilterDTO dashboardFilter) throws InterruptedException {

        final Map<String, Map<String, String>> countsMap = new HashMap<>();
        final IceTicketListDAO iceTicketListDAO = new IceTicketListDAO();
       // final OamTicketListDAO oamTicketListDAO = new OamTicketListDAO();
        final StringBuilder queryIceUnion = new StringBuilder();
        //final StringBuilder queryOamUnion = new StringBuilder();
        //long startTime = System.nanoTime();

        //ICE QUERY  UNION ALL 
        queryIceUnion
                //BOX!
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.OVERALL_ICE_OPEN.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.OVERALL_ICE_COMPLETED.toString()))
                //BOX2
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.OVERALL_ICE_PAST_DUE.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.OVERALL_ICE_DUE_TODAY.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.OVERALL_ICE_CURRENT_AT_RISK.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.OVERALL_ICE_FUTURE.toString()))
                //BOX3
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTICKET_ICE_PAST_DUE.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTICKET_ICE_DUE_TODAY.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTICKET_ICE_CURRENT_AT_RISK.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTICKET_ICE_FUTURE.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTICKET_ICE_OPEN.toString()))
                //BOX4
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTEAM_PAST_DUE.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTEAM_DUE_TODAY.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTEAM_CURRENT_AT_RISK.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTEAM_FUTURE.toString()))
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.MYTEAM_TOTAL.toString()))
                //BOX5
                .append(" UNION ALL ")
                .append(iceTicketListDAO.countQuery(dashboardFilter, IceTicketListType.UP_FOR_GRABS_ICE.toString()));
       

        Thread iceCountMapThread = new Thread(new Runnable() {
            @Override
            public void run() {
                countsMap.put(ICE_ABBR, iceTicketListDAO.findCountMap(queryIceUnion.toString()));
            }
        });

       /* Thread oamCountMapThread = new Thread(new Runnable() {
            @Override
            public void run() {
                countsMap.put(OAM_ABBR, oamTicketListDAO.findCountMap(queryOamUnion.toString()));
            }
        });*/

        iceCountMapThread.start();
       // oamCountMapThread.start();

        iceCountMapThread.join();
      //  oamCountMapThread.join();
        iceTicketListDAO.takeDown();
       // oamTicketListDAO.takeDown();
        //long endTime = System.nanoTime();
        //System.out.println("com.verisk.ice.restservice.RESTDashboard.findCounts()->ByUnions=" + (double) (endTime - startTime) / (double) 1000000000);

        return countsMap;
    }

    @POST
    @Path("/appidbyclients")
    public List<AppIdDTO> findAppIdsByClients(DashboardFilterDTO dashboardFilter) {
        DashboardFilterDAO dashboardFilterDAO = new DashboardFilterDAO();
        List<AppIdDTO> appIdDTOs = dashboardFilterDAO.findAppIdsByClient(dashboardFilter);
        dashboardFilterDAO.takeDown();
        return appIdDTOs;
    }

    @POST
    @Path("/requesttypes")
    public List<String[]> findRequestTypes() {
        List<String[]> requestTypes = new ArrayList<>();
        for (RequestCode requestCode : CommonUtils.RequestCode.values()) {
            requestTypes.add(new String[]{"ice:" + requestCode.getRequestTypeId(), "" + requestCode.getRequestTitle()});
        }
        return requestTypes;
    }

    @POST
    @Path("/clients")
    public List<ClientDTO> findClients(DashboardFilterDTO dashboardFilter) {
        DashboardFilterDAO dashboardFilterDAO = new DashboardFilterDAO();
        List<ClientDTO> clientDTOs = dashboardFilterDAO.findClients(dashboardFilter);
        dashboardFilterDAO.takeDown();
        return clientDTOs;
    }

    @POST
    @Path("/loadDashboardFilter")
    public DashboardFilterDTO loadDashboardFilter(String userId, @Context HttpServletRequest request) {
        DashboardFilterDAO dashboardFilterDAO = new DashboardFilterDAO();
        DashboardFilterDTO dashboardFilterDTO = dashboardFilterDAO.find(userId);
        if (request != null && request.getSession() != null) {
            Object teamRole = request.getSession().getAttribute("TeamRole");
            if (teamRole != null) {
                dashboardFilterDTO.setTeamRole(teamRole.toString());
            } else {
                dashboardFilterDTO.setTeamRole("ANONYMOUS");
            }
        } else {
            dashboardFilterDTO.setTeamRole("ANONYMOUS");
        }
        dashboardFilterDAO.takeDown();
        return dashboardFilterDTO;
    }

    @POST
    @Path("/changeAssignee")
    public void changeAssignee(String userId, @QueryParam("requestCode") String requestCode, @Context HttpServletRequest request) {
        queryBeanPM queryBeanPM = new queryBeanPM();
        DashboardFilterDAO dashboardFilterDAO = new DashboardFilterDAO();
        MailSender mailSender = new MailSenderImpl();
        MailMessagePOJO oldMessagePOJO = new MailMessagePOJO();
        Map<String, String> values = new HashMap<>();
        if (queryBeanPM.getRequestDetails(requestCode)) {
            if (queryBeanPM.moveNext()) {
                oldMessagePOJO.setMainEnggName(queryBeanPM.checkEmptyAndNull(queryBeanPM.getData("User_Name")));
                values.put("requestTypeName", queryBeanPM.getData("issuetypename"));
                String phaseid = queryBeanPM.getData("phaseid");
                values.put("prevPhaseId", phaseid);
                values.put("currentPhaseId", phaseid);
            }
        }
        if (dashboardFilterDAO.changeAssignee(requestCode, userId)) {
            values.put("requestCode", requestCode);
            values.put("domainName", (String) request.getSession().getAttribute("DomainName"));
            values.put("userId", (String) request.getSession().getAttribute("UserID"));
            mailSender.sendMail(values, oldMessagePOJO);
        }
        dashboardFilterDAO.takeDown();
        queryBeanPM.takeDown();
    }

    @POST
    @Path("saveDashboardFilter")
    public void saveDashboardFilter(DashboardFilterDTO dashboardFilter) {
        DashboardFilterDAO dashboardFilterDAO = new DashboardFilterDAO();
        DashboardFilterDTO.separateStartAndEndDateByDaterange(dashboardFilter);
        if (dashboardFilterDAO.isExistByUserId(dashboardFilter.getUserid())) {
            dashboardFilterDAO.update(dashboardFilter.getUserid(), dashboardFilter);
        } else {
            dashboardFilterDAO.insert(dashboardFilter);
        }
        dashboardFilterDAO.takeDown();
    }

    @POST
    @Path("loadIceLinkIds")
    public List<String> loadIceLinkIds(String filterKey) {
        IceDAO iceDAO = new IceDAO();
        List<String> list = iceDAO.loadIceLinkIds(filterKey);
        iceDAO.takeDown();
        return list;
    }
}
