/*
 * Date : 2016-04-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service;

import com.d2hawkeye.util.velocity.MailMessagePOJO;
import com.verisk.ice.model.phaseswitch.DragDropInfo;
import com.verisk.ice.model.phaseswitch.DragDropInfoOAM;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface MailSender {

    void sendMailForPhaseSwitchDragDrop(DragDropInfo dragDropInfo, MailMessagePOJO oldMailMessagePOJO, String domainName, String userId);

    void sendMailForPhaseSwitchDragDropOAM(DragDropInfoOAM dragDropInfoOAM, String domainName, String userId);

    void sendMail(Map<String, String> values, MailMessagePOJO oldMailMessagePOJO);

    void sendMailOAM(Map<String, String> values, String event);
}
