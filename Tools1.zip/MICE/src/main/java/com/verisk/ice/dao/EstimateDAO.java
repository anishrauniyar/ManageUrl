/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.EstimateDTO;
import com.verisk.ice.utils.DTOUtils;
import java.sql.PreparedStatement;

/**
 *
 * @author i81324
 */
public final class EstimateDAO extends ConnectionBean implements CrudDAO<EstimateDTO> {

    private void setConnection() throws Exception {
        if (myConn == null || myConn.isClosed()) {
            setAlias("RequestManager->SuperDomainDataBase");
            this.makeConnection();
        }
    }

    @Override
    public void insert(final EstimateDTO entity) {
        String insertSQL = "INSERT INTO OAM_CR_ESTMANAGER "
                + "( requestcode, accountmanager, approvedby, approvedate, requestdescription, billableamount )"
                + " VALUES (?, ?, ?, ?, ?, ?)";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getRequestcode());
            ps.setString(2, entity.getAccountmanager());
            ps.setString(3, entity.getApprovedby());
            ps.setDate(4, DTOUtils.convertSQLDate(entity.getApprovedate()));
            ps.setString(5, entity.getRequestdescription());
            ps.setLong(6, DTOUtils.convertStringToLong(entity.getBillableamount()));
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(String requestCode, EstimateDTO entity) {
        String insertSQL = "UPDATE OAM_CR_ESTMANAGER SET "
                + "accountmanager = ?, approvedby = ?, approvedate = ?, requestdescription = ?, billableamount = ?  "
                + "WHERE requestcode = ?";
        try {
            setConnection();
            myConn.setAutoCommit(true);
            PreparedStatement ps = myConn.prepareStatement(insertSQL);
            ps.setString(1, entity.getAccountmanager());
            ps.setString(2, entity.getApprovedby());
            ps.setDate(3, DTOUtils.convertSQLDate(entity.getApprovedate()));
            ps.setString(4, entity.getRequestdescription());
            ps.setLong(5, DTOUtils.convertStringToLong(entity.getBillableamount()));
            ps.setString(6, requestCode);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public EstimateDTO find(String requestCode) {
        EstimateDTO estimateDTO = new EstimateDTO();
        String sql = "SELECT * FROM OAM_CR_ESTMANAGER WHERE  REQUESTCODE='" + requestCode + "'";
        if (getList(sql, "EstimateDAO#find(" + requestCode + ")")) {
            if (moveNext()) {
                estimateDTO.setAccountmanager(getData(EstimateDTO.DBColumns.ACCOUNTMANAGER.toString()));
                estimateDTO.setBillableamount(getData(EstimateDTO.DBColumns.BILLABLEAMOUNT.toString()));
                estimateDTO.setApprovedate(getOnlyDate(getData(EstimateDTO.DBColumns.APPROVEDATE.toString()), true));
                estimateDTO.setApprovedby(getData(EstimateDTO.DBColumns.APPROVEDBY.toString()));
                estimateDTO.setEstid(getData(EstimateDTO.DBColumns.ESTID.toString()));
                estimateDTO.setRequestcode(getData(EstimateDTO.DBColumns.REQUESTCODE.toString()));
                estimateDTO.setRequestdescription(getData(EstimateDTO.DBColumns.REQUESTDESCRIPTION.toString()));
            }
        }
        return estimateDTO;
    }

}
