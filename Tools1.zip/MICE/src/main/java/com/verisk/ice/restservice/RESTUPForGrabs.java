/*
 * Date : 2016-01-21
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.restservice;

import com.d2hawkeye.util.CommonUtils;
import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.dao.OamDAO;
import com.verisk.ice.model.upforgrabs.UpForGrabsSwitchWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.service.MailSender;
import com.verisk.ice.service.UpForGrabsService;
import com.verisk.ice.service.impl.MailSenderImpl;
import com.verisk.ice.service.impl.UpForGrabsServiceImpl;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/upforgrabs")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class RESTUPForGrabs {

    private static final Logger LOG = LoggerFactory.getLogger(RESTUPForGrabs.class.getName());

    public static final String ICE_ABBR = "ice";
    public static final String OAM_ABBR = "oam";

    @POST
    @Path("/allIce")
    public UpForGrabsSwitchWrapper findUpForGrabsSwitchWrapperICE(DashboardFilterWrapper dashboardFilterWrapper) {
        UpForGrabsService upForGrabsService = new UpForGrabsServiceImpl();
        return upForGrabsService.findUpForGrabsSwitchWrapperICE(dashboardFilterWrapper);
    }

    @POST
    @Path("/allOam")
    public UpForGrabsSwitchWrapper findUpForGrabsSwitchWrapperOAM(DashboardFilterWrapper dashboardFilterWrapper) {
        UpForGrabsService upForGrabsService = new UpForGrabsServiceImpl();
        return upForGrabsService.findUpForGrabsSwitchWrapperOAM(dashboardFilterWrapper);
    }

    @POST
    @Path("/changeAssigneeOAM")
    public void changeAssignee(String userId, @QueryParam("appId") String appId, @QueryParam("prevAssignee") String prevAssignee,@QueryParam("phase") String phase, @QueryParam("client") String client, @Context HttpServletRequest request) {
        OamDAO oamDAO = new OamDAO();
        Map<String, String> changeObj = new HashMap<>();
        changeObj.put("appid", appId);
        changeObj.put("assignedto", userId);
        changeObj.put("seesionUserId", (String) request.getSession().getAttribute(CommonUtils.SessionAttributes.UserID.toString()));
        changeObj.put("phase",phase);
        changeObj.put("client", client);
        if (oamDAO.changeAssignee(changeObj)) {
            MailSender mailSender = new MailSenderImpl();
            Map<String, String> values = new HashMap<>();
            values.put("appid", appId);
            values.put("prevAssignee", prevAssignee);
            values.put("prevPhaseCode", "");
            values.put("currentPhaseCode", "");
            values.put("domainName", (String) request.getSession().getAttribute(CommonUtils.SessionAttributes.DomainName.toString()));
            values.put("userId", (String) request.getSession().getAttribute(CommonUtils.SessionAttributes.UserID.toString()));
            mailSender.sendMailOAM(values,"ASSIGNEE");
        }
        oamDAO.takeDown();
    }

}
