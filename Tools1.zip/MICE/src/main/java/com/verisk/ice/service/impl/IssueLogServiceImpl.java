/*
 * Date : 2016-00-21 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.IssueLogDAO;
import com.verisk.ice.model.PageSwitcherDTO;
import com.verisk.ice.model.wrapper.IssueLogFilterWrapper;
import com.verisk.ice.model.wrapper.IssueLogWrapper;
import com.verisk.ice.service.IssueLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IssueLogServiceImpl implements IssueLogService {

    private static final Logger LOG = LoggerFactory.getLogger(IssueLogServiceImpl.class.getName());

    @Override
    public IssueLogWrapper findAll(IssueLogFilterWrapper issueLogFilterWrapper) {
        IssueLogDAO issueLogDAO = new IssueLogDAO();
        IssueLogFilterWrapper.setDefaultPageSwitcherIfNeccessary(issueLogFilterWrapper, PageSwitcherDTO.PageSwitcherDTOType.TABLE_LIST_VIEW);
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(issueLogFilterWrapper));
        }
        IssueLogWrapper issueLogWrapper = issueLogDAO.findIssueLogByIssueLogFilterWrapper(issueLogFilterWrapper);
        issueLogDAO.takeDown();
        return issueLogWrapper;
    }

}
