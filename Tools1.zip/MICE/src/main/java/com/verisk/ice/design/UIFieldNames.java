/*
 * Date : 2015-12-02
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.design;

/**
 *
 * @author i81324
 */
public enum UIFieldNames {

    ImplementationType("implementationtype"),
    ApplicationType("applicationtype"),
    DataType("dataType"),
    newAIPLayoutID("newAIPLayoutID"),
    oldAIPLayoutID("oldAIPLayoutID"),
    implementedByImplementationServices("implementedByImplementationServices"),
    ImplementationICEID("ImplementationICEID"),
    PrioritizedBy("PrioritizedBy");

    private final String field;

    private UIFieldNames(String field) {
        this.field = field;
    }

    public String getField() {
        return field;
    }

}
