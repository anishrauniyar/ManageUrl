/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.service;

import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface TicketListService {

    TicketListWrapper findTicketList(TicketListFilterWrapper ticketListFilterWrapper, String type, String app);
    
    TicketListWrapper findTicketListWithoutPagination(TicketListFilterWrapper ticketListFilterWrapper, String type, String app);
    
    TicketListWrapper findTicketListGrid(TicketListFilterWrapper ticketListFilterWrapper, String type, String app);

    String findCount(DashboardFilterDTO dashboardFilterDTO, String type, String app);

    Map<String, Object> prepareForQuickEdit(String requestCode, String type, String app);

}
