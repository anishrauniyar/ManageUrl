/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.phaseswitch.DragDropInfo;
import com.verisk.ice.model.phaseswitch.DragDropInfoOAM;
import com.verisk.ice.model.phaseswitch.OamPhaseSwitchWrapper;
import com.verisk.ice.model.phaseswitch.PhaseSwitchFilterWrapper;
import com.verisk.ice.model.phaseswitch.PhaseSwitchWrapper;
import com.verisk.ice.service.PhaseSwtichService;
import com.verisk.ice.service.impl.PhaseSwtichServiceImpl;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/phaseswitch")
@Produces(MediaType.APPLICATION_JSON)
public class RESTPhaseSwitch {

    @POST
    @Path("/all")
    public List<PhaseSwitchWrapper> allPhaseSwitchWrapper(PhaseSwitchFilterWrapper phaseSwitchFilterWrapper) {
        PhaseSwtichService phaseSwtichService = new PhaseSwtichServiceImpl();
        return phaseSwtichService.findPhaseSwitchWrapperWithoutPagination(phaseSwitchFilterWrapper);
    }

    @POST
    @Path("/allOam")
    public OamPhaseSwitchWrapper allOamPhaseSwitchWrapper(DashboardFilterDTO dashboardFilterDTO) {
        PhaseSwtichService phaseSwtichService = new PhaseSwtichServiceImpl();
        return phaseSwtichService.findOamPhaseSwitchWrapperWithoutPagination(dashboardFilterDTO);
    }

    @POST
    @Path("/changephaseOAM")
    public void changeDragDropInfoOAM(DragDropInfoOAM dragDropInfoOAM, @Context HttpServletRequest request) {
        PhaseSwtichService phaseSwtichService = new PhaseSwtichServiceImpl();
        phaseSwtichService.changeDragDropInfoOAM(dragDropInfoOAM, request);
    }

    @POST
    @Path("/changephase")
    public void changeDragDropInfo(DragDropInfo dragDropInfo, @Context HttpServletRequest request) {
        PhaseSwtichService phaseSwtichService = new PhaseSwtichServiceImpl();
        phaseSwtichService.changeDragDropInfo(dragDropInfo, request);
    }

    @POST
    @Path("/icerequesttypeswithcount")
    public List<Map<String, String>> findIceRequestTypesWithCount(DashboardFilterDTO dashboardFilterDTO) {
        PhaseSwtichService phaseSwtichService = new PhaseSwtichServiceImpl();
        return phaseSwtichService.findIceRequestTypesWithCount(dashboardFilterDTO);
    }

    @POST
    @Path("/getAllUser")
    public List<Map<String, String>> getAllUser() {
        PhaseSwtichService phaseSwtichService = new PhaseSwtichServiceImpl();
        return phaseSwtichService.getAllUser();
    }

}
