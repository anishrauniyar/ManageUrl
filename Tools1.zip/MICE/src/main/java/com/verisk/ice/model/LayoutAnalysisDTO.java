/*
 * Date : 2015-12-09
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import com.d2hawkeye.util.MapObjectUtils;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author i81324
 */
public class LayoutAnalysisDTO {

    public enum DBColumns {

        LAID, REQUESTCODE, EIGERPATH, REASONCHANGE, ADDITIONALCOMMENTS, ACCOUNTMANAGER, APPROVEDBY, APPROVEDATE, REQUESTDESCRIPTION
    }

    private String laid;
    private String requestcode;
    private String eigerpath; //Layout Location
    private String reasonchange;
    private String additionalcomments;
    private String accountmanager;
    private String approvedby;
    private String approvedate;
    private String requestdescription;

    public static LayoutAnalysisDTO initObjectByHttpRequest(HttpServletRequest request) {
        LayoutAnalysisDTO analysisDTO = new LayoutAnalysisDTO();
        if (request == null) {
            return analysisDTO;
        }
        analysisDTO.setAccountmanager(MapObjectUtils.mapStringWithNotNull(request.getParameter("accountmanager")));
        analysisDTO.setAdditionalcomments(MapObjectUtils.mapStringWithNotNull(request.getParameter("additionalComments")));
        analysisDTO.setApprovedate(MapObjectUtils.mapStringWithNotNull(request.getParameter("approvalDate")));
        analysisDTO.setApprovedby(MapObjectUtils.mapStringWithNotNull(request.getParameter("approvedBy")));
        analysisDTO.setEigerpath(MapObjectUtils.mapStringWithNotNull(request.getParameter("eigerPath")));
        analysisDTO.setRequestdescription(MapObjectUtils.mapStringWithNotNull(request.getParameter("requestDescription")));
        analysisDTO.setReasonchange(MapObjectUtils.mapStringWithNotNull(request.getParameter("layoutChangeReason")));
        analysisDTO.setRequestcode(MapObjectUtils.mapStringWithNotNull(request.getParameter("ProjectID")));
        return analysisDTO;
    }

    public LayoutAnalysisDTO() {
    }
    
    public LayoutAnalysisDTO(LayoutAnalysisDTO analysisDTO) {
        this.accountmanager = analysisDTO.accountmanager;
        this.additionalcomments = analysisDTO.additionalcomments;
        this.approvedate = analysisDTO.approvedate;
        this.approvedby = analysisDTO.approvedby;
        this.eigerpath = analysisDTO.eigerpath;
        this.laid = analysisDTO.laid;
        this.reasonchange = analysisDTO.reasonchange;
        this.requestcode = analysisDTO.requestcode;
        this.requestdescription = analysisDTO.requestdescription;
    }

    public String getRequestcode() {
        return requestcode;
    }

    public void setRequestcode(String requestcode) {
        this.requestcode = requestcode;
    }

    public String getEigerpath() {
        return eigerpath;
    }

    public void setEigerpath(String eigerpath) {
        this.eigerpath = eigerpath;
    }

    public String getReasonchange() {
        return reasonchange;
    }

    public void setReasonchange(String reasonchange) {
        this.reasonchange = reasonchange;
    }

    public String getAdditionalcomments() {
        return additionalcomments;
    }

    public void setAdditionalcomments(String additionalcomments) {
        this.additionalcomments = additionalcomments;
    }

    public String getAccountmanager() {
        return accountmanager;
    }

    public void setAccountmanager(String accountmanager) {
        this.accountmanager = accountmanager;
    }

    public String getApprovedby() {
        return approvedby;
    }

    public void setApprovedby(String approvedby) {
        this.approvedby = approvedby;
    }

    public String getLaid() {
        return laid;
    }

    public void setLaid(String laid) {
        this.laid = laid;
    }

    public String getApprovedate() {
        return approvedate;
    }

    public void setApprovedate(String approvedate) {
        this.approvedate = approvedate;
    }

    public String getRequestdescription() {
        return requestdescription;
    }

    public void setRequestdescription(String requestdescription) {
        this.requestdescription = requestdescription;
    }
    
}
