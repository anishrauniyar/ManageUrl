/*
 * Date : 2016-00-12 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@AllArgsConstructor
@Getter
public enum UISpecification {
    requestDate(UIFieldType.palinText, "Request Date", false, "");

    private final UIFieldType type;
    private final String label;
    private final boolean refreshDefaultValues;
    private final String defaultValuesFetchSQLQuery;
}
