/*
 * Date : 2016-02-03
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */

package com.verisk.ice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CountListDTO {

    private String id;
    private String description;
}
