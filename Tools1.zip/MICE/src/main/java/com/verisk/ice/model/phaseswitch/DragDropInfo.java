/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.phaseswitch;

import com.verisk.ice.utils.ValidateUtility;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DragDropInfo {

    private String assignee;
    private String remarks;
    private DataDropZone dataDropZone;
    private DataDragItem dataDragItem;

    public static boolean isValidDragDropPhaseSwitchConstraints(DragDropInfo dragDropInfo) {
        try {
            ValidateUtility.isNotNull(dragDropInfo);
            ValidateUtility.isNotNull(dragDropInfo.getDataDragItem());
            ValidateUtility.isNotNull(dragDropInfo.getDataDropZone());
            ValidateUtility.isNotNull(dragDropInfo.getDataDragItem().getDataDragItemRequestTypeId());
            ValidateUtility.isNotNull(dragDropInfo.getDataDragItem().getDataDragItemPhaseId());
            //DRAG AND DROP RESTRICTION CONTRAINTS
            if (!dragDropInfo.getDataDragItem().getDataDragItemRequestTypeId().equals(dragDropInfo.getDataDropZone().getDataDropZoneRequestTypeId())) {
                return false;
            }
            if (dragDropInfo.getDataDragItem().getDataDragItemPhaseId().equals(dragDropInfo.getDataDropZone().getDataDropZonePhaseId())) {
                return false;
            }
            //END
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
