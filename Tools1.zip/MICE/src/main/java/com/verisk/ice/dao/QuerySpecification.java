/*
 * Date : 2016-00-15 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao;

import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
public enum QuerySpecification {
    INSTANCE;

    private final String clientsAllQuery = "SELECT * FROM OAM_RM_CLIENTS";

    public String getMyTeamUserIdsQueryIN(String userid, String app) {
        return " SELECT * FROM ("
                + " SELECT Regexp_substr(t.userids, '[^,]+', 1, LEVEL) userids "
                + " FROM   (SELECT Get_my_team_userids('" + userid + "', '" + app + "') AS userids "
                + "        FROM   dual) t "
                + " CONNECT BY LEVEL <= Regexp_count(t.userids, '[,]+') + 1 "
                + " ) WHERE USERIDS IS NOT NULL GROUP BY USERIDS";
    }

    public String getMyTeamPhaseIdsQueryIN(String userid, String app) {
        return " SELECT DISTINCT PHASEID  FROM oam_cr_role_phase WHERE TEAMID IN ( "
                + " SELECT DISTINCT TEAMID FROM oam_cr_user_role r, oam_cr_team t"
                + " WHERE r.userid='" + userid + "' AND r.teamid=t.id AND t.application IN ('" + app + "'))";
    }

    public String getMyTeamPhaseIdsQueryINByTeamId(String teamId, String app) {
        return " SELECT DISTINCT PHASEID FROM oam_cr_role_phase   tp "
                + " left JOIN oam_cr_team t      "
                + " ON t.id = tp.teamid  "
                + " WHERE teamid='" + teamId + "' AND t.application IN ('" + app + "') ";
    }

    public String getMyTeamUserIdsQueryINByTeamId(String teamId, String app) {
        return " SELECT DISTINCT userid FROM oam_cr_user_role   tp "
                + " left JOIN oam_cr_team t      "
                + " ON t.id = tp.teamid  "
                + " WHERE teamid='" + teamId + "' AND t.application IN ('" + app + "') ";
    }

    public String getMyTeamNamesQueryINByPhaseId(String phaseId, String app) {
        return "SELECT listagg(t.name, ',') WITHIN GROUP(ORDER BY t.name) teamnames FROM oam_cr_team t, oam_cr_role_phase p "
                + "WHERE   "
                + "t.id=p.teamid AND t.application IN ('" + app + "') AND p.PHASEID='" + phaseId + "' ";
    }

    public String getMyTeamManagerNamesQueryINByPhaseId(String phaseId, String app) {
        return "SELECT listagg(usr.username, ',') WITHIN GROUP(ORDER BY usr.username) teamnames FROM oam_cr_team t, "
                + "oam_cr_role_phase p, oam_cr_manager_role m, usr_users usr "
                + "WHERE   "
                + "t.id=p.teamid AND t.application IN ('" + app + "') AND m.teamid=t.id AND usr.userid=m.userid AND p.PHASEID='" + phaseId + "'";
    }
}
