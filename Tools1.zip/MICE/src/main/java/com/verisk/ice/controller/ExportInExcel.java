/*
 * Date : 2016-06-07 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.controller;

import com.verisk.ice.design.ReportType;
import com.verisk.ice.service.ExcelReport;
import com.verisk.ice.service.impl.ExcelReportImpl;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.jxls.area.Area;
import org.jxls.builder.AreaBuilder;
import org.jxls.builder.xls.XlsCommentAreaBuilder;
import org.jxls.common.Context;
import org.jxls.transform.Transformer;
import org.jxls.transform.poi.PoiTransformer;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class ExportInExcel extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        exportInExcel(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Export In Excel";
    }

    private void exportInExcel(HttpServletRequest request, HttpServletResponse response) throws IOException {

        ReportType reportType = ReportType.valueOf(request.getParameter("excelType"));
        if (reportType != null) {
            OutputStream os = response.getOutputStream();
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream(reportType.getXlsxFileName());
            try (InputStream is = inputStream) {
                ExcelReport excelReport = new ExcelReportImpl();
                String fileName = reportType.getReportName() + System.currentTimeMillis() + ".xlsx";
                response.setContentType("application/vnd.ms-excel");
                response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

                Transformer transformer = PoiTransformer.createTransformer(is, os);
                AreaBuilder areaBuilder = new XlsCommentAreaBuilder(transformer);
                List<Area> xlsAreaList = areaBuilder.build();
                Area xlsArea = xlsAreaList.get(0);

                Context context = new Context();
                Calendar calender = Calendar.getInstance();
                String today = (calender.get(Calendar.MONTH) + 1) + "/" + calender.get(Calendar.DAY_OF_MONTH) + "/" + calender.get(Calendar.YEAR);
                context.putVar("today", today);

                if (reportType.toString().equals(ReportType.TICKETS_FLOW_REPORT.toString())) {
                    excelReport.dumpTicketsFlowReport(context, xlsArea);
                } else if (reportType.toString().equals(ReportType.ICE_AGE_REPORT.toString())) {
                    excelReport.dumpIceAgeReport(context, xlsArea);
                } else if (reportType.toString().equals(ReportType.ICE_AGE_REPORT_BY_ID.toString())) {
                    Map<String, String> params = new HashMap<>();
                    params.put("pkSourceId", request.getParameter("pkSourceId"));
                    excelReport.dumpIceAgeReportById(context, xlsArea, params);
                } else {
                    return;
                }

                transformer.write();
                is.close();

            } catch (Exception ex) {
                System.out.println("com.verisk.ice.controller.ExportInExcel.doPost()" + ex.getMessage());
            } finally {
                if (os != null) {
                    os.flush();
                    os.close();
                }

            }
        }

    }

}
