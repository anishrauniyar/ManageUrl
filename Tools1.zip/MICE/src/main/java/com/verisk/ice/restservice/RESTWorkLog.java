/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;
import com.verisk.ice.model.worklog.WorkLogDTO;
import com.verisk.ice.service.WorkLogService;
import com.verisk.ice.service.impl.WorkLogServiceImpl;
import java.util.List;
import java.util.Map;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/worklog")
@Produces(MediaType.APPLICATION_JSON)
public class RESTWorkLog {

    @POST
    @Path("/save")
    public void saveWorkLog(WorkLogDTO workLogDTO) {
        WorkLogService workLogService = new WorkLogServiceImpl();
        workLogService.saveWorkLog(workLogDTO);
    }

    @POST
    @Path("/history")
    public List<Map<String, String>> getWorkLogHistory(String requestCode) {
        WorkLogService workLogService = new WorkLogServiceImpl();
        return workLogService.getWorkLogHistory(requestCode);
    }

}
