/*
 * Date : 2016-00-11 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.dao;

import com.d2hs.soam.ConnectionBean;
import com.verisk.ice.model.ui.UIOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class UILayoutDAO extends ConnectionBean {

    public List<UIOption> findAllOptionsBySQLQuery(String sql) {
        if (sql != null) {
            if (getList(sql, "UILayoutDAO#findAllOptionsBySQLQuery()")) {
                List<UIOption> uIOptions = new ArrayList<>();
                while (moveNext()) {
                    uIOptions.add(new UIOption(getData("ID"), getData("LABEL")));
                }
                return uIOptions;
            }
        }
        return Collections.emptyList();
    }
}
