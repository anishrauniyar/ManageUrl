/*
 * Date : 2016-01-28
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */

package com.verisk.ice.model;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class ClientInPhaseDTO {

}
