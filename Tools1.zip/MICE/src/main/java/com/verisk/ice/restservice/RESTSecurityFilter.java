/*
 * Date : 2016-00-10 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.restservice;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public class RESTSecurityFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        if ((request instanceof HttpServletRequest) && (response instanceof HttpServletResponse)) {
            HttpServletRequest httpServletRequest = (HttpServletRequest) request;
            HttpServletResponse httpServletResponse = (HttpServletResponse) response;
            if (isSessionValid(httpServletRequest)) {
                System.out.println("REST service url are authorized.");
            } else {
                System.out.println("REST service url are unauthorized.");
                httpServletResponse.sendRedirect("/Logout.jsp");
                return;
            }
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    }

    private boolean isSessionValid(HttpServletRequest httpServletRequest) {
        HttpSession session = httpServletRequest.getSession();
        String isLoginValid = (String) session.getAttribute("isValid");
        return "Valid".equalsIgnoreCase(isLoginValid);
    }

}
