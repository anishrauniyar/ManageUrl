/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.restservice;

import com.sun.jersey.spi.resource.Singleton;

import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.wrapper.FactsAndStatsWrapper;
import com.verisk.ice.service.FactsAndStatsService;
import com.verisk.ice.service.impl.FactsAndStatsServiceImpl;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Singleton
@Path("/factsandstats")
@Produces(MediaType.APPLICATION_JSON)
public class RESTFactsAndStats {

    @POST
    @Path("/all")
    public FactsAndStatsWrapper allFactsAndStats(@QueryParam("searchKey") String searchKey, DashboardFilterWrapper dashboardFilterWrapper) {
        FactsAndStatsService factsAndStatsService = new FactsAndStatsServiceImpl();
        return factsAndStatsService.findFactsAndStats(dashboardFilterWrapper, searchKey);
    }

}
