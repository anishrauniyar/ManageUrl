/*
 * Date : 2016-05-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.upforgrabs;

import com.verisk.ice.model.wrapper.TicketListWrapper;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UpForGrabsMyTeam {

    private String userid;
    private String name;
    private TicketListWrapper listWrapper;
}
