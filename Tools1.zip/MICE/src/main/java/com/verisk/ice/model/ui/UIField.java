/*
 * Date : 2016-00-11 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UIField {

    private String uniqueId;
    private String type;
    private String label;
    private String value;
    private List<UIOption> defaultValues;
    private String inputType;

}
