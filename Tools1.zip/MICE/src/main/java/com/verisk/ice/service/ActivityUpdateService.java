/*
 * Date : 2016-01-25
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.service;

import com.verisk.ice.model.ActivityUpdateDTO;
import com.verisk.ice.model.wrapper.ActivityUpdateWrapper;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public interface ActivityUpdateService {

    ActivityUpdateWrapper findActivityUpdates(DashboardFilterWrapper dashboardFilterWrapper);

    List<ActivityUpdateDTO> findAllHistoryLogByRequestCode(Map<String, String> historyFilterWrapper);

    void saveSkipActivityUpdate(String activityUpdateId, String userId);
}
