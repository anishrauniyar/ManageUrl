/*
 * Date : 2016-00-12 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.model.ui;

import java.util.List;


public class UIFieldBuilder {

    private String uniqueId;
    private String type;
    private String label;
    private String value;
    private List<UIOption> defaultValues;
    private String inputType;

    public UIFieldBuilder() {
    }

    public UIFieldBuilder setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
        return this;
    }

    public UIFieldBuilder setType(String type) {
        this.type = type;
        return this;
    }

    public UIFieldBuilder setLabel(String label) {
        this.label = label;
        return this;
    }

    public UIFieldBuilder setValue(String value) {
        this.value = value;
        return this;
    }

    public UIFieldBuilder setDefaultValues(List<UIOption> defaultValues) {
        this.defaultValues = defaultValues;
        return this;
    }

    public UIFieldBuilder setInputType(String inputType) {
        this.inputType = inputType;
        return this;
    }

    public UIField createUIField() {
        return new UIField(uniqueId, type, label, value, defaultValues, inputType);
    }
    
}
