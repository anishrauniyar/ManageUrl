/*
 * Date : 2016-02-08
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.model;

import com.d2hawkeye.util.MapObjectUtils;
import com.verisk.ice.design.DBDefination;
import com.verisk.ice.design.DataType;
import javax.servlet.http.HttpServletRequest;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
@Getter
@Setter
@NoArgsConstructor
public class DefectDTO {

    @DBDefination(columnName = "defid", dataType = DataType.NUMBER)
    private String defid;
    @DBDefination(columnName = "requestcode", dataType = DataType.NUMBER)
    private String requestcode;
    @DBDefination(columnName = "requestcode", dataType = DataType.NUMBER)
    private String application;
    //No db column only used for temporary
    private String applicationName;
    @DBDefination(columnName = "requestcode", dataType = DataType.NUMBER)
    private String component;
    @DBDefination(columnName = "requestcode", dataType = DataType.VARCHAR2)
    private String componentName;
    @DBDefination(columnName = "requestcode", dataType = DataType.NUMBER)
    private String impactedcomponent;
    @DBDefination(columnName = "requestcode", dataType = DataType.VARCHAR2)
    private String impactedcomponentName;
    @DBDefination(columnName = "requestcode", dataType = DataType.NUMBER)
    private String requestdescription;
    @DBDefination(columnName = "category", dataType = DataType.VARCHAR2)
    private String category;
    @DBDefination(columnName = "subType", dataType = DataType.VARCHAR2)
    private String subType;
    @DBDefination(columnName = "categoryName", dataType = DataType.VARCHAR2)
    private String categoryName;
    @DBDefination(columnName = "subTypeName", dataType = DataType.VARCHAR2)
    private String subTypeName;
    @DBDefination(columnName = "RootCause", dataType = DataType.VARCHAR2)
    private String RootCause;

    public static DefectDTO initObjectByHttpRequest(HttpServletRequest request) {
        DefectDTO defectDTO = new DefectDTO();
        if (request == null) {
            return defectDTO;
        }
        defectDTO.setApplication(MapObjectUtils.mapStringWithNotNull(request.getParameter("defectApplication")));
        defectDTO.setComponent(MapObjectUtils.mapStringWithNotNull(request.getParameter("defectComponent")));
        defectDTO.setComponentName(MapObjectUtils.mapStringWithNotNull(request.getParameter("defectComponentName")));
        defectDTO.setImpactedcomponent(MapObjectUtils.mapStringWithNotNull(request.getParameter("defectImpactedComponent")));
        defectDTO.setImpactedcomponentName(MapObjectUtils.mapStringWithNotNull(request.getParameter("defectImpactedComponentName")));
        defectDTO.setRequestcode(MapObjectUtils.mapStringWithNotNull(request.getParameter("ProjectID")));
        defectDTO.setRequestdescription(MapObjectUtils.mapStringWithNotNull(request.getParameter("requestDescription")));
        defectDTO.setCategory(MapObjectUtils.mapStringWithNotNull(request.getParameter("category")));
        defectDTO.setSubType(MapObjectUtils.mapStringWithNotNull(request.getParameter("subType")));
        defectDTO.setRootCause(MapObjectUtils.mapStringWithNotNull(request.getParameter("RootCause")));
        return defectDTO;
    }

    public DefectDTO(DefectDTO defectDTO) {
        this.application = defectDTO.application;
        this.component = defectDTO.component;
        this.defid = defectDTO.defid;
        this.impactedcomponent = defectDTO.impactedcomponent;
        this.requestcode = defectDTO.requestcode;
        this.requestdescription = defectDTO.requestdescription;
        this.applicationName = defectDTO.applicationName;
        this.componentName = defectDTO.componentName;
        this.impactedcomponentName = defectDTO.impactedcomponentName; 
        this.category=defectDTO.category;
        this.subType=defectDTO.subType;
        this.RootCause=defectDTO.RootCause;
        this.categoryName = defectDTO.categoryName;
        this.subTypeName =  defectDTO.subTypeName;
    }
}
