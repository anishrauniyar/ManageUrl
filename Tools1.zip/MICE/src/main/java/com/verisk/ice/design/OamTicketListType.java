/*
 * Date : 2016-02-29
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.design;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.QuerySpecification;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.utils.DAOUtils;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.Getter;

/**
 *
 * @author Bhuwan Prasad Upadhyay
 */
public enum OamTicketListType {

    /*
    Note: Before change enum constants please see the method #getRootQueryByTicketListType(...)
    Warnning:
        -> OVERALL
        -> MYTICKET
    - Starting these word enum  are use carefully here
    - help: please see the method : getRootQueryByTicketListType(...) for 
     */
    OVERALL_OAM("All OAM Tickets", "   "),
    OVERALL_OAM_OPEN("All OAM Tickets", "   "),
    OVERALL_OAM_COMPLETED("All OAM Tickets", " AND Upper(phasedesc) IN ('POSTED','ON HOLD','PENDING','WAITING ON DATA FROM CLIENT') "),
    MYTEAM_PAST_DUE("OAM | Past Due -> My Team", " AND TRUNC(TARGETDATE) < TRUNC(SYSDATE)    "),
    MYTEAM_DUE_TODAY("OAM | Due Today -> My Team", " AND TRUNC(TARGETDATE) = TRUNC(SYSDATE)    "),
    MYTEAM_TOTAL("OAM | Total -> My Team", "    "),
    MYTEAM_CURRENT_AT_RISK("OAM | Current At Risk -> My Team", " AND ( TRUNC(TARGETDATE)=TRUNC(ADD_WORKING_DAYS('1', SYSDATE)) OR  TRUNC(TARGETDATE)=TRUNC(ADD_WORKING_DAYS('2', SYSDATE)))    "),
    MYTEAM_FUTURE("OAM | Future -> My Team", " AND ( TRUNC(TARGETDATE) > TRUNC(ADD_WORKING_DAYS('2', SYSDATE)) OR TARGETDATE IS null )    "),
    OVERALL_OAM_PAST_DUE("OAM | Past Due -> Overall", " AND ( TRUNC(TARGETDATE) < TRUNC(SYSDATE) )    "),
    OVERALL_OAM_DUE_TODAY("OAM | Due Today -> Overall", " AND TRUNC(TARGETDATE) = TRUNC(SYSDATE)    "),
    OVERALL_OAM_CURRENT_AT_RISK("OAM | Current At Risk -> Overall", " AND ( TRUNC(TARGETDATE)=TRUNC(ADD_WORKING_DAYS('1', SYSDATE)) OR  TRUNC(TARGETDATE)=TRUNC(ADD_WORKING_DAYS('2', SYSDATE)))     "),
    OVERALL_OAM_FUTURE("OAM | Future -> Overall", " AND ( TRUNC(TARGETDATE) > TRUNC(ADD_WORKING_DAYS('2', SYSDATE)) OR TARGETDATE IS null )     "),
    MYTICKET_OAM_PAST_DUE("OAM | Past Due -> My Tickets", " AND TRUNC(TARGETDATE) < TRUNC(SYSDATE)    "),
    MYTICKET_OAM_DUE_TODAY("OAM | Due Today -> My Tickets", " AND TRUNC(TARGETDATE) = TRUNC(SYSDATE)    "),
    MYTICKET_OAM_CURRENT_AT_RISK("OAM | Current At Risk -> My Tickets", " AND ( TRUNC(TARGETDATE)=TRUNC(ADD_WORKING_DAYS('1', SYSDATE)) OR  TRUNC(TARGETDATE)=TRUNC(ADD_WORKING_DAYS('2', SYSDATE)))     "),
    MYTICKET_OAM_FUTURE("OAM | Future -> My Tickets", " AND (TRUNC(TARGETDATE) > TRUNC(ADD_WORKING_DAYS('2', SYSDATE)) OR TARGETDATE IS null )     "),
    MYTICKET_OAM_OPEN("OAM | My Tickets", " "),
    UP_FOR_GRABS_OAM("OAM -> Up For Grabs", "     "),
    USER_OAM_TICKET_UP_FOR_GRABS("My Open Tickets", "   "),
    UNASSIGNED_OAM_TICKET_UP_FOR_GRABS("My Open Tickets", "   "),
    OAM_PHASE_SWITCH("OAM Phase Switch", "");

    @Getter
    private final String tableHeaderTitle;
    @Getter
    private final Map<String, String> tableColumnKeyLabel;
    @Getter
    private final String predicateQueryAppender;

    private OamTicketListType(String tableHeaderTitle, String predicateQueryAppender) {
        this.tableHeaderTitle = tableHeaderTitle;
        this.tableColumnKeyLabel = new LinkedHashMap<String, String>() {
            {
                put("clientid", "Client ID");
                put("appid", "App ID");
                put("applicationname", "Application Name");
                put("commentdesc", "Comment");
                put("phasecode", "Phase Code");
                put("phasedesc", "Current Phase");
                put("targetdate", "Target Date");
                put("assigneeid", "Assigned To");
                put("assignee", "Assignee"); //Assignee Username
                put("targetdate", "Target Date");
            }
        };
        this.predicateQueryAppender = predicateQueryAppender;
    }

    public String getRootQueryByTicketListType(OamTicketListType ticketListType, TicketListFilterWrapper ticketListFilterWrapper) {
        String rootQuery = "SELECT p.appid, app.clientid, app.applicationname, p.phasecode, phase.phasedesc, To_char(p.targetdate,'MM/DD/YYYY') as targetdate,"
                + " SUBSTR(Trim(p.comment_), 0, 60) as commentdesc, p.assignedto as assigneeid, rp.username as assignee  from "
                + "   oam_productionmanager  p "
                + "         left JOIN   oam_pm_phases  phase "
                + "         ON p.PHASECODE=phase.PHASECODE "
                + "         left JOIN oam_clientapps app "
                + "         ON p.appid=app.applicationid "
                + "       left join (SELECT userid,  "
                + "                         username "
                + "                  FROM   usr_users where oamstatus=1) rp  "
                + "              ON p.assignedto = rp.userid  "
                + "         WHERE 1=1 and inproduction='Y' "
                + ticketListType.getPredicateQueryAppender();

        //ADDING FILTER PARAMETES IN QUERY
        rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("p.appid", rootQuery, ticketListFilterWrapper.getDashboardFilter().getAppids());
        rootQuery = DAOUtils.addQueryForFilterOnSingleColumn("app.clientid", rootQuery, ticketListFilterWrapper.getDashboardFilter().getClientids());
        //END

        //MYTICKET + UP_FOR_GRABS + OAM_PHASE_SWITCH //PHASE CODE MAPPING WITH USER TEAMS
        if (ticketListType.toString().startsWith("MYTEAM")
                || ticketListType.toString().contains("UP_FOR_GRABS")
                || ticketListType.toString().startsWith("OAM_PHASE_SWITCH")) {
            rootQuery += " AND phase.phasecode IN ( "
                    + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryIN(ticketListFilterWrapper.getDashboardFilter().getUserid(), "OAM")
                    + ") ";
        }
        //END

        //MYTICKET
        if (ticketListType.toString().startsWith("MYTICKET")
                || ticketListType.toString().startsWith("OAM_PHASE_SWITCH")) {
            rootQuery += " AND p.assignedto='" + ticketListFilterWrapper.getDashboardFilter().getUserid() + "' ";
        }

        //USER_OAM_TICKET_UP_FOR_GRABS
        if (ticketListType.toString().startsWith("USER_OAM_TICKET_UP_FOR_GRABS")) {
            rootQuery += " AND p.assignedto='" + ticketListFilterWrapper.getDashboardFilter().getUserid() + "' ";
            if (ticketListFilterWrapper.getCoreQueryfilterKeys() != null) {
                String teamId = ticketListFilterWrapper.getCoreQueryfilterKeys().get("teamId");
                rootQuery += " AND p.phasecode IN ( "
                        + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryINByTeamId(teamId, "OAM")
                        + ") ";
            }
        }

        //UNASSIGNED_OAM_TICKET_UP_FOR_GRABS
        if (ticketListType.toString().startsWith("UNASSIGNED_OAM_TICKET_UP_FOR_GRABS")) {

            if (ticketListFilterWrapper.getCoreQueryfilterKeys() != null) {
                String teamId = ticketListFilterWrapper.getCoreQueryfilterKeys().get("teamId");
                rootQuery += " AND ( p.assignedto IS NULL OR  p.assignedto NOT IN ("
                        + QuerySpecification.INSTANCE.getMyTeamUserIdsQueryINByTeamId(teamId, "OAM")
                        + " ) ) ";
                rootQuery += " AND p.phasecode  IN ( "
                        + QuerySpecification.INSTANCE.getMyTeamPhaseIdsQueryINByTeamId(teamId, "OAM")
                        + ") ";
            }
        }

        //OAM_PHASE_SWITCH
        if (!ticketListType.toString().startsWith("OAM_PHASE_SWITCH")) {
            //ONLY OPEN
            rootQuery += " AND Upper(phase.phasedesc) NOT IN ('POSTED','ON HOLD','PENDING','WAITING ON DATA FROM CLIENT') ";
        }

        rootQuery += " ORDER  BY appid asc ";

        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            System.out.println("OamTicketListType#getRootQueryByTicketListType()=>" + ticketListType + ">>>>>>" + rootQuery);
        }

        return rootQuery;
    }
}
