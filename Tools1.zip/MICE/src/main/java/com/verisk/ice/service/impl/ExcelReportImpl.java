/*
 * Date : 2016-06-07 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import com.d2hawkeye.util.MapObjectUtils;
import com.verisk.ice.dao.report.IceAgeReportDAO;
import com.verisk.ice.dao.report.TicketFlowReportDAO;
import com.verisk.ice.service.ExcelReport;
import java.util.List;
import java.util.Map;
import org.jxls.area.Area;
import org.jxls.common.CellRef;
import org.jxls.common.Context;

public class ExcelReportImpl implements ExcelReport {

    @Override
    public void dumpTicketsFlowReport(Context context, Area xlsArea) {
        TicketFlowReportDAO ticketFlowReportDAO = new TicketFlowReportDAO();
        Map<String, Object> map = ticketFlowReportDAO.findTicketFlow();
        ticketFlowReportDAO.takeDown();
        Map<String, String> reportTimeWindow = (Map<String, String>) map.get("reportTimeWindow");
        context.putVar("week1date", reportTimeWindow.get("week1start") + "-" + reportTimeWindow.get("week1end"));
        context.putVar("week2date", reportTimeWindow.get("week2start") + "-" + reportTimeWindow.get("week2end"));
        context.putVar("week3date", reportTimeWindow.get("week3start") + "-" + reportTimeWindow.get("week3end"));
        context.putVar("week4date", reportTimeWindow.get("week4start") + "-" + reportTimeWindow.get("week4end"));
        context.putVar("records", (List<Map<String, String>>) map.get("list"));

        xlsArea.applyAt(new CellRef("Report!A4"), context);
    }

    @Override
    public void dumpIceAgeReport(Context context, Area xlsArea) {
        IceAgeReportDAO iceAgeReportDAO = new IceAgeReportDAO();
        List<Map<String, String>> list = iceAgeReportDAO.findAgeReport();
        context.putVar("records", list);
        iceAgeReportDAO.takeDown();
        xlsArea.applyAt(new CellRef("Report!A4"), context);
    }

    @Override
    public void dumpIceAgeReportById(Context context, Area xlsArea, Map<String, String> params) {
        IceAgeReportDAO iceAgeReportDAO = new IceAgeReportDAO();
        List<Map<String, String>> list = iceAgeReportDAO.findAgeReportById(params.get("pkSourceId"));
        context.putVar("records", list);
        context.putVar("pkSourceId", MapObjectUtils.getN_AIfEmptyString(params.get("pkSourceId")));
        iceAgeReportDAO.takeDown();
        xlsArea.applyAt(new CellRef("Report!A4"), context);
    }

}
