/*
 * Date : 2016-04-14 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import com.d2hawkeye.util.CommonUtils;
import com.d2hawkeye.util.velocity.MailMessageModel;
import com.d2hawkeye.util.velocity.MailMessagePOJO;
import com.d2hawkeye.util.velocity.RequestMailMessage;
import com.d2hawkeye.util.velocity.VelocityUtils;
import com.d2hs.soam.rm.queryBeanPM;
import com.verisk.ice.dao.IceDAO;
import com.verisk.ice.dao.OamDAO;
import com.verisk.ice.model.phaseswitch.DragDropInfo;
import com.verisk.ice.model.phaseswitch.DragDropInfoOAM;
import com.verisk.ice.service.MailSender;
import d2Systems.oam.SendMail;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MailSenderImpl implements MailSender {

    private static final Logger LOG = LoggerFactory.getLogger(MailSenderImpl.class.getName());

    @Override
    public void sendMailForPhaseSwitchDragDrop(DragDropInfo dragDropInfo, MailMessagePOJO oldMailMessagePOJO, String domainName, String userId) {
        Map<String, String> values = new HashMap<>();
        values.put("requestCode", dragDropInfo.getDataDragItem().getDataDragItemRequestCode());
        values.put("requestTypeName", CommonUtils.getRequestTitleById(dragDropInfo.getDataDragItem().getDataDragItemRequestTypeId()));
        values.put("prevPhaseId", dragDropInfo.getDataDragItem().getDataDragItemPhaseId());
        values.put("currentPhaseId", dragDropInfo.getDataDropZone().getDataDropZonePhaseId());
        values.put("domainName", domainName);
        values.put("userId", userId);
        sendMail(values, oldMailMessagePOJO);
    }

    @Override
    public void sendMail(Map<String, String> values, MailMessagePOJO oldMailMessagePOJO) {
        String requestCode = values.get("requestCode");
        String requestTypeName = values.get("requestTypeName");
        String domainName = values.get("domainName");
        String userId = values.get("userId");
        String prevPhaseId = values.get("prevPhaseId");
        String currentPhaseId = values.get("currentPhaseId");

        final Vector sendMail_CCList = new Vector();
        final Vector sendMail_ToList = new Vector();

        queryBeanPM queryBeanPM = new queryBeanPM();
        IceDAO iceDAO = new IceDAO();

        try {

            String sendMail_RequestType = requestTypeName;
            String sendMail_RequestCode = requestCode;
            String defaultEmail = "DataOps_ICR@verscend.com";
            String sendMail_RequestTypeId = "";
            String sendMail_ClientName = "";
            String sendMail_AppId = "";
            String sendMail_phaseDesc = "";
            final String sendMail_UID = userId;
            String sendMail_RequestTypeCode = "";
            String sendMail_ClientId = "";
            String sendMail_ApprovedBy = "";
            String sendMail_SignedOffBy = "";
            final String sendMail_from = queryBeanPM.getEngineerName(sendMail_UID) + "<" + queryBeanPM.getEngineerEmail(sendMail_UID) + ">";
            CommonUtils.RequestCode requestTypeRequestCode = null;

            if (queryBeanPM.getRequestDetails(requestCode)) {
                if (queryBeanPM.moveNext()) {
                    sendMail_ClientName = queryBeanPM.getData("clientname");
                    sendMail_AppId = queryBeanPM.getData("AppID");
                    sendMail_phaseDesc = queryBeanPM.getData("phasename");
                    sendMail_RequestTypeId = queryBeanPM.getData("requesttypeid");
                    requestTypeRequestCode = CommonUtils.getRequestTypeById(sendMail_RequestTypeId);
                    sendMail_RequestTypeCode = requestTypeRequestCode.getRequestCode();
                    sendMail_ClientId = queryBeanPM.getData("clientid");

                }
            }

            {
                if (requestTypeRequestCode != null) {
                    String sql = "SELECT * FROM " + requestTypeRequestCode.getDbTblName() + " WHERE REQUESTCODE='" + requestCode + "'";
                    if (queryBeanPM.getList(sql, "MailSenderImpl#sendMail()")) {
                        if (queryBeanPM.moveNext()) {
                            sendMail_ApprovedBy = queryBeanPM.getData("approvedby");
                            sendMail_SignedOffBy = queryBeanPM.getData("signedoffby");
                        }
                    }
                }
            }

            if (!sendMail_UID.equals("")) {
                sendMail_ToList.addElement(queryBeanPM.getEngineerName(sendMail_UID) + "<" + queryBeanPM.getEngineerEmail(sendMail_UID) + ">");
            }
            //GETTING EMAIL RECIPENTS FROM REQUESTION PERSON && ASSIGNED TO
            iceDAO.setVectorTOEmailAddressAssignedToAndRequestingPerson(sendMail_ToList, requestCode);

            /*CC EMAILS*/
            //GETTING EMAIL RECIPENTS FROM APPROVED BY
            if (!sendMail_ApprovedBy.equals("")) {
                String approvedByName = queryBeanPM.getEngineerName(sendMail_ApprovedBy);
                String approvedByEmail = queryBeanPM.getEngineerEmail(sendMail_ApprovedBy);
                if (!sendMail_CCList.contains(approvedByName + "<" + approvedByEmail + ">")) {
                    sendMail_CCList.addElement(approvedByName + "<" + approvedByEmail + ">");
                }
            }

            //GETTING EMAIL RECIPENTS FROM SIGNED OFF BY
            if (!sendMail_SignedOffBy.equals("")) {
                String signedOffByName = queryBeanPM.getEngineerName(sendMail_SignedOffBy);
                String signedOffByEmail = queryBeanPM.getEngineerEmail(sendMail_SignedOffBy);
                if (!sendMail_CCList.contains(signedOffByName + "<" + signedOffByEmail + ">")) {
                    sendMail_CCList.addElement(signedOffByName + "<" + signedOffByEmail + ">");
                }
            }

            //GETTING EMAIL RECIPENTS FROM MESSAGING GROUP  BY REQUEST TYPE CODE
            queryBeanPM.getEmailRecipentsFromMsgGrpOAMPMType(sendMail_RequestTypeCode);
            while (queryBeanPM.moveNext()) {
                String usermail = queryBeanPM.getData("email");
                if (!sendMail_CCList.contains(usermail)) {
                    sendMail_CCList.addElement(usermail);
                }
            }

            //GETTING EMAIL RECIPENTS FROM MESSAGING GROUP BY CLIENT
            queryBeanPM.getEmailRecipentsFromMsgGrpOAMPM(sendMail_ClientId);
            while (queryBeanPM.moveNext()) {
                String usermail = queryBeanPM.getData("email");
                if (!sendMail_CCList.contains(usermail)) {
                    sendMail_CCList.addElement(usermail);
                }
            }

            //GETTING EMAIL RECIPENTS BY APP ID
            queryBeanPM.getCCEmailForBA_WPM_NPM_CL(sendMail_AppId);
            while (queryBeanPM.moveNext()) {
                String usermail = queryBeanPM.getData("email");
                if (!sendMail_CCList.contains(usermail)) {
                    sendMail_CCList.addElement(usermail);
                }
            }

            //GETTING EMAIL RECIPENTS BY PHASE IDS
            iceDAO.setVectorCCEmailAddressByPhaseIds(sendMail_CCList, prevPhaseId, currentPhaseId);

            if (!sendMail_CCList.contains(defaultEmail)) {
                sendMail_CCList.addElement(defaultEmail);
            }

            final String sendMail_MsgSubject = sendMail_RequestType + ":Request #" + sendMail_RequestCode + "; Client:" + sendMail_ClientName + "; Phase:" + sendMail_phaseDesc;//+  sendMail_subj;
            final String sendMail_MailMsg = queryBeanPM.getFormattedRequestMessageForNew(requestCode, domainName, oldMailMessagePOJO, userId);
            final String sendMail_Assignee = queryBeanPM.getEngineerName(sendMail_UID) + "<" + queryBeanPM.getEngineerEmail(sendMail_UID) + ">";
            new Thread(new Runnable() {
                @Override
                public void run() {
                    System.out.println("MailSender.run()");
                    new SendMail().send(sendMail_from, sendMail_ToList, sendMail_CCList, sendMail_MsgSubject, sendMail_MailMsg, sendMail_Assignee);
                    System.out.println("MailSender.finish()");
                }
            }).start();

        } catch (Exception ex) {
            LOG.info(ex.getMessage());
        } finally {
            queryBeanPM.takeDown();
            iceDAO.takeDown();
        }
    }

    @Override
    public void sendMailForPhaseSwitchDragDropOAM(DragDropInfoOAM dragDropInfoOAM, String domainName, String userId) {
        Map<String, String> values = new HashMap<>();
        values.put("appid", dragDropInfoOAM.getDataDragItem().getDataDragItemAppId());
        values.put("prevAssignee", dragDropInfoOAM.getDataDragItem().getDataAssignee());
        values.put("prevPhaseCode", dragDropInfoOAM.getDataDragItem().getDataDragItemPhaseCode());
        values.put("currentPhaseCode", dragDropInfoOAM.getDataDropZone().getDataDropZonePhaseCode());
        values.put("domainName", domainName);
        values.put("userId", userId);
        sendMailOAM(values, "PHASE");
    }

    @Override
    public void sendMailOAM(Map<String, String> values, String events) {
        String appId = values.get("appid");
        String userId = values.get("userId");
        String prevPhaseCode = values.get("prevPhaseCode");
        String currentPhaseCode = values.get("currentPhaseCode");
        String prevAssignee = values.get("prevAssignee");

        final Vector sendMail_CCList = new Vector();
        final Vector sendMail_ToList = new Vector();

        queryBeanPM queryBeanPM = new queryBeanPM();
        IceDAO iceDAO = new IceDAO();
        OamDAO oamDAO = new OamDAO();

        try {
            final RequestMailMessage mailMessage = new RequestMailMessage();
            String sendMail_AppId = appId;
            String sendMail_AppName = "";
            final String sendMail_UID = userId;
            //String sendMail_ClientId = "";

            final String sendMail_from = queryBeanPM.getEngineerName(sendMail_UID) + "<" + queryBeanPM.getEngineerEmail(sendMail_UID) + ">";

            /*TO EMAILS*/
            if (!sendMail_UID.equals("")) {
                sendMail_ToList.addElement(sendMail_from);
            }

            /*CC EMAILS*/
            //GETTING EMAIL RECIPENTS FROM MESSAGING GROUP BY CLIENT
//            queryBeanPM.getEmailRecipentsFromMsgGrpOAMPM(sendMail_ClientId);
//            while (queryBeanPM.moveNext()) {
//                String usermail = queryBeanPM.getData("email");
//                if (!sendMail_CCList.contains(usermail)) {
//                    sendMail_CCList.addElement(usermail);
//                }
//            }
            //GETTING EMAIL RECIPENTS BY APP ID
            queryBeanPM.getCCEmailForBA_WPM_NPM_CL(sendMail_AppId);
            while (queryBeanPM.moveNext()) {
                String usermail = queryBeanPM.getData("email");
                if (!sendMail_CCList.contains(usermail)) {
                    sendMail_CCList.addElement(usermail);
                }
            }

            
            mailMessage.setRequestCode(sendMail_AppId);
            ArrayList<MailMessageModel> messageModels = new ArrayList<>();
            mailMessage.setMailMessageModels(messageModels);

            Map<String, String> map = oamDAO.appendMessageModels(mailMessage, values);
            sendMail_AppName = map.get("applicationname");
                        
            //TO LIST
            //GETTING EMAIL RECIPENTS CURRENT AND PREVIOUS ASSIGNED TO
            System.out.println("com.verisk.ice.service.impl.MailSenderImpl.sendMailOAM()->" + map.get("assigneeid") + " =>" + prevAssignee);
            if (map.get("assigneeid") != null && !map.get("assigneeid").trim().isEmpty()) {
                sendMail_ToList.addElement(queryBeanPM.getEngineerName(map.get("assigneeid")) + "<" + queryBeanPM.getEngineerEmail(map.get("assigneeid")) + ">");
            }

            if (prevAssignee != null && !prevAssignee.trim().isEmpty()) {
                sendMail_ToList.addElement(queryBeanPM.getEngineerName(prevAssignee) + "<" + queryBeanPM.getEngineerEmail(prevAssignee) + ">");
            }
                                    
            VelocityContext velocityContext = new VelocityContext();
            velocityContext.put("req", mailMessage);
            VelocityUtils velocityUtils = new VelocityUtils();
            velocityUtils.initVelocityConfiguration();
            String message = velocityUtils.prepareMessage("requestMailMessageTemplateOAM.vsl", velocityContext);
            String sendMail_MsgSubject_ = "Message - " + sendMail_AppName + "(" + sendMail_AppId + ") - ";

            String currentPhase = oamDAO.findOamPhaseDescByPhaseCode(currentPhaseCode);

            if (events.equalsIgnoreCase("PHASE")) {
                sendMail_MsgSubject_ += "" + currentPhase;

            } else {
                sendMail_MsgSubject_ += "Assigned";
                currentPhaseCode = map.get("phasecode");
            }
            
            //GETTING EMAIL RECIPENTS BY PHASE IDS
            iceDAO.setVectorCCEmailAddressByPhaseIds(sendMail_CCList, prevPhaseCode, currentPhaseCode);
            
            final String sendMail_MsgSubject = sendMail_MsgSubject_;

            final String sendMail_MailMsg = message;
            final String sendMail_Assignee = queryBeanPM.getEngineerName(sendMail_UID) + "<" + queryBeanPM.getEngineerEmail(sendMail_UID) + ">";
            new Thread(new Runnable() {
                @Override
                public void run() {
                    System.out.println("MailSender.run()->OAM");
                    new SendMail().send(sendMail_from, sendMail_ToList, sendMail_CCList, sendMail_MsgSubject, sendMail_MailMsg, sendMail_Assignee);
                    System.out.println("MailSender.finish()->OAM");
                }
            }).start();

        } catch (Exception ex) {
            LOG.info(ex.getMessage());
        } finally {
            queryBeanPM.takeDown();
            iceDAO.takeDown();
            oamDAO.takeDown();
        }
    }

}
