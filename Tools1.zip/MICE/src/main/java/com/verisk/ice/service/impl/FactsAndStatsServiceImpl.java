/*
 * Date : 2016-01-28
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 */
package com.verisk.ice.service.impl;

import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.FactsAndStatsDAO;
import com.verisk.ice.model.wrapper.DashboardFilterWrapper;
import com.verisk.ice.model.wrapper.FactsAndStatsWrapper;
import com.verisk.ice.service.FactsAndStatsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FactsAndStatsServiceImpl implements FactsAndStatsService {

    private static final Logger LOG = LoggerFactory.getLogger(FactsAndStatsServiceImpl.class.getName());

    @Override
    public FactsAndStatsWrapper findFactsAndStats(DashboardFilterWrapper dashboardFilterWrapper, String searchKey) {
        FactsAndStatsDAO factsAndStatsDAO = new FactsAndStatsDAO();
        DashboardFilterWrapper.setDefaultPageSwitcherIfNeccessary(dashboardFilterWrapper);
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(dashboardFilterWrapper));
        }
        FactsAndStatsWrapper factsAndStatsWrapper = factsAndStatsDAO.findAllFactsAndStats(dashboardFilterWrapper, searchKey);
        factsAndStatsDAO.takeDown();
        return factsAndStatsWrapper;
    }

}
