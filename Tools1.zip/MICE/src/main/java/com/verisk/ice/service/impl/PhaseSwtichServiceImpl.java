/*
 * Date : 2016-04-01 
 * Author : Bhuwan Prasad Upadhyay (i81324)
 * Email : rkc
 *
 */
package com.verisk.ice.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.d2hawkeye.util.CommonUtils;
import com.d2hawkeye.util.velocity.MailMessagePOJO;
import com.d2hs.soam.rm.queryBeanPM;
import com.verisk.ice.dao.DAOFactory;
import com.verisk.ice.dao.IceDAO;
import com.verisk.ice.dao.IceTicketListDAO;
import com.verisk.ice.dao.OamDAO;
import com.verisk.ice.dao.OamTicketListDAO;
import com.verisk.ice.dao.phaseswitch.PhaseSwitchDAO;
import com.verisk.ice.design.IceTicketListType;
import com.verisk.ice.design.OamTicketListType;
import com.verisk.ice.model.DashboardFilterDTO;
import com.verisk.ice.model.phaseswitch.DragDropInfo;
import com.verisk.ice.model.phaseswitch.DragDropInfoOAM;
import com.verisk.ice.model.phaseswitch.OamPhaseDetail;
import com.verisk.ice.model.phaseswitch.OamPhaseSwitchWrapper;
import com.verisk.ice.model.phaseswitch.PhaseDetail;
import com.verisk.ice.model.phaseswitch.PhaseSwitchFilterWrapper;
import com.verisk.ice.model.phaseswitch.PhaseSwitchWrapper;
import com.verisk.ice.model.phaseswitch.PhaseWrapper;
import com.verisk.ice.model.phaseswitch.Request;
import com.verisk.ice.model.wrapper.TicketListFilterWrapper;
import com.verisk.ice.model.wrapper.TicketListWrapper;
import com.verisk.ice.service.MailSender;
import com.verisk.ice.service.PhaseSwtichService;
import com.verisk.ice.utils.AbbrevConstants;
import com.verisk.ice.utils.ValidateUtility;

public class PhaseSwtichServiceImpl implements PhaseSwtichService {

    private static final Logger LOG = LoggerFactory.getLogger(PhaseSwtichServiceImpl.class.getName());

    @Override
    public List<PhaseSwitchWrapper> findPhaseSwitchWrapperWithoutPagination(PhaseSwitchFilterWrapper phaseSwitchFilterWrapper) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(phaseSwitchFilterWrapper));
        }
        List<PhaseSwitchWrapper> phaseSwitchWrappers = new ArrayList<>();

        final IceDAO iceDAO = new IceDAO();
        final IceTicketListDAO iceTicketListDAO = new IceTicketListDAO();

        try {
            ValidateUtility.isNotNull(phaseSwitchFilterWrapper);
            ValidateUtility.isNotNull(phaseSwitchFilterWrapper.getDashboardFilter());
            ValidateUtility.isNotNull(phaseSwitchFilterWrapper.getDashboardFilter().getRequesttypeids());
            ValidateUtility.isNotNull(phaseSwitchFilterWrapper.getDashboardFilter().getRequesttypeids().get(AbbrevConstants.ICE_ABBR));
            String[] requestTypeIds = phaseSwitchFilterWrapper.getDashboardFilter().getRequesttypeids().get(AbbrevConstants.ICE_ABBR);
            if (requestTypeIds.length == 0 || requestTypeIds[0].trim().isEmpty()) {
                return phaseSwitchWrappers;
            }
            List<PhaseDetail> phaseDetails = iceDAO.findPhaseDetailByRequestTypeIds(requestTypeIds);
            for (final String requesttypeid : requestTypeIds) {
                PhaseSwitchWrapper phaseSwitchWrapper = new PhaseSwitchWrapper();
                phaseSwitchWrapper.setRequestDescription(CommonUtils.getRequestTitleById(requesttypeid));
                phaseSwitchWrapper.setDataDropZoneRequestTypeId(requesttypeid);
                List<PhaseWrapper> phaseWrapperList = new ArrayList<>();

                phaseSwitchFilterWrapper.getDashboardFilter().setRequesttypeids(new HashMap<String, String[]>() {
                    {
                        put(AbbrevConstants.ICE_ABBR, new String[]{requesttypeid});
                    }
                });
                TicketListFilterWrapper ticketListFilterWrapper = new TicketListFilterWrapper();
                ticketListFilterWrapper.setDashboardFilter(phaseSwitchFilterWrapper.getDashboardFilter());

                for (PhaseDetail phaseDetail : phaseDetails) {
                    if (phaseDetail.getIssuetypeid().equalsIgnoreCase(requesttypeid)) {
                        PhaseWrapper phaseWrapper = new PhaseWrapper();
                        phaseWrapper.setStatusid(phaseDetail.getStatusid());
                        phaseWrapper.setDataDropZonePhaseId(phaseDetail.getPhaseid());
                        phaseWrapper.setDataDropZonePhaseName(phaseDetail.getPhasename());
                        phaseWrapper.setRequestTypeId(requesttypeid);

                        List<Request> requestList = new ArrayList<>();

                        Map<String, String> filters = new HashMap<>();
                        filters.put("phaseid", phaseDetail.getPhaseid());
                        ticketListFilterWrapper.setFilterKeys(filters);

                        TicketListWrapper ticketListWrapper = null;

                        if (phaseSwitchFilterWrapper.isByteam()) {
                            ticketListWrapper = iceTicketListDAO.findAllWithoutPagination(ticketListFilterWrapper, IceTicketListType.MYTEAM_PHASE_SWITCH.toString());
                        } else if (phaseSwitchFilterWrapper.isByme()) {
                            ticketListWrapper = iceTicketListDAO.findAllWithoutPagination(ticketListFilterWrapper, IceTicketListType.MYTICKET_PHASE_SWITCH.toString());
                        }

                        for (Map<String, String> map : ticketListWrapper.getList()) {
                            requestList.add(new Request(map.get("requestcode"), map.get("requesttitle"), map.get("requesttypeid"), map.get("phaseid"), map.get("EnggID"), map.get("USER_NAME"), map.get("clientname"), map.get("TargetCompDate"), map.get("priority")));
                        }
                        phaseWrapper.setRequestList(requestList);

                        phaseWrapper.setPageSwitcherDTO(ticketListWrapper.getPageSwitcherDTO());
                        phaseSwitchWrapper.setTotalCount(phaseSwitchWrapper.getTotalCount() + Integer.valueOf(ticketListWrapper.getPageSwitcherDTO().getTotal()));
                        phaseWrapperList.add(phaseWrapper);
                    }
                }
                phaseSwitchWrapper.setPhaseWrapperList(phaseWrapperList);
                phaseSwitchWrappers.add(phaseSwitchWrapper);
            }

        } catch (Exception e) {
            LOG.error("ERR: " + e.getMessage());
        } finally {
            iceDAO.takeDown();
            iceTicketListDAO.takeDown();
        }
        return phaseSwitchWrappers;
    }

    @Override
    public OamPhaseSwitchWrapper findOamPhaseSwitchWrapperWithoutPagination(DashboardFilterDTO dashboardFilterDTO) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(dashboardFilterDTO));
        }
        OamPhaseSwitchWrapper oamPhaseSwitchWrapper = new OamPhaseSwitchWrapper();

        final OamDAO oamDAO = new OamDAO();
        final OamTicketListDAO oamTicketListDAO = new OamTicketListDAO();

        try {
            ValidateUtility.isNotNull(dashboardFilterDTO);

            /*REMOVING DASHBOARD FILTER*/
            dashboardFilterDTO.setAppids(null);
            dashboardFilterDTO.setDateRange(null);

            List<OamPhaseDetail> oamPhaseDetails = oamDAO.findOamPhasesLazy();
            for (final OamPhaseDetail oamPhaseDetail : oamPhaseDetails) {
                TicketListFilterWrapper ticketListFilterWrapper = new TicketListFilterWrapper();
                ticketListFilterWrapper.setDashboardFilter(dashboardFilterDTO);
                Map<String, String> filters = new HashMap<>();
                filters.put("phasedesc", oamPhaseDetail.getPhaseName());
                ticketListFilterWrapper.setFilterKeys(filters);
                final TicketListWrapper ticketListWrapper = oamTicketListDAO.findAllWithoutPagination(ticketListFilterWrapper, OamTicketListType.OAM_PHASE_SWITCH.toString());
                oamPhaseDetail.setTicketListWrapper(ticketListWrapper);
                oamPhaseSwitchWrapper.setTotalCount(oamPhaseSwitchWrapper.getTotalCount() + Integer.valueOf(ticketListWrapper.getPageSwitcherDTO().getTotal()));
            }
            oamPhaseSwitchWrapper.setOamPhaseDetails(oamPhaseDetails);
        } catch (Exception e) {
            LOG.error("ERR: " + e.getMessage());
        } finally {
            oamDAO.takeDown();
            oamTicketListDAO.takeDown();
        }
        return oamPhaseSwitchWrapper;
    }

    @Override
    public void changeDragDropInfo(DragDropInfo dragDropInfo, HttpServletRequest request) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(dragDropInfo));
        }
        if (DragDropInfo.isValidDragDropPhaseSwitchConstraints(dragDropInfo)) {
            queryBeanPM queryBeanPM = new queryBeanPM();
            MailMessagePOJO oldMessagePOJO = new MailMessagePOJO();
            if (queryBeanPM.getRequestDetails(dragDropInfo.getDataDragItem().getDataDragItemRequestCode())) {
                if (queryBeanPM.moveNext()) {
                    oldMessagePOJO.setRemarks(queryBeanPM.getData("remarks"));
                    oldMessagePOJO.setMainEnggName(queryBeanPM.getData("User_Name"));
                    oldMessagePOJO.setPhase(queryBeanPM.getData("phasename"));
                }
            }
            PhaseSwitchDAO phaseSwitchDAO = new PhaseSwitchDAO();
            MailSender mailSender = new MailSenderImpl();
            if (phaseSwitchDAO.changeDragDropInfo(dragDropInfo, (String) request.getSession().getAttribute("UserID"))) {
                mailSender.sendMailForPhaseSwitchDragDrop(dragDropInfo, oldMessagePOJO, (String) request.getSession().getAttribute("DomainName"), (String) request.getSession().getAttribute("UserID"));
            }
            queryBeanPM.takeDown();
            phaseSwitchDAO.takeDown();
        }
    }

    @Override
    public void changeDragDropInfoOAM(DragDropInfoOAM dragDropInfoOAM, HttpServletRequest request) {
        if (DAOFactory.INSTANCE.getIsLogEnable()) {
            LOG.info(DAOFactory.INSTANCE.getJson().toJson(dragDropInfoOAM));
        }
        if (DragDropInfoOAM.isValidDragDropPhaseSwitchConstraints(dragDropInfoOAM)) {
            PhaseSwitchDAO phaseSwitchDAO = new PhaseSwitchDAO();
            MailSender mailSender = new MailSenderImpl();
            if (phaseSwitchDAO.changeDragDropInfoOAM(dragDropInfoOAM)) {
                mailSender.sendMailForPhaseSwitchDragDropOAM(dragDropInfoOAM, (String) request.getSession().getAttribute(CommonUtils.SessionAttributes.DomainName.toString()), (String) request.getSession().getAttribute(CommonUtils.SessionAttributes.UserID.toString()));
            }
            phaseSwitchDAO.takeDown();
        }
    }

    @Override
    public List<Map<String, String>> getAllUser() {
        IceDAO iceDAO = new IceDAO();
        List<Map<String, String>> allUser = iceDAO.getAllUser();
        iceDAO.takeDown();
        return allUser;
    }

    @Override
    public List<Map<String, String>> findIceRequestTypesWithCount(DashboardFilterDTO dashboardFilterDTO) {
        final IceTicketListDAO iceTicketListDAO = new IceTicketListDAO();
        List<Map<String, String>> requestTypesWithCount = new ArrayList<>();
        for (CommonUtils.RequestCode requestCode : CommonUtils.RequestCode.values()) {
            Map<String, String[]> requestTypes = new HashMap<>();
            requestTypes.put("ice", new String[]{requestCode.getRequestTypeId()});
            dashboardFilterDTO.setRequesttypeids(requestTypes);
            String count = iceTicketListDAO.count(dashboardFilterDTO, IceTicketListType.MYTICKET_PHASE_SWITCH.toString());
            if (Integer.valueOf(count) > 0) {
                Map<String, String> map = new HashMap<>();
                map.put("id", requestCode.getRequestTypeId());
                map.put("name", requestCode.getRequestTitle());
                map.put("count", count);
                requestTypesWithCount.add(map);
            }
        }
        iceTicketListDAO.takeDown();
        return requestTypesWithCount;
    }

}
