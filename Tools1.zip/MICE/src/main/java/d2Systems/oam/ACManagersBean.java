/*******************************************************************************************************

 File: ACManagersBean.java
 Created by:
 Date:

 Description:

 Modifications:

 Date:					Changed by:					Description
 ------------------------------------------------------------------------
 Oct 18 2002				Pawan K Shrestha			Table names changed
 tbl_LogTransactions tbl_MaintenanceManager
 tbl_ProjectManagement OAM_REQUESTMANAGER
 tbl_CycleDescription OAM_PRODUCTIONMANAGER
 tbl_StaffType tbl_UsersType
 tbl_Staff OAM_USERS
 tbl_UserPasswordsLog tbl_UsersPassword

 Oct 21 2002				Pawan K Shrestha			Table names changed
 tbl_UsersType OAM_USERTYPES
 tbl_UsersPassword OAM_USERPASSWORDS

 Oct 21 2002				Pawan K Shrestha			Changed field names and tablenames

 Apr 27 2003				Pawan K Shrestha			OAM_USERS@HawkeyeUser changed to
 USR_USERS and
 its field names corrected
 Jun 24 2003       Nilesh Shretha        Table name OAM_USERS changed to ztbl_users
 *******************************************************************************************************/

package d2Systems.oam;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.d2hs.soam.ConnectionBean;

public class ACManagersBean extends ConnectionBean{

    private String		mess	="class defined";
    private ResultSet   myRS1=null;

//CONSTRUCTOR
    public ACManagersBean()
    {
        super();
    }

    public String getMessage()
    {
        return this.mess;
    }

//jan 10 2002
    /**
     * 
     * @param uid
     * @return true if user is admin
     * modified by Vadhikari
     * if isadmin is false after checking the usertype code
     * Again, checking on OAM_USER_RIGHTS to know user is admin or not 
     * @throws Exception
     */
    public boolean IsAdmin(String uid) throws Exception
    {
        boolean retVal=false;
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery("SELECT CASE WHEN SUBSTR(a.OAMUserTypeCode,1,1)='1' OR  b.UserTypeDesc LIKE 'Admin' THEN '1' ELSE '0' END AS isAdmin FROM USR_USERS a,  OAM_USERTYPES b WHERE a.OAMUserTypeCode = b.USERTYPECODE AND a.UserID='"+uid+"'");
            myRS.next();
            String isAdmin=myRS.getString("isAdmin");
            if(isAdmin.equals("1")){
                retVal=true;
            }
            if(!retVal)
            {
            	String var1 = ""
            			+ "SELECT Count(rname) AS Count  "
            			+ "FROM   oam_user_rights a "
            			+ "       inner join oam_rights b "
            			+ "               ON a.rid = b.rid "
            			+ "WHERE  userid = '"+uid+"'"
            			+ "       AND Upper(rname) LIKE Upper('%admin%') ";
            	myRS.close();
            	myRS=stmt.executeQuery(var1);
            	myRS.next();
            	if(myRS.getInt("Count") >=1)
            	{
            		retVal = true;
            	}
            }
            System.out.println("isAdmin "+retVal);
            mess="user type being extracted";
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->0<-"+se);retVal=false; mess=se.getMessage();
            System.out.println("isAdmin "+retVal);
        }
        return retVal;
    }

    /*
    Function: IsMessageAdmin
    Desc: This function is similar to the IsAdmin function. just that it checks if the user is a phase messaging admin
    Author: Anjana
    Date: Nov 13, 2007
     */
    public boolean IsMessageAdmin(String uid) throws Exception
    {
        boolean retVal=false;
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery("SELECT CASE WHEN SUBSTR(a.OAMUserTypeCode,1,1)='2' " +
                    " \n THEN '1' ELSE '0' END AS isMsgAdmin FROM USR_USERS a, OAM_USERTYPES b " +
                    " \n WHERE a.OAMUserTypeCode = b.USERTYPECODE AND a.UserID='"+uid+"'");
            System.out.println("SELECT CASE WHEN SUBSTR(a.OAMUserTypeCode,1,1)='2' " +
                                " \n THEN '1' ELSE '0' END AS isMsgAdmin FROM USR_USERS a, OAM_USERTYPES b " +
                                " \n WHERE a.OAMUserTypeCode = b.USERTYPECODE AND a.UserID='"+uid+"'");

            myRS.next();
            String isAdmin=myRS.getString("isMsgAdmin");
            if(isAdmin.equals("1")){
                retVal=true;
            }
            mess="user type being extracted";
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->0<-"+se);retVal=false; mess=se.getMessage();
            System.out.println("isMsgAdmin "+retVal);
        }
        return retVal;
    }


//  Returns the user type
    public String getUserType(String uid) throws Exception
    {
        String retVal="";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery("select t.UserTypeDesc from USR_USERS s,OAM_USERTYPES t where s.OAMUserTypeCode=t.USERTYPECODE and s.UserID='"+uid+"'");

            myRS.next();
            retVal=myRS.getString("UserTypeDesc");
            mess="user type being extracted";
          

        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->1<-"+se);retVal=""; mess=se.getMessage();
            System.out.println(mess+" retVal "+retVal);
        }
        return retVal.trim();
    }


    public String getUserTypeCode(String uid) throws Exception
    {
        String retVal="";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery("select t.USERTYPECODE from USR_USERS s,OAM_USERTYPES t where s.OAMUserTypeCode=t.USERTYPECODE and s.UserID='"+uid+"'");

            myRS.next();
            retVal=myRS.getString("USERTYPECODE");
            mess="user type being extracted";
          }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->2<-"+se);retVal=""; mess=se.getMessage();
            System.out.println("userid is :"+uid);
        }

        return retVal.trim();
    }

// Checks if user is Account manager
    public boolean isAccountManager(String uid) throws Exception
    {
        boolean retVal=false;
        try{
            if(getUserType(uid).equals("CPM"))
            {
                retVal=true;
                mess="user type being extracted";
            }
        }
        catch (Exception e){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->3<-"+e); mess=e.toString();}
        return retVal;
    }


    public boolean executeQuery(String UserType)
    {
        boolean  retVal=false;

        if(UserType.equals("eng"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS USERTYPECODE,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,3)=SUBSTR(t.USERTYPECODE,2,3) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('E&D','ITEG') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("CPM"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS USERTYPECODE,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,3)=SUBSTR(t.USERTYPECODE,2,3) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('CPM', 'CPM [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("BI"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS USERTYPECODE,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.USERTYPECODE,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('BI','BI Admin') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("DE"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('DE','DE [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("CMD"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('CMD','CMD [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("engPM"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('E&D', 'E&D [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("AM"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('AM','AM [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("PROD"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('Production','Production [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("BE"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('BE','BE [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("CSA"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('CSA','CSA [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("DG"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('DG','DG [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";
        else if(UserType.equals("DM"))
            strSQL="select s.UserID,s.SeedUserID AS PKSource,s.OAMUserTypeCode AS UserTypeCode,s.UserName,s.EMail,s.LoginName  from USR_USERS s,OAM_USERTYPES t WHERE SUBSTR(s.OAMUserTypeCode,2,4)=SUBSTR(t.UserTypeCode,2,4) AND s.OAMStatus=1 AND t.UserTypeDesc IN ('DM','DM [Admin]') GROUP BY s.UserID,s.SeedUserID,s.OAMUserTypeCode,s.UserName,s.EMail,s.LoginName ORDER BY s.UserName";

        else
            strSQL=" SELECT UserID,SeedUserID AS PKSource,OAMUserTypeCode AS UserTypeCode,UserName||'['||loginname ||']'AS username ,EMail,LoginName FROM USR_USERS  WHERE OAMStatus=1 ORDER BY UserName";

        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            mess=strSQL;
            retVal=true;
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->4<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }


    public boolean getListOfUserTypes()
    {
        boolean  retVal=false;
        strSQL="SELECT UserTypeCode,UserTypeDesc FROM OAM_USERTYPES ORDER BY UserTypeDesc";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            mess="user type being extracted";
            retVal=true;
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->5<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }


    public boolean executeQueryForUserID(String UID)
    {
        boolean  retVal=false;
        strSQL="SELECT * FROM ztblUsers@HawkeyeUser WHERE UserID='"+UID+"'";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            mess="user type being extracted";
            retVal=true;
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->6<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }

//public boolean getStaffInfo(int uid) -- user id is now string data type
    public boolean getStaffInfo(String uid)
    {
        boolean  retVal=false;
        /*strSQL="SELECT UserID,SeedUserID AS PKSource,UserTypeCode,UserName,EMail,Phone,LoginName,Comment_,isAdmin  FROM USR_USERS where UserID='"+uid+"'";*/
        strSQL="SELECT USERID,SEEDUSERID PKSOURCE,USERTYPECODE,USERNAME,EMAIL,LOGINNAME,CSMADM_YN FROM USR_USERS where UserID='"+uid+"'";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            mess="user info extracted ";
            retVal=true;
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->7<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }


    public String getSqlString(){
        return strSQL;
    }



    public String isPasswordExists(String uid,String password)
    {
//comparision of encrypted password
        String retVal="0";
        strSQL="SELECT (SELECT COUNT(*) FROM USR_USERS WHERE UserID='"+uid+"' AND (pwdcompare('" +
                password.replace('\'','`') + "',CONVERT(nvarchar,Password))=1))+(SELECT COUNT(*) FROM OAM_USERPASSWORDS WHERE UserID='" +
                uid + "' AND (pwdcompare('" + password.replace('\'','`') + "',CONVERT(nvarchar,Password))=1)) AS recCount";
        try{
            Statement st1=myConn.createStatement();
            ResultSet rs1=st1.executeQuery(strSQL);
            while(rs1.next()){
                retVal=rs1.getString("recCount");
            }

        }
        catch (SQLException e){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->8<-"+e);}
        return retVal;
    }

    public String isOldPasswordMatches(String uid,String password)
    {
        String retVal="0";
        strSQL="SELECT COUNT(*) as recCount FROM USR_Users WHERE UserID='"+uid+"' AND (Password = ora_hash('" + password + "'))";
        try{
            Statement st1=myConn.createStatement();
            ResultSet rs1=st1.executeQuery(strSQL);
            while(rs1.next()){
                retVal=rs1.getString("recCount");
            }
        }
        catch (SQLException e){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->9<-"+e);}
        return retVal;
    }

    public String changePassword(String uid,String password)
    {

        String retVal="0";
//strSQL=	" UPDATE OAM_USERS SET Password= '"+password+"' WHERE UserID="+uid;
        strSQL=	" sp_ChangeUserPassword  '" + uid.replace('\'','`') + "','" + password.replace('\'','`') + "'";
        try{
            Statement st=myConn.createStatement();
            ResultSet rs=st.executeQuery(strSQL);
            while(rs.next()){
                retVal=rs.getString("isPasswordUpdated");
            }
            mess="user info being edited";
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->10<-"+se);retVal="-1"; mess=se.getMessage();}
        return (retVal);
    }


    public boolean changeUserInfo(String uid,String name,String email,String login,String isadm,String type) throws Exception
    {
        boolean  retVal=false;
        //if(comment.equals(""))comment="N/A";
        strSQL=	" UPDATE USR_USERS "+
                " SET USERNAME='"+name.replace('\'','`')+"',"+
                " EMAIL='"+email.replace('\'','`')+"',"+
                //" Phone='"+phone.replace('\'','`')+"',"+
                " LOGINNAME='"+login.replace('\'','`')+"'," +
                " CSMADM_YN="+ isadm +  "," +
                " USERTYPECODE='"+type+"', "+
                //" Comment='"+comment.replace('\'','`')+"' "+
                " WHERE USERID='"+uid+"'" ;
        try{
            stmt=myConn.createStatement();
            int rows=stmt.executeUpdate(strSQL);
            //mess="user info being edited";
            mess=strSQL;
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->11<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }


    public boolean checkLoginNameExists(String uname)
    {
        boolean  retVal=false;
        strSQL=	"SELECT LoginName FROM USR_USERS WHERE LoginName='"+uname.replace('\'','`')+"' AND OAMStatus=1 ";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            mess="user info being checked";
            retVal=myRS.next();
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->12<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }



//adds a user entry and returns the UserID
    public boolean addUser(String name,String email,String phone, String uname,String password,String type,String comment,String isadmin)
    {
        boolean retVal=false;
        if(name.equals(""))name="N/A";
        if(email.equals(""))email="N/A";
        if(phone.equals(""))phone="N/A";
        //if(uname.equals(""))uname="none";
        //if(password.equals(""))password="none";
        if(comment.equals(""))comment="none";
        String adminflag=(isadmin.equals("y"))?"1":"0";
        strSQL=	" sp_InsertUser '" + type + "','" +
                name.replace('\'','`') + "','" +
                email.replace('\'','`') + "','" +
                phone.replace('\'','`') + "','" +
                uname.replace('\'','`') + "','" +
                password.replace('\'','`') + "','" +
                comment.replace('\'','`') + "'," +
                isadmin;

        try{
            stmt=myConn.createStatement();
            int rows=stmt.executeUpdate(strSQL);
            mess="user info being added";
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->13<-"+se);retVal=false; mess=se.getMessage();}

        return (retVal);
    }


    public boolean deleteUser(String uid)
    {
        boolean  retVal=false;
        strSQL=	" DELETE FROM ztbl_Users " +
                " WHERE UserID='"+uid+"'";
        try{
            stmt=myConn.createStatement();
            int rows=stmt.executeUpdate(strSQL);
            mess="user info being deleted";
            retVal=true;
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->14<-"+se);retVal=false; mess=se.getMessage();}
        return (retVal);
    }

    public String getUserID(){
        String id="";
        try{
            id=myRS.getString("User_ID");
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->15<-"+se);mess=se.getMessage();}
        return id;
    }

    public String getACManagerName(){
        String id="";
        try{
            id=myRS.getString("UserName");
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->16<-"+se);mess=se.getMessage();}
        return id;
    }

    public String getUserName(){
        String id="";
        try{
            id=myRS.getString("LoginName");
        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->17<-"+se);mess=se.getMessage();}
        return id;
    }

    public String getUserName(String uid){
        String id="";
        strSQL = "Select LoginName from USR_USERS WHERE UserID = '" +uid+ "'";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            myRS.next();
            String uname  = myRS.getString("LoginName");
            {
                return uname;
            }

        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->18<-"+se);mess=se.getMessage();}
        return "";
    }


//Login validation part
    public boolean ValidateUser(String uname,String pwd) throws Exception
    {
        boolean retVal=false;
        uname=uname.trim().replace('\'','`');
        pwd=pwd.trim().replace('\'','`');
        strSQL="SELECT USERID,LVL FROM USR_USERS WHERE loginName='"+uname+"' AND Password = ora_hash('" + pwd + "')AND OAMStatus=1 ";
        mess=strSQL;
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery(strSQL);
            if(myRS.next())
            {
                retVal=true;
            }
            mess="user being validated";
        }
        catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->19<-"+se);retVal=false; mess=se.getMessage();}
        return retVal;
    }
    public String getEncPwd(String uid) throws Exception
    {
        String retVal="";
        try{
            stmt=myConn.createStatement();
            myRS=stmt.executeQuery("select loginname from USR_USERS  where UserID='"+uid+"'");

            myRS.next();
            retVal=myRS.getString("loginname");
            retVal=Base64Encoder.encode(retVal.getBytes());
            mess="user type being extracted";

        }catch (SQLException se){
            System.out.println("\nError:[default-war/d2Systems/oam/ACManagersBean.java]->20<-"+se);retVal=""; mess=se.getMessage();}
        return retVal.trim();
    }


    public void cleanup() throws Exception
    {}

    /*
     Function: checkForRight
     Desc: This function checks if the user uid has the right rid. it checks into the OAM_USER_RIGHTS table.
     Author: Anjana
     Date: Nov 14, 2007
      */
     public boolean checkForRight(String uid, String rid)
     {

         strSQL = "SELECT COUNT(*) CNT FROM OAM_USER_RIGHTS WHERE UserID = '" +uid+ "' AND RID = '" +rid+ "'";
         try
         {
             getList(strSQL, "Checking for specific user right - Phase Bean");
             myRS.next();
             int count = myRS.getInt("CNT");
             //System.out.println(strSQL + "\n" + "Count is <<<<<<<<<<<<<<" +count+ ">>>>>>>>>>>>>>>>");
             if (count > 0) return true;
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
         return false;    
     }
     
     /*
   
     Desc: This function checks if the user uid has the right of security Managers of OAM.
     Author: vadhikari
     Date: feb 18, 2013
      */
     public boolean checkForSecurityManager(String uid)
     {

         strSQL = "SELECT COUNT(*) CNT FROM oam_domainmanagers WHERE UserID = '" +uid+ "' AND status = 1";
         try
         {
             getList(strSQL, "Checking for specific user right - Phase Bean");
             myRS.next();
             int count = myRS.getInt("CNT");
             //System.out.println(strSQL + "\n" + "Count is <<<<<<<<<<<<<<" +count+ ">>>>>>>>>>>>>>>>");
             if (count > 0) return true;
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
         return false;    
     }
     
     
     /*
     
     Desc: This function checks if the user uid has the right of superAdmin of OAM.
     Author: vadhikari
     Date: march 5, 2013
      */
     public boolean isSuperAdmin(String uid)
     {

         strSQL = "SELECT COUNT(*) CNT FROM oam_superadmins WHERE UserID = '" +uid+ "'";
         try
         {
             getList(strSQL, "Checking for specific user right - AcManagerBean");
             myRS.next();
             int count = myRS.getInt("CNT");
             //System.out.println(strSQL + "\n" + "Count is <<<<<<<<<<<<<<" +count+ ">>>>>>>>>>>>>>>>");
             if (count > 0) return true;
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
         return false;    
     }

     
     
     /*
     Method: checkForOamRight
     Desc: This method checks if the user uid has the right name. it checks into the OAM_USER_RIGHTS table.
     Purpose: It has been created to implement Oam Login As feature. 
     Author: Ram Kumar Sah
     Date: Jun 26, 2008
      */
     public boolean checkForOamRight(String uid, String rightName)        
     {

         strSQL = "SELECT COUNT(*) CNT FROM OAM_USER_RIGHTS WHERE UserID = '" +uid+ "' AND rid=(select rid from oam_rights where RNAME = '" +rightName+ "')";
         try
         {
             getList(strSQL, "Checking for specific user right - Phase Bean");
             //System.out.println(strSQL);
             myRS.next();
             int count = myRS.getInt("CNT");
             //System.out.println(strSQL + "\n" + "Count is <<<<<<<<<<<<<<" +count+ ">>>>>>>>>>>>>>>>");
             if (count > 0) return true;
         }
         catch(SQLException se)
         {
             se.printStackTrace();
         }
         return false;    
     }

     	public boolean isOAMUser(String uid)
     	{
     		boolean isOAMUser=false;
     		strSQL="select OAMUserTypeCode as OAMUserTypeCode from USR_USERS WHERE UserID='"+uid+"'";
     		try{
     			stmt=myConn.createStatement();
     			myRS=stmt.executeQuery(strSQL);
     			while(myRS.next())
     			{
     				if(myRS.getString("OAMUserTypeCode")!=null)
     				{
     					isOAMUser=true;
     				}
     			}
     			
     		}
     		catch(Exception e){
     			e.printStackTrace();
     		}
     		return isOAMUser;
     	}
     	
     	/** 
     	 * Added By: Dinesh Bajracharya
     	 * Added On: July 1, 2010
     	 * Description: To get the deault page of Production Manger(Main or Lite) for User*/
     	public String getPMDefaultPage(String uid)
     	{
     		String defaultPage="Main";
     		strSQL="select fieldvalue from OAM_PM_LITEUSERFILTERDATA where filtername='defaultPage' and userid='"+uid+"'";
     		try{
     			stmt=myConn.createStatement();
     			myRS=stmt.executeQuery(strSQL);
     			while(myRS.next())
     			{
     				defaultPage=myRS.getString("fieldvalue");
     			}
     			
     		}
     		catch(Exception e){
     			e.printStackTrace();
     		}
     		return defaultPage;
     	}
     	
     	/**
     	 * 
     	 * Description: This method returns if the given user has access to VHIPPM module or not
     	 * ACManagersBean.java
     	 * hasAccessToVHIPPM
     	 * boolean
     	 * @author: Dinesh Bajracharya
     	 * @since: Dec 22, 2010
     	 */
     	public String hasAccessToVHIPPM(String userID){
     		int count=0;
    		String sqlString = "select count(*) ct from oam_user_rights a inner join oam_rights b on a.rid=b.rid where userid='"+userID+"' and rname like 'VHIPPM'";
    		//System.out.println("SQL->"+sqlString);
    		try {
    			stmt = myConn.createStatement();
    			myRS = stmt.executeQuery(sqlString);
    			while (myRS.next()) {
    				count = myRS.getInt("ct");
    			}
    		} catch (SQLException se) {
    			System.out
    					.println("\nError:[default-war/d2Systems/oam/ACManagersBean.hasAccessToVHIPPM]->70<-"
    							+ se);
    		}
    		if(count>0) return "Y";
    		return "N";
     	}
     	
     	/**
     	 * Description : This method will return all the accessible clients by user
     	 * @param userID
     	 * @return 
     	 * @author vadhikari
     	 * @since Feb 27, 2013
     	 */
     	public List getAccessibleClients(String userID)
     	{
     		List<String> listOfAccessibleClients = new ArrayList<String>();
     		String sqlString = ""
        			+ "SELECT MIdomain.clientid "
        			+ "FROM   oam_domainmiclients MIdomain "
        			+ "       inner join oam_domainusers dusers "
        			+ "               ON MIdomain.domainid = dusers.domainid "
        			+ "                  AND dusers.userid = '"+userID+"'"
        			+ "UNION "
        			+ "SELECT datadomain.clientid "
        			+ "FROM   oam_domaindatasources datadomain "
        			+ "       inner join oam_domainusers dusers "
        			+ "               ON datadomain.domainid = dusers.domainid "
        			+ "                  AND dusers.userid = '"+userID+"'";
     		
     		try {
    			stmt = myConn.createStatement();
    			myRS = stmt.executeQuery(sqlString);
    			while (myRS.next()) {
    				listOfAccessibleClients.add(myRS.getString("CLIENTID"));
    				}
    		} catch (SQLException se) {
    			System.out
    					.println("\nError:[default-war/d2Systems/oam/ACManagersBean.getAccessibleClients]->71<-"
    							+ se);
    		}
     		 //System.out.println("returning the list of clients"+listOfAccessibleClients);
     		return listOfAccessibleClients;
     	}
     	/**
     	 * Description : This method will return all the accessible users by user
     	 * @param userID
     	 * @return 
     	 * @author vadhikari
     	 * @since Feb 27, 2013
     	 */
     	public List getAccessibleUsers(String userID)
     	{
     		List<String> listOfAccessibleUsers = new ArrayList<String>();
     		String accessibleUsers = ""
        			+ "SELECT domainuser.userid "
        			+ "FROM   oam_domainusers domainuser "
        			+ "       inner join (SELECT domainid "
        			+ "                   FROM   oam_domainusers "
        			+ "                   WHERE  userid = '"+userID+"') domainusr "
        			+ "               ON domainuser.domainid = domainusr.domainid "
    				+ "UNION "
    				+ "SELECT '"+userID+"'from dual";
     		
     		try {
    			stmt = myConn.createStatement();
    			myRS = stmt.executeQuery(accessibleUsers);
    			while (myRS.next()) {
    				listOfAccessibleUsers.add(myRS.getString("userid"));
    				}
    		} catch (SQLException se) {
    			System.out
    					.println("\nError:[default-war/d2Systems/oam/ACManagersBean.getAccessibleUsers]->72<-"
    							+ se);
    		}
     		return listOfAccessibleUsers;
     	}
     	/**
     	 * Description : This method will return all the accessible EI clients by user
     	 * @param userID
     	 * @return 
     	 * @author vadhikari
     	 * @since Feb 27, 2013
     	 */
     	public List getAccessibleEIClients(String userID)
     	{
     		List<String> listOfAccessibleEIClients = new ArrayList<String>();
     		String accessibleClients = ""
        			+ "SELECT EIdomain.clientid "
        			+ "FROM   oam_domainEIclients EIdomain "
        			+ "       inner join oam_domainusers dusers "
        			+ "               ON EIdomain.domainid = dusers.domainid "
        			+ "                  AND dusers.userid = '"+userID+"'";
     		
     		try {
    			stmt = myConn.createStatement();
    			myRS = stmt.executeQuery(accessibleClients);
    			while (myRS.next()) {
    				listOfAccessibleEIClients.add(myRS.getString("clientid"));
    				}
    		} catch (SQLException se) {
    			System.out
    					.println("\nError:[default-war/d2Systems/oam/ACManagersBean.getAccessibleUsers]->72<-"
    							+ se);
    		}
     		return listOfAccessibleEIClients;
     	}
     	
     	/**
     	 * this method returns the access on modules
     	 * for a given user
     	 * TODO
     	 * @param userID
     	 * @return
     	 * @author:Ramesh Raj Baral
     	 * @since:Jul 9, 2013
     	 * @modified by: Vadhikari
     	 * added usertype as userroles
     	 */
     	public Map<String,String> getUserRoles(String userID){
     		Map<String,String> rolesMap=new HashMap<String,String>();
     		String sqlString = "SELECT RT.RID,RT.RNAME FROM OAM_RIGHTS RT INNER JOIN OAM_USER_RIGHTS UR " +
     				" ON UR.RID=RT.RID WHERE UR.USERID='"+userID+"'";
     		sqlString += " UNION select s.OAMUserTypeCode , t.UserTypeDesc from USR_USERS s,OAM_USERTYPES t where s.OAMUserTypeCode=t.USERTYPECODE and s.UserID='"+userID+"'";
    		try {
    			stmt = myConn.createStatement();
    			myRS = stmt.executeQuery(sqlString);
    			while (myRS.next()) {
    				rolesMap.put(myRS.getString("rid"), myRS.getString("rname"));
    			}
    		} catch (SQLException se) {
    			System.out
    					.println("\nError:[default-war/d2Systems/oam/ACManagersBean.getUserRoles]->71<-"
    							+ se);
    		}
    		return rolesMap;
     	}

}
