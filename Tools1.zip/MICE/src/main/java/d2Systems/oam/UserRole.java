
package d2Systems.oam;

import java.io.Serializable;

/**
 * Class UserRole.java
 * Version 1.0
 * @author Ramesh Raj Baral
 * @since 9th July,2013
 *
 */
public class UserRole implements Serializable {

	private static final long serialVersionUID = -4931829140270107430L;
	
	private String roleID;
	private String roleName;
	private String description;
	
	public UserRole(String rid,String rName,String description){
		this.roleID=rid;
		this.roleName=rName;
		this.description=description;
	}
	
	public String getRoleID() {
		return roleID;
	}
	public void setRoleID(String roleID) {
		this.roleID = roleID;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
}
