/***************************************************************************************
Filename: SendMail.java
Creator : Pawan Shrestha
Date    : Oct. 1, 2002
Description:
Methods in this class are called to create message object, fill required and optional parameters,
fill mail server information and send.
Modifications:
Date:					Changed by:					Description
Oct 29,2003				Pawan K.S.					method setCCAddresses() added
Oct 30,2003				Pawan K.S.					methods setSMTPHost(),getSMTPHost() added
Mar 16,2009             Bhanu Chalise               1.Hosts changed to smtp.datacenter.d2hawkeye.net 
                                                    2.Qc mail receipent changed
Feb 14, 2012			Bhanu Chalise               Merged oam and rm email class into one read 
													smtp,enableemaisend and Qc from database                                                                        
 *                                                                                      
 ************************************************************************************************/
package d2Systems.oam;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.d2hs.soam.SqlBean;

public class SendMail extends SqlBean 
{
    private boolean hasCCAddr 			=	false;
    private InternetAddress[] ccAddrList;
    private String errString 			= 	"";
    private String host 				= 	""; 
    private boolean enableQCMailSend 	= 	true;
    private boolean enableMailSend 		= 	false;
    private boolean msgSend 			= 	false;
    private InternetAddress[] qcEmailRecipient;
    private int noOfRetries 			= 	1;
    private InternetAddress[] qcToList	= 	new InternetAddress[1];
    private boolean productionSendMail	=	true;
    
    
    public SendMail() 
    {
    	
    	SqlBean sbean					= 	new SqlBean();
    	String tempSmtpAdd				=	sbean.getFixedParameter("smtpHostAddress");
    	if(tempSmtpAdd	==	null	|| tempSmtpAdd.trim().equals(""))
    	{
    		tempSmtpAdd="smtpnj.d2hawkeye.net";
    	}
   		boolean tempIsEnableMailSend	=	(sbean.getFixedParameter("enableMailSend")!=null && sbean.getFixedParameter("enableMailSend").equalsIgnoreCase("true"))?true:false;
    	boolean tempIsEnableQCMailSend	=	(sbean.getFixedParameter("isQcForEmailSend")!=null && sbean.getFixedParameter("isQcForEmailSend").equalsIgnoreCase("true"))?true:false;
    	String tempQcEmails				=	sbean.getFixedParameter("oamQcEmailRecepients");
    	
    	this.setProductionSendMail((sbean.getFixedParameter("isProductionSendMail")!=null && sbean.getFixedParameter("isProductionSendMail").equalsIgnoreCase("true"))?true:false);
    	
    	if( sbean.getFixedParameter("noOfEmailRetries") != null &&  !sbean.getFixedParameter("noOfEmailRetries").equals("") )
    	{
    		this.setNoOfRetries(Integer.parseInt(sbean.getFixedParameter("noOfEmailRetries")));
    	}
        
    	this.setHost(tempSmtpAdd);
    	this.setEnableMailSend(tempIsEnableMailSend);
    	this.setEnableQCMailSend(tempIsEnableQCMailSend);
    	
        System.out.println(" Sending Email:: using SendEmail class " +
		        		   "\n Send email  Qc enabled " + this.isEnableQCMailSend() +
		        		   "\n Send email  Enabled " +  this.isEnableMailSend() +
		        		   "\n host " + this.getHost() );

        String[] strArrayQcEmails	 	=	tempQcEmails.split(",");
        qcEmailRecipient = new InternetAddress[strArrayQcEmails.length];
        int k = 0;
        for (int i = 0; i < strArrayQcEmails.length; i++) {

            try {
                if ((strArrayQcEmails[i]).indexOf("N/A") == -1) {
                	qcEmailRecipient[k] = new InternetAddress(strArrayQcEmails[i]);
                    k++;
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
         qcToList[0]=qcEmailRecipient[0];
    }
   
    
    public SendMail(String mailServer,boolean enableMailSend,boolean enableQCMailSend, InternetAddress[] qcEmailRecipient)
    {
    	this.host =mailServer;
    	this.enableMailSend=enableMailSend;
    	this.enableQCMailSend=enableQCMailSend;
    	this.qcEmailRecipient=qcEmailRecipient;
    	
    }

    public String getError() {
        return errString;
    }

	public String getHost() {
		return host;
	}


	public void setHost(String host) {
		this.host = host;
	}


	public boolean isEnableQCMailSend() {
		return enableQCMailSend;
	}


	public void setEnableQCMailSend(boolean enableQCMailSend) {
		this.enableQCMailSend = enableQCMailSend;
	}


	public boolean isEnableMailSend() {
		return enableMailSend;
	}


	public void setEnableMailSend(boolean enableMailSend) {
		this.enableMailSend = enableMailSend;
	}

	public InternetAddress[] getQcToList() {
		return qcToList;
	}


	public void setQcToList(InternetAddress[] qcToList) {
		this.qcToList = qcToList;
	}
	
	/**
	 * @return the productionSendMail
	 */
	public boolean isProductionSendMail() {
		return productionSendMail;
	}


	/**
	 * @param productionSendMail the productionSendMail to set
	 */
	public void setProductionSendMail(boolean productionSendMail) {
		this.productionSendMail = productionSendMail;
	}


	/**
	 * @return the noOfRetries
	 */
	public int getNoOfRetries() {
		return noOfRetries;
	}


	/**
	 * @param noOfRetries the noOfRetries to set
	 */
	public void setNoOfRetries(int noOfRetries) {
		this.noOfRetries = noOfRetries;
	}


	public void setCCAddresses(Vector ccAddr) {
        try {
            hasCCAddr = true;
            InternetAddress[] ccAddrListTemp = new InternetAddress[ccAddr.size()];
            int realCcSize = 0;
            for (int i = 0; i < ccAddrListTemp.length; i++) {
                if (!"N/A".equalsIgnoreCase(ccAddr.elementAt(i).toString())) {
                    ccAddrListTemp[realCcSize] = new InternetAddress(ccAddr.elementAt(i).toString());
                    realCcSize++;
                }
            }

            ccAddrList = new InternetAddress[realCcSize];
            for (int i = 0; i < realCcSize; i++) {
                ccAddrList[i] = ccAddrListTemp[i];
            }

        } catch (Exception e) {
            System.out.println("\nError:[default-war/d2Systems/oam/SendMail.java]->0<-" + e);
            errString = e.toString();
        }

    }

    /*
    public static void main(String[] args){
    SendMail sm= new SendMail();
    sm.enableMailSend= true;
    sm.isQC=false;
    sm.setSMTPHost("smtp.datacenter.d2hawkeye.net");
    Vector to=new Vector();
    to.add("bchalise@veriskhealth.com");
    to.add("rsharma@veriskhealth.com");
    to.add("N/A");
    Vector ccs=new Vector();
    ccs.add("dibajracharya@veriskhealth.com");
    ccs.add("rsah@veriskhealth.com");
    ccs.add("N/A");
    System.out.print("Mail send Started----------");
    sm.send("oamtest@veriskhealth.com",to,ccs,"TEST ",
    "<br><br><br><br>This is test, please do not reply<br>---------------------------------------------------------<br>--Bhanu ");
    System.out.print("Mail send Complete----------");
    }
     */
    
    public boolean send(String from, String to, String msgSubject, String msgText) {
        System.out.println(" Sending Email::" + from + " to ::" + to);

        if(!isEnableMailSend()){
        	System.out.println(" Mail send is disabled ");
        	return false;
        }
        
        if (isEnableQCMailSend()) {
            return this.sendQC(from, to, msgSubject, msgText);
        }
        
        if(!isProductionSendMail())
        {
        	from="UAT_"+from;
        }

        Properties props = new Properties();
        props.put("mail.smtp.host", this.getHost()); 
        props.put("mail.transport.protocol", "smtp");

        Session session = Session.getDefaultInstance(props, null);

        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            InternetAddress[] address = {new InternetAddress(to)};
            msg.setRecipients(Message.RecipientType.TO, address);

            if (hasCCAddr) {
                msg.setRecipients(Message.RecipientType.CC, ccAddrList);
            }

            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            /*Blocked the mail send for email id "N/A"*/ 
            if (to.indexOf("N/A") == -1) {
                    Transport.send(msg);
                    msgSend = true;
                }
            
            hasCCAddr = false;
        } catch (Exception e) {
            System.out.println("\nError:[default-war/d2Systems/oam/SendMail.send]->1<-" + e);
            errString = e.toString();
        }

        return msgSend;
    }

    /**
     * This is a wrapper for send email. In qc phase, all email send by this class is infact
     * send to qc persons, the actaul to ,cc are appended in email body.
     * @param from
     * @param to
     * @param msgSubject
     * @param msgText
     * @return boolean
     */
    private int triggerCount = 0;
    public boolean send(String from, Vector to, Vector ccs, String msgSubject, String msgText, String Assignee) {
    	
        System.out.println("d2Systems.oam.SendMail.send()-> SEND MAIL BEGIN");
    	     	
    	
    	if(ccs!=null && to != null){
            System.out.println(" Sending Email:: " + from + " to ::" + to );
            System.out.println(" Sending Email:: " + from + " cc ::" + ccs );
    	}
    	   /**
         * modified by Ram Gautam, Sept 11,2012
         * description: modifed to set the unique receivers on both to and cc email list.
         */
        Vector uniqueToList=new Vector();
        Vector uniqueCCList=new Vector();
        
        
        for(int i=0;i<to.size();i++){
        	if(!uniqueToList.contains(to.elementAt(i))){
        		//System.out.println("uniqueListTo:"+uniqueToList+"\n element"+to.elementAt(i));
        		uniqueToList.add(to.elementAt(i));
        	}
        }
        if (ccs != null) {
	        for(int i=0;i<ccs.size();i++){
	        	if(!uniqueToList.contains(ccs.elementAt(i))&&!uniqueCCList.contains(ccs.elementAt(i))){
	        		//System.out.println("uniqueListCC:"+uniqueCCList+"\n element"+ccs.elementAt(i));
	        		uniqueCCList.add(ccs.elementAt(i));
	        	}
	        }
        }
        
        if(!isEnableMailSend()){
        	System.out.println(" Mail send is disabled ");
        	return false;
        }
        
        if (isEnableQCMailSend()) {
        	String intended = "<br><br><b>To::</b> ";
        	   for (int i = 0; i < uniqueToList.size(); i++) {                    
                     intended +=  uniqueToList.get(i) + ",";
                 }
                 
             intended += "<br><br><b>CC::</b> ";
             
             for (int i = 0; i < uniqueCCList.size(); i++) {                    
                 intended +=  uniqueCCList.get(i) + ",";
             }
             intended += "<br/>----------------------------------------------<br><br>";
        	
        	 return sendTestQC(Assignee, msgSubject, intended + msgText);
           // return sendQC(from, uniqueToList, uniqueCCList, msgSubject, msgText);
        }
        
        if(!isProductionSendMail())
        {
        	from="UAT_"+from;
        }
        
        msgSend = false;
        Properties props = new Properties();
        props.put("mail.smtp.host", this.getHost());
        props.put("mail.transport.protocol", "smtp");

        Session session = Session.getDefaultInstance(props, null);

        try {
            InternetAddress[] toList = new InternetAddress[uniqueToList.size()];
            int realToListSize = 0;

            for (int i = 0; i < toList.length; i++) {

                if ((uniqueToList.elementAt(i).toString()).indexOf("N/A") == -1) {
                    toList[realToListSize] = new InternetAddress(uniqueToList.elementAt(i).toString());
                    realToListSize++;
                }
            }
            InternetAddress[] toFilteredList = new InternetAddress[realToListSize];
            for (int i = 0; i < realToListSize; i++) {
                toFilteredList[i] = toList[i];
            }

            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipients(Message.RecipientType.TO, toFilteredList);

            
                InternetAddress[] ccList = new InternetAddress[uniqueCCList.size()];
                int realCcSize = 0;
                for (int i = 0; i < ccList.length; i++) {
                    if ((uniqueCCList.elementAt(i).toString()).indexOf("N/A") == -1) {
                        ccList[realCcSize] = new InternetAddress(uniqueCCList.elementAt(i).toString());
                        realCcSize++;
                    }
                }
                InternetAddress[] ccFilteredList = new InternetAddress[realCcSize];
                for (int i = 0; i < realCcSize; i++) {
                    ccFilteredList[i] = ccList[i];
                }
                msg.setRecipients(Message.RecipientType.CC, ccFilteredList);
           


            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            System.out.println("d2Systems.oam.SendMail.send()->Transport-before");
            Transport.send(msg);
            System.out.println("d2Systems.oam.SendMail.send()->Transport-after");
            msgSend = true;
            hasCCAddr = false;
            triggerCount++ ; 
        } catch (Exception e) {
        	   System.out.println("d2Systems.oam.SendMail.send()-Error>" + e.getMessage());
        	triggerCount++ ; 
        	if ( triggerCount <= getNoOfRetries())
        	{
        		 return send( from, to, ccs,  msgSubject,  msgText , Assignee );
        	}
        	else
        	{
        		
        		//logFailedNotification(from, uniqueToList, uniqueCCList,  msgSubject,  msgText ,e.toString());
                errString = e.toString();
        	}
           
        }
        System.out.println("d2Systems.oam.SendMail.send()-> SEND MAIL FINISHED");
        return msgSend;
    }

    public boolean sendQC(String from, String to, String msgSubject, String msgText) {

    	System.out.println(" Sending Email:: " + from + " to ::" + to );

    	
    	
        if(!isEnableMailSend()){
        	System.out.println(" Mail send is disabled ");
        	return false;
        }
    	
        if(!isProductionSendMail())
        {
        	from="UAT_"+from;
        }
        
    	msgSend = false;
        Properties props = new Properties();
        props.put("mail.smtp.host", this.getHost());
        props.put("mail.transport.protocol", "smtp");

        Session session = Session.getDefaultInstance(props, null);
        String intended = "----------------------------<br><br><b>To::</b> ";
        intended += to + " <br/><b>CC::</b>";
        try {
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            InternetAddress[] address = qcToList;
            msg.setRecipients(Message.RecipientType.TO, address);

            if (hasCCAddr) {
                for (int i = 0; i < ccAddrList.length; i++) {
                    InternetAddress ccAdd = ccAddrList[i];
                    intended += ccAdd.getAddress() + ",";
                }
            }
            intended += "<br/>----------------------------------------------<br><br><b>Orginal Mail::</b><br>";

           // msgText = intended + msgText;
            msgSubject = "[ICE Mail QC] " + msgSubject;

            msg.setRecipients(Message.RecipientType.CC, qcEmailRecipient);
            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            System.out.println("Before sending mail to " + to + " from VECTOR");
                if (to.indexOf("N/A") == -1) {
                    Transport.send(msg);
                }
            System.out.println("Sending email complete");

            msgSend = true;
            hasCCAddr = false;
        } catch (Exception e) {
            System.out.println("\nError:[default-war/d2Systems/oam/SendMail.sendQC]->1<-" + e);
            errString = e.toString();
        }

        return msgSend;
    }

    /**
     * This method is called when app is run in qc mode, all the emalis are send to qc persons and intented email address is 
     * appended in email.
     * @param from
     * @param to
     * @param ccs
     * @param msgSubject
     * @param msgText
     * @return boolean
     */
    public boolean sendTestQC(String from, String msgSubject, String msgText) {   
    	
    	 if(!isProductionSendMail())
         {
         	from="UAT_"+from;
         }
    	 
    	msgSend = false;
        Properties props = new Properties();
        props.put("mail.smtp.host", this.getHost());
        props.put("mail.transport.protocol", "smtp");

        Session session = Session.getDefaultInstance(props, null);
        String intended = "----------------------------<br><br><b>To::</b> ";
        try {
          
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipient(Message.RecipientType.TO, new InternetAddress(from));          
            intended += " <br/><b>CC::</b>";         
            msg.setRecipient(Message.RecipientType.CC, new InternetAddress(from));
            intended += "<br/>----------------------------------------------<br><br><b>Orginal Mail::</b><br>";

           // msgText = intended + msgText;
            msgSubject = "[ICE Mail QC] " + msgSubject;

            msg.setSubject(msgSubject);
            msg.setSentDate(new Date());
            msg.setText(msgText);
            msg.setHeader("Content-Type", "text/html");
            Transport.send(msg);
            msgSend = true;         
           
        } catch (Exception e) {
        	e.printStackTrace();
        
        }

        return msgSend;
    }
    
    public boolean sendQC(String from, Vector to, Vector ccs, String msgSubject, String msgText) {   
    	
   	 if(!isProductionSendMail())
        {
        	from="UAT_"+from;
        }
   	 
   	msgSend = false;
       Properties props = new Properties();
       props.put("mail.smtp.host", this.getHost());
       props.put("mail.transport.protocol", "smtp");

       Session session = Session.getDefaultInstance(props, null);
       String intended = "----------------------------<br><br><b>To::</b> ";
       try {
           InternetAddress[] toList = new InternetAddress[to.size()];
           for (int i = 0; i < toList.length; i++) {
               intended += to.elementAt(i).toString() + ",";
           }
           Message msg = new MimeMessage(session);
           msg.setFrom(new InternetAddress(from));
           msg.setRecipients(Message.RecipientType.TO, qcToList);
           intended += " <br/><b>CC::</b>";

           if (ccs != null) {
               InternetAddress[] ccList = new InternetAddress[ccs.size()];
               for (int i = 0; i < ccList.length; i++) {
                   ccList[i] = new InternetAddress(ccs.elementAt(i).toString());
                   intended += ccList[i].getAddress() + ",";
               }
           }
           msg.setRecipients(Message.RecipientType.CC, qcEmailRecipient);
           intended += "<br/>----------------------------------------------<br><br><b>Orginal Mail::</b><br>";

           msgText = intended + msgText;
           msgSubject = "[OAM Mail QC] " + msgSubject;

           msg.setSubject(msgSubject);
           msg.setSentDate(new Date());
           msg.setText(msgText);
           msg.setHeader("Content-Type", "text/html");
           Transport.send(msg);
           msgSend = true;
           hasCCAddr = false;
           triggerCount++;
       } catch (Exception e) {
       	e.printStackTrace();
       	triggerCount++ ; 
       	if ( triggerCount <= getNoOfRetries())
       	{
       		 return send( from, to, ccs,  msgSubject,  msgText , from);
       	}
       	else
       	{
       		
       		logFailedNotification(from, to, ccs,  msgSubject,  msgText ,e.getMessage());
            errString = e.toString();
       	}
       }

       return msgSend;
   }


    public boolean sendList(String xmlFileName, String from, String sub, String msg) {
        try {
            SendMail mail = new SendMail();
            FileReader xmlFileReader = new FileReader(xmlFileName);
            BufferedReader xmlFileBReader = new BufferedReader(xmlFileReader);

            String fileLine = "";
            String toName = "";
            String toEmail = "";
            boolean success = true;

            do {
                fileLine = xmlFileBReader.readLine();
                if (fileLine.indexOf("<file>") == -1 && fileLine.indexOf("</file>") == -1) {
                    toName = fileLine.substring(fileLine.indexOf("<name>") + 6, fileLine.indexOf("</name>"));
                    toEmail = fileLine.substring(fileLine.indexOf("<email>") + 7, fileLine.indexOf("</email>"));
                    System.out.println("Name: " + toName + " Email: " + toEmail);
                    mail.send(from, toName + "<" + toEmail + ">", sub, msg);
                }
            } while (fileLine.indexOf("</file>") == -1);
            return success;
        } catch (FileNotFoundException err) {
            System.out.println("\nError:[default-war/d2Systems/oam/SendMail.java]->3<-" + err);
            System.out.println(err);
            return false;
        } catch (IOException err) {
            System.out.println("\nError:[default-war/d2Systems/oam/SendMail.java]->4<-" + err);
            System.out.println(err);
            return false;
        }
    }
    
    /**
     * @author Vivek Adhikari
     * Method to log all the details when email trigger is failed.
     * @param from
     * @param emailTO
     * @param emailCC
     * @param msgSubject
     * @param msgText
     * @param errorMessage
     * @return
     */
    public boolean logFailedNotification(String from, Vector emailTO, Vector emailCC, String msgSubject, String msgText , String errorMessage) 
    {
    	boolean isInserted = false ; 
    	String toEmail ;
    	StringBuffer toEmailBuffer = new StringBuffer();
    	
    	Iterator it = emailTO.iterator();
    	 while(it.hasNext())
    	 {
    		
    		 toEmailBuffer.append(it.next() + ",");
    	 }
    	 toEmail = toEmailBuffer.toString();
    	 
    	 String ccEmail ;
    	 StringBuffer ccEmailBuffer = new StringBuffer();
    	 Iterator it1 = emailCC.iterator();
    	 while(it1.hasNext())
    	 {
    		 ccEmailBuffer.append(it1.next() + ",");
    	 }
    	 ccEmail = ccEmailBuffer.toString();
    	  
    	 //try {
    		 return true;
    		// return new SqlBean().executeQuery(from, toEmail,ccEmail, TextEncoder.encodeSQL(msgSubject) , TextEncoder.encodeSQL(msgText) ,TextEncoder.encodeSQL(errorMessage) );
		//} catch (SQLException e) {
			//return isInserted;
		//}
    	 
    }
}
