package d2Systems.rm;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * FileName:UserPreference.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jun 24, 2010
 *
 */
public class UserPreference {

	/**
	 * @author Ramesh Raj Baral
	 * @since Aug 13 2010
	 * Modifications to adjust customizable filters
	 */
	
	private boolean light=false;
	private UserFilters userDefaultFilter=null; 
	private List<UserFilters> userFiltersList=null;
	
	public UserPreference(){
		userFiltersList=new ArrayList<UserFilters>();
		userDefaultFilter=new UserFilters();
	}
	public boolean isLight() {
		return light;
	}
	public void setLight(boolean light) {
		this.light = light;
	}
	public List<UserFilters> getUserFiltersList() {
		return userFiltersList;
	}
	public void setUserFiltersList(List<UserFilters> userFiltersList) {
		this.userFiltersList = userFiltersList;
	}
	public UserFilters getUserDefaultFilter() {
		return userDefaultFilter;
	}
	public void setUserDefaultFilter(UserFilters userDefaultFilter) {
		this.userDefaultFilter = userDefaultFilter;
	}
}
