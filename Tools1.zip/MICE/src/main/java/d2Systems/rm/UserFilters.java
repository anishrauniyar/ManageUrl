package d2Systems.rm;

/**
 * 
 * FileName:UserFilters.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Aug 13, 2010
 *
 */
public class UserFilters {

	private String filterID;
	private String filterName;
	private String requestType;
	private String requestStatus;
	private String requestPriority;
	private String requestSeverity;
	private String requestOwner;
	
	public UserFilters(){
		this.filterID="0";
		this.filterName="N/A";
		this.requestOwner="0";
		this.requestOwner="0";
		this.requestPriority="0";
		this.requestSeverity="0";
		this.requestStatus="0";
	}
	
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getRequestPriority() {
		return requestPriority;
	}
	public void setRequestPriority(String requestPriority) {
		this.requestPriority = requestPriority;
	}
	public String getRequestSeverity() {
		return requestSeverity;
	}
	public void setRequestSeverity(String requestSeverity) {
		this.requestSeverity = requestSeverity;
	}

	public String getRequestOwner() {
		return requestOwner;
	}
	public void setRequestOwner(String requestOwner) {
		this.requestOwner = requestOwner;
	}
	public String getFilterID() {
		return filterID;
	}
	public void setFilterID(String filterID) {
		this.filterID = filterID;
	}
}
