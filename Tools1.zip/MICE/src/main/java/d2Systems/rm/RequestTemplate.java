package d2Systems.rm;

import java.io.File;
import java.util.List;

import d2Systems.rm.User;
import com.d2hs.soam.rm.RequestAttachment;

/**
 * <li>This class resembles the template of a normal request</li>
 * <li>The values of the required attribute can be set according to requirement</li>
 * FileName:RequestTemplate.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jun 3, 2010
 *
 */
public class RequestTemplate {

	private String requestSource;
	private String client;
	private String product;
	private String project;
	private String requestType;
	private String requestTypeDesc;
	private String module;
	private String area;
	private String requestTitle;
	private String dataLayout;
	private String dataType;
	private String description;
	private String assingedTo;
	private List acknowledgeUsers;
	private String versionDetected;
	private String requestDate;
	private String targetDate;
	private String priority;
	private String estimatedHours;
	private String targetedVersion;
	private boolean hasAttachment;
	private String phaseInjected;
	private String phaseDetected;
	private boolean trustedUserFilter;//if Y allow all else allow from the trustedusers value
	private String templateID;
	private String templateName;
	private User requestingUser;
	private RequestEmail requestEmail;
	String requestCode;
	private List trustedUsers;
	private String parentRequestCode;
	private String statusID;
	private String severityID;
	private boolean completed;
	private String impact;
	private String addedBy;
	private boolean trustedFilter;
	private boolean isValid;
	private String dataProvider;
	private List<RequestAttachment> attachments;
	
	

	public RequestTemplate(){
		
	}
	public RequestTemplate(String tempID,String tempName){
		this.templateID=tempID;
		this.templateName=tempName;
	}
	public String getRequestSource() {
		return requestSource;
	}
	public void setRequestSource(String requestSource) {
		this.requestSource = requestSource;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getRequestTitle() {
		return requestTitle;
	}
	public void setRequestTitle(String requestTitle) {
		this.requestTitle = requestTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAssingedTo() {
		return assingedTo;
	}
	public void setAssingedTo(String assingedTo) {
		this.assingedTo = assingedTo;
	}
	
	public String getVersionDetected() {
		return versionDetected;
	}
	public void setVersionDetected(String versionDetected) {
		this.versionDetected = versionDetected;
	}
	public String getTargetDate() {
		return targetDate;
	}
	public void setTargetDate(String targetDate) {
		this.targetDate = targetDate;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getEstimatedHours() {
		return estimatedHours;
	}
	public void setEstimatedHours(String estimatedHours) {
		this.estimatedHours = estimatedHours;
	}
	public String getTargetedVersion() {
		return targetedVersion;
	}
	public void setTargetedVersion(String targetedVersion) {
		this.targetedVersion = targetedVersion;
	}
	public boolean isHasAttachment() {
		return hasAttachment;
	}
	public void setHasAttachment(boolean hasAttachment) {
		this.hasAttachment = hasAttachment;
	}

	public String getPhaseInjected() {
		return phaseInjected;
	}
	public void setPhaseInjected(String phaseInjected) {
		this.phaseInjected = phaseInjected;
	}
	public String getPhaseDetected() {
		return phaseDetected;
	}
	public void setPhaseDetected(String phaseDetected) {
		this.phaseDetected = phaseDetected;
	}
	public boolean isTrustedUserFilter() {
		return trustedUserFilter;
	}
	public void setTrustedUserFilter(boolean trustedUserFilter) {
		this.trustedUserFilter = trustedUserFilter;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getTemplateID() {
		return templateID;
	}
	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public User getRequestingUser() {
		return requestingUser;
	}
	public void setRequestingUser(User requestingUser) {
		this.requestingUser = requestingUser;
	}
	public RequestEmail getRequestEmail() {
		return requestEmail;
	}
	public void setRequestEmail(RequestEmail requestEmail) {
		this.requestEmail = requestEmail;
	}
	public String getRequestCode() {
		return requestCode;
	}
	public void setRequestCode(String requestCode) {
		this.requestCode = requestCode;
	}
	public List getTrustedUsers() {
		return trustedUsers;
	}
	public void setTrustedUsers(List trustedUsers) {
		this.trustedUsers = trustedUsers;
	}
	public List getAcknowledgeUsers() {
		return acknowledgeUsers;
	}
	public void setAcknowledgeUsers(List acknowledgeUsers) {
		this.acknowledgeUsers = acknowledgeUsers;
	}
	public String getParentRequestCode() {
		return parentRequestCode;
	}
	public void setParentRequestCode(String parentRequestCode) {
		this.parentRequestCode = parentRequestCode;
	}
	public String getStatusID() {
		return statusID;
	}
	public void setStatusID(String statusID) {
		this.statusID = statusID;
	}
	public String getSeverityID() {
		return severityID;
	}
	public void setSeverityID(String severityID) {
		this.severityID = severityID;
	}
	public boolean isCompleted() {
		return completed;
	}
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}
	public String getAddedBy() {
		return addedBy;
	}
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}
	public boolean isTrustedFilter() {
		return trustedFilter;
	}
	public void setTrustedFilter(boolean trustedFilter) {
		this.trustedFilter = trustedFilter;
	}
	public boolean isValid() {
		return isValid;
	}
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	public String getDataProvider() {
		return dataProvider;
	}
	public void setDataProvider(String dataProvider) {
		this.dataProvider = dataProvider;
	}
	public List<RequestAttachment> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<RequestAttachment> attachments) {
		this.attachments = attachments;
	}
	public String getRequestTypeDesc() {
		return requestTypeDesc;
	}
	public void setRequestTypeDesc(String requestTypeDesc) {
		this.requestTypeDesc = requestTypeDesc;
	}
	public void setDataLayout(String dataLayout) {
		this.dataLayout = dataLayout;
	}
	public String getDataLayout() {
		return dataLayout;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDataType() {
		return dataType;
	}
	

	
}
