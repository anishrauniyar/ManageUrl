package d2Systems.rm;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import d2Systems.rm.User;
import com.d2hs.soam.ConnectionBean;
import d2Systems.oam.SendMail;
import com.d2hs.soam.rm.QueryBean;
import com.d2hs.soam.rm.RequestAttachment;
import com.sun.mail.pop3.POP3Folder;

/**
 * 
 * FileName:EmailRequestAdder.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jun 4, 2010
 *
 */
public class EmailRequestAdder extends ConnectionBean {

	private static File file;
	private static FileOutputStream foStream;
	private static POP3Folder pf;
	private Map usersMap=new HashMap();
	private Map usersMapByID=new HashMap();
	private Map validTemplatesMap=new HashMap();
	private String ticketAddress;
	private String ticketPwd;
	private String ticketPopServer;
	private String ticketPopPort;
	private String ticketSmtpServer;
	private String ticketSmtpPort;
	private String ticketMailServer;
	private String failureMsg;
	
	public EmailRequestAdder() throws ClassNotFoundException, SQLException, IOException{
		String sql="select userid,username,loginname,email from usr_users";
		String sql_templates="SELECT templ.*, "
							+ "       TYPE.requesttypedesc "
							+ "FROM   oam_rm_templates templ "
							+ "       inner join oam_rm_request_types type "
							+ "         ON TYPE.requesttypeid = templ.requesttype ";

		String sql_ticket="select *from oam_rm_ticketmail";
		try {
			if(myConn==null)
			this.connectDB();
		ResultSet rs;
		Statement stmt=myConn.createStatement();
		rs=stmt.executeQuery(sql);
		while(rs.next()){
			User user=new User();
			user.setLoginName(rs.getString("loginname"));
			//if useremail in db is in d2hawkeye domain replace it with veriskhealth domain
			String userEmail=rs.getString("email")==null?"":(rs.getString("email").replaceAll("d2hawkeye", "veriskhealth"));
			user.setUserEmail(userEmail);
			user.setUserID(rs.getString("userid"));
			user.setUserName(rs.getString("username"));
			usersMap.put(user.getUserEmail(),user);
			usersMapByID.put(user.getUserID(), user);
		}
		rs=stmt.executeQuery(sql_templates);
		while(rs.next()){
			RequestTemplate template=new RequestTemplate(rs.getString("templateid"),rs.getString("templatename"));
			List trustedUsersList=new ArrayList();
			List ackUsersList=new ArrayList();
			String ackUsers="";
			String trustedUsers="";
			ackUsers=rs.getString("acknowledgeusers")==null?"":rs.getString("acknowledgeusers");
			trustedUsers=rs.getString("trustedusers")==null?"":rs.getString("trustedusers");
			User user;
			if(ackUsers.length()>0){
				String[] ackUsersArr=ackUsers.split(",");
				for(int ai=0;ai<ackUsersArr.length;ai++){
					user=new User();
					user=(User)usersMapByID.get(ackUsersArr[ai]);
					if(user!=null)
						ackUsersList.add(user);
				}
			}
			if(trustedUsers.length()>0){
				String[] trustUsersArr=trustedUsers.split(",");
				for(int i=0;i<trustUsersArr.length;i++){
					user=(User)usersMapByID.get(trustUsersArr[i]);
					if(user!=null)
						trustedUsersList.add(user);
				}
			}
			template.setRequestSource(rs.getString("requestsource"));
			template.setAcknowledgeUsers(ackUsersList);
			template.setTrustedUsers(trustedUsersList);
			template.setAddedBy(rs.getString("addedby"));
			template.setPhaseInjected(rs.getString("phaseinjected"));
			template.setPhaseDetected(rs.getString("phasedetected"));
			template.setVersionDetected(rs.getString("versiondetected"));
			template.setRequestType(rs.getString("requesttype"));
			template.setRequestTypeDesc(rs.getString("requesttypedesc"));
			String dataProviderID=rs.getString("dataproviderid")==null?"0":(rs.getString("dataproviderid").trim().length()<1?"0":rs.getString("dataproviderid"));
			String estimatedHours=rs.getString("estimatedhours")==null?"0":rs.getString("estimatedhours").trim().length()<1?"0":rs.getString("estimatedhours");
			
			template.setDataProvider(dataProviderID);
			template.setEstimatedHours(estimatedHours);
			boolean trustedFilterOn=rs.getString("trusteduserfilter")==null?false:(rs.getString("trusteduserfilter").equalsIgnoreCase("Y")?true:false);
			template.setTrustedFilter(trustedFilterOn);
			validTemplatesMap.put(template.getTemplateName(), template);
		}
		rs=stmt.executeQuery(sql_ticket);
		while(rs.next()){
			String fieldname=rs.getString("fieldname");
			String fieldvalue=rs.getString("fieldvalue");
			
			if(fieldname.equalsIgnoreCase("email"))
				this.ticketAddress=fieldvalue;
			else if(fieldname.equalsIgnoreCase("password"))
				this.ticketPwd=fieldvalue;
			else if(fieldname.equalsIgnoreCase("popport"))
				this.ticketPopPort=fieldvalue;
			else if(fieldname.equalsIgnoreCase("popserver"))
				this.ticketPopServer=fieldvalue;
			else if(fieldname.equalsIgnoreCase("smtpport"))
				this.ticketSmtpPort=fieldvalue;
			else if(fieldname.equalsIgnoreCase("smtpserver"))
				this.ticketSmtpServer=fieldvalue;
			else if(fieldname.equalsIgnoreCase("mailserver"))
				this.ticketMailServer=fieldvalue;
		
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try{
				this.takeDown();
			}catch(Exception ex){
				System.out.println("Exception disconnecting from DB:"+ex.getMessage());
			}
			//oracleDB.disconnect();
		}
		
	}
	

	/**
	 * 
	 * Description:
	 * scanAndInsertFromEmail
	 * <li>scan inbox and insert new request if new mail has arrived</li>
	 * @throws Exception 
	 * @throws IOException
	 * void
	 * Author:Ramesh Raj Baral
	 * @since Jun 4, 2010
	 */
	
	public void scanAndInsertFromEmail() throws Exception{
		System.out.println("from scanandinsertfromemail method");
		List requestsList=this.readEmail();
		if(requestsList!=null && requestsList.size()>0){
		this.enterNewRequestFromEmail(requestsList);
		}
		else
			System.out.println("no new mails arrived so far");
	}
	/**
	 * 
	 * Description:readEmail
	 * <li>this method reads emails from the specified server and returns the <code>List</code> of RequestTemplate</li>
	 * @return
	 * @throws Exception 
	 * @since Jun 4, 2010
	 */

	public  List readEmail() throws Exception{
		return null;
	}
/**
 * 
 * Description:
 * <li>This method iteratively accesses the email contents and initializes the RequestTemplate from the mail</li>
 * @param p
 * @param requestEmail
 * @param requestTemplate
 * @throws IOException
 * @throws MessagingException
 * void
 * Author:Ramesh Raj Baral
 * @since Jun 4, 2010
 */
	
	public void printParts(Part p,RequestEmail requestEmail,RequestTemplate requestTemplate) throws IOException, MessagingException {
		   Object o = p.getContent();
		   
		   if (o instanceof String) {
			       String msg="*********This is a String**"+requestEmail.getMessageID()+"********\n";
				   //System.out.println(msg);
			       //System.out.println((String)o);
			       //foStream.write(msg.getBytes());
			       //foStream.write(((String)o).getBytes());
			       /**
			        * from the <code>RequestEmail</code> sent populate the <code>RequesteTemplate</code>
			        * object which will be the new request
			        * the other fields of the template is 
			        */
			       requestTemplate.setDescription((String)o);
			       requestEmail.setMsgBody(requestTemplate.getDescription());
			       
			   } else if (o instanceof Multipart) {
			       String mmsg="***********This is a Multipart********";
				   //System.out.println(mmsg);
			       Multipart mp = (Multipart)o;
			       int count = mp.getCount();
			       //foStream.write(mmsg.getBytes());
			       for (int i = 0; i < count; i++) {
			    	   BodyPart bp=mp.getBodyPart(i);
			    	   if(i>0){
			    		   String disp=bp.getDisposition();
			    		   if(disp!=null && disp.equalsIgnoreCase(bp.ATTACHMENT)){
			    			   //foStream.write(new String("******Attachment follows*****"+bp.getFileName()+"******").getBytes());
			    			   //foStream.write(disp.getBytes());
			    			   System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^ saving the attachments");
			    			   //saveAttachment(bp.getFileName(),bp.getInputStream());
			    			   RequestAttachment attachment=getAttachment(bp.getFileName(), bp.getInputStream());
			    			   requestTemplate.setHasAttachment(true);
			    			   if(requestTemplate.getAttachments()==null){
			    				   List attachmentsList=new ArrayList();
			    				   attachmentsList.add(attachment);
			    				   requestTemplate.setAttachments(attachmentsList);
			    			   }
			    			   else{
			    				   List existingAttachmentsList=requestTemplate.getAttachments();
			    				   existingAttachmentsList.add(attachment);
			    				   requestTemplate.setAttachments(existingAttachmentsList);
			    			   }
			    			   
			    		   }
			    		   
			    	   }
			    	   String partNo="****partNo..."+i;
			    	   if(i<1){
			    	   //foStream.write(partNo.getBytes());
			           printParts(mp.getBodyPart(i),requestEmail,requestTemplate);
			    	   }
			       }
			   } else if (o instanceof InputStream) {
			        //System.out.println("This is just an input stream");
			        InputStream is = (InputStream)o;
			        int c;
			      /*  while ((c = is.read()) != -1){
			        	//System.out.write(c);
			        	foStream.write(c);
			        }*/
			       
			   }
			   else{
				   //System.out.println("inside 2.......b..........");
			   }
		   }
/**
 * 
 * getAttachment
 * Description:
 * this method stores the returns the attached files in the form of bytes
 * EmailRequestAdder
 * @param filename
 * @param iStream
 * @return
 * @throws IOException
 * @return RequestAttachment
 * @author:Ramesh Raj Baral
 * @since:Jul 16, 2010
 *
 */
	
	public  RequestAttachment getAttachment(String filename,InputStream iStream) throws IOException{
		RequestAttachment attachment;
		byte[] attachmentContents;
		//String tempFolder=new File(new File(".").getCanonicalPath()).toString()+System.getProperty("file.separator")+this.tempFileLocation+System.getProperty("file.separator");
		//String fileName=folderName+System.getProperty("file.separator")+filename;
		File file= new File(filename);
	    /*
	      * Create byte array large enough to hold the content of the file.
	      * Use File.length to determine size of the file in bytes.
	      */
		attachmentContents = new byte[(int)iStream.available()];
		iStream.read(attachmentContents);
		attachment=new RequestAttachment();
		attachment.setFileContent(attachmentContents);
		attachment.setFileName(filename);
	    System.out.println("****************************attachments converted to byets array: for file:"+filename+"..total bytes read:"+attachmentContents.length+"..available:"+iStream.available());
	    if(file.exists())
	    System.out.println("Attachments downloaded as:"+filename);
	    else
	    System.out.println("attachment couldnot be downloaded");
	    return attachment;
	 }
	
	
	/**
	 * 
	 * saveAttachment
	 * EmailRequestAdder
	 * @param filename
	 * @param iStream
	 * @throws IOException
	 * @return void
	 * @author:Ramesh Raj Baral
	 * @since:Jul 16, 2010
	 *
	 */
	public static void saveAttachment(String filename,InputStream iStream) throws IOException{
		String folderName="/home/D2HS/rbaral/Desktop/mailattachment";
		String fileName=folderName+System.getProperty("file.separator")+filename;
		File file= new File(fileName);
		    FileOutputStream fos = new FileOutputStream(file);
		    BufferedOutputStream bos = new BufferedOutputStream(fos);
		    BufferedInputStream bis = new BufferedInputStream(iStream);
		    int aByte;
		    while ((aByte = bis.read()) != -1) {
		      bos.write(aByte);
		    }
		    bos.flush();
		    bos.close();
		    bis.close();
		    if(file.exists())
		    System.out.println("Attachments downloaded as:"+fileName);
		    else
		    System.out.println("attachment couldnot be downloaded");
		  }
	
	/**
	 * 
	 * Description:
	 * enterNewRequestFromEmail
	 * <li>simple replica of enterNewRequest,but this inserts the new request on receiving new emails</li> 
	 * @param jobID
	 * @return
	 * boolean
	 * Author:Ramesh Raj Baral
	 * @since Jun 4, 2010
	 */
	public boolean enterNewRequestFromEmail(List requestTemplateList)
	{
		return true;
	}
	
	
	/**
	 * 
	 * Description:
	 * initializeTemplates
	 * <li>initializes the templates property from the one retrieved from db if their entry is found in db</li>
	 * @param templatesList
	 * @return
	 * List
	 * Author:Ramesh Raj Baral
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @since Jun 7, 2010
	 */
	public List initializeTemplates(List requestTemplateList) throws ClassNotFoundException, SQLException{
		RequestTemplate requestTemplate;
		List validTemplatesList=new ArrayList();
		ResultSet rs;
		try{
			if(myConn==null)
			this.connectDB();
		//retrieve only the required template info
		String sql_templates="select *from oam_rm_templates";
		rs=(myConn.createStatement()).executeQuery(sql_templates);
		while(rs.next()){
			String templateName=rs.getString("templatename");
			for(int i=0;i<requestTemplateList.size();i++){
				requestTemplate=(RequestTemplate)requestTemplateList.get(i);
				if(templateName.equalsIgnoreCase(requestTemplate.getTemplateName())){
				requestTemplate.setArea(rs.getString("area"));
				requestTemplate.setAssingedTo(rs.getString("assignedto"));
				requestTemplate.setClient(rs.getString("client"));
				requestTemplate.setEstimatedHours(rs.getString("estimatedhours")==null?"":rs.getString("estimatedhours"));
				requestTemplate.setModule(rs.getString("modules")==null?"":rs.getString("modules"));
				requestTemplate.setPriority(rs.getString("priority")==null?"":rs.getString("priority"));
				requestTemplate.setProduct(rs.getString("product")==null?"":rs.getString("product"));
				requestTemplate.setProject(rs.getString("project")==null?"":rs.getString("project"));
				requestTemplate.setRequestSource(rs.getString("requestsource")==null?"":rs.getString("requestsource"));
				requestTemplate.setTargetDate(rs.getString("targetdate")==null?"":rs.getString("targetdate"));
				requestTemplate.setTemplateID(rs.getString("templateid"));
				requestTemplate.setTrustedUserFilter(rs.getString("trusteduserfilter").equalsIgnoreCase("Y")?true:false);
				requestTemplate.setVersionDetected(rs.getString("versiondetected")==null?"0":rs.getString("versiondetected"));
				requestTemplate.setPhaseDetected(rs.getString("phasedetected")==null?"0":rs.getString("phasedetected"));
				requestTemplate.setPhaseInjected(rs.getString("phaseinjected")==null?"0":rs.getString("phaseinjected"));
				requestTemplate.setVersionDetected(rs.getString("versiondetected")==null?"":rs.getString("versiondetected"));
				requestTemplate.setSeverityID(rs.getString("severity")==null?"0":rs.getString("severity"));
				requestTemplate.setStatusID("8");//Assigned");
				requestTemplate.setCompleted(false);
				String ackUsers=(rs.getString("acknowledgeusers")==null)?"":rs.getString("acknowledgeusers");
				List ackUsersList;
				if(ackUsers.split(",")!=null){
					String[] akUsers=ackUsers.split(",");
					User user;
					ackUsersList=new ArrayList();
					for(int j=0;j<akUsers.length;j++){
						user=getUserDetails(akUsers[j]);
						if(user.getUserEmail()!=null)
						user.getUserEmail().replaceAll("d2hawkeye","veriskhealth" );
						ackUsersList.add(user);
					}
				}
				else{
					ackUsersList=new ArrayList();
					User user=new User();
					if(ackUsers.length()>0){
						user=getUserDetails(ackUsers);
						if(user.getUserEmail()!=null)
						user.getUserEmail().replaceAll("d2hawkeye","veriskhealth" );
						
					}
					ackUsersList.add(user);
				}
				requestTemplate.setAcknowledgeUsers(ackUsersList);
				validTemplatesList.add(requestTemplate);
				}
			}
		}
		}catch(Exception ex){
			System.out.println("Exception initializing templates:"+ex.getMessage());
		}
    	finally{
      		  try{
      			  this.disconnectDB();
      		  }catch(Exception ex){
      			  System.out.println("exception in disconnectDB from readEmail:"+ex.getMessage());
      		  }
      	  }
		System.out.println(validTemplatesList.size()+" templates were initialized");
		return validTemplatesList;
	}
	
	/**
	 * 
	 * Description:
	 * <code>sendRequestAddedMails</code>
	 * <li>triggers the mail for the requests which are successfully inserted</li>
	 * @param requestTemplateMap
	 * void
	 * Author:Ramesh Raj Baral
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @since Jun 8, 2010
	 */
	public void sendRequestAddedMails(Map requestTemplateMap) throws ClassNotFoundException, SQLException{
		
	}
	/**
	 * 
	 * Description:
	 * getUserDetails
	 * <li>return the user details from the usersMap object initialized at app start up</li>
	 * @param userID
	 * @return
	 * User
	 * Author:Ramesh Raj Baral
	 * @since Jun 8, 2010
	 */
	public User getUserDetails(String userID){
		User user=new User();
		user.setUserID(userID);
		Iterator iter=usersMap.keySet().iterator();
		while(iter.hasNext()){
			String key=iter.next().toString();//userEmail is the key
			user=(User)usersMap.get(key);
			if(userID.equals(user.getUserID()))
				break;
		}
		return user;
		
	}

	/**
	 * 
	 * getTrimmedElements
	 * EmailRequestAdder
	 * Description:this method takes input string and then eliminates unwanted white space in it
	 * @return
	 * @return String
	 * @author:Ramesh Raj Baral
	 * @since:Jul 2, 2010
	 *
	 */
	public String getTrimmedElements(String param){
		String trimmedString="";
		String tokenArr[]=param.split(" ");
		for(int i=0;i<tokenArr.length;i++){
			if(tokenArr[i].trim().length()>0){
				trimmedString=trimmedString.concat(tokenArr[i]+" ");
			}
		}
		System.out.println("Trimmed msg subject:"+trimmedString);
		return trimmedString;
	}
	
	/**
	 * Description:If the mail sent by user was invalid due to any reason then send the failure email
	 * sendFailureEmail
	 * EmailRequestAdder
	 * @param requestEmail
	 * @param failureString
	 * @throws MessagingException
	 * @throws UnsupportedEncodingException
	 * @return void
	 * @author:Ramesh Raj Baral
	 * @since:Aug 11, 2010
	 *
	 */
	public void sendFailureEmail(RequestEmail requestEmail,String failureString) throws MessagingException, UnsupportedEncodingException{
		
		
	}
	
	public void readGmail() throws MessagingException, IOException{
	     String host = "pop.gmail.com";
	      String user = "rameshrajbaral@gmail.com";
	      String password = "";
	      // Get system properties
	     Properties properties = System.getProperties();

	      // Get the default Session object.
	      Session session = Session.getDefaultInstance(properties, null);

	      // Get a Store object that implements the specified protocol.
	      Store store = session.getStore("pop3s");

	      //Connect to the current host using the specified username and password.
	      store.connect(host, user, password);

	      //Create a Folder object corresponding to the given name.
	      Folder folder = store.getFolder("inbox");

	      // Open the Folder.
	      folder.open(Folder.READ_ONLY);
	      System.out.println("new emails:"+folder.getNewMessageCount());;
	      Message[] message = folder.getMessages();

	      // Display message.
	      for (int i = message.length-1; i >0; i--) {
	    	  try{
	          System.out.println("------------ Message " + (i + 1) + " ------------");
	          System.out.println("SentDate : " + message[i].getSentDate());
	          System.out.println("From : " + message[i].getFrom()[0]);
	          System.out.println("Subject : " + message[i].getSubject());
	          //System.out.print("Message : ");

	          InputStream stream = message[i].getInputStream();
	         /* while (stream.available() != 0) {
	              //System.out.print((char) stream.read());
	          }*/
	    	  }catch(MessageRemovedException mex){
	    	    	 System.out.println("message removed exception ");
	    	     }
	      }
	     
	      folder.close(true);
	      store.close();

		}
	
	public void sendEmail() throws MessagingException, UnsupportedEncodingException{
		Properties props = new Properties();
        props.put("mail.smtp.host", "dhobikhola");
        props.put("mail.transport.protocol", "smtp");
        InternetAddress[] bccFilteredList = new InternetAddress[1];
        bccFilteredList[0]=new InternetAddress("rbaral@veriskhealth.com".toString(),"ramesh");
        InternetAddress[] toFilteredList = new InternetAddress[1];
        toFilteredList[0]=new InternetAddress("rbaral@veriskhealth.com".toString(),"Mr Baral");
        Session session = Session.getDefaultInstance(props, null);
        session.setDebug(true);
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress("rbaral@veriskhealth.com","Ramesh"));
        msg.setRecipients(Message.RecipientType.TO, toFilteredList);
        msg.setRecipients(Message.RecipientType.BCC,bccFilteredList);
        msg.setSubject("test!");
        msg.setHeader("Content-Type", "text/html");
        String body="test body.";
        msg.setText(body);
        Transport.send(msg);
        System.out.println("mail sent");
	}
	
	
	}

