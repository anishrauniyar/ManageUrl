package d2Systems.rm;

import java.util.List;

import d2Systems.rm.User;

/**
 * 
 * FileName:UserRequest.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jun 21, 2010
 *
 */
public class UserRequest extends RequestTemplate {
	private boolean inWatchList;
	private String requestDate;
	private int documentCount;
	private String actionTaken;
	private String projectName;
	private String productName;
	private User assignedToUser;
	private String requestTypeName;
	private String clientName;
	private String pkSource;
	private String reqCompCode;
	private String severityName;
	private String moreDesc;
	private String tinyDesc;
	private boolean access=true;
	private boolean exists=true;
	private boolean hasFollowUps=false;
	private List followUpList;
	
	
	public UserRequest(){
		
	}
	public boolean isInWatchList() {
		return inWatchList;
	}
	public void setInWatchList(boolean inWatchList) {
		this.inWatchList = inWatchList;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public int getDocumentCount() {
		return documentCount;
	}
	public void setDocumentCount(int documentCount) {
		this.documentCount = documentCount;
	}
	public String getActionTaken() {
		return actionTaken;
	}
	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public User getAssignedToUser() {
		return assignedToUser;
	}
	public void setAssignedToUser(User assignedToUser) {
		this.assignedToUser = assignedToUser;
	}
	public String getRequestTypeName() {
		return requestTypeName;
	}
	public void setRequestTypeName(String requestTypeName) {
		this.requestTypeName = requestTypeName;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getPkSource() {
		return pkSource;
	}
	public void setPkSource(String pkSource) {
		this.pkSource = pkSource;
	}
	public String getReqCompCode() {
		return reqCompCode;
	}
	public void setReqCompCode(String reqCompCode) {
		this.reqCompCode = reqCompCode;
	}
	public String getSeverityName() {
		return severityName;
	}
	public void setSeverityName(String severityName) {
		this.severityName = severityName;
	}
	public String getMoreDesc() {
		/**
		 * if the request description is more than 500 chars
		 * then split it into first-part -first 500 char and second part
		 * the remaining one
		 */
		String moreDesc="";
		if(this.getDescription().length()>500)
			moreDesc=this.getDescription().substring(500,this.getDescription().length()-1);
		this.setMoreDesc(moreDesc);	
		return moreDesc;
	}
	public void setMoreDesc(String moreDesc) {
		this.moreDesc = moreDesc;
	}
	public String getTinyDesc() {
		if(this.getDescription().length()>500)
			this.tinyDesc=this.getDescription().substring(0,500);
		else
			this.tinyDesc=this.getDescription();
		return tinyDesc;
	}
	public void setTinyDesc(String tinyDesc) {
		this.tinyDesc = tinyDesc;
	}
	public boolean isAccess() {
		return access;
	}
	public void setAccess(boolean access) {
		this.access = access;
	}
	public boolean isExists() {
		return exists;
	}
	public void setExists(boolean exists) {
		this.exists = exists;
	}
	public List getFollowUpList() {
		return followUpList;
	}
	public void setFollowUpList(List followUpList) {
		this.followUpList = followUpList;
	}
	public boolean isHasFollowUps() {
		return hasFollowUps;
	}
	public void setHasFollowUps(boolean hasFollowUps) {
		this.hasFollowUps = hasFollowUps;
	}
	

}
