package d2Systems.rm;

public class User {
  private String user;
  
  /**
   * fields added to accomodate the users attributes 
   * @author Ramesh Raj Baral
   * @since Jun 3 2010
   */
  private String userName;
  private String userID;
  private String userEmail;
  private String loginName;
  
  public User(){
	  
  }
  
  public User(String u) {
    this.user = u;
  }

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getUserID() {
	return userID;
}

public void setUserID(String userID) {
	this.userID = userID;
}

public String getUserEmail() {
	return userEmail;
}

public void setUserEmail(String userEmail) {
	this.userEmail = userEmail;
}

public String getLoginName() {
	return loginName;
}

public void setLoginName(String loginName) {
	this.loginName = loginName;
}

}