/**
 * @author Vivek Adhikari
 * @since April 11,2013
 * To implement Send To RM feature from MI - PM
 * DTO having most property which required to Send PM Comment To RM
 */
package d2Systems.rm;

import java.util.List;

public class RequestDetailsDTO {

	private boolean isSendToDH;
	
	private String clientID;
	
	private String productID;
	
	private String projectID;
	private String projectName;
	
	private String userID;
	private String userName;
	private List allUsers;
	
	private String requestTypeID;
	private String requestTypeName;
	
	private List allRequestTypeList;
	
	private String  requestPrirotyID;
	private String requestPrirotyName;
	
	private List allRequestPrirotyList;
	
	private String projectAreaID;
	private String projectAreaName;
	
	private List allProjectAreaList;
	
	private String versionDetectedID;
	private String versionDetectedName;
	
	private List allVersionDetectedList;
	
	private String moduleID;
	private String moduleName;
	
	private List allModuleList;
	
	private String assignedToUserID;
	private String assignedTouserName;
	
	private String assignedTOLoginName;
	
	
	private String severityID;
	private String severityName;
	
	private List allSeverityList;
	
	
	private String requestTitle;
	
	private String pmMessageID;
	
	private String[] ccUsers;
	
	private String requestPhase;

	/**
	 * @return the ccUsers
	 */
	public String[] getCcUsers() {
		return ccUsers;
	}

	/**
	 * @param ccUsers the ccUsers to set
	 */
	public void setCcUsers(String[] ccUsers) {
		this.ccUsers = ccUsers;
	}

	/**
	 * @return the projectID
	 */
	public String getProjectID() {
		return projectID;
	}

	/**
	 * @param projectID the projectID to set
	 */
	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the allUsers
	 */
	public List getAllUsers() {
		return allUsers;
	}

	/**
	 * @param allUsers the allUsers to set
	 */
	public void setAllUsers(List allUsers) {
		this.allUsers = allUsers;
	}

	/**
	 * @return the requestTypeID
	 */
	public String getRequestTypeID() {
		return requestTypeID;
	}

	/**
	 * @param requestTypeID the requestTypeID to set
	 */
	public void setRequestTypeID(String requestTypeID) {
		this.requestTypeID = requestTypeID;
	}

	/**
	 * @return the requestTypeName
	 */
	public String getRequestTypeName() {
		return requestTypeName;
	}

	/**
	 * @param requestTypeName the requestTypeName to set
	 */
	public void setRequestTypeName(String requestTypeName) {
		this.requestTypeName = requestTypeName;
	}

	/**
	 * @return the allRequestTypeList
	 */
	public List getAllRequestTypeList() {
		return allRequestTypeList;
	}

	/**
	 * @param allRequestTypeList the allRequestTypeList to set
	 */
	public void setAllRequestTypeList(List allRequestTypeList) {
		this.allRequestTypeList = allRequestTypeList;
	}


	/**
	 * @return the requestPrirotyID
	 */
	public String getRequestPrirotyID() {
		return requestPrirotyID;
	}

	/**
	 * @param requestPrirotyID the requestPrirotyID to set
	 */
	public void setRequestPrirotyID(String requestPrirotyID) {
		this.requestPrirotyID = requestPrirotyID;
	}

	/**
	 * @return the requestPrirotyName
	 */
	public String getRequestPrirotyName() {
		return requestPrirotyName;
	}

	/**
	 * @param requestPrirotyName the requestPrirotyName to set
	 */
	public void setRequestPrirotyName(String requestPrirotyName) {
		this.requestPrirotyName = requestPrirotyName;
	}

	/**
	 * @return the allRequestPrirotyList
	 */
	public List getAllRequestPrirotyList() {
		return allRequestPrirotyList;
	}

	/**
	 * @param allRequestPrirotyList the allRequestPrirotyList to set
	 */
	public void setAllRequestPrirotyList(List allRequestPrirotyList) {
		this.allRequestPrirotyList = allRequestPrirotyList;
	}

	/**
	 * @return the projectAreaID
	 */
	public String getProjectAreaID() {
		return projectAreaID;
	}

	/**
	 * @param projectAreaID the projectAreaID to set
	 */
	public void setProjectAreaID(String projectAreaID) {
		this.projectAreaID = projectAreaID;
	}

	/**
	 * @return the projectAreaName
	 */
	public String getProjectAreaName() {
		return projectAreaName;
	}

	/**
	 * @param projectAreaName the projectAreaName to set
	 */
	public void setProjectAreaName(String projectAreaName) {
		this.projectAreaName = projectAreaName;
	}

	/**
	 * @return the allProjectAreaList
	 */
	public List getAllProjectAreaList() {
		return allProjectAreaList;
	}

	/**
	 * @param allProjectAreaList the allProjectAreaList to set
	 */
	public void setAllProjectAreaList(List allProjectAreaList) {
		this.allProjectAreaList = allProjectAreaList;
	}

	/**
	 * @return the versionDetectedID
	 */
	public String getVersionDetectedID() {
		return versionDetectedID;
	}

	/**
	 * @param versionDetectedID the versionDetectedID to set
	 */
	public void setVersionDetectedID(String versionDetectedID) {
		this.versionDetectedID = versionDetectedID;
	}

	/**
	

	/**
	 * @return the moduleID
	 */
	public String getModuleID() {
		return moduleID;
	}

	
	/**
	 * @return the versionDetectedName
	 */
	public String getVersionDetectedName() {
		return versionDetectedName;
	}

	/**
	 * @param versionDetectedName the versionDetectedName to set
	 */
	public void setVersionDetectedName(String versionDetectedName) {
		this.versionDetectedName = versionDetectedName;
	}

	/**
	 * @return the allVersionDetectedList
	 */
	public List getAllVersionDetectedList() {
		return allVersionDetectedList;
	}

	/**
	 * @param allVersionDetectedList the allVersionDetectedList to set
	 */
	public void setAllVersionDetectedList(List allVersionDetectedList) {
		this.allVersionDetectedList = allVersionDetectedList;
	}

	/**
	 * @param moduleID the moduleID to set
	 */
	public void setModuleID(String moduleID) {
		this.moduleID = moduleID;
	}

	

	/**
	 * @return the moduleName
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * @param moduleName the moduleName to set
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/**
	 * @return the allModuleList
	 */
	public List getAllModuleList() {
		return allModuleList;
	}

	/**
	 * @param allModuleList the allModuleList to set
	 */
	public void setAllModuleList(List allModuleList) {
		this.allModuleList = allModuleList;
	}

	/**
	 * @return the assignedToUserID
	 */
	public String getAssignedToUserID() {
		return assignedToUserID;
	}

	/**
	 * @param assignedToUserID the assignedToUserID to set
	 */
	public void setAssignedToUserID(String assignedToUserID) {
		this.assignedToUserID = assignedToUserID;
	}

	/**
	 * @return the assignedTouserName
	 */
	public String getAssignedTouserName() {
		return assignedTouserName;
	}

	/**
	 * @param assignedTouserName the assignedTouserName to set
	 */
	public void setAssignedTouserName(String assignedTouserName) {
		this.assignedTouserName = assignedTouserName;
	}

	/**
	 * @return the assignedTOLoginName
	 */
	public String getAssignedTOLoginName() {
		return assignedTOLoginName;
	}

	/**
	 * @param assignedTOLoginName the assignedTOLoginName to set
	 */
	public void setAssignedTOLoginName(String assignedTOLoginName) {
		this.assignedTOLoginName = assignedTOLoginName;
	}

	/**
	 * @return the severityID
	 */
	public String getSeverityID() {
		return severityID;
	}

	/**
	 * @param severityID the severityID to set
	 */
	public void setSeverityID(String severityID) {
		this.severityID = severityID;
	}

	/**
	 * @return the severityName
	 */
	public String getSeverityName() {
		return severityName;
	}

	/**
	 * @param severityName the severityName to set
	 */
	public void setSeverityName(String severityName) {
		this.severityName = severityName;
	}

	/**
	 * @return the allSeverityList
	 */
	public List getAllSeverityList() {
		return allSeverityList;
	}

	/**
	 * @param allSeverityList the allSeverityList to set
	 */
	public void setAllSeverityList(List allSeverityList) {
		this.allSeverityList = allSeverityList;
	}

	/**
	 * @return the requestTitle
	 */
	public String getRequestTitle() {
		return requestTitle;
	}

	/**
	 * @param requestTitle the requestTitle to set
	 */
	public void setRequestTitle(String requestTitle) {
		this.requestTitle = requestTitle;
	}

	/**
	 * @return the isSendToDH
	 */
	public boolean isSendToDH() {
		return isSendToDH;
	}

	/**
	 * @param isSendToDH the isSendToDH to set
	 */
	public void setSendToDH(boolean isSendToDH) {
		this.isSendToDH = isSendToDH;
	}

	/**
	 * @return the pmMessageID
	 */
	public String getPmMessageID() {
		return pmMessageID;
	}

	/**
	 * @param pmMessageID the pmMessageID to set
	 */
	public void setPmMessageID(String pmMessageID) {
		this.pmMessageID = pmMessageID;
	}

	/**
	 * @return the productID
	 */
	public String getProductID() {
		return productID;
	}

	/**
	 * @param productID the productID to set
	 */
	public void setProductID(String productID) {
		this.productID = productID;
	}

	/**
	 * @return the requestPhase
	 */
	public String getRequestPhase() {
		return requestPhase;
	}

	/**
	 * @param requestPhase the requestPhase to set
	 */
	public void setRequestPhase(String requestPhase) {
		this.requestPhase = requestPhase;
	}

	/**
	 * @return the clientID
	 */
	public String getClientID() {
		return clientID;
	}

	/**
	 * @param clientID the clientID to set
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	
	
	
	
	
	
	
	
	
	
	
}
