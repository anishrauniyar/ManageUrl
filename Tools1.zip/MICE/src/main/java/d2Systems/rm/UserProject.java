package d2Systems.rm;

/**
 * 
 * FileName:UserProject.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jul 2, 2010
 *
 */
public class UserProject {

	private String projectID;
	private String projectName;
	private String productID;
	private String productName;
	private boolean preferred;
	
	public UserProject(){
		
	}
	
	public UserProject(String projectID,String projectName){
		this.projectID=projectID;
		this.projectName=projectName;
	}
	public String getProjectID() {
		return projectID;
	}
	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

	public boolean isPreferred() {
		return preferred;
	}

	public void setPreferred(boolean preferred) {
		this.preferred = preferred;
	}
	
}
