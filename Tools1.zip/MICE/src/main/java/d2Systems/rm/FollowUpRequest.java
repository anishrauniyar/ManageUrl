package d2Systems.rm;

/**
 * 
 * FileName:FollowUpRequest.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Aug 18, 2010
 *
 */
public class FollowUpRequest extends UserRequest {

	private String parentRequestCode;

	public String getParentRequestCode() {
		return parentRequestCode;
	}

	public void setParentRequestCode(String parentRequestCode) {
		this.parentRequestCode = parentRequestCode;
	}
	
}
