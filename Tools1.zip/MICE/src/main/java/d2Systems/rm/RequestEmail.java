package d2Systems.rm;

import java.io.File;

import d2Systems.rm.User;

/**
 * <li>this class is the holder of the mail that was sent to add the request</li>
 * FileName:RequestEmail.java
 * Version:1.0
 * @author:Ramesh Raj Baral
 * @since:Jun 4, 2010
 *
 */
public class RequestEmail {

	private User fromUser;
	private String msgSubject;
	private String msgBody;
	private File[] attachments;
	private boolean hasAttachments;
	private String messageID;
	private boolean validForTicket=false;
	
	public RequestEmail(){
		
	}
	
	public RequestEmail(User user){
		this.fromUser=user;
	}
	
	public User getFromUser() {
		return fromUser;
	}
	public void setFromUser(User fromUser) {
		this.fromUser = fromUser;
	}
	public String getMsgSubject() {
		return msgSubject;
	}
	public void setMsgSubject(String msgSubject) {
		this.msgSubject = msgSubject;
	}
	public String getMsgBody() {
		return msgBody;
	}
	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}
	public File[] getAttachments() {
		return attachments;
	}
	public void setAttachments(File[] attachments) {
		this.attachments = attachments;
	}
	public boolean isHasAttachments() {
		return hasAttachments;
	}
	public void setHasAttachments(boolean hasAttachments) {
		this.hasAttachments = hasAttachments;
	}

	public String getMessageID() {
		return messageID;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}

	public boolean isValidForTicket() {
		return validForTicket;
	}

	public void setValidForTicket(boolean validForTicket) {
		this.validForTicket = validForTicket;
	}
}
