package com.vit.springController;

import com.vit.domain.Entry;
import com.vit.domain.Worklog;
import com.vit.utility.JsonUtils;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
//import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class JiraPayrollController
{
  //Logger log = Logger.getLogger(getClass());
	
	String test="{\"worklog\":[{\"key\":\"VITDATA-48628\",\"summary\":\"905-001 Premier MSSP St. Vincent ACO Implementation - Data Analysis\",\"entries\":[{\"id\":283528,\"comment\":\"Data analysis regarding Quarterly assignment and eligibility file.\",\"timeSpent\":3600,\"author\":\"i80953\",\"authorFullName\":\"Bajracharya, Ujen\",\"created\":1456138076313,\"startDate\":1456138020000,\"updateAuthor\":\"i80953\",\"updateAuthorFullName\":\"Bajracharya, Ujen\",\"updated\":1456138076313}],\"fields\":[{\"label\":\"07.Data Analysis\",\"value\":\"components\"},{\"label\":\"    Premier - Medicare - St Vincent\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Medicare - St Vincent\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-49765\",\"summary\":\"731-002 Premier Ellis Commercial Regular Processing - Data Analysis\",\"entries\":[{\"id\":283682,\"comment\":\"\",\"timeSpent\":7200,\"author\":\"i81221\",\"authorFullName\":\"Amatya, Bipika\",\"created\":1456158742051,\"startDate\":1456158720000,\"updateAuthor\":\"i81221\",\"updateAuthorFullName\":\"Amatya, Bipika\",\"updated\":1456158742051}],\"fields\":[{\"label\":\"07.Data Analysis\",\"value\":\"components\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Commercial - Ellis\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-49766\",\"summary\":\"731-002 Premier Ellis Commercial Regular Processing - Data Scrubbing\",\"entries\":[{\"id\":283680,\"comment\":\"\",\"timeSpent\":7200,\"author\":\"i81221\",\"authorFullName\":\"Amatya, Bipika\",\"created\":1456158695559,\"startDate\":1456158660000,\"updateAuthor\":\"i81221\",\"updateAuthorFullName\":\"Amatya, Bipika\",\"updated\":1456158695559}],\"fields\":[{\"label\":\"16.Data Scrubbing\",\"value\":\"components\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Commercial - Ellis\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-50247\",\"summary\":\"643-001 : Bulk Data Feed - CIGNA : Data Import and Review\",\"entries\":[{\"id\":283914,\"comment\":\"Import completed issue to transfer the data have been posted. Waiting for WPM reply\",\"timeSpent\":7200,\"author\":\"i80986\",\"authorFullName\":\"Pokhrel, Biplab\",\"created\":1456210105418,\"startDate\":1456123620000,\"updateAuthor\":\"i80986\",\"updateAuthorFullName\":\"Pokhrel, Biplab\",\"updated\":1456210105418}],\"fields\":[{\"label\":\"06.Import Data and Review\",\"value\":\"components\"},{\"label\":\"    Bulk Data Feed - Cigna\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Bulk Data Feed - Cigna\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-51724\",\"summary\":\"Weekly TL/CL Team Meeting\",\"entries\":[{\"id\":283638,\"comment\":\"Cl/Tl meeting\",\"timeSpent\":4320,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148377360,\"startDate\":1456148340000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148377360}],\"fields\":[{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"components\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12031\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12430\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15726\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15727\"},{\"label\":\"Ops General\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53012\",\"summary\":\"731-001 Premier Memorial Commercial Regular Processing - Data Analysis\",\"entries\":[{\"id\":283587,\"comment\":\"Memorial Commercial Data Analysis.\",\"timeSpent\":18000,\"author\":\"i81231\",\"authorFullName\":\"Sapkota, Shashwat\",\"created\":1456143078483,\"startDate\":1456143000000,\"updateAuthor\":\"i81231\",\"updateAuthorFullName\":\"Sapkota, Shashwat\",\"updated\":1456143078483}],\"fields\":[{\"label\":\"07.Data Analysis\",\"value\":\"components\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53013\",\"summary\":\"731-001 Premier Memorial Commercial Regular Processing - Data Scrubbing\",\"entries\":[{\"id\":283590,\"comment\":\"Memorial Commercial Data Scrubbing.\",\"timeSpent\":10800,\"author\":\"i81231\",\"authorFullName\":\"Sapkota, Shashwat\",\"created\":1456143099487,\"startDate\":1456143060000,\"updateAuthor\":\"i81231\",\"updateAuthorFullName\":\"Sapkota, Shashwat\",\"updated\":1456143099487}],\"fields\":[{\"label\":\"16.Data Scrubbing\",\"value\":\"components\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53014\",\"summary\":\"731-001 Premier Memorial Commercial Regular Processing - Scrub QC\",\"entries\":[{\"id\":283661,\"comment\":\"Import Vs Scrub data and change request verification.\",\"timeSpent\":16200,\"author\":\"i80953\",\"authorFullName\":\"Bajracharya, Ujen\",\"created\":1456155004518,\"startDate\":1456154940000,\"updateAuthor\":\"i80953\",\"updateAuthorFullName\":\"Bajracharya, Ujen\",\"updated\":1456155004518}],\"fields\":[{\"label\":\"20.Scrub QC\",\"value\":\"components\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Commercial - Memorial\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53294\",\"summary\":\"Data Analysis (Pre and Post Scrub)\",\"entries\":[{\"id\":283639,\"comment\":\"Data scrubbing and analysis\",\"timeSpent\":5400,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148452843,\"startDate\":1456148400000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148452843}],\"fields\":[{\"label\":\"07.Data Analysis\",\"value\":\"components\"},{\"label\":\"    BCBS IL - HMO\n\",\"value\":\"customfield_12031\"},{\"label\":\"    BCBS IL - HMO\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53296\",\"summary\":\"Scrub Data QC\",\"entries\":[{\"id\":284472,\"comment\":\"scrub qc being continued....dup issue in rx posted in jira.\",\"timeSpent\":14400,\"author\":\"i80863\",\"authorFullName\":\"Kapali, Sweta\",\"created\":1456283391262,\"startDate\":1456196940000,\"updateAuthor\":\"i80863\",\"updateAuthorFullName\":\"Kapali, Sweta\",\"updated\":1456283391262}],\"fields\":[{\"label\":\"20.Scrub QC\",\"value\":\"components\"},{\"label\":\"    BCBS IL - HMO\n\",\"value\":\"customfield_12031\"},{\"label\":\"    BCBS IL - HMO\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53308\",\"summary\":\"819-001 Crawford Advisors - ICE#165873- CAP BCBS Claims integration - Feb Processing\",\"entries\":[{\"id\":283616,\"comment\":\"Started working of scrub script.\r\nLOA portion need to be updated once Elig is completed.\",\"timeSpent\":14400,\"author\":\"i81134\",\"authorFullName\":\"Chakradhar, Sagar\",\"created\":1456144428364,\"startDate\":1456141260000,\"updateAuthor\":\"i81134\",\"updateAuthorFullName\":\"Chakradhar, Sagar\",\"updated\":1456144428364}],\"fields\":[{\"label\":\"01.ALL\",\"value\":\"components\"},{\"label\":\"    Crawford Advisors - MI\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Crawford Advisors - MI\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53314\",\"summary\":\"819-001 Crawford Advisors - ICE#165874- CAP BCBS RxClaims integration - Feb Processing\",\"entries\":[{\"id\":283555,\"comment\":\"Started working of scrub script.\r\nLOA portion need to be updated once Elig is completed.\",\"timeSpent\":14400,\"author\":\"i81134\",\"authorFullName\":\"Chakradhar, Sagar\",\"created\":1456141301831,\"startDate\":1456141200000,\"updateAuthor\":\"i81134\",\"updateAuthorFullName\":\"Chakradhar, Sagar\",\"updated\":1456141301831}],\"fields\":[{\"label\":\"01.ALL\",\"value\":\"components\"},{\"label\":\"    Crawford Advisors - MI\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Crawford Advisors - MI\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53601\",\"summary\":\"764-003 proview quarterly DFW Airport med RX and Enrollment variance (ICE 171096)\",\"entries\":[{\"id\":283605,\"comment\":\"\",\"timeSpent\":14400,\"author\":\"i81143\",\"authorFullName\":\"Shrestha, Manoj\",\"created\":1456143410083,\"startDate\":1456143360000,\"updateAuthor\":\"i81143\",\"updateAuthorFullName\":\"Shrestha, Manoj\",\"updated\":1456143410083}],\"fields\":[{\"label\":\"10.Scrub Script Preparation/Modification\",\"value\":\"components\"},{\"label\":\"    ProView Advanced Administrator, LLC\n\",\"value\":\"customfield_12031\"},{\"label\":\"    ProView Advanced Administrator, LLC - Quarterly\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Change Request\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53686\",\"summary\":\"Data Analysis (Pre and Post Scrub)\",\"entries\":[{\"id\":283641,\"comment\":\"New group analysis\",\"timeSpent\":5400,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148567576,\"startDate\":1456148520000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148567576}],\"fields\":[{\"label\":\"07.Data Analysis\",\"value\":\"components\"},{\"label\":\"    Meritain- CBSA\n\",\"value\":\"customfield_12031\"},{\"label\":\"    CBSA /Guided2Health\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53687\",\"summary\":\"Data Scrubbing\",\"entries\":[{\"id\":283640,\"comment\":\"Rescrub due to scrub error\",\"timeSpent\":3600,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148510958,\"startDate\":1456148460000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148510958}],\"fields\":[{\"label\":\"16.Data Scrubbing\",\"value\":\"components\"},{\"label\":\"    Meritain- CBSA\n\",\"value\":\"customfield_12031\"},{\"label\":\"    CBSA /Guided2Health\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53710\",\"summary\":\"872-001 Premier Medicare Wellspan: Service date/ Paid date logic update (ICE#164074).: Code development.\",\"entries\":[{\"id\":283423,\"comment\":\"Impact analysis report generation and review reports.\",\"timeSpent\":5400,\"author\":\"i80953\",\"authorFullName\":\"Bajracharya, Ujen\",\"created\":1456118579510,\"startDate\":1456118520000,\"updateAuthor\":\"i80953\",\"updateAuthorFullName\":\"Bajracharya, Ujen\",\"updated\":1456118579510}],\"fields\":[{\"label\":\"10.Scrub Script Preparation/Modification\",\"value\":\"components\"},{\"label\":\"    Premier - Medicare – Wellspan\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Premier - Medicare – Wellspan\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53718\",\"summary\":\"Data Analysis (Pre and Post Scrub)\",\"entries\":[{\"id\":283642,\"comment\":\"Post scrub analysis\",\"timeSpent\":3600,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148609416,\"startDate\":1456148580000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148609416}],\"fields\":[{\"label\":\"07.Data Analysis\",\"value\":\"components\"},{\"label\":\"    Network Health Plan – Medicare\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Network Health Plan – Medicare\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53720\",\"summary\":\"Scrub Data QC\",\"entries\":[{\"id\":283681,\"comment\":\"\",\"timeSpent\":14400,\"author\":\"i81221\",\"authorFullName\":\"Amatya, Bipika\",\"created\":1456158715498,\"startDate\":1456158660000,\"updateAuthor\":\"i81221\",\"updateAuthorFullName\":\"Amatya, Bipika\",\"updated\":1456218860269}],\"fields\":[{\"label\":\"20.Scrub QC\",\"value\":\"components\"},{\"label\":\"    Network Health Plan – Medicare\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Network Health Plan – Medicare\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-53853\",\"summary\":\"Code Review\",\"entries\":[{\"id\":283643,\"comment\":\"New added group listed and post in ICE.\",\"timeSpent\":2700,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148720967,\"startDate\":1456148640000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148720967}],\"fields\":[{\"label\":\"13.Scrub Script Review\",\"value\":\"components\"},{\"label\":\"    Meritain- CBSA\n\",\"value\":\"customfield_12031\"},{\"label\":\"    CBSA /Guided2Health\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54122\",\"summary\":\"856-002 Trinity Medicare Advantage - Import Data and Review - Feb 2016\",\"entries\":[{\"id\":283915,\"comment\":\"Import, Transfer,DSR rules, DSR shared \",\"timeSpent\":10800,\"author\":\"i80986\",\"authorFullName\":\"Pokhrel, Biplab\",\"created\":1456210143889,\"startDate\":1456123680000,\"updateAuthor\":\"i80986\",\"updateAuthorFullName\":\"Pokhrel, Biplab\",\"updated\":1456210143889}],\"fields\":[{\"label\":\"01.ALL\",\"value\":\"components\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54293\",\"summary\":\"Premier - Daily huddle.\",\"entries\":[{\"id\":283389,\"comment\":\"Premier Daily huddle.\",\"timeSpent\":1800,\"author\":\"i80953\",\"authorFullName\":\"Bajracharya, Ujen\",\"created\":1456117695565,\"startDate\":1456117620000,\"updateAuthor\":\"i80953\",\"updateAuthorFullName\":\"Bajracharya, Ujen\",\"updated\":1456117695565}],\"fields\":[{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"components\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12031\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12430\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15726\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15727\"},{\"label\":\"Ops General\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54300\",\"summary\":\"826-001 Horan Associates - ICE#175110 - New Group Cincinnati - Feb processing\",\"entries\":[{\"id\":283591,\"comment\":\"data import\",\"timeSpent\":5400,\"author\":\"i80833\",\"authorFullName\":\"Bajracharya, Romi\",\"created\":1456143102117,\"startDate\":1456143060000,\"updateAuthor\":\"i80833\",\"updateAuthorFullName\":\"Bajracharya, Romi\",\"updated\":1456143102117}],\"fields\":[{\"label\":\"01.ALL\",\"value\":\"components\"},{\"label\":\"    Horan Associates\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Horan Associates\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54302\",\"summary\":\"824-003 Trinity Staging - Monthly processing - Feb ( Import and Review )\",\"entries\":[{\"id\":283917,\"comment\":\"\",\"timeSpent\":10800,\"author\":\"i80986\",\"authorFullName\":\"Pokhrel, Biplab\",\"created\":1456210242268,\"startDate\":1456123740000,\"updateAuthor\":\"i80986\",\"updateAuthorFullName\":\"Pokhrel, Biplab\",\"updated\":1456210842361}],\"fields\":[{\"label\":\"06.Import Data and Review\",\"value\":\"components\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54308\",\"summary\":\"0816 - Towers Watson - 1XA -  #174784: Dropping Claims From Highmark for group Heinz\",\"entries\":[{\"id\":287322,\"comment\":\"Highmark duplicate data removed.\r\nScrub modification completed.\",\"timeSpent\":14400,\"author\":\"i81134\",\"authorFullName\":\"Chakradhar, Sagar\",\"created\":1456917497408,\"startDate\":1456139820000,\"updateAuthor\":\"i81134\",\"updateAuthorFullName\":\"Chakradhar, Sagar\",\"updated\":1456917497408}],\"fields\":[{\"label\":\"10.Scrub Script Preparation/Modification\",\"value\":\"components\"},{\"label\":\"    Towers Watson 1Xchange\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Towers Watson 1Xchange\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54311\",\"summary\":\"Daily stand up Meeting\",\"entries\":[{\"id\":286725,\"comment\":\"\",\"timeSpent\":1800,\"author\":\"i80944\",\"authorFullName\":\"Karmacharya, Kripa\",\"created\":1456806507828,\"startDate\":1456201680000,\"updateAuthor\":\"i80944\",\"updateAuthorFullName\":\"Karmacharya, Kripa\",\"updated\":1456806507828}],\"fields\":[{\"label\":\"46.Project Meeting\",\"value\":\"components\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12031\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12430\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15726\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15727\"},{\"label\":\"Ops General\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54316\",\"summary\":\"Weekly Operations meeting.\",\"entries\":[{\"id\":283520,\"comment\":\"Weekly operations meeting.\",\"timeSpent\":3600,\"author\":\"i80953\",\"authorFullName\":\"Bajracharya, Ujen\",\"created\":1456133813271,\"startDate\":1456133760000,\"updateAuthor\":\"i80953\",\"updateAuthorFullName\":\"Bajracharya, Ujen\",\"updated\":1456133813271}],\"fields\":[{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"components\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12031\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_12430\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15726\"},{\"label\":\"    Meeting\n\",\"value\":\"customfield_15727\"},{\"label\":\"Ops General\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54336\",\"summary\":\"175-001:BCBSIL HMOI : Duplicate data found in RXClaims :Feb 2016 \",\"entries\":[{\"id\":283635,\"comment\":\"Duplicate file has been removed from scrub and imported table.\",\"timeSpent\":3600,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456148221433,\"startDate\":1456148160000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456148221433}],\"fields\":[{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"components\"},{\"label\":\"    BCBS IL - HMO\n\",\"value\":\"customfield_12031\"},{\"label\":\"    BCBS IL - HMO\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Defect\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54354\",\"summary\":\"864-001: Trinity Medicaid : Change logic for MM per ICE#168681\",\"entries\":[{\"id\":286322,\"comment\":\"Scrub Script changed and impact analysis share . Few questions asked to WPM for confirmation.\",\"timeSpent\":21600,\"author\":\"i80767\",\"authorFullName\":\"Joshi, Jayan Lal\",\"created\":1456744808914,\"startDate\":1456139940000,\"updateAuthor\":\"i80767\",\"updateAuthorFullName\":\"Joshi, Jayan Lal\",\"updated\":1456744808914}],\"fields\":[{\"label\":\"10.Scrub Script Preparation/Modification\",\"value\":\"components\"},{\"label\":\"    Trinity Health Corporation – Medicaid\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Trinity Health Corporation – Medicaid\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Change Request\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54386\",\"summary\":\"839-001 : VIVA Health : MRE pull\",\"entries\":[{\"id\":283601,\"comment\":\"MRE pull and verification of the report\",\"timeSpent\":14400,\"author\":\"i80833\",\"authorFullName\":\"Bajracharya, Romi\",\"created\":1456143269229,\"startDate\":1456143240000,\"updateAuthor\":\"i80833\",\"updateAuthorFullName\":\"Bajracharya, Romi\",\"updated\":1456143269229}],\"fields\":[{\"label\":\"22.Hawkeye Process\",\"value\":\"components\"},{\"label\":\"    VIVA Health, Inc.\n\",\"value\":\"customfield_12031\"},{\"label\":\"    VIVA Health Inc - Commercial\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54392\",\"summary\":\"764-003 Bexar County enrollment variance (ice:170782)\",\"entries\":[{\"id\":283609,\"comment\":\"\",\"timeSpent\":14400,\"author\":\"i81143\",\"authorFullName\":\"Shrestha, Manoj\",\"created\":1456143669432,\"startDate\":1456143660000,\"updateAuthor\":\"i81143\",\"updateAuthorFullName\":\"Shrestha, Manoj\",\"updated\":1456143669432}],\"fields\":[{\"label\":\"10.Scrub Script Preparation/Modification\",\"value\":\"components\"},{\"label\":\"    ProView Advanced Administrator, LLC\n\",\"value\":\"customfield_12031\"},{\"label\":\"    ProView Advanced Administrator, LLC - Quarterly\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Change Request\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54436\",\"summary\":\"832-001 HPI - Import Data and Review - Feb 2016\",\"entries\":[{\"id\":283919,\"comment\":\"Added Pattern, Verified files with File Tracker, Exception Import.\",\"timeSpent\":14400,\"author\":\"i81228\",\"authorFullName\":\"Bista, Puspa\",\"created\":1456210706015,\"startDate\":1456124220000,\"updateAuthor\":\"i81228\",\"updateAuthorFullName\":\"Bista, Puspa\",\"updated\":1456210706015}],\"fields\":[{\"label\":\"06.Import Data and Review\",\"value\":\"components\"},{\"label\":\"    Hewlett Packard\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Hewlett Packard\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54437\",\"summary\":\"882-001 HPE- Import Data and Review - Feb 2016\",\"entries\":[{\"id\":283920,\"comment\":\"Added Pattern, Verified files with File Tracker, Exception Import.\",\"timeSpent\":14400,\"author\":\"i81228\",\"authorFullName\":\"Bista, Puspa\",\"created\":1456210729791,\"startDate\":1456124280000,\"updateAuthor\":\"i81228\",\"updateAuthorFullName\":\"Bista, Puspa\",\"updated\":1456210729791}],\"fields\":[{\"label\":\"06.Import Data and Review\",\"value\":\"components\"},{\"label\":\"    Hewlett Packard\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Hewlett Packard\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54465\",\"summary\":\"861-001 : Goodyear - Data Import - March 2016\",\"entries\":[{\"id\":283977,\"comment\":\"DSR review\",\"timeSpent\":7200,\"author\":\"i80833\",\"authorFullName\":\"Bajracharya, Romi\",\"created\":1456220975521,\"startDate\":1456134540000,\"updateAuthor\":\"i80833\",\"updateAuthorFullName\":\"Bajracharya, Romi\",\"updated\":1456220975521},{\"id\":283982,\"comment\":\"File import completed by resolving Exception lists.\",\"timeSpent\":14400,\"author\":\"i80944\",\"authorFullName\":\"Karmacharya, Kripa\",\"created\":1456224404334,\"startDate\":1456137960000,\"updateAuthor\":\"i80944\",\"updateAuthorFullName\":\"Karmacharya, Kripa\",\"updated\":1456224404334}],\"fields\":[{\"label\":\"06.Import Data and Review\",\"value\":\"components\"},{\"label\":\"    Goodyear\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Goodyear\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54481\",\"summary\":\"824-002 Trinity - Staging - ICE#155640 - Futura Implementation - Rx - February\",\"entries\":[{\"id\":284467,\"comment\":\"\",\"timeSpent\":3600,\"author\":\"i80863\",\"authorFullName\":\"Kapali, Sweta\",\"created\":1456282617196,\"startDate\":1456196160000,\"updateAuthor\":\"i80863\",\"updateAuthorFullName\":\"Kapali, Sweta\",\"updated\":1456282617196}],\"fields\":[{\"label\":\"13.Scrub Script Review\",\"value\":\"components\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54544\",\"summary\":\"824-002 Trinity - Staging - ICE#155638 - Futura Implementation - Elig - February 2016 (Code Review)\t\",\"entries\":[{\"id\":284469,\"comment\":\"code review ongoing..\",\"timeSpent\":7200,\"author\":\"i80863\",\"authorFullName\":\"Kapali, Sweta\",\"created\":1456282833473,\"startDate\":1456196400000,\"updateAuthor\":\"i80863\",\"updateAuthorFullName\":\"Kapali, Sweta\",\"updated\":1456282850245}],\"fields\":[{\"label\":\"19.Scrub Test Case Review\",\"value\":\"components\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54545\",\"summary\":\"824-003 Trinity - Staging - ICE#155476 - Futura Implementation - Claims - February (Code Review)\",\"entries\":[{\"id\":284471,\"comment\":\"code review being continued...\",\"timeSpent\":3600,\"author\":\"i80863\",\"authorFullName\":\"Kapali, Sweta\",\"created\":1456283170027,\"startDate\":1456196700000,\"updateAuthor\":\"i80863\",\"updateAuthorFullName\":\"Kapali, Sweta\",\"updated\":1456283170027}],\"fields\":[{\"label\":\"13.Scrub Script Review\",\"value\":\"components\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Trinity Health Corporation\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-54620\",\"summary\":\"764-003 proview quarterly processing data scrubbing\",\"entries\":[{\"id\":285125,\"comment\":\"Scrub error resolved.\",\"timeSpent\":10800,\"author\":\"i80829\",\"authorFullName\":\"Maharjan, Dipu\",\"created\":1456409662903,\"startDate\":1456150380000,\"updateAuthor\":\"i80829\",\"updateAuthorFullName\":\"Maharjan, Dipu\",\"updated\":1456409662903}],\"fields\":[{\"label\":\"16.Data Scrubbing\",\"value\":\"components\"},{\"label\":\"    ProView Advanced Administrator, LLC\n\",\"value\":\"customfield_12031\"},{\"label\":\"    ProView Advanced Administrator, LLC - Quarterly\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Sub Task\",\"value\":\"issuetype\"}]},{\"key\":\"VITDATA-55267\",\"summary\":\"643-001: Cigna Bulk layout change.\",\"entries\":[{\"id\":286323,\"comment\":\"Scrub Script modification ongoing. Questions asked to WPM for confirmation on new layout.\",\"timeSpent\":7200,\"author\":\"i80767\",\"authorFullName\":\"Joshi, Jayan Lal\",\"created\":1456745003797,\"startDate\":1456140120000,\"updateAuthor\":\"i80767\",\"updateAuthorFullName\":\"Joshi, Jayan Lal\",\"updated\":1456745028611}],\"fields\":[{\"label\":\"04.Import Script Preparation/Modification\",\"value\":\"components\"},{\"label\":\"    Bulk Data Feed - Cigna\n\",\"value\":\"customfield_12031\"},{\"label\":\"    Bulk Data Feed - Cigna\n\",\"value\":\"customfield_12430\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15726\"},{\"label\":\"NoValueForFieldOnIssue\",\"value\":\"customfield_15727\"},{\"label\":\"Task\",\"value\":\"issuetype\"}]}],\"startDate\":1456078500000,\"endDate\":1456164900000}";
	@InitBinder
  public void initBinder(WebDataBinder binder)
  {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
  }
  
  public String getOnlyDate(Date dtime)
  {
    String dateFromat = "dd.MM.yyyy";
    SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
    String dateTime = "";
    dateTime = sdf.format(dtime);
    //this.log.info("dtime:" + dateTime);
    return dateTime;
  }
  
  public String getDateTime(Date dtime)
  {
    String dateFromat = "dd.MM.yyyy HH:mm";
    SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
    String dateTime = "";
    dateTime = sdf.format(dtime);
   // this.log.info("dateTime:" + dateTime);
    return dateTime;
  }
  
  @RequestMapping(value={"/jira/worklog"}, params={"jql"}, method={org.springframework.web.bind.annotation.RequestMethod.GET}, produces={"application/json"})
  @ResponseBody
  public String jiraWorklog(@RequestParam String jql)
    throws URISyntaxException
  {
   // this.log.info("EFFORT:" + jql);
    String https_url = "https://jira.hcinsight.net/rest/api/2/search?jql=" + URLEncoder.encode(jql) + "&fields=worklog";
    
    //this.log.info("https_url:" + https_url);
    URL uri = null;
    try
    {
      uri = new URL(https_url);
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
    }
    HttpsURLConnection con = null;
    try
    {
      con = (HttpsURLConnection)uri.openConnection();
      con.setRequestProperty("Authorization", "Basic aTgwODc0OldlbGNvbWUxNzAy");
      //con.setConnectTimeout(1000*600*10);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return getRESTContent(con);
  }
  
  @RequestMapping(value={"/jira/log/group"}, method={org.springframework.web.bind.annotation.RequestMethod.GET}, produces={"application/json"})
  @ResponseBody
  public String jiraLogGroup(@RequestParam("group") String group, @RequestParam("sdate") String sdate, @RequestParam("edate") String edate)
    throws URISyntaxException
  {
    return calculateJiraWorklog(group, sdate, edate);
  }
  
  @RequestMapping(value={"/jira/log/user"}, method={org.springframework.web.bind.annotation.RequestMethod.GET}, produces={"application/json"})
  @ResponseBody
  public String jiraLogUser(@RequestParam("user") String user, @RequestParam("sdate") String sdate, @RequestParam("edate") String edate)
    throws URISyntaxException
  {
    String https_url = "https://jira.hcinsight.net/rest/timesheet-gadget/1.0/raw-timesheet.json?targetUser=" + user + "&startDate=" + sdate + "&endDate=" + edate;
    
   // this.log.info("https_url:" + https_url);
    URL uri = null;
    try
    {
      uri = new URL(https_url);
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
    }
    HttpsURLConnection con = null;
    try
    {
      con = (HttpsURLConnection)uri.openConnection();
      con.setRequestProperty("Authorization", "Basic aTgwODc0OldlbGNvbWUxNzAy");
      //con.setConnectTimeout(1000*600*10);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return getRESTContent(con);
  }
  
  @RequestMapping(value={"/jira/issue/{id}"}, method={org.springframework.web.bind.annotation.RequestMethod.GET}, produces={"application/json"})
  @ResponseBody
  public String jiraIssue(@PathVariable("id") String id)
    throws URISyntaxException
  {
    String https_url = "https://jira.hcinsight.net/rest/api/2/issue/" + id;
   // this.log.info("https_url:" + https_url);
    URL uri = null;
    try
    {
      uri = new URL(https_url);
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
    }
    HttpsURLConnection con = null;
    try
    {
      con = (HttpsURLConnection)uri.openConnection();
      con.setRequestProperty("Authorization", "Basic aTgwODc0OldlbGNvbWUxNzAy");
      //con.setConnectTimeout(1000*600*10);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return getRESTContent(con);
  }
  
  private static String getRESTContent(HttpsURLConnection con)
  {
    String data = null;
    if (con != null)
    {
      BufferedReader br = null;
      StringBuilder sb = new StringBuilder();
      try
      {
        br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String jsonData;
        while ((jsonData = br.readLine()) != null) {
          sb.append(jsonData);
        }
        br.close();
        data = sb.toString();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }
   // System.out.println("data:"+data);
    return data;
  }
  
  String getJiraIssueDetail(String id)
    throws URISyntaxException
  {
    String https_url = "https://jira.hcinsight.net/rest/api/2/issue/" + id;
   System.out.println("https_url:" + https_url);
    URL uri = null;
    try
    {
      uri = new URL(https_url);
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
    }
    HttpsURLConnection con = null;
    try
    {
      con = (HttpsURLConnection)uri.openConnection();
      con.setRequestProperty("Authorization", "Basic aTgwODc0OldlbGNvbWUxNzAy");
     // con.setConnectTimeout(1000*600*10);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return getRESTContent(con);
  }
  
  String jiraLogGroupDetail(String group, String sdate, String edate)
    throws URISyntaxException
  {
    String target = "";
    String https_url="";
    if(group.equalsIgnoreCase("VITDATA")){
    	 target = "targetGroup";
    	 group="verisk-users";
    	https_url = "https://jira.hcinsight.net/rest/timesheet-gadget/1.0/raw-timesheet.json?" + target + "=" + group + "&filterid=29948&startDate=" + sdate + "&endDate=" + edate +"&moreFields=customfield_12031&moreFields=customfield_12430&moreFields=customfield_15726&moreFields=customfield_15727&moreFields=components&moreFields=issuetype";

    }
    else if (group.contains("VITDATA") || group.contains("VHTDBA")) {
      target = "targetGroup";
      https_url = "https://jira.hcinsight.net/rest/timesheet-gadget/1.0/raw-timesheet.json?" + target + "=" + group + "&startDate=" + sdate + "&endDate=" + edate +"&moreFields=customfield_12031&moreFields=customfield_12430&moreFields=customfield_15726&moreFields=customfield_15727&moreFields=components&moreFields=issuetype";

    } else {
      target = "targetUser";
      https_url = "https://jira.hcinsight.net/rest/timesheet-gadget/1.0/raw-timesheet.json?" + target + "=" + group + "&startDate=" + sdate + "&endDate=" + edate +"&moreFields=customfield_12031&moreFields=customfield_12430&moreFields=customfield_15726&moreFields=customfield_15727&moreFields=components&moreFields=issuetype";

    }
    
        
  //  this.log.info(https_url);
    System.out.println("URL:"+https_url);
    URL uri = null;
    try
    {
      uri = new URL(https_url);
    }
    catch (MalformedURLException e)
    {
      e.printStackTrace();
    }
    HttpsURLConnection con = null;
    try
    {
      con = (HttpsURLConnection)uri.openConnection();
      con.setRequestProperty("Authorization", "Basic aTgwODc0OldlbGNvbWUxNzAy");
     // con.(1000*600*10);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return getRESTContent(con);
  }
  

  
  public String calculateJiraWorklog(String group, String sdate, String edate)
  {
    try
    {
    
	String	groupString = jiraLogGroupDetail(group, sdate, edate);
	
	System.out.println(">>>:"+groupString);
	
	groupString = groupString.replace("\r\n", " ").replace("\n", " ");
	System.out.println(">>>:1111"+groupString);
     
      JSONObject jObj = new JSONObject(groupString);
      
      
      
      JSONArray jArr = jObj.getJSONArray("worklog");
      List<Worklog> wlogs = new ArrayList();
      for (int i = 0; i < jArr.length(); i++)
      {
        Worklog wlog = new Worklog();
        JSONObject obj = jArr.getJSONObject(i);
        String issueType="";
        
        if (obj.getString("key").contains("VITDATA"))
        {
        	  wlog.setKey(obj.getString("key"));
              wlog.setSummary(obj.getString("summary"));
          
          
              JSONArray field = obj.getJSONArray("fields");
              for (int j = 0; j < field.length(); j++)
              {
                
            	JSONObject subObj = field.getJSONObject(j);
            	
            	String value = subObj.getString("value");
                 String label = subObj.getString("label");
                 
                 if(value.equalsIgnoreCase("issuetype"))

              	 issueType=label;
                 
                 if(issueType.toUpperCase().contains("GENERAL")){
                	 wlog.setProject("Ops General");
                 }
                	
                if(value.equalsIgnoreCase("components"))
                	if(!label.equalsIgnoreCase("NoValueForFieldOnIssue"))
                	 wlog.setTask(label.replace("\n", ""));
                	else
                		 wlog.setTask("01.ALL");
                 
                 if(value.equalsIgnoreCase("customfield_12031") && !label.equalsIgnoreCase("NoValueForFieldOnIssue"))
                	 wlog.setProject(label.replace("\n", ""));
                 if(value.equalsIgnoreCase("customfield_12430") && !label.equalsIgnoreCase("NoValueForFieldOnIssue"))
                	 wlog.setSubproject(label.replace("\n", ""));
                 if(value.equalsIgnoreCase("customfield_15726") && !label.equalsIgnoreCase("NoValueForFieldOnIssue"))
                	 wlog.setSubproject(label.replace("\n", ""));
                 if(value.equalsIgnoreCase("customfield_15727") && !label.equalsIgnoreCase("NoValueForFieldOnIssue"))
                	 wlog.setTask(label.replace("\n", ""));
               
                 
              }
              JSONArray jsubArr = obj.getJSONArray("entries");
              List<Entry> entries = new ArrayList();
              for (int j = 0; j < jsubArr.length(); j++)
              {
                Entry entry = new Entry();
                JSONObject subObj = jsubArr.getJSONObject(j);
                entry.setAuthor(subObj.getString("author"));
                entry.setTimespent(Integer.valueOf(subObj.getInt("timeSpent")));
                entry.setComment(subObj.getString("comment"));
                entries.add(entry);
              }
              wlog.setEntries(entries);
              wlogs.add(wlog);
        }
        else if (obj.getString("key").contains("VHTDBA")){
        	wlog.setKey(obj.getString("key"));
            wlog.setSummary(obj.getString("summary"));
            wlog.setTask(obj.getString("key"));
            wlog.setProject("VHTDBA-JIRA");
            wlog.setSubproject("VHTDBA-JIRA");
            
            JSONArray jsubArr = obj.getJSONArray("entries");
            List<Entry> entries = new ArrayList();
            for (int j = 0; j < jsubArr.length(); j++)
            {
              Entry entry = new Entry();
              JSONObject subObj = jsubArr.getJSONObject(j);
              entry.setAuthor(subObj.getString("author"));
              entry.setTimespent(Integer.valueOf(subObj.getInt("timeSpent")));
              entry.setComment(subObj.getString("comment"));
              entries.add(entry);
            }
            wlog.setEntries(entries);
            wlogs.add(wlog);
            
        }else{
        	
        	wlog.setKey(obj.getString("key"));
            wlog.setSummary(obj.getString("summary"));
            wlog.setTask(obj.getString("key"));
            wlog.setProject("JIRA");
            wlog.setSubproject("JIRA");
            
            JSONArray jsubArr = obj.getJSONArray("entries");
            List<Entry> entries = new ArrayList();
            for (int j = 0; j < jsubArr.length(); j++)
            {
              Entry entry = new Entry();
              JSONObject subObj = jsubArr.getJSONObject(j);
              entry.setAuthor(subObj.getString("author"));
              entry.setTimespent(Integer.valueOf(subObj.getInt("timeSpent")));
              entry.setComment(subObj.getString("comment"));
              entries.add(entry);
            }
            wlog.setEntries(entries);
            wlogs.add(wlog);
        	
        }
        
      }
     System.out.println(JsonUtils.toJSon(wlogs));
      return JsonUtils.toJSon(wlogs);
    }
    catch (JSONException e)
    {
      e.printStackTrace();
      return null;
    }
   catch (URISyntaxException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    return null;
    
  }
}
