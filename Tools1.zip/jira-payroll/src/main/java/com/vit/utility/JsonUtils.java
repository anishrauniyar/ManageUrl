package com.vit.utility;

import com.vit.domain.Entry;
import com.vit.domain.Worklog;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonUtils
{
  public static String toJSon(List<Worklog> worklogs)
  {
    JSONObject jsonParent = new JSONObject();
    JSONArray jsonArrParent = new JSONArray();
    try
    {
      for (int i = 0; i < worklogs.size(); i++)
      {
        Worklog wlog = (Worklog)worklogs.get(i);
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("key", wlog.getKey());
        jsonObj.put("summary", wlog.getSummary());
        jsonObj.put("task", wlog.getTask());
        jsonObj.put("project", wlog.getProject());
        jsonObj.put("subproject", wlog.getSubproject());
        JSONArray jsonArr = new JSONArray();
        for (Entry entry : wlog.getEntries())
        {
          JSONObject entryObj = new JSONObject();
          entryObj.put("author", entry.getAuthor());
          entryObj.put("comment", entry.getComment());
          entryObj.put("timeSpent", entry.getTimespent());
          jsonArr.put(entryObj);
        }
        jsonObj.put("entries", jsonArr);
        
        jsonArrParent.put(jsonObj);
      }
      jsonParent.put("worklog", jsonArrParent);
    }
    catch (JSONException ex)
    {
      ex.printStackTrace();
    }
    return jsonParent.toString();
  }
  
  public static void main(String[] args) {
	
	  
	  
}
}
