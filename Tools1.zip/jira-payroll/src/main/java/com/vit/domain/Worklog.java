package com.vit.domain;

import java.util.List;

public class Worklog
{
  String key;
  String summary;
  String task;
  String project;
  String subproject;
  List<Entry> entries;
  
  public String getKey()
  {
    return this.key;
  }
  
  public void setKey(String key)
  {
    this.key = key;
  }
  
  public String getSummary()
  {
    return this.summary;
  }
  
  public void setSummary(String summary)
  {
    this.summary = summary;
  }
  
  public String getTask()
  {
    return this.task;
  }
  
  public void setTask(String task)
  {
    this.task = task;
  }
  
  public List<Entry> getEntries()
  {
    return this.entries;
  }
  
  public void setEntries(List<Entry> entries)
  {
    this.entries = entries;
  }
  
  public String getProject()
  {
    return this.project;
  }
  
  public void setProject(String project)
  {
    this.project = project;
  }
  
  public String getSubproject()
  {
    return this.subproject;
  }
  
  public void setSubproject(String subproject)
  {
    this.subproject = subproject;
  }
}
