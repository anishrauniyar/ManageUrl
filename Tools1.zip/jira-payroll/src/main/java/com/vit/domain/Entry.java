package com.vit.domain;

public class Entry
{
  String comment;
  String author;
  Integer timespent;
  
  public String getComment()
  {
    return this.comment;
  }
  
  public void setComment(String comment)
  {
    this.comment = comment;
  }
  
  public String getAuthor()
  {
    return this.author;
  }
  
  public void setAuthor(String author)
  {
    this.author = author;
  }
  
  public Integer getTimespent()
  {
    return this.timespent;
  }
  
  public void setTimespent(Integer timespent)
  {
    this.timespent = timespent;
  }
}
