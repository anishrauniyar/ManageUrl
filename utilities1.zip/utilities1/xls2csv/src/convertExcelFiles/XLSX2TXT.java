/*Derived from http://poi.apache.org/spreadsheet/how-to.html*/
// MODIFIED BY AYAM - FIXED ISSUE-> IT WAS NOT CONSIDERING SHARED STRINGS TABLE INITIALLY
//ESCAPED " with "" (TO HANDLE FROM ORACLE)
//CHANGED JULIAN DATE FORMAT TO HAVE yyyy 
package convertExcelFiles;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.poi.POIXMLProperties;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public class XLSX2TXT {
	public static int headerColumnCount = -1;
	public static boolean emptySheetFlag;
	public static boolean closeFlag = false;

	enum xssfDataType {
		BOOL, ERROR, FORMULA, INLINESTR, SSTINDEX, NUMBER,
	}

	/**
	 * 
	 * Class for Handling Sheets (xml)
	 * 
	 */
	class MyXSSFSheetHandler extends DefaultHandler {

		/**
		 * Table with styles
		 */
		private StylesTable stylesTable;

		/**
		 * Table with unique strings(Generally sharesStrings.xml inside the xl
		 * folder of the extracted xls file)
		 */
		private ReadOnlySharedStringsTable sharedStringsTable;

		/**
		 * Destination for data. (Sheet-wise Txt file in case of AIP)
		 */
		private final PrintStream output;

		/**
		 * Number of columns to read starting with leftmost
		 */
		@SuppressWarnings("unused") //Testing Phase
		private final int minColumnCount;

		/**
		 * Set when V start element is seen(V is For Value)
		 */
		private boolean vIsOpen;

		// Set when cell start element is seen;
		// used when cell close element is seen.
		private xssfDataType nextDataType;

		// Used to format numeric cell values.
		private short formatIndex;
		private String formatString;
		private final DataFormatter formatter;

		private int thisColumn = -1;
		// The last column printed to the output stream
		private int lastColumnNumber = -1;

		// Gathers characters as they are seen.
		private StringBuffer value;

		public MyXSSFSheetHandler(StylesTable styles,
				ReadOnlySharedStringsTable strings, int cols, PrintStream target) {
			this.stylesTable = styles;
			this.sharedStringsTable = strings;
			this.minColumnCount = cols;
			this.output = target;
			this.value = new StringBuffer();
			this.nextDataType = xssfDataType.NUMBER;
			this.formatter = new DataFormatter();
		}

		public void startElement(String uri, String localName, String name,
				Attributes attributes) throws SAXException {

			if ("inlineStr".equals(name) || "v".equals(name)
					|| "t".equals(name)) {
				vIsOpen = true;
				// Clear contents cache
				value.setLength(0);
			}
			// c => cell
			else if ("c".equals(name)) {
				// Get the cell reference
				String r = attributes.getValue("r");
				int firstDigit = -1;
				for (int c = 0; c < r.length(); ++c) {
					if (Character.isDigit(r.charAt(c))) {
						firstDigit = c;
						break;
					}
				}
				thisColumn = nameToColumn(r.substring(0, firstDigit));

				// Set up defaults.
				this.nextDataType = xssfDataType.NUMBER;
				this.formatIndex = -1;
				this.formatString = null;
				String cellType = attributes.getValue("t");
				String cellStyleStr = attributes.getValue("s");
				if ("b".equals(cellType))
					nextDataType = xssfDataType.BOOL;
				else if ("e".equals(cellType))
					nextDataType = xssfDataType.ERROR;
				else if ("inlineStr".equals(cellType))
					nextDataType = xssfDataType.INLINESTR;
				else if ("s".equals(cellType))
					nextDataType = xssfDataType.SSTINDEX;
				else if ("str".equals(cellType))
					nextDataType = xssfDataType.FORMULA;
				else if (cellStyleStr != null) {
					// It's a number, but almost certainly one
					// with a special style or format
					int styleIndex = Integer.parseInt(cellStyleStr);
					XSSFCellStyle style = stylesTable.getStyleAt(styleIndex);
					this.formatIndex = style.getDataFormat();
					this.formatString = style.getDataFormatString();
					if (this.formatString == null)
						this.formatString = BuiltinFormats
								.getBuiltinFormat(this.formatIndex);
				}
				if (!closeFlag) {
					if (headerColumnCount == -1) {
						headerColumnCount = 1;
					} else {
						headerColumnCount += 1;
					}
				}
			}

		}

		public void endElement(String uri, String localName, String name)
				throws SAXException {

			String thisStr = null;

			// v => contents of a cell
			if ("v".equals(name) || "t".equals(name)) {
				// Process the value contents as required.
				// Do now, as characters() may be called more than once
				switch (nextDataType) {

				case BOOL:
					char first = value.charAt(0);
					thisStr = first == '0' ? "FALSE" : "TRUE";
					break;

				case ERROR:
					thisStr = '"' + value.toString().replaceAll("\"", "\"\"") + '"';
					break;

				case FORMULA:
					// A formula could result in a string value,
					// so always add double-quote characters.
					thisStr = '"' + value.toString().replaceAll("\"", "\"\"") + '"';
					break;

				case INLINESTR:
					XSSFRichTextString rtsi = new XSSFRichTextString(
							value.toString());
					thisStr = '"' + rtsi.toString().replaceAll("\"", "\"\"") + '"';
					thisStr = thisStr.replaceAll("\n", " ");
					break;

				case SSTINDEX:
					String sstIndex = value.toString();
					try {
						int idx = Integer.parseInt(sstIndex);
						XSSFRichTextString rtss = new XSSFRichTextString(
								sharedStringsTable.getEntryAt(idx));
						thisStr = '"' + rtss.toString()
								.replaceAll("\"", "\"\"") + '"';
						thisStr = thisStr.replaceAll("\n", " ");
					} catch (NumberFormatException ex) {
						System.err.println("Failed to parse SST index '"
								+ sstIndex + "': " + ex.toString());
						System.exit(1);
					}
					break;

				case NUMBER:
					String n = value.toString();
					if (this.formatString != null) {
						if (this.formatString.equals("m/d/yy")) {
							this.formatString = "mm/dd/yyyy";
						}
						thisStr = formatter.formatRawCellContents(
								Double.parseDouble(n), this.formatIndex,
								this.formatString);
					} else
						thisStr = n;
					break;

				default:
					/*thisStr = "( Failed: Unexpected type: " + nextDataType
							+ ")";*/
					thisStr = "";
					System.err.println("Unexpected Datatype Found");
					System.exit(1);
					break;
				}

				// Output after we've seen the string contents
				// Emit commas for any fields that were missing on this row
				if (lastColumnNumber == -1) {
					lastColumnNumber = 0;
				}
				for (int i = lastColumnNumber; i < thisColumn; ++i)
					output.print(delimiter);

				// Might be the empty string.
				output.print(thisStr);

				// Update column
				if (thisColumn > -1)
					lastColumnNumber = thisColumn;

			} else if ("row".equals(name)) {
				emptySheetFlag = false;
				// Print out any missing commas if needed
				/*if (minColumns > 0) {
					// Columns are 0 based
					if (lastColumnNumber == -1) {
						lastColumnNumber = 0;
					}
					for (int i = lastColumnNumber; i < (this.minColumnCount); i++) {
						output.print(delimiter);
					}
				}*/
				//---------------------------------------------------------
				// /*  New Logic -> To Make File Layout Consistent -------------- 
				if (headerColumnCount > 0 && closeFlag) {
					// Columns are 0 based
					
					if (lastColumnNumber == -1) {
						lastColumnNumber = 0;
					}
					for (int i = lastColumnNumber; i < (headerColumnCount-1); i++) {
						output.print(delimiter);
					}
				}
				//------------------------------------------------------------ */
				// We're onto a new row
				output.println();
				lastColumnNumber = -1;
				closeFlag = true;

			}
		}

		public void characters(char[] ch, int start, int length)
				throws SAXException {
			if (vIsOpen)
				value.append(ch, start, length);
		}

		private int nameToColumn(String name) {
			int column = -1;
			for (int i = 0; i < name.length(); ++i) {
				int c = name.charAt(i);
				column = (column + 1) * 26 + c - 'A';
			}
			return column;
		}

	}

	private OPCPackage xlsxPackage;
	private int minColumns;
	private String fileName;
	private String extractPath;
	private String delimiter;

	/**
	 * Creates a new XLSX -> TXT converter
	 * 
	 * @param pkg
	 *            The XLSX package to process
	 * @param minColumns
	 *            The minimum number of columns to output, or -1 for no minimum
	 * @param xlsxFile
	 *            The xlsx file to process
	 * @param extractPath
	 *            The Output Path for the converted text file
	 * @param delimiter
	 *            The delimiter to use in the text file
	 * 
	 */
	public XLSX2TXT(OPCPackage pkg, int minColumns, File xlsxFile,
			String extractPath, String delimiter) {
		this.xlsxPackage = pkg;
		// this.output = output;
		this.minColumns = minColumns;
		this.fileName = xlsxFile.getName();
		this.extractPath = extractPath;
		this.delimiter = delimiter;

	}

	/**
	 * Parses and shows the content of one sheet using the specified styles and
	 * shared-strings tables.
	 * 
	 * @param styles
	 * @param strings
	 * @param sheetInputStream
	 * @param sheetName
	 */
	public void processSheet(StylesTable styles,
			ReadOnlySharedStringsTable strings, InputStream sheetInputStream,
			String sheetName) throws IOException, ParserConfigurationException,
			SAXException {
		emptySheetFlag = true;
		File fl = new File(fileName);
		String fileName1 = fl.getName();
		// String fileName1WithoutSpace = fileName1.replaceAll("\\s", "");
		String sheetNameWithoutSpace = sheetName.replaceAll("\\s", "");
		String csvSheetName = extractPath + fileName1 + "_"
				+ sheetNameWithoutSpace + ".txt";
		FileOutputStream fout = new FileOutputStream(csvSheetName);
		PrintStream stdout = new PrintStream(fout);
		System.setOut(stdout);

		InputSource sheetSource = new InputSource(sheetInputStream);
		SAXParserFactory saxFactory = SAXParserFactory.newInstance();
		SAXParser saxParser = saxFactory.newSAXParser();
		XMLReader sheetParser = saxParser.getXMLReader();
		this.minColumns=-1;
		closeFlag=false;
		headerColumnCount=-1;
		ContentHandler handler = new MyXSSFSheetHandler(styles, strings,
				this.minColumns, stdout);
		sheetParser.setContentHandler(handler);
		sheetParser.parse(sheetSource);
		fout.close();
		stdout.close();
		if (!emptySheetFlag) {
			Excel2Text.listOfConvertedFiles += "|" + extractPath + fileName1
					+ "_" + sheetNameWithoutSpace + ".txt";
		} else {
			try {
				File file = new File(csvSheetName);
				file.delete();
			} catch (Exception e) {
				System.err.println("Empty Sheet Deletion Unsuccessful");
			}
		}

	}

	public void process() throws IOException, OpenXML4JException,
			ParserConfigurationException, SAXException {

		ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(
				this.xlsxPackage); // HERE
		XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);
		StylesTable styles = xssfReader.getStylesTable();
		XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader
				.getSheetsData();

		while (iter.hasNext()) {
			InputStream stream = iter.next();
			String sheetName = iter.getSheetName();
			processSheet(styles, strings, stream, sheetName);
			stream.close();
		}
	}

	public static void fn_xlsx2txt(String args, String extractPath,
			String delimiter) throws Exception {

		File xlsxFile = new File(args);

		if (!xlsxFile.exists()) {
			System.err
					.println("Not found or not a file: " + xlsxFile.getPath());
			System.exit(1);
		}

		int minColumns = -1;

		OPCPackage p = OPCPackage.open(xlsxFile.getPath(), PackageAccess.READ);

		String appType = null;
		POIXMLProperties props = new POIXMLProperties(p);
		appType = props.getExtendedProperties().getUnderlyingProperties()
				.getApplication();
		System.out.println("The file is " + appType + " generated xlsx file");

		XLSX2TXT xlsx2txt = new XLSX2TXT(p, minColumns, xlsxFile, extractPath,
				delimiter);
		xlsx2txt.process();
		//System.err.println(headerColumnCount);
	}

}
