
package convertExcelFiles;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

//import org.apache.commons.lang3.StringEscapeUtils;

import jxl.Cell;
import jxl.CellType;
import jxl.DateCell;
import jxl.NumberCell;
import jxl.Sheet;
import jxl.Workbook;
/**
 * This class uses JXL API library for converting excel files(1997-2003 format only) with .xls extension
 * @author:Ayam Pokhrel
 * 
 */
public class JXL2CSV {

	/**
	 * 
	 * @param filePath
	 * 				The xls file path
	 * @param destinationPath
	 * 				Converted File Path
	 * @param delimiter
	 * 				The delimiter of the converted file
	 * @throws Exception
	 * 				
	 */
	public static void convertExcelFile(String filePath, String destinationPath,
			String delimiter) throws Exception {
		String timeZone = null;
		int skip = 0;
		if (!filePath.toLowerCase().endsWith(".xls")) {
			System.err.println("Couldn't find xls file");
			System.exit(1);
		} else {

			File input = new File(filePath);

			if (input.exists() && input.canRead()) {

				String fname = (input.getParent() == null) ? input.getName()
						: input.getParent() + File.separator + input.getName();

				Workbook workbook = Workbook.getWorkbook(new File(fname));
				int NumberOfSheets = workbook.getNumberOfSheets();

				for (int k = 0; k < NumberOfSheets; k++) {
					Sheet sheet = workbook.getSheet(k);

					int numrows = sheet.getRows();

					int numcols = sheet.getColumns();

					if (numrows > 0) {
						String SheetName = sheet.getName()
								.replaceAll("\\s", "");

						String destinationFileName = destinationPath
								+ input.getName() + "_" + SheetName + ".txt";
						File txtFile = new File(destinationFileName);

						BufferedWriter bout = null;
						OutputStreamWriter writer = new OutputStreamWriter(
								new FileOutputStream(txtFile, false), "UTF-8");
						bout = new BufferedWriter(writer);

						for (int i = skip; i < numrows; i++) {
							for (int j = 0; j < numcols; j++) {
								String cellValue = "";

								Cell a1 = sheet.getCell(j, i);
								if (a1.getType() == CellType.NUMBER) {
									NumberCell n1 = (NumberCell) a1;

									cellValue = '"' + n1.getContents()
											.replaceAll("\"", "\"\"") + '"';
								} else if (a1.getType() == CellType.DATE) {
									DateCell d1 = (DateCell) a1;

									// PREVIOUSLY, //ALSO IN OLD DASHBOARD
									/*SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
									sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
									cellValue = sdf.format(d1.getDate());*/

									// Get The Excel Format String and work
									/*String localFormat = d1.getCellFormat()
											.getFormat().getFormatString();
									SimpleDateFormat sdf = new SimpleDateFormat(
											localFormat); //NEEDS MAPPING
									
									cellValue = sdf.format(d1.getDate());*/

									// NEXT APPROACH
									/*DateFormat localFormat = d1.getDateFormat();
									System.err.println(localFormat.getTimeZone().getID());
									localFormat.format(d1.getDate());
									cellValue = '"' + localFormat.format(d1
											.getDate()) + '"';*/

									// THE NEXT APPROACH
									DateFormat localFormat = d1.getDateFormat();
									timeZone = localFormat.getTimeZone()
											.getID(); // Use this in case of any
														// issue

									SimpleDateFormat sdf = new SimpleDateFormat(
											"MM/dd/yyyy");
									sdf.setTimeZone(TimeZone.getTimeZone("GMT")); // Use
																					// timeZone
																					// here
									cellValue = sdf.format(d1.getDate());
									cellValue = '"' + cellValue.replaceAll(
											"\"", "") + '"';
								} else {
									cellValue = a1.getContents();
									cellValue = cellValue.replaceAll("\"",
											"\"\"");
									cellValue = '"' + cellValue.replaceAll(
											"\n", " ") + '"';

								}

								if (j == (numcols - 1)) {
									bout.write(cellValue);
								} else {
									bout.write(cellValue + delimiter);
								}

							}
							bout.write("\n");
							// bout.newLine();

						}
						bout.flush();
						writer.flush();
						bout.close();
						writer.close();
						Excel2Text.listOfConvertedFiles += "|"
								+ destinationFileName;
					}
				}
				System.err.println(timeZone);
			}

		}

	}
}
