
package convertExcelFiles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

//import jxl.read.biff.BiffException;

import org.apache.commons.cli.*;
import org.apache.tika.Tika;
/**
 * This class delegates excel conversion to either JXL2CSV class or XLSX2TXT class
 * @author:Ayam Pokhrel
 * @version: 1.0
 */
public class Excel2Text {
	/**
	 * Apache Tika xlsType
	 */
	public static String xlsType = "application/vnd.ms-excel";
	/**
	 * Apache Tika xlsxType
	 */
	public static String xlsxType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static String listOfConvertedFiles = "|";
	/**
	 * For Displaying the output in Standard output Stream.
	 */
	public static PrintStream consoleOutput = System.out;
	public static boolean xlsxFlag = false;
	public static boolean xlsFlag = false;
	public static boolean binaryFlag = false;

	public static void main(String[] args) {

		String excelFile = "";
		String extractTextPath = "";
		String textDelimiter = ",";
		Options options = new Options();
		options.addOption("i", true, "<input excel fileName> [required]");
		options.addOption("d", true, "<delimiter> [optional]");
		options.addOption("o", true, "<dump folder> [optional]");

		if (args.length < 1) {
			usage(options);
			return;
		}
		CommandLineParser parser = new BasicParser();
		CommandLine cmd;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException pe) {
			consoleOutput.println(pe);
			usage(options);
			return;
		}

		if (cmd.hasOption("i")) {

			excelFile = (cmd.getOptionValue('i'));
		}

		if (cmd.hasOption("o")) {

			extractTextPath = (cmd.getOptionValue('o'));
			File file = new File(extractTextPath);
			if (file.isDirectory() && file.exists() && file.canWrite()) {
				extractTextPath = file.getPath();
				extractTextPath += "/";
			} else {
				System.err.println("Invalid Output Directory: "
						+ extractTextPath
						+ "\n(Write  Permission or Existence issue)");
				System.exit(1);
			}

		}

		if (cmd.hasOption("d")) {
			textDelimiter = (cmd.getOptionValue('d'));
		}

		if (excelFile == null || excelFile.equals("")) {
			usage(options);
			System.exit(1);
		}
		
		String ext;
		if(excelFile.contains(".")){
			ext = excelFile.substring(excelFile.lastIndexOf('.'),
					excelFile.length());
		}
		else{
			ext = "";
		}
		File fl = new File(excelFile);
		if (!fl.exists()) {
			System.err.println("file not found : " + fl.getPath());
			System.exit(1);
		}
		Tika tika = new Tika();
		String fileType = "";
		try {
			fileType = tika.detect(fl);
			
		} catch (IOException e2) {
			System.err.println("APACHE TIKA EXCEPTION OCCURRED");
			System.exit(1);
		}
		if (fileType.equals(xlsType)) {
			xlsFlag = true;
		} else if (fileType.equals(xlsxType)) {
			xlsxFlag = true;
		}
		if (!(xlsFlag | xlsxFlag)) {
			consoleOutput.println("File check failed at first check");
			boolean readableFlag = false;
			int controlCharacterCount = 0;
			if (ext.toLowerCase().equals(".xls")) {
				xlsFlag = true;
			}
			if (ext.toLowerCase().equals(".xlsx")) {
				xlsxFlag = true;
			}
			try {
				char[] cArray = new char[51];
				FileReader r = new FileReader(fl);
				r.read(cArray, 0, 50);
				r.close();
				for (int i = 0; i < cArray.length; i++) {

					readableFlag = Character.isISOControl(cArray[i]);

					if (readableFlag == true
							&& !Character.isWhitespace(cArray[i])) {
						controlCharacterCount++;
					}

				}
				if (controlCharacterCount < 6) {
					System.err
							.println("The Given File has readable Text rather than binary data");
					System.exit(1);
				}
			} catch (FileNotFoundException e1) {
				System.err.println(e1.getMessage());
				System.exit(1);
			} catch (IOException e) {
				System.err.println(e.getMessage());
				System.exit(1);
			}
		}

		if (xlsxFlag) {

			try {
				XLSX2TXT.fn_xlsx2txt(excelFile, extractTextPath, textDelimiter);

				consoleOutput.println("Excel Conversion Successful");
				consoleOutput.println(listOfConvertedFiles);
			} catch (org.apache.poi.openxml4j.exceptions.InvalidOperationException e) {

				System.err.println(e.getMessage());
				System.exit(1);
			} catch (Exception e) {

				System.err.println("Unable to process:" + e.getMessage());
				System.exit(1);
			}

		} else if (xlsFlag) {

			try {
				JXL2CSV.convertExcelFile(excelFile, extractTextPath, textDelimiter);
				consoleOutput.println("Excel Conversion Successful");
				consoleOutput.println(listOfConvertedFiles);
				System.exit(0);
			} catch (Exception ee) {
				System.err.println("Unable To Process This File");
				System.exit(1);
			}

		} else {

			System.err
					.println("Extention unknown for Excel file: " + excelFile);
			System.exit(1);
		}
		System.exit(0);

	}
	/**
	 * 
	 * @param options
	 * This Method is for the usage information(Command Line)
	 */
	private static void usage(Options options) {
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("xls2csv", options);
	}

}
