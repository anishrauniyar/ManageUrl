package model;

import java.util.Date;

public class HistoryModel {
	private int noOfClients;
	public int getNoOfClients() {
		return noOfClients;
	}
	public void setNoOfClients(int noOfClients) {
		this.noOfClients = noOfClients;
	}
	public int getNoOfPayors() {
		return noOfPayors;
	}
	public void setNoOfPayors(int noOfPayors) {
		this.noOfPayors = noOfPayors;
	}
	public int getTotalFilesReceived() {
		return totalFilesReceived;
	}
	public void setTotalFilesReceived(int totalFilesReceived) {
		this.totalFilesReceived = totalFilesReceived;
	}
	public int getImportedCount() {
		return importedCount;
	}
	public void setImportedCount(int importedCount) {
		this.importedCount = importedCount;
	}
	public int getUnknownCount() {
		return unknownCount;
	}
	public void setUnknownCount(int unknownCount) {
		this.unknownCount = unknownCount;
	}
	public int getControlCount() {
		return controlCount;
	}
	public void setControlCount(int controlCount) {
		this.controlCount = controlCount;
	}
	public int getExceptionsCount() {
		return exceptionsCount;
	}
	public void setExceptionsCount(int exceptionsCount) {
		this.exceptionsCount = exceptionsCount;
	}
	public int getUnprocessedCount() {
		return unprocessedCount;
	}
	public void setUnprocessedCount(int unprocessedCount) {
		this.unprocessedCount = unprocessedCount;
	}
	public int getDoNotUseCount() {
		return doNotUseCount;
	}
	public void setDoNotUseCount(int doNotUseCount) {
		this.doNotUseCount = doNotUseCount;
	}
	public double getTotalSize() {
		return totalSize;
	}
	public void setTotalSize(double totalSize) {
		this.totalSize = totalSize;
	}
	public int getMmRecordsCount() {
		return mmRecordsCount;
	}
	public void setMmRecordsCount(int mmRecordsCount) {
		this.mmRecordsCount = mmRecordsCount;
	}
	public int getEeRecordsCount() {
		return eeRecordsCount;
	}
	public void setEeRecordsCount(int eeRecordsCount) {
		this.eeRecordsCount = eeRecordsCount;
	}
	public int getRxRecordsCount() {
		return rxRecordsCount;
	}
	public void setRxRecordsCount(int rxRecordsCount) {
		this.rxRecordsCount = rxRecordsCount;
	}
	public int getOtherRecordsCount() {
		return otherRecordsCount;
	}
	public void setOtherRecordsCount(int otherRecordsCount) {
		this.otherRecordsCount = otherRecordsCount;
	}
	public double getProcessingTime() {
		return processingTime;
	}
	public void setProcessingTime(double processingTime) {
		this.processingTime = processingTime;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	private int noOfPayors;
	private int totalFilesReceived;
	private int importedCount;
	private int unknownCount;
	private int controlCount;
	private int exceptionsCount;
	private int unprocessedCount;
	private int doNotUseCount;
	private double totalSize;
	private int mmRecordsCount;
	private int eeRecordsCount;
	private int rxRecordsCount;
	private int otherRecordsCount;
	private double processingTime;
	private Date date;
}