package model;

import java.util.Date;

public class ControlReconModel {
	private String clientId, fileid, filename, payorname, fileDataType;
	private String dmfileid, ctlFileName;
	

	public String getClientId() {
		return clientId;
	}



	public void setClientId(String clientId) {
		this.clientId = clientId;
	}



	public String getFileid() {
		return fileid;
	}



	public void setFileid(String fileid) {
		this.fileid = fileid;
	}



	public String getFilename() {
		return filename;
	}



	public void setFilename(String filename) {
		this.filename = filename;
	}



	public String getPayorname() {
		return payorname;
	}



	public void setPayorname(String payorname) {
		this.payorname = payorname;
	}



	public String getFileDataType() {
		return fileDataType;
	}



	public void setFileDataType(String fileDataType) {
		this.fileDataType = fileDataType;
	}



	public String getDmfileid() {
		return dmfileid;
	}



	public void setDmfileid(String dmfileid) {
		this.dmfileid = dmfileid;
	}



	public String getCtlFileName() {
		return ctlFileName;
	}



	public void setCtlFileName(String ctlFileName) {
		this.ctlFileName = ctlFileName;
	}



	public Date getDataFileDate() {
		return dataFileDate;
	}



	public void setDataFileDate(Date dataFileDate) {
		this.dataFileDate = dataFileDate;
	}



	public Date getCtlFileDate() {
		return ctlFileDate;
	}



	public void setCtlFileDate(Date ctlFileDate) {
		this.ctlFileDate = ctlFileDate;
	}



	public Integer getDataLayoutID() {
		return dataLayoutID;
	}



	public void setDataLayoutID(Integer dataLayoutID) {
		this.dataLayoutID = dataLayoutID;
	}



	public Integer getCtlLayoutID() {
		return ctlLayoutID;
	}



	public void setCtlLayoutID(Integer ctlLayoutID) {
		this.ctlLayoutID = ctlLayoutID;
	}



	public Double getVhBilledAmount() {
		return vhBilledAmount;
	}



	public void setVhBilledAmount(Double vhBilledAmount) {
		this.vhBilledAmount = vhBilledAmount;
	}



	public Double getVhAllowedAmount() {
		return vhAllowedAmount;
	}



	public void setVhAllowedAmount(Double vhAllowedAmount) {
		this.vhAllowedAmount = vhAllowedAmount;
	}



	public Double getVhPaidAmount() {
		return vhPaidAmount;
	}



	public void setVhPaidAmount(Double vhPaidAmount) {
		this.vhPaidAmount = vhPaidAmount;
	}



	public Double getVhEmployeeAmount() {
		return vhEmployeeAmount;
	}



	public void setVhEmployeeAmount(Double vhEmployeeAmount) {
		this.vhEmployeeAmount = vhEmployeeAmount;
	}



	public Double getVendorBilledAmount() {
		return vendorBilledAmount;
	}



	public void setVendorBilledAmount(Double vendorBilledAmount) {
		this.vendorBilledAmount = vendorBilledAmount;
	}



	public Double getVendorAllowedAmount() {
		return vendorAllowedAmount;
	}



	public void setVendorAllowedAmount(Double vendorAllowedAmount) {
		this.vendorAllowedAmount = vendorAllowedAmount;
	}



	public Double getVendorPaidAmount() {
		return vendorPaidAmount;
	}



	public void setVendorPaidAmount(Double vendorPaidAmount) {
		this.vendorPaidAmount = vendorPaidAmount;
	}



	public Double getVendorEmployeeAmount() {
		return vendorEmployeeAmount;
	}



	public void setVendorEmployeeAmount(Double vendorEmployeeAmount) {
		this.vendorEmployeeAmount = vendorEmployeeAmount;
	}



	public Double getVarBilledAmount() {
		return varBilledAmount;
	}



	public void setVarBilledAmount(Double varBilledAmount) {
		this.varBilledAmount = varBilledAmount;
	}



	public Double getVarAllowedAmount() {
		return varAllowedAmount;
	}



	public void setVarAllowedAmount(Double varAllowedAmount) {
		this.varAllowedAmount = varAllowedAmount;
	}



	public Double getVarPaidAmount() {
		return varPaidAmount;
	}



	public void setVarPaidAmount(Double varPaidAmount) {
		this.varPaidAmount = varPaidAmount;
	}



	public Double getVarEmployeeAmount() {
		return varEmployeeAmount;
	}



	public void setVarEmployeeAmount(Double varEmployeeAmount) {
		this.varEmployeeAmount = varEmployeeAmount;
	}



	public Integer getVhEmployeeCount() {
		return vhEmployeeCount;
	}



	public void setVhEmployeeCount(Integer vhEmployeeCount) {
		this.vhEmployeeCount = vhEmployeeCount;
	}



	public Integer getVhMemberCount() {
		return vhMemberCount;
	}



	public void setVhMemberCount(Integer vhMemberCount) {
		this.vhMemberCount = vhMemberCount;
	}



	public Integer getVhRecordCount() {
		return vhRecordCount;
	}



	public void setVhRecordCount(Integer vhRecordCount) {
		this.vhRecordCount = vhRecordCount;
	}



	public Integer getVendorEmployeeCount() {
		return vendorEmployeeCount;
	}



	public void setVendorEmployeeCount(Integer vendorEmployeeCount) {
		this.vendorEmployeeCount = vendorEmployeeCount;
	}



	public Integer getVendorMemberCount() {
		return vendorMemberCount;
	}



	public void setVendorMemberCount(Integer vendorMemberCount) {
		this.vendorMemberCount = vendorMemberCount;
	}



	public Integer getVendorRecordCount() {
		return vendorRecordCount;
	}



	public void setVendorRecordCount(Integer vendorRecordCount) {
		this.vendorRecordCount = vendorRecordCount;
	}



	public Integer getVarEmployeeCount() {
		return varEmployeeCount;
	}



	public void setVarEmployeeCount(Integer varEmployeeCount) {
		this.varEmployeeCount = varEmployeeCount;
	}



	public Integer getVarMemberCount() {
		return varMemberCount;
	}



	public void setVarMemberCount(Integer varMemberCount) {
		this.varMemberCount = varMemberCount;
	}



	public Integer getVarRecordCount() {
		return varRecordCount;
	}



	public void setVarRecordCount(Integer varRecordCount) {
		this.varRecordCount = varRecordCount;
	}



	private Date dataFileDate=null,ctlFileDate=null;
	private Integer dataLayoutID=null, ctlLayoutID=null;
	

	private Double vhBilledAmount=null, vhAllowedAmount=null, vhPaidAmount=null,
			vhEmployeeAmount=null;
	private Double vendorBilledAmount=null, vendorAllowedAmount=null, vendorPaidAmount=null,
			vendorEmployeeAmount=null;
	private Double varBilledAmount=null, varAllowedAmount=null, varPaidAmount=null,
			varEmployeeAmount=null;
	private Integer vhEmployeeCount=null, vhMemberCount=null, vhRecordCount=null;
	private Integer vendorEmployeeCount=null, vendorMemberCount=null, vendorRecordCount=null;

	

	private Integer varEmployeeCount=null, varMemberCount=null, varRecordCount=null;
}
