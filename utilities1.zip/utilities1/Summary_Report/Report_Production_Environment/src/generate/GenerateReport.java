package generate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import model.HistoryModel;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import excelGenerator.ListOfListToExcel;

import reportDAO.GeneralDAO;

public class GenerateReport {
	public static String query = "";
	public static boolean clientFlag = false;
	public static String maskingQuery = "       CASE WHEN  flval IS NULL THEN 'BLANKNULL'  ELSE 'INCORRECT FORMAT' END AS \n        SOURCE_VALUE, \n";

	public static void main(String[] args) {
		String clientSubQuery = "";
		String importServerSubQuery = "";
		String removeManualDataString = " and Upper(INFO1)  NOT LIKE '%MANUALLY%' ";
		Options options = new Options();
		options.addOption("e", true, "<Start Time> [Eg: 20141020 00:01:00]");
		options.addOption("s", true, "<End Time> [Eg: 20141020 00:01:00]");
		options.addOption("o", true,
				"<Directory> [Eg: /data1/AIP/sample.xlsx ]");
		options.addOption("c", true,
				"<Client Id> [Enclose With single Quotation Mark]");
		options.addOption("f", false, "[Client Specific Filter]");
		options.addOption("m", false, "[Manual Flag]");
		options.addOption("i", true, "Import Server Filter");
		options.addOption("n", false, "No Masking");
		options.addOption("t", true, "<Connect String>");
		options.addOption("u", true, "<SCHEMA/USER>");
		options.addOption("p", true, "<Password>");
		if (args.length < 6) {
			usage(options);
			return;
		}

		CommandLineParser parser = new BasicParser();
		CommandLine cmd;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException pe) {
			System.out.println(pe);
			usage(options);
			return;
		}
		if (!cmd.hasOption("t") || !cmd.hasOption("u") || !cmd.hasOption("p")) {
			usage(options);
			System.exit(1);
		} else {
			GeneralDAO.connectString = (cmd.getOptionValue('t'));
			GeneralDAO.user = (cmd.getOptionValue('u'));
			GeneralDAO.pass = (cmd.getOptionValue('p'));
		}

		String startTime = "";
		String endTime = "";
		String outputPath = "";
		String clientId = "";

		if (cmd.hasOption("e")) {
			endTime = (cmd.getOptionValue('e'));
			ListOfListToExcel.eDate = endTime;
			// 20141020 00:01:00
		}
		if (cmd.hasOption("i")) {
			importServerSubQuery = "       AND UPPER(executed_from) LIKE '%"
					+ cmd.getOptionValue('i').toUpperCase() + "%' ";
		}
		if (cmd.hasOption("f")) {
			if (!cmd.hasOption("c")) {
				usage(options);
				System.exit(1);
			} else if (cmd.getOptionValue("c").contains(",")) {
				usage(options);
				System.exit(1);
			} else {
				clientFlag = true;
			}
		}

		if (cmd.hasOption('m')) {
			removeManualDataString = "";
		}

		if (cmd.hasOption("s")) {

			startTime = (cmd.getOptionValue('s'));
			ListOfListToExcel.sDate = startTime;
			// 20141021 00:01:00
		}

		if (cmd.hasOption("o")) {

			outputPath = (cmd.getOptionValue('o'));

		}
		if (cmd.hasOption("c")) {
			clientId = (cmd.getOptionValue('c'));
			clientSubQuery = " and Client_ID in (" + clientId + ") ";
		}

		if (startTime.equals("") || endTime.equals("") || outputPath.equals("")) {
			usage(options);
			System.exit(1);
		}
		if (cmd.hasOption("n")) {

			maskingQuery = "		  Nvl(flval,'BLANKNULL') SOURCE_VALUE, \n";
		}

		String importSummaryQuery = ""
				+ "SELECT Client_ID as \"Client ID\", "
				+ "       Client_Name as \"Client Name\", "
				+ "       Data_Manager_ID as \"Data Manager ID\", "
				+ "       File_Name as \"File Name\", "
				+ "       AIP_Layout_Id as \"AIP Layout Id\", "
				+ "       Payor, "
				+ "       File_Data_Type as \"File Data Type\", "
				+ "       File_Size as \"File Size (MB)\", "
				+ "       Raw_Record_Count as \"Raw Record Count\", "
				+ "       Imported_Count as \"Imported Count\", "
				+ "       To_NUMBER(nvl(Raw_Record_Count,0))-To_NUMBER(nvl(Imported_Count,0)) as Variance, "
				+ "       LAYOUT_DETAIL as \"#Fields/Length\", "
				+ "       TO_Char(File_Date,'yyyy-mm-dd hh24:mi:ss') as \"File Date\", "
				+ "       Process_Information as \"Process Information\", "
				+ "       Process_Time as \"Process Time\", "
				+ "       EXCEPTION_DETAILS as \"Exception Details\", "
				+ "       ord, category_name " + "FROM   aip_import_summary_view "
				+ "		  WHERE  processdate >= "
				+ "              To_date('" + startTime
				+ "', 'YYYY-MM-DD HH24:MI:SS') "
				+ "       AND processdate < "
				+ "           To_date('" + endTime
				+ "', 'YYYY-MM-DD HH24:MI:SS') " + importServerSubQuery
				+ removeManualDataString + clientSubQuery;
		/* ---------------------------------------------------------------------------------------------
		String dataValueQuery = ""
				+ "SELECT dmfileid, \n"
				+ "       filename, \n"
				+ "       AIP_LAYOUT_ID, \n"
				+ "       data_type, \n"
				+ "       field_name, \n"
				+ "       checktype, \n"
				+ "       checkdetail, \n"
				+ "       result \n"
				+ "FROM   (SELECT b.dmfileid, \n"
				+ "               b.filename, \n"
				+ "               Nvl(b.layoutid,0)                    AS AIP_LAYOUT_ID, \n"
				+ "               b.datatype                           AS DATA_TYPE, \n"
				+ "               a.fieldname                          AS FIELD_NAME, \n"
				+ "               a.checktype, \n"
				+ "               a.checkdetail, \n"
				+ "               a.result, \n"
				+ "               Exception_check(checkdetail, result) AS a, \n"
				+ "               CASE \n"
				+ "                 WHEN a.checktype IN ( 'COLSUM', 'COLSUMFIXED' ) \n"
				+ "                      AND result = 0.00 THEN 1 \n"
				+ "                 WHEN a.checktype IN ( 'CHKVAL', 'CHKVALFIXED' ) \n"
				+ "                      AND Exception_check(a.checkdetail, a.result) = 1 THEN 1 \n"
				+ "               END                                  AS excep \n"
				+ "        FROM   imp_file_stats_log a \n"
				+ "               join imp_main_log b \n"
				+ "                 ON a.fileid = b.fileid \n"
				+ "                               ||'_' \n"
				+ "                               ||b.dmfileid \n"
				+ "                    AND b.clientid = "
				+ clientId
				+ "					   AND b.endtime>=To_Date('"
				+ startTime
				+ "','YYYY-MM-DD HH24:MI:SS')	\n"
				+ "			           AND b.endtime<To_Date('"
				+ endTime
				+ "','YYYY-MM-DD HH24:MI:SS') \n"
				+ "					   AND  a.checktype IN ( 'COLSUM', 'COLSUMFIXED','CHKVAL','CHKVALFIXED','CHKDATE' )  	\n"
				+ "   	   ) \n"
				// + "WHERE  excep = 1 "
				+ "ORDER  BY dmfileid, " + "          field_name";
		//----------------------------------------------------------------------------   */
		 /* ------------------------------------------------------------
		
		String numberExceptionQuery = ""
				+ "SELECT b.dmfileid                                     AS DMFILEID, \n"
				+ "       b.filename                                     DATA_SOURCE, \n"
				+ "       Nvl(b.layoutid,0)                              AS AIP_LAYOUT_ID, \n"
				+ "       aitablename                               	 AS TABLENAME, \n"
				+ "       b.datatype                                     DATA_TYPE, \n"
				+ "       c.payor, \n"
				+ "       Upper(a.colname)                               FIELD_NAME, \n"
				+ "       a.dataformat                                   LAYOUT_FORMAT, \n"
				+ maskingQuery
				+ "       a.rc                                           VALUE_COUNT, \n"
				+ "       RECORDCOUNT AS TOTAL_COUNT\n"
				+ "FROM   (SELECT e.*, \n"
				+ "               f.fileid, \n"
				+ "               f.layoutid, \n"
				+ "               f.sublayoutid \n"
				+ "        FROM   rpt_chk_date_number e, \n"
				+ "               rpt_main_log f \n"
				+ "        WHERE  e.sn = f.sn \n"
				+ "               AND reporttype = 'DTE_NUM_CHK') a, \n"
				+ "       imp_main_log b, \n"
				+ "       imp_layouts c   , imp_sub_layouts d , imp_main_det_log e \n"
				+ "WHERE  a.fileid = b.fileid \n"
				+ "                  || '_' \n"
				+ "                  || b.dmfileid \n"
				+ "       AND b.layoutid = c.layoutid \n"
				+ "       AND c.layoutid=d.layoutid \n"
				+ "       AND d.sublayoutid=a.sublayoutid \n"
				+ "       AND a.fileid=e.fileid \n"
				+ "       AND a.sublayoutid=e.sublayoutid \n"
				+ "       AND b.clientid = "
				+ clientId
				+ " \n AND"
				+ "       b.endtime >= \n"
				+ "           To_date('"
				+ startTime
				+ "', 'YYYY-MM-DD HH24:MI:SS') \n"
				+ "       AND b.endtime < \n"
				+ "           To_date('"
				+ endTime
				+ "', 'YYYY-MM-DD HH24:MI:SS') \n"
				+ "ORDER  BY a.fileid, \n"
				+ "          flval, " + "          rc";
		// ------------------------------------------------------------- */
		
		String unhandledException = ""
				+ "SELECT Client_ID, "
				+ "       Client_Name, "
				+ "       Data_Manager_ID, "
				+ "       File_Name, "
				+ "         AIP_Layout_Id, "
				+ "       Payor, "
				+ "       File_Data_Type, "
				+ "       File_Size as \"File Size (MB)\", "
				+ "       Raw_Record_Count, "
				+ "       Imported_Count, "
				+ "       LAYOUT_DETAIL, "
				+ "       TO_Char(File_Date,'yyyy-mm-dd hh24:mi:ss') as File_Date, "
				+ "       Process_Information, "
				+ "       Process_Time, "
				+ "       EXCEPTION_DETAILS, "
				+ "       ord "
				+ "FROM   aip_import_summary_view "
				+ "WHERE  processdate < "
				+ "              To_date('"
				+ startTime
				+ "', 'YYYY-MM-DD HH24:MI:SS') "
				+ " AND   processdate > To_date('"
				+ startTime
				+ "', 'YYYY-MM-DD HH24:MI:SS')-90 "
				+ importServerSubQuery
				+ removeManualDataString
				+ clientSubQuery
				+ " and ord=1 ";
		
		String dataProfilerStatusQuery = ""
				+ "SELECT a.fileid         AS \"AIP File ID\", "
				+ "       a.dmfileid, "
				+ "       vi.file_name     AS FileName, "
				+ "       vi.aip_layout_id AS \"AIP Layout ID\", "
				+ "		  vi.Payor,"
				+ "       a.no_of_checks, "
				+ "       CASE "
				+ "         WHEN a.current_status = 'COMPLETED SUCCESSFULLY' "
				+ "              AND a.overall_profiling_status = 'FILE CHECKS FAILED' THEN "
				+ "         'FAILED' "
				+ "         WHEN a.current_status = 'EXCEPTION' THEN 'EXCEPTION' "
				+ "         WHEN a.current_status = 'RUNNING' THEN 'RUNNING' "
				+ "         WHEN a.overall_profiling_status = 'ALL CHECKS PASSED (WITH NO CHECKS)' "
				+ "       THEN "
				+ "         'PASSED(WITH NO CHECKS)' "
				+ "         ELSE 'PASSED' "
				+ "       END              AS \"Data Profiler Status\" "
				+ "FROM   (SELECT * "
				+ "        FROM   aip_import_summary_view vi "
				+ "        WHERE  vi.processdate >= To_date('"+startTime+"', "
				+ "                             '	  YYYY-MM-DD HH24:MI:SS') "
				+ "               AND vi.processdate < To_date('"+endTime+"', "
				+ "                                'YYYY-MM-DD HH24:MI:SS') "
				//+ "               AND Upper(vi.info1) NOT LIKE '%MANUALLY%' "
				+ removeManualDataString
				+clientSubQuery
				//+ "               AND vi.client_id = '759' "
				+ "               AND vi.fileid IS NOT NULL "
				+ "               AND vi.PROCESSSTATUS='IMPORTED' AND   vi.CATEGORY_NAME ='DATAFILE') vi "
				+ "       left join (SELECT * "
				+ "                  FROM   (SELECT log_sn, "
				+ "                                 fileid, "
				+ "                                 dmfileid, "
				+ "                                 current_status, "
				+ "                                 overall_profiling_status, "
				+ "                                 Row_number() "
				+ "                                   over( "
				+ "                                     PARTITION BY fileid "
				+ "                                     ORDER BY log_sn DESC)rn "
				+ "                          FROM   dp_rpt_main_log) a "
				+ "                         left join (SELECT log_sn, "
				+ "                                           Count(*) no_of_checks "
				+ "                                    FROM   dp_rpt_detail_log "
				+ "                                    GROUP  BY log_sn) b "
				+ "                                ON a.log_sn = b.log_sn "
				+ "                  WHERE  a.rn = 1) a "
				+ "              ON a.fileid = vi.fileid";
		
		String sumationQuery = "SELECT\n"
				+	" fn_get_readable_Count(Count(Data_Manager_ID))||'|'||  \n" 
				+	" fn_get_readable_Count(count(CASE WHEN SUMMARY_STATUS ='IMPORTED' then 1 END))|| \n"
				+	" '@'||FN_get_Readable_size(sum(CASE WHEN SUMMARY_STATUS ='IMPORTED' then Nvl(File_Size,0) END  ))||'@'||fn_get_readable_Time(sum(CASE WHEN SUMMARY_STATUS ='IMPORTED' then Nvl(Process_Time,0) END  )) || '|'|| \n"
				+	" fn_get_readable_Count(count(CASE WHEN SUMMARY_STATUS ='UNKNOWN' then 1 END))|| \n"
				+	" '@'||FN_get_Readable_size(sum(CASE WHEN SUMMARY_STATUS ='UNKNOWN' THEN  Nvl(File_Size,0) END  ))||'@'||fn_get_readable_Time(sum(CASE WHEN SUMMARY_STATUS ='UNKNOWN' THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+	" fn_get_readable_Count(count(CASE WHEN SUMMARY_STATUS = 'CONTROL' then 1 END))|| \n"
				+	" '@'||FN_get_Readable_size(sum(CASE WHEN SUMMARY_STATUS = 'CONTROL'  THEN  Nvl(File_Size,0) END  ))||'@'||fn_get_readable_Time(sum(CASE WHEN SUMMARY_STATUS = 'CONTROL'  THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+	" fn_get_readable_Count(count(CASE WHEN SUMMARY_STATUS ='EXCEPTIONS'  then 1 END))|| \n"
				+	" '@'||FN_get_Readable_size(sum(CASE WHEN SUMMARY_STATUS = 'EXCEPTIONS' THEN  Nvl(File_Size,0) END  ))||'@'||fn_get_readable_Time(sum(CASE WHEN  SUMMARY_STATUS = 'EXCEPTIONS'   THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+	" fn_get_readable_Count(count(CASE WHEN SUMMARY_STATUS ='UNPROCESSED' then 1 END))|| \n"
				+	" '@'||FN_get_Readable_size(sum(CASE WHEN SUMMARY_STATUS ='UNPROCESSED' THEN  Nvl(File_Size,0) END  ))||'@'||fn_get_readable_Time(sum(CASE WHEN SUMMARY_STATUS ='UNPROCESSED' THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+	" fn_get_readable_Count(count(CASE WHEN SUMMARY_STATUS ='DONOTUSE' then 1 END))|| \n"
				+	" '@'||FN_get_Readable_size(sum(CASE WHEN SUMMARY_STATUS ='DONOTUSE' THEN  Nvl(File_Size,0) END  ))||'@'||fn_get_readable_Time(sum(CASE WHEN SUMMARY_STATUS ='DONOTUSE' THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+	" fn_get_readable_Count(Count(DISTINCT Client_ID) )||'|'|| \n"
				+	" fn_get_readable_Count(sum(CASE WHEN summary_status ='IMPORTED' then Nvl(Imported_Count,0) END  ))||'|'|| \n"
				+	" fn_get_readable_Time(nvl(sum( Process_Time),0))   AS concatinated_Output \n"
				+ 	"	 FROM  \n "
				+	" ( SELECT CASE WHEN CATEGORY_NAME='CONTROLTOTAL' THEN 'CONTROL' WHEN processstatus IN ('MANUAL SUBMITTED EXCEPTIONS','RUNNING','MANUAL SUBMITTED EXCEPTIONS') THEN 'UNKNOWN' ELSE PROCESSSTATUS END AS summary_status,  a.*  FROM aip_import_summary_view a ) \n"
				+ 	"	WHERE  processdate >= " + "\n"
				+ 	"              To_date('" + startTime+"', 'YYYY-MM-DD HH24:MI:SS') " + "\n"
				+ 	"       AND processdate < "
				+ 	"\n" + "           To_date('" + endTime+"', 'YYYY-MM-DD HH24:MI:SS') " + "\n" + importServerSubQuery
				+ 	"\n" + removeManualDataString + "\n" + clientSubQuery + "\n"
				+ 	"  ";
		
		GeneralDAO.initializeConnection();
		SimpleDateFormat reportDateFormat = new SimpleDateFormat("yyyyMMdd");
		
		String beginDate = null;
		try {
			Date currentDay = convertToDate(endTime);
			Calendar cal = Calendar.getInstance();
			cal.setTime(currentDay);
			cal.add(Calendar.DAY_OF_MONTH, -15);
			beginDate = reportDateFormat.format(cal.getTime());
		} catch (Exception e) {
			System.err.println("The Given Date Cannot be parsed");
			System.exit(1);
		}

		String summaryHistoryQuery = "SELECT\n"
				+ " Count(Data_Manager_ID)||'|'||  \n" 
				+ " count(CASE WHEN SUMMARY_STATUS ='IMPORTED' then 1 END)|| \n"
				+ " '@'||sum(CASE WHEN SUMMARY_STATUS ='IMPORTED' then Nvl(File_Size,0) END  )||'@'||sum(CASE WHEN SUMMARY_STATUS ='IMPORTED' then Nvl(Process_Time,0) END  ) || '|'|| \n"
				+ " count(CASE WHEN SUMMARY_STATUS ='UNKNOWN' then 1 END)|| \n"
				+ " '@'||sum(CASE WHEN SUMMARY_STATUS ='UNKNOWN' THEN  Nvl(File_Size,0) END  )||'@'||sum(CASE WHEN SUMMARY_STATUS ='UNKNOWN' THEN  Nvl(Process_Time,0) END  ) ||'|'|| \n"
				+ " (count(CASE WHEN SUMMARY_STATUS = 'CONTROL' then 1 END))|| \n"
				+ " '@'||(sum(CASE WHEN SUMMARY_STATUS = 'CONTROL'  THEN  Nvl(File_Size,0) END  ))||'@'||(sum(CASE WHEN SUMMARY_STATUS = 'CONTROL'  THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+ " (count(CASE WHEN SUMMARY_STATUS ='EXCEPTIONS'  then 1 END))|| \n"
				+ " '@'||(sum(CASE WHEN SUMMARY_STATUS = 'EXCEPTIONS' THEN  Nvl(File_Size,0) END  ))||'@'||(sum(CASE WHEN  SUMMARY_STATUS = 'EXCEPTIONS'   THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+ " (count(CASE WHEN SUMMARY_STATUS ='UNPROCESSED' then 1 END))|| \n"
				+ " '@'||(sum(CASE WHEN SUMMARY_STATUS ='UNPROCESSED' THEN  Nvl(File_Size,0) END  ))||'@'||(sum(CASE WHEN SUMMARY_STATUS ='UNPROCESSED' THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+ " (count(CASE WHEN SUMMARY_STATUS ='DONOTUSE' then 1 END))|| \n"
				+ " '@'||(sum(CASE WHEN SUMMARY_STATUS ='DONOTUSE' THEN  Nvl(File_Size,0) END  ))||'@'||(sum(CASE WHEN SUMMARY_STATUS ='DONOTUSE' THEN  Nvl(Process_Time,0) END  )) ||'|'|| \n"
				+ " (Count(DISTINCT Client_ID) )||'|'|| \n"
				+ " (sum(CASE WHEN summary_status ='IMPORTED' then Nvl(Imported_Count,0) END  ))||'|'|| \n"
				+ " (nvl(sum( Process_Time),0))||'|'||Count(DISTINCT Payor)   AS concatinated_Output, \n"
				+ " shorttime \n" + " FROM\n" 
				+	" ( SELECT To_Char(processdate,'yyyy-MM-dd')  AS SHORTTIME, CASE WHEN CATEGORY_NAME='CONTROLTOTAL' THEN 'CONTROL' WHEN processstatus IN ('MANUAL SUBMITTED EXCEPTIONS','RUNNING','MANUAL SUBMITTED EXCEPTIONS') THEN 'UNKNOWN' ELSE PROCESSSTATUS END AS summary_status,  a.*  FROM aip_import_summary_view a ) \n"
				+ "WHERE  processdate > " + "\n"
				+ "              To_date('" + beginDate + "', 'YYYY-MM-DD') "
				+ "\n"
				+ "       AND processdate <= "
				+ "\n" + "           To_date('" + endTime.substring(0, 8)
				+ "', 'YYYYMMDD') " + "\n" + importServerSubQuery + "\n"
				+ removeManualDataString + "\n" + clientSubQuery + "\n"
				+ "  GROUP BY shorttime     ORDER BY 2 DESC";
		List<List<String>> dailySummaryHistoryList = GeneralDAO
				.getListOfList(summaryHistoryQuery);
		ListOfListToExcel.location = outputPath;
		ListOfListToExcel.listOfList = GeneralDAO
				.getListOfList(importSummaryQuery);

		if (clientFlag == true) {
			/*ListOfListToExcel.dataValueList = GeneralDAO
					.getListOfList(dataValueQuery);
			ListOfListToExcel.thirdList = GeneralDAO
					.getListOfList(numberExceptionQuery);*/
			ListOfListToExcel.dpStatusList=GeneralDAO
			.getListOfList(dataProfilerStatusQuery);
			ListOfListToExcel.fourthList = GeneralDAO
					.getListOfList(unhandledException);
		}
		
		List<List<String>> summationResult = GeneralDAO
				.getListOfList(sumationQuery);

		List<HistoryModel> historyData = new ArrayList<HistoryModel>();
		if (dailySummaryHistoryList != null) {
			if (dailySummaryHistoryList.size() > 1) {
				for (int i = 1; i < dailySummaryHistoryList.size(); i++) {
					HistoryModel model = new HistoryModel();
					model.setDate(convertToDate(dailySummaryHistoryList.get(i)
							.get(1)));
					model.setNoOfClients(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[7]));
					model.setNoOfPayors(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[10]));
					model.setTotalFilesReceived(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[0]));
					model.setImportedCount(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[1].split("@", -1)[0]));
					model.setUnknownCount(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[2].split("@", -1)[0]));
					model.setControlCount(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[3].split("@", -1)[0]));
					model.setExceptionsCount(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[4].split("@", -1)[0]));
					model.setUnprocessedCount(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[5].split("@", -1)[0]));
					model.setDoNotUseCount(convertToInteger(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[6].split("@", -1)[0]));
					model.setTotalSize(convertToDouble(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[1].split("@", -1)[1])
							/ (1024 * 1024));
					model.setProcessingTime(convertToDouble(dailySummaryHistoryList
							.get(i).get(0).split("\\|", -1)[9]));
					historyData.add(model);
				}
				ListOfListToExcel.summaryHistoryList = historyData;
			}
		}
		

		GeneralDAO.closeAll();

		ListOfListToExcel.listOfListToXLSX();
		if (summationResult.size() > 1) {
			System.out.println(summationResult.get(1).get(0));
		}
	}

	private static void usage(Options options) {
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("ReportGenerator", options);
	}

	public static double convertToDouble(String s) {
		try {
			return Double.parseDouble(s);
		} catch (Exception e) {
			return 0;
		}
	}

	public static int convertToInteger(String i) {
		try {
			return Integer.parseInt(i);
		} catch (Exception e) {
			return 0;
		}
	}

	public static Date convertToDate(String date) {

		SimpleDateFormat queryResultDateFormat;
		if (date.contains("-")) {
			queryResultDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		} else {
			queryResultDateFormat = new SimpleDateFormat("yyyyMMdd");
		}
		try {
			return queryResultDateFormat.parse(date);
		} catch (Exception e) {
			return null;
		}
	}

	public static Date convertControlTotalReconDate(String date) {

		SimpleDateFormat queryResultDateFormat;
		queryResultDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		try {
			return queryResultDateFormat.parse(date);
		} catch (Exception e) {
			return null;
		}
	}
}
