package generate;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class ReadAndSourceVariables {
	
	public static String configFileLocation="O:/AIP-aypokhrel/Report_Config.properties";
	public static void sourceAllVariables() {

		Properties prop = new Properties();
		InputStream input = null;

		try {	
			File file = new File(configFileLocation);
			if (!file.exists()) {
				System.err.println("Configuration File Does Not Exist");
			}
			
			input = new FileInputStream(file);

			prop.load(input);

			System.out.println(prop.getProperty("query"));
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
	public static void main(String[] args){
		sourceAllVariables();
	}
}
