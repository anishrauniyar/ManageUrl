package excelGenerator;

import java.awt.Color;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import model.ControlReconModel;
import model.HistoryModel;

import org.apache.poi.ss.usermodel.DataConsolidateFunction;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFPivotTable;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ListOfListToExcel {
	public static ArrayList<String[]> rowList = new ArrayList<String[]>();
	public static String location = "";
	public static List<List<String>> listOfList = null;
	public static List<List<String>> dataValueList = null;
	public static List<List<String>> thirdList = null;
	public static List<List<String>> dpStatusList = null;
	public static List<List<String>> fourthList = null;
	public static String sDate;
	public static String eDate;
	public static Font coloredFont;
	public static List<HistoryModel> summaryHistoryList = null;
	public static List<ControlReconModel> controlReconDataList = null;

	public static XSSFCellStyle changeFontColourOfStyle(
			XSSFCellStyle cellstyle, XSSFWorkbook workbook) {
		XSSFCellStyle tempstyle = workbook.createCellStyle();
		tempstyle.cloneStyleFrom(cellstyle);
		tempstyle.setFont(coloredFont);
		tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		return tempstyle;
	}

	public static XSSFCellStyle wrapTextStyle(XSSFCellStyle cellstyle,
			XSSFWorkbook workbook) {
		XSSFCellStyle tempstyle = workbook.createCellStyle();
		tempstyle.cloneStyleFrom(cellstyle);
		tempstyle.setWrapText(true);
		tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		return tempstyle;
	}

	public static XSSFCellStyle alternateColoursStyle(XSSFCellStyle cellstyle,
			int arg, XSSFWorkbook workbook) {
		// XSSFColor dimColor = new XSSFColor(new java.awt.Color(0,0,0f));
		XSSFCellStyle tempstyle = workbook.createCellStyle();
		tempstyle.cloneStyleFrom(cellstyle);
		tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		if (arg % 2 == 0) {
			tempstyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(
					245, 245, 245)));
		} else {
			tempstyle.setFillForegroundColor(IndexedColors.WHITE.index);

		}
		tempstyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		return tempstyle;
	}

	public static void setValueOfCell(XSSFCell cell, Integer value) {
		if (value == null) {
			cell.setCellValue("");
		} else
			cell.setCellValue(value);
	}

	public static void setValueOfCell(XSSFCell cell, Date value) {
		if (value == null) {
			cell.setCellValue("");
		} else
			cell.setCellValue(value);
	}

	public static void setValueOfCell(XSSFCell cell, Double value) {
		if (value == null) {
			cell.setCellValue("");
		} else
			cell.setCellValue(value);
	}

	public static void listOfListToXLSX() {
		try {
			String xlsxFileAddress = location;
			Class.forName("org.apache.poi.xssf.usermodel.XSSFWorkbook");
			XSSFWorkbook workBook = new XSSFWorkbook();

			// STYLES DEFINITION ---------------------------------
			XSSFCellStyle tableHeadingStyle = workBook.createCellStyle(); // FOR
																			// TABLE
																			// HEADING
			XSSFCellStyle borderOnlyStyle = workBook.createCellStyle(); // FOR
																		// EACH
			// CELL
			XSSFCellStyle headingCellStyle = workBook.createCellStyle();
			XSSFCellStyle titleStyle = workBook.createCellStyle();
			XSSFCellStyle numberCellStyle = workBook.createCellStyle();
			XSSFCellStyle currencyStyle = workBook.createCellStyle();
			XSSFCellStyle layoutIdStyle = workBook.createCellStyle();
			XSSFCellStyle varianceStyle = workBook.createCellStyle();
			XSSFCellStyle veriskStyle = workBook.createCellStyle();
			XSSFCellStyle vendorStyle = workBook.createCellStyle();
			XSSFCellStyle numberCellColouredStyle = workBook.createCellStyle();
			XSSFCellStyle specificCellStyle = workBook.createCellStyle();
			specificCellStyle
					.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			numberCellColouredStyle
					.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);

			XSSFCellStyle dateStyle = workBook.createCellStyle();
			XSSFCellStyle floatStyle = workBook.createCellStyle();
			XSSFCellStyle dateCellStyle = workBook.createCellStyle();
			// ----------------------------------------------------
			dateStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			floatStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			layoutIdStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			numberCellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			dateCellStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			borderOnlyStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			// FONT -------------------------------------------------
			Font tableHeadingFont = workBook.createFont(); // FOR TABLE HEADING
			Font titleFont = workBook.createFont();
			tableHeadingFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			titleFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			titleFont.setColor(IndexedColors.BLACK.index);
			tableHeadingFont.setColor(IndexedColors.BLACK.index);
			coloredFont = workBook.createFont();
			coloredFont.setColor(IndexedColors.RED.index);

			Font headingFont = workBook.createFont();
			headingFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			headingFont.setFontHeightInPoints((short) 15);
			headingCellStyle.setFont(headingFont);
			titleStyle.setFont(titleFont);
			titleStyle.setFillForegroundColor(new XSSFColor(new Color(219, 229,
					241)));
			titleStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			titleStyle.setAlignment(XSSFCellStyle.ALIGN_LEFT);
			titleStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			titleStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			titleStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			titleStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			headingCellStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			// -----------------------------------------------------
			Font specificFont = workBook.createFont();
			Font normalFont = workBook.createFont();
			specificFont.setColor(IndexedColors.RED.index);
			specificFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			normalFont.setColor(IndexedColors.BLACK.index);
			// STYLES ------------------------------------------------------
			veriskStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			veriskStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			veriskStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			veriskStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			veriskStyle.setFont(titleFont);
			veriskStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			veriskStyle.setFillForegroundColor(new XSSFColor(new Color(120,
					152, 194)));
			veriskStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);

			vendorStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			vendorStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			vendorStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			vendorStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			vendorStyle.setFont(titleFont);
			vendorStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			vendorStyle.setFillForegroundColor(new XSSFColor(new Color(191,
					219, 255)));
			vendorStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);

			varianceStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			varianceStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			varianceStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			varianceStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			varianceStyle.setFont(titleFont);
			varianceStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			varianceStyle.setFillForegroundColor(new XSSFColor(new Color(153,
					186, 248)));
			varianceStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);

			tableHeadingStyle.setFont(tableHeadingFont);
			tableHeadingStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			tableHeadingStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
			tableHeadingStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
			tableHeadingStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
			tableHeadingStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
			tableHeadingStyle.setFillForegroundColor(new XSSFColor(new Color(
					219, 229, 241)));
			tableHeadingStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			borderOnlyStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			borderOnlyStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			borderOnlyStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			borderOnlyStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			borderOnlyStyle.setFont(normalFont);
			numberCellStyle = borderOnlyStyle;
			layoutIdStyle = borderOnlyStyle;
			// specificCellStyle=borderOnlyStyle;
			specificCellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			specificCellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			specificCellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			specificCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			specificCellStyle.setFont(specificFont);
			numberCellColouredStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			numberCellColouredStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			numberCellColouredStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			numberCellColouredStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			numberCellColouredStyle.setFont(specificFont);

			numberCellColouredStyle.setDataFormat(workBook.createDataFormat()
					.getFormat("#,##0"));
			numberCellStyle.setDataFormat(workBook.createDataFormat()
					.getFormat("#,##0"));
			layoutIdStyle.setDataFormat(workBook.createDataFormat().getFormat(
					"###0"));
			dateStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			dateStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			dateStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			dateStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			dateStyle.setDataFormat(workBook.createDataFormat().getFormat(
					"yyyy-mm-dd hh:mm:ss"));
			dateCellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			dateCellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			dateCellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			dateCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			dateCellStyle.setDataFormat(workBook.createDataFormat().getFormat(
					"d-mmm"));
			dateCellStyle.setFillForegroundColor(new XSSFColor(new Color(219,
					229, 241)));
			dateCellStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			dateCellStyle.setFont(titleFont);
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyy-MM-dd hh:mm:ss");
			// 2014-09-14 13:23:41
			floatStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			floatStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			floatStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			floatStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			floatStyle.setDataFormat(workBook.createDataFormat().getFormat(
					"0.#0"));

			//
			currencyStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
			currencyStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
			currencyStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
			currencyStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
			currencyStyle.setDataFormat(workBook.createDataFormat().getFormat(
					"$0.#0"));
			// ---------------------------------------------------------------
			// Imported Successfully 11 FileSizze 6

			XSSFSheet summarySheet = workBook.createSheet("Count Summary");
			// summarySheet.setDisplayGridlines(false);
			// ------------------------------------SUMMARY
			// SHEET-----------------------------

			XSSFRow titleRowSummarySheet = summarySheet.createRow(0);
			XSSFCell titleRowSummarySheetCell = titleRowSummarySheet
					.createCell(0);
			titleRowSummarySheetCell.setCellStyle(titleStyle);
			titleRowSummarySheetCell.setCellValue("Date");
			XSSFRow clientsRowSummarySheet = summarySheet.createRow(1);
			XSSFCell clientsRowSummarySheetCell = clientsRowSummarySheet
					.createCell(0);
			clientsRowSummarySheetCell.setCellStyle(titleStyle);
			clientsRowSummarySheetCell.setCellValue("#Client");
			XSSFRow PayorsRowSummarySheet = summarySheet.createRow(2);
			XSSFCell PayorsRowSummarySheetCell = PayorsRowSummarySheet
					.createCell(0);
			PayorsRowSummarySheetCell.setCellStyle(titleStyle);
			PayorsRowSummarySheetCell.setCellValue("#Payors");
			XSSFRow totalFilesRowSummarySheet = summarySheet.createRow(3);
			XSSFCell totalFilesRowSummarySheetCell = totalFilesRowSummarySheet
					.createCell(0);
			totalFilesRowSummarySheetCell.setCellStyle(titleStyle);
			totalFilesRowSummarySheetCell.setCellValue("Total Files Received");
			XSSFRow importedRowSummarySheet = summarySheet.createRow(4);
			XSSFCell importedRowSummarySheetCell = importedRowSummarySheet
					.createCell(0);
			importedRowSummarySheetCell.setCellStyle(titleStyle);
			importedRowSummarySheetCell.setCellValue("#Imported Files");
			XSSFRow unknownRowSummarySheet = summarySheet.createRow(5);
			XSSFCell unknownRowSummarySheetCell = unknownRowSummarySheet
					.createCell(0);
			unknownRowSummarySheetCell.setCellStyle(titleStyle);
			unknownRowSummarySheetCell.setCellValue("#Unknown Files");
			XSSFRow controlRowSummarySheet = summarySheet.createRow(6);
			XSSFCell controlRowSummarySheetCell = controlRowSummarySheet
					.createCell(0);
			controlRowSummarySheetCell.setCellStyle(titleStyle);
			controlRowSummarySheetCell.setCellValue("#Control Total Files");
			XSSFRow exceptionRowSummarySheet = summarySheet.createRow(7);
			XSSFCell exceptionRowSummarySheetCell = exceptionRowSummarySheet
					.createCell(0);
			exceptionRowSummarySheetCell.setCellStyle(titleStyle);
			exceptionRowSummarySheetCell.setCellValue("#Exceptions");
			XSSFRow unprocessedRowSummarySheet = summarySheet.createRow(8);
			XSSFCell unprocessedRowSummarySheetCell = unprocessedRowSummarySheet
					.createCell(0);
			unprocessedRowSummarySheetCell.setCellStyle(titleStyle);
			unprocessedRowSummarySheetCell.setCellValue("#Unprocessed Files");
			XSSFRow doNotuseRowSummarySheet = summarySheet.createRow(9);
			XSSFCell doNotuseRowSummarySheetCell = doNotuseRowSummarySheet
					.createCell(0);
			doNotuseRowSummarySheetCell.setCellStyle(titleStyle);
			doNotuseRowSummarySheetCell.setCellValue("#Do Not Use Files");
			XSSFRow importedSizeRowSummarySheet = summarySheet.createRow(10);
			XSSFCell importedSizeRowSummarySheetCell = importedSizeRowSummarySheet
					.createCell(0);
			importedSizeRowSummarySheetCell.setCellStyle(titleStyle);
			importedSizeRowSummarySheetCell.setCellValue("Imported Size(MB)");
			XSSFRow processingTimeRowSummarySheet = summarySheet.createRow(11);
			XSSFCell processingTimeRowSummarySheetCell = processingTimeRowSummarySheet
					.createCell(0);
			processingTimeRowSummarySheetCell.setCellStyle(titleStyle);
			processingTimeRowSummarySheetCell
					.setCellValue("Processing Time(Minutes)");
			if (summaryHistoryList != null) {
				for (int k = 1; k <= summaryHistoryList.size(); k++) {
					XSSFCell dayCell = titleRowSummarySheet.createCell(k);
					dayCell.setCellStyle(dateCellStyle);

					dayCell.setCellValue(summaryHistoryList.get(k - 1)
							.getDate());

					//
					XSSFCell clientCell = clientsRowSummarySheet.createCell(k);
					clientCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					clientCell.setCellValue(summaryHistoryList.get(k - 1)
							.getNoOfClients());
					//
					XSSFCell payorCell = PayorsRowSummarySheet.createCell(k);
					payorCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					payorCell.setCellValue(summaryHistoryList.get(k - 1)
							.getNoOfPayors());
					//
					XSSFCell totalFielsCell = totalFilesRowSummarySheet
							.createCell(k);
					totalFielsCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					totalFielsCell.setCellValue(summaryHistoryList.get(k - 1)
							.getTotalFilesReceived());
					//
					XSSFCell importedCell = importedRowSummarySheet
							.createCell(k);
					importedCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					importedCell.setCellValue(summaryHistoryList.get(k - 1)
							.getImportedCount());
					//
					XSSFCell unknownCell = unknownRowSummarySheet.createCell(k);
					unknownCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					unknownCell.setCellValue(summaryHistoryList.get(k - 1)
							.getUnknownCount());
					//
					XSSFCell controlCell = controlRowSummarySheet.createCell(k);
					controlCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					controlCell.setCellValue(summaryHistoryList.get(k - 1)
							.getControlCount());
					//
					XSSFCell exceptionsCell = exceptionRowSummarySheet
							.createCell(k);
					exceptionsCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					exceptionsCell.setCellValue(summaryHistoryList.get(k - 1)
							.getExceptionsCount());
					//
					XSSFCell unprocessedCell = unprocessedRowSummarySheet
							.createCell(k);
					unprocessedCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					unprocessedCell.setCellValue(summaryHistoryList.get(k - 1)
							.getUnprocessedCount());
					//
					XSSFCell doNotUseCell = doNotuseRowSummarySheet
							.createCell(k);
					doNotUseCell.setCellStyle(alternateColoursStyle(
							numberCellStyle, k, workBook));
					doNotUseCell.setCellValue(summaryHistoryList.get(k - 1)
							.getDoNotUseCount());
					//
					XSSFCell importedSizeCell = importedSizeRowSummarySheet
							.createCell(k);
					importedSizeCell.setCellStyle(alternateColoursStyle(
							floatStyle, k, workBook));
					importedSizeCell.setCellValue(summaryHistoryList.get(k - 1)
							.getTotalSize());
					//
					XSSFCell processingTimeCell = processingTimeRowSummarySheet
							.createCell(k);
					processingTimeCell.setCellStyle(alternateColoursStyle(
							floatStyle, k, workBook));
					processingTimeCell.setCellValue(summaryHistoryList.get(
							k - 1).getProcessingTime());
				}
			}
			int y = 0;
			while (y < summarySheet.getRow(0).getLastCellNum()) {
				summarySheet.setColumnWidth(y, 2550);
				y++;
			}
			summarySheet.autoSizeColumn(0);
			summarySheet.createFreezePane(1, 1);
			// ------------------------------------------------------------------------------

			XSSFSheet pivotSheet = workBook.createSheet("Exception Summary");
			pivotSheet.setDisplayGridlines(false);

			XSSFSheet successfulSheet = workBook.createSheet("Successful");
			successfulSheet.setDisplayGridlines(false);

			XSSFSheet exceptionsSheet = workBook.createSheet("Exceptions");
			exceptionsSheet.setDisplayGridlines(false);
			XSSFSheet controlSheet = workBook.createSheet("Control Totals");
			controlSheet.setDisplayGridlines(false);
			int rowNum = 0;
			int rowNumExceptionsSheet = 0;
			int rowNumControlSheet = 0;
			int columnCount = 0;

			int noOfColumns = listOfList.get(0).size();
			for (int j = 0; j < listOfList.size(); j++) {
				boolean changeColourVarainceFlag = false;
				List<String> str = listOfList.get(j);
				if ((str.get(16).contains("2")
						&& !str.get(17).toUpperCase().contains("CONTROLTOTAL")) || j == 0) {
					int percentage = 0;
					if (str.get(8) != null && str.get(10) != null
							&& str.get(8).trim() != ""
							&& str.get(10).trim() != "" && rowNum != 0) {
						int rawRecord = Integer.parseInt(str.get(8));
						int variance = Integer.parseInt(str.get(10));
						if (rawRecord != 0) {
							percentage = (variance * 100) / (rawRecord);
							if (Math.abs(percentage) > 5
									&& Math.abs(variance) > 2) {
								changeColourVarainceFlag = true;
							}
						}
					}
					int temp = str.size() - 2;
					XSSFRow currentRow = successfulSheet.createRow(rowNum);
					for (int i = 0; i < temp; i++) {
						if (rowNum == 0) {
							XSSFCell cell = currentRow.createCell(i);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							// NEW ONE
							XSSFCell cell = currentRow.createCell(i);
							if (changeColourVarainceFlag) {
								cell.setCellStyle(changeFontColourOfStyle(
										borderOnlyStyle, workBook));
							} else {
								cell.setCellStyle(borderOnlyStyle);
							}

							if (i == 7) {

								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(getSizeMBFloat(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								if (changeColourVarainceFlag) {
									cell.setCellStyle(changeFontColourOfStyle(
											floatStyle, workBook));
								} else {
									cell.setCellStyle(floatStyle);
								}
							} else if (i == 4) {
								if (changeColourVarainceFlag) {
									cell.setCellStyle(changeFontColourOfStyle(
											layoutIdStyle, workBook));
								} else {
									cell.setCellStyle(layoutIdStyle);
								}
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 8 || i == 9 || i == 10) {
								if (changeColourVarainceFlag) {
									cell.setCellStyle(changeFontColourOfStyle(
											numberCellStyle, workBook));
								} else {
									cell.setCellStyle(numberCellStyle);
								}
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 12) {
								if (str.get(i) != null && str.get(i) != "") {

									cell.setCellValue(dateFormat.parse(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								if (changeColourVarainceFlag) {
									cell.setCellStyle(changeFontColourOfStyle(
											dateStyle, workBook));
								} else {
									cell.setCellStyle(dateStyle);
								}
							} else if (i == 14) {
								if (str.get(i) != null && str.get(i) != "") {

									cell.setCellValue(Float.parseFloat(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								if (changeColourVarainceFlag) {
									cell.setCellStyle(changeFontColourOfStyle(
											floatStyle, workBook));
								} else {
									cell.setCellStyle(floatStyle);
								}
							} else if (i == temp - 1) {
								if (changeColourVarainceFlag) {
									cell.setCellStyle(changeFontColourOfStyle(
											wrapTextStyle(borderOnlyStyle,
													workBook), workBook));
								} else {
									cell.setCellStyle(wrapTextStyle(
											borderOnlyStyle, workBook));
								}
								cell.setCellValue(str.get(i));
							} else {
								cell.setCellValue(str.get(i));
							}
						}
					}
					rowNum++;
				}

			}

			for (int j = 0; j < listOfList.size(); j++) {

				List<String> str = listOfList.get(j);
				if ((str.get(16).contains("1")
						&& !str.get(17).toUpperCase().contains("CONTROLTOTAL"))
						|| j == 0) {
					XSSFRow currentRowSecondSheet = exceptionsSheet
							.createRow(rowNumExceptionsSheet);
					int m = 0;
					int temp = str.size() - 2;
					for (int i = 0; i < temp; i++) {

						if (i == 10) {
							continue;
						}

						if (rowNumExceptionsSheet == 0) {
							XSSFCell cell = currentRowSecondSheet.createCell(m);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							// NEW ONE
							XSSFCell cell = currentRowSecondSheet.createCell(m);
							cell.setCellStyle(borderOnlyStyle);

							if (i == 7) {
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(getSizeMBFloat(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}

								cell.setCellStyle(floatStyle);

							} else if (i == 4) {
								cell.setCellStyle(layoutIdStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 8 || i == 9) {
								cell.setCellStyle(numberCellStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 12) {
								cell.setCellStyle(dateStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(dateFormat.parse(str
											.get(i)));

								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 13) {
								cell.setCellStyle(wrapTextStyle(
										borderOnlyStyle, workBook));
								cell.setCellValue(str.get(i));
								// System.err.println(str.get(i));
							} else if (i == 14) {
								if (str.get(i) != null && str.get(i) != "") {

									cell.setCellValue(Float.parseFloat(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								cell.setCellStyle(floatStyle);

							} else if (i == temp - 1) {
								cell.setCellStyle(wrapTextStyle(
										borderOnlyStyle, workBook));
								cell.setCellValue(str.get(i));
							} else {
								cell.setCellValue(str.get(i));
							}

						}
						m++;
					}
					rowNumExceptionsSheet++;
				}

			}
			for (int j = 0; j < listOfList.size(); j++) {

				List<String> str = listOfList.get(j);
				if (str.get(17).toUpperCase().contains("CONTROLTOTAL")
						|| j == 0) {
					XSSFRow currentRowControlSheet = controlSheet
							.createRow(rowNumControlSheet);
					int m = 0;
					for (int i = 0; i < str.size() - 2; i++) {
						if (i == 10) {
							continue;
						}
						if (rowNumControlSheet == 0) {
							XSSFCell cell = currentRowControlSheet
									.createCell(m);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							// NEW ONE
							XSSFCell cell = currentRowControlSheet
									.createCell(m);
							cell.setCellStyle(borderOnlyStyle);

							if (i == 7) {
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(getSizeMBFloat(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}

								cell.setCellStyle(floatStyle);
							} else if (i == 4) {
								cell.setCellStyle(layoutIdStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 8 || i == 9) {
								cell.setCellStyle(numberCellStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 12) {
								cell.setCellStyle(dateStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(dateFormat.parse(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 14) {
								if (str.get(i) != null && str.get(i) != "") {

									cell.setCellValue(Float.parseFloat(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								cell.setCellStyle(floatStyle);
							} else {
								cell.setCellValue(str.get(i));
							}

						}
						m++;
					}
					rowNumControlSheet++;
				}

			}
			CellRangeAddress filterRangeSuccessful = new CellRangeAddress(0,
					successfulSheet.getLastRowNum(), 0,
					successfulSheet.getRow(successfulSheet.getLastRowNum())
							.getLastCellNum() - 1);
			CellRangeAddress filterRangeControlExce = new CellRangeAddress(0,
					exceptionsSheet.getLastRowNum(), 0,
					exceptionsSheet.getRow(exceptionsSheet.getLastRowNum())
							.getLastCellNum() - 1);

			successfulSheet.setAutoFilter(filterRangeSuccessful);
			exceptionsSheet.setAutoFilter(filterRangeControlExce);
			controlSheet.setAutoFilter(filterRangeControlExce);
			successfulSheet.createFreezePane(0, 1);
			exceptionsSheet.createFreezePane(0, 1);
			controlSheet.createFreezePane(0, 1);
			while (columnCount < successfulSheet.getRow(0).getLastCellNum() - 1) {
				successfulSheet.autoSizeColumn(columnCount, false);
				controlSheet.autoSizeColumn(columnCount, false);
				if (columnCount != 12) {
					exceptionsSheet.autoSizeColumn(columnCount, false);
				}
				columnCount++;
			}
			// /* FOR WRAPPING TEXT AT THE LAST FIELD
			successfulSheet.setColumnWidth(columnCount, 14000);
			exceptionsSheet.setColumnWidth(12, 15000);
			exceptionsSheet.setColumnWidth(columnCount - 1, 14000);

			// */
			columnCount = 0;
			XSSFCellStyle sumStyle = workBook.createCellStyle();
			sumStyle.setFont(tableHeadingFont);
			sumStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			sumStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
			sumStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
			sumStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
			sumStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
			sumStyle.setFillForegroundColor(new XSSFColor(new Color(219, 229,
					241)));
			sumStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			XSSFCellStyle sumIntegerStyle = workBook.createCellStyle();

			sumIntegerStyle.setFont(tableHeadingFont);
			sumIntegerStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			sumIntegerStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
			sumIntegerStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
			sumIntegerStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
			sumIntegerStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
			sumIntegerStyle.setFillForegroundColor(new XSSFColor(new Color(219,
					229, 241)));
			sumIntegerStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
			sumIntegerStyle.setDataFormat(workBook.createDataFormat()
					.getFormat("#,##0"));
			sumStyle.setDataFormat(workBook.createDataFormat().getFormat(
					"#,##0.0#"));
			XSSFRow sumRow = successfulSheet.createRow(rowNum);
			XSSFRow sumRowExceptionsSheet = exceptionsSheet
					.createRow(rowNumExceptionsSheet);
			XSSFRow sumRowControlSheet = controlSheet
					.createRow(rowNumControlSheet);
			columnCount = 0;
			while (columnCount <= noOfColumns - 3) {
				sumRow.createCell(columnCount);
				sumRowExceptionsSheet.createCell(columnCount);
				sumRowControlSheet.createCell(columnCount);
				sumRow.getCell(columnCount).setCellStyle(sumStyle);
				sumRowExceptionsSheet.getCell(columnCount).setCellStyle(
						sumStyle);
				sumRowControlSheet.getCell(columnCount).setCellStyle(sumStyle);
				columnCount++;
			}
			sumRow.createCell(columnCount);
			sumRow.getCell(columnCount).setCellStyle(sumStyle);
			columnCount = 0;

			XSSFCell sumCell = sumRow.createCell(0);
			XSSFCell sumCellSecondSheet = sumRowExceptionsSheet.createCell(0);
			XSSFCell sumCellControlSheet = sumRowControlSheet.createCell(0);

			// --rowNum;

			XSSFCell hSumCell = sumRow.createCell(7);
			hSumCell.setCellStyle(sumStyle);
			hSumCell.setCellType(XSSFCell.CELL_TYPE_FORMULA);

			XSSFCell jSumCell = sumRow.createCell(9);
			jSumCell.setCellStyle(sumIntegerStyle);
			jSumCell.setCellType(XSSFCell.CELL_TYPE_FORMULA);

			XSSFCell oSumCell = sumRow.createCell(14);
			oSumCell.setCellStyle(sumStyle);
			oSumCell.setCellType(XSSFCell.CELL_TYPE_FORMULA);
			if (rowNum >= 8) {
				jSumCell.setCellFormula("SUM(J1:J" + rowNum + ")");
				hSumCell.setCellFormula("SUM(H1:H" + rowNum + ")");
				oSumCell.setCellFormula("SUM(O1:O" + rowNum + ")");
			}

			XSSFCell hSumCellSecond = sumRowExceptionsSheet.createCell(7);
			XSSFCell hSumCellControl = sumRowControlSheet.createCell(7);
			hSumCellSecond.setCellStyle(sumStyle);
			hSumCellControl.setCellStyle(sumStyle);
			hSumCellSecond.setCellType(XSSFCell.CELL_TYPE_FORMULA);
			hSumCellControl.setCellType(XSSFCell.CELL_TYPE_FORMULA);

			XSSFCell jSumCellSecond = sumRowExceptionsSheet.createCell(9);
			XSSFCell jSumCellControl = sumRowControlSheet.createCell(9);
			jSumCellSecond.setCellStyle(sumIntegerStyle);
			jSumCellControl.setCellStyle(sumIntegerStyle);
			jSumCellSecond.setCellType(XSSFCell.CELL_TYPE_FORMULA);
			jSumCellControl.setCellType(XSSFCell.CELL_TYPE_FORMULA);

			XSSFCell nSumCellSecond = sumRowExceptionsSheet.createCell(13);
			XSSFCell nSumCellControl = sumRowControlSheet.createCell(13);
			nSumCellSecond.setCellStyle(sumStyle);
			nSumCellControl.setCellStyle(sumStyle);
			nSumCellSecond.setCellType(XSSFCell.CELL_TYPE_FORMULA);
			nSumCellControl.setCellType(XSSFCell.CELL_TYPE_FORMULA);
			if (rowNumExceptionsSheet >= 2) {
				nSumCellSecond.setCellFormula("SUM(N1:N"
						+ rowNumExceptionsSheet + ")");
				hSumCellSecond.setCellFormula("SUM(H1:H"
						+ rowNumExceptionsSheet + ")");
				jSumCellSecond.setCellFormula("SUM(J1:J"
						+ rowNumExceptionsSheet + ")");
			}
			if (rowNumControlSheet >= 2) {
				nSumCellControl.setCellFormula("SUM(N1:N" + rowNumControlSheet
						+ ")");
				hSumCellControl.setCellFormula("SUM(H1:H" + rowNumControlSheet
						+ ")");
				jSumCellControl.setCellFormula("SUM(J1:J" + rowNumControlSheet
						+ ")");
			}
			// /--------------------

			sumCell.setCellStyle(sumStyle);
			sumCell.setCellValue("TOTAL");
			sumCellSecondSheet.setCellStyle(sumStyle);
			sumCellSecondSheet.setCellValue("TOTAL");
			sumCellControlSheet.setCellStyle(sumStyle);
			sumCellControlSheet.setCellValue("TOTAL");
			columnCount = 0;

			if (dataValueList != null) {
				XSSFSheet dataValueSheet = workBook
						.createSheet("Data Value Exception");
				dataValueSheet.setDisplayGridlines(false);
				int rowNumDataValueSheet = 0;
				for (int j = 0; j < dataValueList.size(); j++) {
					XSSFRow currentRowDataValueSheet = dataValueSheet
							.createRow(rowNumDataValueSheet);
					List<String> str = dataValueList.get(j);
					int temp = str.size();
					for (int i = 0; i < temp; i++) {
						if (rowNumDataValueSheet == 0) {
							XSSFCell cell = currentRowDataValueSheet
									.createCell(i);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							XSSFCell cell = currentRowDataValueSheet
									.createCell(i);
							if (i == 2) {
								cell.setCellStyle(numberCellStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == temp - 1) {
								cell.setCellStyle(wrapTextStyle(
										borderOnlyStyle, workBook));
								cell.setCellValue(str.get(i));
							} else {
								cell.setCellStyle(borderOnlyStyle);
								cell.setCellValue(str.get(i));
							}

						}
					}
					rowNumDataValueSheet++;
				}
				columnCount = 0;
				while (columnCount < dataValueSheet.getRow(0).getLastCellNum() - 1) {
					dataValueSheet.autoSizeColumn(columnCount, false);
					columnCount++;
				}
				dataValueSheet.setColumnWidth(columnCount, 14000);

				CellRangeAddress filterRangeDataValue = new CellRangeAddress(0,
						dataValueSheet.getLastRowNum(), 0, dataValueSheet
								.getRow(dataValueSheet.getLastRowNum())
								.getLastCellNum() - 1);
				dataValueSheet.setAutoFilter(filterRangeDataValue);
				dataValueSheet.createFreezePane(0, 1);
			}
			if (dpStatusList != null) {
				XSSFSheet rawProfilerSheet = workBook
						.createSheet("Raw Profiler Status");
				rawProfilerSheet.setDisplayGridlines(false);
				int dataProfilerRowNum = 0;
				for (int j = 0; j < dpStatusList.size(); j++) {
					XSSFRow currentRowDataProfilerSheet = rawProfilerSheet
							.createRow(dataProfilerRowNum);
					List<String> str = dpStatusList.get(j);
					for (int i = 0; i < str.size(); i++) {
						if (dataProfilerRowNum == 0) {
							XSSFCell cell = currentRowDataProfilerSheet
									.createCell(i);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							XSSFCell cell = currentRowDataProfilerSheet
									.createCell(i);
							if (i == 3 || i == 5) {
								cell.setCellStyle(numberCellStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else {
								cell.setCellStyle(borderOnlyStyle);
								cell.setCellValue(str.get(i));
							}

						}
					}
					dataProfilerRowNum++;
				}
				columnCount = 0;

				while (columnCount < rawProfilerSheet.getRow(0)
						.getLastCellNum()) {
					rawProfilerSheet.autoSizeColumn(columnCount, false);
					columnCount++;
				}

				CellRangeAddress filterRangedateNumberExceptionSheet = new CellRangeAddress(
						0, rawProfilerSheet.getLastRowNum(), 0,
						rawProfilerSheet.getRow(
								rawProfilerSheet.getLastRowNum())
								.getLastCellNum() - 1);

				rawProfilerSheet
						.setAutoFilter(filterRangedateNumberExceptionSheet);
				rawProfilerSheet.createFreezePane(0, 1);
			}
			if (thirdList != null) {
				XSSFSheet dateNumberExceptionSheet = workBook
						.createSheet("Date Number Exception");
				dateNumberExceptionSheet.setDisplayGridlines(false);
				int rowNumDateNumberSheet = 0;
				for (int j = 0; j < thirdList.size(); j++) {
					XSSFRow currentRowDateNumberSheet = dateNumberExceptionSheet
							.createRow(rowNumDateNumberSheet);
					List<String> str = thirdList.get(j);
					for (int i = 0; i < str.size(); i++) {
						if (rowNumDateNumberSheet == 0) {
							XSSFCell cell = currentRowDateNumberSheet
									.createCell(i);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							XSSFCell cell = currentRowDateNumberSheet
									.createCell(i);
							if (i == 2 | i == 9 || i == 10) {
								cell.setCellStyle(numberCellStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else {
								cell.setCellStyle(borderOnlyStyle);
								cell.setCellValue(str.get(i));
							}

						}
					}
					rowNumDateNumberSheet++;
				}
				columnCount = 0;

				while (columnCount < dateNumberExceptionSheet.getRow(0)
						.getLastCellNum()) {
					dateNumberExceptionSheet.autoSizeColumn(columnCount, false);
					columnCount++;
				}

				CellRangeAddress filterRangedateNumberExceptionSheet = new CellRangeAddress(
						0, dateNumberExceptionSheet.getLastRowNum(), 0,
						dateNumberExceptionSheet.getRow(
								dateNumberExceptionSheet.getLastRowNum())
								.getLastCellNum() - 1);

				dateNumberExceptionSheet
						.setAutoFilter(filterRangedateNumberExceptionSheet);
				dateNumberExceptionSheet.createFreezePane(0, 1);
			}
			if (fourthList != null) {
				XSSFSheet unhandledExceptionsSheet = workBook
						.createSheet("Unhandled Exceptions");
				int rowNumFifthSheet = 0;
				unhandledExceptionsSheet.setDisplayGridlines(false);
				for (int j = 0; j < fourthList.size(); j++) {

					List<String> str = fourthList.get(j);

					XSSFRow currentRowFifthSheet = unhandledExceptionsSheet
							.createRow(rowNumFifthSheet);
					int temp = str.size() - 1;
					for (int i = 0; i < temp; i++) {
						if (rowNumFifthSheet == 0) {
							XSSFCell cell = currentRowFifthSheet.createCell(i);
							cell.setCellStyle(tableHeadingStyle);
							cell.setCellValue(str.get(i));
						} else {
							// NEW ONE
							XSSFCell cell = currentRowFifthSheet.createCell(i);
							cell.setCellStyle(borderOnlyStyle);

							if (i == 7) {
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(getSizeMBFloat(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								cell.setCellStyle(floatStyle);
							} else if (i == 4 || i == 8 || i == 9) {
								cell.setCellStyle(numberCellStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(Long.parseLong(str.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 11) {
								cell.setCellStyle(dateStyle);
								if (str.get(i) != null && str.get(i) != "") {
									cell.setCellValue(dateFormat.parse(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
							} else if (i == 13) {
								if (str.get(i) != null && str.get(i) != "") {

									cell.setCellValue(Float.parseFloat(str
											.get(i)));
								} else {
									cell.setCellValue(str.get(i));
								}
								cell.setCellStyle(floatStyle);
							} else if (i == temp - 1) {

								cell.setCellStyle(wrapTextStyle(
										borderOnlyStyle, workBook));
								cell.setCellValue(str.get(i));
							} else {
								cell.setCellValue(str.get(i));
							}

						}
					}
					rowNumFifthSheet++;

				}

				columnCount = 0;
				while (columnCount < unhandledExceptionsSheet.getRow(0)
						.getLastCellNum() - 1) {
					unhandledExceptionsSheet.autoSizeColumn(columnCount, false);
					columnCount++;
				}
				unhandledExceptionsSheet.setColumnWidth(columnCount, 14000);
				CellRangeAddress filterRangeUnhandledExceptionsSheet = new CellRangeAddress(
						0, unhandledExceptionsSheet.getLastRowNum(), 0,
						unhandledExceptionsSheet.getRow(
								unhandledExceptionsSheet.getLastRowNum())
								.getLastCellNum() - 1);

				unhandledExceptionsSheet
						.setAutoFilter(filterRangeUnhandledExceptionsSheet);
				unhandledExceptionsSheet.createFreezePane(0, 1);
			}
			if (exceptionsSheet.getLastRowNum() != 1) {
				XSSFPivotTable pivotTable = pivotSheet.createPivotTable(
						new AreaReference("A1:O" + rowNumExceptionsSheet),
						new CellReference("A3"), exceptionsSheet);
				// pivotTable.addRowLabel(1);
				pivotTable.addRowLabel(12);
				pivotTable.addRowLabel(5);
				pivotTable.addRowLabel(3);
				//
				pivotTable.addReportFilter(1);
				pivotTable.addColumnLabel(DataConsolidateFunction.COUNT, 0);
			} else {
				XSSFRow warningRowPivotSheet = pivotSheet.createRow(0);
				XSSFCell warningCell = warningRowPivotSheet.createCell(8);
				CellRangeAddress warningRange = new CellRangeAddress(0, 0, 8,
						13);
				String warning = "*No any exception record to create the pivot table";
				warningCell.setCellValue(warning);
				pivotSheet.addMergedRegion(warningRange);
			}
			if (controlReconDataList != null) {
				if (controlReconDataList.size() > 1) {
					XSSFSheet controlReconSheet = workBook
							.createSheet("Control Recon");
					controlReconSheet.setDisplayGridlines(false);
					XSSFRow infoRowControlRecon = controlReconSheet
							.createRow(0);
					CellRangeAddress veriskRange = new CellRangeAddress(0, 0,
							10, 16);
					CellRangeAddress vendorRange = new CellRangeAddress(0, 0,
							17, 23);
					CellRangeAddress varianceRange = new CellRangeAddress(0, 0,
							24, 30);

					XSSFCell veriskCell = infoRowControlRecon.createCell(10);
					veriskCell.setCellStyle(veriskStyle);
					veriskCell.setCellValue("Verisk");
					XSSFCell vendorCell = infoRowControlRecon.createCell(17);
					vendorCell.setCellStyle(vendorStyle);
					vendorCell.setCellValue("Vendor");
					XSSFCell varienceCell = infoRowControlRecon.createCell(24);
					varienceCell.setCellStyle(varianceStyle);
					varienceCell.setCellValue("Variance");
					controlReconSheet.addMergedRegion(varianceRange);
					controlReconSheet.addMergedRegion(vendorRange);
					controlReconSheet.addMergedRegion(veriskRange);
					XSSFRow headingRowControlRecon = controlReconSheet
							.createRow(1);
					//
					XSSFCell cell0 = headingRowControlRecon.createCell(0);
					cell0.setCellStyle(tableHeadingStyle);
					cell0.setCellValue("Client ID");

					//
					XSSFCell cell1 = headingRowControlRecon.createCell(1);
					cell1.setCellStyle(tableHeadingStyle);
					cell1.setCellValue("Data Manager ID");
					//
					XSSFCell cell2 = headingRowControlRecon.createCell(2);
					cell2.setCellStyle(tableHeadingStyle);
					cell2.setCellValue("FileName");
					//
					XSSFCell cell26 = headingRowControlRecon.createCell(3);
					cell26.setCellStyle(tableHeadingStyle);
					cell26.setCellValue("Data Layout Id");

					//
					XSSFCell cell28 = headingRowControlRecon.createCell(4);
					cell28.setCellStyle(tableHeadingStyle);
					cell28.setCellValue("Datafile Date");
					//
					XSSFCell cell27 = headingRowControlRecon.createCell(5);
					cell27.setCellStyle(tableHeadingStyle);
					cell27.setCellValue("Control-FileName");
					//
					XSSFCell cell30 = headingRowControlRecon.createCell(6);
					cell30.setCellStyle(tableHeadingStyle);
					cell30.setCellValue("Control Layout ID");
					//
					XSSFCell cell29 = headingRowControlRecon.createCell(7);
					cell29.setCellStyle(tableHeadingStyle);
					cell29.setCellValue("ControlFile Date");
					//
					XSSFCell cell3 = headingRowControlRecon.createCell(8);
					cell3.setCellStyle(tableHeadingStyle);
					cell3.setCellValue("PayorName");
					//
					XSSFCell cell4 = headingRowControlRecon.createCell(9);
					cell4.setCellStyle(tableHeadingStyle);
					cell4.setCellValue("File Data Type");
					//
					XSSFCell cell5 = headingRowControlRecon.createCell(10);
					cell5.setCellStyle(tableHeadingStyle);
					cell5.setCellValue("Billed Amount");
					//
					XSSFCell cell6 = headingRowControlRecon.createCell(11);
					cell6.setCellStyle(tableHeadingStyle);
					cell6.setCellValue("Allowed Amount");
					//
					XSSFCell cell7 = headingRowControlRecon.createCell(12);
					cell7.setCellStyle(tableHeadingStyle);
					cell7.setCellValue("Paid Amount");
					//
					XSSFCell cell8 = headingRowControlRecon.createCell(13);
					cell8.setCellStyle(tableHeadingStyle);
					cell8.setCellValue("Employee Amount");
					//
					XSSFCell cell9 = headingRowControlRecon.createCell(14);
					cell9.setCellStyle(tableHeadingStyle);
					cell9.setCellValue("Employee Count");
					//
					XSSFCell cell10 = headingRowControlRecon.createCell(15);
					cell10.setCellStyle(tableHeadingStyle);
					cell10.setCellValue("Member Count");
					//
					XSSFCell cell11 = headingRowControlRecon.createCell(16);
					cell11.setCellStyle(tableHeadingStyle);
					cell11.setCellValue("Record Count");
					//
					XSSFCell cell12 = headingRowControlRecon.createCell(17);
					cell12.setCellStyle(tableHeadingStyle);
					cell12.setCellValue("Billed Amount");
					//
					XSSFCell cell13 = headingRowControlRecon.createCell(18);
					cell13.setCellStyle(tableHeadingStyle);
					cell13.setCellValue("Allowed Amount");
					//
					XSSFCell cell14 = headingRowControlRecon.createCell(19);
					cell14.setCellStyle(tableHeadingStyle);
					cell14.setCellValue("Paid Amount");
					//
					XSSFCell cell15 = headingRowControlRecon.createCell(20);
					cell15.setCellStyle(tableHeadingStyle);
					cell15.setCellValue("Employee Amount");
					//
					XSSFCell cell16 = headingRowControlRecon.createCell(21);
					cell16.setCellStyle(tableHeadingStyle);
					cell16.setCellValue("Employee Count");
					//
					XSSFCell cell17 = headingRowControlRecon.createCell(22);
					cell17.setCellStyle(tableHeadingStyle);
					cell17.setCellValue("Member Count");
					//
					XSSFCell cell18 = headingRowControlRecon.createCell(23);
					cell18.setCellStyle(tableHeadingStyle);
					cell18.setCellValue("Record Count");
					//
					XSSFCell cell19 = headingRowControlRecon.createCell(24);
					cell19.setCellStyle(tableHeadingStyle);
					cell19.setCellValue("Billed Amount");
					//
					XSSFCell cell20 = headingRowControlRecon.createCell(25);
					cell20.setCellStyle(tableHeadingStyle);
					cell20.setCellValue("Allowed Amount");
					//
					XSSFCell cell21 = headingRowControlRecon.createCell(26);
					cell21.setCellStyle(tableHeadingStyle);
					cell21.setCellValue("Paid Amount");
					//
					XSSFCell cell22 = headingRowControlRecon.createCell(27);
					cell22.setCellStyle(tableHeadingStyle);
					cell22.setCellValue("Employee Amount");
					//
					XSSFCell cell23 = headingRowControlRecon.createCell(28);
					cell23.setCellStyle(tableHeadingStyle);
					cell23.setCellValue("Employee Count");
					//
					XSSFCell cell24 = headingRowControlRecon.createCell(29);
					cell24.setCellStyle(tableHeadingStyle);
					cell24.setCellValue("Member Count");
					//
					XSSFCell cell25 = headingRowControlRecon.createCell(30);
					cell25.setCellStyle(tableHeadingStyle);
					cell25.setCellValue("Record Count");
					for (int i = 1; i < controlReconDataList.size(); i++) {
						XSSFRow currentRow = controlReconSheet.createRow(i + 1);
						//
						XSSFCell cellR0 = currentRow.createCell(0);
						cellR0.setCellStyle(borderOnlyStyle);
						cellR0.setCellValue(controlReconDataList.get(i)
								.getClientId());

						//
						XSSFCell cellR1 = currentRow.createCell(1);
						cellR1.setCellStyle(borderOnlyStyle);
						cellR1.setCellValue(controlReconDataList.get(i)
								.getDmfileid());
						//
						XSSFCell cellR2 = currentRow.createCell(2);
						cellR2.setCellStyle(borderOnlyStyle);
						cellR2.setCellValue(controlReconDataList.get(i)
								.getFilename());
						//
						//
						XSSFCell cellR26 = currentRow.createCell(3);
						cellR26.setCellStyle(layoutIdStyle);
						setValueOfCell(cellR26, controlReconDataList.get(i)
								.getDataLayoutID());
						//
						XSSFCell cellR27 = currentRow.createCell(4);
						cellR27.setCellStyle(dateStyle);
						setValueOfCell(cellR27, controlReconDataList.get(i)
								.getDataFileDate());

						//
						XSSFCell cellR28 = currentRow.createCell(5);
						cellR28.setCellStyle(borderOnlyStyle);
						cellR28.setCellValue(controlReconDataList.get(i)
								.getCtlFileName());
						//
						XSSFCell cellR29 = currentRow.createCell(6);
						cellR29.setCellStyle(layoutIdStyle);
						// cellR29.setCellValue("");
						setValueOfCell(cellR29, controlReconDataList.get(i)
								.getCtlLayoutID());
						//
						XSSFCell cellR30 = currentRow.createCell(7);
						cellR30.setCellStyle(dateStyle);
						setValueOfCell(cellR30, controlReconDataList.get(i)
								.getCtlFileDate());

						//
						XSSFCell cellR3 = currentRow.createCell(8);
						cellR3.setCellStyle(borderOnlyStyle);
						cellR3.setCellValue(controlReconDataList.get(i)
								.getPayorname());
						//
						XSSFCell cellR4 = currentRow.createCell(9);
						cellR4.setCellStyle(borderOnlyStyle);
						cellR4.setCellValue(controlReconDataList.get(i)
								.getFileDataType());
						//
						XSSFCell cellR5 = currentRow.createCell(10);
						cellR5.setCellStyle(currencyStyle);
						setValueOfCell(cellR5, controlReconDataList.get(i)
								.getVhBilledAmount());
						//
						XSSFCell cellR6 = currentRow.createCell(11);
						cellR6.setCellStyle(currencyStyle);
						setValueOfCell(cellR6, controlReconDataList.get(i)
								.getVhAllowedAmount());
						//
						XSSFCell cellR7 = currentRow.createCell(12);
						cellR7.setCellStyle(currencyStyle);
						setValueOfCell(cellR7, controlReconDataList.get(i)
								.getVhPaidAmount());
						//
						XSSFCell cellR8 = currentRow.createCell(13);
						cellR8.setCellStyle(currencyStyle);
						setValueOfCell(cellR8, controlReconDataList.get(i)
								.getVhEmployeeAmount());
						//
						XSSFCell cellR9 = currentRow.createCell(14);
						cellR9.setCellStyle(numberCellStyle);
						setValueOfCell(cellR9, controlReconDataList.get(i)
								.getVhEmployeeCount());
						//
						XSSFCell cellR10 = currentRow.createCell(15);
						cellR10.setCellStyle(numberCellStyle);
						setValueOfCell(cellR10, controlReconDataList.get(i)
								.getVhMemberCount());
						//
						XSSFCell cellR11 = currentRow.createCell(16);
						cellR11.setCellStyle(numberCellStyle);
						setValueOfCell(cellR11, controlReconDataList.get(i)
								.getVhRecordCount());
						//
						XSSFCell cellR12 = currentRow.createCell(17);
						cellR12.setCellStyle(currencyStyle);
						setValueOfCell(cellR12, controlReconDataList.get(i)
								.getVendorBilledAmount());
						//
						XSSFCell cellR13 = currentRow.createCell(18);
						cellR13.setCellStyle(currencyStyle);
						setValueOfCell(cellR13, controlReconDataList.get(i)
								.getVendorAllowedAmount());
						//
						XSSFCell cellR14 = currentRow.createCell(19);
						cellR14.setCellStyle(currencyStyle);
						setValueOfCell(cellR14, controlReconDataList.get(i)
								.getVendorPaidAmount());
						//
						XSSFCell cellR15 = currentRow.createCell(20);
						cellR15.setCellStyle(currencyStyle);
						setValueOfCell(cellR15, controlReconDataList.get(i)
								.getVendorEmployeeAmount());
						//
						XSSFCell cellR16 = currentRow.createCell(21);
						cellR16.setCellStyle(numberCellStyle);
						setValueOfCell(cellR16, controlReconDataList.get(i)
								.getVendorEmployeeCount());
						//
						XSSFCell cellR17 = currentRow.createCell(22);
						cellR17.setCellStyle(numberCellStyle);
						setValueOfCell(cellR17, controlReconDataList.get(i)
								.getVendorMemberCount());
						//
						XSSFCell cellR18 = currentRow.createCell(23);
						cellR18.setCellStyle(numberCellStyle);
						setValueOfCell(cellR18, controlReconDataList.get(i)
								.getVendorRecordCount());
						//
						XSSFCell cellR19 = currentRow.createCell(24);
						cellR19.setCellStyle(currencyStyle);
						setValueOfCell(cellR19, controlReconDataList.get(i)
								.getVarBilledAmount());
						//
						XSSFCell cellR20 = currentRow.createCell(25);
						cellR20.setCellStyle(currencyStyle);
						setValueOfCell(cellR20, controlReconDataList.get(i)
								.getVarAllowedAmount());
						//
						XSSFCell cellR21 = currentRow.createCell(26);
						cellR21.setCellStyle(currencyStyle);
						setValueOfCell(cellR21, controlReconDataList.get(i)
								.getVarPaidAmount());
						//
						XSSFCell cellR22 = currentRow.createCell(27);
						cellR22.setCellStyle(currencyStyle);
						setValueOfCell(cellR22, controlReconDataList.get(i)
								.getVarEmployeeAmount());
						//
						XSSFCell cellR23 = currentRow.createCell(28);
						cellR23.setCellStyle(numberCellStyle);
						setValueOfCell(cellR23, controlReconDataList.get(i)
								.getVarEmployeeCount());
						//
						XSSFCell cellR24 = currentRow.createCell(29);
						cellR24.setCellStyle(numberCellStyle);
						setValueOfCell(cellR24, controlReconDataList.get(i)
								.getVarMemberCount());
						//
						XSSFCell cellR25 = currentRow.createCell(30);
						cellR25.setCellStyle(numberCellStyle);
						setValueOfCell(cellR25, controlReconDataList.get(i)
								.getVarRecordCount());
					}
					y = 0;
					while (y < controlReconSheet.getRow(1).getLastCellNum()) {
						controlReconSheet.autoSizeColumn(y);
						y++;
					}
					controlReconSheet.createFreezePane(4, 2);
				}
			}

			// ---------------WRITING TO FILE----------------------------
			FileOutputStream fileOutputStream = new FileOutputStream(
					xlsxFileAddress);
			workBook.write(fileOutputStream);
			fileOutputStream.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static Float getSizeMBFloat(String bytesString) {
		if (bytesString == "") {
			return 0f;
		}
		long bytes = Long.parseLong(bytesString);

		Float temp = (float) bytes / (1024 * 1024);
		return temp;
	}
}
