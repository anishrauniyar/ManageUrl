package svnPush;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.tmatesoft.svn.core.SVNDepth;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.internal.wc.DefaultSVNOptions;

import org.tmatesoft.svn.core.wc.SVNClientManager;
import org.tmatesoft.svn.core.wc.SVNRevision;
import org.tmatesoft.svn.core.wc.SVNUpdateClient;

/**
 * Class for doing Bulk-Checkin. It first checkouts the scripts and does checkin
 * and addition
 * 
 * @author Ayam Pokhrel
 * @version 1.0
 */
public class CommitToSVN {

	/**
	 * Path of Working Directory
	 */
	public static File workingDirectory;
	/**
	 * URL for attribute Script
	 */
	private static SVNURL url;
	private static SVNURL svnAttributeURL;
	private static SVNURL svnImportURL;
	private static SVNURL svnCattrUrl;
	public static String attributeURLString;
	public static String importURLString;
	public static String controlURLString;

	public static String testAttributeURLString;
	public static String testImportURLString;
	public static String testControlURLString;
	public static String svnUserName;
	public static String svnPassword;

	/**
	 * SVN Client Manager
	 */
	public static SVNClientManager svnCM;
	/**
	 * Flag for checking whether the svn repositories are initialized or not
	 */
	public static boolean isInitialized = false;
	/**
	 * Flag for test Checkin
	 */
	public static boolean testCheckin = false;

	/**
	 * This Method initializes the Repository
	 */
	public static void initialize() {
		try {
			DAVRepositoryFactory.setup();
			FSRepositoryFactory.setup();
			SVNRepositoryFactoryImpl.setup();
			svnCM = SVNClientManager.newInstance(new DefaultSVNOptions(),
					svnUserName, svnPassword);
			if (testCheckin) {
				attributeURLString = testAttributeURLString;
				importURLString = testImportURLString;
				controlURLString = testControlURLString;
			}
			System.out.println("Doing SVN Checking....");
			System.out.println("Attribute URL is: \n" + attributeURLString);
			System.out.println("ImportScript URL is: \n" + importURLString);
			System.out.println("Cattr URL is: \n" + controlURLString);
			isInitialized = true;
		} catch (Exception e) {
			System.err.println("SVN initialization failed");
		}

	}

	/**
	 * Method for Checking out the current AIP scripts
	 * 
	 * @param url
	 *            SVN Url
	 * @param source
	 *            Working Directory
	 */

	public static long checkOutScripts(SVNURL url, File source)
			throws SVNException {
		SVNUpdateClient uCL = svnCM.getUpdateClient();
		uCL.setIgnoreExternals(false);

		return uCL.doCheckout(url, source, SVNRevision.HEAD, SVNRevision.HEAD,
				SVNDepth.INFINITY, true);

	}

	/**
	 * Method for Adding new scripts, changing and Committing the the current
	 * AIP scripts
	 * 
	 * @param workingPath
	 *            The Working Directory(Local)
	 * @param type
	 *            The Type of the AIP Script
	 * @param option
	 *            The option (integer) whether to do svn-checkout or do change
	 *            and commit files
	 */
	@SuppressWarnings("deprecation")
	public static void checkOutAndCommit(String workingPath, int type,
			int option) {
		if (isInitialized == false) {
			initialize();
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		Calendar cal = Calendar.getInstance();
		try {
			svnAttributeURL = SVNURL.parseURIEncoded(attributeURLString);
			svnImportURL = SVNURL.parseURIEncoded(importURLString);
			svnCattrUrl = SVNURL.parseURIEncoded(controlURLString);
			if (type == 0) {
				url = svnAttributeURL;
			} else if (type == 1) {
				url = svnCattrUrl;
			} else if (type == 2) {
				url = svnImportURL;
			}

		} catch (SVNException e) {
			System.err.println("SVN EXception Caught " + e.getMessage());
		}
		try {
			workingDirectory = new File(workingPath);
			if (option == 1) {
				System.out.println("Checking out from" + url.getPath());
				checkOutScripts(url, workingDirectory);
				System.out.println("SVN Check out Completed");
			}
			if (option == 2) {
				File[] paths = { workingDirectory };
				System.out.println("Adding new files to " + workingDirectory);
				svnCM.getWCClient().doAdd(workingDirectory, true, true, true,
						SVNDepth.INFINITY, true, true);
				System.out.println("Committing...");
				svnCM.getCommitClient()
						.doCommit(
								paths,
								false,
								"New Scripts Committed on "
										+ sdf.format(cal.getTime()), true, true);
				System.out
						.println("Successfully Committed this directory to SVN");
			}
		} catch (SVNException e) {
			System.err.println("Error Occured " + e.getMessage());
		}

	}

}
