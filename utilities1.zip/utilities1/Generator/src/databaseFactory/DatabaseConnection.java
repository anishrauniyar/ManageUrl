
package databaseFactory;

import java.sql.Connection;
import java.sql.SQLException;
/** 
 * This is the general interface and method signature for the creation of Database Connection
 * @author Ayam Pokhrel
 * @version 1.0
 */
public interface DatabaseConnection {
	/**
	 * Method Signature to create and return a database connection
	 * 
	 * @param connectString
	 *            The Connection String. They are different for different
	 *            databases.e.g: For ORACLE: hostname:port:SID ,
	 *            samplemachine:1521:d2he
	 * @param user
	 *            Username or Schemaname for the database
	 * @param password
	 *            Password for the given user/schema
	 * 
	 */

	public Connection getConnection(String connectString, String user,
			String password) throws SQLException, ClassNotFoundException;

}
