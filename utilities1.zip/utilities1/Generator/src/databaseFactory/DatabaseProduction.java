
package databaseFactory;

import java.sql.Connection;
import java.sql.SQLException;
/** This is the interface for DatabaseFactory(Following Factory Method Design Pattern)
 * @author Ayam Pokhrel
 * @version 1.0
 */
public interface DatabaseProduction {
	/**
	 * Method Signature to create and return a database connection
	 * 
	 * @param connectType
	 *            Type of database, eg: ORACLE , etc.
	 * @param connectString
	 *            The Connection String. They are different for different
	 *            databases.e.g: For ORACLE: hostname:port:SID ,
	 *            samplemachine:1521:d2he
	 * @param user
	 *            Username or Schemaname for the database
	 * @param password
	 *            Password for the given user/schema
	 * 
	 */
	public Connection getDatabaseConnection(String connectType,
			String connectString, String user, String password)
			throws SQLException, ClassNotFoundException;
}
