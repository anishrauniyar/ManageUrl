package utilities;

import generateScript.GenerateAllImportScript;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import svnPush.CommitToSVN;

public class PropsUtils {

	public static void sourceAllVariables(File propertiesFile)
			throws IOException {
		Properties prop = new Properties();
		InputStream input = null;
		input = new FileInputStream(propertiesFile);
		prop.load(input);
		if (prop.getProperty("ATTRIBUTE") == null
				|| prop.getProperty("IMPORT") == null
				|| prop.getProperty("IMPORT").equals("")
				|| prop.getProperty("CONTROL") == null
				|| prop.getProperty("TEST_ATTRIBUTE") == null
				|| prop.getProperty("TEST_IMPORT") == null
				|| prop.getProperty("TEST_CONTROL") == null
				|| prop.getProperty("SVN_USERNAME") == null
				|| prop.getProperty("SVN_PASSWORD") == null) {
			System.err.println("Insufficient properties");
			System.exit(1);
		}
		if (prop.getProperty("ORACLE_LOGS_BASE_PATH")!=null && !prop.getProperty("ORACLE_LOGS_BASE_PATH").equals("")) {
			GenerateAllImportScript.logsBasePath = prop
					.getProperty("ORACLE_LOGS_BASE_PATH");
		}
		CommitToSVN.svnUserName= prop.getProperty("SVN_USERNAME") ;
		CommitToSVN.svnPassword= prop.getProperty("SVN_PASSWORD") ;	
		CommitToSVN.attributeURLString=prop.getProperty("ATTRIBUTE");
		CommitToSVN.importURLString=prop.getProperty("IMPORT");
		CommitToSVN.controlURLString=prop.getProperty("CONTROL");
		CommitToSVN.testAttributeURLString=prop.getProperty("TEST_ATTRIBUTE");
		CommitToSVN.testControlURLString=prop.getProperty("TEST_CONTROL");
		CommitToSVN.testImportURLString=prop.getProperty("TEST_IMPORT"); 

		// GeneralDAO.connectString = prop.getProperty("SVN_LOCATION");
		// GeneralDAO.user = prop.getProperty("TEST_SVN_LOCATION");
		if (input != null) {
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
