package generateScript;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * This Class generates control total parsing script for both inline control
 * total and control total files
 * 
 * @author Ayam Pokhrel
 * @version 1.0
 */
public class GenerateAllCAttribute {

	/**
	 * Object to hold the main Connection
	 */
	protected static Connection conn;
	/**
	 * Flag to check if the connection is initialized
	 */
	static boolean isInitialized = false;
	/**
	 * @see GenerateAllAttribute#allAttributesHashtable
	 */
	public static Map<String, String> allCAttributeHashtable = new HashMap<String, String>();

	public static String subLayoutQuery = "SELECT a.SUBLAYOUTID,Upper(a.LAYOUTTYPE) LAYOUTTYPE,a.LAYOUTDETAIL,nvl(a.WHERECLAUSE,'NA'),upper(SubStr(a.WHERECLAUSE,1,InStr(Upper(a.WHERECLAUSE),'=')-1)) label,upper(SubStr(a.WHERECLAUSE,InStr(Upper(a.WHERECLAUSE),'='))) label1,Nvl(a.SUBLAYOUTDESC,'DATAFILE') SUBLAYOUTDESC,"
			+ "Nvl(b.LAYOUTTYPEID,a.LAYOUTTYPE)  AS SORTLAYOUTTYPE,b.FIELDTERMINATOR,c.NOOFFLDCNT,c.SUMOFFIELDS, Nvl(a.TRAILERFLAG,'N') as TRAILERFLAG, Nvl(a.SUMFLAG,'N') As SUMFLAG "
			+ "FROM (SELECT * FROM IMP_SUB_LAYOUTS WHERE LAYOUTID= ? "
			+ " and Upper(SUBLAYOUTDESC)='CONTROLTOTAL' "
			+ " ) a "
			+ " left join TBL_FILEPATTERNS_LAYOUT b"
			+ " ON Upper(a.LAYOUTTYPE)=Upper(b.LAYOUTTYPE) LEFT JOIN (SELECT LAYOUTID,SUBLAYOUTID,COUNT(*) NOOFFLDCNT,SUM(FIELDLENGTH) as SUMOFFIELDS FROM IMP_LAYOUTS_FIELDS WHERE LAYOUTID= ? "
			+ " GROUP BY  LAYOUTID,SUBLAYOUTID) c ON a.SUBLAYOUTID=c.SUBLAYOUTID";
	public static String colNoQuery = "SELECT DISTINCT COLUMNID,startpos,To_Number(Nvl(endpos,0))-To_Number(Nvl(startpos,0))+1 AS lengthOfField FROM IMP_LAYOUTS_FIELDS WHERE upper(COLUMNNAME)=? "
			+ " AND LAYOUTID= ? " + " AND sublayoutid=? ";

	public static String getDetailsQuery = "SELECT a.SN, a.SUBLAYOUTID, a.COLUMNID, a.COLUMNNAME, a.DATATYPE, DATETYPEDETIAL, a.STARTPOS, a.FIELDLENGTH, b.CTRL_FIELD,"
			+ " a.endpos,a.fieldlinenumber,a.fielddelimiter,l.layouttypeid,a.fieldposition,f.layouttypeid"
			+ " FROM ( SELECT 	a.SN, a.layoutid,	a.SUBLAYOUTID,a.COLUMNID,a.COLUMNNAME,a.DATATYPE,Nvl(a.datetypedetial,'NA') AS datetypedetial,To_Number(Nvl(STARTPOS,'1')) AS STARTPOS,FIELDLENGTH,a.endpos,fieldlinenumber,Upper(fielddelimiter) AS FIELDDELIMITER,fieldposition "
			+ " FROM IMP_LAYOUTS_FIELDS a WHERE LAYOUTID= ? "
			+ " AND SUBLAYOUTID= ? "
			+ " ORDER BY To_Number(COLUMNID)) a left JOIN  imp_ctrl_map b ON a.SN=b.LAYOUT_SN "
			+ "left JOIN imp_sub_layouts s ON a.layoutid = s.layoutid  AND  a.sublayoutid = s.sublayoutid"
			+ " left JOIN  tbl_filepatterns_layout  f ON Upper(s.layouttype)=Upper(f.layouttype)"
			+ " left JOIN tbl_filepatterns_layout l ON  Upper(a.fielddelimiter) = Upper(l.layouttype) WHERE b.CTRL_FIELD IS NOT NULL ";
	public static String getAllQuery = "SELECT DISTINCT LAYOUTID FROM IMP_LAYOUTS"; // WHERE
																					// MANUALFLAG='N'";
	public static String checkControlLayoutQuery = " SELECT DATATYPE,nvl(SKIPROW,'0'),nvl(PUCHCHARFLAG,'Y'),nvl(OPTIONALLY,'Y'),nvl(TRAILERSKIP,'0') FROM imp_layouts where layoutid = ? ";
	public static PreparedStatement subLayoutQueryPreparedStatement = null;
	public static PreparedStatement colNoQueryPreparedStatement = null;
	public static PreparedStatement getDetailsQueryPreparedStatement = null;
	public static PreparedStatement getAllQueryPreparedStatement = null;
	public static PreparedStatement checkControlTotalLayoutPreparedStatement = null;
	private static boolean invalidWhereClauseFlag = false;

	/**
	 * @see GenerateAllAttribute#initialize(Connection)
	 */
	public static void initialize(Connection connArg) {
		conn = connArg;

		try {

			subLayoutQueryPreparedStatement = conn
					.prepareStatement(subLayoutQuery);
			colNoQueryPreparedStatement = conn.prepareStatement(colNoQuery);
			getDetailsQueryPreparedStatement = conn
					.prepareStatement(getDetailsQuery);
			checkControlTotalLayoutPreparedStatement = conn
					.prepareStatement(checkControlLayoutQuery);
			isInitialized = true;
		} catch (Exception e) {
			System.err.println("ERROR B");
			System.err.println("Error: " + e.getMessage()
					+ " Initialize Connection");
		}
	}

	/**
	 * @see GenerateAllAttribute#generate(String...)
	 */
	public static Map<String, String> generate(String... strings) {

		if (strings.length != 0) {
			try {
				String tempLayoutId;
				getAllQueryPreparedStatement = conn
						.prepareStatement(getAllQuery);
				ResultSet allLayouts = getAllQueryPreparedStatement
						.executeQuery();
				while (allLayouts.next()) {
					tempLayoutId = allLayouts.getString(1).trim();
					String temp = getCAttribute(tempLayoutId);
					if (temp != "") {
						allCAttributeHashtable.put(tempLayoutId, temp);
					}
				}
				return allCAttributeHashtable;

			} catch (SQLException e) {
				System.err.println("Error M : " + e.getMessage());
			}
		}
		return null;
	}

	/**
	 * @see GenerateAllAttribute#endConnection()
	 */

	public static void endConnection() {
		try {
			if (subLayoutQueryPreparedStatement != null) {
				subLayoutQueryPreparedStatement.close();
			}
			if (colNoQueryPreparedStatement != null) {
				colNoQueryPreparedStatement.close();
			}
			if (getDetailsQueryPreparedStatement != null) {
				getDetailsQueryPreparedStatement.close();
			}
			if (checkControlTotalLayoutPreparedStatement != null) {
				checkControlTotalLayoutPreparedStatement.close();
			}

		} catch (Exception e) {
			System.err.println("ERROR C");
			System.err.println("Error:" + e.getMessage() + " EndConnection");
		}
	}

	/**
	 * @see GenerateAllAttribute#resultSetToListOfList(PreparedStatement)
	 */
	private static List<List<String>> resultSetToListOfList(
			PreparedStatement stm) {
		try {
			ResultSet rs = stm.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			List<String> columnNames = new ArrayList<String>(numberOfColumns);
			// Get the column names
			for (int column = 0; column < numberOfColumns; column++) {
				columnNames.add(metaData.getColumnLabel(column + 1));
			}
			// Get all rows, but first make the first row the column names
			List<List<String>> rows = new ArrayList<List<String>>();
			rows.add(columnNames);
			while (rs.next()) {
				List<String> newRow = new ArrayList<String>(numberOfColumns);
				for (int i = 1; i <= numberOfColumns; i++) {
					if (rs.getObject(i) != null && rs.getObject(i) != "") {
						newRow.add(rs.getObject(i).toString());
					} else {
						newRow.add("");
					}
				}
				rows.add(newRow);
			}
			if (rs != null) {
				rs.close();
			}

			return rows;

		} catch (Exception e) {
			System.err.println("ERROR D");
			System.err.println("Error: " + e.getMessage()
					+ " Result Set To List OF List " + stm.toString());
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Method to replace the unwanted characters from the whereclause
	 * 
	 * @param sublayoutWhereClause
	 * @return
	 */
	private static String getReplacedWhereclause(String sublayoutWhereClause) {

		String replacedWhereClause = "";
		replacedWhereClause = sublayoutWhereClause.replaceAll("[']", "")
				.replaceAll("(\\((\\d+:\\d+)\\))", "$2");
		return replacedWhereClause;

	}

	private static String generateFmonParsableWhereclause(String subLayoutType,
			String replacedWhereClause, String shortDelimiter, String layoutId,
			String subLayoutID, boolean controlFlag) {
		String whereClause = "";
		String operator = "";
		String whereClauseLHS = "";
		String whereClauseRHS = "";
		int startpos = 0;
		int endpos = 0;
		String controlCondition = "";

		if (replacedWhereClause.contains("!=")) {
			operator = "!=";
			whereClauseLHS = replacedWhereClause.substring(0,
					replacedWhereClause.indexOf("!"));
			whereClauseRHS = replacedWhereClause.substring(
					replacedWhereClause.indexOf("!") + 2,
					replacedWhereClause.length());
		} else if (replacedWhereClause.contains("=")) {
			operator = "=";
			whereClauseLHS = replacedWhereClause.substring(0,
					replacedWhereClause.indexOf("="));
			whereClauseRHS = replacedWhereClause.substring(
					replacedWhereClause.indexOf("=") + 1,
					replacedWhereClause.length());

		}
		whereClauseRHS = whereClauseRHS.trim();
		whereClauseLHS = whereClauseLHS.trim();

		if (whereClauseLHS.matches(".*(\\d+:\\d+).*")) {
			try {
				startpos = Integer.parseInt(whereClauseLHS.substring(0,
						whereClauseLHS.indexOf(":")).trim());
				endpos = Integer.parseInt(whereClauseLHS.substring(
						whereClauseLHS.indexOf(":") + 1,
						whereClauseLHS.length()).trim());
			} catch (NumberFormatException e) {
				System.err
						.println("Number Format Exception in whereclause for given Layoutid "
								+ layoutId);
				invalidWhereClauseFlag = true;

			}

			whereClause = (startpos) + "," + (endpos - startpos + 1) + "|"
					+ operator + "|" + whereClauseRHS;
			controlCondition = "CONTROLIDENT" + "|FIXED|" + whereClause;

		} else if (!controlFlag) {
			whereClauseLHS = whereClauseLHS.toUpperCase();
			try {
				colNoQueryPreparedStatement.setString(1, whereClauseLHS);
				colNoQueryPreparedStatement.setString(2, layoutId);
				colNoQueryPreparedStatement.setString(3, subLayoutID);
			} catch (SQLException e) {
				System.err.println("ERROR: G " + e.getMessage());
			}

			List<List<String>> colNo = null;
			colNo = resultSetToListOfList(colNoQueryPreparedStatement);
			if (colNo.size() > 1) {
				try {
					Integer.parseInt(colNo.get(1).get(0));
				} catch (Exception e) {
					invalidWhereClauseFlag = true;
				}
				if (subLayoutType.equalsIgnoreCase("Fixed length")) {
					whereClause = colNo.get(1).get(1) + ","
							+ colNo.get(1).get(2) + "|" + operator + "|"
							+ whereClauseRHS;
					controlCondition = "CONTROLIDENT" + "|FIXED|" + whereClause;
				} else {
					whereClause = colNo.get(1).get(0) + "|" + operator + "|"
							+ whereClauseRHS;

					controlCondition = "CONTROLIDENT" + "|" + shortDelimiter
							+ "|" + whereClause;
				}

			} else {
				invalidWhereClauseFlag = true;
			}
		}
		return controlCondition;
	}

	private static String parseWhereClause(String subLayoutType,
			String replacedWhereClause, String shortDelimiter, String layoutId,
			String subLayoutID, boolean controlFlag) {
		String combinedWhereClause = "";
		List<String> name = Arrays.asList(replacedWhereClause.split(
				"(?i)(\\sAND\\s)|(\\sOR\\s)", -1));

		Iterator<String> iter = name.iterator();
		String firstCondition = iter.next();

		String whereClause = generateFmonParsableWhereclause(subLayoutType,
				firstCondition, shortDelimiter, layoutId, subLayoutID,
				controlFlag);
		int firstPosition = firstCondition.length() - 1;
		if (replacedWhereClause.length() == firstCondition.length()) {
			return whereClause;
		} else {
			combinedWhereClause = whereClause + "\n";
			while (iter.hasNext()) {
				String temp = iter.next();

				whereClause = "\n"
						+ generateFmonParsableWhereclause(subLayoutType, temp,
								shortDelimiter, layoutId, subLayoutID,
								controlFlag);
				int lastPosition = replacedWhereClause.lastIndexOf(temp);
				String operator = replacedWhereClause.substring(firstPosition,
						lastPosition);

				if (operator.toUpperCase().contains("AND")) {
					combinedWhereClause += "CONTROLCONDITION|AND";
				} else if (operator.toUpperCase().contains("OR")) {
					combinedWhereClause += "CONTROLCONDITION|OR";
				} else {
					invalidWhereClauseFlag = true;
				}
				firstPosition += temp.length();
				combinedWhereClause += whereClause;
				if (iter.hasNext()) {
					combinedWhereClause += "\n";
				}
			}
		}

		return combinedWhereClause;
	}

	/**
	 * This Method generates the Control Total Attribute Script
	 */
	public static String getCAttribute(String layoutId) {
		String returnString = "";
		List<List<String>> sublayout = null;
		List<List<String>> controlCheckList = null;
		String skipRow = "";
		String trailer = "";
		String punchchar = "";
		String optionallyEnclosed = "";
		try {
			subLayoutQueryPreparedStatement.setString(2, layoutId);
			subLayoutQueryPreparedStatement.setString(1, layoutId);
			checkControlTotalLayoutPreparedStatement.setString(1, layoutId);
		} catch (SQLException e) {
			System.err.println("ERROR: E" + e.getMessage());
		}

		sublayout = resultSetToListOfList(subLayoutQueryPreparedStatement);
		controlCheckList = resultSetToListOfList(checkControlTotalLayoutPreparedStatement);
		boolean controlFlag = false;
		if (controlCheckList.size() == 2) {
			controlFlag = controlCheckList.get(1).get(0)
					.equalsIgnoreCase("Control Total");
			skipRow = controlCheckList.get(1).get(1);
			punchchar = controlCheckList.get(1).get(2);
			optionallyEnclosed = controlCheckList.get(1).get(3);
			trailer = controlCheckList.get(1).get(4);
		}
		if (sublayout.size() > 1) {
			for (int i = 1; i < sublayout.size(); i++) {
				String subLayoutId = sublayout.get(i).get(0);
				String subLayoutType = sublayout.get(i).get(1);
				String subLayoutWhereClause = sublayout.get(i).get(3);
				String replacedWhereClause = "";
				try {
					replacedWhereClause = getReplacedWhereclause(subLayoutWhereClause);
				} catch (Exception e) {
					System.err.println("ERROR!! Whereclause Not Valid");
				}
				String controlCondition;
				String shortDelimiter = sublayout.get(i).get(7);
				String sumFlag = sublayout.get(i).get(12);
				String trailerWhereclauseFlag = sublayout.get(i).get(11);
				if (trailerWhereclauseFlag.equalsIgnoreCase("Y")) {
					controlCondition = "CONTROLIDENT|TRAILER";
				} else {
					controlCondition = parseWhereClause(subLayoutType,
							replacedWhereClause, shortDelimiter, layoutId,
							subLayoutId, controlFlag);
				}
				if (invalidWhereClauseFlag) {
					invalidWhereClauseFlag = false;
					return "INVALID|NO WHERECLAUSE FIELD FOUND";
				}

				try {
					getDetailsQueryPreparedStatement.setString(1, layoutId);
					getDetailsQueryPreparedStatement.setString(2, subLayoutId);
				} catch (SQLException e) {
					System.err.println("ERROR: H" + e.getMessage());
				}
				List<List<String>> sublayoutDetail = null;
				sublayoutDetail = resultSetToListOfList(getDetailsQueryPreparedStatement);
				if (controlFlag) {
					if (trailerWhereclauseFlag.equalsIgnoreCase("Y")) {
						returnString = "CONTROLIDENT|TRAILER";
					} else {
						returnString = "CONTROLIDENT|ALL";
					}
					if (subLayoutType.equalsIgnoreCase("HORIZONTAL")) {
						if (sublayoutDetail.size() > 1) {

							returnString += "\nHEADER|" + skipRow + "\n";
							returnString += "TRAILER|" + trailer + "\n";
							returnString += "OPTENC|" + optionallyEnclosed
									+ "\n";
							returnString += "PUCHCHAR|" + punchchar + "\n";
							returnString += "TYPE|H\n";
							returnString += "SUM|" + sumFlag;

							for (int j = 1; j < sublayoutDetail.size(); j++) {
								returnString += "\n";
								String dateTypeDetail = sublayoutDetail.get(j)
										.get(5);
								if (sublayoutDetail.get(j).get(11)
										.equalsIgnoreCase("Fixed length")) {
									int length;
									returnString += sublayoutDetail.get(j).get(
											8)
											+ "|"
											+ sublayoutDetail.get(j).get(10)
											+ "|"
											+ sublayoutDetail.get(j).get(12)
											+ "|";
									returnString += sublayoutDetail.get(j).get(
											6)
											+ ",";

									try {
										length = (Integer
												.parseInt(sublayoutDetail
														.get(j).get(9))
												- Integer
														.parseInt(sublayoutDetail
																.get(j).get(6)) + 1);
									} catch (Exception e) {
										System.err
												.println("Error!! Invalid Cattr!! ");
										return "";
									}
									returnString += length;

									if (!dateTypeDetail.equalsIgnoreCase("NA")) {
										returnString += "|" + dateTypeDetail;
									}
								} else {
									returnString += sublayoutDetail.get(j).get(
											8)
											+ "|"
											+ sublayoutDetail.get(j).get(10)
											+ "|"
											+ sublayoutDetail.get(j).get(12)
											+ "|"
											+ sublayoutDetail.get(j).get(13);
									if (!dateTypeDetail.equalsIgnoreCase("NA")) {
										returnString += "|" + dateTypeDetail;
									}
								}

							}
						} else {
							returnString += "\nINVALID|NO MAPPING DEFINED";
						}

					} else if (subLayoutType.equalsIgnoreCase("VERTICAL")) {

						if (sublayoutDetail.size() > 1) {
							returnString += "\nHEADER|" + skipRow + "\n";
							returnString += "TRAILER|" + trailer + "\n";
							returnString += "OPTENC|" + optionallyEnclosed
									+ "\n";
							returnString += "PUCHCHAR|" + punchchar + "\n";
							returnString += "TYPE|V\n";
							returnString += "SUM|" + sumFlag;

							for (int j = 1; j < sublayoutDetail.size(); j++) {

								returnString += "\n";
								String dateTypeDetail = sublayoutDetail.get(j)
										.get(5);
								if (sublayoutDetail.get(j).get(11)
										.equalsIgnoreCase("Fixed length")) {
									int length;
									returnString += sublayoutDetail.get(j).get(
											8)
											+ "|"
											+ sublayoutDetail.get(j).get(12)
											+ "|";
									returnString += sublayoutDetail.get(j).get(
											6)
											+ ",";

									try {
										length = (Integer
												.parseInt(sublayoutDetail
														.get(j).get(9))
												- Integer
														.parseInt(sublayoutDetail
																.get(j).get(6)) + 1);
									} catch (Exception e) {
										System.err
												.println("Error!! Invalid Cattr!! ");
										return "";
									}
									returnString += length;

									if (!dateTypeDetail.equalsIgnoreCase("NA")) {
										returnString += "|" + dateTypeDetail;
									}
								} else {
									returnString += sublayoutDetail.get(j).get(
											8)
											+ "|"
											+ sublayoutDetail.get(j).get(12)
											+ "|"
											+ sublayoutDetail.get(j).get(13);
									if (!dateTypeDetail.equalsIgnoreCase("NA")) {
										returnString += "|" + dateTypeDetail;
									}
								}

							}
						} else {
							returnString += "\nINVALID|NO MAPPING DEFINED";
						}

					}
				} else {

					if (subLayoutType.equalsIgnoreCase("Fixed length")) {
						returnString = controlCondition;
						returnString += "\nHEADER|" + skipRow + "\n";
						returnString += "TRAILER|" + trailer + "\n";
						returnString += "OPTENC|" + optionallyEnclosed + "\n";
						returnString += "PUCHCHAR|" + punchchar + "\n";
						returnString += "SUM|" + sumFlag;

						if (sublayoutDetail.size() > 1) {
							for (int j = 1; j < sublayoutDetail.size(); j++) {
								String dateTypeDetail = sublayoutDetail.get(j)
										.get(5); // ADDED DATE FOR INLINE CTL ON
													// 03-16-2015
								returnString += "\n"
										+ sublayoutDetail.get(j).get(8) + "|"
										+ sublayoutDetail.get(j).get(14) + "|"
										+ sublayoutDetail.get(j).get(6) + ","
										+ sublayoutDetail.get(j).get(7);
								if (!dateTypeDetail.equalsIgnoreCase("NA")) {
									returnString += "|" + dateTypeDetail;
								}
							}
						} else {
							returnString += "\nINVALID|NO MAPPING DEFINED";
						}
					} else {
						returnString = controlCondition;
						returnString += "\nHEADER|" + skipRow + "\n";
						returnString += "TRAILER|" + trailer + "\n";
						returnString += "OPTENC|" + optionallyEnclosed + "\n";
						returnString += "PUCHCHAR|" + punchchar + "\n";
						returnString += "SUM|" + sumFlag;
						if (sublayoutDetail.size() > 1) {
							for (int j = 1; j < sublayoutDetail.size(); j++) {
								String dateTypeDetail = sublayoutDetail.get(j)
										.get(5); // ADDED DATE FOR INLINE CTL ON
													// 03-16-2015
								returnString += "\n"
										+ sublayoutDetail.get(j).get(8) + "|"
										+ sublayoutDetail.get(j).get(14) + "|"
										+ sublayoutDetail.get(j).get(2);
								if (!dateTypeDetail.equalsIgnoreCase("NA")) {
									returnString += "|" + dateTypeDetail;
								}
							}
						} else {
							returnString += "\nINVALID|NO MAPPING DEFINED";
						}
					}
				}
			}
		}
		return (returnString);
	}

}
