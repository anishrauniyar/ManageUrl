package generateScript;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import svnPush.CommitToSVN;
//import svnPush.PushToSVN;
import databaseFactory.DatabaseFactory;
import databaseFactory.DatabaseProduction;

/**
 * Main Controller Class for the generation of attribute scripts,
 * control-attribute scripts and import scripts;
 * 
 * @author Ayam Pokhrel
 * @version 1.0
 */
public class Generator {
	/**
	 * Connect String for database
	 */
	public static String connectString;
	/**
	 * Schema name
	 */
	public static String user;

	/**
	 * Password
	 */
	public static String password;
	/**
	 * Database Connection
	 */
	public static Connection conn;
	/**
	 * Insert Query for insertion into svn
	 */
	public static String svnDatabaseInsertQuery = "Insert into imp_svn_checkin(layoutid,scripttype,script_name,from_date,created_date,created_by) values (?,?,?,sysdate,sysdate,'Generator Tool')";
	// public static String svnDatabaseDeleteQuery
	// ="DELETE FROM imp_svn_checkin where layoutid = ?";
	/**
	 * Prepared Statement for svn Insertion
	 */
	public static PreparedStatement svnInsertQuery;
	// public static PreparedStatement svnDeleteQuery;
	// public static String truncateQuery = "TRUNCATE TABLE imp_svn_checkin";
	/**
	 * Prepared Statement for svn truncate
	 */
	public static PreparedStatement truncateSvnEntries;

	/**
	 * Database Connection Flag
	 */
	public static boolean mainConnectionFlag = false;
	/**
	 * SVN Flag
	 */
	public static boolean svnFlag = false;
	/**
	 * Run Time Flag for Override Feature
	 */
	public static boolean runTimeFlag = false;
	/**
	 * Flag for table insertion(imp_svn_checkin)
	 */
	public static boolean insertIntoTable = true;

	/**
	 * Method to establish the database connection
	 */
	public static void establishMainConnection() {
		conn = null;
		DatabaseProduction dbFactory = new DatabaseFactory();
		try {
			conn = dbFactory.getDatabaseConnection("ORACLE", connectString,
					user, password);
			svnInsertQuery = conn.prepareStatement(svnDatabaseInsertQuery);
			// svnDeleteQuery=conn.prepareStatement(svnDatabaseDeleteQuery);
			// truncateSvnEntries = conn.prepareStatement(truncateQuery);
			mainConnectionFlag = true;
		} catch (ClassNotFoundException e) {
			System.err.println("ERROR");
			System.err.println(e.getMessage() + " Driver Class not found");
		} catch (SQLException e) {
			System.err.println("ERROR");
			System.err.println(e.getMessage() + " Connection Failed");
		}

	}

	/**
	 * Method to end the main connection
	 */

	public static void endMainConnection() {
		if (mainConnectionFlag) {
			if (svnInsertQuery != null) {
				try {
					svnInsertQuery.close();
				} catch (SQLException e) {
					System.err.println("ERROR!! cannot Close Statement");
				}

			}
			/*if (truncateSvnEntries != null) {
				try {
					truncateSvnEntries.close();
				} catch (SQLException e) {
					System.err.println("ERROR!! cannot Close Statement");
				}

			}*/
			if (conn != null) {
				try {
					conn.commit();
					conn.close();
				} catch (SQLException e) {
					System.err.println("ERROR!!! Connection Closing Failed");
				}
			}
		}
	}

	/**
	 * Usage Function for displaying the usage
	 * 
	 * @param options
	 *            Command Line Options
	 */
	private static void usage(Options options) {
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("Generator", options);
		System.err.println("Examples:");
		System.err
				.println("java -jar Generator.jar -t A -c 10.48.6.216:1521:d2he -u IMPORTDB -p oracle -l ALL -d /data1/AIP/attr ");
		System.err
				.println("java -jar Generator.jar -t C -c 10.48.6.216:1521:d2he -u IMPORTDB -p oracle -l 25");
		System.err
				.println("java -jar Generator.jar -t I -c 10.48.6.216:1521:d2he -u IMPORTDB -p oracle -l 25 -i Y ");
		System.err
				.println("java -jar Generator.jar -t I -c 10.48.6.216:1521:d2he -u IMPORTDB -p oracle -l ALL -d /data1/AIP/sql -i N ");

		System.err
				.println("java -jar Generator.jar -z -s /data1/AIP/datadashboard/utilities/Scripts/ -c 10.48.6.216:1521:d2he -u IMPORTDB -p oracle -f /u05/AIP/conf/GENERATOR.properies");

		System.err
				.println("-----------------------------------------------------------------------------------------------");
		System.exit(1);
	}

	/**
	 * Method to dump scripts into files.
	 * 
	 * @param table
	 *            Key Value Pairs of layoutid and respective scripts
	 * @param type
	 *            Type of the script to be dumped (Attribute, C-Attribute or
	 *            Import Script)
	 * 
	 * @param location
	 *            Location or path of the directory where files are to be dumped
	 * 
	 */
	public static void writeToFile(Map<String, String> table, String type,
			String location) {
		String extension = "unknown";
		String prefix = "";
		String version = "";
		String emptyLine = "";
		String scriptType = "";
		if (type.equalsIgnoreCase("A")) {
			scriptType = "attr";
			extension = "attr";
			version = "#Version 1.0 , Generated on "
					+ new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
							.format(Calendar.getInstance().getTime()) + "\n";
			emptyLine = "\n";

		} else if (type.equalsIgnoreCase("C")) {
			scriptType = "cattr";
			extension = "cattr";
			version = "#Version 1.0 , Generated on "
					+ new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
							.format(Calendar.getInstance().getTime()) + "\n";
			emptyLine = "\n";
		} else if (type.equalsIgnoreCase("I")) {
			scriptType = "import";
			extension = "sql";
			prefix = "IP_";
		}

		FileWriter fw = null;
		BufferedWriter bw = null;
		for (Map.Entry<String, String> entry : table.entrySet()) {
			String nameOfFile = prefix + entry.getKey() + "." + extension;
			/*File file = new File(location + "/" + prefix + entry.getKey() + "."
					+ extension);*/
			File file = new File(location + "/" + nameOfFile);
			if (!file.exists()) {
				try {
					file.createNewFile();

				} catch (IOException e) {
					System.err.println("ERROR!!" + e.getMessage()
							+ " File Creating Error! compileProcedure");
				}
			}
			try {
				fw = new FileWriter(file.getAbsoluteFile(), false);
				bw = new BufferedWriter(fw);
				bw.write(version);
				bw.write(entry.getValue());
				bw.write(emptyLine);
				bw.flush();
				fw.flush();
				bw.close();
				fw.close();
				if (insertIntoTable == true) {
					svnInsertQuery.setObject(1, entry.getKey());
					svnInsertQuery.setObject(2, scriptType);
					svnInsertQuery.setObject(3, nameOfFile);
					svnInsertQuery.addBatch();
				}
				// svnDeleteQuery.setObject(1, entry.getKey());
				// svnDeleteQuery.addBatch();
			} catch (IOException e) {
				System.err.println("ERROR " + e.getMessage());
			} catch (SQLException e) {
				System.err.println("ERROR " + e.getMessage());
			}
		}
	}

	/**
	 * Main Method of the generator
	 * 
	 * @param args
	 *            Command Line Arguments
	 * 
	 */
	public static void main(String... args) {
		Set<String> operations = new HashSet<String>();
		operations.add("A");
		operations.add("C");
		operations.add("I");
		Options options = new Options();
		options.addOption("s", true, "<Root Directory Path for Svn Checkin>");
		options.addOption("c", true, "<Connect String>");
		options.addOption("u", true, "<SCHEMA/USER>");
		options.addOption("p", true, "<Password>");
		options.addOption("i", true, "<is test?[y/n]>");
		options.addOption("d", true, "<Dump Location>");
		options.addOption("t", true, "<Type of Script>[A or I or C]");
		options.addOption("l", true,
				"<Layout ID>[put ALL for all otherwise put certain number]");
		options.addOption("r", true, "Run Time Argument");
		options.addOption("z", false,
				"Specify this if test checkin is to be done");
		options.addOption("f", true, "<PropertiesFileLocation>");

		String sn = null;

		CommandLineParser parser = new BasicParser();
		CommandLine cmd;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException pe) {
			System.err.println(pe.getMessage());
			usage(options);
			endMainConnection();
			return;
		}

		String svnWorkingDirectory;
		String attrPath, cattrPath, importPath;
		if (cmd.hasOption("f")) {
			File file = new File(cmd.getOptionValue('f'));
			if (!file.exists()) {
				System.err.println("Properties File Not Found");
				usage(options);
				System.exit(1);
			} else {
				try {
					utilities.PropsUtils.sourceAllVariables(file);
				} catch (Exception e) {
					System.exit(1);
				}

			}
		}
		if (!cmd.hasOption("c") || !cmd.hasOption("u") || !cmd.hasOption("p")) {
			usage(options);
			endMainConnection();
			System.exit(1);
		} else {
			connectString = (cmd.getOptionValue('c'));
			user = (cmd.getOptionValue('u'));
			password = (cmd.getOptionValue('p'));
			establishMainConnection();
		}
		if (cmd.hasOption("r")) {
			runTimeFlag = true;
			sn = cmd.getOptionValue('r');
		}
		if (cmd.hasOption("z")) {
			CommitToSVN.testCheckin = true;
			System.out.println("Test Checkin.. Database Insertion is false");
			insertIntoTable = false;
		}

		if (cmd.hasOption("s")) {
			if (!cmd.hasOption('f')) {
				System.err.println("Configuration file not Provided");
				usage(options);
				System.exit(1);
			}
			svnWorkingDirectory = (cmd.getOptionValue('s'));
			File file = new File(svnWorkingDirectory);
			if (!file.exists() || !file.canWrite() || !file.isDirectory()) {
				System.err
						.println("ERROR !! Invalid SVN Working Directory.. Check Directory or Write Permissions");
				System.exit(1);

			} else {
				svnFlag = true;
				String temp = file.getAbsolutePath();
				attrPath = temp + "/attr";
				cattrPath = temp + "/cattr";
				importPath = temp + "/importscripts";
				File attrDir = new File(attrPath);
				File cattrDir = new File(cattrPath);
				File importDir = new File(importPath);
				if (!attrDir.exists()) {
					attrDir.mkdir();
					attrDir.setWritable(true);
				}
				if (!cattrDir.exists()) {
					cattrDir.mkdir();
					cattrDir.setWritable(true);
				}
				if (!importDir.exists()) {
					importDir.mkdir();
					importDir.setWritable(true);
				}

				// SVN WORKINGS
				// ....................................................

				GenerateAllImportScript.initialize(conn);
				Map<String, String> table = GenerateAllImportScript
						.generate("N");
				CommitToSVN.checkOutAndCommit(importPath, 2, 1);
				writeToFile(table, "I", importPath);
				GenerateAllImportScript.endConnection();
				CommitToSVN.checkOutAndCommit(importPath, 2, 2);

				GenerateAllAttribute.initialize(conn);
				Map<String, String> tableAttribute = GenerateAllAttribute
						.generate("ALL");
				CommitToSVN.checkOutAndCommit(attrPath, 0, 1);
				writeToFile(tableAttribute, "A", attrPath);
				GenerateAllAttribute.endConnection();
				CommitToSVN.checkOutAndCommit(attrPath, 0, 2);

				GenerateAllCAttribute.initialize(conn);
				Map<String, String> tableCattr = GenerateAllCAttribute
						.generate("ALL");
				CommitToSVN.checkOutAndCommit(cattrPath, 1, 1);
				writeToFile(tableCattr, "C", cattrPath);
				GenerateAllCAttribute.endConnection();
				CommitToSVN.checkOutAndCommit(cattrPath, 1, 2);

				try {
					// truncateSvnEntries.execute();
					// svnDeleteQuery.executeBatch();
					if (insertIntoTable = true) {
						svnInsertQuery.executeBatch();
					}
				} catch (SQLException e) {
					System.err.println("Cannot Insert into imp_svn_checkin");
				}

			}

		} else {
			if (!cmd.hasOption("t")
					|| !operations.contains(cmd.getOptionValue('t')
							.toUpperCase())) {
				usage(options);
				endMainConnection();
				System.exit(1);
			} else {
				String argument = cmd.getOptionValue('t');
				if (!cmd.hasOption("l")) {
					usage(options);
					endMainConnection();
					System.exit(1);
				}
				if (argument.equalsIgnoreCase("A")) {

					String attribute;
					String layoutid = cmd.getOptionValue('l');
					String Version = "#Version 1.0 , Generated on "
							+ new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
									.format(Calendar.getInstance().getTime());

					if (layoutid.equalsIgnoreCase("ALL")) {
						if (!cmd.hasOption("d")) {
							usage(options);
							// GenerateAllAttribute.endConnection();
							endMainConnection();
							System.exit(1);
						} else {
							GenerateAllAttribute.initialize(conn);
							Map<String, String> table = GenerateAllAttribute
									.generate("ALL");
							writeToFile(table, "A", cmd.getOptionValue('d'));
						}

					} else {
						if (runTimeFlag) {
							GenerateAllAttribute.sn = sn;
							GenerateAllAttribute.runTimeFlag = true;
						}
						GenerateAllAttribute.initialize(conn);
						String attDesc = GenerateAllAttribute
								.getAttributeScript(layoutid);
						attribute = Version + "\n" + attDesc;
						if (attDesc == "") {
							System.err
									.println("ERROR: NO Datafile Layout Found");
							System.exit(1);
						} else if (attDesc == "Import Script is not generated for Control Control") {
							System.err
									.println("Import Script is not generated for Control Control");
							System.exit(1);
						} else {
							System.out.println(attribute);
						}

					}
					GenerateAllAttribute.endConnection();

				}
				if (argument.equalsIgnoreCase("I")) {
					String script;
					String layoutid = cmd.getOptionValue('l');
					GenerateAllImportScript.initialize(conn);

					if (layoutid.equalsIgnoreCase("ALL")) {
						if (!cmd.hasOption("d") || !cmd.hasOption("i")) {
							usage(options);
							GenerateAllImportScript.endConnection();
							endMainConnection();
							System.exit(1);
						} else {

							Map<String, String> table = GenerateAllImportScript
									.generate(cmd.getOptionValue('i'));
							writeToFile(table, "I", cmd.getOptionValue('d'));
						}

					} else {
						if (!cmd.hasOption("i")) {
							usage(options);
							GenerateAllImportScript.endConnection();
							endMainConnection();
							System.exit(1);
						} else {
							if (!cmd.getOptionValue('i').equalsIgnoreCase("Y")
									&& !cmd.getOptionValue('i')
											.equalsIgnoreCase("N")) {

								usage(options);
								GenerateAllImportScript.endConnection();
								endMainConnection();
								System.exit(1);
							} else {
								String version = "--Version 1.0 , Generated on "
										+ new SimpleDateFormat(
												"yyyy-MM-dd hh:mm:ss")
												.format(Calendar.getInstance()
														.getTime());
								boolean isTest = cmd.getOptionValue('i')
										.equalsIgnoreCase("Y");
								script = GenerateAllImportScript
										.imprtScrptGeneration(layoutid, isTest,
												version);
								if (script.equals("ERROR: No Layout Found")) {
									System.err
											.println("ERROR: No Layout Found");
									System.exit(1);
								} else if (script
										.equals("Import Script is not generated for Control Control")) {
									System.err
											.println("Import Script is not generated for Control Control");
									System.exit(1);
								} else {
									System.out.println(script);
								}
							}
						}
					}
					GenerateAllImportScript.endConnection();
				}
				if (argument.equalsIgnoreCase("C")) {
					String cAttribute;
					String layoutid = cmd.getOptionValue('l');
					GenerateAllCAttribute.initialize(conn);

					if (layoutid.equalsIgnoreCase("ALL")) {
						if (!cmd.hasOption("d")) {
							usage(options);
							GenerateAllCAttribute.endConnection();
							endMainConnection();
							System.exit(1);
						} else {
							Map<String, String> table = GenerateAllCAttribute
									.generate("ALL");
							writeToFile(table, "C", cmd.getOptionValue('d'));
						}

					} else {
						cAttribute = GenerateAllCAttribute
								.getCAttribute(layoutid);
						if (cAttribute == "") {
							System.err
									.println("ERROR: No Cattr for this Layout");
							System.exit(1);
						} else {
							String version = "#Version 1.0 , Generated on "
									+ new SimpleDateFormat(
											"yyyy-MM-dd hh:mm:ss")
											.format(Calendar.getInstance()
													.getTime()) + "\n";
							System.out.println(version + cAttribute);
						}
					}
					GenerateAllCAttribute.endConnection();
				}
			}

		}

		if (mainConnectionFlag) {
			endMainConnection();
		}
		System.exit(0);

	}
}
