package generateScript;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is the wrapper class for generating import Script. Purpose :
 * Generates Import script
 * 
 * @version 1.0
 */
public class GenerateAllImportScript {

	/**
	 * Connection object to hold Single & Main Connection
	 */
	public static Connection conn;
	/**
	 * Flag to Check if the connection is initialized
	 */
	static boolean isInitialized = false;
	/**
	 * stores key value pairs of layout id and their attribute Scripts
	 */
	public static Map<String, String> allImportScriptHashtable = new HashMap<String, String>();
	public static String logsBasePath = "/aipfs/AIPDBLogs/oracleImportDetailLogs";
	public static String layoutTypeCheckingQuery = " SELECT DATATYPE,PAYOR,nvl(characterset,'US7ASCII') as CHARACTERSET  FROM imp_layouts WHERE layoutid = ?";
	public static String layoutInfoQuery = "SELECT LAYOUTID, PAYOR, DATATYPE,'NULL' AS LAYOUTTYPE ,'NULL' as LAYOUTDETAIL, "
			+ " PUCHCHARFLAG, OPTIONALLY, SKIPROW,upper(SHORTPAYOR) FROM IMP_LAYOUTS WHERE LAYOUTID= ? ";

	public static String subLayoutsInfoQuery = "SELECT  distinct SUBLAYOUTID,LAYOUTTYPE ,LAYOUTDETAIL,REPLACE(Nvl(WHERECLAUSE,'NA'),'''','''''') "
			+ " WHERECLAUSE FROM IMP_SUB_LAYOUTS WHERE LAYOUTID= ? AND SUBLAYOUTDESC='DATAFILE'";

	public static String currentSublayoutFieldsQuery = "Select SUBLAYOUTID,Nvl(COLUMNNAME,'NA'),Nvl(DATATYPE,'NA'),"
			+ " Nvl(DATETYPEDETIAL,'NA'),Nvl(FIELDLENGTH,200),STARTPOS,ENDPOS FROM  IMP_LAYOUTS_FIELDS WHERE LAYOUTID=? "
			+ "AND SUBLAYOUTID= ?  ORDER BY To_Number(COLUMNID)";
	public static String extractFieldTermnatorQuery = "SELECT FIELDTERMINATOR FROM TBL_FILEPATTERNS_LAYOUT   WHERE Upper(LAYOUTTYPE)= ? ";
	public static String getAllQuery = "SELECT DISTINCT LAYOUTID FROM IMP_LAYOUTS WHERE MANUALFLAG='N' and LAYOUT_STATUS='FINALIZED' AND Upper(DATATYPE) NOT LIKE '%CONTROL%' ";
	public static String delimiterQuery = "SELECT FIELDTERMINATOR FROM  TBL_FILEPATTERNS_LAYOUT WHERE LAYOUTTYPE = (SELECT LAYOUTTYPE FROM  IMP_SUB_LAYOUTS WHERE LAYOUTID = ? AND sublayoutid='1')";
	public static String checkDateOverrideCompatibilityQry = "SELECT DISTINCT upper(datetypedetial) FROM imp_layouts_fields a left JOIN imp_sub_layouts b ON      a.layoutid=b.layoutid     AND a.sublayoutid=b.sublayoutid WHERE a.layoutid = ? AND upper(a.datetypedetial) !='NA' AND upper(a.datatype) IN ('DATE','TIMESTAMP') AND b.SUBLAYOUTDESC !='CONTROLTOTAL' ";
	public static PreparedStatement getAllQueryPreparedStatement = null;
	public static PreparedStatement layoutInfoPreparedStatement = null;
	public static PreparedStatement distinctSubLayoutInfoPreparedStatement = null;
	public static PreparedStatement currentSubLayoutFieldsPreparedStatement = null;
	public static PreparedStatement extractFieldTerminatorPreparedStatement = null;
	public static PreparedStatement delimeterQueryPreparedStatement = null;
	public static PreparedStatement layoutTypeQueryPreparedStatement = null;
	public static PreparedStatement checkDateOverrideCmptbltyPrepdStmt = null;

	/**
	 * Flag to check whether the layout is control total or not
	 */
	public static boolean controlTotalFlag = false;
	/**
	 * If true, this key value pair gets inserted into allImportScriptHashtable
	 * 
	 * @see GenerateAllAttribute#allAttributesHashtable
	 */
	public static boolean putIntoList = true;

	public static String payorName;

	/**
	 * Method to establish the oracle connection
	 */
	public static void initialize(Connection connArg) {
		conn = connArg;
		try {
			layoutInfoPreparedStatement = conn
					.prepareStatement(layoutInfoQuery);
			distinctSubLayoutInfoPreparedStatement = conn
					.prepareStatement(subLayoutsInfoQuery);
			currentSubLayoutFieldsPreparedStatement = conn
					.prepareStatement(currentSublayoutFieldsQuery);
			extractFieldTerminatorPreparedStatement = conn
					.prepareStatement(extractFieldTermnatorQuery);
			layoutTypeQueryPreparedStatement = conn
					.prepareStatement(layoutTypeCheckingQuery);
			delimeterQueryPreparedStatement = conn
					.prepareStatement(delimiterQuery);
			checkDateOverrideCmptbltyPrepdStmt = conn
					.prepareStatement(checkDateOverrideCompatibilityQry);
			isInitialized = true;
		} catch (Exception e) {
			System.err.println("ERROR");
			System.err.println(e.getMessage() + " Initialize Connection");
		}
	}

	/**
	 * Method to generate Script for all Layout
	 */
	public static Map<String, String> generate(String... strings) {
		if (strings.length != 0) {
			// boolean isTest = Boolean.parseBoolean(strings[0]);
			boolean isTest = strings[0].equalsIgnoreCase("Y");
			String version = "--Version 1.0 , Generated on "
					+ new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
							.format(Calendar.getInstance().getTime());
			try {
				String tempLayoutId;
				getAllQueryPreparedStatement = conn
						.prepareStatement(getAllQuery);
				ResultSet allLayouts = getAllQueryPreparedStatement
						.executeQuery();
				while (allLayouts.next()) {
					tempLayoutId = allLayouts.getString(1).trim();
					String tempScript = imprtScrptGeneration(tempLayoutId,
							isTest, version);
					if (putIntoList) {
						allImportScriptHashtable.put(tempLayoutId, tempScript);
					}
				}
				return allImportScriptHashtable;

			} catch (SQLException e) {
				System.err.println("Error M : " + e.getMessage());
			}
		}
		return null;
	}

	/**
	 * Method to close the oracle connection
	 */
	public static void endConnection() {
		try {
			if (layoutTypeQueryPreparedStatement != null) {
				layoutTypeQueryPreparedStatement.close();
			}
			if (layoutInfoPreparedStatement != null) {
				layoutInfoPreparedStatement.close();
			}
			if (distinctSubLayoutInfoPreparedStatement != null) {
				distinctSubLayoutInfoPreparedStatement.close();
			}
			if (currentSubLayoutFieldsPreparedStatement != null) {
				currentSubLayoutFieldsPreparedStatement.close();
			}
			if (extractFieldTerminatorPreparedStatement != null) {
				extractFieldTerminatorPreparedStatement.close();
			}
			if (checkDateOverrideCmptbltyPrepdStmt != null) {
				checkDateOverrideCmptbltyPrepdStmt.close();
			}
		} catch (Exception e) {
			System.err.println("ERROR");
			System.err.println(e.getMessage() + " EndConnection");
		}
	}

	/**
	 * @see GenerateAllAttribute#resultSetToListOfList(PreparedStatement)
	 */
	public static List<List<String>> resultSetToListOfList(PreparedStatement stm) {
		try {
			ResultSet rs = stm.executeQuery();
			ResultSetMetaData metaData = rs.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			List<String> columnNames = new ArrayList<String>(numberOfColumns);
			for (int column = 0; column < numberOfColumns; column++) {
				columnNames.add(metaData.getColumnLabel(column + 1));
			}

			List<List<String>> rows = new ArrayList<List<String>>();
			rows.add(columnNames);
			while (rs.next()) {
				List<String> newRow = new ArrayList<String>(numberOfColumns);
				for (int i = 1; i <= numberOfColumns; i++) {
					if (rs.getObject(i) != null && rs.getObject(i) != "") {
						newRow.add(rs.getObject(i).toString());
					} else {
						newRow.add("");
					}
				}
				rows.add(newRow);
			}
			if (rs != null) {
				rs.close();
			}

			return rows;

		} catch (Exception e) {
			System.err.println("ERROR");
			System.err.println(e.getMessage() + " Result Set To List OF List "
					+ stm.toString());
			return null;
		}
	}

	/**
	 * Method to Generate the import Script
	 * 
	 * @param layoutId
	 *            Layout Id for which script is to be generated
	 * @param isTest
	 *            if true, test import script is generated(With comments on Z-
	 *            Table dropping command)
	 * @param Version
	 *            The Version Information String
	 */
	public static String imprtScrptGeneration(String layoutId, boolean isTest,
			String Version) {
		boolean dateOverrideFlag = false;
		String dateFormatForOverride = "YYYYMMDD";
		String commentForTestString = "";
		String testImportID="";
		String charsetString = "US7ASCII";
		String dropAiTableStatement = "";
		if (isTest == true) {
			commentForTestString = "--";
			SimpleDateFormat sdf = new SimpleDateFormat("SSS");
			testImportID=sdf.format(new Date());
		}

		String original_layoutId = layoutId;

		if (isTest)
			if (layoutId.contains("_"))
				original_layoutId = layoutId
						.substring(0, layoutId.indexOf("_"));
			else

				original_layoutId = layoutId;
		try {
			layoutTypeQueryPreparedStatement.setString(1, original_layoutId);
			ResultSet rsCheckLayout = layoutTypeQueryPreparedStatement
					.executeQuery();
			while (rsCheckLayout.next()) {
				controlTotalFlag = rsCheckLayout.getString("DATATYPE")
						.toUpperCase().contains("CONTROL TOTAL");
				payorName = rsCheckLayout.getString("PAYOR");
				charsetString = rsCheckLayout.getString("CHARACTERSET");
				if (!charsetString.equalsIgnoreCase("US7ASCII")) {
					charsetString += "\n"
							+ "\t\tSTRING SIZES ARE IN CHARACTERS ";
				}
			}
		} catch (SQLException e2) {
			System.err.println("ERROR!! Layout Checking Query Failed "
					+ e2.getMessage());
		}
		try {
			layoutInfoPreparedStatement.setString(1, original_layoutId);
			distinctSubLayoutInfoPreparedStatement.setString(1,
					original_layoutId);
		} catch (SQLException e1) {
			System.err.println("ERROR: ");
			e1.printStackTrace();
		}

		String DateFormat = "YYYY-MM-DD";

		List<List<String>> distinctDatafileSublayouts = null;
		List<List<String>> currentSubLayoutFields = null;
		List<List<String>> layoutInfo = null;

		layoutInfo = resultSetToListOfList(layoutInfoPreparedStatement);

		String Script = "";
		if (controlTotalFlag == true) {
			Script = "Import Script is not generated for Control Control";
			putIntoList = false;
			return Script;
		} else {
			putIntoList = true;
		}

		if (layoutInfo.size() > 1) {
			try {
				delimeterQueryPreparedStatement.setString(1, original_layoutId);
				checkDateOverrideCmptbltyPrepdStmt.setString(1,
						original_layoutId);

			} catch (SQLException e1) {
				System.err.println("ERROR: ");
				e1.printStackTrace();
			}
			List<List<String>> delList = null;
			delList = resultSetToListOfList(delimeterQueryPreparedStatement);
			List<List<String>> dateFormatCheckList = null;
			dateFormatCheckList = resultSetToListOfList(checkDateOverrideCmptbltyPrepdStmt);
			String delmtr = "\\n";
			if (delList.size() > 1) {
				delmtr = delList.get(1).get(0);
			}
			if (dateFormatCheckList.size() == 2) {
				dateOverrideFlag = true;
				dateFormatForOverride = dateFormatCheckList.get(1).get(0);
			}

			String punchChr = layoutInfo.get(1).get(5);
			String optEnc = layoutInfo.get(1).get(6);
			String skip = layoutInfo.get(1).get(7);
			// System.err.println(skip);
			String shortPayor = layoutInfo.get(1).get(8);

			String aiTableName = "AI_" + original_layoutId;
			String procedureName = "IP_" + layoutId;

			if (aiTableName.length() > 25) {
				aiTableName = aiTableName.substring(0, 24);
			}
			if (aiTableName.length() > 30) {
				procedureName = procedureName.substring(0, 30);
			}

			distinctDatafileSublayouts = resultSetToListOfList(distinctSubLayoutInfoPreparedStatement);
			String[] tablename = new String[distinctDatafileSublayouts.size() - 1];
			String[] reducedTableName = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] tTableFields = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] zTableFieldsDeclaration = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] zTableFieldsDefinition = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] aiTableFields = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] InsertBlocktrim = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] InsertBlock = new String[distinctDatafileSublayouts.size() - 1];
			String[] aiInsertBlock = new String[distinctDatafileSublayouts
					.size() - 1];
			String[] whereClause = new String[distinctDatafileSublayouts.size() - 1];
			String[] layouttype = new String[distinctDatafileSublayouts.size() - 1];
			String[] subLayoutNumbers = new String[distinctDatafileSublayouts
					.size() - 1];
			// String[] trailerSkipCondition = new String[noSubLayout.size() -
			// 1];

			String scriptInfo = "--------------------------------------------";

			for (int subLayoutIndex = 1; subLayoutIndex < distinctDatafileSublayouts
					.size(); subLayoutIndex++) {

				tTableFields[subLayoutIndex - 1] = "";
				zTableFieldsDeclaration[subLayoutIndex - 1] = "";
				zTableFieldsDefinition[subLayoutIndex - 1] = "";
				InsertBlock[subLayoutIndex - 1] = "";
				InsertBlocktrim[subLayoutIndex - 1] = "";
				aiTableFields[subLayoutIndex - 1] = "";
				aiInsertBlock[subLayoutIndex - 1] = "";
				whereClause[subLayoutIndex - 1] = "";
				layouttype[subLayoutIndex - 1] = "";
				// trailerSkipCondition[sl-1]="";

				try {
					currentSubLayoutFieldsPreparedStatement.setString(1,
							original_layoutId);
					currentSubLayoutFieldsPreparedStatement.setString(
							2,
							distinctDatafileSublayouts.get(subLayoutIndex)
									.get(0).toString());
				} catch (SQLException e) {
					System.err.println("ERROR: ");
					e.printStackTrace();
				}

				currentSubLayoutFields = resultSetToListOfList(currentSubLayoutFieldsPreparedStatement);
				tablename[subLayoutIndex - 1] = aiTableName
						+ "_"
						+ distinctDatafileSublayouts.get(subLayoutIndex).get(0)
								.toString();

				subLayoutNumbers[subLayoutIndex - 1] = distinctDatafileSublayouts
						.get(subLayoutIndex).get(0).toString();
				tablename[subLayoutIndex - 1] += "_" + shortPayor;

				reducedTableName[subLayoutIndex - 1] = original_layoutId
						+ "_"
						+ distinctDatafileSublayouts.get(subLayoutIndex).get(0)
								.toString();

				whereClause[subLayoutIndex - 1] = distinctDatafileSublayouts
						.get(subLayoutIndex).get(3).toString();
				layouttype[subLayoutIndex - 1] = distinctDatafileSublayouts
						.get(subLayoutIndex).get(1).toString();

				for (int k = 1; k < currentSubLayoutFields.size(); k++) {

					if (layouttype[subLayoutIndex - 1].toUpperCase()
							.startsWith("FIX")
							|| layouttype[subLayoutIndex - 1].toUpperCase()
									.startsWith("SUB")) {
						zTableFieldsDeclaration[subLayoutIndex - 1] = zTableFieldsDeclaration[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ "  VARCHAR2("
								+ Integer.parseInt(currentSubLayoutFields
										.get(k).get(4).toString()) + "),\n\t";
						zTableFieldsDefinition[subLayoutIndex - 1] = zTableFieldsDefinition[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ "  POSITION("
								+ currentSubLayoutFields.get(k).get(5)
										.toString()
								+ ":"
								+ currentSubLayoutFields.get(k).get(6)
										.toString() + "),\n\t";
					} else {
						zTableFieldsDeclaration[subLayoutIndex - 1] = zTableFieldsDeclaration[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ "  VARCHAR2("
								+ Integer.parseInt(currentSubLayoutFields
										.get(k).get(4).toString()) + "),\n\t";
						zTableFieldsDefinition[subLayoutIndex - 1] = zTableFieldsDefinition[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + "\tCHAR(700"
								// +
								// currentSubLayoutFields.get(k).get(4).toString()
								+ ")" + ",\n\t";
					}

					if (currentSubLayoutFields.get(k).get(2).toString()
							.toUpperCase().startsWith("DATE")) {
						if (dateOverrideFlag) {
							// DateFormat = dateFormatForOverride;
							DateFormat = "'||p_date||'";
						} else {
							DateFormat = currentSubLayoutFields.get(k).get(3)
									.toString();
						}
						aiTableFields[subLayoutIndex - 1] = aiTableFields[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + "  DATE,\n\t";
						aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]

								+ "\tVH_TO_DATE("
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ ",''"
								+ DateFormat
								+ "'') AS "
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + ",\n";
					}
					/*
					 * Added on October 10, 2015... Support for TimeStamp Datatype 
					 */
					// /*
					else if (currentSubLayoutFields.get(k).get(2).toString()
							.toUpperCase().startsWith("TIMESTAMP")) {
						if (dateOverrideFlag) {
							DateFormat = "'||p_date||'";
						} else {
							DateFormat = currentSubLayoutFields.get(k).get(3)
									.toString();
						}
						aiTableFields[subLayoutIndex - 1] = aiTableFields[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + "  DATE,\n\t";
						aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]

								+ "\tVH_TO_DATE("
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ ",''"
								+ DateFormat
								+ "'',''Y'') AS "
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + ",\n";
					}
					// -------------------------------------- */
					else if (currentSubLayoutFields.get(k).get(2).toString()
							.toUpperCase().startsWith("NUMBER")) {
						aiTableFields[subLayoutIndex - 1] = aiTableFields[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + " NUMBER(19,4),\n\t";
						if (punchChr.toUpperCase().startsWith("Y"))
							aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]
									+ "\tVH_TO_NUMBER(PC("

									+ currentSubLayoutFields.get(k).get(1)
											.toString()

									+ ")) AS "
									+ currentSubLayoutFields.get(k).get(1)
											.toString() + ",\n";
						else
							aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]

									+ "\tVH_TO_NUMBER("

									+ currentSubLayoutFields.get(k).get(1)
											.toString()

									+ ") AS "
									+ currentSubLayoutFields.get(k).get(1)
											.toString() + ",\n";
					} else if (currentSubLayoutFields.get(k).get(2).toString()
							.toUpperCase().startsWith("INTEGER")
							|| currentSubLayoutFields.get(k).get(2).toString()
									.toUpperCase().startsWith("FLOAT")) {
						aiTableFields[subLayoutIndex - 1] = aiTableFields[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ "\t"
								+ currentSubLayoutFields.get(k).get(2)
										.toString().toUpperCase() + " ,\n\t";
						if (punchChr.toUpperCase().startsWith("Y"))
							aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]
									+ "\tVH_TO_NUMBER(PC("
									+ currentSubLayoutFields.get(k).get(1)
											.toString()
									+ ")) AS "
									+ currentSubLayoutFields.get(k).get(1)
											.toString() + ",\n";
						else
							aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]

									+ "\tVH_TO_NUMBER("

									+ currentSubLayoutFields.get(k).get(1)
											.toString()

									+ ") AS "
									+ currentSubLayoutFields.get(k).get(1)
											.toString() + ",\n";
					} else if (currentSubLayoutFields.get(k).get(2).toString()
							.toUpperCase().startsWith("NVARCHAR2")
							|| currentSubLayoutFields.get(k).get(2).toString()
									.toUpperCase().startsWith("VARCHAR")
							|| currentSubLayoutFields.get(k).get(2).toString()
									.toUpperCase().startsWith("CHAR")) {
						aiTableFields[subLayoutIndex - 1] = aiTableFields[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ "\t"
								+ currentSubLayoutFields.get(k).get(2)
										.toString().toUpperCase()
								+ "("
								+ currentSubLayoutFields.get(k).get(4)
										.toString() + "),\n\t";
						aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]

								+ "\t"
								+ currentSubLayoutFields.get(k).get(1)
										.toString()

								+ " AS "
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + ",\n";

					} else {
						aiTableFields[subLayoutIndex - 1] = aiTableFields[subLayoutIndex - 1]
								+ currentSubLayoutFields.get(k).get(1)
										.toString()
								+ "  VARCHAR2("
								+ currentSubLayoutFields.get(k).get(4)
										.toString() + "),\n\t";
						aiInsertBlock[subLayoutIndex - 1] = aiInsertBlock[subLayoutIndex - 1]

								+ "\t"
								+ currentSubLayoutFields.get(k).get(1)
										.toString()

								+ " AS "
								+ currentSubLayoutFields.get(k).get(1)
										.toString() + ",\n";

					}

				}

				zTableFieldsDeclaration[subLayoutIndex - 1] += "C  VARCHAR2(4000) ,\n\tAIPlineNumber number(19,4)";
				zTableFieldsDefinition[subLayoutIndex - 1] += "C  POSITION(1:4000),\n\tAIPlineNumber recnum";

			}
			String optionalFlag = "N";

			if (optEnc.toLowerCase().equals("y")) {
				optionalFlag = "Y";
			} else {
				optionalFlag = "N";
			}

			String startOfScript = "";
			String createAITable = "";
			String directoryCreate = "";
			String directoryDelete="";
			String logDirectoryCreate = "";
			String zTableBlock = "";
			String alterSession = "";
			String tTableBlock = "";
			String insertIntoAIBlock = "";
			String endofScript = "";

			startOfScript = "CREATE OR REPLACE PROCEDURE "
					+ procedureName
					+ "(p_FilePath VARCHAR2,p_FileID VARCHAR2 DEFAULT '999_999',p_CLIENTID VARCHAR2 DEFAULT '999',p_EMPGRP VARCHAR2 DEFAULT 'UNKN',p_skip NUMBER DEFAULT "
					+ skip
					+ " ,p_delim VARCHAR2 DEFAULT '"
					+ delmtr
					+ "' ,p_schema VARCHAR2 DEFAULT 'importDb',p_opt VARCHAR2 DEFAULT '"
					+ optionalFlag + "'";
			if (dateOverrideFlag) {
				startOfScript = startOfScript + " ,p_date VARCHAR2 DEFAULT '"
						+ dateFormatForOverride + "'";
			}
			startOfScript = startOfScript
					+ " )\n"

					+ Version
					+ "\n--EXAMPLE: \n"
					+ "-- EXEC "
					+ procedureName
					+ "(p_FilePath=> 'filePath', p_FileID=>'999_999',p_CLIENTID=>'999',p_EMPGRP=>'UNKN',p_skip=>'"
					+ skip
					+ "',p_delim=>'"
					+ delmtr
					+ "',p_schema=>'flmsdevs',p_opt=>'"
					+ optionalFlag
					+ "')"
					+ "\nIS\n\tpayorName VARCHAR2(200); \n\taip_import_logs_dir VARCHAR2(200); \n\tp_EMPGRP_ESCAPED VARCHAR2(250); \n\tdmfile VARCHAR2(150); \n\tf_fileID VARCHAR2(50) ;\n\td_StartDate DATE;\n\tv_QueryID NUMBER(22);\n\tv_ErrorNumber NUMBER(4);\n\tv_Query CLOB;\n\tSourceDirectory VARCHAR2(1000);\n\tFileName VARCHAR2(500) ;\n\tn_RowCount NUMBER(22);\n\tn_SubRowCount NUMBER(22);\n\tv_ErrMsg VARCHAR2(4000);\n\tv_optional_String VARCHAR2(150);\n\tDATE_CREATED DATE;\n\tEndDate DATE;\n\nBEGIN\n	SourceDirectory:=REPLACE(SubStr(p_FilePath,1,InStr(p_FilePath,'/',-1)),'''','''''') ;\n	FileName:=REPLACE(SubStr(p_FilePath,InStr(p_FilePath,'/',-1)+1),'''','''''') ;\n	p_EMPGRP_ESCAPED := REPLACE(p_EMPGRP,'''','''''') ;	\n	v_QueryID:=0;\n	d_StartDate :=SYSDATE;\n\tv_ErrMsg:='';\n\tdmfile:=substr(p_FileID,instr(p_FileID,'_'));\n\tpayorName:='"
					+ payorName
					+ "'; \n\tf_fileID:=SubStr(p_FileID,1,(InStr(p_FileID,'_')-1));\n\taip_import_logs_dir:='importlog_'||p_FileID||'_dir';\n\tv_ErrorNumber:=0;\n\tv_optional_String:=' LRTRIM ';\n"
					+ "\tIF p_opt = 'Y'	THEN\n\t\tBEGIN\n\t\t\tv_optional_String:='OPTIONALLY ENCLOSED BY ''\"'' LRTRIM';\n\t\tEND;\n\tEND IF;\n-------\n";

			for (int z = 0; z < tTableFields.length; z++) {
				try {
					extractFieldTerminatorPreparedStatement.setString(1,
							layouttype[z].toUpperCase());
				} catch (SQLException e) {
					System.err.println("ERROR: ");
					e.printStackTrace();
				}
				List<List<String>> lay = resultSetToListOfList(extractFieldTerminatorPreparedStatement);

				if (lay != null && lay.size() > 1) {
					layouttype[z] = "\""
							+ ((List<String>) (lay.get(1))).get(0).toString()
							+ "\"";

				} else {
					layouttype[z] = "NA";
				}

				createAITable = createAITable
						+ "BEGIN\nv_Query:='CREATE TABLE "
						+ tablename[z]
						+ "\n\t(\n\t"
						+ aiTableFields[z]
						+ "UDF1 VARCHAR2(200),\n\tUDF2\tVARCHAR2(200),\n\tUDF3\tVARCHAR2(200),\n\tUDF4 VARCHAR2(200),\n\tUDF5 VARCHAR2(200),\n\tSourceFileName VARCHAR2(255),\n\tReceivedMonth VARCHAR2(6),\n\tImportedDate Date,\n\tCLIENTID VARCHAR2(200),\n\tEMPGRP VARCHAR2(200),\n\tFILEID VARCHAR2(200),\n\tROWNUMBER VARCHAR2(200),\n\tHASHKEY VARCHAR2(200),\n\tPayorName VARCHAR2(100)) NOLOGGING';\n--------\nEXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN NULL; END;\n-------\n"
						+ "";// "EXECUTE IMMEDIATE 'Delete From "+tablename[z]+" where fileid like ''%'||dmfile||''' and sourcefilename='''||FileName|| '''';\nCOMMIT;\n-----\n";
				if(isTest){
					dropAiTableStatement="BEGIN\nv_Query:='DROP TABLE "
							+ tablename[z]
							+ " PURGE';"		
							+"\nEXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN NULL; END;\n--------\n";
				}
				directoryCreate = "BEGIN\nv_Query:='CREATE OR REPLACE DIRECTORY ID_'||p_FileID||'"+testImportID+" AS '''|| SourceDirectory || '''';\nBEGIN EXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN NULL; END ;\n--------\n";
				directoryDelete = "v_Query:='DROP DIRECTORY ID_'||p_FileID||'"+testImportID+"';\n"+commentForTestString+"BEGIN EXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN NULL; END ;\n--------\n";
				logDirectoryCreate = "v_Query:='CREATE OR REPLACE DIRECTORY '||aip_import_logs_dir||' AS ''"
						+ logsBasePath
						+ "''';\nBEGIN EXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN NULL; END ;\n--------\n";
				zTableBlock = zTableBlock
						// + commentForTestString
						+ "BEGIN EXECUTE IMMEDIATE'DROP TABLE Z_"
						+ reducedTableName[z]// + tablename[z]
						+ "_"
						+ "'||f_fileID||'"
						+ " PURGE'; EXCEPTION WHEN OTHERS THEN NULL; END;\n--------\nv_Query:=\n'CREATE TABLE Z_"
						+ reducedTableName[z]// + tablename[z]
						+ "_"
						+ "'||f_fileID||'"
						+ "\n(\n	"
						+ zTableFieldsDeclaration[z]
						+ "\n)\nORGANIZATION EXTERNAL\n(\n	TYPE ORACLE_LOADER\n	DEFAULT DIRECTORY ID_'||p_FileID||'"+testImportID+"\n	ACCESS PARAMETERS\n	(\n		RECORDS DELIMITED BY NEWLINE CHARACTERSET "
						+ charsetString;

				;

				if (!whereClause[z].equalsIgnoreCase("NA")) {

					zTableBlock = zTableBlock + "\n\t\tLOAD WHEN "
							+ whereClause[z];
				}

				zTableBlock = zTableBlock

						+ "\n\t\tNODISCARDFILE\t\n\t\tBADFILE\t '||aip_import_logs_dir||': \"'||FileName||'_'||p_FileID||'.'||p_CLIENTID||'.bad\"\n\t\tLOGFILE\t '||aip_import_logs_dir||': \"'||FileName||'_'||p_FileID||'.'||p_CLIENTID||'.log\"\n\t\tSKIP  "
						+ "'||p_skip||'"
						+ "\n		READSIZE 1048576\n		FIELDS TERMINATED BY "
						+ "\"'||p_delim||'\""
						+ "\n"
						+ "\t\t'||v_optional_String||' "
						+ "\n		MISSING FIELD VALUES ARE NULL\n		REJECT ROWS WITH ALL NULL FIELDS\n (\t\n\t"
						+ zTableFieldsDefinition[z]
						+ "\n  )\n )\n	LOCATION ('''||FileName||''')\n)';\n--------\nBEGIN EXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN BEGIN v_ErrorNumber:=v_ErrorNumber+1; v_ErrMsg:=v_ErrMsg||' '|| v_ErrorNumber||'. ERROR AT CREATING Z TABLE Z_"
						+ reducedTableName[z]// + tablename[z]
						+ " : '||substr(SQLERRM, 1,400) ;END ;END;\n--------\n";
				//\nPARALLEL 4	
				alterSession = "BEGIN EXECUTE IMMEDIATE 'ALTER SESSION ENABLE PARALLEL DML'; EXCEPTION WHEN OTHERS THEN NULL; END;\n\n";
				tTableBlock += "BEGIN EXECUTE IMMEDIATE 'DROP TABLE T_"
						+ reducedTableName[z]// + tablename[z]
						+ "_'||f_fileID||' PURGE'; EXCEPTION WHEN OTHERS THEN NULL; END;\n";
				tTableBlock += "BEGIN EXECUTE IMMEDIATE 'CREATE TABLE T_"
						+ reducedTableName[z]
						+ "_'||f_fileID||' AS SELECT * from Z_"
						+ reducedTableName[z] + "_'||f_fileID ";

				tTableBlock += " ; EXCEPTION WHEN OTHERS THEN BEGIN v_ErrorNumber:=v_ErrorNumber+1; v_ErrMsg:=v_ErrMsg||' '||v_ErrorNumber ||'. ERROR WHILE READING FROM Z TABLE Z_"
						+ tablename[z]
						+ " : '||substr(SQLERRM, 1,400) ;END ;END;\n\n";
				insertIntoAIBlock = insertIntoAIBlock
						+ "v_Query:=\n'INSERT INTO /*+ append +*/ "
						+ tablename[z]
						+ "\nSELECT /*+ parallel(4) +*/\n"
						+ aiInsertBlock[z]
						+ "\tNULL AS UDF1,\n\tNULL AS UDF2,\n\tNULL AS UDF3,\n\tNULL AS UDF4,\n\tNULL AS UDF5,\n\t'''||Filename||''' AS SourceFileName,\n\tTO_CHAR(SYSDATE,''YYYYMM'') ,\n\tSYSDATE,\n\t'''||p_CLIENTID||''' AS CLIENTID,\n\t'''||p_EMPGRP_ESCAPED||''' AS EMPGRP ,\n\t'''||p_FileID||''' AS  FILEID,\n\tAIPlineNumber AS ROWNUMBER,\n\tmd5hash(C) AS HASHKEY,\n\t'''||payorName||''' AS PayorName\nFROM\n\tT_"
						+ reducedTableName[z] + "_"
						+ "'||f_fileID||' where trim(C) is not null";

				insertIntoAIBlock = insertIntoAIBlock
						+ "';\n--------\nBEGIN EXECUTE IMMEDIATE v_Query;EXCEPTION WHEN OTHERS THEN BEGIN v_ErrorNumber:=v_ErrorNumber+1;v_ErrMsg:=v_ErrMsg||' '||v_ErrorNumber||'. ERROR AT INSERT INTO AI "
						+ tablename[z]
						+ " : '||substr(SQLERRM, 1,400);END ;END;\n"
						+ "n_SubRowCount:= SQL%ROWCOUNT;COMMIT;"
						+ "\nDATE_CREATED:= SYSDATE;"

						+ "\n"+commentForTestString+"BEGIN EXECUTE IMMEDIATE 'UPDATE '||p_schema||'.IMP_MAIN_DET_LOG SET AISCHEMANAME=:a,AITABLENAME=:b"

						+ ",RECORDCOUNT=:c,DATE_CREATED=:d WHERE FILEID=:e AND SUBLAYOUTID=:f' "
						+ "USING USER, '"
						+ tablename[z]
						+ "',n_SubRowCount,DATE_CREATED,p_FileID,'"
						+ subLayoutNumbers[z]
						+ "';EXCEPTION WHEN OTHERS THEN NULL ;END ;\n"
						+ "BEGIN EXECUTE IMMEDIATE 'Select '||n_RowCount||'+'||n_SubRowCount||' from dual' INTO  n_RowCount;EXCEPTION WHEN OTHERS THEN NULL ;END ;\n";

				insertIntoAIBlock = insertIntoAIBlock
						+ commentForTestString
						+ "BEGIN EXECUTE IMMEDIATE 'DROP TABLE Z_"
						+ reducedTableName[z]
						+ "_"
						+ "'||f_fileID||'"
						+ " PURGE'; EXCEPTION WHEN OTHERS THEN NULL; END;\n--------\n";

			}
			endofScript="EndDate:=SYSDATE;\n";
			endofScript += "v_Query:='UPDATE '||p_schema||'.IMP_MAIN_LOG SET IMPORT_RECORD_CNT=:a,STATUS_OF_IMPORT=:b,StartTime=:c,endTime=:d WHERE  FILEID||''_''||DMFILEID =:e';"
					+"\n"+commentForTestString+"BEGIN EXECUTE IMMEDIATE v_Query USING n_RowCount,Nvl(v_ErrMsg,'SUCCESS'),d_StartDate,EndDate,p_FileID ;EXCEPTION WHEN OTHERS THEN NULL;END ;\n";
			endofScript +=directoryDelete+"\n";
			endofScript += "END ;\nCOMMIT;\nEND " + procedureName + ";\n/";
			Script += scriptInfo;
			Script += "\n";
			Script += startOfScript;
			Script += "\n";
			Script += dropAiTableStatement;
			Script += createAITable;
			Script += directoryCreate;
			Script += "\n";
			Script += logDirectoryCreate;
			Script += "\n";
			Script += zTableBlock;
			Script += alterSession;
			Script += tTableBlock;
			Script += insertIntoAIBlock;
			Script += endofScript;

		} else {
			Script = "ERROR: No Layout Found";
		}
		return Script;
	}
}
