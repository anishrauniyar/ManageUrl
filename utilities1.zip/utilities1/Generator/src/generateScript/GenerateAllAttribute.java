package generateScript;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * This class is responsible for generating Attribute Script Purpose : Generates
 * attribute script
 * 
 * @version 1.0
 */
public class GenerateAllAttribute {
	/**
	 * Connection object to hold Single & Main Connection
	 */
	public static Connection conn;
	/**
	 * Flag to check whether the column defined in the whereclause exists or not
	 */
	public static boolean invalidWhereclauseFlag = false;
	/**
	 * Flag to check whether the whereclause exists or not in case of multiple
	 * sub-layouts Layout
	 */
	public static boolean whereclauseMissingFlag = false;

	/**
	 * Flag for runtime Generation
	 */
	public static boolean runTimeFlag = false;

	/**
	 * The Value of SN(imp_clientpatterns) passed during override of layout
	 */
	public static String sn = null;
	/**
	 * Flag to check if the connection is initialized
	 */
	static boolean isInitialized = false;

	/**
	 * stores key value pairs of layout id and their attribute Scripts
	 */
	public static Map<String, String> allAttributesHashtable = new HashMap<String, String>();
	// GENERAL SKELETAL QUERIES FOR ALL
	// ---------------------------------------------------------------------------------------------------------
	public static String layoutDetailsQuery = "SELECT B.payor,upper(B.datatype) datatype,B.puchcharflag, B.optionally, B.skiprow ,Nvl(B.TRAILERSKIP,'0') TRAILERSKIP FROM imp_layouts b where LAYOUTID=?";
	public static String overrideQuery = "SELECT a.payor, a.datatype, a.puchcharflag, Nvl(b.optionally,a.optionally)  optionally, Nvl(b.skiprows,a.skiprow) skiprow,  Nvl(b.overriddentrailer,a.TRAILERSKIP) trailerskip ,Nvl(b.overriddendate,'NA') overriddendate,Nvl(c.layouttypeid,'NA') overridedelimitter FROM (SELECT B.payor,upper(B.datatype) datatype,B.puchcharflag, B.optionally, B.skiprow ,Nvl(B.TRAILERSKIP,'0') TRAILERSKIP, B.layoutid FROM imp_layouts b where b.LAYOUTID=? ) a  left JOIN (SELECT * FROM imp_clientpatterns  WHERE SN=? ) b  ON a.layoutid=b.layoutid  left JOIN tbl_filepatterns_layout c ON Upper(b.delimiter)=upper(c.layouttype)";
	public static String distinctDatafileSublayoutsQuery = "SELECT a.SUBLAYOUTID,Upper(a.LAYOUTTYPE) LAYOUTTYPE,a.LAYOUTDETAIL,nvl(a.WHERECLAUSE,'NA'),upper(SubStr(a.WHERECLAUSE,1,InStr(Upper(a.WHERECLAUSE),'=')-1)) label,upper(SubStr(a.WHERECLAUSE,InStr(Upper(a.WHERECLAUSE),'='))) label1,Nvl(a.SUBLAYOUTDESC,'DATAFILE') SUBLAYOUTDESC,"
			+ "Nvl(b.LAYOUTTYPEID,a.LAYOUTTYPE)  AS SORTLAYOUTTYPE,b.FIELDTERMINATOR,c.NOOFFLDCNT,c.SUMOFFIELDS "
			+ "FROM (SELECT * FROM IMP_SUB_LAYOUTS WHERE LAYOUTID= ? "
			+ "and Upper(SUBLAYOUTDESC)='DATAFILE' "
			+ " ) a "
			+ " left join TBL_FILEPATTERNS_LAYOUT b"
			// +
			// " ON Upper(a.LAYOUTTYPE)=Upper(b.LAYOUTTYPE) LEFT JOIN (SELECT LAYOUTID,SUBLAYOUTID,COUNT(*) NOOFFLDCNT,SUM(FIELDLENGTH) as SUMOFFIELDS FROM IMP_LAYOUTS_FIELDS WHERE LAYOUTID=? GROUP BY  LAYOUTID,SUBLAYOUTID) c ON a.SUBLAYOUTID=c.SUBLAYOUTID order by to_number(a.SUBLAYOUTID) ASC ";
			+ " ON Upper(a.LAYOUTTYPE)=Upper(b.LAYOUTTYPE) LEFT JOIN (SELECT LAYOUTID,SUBLAYOUTID,COUNT(*) NOOFFLDCNT,MAX(ENDPOS) as SUMOFFIELDS FROM IMP_LAYOUTS_FIELDS WHERE LAYOUTID=? GROUP BY  LAYOUTID,SUBLAYOUTID) c ON a.SUBLAYOUTID=c.SUBLAYOUTID order by to_number(a.SUBLAYOUTID) ASC ";

	public static String queryCtFlag = "SELECT * FROM imp_sub_layouts WHERE layoutid=? AND SUBLAYOUTDESC='CONTROLTOTAL'";

	public static String getColumnNumberQuery = "SELECT DISTINCT COLUMNID,startpos,To_Number(Nvl(endpos,0))-To_Number(Nvl(startpos,0))+1 AS lengthOfField  FROM IMP_LAYOUTS_FIELDS WHERE upper(COLUMNNAME)= ? "
			+ " AND LAYOUTID= ?" + " AND sublayoutid= ? ";

	public static String fieldCheckDetailsQuery = ""
			+ "SELECT a.columnid, "
			+ "       a.columnname, "
			+ "       a.datatype, "
			+ "       a.datetypedetial, "
			+ "       a.fieldlength, "
			+ "       a.startpos, "
			+ "       a.endpos, "
			+ "       a.sn, "
			+ "       B.getstatsfunction, "
			+ "       B.chkvalues "
			+ "FROM   (SELECT layoutid,columnid, "
			+ "               Upper(columnname)                                   COLUMNNAME, "
			+ "               Upper(datatype)                                     DATATYPE, "
			+ "               datetypedetial, "
			+ "               fieldlength, "
			+ "				  startpos, "
			+ "			      endpos , "
			+ "               sn "
			+ "        FROM   (SELECT layoutid, "
			+ "                       sn, "
			+ "                       sublayoutid, "
			+ "                       To_number(columnid)    COLUMNID, "
			+ "                       columnname, "
			+ "                       datatype, "
			+ "                       datetypedetial, "
			+ "                       To_number(fieldlength) FIELDLENGTH, "
			+ "						  To_Number(startpos) STARTPOS,"
			+ "					      To_Number(endpos) ENDPOS"
			+ "                FROM   imp_layouts_fields "
			+ "                WHERE  layoutid = ? "
			+ "                       AND sublayoutid =? "
			+ "                ORDER  BY To_number(sublayoutid), "
			+ "                          To_number(columnid)) "
			+ "        ORDER  BY To_number(columnid)) a "
			+ " LEFT JOIN (SELECT LAYOUT_ID,LAYOUT_SN,GETSTATSFUNCTION,RTrim(rtrim(xmlagg (xmlelement (e,FIELD_VALUE || ',')).extract ('//text()').getClobVal(), ','),' ,') AS CHKVALUES FROM  IMP_LAYOUT_DETAILS where layout_id = ? GROUP BY LAYOUT_ID,LAYOUT_SN,GETSTATSFUNCTION) b"
			+ " ON a.sn = b.LAYOUT_SN    AND a.layoutid=b.layout_id"
			+ " WHERE  b.getstatsfunction IS NOT NULL ORDER BY COLUMNID";
	public static String getAllQuery = "SELECT DISTINCT LAYOUTID FROM IMP_LAYOUTS  WHERE     DATATYPE  NOT LIKE  'Control Total'";

	// PREPARED STATEMENT FOR ABOVE QUERIES
	public static PreparedStatement layoutDetailsQueryPreparedStatement = null;
	public static PreparedStatement distinctDatafileSublayoutsQueryPreparedStatement = null;
	public static PreparedStatement ctFlagQueryPreparedStatement = null;
	public static PreparedStatement getColumnNumberPreparedStatement = null;
	public static PreparedStatement fieldCheckDetailsPreparedStatement = null;
	public static PreparedStatement getAllQueryPreparedStatement = null;
	public static PreparedStatement overrideQueryPreparedStatement = null;

	/**
	 * Method to initialize the connection
	 */
	public static void initialize(Connection connArg) {
		conn = connArg;
		try {
			layoutDetailsQueryPreparedStatement = conn
					.prepareStatement(layoutDetailsQuery);
			distinctDatafileSublayoutsQueryPreparedStatement = conn
					.prepareStatement(distinctDatafileSublayoutsQuery);
			ctFlagQueryPreparedStatement = conn.prepareStatement(queryCtFlag);
			getColumnNumberPreparedStatement = conn
					.prepareStatement(getColumnNumberQuery);
			fieldCheckDetailsPreparedStatement = conn
					.prepareStatement(fieldCheckDetailsQuery);
			if (runTimeFlag) {
				overrideQueryPreparedStatement = conn
						.prepareStatement(overrideQuery);
			}
			isInitialized = true;
		} catch (Exception e) {
			System.err.println("ERROR A");
			System.err.println(e.getMessage() + " Initialize Connection");
		}
	}

	/**
	 * Method to Convert Clob to String
	 */
	public static String convertClobToString(Clob clob) {
		String result = "";
		try {

			BufferedReader br = new BufferedReader(clob.getCharacterStream());
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
			result = sb.toString();
		} catch (SQLException e) {
			System.err.println("Error Converting CLOB ");
		} catch (IOException e) {
			System.err.println("Error Converting CLOB ");
		}

		return result;
	}

	/**
	 * Method to generate scripts for all layouts
	 */
	public static Map<String, String> generate(String... strings) {

		if (strings.length != 0) {
			try {
				String tempLayoutId;
				getAllQueryPreparedStatement = conn
						.prepareStatement(getAllQuery);
				ResultSet allLayouts = getAllQueryPreparedStatement
						.executeQuery();

				while (allLayouts.next()) {
					tempLayoutId = allLayouts.getString(1).trim();
					allAttributesHashtable.put(tempLayoutId,
							getAttributeScript(tempLayoutId));
				}
				return allAttributesHashtable;

			} catch (SQLException e) {
				System.err.println("Error M : " + e.getMessage());
			}
		}
		return null;
	}

	/**
	 * Method to end the connection
	 */
	public static void endConnection() {
		try {
			if (layoutDetailsQueryPreparedStatement != null) {
				layoutDetailsQueryPreparedStatement.close();
			}
			if (distinctDatafileSublayoutsQueryPreparedStatement != null) {
				distinctDatafileSublayoutsQueryPreparedStatement.close();
			}
			if (ctFlagQueryPreparedStatement != null) {
				ctFlagQueryPreparedStatement.close();
			}
			if (getColumnNumberPreparedStatement != null) {
				getColumnNumberPreparedStatement.close();
			}
			if (fieldCheckDetailsPreparedStatement != null) {
				fieldCheckDetailsPreparedStatement.close();
			}
			if (getAllQueryPreparedStatement != null) {
				getAllQueryPreparedStatement.close();
			}
			if (overrideQueryPreparedStatement != null) {
				overrideQueryPreparedStatement.close();
			}
			if (allAttributesHashtable != null) {
				allAttributesHashtable.clear();
			}
		} catch (Exception e) {
			System.err.println("ERROR B");
			System.err.println(e.getMessage() + " EndConnection");
		}
	}

	/**
	 * Method to convert the resultset(table data) to List<List<String>>
	 * 
	 * @param stm
	 *            The select query prepared Statement whose resultset is to be
	 *            converted into list of list
	 */
	public static List<List<String>> resultSetToListOfList(PreparedStatement stm) {
		try {
			if (stm != null) {
				ResultSet rs = stm.executeQuery();
				ResultSetMetaData metaData = rs.getMetaData();
				int numberOfColumns = metaData.getColumnCount();
				List<String> columnNames = new ArrayList<String>(
						numberOfColumns);
				for (int column = 0; column < numberOfColumns; column++) {
					columnNames.add(metaData.getColumnLabel(column + 1));
				}
				List<List<String>> rows = new ArrayList<List<String>>();
				rows.add(columnNames);
				while (rs.next()) {
					List<String> newRow = new ArrayList<String>(numberOfColumns);
					for (int i = 1; i <= numberOfColumns; i++) {
						if (rs.getObject(i) != null && rs.getObject(i) != "") {
							if (rs.getObject(i) instanceof oracle.sql.CLOB) {

								newRow.add(convertClobToString(rs.getClob(i)));
							} else {
								newRow.add(rs.getObject(i).toString());
							}
						} else {
							newRow.add("");
						}
					}
					rows.add(newRow);
				}
				if (rs != null) {
					rs.close();
				}
				return rows;
			} else {
				return null;
			}

		} catch (Exception e) {
			System.err.println("ERROR C");
			System.err.println(e.getMessage() + " Result Set To List OF List "
					+ stm.toString());
			// e.printStackTrace();
			return null;
		}

	}

	/**
	 * Method to generate Attribute Script for that layoutid
	 * 
	 * @param layoutId
	 *            The layoutid for which script is to be generated
	 */
	public static String getAttributeScript(String layoutId) {
		String delimiter = "NA";
		String dateType = "NA";
		String typeFlag = "1";
		String attributeScript = "AAA";
		String header = "0";
		String trailer = "0";
		String puchChar = "N";
		String optionallyEnc = "NA";
		// initialize();
		try {
			layoutDetailsQueryPreparedStatement.setString(1, layoutId);
		} catch (SQLException e) {
			System.err.println("Error D " + e.getMessage());
		}
		List<List<String>> layoutDetails = null;
		layoutDetails = resultSetToListOfList(layoutDetailsQueryPreparedStatement);
		if (layoutDetails.size() > 1) {
			if (layoutDetails.get(1).get(1).equalsIgnoreCase("CONTROL TOTAL")) {
				return "";
			}

			puchChar = layoutDetails.get(1).get(2);
			optionallyEnc = layoutDetails.get(1).get(3);
			header = layoutDetails.get(1).get(4);
			trailer = layoutDetails.get(1).get(5);
			attributeScript = "FLID|" + typeFlag + "|" + layoutId;

			if (runTimeFlag) {
				List<List<String>> layoutDetailsRuntime = null;
				try {
					overrideQueryPreparedStatement.setString(1, layoutId);
					overrideQueryPreparedStatement.setString(2, sn);
				} catch (SQLException e) {
					System.err.println("Error: " + e.getMessage());
				}
				layoutDetailsRuntime = resultSetToListOfList(overrideQueryPreparedStatement);
				if (layoutDetailsRuntime.size() > 1) {
					puchChar = layoutDetailsRuntime.get(1).get(2);
					optionallyEnc = layoutDetailsRuntime.get(1).get(3);
					header = layoutDetailsRuntime.get(1).get(4);
					trailer = layoutDetailsRuntime.get(1).get(5);
					dateType = dateType == layoutDetailsRuntime.get(1).get(6) ? dateType
							: layoutDetailsRuntime.get(1).get(6);
					delimiter = delimiter == layoutDetailsRuntime.get(1).get(7) ? delimiter
							: layoutDetailsRuntime.get(1).get(7);

				}
			}
			attributeScript += "\n"
					+ getAttributeValues(layoutId, header, trailer, puchChar,
							optionallyEnc, dateType, delimiter);

		} else {
			attributeScript = "";
		}
		if (invalidWhereclauseFlag) {
			return "INVALID|Whereclause not Valid";
		} else if (whereclauseMissingFlag == true) {
			return "INVALID|Whereclause Missing";
		} else {
			return attributeScript;
		}
	}

	/**
	 * Method to get the attribute values
	 */
	public static String getAttributeValues(String layoutId, String header,
			String trailer, String punchChar, String optionallyEnclosed,
			String dateType, String delimiter) {
		invalidWhereclauseFlag = false;
		whereclauseMissingFlag = false;
		String returnString = "";
		try {
			distinctDatafileSublayoutsQueryPreparedStatement.setString(1,
					layoutId);

		} catch (SQLException e) {
			System.err.println("ERROR E");
			System.err.println(e.getMessage());
		}
		try {
			distinctDatafileSublayoutsQueryPreparedStatement.setString(2,
					layoutId);

		} catch (SQLException e) {
			System.err.println("ERROR F");
			System.err.println(e.getMessage());
		}
		List<List<String>> distinctDatafileSublayoutsList = null;
		distinctDatafileSublayoutsList = resultSetToListOfList(distinctDatafileSublayoutsQueryPreparedStatement);

		try {
			ctFlagQueryPreparedStatement.setString(1, layoutId);

		} catch (SQLException e) {
			System.err.println("ERROR G");
			System.err.println(e.getMessage());
		}
		List<List<String>> ctFlag = null;

		ctFlag = resultSetToListOfList(ctFlagQueryPreparedStatement);
		int ctf = 0;
		if (ctFlag.size() > 1)
			ctf = 1;
		if (distinctDatafileSublayoutsList.size() > 1) {

			for (int i = 1; i < distinctDatafileSublayoutsList.size(); i++) {

				String subLayoutID = distinctDatafileSublayoutsList.get(i).get(
						0);
				String subLayoutType = distinctDatafileSublayoutsList.get(i)
						.get(1);
				String sublayoutWhereClause = distinctDatafileSublayoutsList
						.get(i).get(3);
				String replacedWhereClause = "";

				try {
					replacedWhereClause = getReplacedWhereclause(sublayoutWhereClause);

				} catch (Exception e) {
					System.err.println("ERROR!! Whereclause Not Valid");
				}

				String shortDelimiter = distinctDatafileSublayoutsList.get(i)
						.get(7);

				if (runTimeFlag && delimiter.trim() != ""
						&& !delimiter.equalsIgnoreCase("NA")
						&& !delimiter.toUpperCase().contains("FIX")) {
					shortDelimiter = delimiter;
				}
				String whereClause = parseWhereClause(subLayoutType,
						replacedWhereClause, shortDelimiter, layoutId,
						subLayoutID);

				String noOfFieldsFromTable = distinctDatafileSublayoutsList
						.get(i).get(9);
				String sumOfFields = distinctDatafileSublayoutsList.get(i).get(
						10);

				// List<List<String>> sublayoutDetail = null;
				try {
					fieldCheckDetailsPreparedStatement.setString(1, layoutId);
					fieldCheckDetailsPreparedStatement
							.setString(2, subLayoutID);
					fieldCheckDetailsPreparedStatement.setString(3, layoutId);
				} catch (SQLException e) {
					System.err.println("ERROR J");
					System.err.println(e.getMessage());
				}
				// sublayoutDetail =
				// resultSetToListOfList(fieldCheckDetailsPreparedStatement);
				// String fieldValues = "";
				if (subLayoutType.equalsIgnoreCase("Fixed length")) {

					if (i == 1) {
						returnString += "HEADER" + "|" + header;
						returnString += "\n" + "TRAILER" + "|" + trailer;
						returnString += "\n" + "OPTENC" + "|"
								+ optionallyEnclosed;
						returnString += "\n" + "PUCHCHAR" + "|" + punchChar;
						if (ctf == 1)
							returnString += "\n" + "CONTROLLINE" + "|" + "1";
						else
							returnString += "\n" + "CONTROLLINE" + "|" + "0";
					}

					if (!sublayoutWhereClause.equalsIgnoreCase("NA")) {
						returnString += whereClause;
					}
					returnString += "\n" + "LAYOUTNUM" + "|" + subLayoutID;

					/*for (int j = 1; j < sublayoutDetail.size(); j++) {
						String postStrt = sublayoutDetail.get(j).get(5);
						String fieldLength = sublayoutDetail.get(j).get(4);
						fieldValues = sublayoutDetail.get(j).get(9);

						if (sublayoutDetail.get(j).get(8)
								.equalsIgnoreCase("CHKVAL")) {

							returnString += "\n" + "CHKVALFIXED" + "|"
									+ sublayoutDetail.get(j).get(1) + "|"
									+ postStrt + "," + fieldLength + "|"
									+ fieldValues;
						} else if (sublayoutDetail.get(j).get(8)
								.equalsIgnoreCase("COLSUM")) {

							returnString += "\n" + "COLSUMFIXED" + "|"
									+ sublayoutDetail.get(j).get(1) + "|"
									+ postStrt + "," + fieldLength;
						} else if (sublayoutDetail.get(j).get(8)
								.equalsIgnoreCase("CHKDATE")) {
							if (runTimeFlag && dateType.trim() != ""
									&& !dateType.equalsIgnoreCase("NA")) {
								returnString += "\n" + "CHKDATEFIXED" + "|"
										+ sublayoutDetail.get(j).get(1) + "|"
										+ postStrt + "," + fieldLength + "|"
										+ dateType.toUpperCase();
							} else {
								returnString += "\n" + "CHKDATEFIXED" + "|"
										+ sublayoutDetail.get(j).get(1) + "|"
										+ postStrt + "," + fieldLength + "|"
										+ sublayoutDetail.get(j).get(3);
							}
						}

					}*/
					returnString += "\n" + "CHKLENFIXED" + "|" + sumOfFields;
				} else {

					if (i == 1) {

						returnString += "HEADER" + "|" + header;
						returnString += "\n" + "TRAILER" + "|" + trailer;
						returnString += "\n" + "OPTENC" + "|"
								+ optionallyEnclosed;
						returnString += "\n" + "PUCHCHAR" + "|" + punchChar;
						if (ctf == 1)
							returnString += "\n" + "CONTROLLINE" + "|" + "1";
						else
							returnString += "\n" + "CONTROLLINE" + "|" + "0";
					}

					if (!sublayoutWhereClause.equalsIgnoreCase("NA")) {
						returnString += whereClause;
					} else {
						if (Integer.parseInt(subLayoutID) > 1) {
							whereclauseMissingFlag = true;
							return "";
						}
					}
					returnString += "\n" + "LAYOUTNUM" + "|" + subLayoutID;

					/*for (int j = 1; j < sublayoutDetail.size(); j++) {
						String columnPosition = sublayoutDetail.get(j).get(0);
						fieldValues = sublayoutDetail.get(j).get(9);
						if (sublayoutDetail.get(j).get(8)
								.equalsIgnoreCase("CHKVAL")) {

							returnString += "\n" + "CHKVAL" + "|"
									+ sublayoutDetail.get(j).get(1) + "|"
									+ shortDelimiter + "|" + columnPosition
									+ "|" + fieldValues;
						} else if (sublayoutDetail.get(j).get(8)
								.equalsIgnoreCase("COLSUM")) {

							returnString += "\n" + "COLSUM" + "|"
									+ sublayoutDetail.get(j).get(1) + "|"
									+ shortDelimiter + "|" + columnPosition;
						} else if (sublayoutDetail.get(j).get(8)
								.equalsIgnoreCase("CHKDATE")) {

							if (runTimeFlag && dateType.trim() != ""
									&& !dateType.equalsIgnoreCase("NA")) {

								returnString += "\n" + "CHKDATE" + "|"
										+ sublayoutDetail.get(j).get(1) + "|"
										+ shortDelimiter + "|" + columnPosition
										+ "|" + dateType.toUpperCase();
							} else {
								returnString += "\n" + "CHKDATE" + "|"
										+ sublayoutDetail.get(j).get(1) + "|"
										+ shortDelimiter + "|" + columnPosition
										+ "|" + sublayoutDetail.get(j).get(3);
							}
						}
					}*/
					returnString += "\n" + "CHKNUMFIELDS" + "|"
							+ shortDelimiter + "|" + noOfFieldsFromTable;
				}
			}
		}
		return (returnString);
	}

	/**
	 * Method to replace the unwanted characters from the whereclause
	 * 
	 * @param sublayoutWhereClause
	 * @return
	 */
	private static String getReplacedWhereclause(String sublayoutWhereClause) {

		String replacedWhereClause = "";
		replacedWhereClause = sublayoutWhereClause.replaceAll("[']", "")
				.replaceAll("(\\((\\d+:\\d+)\\))", "$2");
		return replacedWhereClause;

	}

	private static String parseWhereClause(String subLayoutType,
			String replacedWhereClause, String shortDelimiter, String layoutId,
			String subLayoutID) {
		String combinedWhereClause = "";
		List<String> name = Arrays.asList(replacedWhereClause.split(
				"(?i)(\\sAND\\s)|(\\sOR\\s)", -1));
		Iterator<String> iter = name.iterator();
		String firstCondition = iter.next();
		String whereClause = generateFmonParsableWhereclause(subLayoutType,
				firstCondition, shortDelimiter, layoutId, subLayoutID);
		int firstPosition = firstCondition.length() - 1;
		if (replacedWhereClause.length() == firstCondition.length()) {
			return whereClause;
		} else {
			combinedWhereClause = whereClause + "\n";
			while (iter.hasNext()) {
				String temp = iter.next();

				whereClause = generateFmonParsableWhereclause(subLayoutType,
						temp, shortDelimiter, layoutId, subLayoutID);
				int lastPosition = replacedWhereClause.lastIndexOf(temp);
				String operator = replacedWhereClause.substring(firstPosition,
						lastPosition);

				if (operator.toUpperCase().contains("AND")) {
					combinedWhereClause += "RECORDCONDITION|AND";
				} else if (operator.toUpperCase().contains("OR")) {
					combinedWhereClause += "RECORDCONDITION|OR";
				} else {
					invalidWhereclauseFlag = true;
				}
				firstPosition += temp.length();
				combinedWhereClause += whereClause;
				if (iter.hasNext()) {
					combinedWhereClause += "\n";
				}
			}
		}

		return combinedWhereClause;
	}

	private static String generateFmonParsableWhereclause(String subLayoutType,
			String replacedWhereClause, String shortDelimiter, String layoutId,
			String subLayoutID) {
		String whereClause = "";
		String separator = "";
		String whereClauseLHS = "";
		String whereClauseRHS = "";
		int startpos = 0;
		int endpos = 0;
		if (replacedWhereClause.contains("!=")) {
			separator = "!=";
			whereClauseLHS = replacedWhereClause.substring(0,
					replacedWhereClause.indexOf("!")).trim();
			whereClauseRHS = replacedWhereClause.substring(
					replacedWhereClause.indexOf("!") + 2,
					replacedWhereClause.length()).trim();
		} else if (replacedWhereClause.contains("=")) {
			separator = "=";
			whereClauseLHS = replacedWhereClause.substring(0,
					replacedWhereClause.indexOf("=")).trim();
			whereClauseRHS = replacedWhereClause.substring(
					replacedWhereClause.indexOf("=") + 1,
					replacedWhereClause.length()).trim();
		}
		if (whereClauseLHS.matches(".*(\\d+:\\d+).*")) {
			try {
				startpos = Integer.parseInt(whereClauseLHS.substring(0,
						whereClauseLHS.indexOf(":")).trim());
				endpos = Integer.parseInt(whereClauseLHS.substring(
						whereClauseLHS.indexOf(":") + 1,
						whereClauseLHS.length()).trim());
			} catch (NumberFormatException e) {

				System.err
						.println("Number Format Exception in whereclause for given Layoutid "
								+ layoutId);
				invalidWhereclauseFlag = true;

			}
			whereClause = "\n" + "RECORDIDENT" + "|FIXED|" + (startpos) + ","
					+ (endpos - startpos + 1) + "|" + separator + "|"
					+ whereClauseRHS;

		} else {
			whereClauseLHS = whereClauseLHS.toUpperCase();

			try {
				getColumnNumberPreparedStatement.setObject(1, whereClauseLHS);
				getColumnNumberPreparedStatement.setObject(2, layoutId);
				getColumnNumberPreparedStatement.setObject(3, subLayoutID);
			} catch (SQLException e) {
				System.err.println("ERROR I");
				System.err.println(e.getMessage());
				e.printStackTrace();
			}

			List<List<String>> colNo = null;
			colNo = resultSetToListOfList(getColumnNumberPreparedStatement);
			if (colNo.size() > 1) {
				// Again Calculate the position of the field
				if (subLayoutType.equalsIgnoreCase("Fixed length")) {
					whereClause = colNo.get(1).get(1) + ","
							+ colNo.get(1).get(2) + "|" + separator + "|"
							+ whereClauseRHS;
					whereClause = "\n" + "RECORDIDENT" + "|FIXED|"
							+ whereClause;

				} else {
					whereClause = colNo.get(1).get(0) + "|" + separator + "|"
							+ whereClauseRHS;
					whereClause = "\n" + "RECORDIDENT" + "|" + shortDelimiter
							+ "|" + whereClause;
				}

			} else {
				if (!replacedWhereClause.equalsIgnoreCase("NA")) {
					invalidWhereclauseFlag = true;
					System.err.println("Field Not Found For This Layoutid "
							+ layoutId);
				}
			}
		}
		return whereClause;
	}

}
