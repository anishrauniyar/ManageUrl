package reportDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import databaseFactory.DatabaseFactory;
import databaseFactory.DatabaseProduction;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class GeneralDAO {

	public static Connection conn;
	public static PreparedStatement stmt;
	public static String connectString = "10.48.6.177:1521:d2he";
	public static String user = "importdb";
	public static String pass = "oracle";

	public static void initializeConnection() {
		conn = null;
		DatabaseProduction dbFactory = new DatabaseFactory();
		try {
			conn = dbFactory.getDatabaseConnection("ORACLE", connectString,
					user, pass);
		} catch (ClassNotFoundException e) {
			System.out.println("ERROR!");
			System.out.println(e.getMessage() + " Driver Class not found");
		} catch (SQLException e) {
			System.out.println("ERROR!!");
			System.out.println(e.getMessage() + " Connection Failed");
		}
	}

	private static List<List<String>> resultSetToListOfList(
			PreparedStatement stm) {
		try {
			if (stm != null) {
				ResultSet rs = stm.executeQuery();
				ResultSetMetaData metaData = rs.getMetaData();
				int numberOfColumns = metaData.getColumnCount();
				List<String> columnNames = new ArrayList<String>(
						numberOfColumns);

				for (int column = 0; column < numberOfColumns; column++) {
					columnNames.add(metaData.getColumnLabel(column + 1));
				}

				List<List<String>> rows = new ArrayList<List<String>>();
				rows.add(columnNames);
				while (rs.next()) {
					List<String> newRow = new ArrayList<String>(numberOfColumns);
					for (int i = 1; i <= numberOfColumns; i++) {
						if (rs.getObject(i) != null && rs.getObject(i) != "") {
							newRow.add(rs.getObject(i).toString());
						} else {
							newRow.add("");
						}
					}
					rows.add(newRow);
				}
				if (rs != null) {
					rs.close();
				}
				return rows;
			} else {
				return null;
			}

		} catch (Exception e) {
			System.out.println("ERROR C");
			System.out.println(e.getMessage() + " Result Set To List OF List "
					+ stm.toString());
			return null;
		} finally {
			if (stm != null) {
				try {
					stm.close();
				} catch (SQLException e) {
					System.out.println("Statement couldn't be closed");
					e.printStackTrace();
				}
			}

		}

	}

	public static void closeAll() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("Connection couldn't be closed");
				e.printStackTrace();
			}
		}
	}

	public static List<List<String>> getListOfList(String query) {
		
		try {
			stmt = conn.prepareStatement(query);
		} catch (SQLException e) {
			System.out.println("Error in Initializing Statement");
			e.printStackTrace();
		}
		return resultSetToListOfList(stmt);
	}

}
