package model;

import excelModel.ExcelModel;
import annotations.Column;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class SUMMARY extends ExcelModel{
	@Column(order = 2)
	Integer detsn;
	public Integer getDetsn() {
		return detsn;
	}
	public void setDetsn(Integer detsn) {
		this.detsn = detsn;
	}
	public Integer getSublayoutid() {
		return sublayoutid;
	}
	public void setSublayoutid(Integer sublayoutid) {
		this.sublayoutid = sublayoutid;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getCheckName() {
		return checkName;
	}
	public void setCheckName(String checkName) {
		this.checkName = checkName;
	}
	public Double getThreshold() {
		return threshold;
	}
	public void setThreshold(Double threshold) {
		this.threshold = threshold;
	}
	public Double getPercentage() {
		return percentage;
	}
	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Column(order = 3)
	Integer sublayoutid;
	@Column(order = 4)
	String fieldName;
	@Column(order = 5)
	String checkName;
	@Column(order = 7)
	Double threshold;
	@Column(order = 10)
	Double percentage;
	@Column(order = 11,filterCondition="THRESHOLD NOT MET")
	String remarks;
	@Column(order = 6)
	String requiredField;
	@Column(order = 8)
	Integer totalRecord;
	@Column(order = 9)
	Integer notNullCount;
	public Integer getNotNullCount() {
		return notNullCount;
	}
	public void setNotNullCount(Integer notNullCount) {
		this.notNullCount = notNullCount;
	}
	public Integer getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(Integer totalRecord) {
		this.totalRecord = totalRecord;
	}
	public String getRequiredField() {
		return requiredField;
	}
	public void setRequiredField(String requiredField) {
		this.requiredField = requiredField;
	}
}
