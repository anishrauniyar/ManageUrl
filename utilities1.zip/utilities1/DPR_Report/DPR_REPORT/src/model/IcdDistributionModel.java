package model;

import annotations.Column;
import excelModel.ExcelModel;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class IcdDistributionModel extends ExcelModel{
	@Column(order = 2)
	private Integer subLayoutid;
	@Column(order = 3)
	private String filedName;
	@Column(order = 4)
	private String distribution;
	@Column(order = 5)
	private Integer count;
	@Column(order = 6)
	private Double percentage;

	public Integer getSubLayoutid() {
		return subLayoutid;
	}

	public void setSubLayoutid(Integer subLayoutid) {
		this.subLayoutid = subLayoutid;
	}

	public String getFiledName() {
		return filedName;
	}

	public void setFiledName(String filedName) {
		this.filedName = filedName;
	}

	public String getDistribution() {
		return distribution;
	}

	public void setDistribution(String distribution) {
		this.distribution = distribution;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
}
