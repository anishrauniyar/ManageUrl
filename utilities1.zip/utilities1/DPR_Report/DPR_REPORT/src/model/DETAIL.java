package model;

import excelModel.ExcelModel;
import annotations.Column;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class DETAIL extends ExcelModel{
	@Column(order = 3)
	Integer detsn;
	
	public Integer getDetsn() {
		return detsn;
	}
	public void setDetsn(Integer detsn) {
		this.detsn = detsn;
	}
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	public String getInvalidValue() {
		return invalidValue;
	}
	public void setInvalidValue(String invalidValue) {
		this.invalidValue = invalidValue;
	}
	public String getInvReason() {
		return invReason;
	}
	public void setInvReason(String invReason) {
		this.invReason = invReason;
	}
	
	public Double getPercentage() {
		return percentage;
	}
	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}
	@Column(order = 4)
	String column;
	@Column(order = 5)
	String check;
	@Column(order = 6)
	String invalidValue;
	@Column(order = 7)
	String invReason;
	@Column(order = 8)
	Integer invalidCount;
	public Integer getInvalidCount() {
		return invalidCount;
	}
	public void setInvalidCount(Integer invalidCount) {
		this.invalidCount = invalidCount;
	}
	@Column(order = 9,format="0.00%")
	Double percentage;
}
