package databaseFactory;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Ayam Pokhrel
 */
public interface DatabaseProduction {
    
    public Connection getDatabaseConnection(String connectType, String connectString, String User, String Pass) throws SQLException, ClassNotFoundException;

}
