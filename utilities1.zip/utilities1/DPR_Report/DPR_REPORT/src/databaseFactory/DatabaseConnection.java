package databaseFactory;

import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Ayam Pokhrel
 */
public interface DatabaseConnection {
   
    public Connection getConnection(String connectString, String user, String pass) throws SQLException,ClassNotFoundException;
    
}
