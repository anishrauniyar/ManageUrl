package databaseFactory;

import databaseFactory.DatabaseConnection;
import databaseFactory.OracleDatabaseConnection;
import java.sql.Connection;
import java.sql.SQLException;


/**
 *
 * @author Ayam Pokhrel/intern15
 */

public class DatabaseFactory implements DatabaseProduction{
    
    DatabaseConnection dbconnection = null;
    Connection connection = null;
    @Override
    public Connection getDatabaseConnection(String connectType ,String connectString, String user, String pass) throws SQLException, ClassNotFoundException {
        
        if(connectType.equalsIgnoreCase("ORACLE")){
           dbconnection = new OracleDatabaseConnection();
           connection = dbconnection.getConnection(connectString,user,pass);

           return connection;
        }
        
        return connection;
    }
}

