package databaseFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
*
* @author Ayam Pokhrel
*/
public class OracleDatabaseConnection implements DatabaseConnection {

    public String destinationAddress="192.168.78.75:1521:KVAI";
    private final String DB_DRIVER = "oracle.jdbc.driver.OracleDriver";
    private String DB_CONNECTION = "jdbc:oracle:thin:@";
    public String DB_USER = "IMPORTDB";
    public String DB_PASSWORD = "oracle";
    public Connection dbConnectionOracle;


    @Override
    public Connection getConnection(String connectString, String user, String pass) throws ClassNotFoundException, SQLException {

        dbConnectionOracle = null;
        Class.forName(DB_DRIVER);
        destinationAddress=connectString;
        DB_USER=user;
        DB_PASSWORD=pass;
        DB_CONNECTION = DB_CONNECTION + destinationAddress;
      
        dbConnectionOracle = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
        dbConnectionOracle.setAutoCommit(false);
        return dbConnectionOracle;
    }
    
}
