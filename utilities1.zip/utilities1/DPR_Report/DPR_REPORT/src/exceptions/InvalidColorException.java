package exceptions;
/**
 * 
 * @author i81236,Ayam Pokhrel
 *
 */
public class InvalidColorException extends Exception {

	private static final long serialVersionUID = 1L;

	public void showMessage() {
		System.err.println("Invalid Color String");
	}
}
