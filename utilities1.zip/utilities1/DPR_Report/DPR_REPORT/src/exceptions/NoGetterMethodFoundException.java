package exceptions;

/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class NoGetterMethodFoundException extends Exception {

	/**
	 * Serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	public static String showMessage() {
		return "No Getter Method Found For Annotated Field";
	}
}
