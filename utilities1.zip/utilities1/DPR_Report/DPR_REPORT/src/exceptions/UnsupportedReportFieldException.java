package exceptions;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class UnsupportedReportFieldException extends Exception {

	/**
	 * Serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	public static String showMessage() {
		return "The given field is not supported Report";
	}
}
