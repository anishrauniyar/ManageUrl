package exceptions;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class NumberOfFieldsDoesntMatchException extends Exception {

	/**
	 * Serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	public static String showMessage() {
		return "Number Of Fields in the field List doesn't match with the number of Class Fields";
	}
}
