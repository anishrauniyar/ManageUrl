package exceptions;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class DuplicateOrderNumberException extends Exception {

	/**
	 * Serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	public static String showMessage() {
		return "Duplicate Field Order";
	}
}
