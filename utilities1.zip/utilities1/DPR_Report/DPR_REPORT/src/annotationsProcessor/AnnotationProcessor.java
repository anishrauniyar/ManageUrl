package annotationsProcessor;

import java.beans.IntrospectionException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

//import org.apache.commons.beanutils.PropertyUtils;

import utilities.ColumnUtilities;
import excelModel.TestModel;
import exceptions.DuplicateOrderNumberException;
import exceptions.NoGetterMethodFoundException;
import exceptions.UnsupportedReportFieldException;
import annotations.Column;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class AnnotationProcessor {

	public static TreeMap<Integer, ColumnUtilities> processAnnotation(
			String className) throws NoSuchMethodException, SecurityException,
			ClassNotFoundException, UnsupportedReportFieldException,
			DuplicateOrderNumberException, IntrospectionException,
			NoGetterMethodFoundException {
		TreeMap<Integer, ColumnUtilities> map = new TreeMap<Integer, ColumnUtilities>();
		Class<?> classObject = Class.forName(className);
		Field[] fields = classObject.getDeclaredFields();
		List<Field> fieldList = Arrays.asList(fields);
		Iterator<Field> iter = fieldList.iterator();
		while (iter.hasNext()) {
			Field field = iter.next();
			readAnnotationOn(field, classObject, map);
		}
		return map;
	}

	private static final HashSet<String> supportedTypes = new HashSet<String>(
			Arrays.asList(new String[] { "Double", "Integer", "Float",
					"String", "Date", "Long" }));

	static void readAnnotationOn(Field field, Class<?> className,
			TreeMap<Integer, ColumnUtilities> map)
			throws UnsupportedReportFieldException,
			DuplicateOrderNumberException, IntrospectionException,
			NoGetterMethodFoundException {
		Class<?> fieldType = field.getType();
		String fieldName = field.getName();
		ColumnUtilities columnUtilities = new ColumnUtilities();
		Annotation[] annotations = field.getDeclaredAnnotations();
		for (Annotation annotation : annotations) {
			boolean isAnnotationNotNull = field
					.isAnnotationPresent(Column.class);
			if (isAnnotationNotNull) {
				if (annotation instanceof Column) {

					Column columnInfo = (Column) annotation;
					int order = columnInfo.order();
					String dataFormat = columnInfo.format();
					String filterCondition = columnInfo.filterCondition();
					if (!supportedTypes.contains(fieldType.getSimpleName())) {
						throw new UnsupportedReportFieldException();
					}
					if (map.containsKey(order)) {
						throw new DuplicateOrderNumberException();
					}

					columnUtilities.setFieldType(fieldType.getSimpleName());
					columnUtilities.setFieldName(fieldName);
					columnUtilities.setFilterCondition(filterCondition);
					columnUtilities.setDataFormat(dataFormat);
					map.put(order, columnUtilities);
				}
			}
		}

	}

/*	static boolean propertyExists(String property, Object className) {
		return PropertyUtils.isReadable(className, property);

	}*/

	public static void main(String... args) {
		TestModel tm = new TestModel();
		String className = tm.getClass().getName();
		try {
			processAnnotation(className);
			for (Entry<Integer, ColumnUtilities> i : processAnnotation(
					className).entrySet()) {
				System.err.println(i.getKey());
			}
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedReportFieldException e) {
			e.printStackTrace();
		} catch (DuplicateOrderNumberException e) {
			e.printStackTrace();
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (NoGetterMethodFoundException e) {
			e.printStackTrace();
		}
	}
}