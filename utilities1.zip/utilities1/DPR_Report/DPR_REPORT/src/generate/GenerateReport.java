package generate;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import excel.ExcelGenerator;
import excel.StyleBank;
import excelModel.ExcelModel;

import model.DETAIL;
import model.IcdDistributionModel;
import model.SUMMARY;

//import model.ControlReconModel;

import reportDAO.GeneralDAO;

/**
 * 
 * @author i81236, Ayam Pokhrel
 * 
 */
public class GenerateReport {
	private static void usage(Options options) {
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("DPR Report", options);
		System.exit(1);
	}

	public static void main(String[] args) {

		Options options = new Options();
		options.addOption("p", true, "<Properties File>");
		options.addOption("f", true, "<AIP File ID>");
		options.addOption("l", true, "<DPR Report Location>");
		CommandLineParser parser = new BasicParser();
		CommandLine cmd;
		String fileID;
		String reportLocation;
		try {
			cmd = parser.parse(options, args);
		} catch (ParseException pe) {
			System.out.println(pe);
			usage(options);
			return;
		}
		if (cmd.hasOption("p")) {
			File file = new File(cmd.getOptionValue('p'));
			if (!file.exists()) {
				System.err.println("Properties File Not Found");
				usage(options);
				System.exit(1);
			} else {
				try {
					utilities.PropsUtils.sourceAllVariables(file);
				} catch (Exception e) {
					System.exit(1);
				}

			}
		}
		// generate("16054",
		// "O:\\Operations\\AIP\\AIP-aypokhrel\\DP\\ChangeRequest.xlsx");
		if (!cmd.hasOption("l") || !cmd.hasOption("f")) {
			System.err.println("Insufficient Parameters");
			usage(options);
			System.exit(1);
		} else {
			fileID = cmd.getOptionValue('f');
			reportLocation = cmd.getOptionValue('l');
			try {
				generate(fileID, reportLocation);
			} catch (Exception e) {
				System.exit(1);
			}
		}
	}

	public static void generate(String fileid, String path) {
		GeneralDAO.initializeConnection();
		final String fileImportQuery = "SELECT a.filename, a.clientid, nvl(a.layoutid,0) as layoutid,a.dmfileid,a.datatype,b.payor,a.PATTERN_SN FROM imp_main_log a left JOIN imp_layouts b ON a.layoutid=b.layoutid WHERE fileid = '"
				+ fileid + "'";
		List<List<String>> fileStatusList = GeneralDAO
				.getListOfList(fileImportQuery);
		if (fileStatusList.size() < 2) {
			System.err.println("File Information Not Found");
			System.exit(1);
		}
		final String summaryQuery = "SELECT det_sn,a.sublayoutid,field_name,CASE b.name WHEN 'Date Format Check' THEN b.name||' ('||Nvl(l.overriddendate,f.datetypedetial)||')' ELSE b.name END AS name,threshold AS valid_threshold,a.TOTAL_RECORD, a.total_record - a.null_count AS not_null_count, round((100-Nvl(invalid_percentage,100)),2) AS Valid_Percentage,nvl(chk_remarks,'EXCEPTION')  AS check_status, required_flag  FROM    dp_rpt_detail_log  a LEFT JOIN DP_CHECKS_MASTER b ON a.mas_id=b.mas_id  left JOIN imp_layouts_fields f ON a.field_sn=f.sn left JOIN imp_clientpatterns l ON l.sn='"
				+ fileStatusList.get(1).get(6)
				+ "' AND l.isoverridden='Y' where log_sn IN (SELECT max(log_sn) FROM dp_rpt_main_log WHERE fileid ='"
				+ fileid
				+ "') AND B.NAME!='ICD 9/10 Distribution'  ORDER BY chk_remarks DESC ,(Nvl(total_invalid,0)+Nvl(null_count,0)) desc";

		List<List<String>> checkDetailsList = GeneralDAO
				.getListOfList(summaryQuery);
		final String invalidValuesList = "SELECT * FROM ( SELECT a.* , ROW_NUMBER()OVER(PARTITION BY det_sn ORDER BY det_sn)rn  FROM ( SELECT a.det_sn,b.field_name,c.name,a.invalid_value,a.Invalid_reason,a.invalid_count ,round(DP_FXN_CALC_INVALID(a.INVALID_REASON,b.TOTAL_RECORD,a.INVALID_COUNT,b.NULL_COUNT,b.REQUIRED_FLAG),2) AS percentage FROM  dp_rpt_results a left JOIN dp_rpt_detail_log b ON  a.det_sn=b.det_sn  left JOIN dp_checks_master c ON b.mas_id=c.mas_id  WHERE a.det_sn IN (SELECT det_sn FROM    dp_rpt_detail_log  where log_sn IN (SELECT max(log_sn) FROM dp_rpt_main_log WHERE fileid = '"
				+ fileid + "') AND CHECK_NAME!='DISTICD'  ) )a ) WHERE rn<=100";
		List<List<String>> invalidSamplesList = GeneralDAO
				.getListOfList(invalidValuesList);
		String fileStatusQuery = "SELECT OVERALL_PROFILING_STATUS FROM dp_rpt_main_log  where log_sn IN (SELECT max(log_sn) FROM dp_rpt_main_log WHERE fileid ='"
				+ fileid + "')";
		List<List<String>> status = GeneralDAO.getListOfList(fileStatusQuery);

		if (checkDetailsList.size() < 2) {
			System.err.println("No Checks Defined");
			System.exit(1);
		}

		String icdDistributionQuery = "SELECT b.sublayoutid,b.field_name,c.distribution_type,c.distribution_count,Round((c.distribution_count*100/b.total_record),2) as percentage FROM dp_rpt_detail_log b  left JOIN dp_rpt_results c ON b.det_Sn=c.det_sn WHERE b.log_sn = (SELECT Max(log_sn) FROM   dp_rpt_main_log WHERE fileid = '"
				+ fileid
				+ "') AND  b.check_name = 'DISTICD'  ORDER BY sublayoutid , field_name , distribution_count desc";
		List<List<String>> icdDistributionList = GeneralDAO
				.getListOfList(icdDistributionQuery);
		ArrayList<ExcelModel> icdDistributionModelList = new ArrayList<ExcelModel>();
		ArrayList<ExcelModel> summaryList = new ArrayList<ExcelModel>();
		ArrayList<ExcelModel> detailList = new ArrayList<ExcelModel>();
		for (int i = 1; i < checkDetailsList.size(); i++) {
			SUMMARY summaryModel = new SUMMARY();
			summaryModel.setDetsn(convertToInteger(checkDetailsList.get(i).get(
					0)));
			summaryModel.setSublayoutid(convertToInteger(checkDetailsList
					.get(i).get(1)));
			summaryModel.setFieldName(checkDetailsList.get(i).get(2));
			summaryModel.setCheckName(checkDetailsList.get(i).get(3));
			summaryModel.setThreshold(convertToDouble(checkDetailsList.get(i)
					.get(4)));
			summaryModel.setTotalRecord(convertToInteger(checkDetailsList.get(i)
					.get(5)));
			summaryModel.setNotNullCount(convertToInteger(checkDetailsList.get(i)
					.get(6)));
			summaryModel.setPercentage(convertToDouble(checkDetailsList.get(i)
					.get(7)));
			summaryModel.setRemarks(checkDetailsList.get(i).get(8));
			summaryModel.setRequiredField(checkDetailsList.get(i).get(9));
			if (i == 1) {
				summaryModel.fieldNames = "DET_SN|SUBLAYOUTID|FIELD NAME|CHECK NAME|REQUIRED|VALID THRESHOLD|RECORD COUNT|NOT NULL COUNT|VALID PERCENTAGE|CHECK STATUS";
				summaryModel.skipRow = 5;
				summaryModel.headingRowFillColor = "0|176|240";
			}
			summaryList.add(summaryModel);
		}
		for (int i = 1; i < invalidSamplesList.size(); i++) {
			DETAIL detailModel = new DETAIL();
			detailModel.setDetsn(convertToInteger(invalidSamplesList.get(i)
					.get(0)));
			detailModel.setColumn(invalidSamplesList.get(i).get(1));
			detailModel.setCheck(invalidSamplesList.get(i).get(2));
			detailModel.setInvalidValue(invalidSamplesList.get(i).get(3));
			detailModel.setInvReason(invalidSamplesList.get(i).get(4));
			detailModel.setInvalidCount(convertToInteger(invalidSamplesList
					.get(i).get(5)));
			detailModel.setPercentage(convertToDouble(invalidSamplesList.get(i)
					.get(6)));
			if (i == 1) {
				detailModel.fieldNames = "DET_SN|COLUMN|CHECK|INVALID VALUE|INVALID REASON|INVALID COUNT|PERCENTAGE(%)";
				detailModel.skipRow = 3;
				detailModel.headingRowFillColor = "0|176|240";
			}

			detailList.add(detailModel);
		}
		for (int i = 1; i < icdDistributionList.size(); i++) {
			IcdDistributionModel model = new IcdDistributionModel();
			model.setSubLayoutid(convertToInteger(icdDistributionList.get(i)
					.get(0)));
			model.setFiledName(icdDistributionList.get(i).get(1));
			model.setDistribution(icdDistributionList.get(i).get(2));
			model.setCount(convertToInteger(icdDistributionList.get(i).get(3)));
			model.setPercentage(convertToDouble(icdDistributionList.get(i).get(
					4)));
			if (i == 1) {
				model.fieldNames = "SUBLAYOUTID|COLUMN|DISTRIBUTION|COUNT|PERCENTAGE(%)";
				model.skipRow = 3;
				model.headingRowFillColor = "0|176|240";
				model.sheetName = "ICD DISTRIBUTION";
			}
			icdDistributionModelList.add(model);
		}
		try {
			XSSFWorkbook wb = ExcelGenerator.createWorkBook(summaryList,
					detailList, icdDistributionModelList);
			XSSFSheet detailSheet = wb.getSheetAt(1);

			XSSFCellStyle defaultStyle = StyleBank.getDefaultStyle(wb);
			XSSFCellStyle mrgeStyle = wb.createCellStyle();
			mrgeStyle.cloneStyleFrom(defaultStyle);
			mrgeStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			XSSFRow statusRow = detailSheet.createRow(0);
			XSSFRow statusRow1 = detailSheet.createRow(1);
			XSSFRow statusRow2 = detailSheet.createRow(2);
			XSSFRow statusRow3 = detailSheet.createRow(3);
			XSSFCell filenameCell = statusRow1.createCell(3);
			filenameCell.setCellStyle(defaultStyle);
			filenameCell.setCellValue("Filename:");
			XSSFCell filenameCell1 = statusRow1.createCell(4);
			filenameCell1.setCellStyle(mrgeStyle);
			filenameCell1.setCellValue(fileStatusList.get(1).get(0));
			XSSFCell fillerCell7 = statusRow1.createCell(5);
			fillerCell7.setCellStyle(defaultStyle);
			XSSFCell fillerCell8 = statusRow1.createCell(6);
			fillerCell8.setCellStyle(defaultStyle);
			XSSFCell fillerCell6 = statusRow1.createCell(7);
			fillerCell6.setCellStyle(defaultStyle);
			XSSFCell fillerCell9 = statusRow1.createCell(8);
			fillerCell9.setCellStyle(defaultStyle);
			XSSFCell filenameCell4 = statusRow1.createCell(9);
			filenameCell4.setCellStyle(defaultStyle);
			filenameCell4.setCellValue("AIP File ID:");
			XSSFCell filenameCell5 = statusRow1.createCell(10);

			filenameCell5.setCellStyle(defaultStyle);
			filenameCell5.setCellValue(fileid);

			// ----
			XSSFCell clientIDCell = statusRow2.createCell(3);
			clientIDCell.setCellStyle(defaultStyle);
			clientIDCell.setCellValue("Datatype:");
			XSSFCell clientIdClell1 = statusRow2.createCell(4);
			clientIdClell1.setCellStyle(mrgeStyle);
			clientIdClell1.setCellValue(fileStatusList.get(1).get(4));
			XSSFCell fillerCell5 = statusRow2.createCell(5);
			fillerCell5.setCellStyle(defaultStyle);
			XSSFCell fillerCell4 = statusRow2.createCell(6);
			fillerCell4.setCellStyle(defaultStyle);
			XSSFCell fillerCell3 = statusRow2.createCell(7);
			fillerCell3.setCellStyle(defaultStyle);
			XSSFCell fillerCell10 = statusRow2.createCell(8);
			fillerCell10.setCellStyle(defaultStyle);
			XSSFCell clientidCell4 = statusRow2.createCell(9);
			clientidCell4.setCellStyle(defaultStyle);
			clientidCell4.setCellValue("Client ID:");
			XSSFCell clientdiCell5 = statusRow2.createCell(10);
			clientdiCell5.setCellStyle(defaultStyle);
			clientdiCell5.setCellValue(fileStatusList.get(1).get(1));
			// ---
			// ----
			XSSFCell layoutCell = statusRow3.createCell(3);
			layoutCell.setCellStyle(defaultStyle);
			layoutCell.setCellValue("Payer");
			XSSFCell layoutCell1 = statusRow3.createCell(4);
			layoutCell1.setCellStyle(mrgeStyle);
			layoutCell1.setCellValue(fileStatusList.get(1).get(5));
			XSSFCell layoutCell2 = statusRow3.createCell(5);
			layoutCell2.setCellStyle(defaultStyle);
			
			XSSFCell fillerCell1 = statusRow3.createCell(6);
			fillerCell1.setCellStyle(defaultStyle);
			XSSFCell fillerCell2 = statusRow3.createCell(7);
			fillerCell2.setCellStyle(defaultStyle);
			XSSFCell fillerCell11 = statusRow3.createCell(8);
			fillerCell11.setCellStyle(defaultStyle);
			XSSFCell layoutCell4 = statusRow3.createCell(9);
			layoutCell4.setCellStyle(defaultStyle);
			layoutCell4.setCellValue("Layout ID:");
			XSSFCell latoutCle5 = statusRow3.createCell(10);
			latoutCle5.setCellStyle(defaultStyle);
			latoutCle5.setCellValue(fileStatusList.get(1).get(2));
			// ---
			XSSFCellStyle mCtyle = wb.createCellStyle();
			mCtyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
			CellRangeAddress mergeRange = new CellRangeAddress(0, 0, 1, 10);
			CellRangeAddress fileNameMergeRange = new CellRangeAddress(1, 1, 4,
					8);
			CellRangeAddress payorNameMergeRange = new CellRangeAddress(2, 2,
					4, 8);
			CellRangeAddress datatypeMergerange = new CellRangeAddress(3, 3, 4,
					8);

			Font defaultFont = wb.createFont();
			defaultFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			defaultFont.setFontHeightInPoints((short) 17);
			Font successFont = wb.createFont();
			successFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			successFont.setFontHeightInPoints((short) 17);
			successFont.setColor(IndexedColors.GREEN.getIndex());
			Font failedFont = wb.createFont();
			failedFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
			failedFont.setFontHeightInPoints((short) 17);
			failedFont.setColor(IndexedColors.RED.getIndex());
			mCtyle.setFont(defaultFont);
			detailSheet.addMergedRegion(mergeRange);
			detailSheet.addMergedRegion(fileNameMergeRange);
			detailSheet.addMergedRegion(payorNameMergeRange);
			detailSheet.addMergedRegion(datatypeMergerange);

			XSSFCell statusCell = statusRow.createCell(1);
			statusCell.setCellStyle(mCtyle);
			XSSFRichTextString failedString = new XSSFRichTextString(
					"Overall File Status: FAILED");
			failedString.applyFont(20, failedString.length(), failedFont);
			XSSFRichTextString passedString = new XSSFRichTextString(
					"Overall File Status: PASSED");
			passedString.applyFont(20, passedString.length(), successFont);

			if (status.get(1).get(0).contains("PASSED")) {

				statusCell.setCellValue(passedString);
			} else {
				statusCell.setCellValue(failedString);
			}

			// ----------
			XSSFCell remarksCell = detailSheet.getRow(5).createCell(11);
			remarksCell.setCellStyle(detailSheet.getRow(5).getCell(10)
					.getCellStyle());
			remarksCell.setCellValue("REMARKS");
			XSSFCellStyle linkStyle = wb.createCellStyle();
			linkStyle.cloneStyleFrom(defaultStyle);
			Font linkFont = wb.createFont();
			linkFont.setColor(IndexedColors.BLUE.getIndex());
			linkFont.setUnderline(XSSFFont.U_SINGLE);
			linkStyle.setFont(linkFont);
			linkStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);

			if (detailList.size() != 0) {
				int th = wb.getSheetAt(2).getLastRowNum() + 1;
				for (int k = 6; k < detailSheet.getLastRowNum() + 1; k++) {
					Cell cell = detailSheet.getRow(k).createCell(11);
					cell.setCellStyle(linkStyle);
					cell.setCellType(XSSFCell.CELL_TYPE_FORMULA);
					cell.setCellFormula("IF(ISNA(MATCH(B" + (k + 1)
							+ ",DETAIL!$C$5:$C$" + th
							+ ",0)),\"\",HYPERLINK(\"#\"&\"DETAIL!B\"&(MATCH(B"
							+ (k + 1) + ",DETAIL!$C$5:$C$" + th
							+ ",0)+4),\"REVIEW\"))");
				}
			} else {
				
				for (int k = 6; k < detailSheet.getLastRowNum() + 1; k++) {
					Cell cell = detailSheet.getRow(k).createCell(11);
					cell.setCellStyle(linkStyle);
				}

			}
			// ---------
			for (int j = 1; j < 11; j++) {
				detailSheet.autoSizeColumn(j);
				if (detailList.size() != 0) {
					wb.getSheetAt(2).autoSizeColumn(j);
				}
			}
			detailSheet.createFreezePane(0, 6);
			if (detailList.size() != 0) {
				XSSFSheet resultsSheet = wb.getSheetAt(2);
				resultsSheet.createFreezePane(0, 4);
				resultsSheet.setColumnHidden(2, true);
				XSSFCell goBackCell = resultsSheet.getRow(3).createCell(1);
				goBackCell.setCellStyle(resultsSheet.getRow(3).getCell(4)
						.getCellStyle());
				goBackCell.setCellValue("Back");
				int th = detailSheet.getLastRowNum() + 1;
				for (int k = 4; k < resultsSheet.getLastRowNum() + 1; k++) {
					Cell cell = resultsSheet.getRow(k).createCell(1);
					cell.setCellStyle(linkStyle);
					cell.setCellType(XSSFCell.CELL_TYPE_FORMULA);
					cell.setCellFormula("HYPERLINK(\"#\"&\"SUMMARY!C\"&(MATCH(C"
							+ (k + 1)
							+ ",SUMMARY!$B$7:$B$"
							+ th
							+ ",0)+6),\"..\")");
				}
				XSSFRow datasetRow = resultsSheet.createRow(0);
				XSSFCell datasetCell = datasetRow.createCell(1);
				datasetCell.setCellStyle(mCtyle);
				XSSFRichTextString invalidDataSet = new XSSFRichTextString(
						"Invalid Dataset");
				invalidDataSet
						.applyFont(0, invalidDataSet.length(), failedFont);
				datasetCell.setCellValue(invalidDataSet);
				String warning = "*showing maximum 100 invalid values per check";
				XSSFRow warningRow = resultsSheet.createRow(2);
				XSSFCell warningCell = warningRow.createCell(1);
				warningCell.setCellValue(warning);
				// warningCell.setCellStyle(mCtyle);
				CellRangeAddress invalidDataSetRange = new CellRangeAddress(0,
						1, 1, 8);
				CellRangeAddress warningRange = new CellRangeAddress(2, 2, 1, 8);
				resultsSheet.addMergedRegion(invalidDataSetRange);
				resultsSheet.addMergedRegion(warningRange);

			}
			detailSheet.setColumnHidden(1, true);
			if (icdDistributionModelList.size() != 0) {
				XSSFSheet icdDistSheet = wb.getSheet("ICD DISTRIBUTION");
				for (int j = 1; j < 6; j++) {
					icdDistSheet.autoSizeColumn(j);
				}
				icdDistSheet.createFreezePane(0, 4);
				CellRangeAddress inforange = new CellRangeAddress(0, 1, 1, 5);
				XSSFRow infoRow = icdDistSheet.createRow(0);
				XSSFCell infoCell = infoRow.createCell(1);
				infoCell.setCellStyle(mCtyle);
				infoCell.setCellValue("ICD Distribution");
				icdDistSheet.addMergedRegion(inforange);
			}
			String xlsxFileAddress = path;
			wb.removeSheetAt(0);
			FileOutputStream fileOutputStream = new FileOutputStream(
					xlsxFileAddress);
			wb.write(fileOutputStream);

		} catch (Exception e) {
			e.printStackTrace();
		}
		GeneralDAO.closeAll();

	}

	public static double convertToDouble(String s) {
		try {
			return Double.parseDouble(s);
		} catch (Exception e) {
			return 0;
		}
	}

	public static int convertToInteger(String i) {
		try {
			return Integer.parseInt(i);
		} catch (Exception e) {
			return 0;
		}
	}

	public static Date convertToDate(String date) {

		SimpleDateFormat queryResultDateFormat;
		if (date.contains("-")) {
			queryResultDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		} else {
			queryResultDateFormat = new SimpleDateFormat("yyyyMMdd");
		}
		try {
			return queryResultDateFormat.parse(date);
		} catch (Exception e) {
			return null;
		}
	}

}
