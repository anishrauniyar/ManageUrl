package excel;

import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFCell;
/**
 * 
 * @author i81236,Ayam Pokhrel
 *
 */
public class ExcelUtilities {

	public static void setValueOfCell(XSSFCell cell, Object value) {
		if (value == null) {
			cell.setCellValue("");
		} else if (value instanceof Integer) {
			cell.setCellValue((Integer) value);
		} else if (value instanceof Date) {
			cell.setCellValue((Date) value);
		} else if (value instanceof Double) {
			cell.setCellValue((Double) value);
		} else if (value instanceof Long) {
			cell.setCellValue((Long) value);
		} else if (value instanceof Float) {
			cell.setCellValue((Float) value);
		} else if (value instanceof String) {
			cell.setCellValue((String) value);
		}
	}

}
