package excel;

import java.awt.Color;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 
 * @author Ayam Pokhrel This is the main Style class for excel reporting tool
 */

public class StyleBank {

	/**
	 * This field is used for alternate coloring based upon division by two. It
	 * is incremented each time by 1 after it is used.
	 */

	private static int alternateInteger;

	/**
	 * 
	 * @return alternateFlag (Alternate Boolean Value)
	 */
	private static boolean alternateFunction() {
		if (alternateInteger % 2 == 0) {
			alternateInteger++;
			return true;
		} else {
			alternateInteger++;
			return false;
		}
	}

	private static HashMap<String, XSSFCellStyle> dataFormatStylesMap = new HashMap<String, XSSFCellStyle>();
	private static HashMap<XSSFCellStyle, XSSFCellStyle> colourStylesMap = new HashMap<XSSFCellStyle, XSSFCellStyle>();
	private static HashMap<XSSFCellStyle, XSSFCellStyle> wrapTextMap = new HashMap<XSSFCellStyle, XSSFCellStyle>();

	// private static boolean isAlternalteInitialized = false;
	// private static HashMap<Boolean, XSSFCellStyle> alternateStyleMap = new
	// HashMap<Boolean, XSSFCellStyle>();

	/**
	 * This method creates the default cell style for the report which is the
	 * style having only borders and normal black font.
	 * 
	 * @param workbook
	 *            The workbook on which the style is going to be created
	 * @return XSSFCellStyle (Borders-only Style)
	 */
	public static XSSFCellStyle getDefaultStyle(XSSFWorkbook workbook) {
		XSSFCellStyle defaultStyle = workbook.createCellStyle();
		defaultStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		defaultStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		defaultStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		defaultStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		defaultStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		XSSFFont defaultFont = workbook.createFont();
		defaultFont.setColor(IndexedColors.BLACK.index);
		defaultStyle.setFont(defaultFont);
		return defaultStyle;
	}

	public static XSSFCellStyle getTitleStyle(XSSFWorkbook workbook,
			Color titleFontColor, Color fillColor) {
		XSSFCellStyle titleStyle = workbook.createCellStyle();
		titleStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
		titleStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
		titleStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
		titleStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
		titleStyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
		titleStyle.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		titleStyle.setFillForegroundColor(new XSSFColor(fillColor));
		titleStyle.setFillPattern(XSSFCellStyle.SOLID_FOREGROUND);
		XSSFFont defaultFont = workbook.createFont();
		defaultFont.setColor(new XSSFColor(titleFontColor));
		defaultFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);
		titleStyle.setFont(defaultFont);
		return titleStyle;
	}

	public static XSSFCellStyle getAlternateColorStyle(XSSFCellStyle cellStyle,
			XSSFWorkbook workbook) {

		XSSFCellStyle tempstyle = workbook.createCellStyle();
		tempstyle.cloneStyleFrom(cellStyle);
		tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);

		if (alternateFunction()) {
			tempstyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(
					245, 245, 245)));
		} else {
			tempstyle.setFillForegroundColor(IndexedColors.WHITE.index);
		}

		return tempstyle;
	}

	public static XSSFCellStyle getWrapTextStyle(XSSFCellStyle cellstyle,
			XSSFWorkbook workbook) {
		if (wrapTextMap.containsKey(cellstyle)) {
			return wrapTextMap.get(cellstyle);
		} else {
			XSSFCellStyle tempstyle = workbook.createCellStyle();
			tempstyle.cloneStyleFrom(cellstyle);
			tempstyle.setWrapText(true);
			tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			wrapTextMap.put(cellstyle, tempstyle);
			return tempstyle;
		}

	}

	public static XSSFCellStyle getDataFormatStyle(XSSFCellStyle cellstyle,
			String format, XSSFWorkbook workbook) {
		if (dataFormatStylesMap.containsKey(format)) {
			return dataFormatStylesMap.get(format);
		} else {
			XSSFCellStyle tempstyle = workbook.createCellStyle();
			tempstyle.cloneStyleFrom(cellstyle);
			tempstyle.setDataFormat(workbook.createDataFormat().getFormat(
					format));
			tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
			dataFormatStylesMap.put(format, tempstyle);
			return tempstyle;
		}
	}

	public static XSSFCellStyle getFilterStyle(boolean filterFlag,
			XSSFCellStyle cellstyle, XSSFWorkbook workbook, Color color) {
		if (filterFlag) {
			if (colourStylesMap.containsKey(cellstyle)) {
				return colourStylesMap.get(cellstyle);
			} else {
				XSSFCellStyle tempstyle = workbook.createCellStyle();
				tempstyle.cloneStyleFrom(cellstyle);
				XSSFFont coloredFont = workbook.createFont();
				coloredFont.setColor(new XSSFColor(color));
				tempstyle.setFont(coloredFont);
				tempstyle.setVerticalAlignment(XSSFCellStyle.VERTICAL_CENTER);
				colourStylesMap.put(cellstyle, tempstyle);
				return tempstyle;
			}
		} else {
			return cellstyle;
		}
	}

	public static XSSFFont getFilterFont(XSSFWorkbook workbook, Color color) {
		XSSFFont coloredFont = workbook.createFont();
		coloredFont.setColor(new XSSFColor(color));
		return coloredFont;
	}

}
