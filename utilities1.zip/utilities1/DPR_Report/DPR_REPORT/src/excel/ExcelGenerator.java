package excel;

import java.awt.Color;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.TreeSet;


import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import annotationsProcessor.AnnotationProcessor;
import utilities.ColumnUtilities;
import utilities.ParserUtilities;
import excelModel.ExcelModel;
import exceptions.DuplicateOrderNumberException;
import exceptions.InvalidColorException;
import exceptions.NoGetterMethodFoundException;
import exceptions.NumberOfFieldsDoesntMatchException;
import exceptions.UnsupportedReportFieldException;
/**
 * 
 * @author i81236,Ayam Pokhrel
 *
 */
public class ExcelGenerator {
	private static XSSFCellStyle defaultStyle;
	private static XSSFCellStyle tableHeadingStyle;
	private static XSSFFont coloredFont;

	private static Color filterColor;
	private static Color tableHeadingFontColor;
	private static Color fillColor;

	@SafeVarargs
	public static XSSFWorkbook createWorkBook(
			ArrayList<ExcelModel>... listOfExcelObjectList)
			throws NoSuchMethodException, SecurityException,
			ClassNotFoundException, UnsupportedReportFieldException,
			DuplicateOrderNumberException, IntrospectionException,
			NoGetterMethodFoundException, NumberOfFieldsDoesntMatchException,
			InvalidColorException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet coverPageSheet = workbook.createSheet("CoverPage");
		coverPageSheet.setDisplayGridlines(false);
		for (ArrayList<ExcelModel> modelList : listOfExcelObjectList) {
			if (modelList== null) {
				continue;
			}
			if(modelList.size()==0){
				continue;
			}
			ExcelModel model = modelList.get(0);
			createSheet(model, workbook, modelList);
		}
		excelModel.TestModel.workbook = workbook;
		return workbook;

	}

	private static void createSheet(ExcelModel model, XSSFWorkbook workbook,
			ArrayList<ExcelModel> modelList) throws NoSuchMethodException,
			SecurityException, ClassNotFoundException,
			UnsupportedReportFieldException, DuplicateOrderNumberException,
			IntrospectionException, NoGetterMethodFoundException,
			NumberOfFieldsDoesntMatchException, InvalidColorException,
			IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		setDefaultStyles(workbook, model.filterColor,
				model.headingRowFillColor, model.headingRowFontColor);
		TreeMap<Integer, ColumnUtilities> map = AnnotationProcessor
				.processAnnotation(model.getClass().getName());
		int layoutType;
		switch (model.layoutType) {
		case ExcelModel.VERTICAL:
			layoutType = 2;
			break;
		case ExcelModel.HORIZONTAL:
			layoutType = 1;
			break;
		default:
			layoutType = 1;
			break;
		}
		XSSFSheet workingSheet;
		if (model.embeddedSheetNumber == null) {
			if (model.sheetName == null) {
				workingSheet = workbook.createSheet(model.getClass()
						.getSimpleName());
			} else {
				workingSheet = workbook.createSheet(model.sheetName);
			}
		} else {
			workingSheet = workbook.getSheetAt(model.embeddedSheetNumber - 1);
		}

		if (model.displayGridLines == null) {
			workingSheet.setDisplayGridlines(true);
		} else {
			workingSheet.setDisplayGridlines(model.displayGridLines);
		}

		fillSheetData(workingSheet, workbook, model, layoutType, map, modelList);

	}

	private static void setDefaultStyles(XSSFWorkbook workbook,
			String filterColor2, String headingRowFillColor,
			String headingRowFontColor) throws InvalidColorException {
		defaultStyle = StyleBank.getDefaultStyle(workbook);
		tableHeadingFontColor = ParserUtilities.parseColor(headingRowFontColor);
		fillColor = ParserUtilities.parseColor(headingRowFillColor);
		tableHeadingStyle = StyleBank.getTitleStyle(workbook,
				tableHeadingFontColor, fillColor);
		filterColor = ParserUtilities.parseColor(filterColor2);
		coloredFont = StyleBank.getFilterFont(workbook, filterColor);
	}

	private static void fillSheetData(XSSFSheet workingSheet,
			XSSFWorkbook workbook, ExcelModel model, int layoutType,
			TreeMap<Integer, ColumnUtilities> map,
			ArrayList<ExcelModel> modelList)
			throws NumberOfFieldsDoesntMatchException, IntrospectionException,
			IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {

		switch (layoutType) {
		case 1:
			fillSheetDataHorizontal(workingSheet, workbook, model, map,
					modelList);
			break;
		case 2:
			fillSheetDataVertical(workingSheet, workbook, model, map, modelList);
			break;
		}
	}

	private static void fillSheetDataVertical(XSSFSheet workingSheet,
			XSSFWorkbook workbook, ExcelModel model,
			TreeMap<Integer, ColumnUtilities> map,
			ArrayList<ExcelModel> modelList)
			throws NumberOfFieldsDoesntMatchException {
		List<String> fieldList = null;
		if (model.fieldNames != null) {
			fieldList = ParserUtilities
					.parseDelimittedStringToStringList(model.fieldNames);
		}

		if (fieldList != null && fieldList.size() != map.size()) {
			throw new NumberOfFieldsDoesntMatchException();
		}
		// int startRow = model.skipRow;
	}

	private static void fillSheetDataHorizontal(XSSFSheet workingSheet,
			XSSFWorkbook workbook, ExcelModel model,
			TreeMap<Integer, ColumnUtilities> map,
			ArrayList<ExcelModel> modelList)
			throws NumberOfFieldsDoesntMatchException, IntrospectionException,
			IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		int startRow = model.skipRow;

		List<String> fieldList = null;
		if (model.fieldNames != null) {
			fieldList = ParserUtilities
					.parseDelimittedStringToStringList(model.fieldNames);
		}

		if (fieldList != null && fieldList.size() != map.size()) {
			throw new NumberOfFieldsDoesntMatchException();
		}
		XSSFRow titleRow = workingSheet.createRow(startRow);
		int m = 0;
		int startingColumnNumber = -1;
		boolean isFieldListNull = fieldList == null;
		int filterColumnKey = -1;
		String filterCondition = "defaultFilterCondition";
		Set<Integer> set = map.keySet();
		TreeSet<Integer> columnsSet = new TreeSet<Integer>(set);
		for (Entry<Integer, ColumnUtilities> i : map.entrySet()) {
			int currentCellNumber = i.getKey() - 1;
			XSSFCell cell = titleRow.createCell(currentCellNumber);
			if (startingColumnNumber < 0) {
				startingColumnNumber = currentCellNumber;
			}
			cell.setCellStyle(tableHeadingStyle);
			if (!isFieldListNull) {
				cell.setCellValue(fieldList.get(m));

			} else {
				cell.setCellValue(i.getValue().getFieldName());
			}
			m++;
			String temp = i.getValue().getFilterCondition();
			boolean isFilterOn = !(temp.equals("defaultFilterCondition"));
			if (isFilterOn) {
				filterCondition = temp;
				filterColumnKey = i.getKey();
			}

		}

		int rowNum = startRow + 1;
		for (int j = 0; j < modelList.size(); j++) {
			boolean filterFlag = false;
			if (filterColumnKey > -1) {
				String fieldName = map.get(filterColumnKey).getFieldName();
				PropertyDescriptor pd = new PropertyDescriptor(fieldName,
						modelList.get(j).getClass());
				if (pd.getReadMethod().invoke(modelList.get(j)).toString()
						.contains(filterCondition)) {
					filterFlag = true;
				}
			}
			Iterator<Integer> iter = columnsSet.iterator();
			XSSFRow currentRow;
			if (workingSheet.getRow(rowNum) == null) {
				currentRow = workingSheet.createRow(rowNum);
			} else {
				currentRow = workingSheet.getRow(rowNum);
			}

			while (iter.hasNext()) {

				int columnNumber = iter.next();
				ColumnUtilities util = map.get(columnNumber);
				String dataFormat = util.getDataFormat();
				String dataType = util.getFieldType();
				PropertyDescriptor pd = new PropertyDescriptor(
						util.getFieldName(), modelList.get(j).getClass());
				Object value = pd.getReadMethod().invoke(modelList.get(j));
				XSSFCell cell = currentRow.createCell(columnNumber - 1);
				cell.setCellStyle(defaultStyle);
				ExcelUtilities.setValueOfCell(cell, value);
				if (filterFlag) {
					CellUtil.setFont(cell, workbook, coloredFont);
				}
				
				if (!dataFormat.equals("defaultFormat")) {
					CellUtil.setCellStyleProperty(cell, workbook,
							CellUtil.DATA_FORMAT, dataFormat);
				} else {
					switch (dataType) {
					case "Double":
						CellUtil.setCellStyleProperty(cell, workbook,
								CellUtil.DATA_FORMAT, "0.#0");
						break;
					case "Integer":
						CellUtil.setCellStyleProperty(cell, workbook,
								CellUtil.DATA_FORMAT, "#,##0");
						break;
					case "Float":
						CellUtil.setCellStyleProperty(cell, workbook,
								CellUtil.DATA_FORMAT, "0.#0");
						break;
					case "Date":
						CellUtil.setCellStyleProperty(cell, workbook,
								CellUtil.DATA_FORMAT, "yyyy-mm-dd hh:mm:ss");
						break;
					case "Long":
						CellUtil.setCellStyleProperty(cell, workbook,
								CellUtil.DATA_FORMAT, "#,##0");
						break;
					default:
						break;
					}
				}
			}
			rowNum++;
		}
		
		 // FROM HERE CUSTOMIZATION --------------------------------------------------------------//
		/* 
		XSSFSheetConditionalFormatting sheetCF = workingSheet.getSheetConditionalFormatting();		
		XSSFConditionalFormattingRule rule1 = sheetCF.createConditionalFormattingRule("MOD(SUMPRODUCT(--(($D$2:INDIRECT(ADDRESS(ROW()-1,1,3,1))=$D$3:INDIRECT(ADDRESS(ROW(),1,3,1)))=FALSE)),2)");
		XSSFPatternFormatting fill1 = rule1.createPatternFormatting();
		fill1.setFillForegroundColor(IndexedColors.BLUE.index);
		fill1.setFillPattern(PatternFormatting.SOLID_FOREGROUND);



		CellRangeAddress[] regions = {
		        CellRangeAddress.valueOf("A1:F10")
		};

		sheetCF.addConditionalFormatting(regions, rule1);
		
		// TILL HERE ---------------------------------------------------//
*/		 
	}
}
