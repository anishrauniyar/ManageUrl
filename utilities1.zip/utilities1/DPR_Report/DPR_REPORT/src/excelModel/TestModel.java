package excelModel;

import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PatternFormatting;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;

import excel.ExcelGenerator;
import annotations.Column;

public class TestModel extends ExcelModel {
	public static Workbook workbook;
	@Column(order = 4)
	Integer rollNumber;
	//@Column(order = 2, filterCondition = "Ayam")
	 @Column(order = 5)
	String name;

	@Column(order = 6)
	Double marks;

	public Integer getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(Integer rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getMarks() {
		return marks;
	}

	public void setMarks(Double marks) {
		this.marks = marks;
	}

	public static void main(String[] args) {
		TestModel testmodel = new TestModel();
		testmodel.setName("Ayam");
		testmodel.setMarks(20.22);
		testmodel.setRollNumber(05);

		//testmodel.embeddedSheetNumber = 1;
		testmodel.displayGridLines = false;
		testmodel.fieldNames = "Ram|Shyam|Hari";
		

		ArrayList<ExcelModel> testList = new ArrayList<ExcelModel>();

		testList.add(testmodel);

		TestModel testmodel2 = new TestModel();
		testmodel2.setName("Renu");
		testmodel2.setMarks(20.2234567);
		testmodel2.setRollNumber(6);
		testList.add(testmodel2);
		
		TestModel test = new TestModel();
		test.setName("Shyam");
		test.setMarks(20.2234567);
		test.setRollNumber(7);
		testList.add(test);
		
		TestModel test2 = new TestModel();
		test2.setName("Renu");
		test2.setMarks(20.2234567);
		test2.setRollNumber(8);
		testList.add(test2);

		try {
			ExcelGenerator.createWorkBook(testList);
			Sheet my_sheet = workbook.cloneSheet(1);
			for(int i=1;i<my_sheet.getLastRowNum()+1;i++){
				
				Cell cell = my_sheet.getRow(i).createCell(12);
				String strFormula= "IF(D"+(i+1)+"=D"+(i)+",M"+(i)+",1-M"+(i)+")";
				System.err.println(strFormula);
				if(i==1){
					cell.setCellValue(0);
					continue;
				}
				cell.setCellType(XSSFCell.CELL_TYPE_FORMULA);
				cell.setCellFormula(strFormula);
			}
			
			
			my_sheet.createRow(5).createCell(0).setCellValue(41);
			SheetConditionalFormatting sheetCF = my_sheet.getSheetConditionalFormatting();
			
			ConditionalFormattingRule rule1 = sheetCF.createConditionalFormattingRule("IF(D3=D2,M2,1-M2)>0");
			PatternFormatting fill1 = rule1.createPatternFormatting();
	        fill1.setFillBackgroundColor(IndexedColors.BLUE.index);
	        fill1.setFillPattern(PatternFormatting.SOLID_FOREGROUND);

	        CellRangeAddress[] regions = {
	                CellRangeAddress.valueOf("A1:F10")
	        };

	        sheetCF.addConditionalFormatting(regions, rule1);
            
	 
			String xlsxFileAddress = "O:\\AIP-aypokhrel\\DP\\testReport.xlsx";
			FileOutputStream fileOutputStream = new FileOutputStream(
					xlsxFileAddress);
			workbook.write(fileOutputStream);
			fileOutputStream.close();
		} catch (Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
	}
}
