package excelModel;
/**
 * 
 * @author i81236,Ayam Pokhrel
 *
 */
public abstract class ExcelModel {
	public static final int HORIZONTAL = 1;
	public static final int VERTICAL = 2;
	public String filterColor = "255|0|0";
	public String headingRowFontColor = "0|0|0";
	public String headingRowFillColor = "219|229|241";
	public String sheetName;
	public String fieldNames = null;
	public int layoutType = HORIZONTAL;
	public Integer embeddedSheetNumber;
	public Integer skipRow = 0;
	public Boolean displayGridLines;
}
