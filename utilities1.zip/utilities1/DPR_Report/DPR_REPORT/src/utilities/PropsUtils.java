package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import reportDAO.GeneralDAO;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class PropsUtils {

	public static void sourceAllVariables(File propertiesFile) throws IOException {
		Properties prop = new Properties();
		InputStream input = null;
			input = new FileInputStream(propertiesFile);
			prop.load(input);
			GeneralDAO.connectString = prop.getProperty("CONNECT_STRING");
			GeneralDAO.user = prop.getProperty("SCHEMA");
			GeneralDAO.pass = prop.getProperty("PASSWORD");
		
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	
}
