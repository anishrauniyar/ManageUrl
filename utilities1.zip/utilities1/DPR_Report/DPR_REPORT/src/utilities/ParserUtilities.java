package utilities;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import exceptions.InvalidColorException;
/**
 * 
 * @author i81236,Ayam Pokhrel
 *
 */
public class ParserUtilities {
	public static List<String> parseDelimittedStringToStringList(
			String pipeDelimittedList) {
		List<String> splittedStringList = Arrays.asList(pipeDelimittedList
				.split("\\|", -1));
		return splittedStringList;
	}

	public static Color parseColor(String delimitedString)
			throws InvalidColorException {
		List<String> splittedStringList = parseDelimittedStringToStringList(delimitedString);
		if (splittedStringList == null || splittedStringList.size() != 3) {
			throw new exceptions.InvalidColorException();
		}
		int red = Integer.parseInt(splittedStringList.get(0).trim());
		int green = Integer.parseInt(splittedStringList.get(1).trim());
		int blue = Integer.parseInt(splittedStringList.get(2).trim());
		Color color = new Color(red, green, blue);
		return color;
	}
}
