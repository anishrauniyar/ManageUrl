package utilities;
/**
 * 
 * @author i81236, Ayam Pokhrel
 *
 */
public class ColumnUtilities {
	private String fieldName;
	private String dataFormat;
	private String filterCondition;
	private boolean isWrapText;
	private String fieldType;

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getDataFormat() {
		return dataFormat;
	}

	public void setDataFormat(String dataFormat) {
		this.dataFormat = dataFormat;
	}

	public String getFilterCondition() {
		return filterCondition;
	}

	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}

	public boolean isWrapText() {
		return isWrapText;
	}

	public void setWrapText(boolean isWrapText) {
		this.isWrapText = isWrapText;
	}
}
