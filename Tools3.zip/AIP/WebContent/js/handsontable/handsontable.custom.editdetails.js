var lengthCheck = 0;
var reg = /^[a-zA-z\d]+$/i;
var reg2 = /\s/i;
var reg3 = /^\d/i;
var reg4 = /^_/i;
var reg5 = /^\d+$/i;
var otherCheck = 0;
var dupCheck = new Array();
var invalidfieldlength = 0;
var datatyepcheck = 0;
var columnnamecheck = 0;
var datecheck = 0;
var datatypeempty = 0;
var timestampcheck = 0;
var invalidfieldlength = 0;
var oracleDataType = new Array("varchar", "char", "varchar2", "date",
		"nvarchar2", "float", "number", "integer", "timestamp");
var reservedwords = new Array("ALL", "AND", "ARE", "ASTERISK", "AT", "ATSIGN",
		"BADFILE", "BADFILENAME", "BACKSLASH", "BENDIAN", "BIG", "BLANKS",
		"BY", "BYTES", "BYTESTR", "CHAR", "CHARACTERS", "CHARACTERSET",
		"CHARSET", "CHARSTR", "CHECK", "CLOB", "COLLENGTH", "COLON", "COLUMN",
		"COMMA", "CONCAT", "CONSTANT", "COUNTED", "DATA", "DATE", "DATE_CACHE",
		"DATE_FORMAT", "DATEMASK", "DAY", "DEBUG", "DECIMAL", "DEFAULTIF",
		"DELIMITBY", "DELIMITED", "DISCARDFILE", "DOT", "DOUBLE", "DOUBLETYPE",
		"DQSTRING", "DQUOTE", "DSCFILENAME", "ENCLOSED", "ENDIAN", "ENDPOS",
		"EOF", "EQUAL", "EXIT", "EXTENDED_IO_PARAMETERS", "EXTERNAL",
		"EXTERNALKW", "EXTPARM", "FIELD", "FIELDS", "FILE", "FILEDIR",
		"FILENAME", "FIXED", "FLOAT", "FLOATTYPE", "FOR", "FROM", "HASH",
		"HEXPREFIX", "IN", "INTEGER", "INTERVAL", "LANGUAGE", "IS", "LEFTCB",
		"LEFTTXTDELIM", "LEFTP", "LENDIAN", "LDRTRIM", "LITTLE", "LOAD",
		"LOBFILE", "LOBPC", "LOBPCCONST", "LOCAL", "LOCALTZONE", "LOGFILE",
		"LOGFILENAME", "LRTRIM", "LTRIM", "MAKE_REF", "MASK", "MINUSSIGN",
		"MISSING", "MISSINGFLD", "MONTH", "NEWLINE", "NO", "NOCHECK", "NOT",
		"NOBADFILE", "NODISCARDFILE", "NOLOGFILE", "NOTEQUAL", "NOTERMBY",
		"NOTRIM", "NULL", "NULLIF", "OID", "OPTENCLOSE", "OPTIONALLY",
		"OPTIONS", "OR", "ORACLE_DATE", "ORACLE_NUMBER", "PLUSSIGN",
		"POSITION", "PROCESSING", "QUOTE", "RAW", "READSIZE", "RECNUM",
		"RECORDS", "REJECT", "RIGHTCB", "RIGHTTXTDELIM", "RIGHTP", "ROW",
		"ROWS", "RTRIM", "SCALE", "SECOND", "SEMI", "SETID", "SIGN", "SIZES",
		"SKIP", "STRING", "TERMBY", "TERMEOF", "TERMINATED", "TERMWS",
		"TERRITORY", "TIME", "TIMESTAMP", "TIMEZONE", "TO", "TRANSFORMS",
		"UNDERSCORE", "UINTEGER", "UNSIGNED", "VALUES", "VARCHAR", "VARCHARC",
		"VARIABLE", "VARRAW", "VARRAWC", "VLENELN", "VMAXLEN", "WHEN",
		"WHITESPACE", "WITH", "YEAR", "ZONED", "UDF1", "UDF2", "UDF3", "UDF4",
		"UDF5", "SOURCEFILENAME", "RECEIVEDMONTH", "IMPORTEDDATE", "CLIENTID",
		"EMPGRP", "FILEID", "ROWNUMBER", "HASHKEY", "PAYORNAME", "C",
		"AIPLINENUMBER","CURRENT","GROUP");

fieldValueRenderer = function(instance, td, row, col, prop, value,
		cellProperties) {

	Handsontable.TextCell.renderer.apply(this, arguments);
	var duplicateCounter = 0;
	lengthCheck = 0;
	otherCheck = 0;
	invalidfieldlength = 0;
	datatyepcheck = 0;
	columnnamecheck = 0;
	datatypeempty = 0;
	datecheck = 0;
	timestampcheck = 0;
	for ( var i = 1; i <= row; i++) {
		var rowIndex = row - 1;

		var temp = value;
		if (temp != null && temp != "") {
			temp = temp.toLowerCase();
		}
		var mainData = $("#editTable").handsontable('getDataAtCell', rowIndex,
				col);

		var fieldlengthval = $("#editTable").handsontable('getDataAtCell',
				rowIndex, col + 3);
		var dataType = $("#editTable").handsontable('getDataAtCell', rowIndex,
				col + 1);
		var columnname = $("#editTable").handsontable('getDataAtCell',
				rowIndex, col);
		var dateformatValue = $("#editTable").handsontable('getDataAtCell',
				rowIndex, col + 2);
		var timestampformat = $("#editTable").handsontable('getDataAtCell',
				rowIndex, col + 2);
		if (mainData != null && mainData != "") {
			mainData = mainData.toLowerCase();
		}

		if ($("#editTable").handsontable('getDataAtCell', rowIndex, col) != null
				&& $("#editTable").handsontable('getDataAtCell', rowIndex, col) != ""
				&& mainData == temp) {

			// if($("#editTable").handsontable('getDataAtCell',rowIndex,col-1)!=null
			// &&
			// $("#editTable").handsontable('getDataAtCell',rowIndex,col-1)!=""){
			// $(td).append("");
			// if($("#editTable").handsontable('getDataAtCell',row,col-1)===$("#editTable").handsontable('getDataAtCell',rowIndex,col-1))
			// {
			var dupTd = $("#editTable").handsontable('getCell', rowIndex, col);

			$(dupTd).css({
				background : 'red'
			});
			duplicateCounter++;

			// }
			// console.log($("#editTable").handsontable('getDataAtCell',row,col-1));
			// console.log($("#editTable").handsontable('getDataAtCell',rowIndex,col-1));
			// }

		}

		// check if column length is greater than 30
		if (mainData != null && mainData != "" && mainData.length > 30) {
			var dupTd = $("#editTable").handsontable('getCell', rowIndex, col);

			$(dupTd).css({
				background : 'red'
			});
			lengthCheck++;
		}

		if (mainData != null
				&& mainData != ""
				&& (!mainData.match(reg) || mainData.match(reg2)
						|| mainData.match(reg3) || mainData.match(reg4))) {

			var dupTd = $("#editTable").handsontable('getCell', rowIndex, col);

			$(dupTd).css({
				background : 'red'
			});
			otherCheck++;
		}
		if (mainData != null && mainData != "") {
			if (dataType == null || dataType == "") {
				var invalDT = $("#editTable").handsontable('getCell', rowIndex,
						col + 1);

				$(invalDT).css({
					background : 'red'
				});
				datatypeempty++;

			}
		}

		if (dataType != null && dataType != "") {
			if (dataType.toLowerCase() == "date") {
				if (dateformatValue == null || dateformatValue == "") {
					var invalDT = $("#editTable").handsontable('getCell',
							rowIndex, col + 2);

					$(invalDT).css({
						background : 'red'
					});
					datecheck++;
				}
			}

		}
		if (dataType != null && dataType != "") {
			if (dataType.toLowerCase() == "timestamp") {
				if (timestampformat == null || timestampformat == "") {
					var invalDT = $("#editTable").handsontable('getCell',
							rowIndex, col + 2);

					$(invalDT).css({
						background : 'red'
					});
					timestampcheck++;
				}
			}

		}

		if (dataType != null && dataType != "") {
			for ( var j = 0; j < oracleDataType.length; j++) {
				if (dataType.toLowerCase() == oracleDataType[j]) {
					result = 1;
					break;
				}

			}
			if (result != 1) {

				var invalDT = $("#editTable").handsontable('getCell', rowIndex,
						col + 1);

				$(invalDT).css({
					background : 'red'
				});
				datatyepcheck++;
			}

			result = 0;
		}
		if (columnname != null && columnname != "") {
			for ( var j = 0; j < reservedwords.length; j++) {

				if (columnname.toUpperCase() == reservedwords[j]) {
					result = 1;
					break;
				}

			}
			if (result == 1) {

				var invalCN = $("#editTable").handsontable('getCell', rowIndex,
						col);

				$(invalCN).css({
					background : 'red'
				});
				columnnamecheck++;
			}

			result = 0;
		}

		if (fieldlengthval != null
				&& fieldlengthval != ""
				&& (!fieldlengthval.match(reg5) || fieldlengthval.match(reg2) || fieldlengthval
						.match(reg4))) {
			var invalFL = $("#editTable").handsontable('getCell', rowIndex,
					col + 3);

			$(invalFL).css({
				background : 'red'
			});

			invalidfieldlength++;
		}

	}
	if (duplicateCounter > 0) {
		$(td).css({
			background : 'red'
		});
		dupCheck[row] = true;
	} else {
		$(td).css({
			background : '#FFFFFF'
		});
		dupCheck[row] = false;
	}

};

function inserttohansontable(datavalue, noofrows) {

	var f1 = [];
	f1 = datavalue;

	if (datavalue != null) {

		var $container = $("#editTable");
		$container.handsontable({
			data : f1,
			minRows : noofrows,
			minCols : 7,
			minSpareRows : 1,
			autoWrapRow : true,
			manualColumnResize : true,
			fillHandle : true,

			colHeaders : [ "Column Name", "Data Type", "Date Type Detail",
					"Field Length", "Business Name", "Start Pos", "End Pos" ],
			columns : [

			{}, {}, {}, {}, {}, {}, {} ],
			cells : function(row, col, prop) {

				var cellProperties = {};

				if (col == 0) {
					cellProperties.type = {
						renderer : fieldValueRenderer
					};
				}
				return cellProperties;
			},

			rowHeaders : true,
			contextMenu : [ 'row_above', 'row_below', 'remove_row', 'hsep1',
					'undo', 'redo' ],

			onChange : function(change, source) {

				$container.handsontable('render');
			},

		});
	}

}

function validateForm() {

	var csv_value = jQuery('.htCore').table2CSV({
		delivery : 'value'
	});

	var le = csv_value.length;

	jQuery(".layoutEmpty").val(true);
	jQuery(".colMaxChk").val(true);
	jQuery(".invChk").val(true);
	jQuery(".dupChk").val(true);
	jQuery(".invFieldlenval").val(true);
	jQuery(".invDT").val(true);
	jQuery(".invCN").val(true);
	jQuery(".invDateDesc").val(true);
	if (le === 100) {
		jQuery(".layoutEmpty").val(false);
	} else {
		var chkss = true;
		for ( var s = 0; s < dupCheck.length; s++) {
			if (dupCheck[s] === true) {
				chkss = true;
				break;
			} else {
				chkss = false;
			}
		}
		if (lengthCheck > 0) {
			jQuery(".colMaxChk").val(false);
		} else if (chkss == true) {
			jQuery(".dupChk").val(false);
		} else if (otherCheck > 0) {
			jQuery(".invChk").val(false);
		} else if (datatyepcheck > 0) {
			jQuery(".invDT").val(false);
		} else if (columnnamecheck > 0) {
			jQuery(".invCN").val(false);
		} else if (datatypeempty > 0) {
			jQuery(".invDT").val(false);
		} else if (datecheck > 0) {
			jQuery(".invDateDesc").val(false);
		} else if (timestampcheck > 0) {
			jQuery(".invDateDesc").val(false);
		} else if (invalidfieldlength > 0) {
			jQuery(".invFieldlenval").val(false);
		} else {
			jQuery(".csv_text").val(csv_value);
		}

	}
}