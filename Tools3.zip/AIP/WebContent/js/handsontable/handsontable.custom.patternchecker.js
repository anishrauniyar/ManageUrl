$(function(){
	


	dataTable = $("#editTable");

	dataTable.handsontable({
		minRows: 3,
		minCols: 1,
		minSpareRows: 1,
		autoWrapRow: true,
		manualColumnResize: true,
		fillHandle: true,
	
		
		colHeaders:["List of Strings"],
		columns :[
		          
		         {},
		          ],    
		        
		          rowHeaders: true,
		          contextMenu: ['row_above', 'row_below', 'remove_row','hsep1','undo','redo'],
		          onChange:function (change, source) {
		        	  
		        	  dataTable.handsontable('render');
		          }

	});

});	

function renderer(row)
{
	
	var pmatched = $("#editTable").handsontable('getCell',row-1, 0);
	
	$(pmatched).css({
		background: 'green'
	});
	
}
function redrenderer(row)
{
var pmatched = $("#editTable").handsontable('getCell',row-1, 0);
	
	$(pmatched).css({
		background: 'red'
	});
	
	}

function validateForm() {
	var csv_value = jQuery('.htCore').table2CSV({
		delivery : 'value'
	});

jQuery(".csv_text").val(csv_value);
	
}