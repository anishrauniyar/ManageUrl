jQuery.fn.table2CSV = function(options) {

	var options = jQuery.extend({
		separator: ';',
		header: [],
		delivery: 'popup' // popup, value
	},
	options);

	var csvData = [];
	var headerArr = [];
	var el = this;

	//header
	var numCols = options.header.length;
	var tmpRow = []; // construct header avalible array

	if (numCols > 0) {
		for (var i = 0; i < numCols; i++) {
			tmpRow[tmpRow.length] = formatData(options.header[i]);
		}
	} else {
		$(el).filter(':visible').find('th').each(function() {
			if ($(this).css('display') != 'none') tmpRow[tmpRow.length] = formatData($.trim($(this).html()));
		});
	}

	row2CSV(tmpRow);
	var r =0;
	// actual data
	$(el).find('tr').each(function() {
		var tmpRow = [];
		var c= 0;
		if($(this).find('td:first').html()!= null && $(this).find('td:first').html()!=''){
			
			$(this).filter(':visible').find('td').each(function() {

				if(c==3 && ($.trim($(this).html())==null || $.trim($(this).html())=='')){
					tmpRow[tmpRow.length] = formatData('200');	
				}
				else{
					tmpRow[tmpRow.length] = formatData($.trim($(this).html()));
				}
				c++;
			});
			row2CSV(tmpRow);
			r++;
		}
		//console.log(r+"--s"+$(this).find('td:first').html());
		
	});
	
	if (options.delivery == 'popup') {
		var mydata = csvData.join('\n');
		return popup(mydata);
	} else {
		var mydata = csvData.join('~');
		return mydata;
	}

	function row2CSV(tmpRow) {
		var tmp = tmpRow.join(''); // to remove any blank rows
		// alert(tmp);
		if (tmpRow.length > 0 && tmp != '') {
			var mystr = tmpRow.join(options.separator);
			csvData[csvData.length] = $.trim(mystr);
		}
	}
	function formatData(input) {
		// replace " with “
		var regexp = new RegExp(/["]/g);
		var output = input.replace(regexp, "“");
		//HTML
		var regexp = new RegExp(/\<[^\<]+\>/g);
		var output = output.replace(regexp, "");
		if (output == "") return '';
		return '"' + $.trim(output) + '"';
		// return $.trim(output);
	}
	function popup(data) {
		var generator = window.open('', 'csv', 'height=400,width=600');
		generator.document.write('<html><head><title>CSV</title>');
		generator.document.write('</head><body >');
		generator.document.write('<textArea cols=70 rows=15 wrap="off" >');
		generator.document.write(data);
		generator.document.write('</textArea>');
		generator.document.write('</body></html>');
		generator.document.close();
		return true;
	}
};