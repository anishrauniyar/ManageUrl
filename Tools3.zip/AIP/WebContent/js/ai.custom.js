/**
 *@author Sagar Shrestha
 *@since Apr 4, 2014
 */

/*function loadPage(url){
	$("#container").html("");
	$("#container").load(url);
	var lucHeight = $(".layoutUnitCenter").height();
	$("#container").css("height", lucHeight + 'px');
}
 */

function start() {
	PF('statusDialogNonAjax').show();
}
function stop() {
	PF('statusDialogNonAjax').hide(); 
}

function selectMenuitemLink(link) {
	$("#navigationMenu").find(".ui-state-active").
	removeClass("ui-state-active");
	$(link).addClass("ui-state-active");
}


function changeColor(col,isgeneric) {
	col = jQuery("."+ col);

	if(isgeneric){
		col.removeClass('data-default');
		col.removeClass('data-specific');
		col.addClass('data-generic');
	}
	else{
		col.removeClass('data-default');
		col.removeClass('data-generic');
		col.addClass('data-specific');
	}

}

function closeDialogIfSucess(xhr, status, args, dialogWidget, dialogId) {
	if (args.validationFailed || args.KEEP_DIALOG_OPENED) {
		jQuery('#'+dialogId).effect("bounce", {times : 4, distance : 20}, 100);
	} else {
		PF(dialogWidget).hide();
	}
}

