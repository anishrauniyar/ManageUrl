/*
 *Class Name : LayoutTypeController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.vit.ai.admin.model.LayoutType;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * @author Binesh Sah
 * 
 * @version 1.0 27 July 2014
 */
@ManagedBean
@ViewScoped
public class LayoutTypeController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<LayoutType> listOfLayoutType;
	private String layoutTypeID;
	private String layoutType;
	private String fieldTerminator;
	private LayoutType selectedLayoutType;

	public String getLayoutTypeID() {
		return layoutTypeID;
	}

	public void setLayoutTypeID(String layoutTypeID) {
		this.layoutTypeID = layoutTypeID;
	}

	public String getFieldTerminator() {
		return fieldTerminator;
	}

	public void setFieldTerminator(String fieldTerminator) {
		this.fieldTerminator = fieldTerminator;
	}

	public LayoutTypeController() {

	}

	@PostConstruct
	public void init() {

		loadLayoutTypes();
	}

	public ArrayList<LayoutType> getListOfLayoutType() {
		return listOfLayoutType;
	}

	public void setListOfLayoutType(ArrayList<LayoutType> listOfLayoutType) {
		this.listOfLayoutType = listOfLayoutType;
	}

	public void createLayoutType() {
		try {
			String query = "INSERT INTO TBL_FILEPATTERNS_LAYOUT (LAYOUTTYPEID, LAYOUTTYPE, FIELDTERMINATOR) VALUES('"
					+ this.getLayoutTypeID().toUpperCase()
					+ "','"
					+ this.getLayoutType()
					+ "','"
					+ this.getFieldTerminator()
					+ "')";
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result=db.executeDML(query);
			db.endConnection();
			if(result.compareTo("1")==0){
				closeDialog();
				displayInfoMessageToUser("Added With Sucess", "Status");
				loadLayoutTypes();
				resetLayoutType();
			}else{
				keepDialogOpen();
				displayErrorMessageToUser(
						"Ops, we could not add. Try again later."
								, "Status");
			}
		
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not add. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void updateLayoutType(String layoutTypeid) {
		try {
			String query = "UPDATE TBL_FILEPATTERNS_LAYOUT SET LAYOUTTYPE='"
					+ this.selectedLayoutType.getLayoutType()
					+ "',FIELDTERMINATOR='"
					+ this.selectedLayoutType.getFieldTerminator()
					+ "' WHERE LAYOUTTYPEID='" + layoutTypeid + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			int result=db.update(query);
			if(result==1){
				closeDialog();
				displayInfoMessageToUser("Updated With Sucess", "Status");
				loadLayoutTypes();
				resetLayoutType();
			}else{
				keepDialogOpen();
				displayErrorMessageToUser(
						"Ops, we could not update. Try again later! Error:"
								, "Status");
			}
			db.endConnection();
			
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not update. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void deleteLayoutType(String layoutTypeid) {
		try {
			String query = "DELETE FROM TBL_FILEPATTERNS_LAYOUT WHERE LAYOUTTYPEID='"
					+ layoutTypeid + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess", "Status");
			loadLayoutTypes();
			resetLayoutType();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not create. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	private void loadLayoutTypes() {
		listOfLayoutType = new ArrayList<LayoutType>();
		String query = " SELECT LAYOUTTYPEID, LAYOUTTYPE, FIELDTERMINATOR FROM TBL_FILEPATTERNS_LAYOUT";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> listAll = db.resultSetToListOfList(query);
		db.endConnection();
		if (listAll.size() > 0) {
			for (int i = 1; i < listAll.size(); i++) {
				listOfLayoutType.add(new LayoutType(listAll.get(i).get(0),
						listAll.get(i).get(1), listAll.get(i).get(2)));
				setListOfLayoutType(listOfLayoutType);
			}

		}

	}

	public void resetLayoutType() {

		this.layoutType = "";
		this.layoutTypeID = "";
		this.fieldTerminator = "";
	}

	public LayoutType getSelectedLayoutType() {
		return selectedLayoutType;
	}

	public void setSelectedLayoutType(LayoutType selectedLayoutType) {
		this.selectedLayoutType = selectedLayoutType;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

}
