/*
 *Class Name : DataTypeController.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.admin.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import com.vit.ai.admin.model.DataType;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for datatype
 * 
 * @author Aashish Dhungana
 * @author Binesh Sah
 * 
 * @version 1.0 27 May 2014
 */
@ManagedBean
@ViewScoped
public class DataTypeController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = -3071787008575647912L;
	private ArrayList<DataType> listOfDataType;
	private String dataTypeID;
	private String dataType;
	private DataType selectedDataType;

	public DataType getSelectedDataType() {
		return selectedDataType;
	}

	public void setSelectedDataType(DataType selectedDataType) {
		this.selectedDataType = selectedDataType;
	}

	public String getDataTypeID() {
		return dataTypeID;
	}

	public void setDataTypeID(String dataTypeID) {
		this.dataTypeID = dataTypeID;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public ArrayList<DataType> getListOfDataType() {
		return listOfDataType;
	}

	public void setListOfDataType(ArrayList<DataType> listOfDataType) {
		this.listOfDataType = listOfDataType;
	}

	public DataTypeController() {

	}

	@PostConstruct
	public void init() {
		loadDataTypes();
	}

	public void createDataType() {
		try {
			String query = "INSERT INTO  TBL_FILEPATTERNS_DATATYPE (DATATYPEID, DATATYPE) VALUES ('"
					+ this.getDataTypeID().toUpperCase()
					+ "','"
					+ this.getDataType() + "')";
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result=db.executeDML(query);
			db.endConnection();
			if(result.compareTo("1")==0){
				closeDialog();
				displayInfoMessageToUser("Added With Sucess", "Status");
				loadDataTypes();
				resetDataType();
			}else{
				keepDialogOpen();
				displayErrorMessageToUser(
						"Ops, we could not add. Try again later.", "Status");
				
			}
			
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not add. Try again later! Error:"
							+ e.getMessage(), "Status");
		}
	}

	public void updateDataType(String dataTypeid) {
		try {
			String query = "UPDATE TBL_FILEPATTERNS_DATATYPE SET DATATYPE='"
					+ this.selectedDataType.getDataType()
					+ "' WHERE DATATYPEID='" + dataTypeid + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			int result=db.update(query);
			System.out.println("Result "+result);
			if(result==1){
				db.endConnection();
				closeDialog();
				displayInfoMessageToUser("Updated With Sucess", "Status");
				loadDataTypes();
				resetDataType();
			}else{
				
				keepDialogOpen();
				displayInfoMessageToUser("Failed to update.Please try again", "Error");
			}
			
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not update. Try again later! Error:"
							+ e.getMessage(), "Status");
		}
	}

	public void deleteDataType(String dataTypeid) {
		try {
			String query = "DELETE FROM TBL_FILEPATTERNS_DATATYPE  WHERE DATATYPEID='"
					+ dataTypeid + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess", "Status");
			loadDataTypes();
			resetDataType();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not delete. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	private void loadDataTypes() {
		listOfDataType = new ArrayList<DataType>();
		String query = "SELECT  DATATYPEID, DATATYPE  FROM TBL_FILEPATTERNS_DATATYPE";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> listAll = db.resultSetToListOfList(query);
		db.endConnection();
		if (listAll.size() > 0) {
			for (int i = 1; i < listAll.size(); i++) {
				listOfDataType.add(new DataType(listAll.get(i).get(0), listAll
						.get(i).get(1)));
				setListOfDataType(listOfDataType);
			}
		}

	}

	public void resetDataType() {
		this.dataTypeID = "";
		this.dataType = "";

	}

}
