package com.vit.ai.admin.controller;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

import com.vit.dbconnection.ConnectDB;


/**
 * Controller Class for changing password
 * 
 * @author Anish Rauniyar
 * 
 * 
 */
@ManagedBean
@ViewScoped
public class EmailBean {
	private static final long serialVersionUID = 1L;
	
	private final Logger log = Logger.getLogger(EmailBean.class); 
	
	private String newEmail;
	private String newEmail2;


	public String getNewEmail() {
		return newEmail;
	}

	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}

	public String getNewEmail2() {
		return newEmail2;
	}

	public void setNewEmail2(String newEmail2) {
		this.newEmail2 = newEmail2;
	}

	public void save() throws NoSuchAlgorithmException {
		
		Pattern emailPattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
		Matcher matcher = emailPattern.matcher(newEmail);
		log.info("The matcher is" + matcher.find());
		FacesMessage msg = null;
		
		String newEmail = this.getNewEmail();
		String confirmEmail = this.getNewEmail2();
		
		if (!newEmail.equals(confirmEmail)) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Email Mismatch", "");
		} else if (matcher.find()){

			String query = "UPDATE AIPD_USERS SET EMAIL='" + newEmail
					+ "' WHERE USERID='" + getUserID() + "'  ";
			ConnectDB db = new ConnectDB();
			db.initialize();
	
			int result = db.update(query);
	
			db.endConnection();
	
			
			if (result == 1) {
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
						"Email Changed", "");
			} else if (result == -1) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating Email", "");
			} else {
				/*msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating Email", "Old password is incorrect.");*/
			}
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Not an Email Format", "");
		}
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	private String userID;
	
	
/*
	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}
*/
	public String getUserID() {

		return userID;
	}

	public void setUserID(String userID) {

		this.userID = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
		System.out.println(this.userID);
	}

	public EmailBean() {
		setUserID("");
	}
}
