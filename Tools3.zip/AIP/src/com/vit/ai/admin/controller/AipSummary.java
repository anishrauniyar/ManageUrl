package com.vit.ai.admin.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.primefaces.model.chart.PieChartModel;

import com.vit.ai.admin.model.AipSummaryModel;
import com.vit.ai.admin.monitor.dao.AipSummaryDAO;

@ManagedBean
public class AipSummary {
	
	
	protected ArrayList<AipSummaryModel> listofFmonInstance;
	protected ArrayList<String> clientId;
	
	
	public ArrayList<String> getClientId() {
		return clientId;
	}

	public void setClientId(ArrayList<String> clientId) {
		this.clientId = clientId;
	}

	public ArrayList<AipSummaryModel> getListofFmonInstance() {
		return listofFmonInstance;
	}

	public void setListofFmonInstance(ArrayList<AipSummaryModel> listofFmonInstance) {
		this.listofFmonInstance = listofFmonInstance;
	}

	public AipSummary() {
		init();
	}

	public void init() {
		AipSummaryDAO fmonInstance = new AipSummaryDAO();
		this.listofFmonInstance = fmonInstance.getFmonInstance();
		ArrayList<String> client = new ArrayList<>();
		client.add("111");
		client.add("142");
		setClientId(client);
		
	}
	
}
