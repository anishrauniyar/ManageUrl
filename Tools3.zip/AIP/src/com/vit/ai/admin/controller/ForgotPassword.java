/**
 * ClassName PasswordGenerator
 * 
 * Copyright: Verisk Information Technologies
 */

package com.vit.ai.admin.controller;

import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.ai.utils.EmailConfiguration;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 *
 * @version 22 May 2015
 */
@ManagedBean
@ViewScoped
public class ForgotPassword extends AbstractController implements Serializable {

	private static final long serialVersionUID = 5391760542188926834L;
	private String userid;
	private String resetCode;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getResetCode() {
		return resetCode;
	}

	public void setResetCode(String resetCode) {
		this.resetCode = resetCode;
	}

	public void sendResetCode() {
		if (this.userid.isEmpty()) {
			displayErrorMessageToUser("Invalid UserID", "ERROR");
			return;
		}
		String query = "select userid,email from aipd_users where userid='"
				+ this.userid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);

		if (rs != null) {
			if (rs.size() > 1) {
				PasswordGenerator genResetCode = new PasswordGenerator();
				String resetcode = genResetCode.newResetCode();
				String queryupdate = "update aipd_users set resetcode='"
						+ resetcode + "' where userid='" + this.userid + "'";
				int status = db.update(queryupdate);
				db.endConnection();
				if (status > 0) {
					EmailConfiguration sendresetcode = new EmailConfiguration();
					//sendresetcode.setTo(this.userid + "@veriskhealth.com");
					String email = rs.get(1).get(1);
					sendresetcode.setTo(email);
					sendresetcode.setSubject("AIP RESET CODE");
					String content = "Your Reset Code is : " + resetcode;
					sendresetcode.setContent(content);
					int status1 = sendresetcode.sendMail();
					if (status1 == 1) {
						displayInfoMessageToUser(
								"A Reset code has been sent to your e-mail.Please enter the reset code to reset your password",
								"ResetCode Sent");

					} else {
						displayErrorMessageToUser("Failed.Please Try again",
								"Error");
					}
				} else {
					displayErrorMessageToUser("Failed.Please Try again",
							"Error");
				}
			} else {
				displayErrorMessageToUser("Userid doesn't exist",
						"Invalid Username");
				return;
			}
		} else {
			displayErrorMessageToUser("ERROR", "ERROR");
			return;
		}

	}

	public void resetPassword() {
		if (this.userid.isEmpty()) {
			displayErrorMessageToUser("Invalid UserID", "ERROR");
			return;
		}
		if(this.resetCode.isEmpty())
		{
			displayErrorMessageToUser("Reset Code cannot be empty", "ERROR");
			return;
		}
		String query = "select resetcode,email from aipd_users where userid='"
				+ this.userid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				if (rs.get(1).get(0).compareTo(this.resetCode) == 0) {
					PasswordGenerator genPassword = new PasswordGenerator();
					String pwd = genPassword.newPassword();
					CustomUtility cuObj = new CustomUtility();
					ConnectDB dbupd = new ConnectDB();
					dbupd.initialize();
					int check = dbupd
							.update("update aipd_users set password='"
									+ cuObj.getHashValue(pwd) + "' where userid='"+this.userid+"'");
					dbupd.update("update aipd_users set resetcode='' where userid='"+this.userid+"'");
					dbupd.endConnection();
					if (check > 0) {
						EmailConfiguration sendpassword = new EmailConfiguration();
						String email = rs.get(1).get(1);
						System.out.println(email);
						sendpassword.setTo(email);
						sendpassword.setSubject("AIP PASSWORD RESET");
						sendpassword
								.setContent("Your New Password is : "
										+ pwd
										+ "\n . Please change your password on first login");
						int stat = sendpassword.sendMail();
						if (stat == 1) {
							displayInfoMessageToUser(
									"Your New Password has been sent to your mail.",
									"Password Reset");

						} else {
							displayErrorMessageToUser("Failed",
									"Password Reset");
						}

					} else {
						displayErrorMessageToUser("ERROR", "ERROR");

					}

				} else {
					displayErrorMessageToUser("Reset Code Mismatch", "ERROR");
				}
			} else {
				displayErrorMessageToUser("Userid not found", "ERROR");
			}
		} else {
			displayErrorMessageToUser("ERROR", "ERROR");
		}
	}
}
