/*
 *Class Name : AischemaCleanUP.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.admin.controller;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.vit.ai.admin.model.AIcleanUP;
import com.vit.ai.flms.model.MClients;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for AI Schema clean up
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 29 Mar 2016
 */
@ManagedBean
@ViewScoped
public class AischemaCleanUP extends AbstractController implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<AIcleanUP> listOfAIcleanupPolicy;
	private String clientID="";
	private String frequency;
	private String retentPeriod="";
	private AIcleanUP selectedCleaupPolicy;
	@ManagedProperty(value = "#{userInformation}")
	protected UserInformation userinfo;
	SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private LinkedHashMap<String, String> clients;
	protected FilterLogController filterData;
	
	
	


	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public AischemaCleanUP() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
		clients = new LinkedHashMap<String, String>();
		MClients objMC = new MClients(false);
		setClients(objMC.getClients());
	}

	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}
	
	public void createCleanPolicy() {
		try {
			
			String query = "INSERT INTO  DEL_AICLEANUPPOLICY (SN, CLIENTID, FREQUENCY, RETENTIONPERIOD, CREATEDBY,CREATEDDATE) VALUES (aip_cleanpolicy_seq.NEXTVAL,'"
					+ this.getClientID()
					+ "','"
					+ this.getFrequency() + "','"+this.getRetentPeriod()+"','"+this.userinfo.getFullname()+"',sysdate)";
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result=db.executeDML(query);
			db.endConnection();
			if(result.compareTo("1")==0){
				closeDialog();
				displayInfoMessageToUser("Added With Sucess", "Status");
				loadCleanupPolicy();
				resetCleanPolicy();
			}else{
				keepDialogOpen();
				displayErrorMessageToUser(
						"Ops, we could not add. Try again later.", "Status");
				
			}
			
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not add. Try again later! Error:"
							+ e.getMessage(), "Status");
		}
	}

	public void updateCleanPolicy(String sn) {
		try {
			String query = "UPDATE DEL_AICLEANUPPOLICY SET FREQUENCY='"
					+ this.selectedCleaupPolicy.getFrequency()
					+ "',RETENTIONPERIOD='"+selectedCleaupPolicy.getRetentionPeriod()+"',updatedby='"+userinfo.getFullname()+"',updatedate=sysdate WHERE sn=" +sn + "";
			ConnectDB db = new ConnectDB();
			db.initialize();
			int result=db.update(query);
			db.endConnection();
			if(result==1){
				
				closeDialog();
				displayInfoMessageToUser("Updated With Sucess", "Status");
				loadCleanupPolicy();
				resetCleanPolicy();
			}else{
				
				keepDialogOpen();
				displayInfoMessageToUser("Failed to update.Please try again", "Error");
			}
			
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not update. Try again later! Error:"
							+ e.getMessage(), "Status");
		}
	}

	public void deleteCleanPolicy(String sn) {
		try {
			String query = "DELETE FROM DEL_AICLEANUPPOLICY  WHERE sn="
					+ sn + "";
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess", "Status");
			loadCleanupPolicy();
			resetCleanPolicy();
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not delete. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void loadCleanupPolicy() {
		System.out.println("Clientid "+this.filterData.getClientID());
		listOfAIcleanupPolicy = new ArrayList<AIcleanUP>();
		String query = "SELECT SN, CLIENTID, FREQUENCY, RETENTIONPERIOD, CREATEDBY, EXECUTEDBY,EXECUTEDDATE,createdDate  FROM DEL_AICLEANUPPOLICY where clientid='"+this.filterData.getClientID()+"'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> listAll = db.resultSetToListOfList(query);
		db.endConnection();
		if (listAll.size() > 0) {
			for (int i = 1; i < listAll.size(); i++) {
				listOfAIcleanupPolicy.add(new AIcleanUP(listAll.get(i).get(0), listAll
						.get(i).get(1),listAll.get(i).get(2),listAll.get(i).get(3),listAll.get(i).get(4),listAll.get(i).get(5),listAll.get(i).get(6),listAll.get(i).get(7)));
				setListOfAIcleanupPolicy(listOfAIcleanupPolicy);
			}
		}

	}
	public void executeCleanScript(String sn){
		System.out.println("Execute Script");
		try {
			String query = "UPDATE DEL_AICLEANUPPOLICY SET EXECUTEDBY='"+userinfo.getFullname()+"',EXECUTEDDATE=sysdate WHERE sn=" +sn+ "";
			ConnectDB db = new ConnectDB();
			db.initialize();
			int result=db.update(query);
			db.endConnection();
			if(result==1){
				
				closeDialog();
				displayInfoMessageToUser("Cleaned With Sucess", "Status");
				loadCleanupPolicy();
				resetCleanPolicy();
			}else{
				
				keepDialogOpen();
				displayInfoMessageToUser("Failed to Clean.Please try again", "Error");
			}
			
		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not Clean. Try again later! Error:"
							+ e.getMessage(), "Status");
		}
	}

	public void resetCleanPolicy() {
		
		this.frequency = "";
		this.setRetentPeriod("");
		

	}

	public ArrayList<AIcleanUP> getListOfAIcleanupPolicy() {
		return listOfAIcleanupPolicy;
	}

	public void setListOfAIcleanupPolicy(ArrayList<AIcleanUP> listOfAIcleanupPolicy) {
		this.listOfAIcleanupPolicy = listOfAIcleanupPolicy;
	}



	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public AIcleanUP getSelectedCleaupPolicy() {
		return selectedCleaupPolicy;
	}

	public void setSelectedCleaupPolicy(AIcleanUP selectedCleaupPolicy) {
		this.selectedCleaupPolicy = selectedCleaupPolicy;
	}

	

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		this.clients = clients;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		filterData.setClientID(clientID);
		this.clientID = filterData.getClientID();
		
	}

	public String getRetentPeriod() {
		return retentPeriod;
	}

	public void setRetentPeriod(String retentPeriod) {
		this.retentPeriod = retentPeriod;
	}

	
}
