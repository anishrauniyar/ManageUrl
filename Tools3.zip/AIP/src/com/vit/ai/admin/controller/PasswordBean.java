/*
 *Class Name : PasswordBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.controller;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for changing password
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.4 28 Feb 2015
 */
@ManagedBean
@ViewScoped
public class PasswordBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String oldPassword;
	private String newPassword;
	private String newPassword2;

	public String getOldPassword() {
		return oldPassword;
	}

	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getNewPassword2() {
		return newPassword2;
	}

	public void setNewPassword2(String newPassword2) {
		this.newPassword2 = newPassword2;
	}

	public void save() throws NoSuchAlgorithmException {
		MessageDigest m = MessageDigest.getInstance("MD5");
		m.update(newPassword.getBytes(), 0, newPassword.length());

		String encStr = new BigInteger(1, m.digest()).toString(16);

		MessageDigest m2 = MessageDigest.getInstance("MD5");
		m2.update(oldPassword.getBytes(), 0, oldPassword.length());

		String encStr2 = new BigInteger(1, m2.digest()).toString(16);

		String query = "UPDATE AIPD_USERS SET PASSWORD='" + encStr
				+ "' WHERE USERID='" + getUserID() + "' AND PASSWORD='"
				+ encStr2 + "' ";
		ConnectDB db = new ConnectDB();
		db.initialize();

		int result = db.update(query);

		db.endConnection();

		FacesMessage msg = null;
		if (result == 1) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Password Changed", "");
		} else if (result == -1) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error Updating Password", "");
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error Updating Password", "Old password is incorrect.");
		}
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	private String userID;
	
	
/*
	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}
*/
	public String getUserID() {

		return userID;
	}

	public void setUserID(String userID) {

		this.userID = FacesContext.getCurrentInstance().getExternalContext().getRemoteUser();
		System.out.println(this.userID);
	}

	public PasswordBean() {
		setUserID("");
	}

}
