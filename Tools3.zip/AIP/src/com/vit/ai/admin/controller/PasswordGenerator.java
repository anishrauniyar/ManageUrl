/**
 * ClassName PasswordGenerator
 * 
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.controller;

import java.math.BigInteger;
import java.security.SecureRandom;

/**
 * Class for generating random passwords
 * Chooses 130 bits from a cryptographically secure random bit generator
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 21 May 2015
 * 
 */
public class PasswordGenerator {
	
	private SecureRandom password = new SecureRandom();
	
	public String newPassword(){
		return new BigInteger(130,password).toString(32).substring(0, 8);
	}
	
	public String newResetCode(){
		return new BigInteger(130,password).toString(32).substring(9,16);
	}
	
	
	

}
