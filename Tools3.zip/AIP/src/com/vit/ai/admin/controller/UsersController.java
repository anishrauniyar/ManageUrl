/*
 * Class Name: UsersController.java
 * 
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.admin.controller;

import java.io.Serializable;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import com.vit.ai.admin.model.Users;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.ai.utils.EmailConfiguration;
import com.vit.dbconnection.ConnectDB;

/**
 * Managed Bean for handling users
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 12 June 2014
 * 
 */
@ManagedBean
@ViewScoped
public class UsersController extends AbstractController implements Serializable {

	private static Logger log = Logger.getLogger(UsersController.class
			.getName());
	private static final long serialVersionUID = 1L;

	private Users selectedUser;
	private ArrayList<Users> userlogs;
	private ArrayList<Users> listOfUsers;
	private String fullName;
	private String email;
	private String userRole;
	private String password;
	private String userid;
	private ArrayList<String> listofRoles;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UsersController() {

	}

	public ArrayList<Users> getListOfUsers() {
		return listOfUsers;
	}

	public void setListOfUsers(ArrayList<Users> listOfUsers) {
		this.listOfUsers = listOfUsers;
	}

	@PostConstruct
	public void init() {
		loadUserss();
		this.listofRoles = new ArrayList<>();
		String query = "select role_name from aip_user_roles";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {
					this.listofRoles.add(rs.get(i).get(0));
				}
			}
		}

	}

	public void GeneratePassword() {
		PasswordGenerator genPassword = new PasswordGenerator();
		setPassword(genPassword.newPassword());
		
	}

	/**
	 * Method to create new users for the system
	 */
	public void createUsers() {
		try {
			GeneratePassword();
			CustomUtility cuObj = new CustomUtility();
			/*String query = "INSERT INTO AIPD_USERS(USERID, FULLNAME, EMAIL, USER_ROLE, PASSWORD) VALUES ("
					+ "'"
					+ this.getUserid().toLowerCase()
					+ "','"
					+ this.getFullName()
					+ "','"
					+ this.getUserid().toLowerCase()
					+ "@veriskhealth.com',"
					+ "(select distinct(ROLE_ID) from aip_user_roles where role_name = '"
					+ this.getUserRole()
					+ "')"
					+ ",'"
					+ cuObj.getHashValue(this.password) + "')";*/
			String query = "INSERT INTO AIPD_USERS(USERID, FULLNAME, EMAIL, USER_ROLE, PASSWORD) VALUES ("
					+ "'"
					+ this.getUserid().replace("'", "''")
					+ "','"
					+ this.getFullName().replace("'", "''")
					+ "','"
					+ this.getEmail().replace("'", "''")
					+ "',"
					+ "(select distinct(ROLE_ID) from aip_user_roles where role_name = '"
					+ this.getUserRole()
					+ "')"
					+ ",'"
					+ cuObj.getHashValue(this.password) + "')";

			ConnectDB db = new ConnectDB();
			db.initialize();
			String check = db.executeDML(query);
			if (check.compareTo("1") == 0) {
				db.endConnection();
				closeDialog(); // Closes the primefaces dialog
				displayInfoMessageToUser("Added With Sucess", "Status");
				loadUserss();
				sendMail();
			} else {
				keepDialogOpen();// Keeps the dialog opened incase of some error
				displayErrorMessageToUser(
						"Ops, we could not add. Try again later! Error:",
						"Status");
			}

		} catch (Exception e) {
			log.error("Creating User: " + e.getMessage());
			keepDialogOpen();// Keeps the dialog opened incase of some error
			displayErrorMessageToUser(
					"Ops, we could not add. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void sendMail() throws InterruptedException {
		EmailConfiguration sendemail = new EmailConfiguration();
		//sendemail.setTo(this.getUserid() + "@veriskhealth.com");
		sendemail.setTo(this.getEmail());
		sendemail.setSubject("New AIP Account");
		String firstMailContent = "Hello "
				+ this.fullName
				+ ",\n"
				+ "Your New AIP Account has been created.Below is your Account Information."
				+ "\n"
				+ "UserID : "
				+ this.userid
				+ ".\n"
				+ "User Privilege : "
				+ this.userRole
				+ ".\n\n"
				+ "Your Password will be available in upcoming  mail.";
				
		sendemail.setContent(firstMailContent);
		int status = sendemail.sendMail();
		if (status == 1) {
			displayInfoMessageToUser("Username Mail sent", "Userid sent");
			Thread.sleep(3000);

			EmailConfiguration sendpassword = new EmailConfiguration();
			//sendpassword.setTo(this.userid + "@veriskhealth.com");
			sendpassword.setTo(this.getEmail());
			sendpassword
					.setContent("Your AIP Password is : "
							+ this.password
							+ "\n"
							+ "Please change password on first login");
							
			sendpassword.setSubject("AIP Account Details");
			int status1 = sendpassword.sendMail();
			if (status1 == 1) {
				displayInfoMessageToUser("Password Mail Sent", "Password Sent");
			} else {
				log.error("Password Mail not Sent");
				displayErrorMessageToUser("Password Mail Not Sent",
						"Mail Error");
			}

		} else {

			log.error("UserId Mail not Sent");
			displayErrorMessageToUser("Userid Mail Not Sent", "Mail Error");
		}
		resetUsers();

	}

	public void updateUsers(String userid) {
		try {

			String query = "UPDATE AIPD_USERS SET FULLNAME='"
					+ this.selectedUser.getFullName().replace("'", "''") + "', EMAIL='"+this.selectedUser.getEmail().replace("'", "''")+"', USER_ROLE="
					+ "(select distinct(ROLE_ID) from aip_user_roles where role_name = '" + this.selectedUser.getUser_role()+"')  WHERE USERID='"
					+ userid.replace("'", "''") + "'";
			log.info("Add User Query : " + query);

			ConnectDB db = new ConnectDB();
			db.initialize();
			 db.update(query);
			db.endConnection();
			closeDialog();
			displayInfoMessageToUser("Updated With Sucess", "Status");
			loadUserss();
			resetUsers();
		} catch (Exception e) {
			log.error("Updating User:" + e.getMessage());
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not update. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void deleteUsers(String userid) {
		try {
			String query = "DELETE FROM AIPD_USERS WHERE USERID='" + userid.replace("'", "''")
					+ "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
			closeDialog();
			displayInfoMessageToUser("Deleted With Sucess", "Status");
			loadUserss();
			resetUsers();
		} catch (Exception e) {
			log.error("Deleting User:" + e.getMessage());
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not delete. Try again later! Error:"
							+ e.getMessage(), "Status");
			// e.printStackTrace();
		}
	}

	/**
	 * Method that sets all the users in the system for display
	 */
	private void loadUserss() {
		
		if (this.listOfUsers != null) {
			this.listOfUsers = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot()
					.findComponent("frm:usersID");
			dt1.setFilters(null);
			dt1.reset();
		}
		listOfUsers = new ArrayList<Users>();
		String query = "SELECT a.USERID, a.FULLNAME, a.EMAIL, b.role_name FROM AIPD_USERS a left join aip_user_roles b on a.user_role = b.role_id";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> listAllUsers = db.resultSetToListOfList(query);
		db.endConnection();
		if (listAllUsers.size() > 0) {
			for (int i = 1; i < listAllUsers.size(); i++) {
				listOfUsers.add(new Users(listAllUsers.get(i).get(0),
						listAllUsers.get(i).get(1), listAllUsers.get(i).get(2),
						listAllUsers.get(i).get(3)));

				setListOfUsers(listOfUsers);
			}
		}

	}

	public void resetUsers() {
		this.userid = "";
		this.fullName = "";
		this.userRole = "";
		this.email = "";

	}

	public Users getSelectedUser() {
		return selectedUser;
	}

	public void setSelectedUser(Users selectedUser) {
		this.selectedUser = selectedUser;
	}

	/**
	 * Filter Function for p:datatable to make case-insensitive filters
	 * 
	 * @param value
	 * @param filter
	 * @param locale
	 * @return true or false
	 */
	public boolean filterByName(Object value, Object filter, Locale locale) {

		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public ArrayList<Users> getUserlogs() {
		return userlogs;
	}

	public void setUserlogs(ArrayList<Users> userlogs) {
		this.userlogs = userlogs;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public ArrayList<String> getListofRoles() {
		return listofRoles;
	}

	public void setListofRoles(ArrayList<String> listofRoles) {
		this.listofRoles = listofRoles;
	}

}
