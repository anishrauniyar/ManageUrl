/**
 * ClassName: LoginManager.java
 * 
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.vit.ai.admin.model.User;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Login class for JAAS Implementation
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 11 May 2015
 */
@ManagedBean
@ViewScoped
public class LoginManager implements Serializable {

	private static final long serialVersionUID = 3565449422903078482L;
	private static final String HOME_PAGE = "/";
	private static final String PAGE_AFTER_LOGOUT = HOME_PAGE;
	private static final String SESSION_USER_VARIABLE_NAME = "user";
	private String userid;
	private String email;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;
	private static Logger log = Logger.getLogger(LoginManager.class.getName());

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	private String username;
	private String password;
	private String forwardUrl;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@PostConstruct
	public void init()  {
		
		
		this.forwardUrl = extractRequestedUrlBeforeLogin();
		
	}

	public String extractRequestedUrlBeforeLogin() {
		ExternalContext externalContext = externalContext();
		
		String requestedUrl = (String) externalContext.getRequestMap().get(
				RequestDispatcher.FORWARD_REQUEST_URI);
		if (requestedUrl == null) {
			return externalContext.getRequestContextPath() + HOME_PAGE;
		}
	


		String queryString = (String) externalContext.getRequestMap().get(
				RequestDispatcher.FORWARD_QUERY_STRING);
		
		
		return requestedUrl + (queryString == null ? "" : "?" + queryString);
	}

	private ExternalContext externalContext() {
		return facesContext().getExternalContext();
	}

	private FacesContext facesContext() {
		return FacesContext.getCurrentInstance();
	}

	public void login() throws IOException {

		ExternalContext externalContext = externalContext();
		HttpServletRequest request = (HttpServletRequest) externalContext
				.getRequest();
		try {
			CustomUtility objCu = new CustomUtility();
			request.login(userid.toLowerCase(), objCu.getHashValue(this.password));
			getUserParameters(userid.toLowerCase());
			externalContext.getSessionMap().put(SESSION_USER_VARIABLE_NAME,
					new User(userid.toLowerCase()));
			if (getSessionData() != null) {
				getSessionData().setFullname(username);
				getSessionData().setEmail(email);
			}

			externalContext.redirect(forwardUrl);
		} catch (ServletException e) {
			String loginErrorMessage = e.getLocalizedMessage();
			log.debug(loginErrorMessage);
			if(loginErrorMessage.contains("authenticated"))
			{
				externalContext.redirect(forwardUrl);	
			}
			else
			{
			facesContext()
					.addMessage(null, new FacesMessage("Invalid Username or Password"));
			}
		}
	}

	public void getUserParameters(String userid) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select fullname,email from aipd_users where userid='"
				+ userid + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		System.out.println(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				System.out.println("If its coming here");
				this.username = rs.get(1).get(0);
				this.email = rs.get(1).get(1);
			}
		} else {
			try {
				logout("Sorry Couldnot connect to database. Please try again later or contact AIP team");
			} catch (IOException e) {
				System.out.println(e.toString());
				String logoutErrorMessage = e.getLocalizedMessage();
				facesContext().addMessage(null,
						new FacesMessage(logoutErrorMessage));
			}
		}
	}

	public void logout() throws IOException {

		ExternalContext externalContext = externalContext();
		externalContext.invalidateSession();
		externalContext.redirect(externalContext.getRequestContextPath()
				+ PAGE_AFTER_LOGOUT);
	}

	public void logout(String message) throws IOException {

		ExternalContext externalContext = externalContext();
		externalContext.invalidateSession();
		externalContext.redirect(externalContext.getRequestContextPath()
				+ PAGE_AFTER_LOGOUT);
		facesContext().addMessage(null, new FacesMessage(message));
	}

	public User getUser() {
		FacesContext context = facesContext();
		ExternalContext externalContext = context.getExternalContext();
		return (User) externalContext.getSessionMap().get("user");
	}

	public boolean isUserLoggedIn() {
		return getUser() != null;
	}

	public boolean isUserInRole(String role) {
		FacesContext context = facesContext();
		ExternalContext externalContext = context.getExternalContext();
		return externalContext.isUserInRole(role);
	}
}
