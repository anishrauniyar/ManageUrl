/*
 *Class Name : LayoutType.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.model;

import java.io.Serializable;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 25 Dec 2015
 */
public class LayoutType implements Serializable {

	private static final long serialVersionUID = -3489619015966553629L;
	private String layoutTypeID;
	private String layoutType;
	private String fieldTerminator;

	public String getLayoutTypeID() {
		return layoutTypeID;
	}

	public void setLayoutTypeID(String layoutTypeID) {
		this.layoutTypeID = layoutTypeID;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getFieldTerminator() {
		return fieldTerminator;
	}

	public void setFieldTerminator(String fieldTerminator) {
		this.fieldTerminator = fieldTerminator;
	}

	public LayoutType(String layoutTypeID, String layoutType,
			String fieldTerminator) {
		super();
		this.layoutTypeID = layoutTypeID;
		this.layoutType = layoutType;
		this.fieldTerminator = fieldTerminator;
	}

	public LayoutType() {

	}

}
