package com.vit.ai.admin.model;

public class AipSummaryModel {

	
	protected String fmonId;
	protected String status;
	protected String server;
	protected String clients;
		 
	public AipSummaryModel(String fmonId, String status, String server,
			String clients) {
		super();
		this.fmonId = fmonId;
		this.status = status;
		this.server = server;
		this.clients = clients;
	}
	public String getFmonId() {
		return fmonId;
	}
	public void setFmonId(String fmonId) {
		this.fmonId = fmonId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getClients() {
		return clients;
	}
	public void setClients(String clients) {
		this.clients = clients;
	}
		
}
