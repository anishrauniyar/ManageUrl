/*
 *Class Name : DataType.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.model;

import java.io.Serializable;

/**
 * Model class for data type administration
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 17 Sep 2014
 */
public class DataType implements Serializable {

	private static final long serialVersionUID = -6157419274597777651L;
	private String dataTypeID;
	private String dataType;

	public DataType(String dataTypeID, String dataType) {
		super();
		this.dataTypeID = dataTypeID;
		this.dataType = dataType;
	}

	public DataType() {

	}

	public String getDataTypeID() {
		return dataTypeID;
	}

	public void setDataTypeID(String dataTypeID) {
		this.dataTypeID = dataTypeID;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

}
