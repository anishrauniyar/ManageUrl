/* 
 *Class Name : Users.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.model;

import java.io.Serializable;

/**
 * @author Binesh Sah
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.2 05 Jan 2015
 */
public class Users implements Serializable {

	private static final long serialVersionUID = 6901898377577934140L;
	private String userid = "";
	private String fullName = "";
	private String email = "";
	private String user_role = "";
	private String password = "";

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Users() {

	}

	public Users(String userID, String fullName, String email, String userrole) {
		super();
		this.userid = userID;
		this.fullName = fullName;
		this.email = email;
		this.user_role = userrole;
		
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

}
