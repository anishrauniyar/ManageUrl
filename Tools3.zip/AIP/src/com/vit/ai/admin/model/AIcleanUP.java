/*
 *Class Name : AIcleanUP.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.model;

import java.io.Serializable;

/**
 * Model class for Clean up administration
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 29 Mar 2016
 */
public class AIcleanUP implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String clientID;
	private String frequency;
	private String retentionPeriod;
	private String sn;
	private String createdBy;
	private String executedBy;
	private String executedDate;
	private String createdDate;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public String getExecutedDate() {
		return executedDate;
	}

	public void setExecutedDate(String executedDate) {
		this.executedDate = executedDate;
	}


	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	
	public AIcleanUP(String sn,String clientID, String frequency,String retentionperiod,String createdBy,String executedBy,
			String executedDate,String createddate) {
		super();
		this.sn=sn;
		this.clientID=clientID;
		this.frequency =frequency;
		this.retentionPeriod=retentionperiod;
		this.createdBy=createdBy;
		this.executedBy=executedBy;
		this.executedDate=executedDate;
		this.createdDate=createddate;
	}

	public AIcleanUP() {

	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getExecutedBy() {
		return executedBy;
	}

	public void setExecutedBy(String executedBy) {
		this.executedBy = executedBy;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getRetentionPeriod() {
		return retentionPeriod;
	}

	public void setRetentionPeriod(String retentionPeriod) {
		this.retentionPeriod = retentionPeriod;
	}


}
