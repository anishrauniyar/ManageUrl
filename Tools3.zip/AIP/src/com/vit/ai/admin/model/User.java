/**
 * ClassName: User.java
 * 
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.admin.model;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 08 May 2015
 */
public class User {

	private String username = "";

	public User(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return this.getUsername();
	}

}
