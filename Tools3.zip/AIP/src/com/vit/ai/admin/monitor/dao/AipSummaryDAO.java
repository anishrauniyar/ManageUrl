package com.vit.ai.admin.monitor.dao;

import java.util.ArrayList;
import java.util.List;

import com.vit.ai.admin.model.AipSummaryModel;
import com.vit.ai.inventory.model.MainLog;
import com.vit.dbconnection.ConnectDB;

public class AipSummaryDAO {

	public ArrayList<AipSummaryModel> getFmonInstance() {
		// TODO Auto-generated method stub
		String query = "SELECT INSTANCE_NAME,STATUS,MACHINE,CLIENTID FROM aip_main_instance";
		ArrayList<AipSummaryModel> fmonArrayList =  new ArrayList<>();
		ArrayList<AipSummaryModel> fmonModel = new ArrayList<AipSummaryModel>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> fmonResultSet = db.resultSetToListOfList(query);
		db.endConnection();

		if (fmonResultSet.size() > 0) {
			for (int i = 1; i < fmonResultSet.size(); i++) {
				AipSummaryModel model = new AipSummaryModel(fmonResultSet.get(i).get(0), fmonResultSet.get(i).get(1), fmonResultSet.get(i).get(2), fmonResultSet.get(i).get(3));
				fmonArrayList.add(model);
			}
		}
		return fmonArrayList;
	}	
	
}
