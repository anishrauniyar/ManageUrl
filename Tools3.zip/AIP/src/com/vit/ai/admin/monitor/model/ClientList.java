package com.vit.ai.admin.monitor.model;

import java.io.Serializable;
import java.util.Date;

public class ClientList implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1983391758568053381L;
	private String clientid;
	private String frequency;
	private Date startTime;
	

	public ClientList(String clientid, String frequency, Date startTime) {
		super();
		this.clientid = clientid;
		this.frequency = frequency;
		this.startTime = startTime;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

}
