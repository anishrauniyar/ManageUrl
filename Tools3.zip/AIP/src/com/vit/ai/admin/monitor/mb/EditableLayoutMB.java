package com.vit.ai.admin.monitor.mb;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.admin.monitor.dao.EditableLayoutDAO;
import com.vit.ai.admin.monitor.model.Client;
import com.vit.ai.admin.monitor.model.Layout;
import com.vit.ai.admin.monitor.model.User;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.payormanagement.controller.PayorManagementActions;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.EmailConfiguration;


@ManagedBean
@ViewScoped
public class EditableLayoutMB extends PayorManagementActions implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static String serverName = AIConstant.DASHBOARD_SERVER_NAME;
	private static String editableLayoutPath = AIConstant.EDITABLE_LAYOUT_PATH;
	
	private static Logger log = Logger.getLogger(EditableLayoutMB.class.getName());
	
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;
	
	private EditableLayoutDAO editableLayoutDAO;
	
	private List<Layout> layout; 
	private String selectedlayout;
	
	private List<Client> client;
	private String[] selectedClient;
	private String outputClients = "No Clients Found";
	
	private List<User> user;
	private List<String> selectedUser;
	
	private String message;
		
	private String inputCommand;
	private String commandOutput;
	
	@PostConstruct
	public void init() {
		if(layout == null) {
			layout = this.getEditableLayoutDAO().getLayout();
		}
		if(client == null) {
			client = this.getEditableLayoutDAO().getClients();
		}
		if(user == null) {
			user = this.getEditableLayoutDAO().getUsers();
		}
	}

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public String getInputCommand() {
		return inputCommand;
	}

	public void setInputCommand(String inputCommand) {
		this.inputCommand = inputCommand;
	}

	public String getCommandOutput() {
		return commandOutput;
	}

	public void setCommandOutput(String commandOutput) {
		this.commandOutput = commandOutput;
	}

	public EditableLayoutDAO getEditableLayoutDAO() {
		if(editableLayoutDAO == null) {
			editableLayoutDAO = new EditableLayoutDAO();
		}
		return editableLayoutDAO;
	}

	public void setEditableLayoutDAO(EditableLayoutDAO editableLayoutDAO) {
		this.editableLayoutDAO = editableLayoutDAO;
	}
	
	public List<Layout> getLayout() {
		return layout;
	}

	public void setLayout(List<Layout> layout) {
		this.layout = layout;
	}

	public List<Client> getClient() {
		return client;
	}

	public void setClient(List<Client> client) {
		this.client = client;
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}	
	
	public String getSelectedlayout() {
		if(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid")!=null)
		{
			this.selectedlayout=FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid");
		}
		else
		{
			this.selectedlayout="";
		}
		return this.selectedlayout;

	}

	public void setSelectedlayout(String selectedlayout) {
		this.selectedlayout = selectedlayout;
	}

	public String[] getSelectedClient() {
		return selectedClient;
	}

	public void setSelectedClient(String[] selectedClient) {
		this.selectedClient = selectedClient;
	}

	public List<String> getSelectedUser() {
		return selectedUser;
	}

	public void setSelectedUser(List<String> selectedUser) {
		this.selectedUser = selectedUser;
	}
	
	public String getOutputClients() {
		return outputClients;
	}

	public void setOutputClients(String outputClients) {
		this.outputClients = outputClients;
	}

	public void callLayoutEditable() {
		if(selectedlayout != null && !selectedlayout.equals("") && 
				selectedClient != null && !outputClients.equals("") &&
					message != null && !message.equals("") &&
							selectedUser != null && !selectedUser.equals("")) {
			int layoutId = Integer.parseInt(selectedlayout);
			String message = "";
			log.info("Layout editable call for..."+layoutId);
			
			String manualFlag = this.getEditableLayoutDAO().checkLayoutManual(layoutId);
			if(manualFlag.equals("Y")) {
				message = "Layout "+layoutId+" is set as Manual";
				triggerEmailManualFlag(layoutId);
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
						"Warning",message));
			} else {
				String clientIds="";
				List<String> clients = this.getEditableLayoutDAO().checkLayoutInfo(layoutId);
				for(int j=0; j<clients.size(); j++) {
					clientIds += clients.get(j) + " ";					
				}				
				this.outputClients = clientIds;
				log.info("Cliets:"+getOutputClients());
				RequestContext.getCurrentInstance().execute("PF('dialogContinue').show();");
			}
		} else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
					"Warning","Layout, Client, Message and Email should not be empty!!!"));
		}
	}

	public void shellLayoutEditable() {
		
		String command = editableLayoutPath + "layoutEditable -l \"'" +  selectedlayout + 
							"'\" -c \"'" + StringUtils.join(selectedClient,',') +
							"'\" -m '" + message + 
							"' -e '" + StringUtils.join(selectedUser, ' ') + "' -u '" + this.sessionData.getFullname() + "' -d";
		log.info("Command::" + command);
		String output = handleShellExecute(command);
		
		log.info("output : " + output);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
				"Info","Editing of Layout completed."));
		System.out.println("Step1");
		RequestContext.getCurrentInstance().closeDialog("utilities");
		System.out.println("Step2");
		
		/*	if(output.compareTo("1")==0)
			{
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
						"Warning","Error occured. Please try again!"));
			
			else
			{
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Info","Editing of Layout completed."));
			}
			RequestContext.getCurrentInstance().closeDialog("utilities");*/
		//closeLayoutEditForm();
		
		
	}

	public void shellExecuteThread() {
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		executorService.execute(new Runnable() {

			@Override
			public void run() {
				handleShellExecute();
			}
		});
					
		executorService.shutdown();
	}
	
	public void showvalue() {
		log.info("Show value::"+ this.commandOutput);
	}
	
	public String handleShellExecute() {
		String command = this.inputCommand;
		final String output="";
		log.info("Shell execute called ..."+command);
		try {
			setCommandOutput("");
			final Process process = Runtime.getRuntime().exec(command);
			
			ExecutorService executorService = Executors.newSingleThreadExecutor();
			executorService.execute(new Runnable() {

				@Override
				public void run() {
			
					if(process.getInputStream() != null) {
						try {
							setCommandOutput(loadStream(process.getInputStream()));
						} catch (Exception e) {
							log.error(e.getMessage());
						}
					}	
				}
			});
			executorService.shutdown();
			
		} catch (Exception e) {
			log.error("Error in handleshell"+e.getMessage());
			setCommandOutput(e.getMessage());
		} 
		return output;
	}
	
	public String handleShellExecute(String command) {
		String output="";
		try {
						
			RuntimeExecutor rt = new RuntimeExecutor(serverName);
			output = rt.runSimpleCommand(command);
			rt.endProcess();
			
			log.debug("Output:"+output);
			
		} catch (Exception e) {
			log.error("Error in handleshell"+e.getMessage());
		} 
		return output;
	}
	
	private static String loadStream(InputStream is) throws Exception {
		StringBuilder sb = new StringBuilder();
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		String line;
		while((line = br.readLine()) != null) {
			sb.append(line).append("\n");				
		}
		br.close();
		isr.close();
		return sb.toString();
	}
	
	private void triggerEmailManualFlag(int layoutId) {
		EmailConfiguration email = new EmailConfiguration();
		ArrayList<String> ccList=new ArrayList<String>();
		if(selectedUser.size() > 1) {
			for(int i=0; i<selectedUser.size(); i++) {
				ccList.add(selectedUser.get(i));
			}
			email.setTo(selectedUser.get(0));
			email.setCc(ccList);
		} else {
			email.setTo(selectedUser.get(0));
		}
		
		email.setSubject("Layout editable request Layout id: "+layoutId);
		email.setContent("AIP Layout Editable Notification System\n" +
				"---------------------------------------------------------------------\n" +
				"Hello "+getUsername()+",\n\n" +
				"Layout is set as manual. User has manually generated imported script.\n\n" +
				"This layout cannot be set to editable mode.");
		int status = email.sendMail();
		if (status == 1) {
			log.info("Email Sent");
		} else {
			log.info("Couldnot send email");
		}
	}
	
	public void triggerEmailNoEditable() {
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
				"Info","User is not sure to edit the layout!!!"));
		EmailConfiguration email = new EmailConfiguration();
		ArrayList<String> ccList=new ArrayList<String>();
		if(selectedUser.size() > 1) {
			for(int i=0; i<selectedUser.size(); i++) {
				ccList.add(selectedUser.get(i));
			}
			email.setTo(selectedUser.get(0));
			email.setCc(ccList);
		} else {
			email.setTo(selectedUser.get(0));
		}
		email.setSubject("Layout editable request Layout id:");
		email.setContent("AIP Layout Editable Notification System\n" +
				"---------------------------------------------------------------------\n" +
				"Hello "+getUsername()+",\n\n" +
				"Following client id is/are affected : \n"+  this.outputClients +"\n\n" +
				"Please communicate the changes with affected client first and after mutual understading between affected clients," +
				" request for layout editable mode.");
		int status = email.sendMail();
		if (status == 1) {
			log.info("Email Sent");
		} else {
			log.info("Couldnot send email");
		}
	}
	
	private String getUsername() {
		String userName = "";
		if(this.selectedUser.size() == 1) {
			String namePart[] = selectedUser.get(0).split("@");
			return namePart[0];
		} else {
			return userName;
		}
	}
	public void closeLayoutEditForm() {
		RequestContext.getCurrentInstance().closeDialog("utilities");
	}

}
