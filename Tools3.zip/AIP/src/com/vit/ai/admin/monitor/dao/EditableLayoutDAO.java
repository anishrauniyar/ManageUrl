package com.vit.ai.admin.monitor.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.admin.monitor.model.Client;
import com.vit.ai.admin.monitor.model.Layout;
import com.vit.ai.admin.monitor.model.User;
import com.vit.dbconnection.ConnectDB;

public class EditableLayoutDAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger(EditableLayoutDAO.class.getName());
	
	public List<Layout> getLayout() {
		List<List<String>> layoutList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
//		String sqlQuery = "SELECT LAYOUTID, PAYOR, PAYORID, DATATYPE FROM IMP_LAYOUTS";
		String sqlQuery = "SELECT DISTINCT LAYOUTID FROM IMP_LAYOUTS";
		log.debug("EditableLayoutDAO.getLayout()::"+sqlQuery);
		layoutList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Layout> layout = new ArrayList<Layout>();
		if(layoutList.size() > 0) {
			for(int i=1; i<layoutList.size(); i++) {
				layout.add(new Layout(layoutList.get(i).get(0)));
			}
		}
		return layout;		
	}
	
	public List<Client> getClients() {
		List<List<String>> clientList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
//		String sqlQuery = "SELECT CLIENTID, CLIENTNAME FROM IMP_CLIENT_LIST";
		String sqlQuery = "SELECT Nvl(CLIENTID,'NA') CLIENTID, Nvl(CLIENTNAME,'NA') CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS ORDER BY CLIENTID";
		log.debug("EditableLayoutDAO.getClients()::"+sqlQuery);
		clientList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Client> client = new ArrayList<Client>();
		if(clientList.size() > 0) {
			for(int i=1; i<clientList.size(); i++) {
				client.add(new Client(clientList.get(i).get(0), clientList.get(i).get(1)));
			}
		}
		return client;		
	}
	
	public List<User> getUsers() {
		List<List<String>> userList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT USERID, FULLNAME, EMAIL FROM AIPD_USERS ORDER BY FULLNAME";
		log.debug("EditableLayoutDAO.getUsers()::"+sqlQuery);
		userList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<User> user = new ArrayList<User>();
		if(userList.size() > 0) {
			for(int i=1; i<userList.size(); i++) {
				user.add(new User(userList.get(i).get(0), userList.get(i).get(1), userList.get(i).get(2)));
			}
		}
		return user;		
	}
	
	public String checkLayoutManual(int layoutId) {
		List<List<String>> manualFlagList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT MANUALFLAG FROM IMP_LAYOUTS WHERE LAYOUTID =" +layoutId; 
		log.debug("EditableLayoutDAO.checkLayoutManual::"+sqlQuery);
		manualFlagList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		String manualFlag="";
		if(manualFlagList.size() > 0) {
			manualFlag = manualFlagList.get(1).get(0);
		}
		return manualFlag;
	}
	
	public List<String> checkLayoutInfo(int layoutId) {
		List<List<String>> clientList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT DISTINCT CLIENTID FROM IMP_CLIENTPATTERNS WHERE LAYOUTID = " +layoutId; 
		log.debug("EditableLayoutDAO.checkLayoutInfo::"+sqlQuery);
		clientList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<String> clients = new ArrayList<String>();
		if(clientList.size() > 0) {
			for(int i=1; i<clientList.size(); i++) {
				clients.add(clientList.get(i).get(0));
			}
		}
		return clients;
	}

}
