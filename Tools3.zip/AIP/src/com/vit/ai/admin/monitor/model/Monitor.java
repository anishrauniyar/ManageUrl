package com.vit.ai.admin.monitor.model;

public class Monitor {
	
	private String displayName;
	private int displayValue;
	
	public Monitor(String displayName, int displayValue) {
		super();
		this.displayName = displayName;
		this.displayValue = displayValue;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public int getDisplayValue() {
		return displayValue;
	}
	public void setDisplayValue(int displayValue) {
		this.displayValue = displayValue;
	}

}
