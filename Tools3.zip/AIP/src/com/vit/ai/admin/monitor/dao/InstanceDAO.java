package com.vit.ai.admin.monitor.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.vit.ai.admin.monitor.model.Client;
import com.vit.ai.admin.monitor.model.ClientList;
import com.vit.ai.admin.monitor.model.Instance;
import com.vit.ai.admin.monitor.model.Monitor;
import com.vit.dbconnection.ConnectDB;

/**
 * This class is DAO of Instance
 * @author i80654
 *
 */
public class InstanceDAO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger(InstanceDAO.class.getName());
	
	
	public List<Instance> getInstance() {
		List<List<String>> instanceList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT INSTANCE_NAME, CONFIG_FILE, CLIENTID, START_DATE, END_DATE, STATUS, CREATED_BY, CREATED_DATE, MACHINE " + 
				"FROM AIP_MAIN_INSTANCE";
		log.debug("InstanceDAO.getInstance()::"+sqlQuery);
		instanceList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Instance> instance = new ArrayList<Instance>();
		if(instanceList.size() > 0) {
			for(int i=1; i<instanceList.size(); i++) {
				instance.add(new Instance(instanceList.get(i).get(0), instanceList.get(i).get(1), instanceList.get(i).get(2),
						instanceList.get(i).get(3), instanceList.get(i).get(4), instanceList.get(i).get(5),
						instanceList.get(i).get(6), instanceList.get(i).get(7), instanceList.get(i).get(8)));
			}
		}
		return instance;		
	}
	
	public List<String> getClients(String instanceName) {
		List<List<String>> clientList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT CLIENTID " + 
				"FROM AIP_MAIN_INSTANCE WHERE INSTANCE_NAME = '"+instanceName+"'";
		log.debug("InstanceDAO.getClients()::"+sqlQuery);
		clientList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<String> clients = new ArrayList<String>();
		if(clientList.size() > 0) {
			StringTokenizer st = new StringTokenizer(clientList.get(1).get(0), ",");
			while(st.hasMoreElements()) {
				clients.add((String) st.nextElement());
			}
			
		}
		return clients;		
	}

	
	public List<String> getFmonServers() {
		List<List<String>> serverList;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT MACHINENAME FROM aip_fmon_server";
		log.debug("InstanceDAO.getFmonServers()::"+sqlQuery);
		serverList = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<String> servers = new ArrayList<String>();
		if(serverList.size() > 0) {
			for(int i=1; i<serverList.size(); i++) {
				servers.add(serverList.get(i).get(0));
			}
		}
		return servers;		
	}
	
	
	public List<Client> getClientList() {
		List<List<String>> clients;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT CLIENTID,CLIENTNAME FROM IMP_CLIENT_LIST ORDER BY CLIENTID";
		log.debug("InstanceDAO.getClientList()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Client> clientList = new ArrayList<Client>();
		if(clients.size() > 0) {
			for(int i=1; i<clients.size(); i++) {
				clientList.add(new Client(clients.get(i).get(0), clients.get(i).get(1)));
			}
		}
		return clientList;		
	}
	
	public boolean clientExists(String clientId, String instanceName) {
		List<List<String>> clients;
		boolean clientExists = false;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT Count(*) FROM AIP_MAIN_INSTANCE WHERE clientId like '%"+clientId+"%'" +
				"	AND instance_name='"+instanceName+"'";
		log.debug("InstanceDAO.clientExists()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		if(clients.size() > 0 && Integer.parseInt(clients.get(1).get(0)) > 0) {
			clientExists = true;
		}
		log.info("client exists:"+clientExists);
		return clientExists;		
	}
	
	public boolean clientExists(List<ClientList> clientList) {
		List<List<String>> clients;
		boolean clientExists = false;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT Count(*) FROM AIP_MAIN_INSTANCE WHERE clientId in (";
		for(int i=0; i<clientList.size(); i++) {
			sqlQuery += "'"+clientList.get(i).getClientid()+"',";
		}
		if(sqlQuery.lastIndexOf(",")>0) {
			sqlQuery = sqlQuery.substring(0, sqlQuery.lastIndexOf(","));
		}
		sqlQuery += ")";
		log.debug("InstanceDAO.clientExists(clientList)::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		if(clients.size() > 0 && Integer.parseInt(clients.get(1).get(0)) > 0) {
			clientExists = true;
		}
		return clientExists;		
	}
	
	public int totalClientsInMonitor() {
		List<List<String>> clients;
		int number_clients=0;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT Count(DISTINCT client_id) AS  total_clients_monitor FROM aip_import_summary_view";
		log.debug("InstanceDAO.totalClientsInMonitor()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		if(clients.size() > 0) {
			number_clients = Integer.parseInt(clients.get(1).get(0));
		}
		return number_clients;
	}
	
	public int totalNumberofFilesInMonitor() {
		List<List<String>> clients;
		int number_files=0;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT Count(DISTINCT file_name) FROM aip_import_summary_view";
		log.debug("InstanceDAO.totalNumberofFilesInMonitor()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		if(clients.size() > 0) {
			number_files = Integer.parseInt(clients.get(1).get(0));
		}
		return number_files;
	}
	
	public int totalSizeofFilesInMonitor() {
		List<List<String>> clients;
		int size_files=0;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		//TODO --- change is JSF page for instance action
		//also change icon for unknown type
		String sqlQuery = "SELECT Round(Sum(file_size)/(1024*1024*1024)) FROM aip_import_summary_view";
		log.debug("InstanceDAO.totalSizeofFilesInMonitor()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		if(clients.size() > 0) {
			size_files = Integer.parseInt(clients.get(1).get(0));
		}
		return size_files;
	}
	
	public List<Monitor> totalClientsInServer() {
		List<List<String>> clients;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT executed_from, Count(DISTINCT client_id) AS  total_clients_server FROM aip_import_summary_view GROUP BY executed_from";
		log.debug("InstanceDAO.totalClientsInServer()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Monitor> monitorList = new ArrayList<Monitor>();
		if(clients.size() > 0) {
			for(int i=1; i<clients.size(); i++) {
				monitorList.add(new Monitor(clients.get(i).get(0), Integer.parseInt(clients.get(i).get(1))));
			}
		}
		return monitorList;
	}
	
	public List<Monitor> totalFileSizeInInstance() {
		List<List<String>> clients;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT b.fmontag, round(Sum(a.filesize)/1024)  FROM aip_dmfilelist_log a, aip_cron_log b where a.fmonid=b.fmonid " + 
							"GROUP BY b.fmontag";
		log.debug("InstanceDAO.totalFileSizeInInstance()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Monitor> monitorList = new ArrayList<Monitor>();
		if(clients.size() > 0) {
			for(int i=1; i<clients.size(); i++) {
				monitorList.add(new Monitor(clients.get(i).get(0), Integer.parseInt(clients.get(i).get(1))));
			}
		}
		return monitorList;
	}
	
	public List<Monitor> totalFileNumberInInstance() {
		List<List<String>> clients;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT b.fmontag, count(a.filesize)  FROM aip_dmfilelist_log a, aip_cron_log b where a.fmonid=b.fmonid " + 
							"GROUP BY b.fmontag";
		log.debug("InstanceDAO.totalFileNumberInInstance()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Monitor> monitorList = new ArrayList<Monitor>();
		if(clients.size() > 0) {
			for(int i=1; i<clients.size(); i++) {
				monitorList.add(new Monitor(clients.get(i).get(0), Integer.parseInt(clients.get(i).get(1))));
			}
		}
		return monitorList;
	}
	
	public List<Monitor> totalProcessTimeInInstance() {
		List<List<String>> clients;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		String sqlQuery = "SELECT b.fmontag,Round(Sum(endtime-processtime)*24*60*60)  FROM aip_dmfilelist_log a, " +
							"aip_cron_log b where a.fmonid=b.fmonid GROUP BY b.fmontag";
		log.debug("InstanceDAO.totalProcessTimeInInstance()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Monitor> monitorList = new ArrayList<Monitor>();
		if(clients.size() > 0) {
			for(int i=1; i<clients.size(); i++) {
				monitorList.add(new Monitor(clients.get(i).get(0), Integer.parseInt(clients.get(i).get(1))));
			}
		}
		return monitorList;
	}
	
	public List<Monitor> totalProcessTimeInServer() {
		List<List<String>> clients;
		ConnectDB conndb = new ConnectDB();
		conndb.initialize();
		//TODO
		String sqlQuery = "SELECT executed_from, Round(Sum(process_time)/(24)) FROM aip_import_summary_view GROUP BY executed_from";
		log.debug("InstanceDAO.totalProcessTimeInServer()::"+sqlQuery);
		clients = conndb.resultSetToListOfList(sqlQuery);
		conndb.endConnection();
		List<Monitor> monitorList = new ArrayList<Monitor>();
		if(clients.size() > 0) {
			for(int i=1; i<clients.size(); i++) {
				monitorList.add(new Monitor(clients.get(i).get(0), Integer.parseInt(clients.get(i).get(1))));
			}
		}
		return monitorList;
	}
	
}
