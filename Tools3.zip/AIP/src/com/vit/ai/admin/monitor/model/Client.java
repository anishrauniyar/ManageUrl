package com.vit.ai.admin.monitor.model;

import java.io.Serializable;

public class Client implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String clientId;
	private String clientName;
	
	public Client(String clientId, String clientName) {
		super();
		this.clientId = clientId;
		this.clientName = clientName;
	}
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
}
