package com.vit.ai.admin.monitor.model;

import java.io.Serializable;

public class Layout implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String layoutId;
	private String payor;
	private String payorId;
	private String dataType;
	
	public Layout(String layoutId) {
		super();
		this.layoutId = layoutId;
	}
	
	public Layout(String layoutId, String payor, String payorId, String dataType) {
		super();
		this.layoutId = layoutId;
		this.payor = payor;
		this.payorId = payorId;
		this.dataType = dataType;
	}
	
	public String getLayoutId() {
		return layoutId;
	}
	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}
	public String getPayor() {
		return payor;
	}
	public void setPayor(String payor) {
		this.payor = payor;
	}
	public String getPayorId() {
		return payorId;
	}
	public void setPayorId(String payorId) {
		this.payorId = payorId;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}	

}
