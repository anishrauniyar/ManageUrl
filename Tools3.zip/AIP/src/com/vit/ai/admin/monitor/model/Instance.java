package com.vit.ai.admin.monitor.model;

import java.io.Serializable;

/**
 * Model class for Instance
 * @author i80654
 *
 */
public class Instance implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String configFile;
	private String clientId;
	private String startDate;
	private String endDate;
	private String status;
	private String createdBy;
	private String createdDate;	
	private String machine;
	
	/**
	 * Constructor of {@link Instance}
	 * 
	 * @param name
	 * @param configFile
	 * @param clientId
	 * @param startDate
	 * @param endDate
	 * @param status
	 * @param createdBy
	 * @param createdDate
	 */
	public Instance(String name, String configFile, String clientId,
			String startDate, String endDate, String status, String createdBy,
			String createdDate, String machine) {
		super();
		this.name = name;
		this.configFile = configFile;
		this.clientId = clientId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.machine = machine;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getConfigFile() {
		return configFile;
	}
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getMachine() {
		return machine;
	}
	public void setMachine(String machine) {
		this.machine = machine;
	}

}
