package com.vit.ai.admin.monitor.mb;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.primefaces.model.DualListModel;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.CategoryAxis;
import org.primefaces.model.chart.ChartSeries;
import org.primefaces.model.chart.LineChartModel;

import com.vit.ai.admin.monitor.dao.InstanceDAO;
import com.vit.ai.admin.monitor.model.Client;
import com.vit.ai.admin.monitor.model.ClientList;
import com.vit.ai.admin.monitor.model.Instance;
import com.vit.ai.admin.monitor.model.Monitor;
import com.vit.ai.admin.monitor.model.Template;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.utils.AbstractController;


/**
 * This class is the Managed Bean of Instance.
 * @author i80654
 *
 */

@ManagedBean
@ViewScoped
public class InstanceMB extends AbstractController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static Logger log = Logger.getLogger(InstanceMB.class.getName());
	
	private static String serverName = AIConstant.DASHBOARD_SERVER_NAME;
	private static String fmonPath = AIConstant.FMON_PATH;
	private static String filePath = AIConstant.CONFIG_FILE_PATH;
	private static String clientFilePath = AIConstant.CLIENT_FILE_PATH;
	 
	private InstanceDAO instanceDAO;
	private List<Instance> instance;
	private Template template;
	private String action;
	private String instanceAction;
	
	private String instanceName;
	private List<ClientList> clientList;
	
	
	private DualListModel<String> clients = new DualListModel<String>();
	private String sourceInstance;
	private String targetInstance;
	private List<String> oldTarget;
	
	private String updateInstance;
	private String updateAction;
	private String heartbeatInstance;
	private String heartbeatAction;
	
	private List<String> fmonServers;
	private String selectedServer;
	
	private List<Client> addClientInstance;
	private String addClient;
	private String frequency;
	private Date startTime;
	
	private int totalClientsMonitor=0;
	private int totalNumberofFilesInMonitor=0;
	private int totalFileSizeinMonitor=0;
	
	
	private LineChartModel lineModel;
	
	public List<Instance> getInstance() {
		return instance;
	}
	
	@PostConstruct
	public void init() {
		log.info("InstanceMB Init called...");
		if(instance == null) {
			instance = getInstanceDAO().getInstance();
		}
		if(fmonServers == null) {
			fmonServers = this.getInstanceDAO().getFmonServers();
		}
		if(addClientInstance == null) {
			addClientInstance = this.getInstanceDAO().getClientList();
		}
		if(totalClientsMonitor == 0) {
			totalClientsMonitor = this.getInstanceDAO().totalClientsInMonitor();
		}
		if(totalNumberofFilesInMonitor == 0) {
			totalNumberofFilesInMonitor = this.getInstanceDAO().totalNumberofFilesInMonitor();
		}
		if(totalFileSizeinMonitor == 0) {
			totalFileSizeinMonitor = this.getInstanceDAO().totalSizeofFilesInMonitor();
		}
			
		createLineModel();
	}
	
	public void readTemplate() {
		Properties p = new Properties();
		
		try {
			log.info("Read template called...");
			p.load(Thread.currentThread().getContextClassLoader()
					.getResourceAsStream("template.properties"));
			template = new Template(p.getProperty("RESUMEFET"),p.getProperty("CLIENTID"));
			resetTemplate();
			
		} catch (IOException e) {
			log.error("InstanceMB::readTemplate::"+e.getMessage());
		}
	}
	
	public void resetTemplate() {
		this.instanceName = "";
		this.selectedServer = "";
	}
	
	
	public void continueNewTemplate() {
		clientList = new ArrayList<ClientList>();
		String clientId =this.getTemplate().getClientId();
		clientId = clientId.replaceAll("\"", "").replace("'", "");
		StringTokenizer st = new StringTokenizer(clientId,",");
		while(st.hasMoreElements()) {
			ClientList obj = new ClientList((String) st.nextElement(),"",null);
			this.clientList.add(obj);
		}
		if(this.getInstanceDAO().clientExists(clientList)) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error","Clientid already exists"));
		}
	}
	
	public void createNewTemplate() {
		
		log.info("Create template called...");
		
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("template.properties");
		
		File fileConfig = new File(filePath+instanceName+".properties");
		
		try {
			if(!fileConfig.exists()) {
				fileConfig.createNewFile();
			}			
			
			OutputStream outStream = new FileOutputStream(fileConfig);
			
			byte[] buffer = new byte[1024];
			int length;
			while((length = is.read(buffer)) > 0) {
				outStream.write(buffer, 0, length);
			}	
			outStream.close();
			is.close();
			
			PropertiesConfiguration config = new PropertiesConfiguration(fileConfig);
//			config.setProperty("ACTIONSLIST", this.getTemplate().getActionList());
//			config.setProperty("listGenerate", this.getTemplate().getListGenerate());
			config.setProperty("RESUMEFET", this.getTemplate().getResumeFet());
			config.setProperty("CLIENTID", this.getTemplate().getClientId());
			
			config.save(new FileWriter(filePath+instanceName+".conftemp"));
			
			BufferedReader br = new BufferedReader(new FileReader(filePath+instanceName+".conftemp"));
			BufferedWriter bw = new BufferedWriter(new FileWriter(filePath+instanceName+".conf"));
			String line;
			while((line = br.readLine()) != null) {
				line = line.replace("\\", "");				
				bw.write(line);
				bw.newLine();
			}
				
			br.close();
			bw.flush();
			bw.close();
			System.gc();
			
			if(fileConfig.exists()) {
				fileConfig.delete();
			}
			
		} catch (IOException | ConfigurationException e1) {
			log.error("InstanceMB::createNewTemplate::"+e1.getMessage());
		}
		
		File fileClientList = new File(clientFilePath+instanceName+"_clientlist.txt");
		if(!fileClientList.exists()) {
			try {
				fileClientList.createNewFile();
				
				FileWriter fw = new FileWriter(fileClientList.getAbsoluteFile());
				BufferedWriter bw = new BufferedWriter(fw);
				for(int i=0;i<this.clientList.size();i++) {
					bw.write(this.clientList.get(i).getClientid()+"|"+
								this.clientList.get(i).getFrequency()+"|"+
									new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(clientList.get(i).getStartTime())+"\n");
				}
				bw.close();
				
			} catch (IOException e) {
				log.error(e.getMessage());
			}
		}
		
		String command = fmonPath+"./fmond create --conf "+filePath+instanceName+".conf"+ " --name " + instanceName +
				" --machine "+selectedServer+" --dashboard";
		log.info(command);
		
		RuntimeExecutor rt = new RuntimeExecutor(serverName);
		String output = rt.runSimpleCommand(command);
		rt.endProcess();
		log.info("Output::"+output);
		
		if(output.equalsIgnoreCase("notconnected")) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error","Unable to create instance "+instanceName));
		} else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
				"Success","Instance created successfully for "+instanceName));
		}
		
		File tempFile = new File(filePath+instanceName+".conftemp");
		if(tempFile.exists()) {
			log.info("Temp file deleted.."+tempFile.delete());
		}
	}
	
	public void addClientInstance() {
		log.info(this.addClient+" "+this.updateInstance + " "+ this.frequency + " "+ this.startTime);
		
		if(!this.instanceDAO.clientExists(addClient, updateInstance)){
			
			String command = fmonPath + "./fmond add --name " + this.updateInstance + " --clientid " + this.addClient + " --dashboard";
			log.info(command);
			
			RuntimeExecutor rt = new RuntimeExecutor(serverName);
			String output = rt.runSimpleCommand(command);
			rt.endProcess();
			log.info("Output::"+output);
			
			if(!output.equalsIgnoreCase("notconnected")) {
				File fileClientList = new File(clientFilePath+this.updateInstance+"_clientlist.txt");
				try {
					fileClientList.createNewFile();
					
					FileWriter fw = new FileWriter(fileClientList.getAbsoluteFile());
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(this.addClient + "|" + this.frequency + "|" + 
							new SimpleDateFormat("yyyyMMdd HH:mm:ss").format( this.startTime)+"\n");
					bw.close();
					
				} catch (IOException e) {
					log.error(e.getMessage());
				}
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
						"Success","Client added successfully"));
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error","Error occurred while adding client."));
			}
		} else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error","Client "+ addClient +" already exists for instance "+updateInstance));
		}
	}
	
	public void moveClientInstance() {
		log.info("Move Instance:"+sourceInstance);
		List<String> sourceClients = new ArrayList<String>();
		List<String> targetClients = new ArrayList<String>();
		
		if(sourceInstance != null) {
			sourceClients = this.getInstanceDAO().getClients(sourceInstance);
		}
		if(targetInstance != null) {
			targetClients = this.getInstanceDAO().getClients(targetInstance);
		}
		
		clients = new DualListModel<String>(sourceClients, targetClients);
		setOldTarget(targetClients);
	}
	
	public void updateMoveClient() {
		List<String> movedClient = clients.getTarget();
		movedClient.removeAll(getOldTarget());
		String clientMoved="";
		for(String s: movedClient) {
			clientMoved += s;
		}
		String command = fmonPath+"./fmond move --sname "+sourceInstance+ " --clientid " + clientMoved +
							" --dname "+targetInstance+" --dashboard";
		log.info("Command:"+command);
		
		if(movedClient.size() > 1) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,
					"Failure","Move only one client at a time"));
			moveClientInstance();
		} else {
			RuntimeExecutor rt = new RuntimeExecutor(serverName);
			String output = rt.runSimpleCommand(command);
			rt.endProcess();
			log.info("Output::"+output);
			if(!output.equalsIgnoreCase("notconnected")) {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
						"Success","Client Moved successfully"));
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error","Error occurred during move."));
			}
		}
		moveClientInstance();
		
	}
	
	public void updateInstance() {
		
		String command = fmonPath+"./fmond update --name " + updateInstance + " --action " + updateAction; 
		log.info("Update command:"+command);
		
		RuntimeExecutor rt = new RuntimeExecutor(serverName);
		String output = rt.runSimpleCommand(command);
		rt.endProcess();
		
		if(output.equalsIgnoreCase("notconnected")) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error","Unable to perform "+updateAction + " for instance "+updateInstance));
		} else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Success","Instance "+updateInstance+" "+updateAction+" successfully"));
		}
	}
	
	public void heartbeatInstance() {
		
		String command = fmonPath+"./fmond heartbeat --name " + heartbeatInstance + " --action " + heartbeatAction; 
		log.info("Heartbeat command:"+command);
		
		RuntimeExecutor rt = new RuntimeExecutor(serverName);
		String output = rt.runSimpleCommand(command);
		rt.endProcess();
		
		if(output.equalsIgnoreCase("notconnected")) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error","Unable to perform "+heartbeatAction + " for instance "+heartbeatInstance));
		} else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Success","Instance "+heartbeatInstance+" "+heartbeatAction+" successfully"));
		}
	}
	
	public void setClientList(List<ClientList> clientList) {
		this.clientList = clientList;
	}

	public List<ClientList> getClientList() {
		return clientList;
	}
	
	public InstanceDAO getInstanceDAO() {
		if(this.instanceDAO == null) {
			instanceDAO = new InstanceDAO();
		}
		return instanceDAO;
	}

	public void setInstanceDAO(InstanceDAO instanceDAO) {
		this.instanceDAO = instanceDAO;
	}
	
	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}		
	
	public String getAction() {
		return action;
	}
	
	public void setAction(String action) {
		this.action = action;
	}
	
	public String getInstanceName() {
		return instanceName;
	}

	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName.toUpperCase();
	}

	public DualListModel<String> getClients() {
		return clients;
	}

	public void setClients(DualListModel<String> clients) {
		this.clients = clients;
	}

	public String getSourceInstance() {
		return sourceInstance;
	}

	public void setSourceInstance(String sourceInstance) {
		this.sourceInstance = sourceInstance;
	}

	public String getTargetInstance() {
		return targetInstance;
	}

	public void setTargetInstance(String targetInstance) {
		this.targetInstance = targetInstance;
	}
	
	public List<String> getOldTarget() {
		return oldTarget;
	}

	public void setOldTarget(List<String> oldTarget) {
		this.oldTarget = oldTarget;
	}
	
	public String getUpdateInstance() {
		return updateInstance;
	}

	public void setUpdateInstance(String updateInstance) {
		this.updateInstance = updateInstance;
	}

	public String getHeartbeatInstance() {
		return heartbeatInstance;
	}

	public void setHeartbeatInstance(String heartbeatInstance) {
		this.heartbeatInstance = heartbeatInstance;
	}

	public String getUpdateAction() {
		return updateAction;
	}

	public void setUpdateAction(String updateAction) {
		this.updateAction = updateAction;
	}

	public String getHeartbeatAction() {
		return heartbeatAction;
	}

	public void setHeartbeatAction(String heartbeatAction) {
		this.heartbeatAction = heartbeatAction;
	}

	public void selectInstanceAction(String instanceAction){
		log.info("Selected instance Action "+instanceAction);
		System.out.println("Action "+instanceAction);
		setInstanceAction(instanceAction);
	}
	public void handleActionChange(Instance instance) {

		String instanceName = instance.getName();
		String command = "";
		System.out.println("Action "+this.instanceAction);
		log.info("handel::"+action+"  instancename::"+instanceName);
		try {
			if(this.instanceAction.equals("stop")) {
				log.info("Stopping instance : "+instanceName);
				command = fmonPath+"./fmond stop --name " + instanceName+" --dashboard";
				
			} else if(this.instanceAction.equals("start")) {
				log.info("Starting instance : "+instanceName);
				command = fmonPath+"./fmond start --name " + instanceName+" --dashboard";
				
			} else if(this.instanceAction.equals("remove")) {
				log.info("Starting instance : "+instanceName);
				command = fmonPath+"./fmond remove --name " + instanceName+" --dashboard";
				
			} else if(this.instanceAction.equals("health")) {
				log.info("Starting instance : "+instanceName);
				command = fmonPath+"./fmond health --name " + instanceName+" --dashboard";
				
			} else if(this.instanceAction.equals("status")) {
				log.info("Starting instance : "+instanceName);
				command = fmonPath+"./fmond status --name " + instanceName+" --dashboard";
				
			} else if(this.instanceAction.equals("recover")) {
				log.info("Starting instance : "+instanceName);
				command = fmonPath+"./fmond recover --name " + instanceName+" --dashboard";
			}
			
			log.info("Command:"+command);
			RuntimeExecutor rt = new RuntimeExecutor(serverName);
			String output = rt.runSimpleCommand(command);
			rt.endProcess();
			log.info("Output::"+output);
			if(!output.equalsIgnoreCase("notconnected")) {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
						"Success",instanceName));
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error","Error occurred."));
			}			
			
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error",e.getMessage()));
		}
		this.instanceAction="";
		
		
	}
	

	public List<String> getFmonServers() {
		return fmonServers;
	}

	public void setFmonServers(List<String> fmonServers) {
		this.fmonServers = fmonServers;
	}

	public String getSelectedServer() {
		return selectedServer;
	}

	public void setSelectedServer(String selectedServer) {
		this.selectedServer = selectedServer;
	}

	public List<Client> getAddClientInstance() {
		return addClientInstance;
	}

	public void setAddClientInstance(List<Client> addClientInstance) {
		this.addClientInstance = addClientInstance;
	}

	public String getAddClient() {
		return addClient;
	}

	public void setAddClient(String addClient) {
		this.addClient = addClient;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	
	public LineChartModel getLineModel() {
		return lineModel;
	}

	public void setLineModel(LineChartModel lineModel) {
		this.lineModel = lineModel;
	}
	
	public int getTotalClientsMonitor() {
		return totalClientsMonitor;
	}

	public void setTotalClientsMonitor(int totalClientsMonitor) {
		this.totalClientsMonitor = totalClientsMonitor;
	}
	
	public int getTotalNumberofFilesInMonitor() {
		return totalNumberofFilesInMonitor;
	}

	public void setTotalNumberofFilesInMonitor(int totalNumberofFilesInMonitor) {
		this.totalNumberofFilesInMonitor = totalNumberofFilesInMonitor;
	}

	public int getTotalFileSizeinMonitor() {
		return totalFileSizeinMonitor;
	}

	public void setTotalFileSizeinMonitor(int totalFileSizeinMonitor) {
		this.totalFileSizeinMonitor = totalFileSizeinMonitor;
	}

	private void createLineModel() {
		
		lineModel = initCaterogyModel();
		lineModel.setTitle("Client Server Chart");
		lineModel.setAnimate(true);
		lineModel.setZoom(true);
		lineModel.setLegendPosition("ne");
		lineModel.setShowPointLabels(true);
		lineModel.getAxes().put(AxisType.X, new CategoryAxis("Servers"));
		Axis xAxis = lineModel.getAxis(AxisType.X);
		xAxis.setTickAngle(30);
		
		Axis yAxis = lineModel.getAxis(AxisType.Y);
		yAxis.setLabel("Values");
		yAxis.setMin(0);
		yAxis.setMax(120);
		
	}
	
	private LineChartModel initCaterogyModel() {
		LineChartModel model = new LineChartModel();
		List<Monitor> listClientsInServer = this.getInstanceDAO().totalClientsInServer();
		//List<Monitor> listFileSizeInInstance = this.getInstanceDAO().totalFileSizeInInstance();
		//List<Monitor> listFileNumberInInstance = this.getInstanceDAO().totalFileNumberInInstance();
		//List<Monitor> listProcessedTimeInInstance = this.getInstanceDAO().totalProcessTimeInInstance();
		List<Monitor> listProcessedTimeInServer = this.getInstanceDAO().totalProcessTimeInServer();
		
		ChartSeries totalClientsInServer = new ChartSeries();
		totalClientsInServer.setLabel("Total Clients in each Server");
		try{
		for(int i=0; i<listClientsInServer.size(); i++) {
			totalClientsInServer.set(listClientsInServer.get(i).getDisplayName().split("\\_",-1)[1],
					listClientsInServer.get(i).getDisplayValue());
		}
		}
		catch(Exception e){
			displayErrorMessageToUser("Error in server name", "Error");
		}
		
		/*ChartSeries totalFileSizeInInstance = new ChartSeries();
		totalClientsInServer.setLabel("Total File Processed in each Instance");
		for(int i=0; i<listFileSizeInInstance.size(); i++) {
			totalFileSizeInInstance.set(listFileSizeInInstance.get(i).getDisplayName(),
					listFileSizeInInstance.get(i).getDisplayValue());
		}
		
		ChartSeries totalFileNumberInInstance = new ChartSeries();
		totalClientsInServer.setLabel("Total Number of file processed in each Instance");
		for(int i=0; i<listFileNumberInInstance.size(); i++) {
			totalFileNumberInInstance.set(listFileNumberInInstance.get(i).getDisplayName(),
					listFileNumberInInstance.get(i).getDisplayValue());
		}*/
		
//		ChartSeries totalProcessedTimeInInstance = new ChartSeries();
//		totalClientsInServer.setLabel("Total procesed time in each Instance");
//		for(int i=0; i<listProcessedTimeInInstance.size(); i++) {
//			totalProcessedTimeInInstance.set(listProcessedTimeInInstance.get(i).getDisplayName(),
//					listProcessedTimeInInstance.get(i).getDisplayValue());
//		}
		
		ChartSeries totalProcessedTimeInServer = new ChartSeries();
		totalProcessedTimeInServer.setLabel("Total Processed time for each Server");
		for(int i=0; i<listProcessedTimeInServer.size(); i++) {
			try{
			totalProcessedTimeInServer.set(listProcessedTimeInServer.get(i).getDisplayName().split("\\_",-1)[1], 
					listProcessedTimeInServer.get(i).getDisplayValue());
			}
			catch(Exception e){
				displayErrorMessageToUser("Error in server name", "Error");
				
			}
			
		}
		
			
		model.addSeries(totalClientsInServer);
//		model.addSeries(totalFileSizeInInstance);
//		model.addSeries(totalFileNumberInInstance);
//		model.addSeries(totalProcessedTimeInInstance);
		model.addSeries(totalProcessedTimeInServer);
		
		return model;
	}

	public String getInstanceAction() {
		return instanceAction;
	}

	public void setInstanceAction(String instanceAction) {
		this.instanceAction = instanceAction;
	}
	
}
