package com.vit.ai.admin.monitor.model;

import java.io.Serializable;

public class Template implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String resumeFet;
	private String clientId;
	
		
	public Template(String resumeFet, String clientId) {
		super();
		this.resumeFet = resumeFet;
		this.clientId = clientId;
	}

	public String getResumeFet() {
		return resumeFet;
	}
	
	public void setResumeFet(String resumeFet) {
		this.resumeFet = resumeFet;
	}
	
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
}
