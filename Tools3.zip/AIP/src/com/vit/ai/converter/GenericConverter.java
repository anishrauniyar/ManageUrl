package com.vit.ai.converter;

import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.WeakHashMap;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

@FacesConverter(value="entityconverter")
public class GenericConverter implements Converter {
	
	private static Map<Object,String> entities = new WeakHashMap<Object,String>();

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String uuid) {
		
		// TODO Auto-generated method stub
		for(Entry<Object,String> entry : entities.entrySet())
		{
			if(entry.getValue().equals(uuid))
			{
				return entry.getKey();
			}
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object entity) {
		// TODO Auto-generated method stub
		synchronized(entities)
		{
			if(!entities.containsKey(entity))
			{
				String uuid = UUID.randomUUID().toString();
				entities.put(entity, uuid);
				return uuid;
			}
			else
			{
				return entities.get(entity);
			}
		}
		
	}

}
