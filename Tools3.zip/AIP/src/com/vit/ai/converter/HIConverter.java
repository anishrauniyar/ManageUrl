/*
 *Class Name : HIConverter.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.converter;

import java.io.Serializable;

import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import com.vit.ai.transfer.controller.LabelChangerBean;
import com.vit.ai.transfer.model.HIStructure_value;

/**
 * Converter to map objects to objects for label changer
 * 
 * @author Aashish Dhungana
 *
 * @version 1.0 30 Feb 2015
 */
@ViewScoped
@FacesConverter("hIConverter")
public class HIConverter implements Converter, Serializable {

	private static final long serialVersionUID = -4388577503632554338L;

	public Object getAsObject(FacesContext fc, UIComponent ui, String value) {

		if (!value.isEmpty() && value != null) {

			LabelChangerBean object = (LabelChangerBean) fc
					.getExternalContext().getApplicationMap()
					.get("labelChangerBean");

			return object.getListoftransfercolumns().get(
					Integer.parseInt(value));

		} else {
			return null;
		}
	}

	public int getIndex(LabelChangerBean object, String value) {
		int ind = 0;
		for (int i = 0; i < object.getListoftransfercolumns().size(); i++) {
			if (object.getListoftransfercolumns().get(i).getHiobject()
					.getName().compareTo(value) == 0) {
				ind = object.getListoftransfercolumns().indexOf(object);
				break;
			}
		}
		return ind;
	}

	public String getAsString(FacesContext fc, UIComponent ui, Object value) {

		if (value != null) {
			return String.valueOf(((HIStructure_value) value).getName());
		} else {

			return null;
		}
	}

}
