/*
 *Class Name : PatternRules.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.PrimeFacesContext;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.commons.model.PayerBean;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.flms.model.MClients;
import com.vit.ai.flms.model.Pattern;
import com.vit.ai.flms.model.PatternRulesList;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for FLMS-pattern
 * 
 * @author Aashish Dhungana
 * 
 * @modified By Binesh Sah
 * 
 * @modified By: Anish Rauniyar
 * 
 * @version 1.1 09 July 2015
 */
@ManagedBean
@ViewScoped
public class PatternRules extends AbstractController implements Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(PatternRules.class);
	
	private String client;
	private String sn;
	private LinkedHashMap<String, String> clients;
	private LinkedHashMap<String, String> payers;
	private LinkedHashMap<String, String> layouts;
	private Map<String, String> filterMap;
	private boolean isTransferAffected = false;
	private Pattern pattern;
	private Pattern ctlpattern;
	private ArrayList<Pattern> patternList;
	private ArrayList<Pattern> filteredPatterns;
	private ArrayList<String> employerGroups;
	private ArrayList<String> empgrpSelected;
	
	
	private ArrayList<String> clPayors;
	private ArrayList<String> dataTypes;
	private String layoutID;
	private String ctllayoutID;
	private String importScript;
	private LinkedHashMap<String, String> layoutsprid;
	private String dataType;
	private LinkedHashMap<String, String> layoutTypes;
	private String selectedRules;
	private String attributes;
	private DefaultStreamedContent downloadFile;
	private String filePath;
	private String winScreenHeight;
	private ArrayList<String> listofAppids = new ArrayList<>();
	private boolean appidChanged=false;
	private ArrayList<String> selectedAppids = new ArrayList<>();
	private Pattern patternUnderEdit;

	PatternRulesList objPRL;

	private ArrayList<String> transferTypes;
	
	private ArrayList<String> listEmployer;
	protected String inuseStatus;
	protected String inuseStatusRemarks;
	private ArrayList<String> inuseStatusList;
	
	private String ediFlag;
	private ArrayList<String> ediFlagList = new ArrayList<String>();
	private String ediMapper;
	private ArrayList<String> ediMapperList = new ArrayList<String>();
	
	
	public String getEdiFlag() {
		return ediFlag;
	}


	public void setEdiFlag(String ediFlag) {
		this.ediFlag = ediFlag;
	}


	public ArrayList<String> getEdiFlagList() {
		return ediFlagList;
	}


	public void setEdiFlagList(ArrayList<String> ediFlagList) {
		this.ediFlagList.add("Yes");
		this.ediFlagList.add("No");
	}


	public String getEdiMapper() {
		return ediMapper;
	}


	public void setEdiMapper(String ediMapper) {
		this.ediMapper = ediMapper;
	}


	public ArrayList<String> getEdiMapperList() {
		return ediMapperList;
	}


	public void setEdiMapperList(ArrayList<String> ediMapperList) {
		String query = "SELECT DISTINCT edimapper FROM imp_edimapper";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {
				this.ediMapperList.add(rs.get(i).get(0));
			}
		}		
	}
	
	
	
	public ArrayList<String> getInuseStatusList() {
		return inuseStatusList;
	}

	public void setInuseStatusList(ArrayList<String> inuseStatusList) {
		inuseStatusList.add("A");
		inuseStatusList.add("H");
		inuseStatusList.add("T");
		this.inuseStatusList = inuseStatusList;
	}

	public String getInuseStatus() {
		return inuseStatus;
	}

	public void setInuseStatus(String inuseStatus) {
		this.inuseStatus = inuseStatus;		
	}

	public String getInuseStatusRemarks() {
		return inuseStatusRemarks;
	}

	public void setInuseStatusRemarks(String inuseStatusRemarks) {
		this.inuseStatusRemarks = inuseStatusRemarks;		
	}

	public ArrayList<String> getListEmployer() {
		return listEmployer;
	}

	public void setListEmployer(ArrayList<String> listEmployer) {
		this.listEmployer = listEmployer;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public ArrayList<String> getEmpgrpSelected() {
		return empgrpSelected;
	}

	public void setEmpgrpSelected(ArrayList<String> empgrpSelected) {
		this.empgrpSelected = empgrpSelected;
	}

	public ArrayList<String> getTransferTypes() {
		return transferTypes;
	}

	public void setTransferTypes(ArrayList<String> transferTypes) {		
		transferTypes.add("REFRESH");
		transferTypes.add("APPEND");
		this.transferTypes = transferTypes;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public LinkedHashMap<String, String> getLayoutsprid() {
		return layoutsprid;
	}

	public void setLayoutsprid(LinkedHashMap<String, String> layoutsprid) {
		this.layoutsprid = layoutsprid;
	}

	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public PatternRules() {

		MClients objMClients = new MClients(false);
		clients = objMClients.getClients();

		PayerBean objHRP = new PayerBean();
		payers = objHRP.getPayers();
		LayoutType objLayoutType = new LayoutType();
		setLayoutTypes(objLayoutType.getlayoutTypes());
		
	}

	/**
	 * Load pattern rules information.
	 */
	public void handleClientChange() {

		ArrayList<String> transferType = new ArrayList<String>();
		ArrayList<String> inUseStatusList = new ArrayList<String>();
		resetFilters();
		RequestContext.getCurrentInstance().execute("getwinScreenHeight();");
		if (client != null && !client.equals("")) {
			
			/*if(reset)
			{*/
				if (this.filteredPatterns != null) {
					this.filteredPatterns = null;
					DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
							.getViewRoot().findComponent("frmPR:rulesList");
					dt1.setFilters(null);
					dt1.reset();
				/*}
				reset=false;*/
			}
			layoutID = null;
			objPRL = new PatternRulesList(client, this.userinfo.getFullname());
			setPatternList(objPRL.getPatternList());
			employerGroups= new ArrayList<String>();
			setEmployerGroups(employerGroups);
			//setEmployerGroups(objPRL.getEmployers());
			setClPayors(objPRL.getPayors());
			setDataTypes(objPRL.getDataType());
			setTransferTypes(transferType);
			setInuseStatusList(inUseStatusList);
		} else {

			setPatternList(new ArrayList<Pattern>());
			displayErrorMessageToUser("No client Selected!!", "ERROR");
		}

	}

	public void resetFilters() {
		//reset=true;
	}

	public void afterClientAddition() {

		if (getSessionData().isNewAdditionComplete()) {
			MClients objMClients = new MClients(false);
			clients = objMClients.getClients();

			String query = "SELECT Nvl(CLIENTID,'NA') FROM IMP_CLIENTPATTERNS "
					+ " WHERE SN=(SELECT MAX(SN) FROM IMP_CLIENTPATTERNS "
					+ " WHERE upper(USERLOG)='"
					+ getUserinfo().getFullname().toUpperCase() + "')";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> payerList = db.resultSetToListOfList(query);
			db.endConnection();

			if (payerList.size() > 0) {
				client = payerList.get(1).get(0);

			}

			handleClientChange();
			displayMessage();

		}

		this.sessionData.setNewAdditionComplete(false);
	}

	public void delete(Pattern pattern) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = "";
		String impUserLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) " 
							+ " VALUES  ('1', 'PATTERN_DELETE', 'PATTERNSN: " + pattern.getSn() + " | PATTERN DELETED: " + pattern.getPattern() + " | CLIENTID: " + pattern.getClientID() + "','"
							+ this.userinfo.getFullname() + "', SYSDATE)";
		log.info("The deleted user log  query is: " + impUserLog);
		try {
			db.executeDML(impUserLog);
		} catch (Exception e) {
			log.info("The user log have problem in inserting with: " + e.getMessage());
		}
		
		String patternDetailDelete = db.executeDML("DELETE FROM IMP_CLIENTPATTERNS_EMP_DETAIL WHERE MAINSN IN (SELECT SN FROM IMP_CLIENTPATTERNS_EMP_MAIN WHERE PATTERNSN = '" + pattern.getSn() + "')");
		if (patternDetailDelete.equalsIgnoreCase("1")) {
			String patternMainDelete = db.executeDML("DELETE FROM IMP_CLIENTPATTERNS_EMP_MAIN WHERE patternsn='" + pattern.getSn() + "'");
			if (patternMainDelete.equalsIgnoreCase("1")) {
				result = db.executeDML("DELETE FROM IMP_CLIENTPATTERNS WHERE SN='"+ pattern.getSn() + "'");
			}
		}
		db.endConnection();
		FacesMessage msg = null;
		if (result.equalsIgnoreCase("1")) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Delete rule",
					"Success");
			handleClientChange();
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error occured", result);
		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		this.clients = clients;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getImportScript() {
		return importScript;
	}

	public void setImportScript(String importScript) {
		this.importScript = importScript;
	}

	public DefaultStreamedContent getDownloadFile() {
		return downloadFile;
	}

	public void setDownloadFile(DefaultStreamedContent downloadFile) {
		this.downloadFile = downloadFile;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public ArrayList<Pattern> getPatternList() {
		return patternList;
	}

	public void setPatternList(ArrayList<Pattern> patternList) {

		this.patternList = patternList;
	}

	public String getSelectedRules() {
		return selectedRules;
	}

	public void setSelectedRules(String selectedRules) {
		this.selectedRules = selectedRules;
	}

	/*
	 * public DefaultStreamedContent getDownloadAllScript() {
	 * GenerateImportScript objGIS = new GenerateImportScript();
	 * 
	 * String scriptLocation = AIConstant.IMPORT_SCRIPT_DUMP_LOCATION_ZIPPED;
	 * String filename = client+"_import_scripts.zip";
	 * objGIS.generateAllScripts(scriptLocation,client,filename);
	 * 
	 * FileController objFC = new FileController(scriptLocation + filename);
	 * 
	 * setDownloadAllScript(objFC.getDownload()); return downloadAllScript; }
	 */

	public void setDownloadAllScript(DefaultStreamedContent downloadAllScript) {
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public Pattern getPattern() {
		if (pattern == null) {
			pattern = new Pattern();
		}
		return pattern;
	}

	public void setPattern(Pattern pattern) {
		this.pattern = pattern;
	}

	public void resetPattern() {
		pattern = new Pattern();
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {
		this.payers = payers;
	}

	public LinkedHashMap<String, String> getLayouts() {
		return layouts;
	}

	public void setLayouts(LinkedHashMap<String, String> layouts,String fileType) {
		String payer = pattern.getPayer();
		try{
		if (fileType != null && fileType != "" ) {
			
			String query="";
			/*if(fileType.compareTo("DATAFILE")==0)
			{*/
				query="select distinct LAYOUTID, DATATYPE, LAYOUTTYPE, LAYOUTDETAIL from aip_dashboard_pattern where "+ 
				 " layout_status!='WORKING' and activeflag='Y' and category_name ='"+fileType+"' and Upper(PAYOR)='"+payer+"'";
				 
				
				
		/*	
		 query = "SELECT distinct a.LAYOUTID, a.DATATYPE, b.LAYOUTTYPE, b.LAYOUTDETAIL FROM ("
					+ "  SELECT * FROM  IMP_LAYOUTS  WHERE Upper(PAYOR)='"
					+ payer
					+ "' and datatype not like 'Control Total' and layout_status!='WORKING' and activeflag='Y') A "
					+ " LEFT JOIN IMP_SUB_LAYOUTS B ON A.LAYOUTID=B.LAYOUTID and b.sublayoutid='1'";
			}
			else
			{
				 query = "SELECT distinct a.LAYOUTID, a.DATATYPE, b.LAYOUTTYPE, b.LAYOUTDETAIL FROM ("
							+ "  SELECT * FROM  IMP_LAYOUTS  WHERE Upper(PAYOR)='"
							+ payer
							+ "' and datatype like 'Control Total' and layout_status!='WORKING' and activeflag='Y') A "
							+ " LEFT JOIN IMP_SUB_LAYOUTS B ON A.LAYOUTID=B.LAYOUTID and b.sublayoutid='1'";
			}*/

			System.out.println("query : "+query);
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> layoutList = db.resultSetToListOfList(query);
			db.endConnection();

			layouts = new LinkedHashMap<String, String>();
			if (layoutList.size() > 0) {
				for (int i = 1; i < layoutList.size(); i++) {
					layouts.put(layoutList.get(i).get(0) +"-"+layoutList.get(i).get(1) + "-"
							+ layoutList.get(i).get(2) + "-"
							+ layoutList.get(i).get(3), layoutList.get(i)
							.get(0));
				}
			}
		
			
		
			}else {
			layouts = new LinkedHashMap<String, String>();
		}
		this.layouts = layouts;
		}catch(Exception e){
			displayErrorMessageToUser("Error occured. Please try again", "ERROR");
		}
	}

	/*public void populateLayouts() {
		layouts = new LinkedHashMap<String, String>();
		setLayouts(layouts);
	}*/

	public void listEmployerGroup (String patternsn) {
		log.info("Listing Employer Group...");
		ArrayList<String> listEmployerGroup = new ArrayList<String>();
		ConnectDB db = new ConnectDB();
		//String detailquery = "SELECT EMPGRP FROM imp_clientpatterns_emp_detail WHERE mainsn = (SELECT sn FROM imp_clientpatterns_emp_main WHERE patternsn = '"+patternsn+"')";
		String detailquery = "SELECT STANDARDEMPLOYERNAME FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" a "   
							+ "INNER JOIN imp_clientpatterns_emp_detail b ON a.STANDARDEMPLOYERID = b.EMPGRP " 
							+ "WHERE b.mainsn = (SELECT sn FROM imp_clientpatterns_emp_main WHERE patternsn = '"+patternsn+"')"; 

		String mainquery = "SELECT EMPLOYERGROUP FROM IMP_CLIENTPATTERNS WHERE sn = '"+patternsn+"'";
		log.info(detailquery + " " + mainquery);
		db.initialize();
		List<List<String>> listdetailquery = db.resultSetToListOfList(detailquery);
		List<List<String>> listmainquery = db.resultSetToListOfList(mainquery);
		db.endConnection();
		
		if (listdetailquery.size() > 1) {
			for (int i = 1; i < listdetailquery.size(); i++) {
				listEmployerGroup.add(listdetailquery.get(i).get(0));
				
			}
		} else {
			if (listmainquery.size() > 1) {
				log.info(listmainquery.size());
				log.info(listmainquery.get(0).get(0) + listmainquery.get(1).get(0));
				//listEmployer.add(listmainquery.get(1).get(0));
				for (int i = 1; i < listmainquery.size(); i++) {
					listEmployerGroup.add(listmainquery.get(i).get(0));
					
				}
			}
		}
		
		setSn(pattern.getSn());
		setListEmployer(listEmployerGroup);
		setEmployerGroups(employerGroups);
		
	}
	
	public void handleEmployerChange(String patternsn) {
		log.info("This is the employer change update...." + patternsn);
		employerGroups = new ArrayList<String>();
		setEmployerGroups(employerGroups);
		setSn(pattern.getSn());
	}
	
	public void handleInUseStatusChange(String patternsn) {
		log.info("This is the in use status change.. : " + patternsn);
		inuseStatus = new String();
		inuseStatusRemarks = new String();
		setSn(pattern.getSn());
		String query = "SELECT INUSE_STATUS FROM imp_clientpatterns WHERE SN = '"+getSn()+"'";
		log.info("This is the query for inuse status: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> inuseStatusList = db.resultSetToListOfList(query);
		db.endConnection();
		if (inuseStatusList.size() > 0) {
			inuseStatus = inuseStatusList.get(1).get(0);
			setInuseStatus(inuseStatus);			
			log.info("The inuse status is: " + this.inuseStatus);
		}
		
		query = "SELECT INUSE_STATUS_REMARKS FROM imp_clientpatterns WHERE SN = '"+getSn()+"'";
		log.info("This is the query for inuse status: " + query);
		db.initialize();
		List<List<String>> inuseStatusRemarksList = db.resultSetToListOfList(query);
		db.endConnection();
		if (inuseStatusRemarksList.size() > 0) {	
			inuseStatusRemarks = inuseStatusRemarksList.get(1).get(0);
			setInuseStatusRemarks(inuseStatusRemarks);			
			log.info("The inuse status remarks is: " + this.inuseStatusRemarks);
		}
		
		log.info("Opening dialog box");
		RequestContext.getCurrentInstance().execute("PF('dtUpdateInUseStatusDialog').show();");
	}
	
	public void handleEDIFlagChange(String patternsn) {
		log.info("This is the edi flag change.. : " + patternsn);
		ediFlagList = new ArrayList<String>();
		ediMapperList = new ArrayList<String>();
		
		setSn(pattern.getSn());
		setEdiFlagList(ediFlagList);
		setEdiMapperList(ediMapperList);
		setEdiFlag("Yes");		
		log.info("Opening edi dialog box");
		RequestContext.getCurrentInstance().execute("PF('dtUpdateEDIFlagDialog').show();");
	}
	
	public void instatusChange() {
		log.info("This is inuse status change:" + this.inuseStatus);
	}
	
	public void handlePayerChange(String fileType) {

		
		
		layouts = new LinkedHashMap<String, String>();
		setLayouts(layouts,fileType);
	}

	public void updateEmployerGroup() {
		
		String empPattern = "_";
		String result = "";
		log.info("Sn is: " + this.sn);
		if (empgrpSelected.size() > 0) {
			for (int i = 0; i < empgrpSelected.size(); i++) {

					empPattern = empPattern + empgrpSelected.get(i).substring(0, 3) + "_";
			
			}
		}
		String employer = "UPDATE IMP_CLIENTPATTERNS SET EMPLOYERGROUP='" + empPattern.replaceAll("\'", "\''") + "' WHERE SN='" + this.getSn() + "'";
		String mainEmployer = "UPDATE IMP_CLIENTPATTERNS_EMP_MAIN SET PATTERNSHORTNAME='" + empPattern.replaceAll("\'", "\''") + "' WHERE PATTERNSN='" + this.getSn() + "'";
		String deleteDetail = "DELETE FROM IMP_CLIENTPATTERNS_EMP_DETAIL WHERE MAINSN IN (SELECT SN FROM IMP_CLIENTPATTERNS_EMP_MAIN WHERE PATTERNSN='"+ this.getSn() +"')";
		
		log.info("The query for employer is: " + employer);
		log.info("The query for mainEmployer is: " + mainEmployer);
		log.info("The query for deleteDetail is: " + deleteDetail);

		ConnectDB db = new ConnectDB();
		db.initialize();
		
		try {
			
			result = db.executeDML(employer);
			if (result.equalsIgnoreCase("1")) {
				result = db.executeDML(mainEmployer);
				if (result.equalsIgnoreCase("1")) {
					result = db.executeDML(deleteDetail);
					for (int i = 0; i<empgrpSelected.size();i++) {
						String pattern_detail = "INSERT INTO imp_clientpatterns_emp_detail (sn,mainsn,empgrp) "
								+ "VALUES ('1', (SELECT sn FROM imp_clientpatterns_emp_main where patternsn='"+pattern.getSn()+"'), '" 
								+ empgrpSelected.get(i).replaceAll("\'", "\''") + "')";
						log.info("The pattern details query is: " + pattern_detail);
						result = db.executeDML(pattern_detail);
					}
				}
			}
		} catch (Exception e) {
			log.info("There is a problem while updating the employer group: " + e.getMessage());
		}
		db.endConnection();
		
		if (result.equalsIgnoreCase("1")) {
			setPatternList(objPRL.getPatternList());

			closeDialog();
			handleClientChange();
			displayInfoMessageToUser("Updated With Sucess", "Status");
			resetPattern();
		} else {
			displayErrorMessageToUser("Update Failed:" + result, "Status");
		}
	}

	public void updateInUseStatus() {		
		log.info("This is an inuse status update:");
		String updateInsueStatus = "UPDATE imp_clientpatterns SET INUSE_STATUS = '"+this.inuseStatus+"', INUSE_STATUS_REMARKS = '"+this.inuseStatusRemarks.replace("'", "''")+"' WHERE SN = '"+this.getSn()+"'";
		log.info("This is the update query for inuse status: " + updateInsueStatus);
		ConnectDB db = new ConnectDB();
		db.initialize();
		try {
			String result = db.executeDML(updateInsueStatus);
			if (result.equalsIgnoreCase("1")) {
				log.info("Inuse Status and remarks successfully updated");
				displayInfoMessageToUser("Updated With Sucess", "Status");
				handleClientChange();
			} else {
				displayErrorMessageToUser("Update Failed:" + result, "Status");
			}
		} catch (Exception e) {
			log.info("The error is: " + e.getMessage());
		}
	}
	
	public void updateEDIFlag() {		
		log.info("This is an edi flag update:");
		String flag = "";
		String mapper = "";
		if (this.ediFlag.equals("Yes") && !this.ediMapper.isEmpty()) {
			flag = "Y";
			mapper = this.ediMapper.replace("'", "''");
		} else if (this.ediFlag.equals("No")) {
			flag = "N";
			mapper = "";
		}
		String updateEDIFlag = "UPDATE imp_clientpatterns SET ediflag = '"+flag+"', edimapper = '"+mapper+"' WHERE SN = '"+this.getSn()+"'";
		log.info("This is the update query for edi flag: " + updateEDIFlag);
		ConnectDB db = new ConnectDB();
		db.initialize();
		try {
			String result = db.executeDML(updateEDIFlag);
			if (result.equalsIgnoreCase("1")) {
				log.info("EDI Flag successfully updated");
				displayInfoMessageToUser("Updated With Sucess", "Status");
				handleClientChange();
			} else {
				displayErrorMessageToUser("Update Failed:" + result, "Status");
			}
		} catch (Exception e) {
			log.info("The error is: " + e.getMessage());
		}
	}
	
	
	public void updateLayoutID() {

		String query = "UPDATE IMP_CLIENTPATTERNS SET LAYOUTID='"
				+ pattern.getLayoutID() + "', UPDATEDDATE = sysdate , UPDATEDBY = '"+this.userinfo.getFullname()+"' WHERE SN='" + pattern.getSn()
				+ "' ";
		
		String userLogQuery = "INSERT INTO IMP_CLIENTPATTERNS_HISTORY (SN,OLDLAYOUT,NEWLAYOUT,USERNAME,CHANGEDDATE) "
							+ " SELECT '"  
							+ pattern.getSn() + "',a.layoutid,'"
							+ pattern.getLayoutID() + "','"
							+ this.userinfo.getFullname() + "',SYSDATE FROM imp_clientpatterns a WHERE sn = '" + pattern.getSn() + "'";
		
		String impUserLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) " 
							+ " SELECT '1','LAYOUT_EDIT', 'PATTERNSN: " + pattern.getSn() + " | LAYOUT CHANGED FROM '||a.layoutid||' TO '||" + pattern.getLayoutID() + ", '" 
							+ this.userinfo.getFullname() + "', SYSDATE FROM imp_clientpatterns a WHERE sn = '" + pattern.getSn() + "'";
		
		log.info("The user log query for pattern is: " + userLogQuery);
		log.info("The imp log query for layout change is: " + impUserLog);
		ConnectDB db = new ConnectDB();
		db.initialize();
		
		try {
			db.executeDML(impUserLog);
			db.executeDML(userLogQuery);
		} catch (Exception e) {
			log.info("Problem while inserting the user log in pattern history table with: " + e.getMessage());
		}
		String result = db.executeDML(query);
		db.endConnection();

		if (result.equalsIgnoreCase("1")) {
			setPatternList(objPRL.getPatternList());

			closeDialog();
			handleClientChange();
			displayInfoMessageToUser("Updated With Sucess", "Status");
			resetPattern();
		} else {
			displayErrorMessageToUser("Update Failed:" + result, "Status");
		}
	}

	public ArrayList<Pattern> getFilteredPatterns() {
		return filteredPatterns;
	}

	public void setFilteredPatterns(ArrayList<Pattern> filteredPatterns) {

		this.filteredPatterns = filteredPatterns;
	}

	public ArrayList<String> getEmployerGroups() {
		return employerGroups;
	}

	public void setEmployerGroups(ArrayList<String> employerGroups) {
		
		/*String query = "SELECT DISTINCT empname FROM imp_employer_master WHERE CLIENTID='"
				+ getClient().split("-")[0] + "' order by 1";*/
		
		/*String query = "SELECT DISTINCT STANDARDEMPLOYERNAME FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" a " +
						"left JOIN cpd.cp_clientemployerrelationship@"+AIConstant.CPD_LINK+" b ON a.STANDARDEMPLOYERID = b.STANDARDEMPLOYERID WHERE b.STANDARDCLIENTID = '" + getClient().split("-")[0] + "' order by 1";*/
		String query = "SELECT DISTINCT STANDARDEMPLOYERNAME FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" WHERE STANDARDCLIENTID ='"+getClient().split("-")[0]+"' AND deleted = 0 ";
		log.info("This is the query for employer group: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> employeeList = db.resultSetToListOfList(query);
		db.endConnection();
		if (employeeList.size() > 0) {
			for (int i = 1; i < employeeList.size(); i++) {
				employerGroups.add(employeeList.get(i).get(0));

			}
		}
	}

	public ArrayList<String> getClPayors() {
		return clPayors;
	}

	public void setClPayors(ArrayList<String> payors) {
		this.clPayors = payors;
	}

	public ArrayList<String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(ArrayList<String> dataTypes) {
		this.dataTypes = dataTypes;
	}

	public Map<String, String> getFilterMap() {
		return filterMap;
	}

	public void setFilterMap(Map<String, String> filterMap) {
		this.filterMap = filterMap;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean filterByLayoutID(Object value, Object filter, Locale locale) {
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		return ((Comparable) value).compareTo(Integer.valueOf(filterText)) > 0;
	}

	@SuppressWarnings("unused")
	public void displayMessage() {
		RequestContext context = RequestContext.getCurrentInstance();
		String message = "Succesfully added new pattern for client " + client;
		displayInfoMessageToUser(message, "NEW PATTERN");
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		// RequestContext.getCurrentInstance().execute("patternTable.filter();");
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public void handleSave(Pattern obj) {
		String query = "update imp_clientpatterns set ignoreexception= '"
				+ obj.getIgnoreexception() + "', UPDATEDDATE = sysdate , UPDATEDBY = '"+this.userinfo.getFullname()+"' where sn='" + obj.getSn() + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();

		try {
			db.executeDML(query);
			db.endConnection();
			displayInfoMessageToUser("Successfully Updated",
					"Exception Ignored");
		} catch (Exception ex) {
			displayErrorMessageToUser("Update Failed", "Sorry");
		}

	}

	public String getCtllayoutID() {
		return ctllayoutID;
	}

	public void setCtllayoutID(String ctllayoutID) {
		this.ctllayoutID = ctllayoutID;
	}

	public Pattern getCtlpattern() {
		return ctlpattern;
	}

	public void setCtlpattern(Pattern ctlpattern) {
		this.ctlpattern = ctlpattern;
	}

	
	
	public void handleRemap(ValueChangeEvent event) {

		String oldLayoutID = event.getOldValue().toString();
		String query = "SELECT * FROM hi_legacy_transfer WHERE clientid='"
				+ this.client + "' AND AITABLENAME LIKE '%AI_" + oldLayoutID
				+ "_%'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				this.setTransferAffected(true);
			} else {
				this.setTransferAffected(false);
			}
		} else {
			this.setTransferAffected(false);
		}
	}

	public void setdatapattern(String patterntoUpdate) {
		getSessionData().setValidpattern(patterntoUpdate);
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 850);
		options.put("height", 700);
		options.put("contentWidth", 850);
		options.put("contentHeight", 700);
		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add("data");
		params.put("type", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add(this.client);
		params.put("clientid", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add("update");
		params.put("requesttype", list3);
		RequestContext.getCurrentInstance().openDialog("patternchecker",
				options, params);

	}

	public void updateDatapattern(Pattern ptt) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String impUserLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) "  
							+ " SELECT '1','PATTERN_EDIT', 'PATTERNSN: " + ptt.getSn() + " | OLD PATTERN: '||a.pattern|| ' | NEW LAYOUT: " + getSessionData().getValidpattern().replaceAll("\'", "\''") + "','"
							+ this.userinfo.getFullname() + "', SYSDATE FROM IMP_CLIENTPATTERNS a WHERE SN = " + ptt.getSn();
  
		String query = "UPDATE IMP_CLIENTPATTERNS SET pattern='"
				+ getSessionData().getValidpattern().replaceAll("\'", "''") + "', UPDATEDDATE = sysdate , UPDATEDBY = '"+this.userinfo.getFullname()+"' WHERE SN='"
				+ ptt.getSn() + "'";
		
		log.info("This is a imp User Log for pattern update: " + impUserLog);
		db.executeDML(impUserLog);
		String result = db.executeDML(query);
		db.endConnection();
		FacesMessage msg = null;
		if (result.equalsIgnoreCase("1")) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Pattern  Changed", "Old: " + ptt.getPattern() + ", New:"
							+ getSessionData().getValidpattern());

		}

		else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error Updating Pattern", result);
		}
		getSessionData().setValidpattern("");
		handleClientChange();
		FacesContext.getCurrentInstance().addMessage(null, msg);

	}

	
	public boolean isTransferAffected() {
		return isTransferAffected;
	}

	public void setTransferAffected(boolean isTransferAffected) {
		this.isTransferAffected = isTransferAffected;
	}

	public LinkedHashMap<String, String> getLayoutTypes() {
		return layoutTypes;
	}

	public void setLayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		this.layoutTypes = layoutTypes;
	}
	public void enableOptionall(Pattern pattern,String optionalSignal){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("UPDATE IMP_CLIENTPATTERNS SET isoverridden='"+optionalSignal+"', UPDATEDDATE=sysdate,UPDATEDBY='" + this.userinfo.getFullname() + "'  where sn='"+pattern.getSn()+"' ");

		db.endConnection();
		if(result.compareTo("1")==0){
			handleClientChange();
			displayInfoMessageToUser("Overridden Changed", "Enable Status");
			
			
		}else{
			displayErrorMessageToUser("Overridden Failed to enable.Please try again", "");
		}
	}
	
	
	public void openEditFlag(Pattern pattern)
	{
		System.out.println("coming");
		this.listofAppids = new ArrayList<>();
		this.selectedAppids = new ArrayList<>();

		this.patternUnderEdit = new Pattern();
		this.patternUnderEdit = pattern;
		System.out.println("Size : " + this.patternUnderEdit.getListofAppIds().size());
	
		this.selectedAppids = this.patternUnderEdit.getListofAppIds();
		handleFlagChange(pattern);
		RequestContext.getCurrentInstance().execute("PF('appidConfig').show();");
	}
	
	public void insertAppIDInformation(String sn, ConnectDB db)
	{
		for(int i=0;i<this.selectedAppids.size();i++)
		{
		String query = "Insert into imp_pattern_appid_reln(patternid, appid, created_date, created_by) values('"+sn+"','"+this.selectedAppids.get(i) + "', sysdate , '" + this.userinfo.getFullname() + "')";
		System.out.println(query);
		db.executeDML(query);
		}
	}

	public void handleFlagChange(Pattern pattern)
	{
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query ="";
		this.listofAppids = new ArrayList<>();
		
		
		System.out.println("da : " + pattern.getInterClientAppFlag());
		
		if(pattern.getInterClientAppFlag().compareTo("N")==0)
		{
			//query = "select distinct applicationid from cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" where legacyclientid = '"+this.client+"'";
			query = "SELECT distinct a.applicationid FROM cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" a left JOIN cpd.cp_clientstandardization@"+AIConstant.CPD_LINK+" b ON a.LEGACYCLIENTID = b.LEGACYCLIENTID WHERE b.STANDARDCLIENTID = '"+this.client+"'"; 
			
		}
		else
		{
			query = "select distinct applicationid from cpd.cp_clientapplication@"+AIConstant.CPD_LINK;
		}
		
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		log.info("App Id query is: " + query);
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					this.listofAppids.add(rs.get(i).get(0));
				}
			}
		}
		
	}


	
	public void changeClientFlag(Pattern pattern,String clientFlag){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("UPDATE IMP_CLIENTPATTERNS SET INTERCLIENTAPPFLAG='"+clientFlag+"', UPDATEDDATE=sysdate,UPDATEDBY='" + this.userinfo.getFullname() + "'  where sn='"+pattern.getSn()+"' ");

		db.endConnection();
		if(result.compareTo("1")==0){
			handleClientChange();
	//		handleFlagChange(pattern);
			displayInfoMessageToUser("INTERCLIENTAPP FLAG Changed", "Enable Status");
			
			
		}else{
			displayErrorMessageToUser("INTERCLIENTAPP FLAG Update Failed.Please try again", "");
		}
	}
	
	
	public void updateAppIds()
	{
		try
		{
		if(isAppidChanged())
		{
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query =  "delete from imp_pattern_appid_reln where patternid ='" + this.patternUnderEdit.getSn() + "'";
			String stat = db.executeDML(query);
			if(stat.compareTo("1")==0)
			{
				insertAppIDInformation(this.patternUnderEdit.getSn(), db);
				db.endConnection();
				String concatApps = "";
				
				this.patternUnderEdit.setConcatApps(concatApps);
				displayInfoMessageToUser("App ids Updated", "App id update");
				RequestContext.getCurrentInstance().execute("PF('appidConfig').hide();");
				
			}
		}
		}
		catch(Exception ex)
		{
			System.out.println("Error updating appids");
			displayErrorMessageToUser("Cannot Update", "Please Try again");
			
		}
	}

	public void handleSave(Pattern obj, String columnname) {
		String newValue = "";

		switch (columnname) {

		case "OPTIONALLY":
			newValue = obj.getOptionally();
			break;
		case "SKIPROWS":
			newValue = obj.getSkipRow();
			break;
		case "DELIMITER":
			newValue = obj.getDelimiter();
			break;
		case "OVERRIDDENDATE":
			newValue = obj.getOverridendate();
			break;

		default:
			newValue = "";
			break;
		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("UPDATE IMP_CLIENTPATTERNS SET "
				+ columnname + "='" + newValue.replaceAll("'", "''")
				+ "', UPDATEDDATE=sysdate,UPDATEDBY='" + this.userinfo.getFullname() + "' WHERE sn='" + obj.getSn() + "'");

		db.endConnection();
		FacesMessage msg = null;
		if (result.equalsIgnoreCase("1")) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, columnname
					+ " Changed", "New value:" + newValue);
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error Updating " + columnname, result);
		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void saveCtlfirstString(Pattern pattern,String ctlfirststring){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("UPDATE IMP_CLIENTPATTERNS SET CTL_FIRST_STRING='"+ctlfirststring+"', UPDATEDDATE=sysdate,UPDATEDBY='" + this.userinfo.getFullname() + "' where sn='"+pattern.getSn()+"'  ");

		db.endConnection();
		if(result.compareTo("1")==0){
			displayInfoMessageToUser("Ctl first string changed to "+ctlfirststring, "CTL Status");
		}else{
			displayErrorMessageToUser("Failed to save ctl first string. Try again !!", "CTL Status");
		}
		
	}
	public void saveCtlsecondString(Pattern pattern,String ctlsecondstring){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("UPDATE IMP_CLIENTPATTERNS SET CTL_SECOND_STRING='"+ctlsecondstring+"', UPDATEDDATE=sysdate,UPDATEDBY='" + this.userinfo.getFullname() + "' where sn='"+pattern.getSn()+"'  ");

		db.endConnection();
		if(result.compareTo("1")==0){
			displayInfoMessageToUser("Ctl second string changed to "+ctlsecondstring, "CTL Status");
		}else{
			displayErrorMessageToUser("Failed to save ctl second string.Try again !!", "CTL Status");
		}
		
		
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public ArrayList<String> getListofAppids() {
		return listofAppids;
	}

	public void setListofAppids(ArrayList<String> listofAppids) {
		this.listofAppids = listofAppids;
	}

	public ArrayList<String> getSelectedAppids() {
		return selectedAppids;
	}

	public void setSelectedAppids(ArrayList<String> selectedAppids) {
		this.selectedAppids = selectedAppids;
	}

	public boolean isAppidChanged() {
		return appidChanged;
	}

	public void setAppidChanged(boolean appidChanged) {
		this.appidChanged = appidChanged;
	}
	

}
