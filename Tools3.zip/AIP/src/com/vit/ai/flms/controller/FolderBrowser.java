/* 
 *Class Name : FolderBrowser.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.File;
import java.io.FileFilter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import java.util.List;

import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 12 Jan 2015
 */
public class FolderBrowser implements Serializable {

	private static final long serialVersionUID = 1L;
	private TreeNode root;
	private boolean loop;
	private List<TreeNode> list = new ArrayList<TreeNode>();

	public FolderBrowser(String filea, boolean _loop) {
		this.loop = _loop;
		root = new DefaultTreeNode("Root", null);
		showDir(root, new File(filea));
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void showDir(TreeNode tn, File file) {
		{
			File[] files = file.listFiles();
			FileFilter fileFilter = new FileFilter() {

				@Override
				public boolean accept(File file) {
					// TODO Auto-generated method stub
					return file.getAbsolutePath() != null;
				}
			};
			files = file.listFiles(fileFilter);
			Arrays.sort(files, new Comparator() {

				@Override
				public int compare(Object f1, Object f2) {
					// TODO Auto-generated method stub
					return ((File) f1).getName().toLowerCase().compareTo(
							((File) f2).getName().toLowerCase()
							);
				}

			});
			if (files != null) {

				for (File f : files) {

					if (f.isDirectory()) {

						list.add(new DefaultTreeNode((f), tn));

						if (loop == true) {
							list.get(list.size() - 1).setSelectable(false);
							showDir(list.get(list.size() - 1), f);
						}

					} else {

						list.add(new DefaultTreeNode((f), tn));
					}

				}

			}

		}
	}

	public TreeNode getRoot() {

		return root;
	}
}
