package com.vit.ai.flms.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.model.DualListModel;

import com.vit.ai.flms.model.SecondHashKeyModel;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;


@ManagedBean
@ViewScoped
public class SecondHashKey extends AbstractController implements Serializable {

	private static final long serialVersionUID = 5158770295010936590L;
	private String layoutid="";
	private ArrayList<SecondHashKeyModel> listofFields; 
	private ArrayList<SecondHashKeyModel> listofSelectedFields; 
	 
	private DualListModel<SecondHashKeyModel> dualFields;
	
	public String getLayoutid() {
		return layoutid;
	}
	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}
	public ArrayList<SecondHashKeyModel> getListofFields() {
		return listofFields;
	}
	public void setListofFields(ArrayList<SecondHashKeyModel> listofFields) {
		this.listofFields = listofFields;
	}
	

		public SecondHashKey()
		{
			if(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid")!=null)
			{
				this.layoutid = (String)FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid");
				System.out.println("Layout ID : " + this.layoutid);
			}
		int stat = 	checkifAlreadyExists();
		
		if(stat ==0)
		{
			this.listofFields = new ArrayList<>();
			this.listofSelectedFields = new ArrayList<>();
			init();
		}
		else
		{

			try {
				FacesContext.getCurrentInstance().getExternalContext().redirect("HashInformation.jsf");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
		
		public int checkifAlreadyExists()
		{
			int count = 0;
			String query = "select count(*) from imp_layouts_fields where layoutid = '"+this.layoutid+"' and uniqueHashFlag = 'Y'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			if(rs!=null){
				if(rs.size()>1)
				{
					if(Integer.parseInt(rs.get(1).get(0))>0)
					{
						count = 1;
					}
					else
					{
						count = 0;
					}
				}
			}
			return count;
		}
		
		
		public void init()
		{
			
			String query = "select sn,columnname,uniqueHashFlag from imp_layouts_fields where layoutid='"+this.layoutid+"'";
			System.out.println("Query : " + query);
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			
			if(rs!=null)
			{
				if(rs.size()>1)
				{
					for(int i=1;i<rs.size();i++)
					{
					SecondHashKeyModel hashobject = new SecondHashKeyModel(rs.get(i).get(1), rs.get(i).get(0), rs.get(i).get(2));
					this.listofFields.add(hashobject);
					}
				}
			}
			
			this.dualFields = new DualListModel<SecondHashKeyModel>(this.listofFields,this.listofSelectedFields);
			
			
		}
		public ArrayList<SecondHashKeyModel> getListofSelectedFields() {
			return listofSelectedFields;
		}
		public void setListofSelectedFields(ArrayList<SecondHashKeyModel> listofSelectedFields) {
			this.listofSelectedFields = listofSelectedFields;
		}
		public DualListModel<SecondHashKeyModel> getDualFields() {
			return dualFields;
		}
		public void setDualFields(DualListModel<SecondHashKeyModel> dualFields) {
			this.dualFields = dualFields;
		}
		
		
		public void generateSecondHashKey()
		{
			ConnectDB db = new ConnectDB();
			try
			{
		
			db.initialize();
			
			if(!this.dualFields.getTarget().isEmpty())
			{
				for(int i=0;i<this.dualFields.getTarget().size();i++)
				{
					String fieldsn = (String)this.dualFields.getTarget().get(i).getFieldsn();
					String query= "update imp_layouts_fields set uniquehashflag='Y' where sn='"+fieldsn +"'";
					System.out.println("Second Hash Key Query :  " + query);
					db.executeDML(query);
					}
				
				try {
					FacesContext.getCurrentInstance().getExternalContext().redirect("HashInformation.jsf");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			}
			catch(Exception ex)
			{
				
				System.out.println("ERROR : " + ex.toString());
			}
			finally
			{
				db.endConnection();
			}
		}
}
