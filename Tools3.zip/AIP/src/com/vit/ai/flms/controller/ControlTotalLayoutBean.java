/*
 * Author: Aashish Dhungana
 * 
 *Class Name : ControlTotalLayoutBean.java
 *
 *Version : 1.0
 *
 *Date: 2015/01/07
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.primefaces.context.RequestContext;

import com.vit.ai.commons.model.HRPayerBean;
import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.flms.model.ControlTotal;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for adding control total layouts
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 07 Jan 2015
 */
@ManagedBean
@ViewScoped
public class ControlTotalLayoutBean extends AbstractController implements
		Serializable {

	protected static final long serialVersionUID = -7135697835606680951L;
	protected String layoutid;
	protected String payer;
	protected String dataType;
	protected String layoutType;
	protected String layoutDetail;
	protected String punchChar;
	protected String optEnc;
	protected String skpRow = "0";
	protected String skpLastRow = "0";
	protected String layoutDesc;
	protected String srcInfo;
	protected String subLayoutDesc;
	protected String formatType = "";
	protected boolean validationComplete = false;
	protected LinkedHashMap<String, String> payers;
	protected LinkedHashMap<String, String> layouttypes;
	protected ArrayList<ControlTotal> listoffields;
	protected ArrayList<String> datatypeAutocomplete;
	protected int delimiterentry_count = 0;
	protected ArrayList<String> samples;
	@ManagedProperty(value = "#{userInformation}")
	protected UserInformation userinfo;
	@ManagedProperty(value = "#{loginbean}")
	protected ViewsParameters sessionData;
	protected String sumflag = "N";

	public String getSumflag() {
		return sumflag;
	}

	public void setSumflag(String sumflag) {
		this.sumflag = sumflag;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getLayoutDetail() {
		return layoutDetail;
	}

	public void setLayoutDetail(String layoutDetail) {
		this.layoutDetail = layoutDetail;
	}

	public String getPunchChar() {
		return punchChar;
	}

	public void setPunchChar(String punchChar) {
		this.punchChar = punchChar;
	}

	public String getOptEnc() {
		return optEnc;
	}

	public void setOptEnc(String optEnc) {
		this.optEnc = optEnc;
	}

	public String getSkpRow() {
		return skpRow;
	}

	public void setSkpRow(String skpRow) {
		this.skpRow = skpRow;
	}

	public String getLayoutDesc() {
		return layoutDesc;
	}

	public void setLayoutDesc(String layoutDesc) {
		this.layoutDesc = layoutDesc;
	}

	public String getSrcInfo() {
		return srcInfo;
	}

	public void setSrcInfo(String srcInfo) {
		this.srcInfo = srcInfo;
	}

	public String getSubLayoutDesc() {
		return subLayoutDesc;
	}

	public void setSubLayoutDesc(String subLayoutDesc) {
		this.subLayoutDesc = subLayoutDesc;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public boolean isValidationComplete() {
		return validationComplete;
	}

	public void setValidationComplete(boolean validationComplete) {
		this.validationComplete = validationComplete;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {
		this.payers = payers;
	}

	public ArrayList<ControlTotal> getListoffields() {
		return listoffields;
	}

	public ArrayList<String> getSamples() {
		return samples;
	}

	public void setSamples(ArrayList<String> samples) {
		this.samples = samples;
	}

	public void setListoffields(ArrayList<ControlTotal> listoffields) {
		this.listoffields = listoffields;
	}

	public ControlTotalLayoutBean() {
		this.datatypeAutocomplete = new ArrayList<String>();

		this.datatypeAutocomplete.add("NUMBER");
		// this.datatypeAutocomplete.add("CHAR");
		this.datatypeAutocomplete.add("VARCHAR2");
		this.datatypeAutocomplete.add("DATE");
		// this.datatypeAutocomplete.add("FLOAT");
		// this.datatypeAutocomplete.add("INTEGER");
		// this.datatypeAutocomplete.add("CURRENCY");
		this.samples = new ArrayList<String>();
		this.samples.add("Vertical_Control_Total_Layout.PNG");
		this.samples.add("Horizontal_Control_Total_Layout.PNG");
		this.listoffields = new ArrayList<ControlTotal>();
		setDataType("Control Total");
		setSubLayoutDesc("CONTROLTOTAL");
		HRPayerBean objHRP = new HRPayerBean();
		this.payers = objHRP.getPayers();
		LayoutType objLayoutType = new LayoutType();
		this.layouttypes = objLayoutType.getlayoutTypes();

		for (int i = 0; i < 5; i++) {
			addRows();
		}

	}

	public void addRows() {

		this.listoffields.add(new ControlTotal());
	}

	public LinkedHashMap<String, String> getLayouttypes() {
		return layouttypes;
	}

	public void setLayouttypes(LinkedHashMap<String, String> layouttypes) {
		this.layouttypes = layouttypes;
	}

	public ArrayList<String> getDatatypeAutocomplete() {
		return datatypeAutocomplete;
	}

	public void setDatatypeAutocomplete(ArrayList<String> datatypeAutocomplete) {
		this.datatypeAutocomplete = datatypeAutocomplete;
	}

	public ArrayList<String> completeDatatype(String query) {
		return this.datatypeAutocomplete;
	}

	public void autocompleteDelimiter(String value) {
		this.delimiterentry_count++;
		if (this.delimiterentry_count == 1) {
			System.out.println(value);
			for (int i = 0; i < this.listoffields.size(); i++) {
				this.listoffields.get(i).setLayouttype(value);
			}
		}

	}

	public int getDelimiterentry_count() {
		return delimiterentry_count;
	}

	public void setDelimiterentry_count(int delimiterentry_count) {
		this.delimiterentry_count = delimiterentry_count;
	}

	public String verifyLayout() {

		if (Integer.parseInt(this.calculateLayoutDetail()) == 0) {
			displayErrorMessageToUser("Nothing to Add", "Error");
			this.validationComplete = false;
		}
		String message = "";
		this.validationComplete = false;
		ConnectDB db = new ConnectDB();
		String oldLayoutDetails = "";
		String newLayoutDetails = getNewLayoutDetails();
		if (newLayoutDetails.isEmpty()) {
			this.validationComplete = false;
			return "";
		}

		String query = "SELECT LAYOUTID FROM IMP_LAYOUTS WHERE PAYOR='"
				+ payer.split("~")[0]
				+ "' and datatype='Control Total'  GROUP BY LAYOUTID";

		db.initialize();
		List<List<String>> listOfLayoutID = db.resultSetToListOfList(query);
		List<List<String>> listDetails;

		if (listOfLayoutID.size() > 1) {

			for (int i = 1; i < listOfLayoutID.size(); i++) {

				query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||STARTPOS||ENDPOS||FIELDLINENUMBER||FIELDDELIMITER||FIELDPOSITION  "
						+ " FROM IMP_LAYOUTS_FIELDS "
						+ " WHERE LAYOUTID ='"
						+ listOfLayoutID.get(i).get(0)
						+ "' AND SUBLAYOUTID='1' "
						+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";

				oldLayoutDetails = "";

				listDetails = db.resultSetToListOfList(query);
				if (listDetails.size() > 1) {
					for (int j = 1; j < listDetails.size(); j++) {
						oldLayoutDetails = oldLayoutDetails
								+ listDetails.get(j).get(0);

					}
				} else {
					message = "Validation Complete";
					this.validationComplete = true;
					break;
				}

				if (oldLayoutDetails.equalsIgnoreCase(newLayoutDetails)) {

					message = "Exact Duplicate of LayoutID:"
							+ listOfLayoutID.get(i).get(0);

					this.validationComplete = false;
					break;
				} else {
					message = "Validation Complete";
					this.validationComplete = true;
				}

			}
		} else {
			message = "validation Complete";

			this.validationComplete = true;
		}
		db.endConnection();
		displayInfoMessageToUser(message, "");
		return message;

	}

	public String getNewLayoutDetails() {
		String content = "";
		for (int i = 0; i < this.listoffields.size(); i++) {
			if (!this.listoffields.get(i).getColumnname().isEmpty()) {
				if (this.listoffields.get(i).getLayouttype()
						.compareTo("Fixed length") == 0) {

					try {
						String sp = this.listoffields.get(i).getPosition()
								.split(",")[0].replaceAll("\\(", "");
						String ep = this.listoffields.get(i).getPosition()
								.split(",")[1].replaceAll("\\)", "");
						int startPos = Integer.parseInt(sp);

						int endPos = Integer.parseInt(ep);

						content = content
								+ this.listoffields.get(i).getColumnname()
								+ this.listoffields.get(i).getDatatype()
								+ this.listoffields.get(i).getDateFormat()
								+ startPos + endPos
								+ this.listoffields.get(i).getIndex()
								+ this.listoffields.get(i).getLayouttype() + "";
					} catch (Exception ex) {
						displayErrorMessageToUser("Error in Input", "Error");
						this.validationComplete = false;
						return "";
					}
				}

				else {

					String indext = String.valueOf(this.listoffields.get(i)
							.getIndex());

					content = content
							+ this.listoffields.get(i).getColumnname()
							+ this.listoffields.get(i).getDatatype()
							+ this.listoffields.get(i).getDateFormat() + ""
							+ "" + indext
							+ this.listoffields.get(i).getLayouttype()
							+ this.listoffields.get(i).getColno();
				}

			}
		}

		return content;
	}

	public void addLayout() {
		verifyLayout();
		if (this.validationComplete) {
			ConnectDB db = new ConnectDB();
			db.initialize();
			String payerName = payer.split("~")[0];
			String payerId = payer.split("~")[1];
			String shortName = payer.split("~")[2];
			String username = getUserinfo().getFullname();
			System.out.println("User : " + username);
			String query = "SELECT MAX(LAYOUTID) +1 FROM IMP_LAYOUTS";
			String sn = "0";
			List<List<String>> snList = db.resultSetToListOfList(query);
			if (snList.size() > 1) {
				sn = snList.get(1).get(0);
				setLayoutid(sn);
			} else {
				sn = "0";
			}
			String query1 = "Insert into imp_layouts(LAYOUTID,PAYOR,PAYORID,DATATYPE,PUCHCHARFLAG,OPTIONALLY,SKIPROW,LAYOUTDESCIPTION,SOURCEINFO,USERLOG,SHORTPAYOR,ACTIVEFLAG,LAYOUT_STATUS,TRAILERSKIP,ENTRYDATE)"
					+ "Values ('"
					+ sn
					+ "','"
					+ payerName
					+ "','"
					+ payerId
					+ "','"
					+ this.dataType.toUpperCase()
					+ "','"
					+ this.punchChar
					+ "','"
					+ this.optEnc
					+ "','"
					+ this.skpRow
					+ "','"
					+ this.layoutDesc
					+ "','"
					+ this.srcInfo
					+ "','"
					+ username
					+ "','"
					+ shortName
					+ "','Y','WORKING','"
					+ this.skpLastRow
					+ "', sysdate " 
					+ ")";

			db.executeDML(query1);
			String query2 = "Insert into imp_sub_layouts(LAYOUTID,SUBLAYOUTID,LAYOUTTYPE,LAYOUTDETAIL,SUBLAYOUTDESC,SUMFLAG)"
					+ "values('"
					+ sn
					+ "','1','"
					+ this.formatType.toUpperCase()
					+ "','"
					+ calculateLayoutDetail()
					+ "','"
					+ this.subLayoutDesc
					+ "','" + this.sumflag + "')";

			db.executeDML(query2);

			int columnid = 1;
			String query3 = "";
			for (int i = 0; i < this.listoffields.size(); i++) {
				if (!this.listoffields.get(i).getColumnname().isEmpty()) {
					if (this.listoffields.get(i).getLayouttype()
							.compareTo("Fixed length") != 0) {
						query3 = "Insert into imp_layouts_fields(LAYOUTID,SUBLAYOUTID,COLUMNID,COLUMNNAME,DATATYPE,DATETYPEDETIAL,FIELDLENGTH,FIELDLINENUMBER,FIELDDELIMITER,FIELDPOSITION)"
								+ "values('"
								+ sn
								+ "','1','"
								+ columnid
								+ "','"
								+ this.listoffields.get(i).getColumnname()
								+ "','"
								+ this.listoffields.get(i).getDatatype().toUpperCase()
								+ "','"
								+ this.listoffields.get(i).getDateFormat()
								+ "','100','"
								+ this.listoffields.get(i).getIndex()
								+ "','"
								+ this.listoffields.get(i).getLayouttype()
								+ "','"
								+ this.listoffields.get(i).getColno()
								+ "')";
						columnid++;
						db.executeDML(query3);
					} else {
						String sp = this.listoffields.get(i).getPosition()
								.split(",")[0].replaceAll("\\(", "");
						int startPos = Integer.parseInt(sp);
						String ep = this.listoffields.get(i).getPosition()
								.split(",")[1].replaceAll("\\)", "");
						int endPos = Integer.parseInt(ep);
						query3 = "Insert into imp_layouts_fields(LAYOUTID,SUBLAYOUTID,COLUMNID,COLUMNNAME,DATATYPE,DATETYPEDETIAL,FIELDLENGTH,FIELDLINENUMBER,FIELDDELIMITER,startpos,endpos)"
								+ "values('"
								+ sn
								+ "','1','"
								+ columnid
								+ "','"
								+ this.listoffields.get(i).getColumnname()
								+ "','"
								+ this.listoffields.get(i).getDatatype().toUpperCase()
								+ "','"
								+ this.listoffields.get(i).getDateFormat()
								+ "','100','"
								+ this.listoffields.get(i).getIndex()
								+ "','"
								+ this.listoffields.get(i).getLayouttype()
								+ "','" + startPos + "','" + endPos + "')";
						columnid++;
						System.out.println("Query 3 : " + query3);
						String result = db.executeDML(query3);
						System.out.println(result);

					}
				}

			}
			db.endConnection();
			this.sessionData.setNewAdditionComplete(true);
			RequestContext.getCurrentInstance().closeDialog("addcontroltotal");
		}

	}

	public String getSkpLastRow() {
		return skpLastRow;
	}

	public void setSkpLastRow(String skpLastRow) {
		this.skpLastRow = skpLastRow;
	}

	public String calculateLayoutDetail() {

		String layoutdetail = "";
		int count = 0;
		for (int i = 0; i < this.listoffields.size(); i++) {
			if (!this.listoffields.get(i).getColumnname().isEmpty()) {
				count++;
			}
		}
		layoutdetail = String.valueOf(count);
		return layoutdetail;
	}

}
