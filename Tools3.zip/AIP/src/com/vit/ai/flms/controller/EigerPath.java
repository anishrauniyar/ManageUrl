/*
 *Class Name : EigerPath.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ValueChangeEvent;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.event.SelectEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.TreeNode;
import org.primefaces.model.tagcloud.DefaultTagCloudItem;
import org.primefaces.model.tagcloud.DefaultTagCloudModel;
import org.primefaces.model.tagcloud.TagCloudItem;
import org.primefaces.model.tagcloud.TagCloudModel;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.utils.AbstractController;

/**
 * Controller Class for Eiger path browser
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 23 Jan 2015
 */
@ManagedBean
@ViewScoped
public class EigerPath extends AbstractController implements Serializable {

	private static final long serialVersionUID = 769666004936122036L;
	private static Logger log = Logger.getLogger(EigerPath.class.getName());
	private TreeNode source;
	private TreeNode selectedSource;
	private DefaultStreamedContent pdfmedia;
	private ArrayList<String> clients;
	private String client = "";
	private String path = "";
	private String topTen = "";
	private String lastTen = "";
	private String textFiles = "";
	private static String runCommand;
	boolean isthisexcelFile = false;
	private String excelFile = "";
	private TagCloudModel model;
	private String textfilename = "";
	private DefaultStreamedContent downloadSample;
	private DefaultStreamedContent downloadFile;
	private DefaultStreamedContent downloadTextconvertedFile;
	private String tempFilename = "";

	public String getTextfilename() {
		return textfilename;
	}

	public void setTextfilename(String textfilename) {
		this.textfilename = textfilename;
	}

	public TagCloudModel getModel() {
		return model;
	}

	public String getExcelFile() {
		return excelFile;
	}

	public void setExcelFile(String excelFile) {

		System.out.println("---Excel File Recieved : " + excelFile + "--------");
		this.excelFile = excelFile;
	}

	public boolean isIsthisexcelFile() {
		return isthisexcelFile;
	}

	public void setIsthisexcelFile(boolean isthisexcelFile) {
		this.isthisexcelFile = isthisexcelFile;
	}

	public String getTextFiles() {
		return textFiles;
	}

	public void setTextFiles(String textFiles) {
		this.textFiles = textFiles;
	}

	public String getTopTen() {
		return topTen;
	}

	public void setTopTen(String topTen) {
		this.topTen = topTen;
	}

	public String getLastTen() {
		return lastTen;
	}

	public void setLastTen(String lastTen) {
		this.lastTen = lastTen;
	}

	public EigerPath() {
		try {

			model = new DefaultTagCloudModel();
			this.clients = new ArrayList<>();
			String command = "ls -dt " + AIConstant.EIGER_PATH
					+ "*/| sort -h|sed 's:" + AIConstant.EIGER_PATH + "::g'";
			RuntimeExecutor rt = new RuntimeExecutor(
					AIConstant.DASHBOARD_SERVER_NAME);
			String[] listofClients = rt.runeigerCommand(command).toString()
					.split("\\++");
			for (int i = 0; i < listofClients.length; i++) {
				clients.add(listofClients[i].replace("/", ""));
			}
			rt.endProcess();

		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(), "Client Not Found");
		}
	}

	public TreeNode getSource() {
		return source;
	}

	public void setSource(TreeNode source) {
		this.source = source;
	}

	public TreeNode getSelectedSource() {
		return selectedSource;
	}

	public void setSelectedSource(TreeNode selectedSource) {
		this.selectedSource = selectedSource;
	}

	public DefaultStreamedContent getPdfmedia() {
		return pdfmedia;
	}

	public void setPdfmedia(DefaultStreamedContent pdfmedia) {
		this.pdfmedia = pdfmedia;
	}

	public void prepareCommand() {
		this.topTen = "";
		this.lastTen = "";
		this.tempFilename = "";
		// setPdfmedia(prepDownload(getSelectedSource().toString()));
		System.out.println("PREPARING COMMAND OUT : ");
		System.out.println("----Preparing Command-----" );
		setTextfilename("");
		model = new DefaultTagCloudModel();
		
		System.out.println("---Selected Source : " + getSelectedSource().toString());
		if (getSelectedSource().toString() != null
				|| getSelectedSource().toString() != "") {
			try {

				String file1 = getSelectedSource().toString();

				String ext = getFileExtension(file1);
				log.info("-----File Extention :-------- " + ext);

				if (ext.toLowerCase().equals("xls")
						| ext.toLowerCase().equals("xlsx")) {
					System.out
							.println("This is excel file and is converting into text file");
					isthisexcelFile = true;
					this.setExcelFile(getSelectedSource().toString());

				} else {

					isthisexcelFile = false;
					displayfirstandlastRecord(this.getSelectedSource()
							.toString());

				}
			} catch (InterruptedException e) {

				displayErrorMessageToUser("File not found", "Folder Browser ");
			}
			RequestContext.getCurrentInstance().execute(
					"PF('eigerDialog').show();");
		}

	}

	private static String getFileExtension(String file) {
		String fileName = new File(file).getName();
		log.info("------File Recieved : " + file + "-----");

		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		else
			return "";

	}

	public void xlstoTxtConvertor() throws InterruptedException {
		try {
			model = new DefaultTagCloudModel();
			if (this.getExcelFile() == null || this.getExcelFile() == "") {
				displayErrorMessageToUser("Excel File not found",
						"Excel Convertor Status");
				return;
			} else {
				runCommand = AIConstant.shFilelocation + "./xls2txt -i " + "\""
						+ this.getExcelFile() + "\"" + " -d " + "\"" + "|"
						+ "\"" + " -o \""
						+ AIConstant.EXCELTOTEXT_TEMP_LOCATION + "\"";
				RuntimeExecutor rt = new RuntimeExecutor(
						AIConstant.DASHBOARD_SERVER_NAME);
				String listoftextfiles = rt.runSimpleCommand(runCommand);
				if (listoftextfiles.trim().contains(
						"Attempting with other route")) {
					displayInfoMessageToUser(listoftextfiles
							.replace("null", "").trim(), "Excel Convertor");
				}
				if (listoftextfiles.toString().contains("|")) {
					String[] files = listoftextfiles.toString().split("\\|");
					for (int i = 2; i < files.length; i++) {
						System.out.println(files[i]);
						textFiles += files[i];
						textFiles += "\n";
						model.addTag(new DefaultTagCloudItem(files[i]
								.toString().trim(), 2));
					}

					displayfirstandlastRecord(files[2].toString().trim());
					setTextfilename(files[2].toString().trim());

				}
				listoftextfiles = "";
				rt.endProcess();

				RequestContext.getCurrentInstance().execute(
						"PF('eigerDialog').show();");
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured.Please try again "
							+ e.getMessage(), "Error");
		}
	}

	public void onSelect(SelectEvent event) {
		System.out.println("Selecting ------" + event.getClass());
		TagCloudItem item = (TagCloudItem) event.getObject();
		setTextfilename(item.getLabel());
		System.out.println("Text File name : " + this.textfilename);
		try {
			displayfirstandlastRecord(item.getLabel().toString().trim());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			displayErrorMessageToUser("File Not Found", "Excel Convertor");
		}

	}

	/*
	 * public DefaultStreamedContent prepDownload(String fileName) { File file =
	 * new File(fileName); InputStream input = null; try { input = new
	 * FileInputStream(file); } catch (FileNotFoundException e) {
	 * displayErrorMessageToUser(e.toString(), "File Not Found"); }
	 * ExternalContext externalContext = FacesContext.getCurrentInstance()
	 * .getExternalContext(); DefaultStreamedContent to_retContent = new
	 * DefaultStreamedContent( input,
	 * externalContext.getMimeType(file.getName()), file.getName()); return
	 * to_retContent; }
	 */

	public ArrayList<String> getClients() {
		return clients;
	}

	public void setClients(ArrayList<String> clients) {
		this.clients = clients;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public void reset() {
		this.topTen = "";
		this.lastTen = "";

	}

	public void change(ValueChangeEvent vchange) {
		setSelectedSource(null);

		client = (vchange.getNewValue().toString());
		String path = AIConstant.EIGER_PATH + client;
		// String path = "O:\\data1";
		FolderBrowser bs = new FolderBrowser(path, true);
		source = bs.getRoot();

	}

	public void displayfirstandlastRecord(String sourcefile)
			throws InterruptedException {
		
		
		System.out.println("Display sample records : " + sourcefile);
		this.tempFilename = "";
		RuntimeExecutor objRT = new RuntimeExecutor(
				AIConstant.DASHBOARD_SERVER_NAME);
		try {
			File tempfile = new File(sourcefile);
			String headcmd = "head -15 \"" + sourcefile.toString() + "\" | tee " + AIConstant.EXCELTOTEXT_TEMP_LOCATION
					+ "/sample_" + tempfile.getName();
			String tailcmd = "tail -15 \"" + sourcefile.toString() + "\" | tee -a  " + AIConstant.EXCELTOTEXT_TEMP_LOCATION
					+ "/sample_" + tempfile.getName();
			
			System.out.println("Head : " + headcmd);
			System.out.println("Head : " + tailcmd);
			String testfile = "file " + "\"" + sourcefile.toString() + "\""
					+ "| grep " + "\"ASCII\\|UTF-8" + "\"";
			String status = objRT.runSimpleCommand(testfile);
			System.out.println("status: " + status);
			if (status.isEmpty() || status == null) {
				System.out.println("This is a binary file: ");
				this.topTen = "";
				this.lastTen = "";
				objRT.endProcess();
				return;
			}
			topTen = objRT.runSimpleCommand(headcmd).replaceAll("\f", "\n");
			lastTen = objRT.runSimpleCommand(tailcmd).replaceAll("\f", "\n");
			
		
			
			System.out.println("Writing to a file----" + sourcefile);
			
			File samplefile = new File(AIConstant.EXCELTOTEXT_TEMP_LOCATION
					+ "/sample_" + tempfile.getName());
			setTempFilename(tempfile.getName());
			if (samplefile.exists()) {
				samplefile.delete();
			}
				
				System.out.println("Temp filename : " + this.tempFilename);
				samplefile.createNewFile();
				FileWriter fW = new FileWriter(samplefile.getAbsoluteFile());
				BufferedWriter bW = new BufferedWriter(fW);
				bW.write("************************** Original File Path: "
						+ sourcefile.toString() + " **************************");
				bW.newLine();
				bW.write("************************************************************ Top 15 sample data ************************************************************");
				bW.newLine();
				bW.write(topTen);
				bW.newLine();
				bW.write("************************************************************ Last 15 sample data ************************************************************");
				bW.newLine();
				bW.write(lastTen);
				bW.close();

			
		

		} catch (Exception ex) {
			
			
			displayErrorMessageToUser("File not found.Please try again",
					"Folder browser");
		}

		if (topTen.isEmpty() && lastTen.isEmpty()) {
			objRT.endProcess();
			displayErrorMessageToUser("File not found", "Folder browser");
			return;
		}
		System.out.println();
		objRT.endProcess();

	}

	public DefaultStreamedContent getDownloadSample() {
		try{
		if (tempFilename != "") {
			FileController objFC = new FileController(
					AIConstant.EXCELTOTEXT_TEMP_LOCATION + "/sample_"
							+ tempFilename);

			setDownloadSample(objFC.getDownload());
		} else {
			displayErrorMessageToUser("File Not Found. Please select file",
					"Sample Data");
		}
		}catch(Exception e){
			displayErrorMessageToUser("Error occured. Please try again", "ERROR");
		}
		return downloadSample;
	}

	public void setDownloadSample(DefaultStreamedContent downloadSample) {
		this.downloadSample = downloadSample;
	}

	public String getTempFilename() {
		return tempFilename;
	}

	public void setTempFilename(String tempFilename) {
		this.tempFilename = tempFilename;
	}

	public DefaultStreamedContent getDownloadFile() {
		try{
		System.out.println("Selected Source " + getSelectedSource());
		if (getSelectedSource().toString() != ""
				|| getSelectedSource().toString() != null) {
			FileController objFC = new FileController(getSelectedSource()
					.toString());

			setDownloadFile(objFC.getDownload());
		} else {
			displayErrorMessageToUser("File Not Found. Please select file",
					"Download Failed");
		}}
		catch(Exception e){
			displayErrorMessageToUser("Error occured. Please try again", "ERROR");
		}
		return downloadFile;
	}

	public void setDownloadFile(DefaultStreamedContent downloadFile) {
		this.downloadFile = downloadFile;
	}

	public DefaultStreamedContent getDownloadTextconvertedFile() {
		try{
		System.out.println("Selected Source " + getTextfilename());
		if (getTextfilename().toString() != ""
				|| getTextfilename().toString() != null) {
			FileController objFC = new FileController(getTextfilename()
					.toString());

			setDownloadTextconvertedFile(objFC.getDownload());
		} else {
			displayErrorMessageToUser("File Not Found. Please select file",
					"Download Failed");
		}
		}catch(Exception e){
			displayErrorMessageToUser("Error occured. Please try again", "ERROR");
		}
		return downloadTextconvertedFile;
	}

	public void setDownloadTextconvertedFile(
			DefaultStreamedContent downloadTextconvertedFile) {
		this.downloadTextconvertedFile = downloadTextconvertedFile;
	}

}
