/*
 *Class Name : ExtendExistingLayoutBean.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import com.vit.ai.commons.model.HRPayerBean;
import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for extending a existing layout
 * 
 * @see AddLayoutBean
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 21 Aug 2014
 */
@ManagedBean
@ViewScoped
public class ExtendExistingLayoutBean extends AddLayoutBean implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<Layout> layouts;
	private String extendpayer;
	private String layoutId;
	private int noofRows;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private ArrayList<ArrayList<String>> check = new ArrayList<ArrayList<String>>();
	ArrayList<String> checkin;// ArrayList for populating the HansonTable
	private ArrayList<String> layoutids = new ArrayList<String>();
	private Layout selectedLayout=new Layout();//Layout to be used
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public int getNoofRows() {
		return noofRows;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public void setNoofRows(int noofRows) {
		this.noofRows = noofRows;
	}

	public ArrayList<Layout> getLayouts() {
		return layouts;
	}

	public void setLayouts(ArrayList<Layout> layouts) {
		this.layouts = layouts;
	}

	public ArrayList<String> getLayoutids() {
		return layoutids;
	}

	public void setLayoutids(ArrayList<String> layoutids) {
		this.layoutids = layoutids;
	}

	public ArrayList<ArrayList<String>> getCheck() {

		return this.check;
	}

	public void setCheck(ArrayList<ArrayList<String>> check) {
		this.check = check;
	}

	public String getLayoutId() {
		
		
		if(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid")!=null)
		{
			this.layoutId=FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid");
		}
		else
		{
			this.layoutId="";
		}
		return this.layoutId;

	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	public String getExtendpayer() {

		if (this.selectedLayout != null) {
			this.extendpayer = this.selectedLayout.getPayor();
		} else {
			this.extendpayer = "";
		}

		return this.extendpayer;
	}

	public void setExtendpayer(String extendpayer) {
		this.extendpayer = extendpayer;
	}

	public void openDialog() {
		if (this.partialDuplicate == true) {
			RequestContext.getCurrentInstance().execute(
					"PF('dialogClients').show()");
		}

	}

	public ExtendExistingLayoutBean() {
		super();
		init();
	}

	
	public void init() {
		LayoutsbyID objLayout=new LayoutsbyID(getLayoutId(),"","");
		this.selectedLayout=objLayout.getLayouts().get(0);
	
		if(this.selectedLayout!=null)
		{
		
		HRPayerBean objHRP = new HRPayerBean();
		payers = objHRP.getPayers();
		this.extendpayer =getSelectedLayout().getPayor();
		this.payer = this.payers.get(this.extendpayer);
		this.layoutId = getSelectedLayout().getLayoutID();
		handleLayoutChange();
		}
		

	}

	public void handleLayoutChange() {
		this.csvValues = "";
		if (payer != null && !payer.equals("") && this.layoutId != null
				&& !this.layoutId.equals("")) {

			setCsvValueshere();
			setDataType(getSelectedLayout().getDataType());
			setLayoutType(getSelectedLayout().getLayoutType());
			setPunchChar(getSelectedLayout()
					.getPunchCharFlag());
			setOptEnc(getSelectedLayout()
					.getOptionallyEnclosedFlag());
			setSkpRow(getSelectedLayout().getSkipRow());
			setSkpLastRow(getSelectedLayout().getTrailerSkip() == "" ? "0"
					: getSelectedLayout().getTrailerSkip());
			setWhereClause(getSelectedLayout()
					.getWhereClause());
			setTrailerSkipCondition(getSelectedLayout()
					.getTrailerSkip());
			setLayoutDesc(getSelectedLayout().getLayoutDesc());
			setSubLayoutDesc(getSelectedLayout()
					.getSubLayoutDesc());
			setSrcInfo(getSelectedLayout().getSourceInfo()
					+ "\n" + "---EXTENDED FROM LAYOUTID : " + this.layoutId
					+ "---");
			setVerified("N");
			setCharacterSet(getSelectedLayout().getCharacterSet());

		}

	}

	public void setCsvValueshere() {

		setColLengthGT30(true);
		setDupColCheck(true);
		setInvalidColumn(true);
		setLayoutPopulated(true);
		setInvalDatatype(true);
		setInvalfieldlenthVal(true);
		setInvalDatedescription(true);
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT columnname, datatype, datetypedetial, fieldlength,businessname "
				+ "FROM imp_layouts_fields WHERE layoutid='"
				+ this.layoutId
				+ "' AND SUBLAYOUTID='1' ORDER BY sublayoutid,COLUMNID  asc";

		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();

		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					checkin = new ArrayList<String>();
					String clmname = rs.get(i).get(0);

					checkin.add(" \"" + clmname + "\"");
					String dtype = rs.get(i).get(1);

					checkin.add(" \"" + dtype + "\"");
					String datedetail = rs.get(i).get(2);

					if (datedetail == null) {
						checkin.add(datedetail);
					} else {
						checkin.add(" \"" + datedetail + "\"");
					}
					String flength = rs.get(i).get(3);

					checkin.add(flength);
					
					String businessname=rs.get(i).get(4);
					checkin.add(" \"" + businessname + "\"");

					check.add(i - 1, checkin);

					setCheck(check);
				}
			}
		}

	}

	@Override
	public void addLayout() {
		String messageString = "";
		String results = null;
		try {
			results = verifyLayouts();
			System.out.println("Checking1: " + results);
		} catch (ArrayIndexOutOfBoundsException ex) {

			displayErrorMessageToUser(
					"Couldnot Verify Layouts.Please Try Again", "Error");
			this.validationComplete=false;
			return;
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("No Layout Found.Please Try Again",
					"Error");
			this.validationComplete=false;
			return;
		}
		if (results.equalsIgnoreCase("NEW")) {
			// messageString = "Validation complete. Please submit.";
			validationComplete = true;
			partialDuplicate = false;
		}

		else if (results.contains("Exact Duplicate:")) {
			messageString = results + " of Payer " + payer.split("~")[0]
					+ ". Please verify.";
			validationComplete = false;
			partialDuplicate = false;
			displayInfoMessageToUser(messageString, "New Layout");
			return;
		}
		else
		{
			this.validationComplete=true;
			this.partialDuplicate=false;
		}

		String result = "";
		try {

			String payerfullname = this.payer;

			if (this.validationComplete == true)
				result = "NEW";
			if (result.equalsIgnoreCase("NEW")) {
				String payerName = payerfullname.split("~")[0];
				String payerId = payerfullname.split("~")[1];
				String shortName = payerfullname.split("~")[2];

				String userLog = getUserinfo().getFullname();

				ConnectDB db = new ConnectDB();
				db.initialize();

				String query = "SELECT MAX(LAYOUTID) +1 FROM IMP_LAYOUTS";

				String sn = "0";
				List<List<String>> snList = db.resultSetToListOfList(query);
				if (snList.size() > 1) {
					sn = snList.get(1).get(0);
				} else {
					sn = "0";
				}
				String layoutStatus="";
				String activeFlag="";

				if(!this.isNew)
				{
					layoutStatus="HOLD";
					activeFlag="N";
				}
				else
				{
					layoutStatus="WORKING";
					activeFlag="Y";
				}
				query = "INSERT INTO IMP_LAYOUTS(LAYOUTID,PAYOR, DATATYPE, PUCHCHARFLAG, OPTIONALLY, SKIPROW, "
						+ " ENTRYDATE, TRAILERSKIP,PAYORID ,LAYOUTDESCIPTION ,SOURCEINFO,USERLOG,SHORTPAYOR,ACTIVEFLAG,LAYOUT_STATUS,VERIFIED,CHARACTERSET) "
						+ " VALUES("
						+ sn
						+ ", "
						+ " '"
						+ payerName.replaceAll("'", "''")
						+ "', '"
						+ dataType.replaceAll("'", "''")
						+ "', "
						+ " '"
						+ punchChar
						+ "','"
						+ optEnc
						+ "','"
						+ skpRow
						+ "',SYSDATE, "
						+ " '"
						+ skpLastRow
						+ "','"
						+ payerId
						+ "','"
						+ layoutDesc.replaceAll("'", "''")
						+ "', "
						+ " '"
						+ srcInfo.replaceAll("'", "''")
						+ "','"
						+ userLog
						+ "','"
						+ shortName
						+ "','"+activeFlag+"','"+layoutStatus+"','"
						+ this.verified 
						+ "','"+this.getCharacterSet()+"')";

				db.executeDML(query);

				/*
				 * if(trailerCondition.equalsIgnoreCase("N")) {
				 * trailerSkipCondition = ""; }
				 * if(whereCondition.equalsIgnoreCase("N")) { whereClause = "";
				 * }
				 */

				String splitValues[] = csvValues.split("~");
				String excelDatas[] = new String[splitValues.length - 1];

				String ins = "INSERT INTO IMP_SUB_LAYOUTS(LAYOUTID, SUBLAYOUTID, LAYOUTTYPE, WHERECLAUSE, "
						+ " SUBLAYOUTDESC) VALUES('"
						+ sn
						+ "','1','"
						+ layoutType
						+ "',"
						+ " '"
						+ whereClause.replaceAll("'", "''")
						+ "','"
						+ subLayoutDesc + "')";

				db.executeDML(ins);

				int substrpos = 0;
				int tempSubstr = 0;
				int start = 0;
				int i;
				for (i = 1; i < splitValues.length; i++) {
					excelDatas[i - 1] = splitValues[i].replaceAll("\"", "'")
							.replaceAll(";", ",").replaceAll(",,", ",'',");
					String [] listofFields=excelDatas[i-1].split(",");
					String columnname=listofFields[0].toUpperCase().replaceAll("'", "");
					String datatype=listofFields[1].toUpperCase().replaceAll("'", "");
					String dtdetail=listofFields[2].replaceAll("'", "");
					String length="";
					try
					{
					length=listofFields[3].replaceAll("'", "");
					}
					catch(Exception ex)
					{
						displayErrorMessageToUser("FIELD LENGTH CANNOT BE EMPTY", "ERROR");
						return;
					}
					String busname="";
					try
					{
					busname=listofFields[4].replaceAll("'", "");
					}
					catch(Exception ex)
					{
						busname="";
					}
					

					tempSubstr = substrpos;
					start = tempSubstr + 1;
					String temp=excelDatas[i - 1].substring(0,
							excelDatas[i - 1].lastIndexOf(",") - 1);
					
					

					tempSubstr = Integer
							.parseInt(temp.substring(
									temp.lastIndexOf(",") + 1).replaceAll(
									"'", ""));
					substrpos += tempSubstr;

					ins = "INSERT INTO IMP_LAYOUTS_FIELDS(LAYOUTID,SUBLAYOUTID, COLUMNID, COLUMNNAME, DATATYPE,"
							+ " DATETYPEDETIAL, FIELDLENGTH ,BUSINESSNAME,STARTPOS,ENDPOS,CATEGORY)"
							+ " VALUES('"
							+ sn
							+ "','1','"
							+ i
							+ "','"
							+ columnname.replaceAll("'", "''")
							+ "','"
							+ datatype.replaceAll("'", "''")
							+ "','"
							+ dtdetail.replaceAll("'", "''")
							+ "','"
							+ length.replaceAll("'", "''")
							+ "','"
							+ busname.replaceAll("'", "''")
							+"','"
							+ start
							+ "','"
							+ substrpos
							+ "','"
							+remapCategory(datatype.replaceAll("'", "''"))							
							+ "')";

					if (ins.substring(ins.length() - 2).equalsIgnoreCase(",)")) {
						ins = ins.substring(0, ins.length() - 2);
						ins = ins + ",'')";
					}

					db.executeDML(ins);
				}

				if (layoutType.toLowerCase().startsWith("fixe")
						|| layoutType.toLowerCase().startsWith("subs")) {
					layoutDetail = substrpos + "";
				} else {
					layoutDetail = (i - 1) + "";
				}

				ins = "UPDATE IMP_SUB_LAYOUTS SET LAYOUTDETAIL='"
						+ layoutDetail + "' WHERE LAYOUTID='" + sn
						+ "' AND SUBLAYOUTID='1'";

				db.executeDML(ins);

				db.endConnection();

				getSessionData().setNewAdditionComplete(true);
				RequestContext.getCurrentInstance().closeDialog(
						"extendexistinglayout");
				if(!this.isNew)
				{
					takeActionforPartialDuplicate();
				}
				reset();

				displayInfoMessageToUser(
						"New Layout Added with Layout ID ="
								+ sn
								+ "Please add sublayouts if needed and Checkin scripts and Atributes from the layout Menu",
						"Layout Extended");

			} else {
				displayErrorMessageToUser(
						result + " of Payer " + payer.split("~")[0]
								+ ". Please verify.", "New Layout");
				validationComplete = false;
			}
		} catch (ArrayIndexOutOfBoundsException ex) {

			displayErrorMessageToUser(
					"Couldnot Verify Layouts.Please Try Again", "Error");
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			System.out.println(ex.toString());
			displayErrorMessageToUser("No Layout Found.Please Try Again",
					"Error");
		}
	}

	public void cancel() {
		RequestContext.getCurrentInstance().closeDialog("extendexistinglayout");
	}

	public Layout getSelectedLayout() {
		return selectedLayout;
	}

	public void setSelectedLayout(Layout selectedLayout) {
		this.selectedLayout=selectedLayout;
		System.out.println("check 2 : " + this.selectedLayout.getLayoutID());
	}


}