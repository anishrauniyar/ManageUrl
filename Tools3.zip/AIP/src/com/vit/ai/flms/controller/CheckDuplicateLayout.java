package com.vit.ai.flms.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutFields;
import com.vit.ai.flms.model.PartialDuplicateModel;

public class CheckDuplicateLayout implements Serializable {


	private static final long serialVersionUID = -3891562280612976980L;
	private Layout mainLayout;
	private Layout layoutToCompare;
	private boolean dumpToExcel = false;
	private ArrayList<LayoutFields> newLayoutDetails;
	private ArrayList<LayoutFields> oldLayoutDetails;
	private String fieldToAvoid = "";
	private String valueToAvoid = "";
	private ArrayList<PartialDuplicateModel> partialDuplicateFieldsOldLayout;
	private ArrayList<PartialDuplicateModel> partialDuplicateFieldsNewLayout;
	private String filename="";
	String header="LAYOUTID,COLUMNID,COLUMNNAME,DATATYPE,DATETYPEDETAIL,FIELDLENGTH,STARTPOS,ENDPOS";
	String contenttoWrite="";

	public ArrayList<PartialDuplicateModel> getPartialDuplicateFieldsOldLayout() {
		return partialDuplicateFieldsOldLayout;
	}

	public void setPartialDuplicateFieldsOldLayout(
			ArrayList<PartialDuplicateModel> partialDuplicateFieldsOldLayout) {
		this.partialDuplicateFieldsOldLayout = partialDuplicateFieldsOldLayout;
	}

	public ArrayList<PartialDuplicateModel> getPartialDuplicateFieldsNewLayout() {
		return partialDuplicateFieldsNewLayout;
	}

	public void setPartialDuplicateFieldsNewLayout(
			ArrayList<PartialDuplicateModel> partialDuplicateFieldsNewLayout) {
		this.partialDuplicateFieldsNewLayout = partialDuplicateFieldsNewLayout;
	}

	public Layout getMainLayout() {
		return mainLayout;
	}

	public void setMainLayout(Layout mainLayout) {
		this.mainLayout = mainLayout;
	}

	public Layout getLayoutToCompare() {
		return layoutToCompare;
	}

	public void setLayoutToCompare(Layout layoutToCompare) {
		this.layoutToCompare = layoutToCompare;
	}

	public ArrayList<LayoutFields> getNewLayoutDetails() {
		return newLayoutDetails;
	}

	public void setNewLayoutDetails(ArrayList<LayoutFields> newLayoutDetails) {
		this.newLayoutDetails = newLayoutDetails;
	}

	public ArrayList<LayoutFields> getOldLayoutDetails() {
		return oldLayoutDetails;
	}

	public void setOldLayoutDetails(ArrayList<LayoutFields> oldLayoutDetails) {
		this.oldLayoutDetails = oldLayoutDetails;
	}

	public CheckDuplicateLayout(Layout firstlayout, Layout secondLayout,
			ArrayList<LayoutFields> oldlayoutdetails,
			ArrayList<LayoutFields> newlayoutdetails) {
		this.mainLayout = firstlayout;
		this.layoutToCompare = secondLayout;
		this.oldLayoutDetails = oldlayoutdetails;
		this.newLayoutDetails = newlayoutdetails;

	}

	public int performBasicChecks() {
		int checkstatus = 1;
		
		if (mainLayout.getPayor().compareTo(layoutToCompare.getPayor()) != 0
				|| mainLayout.getLayoutType().compareTo(
						layoutToCompare.getLayoutType()) != 0
				|| mainLayout.getDataType().compareTo(
						layoutToCompare.getDataType()) != 0
				|| mainLayout.getLayoutDetail().compareTo(
						layoutToCompare.getLayoutDetail()) != 0) {
			checkstatus = 0;
		}
		return checkstatus;

	}

	public String checkForExactDuplicate() {

		
		String status = "NEW";
		int i = 0;

		if (mainLayout.getLayoutType().compareTo("Fixed length") == 0) {

			for (LayoutFields obj : oldLayoutDetails) {
				if (obj.equalsForFixedLength(this.newLayoutDetails.get(i))) {
					i++;

				}
			}
		} else {

			for (LayoutFields obj : oldLayoutDetails) {
				if (obj.equalsForDelimited(this.newLayoutDetails.get(i))) {
					i++;

				}
			}
		}


		if (String.valueOf(i).compareTo(mainLayout.getNumOfFields()) == 0) {
			status = "Exact Duplicate of layoutid : "
					+ mainLayout.getLayoutID() + "and sublayoutid : "
					+ mainLayout.getSubLayoutID();

		}

		return status;
	}

	public int checkForPartialDuplicate() {
		int status = 1;
	
		if (performBasicChecks() == 1) {
			
			this.partialDuplicateFieldsOldLayout = new ArrayList<>();
			this.partialDuplicateFieldsNewLayout = new ArrayList<>();
			if (mainLayout.getLayoutType().compareTo("Fixed length") == 0) {
				int i = 0;
				for (LayoutFields obj : oldLayoutDetails) {
					if (!obj.equalsForFixedLength(this.newLayoutDetails.get(i))) {
						this.partialDuplicateFieldsOldLayout
								.add(new PartialDuplicateModel(obj
										.getColumnID(), obj.getColumnName(),
										obj.getDataType(), obj
												.getDateTypeDetail(), String
												.valueOf(obj.getStart()),
										String.valueOf(obj.getEnd())));
						
						
						

						this.partialDuplicateFieldsNewLayout
								.add(new PartialDuplicateModel(
										this.newLayoutDetails.get(i)
												.getColumnID(),
										this.newLayoutDetails.get(i)
												.getColumnName(),
										this.newLayoutDetails.get(i)
												.getDataType(),
										this.newLayoutDetails.get(i)
												.getDateTypeDetail(), String
												.valueOf(this.newLayoutDetails
														.get(i).getStart()),
										String.valueOf(this.newLayoutDetails
												.get(i).getEnd())));

							contenttoWrite+="\n \n" + layoutToCompare.getLayoutID() + "," +this.newLayoutDetails.get(i)
								.getColumnID()+ "," + this.newLayoutDetails.get(i).getColumnName() + "," + this.newLayoutDetails.get(i).getDataType() + "," + this.newLayoutDetails.get(i)
								.getDateTypeDetail() + "," +  this.newLayoutDetails.get(i).getFieldLength()
								+ "," + String
								.valueOf(this.newLayoutDetails.get(i).getStart()) + "," + String.valueOf(this.newLayoutDetails.get(i).getEnd());
							 contenttoWrite+="\n" + mainLayout.getLayoutID() + "," +obj
										.getColumnID()+ "," + obj.getColumnName() + "," + obj.getDataType() + "," + obj
										.getDateTypeDetail() + "," +  obj.getFieldLength()
										+ "," +String
										.valueOf(obj.getStart()) + "," + String.valueOf(obj.getEnd());
							
							
					}
					i++;
					
				}
				
				 if(this.isDumpToExcel() )
					{
						dumpToExcel(contenttoWrite);
					}
			} else {
				int i = 0;
				for (LayoutFields obj : oldLayoutDetails) {
					if (!obj.equalsForDelimited(this.newLayoutDetails.get(i))) {
						this.partialDuplicateFieldsOldLayout
								.add(new PartialDuplicateModel(obj
										.getColumnID(), obj.getColumnName(),
										obj.getDataType(), obj
												.getDateTypeDetail(), String
												.valueOf(obj.getStart()),
										String.valueOf(obj.getEnd())));
						

						this.partialDuplicateFieldsNewLayout
								.add(new PartialDuplicateModel(
										this.newLayoutDetails.get(i)
												.getColumnID(),
										this.newLayoutDetails.get(i)
												.getColumnName(),
										this.newLayoutDetails.get(i)
												.getDataType(),
										this.newLayoutDetails.get(i)
												.getDateTypeDetail(), String
												.valueOf(this.newLayoutDetails
														.get(i).getStart()),
										String.valueOf(this.newLayoutDetails
												.get(i).getEnd())));
						contenttoWrite+="\n \n" + layoutToCompare.getLayoutID() + "," +this.newLayoutDetails.get(i)
								.getColumnID()+ "," + this.newLayoutDetails.get(i).getColumnName() + "," + this.newLayoutDetails.get(i).getDataType() + "," + this.newLayoutDetails.get(i)
								.getDateTypeDetail() + "," + this.newLayoutDetails.get(i).getFieldLength()
								+ "," + String
								.valueOf(this.newLayoutDetails.get(i).getStart()) + "," + String.valueOf(this.newLayoutDetails.get(i).getEnd() + ",");
						contenttoWrite+="\n " + mainLayout.getLayoutID() + "," +obj
								.getColumnID()+ "," + obj.getColumnName() + "," + obj.getDataType() + "," + obj
								.getDateTypeDetail() + "," + obj.getFieldLength()
								+ "," + String
								.valueOf(obj.getStart()) + "," + String.valueOf(obj.getEnd() + ",");
						
					}
					i++;
				}
				if(this.isDumpToExcel())
				{
					dumpToExcel(contenttoWrite);
				}
				
			
			}
			
		} else {
			status = 0;
			return status;
		}

		return status;
	}
	
	
	public void dumpToExcel(String content)
	{
	
		
		File files=new File(filename);
		if(!files.exists())
		{
			try {
				files.createNewFile();
				BufferedWriter writer= new BufferedWriter(new FileWriter(filename,true));
				if(writer!=null)
				{
					writer.write(header);
				}
				writer.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		try {
			
			BufferedWriter writer= new BufferedWriter(new FileWriter(filename,true));
			if(writer!=null)
			{
			
					writer.write(content);
				
			}
			writer.close();
			this.contenttoWrite="";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public boolean isDumpToExcel() {
		return dumpToExcel;
	}

	public void setDumpToExcel(boolean dumpToExcel) {
		this.dumpToExcel = dumpToExcel;
	}

	public String getFieldToAvoid() {
		return fieldToAvoid;
	}

	public void setFieldToAvoid(String fieldToAvoid) {
		this.fieldToAvoid = fieldToAvoid;
	}

	public String getValueToAvoid() {
		return valueToAvoid;
	}

	public void setValueToAvoid(String valueToAvoid) {
		this.valueToAvoid = valueToAvoid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

}
