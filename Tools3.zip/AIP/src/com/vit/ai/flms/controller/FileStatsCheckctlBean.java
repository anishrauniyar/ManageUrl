/*
 *Class Name : FileStatsCheckctlBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.tmatesoft.svn.core.io.SVNRepository;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.flms.model.StatsCheckctl;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;
import com.vit.ai.remoteConnection.ProcessBuilderRunner;
import com.vit.ai.svnconnection.ConnecttoSVN;

/**
 * Class to get the checklist for a control layout attributes
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 21 Aug 2014
 */
@ManagedBean
@ViewScoped
public class FileStatsCheckctlBean extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<StatsCheckctl> statsChkList;
	private String layout_layoutid;
	private String layout_sublayoutid;
	private boolean edited = false;
	private boolean sublayout = false;
	private String layoutstatus = "";

	public String getLayout_layoutid() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.layout_layoutid = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("lid");

		return this.layout_layoutid;
	}

	public void setLayoutid_layoutid(String clientPattern_SN) {
		this.layout_layoutid = clientPattern_SN;
	}

	public boolean isEdited() {
		return edited;
	}

	public void setEdited(boolean edited) {
		this.edited = edited;
	}

	public String getLayout_sublayoutid() {
		FacesContext context = FacesContext.getCurrentInstance();
		this.layout_sublayoutid = (String) context.getExternalContext()
				.getRequestParameterMap().get("slid");
		return layout_sublayoutid;
	}

	public void setLayout_sublayoutid(String layout_sublayoutid) {
		this.layout_sublayoutid = layout_sublayoutid;
	}

	public FileStatsCheckctlBean() {

		init();

	}

	@PostConstruct
	public void init() {

		statsChkList = new ArrayList<StatsCheckctl>();
		setStatsChkList(statsChkList);
		isSublayout();
		FacesContext context = FacesContext.getCurrentInstance();
		this.layoutstatus = (String) context.getExternalContext()
				.getRequestParameterMap().get("layoutstatus");
		
		if(this.layoutstatus == null)
		{
			this.layoutstatus="WORKING";
		}

		System.out.println("Layout Status : " + this.layoutstatus);
	}

	public ArrayList<StatsCheckctl> getStatsChkList() {
		return statsChkList;
	}

	public void setStatsChkList(ArrayList<StatsCheckctl> statsChkList) {
		String query = "SELECT  a.layoutid,sn,sublayoutid, columnid, columnname, datatype, datetypedetial, "
				+ " fieldlength , ctrl_field , c.udf_mapping FROM ( "
				+ "SELECT a.layoutid,sn,sublayoutid, columnid, columnname, datatype, datetypedetial, fieldlength "
				+ "FROM  imp_layouts_fields a "
				+ "WHERE a.layoutid='"
				+ getLayout_layoutid()
				+ "'AND EXISTS (SELECT 1 FROM  imp_sub_layouts b WHERE "
				+ " a.sublayoutid=b.sublayoutid AND b.layoutid='"
				+ getLayout_layoutid()
				+ "' AND SUBLAYOUTDESC='CONTROLTOTAL' )) a "
				+ "left join imp_ctrl_map b" + " ON a.sn=b.layout_sn left join imp_ctrl_udf_map c on b.layout_sn = c.field_sn";
		System.out.println("CTRL query " + query);

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> statsList = db.resultSetToListOfList(query);
		db.endConnection();

		if (statsList.size() > 0) {
			ArrayList<String> statsFunctionList = new ArrayList<String>();
			ConnectDB db1 = new ConnectDB();
			db1.initialize();
			List<List<String>> rs1 = db1
					.resultSetToListOfList("select * from controltotal_fields order by 1");
			db1.endConnection();
			if (rs1 != null && rs1.size() > 0) {
				for (int i = 1; i < rs1.size(); i++) {
					statsFunctionList.add(rs1.get(i).get(0));
				}
			}

			for (int i = 1; i < statsList.size(); i++) {

				statsChkList.add(new StatsCheckctl(statsList.get(i).get(0),
						statsList.get(i).get(1), statsList.get(i).get(2),
						statsList.get(i).get(3), statsList.get(i).get(4),
						statsList.get(i).get(5), statsList.get(i).get(6),
						statsList.get(i).get(7), statsList.get(i).get(8),
						statsFunctionList, getLayout_layoutid(),statsList.get(i).get(9)));

			}
		}

	}

	public void handleSubmit() {
		RequestContext.getCurrentInstance().execute(
				"parent.PF('subdialogforctl').hide();");

		RequestContext.getCurrentInstance().execute(
				"parent.PF('subdialog').show();");
	}

	public void handleDone() {
		this.edited = true;

	}

	public void checkin(String user) {

		System.out.println("CHECKING IN");
		String lid = this.layout_layoutid;
		String cattr = ProcessBuilderRunner.runCAttr(lid);
		if (cattr.contains("INVALID")) {
			RequestContext.getCurrentInstance().execute("PF('bar').hide();");
			String errorMessage = cattr.split("|")[1];
			displayErrorMessageToUser(errorMessage,
					"Error checking in cattr");
			return;
		}
		ConnecttoSVN conn = new ConnecttoSVN();
		SVNRepository repos = conn.connect(AIConstant.SVNCATTR_PATH);

		System.out.println(cattr);
		try {
			boolean check = conn.committoSVNwithfile(repos,
					AIConstant.SVNCATTR_PATH, lid + ".cattr", cattr);
			if (check == true) {
				RequestContext.getCurrentInstance()
						.execute("PF('bar').hide();");
				try {
					RequestContext.getCurrentInstance().closeDialog(
							"fileStatsCheckctl");
					displayInfoMessageToUser(lid
							+ ".cattr checked in successfully", "SVN-CheckIn");
				} catch (Exception ex) {
				}

				finally {
					if (this.sublayout == true) {
						conn.SVNPopulatedb(lid, "cattr", this.layout_layoutid
								+ ".cattr", user.toUpperCase(), "Control");
					} else {
						conn.SVNPopulatedb(lid, "cattr", this.layout_layoutid
								+ ".cattr", user.toUpperCase());
					}
				}

			} else {
				RequestContext.getCurrentInstance()
						.execute("PF('bar').hide();");
				displayInfoMessageToUser(
						"SVN Checkin-Falied.Please try again manually",
						"SVN-CheckIn");
			}
		} catch (Exception e) {
			RequestContext.getCurrentInstance().execute("PF('bar').hide();");
			displayInfoMessageToUser(e.toString(), "Couldnot insert into table");
		}

	}

	public boolean isSublayout() {

		FacesContext context = FacesContext.getCurrentInstance();
		String sublayout = (String) context.getExternalContext()
				.getRequestParameterMap().get("issublayout");
		if (sublayout == null) {
			this.sublayout = true;
		} else {

			if (sublayout.compareTo("Y") == 0) {

				this.sublayout = true;
			} else {
				this.sublayout = false;
			}

			System.out.println("SUBLAYOUT :  " + sublayout);
		}
		return this.sublayout;
	}

	public void setSublayout(boolean sublayout) {
		this.sublayout = sublayout;
	}

	public String getLayoutstatus() {
		
		return layoutstatus;
	}

	public void setLayoutstatus(String layoutstatus) {
		this.layoutstatus = layoutstatus;
	}

}
