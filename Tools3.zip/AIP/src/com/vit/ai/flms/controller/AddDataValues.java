/* 
 * Class Name : AddDataValues.java
 *
 * Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for adding attributes for a data layout
 * 
 * This class is not used
 * @author Aashish Dhungana
 * 
 * @version 1.0 15 June 2014
 */
@ManagedBean
@ViewScoped
public class AddDataValues extends AbstractController implements Serializable {

	private static final Logger LOG = Logger.getLogger(AddDataValues.class
			.getName());
	private static final long serialVersionUID = 1L;
	private String sn;
	private String columnName;
	private String csvvalues;
	private String layoutID;
	private String statsFunction;
	private ArrayList<ArrayList<String>> values = new ArrayList<ArrayList<String>>();

	public ArrayList<ArrayList<String>> getValues() {
		return values;
	}

	public void setValues(ArrayList<ArrayList<String>> values) {
		this.values = values;
	}

	public String getStatsFunction() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.statsFunction = facesContext.getExternalContext()
				.getRequestParameterMap().get("sfn");
		return statsFunction;
	}

	public void setStatsFunction(String statsFunction) {
		this.statsFunction = statsFunction;
	}

	public String getSn() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.sn = facesContext.getExternalContext().getRequestParameterMap()
				.get("csn");
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getColumnName() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.columnName = facesContext.getExternalContext()
				.getRequestParameterMap().get("cname");
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getCsvvalues() {
		return csvvalues;
	}

	public void setCsvvalues(String csvvalues) {
		this.csvvalues = csvvalues;
	}

	public String getLayoutID() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.layoutID = facesContext.getExternalContext()
				.getRequestParameterMap().get("lid");
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public AddDataValues() {
		this.csvvalues = "";
		this.layoutID = getLayoutID();
		this.sn = getSn();
		this.columnName = getColumnName();
		this.statsFunction = getStatsFunction();
		setAttributes();
		RequestContext.getCurrentInstance().execute(
				"insert(" + this.values + ");");

	}

	/**
	 * Returns the attribute for a specific column in a layout
	 */
	public void setAttributes() {

		this.values.clear();
		ArrayList<String> temp;
		String query = "SELECT C.field_value,NVL(c.field_desc,'No Desc') from  IMP_LAYOUT_DETAILS c WHERE LAYOUT_SN="
				+ getSn();
		LOG.info("Add Data Values setAttributes Query  : " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();

		try {
			if (rs != null) {
				if (rs.size() > 1) {
					for (int i = 1; i < rs.size(); i++) {
						temp = new ArrayList<String>();
						temp.add("\"" + rs.get(i).get(0) + "\"");
						temp.add("\"" + rs.get(i).get(1) + "\"");
						this.values.add(temp);
					}
				}
			}

		} catch (Exception e) {

			LOG.error("Add Data Values : " + e.toString());
			displayErrorMessageToUser(
					"Unknown Error occured!!Please try again", "ERROR");
		}

	}

	public void addData() {
		FacesContext.getCurrentInstance();
		if (this.csvvalues.length() > 75) {
			ConnectDB dbdel = new ConnectDB();
			dbdel.initialize();
			String splitValues[] = csvvalues.split("~");
			String excelDatas[] = new String[splitValues.length - 1];
			String querydelete = "delete from imp_layout_details where layout_id='"
					+ this.layoutID + "' AND layout_sn='" + this.sn + "'";

			String resdel = dbdel.executeDML(querydelete);
			dbdel.endConnection();
			if (resdel.compareTo("1") == 0) {

			} else {
				LOG.error("Delete values : " + querydelete);
				System.out.println(querydelete);
				displayErrorMessageToUser("Insert Failed.Please try again",
						"Insert Failed");
				keepDialogOpen();
				return;
			}

			ConnectDB db = new ConnectDB();
			db.initialize();

			for (int i = 1; i < splitValues.length; i++) {
				excelDatas[i - 1] = splitValues[i].replaceAll("\"", "'")
						.replaceAll(";", ",").replaceAll(",,", ",'',");
				if (excelDatas[i - 1].endsWith(",")) {
					excelDatas[i - 1] += "\'\'";
				}

				String query = "Insert into imp_layout_details(LAYOUT_ID,LAYOUT_SN,GETSTATSFUNCTION,FIELD_VALUE,FIELD_DESC) values('"
						+ this.layoutID
						+ "','"
						+ this.sn
						+ "','"
						+ this.statsFunction + "'," + excelDatas[i - 1] + ")";

				try {
					String opt = db.executeDML(query);
					if (opt.compareTo("1") == 0) {
						displayInfoMessageToUser("Value Added Successfully",
								"Add Data Values");
						RequestContext.getCurrentInstance().execute(
								"parent.PF('addD" + this.sn + "').hide();");

					} else {
						LOG.error("Add Values : " + query);
						System.out.println(query);
						displayErrorMessageToUser(
								"Couldnot insert.Please try again",
								"Insert Failed");
						keepDialogOpen();
					}

				} catch (Exception e) {

					LOG.error("Inset Data Values : " + e.toString());
					displayErrorMessageToUser("Insert Failed.Please try again",
							"Insert Failed");
					keepDialogOpen();
				}

			}
			db.endConnection();

		} else {
			RequestContext.getCurrentInstance().execute(
					"parent.PF('addD" + this.sn + "').hide();");
		}

	}

	/**
	 * Enable the Date Check
	 */
	public void enable() {
		Connection c = new ConnectDB().getConnection();
		try {
			String query = "Insert into imp_layout_details(LAYOUT_ID,LAYOUT_SN,GETSTATSFUNCTION) values('"
					+ getLayoutID()
					+ "','"
					+ getSn()
					+ "','"
					+ getStatsFunction() + "')";

			c.createStatement().execute(query);
			c.close();
			displayInfoMessageToUser("Successfully Enabled", "Enable");
		} catch (Exception e1) {

			LOG.error("Enabling data Values: " + e1.toString());
			displayErrorMessageToUser(e1.toString(), "Could not Enable");

		}

	}

	/**
	 * Disable the date Check
	 */
	public void disable() {
		Connection c = new ConnectDB().getConnection();
		try {
			String querydelete = "delete from imp_layout_details where layout_id='"
					+ getLayoutID() + "' AND layout_sn='" + getSn() + "'";

			c.createStatement().execute(querydelete);
			c.close();
			displayInfoMessageToUser("Successfully Disabled", "Disable ");

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			LOG.error("Disabling Data Values : " + e1.toString());
			displayErrorMessageToUser(e1.toString(), "Could not Disable");

		}

	}

}
