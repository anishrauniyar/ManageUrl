package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.flms.model.ControlTotal;
import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutFields;
import com.vit.ai.flms.model.LayoutFieldsModel;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.utils.EmailConfiguration;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class EditControlTotalDetails extends ControlTotalLayoutBean implements
		Serializable {
	private static Logger log = Logger.getLogger(EditControlTotalDetails.class
			.getName());

	private static final long serialVersionUID = 6807057379597474986L;

	private String selectedlid;
	private String selectedpayer;
	private Layout selectedLayout;

	public Layout getSelectedLayout() {
		return selectedLayout;
	}

	public void setSelectedLayout(Layout selectedLayout) {
		this.selectedLayout = selectedLayout;
	}

	public String getSelectedlid() {
		return selectedlid;
	}

	public void setSelectedlid(String lid) {
		this.selectedlid = lid;
	}

	public EditControlTotalDetails() {
		super();
		init();
	}

	@PostConstruct
	public void init() {

		this.selectedlid = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get("lid");
		/*this.selectedpayer = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap().get("payer");
		*/
		System.out.println("Layoutid "+this.selectedlid);

		LayoutsbyID objLayout = new LayoutsbyID(this.selectedlid, "", "");
		this.selectedLayout = objLayout.getLayouts().get(0);

		if (this.selectedLayout != null) {

			/*HRPayerBean objHRP = new HRPayerBean();
			payers = objHRP.getPayers();*/
			this.selectedpayer=this.payer=this.selectedLayout.getPayor();
			this.payer = this.selectedLayout.getPayor();
			System.out.println("Payor "+this.payer);
			handleLayoutChange();
		}

	}

	public void handleLayoutChange() {
		if (this.payer != null && !this.payer.equals("")
				&& this.selectedlid != null && !this.selectedlid.equals("")) {

			this.payer = this.payer.split("~")[0];
			setPayer(payers.get(payer));
			setDataType(this.selectedLayout.getDataType());
			setFormatType(this.selectedLayout.getLayoutType());
			setPunchChar(this.selectedLayout.getPunchCharFlag());
			setOptEnc(this.selectedLayout.getOptionallyEnclosedFlag());
			setSkpRow(this.selectedLayout.getSkipRow());
			setSrcInfo(this.selectedLayout.getSourceInfo());
			setLayoutDesc(this.selectedLayout.getLayoutDesc());
			setFields();
		}
	}

	public void setFields() {
		this.listoffields = new ArrayList<>();
		LayoutFieldsModel objFields = new LayoutFieldsModel(this.selectedlid);
		System.out.println("Selected layouts "+this.selectedlid);
		ArrayList<LayoutFields> fieldsList = new ArrayList<LayoutFields>();
		fieldsList = objFields.getLayoutfields();

		for (int i = 0; i < fieldsList.size(); i++) {

			ControlTotal ctobj = new ControlTotal();
			ctobj.setDatatype(fieldsList.get(i).getDataType());
			ctobj.setFormattype(this.getFormatType());
			ctobj.setColumnname(fieldsList.get(i).getColumnName());
			ctobj.setPosition((String.valueOf(fieldsList.get(i).getStart())
					.isEmpty() ? "0" : String.valueOf(fieldsList.get(i)
					.getStart()))
					+ ","
					+ (String.valueOf(fieldsList.get(i).getEnd()).isEmpty() ? "0"
							: String.valueOf(fieldsList.get(i).getEnd())));
			System.out.println("Position : " + ctobj.getPosition());
			ctobj.setDateFormat(fieldsList.get(i).getDateTypeDetail());
			ctobj.setLayouttype(getLayouttypes().get(fieldsList.get(i).getFieldDelimiter()));
			ctobj.setColno(Integer.parseInt((String) (fieldsList.get(i)
					.getFieldposition().isEmpty() ? "0" : fieldsList.get(i)
					.getFieldposition())));
			ctobj.setIndex(Integer.parseInt((String) (fieldsList.get(i)
					.getLinenumber().isEmpty() ? "0" : fieldsList.get(i)
					.getLinenumber())));
			System.out.println("Index : " + ctobj.getIndex());
			this.listoffields.add(ctobj);

		}
	}

	public String getSelectedpayer() {
		return selectedpayer;
	}

	public void setSelectedpayer(String selectedpayer) {
		this.selectedpayer = selectedpayer;
	}
	
	@Override
	public String verifyLayout() {

		if (Integer.parseInt(this.calculateLayoutDetail()) == 0) {
			displayErrorMessageToUser("Nothing to Add", "Error");
			this.validationComplete = false;
		}
		String message = "";
		this.validationComplete = false;
		ConnectDB db = new ConnectDB();
		String oldLayoutDetails = "";
		String newLayoutDetails = getNewLayoutDetails();
		if (newLayoutDetails.isEmpty()) {
			this.validationComplete = false;
			return "";
		}

		String query = "SELECT LAYOUTID FROM IMP_LAYOUTS WHERE PAYOR='"
				+ payer.split("~")[0]
				+ "' and datatype='CONTROL TOTAL' and layoutid!='"+this.selectedlid + "' GROUP BY LAYOUTID";

		db.initialize();
		List<List<String>> listOfLayoutID = db.resultSetToListOfList(query);
		List<List<String>> listDetails;

		if (listOfLayoutID.size() > 1) {

			for (int i = 1; i < listOfLayoutID.size(); i++) {

				query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||STARTPOS||ENDPOS||FIELDLINENUMBER||FIELDDELIMITER||FIELDPOSITION  "
						+ " FROM IMP_LAYOUTS_FIELDS "
						+ " WHERE LAYOUTID ='"
						+ listOfLayoutID.get(i).get(0)
						+ "' AND SUBLAYOUTID='1' "
						+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";

				oldLayoutDetails = "";

				listDetails = db.resultSetToListOfList(query);
				if (listDetails.size() > 1) {
					for (int j = 1; j < listDetails.size(); j++) {
						oldLayoutDetails = oldLayoutDetails
								+ listDetails.get(j).get(0);

					}
				} else {
					message = "Validation Complete";
					this.validationComplete = true;
					break;
				}
			
				if (oldLayoutDetails.equalsIgnoreCase(newLayoutDetails)) {

					message = "Exact Duplicate of LayoutID:"
							+ listOfLayoutID.get(i).get(0);

					this.validationComplete = false;
					break;
				} else {
					message = "Validation Complete";
					this.validationComplete = true;
				}

			}
		} else {
			message = "validation Complete";

			this.validationComplete = true;
		}
		db.endConnection();
		displayInfoMessageToUser(message, "");
		return message;

	}
	@Override
	public void addLayout() {
		verifyLayout();
		if (this.validationComplete) {
			ConnectDB db = new ConnectDB();
			db.initialize();
			
			String username = getUserinfo().getFullname();
			String sn=this.selectedlid;
			String query1="delete from imp_layouts_fields where layoutid='"+sn+"'";
			db.executeDML(query1);
			
			int columnid = 1;
			String query3 = "";
			for (int i = 0; i < this.listoffields.size(); i++) {
				if (!this.listoffields.get(i).getColumnname().isEmpty()) {
					if (this.listoffields.get(i).getLayouttype()
							.compareTo("Fixed length") != 0) {
						query3 = "Insert into imp_layouts_fields(LAYOUTID,SUBLAYOUTID,COLUMNID,COLUMNNAME,DATATYPE,DATETYPEDETIAL,FIELDLENGTH,FIELDLINENUMBER,FIELDDELIMITER,FIELDPOSITION)"
								+ "values('"
								+ sn
								+ "','1','"
								+ columnid
								+ "','"
								+ this.listoffields.get(i).getColumnname().toUpperCase()
								+ "','"
								+ this.listoffields.get(i).getDatatype().toUpperCase()
								+ "','"
								+ this.listoffields.get(i).getDateFormat()
								+ "','100','"
								+ this.listoffields.get(i).getIndex()
								+ "','"
								+ this.listoffields.get(i).getLayouttype()
								+ "','"
								+ this.listoffields.get(i).getColno()
								+ "')";
						columnid++;
						db.executeDML(query3);
					} else {
						String sp = this.listoffields.get(i).getPosition()
								.split(",")[0].replaceAll("\\(", "");
						int startPos = Integer.parseInt(sp);
						String ep = this.listoffields.get(i).getPosition()
								.split(",")[1].replaceAll("\\)", "");
						int endPos = Integer.parseInt(ep);
						query3 = "Insert into imp_layouts_fields(LAYOUTID,SUBLAYOUTID,COLUMNID,COLUMNNAME,DATATYPE,DATETYPEDETIAL,FIELDLENGTH,FIELDLINENUMBER,FIELDDELIMITER,startpos,endpos)"
								+ "values('"
								+ sn
								+ "','1','"
								+ columnid
								+ "','"
								+ this.listoffields.get(i).getColumnname().toUpperCase()
								+ "','"
								+ this.listoffields.get(i).getDatatype().toUpperCase()
								+ "','"
								+ this.listoffields.get(i).getDateFormat()
								+ "','100','"
								+ this.listoffields.get(i).getIndex()
								+ "','"
								+ this.listoffields.get(i).getLayouttype()
								+ "','" + startPos + "','" + endPos + "')";
						columnid++;
						
						 db.executeDML(query3);
						
						

					}
				}
				String query4="update imp_layouts_fields set updated_by='"+username+"' where layoutid='"+this.getSelectedlid()+"'";
				db.executeDML(query4);

			}
			sendMail(getSelectedlid(),"1",getSelectedLayout().getUserlog());
			db.endConnection();
			this.sessionData.setNewAdditionComplete(true);
			displayInfoMessageToUser("Modification Successfull", "CTL Modify");
			RequestContext.getCurrentInstance().closeDialog("editLayoutctl");
		}

	}
	
	public void sendMail(String layoutid,String sublayoutid,String userLog)
	{
		log.info("--SENDING EMAIL TO --" + userLog);
		String to="";
		if(userLog.compareTo(getUserinfo().getFullname())!=0)
		{
			String query = "select email from aipd_users where fullname='"
					+ userLog + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			
			if (rs != null && rs.size() > 1) {
				
				to = rs.get(1).get(0);
			}
			String Content = "Dear "
					+ userLog
					+ ",\n"
					+ "Your Layout Has Been Modified .Please Verify.\n"
					+ "Layout Information : \n"
					+ "Layout ID : "
					+ layoutid
					+ ". \n"
					+"Sublayoutid :"
					+ sublayoutid
					+". \n"
					+ "Payor : "
					+ getSelectedpayer()
					+ ". \n"
					+ "Modified Date : "
					+ new Date()
					+ ". \n"
					+ "Modified By : "
					+ getUserinfo().getFullname()
					+ ".";
					
			System.out.println("Content : " + Content);
		EmailConfiguration emailobj=new EmailConfiguration();
		emailobj.setTo(to);
		ArrayList<String> ccList=new ArrayList<String>();
		ccList.add("Shekhar.Poudel@verscend.com");
		ccList.add("Nijel.Shrestha@verscend.com");
		//ccList.add("Anish.Rauniyar@verscend.com");
		
		emailobj.setCc(ccList);
		emailobj.setSubject("Layout Modified");
		emailobj.setContent(Content);
		int status=emailobj.sendMail();
		if(status==1)
		{
			log.info("Email Sent");
		}
		else
		{
			log.info("Couldnot send email");
		}
		
		
		}
		
		
	}

}
