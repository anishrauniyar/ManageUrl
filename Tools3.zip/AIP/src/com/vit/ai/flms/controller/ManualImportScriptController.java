/* 
 *Class Name : ManualImportScriptController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.tmatesoft.svn.core.io.SVNRepository;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.ProcessBuilderRunner;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.svnconnection.ConnecttoSVN;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Manual Override
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 27 Feb 2015
 */
@ManagedBean
@ViewScoped
public class ManualImportScriptController extends AbstractController {

	private String layoutid;
	private String oldContent;
	private String newContent;
	private String username;
	private String manualflag;
	private String reasonForManualOverride;
	@ManagedProperty(value = "#{loginbean}")
	protected ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public String getManualflag() {
		return manualflag;
	}

	public void setManualflag(String manualflag) {
		this.manualflag = manualflag;
	}

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public String getOldContent() {
		return oldContent;
	}

	public void setOldContent(String oldContent) {
		this.oldContent = oldContent;
	}

	public String getNewContent() {
		return newContent;
	}

	public void setNewContent(String newContent) {
		this.newContent = newContent;
	}

	public ManualImportScriptController() {

		
	}

	@PostConstruct
	public void init() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.layoutid = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("lid");
		this.manualflag = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("mf");
		this.username = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("uid");
		if (this.manualflag.compareTo("N") == 0) {

			oldContent = ProcessBuilderRunner.runImportScript(layoutid, "N");
			oldContent = "--Import Script Modified by " + this.username
					+ " at " + new Date() + "\n" + oldContent;
			newContent = oldContent;
		} else {
			oldContent = checkoutimpScript(layoutid, username);
			newContent = oldContent;
		}

	}

	public String checkoutimpScript(String layoutID, String username) {

		String content = "";

		ConnecttoSVN conn = new ConnecttoSVN();
		SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
		try {
			System.out.println("CHECKING OUT");
			content = conn.checkoutSVNwithfile(repos, AIConstant.SVNSQL_PATH,
					"IP_" + layoutID + ".sql");

		} catch (Exception e) {

			displayInfoMessageToUser("SVN Checkout-Falied.Please try again ",
					"SVN-CheckOUT");
		}

		return content;
	}

	
	public void checkin(String userid)
	{
		
			String importScript = newContent;
			String attr = "";
			String cattr = "";
			
			System.out.println("ATTRIBUTE FOR MANUAL OVERRIDEN");

			//importScript = ProcessBuilderRunner.runImportScript(layoutid, "N");
			attr = ProcessBuilderRunner.runAttr(layoutid);
			cattr = ProcessBuilderRunner.runCAttr(layoutid);
			ConnecttoSVN conn = new ConnecttoSVN();
			SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
			
				try {
					if (importScript.isEmpty() || importScript == null
							|| importScript.compareTo("ERROR") == 0) {
						System.out.println("IMPORT SCRIPT :  " + importScript);

					} else {
						conn.committoSVNwithfile(repos, AIConstant.SVNSQL_PATH, "IP_"
								+ layoutid + ".sql", importScript);

						conn.SVNPopulatedb(this.layoutid, "Import", "IP_" + this.layoutid
								+ ".sql", userid);
						displayInfoMessageToUser("IP_" + layoutid
								+ ".sql checked in successfully", "SVN-CheckIn");
						updateManualFlag();
						this.sessionData.setManualOverrideComplete(true);
						RequestContext.getCurrentInstance()
								.closeDialog("imporscripteditor");
						FacesContext.getCurrentInstance();
						displayInfoMessageToUser("Manual Override succesfull",
								"Manual Override");

					}
				} catch (Exception e) {

					displayInfoMessageToUser(
							"SVN Checkin-Falied.Please try again ",
							"SVN-CheckIn");
				}
			
			try {
				repos = conn.connect(AIConstant.SVNATTR_PATH);
				if (attr.isEmpty() || attr == null
						|| attr.compareTo("ERROR") == 0) {
					System.out.println("No Attribute Definition");
				} else {
					conn.committoSVNwithfile(repos, AIConstant.SVNATTR_PATH,
							layoutid + ".attr", attr);
					displayInfoMessageToUser(layoutid
							+ ".attr checked in successfully", "SVN-CheckIn");
					conn.SVNPopulatedb(layoutid, "attr", layoutid + ".attr",
							userid);
				}
			} catch (Exception e) {

				displayInfoMessageToUser(
						"SVN Checkin-Falied.Please try again ", "SVN-CheckIn");
			}
			try {
				repos = conn.connect(AIConstant.SVNCATTR_PATH);

				if (cattr.contains("INVALID")) {
					displayErrorMessageToUser(
							"No Mappings defined for Control total",
							"Error in Cattr Checkin");
					return;
				}
				if (cattr.isEmpty() || cattr == null
						|| cattr.compareTo("ERROR") == 0) {

				} else {
					conn.committoSVNwithfile(repos, AIConstant.SVNCATTR_PATH,
							layoutid + ".cattr", cattr);
					displayInfoMessageToUser(layoutid
							+ ".cattr checked in successfully", "SVN-CheckIn");
					conn.SVNPopulatedb(layoutid, "cattr", layoutid + ".cattr",
							userid);
				}

			} catch (Exception e) {
				displayInfoMessageToUser(
						"SVN Checkin-Falied.Please try again ", "SVN-CheckIn");
			}
		}

	
	/*public void checkin(String userid) {

		ConnecttoSVN conn = new ConnecttoSVN();
		SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
		try {

			conn.committoSVNwithfile(repos, AIConstant.SVNSQL_PATH, "IP_"
					+ layoutid + ".sql", newContent);

			conn.SVNPopulatedb(this.layoutid, "Import", "IP_" + this.layoutid
					+ ".sql", userid);
			displayInfoMessageToUser("IP_" + layoutid
					+ ".sql checked in successfully", "SVN-CheckIn");
			updateManualFlag();
			this.sessionData.setManualOverrideComplete(true);
			RequestContext.getCurrentInstance()
					.closeDialog("imporscripteditor");
			FacesContext.getCurrentInstance();
			displayInfoMessageToUser("Manual Override succesfull",
					"Manual Override");
		} catch (Exception e) {

			displayInfoMessageToUser("SVN Checkin-Falied.Please try again ",
					"SVN-CheckIn");

		}

	}
*/
	public void updateManualFlag() {
		String query = "update imp_layouts set MANUALFLAG='Y' , manualoverridereason= '"
				+ this.reasonForManualOverride.replaceAll("\'", "\''")
				+ "' where layoutid='" + this.layoutid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		db.executeDML(query);
		db.endConnection();

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getReasonForManualOverride() {
		return reasonForManualOverride;
	}

	public void setReasonForManualOverride(String reasonForManualOverride) {
		this.reasonForManualOverride = reasonForManualOverride;
	}

}
