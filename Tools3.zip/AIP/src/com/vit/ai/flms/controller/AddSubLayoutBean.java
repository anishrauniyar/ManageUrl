/* 
 *Class Name : AddSubLayoutBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for adding new sublayout
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 25 July 2014
 */
@ManagedBean
@ViewScoped
public class AddSubLayoutBean extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;

	private LinkedHashMap<String, String> layoutTypes;

	private String layoutType;
	private String layoutDetail;
	private String whereClause;
	private String subLayoutDesc;
	private String csvValues;
	private boolean dupColCheck;
	private boolean colLengthGT30;
	private boolean layoutPopulated;
	private boolean invalidColumn;
	protected boolean invalfieldlenthVal;
	protected boolean invalDatatype;
	private boolean validationComplete;
	private String layoutID;
	private String livelayoutID;
	private String sumflag;
	private String trailerflag;
	private boolean fromMaster = false;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getWhereClause() {
		return whereClause;
	}

	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}

	public String getSubLayoutDesc() {
		return subLayoutDesc;
	}

	public void setSubLayoutDesc(String subLayoutDesc) {
		this.subLayoutDesc = subLayoutDesc;
	}

	public LinkedHashMap<String, String> getLayoutTypes() {
		return layoutTypes;
	}

	public void setLayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		this.layoutTypes = layoutTypes;
	}

	public String getLayoutDetail() {
		return layoutDetail;
	}

	public void setLayoutDetail(String layoutDetail) {
		this.layoutDetail = layoutDetail;
	}

	public String getCsvValues() {
		return csvValues;
	}

	public boolean isInvalfieldlenthVal() {
		return invalfieldlenthVal;
	}

	public void setInvalfieldlenthVal(boolean invalfieldlenthVal) {
		this.invalfieldlenthVal = invalfieldlenthVal;
	}

	public boolean isInvalDatatype() {
		return invalDatatype;
	}

	public void setInvalDatatype(boolean invalDatatype) {
		this.invalDatatype = invalDatatype;
	}

	public void setCsvValues(String csvValues) {
		this.csvValues = csvValues;
	}

	public boolean isDupColCheck() {
		return dupColCheck;
	}

	public void setDupColCheck(boolean dupColCheck) {
		this.dupColCheck = dupColCheck;
	}

	public boolean isColLengthGT30() {
		return colLengthGT30;
	}

	public void setColLengthGT30(boolean colLengthGT30) {
		this.colLengthGT30 = colLengthGT30;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public boolean isLayoutPopulated() {
		return layoutPopulated;
	}

	public void setLayoutPopulated(boolean layoutPopulated) {
		this.layoutPopulated = layoutPopulated;
	}

	public boolean isInvalidColumn() {
		return invalidColumn;
	}

	public void setInvalidColumn(boolean invalidColumn) {
		this.invalidColumn = invalidColumn;
	}

	public boolean isValidationComplete() {
		return validationComplete;
	}

	public void setValidationComplete(boolean validationComplete) {
		this.validationComplete = validationComplete;
	}

	public AddSubLayoutBean() {
		init();
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getLivelayoutID() {
		return livelayoutID;
	}

	public void setLivelayoutID(String livelayoutID) {
		this.livelayoutID = livelayoutID;
	}

	public boolean isFromMaster() {
		return fromMaster;
	}

	public void setFromMaster(boolean fromMaster) {
		this.fromMaster = fromMaster;
	}

	public void init() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		String check = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("isFromMaster");
		if (check != null) {
			if (check.compareTo("true") == 0) {
				this.fromMaster = true;
			} else {
				this.fromMaster = false;
			}
		} else {
			this.fromMaster = false;
		}
		LayoutType objLayoutType = new LayoutType();
		layoutTypes = objLayoutType.getlayoutTypes();

		setColLengthGT30(true);
		setDupColCheck(true);
		setInvalidColumn(true);
		setLayoutPopulated(true);
		setInvalDatatype(true);
		setInvalfieldlenthVal(true);
	}

	public void checkLayout() {
		String layouttype = getLayoutType();
		String whereclause = getWhereClause();
		AddLayoutBean objALB = new AddLayoutBean();
		System.out.println("WHERECLASUE :" + whereclause);
		if(whereclause==null)
		{
			whereclause ="";
		}
		String messageString = "";
		
		if (!isLayoutPopulated()) {
			messageString = "Please provide layout information.";
			validationComplete = false;
		} else if (!isColLengthGT30()) {
			messageString = "Column length is greater than 30. Please change it.";
			validationComplete = false;
		} else if (!isDupColCheck()) {
			messageString = "Duplicate column name. Please change it.";
			validationComplete = false;
		} else if (!isInvalidColumn()) {
			messageString = "Invalid column name.Please change it.";
			validationComplete = false;
		} else if (!isInvalDatatype()) {
			messageString = "Invalid data type.Please change it.";
			validationComplete = false;
		} else if (!isInvalfieldlenthVal()) {
			messageString = "Invalid field length value.Please change it.";
			validationComplete = false;
		}

	
		else if (!objALB.checkwhereclause(whereclause.toLowerCase())) {
			messageString = "Invalid where clause.Please change it.";
			validationComplete = false;
		} else {
			String result = checkDuplicate();
			if (result.equalsIgnoreCase("NEW")) {
				messageString = "Validation complete. Please submit.";
				validationComplete = true;
			} else {
				messageString = result + " of Layout ID: " + layoutID
						+ ". Please verify.";
				validationComplete = false;
			}
		}

		displayInfoMessageToUser(messageString, "New Sub Layout");

	}

	public String checkDuplicate() {
		String result = "NEW";
		try {
			ConnectDB db = new ConnectDB();
			CustomUtility objCU = new CustomUtility();

			String oldSubLayoutDetails = "";
			String newSubLayoutDetails = objCU
					.convertArrayToString(csvValues.split("~"), 1)
					.replaceAll("\"", "").replaceAll(";", "")
					.replaceAll(",,", "");
			String query = "SELECT SUBLAYOUTID FROM IMP_SUB_LAYOUTS WHERE LAYOUTID='"
					+ layoutID + "' GROUP BY SUBLAYOUTID";

			db.initialize();
			List<List<String>> listOfSubLayoutID = db
					.resultSetToListOfList(query);
			List<List<String>> listDetails;

			if (listOfSubLayoutID.size() > 1) {

				for (int i = 1; i < listOfSubLayoutID.size(); i++) {

					query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||FIELDLENGTH AS FIELDDATA "
							+ " FROM IMP_LAYOUTS_FIELDS "
							+ " WHERE LAYOUTID ='"
							+ layoutID
							+ "' AND SUBLAYOUTID='"
							+ listOfSubLayoutID.get(i).get(0)
							+ "' "
							+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";

					oldSubLayoutDetails = "";

					listDetails = db.resultSetToListOfList(query);
					if (listDetails.size() > 1) {
						for (int j = 1; j < listDetails.size(); j++) {
							oldSubLayoutDetails = oldSubLayoutDetails
									+ listDetails.get(j).get(0);
						}
					} else {
						result = "NEW";
						break;
					}

					if (oldSubLayoutDetails
							.equalsIgnoreCase(newSubLayoutDetails)) {
						result = "Exact Duplicate of SubLayoutID:"
								+ listOfSubLayoutID.get(i).get(0);
						break;
					}

				}
			} else {
				result = "NEW";
			}
			db.endConnection();
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("Cannot locate file.Please Try Again",
					"Error");
		}
		return result;

	}

	public void add() {
		if (!this.fromMaster)
			RequestContext.getCurrentInstance().execute(
					"parent.PF('subdialog').hide();");

		if (this.layoutID == null || this.layoutID.compareTo("") == 0) {
			displayErrorMessageToUser("No Layout Selected", "ERROR");
			return;
		}
		String result = checkDuplicate();
		try {

			if (result.equalsIgnoreCase("NEW")) {
				
				if(this.trailerflag==null)
				{
					this.trailerflag = "";
				}
				
				if(this.subLayoutDesc.compareTo("CONTROLTOTAL")!=0)
				{
					this.sumflag = "";
					this.trailerflag = "";
				}
				else
				{
					
					if(this.trailerflag.compareTo("Y")==0)
					{
						this.whereClause="";
					}
				}
				ConnectDB db = new ConnectDB();

				db.initialize();

				String query = "SELECT MAX(SUBLAYOUTID) +1 FROM IMP_SUB_LAYOUTS WHERE LAYOUTID='"
						+ layoutID + "'";

				String sn = "0";
				List<List<String>> snList = db.resultSetToListOfList(query);
				if (snList.size() > 1) {
					sn = snList.get(1).get(0);
				} else {
					sn = "0";
				}

				query = "INSERT INTO IMP_SUB_LAYOUTS(LAYOUTID, SUBLAYOUTID, LAYOUTTYPE, "
						+ " WHERECLAUSE,SUBLAYOUTDESC,SUMFLAG,TRAILERFLAG) VALUES('"
						+ layoutID
						+ "', "
						+ " '"
						+ sn
						+ "', "
						+ " '"
						+ layoutType.replaceAll("'", "''")
						+ "',"
						+ " '"
						+ whereClause.replaceAll("'", "''")
						+ "','"
						+ subLayoutDesc + "','"+this.sumflag+"','"+this.trailerflag + "')";

				db.executeDML(query);

				String splitValues[] = csvValues.split("~");
				String excelDatas[] = new String[splitValues.length - 1];

				String ins = "";
				int substrpos = 0;
				int tempSubstr = 0;
				int start = 0;
				int i;

				for (i = 1; i < splitValues.length; i++) {
					excelDatas[i - 1] = splitValues[i].replaceAll("\"", "'")
							.replaceAll(";", ",").replaceAll(",,", ",'',");

					String[] listofFields = excelDatas[i - 1].split(",");
					String columnname = listofFields[0];
					String datatype = listofFields[1];
					String dtdetail = listofFields[2];
					String length = listofFields[3];
					String busname = "";
					try {
						busname = listofFields[4];
					} catch (Exception ex) {
						busname = "''";
					}

					tempSubstr = substrpos;
					start = tempSubstr + 1;
					String temp = excelDatas[i - 1].substring(0,
							excelDatas[i - 1].lastIndexOf(",") - 1);

					System.out.println(temp);

					tempSubstr = Integer.parseInt(temp.substring(
							temp.lastIndexOf(",") + 1).replaceAll("'", ""));
					substrpos += tempSubstr;

					ins = "INSERT INTO IMP_LAYOUTS_FIELDS(LAYOUTID, SUBLAYOUTID, COLUMNID, COLUMNNAME, DATATYPE,"
							+ " DATETYPEDETIAL, FIELDLENGTH,BUSINESSNAME ,STARTPOS,ENDPOS,CATEGORY)"
							+ " VALUES('"
							+ layoutID
							+ "','"
							+ sn
							+ "','"
							+ i
							+ "',"
							+ columnname
							+ ","
							+ datatype
							+ ","
							+ dtdetail
							+ ","
							+ length
							+ ","
							+ busname
							+ ","
							+ start
							+ ","
							+ substrpos + ",'" + remapCategory(datatype.replaceAll("'", "")) + "')";

					if (ins.substring(ins.length() - 2).equalsIgnoreCase(",)")) {
						ins = ins.substring(0, ins.length() - 2);
						ins = ins + ",'')";
					}

					db.executeDML(ins);
				}

				if (layoutType.toLowerCase().startsWith("fixe")
						|| layoutType.toLowerCase().startsWith("subs")) {
					layoutDetail = substrpos + "";
				} else {
					layoutDetail = (i - 1) + "";
				}

				ins = "UPDATE IMP_SUB_LAYOUTS SET LAYOUTDETAIL='"
						+ layoutDetail + "' WHERE LAYOUTID='" + layoutID
						+ "' AND SUBLAYOUTID='" + sn + "'";

				db.executeDML(ins);
				db.endConnection();
				if (this.fromMaster) {

					FacesContext.getCurrentInstance();
					RequestContext.getCurrentInstance().closeDialog(
							"addSubLayout");

				}

				if (this.subLayoutDesc.compareTo("CONTROLTOTAL") == 0) {

					RequestContext.getCurrentInstance().execute(
							"parent.PF('subdialogforctl1').show();");

				} else {

					RequestContext.getCurrentInstance().execute(
							"parent.PF('subdialog').show();");

				}

				livelayoutID = this.layoutID;
				RequestContext.getCurrentInstance().execute(
						"parent.PF('subframe').hide();");

			} else {
				displayErrorMessageToUser(result, "New Sub Layout");
				validationComplete = false;
			}

		} catch (ArrayIndexOutOfBoundsException ex) {

			displayErrorMessageToUser(
					"Couldnot Verify Layout.Please Try Again", "Error");
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser(
					"Could not add sublayout.Please Try Again", "Error");
			System.out.println(ex.toString());
		}

		resetAll();

	}
	
	/* Find appropriate category if category is not pre populated */
	public String remapCategory(String datatype) {
		String category = "";

		String query = "SELECT a.DATATYPE_NAME,b.CATEGORY_NAME FROM dp_catgry_datatype_mapping a left JOIN DP_CHECK_CATEGORIES  b ON   a.cat_sn = b.cat_sn where  a.DATATYPE_NAME='"
				+ datatype + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				category = rs.get(1).get(1);
			} else {
				category = datatype;
			}
		}
		return category;

	}


	public void resetAll() {

		this.layoutTypes = null;
		this.layoutType = null;
		this.layoutDetail = null;
		this.whereClause = null;
		this.subLayoutDesc = null;
		this.csvValues = null;
		this.dupColCheck = false;
		this.colLengthGT30 = false;
		this.layoutPopulated = false;
		this.invalidColumn = false;
		this.validationComplete = false;
		this.layoutID = null;
		this.invalfieldlenthVal = false;
		this.invalDatatype = false;
	}

	public String getLayoutID() {

		if (!this.isFromMaster()) {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			this.layoutID = (String) facesContext.getExternalContext()
					.getRequestParameterMap().get("layoutid");
			if (this.layoutID == null) {
				this.validationComplete = false;
				this.layoutID = livelayoutID;
			}
		} else {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			this.layoutID = (String) facesContext.getExternalContext()
					.getRequestParameterMap().get("lid");
		}
		return layoutID;
	}

	public void cancel() {
		RequestContext.getCurrentInstance().closeDialog("addSubLayout");

	}

	public String getSumflag() {
		return sumflag;
	}

	public void setSumflag(String sumflag) {
		this.sumflag = sumflag;
	}

	public String getTrailerflag() {
		return trailerflag;
	}

	public void setTrailerflag(String trailerflag) {
		this.trailerflag = trailerflag;
	}
}
