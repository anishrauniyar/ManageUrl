/* 
 *Class Name : PatternTest.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for Pattern Validation
 * 
 * @author Aashish Dhungana
 *
 * @version 1.0 27 Dec 2014
 */
@ManagedBean
@ViewScoped
public class PatternTest extends AbstractController implements Serializable {

	private static final long serialVersionUID = 1L;
	private String patterntoTest;
	private String csvvalues;
	private String type;

	private int colnum = 0;
	private boolean matched;
	private String mainData;
	private String data;
	boolean validtovalidate = false;
	boolean validpattern = true;
	private String client = "";
	private boolean isFromUpdate = false;
	private LinkedHashMap<String, String> clients;
	private String oldpattern = "";

	private ArrayList<String> matchedStrings;
	private boolean csin;
	private boolean clientSelected;
	private ArrayList<String> helpresult;
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public boolean isValidpattern() {
		return validpattern;
	}

	public void setValidpattern(boolean validpattern) {
		this.validpattern = validpattern;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public boolean isValidtovalidate() {
		return validtovalidate;
	}

	public void setValidtovalidate(boolean validtovalidate) {
		this.validtovalidate = validtovalidate;
	}

	public String getPatterntoTest() {
		return patterntoTest;
	}

	public void setPatterntoTest(String patterntoTest) {
		this.patterntoTest = patterntoTest;
	}

	public String getCsvvalues() {
		return csvvalues;
	}

	public void setCsvvalues(String csvvalues) {
		this.csvvalues = csvvalues;
	}

	public int getColnum() {
		return colnum;
	}

	public void setColnum(int colnum) {
		this.colnum = colnum;
	}

	public boolean isMatched() {
		return matched;
	}

	public void setMatched(boolean matched) {
		this.matched = matched;
	}

	public PatternTest() {

	}

	@PostConstruct
	public void init() {
		this.csvvalues = "";
		setClients(new LinkedHashMap<String, String>());
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.type = facesContext.getExternalContext().getRequestParameterMap()
				.get("type");
		this.client = facesContext.getExternalContext()
				.getRequestParameterMap().get("clientid");
		String requestFrom = facesContext.getExternalContext()
				.getRequestParameterMap().get("requesttype");

		if (requestFrom.compareTo("new") == 0) {
			this.setFromUpdate(false);
		} else {
			this.setFromUpdate(true);
		}
		if (this.type.compareTo("data") == 0) {
			if (!getSessionData().getValidpattern().equals("")
					|| getSessionData().getValidpattern() != null) {
				this.patterntoTest = getSessionData().getValidpattern();
				this.oldpattern = this.patterntoTest;

			}
		} 
		populateHelp();
	}

	public void TestPattern() {

		int count = 0;
		org.primefaces.context.RequestContext.getCurrentInstance().execute(
				"$(\"#editTable\").handsontable('render');");
		if (this.csin == true) {
		}
		String regex = this.patterntoTest;

		if (this.patterntoTest != null && this.patterntoTest.compareTo("") != 0) {

			
			if (this.csvvalues.length() > 30) {
				String splitValues[] = csvvalues.split("~");
				String excelDatas[] = new String[splitValues.length - 1];
				for (int i = 1; i < splitValues.length; i++) {
					excelDatas[i - 1] = splitValues[i].replaceAll("\"", "")
							.replaceAll(";", ",").replaceAll(",,", ",'',");
					if (!excelDatas[i - 1].isEmpty()) {
						if (csin == true) {
							excelDatas[i - 1] = excelDatas[i - 1].toUpperCase();
						}
						try {
							ConnectDB db = new ConnectDB();
							db.initialize();
						

							List<List<String>> rs = db
									.resultSetToListOfList("select 1 from dual where aip_file_match('"
											+ excelDatas[i - 1].replaceAll("\'", "\''")
											+ "','"
											+ regex.replaceAll("'", "''")
											+ "')=1");
							db.endConnection();
							if (rs != null && rs.size() > 1) {

								if (rs.get(1).get(0).compareTo("1") == 0) {
									org.primefaces.context.RequestContext
											.getCurrentInstance().execute(
													"renderer(" + i + ");");
									count++;
								} else {
									org.primefaces.context.RequestContext
											.getCurrentInstance().execute(
													"redrenderer(" + i + ");");
								}
							}
						} catch (Exception ex) {
							displayErrorMessageToUser(
									"Invalid Pattern.Please try again",
									"Pattern Validator");
						}
					}

				}
				if (count == splitValues.length - 1) {
					this.validtovalidate = true;
				} else {
					this.validtovalidate = false;
				}
			} else {
				displayErrorMessageToUser("Provide list of filenames", "Error");
			}
		} else {
			displayErrorMessageToUser("Provide Pattern to check", "Error");
		}
	}

	public List<List<String>> validator() {
		List<List<String>> rs = new ArrayList<>();

		if (this.csvvalues.length() > 40) {
			String splitValues[] = csvvalues.split("~");
			String excelDatas[] = new String[splitValues.length - 1];
			for (int i = 1; i < splitValues.length; i++) {
				excelDatas[i - 1] = splitValues[i].replaceAll("\"", "")
						.replaceAll(";", ",").replaceAll(",,", ",'',");
				if (!excelDatas[i - 1].isEmpty()) {
					if (csin == true) {
						excelDatas[i - 1] = excelDatas[i - 1].toUpperCase();
					}
					try {
						ConnectDB db = new ConnectDB();
						db.initialize();

						rs = db.resultSetToListOfList("select 'DATA',a.* from imp_clientpatterns a where clientid='"
								+ this.client.split("-")[0].trim()
								+ "' and  aip_file_match('"
								+ excelDatas[i - 1].replaceAll("\'", "\''")
								+ "',pattern)=1 ");

						db.endConnection();

					} catch (Exception ex) {
						displayErrorMessageToUser(
								"Invalid Pattern.Please try again",
								"Pattern Validator");
					}
				}
			}

		}
		return rs;
	}

	public List<List<String>> validatorforupdate(String pattern,
			String updatetype) {
		List<List<String>> rs = new ArrayList<>();

		if (this.csvvalues.length() > 40) {
			String splitValues[] = csvvalues.split("~");
			String excelDatas[] = new String[splitValues.length - 1];
			for (int i = 1; i < splitValues.length; i++) {
				excelDatas[i - 1] = splitValues[i].replaceAll("\"", "")
						.replaceAll(";", ",").replaceAll(",,", ",'',");
				if (!excelDatas[i - 1].isEmpty()) {
					if (csin == true) {
						excelDatas[i - 1] = excelDatas[i - 1].toUpperCase();
					}
					try {
						switch (updatetype) {
						case "DATA": {
							ConnectDB db = new ConnectDB();
							db.initialize();
							String query = "select 'DATA',a.* from imp_clientpatterns a  where clientid='"
									+ this.client.split("-")[0].trim()
									+ "' and pattern!='"
									+this.oldpattern.replace("\'", "\''")
									+ "' and aip_file_match('"
									+ excelDatas[i - 1].replaceAll("\'", "\''")
									+ "',pattern)=1";
							System.out.println(query);

							rs = db.resultSetToListOfList(query);

							db.endConnection();

						}
							break;
						

						default: {
							System.out
									.println("WRONG CHOICE--PATTERN VALIDATION");
						}
							break;
						}

					} catch (Exception ex) {
						displayErrorMessageToUser(
								"Invalid Pattern.Please try again",
								"Pattern Validator");
					}
				}
			}

		}
		return rs;
	}

	public void validate() {

		List<List<String>> rs = new ArrayList<>();
		if (type == null) {
			type = "data";
		}
		this.matchedStrings = new ArrayList<String>();
		TestPattern();
		if (this.validtovalidate == true) {
			
			System.out.println("Is from update : " + this.isFromUpdate);

			if (this.isFromUpdate && this.type.compareTo("data") == 0) {

				rs = validatorforupdate(this.patterntoTest, "DATA");
				
				System.out.println("RS size : " + rs.size());
			} 
			else {
				rs = validator();
			}
			String matchedpattern = "";
			String clientid = "";
			String layoutid = "";
			String empgrp = "";
			String pattern = "";
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					matchedpattern = rs.get(i).get(0);
					clientid = rs.get(i).get(2);
					layoutid = rs.get(i).get(4);
					empgrp = rs.get(i).get(5);
					if (matchedpattern.compareTo("DATA") == 0) {
						pattern = rs.get(i).get(3);
					} else {
						pattern = rs.get(i).get(15);
					}
					this.matchedStrings.add("ClientID:" + clientid
							+ "     LayoutID:" + layoutid
							+ "      Employer Group :" + empgrp
							+ "      pattern :" + pattern);
				}

			}
		}

		if (this.matchedStrings.size() > 0) {
			this.validpattern = false;
		} else {
			this.validpattern = true;

			if (type.compareTo("data") == 0) {
				try {
					RequestContext.getCurrentInstance().closeDialog(
							"patternchecker");
				} catch (Exception ex) {
					RequestContext.getCurrentInstance().execute(
							"parent.PF('pttvalidator').hide();");
				}
				this.sessionData.setValidpattern(this.patterntoTest);

			} 

		}
	}

	public String getMainData() {
		return mainData;
	}

	public void setMainData(String mainData) {
		this.mainData = mainData;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		String query = "SELECT Nvl(CLIENTID,'NA'),Nvl(CLIENTNAME,'NA') FROM HAWKEYEMASTER.M_CLIENTS ORDER BY CLIENTID";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}

		this.clients = clients;
	}

	public ArrayList<String> getMatchedStrings() {
		return matchedStrings;
	}

	public void setMatchedStrings(ArrayList<String> matchedStrings) {
		this.matchedStrings = matchedStrings;
	}

	public boolean isCsin() {
		return csin;
	}

	public void setCsin(boolean csin) {
		this.csin = csin;
	}

	public boolean isClientSelected() {
		clientSelected = this.client.isEmpty();
		return clientSelected;
	}

	public void setClientSelected(boolean clientSelected) {
		this.clientSelected = clientSelected;
	}

	public ArrayList<String> getHelpresult() {
		return helpresult;
	}

	public void setHelpresult(ArrayList<String> helpresult) {
		this.helpresult = helpresult;
	}

	public void populateHelp() {
		if (this.client == null) {
			this.client = "";
		}
		if (this.client != null || !this.client.isEmpty()) {
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "SELECT DISTINCT Pattern FROM tbl_filepatterns  WHERE clientid='"
					+ this.client + "'";
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			this.helpresult = new ArrayList<String>();
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.helpresult.add(rs.get(i).get(0));
				}
			}

		}
	}

	public boolean isFromUpdate() {
		return isFromUpdate;
	}

	public void setFromUpdate(boolean isFromUpdate) {
		this.isFromUpdate = isFromUpdate;
	}

	public String getOldpattern() {
		return oldpattern;
	}

	public void setOldpattern(String oldpattern) {
		this.oldpattern = oldpattern;
	}
}
