/*
 * Class Name : EmployerController.java
 * 
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.vit.ai.flms.model.Employer;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 03 Sep 2014
 */
@ManagedBean
@ViewScoped
public class EmployerController extends AbstractController implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected ArrayList<Employer> mainLogs;
	private String oldvalue;

	private Employer selectedLogs;

	protected LinkedHashMap<String, String> clients;

	public Employer getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(Employer selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	protected String query;
	protected String client;
	protected LinkedHashMap<String, String> months;
	private String clientid;
	private String empgrp;
	private String clientID;
	private String empgrpname;
	private String shortname;
	private String createddate;
	private String createdby;

	// private String username;

	public String getEmpgrpname() {
		return empgrpname;
	}

	public void setEmpgrpname(String empgrpname) {
		this.empgrpname = empgrpname;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	protected FilterLogController filterData;
	public double i = 0;

	public EmployerController() {
		i = 0;
		init();
	}

	public void init() {

		clients = new LinkedHashMap<String, String>();
		setClients(clients);

	}

	public ArrayList<Employer> getMainLogs() {
		return mainLogs;
	}

	public String getEmpgrp() {
		return empgrp;
	}

	public void setEmpgrp(String empgrp) {
		this.empgrp = empgrp;
	}

	public void setMainLogs(ArrayList<Employer> mainLogs) {

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> logList = db.resultSetToListOfList(query);
		db.endConnection();

		if (logList.size() > 0) {
			for (int i = 1; i < logList.size(); i++) {
				mainLogs.add(new Employer(logList.get(i).get(0), logList.get(i)
						.get(1), logList.get(i).get(2), logList.get(i).get(2),
						logList.get(i).get(3), logList.get(i).get(4)));

			}

		}

	}

	public void handleclientchange() {
		try {
			String clientname = this.client;
			String[] client = clientname.split("\\-");
			clientid = client[0];

			String query = "SELECT DISTINCT clientid,empshortname,empname,created_date,created_by FROM imp_employer_master WHERE CLIENTID='"
					+ this.clientid + "'";

			System.out.println("EMP Query is  " + query);
			setQuery(query);

			mainLogs = new ArrayList<Employer>();
			setMainLogs(mainLogs);
		} catch (Exception e) {

			displayErrorMessageToUser(
					"Ops,client not found. Try again later! Error:"
							+ e.getMessage(), "Status");
			// e.printStackTrace();
		}

	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public void doNothing() {

	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clientList = db
				.resultSetToListOfList(" SELECT DISTINCT CLIENTID , CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS order by clientid asc ");

		db.endConnection();

		if (clientList.size() > 0) {
			for (int i = 1; i < clientList.size(); i++) {
				clients.put(clientList.get(i).get(0) + "-("
						+ clientList.get(i).get(1) + ")", clientList.get(i)
						.get(0));
			}
		}
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public void reset() {
		this.clientID = "";
		this.empgrpname = "";
		this.shortname = "";
		this.createddate = "";
		this.createdby = "";
	}

	public void addemp(String username) {
		try {
			String clientname = this.client;
			String[] client = clientname.split("\\-");
			clientid = client[0];
			String query = "INSERT INTO imp_employer_master(clientid, empshortname, empname, created_date, created_by) VALUES ('"
					+ this.clientid
					+ "','"
					+ this.shortname.toUpperCase().replaceAll("\'", "\'\'").trim()
					+ "','"
					+ this.empgrpname.toUpperCase().replaceAll("\'", "\'\'").trim()
					+ "',sysdate,'" + username + "')";
			// System.out.println("Query is "+query);
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result=db.executeDML(query);
			if(result.compareTo("1")==0){
				displayInfoMessageToUser("Added With Success", "Status");
				reset();
			}else{
				displayErrorMessageToUser(
						"Ops, we could not add. Try again later! Error:"
								, "Status");
				
				
			}
			// System.out.println("Employer groupname is inserted");
			db.endConnection();
			
		} catch (Exception e) {

			displayErrorMessageToUser(
					"Ops, we could not add. Try again later! Error:"
							+ e.getMessage(), "Status");
			// e.printStackTrace();
		}
		handleclientchange();
	}

	public void updateemp(String shortname, String empgname, String oldvalue,
			String username) {

		try {
			String clientname = this.client;
			String[] client = clientname.split("\\-");
			clientid = client[0];
			System.out.println(clientid);

			String query = "UPDATE imp_employer_master SET clientid='"
					+ this.clientid + "',empshortname='"
					+ shortname.toUpperCase().replaceAll("\'", "\'\'")
					+ "', empname='"
					+ empgname.toUpperCase().replaceAll("\'", "\'\'")
					+ "',created_date=sysdate,created_by='" + username
					+ "' WHERE CLIENTID='" + this.clientid + "' and empname='"
					+ oldvalue.replaceAll("\'", "\'\'") + "'";
			System.out.println("Query is " + query);
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result=db.executeDML(query);
			// System.out.println("record is updated");
			db.endConnection();
			if(result.compareTo("1")==0){
				displayInfoMessageToUser("Updated With Success", "Status");
				reset();
			}else{
				displayErrorMessageToUser(
						"Ops, we could not update. Try again later! Error:"
								, "Status");
			}
			
		} catch (Exception e) {

			displayErrorMessageToUser(
					"Ops, we could not update. Try again later! Error:"
							+ e.getMessage(), "Status");
			// e.printStackTrace();
		}
		handleclientchange();

	}

	public void deleteemp(String shortname) {
		try {
			String clientname = this.client;
			String[] client = clientname.split("\\-");
			clientid = client[0];

			// System.out.println("EMP group name is "+selectedLogs.getEmpgrpname()+clientid);

			String query = "DELETE FROM imp_employer_master where CLIENTID='"
					+ clientid + "' AND EMPSHORTNAME='"
					+ shortname.replaceAll("\'", "\'\'") + "'";
			System.out.println("Query is " + query);
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			// System.out.println("Record is deleted");
			db.endConnection();
			displayInfoMessageToUser(selectedLogs.getEmpgrpname()
					+ " is Deleted ", "Status");

		} catch (Exception e) {

			displayErrorMessageToUser(
					"Ops, we could not delete. Try again later! Error:"
							+ e.getMessage(), "Status");
			// e.printStackTrace();
		}
		handleclientchange();

	}

	public String getOldvalue() {
		return oldvalue;
	}

	public void setOldvalue(String oldvalue) {
		this.oldvalue = oldvalue;
	}

	public String getShortname() {
		return shortname;
	}

	public void setShortname(String shortname) {
		this.shortname = shortname;
	}

	public String getCreateddate() {
		return createddate;
	}

	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

}
