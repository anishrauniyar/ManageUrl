/* 
 *Class Name : LayoutController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.controller;

import java.io.File;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.event.CellEditEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.tmatesoft.svn.core.io.SVNRepository;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.commons.model.DataType;
import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.commons.model.PayerBean;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutBeanDatatype;
import com.vit.ai.flms.model.LayoutBeanbyPayer;
import com.vit.ai.flms.model.LayoutFields;
import com.vit.ai.flms.model.LayoutFieldsModel;
import com.vit.ai.flms.model.LayoutsByClients;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.flms.model.LayoutsbyStatus;
import com.vit.ai.flms.model.LayoutsbyUser;
import com.vit.ai.poireport.controller.TestDataExporter;
import com.vit.ai.remoteConnection.ProcessBuilderRunner;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.script.GenerateOldImportScript;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.svnconnection.ConnecttoSVN;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for FLMS layout
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.14 20 Apr 2015
 */
@ManagedBean
@ViewScoped
public class LayoutController extends AbstractController implements
		Serializable {

	static Logger log = Logger.getLogger(LayoutController.class.getName());
	private static final long serialVersionUID = 1L;
	private boolean edited = false;
	private String payer;
	private LinkedHashMap<String, String> payers;
	private ArrayList<Layout> layouts;
	private ArrayList<LayoutFields> layoutFields;
	private String layoutID;
	private String importScript;
	private DefaultStreamedContent downloadFile;
	@SuppressWarnings("rawtypes")
	private List testValue;
	private String filePath;
	private String clientsList;
	private ArrayList<String> clients = new ArrayList<String>();
	private String dataType;
	private LinkedHashMap<String, String> layoutsid;
	private ArrayList<String> usernames;
	private ArrayList<String> layoutids;
	private String filteredlayoutid;
	private String selectedClient;
	private Layout selectedLayouts;
	private boolean skip;
	private boolean layoutSelected;
	private String selectedfileType = "DATAFILE";
	private String attributes;
	private String cattributes;
	private String filtertype;
	private String selectedfiltertype;
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String topTen;
	private String lastTen;
	private String clientID;
	private String page;
	private LinkedHashMap<String, String> layoutTypes;
	private LinkedHashMap<String, String> dataTypes;
	protected ArrayList<Layout> flmsfilteredLogs;
	private String winScreenHeight;
	int i = 0;
	private String selectedStatus;
	/* For import script generation old one */
	private String HiTableName;
	private String ProcedureName;
	private DefaultStreamedContent downloadLog;
	private String importNrows = "";
	private ArrayList<String> listofSubLayouts;
	private String selectedsubLayout;
	private String fileID = "";
	boolean  testImportStatus=false;
	private DefaultStreamedContent downloadTestData;
	private String aiQuery="";
	private String nrowsAIData="20";
	private boolean testimportforNrows;
	private boolean testimportforwholeFile=true;
	private boolean getfileStatus=false;
	private String aiTable;
	private String getfilePath="";
	private DefaultStreamedContent downloadFileStats;
	private String layoutType = "";
	private String layoutDetail = "";
	private String statusLayout = "";
	private String manualFlag = "";
	private String datatypeAdvanced="";
	private String activeFlag="";
	private String sourceInfo="";
	private String payeradv="";
	private String datadictionaryUploaded = "";

	public String getPayeradv() {
		return payeradv;
	}

	public void setPayeradv(String payeradv) {
		this.payeradv = payeradv;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getLayoutDetail() {
		return layoutDetail;
	}

	public void setLayoutDetail(String layoutDetail) {
		this.layoutDetail = layoutDetail;
	}

	public String getStatusLayout() {
		return statusLayout;
	}

	public void setStatusLayout(String statusLayout) {
		this.statusLayout = statusLayout;
	}

	public String getManualFlag() {
		return manualFlag;
	}

	public void setManualFlag(String manualFlag) {
		this.manualFlag = manualFlag;
	}

	public String getDatatypeAdvanced() {
		return datatypeAdvanced;
	}

	public void setDatatypeAdvanced(String datatypeAdvanced) {
		this.datatypeAdvanced = datatypeAdvanced;
	}

	public boolean isTestimportforNrows() {
		return testimportforNrows;
	}

	public void setTestimportforNrows(boolean testimportforNrows) {
		this.testimportforNrows = testimportforNrows;
	}

	public boolean isTestimportforwholeFile() {
		this.testimportforwholeFile=true;
		return testimportforwholeFile;
	}

	public void setTestimportforwholeFile(boolean testimportforwholeFile) {
		this.testimportforwholeFile = testimportforwholeFile;
	}

	public boolean isTestImportStatus() {
		return testImportStatus;
	}

	public void setTestImportStatus(boolean testImportStatus) {
		this.testImportStatus = testImportStatus;
	}

	public DefaultStreamedContent getDownloadLog() {
		return downloadLog;
	}

	public void setDownloadLog(DefaultStreamedContent downloadLog) {
		this.downloadLog = downloadLog;
	}

	public boolean isControltotal() {
		return controltotal;
	}

	public void setControltotal(boolean controltotal) {
		this.controltotal = controltotal;
	}

	public boolean isShowlog() {
		return showlog;
	}

	public void setShowlog(boolean showlog) {
		this.showlog = showlog;
	}

	private DefaultStreamedContent downloadOldScriptFile;

	private DefaultStreamedContent downloadAllScript;

	private DefaultStreamedContent downloadAllCAttribute;
	private boolean controltotal = false;
	private boolean showlog = false;

	public String getHiTableName() {
		return HiTableName;
	}

	public void setHiTableName(String hiTableName) {
		HiTableName = hiTableName;
	}

	public String getProcedureName() {
		return ProcedureName;
	}

	public void setProcedureName(String procedureName) {
		ProcedureName = procedureName;
	}

	public String getSelectedStatus() {
		return selectedStatus;
	}

	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}

	public boolean isSkip() {
		return skip;
	}

	public void setSkip(boolean skip) {
		this.skip = skip;
	}

	public String getCattributes() {
		return cattributes;
	}

	public void setCattributes(String cattributes) {
		this.cattributes = cattributes;
	}

	public ArrayList<Layout> getFlmsfilteredLogs() {
		return flmsfilteredLogs;
	}

	public void setFlmsfilteredLogs(ArrayList<Layout> flmsfilteredLogs) {
		this.flmsfilteredLogs = flmsfilteredLogs;
	}

	public String getClientID() {
		return clientID;
	}

	public boolean isEdited() {
		return edited;
	}

	public void setEdited(boolean edited) {
		this.edited = edited;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}

	public String getSelectedfiltertype() {
		return selectedfiltertype;
	}

	public void setSelectedfiltertype(String selectedfiltertype) {
		this.selectedfiltertype = selectedfiltertype;
	}

	public ArrayList<String> getUsernames() {
		return usernames;
	}

	public void setUsernames(ArrayList<String> usernames) {
		this.usernames = usernames;
	}

	private String userlog;

	public ArrayList<Object> getCharacterSets() {
		return characterSets;
	}

	public void setCharacterSets(ArrayList<Object> characterSets) {
		this.characterSets = characterSets;
	}

	private ArrayList<Object> characterSets;

	public String getUserlog() {
		return userlog;
	}

	public void setUserlog(String userlog) {
		this.userlog = userlog;
	}

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		System.out.println("Payer : " + payer);
		this.payer = payer;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {
		this.payers = payers;
	}

	public ArrayList<Layout> getLayouts() {
		return layouts;
	}

	public void setLayouts(ArrayList<Layout> layouts) {

		this.layouts = layouts;
	}

	public ArrayList<LayoutFields> getLayoutFields() {
		return layoutFields;
	}

	public void setLayoutFields(ArrayList<LayoutFields> layoutFields) {
		this.layoutFields = layoutFields;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getImportScript() {
		return importScript;
	}

	public void setImportScript(String importScript) {
		this.importScript = importScript;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	@SuppressWarnings("rawtypes")
	public List getTestValue() {
		return testValue;
	}

	@SuppressWarnings("rawtypes")
	public void setTestValue(List testValue) {
		this.testValue = testValue;
	}

	public DefaultStreamedContent getDownloadFile() {
		return downloadFile;
	}

	public void setDownloadFile(DefaultStreamedContent downloadFile) {
		this.downloadFile = downloadFile;
	}

	public String getTopTen() {
		return topTen;
	}

	public void setTopTen(String topTen) {
		this.topTen = topTen;
	}

	public LayoutController(String override) {
	}

	public LayoutController() {
		try{
		setTestimportforwholeFile(true);
		setSelectedfiltertype("filterbypayers");
		PayerBean objPB = new PayerBean();
		payers = objPB.getPayers();
		
		DataType objDataType = new DataType();
		dataTypes = objDataType.getDataTypes();

		LayoutType objLayoutType = new LayoutType();
		layoutTypes = objLayoutType.getlayoutTypes();
		this.characterSets = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db
				.resultSetToListOfList("select charactersets from aip_character_sets order by 1");
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.characterSets.add(rs.get(i).get(0));
				}
			}
		}
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	public void handleuserChange() {
		try{
		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}

		if (userlog != null && !userlog.equals("")) {
			if (this.payer == null) {
				this.payer = "ALL PAYERS";

			}
			LayoutsbyUser objUIDB = new LayoutsbyUser("ALL PAYERS", userlog);
			layouts = objUIDB.getLayouts();
			this.dataType = "";
			this.filteredlayoutid = "";
			this.selectedClient = "";

		} else
			layouts = new ArrayList<Layout>();
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	
	
	public void handlefilterchange() {
		try{
		setSelectedfiltertype(getFiltertype());
		if (getFiltertype().compareTo("filterbylayoutid") == 0) {
			LayoutsbyID ojbLID = new LayoutsbyID("ALL PAYERS");
			this.layoutids = ojbLID.getLayoutids();

		} else if (getFiltertype().compareTo("filterbyuser") == 0) {
			LayoutsbyUser objUIDB = new LayoutsbyUser("ALL PAYERS");
			this.usernames = objUIDB.getUsers();
		} else if (getFiltertype().compareTo("filterbyclients") == 0) {
			LayoutsByClients ojbCL = new LayoutsByClients("ALL PAYERS");
			this.clients = ojbCL.getClients();
		}
		else if (getFiltertype().compareTo("filterbydatatype") == 0) {
			DataType objDataType = new DataType();
			this.dataTypes= objDataType.getDataTypes();
		}
		
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	public void handleLayoutIDChange() {
		try{
		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.filteredlayoutid != null && !filteredlayoutid.equals("")) {

			LayoutsbyID ojbLID = new LayoutsbyID("ALL PAYERS",
					this.filteredlayoutid);
			layouts = ojbLID.getLayouts();
			this.layoutID = null;
			this.userlog = "";
			this.dataType = "";
			this.selectedClient = "";
			this.selectedStatus = "";

		}
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}
	}

	public void handleDatatypeChange() {

		try{
		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (dataType != null && !dataType.equals("")) {

			LayoutBeanDatatype objLBDT = new LayoutBeanDatatype(dataType,
					"ALL PAYERS");
			layouts = objLBDT.getLayoutsDatatype();
			this.layoutID = null;

			this.userlog = "";
			this.filteredlayoutid = "";
			this.selectedClient = "";
			this.selectedStatus = "";
		} else
			layouts = new ArrayList<Layout>();
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	public void handleClientChange() {
		try{
		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (selectedClient != null && !selectedClient.equals("")) {
			if (this.payer == null) {
				this.payer = "ALL PAYERS";

			}
			LayoutsByClients ojbCL = new LayoutsByClients("ALL PAYERS",
					this.selectedClient);
			setClientID(this.selectedClient.split(" ")[0]);
			layouts = ojbCL.getLayouts();
			this.layoutID = null;
			this.userlog = "";
			this.filteredlayoutid = "";
			this.dataType = "";
			this.selectedStatus = "";
		} else
			layouts = new ArrayList<Layout>();
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	public void handleStatusChange() {
		try{
		System.out.println(this.selectedStatus);
		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}
		this.layoutID = null;
		if (selectedStatus != null && !selectedStatus.equals("")) {
			if (this.payer == null) {
				this.payer = "ALL PAYERS";

			}
			LayoutsbyStatus ojbCL = new LayoutsbyStatus("ALL PAYERS",
					this.selectedStatus);

			layouts = ojbCL.getLayouts();
			this.layoutID = null;
			this.userlog = "";
			this.filteredlayoutid = "";
			this.dataType = "";
			this.selectedClient = "";
		} else
			layouts = new ArrayList<Layout>();
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	/**
	 * Function that will load layout information when user changes the payer.
	 */
	public void handlePayerChange() {
		try{
		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (payer != null && !payer.equals("")) {

			this.layoutID = null;
			this.dataType = "";
			this.userlog = "";
			this.filteredlayoutid = "";

			this.selectedClient = "";
			this.selectedStatus = "";
			LayoutBeanbyPayer objLB = new LayoutBeanbyPayer(payer);
			layouts = objLB.getLayouts();

		} else {
			displayErrorMessageToUser("No Payer Selected", "Select a Payer");
			layouts = new ArrayList<Layout>();

		}
		}
		catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured. Please try again!!", "Error "+e.getMessage());
		}

	}

	public void afterNewSubLayout() {
		displayMessageforSubLayout();
		updateView();

	}

	public void afterNewSubLayoutPaste() {
		displayInfoMessageToUser("New Sublayout Added", "Paste Sublayout");
		updateView();

	}

	public void displayMessageforSubLayout() {
		// TODO Auto-generated method stub
		RequestContext.getCurrentInstance();
		String message = "Succesfully added SubLayout ";
		displayInfoMessageToUser(message, "NEW SUBLAYOUT");
	}

	public void afterNewLayout() {

		if (getSessionData().isNewAdditionComplete()) {
			PayerBean objPB = new PayerBean();
			payers = objPB.getPayers();

			String query = "SELECT upper(PAYOR) FROM IMP_LAYOUTS WHERE "
					+ " LAYOUTID=(SELECT MAX(LAYOUTID) FROM IMP_LAYOUTS "
					+ " WHERE upper(USERLOG)='"
					+ getUserinfo().getFullname().toUpperCase() + "')";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> payerList = db.resultSetToListOfList(query);
			db.endConnection();

			if (payerList.size() > 0) {
				payer = payerList.get(1).get(0);
			}

			handlePayerChange();

			displayMessage();
		}

		this.sessionData.setNewAdditionComplete(false);
		this.reset();
	}

	public void afterLayoutExtend() {

		if (getSessionData().isNewAdditionComplete()) {
			PayerBean objPB = new PayerBean();
			payers = objPB.getPayers();

			String query = "SELECT upper(PAYOR) FROM IMP_LAYOUTS WHERE "
					+ " LAYOUTID=(SELECT MAX(LAYOUTID) FROM IMP_LAYOUTS "
					+ " WHERE upper(USERLOG)='"
					+ getUserinfo().getFullname().toUpperCase() + "')";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> payerList = db.resultSetToListOfList(query);
			db.endConnection();

			if (payerList.size() > 0) {
				payer = payerList.get(1).get(0);
			}

			handlePayerChange();

			displayextendMessage();
		}

		this.sessionData.setNewAdditionComplete(false);

	}

	public void displayextendMessage() {
		// TODO Auto-generated method stub
		displayInfoMessageToUser(
				"New Layout Added .Please add sublayouts if needed",
				"Layout Extended");
	}

	/**
	 * Load the respective layout fields information
	 */
	public void showDetails() {
		this.testImportStatus=false;
		this.testValue = null;
		this.getfileStatus=false;
		this.topTen = "";
		this.lastTen = "";
		this.listofSubLayouts = new ArrayList<>();
		FacesContext context = FacesContext.getCurrentInstance();
		Map<String, String> params = context.getExternalContext()
				.getRequestParameterMap();
		layoutID = params.get("layoutIDs");
		System.out.println("Layoutids " + layoutID);

		if (layoutID != null && !layoutID.equals("")) {
			LayoutFieldsModel objLFB = new LayoutFieldsModel(layoutID);
			layoutFields = objLFB.getLayoutfields();
			
			// GenerateImportScript objGIS = new GenerateImportScript();
			if (this.selectedLayouts.getDataType().compareTo("CONTROL TOTAL") != 0) {
				if (this.selectedLayouts.getManualFlag().compareTo("N") == 0) {
					
					ConnectDB db = new ConnectDB();
					db.initialize();
					String query = "SELECT A.LAYOUTID,B.SUBLAYOUTID||'-'||B.SUBLAYOUTDESC  FROM  IMP_LAYOUTS A LEFT JOIN "
							+ " IMP_SUB_LAYOUTS B ON A.LAYOUTID=B.LAYOUTID WHERE A.LAYOUTID='"
							+ layoutID + "' ";
					
					List<List<String>> layoutidlist = db
							.resultSetToListOfList(query);
					db.endConnection();
					if (layoutidlist.size() > 0) {
						for (int i = 1; i < layoutidlist.size(); i++) {
							listofSubLayouts.add(layoutidlist.get(i).get(1));
							setSelectedsubLayout(layoutidlist.get(1).get(1));
							System.out.println("AI table list "
									+ listofSubLayouts);
						}
						setListofSubLayouts(listofSubLayouts);
					}

					importScript = ProcessBuilderRunner.runImportScript(
							layoutID, "N");
				} else {
					importScript = checkoutimpScript(layoutID);
				}

			} else {
				LayoutType objLayoutType = new LayoutType();
				layoutTypes = objLayoutType.getlayoutTypes();
			}

		} else {
			layoutFields = new ArrayList<LayoutFields>();
		}
	}

	/**
	 * 
	 * @param layoutID
	 *            This is the layoutid
	 * @return
	 */
	public String checkoutimpScript(String layoutID) {
		String username = getUserinfo().getFullname().toUpperCase();
		String content = "";
		@SuppressWarnings("unused")
		String addcontent = "Script Modified by " + username + " at "
				+ new Date();
		ConnecttoSVN conn = new ConnecttoSVN();
		SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
		try {
			System.out.println("CHECKING OUT");
			content = conn.checkoutSVNwithfile(repos, AIConstant.SVNSQL_PATH,
					"IP_" + layoutID + ".sql");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			displayInfoMessageToUser("SVN Checkout-Falied.Please try again ",
					"SVN-CheckOUT");
		}
		// TODO Auto-generated method stub
		return content;
	}
	public void resetN(){
		this.importNrows="N";
	}
	

	public void testImport() throws InterruptedException {

		/*
		 * TestImport objTI = new TestImport(); objTI.setFilePath(filePath);
		 * String[] file = filePath.split("/"); String filename =
		 * file[file.length - 1]; objTI.setLayoutID(layoutID);
		 */
		this.fileID = "";
		this.showlog = false;
		testValue = null;
		this.testImportStatus=false;
		this.getfileStatus=false;
		if(testimportforNrows){
		if (this.importNrows.isEmpty() || this.importNrows == "") {
			this.importNrows = "N";
		}else{
			if(Character.isLetter(this.importNrows.charAt(0))){
				this.importNrows = "N";
			}
				
		}}else{
			this.importNrows = "N";
		}
		String message = "";
		RuntimeExecutor objRT = new RuntimeExecutor(
				AIConstant.DASHBOARD_SERVER_NAME);
		try {
			String headcmd = "head -n 10 \"" + filePath + "\"";

			String tailcmd = "tail -10 \"" + filePath + "\"";

			log.info("Step 1  : ---Computing head -10 for " + filePath);
			log.info("Head Command : " + headcmd);
			topTen = objRT.runSimpleCommand(headcmd).replaceAll("\f", "\n");;
			if (!topTen.isEmpty()) {
				log.info("\t \t SUCCESS.Proceding to Step 2");
			} else {
				log.info("\t \t Empty Result.Proceding to Step 2");
			}

			log.info("Step 2  : ---Computing tail -10 for " + filePath);
			log.info("Tail Command : " + tailcmd);
			lastTen = objRT.runSimpleCommand(tailcmd).replaceAll("\f", "\n");;
			if (!lastTen.isEmpty()) {
				log.info("\t \t SUCCESS.Proceding to Step 3");
			} else {
				log.info("\t \t Empty Result.Proceding to Step 3");
			}

		} catch (Exception ex) {
			log.debug("Test Import Exception : " + ex.toString());
			displayErrorMessageToUser("Test Import Failed.Please try again",
					"Test Import");
		}

		if (topTen.isEmpty() && lastTen.isEmpty()) {

			log.info("------FILE NOT FOUND----- TEST IMPORT EXIT");
			objRT.endProcess();
			displayErrorMessageToUser("File not found", "Test Import");
			return;
		}

		else {
			TestImportController timport = new TestImportController(layoutID,
					filePath, this.importNrows);
			String output = timport.runTestImport().trim();
			if(output.contains("GETFILESTATSPATH")){
				this.getfileStatus=true;
				this.setGetfilePath(output.split("\\^",-1)[0].trim().split("\\|")[1].trim());
				output=output.split("\\^",-1)[1].trim();
			}
			System.out.println("Getfilestats path"+this.getfilePath);
			this.importNrows="N";
			setTestimportforNrows(false);
			log.info("Recieved Output : " + output);
			try {
				
				int errorCode = Integer.parseInt(output);
				if (errorCode == 0) {
					System.out.println("Selected Data type "
							+ this.selectedLayouts.getDataType());
					message = "Test import successfull";

					getOutputForDataFile(20, message);

				} else if (errorCode == 15) {
					message = "Test import successfull for data file but failed for inline CTL";
					getOutputForDataFile(20, message);
				} else if (errorCode == 16) {
					message = "Test import successfull for data file and CTL file";
					getOutputForDataFile(20, message);
				}

				else {

					HandleTestImportErrors(errorCode);
				}

			} catch (Exception ex) {
				if (output.contains("FLID")) {
					String[] line = output.split("\\|");
					String fileID = "";
					String errorcode = "";
					if (line.length >= 2) {
						fileID = line[1].split("\\~", -1)[0].trim();
						setFileID(fileID);
						errorcode = output.split("\\~", -1)[1].trim();
					} else {
						message = "Test import successfull for data file but failed for inline CTL";
						fileID = "";
						errorcode = "";
						getOutputForDataFile(20, message);
					}

					if (this.selectedLayouts.getDataType().compareTo(
							"CONTROL TOTAL") == 0) {
						message = " Test import successfull for Control total file ";
						parseOutputForControlTotal(fileID, message);
					} else if (errorcode.equals("16")) {
						message = "Test import successfull for data file and CTL file";
						getOutputForDataFile(20, message);
					}
					/*
					 * else{ displayErrorMessageToUser("No Records to Display",
					 * "ERROR"); }
					 */
				} else {
					displayErrorMessageToUser(
							"Test import failed. Please try again",
							"Error Occured");
				}
			}
		}

	}

	public void getOutputForDataFile(int noofRows, String message) {
		testImportStatus=true;
		this.getfileStatus=true;
		String shortPayer = getShortPayor(layoutID);
		String tablename = "AI_" + layoutID + "_1_" + shortPayer;
		
		log.info("AI Table Name : " + tablename);
		String query = "select * from " + tablename + " where rownum < "
				+ (noofRows + 1);
		setAiQuery(query);
		setAiTable(tablename);
		ConnectDB db = new ConnectDB();
		db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID, AIConstant.TEST_SCHEMA_NAME,
				"LOCAL");
		List<List<String>> rs = db.resultSetToListOfList(query);
		if (rs != null) {
			if (rs.size() > 1) {
				testValue = db.resultSetToListOfList(query);
				displayInfoMessageToUser(message, "SUCCESS");
			} else {
				displayErrorMessageToUser("No Records to Display", "ERROR");
			}
		} else {
			displayErrorMessageToUser("Table Not Found", "ERROR");
		}
		db.endConnection();

	}

	public String getShortPayor(String layoutID3) {
		String query = "select SHORTPAYOR from imp_layouts where layoutid='"
				+ layoutID3 + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		return rs.get(1).get(0);
	}

	public void parseOutputForControlTotal(String fileID, String message) {
		if (!fileID.isEmpty()) {
			testImportStatus=true;
			ConnectDB db = new ConnectDB();
			String query = "SELECT FROMDATE, TODATE, BILLED_AMT, ALLOWED_AMT, PAID_AMT, EMPLOYEE_AMT, EMPLOYEE_CNT, MEMBER_CNT, RECORD_CNT,UDF1,UDF2,UDF3,UDF4,UDF5,UDF6,UDF7,UDF8,UDF9, CTL_STATUS, CTL_EXTRACT FROM IMP_VH_CT where fileid='"
					+ fileID + "'";
			setAiQuery(query);
			db.initialize(AIConstant.RAC_SERVER_NAME,
					AIConstant.RAC_SERVICE_PORT, AIConstant.RAC_SERVICE_SID,
					AIConstant.TEST_SCHEMA_NAME, "LOCAL");
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					testValue = db.resultSetToListOfList(query);
					displayInfoMessageToUser(message, "SUCCESS");
				} else {
					displayErrorMessageToUser("No Records to Display", "ERROR");
				}
			}
			db.endConnection();

			/*
			 * this.testValue=null; List<List<String>> rows=new ArrayList<>();
			 * List<String> headerRow=new ArrayList<>();
			 * headerRow.add("FROM_DATE"); headerRow.add("TO_DATE");
			 * headerRow.add("BILLED_AMOUNT"); headerRow.add("ALLOWED_AMOUNT");
			 * headerRow.add("PAID_AMOUNT"); headerRow.add("EMPLOYER_AMOUNT");
			 * headerRow.add("EMPLOYER_COUNT"); headerRow.add("MEMBER_COUNT");
			 * headerRow.add("RECORD_COUNT"); headerRow.add("SOURCEFILENAME");
			 * rows.add(headerRow); try { System.out.println("Output "+output);
			 * String[] listofOutputs=output.split("\n"); for(int
			 * i=0;i<listofOutputs.length;i++) {
			 * if(!listofOutputs[i].isEmpty()){
			 * 
			 * List<String> newRow=new ArrayList<>(); String[]
			 * line=listofOutputs[i].split("\\|");
			 * 
			 * 
			 * for(int j=1;j<line.length;j++){ newRow.add(line[j]);
			 * 
			 * 
			 * } newRow.add(listofOutputs[i].split("\\|")[1]);
			 * newRow.add(listofOutputs[i].split("\\|")[2]);
			 * newRow.add(listofOutputs[i].split("\\|")[3]);
			 * newRow.add(listofOutputs[i].split("\\|")[4]);
			 * newRow.add(listofOutputs[i].split("\\|")[5]);
			 * newRow.add(listofOutputs[i].split("\\|")[6]);
			 * newRow.add(listofOutputs[i].split("\\|")[7]);
			 * newRow.add(listofOutputs[i].split("\\|")[8]);
			 * newRow.add(listofOutputs[i].split("\\|")[9]);
			 * newRow.add(listofOutputs[i].split("\\|")[10]); rows.add(newRow);
			 * } }
			 * 
			 * this.testValue=rows;
			 * displayInfoMessageToUser("Test Import Successfull", "SUCCESS"); }
			 * catch(Exception ex) {
			 * log.error("Exception parsing CTRL OUTPUT : " + output); }
			 */
		} else {
			displayErrorMessageToUser("0 Record Imported.", "ERROR");
		}
	}

	public void HandleTestImportErrors(int exitCode) {
		System.out.println("Error Code by sandbox: " + exitCode);
		switch (exitCode) {
		case 1: {

			displayErrorMessageToUser(
					"File Not Found.Make sure you have entered the correct Path",
					"ERROR");
			this.showlog = false;
			break;
		}
		case 2: {
			displayErrorMessageToUser(
					"Attribute File Cannot be Generated.Please Check your Layout ",
					"ERROR");
			this.showlog = false;
			break;

		}
		case 3: {
			displayErrorMessageToUser("Get File Stats failed.Contact AIP Team",
					"ERROR");
			this.showlog = false;
			break;
		}

		case 4: {
			displayErrorMessageToUser(
					"0 Records found.Please make sure your where clause is correct.",
					"ERROR");
			this.showlog = false;
			break;
		}

		case 5: {
			displayErrorMessageToUser(
					"Cannot Import Due to Layout Mismatch Error.Verify your layouts",
					"ERROR");
			this.showlog = false;
			break;
		}

		case 6: {
			displayErrorMessageToUser(
					"Test failed with Oracle Error.Please see log for more details",
					"ERROR");
			this.showlog = true;
			prepareOracleCommand(filePath);
			break;
		}

		case 7: {
			displayErrorMessageToUser(
					"Control Attribute cannot be generated.Verify your layout",
					"ERROR");
			this.showlog = false;
			break;
		}

		case 8: {

			displayErrorMessageToUser(
					"Invalid Mappings for Control Total.Check your Mappings",
					"ERROR");
			this.showlog = false;
			break;
		}

		case 9: {
			displayErrorMessageToUser("Corrupt Cattr File.Check your Layout",
					"ERROR");
			this.showlog = false;
			break;
		}
		case 10: {
			displayErrorMessageToUser(
					"Remote Terminal Connection Failed.Please try again.",
					"ERROR");
			this.showlog = false;
			break;

		}

		default: {
			displayErrorMessageToUser("Unknown Error Occured.Contact AIP Team",
					"ERROR");
			this.showlog = false;
			break;
		}
		}
	}

	public void prepareOracleCommand(String filePath) {

		String[] file = filePath.split("/");
		String filename = file[file.length - 1];

		String oraclelogPath = AIConstant.OracleLogPath + filename + "_"
				+ "999" + "_" + "99999" + "." + "999" + ".log";
		log.info("Oracle Log Path :" + oraclelogPath);
		File filec = new File(oraclelogPath.toString());
		if (filec.exists()) {
			FileController objFC = new FileController(oraclelogPath);
			setDownloadLog(objFC.getDownload());
		} else {
			setDownloadLog(null);
			displayErrorMessageToUser("Log File Not Found", "ERROR");
			this.showlog = false;
		}

	}

	public void delete() {

		Layout layout = this.selectedLayouts;

		ConnectDB db = new ConnectDB();
		db.initialize();
		String checkquery = "select count(clientid) from imp_clientpatterns where layoutid='"
				+ layout.getLayoutID()
				+ "' or ctl_layoutid='"
				+ layout.getLayoutID() + "'";
		System.out.println("Delete Query : " + checkquery);
		List<List<String>> rs = db.resultSetToListOfList(checkquery);
		if (rs.size() > 0) {
			if (Integer.parseInt(rs.get(1).get(0)) > 0) {
				displayErrorMessageToUser(
						"This Layout is used by clients.Cannot be deleted",
						"Delete");
				return;
			}
		}

		String result = "";
		try {
			result = db.executeDML("DELETE FROM IMP_LAYOUTS WHERE "
					+ " LAYOUTID='" + layout.getLayoutID() + "'");
		} catch (Exception ex) {
			log.debug("Delete Layout Exception : " + ex.toString());
		}

		System.out.println("DELETE FROM IMP_LAYOUTS WHERE " + " LAYOUTID='"
				+ layout.getLayoutID() + "'");

		FacesMessage msg = null;

		if (result.equalsIgnoreCase("1")) {

			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Delete layout",
					"Success");
			handlePayerChange();
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error occured", result);

		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
		db.endConnection();
	}

	public void handleSave(Layout layout, String columnName)
			throws SQLException {

		String newValue = "";

		switch (columnName) {
		case "PUCHCHARFLAG":
			newValue = layout.getPunchCharFlag();
			break;
		case "OPTIONALLY":
			newValue = layout.getOptionallyEnclosedFlag();
			break;
		case "SKIPROW":
			newValue = layout.getSkipRow();
			break;
		case "TRAILERSKIP":
			newValue = layout.getTrailerSkip();
			break;
		case "LAYOUTDESCIPTION":
			newValue = layout.getLayoutDesc();
			break;
		case "SOURCEINFO":
			newValue = layout.getSourceInfo();

			break;
		case "ACTIVEFLAG":
			newValue = layout.getActiveFlag();

			if (newValue.compareTo("Y") == 0) {
				int clientstatus = layout.ConditionalCheck();
				if (clientstatus > 0) {
					displayErrorMessageToUser(
							"Layout is already in use by :"
									+ clientstatus
									+ "client. Please Remove Client patterns and deactivate the layout",
							"Update Failed");
					return;
				} else {
					newValue = "N";
				}
			}
			break;
		case "VERIFIED": {
			newValue = layout.getVerified();

		}
			break;
		case "icd10flag": {
			newValue = layout.getIcd10Flag();

		}
			break;

		case "characterset": {
			newValue = layout.getCharacterSet();

		}
			break;
		case "DATADICTIONARYUPLOADED": {
			newValue = layout.getDatadictionaryuploaded();

		}
		break;
		
		default:
			newValue = "";
			break;
		}

		
			String result="";
		ConnectDB db = new ConnectDB();
		db.initialize();
		
			result = db.executeDML("UPDATE IMP_LAYOUTS SET " + columnName
				+ "='" + newValue.replaceAll("'", "''")
				+ "',DATEUPDATED=sysdate, UPDATEDBY='"+this.userinfo.getFullname() + "' WHERE LAYOUTID='"
				+ layout.getLayoutID() + "'");
		
		db.endConnection();
		FacesMessage msg = null;
		if (result.equalsIgnoreCase("1")) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, columnName
					+ " Changed", "New value:" + newValue);
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error Updating " + columnName, result);
		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void handleSavePerSubLayout(Layout layout, String columnName) {

		String newValue = "";

		switch (columnName) {
		/*
		 * case "TRAILERSKIPCONDITION": newValue =
		 * layout.getTrailerSkipCondition(); AddLayoutBean objAL=new
		 * AddLayoutBean(); if(!objAL.checkTrailerlayoutForm(newValue)){
		 * 
		 * String messageString="Invalid trailer condition.Please change it.";
		 * displayInfoMessageToUser(messageString,"New Layout"); return ; }
		 * 
		 * break;
		 */
		
		case "SUMFLAG": {
			newValue = layout.getSumflag();

		}
			break;
		case "TRAILERFLAG": {
			newValue = layout.getTrailerflag();

		}
			break;
		case "WHERECLAUSE":
			newValue = layout.getWhereClause();
			AddLayoutBean obj = new AddLayoutBean();
			if (!obj.checkwhereclause(newValue.toLowerCase())) {

				String messageString = "Invalid where clause.Please change it.";
				displayInfoMessageToUser(messageString, "New Layout");
				return;
			}

			break;
		case "SKIPROW":
			newValue = layout.getSkipRow();
			break;
		default:
			newValue = "";
			break;
		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("UPDATE IMP_SUB_LAYOUTS SET "
				+ columnName + "='" + newValue.replaceAll("'", "''")
				+ "',DATEUPDATED=sysdate, UPDATEDBY='"+this.userinfo.getFullname() + "' " + " WHERE LAYOUTID='"
				+ layout.getLayoutID() + "' AND SUBLAYOUTID='"
				+ layout.getSubLayoutID() + "'");
		db.endConnection();
		FacesMessage msg = null;
		if (result.equalsIgnoreCase("1")) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, columnName
					+ " Changed", "New value:" + newValue);
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error Updating " + columnName, result);
		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public DefaultStreamedContent getDownloadOldScriptFile() {
		GenerateOldImportScript objGOIS = new GenerateOldImportScript();

		String scriptLocation = AIConstant.IMPORT_SCRIPT_DUMP_LOCATION;
		String filename = ProcedureName + ".sql";
		objGOIS.imprtScrptGeneration(this.selectedLayouts.getLayoutID(),
				ProcedureName, HiTableName, layoutID, scriptLocation, filename);

		FileController objFC = new FileController(scriptLocation + filename);

		setDownloadOldScriptFile(objFC.getDownload());
		return downloadOldScriptFile;
	}

	public void setDownloadOldScriptFile(
			DefaultStreamedContent downloadOldScriptFile) {
		this.downloadOldScriptFile = downloadOldScriptFile;
	}

	public String getClientsList() {
		return clientsList;
	}

	public void setClientsList(String clientsList) {
		this.clientsList = clientsList;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public LinkedHashMap<String, String> getLayoutsid() {
		return layoutsid;
	}

	public void setLayoutsid(LinkedHashMap<String, String> layoutsid) {
		this.layoutsid = layoutsid;
	}

	public DefaultStreamedContent getDownloadAllScript() {
		// GenerateImportScript objGIS = new GenerateImportScript();

		String scriptLocation = AIConstant.IMPORT_SCRIPT_DUMP_LOCATION_ZIPPED;
		String filename = this.payer + "_import_scripts.zip";

		ProcessBuilderRunner.generateAllScripts(scriptLocation, this.payer,
				filename);

		FileController objFC = new FileController(scriptLocation + filename);

		setDownloadAllScript(objFC.getDownload());
		return downloadAllScript;
	}

	public void setDownloadAllScript(DefaultStreamedContent downloadAllScript) {
		this.downloadAllScript = downloadAllScript;
	}

	public void viewAttr(Layout layout) {

		this.setAttributes(ProcessBuilderRunner.runAttr(layout.getLayoutID()));

	}

	public void viewCAttr(Layout layout) {

		this.setCattributes(ProcessBuilderRunner.runCAttr(layout.getLayoutID()));

	}

	public DefaultStreamedContent getDownloadAllCAttribute() {
		// GenerateAttribute objGA = new GenerateAttribute();

		String attributeLocation = AIConstant.CATTR_DUMP_LOCATION_ZIPPED;
		String filename = this.payer + "_attributes.zip";
		ProcessBuilderRunner.generateAllCAttribute(attributeLocation,
				this.payer, filename);

		FileController objFC = new FileController(attributeLocation + filename);

		setDownloadAllCAttribute(objFC.getDownload());

		return downloadAllCAttribute;
	}

	public void setDownloadAllCAttribute(
			DefaultStreamedContent downloadAllCAttribute) {
		this.downloadAllCAttribute = downloadAllCAttribute;
	}

	public void displayMessage() {
		RequestContext.getCurrentInstance();
		String message = "Succesfully added new Layout for Payor "
				+ this.payer
				+ "\n Please Checkin Scripts and attributes from the layout Menu";
		displayInfoMessageToUser(message, "NEW LAYOUT");
	}

	public void reset() {

	}

	public ArrayList<String> getLayoutids() {
		return layoutids;
	}

	public void setLayoutids(ArrayList<String> layoutids) {
		this.layoutids = layoutids;
	}

	public String getFilteredlayoutid() {
		return filteredlayoutid;
	}

	public void setFilteredlayoutid(String filteredlayoutid) {
		this.filteredlayoutid = filteredlayoutid;
	}

	public ArrayList<String> getClients() {
		return clients;
	}

	public void setClients(ArrayList<String> clients) {
		this.clients = clients;
	}

	public String getSelectedClient() {
		return selectedClient;
	}

	public void setSelectedClient(String selectedClient) {
		this.selectedClient = selectedClient;
	}

	public Layout getSelectedLayouts() {
		if (this.selectedLayouts == null) {
			return new Layout();
		}
		return selectedLayouts;
	}

	public void setSelectedLayouts(Layout selectedLayouts) {
		this.selectedLayouts = selectedLayouts;
	}

	public boolean isLayoutSelected() {

		if (this.selectedLayouts != null) {
			this.layoutSelected = true;
		} else {
			this.layoutSelected = false;
		}

		return layoutSelected;
	}

	public void setLayoutSelected(boolean layoutSelected) {
		this.layoutSelected = layoutSelected;
	}

	public String getSelectedfileType() {
		return selectedfileType;
	}

	public void setSelectedfileType(String selectedfileType) {
		this.selectedfileType = selectedfileType;
	}

	public String getAttributes() {
		return attributes;
	}

	public void setAttributes(String attributes) {
		this.attributes = attributes;
	}

	public void handleScriptDownload(String layoutID) {
		if (this.selectedLayouts.getManualFlag().compareTo("N") == 0) {
			importScript = ProcessBuilderRunner.runImportScript(layoutID, "N");
		} else {
			importScript = checkoutimpScript(layoutID);
		}

		String importScriptPath = AIConstant.IMPORT_SCRIPT_DUMP_LOCATION;
		ProcessBuilderRunner.generateSQLScript("IP_" + layoutID,
				importScriptPath, importScript);

		FileController objFC = new FileController(importScriptPath + "IP_"
				+ layoutID + ".sql");
		setDownloadFile(objFC.getDownload());
	}

	public void handleDone() {
		this.setEdited(true);

	}

	public ArrayList<Layout> singleLayout() {
		ArrayList<Layout> allLayouts = new ArrayList<Layout>();
		if (this.selectedLayouts != null) {

			for (int i = 0; i < this.layouts.size(); i++) {
				if (this.layouts.get(i).getLayoutID()
						.compareTo(this.selectedLayouts.getLayoutID()) == 0) {
					allLayouts.add(layouts.get(i));
				}
			}
		}

		return allLayouts;
	}

	public String getLastTen() {
		return lastTen;
	}

	public void setLastTen(String lastTen) {
		this.lastTen = lastTen;
	}

	
	public void updateViewafterMap() {
		updateView();
		displayInfoMessageToUser("SVN checkin Successful", "Control Total Map");

	}

	public void updateView() {

		System.out.println("Selected Filter : " + this.selectedfiltertype);

		if (this.selectedfiltertype == null) {

			ExecuteAdvancedSearch();
		}

		else {
			if (getFiltertype().compareTo("filterbylayoutid") == 0) {
				handleLayoutIDChange();

			} else if (getFiltertype().compareTo("filterbyuser") == 0) {
				handleuserChange();
			} else if (getFiltertype().compareTo("filterbyclients") == 0) {
				handleClientChange();
			} else if (getFiltertype().compareTo("filterbydatatype") == 0) {
				handleDatatypeChange();
			} else if (getFiltertype().compareTo("filterbystatus") == 0) {
				handleStatusChange();
			} else if (getFiltertype().compareTo("filterbypayers") == 0) {
				log.info("PAYER : " + this.payer);
				if(this.payer!=null && !this.payer.isEmpty())
				{
				handlePayerChange();
				}
				else
				{

					ExecuteAdvancedSearch();
				}
			}
			
			else
			{
				displayErrorMessageToUser("No Filters Selected", "ERROR");
			}
		}

		if (this.sessionData.isManualOverrideComplete()) {
			displayInfoMessageToUser("Import Script Overridden",
					"Manual Override");
			this.sessionData.setManualOverrideComplete(false);
		}

	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		// RequestContext.getCurrentInstance().execute("patternTable.filter();");
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public void checkindialog() {
		if (this.selectedLayouts.getLayoutstatus().compareTo("WORKING") == 0) {
			RequestContext.getCurrentInstance().execute(
					"PF('layoutworking').show();");
		} else {
			RequestContext.getCurrentInstance().execute(
					"PF('layoutfinal').show();");
		}
	}

	/* Function that shows the import script for manual override */
	public void ManualOverrideWindow() {

		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 750);
		options.put("height", 700);
		options.put("modal", "true");
		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 750);
		options.put("contentHeight", 700);
		options.put("closable", "true");
		String lid = this.selectedLayouts.getLayoutID();
		String uid = getUserinfo().getFullname();
		String mf = this.selectedLayouts.getManualFlag();
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(lid);
		params.put("lid", list1);// Layoutid
		List<String> list2 = new ArrayList<String>();
		list2.add(uid);
		params.put("uid", list2);// Username
		List<String> list3 = new ArrayList<String>();
		list3.add(mf);
		params.put("mf", list3);// Manual Flag
		RequestContext.getCurrentInstance().openDialog("importscripteditor",
				options, params);// ,options,null);
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public void openDialogformanualoverride() {
		if (this.selectedLayouts.getManualFlag().compareTo("N") == 0) {
			RequestContext.getCurrentInstance().execute(
					"PF('manualoverridenew').show();");
		} else {
			RequestContext.getCurrentInstance().execute(
					"PF('manualoverride').show();");
		}
	}

	public void afterManualOverride() {

		System.out.println("Manual Override");
		if (getSessionData().isManualOverrideComplete()) {
			displayInfoMessageToUser("Manual Override Successful",
					"Manual Override");
		} else {
			displayErrorMessageToUser(
					"Manual Override Failed.Please Try again.",
					"Manual Override");
		}
		this.updateView();
	}

	/*
	 * public void updateLayout(Layout lout,String sn) { String
	 * query="Update imp_layouts_fields set " }
	 */
	public void onCellEdit(CellEditEvent event) {

		FacesContext facesContext = FacesContext.getCurrentInstance();
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		String sn = facesContext.getApplication().evaluateExpressionGet(
				facesContext, "#{field.sn}", String.class);

		String columnName = event.getColumn().getColumnKey()
				.substring(event.getColumn().getColumnKey().indexOf("_") + 1);

		System.out.println("oldValue: " + oldValue + "New Val= : " + newValue
				+ "ColumnName : " + columnName + "SN= : " + sn);
		if (newValue != null && !newValue.equals(oldValue)) {

			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "UPDATE imp_layouts_fields SET " + columnName + "='"
					+ newValue + "', updated_by='"
					+ getUserinfo().getFullname() + "' WHERE SN='" + sn + "'";
			String result = db.executeDML(query);
			db.endConnection();
			if (i == 0) {
				System.out.println("Sending Mail");
				sendMail();
				i++;
			}
			FacesMessage msg = null;
			if (result.equalsIgnoreCase("1")) {
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, columnName
						+ " Changed", "Old: " + oldValue + ", New:" + newValue);

			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating " + columnName, result);
			}

			FacesContext.getCurrentInstance().addMessage(null, msg);
		}

	}

	public void sendMail() {

		if (this.selectedLayouts.getUserlog().compareTo(
				getUserinfo().getFullname()) != 0) {
			String to = "";
			String Content = "Dear "
					+ this.selectedLayouts.getUserlog()
					+ ",\n"
					+ "Your Layout Has Been Modified .Please Verify.\n"
					+ "Layout Information : \n"
					+ "Layout ID : "
					+ this.selectedLayouts.getLayoutID()
					+ ", \n"
					+ "Payor : "
					+ this.selectedLayouts.getPayor()
					+ ", \n"
					+ "Modified Date : "
					+ new Date()
					+ ", \n"
					+ "Modified By : "
					+ getUserinfo().getFullname()
					+ ". \n"
					+ "\n \n \n \n"
					+ "*******************************************************"
					+ "\n \n"
					+ "This is a system Generated Mail.Please donot reply to this mail. \n \n"
					+ "If you have any Queries please Contact AIP Team.";
			String query = "select email from aipd_users where fullname='"
					+ this.selectedLayouts.getUserlog() + "'";
			System.out.println(query);
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			System.out.println(rs.size());
			if (rs != null && rs.size() > 1) {
				System.out.println("Its Here :  " + rs.get(1).get(0));
				to = rs.get(1).get(0);
			}
			System.out.println("TO: " + to);
			db.endConnection();
			String from = "aip@verscend.com";
			String host = "localhost";
			Properties properties = System.getProperties();
			// properties.setProperty("mail.smtp.starttls.enable", "true");
			properties.setProperty("mail.smtp.host", host);
			properties.setProperty("mail.smtp.port", "25");
			Session session = Session.getDefaultInstance(properties);
			try {
				MimeMessage message = new MimeMessage(session);
				message.setFrom(new InternetAddress(from));
				message.addRecipient(Message.RecipientType.TO,
						new InternetAddress(to));
				/*message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("rsthakur@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("spoudel@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("aadhungana@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("bisah@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("aaneupane@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("aypokhrel@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("adshrestha@veriskhealth.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("Anish.Rauniyar@verscend.com"));
						*/
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("Shekhar.Poudel@verscend.com"));
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress("Nijel.Shrestha@verscend.com"));
				
				message.setSubject("Layout Modified");
				message.setText(Content);
				System.out.println(Content);
				Transport.send(message);
				log.info("Message Sent.");

			} catch (MessagingException ex) {
				System.out.println("ERROR SENDING MAIL");
				ex.printStackTrace();
			}

		}
	}

	/**
	 * @return the layoutTypes
	 */
	public LinkedHashMap<String, String> getLayoutTypes() {
		return layoutTypes;
	}

	/**
	 * @param layoutTypes
	 *            the layoutTypes to set
	 */
	public void setLayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		this.layoutTypes = layoutTypes;
	}

	public void updateSessionVariable() {

		this.layoutID = null;
		try {
			if (this.selectedLayouts.getActiveFlag().compareTo("N") == 0) {
				RequestContext.getCurrentInstance().execute(
						" DeactivatedLayout();");
			}
		} catch (Exception ex) {
			displayErrorMessageToUser(
					"Unexpected Error has occured.Please try again", "ERROR");
		}

	}

	public void viewExtend() {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayouts.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		RequestContext.getCurrentInstance().openDialog("extendexistinglayout",
				options, params);// ,options,null);

	}

	public void viewaddSubLayout() {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayouts.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add("true");
		params.put("isFromMaster", list2);
		RequestContext.getCurrentInstance().openDialog("addSubLayout", options,
				params);// ,options,null);

	}

	public void viewUpload() {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayouts.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add("true");
		params.put("isFromMaster", list2);
		RequestContext.getCurrentInstance().openDialog("uploadLayout", options,
				params);

	}

	public void viewDownload() {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayouts.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		RequestContext.getCurrentInstance().openDialog("downloadLayout",
				options, params);// ,options,null);

	}

	public void viewAddData() {

		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 800);
		options.put("height", 500);
		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 800);
		options.put("contentHeight", 500);
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayouts.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add("GLOBAL");
		params.put("status", list2);
		RequestContext.getCurrentInstance().openDialog("fileStatsCheck",
				options, params);// ,options,null);

	}

	public void viewctlMap(String lid, String slid, String sublayout,String layoutStatus) {

		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 800);
		options.put("height", 500);
		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 800);
		options.put("contentHeight", 500);
		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(lid);
		params.put("lid", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add(slid);
		params.put("slid", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(sublayout);
		params.put("issublayout", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(layoutStatus);
		params.put("layoutstatus", list4);

		RequestContext.getCurrentInstance().openDialog("fileStatsCheckctl",
				options, params);// ,options,null);

	}

	public void adddatalayoutWindow() {
		// getSessionData().setWindowOpen(true);
		Map<String, Object> options = new HashMap<String, Object>();

		options.put("resizable", false);
		options.put("draggable", false);
		options.put("closable", "true");
		options.put("contentHeight", 510);
		RequestContext.getCurrentInstance().openDialog("addLayout", options,
				null);// ,options,null);

	}

	public void addctllayoutWindow() {
		// getSessionData().setWindowOpen(true);
		Map<String, Object> options = new HashMap<String, Object>();

		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");

		options.put("contentHeight", 510);
		options.put("contentWidth", 970);

		options.put("closable", "true");
		RequestContext.getCurrentInstance().openDialog("addcontroltotal",
				options, null);// ,options,null);

	}

	public void openEditLayoutDetails() {

		Map<String, Object> options = new HashMap<String, Object>();
		options.put("contentHeight", 510);
		options.put("contentWidth", 800);

		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayouts.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		if (getSelectedLayouts().getDataType().compareTo("CONTROL TOTAL") != 0) {
			options.put("closable", "false");
			RequestContext.getCurrentInstance().openDialog("editLayout",
					options, params);// ,options,null);
		} else {

			String payor = this.selectedLayouts.getPayor();
			List<String> list2 = new ArrayList<String>();
			list2.add(payor);
			RequestContext.getCurrentInstance().openDialog("editLayoutctl",
					options, params);
		}

	}

	public String checkDuplicate(String lid, String slid) {

		log.info("--CHECKING DUPLICATE BEFORE PASTE--");
		String result = "NEW";
		try {
			ConnectDB db = new ConnectDB();
			String oldSubLayoutDetails = "";
			String newSubLayoutDetails = "";
			String query = "SELECT SUBLAYOUTID FROM IMP_SUB_LAYOUTS WHERE LAYOUTID='"
					+ getSelectedLayouts().getLayoutID()
					+ "' GROUP BY SUBLAYOUTID";

			db.initialize();
			List<List<String>> listOfSubLayoutID = db
					.resultSetToListOfList(query);
			List<List<String>> listDetails;

			if (listOfSubLayoutID.size() > 1) {

				log.info("--SUBLAYOUT FOUND..CHECKING--");
				String sublayoutdetails = "";
				List<List<String>> newSublayout = new ArrayList<>();

				if (getSelectedLayouts().getLayoutType().compareTo(
						"Fixed length") == 0) {

					log.info("--CHILD LAYOUT IS FIXED--");

					sublayoutdetails = "SELECT COLUMNNAME,DATATYPE,DATETYPEDETIAL,FIELDLENGTH,STARTPOS,ENDPOS  "
							+ " FROM IMP_LAYOUTS_FIELDS "
							+ " WHERE LAYOUTID ='"
							+ lid
							+ "' and sublayoutid='" + slid + "'";

					log.info("QUERY : " + sublayoutdetails);
					newSublayout = db.resultSetToListOfList(sublayoutdetails);

					if (newSublayout == null) {
						return "Sublayout not found";
					}

				} else {
					log.info("--CHILD LAYOUT IS DELIMITED--");

					sublayoutdetails = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||FIELDLENGTH"
							+ " FROM IMP_LAYOUTS_FIELDS "
							+ " WHERE LAYOUTID ='"
							+ lid
							+ "' and sublayoutid='" + slid + "'";
					newSublayout = db.resultSetToListOfList(sublayoutdetails);

					log.info("Query : " + sublayoutdetails);
					if (newSublayout == null) {
						return "Sublayout not found";
					}
				}
				if (newSublayout.size() > 1) {
					for (int j = 1; j < newSublayout.size(); j++) {
						newSubLayoutDetails = newSubLayoutDetails
								+ newSublayout.get(j).get(0);

					}
					log.info("NEW SUBLAYOUT STRING :  " + newSubLayoutDetails);
				}

				for (int i = 1; i < listOfSubLayoutID.size(); i++) {
					if (getSelectedLayouts().getLayoutType().compareTo(
							"Fixed length") == 0) {
						log.info("FIXED LENGTH SUBLAYOUT CHECK");

						query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||FIELDLENGTH||STARTPOS||ENDPOS  "
								+ " FROM IMP_LAYOUTS_FIELDS "
								+ " WHERE LAYOUTID ='"
								+ getSelectedLayouts().getLayoutID()
								+ "' AND SUBLAYOUTID='"
								+ listOfSubLayoutID.get(i).get(0)
								+ "' "
								+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";

					} else {
						log.info("DELIMITED SUBLAYOUT CHECK");
						query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||FIELDLENGTH AS FIELDDATA "
								+ " FROM IMP_LAYOUTS_FIELDS "
								+ " WHERE LAYOUTID ='"
								+ getSelectedLayouts().getLayoutID()
								+ "' AND SUBLAYOUTID='"
								+ listOfSubLayoutID.get(i).get(0)
								+ "' "
								+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";

					}

					oldSubLayoutDetails = "";

					listDetails = db.resultSetToListOfList(query);
					if (listDetails.size() > 1) {
						for (int j = 1; j < listDetails.size(); j++) {
							oldSubLayoutDetails = oldSubLayoutDetails
									+ listDetails.get(j).get(0);
						}
					} else {
						result = "NEW";
						break;
					}

					log.info("OLD SUBLAYOUT DETAILS : " + oldSubLayoutDetails);
					if (oldSubLayoutDetails
							.equalsIgnoreCase(newSubLayoutDetails)) {
						result = "Could not paste.Exact Duplicate of SubLayoutID:"
								+ listOfSubLayoutID.get(i).get(0);
						break;
					}

				}
			} else {
				result = "NEW";
			}
			db.endConnection();
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("Cannot Verify Layout.Please Try Again",
					"Error");
			return "";
		}
		log.info("RESULT : " + result);
		return result;

	}

	public void pasteSubLayout() {
		String checkMessage = "";
		String clipboarddata = this.getSessionData().getClipboard();
		if (!clipboarddata.isEmpty()) {
			String layoutid = clipboarddata.split(",")[0];
			String sublayoutid = clipboarddata.split(",")[1];
			checkMessage = checkDuplicate(layoutid, sublayoutid);
			if (checkMessage.compareTo("NEW") == 0) {
				String query = "select LAYOUTTYPE,LAYOUTDETAIL, WHERECLAUSE , SUBLAYOUTDESC ,TRAILERSKIPCONDITION from imp_sub_layouts where layoutid='"
						+ layoutid + "' and sublayoutid='" + sublayoutid + "'";
				String query1 = "select columnid, columnname, datatype, datetypedetial, fieldlength,startpos, endpos,businessname from imp_layouts_fields where layoutid='"
						+ layoutid + "' and sublayoutid='" + sublayoutid + "'";
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> rs = db.resultSetToListOfList(query);
				List<List<String>> rs1 = db.resultSetToListOfList(query1);

				if (rs != null) {
					if (rs.size() > 1) {
						String queryinsert = "Insert into imp_sub_layouts(layoutid, sublayoutid, layouttype, layoutdetail, whereclause, sublayoutdesc, trailerskipcondition) values('"
								+ getSelectedLayouts().getLayoutID()
								+ "',"
								+ "(select max(sublayoutid + 1) from imp_sub_layouts where layoutid='"
								+ getSelectedLayouts().getLayoutID()
								+ "')"
								+ ",'"
								+ rs.get(1).get(0)
								+ "','"
								+ rs.get(1).get(1)
								+ "','"
								+ rs.get(1).get(2).replaceAll("\'", "\''")
								+ "','"
								+ rs.get(1).get(3)
								+ "','"
								+ rs.get(1).get(4) + "')";
						String check = db.executeDML(queryinsert);
						if (check.compareTo("1") == 0) {
							if (rs1 != null) {
								if (rs1.size() > 1) {
									String queryinsertfields = "";
									for (i = 1; i < rs1.size(); i++) {
										queryinsertfields = "Insert into imp_layouts_fields(layoutid, sublayoutid, columnid, columnname, datatype, datetypedetial, fieldlength,startpos, endpos,businessname) values('"
												+ getSelectedLayouts()
														.getLayoutID()
												+ "',"
												+ "(select max(sublayoutid + 1) from imp_layouts_fields where layoutid='"
												+ getSelectedLayouts()
														.getLayoutID()
												+ "')"
												+ ",'"
												+ rs1.get(i).get(0)
												+ "','"
												+ rs1.get(i).get(1)
												+ "','"
												+ rs1.get(i).get(2)
												+ "','"
												+ rs1.get(i).get(3)
												+ "','"
												+ rs1.get(i).get(4)
												+ "','"
												+ rs1.get(i).get(5)
												+ "','"
												+ rs1.get(i).get(6)
												+ "','"
												+ rs1.get(i).get(7)
												+ "')";
										db.executeDML(queryinsertfields);
									}
								} else {
									displayErrorMessageToUser(
											"Sublayout details not Found",
											"ERROR");
									return;
								}
							} else {
								displayErrorMessageToUser(
										"Sublayout details not Found", "ERROR");
								return;
							}
						} else {
							displayErrorMessageToUser("Cannot Paste", "ERROR");
							return;
						}
					} else {
						displayErrorMessageToUser("Sublayout Not Found",
								"ERROR");
						return;
					}
				} else {
					displayErrorMessageToUser("Sublayout Not Found", "ERROR");
					return;
				}

				displayInfoMessageToUser("New Sublayout Added",
						"Paste Sublayout");
				updateView();
				getSessionData().setClipboard("");
			} else {
				displayErrorMessageToUser(checkMessage, "ERROR");
				return;
			}
		}
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public void printHelloWorld() {
		System.out.println("HELLO WORLD");
	}

	public String getImportNrows() {
		return importNrows;
	}

	public void setImportNrows(String importNrows) {
		this.importNrows = importNrows;
	}

	public ArrayList<String> getListofSubLayouts() {
		return listofSubLayouts;
	}

	public void setListofSubLayouts(ArrayList<String> listofSubLayouts) {
		this.listofSubLayouts = listofSubLayouts;
	}

	public String getSelectedsubLayout() {
		return selectedsubLayout;
	}

	public void setSelectedsubLayout(String selectedsubLayout) {
		this.selectedsubLayout = selectedsubLayout;
	}

	public void handleAItablechange() {
		try {
			
			if (this.getSelectedsubLayout() != "" || this.getFileID() != "") {
				testImportStatus=true;
				this.getfileStatus=true;
				this.testValue = null;
				this.downloadTestData=null;
				System.out.println("Showing AI data for sublayout "
						+ this.getSelectedsubLayout());
				String shortPayer = getShortPayor(layoutID);
				String tablename = "";
				String[] line = this.getSelectedsubLayout().split("\\-", -1);
				String query = "";
				if (line[1].equals("DATAFILE")) {
					tablename = "AI_" + this.layoutID + "_" + line[0] + "_"
							+ shortPayer;
					query = "select * from " + tablename + " where rownum < "
							+ 21;
				} else {
					tablename = "IMP_VH_CT";
					query = "SELECT FROMDATE, TODATE, BILLED_AMT, ALLOWED_AMT, PAID_AMT, EMPLOYEE_AMT, EMPLOYEE_CNT, MEMBER_CNT, RECORD_CNT, CTL_STATUS, CTL_EXTRACT from " + tablename + " where fileid='"
							+ this.getFileID() + "'";
				}

				log.info("AI Table Name : " + tablename);
				log.info("Query : " + query);
				setAiQuery(query);
				setAiTable(tablename);
				System.out.println("Query:" + query);
				ConnectDB db = new ConnectDB();
				db.initialize(AIConstant.RAC_SERVER_NAME,
						AIConstant.RAC_SERVICE_PORT,
						AIConstant.RAC_SERVICE_SID,
						AIConstant.TEST_SCHEMA_NAME, "LOCAL");
				List<List<String>> rs = db.resultSetToListOfList(query);
				if (rs != null) {
					if (rs.size() > 1) {
						testValue = db.resultSetToListOfList(query);
						// displayInfoMessageToUser("Test Import Successfull",
						// "SUCCESS");
					} else {
						displayErrorMessageToUser("No Records to Display",
								"ERROR");
					}
				} else {
					displayErrorMessageToUser("Table Not Found", "ERROR");
				}
				db.endConnection();
			}
		
		} catch (Exception e) {
			displayErrorMessageToUser("Error occured. Please try again",
					"ERROR");
		}

	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public DefaultStreamedContent getDownloadTestData() {
		
		System.out.println("Sublayoutid "+this.selectedsubLayout);
		try{
		if(testValue==null){
			displayErrorMessageToUser("AI table not found. Please make sure this sublayout is correct", "ERROR");
		}else{
			if(this.aiQuery!="" && this.selectedsubLayout!=""){
				TestDataExporter TDE = new TestDataExporter();
				
				
				TDE.processTestImportData(this.layoutID+"_"+this.selectedsubLayout,this.aiQuery,this.nrowsAIData,this.aiTable);
				
				
				FileController objFC = new FileController(AIConstant.TEMPORARY_FILE_LOCATION+this.layoutID+"_"+this.selectedsubLayout+".xlsx");
				
				setDownloadTestData(objFC.getDownload());
			}else{
				displayErrorMessageToUser("AI table not found.Please try again!","ERROR");
			}
		}
		}catch(Exception e){
			displayErrorMessageToUser("Invalid Input.Please try again", "ERROR");
		}
		
		
		return downloadTestData;
	}

	public void setDownloadTestData(DefaultStreamedContent downloadTestData) {
		this.downloadTestData = downloadTestData;
	}

	

	public String getAiQuery() {
		return aiQuery;
	}

	public void setAiQuery(String aiQuery) {
		this.aiQuery = aiQuery;
	}

	public String getNrowsAIData() {
		return nrowsAIData;
	}

	public void setNrowsAIData(String nrowsAIData) {
		this.nrowsAIData = nrowsAIData;
	}

	public String getAiTable() {
		return aiTable;
	}

	public void setAiTable(String aiTable) {
		this.aiTable = aiTable;
	}

	public boolean isGetfileStatus() {
		return getfileStatus;
	}

	public void setGetfileStatus(boolean getfileStatus) {
		this.getfileStatus = getfileStatus;
	}

	public String getGetfilePath() {
		return getfilePath;
	}

	public void setGetfilePath(String getfilePath) {
		this.getfilePath = getfilePath;
	}

	public DefaultStreamedContent getDownloadFileStats() {
		if(this.getfilePath!=""){
			
				FileController objFC = new FileController(this.getfilePath);
				setDownloadFileStats(objFC.getDownload());
			} else{ 
				
				displayErrorMessageToUser("GetfileStats Not Found", "ERROR");
				
			
			}
		
		return downloadFileStats;
	}

	public void setDownloadFileStats(DefaultStreamedContent downloadFileStats) {
		this.downloadFileStats = downloadFileStats;
	}

	public LinkedHashMap<String, String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(LinkedHashMap<String, String> dataTypes) {
		this.dataTypes = dataTypes;
	}
	
	public String buildQuery() {
		String query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
				+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
				+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
				+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag"
				+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
				+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
				+ " ON a.LAYOUTID=c.LAYOUTID "
				+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
				+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
				+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID where";
		if(!this.payeradv.isEmpty())
		{
			query = query + " a.payor='" + this.payeradv + "' and ";
		}
		if (!this.datatypeAdvanced.isEmpty()) {
			query = query + " a.datatype='" + this.datatypeAdvanced + "' and ";
		}
		if (!this.layoutType.isEmpty()) {
			query = query + " b.layoutType='" + this.layoutType + "' and ";
		}
		if (!this.layoutDetail.isEmpty()) {
			query = query + " layoutDetail='" + this.layoutDetail + "' and ";
		}
		if (!this.statusLayout.isEmpty()) {
			query = query + " layout_status='" + this.statusLayout + "' and ";
		}
		if (!this.manualFlag.isEmpty()) {
			query = query + " manualflag='" + this.manualFlag + "' and ";
		}
		if (!this.activeFlag.isEmpty()) {
			query = query + " activeflag='" + this.activeFlag + "' and ";
		}
		if (!this.sourceInfo.isEmpty()) {
			query = query + " UPPER(sourceinfo) like '%" + this.sourceInfo.toUpperCase() + "%' and ";
		}
		if (!this.datadictionaryUploaded.isEmpty()) {
			query = query + " datadictionaryuploaded='" + this.datadictionaryUploaded + "' and ";
		}


		if (query.endsWith(" and ")) {
			query = query.substring(0, query.length() - 4);
		}
		
		query = query + " order by a.layoutid";

		System.out.println("Query for Advanced Search : " + query);
		return query;
	}

	
	public void ExecuteAdvancedSearch() {

		if (this.flmsfilteredLogs != null) {
			this.flmsfilteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmL:layoutList");
			dt1.setFilters(null);
			dt1.reset();

		}

		if (this.payeradv.isEmpty() && this.datatypeAdvanced.isEmpty() && this.layoutType.isEmpty()
				&& this.layoutDetail.isEmpty() && this.manualFlag.isEmpty()
				&& this.statusLayout.isEmpty()&& this.activeFlag.isEmpty()&& this.sourceInfo.isEmpty() && this.datadictionaryUploaded.isEmpty()) {
			displayErrorMessageToUser("Cannot Search with Empty Parameters",
					"Advanced Search");
			return;
		} else {
			String query = buildQuery();
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> layoutsList = db.resultSetToListOfList(query);
			db.endConnection();

			if (layoutsList.size() > 0) {
				this.layouts = new ArrayList<>();

				for (int i = 1; i < layoutsList.size(); i++) {
					this.layouts.add(new Layout(layoutsList.get(i - 1).get(0),
							layoutsList.get(i).get(0), layoutsList.get(i)
									.get(1), layoutsList.get(i).get(2),
							layoutsList.get(i).get(3), layoutsList.get(i)
									.get(4), layoutsList.get(i).get(5),
							layoutsList.get(i).get(6), layoutsList.get(i)
									.get(7), layoutsList.get(i).get(8),
							layoutsList.get(i).get(9), layoutsList.get(i).get(
									10), layoutsList.get(i).get(11),
							layoutsList.get(i).get(12), layoutsList.get(i).get(
									13), layoutsList.get(i).get(14),
							layoutsList.get(i).get(15), layoutsList.get(i).get(
									16), layoutsList.get(i).get(17),
							layoutsList.get(i).get(18), layoutsList.get(i).get(
									19), layoutsList.get(i).get(20),
							layoutsList.get(i).get(21), layoutsList.get(i).get(
									22), layoutsList.get(i).get(23),
							layoutsList.get(i).get(24), layoutsList.get(i).get(
									25), layoutsList.get(i).get(26) , layoutsList.get(i).get(27),layoutsList.get(i).get(28),layoutsList.get(i).get(29)));
				}
			}
		}
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getSourceInfo() {
		return sourceInfo;
	}

	public void setSourceInfo(String sourceInfo) {
		this.sourceInfo = sourceInfo;
	}

	public String getDatadictionaryUploaded() {
		return datadictionaryUploaded;
	}

	public void setDatadictionaryUploaded(String datadictionaryUploaded) {
		this.datadictionaryUploaded = datadictionaryUploaded;
	}
	

}
