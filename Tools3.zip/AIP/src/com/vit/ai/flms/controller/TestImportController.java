package com.vit.ai.flms.controller;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.RuntimeExecutor;

import org.apache.log4j.Logger;

public class TestImportController {
	
	
	private String layoutid;
	private String filePath="";
	private String command="";
	private String nRows="";
	static Logger log= Logger.getLogger(TestImportController.class.getName());
	
	
	public TestImportController(String layoutid, String filePath,String nrows)
	{
		this.setLayoutid(layoutid);
		this.setFilePath(filePath);
		this.setnRows(nrows);
		init();
	}
	
	public void init()
	{
		if(this.nRows.compareTo("N")==0){
			this.command=AIConstant.shFilelocation + "runTestImport.sh -f \""+filePath + "\" -l " + this.layoutid ;	
		}else{
			this.command=AIConstant.shFilelocation + "runTestImport.sh -f \""+filePath + "\" -l " + this.layoutid +" -n "+this.nRows;
		}
		
		log.info("Initializing Test Import  : " + command);
		
	}
	public  String runTestImport() {
	
		String output="";
		RuntimeExecutor testImportTerminal = new RuntimeExecutor(AIConstant.DASHBOARD_SERVER_NAME);
		try
		{
			System.out.println("Command "+command);
		 output  = testImportTerminal.runCommand(command);
		 		
		}
		catch(Exception ex)
		{
			testImportTerminal.endProcess();
			log.info("--Exception Occured--");
			output="10";
		}
		 testImportTerminal.endProcess();
		
		return output;
		
		
	}
		public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	

	public String getnRows() {
		return nRows;
	}

	public void setnRows(String nRows) {
		this.nRows = nRows;
	}
	

}
