/* 
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.commons.model.DataType;
import com.vit.ai.commons.model.HRPayerBean;
import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutFields;
import com.vit.ai.flms.model.LayoutFieldsModel;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.flms.model.PartialDuplicateModel;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.AbstractController;

import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for adding data layout
 * 
 * @author Aashish Dhungana
 * @author Binesh Sah
 * 
 * @version 1.1 15 July 2014
 */
@ManagedBean
@ViewScoped
public class AddLayoutBean extends AbstractController implements Serializable {

	private static Logger log = Logger.getLogger(AddLayoutBean.class.getName());
	private static final long serialVersionUID = 1L;
	protected LinkedHashMap<String, String> payers;
	protected LinkedHashMap<String, String> dataTypes;
	protected LinkedHashMap<String, String> layoutTypes;
	/* ArrayList of partial Duplicate Layouts */
	protected ArrayList<PartialDuplicateModel> layoutnew = new ArrayList<PartialDuplicateModel>();
	private int counterslayoutid = 0;
	protected boolean nextstatus = false;
	private String newlayoutID;
	protected String verified;
	protected String layoutMatched;
	protected int layoutcheck = 0;
	protected ArrayList<PartialDuplicateModel> layoutexisting = new ArrayList<PartialDuplicateModel>();
	protected ArrayList<ArrayList<PartialDuplicateModel>> partialduplicateLayouts = new ArrayList<ArrayList<PartialDuplicateModel>>();
	protected ArrayList<ArrayList<PartialDuplicateModel>> partialduplicateLayoutsNew = new ArrayList<ArrayList<PartialDuplicateModel>>();

	public ArrayList<ArrayList<PartialDuplicateModel>> getPartialduplicateLayoutsNew() {
		return partialduplicateLayoutsNew;
	}

	public void setPartialduplicateLayoutsNew(
			ArrayList<ArrayList<PartialDuplicateModel>> partialduplicateLayoutsNew) {
		this.partialduplicateLayoutsNew = partialduplicateLayoutsNew;
	}

	@ManagedProperty(value = "#{userInformation}")
	protected UserInformation userinfo;
	@ManagedProperty(value = "#{loginbean}")
	protected ViewsParameters sessionData;
	protected String payer;

	protected String dataType;
	protected String layoutType;
	protected String layoutDetail;
	protected String punchChar;
	protected String optEnc;
	protected String skpRow;
	protected String skpLastRow = "0";
	protected String whereClause = "";
	protected String layoutDesc;
	protected String srcInfo;
	protected String subLayoutDesc = "";
	protected String trailerSkipCondition;
	protected boolean partialDuplicate;
	protected boolean invalfieldlenthVal;
	protected boolean invalDatatype;
	protected boolean invalcolumnname;
	protected String csvValues;
	protected boolean dupColCheck;
	protected boolean colLengthGT30;
	protected boolean layoutPopulated;
	protected boolean invalidColumn;
	protected boolean validationComplete;
	protected boolean invalidskplastrow;
	protected String whereCondition;
	protected String trailerCondition;
	protected boolean invalDatedescription;
	protected String characterSet = "US7ASCII";
	protected ArrayList<String> characterSets;
	protected ArrayList<LayoutFields> newLayoutFields;
	protected boolean isNew = true;
	private ArrayList<String> listofLayoutids;

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public ArrayList<LayoutFields> getNewLayoutFields() {
		return newLayoutFields;
	}

	public void setNewLayoutFields(ArrayList<LayoutFields> newLayoutFields) {
		this.newLayoutFields = newLayoutFields;
	}

	public ArrayList<LayoutFields> getMainLayoutFields() {
		return mainLayoutFields;
	}

	public void setMainLayoutFields(ArrayList<LayoutFields> mainLayoutFields) {
		this.mainLayoutFields = mainLayoutFields;
	}

	protected ArrayList<LayoutFields> mainLayoutFields;
	protected Layout newLayout;
	protected Layout mainlayout;

	public void setLayoutDetail(String layoutDetail) {
		this.layoutDetail = layoutDetail;
	}

	public String getCsvValues() {

		return csvValues;
	}

	public void handleYES() {
		this.counterslayoutid++;
	}

	public int getCounterslayoutid() {
		return counterslayoutid;
	}

	public void setCounterslayoutid(int counterslayoutid) {
		this.counterslayoutid = counterslayoutid;
	}

	public void closeDialog() {
		RequestContext.getCurrentInstance().closeDialog("addLayout");
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public void closeLayout() {
		RequestContext.getCurrentInstance().closeDialog("addLayout");
	}

	public String getVerified() {
		return verified;
	}

	public void setVerified(String verified) {
		this.verified = verified;
	}

	public void setCsvValues(String csvValues1) {

		this.csvValues = csvValues1;
	}

	public boolean isDupColCheck() {
		return dupColCheck;
	}

	public void setDupColCheck(boolean dupColCheck) {
		this.dupColCheck = dupColCheck;
	}

	public boolean isColLengthGT30() {
		return colLengthGT30;
	}

	public void setColLengthGT30(boolean colLengthGT30) {
		this.colLengthGT30 = colLengthGT30;
	}

	public boolean isLayoutPopulated() {
		return layoutPopulated;
	}

	public String getWhereCondition() {
		return whereCondition;
	}

	public void setWhereCondition(String whereCondition) {
		this.whereCondition = whereCondition;
	}

	public String getTrailerCondition() {
		return trailerCondition;
	}

	public void setTrailerCondition(String trailerCondition) {
		this.trailerCondition = trailerCondition;
	}

	public boolean isInvalidskplastrow() {
		return invalidskplastrow;
	}

	public void setInvalidskplastrow(boolean invalidskplastrow) {
		this.invalidskplastrow = invalidskplastrow;
	}

	public String getLayoutMatched() {
		return layoutMatched;
	}

	public void setLayoutMatched(String layoutMatched) {
		this.layoutMatched = layoutMatched;
	}

	
	/**
	 * Method to allow the user to add new partial duplicate layout.
	 * @param isPM
	 */
	public boolean handleAddNew(boolean isPM) {

		
		if (this.partialDuplicate) {
			System.out
					.println("--Partial Duplicate Layout--Changing status to HOLD----");
			if (!isPM) {
				this.isNew = false;
			} else {
				this.isNew = true;
			}
		}
		this.validationComplete = true;
		return this.isNew;
	}

	public String getNewlayoutID() {
		return newlayoutID;
	}

	public void setNewlayoutID(String newlayoutID) {
		this.newlayoutID = newlayoutID;
	}

	public void setLayoutPopulated(boolean layoutPopulated) {
		this.layoutPopulated = layoutPopulated;
	}

	public boolean isInvalidColumn() {
		return invalidColumn;
	}

	public void setInvalidColumn(boolean invalidColumn) {
		this.invalidColumn = invalidColumn;
	}

	public boolean isValidationComplete() {
		return validationComplete;
	}

	public void setValidationComplete(boolean validationComplete) {
		this.validationComplete = validationComplete;
	}

	public boolean isNextstatus() {
		return nextstatus;
	}

	public void setNextstatus(boolean nextstatus) {
		this.nextstatus = nextstatus;
	}

	public ArrayList<PartialDuplicateModel> getLayoutnew() {
		return layoutnew;
	}

	public void setLayoutnew(ArrayList<PartialDuplicateModel> layoutnew) {
		this.layoutnew = layoutnew;
	}

	public ArrayList<PartialDuplicateModel> getLayoutexisting() {
		return layoutexisting;
	}

	public void setLayoutexisting(
			ArrayList<PartialDuplicateModel> layoutexisting) {
		this.layoutexisting = layoutexisting;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public boolean isInvalcolumnname() {
		return invalcolumnname;
	}

	public void setInvalcolumnname(boolean invalcolumnname) {
		this.invalcolumnname = invalcolumnname;
	}

	public boolean isPartialDuplicate() {
		return partialDuplicate;
	}

	public void setPartialDuplicate(boolean partialDuplicate) {
		this.partialDuplicate = partialDuplicate;
	}

	public boolean isInvalDatedescription() {
		return invalDatedescription;
	}

	public void setInvalDatedescription(boolean invalDatedescription) {
		this.invalDatedescription = invalDatedescription;
	}

	public String getTrailerSkipCondition() {
		return trailerSkipCondition;
	}

	public void setTrailerSkipCondition(String trailerSkipCondition) {
		this.trailerSkipCondition = trailerSkipCondition;
	}

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getPunchChar() {
		return punchChar;
	}

	public void setPunchChar(String punchChar) {
		this.punchChar = punchChar;
	}

	public String getOptEnc() {
		return optEnc;
	}

	public void setOptEnc(String optEnc) {
		this.optEnc = optEnc;
	}

	public String getSkpRow() {
		return skpRow;
	}

	public void setSkpRow(String skpRow) {
		this.skpRow = skpRow;
	}

	public String getSkpLastRow() {
		return skpLastRow;
	}

	public void setSkpLastRow(String skpLastRow) {
		this.skpLastRow = skpLastRow;
	}

	public String getWhereClause() {
		return whereClause;
	}

	public boolean isInvalfieldlenthVal() {
		return invalfieldlenthVal;
	}

	public void setInvalfieldlenthVal(boolean invalfieldlenthVal) {
		this.invalfieldlenthVal = invalfieldlenthVal;
	}

	public boolean isInvalDatatype() {
		return invalDatatype;
	}

	public void setInvalDatatype(boolean invalDatatype) {
		this.invalDatatype = invalDatatype;
	}

	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}

	public String getLayoutDesc() {
		return layoutDesc;
	}

	public void setLayoutDesc(String layoutDesc) {
		this.layoutDesc = layoutDesc;
	}

	public String getSrcInfo() {
		return srcInfo;
	}

	public void setSrcInfo(String srcInfo) {
		this.srcInfo = srcInfo;
	}

	public String getSubLayoutDesc() {
		return subLayoutDesc;
	}

	public void setSubLayoutDesc(String subLayoutDesc) {
		this.subLayoutDesc = subLayoutDesc;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {
		this.payers = payers;
	}

	public LinkedHashMap<String, String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(LinkedHashMap<String, String> dataTypes) {
		this.dataTypes = dataTypes;
	}

	public LinkedHashMap<String, String> getLayoutTypes() {
		return layoutTypes;
	}

	public void setLayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		this.layoutTypes = layoutTypes;
	}

	public String getLayoutDetail() {
		return layoutDetail;
	}

	public AddLayoutBean(String override) {

	}

	public AddLayoutBean() {
		HRPayerBean objHRP = new HRPayerBean();
		payers = objHRP.getPayers();

		DataType objDataType = new DataType();
		dataTypes = objDataType.getDataTypes();

		LayoutType objLayoutType = new LayoutType();
		layoutTypes = objLayoutType.getlayoutTypes();
		setSubLayoutDesc("DATAFILE");

		this.characterSets = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db
				.resultSetToListOfList("select charactersets from aip_character_sets order by 1");
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.characterSets.add(rs.get(i).get(0));
				}
			}
		}
		setSkpLastRow("0");
		setSkpRow("0");
		trailerCondition = "N";
		whereCondition = "Y";
		setColLengthGT30(true);
		setDupColCheck(true);
		setInvalidColumn(true);
		setLayoutPopulated(true);
		setInvalDatatype(true);
		setInvalcolumnname(true);
		setInvalfieldlenthVal(true);
		setInvalDatedescription(true);
	}

	/**
	 * Opens Dialog for partial duplicate
	 */
	public void openDialog() {
		if (this.partialDuplicate == true) {
			RequestContext.getCurrentInstance().execute(
					"PF('dialogClients').show()");
		}

	}

	/**
	 * Checks all the requirements for a valid layout
	 */
	public void checkLayout() {
		
		String whereclause = getWhereClause();
		System.out.println("Dateformat status "+invalDatedescription);
		String messageString = "";
		if (!isLayoutPopulated()) {
			messageString = "Please provide layout information.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!isColLengthGT30()) {
			messageString = "Column length is greater than 30. Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!isDupColCheck()) {
			messageString = "Duplicate column name. Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!isInvalidColumn()) {
			messageString = "Invalid column name.Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!isInvalDatatype()) {
			messageString = "Invalid data type.Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!isInvalcolumnname()) {
			messageString = "Column Name cannot be one of the reserved words of oracle.Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!isInvalfieldlenthVal()) {
			messageString = "Invalid field length value.Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (!checkwhereclause(whereclause.toLowerCase())) {
			messageString = "Invalid where clause.Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		}

		else if (!isInvalDatedescription()) {
			messageString = "Invalid date/timestamp format.Please change it.";
			partialDuplicate = false;
			validationComplete = false;
		} else if (isInvalidskplastrow()) {
			messageString = "Invalid Trailer Skip field entry";
			partialDuplicate = false;
			validationComplete = false;
		} else {
			String result = "";
			try {
				result = verifyLayouts();
			} catch (ArrayIndexOutOfBoundsException ex) {

				log.debug("Error in Verify Layouts : " + ex.toString());
				displayErrorMessageToUser(
						"Couldnot Verify Layouts.Please Try Again", "Error");
				this.validationComplete = false;
				result = "ERROR";
				return;
			} catch (IndexOutOfBoundsException ex) {

				log.debug("Error in Verify Layouts : " + ex.toString());
				displayErrorMessageToUser(
						"Couldnot Verify Layouts.Please Try Again", "Error");
				this.validationComplete = false;
				result = "ERROR";
				return;
			} catch (NullPointerException ex) {
				System.out.println(ex.getLocalizedMessage());
				log.debug("Error in Verify Layouts in checklayout: "
						+ ex.getMessage());
				FacesContext.getCurrentInstance();
				displayErrorMessageToUser("No Layout Found.Please Try Again",
						"Error");
				this.validationComplete = false;
				result = "ERROR";
				return;
			}

			// result = verifyLayouts();
			System.out.println("Recieved Message String : " + result);

			if (result.equalsIgnoreCase("NEW")) {
				messageString = "Validation complete. Please submit.";
				validationComplete = true;
				partialDuplicate = false;
			} else if (result.contains("Exact Duplicate")) {
				messageString = result + " of Payer " + payer.split("~")[0]
						+ ". Please verify.";
				validationComplete = false;
				partialDuplicate = false;
			} else {
				messageString = result;

			}
		}

		displayInfoMessageToUser(messageString, "New Layout");

	}

	/**
	 * Method to check the validity of the user entered where clause
	 * 
	 * @param layouttype
	 *            Delimiter type
	 * @param whereclause
	 *            User defined where clause
	 * @return True or false
	 */
	public boolean checkwhereclause(String whereclause) {

		boolean result = false;
		if (whereclause.isEmpty()) {
			return true;
		}

		Pattern pattern = Pattern
				.compile("^$|[(][0-9]*[:][0-9]*[)][\\s+]*[!]*[=][\\s+]*[']*[\"]*[(]*[A-Za-z0-9/@#$()][)]*[\"]*[']*");
		Matcher matcher = pattern.matcher(whereclause);
		if (matcher.find()) {
			String delimeter = "";

			try {
				if (whereclause.contains(" and ")) {
					delimeter = "and";
				} else if (whereclause.contains(" or ")) {
					delimeter = "or";
				} else {

					int startR = whereclause.indexOf(":");
					int endR = whereclause.lastIndexOf(")");
					int startL = whereclause.indexOf("(");
					int endL = whereclause.lastIndexOf(":");
					String rightValue = whereclause.substring(startR + 1, endR);
					String leftValue = whereclause.substring(startL + 1, endL);
					int rightV = Integer.parseInt(rightValue);
					int leftV = Integer.parseInt(leftValue);

					if (rightV >= leftV) {
						result = true;

					} else {
						result = false;

					}

				}
				if (whereclause.contains(" and ")
						|| whereclause.contains(" or ")) {
					String stringPart[] = whereclause.split(delimeter);
					for (int i = 0; i < stringPart.length; i++) {

						int startR = stringPart[i].indexOf(":");
						int endR = stringPart[i].lastIndexOf(")");
						int startL = stringPart[i].indexOf("(");
						int endL = stringPart[i].lastIndexOf(":");
						String rightValue = stringPart[i].substring(startR + 1,
								endR);
						String leftValue = stringPart[i].substring(startL + 1,
								endL);
						int rightV = Integer.parseInt(rightValue);
						int leftV = Integer.parseInt(leftValue);

						if (rightV >= leftV) {
							result = true;

						} else {
							result = false;

						}

					}
				}

			} catch (NullPointerException e) {
				System.out.println("Null Pointer" + e.toString());
				result = false;
				
			} catch (ArrayIndexOutOfBoundsException e) {

				System.out.println("Array out of bounds Exception"
						+ e.toString());
				result = false;
			} catch (NumberFormatException e) {
				System.out.println("Number Format Exception" + e.toString());
				result = false;
			} catch (Exception ex) {
				System.out.println("4.Exception" + ex.toString());
				result = false;
			}
		} else {
			result = false;
			Pattern repattern = Pattern
					.compile("^$|[A-Za-z0-9][\\s+]*[!]*[=][\\s+]*[']*[\"]*[A-Za-z0-9/()@#$][\"]*[']*");
			Matcher rematcher = repattern.matcher(whereclause);

			if (rematcher.find()) {

				if (whereclause.contains(",") || whereclause.contains(";")
						|| whereclause.contains(":")) {
					result = false;
				} else {
					result = true;
				}
			}
		}

		return result;
	}


	/**
	 * Creates a LayoutFields Object from the csvvalues
	 * 
	 * @param csvvalues
	 *            Input string from hanson table
	 */
	public int createLayoutFieldsModule(String csvvalues) {
		
		
		System.out.println("Values : " + csvvalues);
		this.newLayoutFields = new ArrayList<>();
		String splitValues[] = csvvalues.split("~",-1);

		String excelDatas[] = new String[splitValues.length - 1];
		int substrpos = 0;
		int tempSubstr = 0;
		int start = 0;

		for (int j = 1; j < splitValues.length; j++) {

			excelDatas[j - 1] = j
					+ ","
					+ splitValues[j].replaceAll("\"", "'").replaceAll(";", ",")
							.replaceAll(",,", ",'',").replaceAll("'", "");

			String[] listofFields = excelDatas[j - 1].split(",");

			tempSubstr = substrpos;
			start = tempSubstr + 1;
			int length = excelDatas[j - 1].length();
			String temp = "";
			// if(excelDatas[j - 1][(excelDatas[j-1].length())-1].)
			if (excelDatas[j - 1].substring(length).compareTo(",") == 0) {
				temp = excelDatas[j - 1].substring(0,
						excelDatas[j - 1].lastIndexOf(",") - 1);
			} else {
				temp = excelDatas[j - 1].substring(0,
						excelDatas[j - 1].lastIndexOf(","));

			}
			
			

			
			try {
				if (listofFields[4].isEmpty()
						|| listofFields[4].compareTo("''") == 0) {
					displayErrorMessageToUser("REQUIRED FIELDS CANNOT BE EMPTY",
							"ERROR");
					this.validationComplete = false;
					return 0;
				}

				tempSubstr = Integer.parseInt(temp.substring(
						temp.lastIndexOf(",") + 1).replaceAll("'", ""));

				substrpos += tempSubstr;

				excelDatas[j - 1] += "," + start + "," + substrpos;

				this.newLayoutFields.add(new LayoutFields(excelDatas[j - 1]
						.split(",")[0], excelDatas[j - 1].split(",")[1],
						excelDatas[j - 1].split(",")[2], excelDatas[j - 1]
								.split(",")[3],
						excelDatas[j - 1].split(",")[4], Integer
								.parseInt(excelDatas[j - 1].split(",")[6]),
						Integer.parseInt(excelDatas[j - 1].split(",")[7]),
						excelDatas[j - 1].split(",")[5]));
			} catch (Exception ex) {
				System.out.println("ERRRR : " + ex.getMessage());
				this.validationComplete = false;
				return 0;

			}

		
		
		}
		return 1;
	}

	public void createLayoutModule() {

		this.newLayout = new Layout();
		this.newLayout.setPayor(this.payer.split("~")[0]);
		this.newLayout.setDataType(this.dataType);
		this.newLayout.setLayoutType(this.layoutType);
		this.newLayout.setLayoutDetail(calculateLayoutDetail());
	}

	public int validateDataModel(String csvValues) {
		String splitValues[] = csvValues.split("~");
		String excelDatas[] = new String[splitValues.length - 1];

		for (int j = 1; j < splitValues.length; j++) {

			excelDatas[j - 1] = j
					+ ","
					+ splitValues[j].replaceAll("\"", "'").replaceAll(";", ",")
							.replaceAll(",,", ",'',").replaceAll("'", "");
			System.out.println("EXCEL DATAS : " + excelDatas[j - 1]);

			String[] listofFields = excelDatas[j - 1].split(",");
			String columnname = "";
			String datatype = "";
			String fieldlength = "";

			try {
				columnname = listofFields[1];
				datatype = listofFields[2];
				fieldlength = listofFields[4];

				if (columnname.isEmpty() || columnname.compareTo("''") == 0
						|| datatype.isEmpty() || datatype.compareTo("''") == 0
						|| fieldlength.isEmpty()
						|| fieldlength.compareTo("''") == 0) {

					return 0;
				}
			} catch (Exception ex) {
				System.out.println("ERROR : " + ex.toString());
				return 0;
			}
		}
		return 1;

	}

	/**
	 * Method to verify Existing layouts with the new Layout
	 * 
	 * @param layoutcheck
	 *            variable for handling the partial duplicate Arraylist and next
	 *            button
	 * 
	 * @param count
	 *            count for number of partial duplicate layouts
	 */
	public String verifyLayouts() {

		try {

			String message = "NEW";
			layoutnew = new ArrayList<>();
			layoutexisting = new ArrayList<>();
			this.partialduplicateLayouts = new ArrayList<>();
			this.partialduplicateLayoutsNew=new ArrayList<>();

			layoutcheck = 0;
			int count = 0;
			int checkstat = validateDataModel(this.csvValues);
			if (checkstat == 0) {
				return "Invalid Layout";
			}
			createLayoutModule();
			int check = createLayoutFieldsModule(this.csvValues);
			if (check == 0) {
				displayErrorMessageToUser("Invalid Layout", "ERROR");
				this.validationComplete = false;
				return "ERROR";
			}

			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "select distinct(layoutid) from imp_layouts where payor='"
					+ this.payer.split("~")[0] + "'";

			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();

			if (rs != null) {
				this.listofLayoutids = new ArrayList<>();
				if (rs.size() > 1) {
					for (int i = 1; i < rs.size(); i++) {
						
						LayoutsbyID layoutObj = new LayoutsbyID(rs.get(i)
								.get(0), "1", "");
						this.mainlayout = new Layout();
						this.mainlayout = layoutObj.getLayouts().get(0);

						LayoutFieldsModel modelObj = new LayoutFieldsModel(rs
								.get(i).get(0), "1");

						this.mainLayoutFields = new ArrayList<>();
						this.mainLayoutFields = modelObj
								.getLayoutfieldsbysublayout();

						if (this.mainLayoutFields.size() == this.newLayoutFields
								.size()) {

							CheckDuplicateLayout duplicateCheck = new CheckDuplicateLayout(
									this.mainlayout, this.newLayout,
									this.mainLayoutFields, this.newLayoutFields);
							message = duplicateCheck.checkForExactDuplicate();

							if (!message.equalsIgnoreCase("NEW")) {
								this.partialDuplicate = false;
								this.validationComplete = false;
								count = 0;
								break;
							} else {
								int stat = duplicateCheck
										.checkForPartialDuplicate();
								

								if (stat == 1) {
									count++;
									message = "Similar Layout already exist in the system.Please Verify";
									this.listofLayoutids.add(rs.get(i).get(0));
									this.partialduplicateLayouts
											.add(duplicateCheck
													.getPartialDuplicateFieldsOldLayout());
									this.layoutexisting = this.partialduplicateLayouts
											.get(layoutcheck);

									this.partialDuplicate = true;

									this.layoutMatched = this.listofLayoutids
											.get(layoutcheck);
									this.partialduplicateLayoutsNew.add(duplicateCheck.getPartialDuplicateFieldsNewLayout());
									this.layoutnew = this.partialduplicateLayoutsNew.get(layoutcheck);
								}
							}

						}
					}

					if (count > 0) {
						this.partialDuplicate = true;
						this.validationComplete = false;
						message = "Similar Layout already exist in the system.Please Verify";
					}
					if (count > 1) {
						this.nextstatus = true;
					} else {
						this.nextstatus = false;
					}
				} else {
					message = "NEW";
				}
			} else {
				displayErrorMessageToUser(
						"Couldnot verify layouts.Please try again", "ERROR");
			}

			return message;

		} catch (Exception ex) {
			log.error("ERROR IN LAYOUT CHECK : " + ex.getMessage());
			this.validationComplete = false;
			return "ERROR";

		}

	}

	public void handleNext() {
		layoutcheck++;
		if (layoutcheck < this.partialduplicateLayouts.size()) {
			try {
				this.layoutexisting = this.partialduplicateLayouts
						.get(layoutcheck);
				this.layoutMatched = this.listofLayoutids.get(layoutcheck);
				this.layoutnew=this.partialduplicateLayoutsNew.get(layoutcheck);
			} catch (Exception ex) {
				log.error("Array Out Of Bounds.Handle Next()");
			}

		}

		if (layoutcheck == this.partialduplicateLayouts.size() - 1) {
			this.nextstatus = false;
		}
	}

	public String calculateLayoutDetail() {

		/*
		 * For fixed length : layout detail= Sum of fieldlengths : layout
		 * Detail=number of fields
		 */

		String splitValues[] = csvValues.split("~");
		String excelDatas[] = new String[splitValues.length - 1];
		int substrpos = 0;
		int tempSubstr = 0;
		int i;
		for (i = 1; i < splitValues.length; i++) {
			excelDatas[i - 1] = splitValues[i].replaceAll("\"", "'")
					.replaceAll(";", ",").replaceAll(",,", ",'',");

			tempSubstr = substrpos;
			String temp = excelDatas[i - 1].substring(0,
					excelDatas[i - 1].lastIndexOf(",") - 1);

			System.out.println("CALCULATE TEMP : " + temp);

			tempSubstr = Integer.parseInt(temp.substring(
					temp.lastIndexOf(",") + 1).replaceAll("'", ""));
			substrpos += tempSubstr;
		}

		if (layoutType.toLowerCase().startsWith("fixe")
				|| layoutType.toLowerCase().startsWith("subs")) {
			layoutDetail = substrpos + "";
		} else {
			layoutDetail = (i - 1) + "";
		}

		return layoutDetail;

	}

	public void addLayout() {

		String messageString = "";
		String results = null;
		try {
			results = verifyLayouts();

		} catch (ArrayIndexOutOfBoundsException ex) {

			displayErrorMessageToUser(
					"Couldnot Verify Layouts.Please Try Again", "Error");
			this.validationComplete = false;
			results = "ERROR";
			return;
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("No Layout Found.Please Try Again",
					"Error");
			this.validationComplete = false;
			results = "ERROR";
			return;
		}
		if (results.equalsIgnoreCase("NEW")) {

			validationComplete = true;
			partialDuplicate = false;
		}

		else if (results.contains("Exact Duplicate")) {
			messageString = results + " of Payer " + payer.split("~")[0]
					+ ". Please verify.";
			validationComplete = false;
			partialDuplicate = false;
			displayInfoMessageToUser(messageString, "New Layout");
			return;
		}

		else {
			this.validationComplete = true;
			this.partialDuplicate = false;
		}

		String result = "";

		RequestContext.getCurrentInstance().execute("PF('subdialog').show()");

		try {

			if (this.validationComplete == true)
				result = "NEW";
			if (result.equalsIgnoreCase("NEW")) {
				String payerName = payer.split("~")[0];
				String payerId = payer.split("~")[1];
				String shortName = payer.split("~")[2];

				String userLog = getUserinfo().getFullname();
				String sn = getNewLayoutId();
				ConnectDB db = new ConnectDB();
				db.initialize();
				String layoutStatus = "";
				String activeFlag = "";
				if (!this.isNew) {
					layoutStatus = "HOLD";
					activeFlag = "N";
				} else {
					layoutStatus = "WORKING";
					activeFlag = "Y";
				}
				String query = "INSERT INTO IMP_LAYOUTS(LAYOUTID,PAYOR, DATATYPE, PUCHCHARFLAG, OPTIONALLY, SKIPROW, "
						+ " ENTRYDATE, TRAILERSKIP,PAYORID ,LAYOUTDESCIPTION ,SOURCEINFO,USERLOG,SHORTPAYOR,ACTIVEFLAG,Verified,characterset,layout_status) "
						+ " VALUES("
						+ sn
						+ ", "
						+ " '"
						+ payerName.replaceAll("'", "''")
						+ "', '"
						+ dataType.replaceAll("'", "''")
						+ "', "
						+ " '"
						+ punchChar
						+ "','"
						+ optEnc
						+ "','"
						+ skpRow
						+ "',SYSDATE, "
						+ " '"
						+ skpLastRow
						+ "','"
						+ payerId
						+ "','"
						+ layoutDesc.replaceAll("'", "''")
						+ "', "
						+ " '"
						+ srcInfo.replaceAll("'", "''")
						+ "','"
						+ userLog
						+ "','"
						+ shortName
						+ "','"
						+ activeFlag
						+ "','"
						+ this.verified
						+ "','"
						+ this.characterSet
						+ "','" + layoutStatus + "')";

				String stat = db.executeDML(query);
				if (stat.compareTo("1") != 0) {
					keepDialogOpen();
					displayErrorMessageToUser(
							"Add Layout Failed.Please Try again", "ERROR");
					return;
				}

				/*
				 * if(trailerCondition.equalsIgnoreCase("N")) {
				 * trailerSkipCondition = ""; }
				 */
				if (whereCondition.equalsIgnoreCase("N")) {
					whereClause = "";
				}

				String splitValues[] = csvValues.split("~");
				String excelDatas[] = new String[splitValues.length - 1];

				String ins = "INSERT INTO IMP_SUB_LAYOUTS(LAYOUTID, SUBLAYOUTID, LAYOUTTYPE, WHERECLAUSE, "
						+ " SUBLAYOUTDESC) VALUES('"
						+ sn
						+ "','1','"
						+ layoutType
						+ "',"
						+ " '"
						+ whereClause.replaceAll("'", "''")
						+ "','"
						+ subLayoutDesc + "')";

				String stat1 = db.executeDML(ins);
				if (stat1.compareTo("1") != 0) {
					keepDialogOpen();
					displayErrorMessageToUser(
							"Add Layout Failed.Please Try again", "ERROR");
					return;
				}
				int substrpos = 0;
				int tempSubstr = 0;
				int start = 0;
				int i;
				for (i = 1; i < splitValues.length; i++) {
					excelDatas[i - 1] = splitValues[i].replaceAll("\"", "'")
							.replaceAll(";", ",").replaceAll(",,", ",'',");
					String[] listofFields = excelDatas[i - 1].split(",");
					String columnname = listofFields[0].toUpperCase().replaceAll("'", "");
					String datatype = listofFields[1].toUpperCase().replaceAll("'", "");
					String dtdetail = listofFields[2].replaceAll("'", "");
					String length = "";

					try {
						length = listofFields[3].replaceAll("'", "");
					} catch (Exception ex) {
						displayErrorMessageToUser(
								"FIELD LENGTH CANNOT BE NULL", "ERROR");
					}
					String busname = "";
					try {
						busname = listofFields[4].replaceAll("'", "");
					} catch (Exception ex) {
						busname = "";
					}

					// System.out.println("CN " + columnname + " busname : " +
					// busname);
					tempSubstr = substrpos;
					start = tempSubstr + 1;
					String temp = excelDatas[i - 1].substring(0,
							excelDatas[i - 1].lastIndexOf(",") - 1);

					tempSubstr = Integer.parseInt(temp.substring(
							temp.lastIndexOf(",") + 1).replaceAll("'", ""));
					substrpos += tempSubstr;

					ins = "INSERT INTO IMP_LAYOUTS_FIELDS(LAYOUTID, SUBLAYOUTID, COLUMNID, COLUMNNAME, DATATYPE,"
							+ " DATETYPEDETIAL, FIELDLENGTH , BUSINESSNAME,STARTPOS,ENDPOS,CATEGORY)"
							+ " VALUES('"
							+ sn
							+ "','1','"
							+ i
							+ "','"
							+ columnname.replaceAll("'", "''")
							+ "','"
							+ datatype.replaceAll("'", "''")
							+ "','"
							+ dtdetail.replaceAll("'", "''")
							+ "','"
							+ length.replaceAll("'", "''")
							+ "','"
							+ busname.replaceAll("'", "''")
							+ "','"
							+ start
							+ "','"
							+ substrpos + "','" + remapCategory(datatype.replaceAll("'", "''")) + "')";

					if (ins.substring(ins.length() - 2).equalsIgnoreCase(",)")) {
						ins = ins.substring(0, ins.length() - 2);
						ins = ins + ",'')";
					}

					db.executeDML(ins);
				}

				System.out.println("Query : " + ins);

				if (layoutType.toLowerCase().startsWith("fixe")
						|| layoutType.toLowerCase().startsWith("subs")) {
					layoutDetail = substrpos + "";
				} else {
					layoutDetail = (i - 1) + "";
				}

				ins = "UPDATE IMP_SUB_LAYOUTS SET LAYOUTDETAIL='"
						+ layoutDetail + "' WHERE LAYOUTID='" + sn
						+ "' AND SUBLAYOUTID='1'";

				db.executeDML(ins);

				db.endConnection();

				getSessionData().setNewAdditionComplete(true);

				if (!this.isNew) {
					takeActionforPartialDuplicate();
				}

			} else {
				displayErrorMessageToUser(
						result + " of Payer " + payer.split("~")[0]
								+ ". Please verify.", "New Layout");
				validationComplete = false;
			}

		} catch (ArrayIndexOutOfBoundsException ex) {

			log.error("Add Layout-Check Duplicate" + ex.toString());

			displayErrorMessageToUser(
					"Couldnot Verify Layouts.Please Try Again", "Error");
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			log.error("Add Layout-Check Duplicate" + ex.toString());
			displayErrorMessageToUser("No Layout Found.Please Try Again",
					"Error");
		}
	}
	
	/* Find appropriate category if category is not pre populated */
	public String remapCategory(String datatype) {
		String category = "";

		String query = "SELECT a.DATATYPE_NAME,b.CATEGORY_NAME FROM dp_catgry_datatype_mapping a left JOIN DP_CHECK_CATEGORIES  b ON   a.cat_sn = b.cat_sn where  a.DATATYPE_NAME='"
				+ datatype + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				category = rs.get(1).get(1);
			} else {
				category = datatype;
			}
		}
		return category;

	}

	public void takeActionforPartialDuplicate() {
		log.info("--Partial Duplicate Layout Detected..Taking action--");
		RequestContext
				.getCurrentInstance()
				.execute(
						"alert('WARNING: You have entered a partial duplicate layout.This layout cannot be used until verified by Payor Management Team.Contact Payor Management Team to activate this layout');");
	}

	/**
	 * Returns the layoutid for a new layout i.e. Max +1
	 */
	public String getNewLayoutId() {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT MAX(LAYOUTID) +1 FROM IMP_LAYOUTS";
		String sn = "0";
		List<List<String>> snList = db.resultSetToListOfList(query);
		db.endConnection();
		if (snList.size() > 1) {
			sn = snList.get(1).get(0);
			setNewlayoutID(sn);
		} else {
			sn = "0";
		}
		return sn;
	}

	public void reset() {
		this.payer = "";
		this.dataType = "";
		this.layoutType = "";
		this.layoutDetail = "";
		this.punchChar = "";
		this.optEnc = "";
		this.isNew = true;

		setSkpLastRow("0");
		setSkpRow("0");
		trailerCondition = "N";
		whereCondition = "N";
		setColLengthGT30(true);
		setDupColCheck(true);
		setInvalidColumn(true);
		setLayoutPopulated(true);
		setInvalDatatype(true);
		setInvalfieldlenthVal(true);
		setInvalDatedescription(true);
		this.whereClause = "";
		this.layoutDesc = "";
		this.srcInfo = "";
		this.subLayoutDesc = "";
		this.trailerSkipCondition = "";
		this.csvValues = "";
		validationComplete = false;
	}

	/**
	 * Returns the latest layoutid from the system
	 */
	public String getnewlayoutid() {
		String query = "SELECT MAX(LAYOUTID) FROM IMP_LAYOUTS";

		String id = "0";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> snList = db.resultSetToListOfList(query);
		db.endConnection();
		if (snList.size() > 1) {
			id = snList.get(1).get(0);

		} else {
			id = "0";
		}
		return id;
	}

	public String getCharacterSet() {
		return characterSet;
	}

	public void setCharacterSet(String characterSet) {
		this.characterSet = characterSet;
	}

	public ArrayList<String> getCharacterSets() {
		return characterSets;
	}

	public void setCharacterSets(ArrayList<String> characterSets) {
		this.characterSets = characterSets;
	}

	public Layout getNewLayout() {
		return newLayout;
	}

	public void setNewLayout(Layout newLayout) {
		this.newLayout = newLayout;
	}

	public Layout getMainlayout() {
		return mainlayout;
	}

	public void setMainlayout(Layout mainlayout) {
		this.mainlayout = mainlayout;
	}

	public ArrayList<String> getListofLayoutids() {
		return listofLayoutids;
	}

	public void setListofLayoutids(ArrayList<String> listofLayoutids) {
		this.listofLayoutids = listofLayoutids;
	}

}
