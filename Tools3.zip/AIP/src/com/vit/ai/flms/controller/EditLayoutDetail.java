package com.vit.ai.flms.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutFields;
import com.vit.ai.flms.model.LayoutFieldsModel;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.CustomUtility;
import com.vit.ai.utils.EmailConfiguration;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class EditLayoutDetail extends AddLayoutBean {

	private static Logger log = Logger.getLogger(EditLayoutDetail.class
			.getName());
	private static final long serialVersionUID = 4534423698871317494L;

	private ArrayList<Layout> layouts;
	private String payor;
	private String endPos;
	private String sublayoutid = "1";
	private ArrayList<String> sublayoutids;
	private String layoutStatus = "";
	private ArrayList<LayoutFields> listofOldFields=new ArrayList<>();
	private ArrayList<LayoutFields> listofNewFields=new ArrayList<>();
	private ArrayList<String> listofLayoutids;

	public ArrayList<String> getListofLayoutids() {
		return listofLayoutids;
	}

	public void setListofLayoutids(ArrayList<String> listofLayoutids) {
		this.listofLayoutids = listofLayoutids;
	}

	public String getLayoutStatus() {
		return layoutStatus;
	}

	public void setLayoutStatus(String layoutStatus) {
		this.layoutStatus = layoutStatus;
	}

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	private String layoutId;
	private int noofRows;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private ArrayList<ArrayList<String>> check = new ArrayList<ArrayList<String>>();
	ArrayList<String> checkin;// ArrayList for populating the HansonTable
	private ArrayList<String> layoutids = new ArrayList<String>();
	private Layout selectedLayout = new Layout();// Layout to be used
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;
	private ArrayList<Layout> listOfLayouts;
	private int numOfChild = 1;

	public int getNumOfChild() {
		return numOfChild;
	}

	public void setNumOfChild(int numOfChild) {
		this.numOfChild = numOfChild;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public int getNoofRows() {
		return noofRows;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public void setNoofRows(int noofRows) {
		this.noofRows = noofRows;
	}

	public ArrayList<Layout> getLayouts() {
		return layouts;
	}

	public void setLayouts(ArrayList<Layout> layouts) {
		this.layouts = layouts;
	}

	public ArrayList<String> getLayoutids() {
		return layoutids;
	}

	public void setLayoutids(ArrayList<String> layoutids) {
		this.layoutids = layoutids;
	}

	public ArrayList<ArrayList<String>> getCheck() {

		return this.check;
	}

	public void setCheck(ArrayList<ArrayList<String>> check) {
		this.check = check;
	}

	public String getLayoutId() {

		return this.layoutId;

	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	public EditLayoutDetail() {
		super();
		init();
	}

	@PostConstruct
	public void init() {
		
		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("lid") != null) {
			this.layoutId = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("lid");
		} else {
			this.layoutId = "";
		}

		getLayoutbySublayoutid("1");

	}

	public void getLayoutbySublayoutid(String slid) {

		LayoutsbyID objLayout = new LayoutsbyID(this.layoutId, slid, "");
		this.listOfLayouts = new ArrayList<>();
		this.listOfLayouts = objLayout.getLayouts();

		ArrayList<String> sublayoutids = new ArrayList<String>();
		setSublayoutids(sublayoutids);

		this.selectedLayout = objLayout.getLayouts().get(0);

		if (this.selectedLayout != null) {

			this.payer = getSelectedLayout().getPayor();

			// this.layoutId = getSelectedLayout().getLayoutID();
			handleLayoutChange();
		}

	}

	public void handleLayoutChange() {
		this.csvValues = "";
		if (payer != null && !payer.equals("") && this.layoutId != null
				&& !this.layoutId.equals("")) {

			this.payor = this.payer.split("~")[0];
			setPayer(payers.get(payer));
			setDataType(getSelectedLayout().getDataType());
			setLayoutType(getSelectedLayout().getLayoutType());
			setPunchChar(getSelectedLayout().getPunchCharFlag());
			setOptEnc(getSelectedLayout().getOptionallyEnclosedFlag());
			setSkpRow(getSelectedLayout().getSkipRow());
			setSkpLastRow(getSelectedLayout().getTrailerSkip() == "" ? "0"
					: getSelectedLayout().getTrailerSkip());
			setWhereClause(getSelectedLayout().getWhereClause());
			setTrailerSkipCondition(getSelectedLayout().getTrailerSkip());
			setLayoutDesc(getSelectedLayout().getLayoutDesc());
			setSubLayoutDesc(getSelectedLayout().getSubLayoutDesc());
			setSrcInfo(getSelectedLayout().getSourceInfo());
			setVerified(getSelectedLayout().getVerified());
			setCharacterSet(getSelectedLayout().getCharacterSet());
			setLayoutStatus(getSelectedLayout().getLayoutstatus());
			/*setColLengthGT30(true);
			setDupColCheck(true);
			setInvalidColumn(true);
			setLayoutPopulated(true);
			setInvalDatatype(true);
			setInvalfieldlenthVal(true);
			setInvalDatedescription(true);*/

		}

	}

	public void setCsvValueshere(String sublayoutid) {
/*
		setColLengthGT30(true);
		setDupColCheck(true);
		setInvalidColumn(true);
		setLayoutPopulated(true);
		setInvalDatatype(true);
		setInvalfieldlenthVal(true);
		setInvalDatedescription(true);*/
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT columnname, datatype, datetypedetial, fieldlength,businessname,startpos,endpos "
				+ "FROM imp_layouts_fields WHERE layoutid='"
				+ this.layoutId
				+ "' and sublayoutid= '"
				+ sublayoutid
				+ "'ORDER BY sublayoutid,COLUMNID  asc";

		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();

		if (rs != null) {
			if (rs.size() > 1) {
				this.noofRows = rs.size() - 1;
				for (int i = 1; i < rs.size(); i++) {
					checkin = new ArrayList<String>();

					String clmname = rs.get(i).get(0);

					checkin.add(" \"" + clmname + "\"");
					String dtype = rs.get(i).get(1);

					checkin.add(" \"" + dtype + "\"");
					String datedetail = rs.get(i).get(2);

					if (datedetail == null) {
						checkin.add(datedetail);
					} else {
						checkin.add(" \"" + datedetail + "\"");
					}
					String flength = rs.get(i).get(3);

					checkin.add(" \"" + flength + "\"");

					String businessname = rs.get(i).get(4);
					checkin.add(" \"" + businessname + "\"");

					String startPos = rs.get(i).get(5);
					if (startPos == null) {
						checkin.add(startPos);
					} else {
						checkin.add(" \"" + startPos + "\"");
					}

					String endPos = rs.get(i).get(6);
					if (endPos == null) {
						checkin.add(endPos);
					} else {
						checkin.add(" \"" + endPos + "\"");
					}

					check.add(i - 1, checkin);

					setCheck(check);
				}
			}
		}

	}

	public ArrayList<LayoutFields> getOldFields(String layoutid,String slid) {
		this.listofOldFields = new ArrayList<>();

		LayoutFieldsModel objLFB = new LayoutFieldsModel(layoutid,slid);
		this.listofOldFields.addAll(objLFB.getLayoutfieldsbysublayout());
		
		return this.listofOldFields;
	}

	public ArrayList<LayoutFields> getNewFields() {
		
		
		this.listofNewFields = new ArrayList<>();

		String splitValues[] = this.csvValues.split("~");
		String excelDatas[] = new String[splitValues.length - 1];

		for (int i = 1; i < splitValues.length; i++) {
			excelDatas[i - 1] = splitValues[i].replaceAll("\"", "'")
					.replaceAll(";", ",").replaceAll(",,", ",'',");
			String[] listofDetails = excelDatas[i - 1].split(",");
			String columnname = listofDetails[0].toUpperCase().replaceAll("\'",
					"");
			String datatype = listofDetails[1].toUpperCase().replaceAll("\'",
					"");
			String ddetail = listofDetails[2].replaceAll("\'", "");
			String fieldlength = "";
			try {
				fieldlength = listofDetails[3].replaceAll("\'", "");
			} catch (Exception ex) {
				displayErrorMessageToUser("FIELD LENGTH CANNOT BE EMPTY",
						"ERROR");
				return new ArrayList<>();
			}
			String businessname = "";
			String stpos = "";
			String epos = "";
			int spos = 0;
			int endpos = 0;
			try {
				businessname = listofDetails[4].toUpperCase().replaceAll("\'",
						"");
			} catch (Exception ex) {
				businessname = "";
			}
			try {
				stpos = listofDetails[5].replaceAll("\'", "");
				spos = Integer.parseInt(stpos);

			} catch (Exception ex) {
				stpos = "";
				spos = 0;
			}
			try {
				epos = listofDetails[6].replaceAll("\'", "");
				endpos = Integer.parseInt(epos);
			} catch (Exception ex) {
				epos = "";
				endpos = 0;
			}
			
			this.listofNewFields.add(new LayoutFields(String.valueOf(i),
					columnname, datatype, ddetail, fieldlength, spos, endpos,
					businessname));

		}
		return this.listofNewFields;

	}

	@Override
	public void addLayout() {
		String messageString = "";
		String results = null;
		try {
			results = verifyLayouts();

		} catch (ArrayIndexOutOfBoundsException ex) {

			displayErrorMessageToUser(
					"Couldnot Verify Layouts.Please Try Again", "Error");
			this.validationComplete = false;
			return;
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("No Layout Found.Please Try Again",
					"Error");
			this.validationComplete = false;
			return;
		}
		if (results.equalsIgnoreCase("NEW")) {

			validationComplete = true;
			partialDuplicate = false;
		}

		else if (results.contains("Exact Duplicate")) {
			messageString = results + " of Payer " + payer.split("~")[0]
					+ ". Please verify.";
			validationComplete = false;
			partialDuplicate = false;
			displayInfoMessageToUser(messageString, "New Layout");
			return;
		} else {
			this.validationComplete = true;
			this.partialDuplicate = false;
		}

		String result = "";
		try {

			if (this.validationComplete == true)
				result = "NEW";
			if (result.equalsIgnoreCase("NEW")) {

				setValidationComplete(false);
				String userLog = getUserinfo().getFullname();
				String sn = this.layoutId;
				String ins = "";
				this.listofOldFields=getOldFields(sn,this.sublayoutid);
				this.listofNewFields=getNewFields();
				
				
				
				String check1 = UpdateFields(this.listofOldFields,
						this.listofNewFields, sn);
				ConnectDB db = new ConnectDB();
				db.initialize();

				if (check1.compareTo("1") == 0) {
					ins = "UPDATE IMP_SUB_LAYOUTS SET LAYOUTDETAIL='"
							+ calculateLayoutDetail() + "' WHERE LAYOUTID='"
							+ sn + "' AND SUBLAYOUTID='" + this.sublayoutid
							+ "'";
					db.executeDML(ins);
					String updatequery = "update imp_layouts_fields set updated_by='"
							+ userLog
							+ "' where layoutid='"
							+ this.layoutId
							+ "'";
					db.executeDML(updatequery);
					sendMail(this.layoutId, this.sublayoutid,
							getSelectedLayout().getUserlog());

				} else if(check1.compareTo("0")==0) {

					displayErrorMessageToUser("Update Failed.Please Reload again to see the updated fields and try again.", "ERROR UPDATE");
					return;
				}
				else if(check1.compareTo("2")==0)
				{
					displayErrorMessageToUser("Cannot Modify Layout.Number of Rows cannot be reduced while editing.", "ERROR UPDATE");
					return;
				}
				db.endConnection();

				displayInfoMessageToUser("Layout Modified Successfully",
						"Layout Modification");

			} else {
				displayErrorMessageToUser(
						result + " of Payer " + payer.split("~")[0]
								+ ". Please verify.", "Layout Modification");
				validationComplete = false;
			}
		} catch (ArrayIndexOutOfBoundsException ex) {

			displayErrorMessageToUser(
					"Couldnot Verify Layouts.Please Try Again", "Error");
		} 
		catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			System.out.println(ex.toString());
			displayErrorMessageToUser("No Layout Found.Please Try Again",
					"Error");
		}
		
	}

	public String UpdateFields(ArrayList<LayoutFields> listofOldFields,
			ArrayList<LayoutFields> listofNewFields, String layoutid) {
		String stat = "0";
		if (listofOldFields.size() == listofNewFields.size()) {
			stat = totalUpdate(listofOldFields, listofNewFields, layoutid);
		} else if (listofOldFields.size() < listofNewFields.size()) {
			stat = partialUpdateAndInsert(listofOldFields, listofNewFields,
					layoutid);
		} else {
			stat = partialUpdateAndDelete(listofOldFields, listofNewFields,
					layoutid);
		}
		return stat;
	}

	public String totalUpdate(ArrayList<LayoutFields> oldFieldsObj,
			ArrayList<LayoutFields> newFieldsObj, String lid) {

		log.info("--TOTAL UPDATE FOR LAYOUT ID : " + lid + "----");
		String stat = "1";
		ConnectDB db = new ConnectDB();
		db.initialize();
		try
		{
		for (int i = 0; i < newFieldsObj.size(); i++) {
			String query = "update imp_layouts_fields set columnname='"
					+ newFieldsObj.get(i).getColumnName() + "' , datatype='"
					+ newFieldsObj.get(i).getDataType() + "',"
					+ "DATETYPEDETIAL='"
					+ newFieldsObj.get(i).getDateTypeDetail()
					+ "', FIELDLENGTH='" + newFieldsObj.get(i).getFieldLength()
					+ "', STARTPOS='" + newFieldsObj.get(i).getStart() + "',"
					+ "ENDPOS='" + newFieldsObj.get(i).getEnd()
					+ "', BUSINESSNAME='"
					+ newFieldsObj.get(i).getBusinessname() + "' where SN='"+oldFieldsObj.get(i).getSn()+"'";
			String check=db.executeDML(query);
			if(check.compareTo("1")!=0)
			{
				stat="0";
				
				return stat;
				
			}
		}
		}
		catch(Exception ex)
		{
			stat="0";
		}
		finally
		{
			db.endConnection();
		}
		return stat;
	}

	public String partialUpdateAndInsert(ArrayList<LayoutFields> oldFieldsObj,
			ArrayList<LayoutFields> newFieldsObj, String lid) {
		log.info("--PARTIAL UPDATE AND INSERT FOR LAYOUT ID : " + lid + "----");
		String stat = "1";
		int lastIndex=0;
		ConnectDB db = new ConnectDB();
		db.initialize();
		for (int i = 0; i < oldFieldsObj.size(); i++) {
			String query = "update imp_layouts_fields set columnname='"
					+ newFieldsObj.get(i).getColumnName().replaceAll("\'", "''") + "' , datatype='"
					+ newFieldsObj.get(i).getDataType().replaceAll("\'", "''") + "',"
					+ "DATETYPEDETIAL='"
					+ newFieldsObj.get(i).getDateTypeDetail().replaceAll("\'", "''")
					+ "', FIELDLENGTH='" + newFieldsObj.get(i).getFieldLength().replaceAll("\'", "''")
					+ "', STARTPOS='" + newFieldsObj.get(i).getStart() + "',"
					+ "ENDPOS='" + newFieldsObj.get(i).getEnd()
					+ "', BUSINESSNAME='"
					+ newFieldsObj.get(i).getBusinessname().replaceAll("\'", "''") + "' where SN='"+oldFieldsObj.get(i).getSn()+"'";
			String check=db.executeDML(query);
			lastIndex=i;
			if(check.compareTo("1")!=0)
			{
				stat="0";
				
				return stat;
				
			}
		}
		for(int i=lastIndex+1;i<newFieldsObj.size();i++)
		{
			String ins = "INSERT INTO IMP_LAYOUTS_FIELDS(LAYOUTID,SUBLAYOUTID, COLUMNID, COLUMNNAME, DATATYPE,"
					+ " DATETYPEDETIAL, FIELDLENGTH ,BUSINESSNAME,STARTPOS,ENDPOS,CATEGORY)"
					+ " VALUES('"
					+ lid
					+ "','"
					+ this.sublayoutid
					+ "','"
					+ (i+1)
					+ "','"
					+ newFieldsObj.get(i).getColumnName().replaceAll("\'", "''")
					+ "','"
					+ newFieldsObj.get(i).getDataType().replaceAll("\'", "''")
					+ "','"
					+ newFieldsObj.get(i).getDateTypeDetail().replaceAll("\'", "''")
					+ "','"
					+ newFieldsObj.get(i).getFieldLength().replaceAll("\'", "''")
					+ "','"
					+ newFieldsObj.get(i).getBusinessname().replaceAll("\'", "''")
					+ "','"
					+ newFieldsObj.get(i).getStart()
					+ "','"
					+ newFieldsObj.get(i).getEnd()
					+"','"
					+remapCategory(newFieldsObj.get(i).getDataType().replaceAll("\'", "''"))
					+ "')";
			String check=db.executeDML(ins);
			lastIndex=i;
			if(check.compareTo("1")!=0)
			{
				stat="0";
				
				return stat;
				
			}

		}
		return stat;
	}

	public String partialUpdateAndDelete(ArrayList<LayoutFields> oldFieldsObj,
			ArrayList<LayoutFields> newFieldsObj, String lid) {
		String stat = "2";
		return stat;
	}

	public void cancel() {
		RequestContext.getCurrentInstance().closeDialog("extendexistinglayout");
	}

	public Layout getSelectedLayout() {
		return selectedLayout;
	}

	public void setSelectedLayout(Layout selectedLayout) {
		this.selectedLayout = selectedLayout;

	}

	@Override
	public int createLayoutFieldsModule(String csvvalues) {

		try {

			this.newLayoutFields = new ArrayList<>();
			String splitValues[] = csvValues.split("~");

			String excelDatas[] = new String[splitValues.length - 1];

			for (int j = 1; j < splitValues.length; j++) {

				excelDatas[j - 1] = j
						+ ","
						+ splitValues[j].replaceAll("\"", "'")
								.replaceAll(";", ",").replaceAll(",,", ",'',")
								.replaceAll("'", "");

				this.newLayoutFields.add(new LayoutFields(excelDatas[j - 1]
						.split(",")[0], excelDatas[j - 1].split(",")[1],
						excelDatas[j - 1].split(",")[2], excelDatas[j - 1]
								.split(",")[3],
						excelDatas[j - 1].split(",")[4], Integer
								.parseInt(excelDatas[j - 1].split(",")[6]),
						Integer.parseInt(excelDatas[j - 1].split(",")[7]),
						excelDatas[j - 1].split(",")[5]));

			}
		} catch (Exception ex) {
			return 0;
		}
		return 1;
	}

	@Override
	public void createLayoutModule() {

		this.newLayout = new Layout();
		this.newLayout.setPayor(this.payer.split("~")[0]);
		this.newLayout.setDataType(this.dataType);
		this.newLayout.setLayoutType(this.layoutType);
		this.newLayout.setLayoutDetail(calculateLayoutDetail());
	}

	@Override
	public int validateDataModel(String csvValues) {
		String splitValues[] = csvValues.split("~");
		String excelDatas[] = new String[splitValues.length - 1];

		for (int j = 1; j < splitValues.length; j++) {

			excelDatas[j - 1] = j
					+ ","
					+ splitValues[j].replaceAll("\"", "'").replaceAll(";", ",")
							.replaceAll(",,", ",'',").replaceAll("'", "");
		

			String[] listofFields = excelDatas[j - 1].split(",");
			String columnname = "";
			String datatype = "";
			String fieldlength = "";
			String spos = "";
			String epos = "";

			try {
				columnname = listofFields[1];
				datatype = listofFields[2];
				fieldlength = listofFields[4];
				spos = listofFields[6];
				epos = listofFields[7];

				if (columnname.isEmpty() || columnname.compareTo("''") == 0
						|| datatype.isEmpty() || datatype.compareTo("''") == 0
						|| fieldlength.isEmpty()
						|| fieldlength.compareTo("''") == 0 || spos.isEmpty()
						|| spos.compareTo("''") == 0 || epos.isEmpty()
						|| epos.compareTo("''") == 0) {

					return 0;
				}
			} catch (Exception ex) {
				System.out.println("ERROR : " + ex.toString());
				return 0;
			}
		}
		return 1;

	}

	@Override
	public String verifyLayouts() {

		if (this.csvValues.length() < 106) {
			displayErrorMessageToUser("Layout Details cannot be empty", "ERROR");
			this.validationComplete = false;
			return "";
		}
		String message = "NEW";

		if (this.sublayoutid.compareTo("1") == 0) {

			layoutnew = new ArrayList<>();
			layoutexisting = new ArrayList<>();
			this.partialduplicateLayouts = new ArrayList<>();

			layoutcheck = 0;
			int count = 0;
			int checkstat = validateDataModel(this.csvValues);
			if (checkstat == 0) {
				this.validationComplete = false;
				return "Invalid Layout";

			}
			createLayoutModule();
			createLayoutFieldsModule(this.csvValues);

			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "select distinct(layoutid) from imp_layouts where payor='"
					+ this.payer.split("~")[0]
					+ "' and layoutid!='"
					+ this.layoutId + "'";

			

			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();

			if (rs != null) {
				this.listofLayoutids = new ArrayList<>();
				if (rs.size() > 1) {
					for (int i = 1; i < rs.size(); i++) {

						LayoutsbyID layoutObj = new LayoutsbyID(rs.get(i)
								.get(0), "1", "");
						this.mainlayout = new Layout();
						this.mainlayout = layoutObj.getLayouts().get(0);

						LayoutFieldsModel modelObj = new LayoutFieldsModel(rs
								.get(i).get(0), "1");

						this.mainLayoutFields = new ArrayList<>();
						this.mainLayoutFields = modelObj
								.getLayoutfieldsbysublayout();

						if (this.mainLayoutFields.size() == this.newLayoutFields
								.size()) {

							CheckDuplicateLayout duplicateCheck = new CheckDuplicateLayout(
									this.mainlayout, this.newLayout,
									this.mainLayoutFields, this.newLayoutFields);
							message = duplicateCheck.checkForExactDuplicate();

							if (!message.equalsIgnoreCase("NEW")) {
								this.partialDuplicate = false;
								this.validationComplete = false;
								count = 0;
								break;
							} else {
								int stat = duplicateCheck
										.checkForPartialDuplicate();
								
								if (stat == 1) {
									count++;
									this.listofLayoutids.add(rs.get(i).get(0));
									this.partialduplicateLayouts
											.add(duplicateCheck
													.getPartialDuplicateFieldsOldLayout());
									this.layoutexisting = this.partialduplicateLayouts
											.get(layoutcheck);

									this.partialDuplicate = true;
									this.layoutMatched = this.listofLayoutids
											.get(layoutcheck);
									this.partialduplicateLayoutsNew.add(duplicateCheck.getPartialDuplicateFieldsNewLayout());
									this.layoutnew = this.partialduplicateLayoutsNew.get(layoutcheck);
									
								}
							}

						}
					}

					if (count > 0) {
						this.partialDuplicate = true;
						this.validationComplete = false;
						message = "Similar Layout already exist in the system.Please Verify";
					}
					if (count > 1) {

						this.nextstatus = true;
					} else {
						this.nextstatus = false;
					}
				} else {
					message = "NEW";
				}
			} else {
				displayErrorMessageToUser(
						"Couldnot verify layouts.Please try again", "ERROR");
			}

		} else {
			message = verifySubLayouts();
		}

		return message;

	}
	
	@Override
	public void handleNext() {
		layoutcheck++;
		if (layoutcheck < this.partialduplicateLayouts.size()) {
			try {
				this.layoutexisting = this.partialduplicateLayouts
						.get(layoutcheck);
				this.layoutMatched = this.listofLayoutids.get(layoutcheck);
				this.layoutnew=this.partialduplicateLayoutsNew.get(layoutcheck);
			} catch (Exception ex) {
				log.error("Array Out Of Bounds.Handle Next()");
			}

		}

		if (layoutcheck == this.partialduplicateLayouts.size() - 1) {
			this.nextstatus = false;
		}
	}

	public String trimPositionInformation(String values) {
		CustomUtility objCU = new CustomUtility();

		String splitValues[] = values.split("~");
		String excelDatas[] = new String[splitValues.length - 1];

		for (int j = 1; j < splitValues.length; j++) {

			String line = splitValues[j].substring(0,
					splitValues[j].lastIndexOf(";"));
			line = line.substring(0, line.lastIndexOf(";"));
			line = line.substring(0, line.lastIndexOf(";"));

			excelDatas[j - 1] = line;

		}
		return objCU.convertArrayToString(excelDatas, 0).replaceAll("\"", "")
				.replaceAll(";", "").replaceAll(",,", "");

	}

	public String calculateLayoutDetail() {

		/*
		 * For fixed length : layout detail= max of End Pos : layout
		 * Detail=number of fields
		 */

		this.endPos = this.csvValues.substring(
				this.csvValues.lastIndexOf(";") + 1).replaceAll("\"", "");
		String splitValues[] = csvValues.split("~");
		if (layoutType.toLowerCase().startsWith("fixe")
				|| layoutType.toLowerCase().startsWith("subs")) {
			layoutDetail = this.endPos;
		} else {
			layoutDetail = String.valueOf((splitValues.length) - 1);
		}

		return layoutDetail;

	}

	public int getNumberofRows(String csvvalues, String delm) {
		int count = 0;
		count = csvvalues.split(delm).length - 1;
		return count;
	}

	public ArrayList<Layout> getListOfLayouts() {
		return listOfLayouts;
	}

	public void setListOfLayouts(ArrayList<Layout> listOfLayouts) {
		this.listOfLayouts = listOfLayouts;
	}

	public ArrayList<ArrayList<String>> generateCheck(String sublayoutID) {
		this.sublayoutid = sublayoutID;

		this.check = new ArrayList<>();
		setCsvValueshere(this.sublayoutid);
		return this.check;

	}

	public String verifySubLayouts() {
		String result = "NEW";
		try {
			ConnectDB db = new ConnectDB();
			CustomUtility objCU = new CustomUtility();

			String oldSubLayoutDetails = "";
			String newSubLayoutDetails = "";
			String query = "SELECT SUBLAYOUTID FROM IMP_SUB_LAYOUTS WHERE LAYOUTID='"
					+ this.layoutId
					+ "' and sublayoutid!='"
					+ this.sublayoutid
					+ "' GROUP BY SUBLAYOUTID";

			db.initialize();
			List<List<String>> listOfSubLayoutID = db
					.resultSetToListOfList(query);
			List<List<String>> listDetails;

			if (listOfSubLayoutID.size() > 1) {

				for (int i = 1; i < listOfSubLayoutID.size(); i++) {
					if (this.layoutType.compareTo("Fixed length") == 0) {
						log.info("FIXED LENGTH SUBLAYOUT CHECK");

						query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL||FIELDLENGTH ||STARTPOS||ENDPOS  "
								+ " FROM IMP_LAYOUTS_FIELDS "
								+ " WHERE LAYOUTID ='"
								+ this.layoutId
								+ "' AND SUBLAYOUTID='"
								+ listOfSubLayoutID.get(i).get(0)
								+ "' "
								+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";
						newSubLayoutDetails = objCU
								.convertArrayToString(csvValues.split("~"), 1)
								.replaceAll("\"", "").replaceAll(";", "")
								.replaceAll(",,", "");
					} else {
						log.info("DELIMITED SUBLAYOUT CHECK");
						query = "SELECT COLUMNNAME||DATATYPE||DATETYPEDETIAL AS FIELDDATA "
								+ " FROM IMP_LAYOUTS_FIELDS "
								+ " WHERE LAYOUTID ='"
								+ this.layoutId
								+ "' AND SUBLAYOUTID='"
								+ listOfSubLayoutID.get(i).get(0)
								+ "' "
								+ " ORDER BY LAYOUTID,SUBLAYOUTID,COLUMNID ";
						newSubLayoutDetails = trimPositionInformation(csvValues);

					}

					oldSubLayoutDetails = "";

					listDetails = db.resultSetToListOfList(query);
					if (listDetails.size() > 1) {
						for (int j = 1; j < listDetails.size(); j++) {
							oldSubLayoutDetails = oldSubLayoutDetails
									+ listDetails.get(j).get(0);
						}
					} else {
						result = "NEW";
						break;
					}

				
					if (oldSubLayoutDetails
							.equalsIgnoreCase(newSubLayoutDetails)) {
						result = "Exact Duplicate of SubLayoutID:"
								+ listOfSubLayoutID.get(i).get(0);
						break;
					}

				}
			} else {
				result = "NEW";
			}
			db.endConnection();
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("Cannot Verify Layout.Please Try Again",
					"Error");
			return "";
		}
		this.partialDuplicate = false;
		return result;

	}

	public String getSublayoutid() {
		return this.sublayoutid;
	}

	public String getEndPos() {
		return endPos;
	}

	public void setEndPos(String endPos) {
		this.endPos = endPos;
	}

	public void setSublayoutid(String sublayoutid) {
		this.sublayoutid = sublayoutid;
	}

	public ArrayList<String> getSublayoutids() {
		return sublayoutids;
	}

	public void setSublayoutids(ArrayList<String> sublayoutids) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select distinct(sublayoutid) from imp_sub_layouts where layoutid='"
				+ this.layoutId + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					sublayoutids.add(rs.get(i).get(0));
				}
			}
		}

		this.sublayoutids = sublayoutids;
	}

	public void deleteSubLayout() {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "Delete from imp_sub_layouts where layoutid='"
				+ this.layoutId + "' and sublayoutid='" + this.sublayoutid
				+ "'";
		
		db.executeDML(query);
		String query1 = "delete from imp_layouts_fields where layoutid='"
				+ this.layoutId + "' and sublayoutid='" + this.sublayoutid
				+ "'";
	
		db.executeDML(query1);
		db.endConnection();
		displayInfoMessageToUser("Sublayout deleted", "Sublayout Removed");
		this.sublayoutid = String
				.valueOf(Integer.parseInt(this.sublayoutid) - 1);

	}

	public void addToClipboard() {
		System.out.println("--Adding to clipboard--");
		String clipboardcontent = this.layoutId + "," + this.sublayoutid;
		this.sessionData.setClipboard(clipboardcontent);
		displayInfoMessageToUser("Sublayout Added to clipboard.",
				"Copy Sublayout");
	}

	public void changeSelectedSublayoutid() {
		try
		{
		getLayoutbySublayoutid(this.sublayoutid);
		}
		catch(Exception ex)
		{
			displayErrorMessageToUser("Sublayout not found.", "Error loading Sublayout");
			return;
		}
	}

	public void close() {
		RequestContext.getCurrentInstance().closeDialog("editLayout");
	}

	public void sendMail(String layoutid, String sublayoutid, String userLog) {
		log.info("--SENDING EMAIL TO --" + userLog);
		String to = "";
		if (userLog.compareTo(getUserinfo().getFullname()) != 0) {
			String query = "select email from aipd_users where fullname='"
					+ userLog + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();

			if (rs != null && rs.size() > 1) {

				to = rs.get(1).get(0);
			}
			String Content = "Dear " + userLog + ",\n"
					+ "Your Layout Has Been Modified .Please Verify.\n"
					+ "Layout Information : \n" + "Layout ID : " + layoutid
					+ ". \n" + "Sublayoutid :" + sublayoutid + ". \n"
					+ "Payor : " + getPayer() + ". \n" + "Modified Date : "
					+ new Date() + ". \n" + "Modified By : "
					+ getUserinfo().getFullname();

			EmailConfiguration emailobj = new EmailConfiguration();
			emailobj.setTo(to);
			ArrayList<String> ccList = new ArrayList<String>();
			ccList.add("Shekhar.Poudel@verscend.com");
			ccList.add("Nijel.Shrestha@verscend.com");
			//ccList.add("Anish.Rauniyar@verscend.com");

			emailobj.setCc(ccList);
			emailobj.setSubject("Layout Modified");
			emailobj.setContent(Content);
			int status = emailobj.sendMail();
			if (status == 1) {
				log.info("Email Sent");
			} else {
				log.info("Couldnot send email");
			}

		}

	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

}
