/* 
 *Class Name : AddPattern.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.controller;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.commons.model.PayerBean;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.flms.model.MClients;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for adding new pattern rule for a client
 * 
 * @author Aashish Dhungana
 * 
 * @Modified by Anish Rauniyar
 *
 * @version 21 July 2014
 */
@ManagedBean
@ViewScoped
public class AddPattern extends AbstractController implements Serializable {

	private static final long serialVersionUID = -8300448064013501765L;
	
	private Logger log = Logger.getLogger(AddPattern.class); 
	
	private LinkedHashMap<String, String> payers;
	private LinkedHashMap<String, String> clients;
	private LinkedHashMap<String, String> layouts;
	private LinkedHashMap<String, String> layoutTypes;
	private ArrayList<String> listofFileTypes;
	private ArrayList<String> employerGroups;
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String payer="";
	private String client="";
	private String layout;
	private String employerGroup;
	private String pattern = "";
	private String subLayoutDesc = "";
	private String remarks = "";
	private String transferType;
	private String ctlpattern = "";
	private LinkedHashMap<String, String> ctllayouts;
	private String skipRow = "";
	private String optEnc = "";
	private String ctllayout = "";
	private String delimiter = "";
	private String datetypedetail = "";
	private boolean disableDelimiterOverride = false;
	private boolean disableDateTypeDetailOverride = false;
	private String isOverriden = "N";
	private String oldSkprow = "";
	private String oldOptEnc = "";
	private String oldDelm = "";
	private String oldDatetypeDetail = "";
	
	private String ctlfirstString="";
	private String ctlsecondString="";
	private ArrayList<String> listofAppIds;
	private ArrayList<String> appidSelected = new ArrayList<>();
	private String interClientAppFlag ="N";
	private ArrayList<String> empgrpSelected = new ArrayList<>();
	
	private String ediPattern;
	private ArrayList<String> ediPatternValues = new ArrayList<String>();
	private String ediMapper;
	private ArrayList<String> ediMapperList = new ArrayList<String>();
	
	
	public String getEdiPattern() {
		return ediPattern;
	}


	public void setEdiPattern(String ediPattern) {
		this.ediPattern = ediPattern;
	}


	public ArrayList<String> getEdiPatternValues() {
		return ediPatternValues;
	}


	public void setEdiPatternValues(ArrayList<String> ediPatternValues) {
		this.ediPatternValues.add("Yes");
		this.ediPatternValues.add("No");
	}


	public String getEdiMapper() {
		return ediMapper;
	}


	public void setEdiMapper(String ediMapper) {
		this.ediMapper = ediMapper;
	}


	public ArrayList<String> getEdiMapperList() {
		return ediMapperList;
	}


	public void setEdiMapperList(ArrayList<String> ediMapperList) {
		String query = "SELECT DISTINCT edimapper FROM imp_edimapper";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {
				this.ediMapperList.add(rs.get(i).get(0));
			}
		}		
	}


	public ArrayList<String> getEmpgrpSelected() {
		return empgrpSelected;
	}


	public void setEmpgrpSelected(ArrayList<String> empgrpSelected) {
		this.empgrpSelected = empgrpSelected;
	}



	public ViewsParameters getSessionData() {
		return sessionData;
	}



	public String getCtlfirstString() {
		return ctlfirstString;
	}

	public void setCtlfirstString(String ctlfirstString) {
		this.ctlfirstString = ctlfirstString;
	}

	public String getCtlsecondString() {
		return ctlsecondString;
	}

	public void setCtlsecondString(String ctlsecondString) {
		this.ctlsecondString = ctlsecondString;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {
		this.payers = payers;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		this.clients = clients;
	}

	public LinkedHashMap<String, String> getLayouts() {
		return layouts;
	}

	public void setLayouts(LinkedHashMap<String, String> layouts) {
		this.layouts = layouts;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getDatetypedetail() {
		return datetypedetail;
	}

	public void setDatetypedetail(String datetypedetail) {
		this.datetypedetail = datetypedetail;
	}

	public LinkedHashMap<String, String> getLayoutTypes() {
		return layoutTypes;
	}

	public void setLayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		this.layoutTypes = layoutTypes;
	}

	public boolean isDisableDelimiterOverride() {
		return disableDelimiterOverride;
	}

	public void setDisableDelimiterOverride(boolean disableDelimiterOverride) {
		this.disableDelimiterOverride = disableDelimiterOverride;
	}

	public boolean isDisableDateTypeDetailOverride() {
		return disableDateTypeDetailOverride;
	}

	public void setDisableDateTypeDetailOverride(
			boolean disableDateTypeDetailOverride) {
		this.disableDateTypeDetailOverride = disableDateTypeDetailOverride;
	}

	public String isOverriden() {
		return isOverriden;
	}

	public void setOverriden(String isOverriden) {
		this.isOverriden = isOverriden;
	}

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getLayout() {
		return layout;
	}

	public void setLayout(String layout) {
		this.layout = layout;
	}

	public String getEmployerGroup() {
		return employerGroup;
	}

	public void setEmployerGroup(String employerGroup) {
		this.employerGroup = employerGroup;
	}

	public String getPattern() {
		this.pattern = this.sessionData.getValidpattern();
		return pattern;
	}

	public void setPattern(String pattern) {
		System.out.println("Pattern : " + pattern);
		this.pattern = pattern;
	}

	public String getSubLayoutDesc() {
		return subLayoutDesc;
	}

	public void setSubLayoutDesc(String subLayoutDesc) {
		this.subLayoutDesc = subLayoutDesc;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public ArrayList<String> getEmployerGroups() {
		return employerGroups;
	}

	public void setEmployerGroups(ArrayList<String> employerGroups) {
		this.employerGroups = employerGroups;
	}

	public String getCtlpattern() {
		/*this.ctlpattern = this.sessionData.getValidctlpattern();*/
		return ctlpattern;
	}

	public void setCtlpattern(String ctlpattern) {
		this.ctlpattern = ctlpattern;
	}

	public LinkedHashMap<String, String> getCtllayouts() {
		return ctllayouts;
	}

	public void setCtllayouts(LinkedHashMap<String, String> ctllayouts) {
		this.ctllayouts = ctllayouts;
	}

	public String getSkipRow() {
		return skipRow;
	}

	public String getCtllayout() {
		return ctllayout;
	}

	public void setCtllayout(String ctllayout) {
		this.ctllayout = ctllayout;
	}

	public void setSkipRow(String skipRow) {
		this.skipRow = skipRow;
	}

	public String getOptEnc() {
		return optEnc;
	}

	public void setOptEnc(String optEnc) {
		this.optEnc = optEnc;
	}

	public String getOldSkprow() {
		return oldSkprow;
	}

	public void setOldSkprow(String oldSkprow) {
		this.oldSkprow = oldSkprow;
	}

	public String getOldOptEnc() {
		return oldOptEnc;
	}

	public void setOldOptEnc(String oldOptEnc) {
		this.oldOptEnc = oldOptEnc;
	}

	public String getOldDelm() {
		return oldDelm;
	}

	public void setOldDelm(String oldDelm) {
		this.oldDelm = oldDelm;
	}

	public String getOldDatetypeDetail() {
		return oldDatetypeDetail;
	}

	public void setOldDatetypeDetail(String oldDatetypeDetail) {
		this.oldDatetypeDetail = oldDatetypeDetail;
	}

	public AddPattern() {
		

		LayoutType objLayoutType = new LayoutType();
		setLayoutTypes(objLayoutType.getlayoutTypes());

		MClients objMC = new MClients();
		clients = objMC.getClients();
		
		this.listofFileTypes = new ArrayList<>();
		setListofFileTypes(listofFileTypes);
		//Loadctllayouts();
		this.ediPatternValues = new ArrayList<String>();
		setEdiPatternValues(ediPatternValues);
		this.ediMapperList = new ArrayList<String>();
		setEdiMapperList(ediMapperList);
	}

	public void Loadctllayouts() {
		if (payer != null && payer != "") {
		String query = "SELECT distinct a.LAYOUTID,  a.DATATYPE, b.LAYOUTTYPE, b.LAYOUTDETAIL,a.payor FROM ("
				+ "  SELECT * FROM  IMP_LAYOUTS  WHERE datatype like '%Control Total%') A "
				+ " LEFT JOIN IMP_SUB_LAYOUTS B ON A.LAYOUTID=B.LAYOUTID " 
			
				+" where Upper(a.payor)='"+getPayer().split("~")[0]+"'";
			
		System.out.println("CTL lay"+query);		
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> layoutList = db.resultSetToListOfList(query);
		db.endConnection();

		ctllayouts = new LinkedHashMap<String, String>();
		if (layoutList.size() > 0) {
			for (int i = 1; i < layoutList.size(); i++) {
				ctllayouts.put(
						layoutList.get(i).get(4) + "-"
								+ layoutList.get(i).get(1) + "-"
								+ layoutList.get(i).get(2) + "-"
								+ layoutList.get(i).get(3) + "- LAYOUT ID("
								+ layoutList.get(i).get(0) + ")", layoutList
								.get(i).get(0));
			}
		}

		else {
			ctllayouts = new LinkedHashMap<String, String>();
		}
		}

	}

	public void handleClientChange() {

		//String query = "SELECT DISTINCT empname FROM imp_employer_master WHERE CLIENTID='" + getClient().split("-")[0] + "' order by 1";
		/*String query = "SELECT DISTINCT STANDARDEMPLOYERNAME from cpd.cp_clientemployerrelationship@"+AIConstant.CPD_LINK+" a left join cpd.cp_employermaster@"+AIConstant.CPD_LINK+" b ON a.STANDARDEMPLOYERID = b.STANDARDEMPLOYERID  WHERE a.STANDARDCLIENTID = '" +
						getClient().split("-")[0] + "' order by 1";*/
		String query = "SELECT DISTINCT STANDARDEMPLOYERNAME FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" WHERE STANDARDCLIENTID ='"+getClient().split("-")[0]+"' AND DELETED = 0 ";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> employeeList = db.resultSetToListOfList(query);
		db.endConnection();
		employerGroups = new ArrayList<String>();
		if (employeeList.size() > 0) {
			for (int i = 1; i < employeeList.size(); i++) {
				employerGroups.add(employeeList.get(i).get(0));

			}
			this.sessionData.setValidpattern("");
			/*this.sessionData.setValidctlpattern("");*/

		}
		db.endConnection();
		handleFlagChange();
	}
	
	

	public void handlePayerChange() {
		if (this.payer!=null && !this.payer.isEmpty() && this.subLayoutDesc!=null && !this.subLayoutDesc.isEmpty()) {
			
			System.out.println("filetype : " + this.subLayoutDesc);
			
			
			String query = "SELECT distinct LAYOUTID, DATATYPE, LAYOUTTYPE, LAYOUTDETAIL FROM AIP_DASHBOARD_PATTERN WHERE CATEGORY_NAME = '"+ this.subLayoutDesc+"' and payor='"+this.payer+"' and  layout_status!='WORKING' and activeflag='Y' order by layoutid";
		
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> layoutList = db.resultSetToListOfList(query);
				db.endConnection();

				layouts = new LinkedHashMap<String, String>();
				if (layoutList.size() > 0) {
					for (int i = 1; i < layoutList.size(); i++) {
						layouts.put(
								 layoutList.get(i).get(0) + "-" + layoutList.get(i).get(1) + "-"
								+ layoutList.get(i).get(2) + "-"
								+ layoutList.get(i).get(3), layoutList
								.get(i).get(0));
					}
				
			
			}
			
		}

		else {
			layouts = new LinkedHashMap<String, String>();
			displayInfoMessageToUser("File Type couldn't be empty.", "Please select file type");
		}

	}

	public void add() {

		if (this.subLayoutDesc.compareTo("CONTROLTOTAL") == 0) {
			this.isOverriden = "N";
			this.skipRow = "";
			this.delimiter = "";
			this.datetypedetail = "";
			this.optEnc = "";
		} else {

			if (oldSkprow.compareTo(this.skipRow) != 0
					|| oldOptEnc.compareTo(this.optEnc) != 0
					|| oldDelm.compareTo(this.delimiter) != 0
					|| oldDatetypeDetail.compareTo(this.datetypedetail) != 0) {
			
				this.isOverriden = "Y";
				if (!isSkipChanged()) {
					this.skipRow = "";
				}
				if (!isDelmChanged()) {
					this.delimiter = "";
				}
				if (!isOptChanged()) {
					this.optEnc = "";
				}
				if (!isDateChanged()) {
					this.datetypedetail = "";
				}
			} else {
				this.isOverriden = "N";
			}

		}
		if(this.isOverriden.compareTo("N")==0)
		{
			this.skipRow="";
			this.optEnc="";
			this.delimiter= "";
			this.datetypedetail = "";
		}
		
		if(this.ctlfirstString == null){this.ctlfirstString="";}
		if(this.ctlsecondString==null){this.ctlsecondString="";}
		log.info("EDI Flag: " + ediPattern + " EDI Mapper: " + ediMapper);
		if(this.ediPattern == null || this.ediPattern.equals("No") || this.ediPattern.isEmpty()) {
			this.ediPattern = "N";
			this.ediMapper = "";
		} else {
			this.ediPattern = "Y";
		}
		log.info("EDI Flag: " + ediPattern + " EDI Mapper: " + ediMapper);
		String empgrpPattern = makeEmpPattern().replaceAll("\'", "\''");

		/*String query = "INSERT INTO IMP_CLIENTPATTERNS(SN,CLIENTID, PATTERN, LAYOUTID, "
				+ " EMPLOYERGROUP, ADDEDDATE, REMARKS,FILETYPE,USERLOG,TRANSFERTYPE,SKIPROWS,OPTIONALLY,DELIMITER,OVERRIDDENDATE,ISOVERRIDDEN, CTL_FIRST_STRING,CTL_SECOND_STRING,INTERCLIENTAPPFLAG) "
				+ " SELECT (SELECT MAX(SN)+1 FROM IMP_CLIENTPATTERNS),'"
				+ client
				+ "','"
				+ pattern.replaceAll("\'", "\''")
				+ "', "
				+ " '"
				+ layout
				+ "', a.STANDARDEMPLOYERID"
				+ "', "
				+ " SYSDATE,'"
				+ remarks
				+ "','"
				+ subLayoutDesc
				+ "','"
				+ getUserinfo().getFullname()
				+ "','"
				+ transferType
				+ "','"
				+ this.skipRow
				+ "','"
				+ this.optEnc
				
				+ "','"
				+ this.delimiter
				+ "','"
				+ this.datetypedetail + "','" + this.isOverriden + "','"+
				(this.ctlfirstString.isEmpty()?this.ctlfirstString : this.ctlfirstString.replaceAll("\'", "\'\'"))+"','"+ 
				(this.ctlsecondString.isEmpty() ? this.ctlsecondString : this.ctlsecondString.replaceAll("\'", "\'\'"))+"','"+this.interClientAppFlag+"' FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" a WHERE STANDARDEMPLOYERNAME ='" 
				+ employerGroup.replaceAll("\'", "\'\'") + "'"; */
		
		String query = "INSERT INTO IMP_CLIENTPATTERNS(SN,CLIENTID, PATTERN, LAYOUTID, "
				+ " EMPLOYERGROUP, ADDEDDATE, REMARKS,FILETYPE,USERLOG,TRANSFERTYPE,SKIPROWS,OPTIONALLY,EDIFLAG,EDIMAPPER,DELIMITER,OVERRIDDENDATE,ISOVERRIDDEN, CTL_FIRST_STRING,CTL_SECOND_STRING,INTERCLIENTAPPFLAG) "
				+ " VALUES ((SELECT MAX(SN)+1 FROM IMP_CLIENTPATTERNS),'"
				+ client
				+ "','"
				+ pattern.replaceAll("\'", "\''")
				+ "', "
				+ " '"
				+ layout
				+ "', '"
				+ empgrpPattern
				+ "', "
				+ " SYSDATE,'"
				+ remarks
				+ "','"
				+ subLayoutDesc
				+ "','"
				+ getUserinfo().getFullname()
				+ "','"
				+ transferType
				+ "','"
				+ this.skipRow
				+ "','"
				+ this.optEnc				
				+ "','"
				+ this.ediPattern
				+ "','"
				+ this.ediMapper
				+ "','"
				+ this.delimiter
				+ "','"
				+ this.datetypedetail + "','" + this.isOverriden + "','"+
				(this.ctlfirstString.isEmpty()?this.ctlfirstString : this.ctlfirstString.replaceAll("\'", "\'\'"))+"','"+ 
				(this.ctlsecondString.isEmpty() ? this.ctlsecondString : this.ctlsecondString.replaceAll("\'", "\'\'"))+"','"+this.interClientAppFlag+"')"; 
		
		/*String query = "INSERT INTO IMP_CLIENTPATTERNS(SN,CLIENTID, PATTERN, LAYOUTID, "
				+ " EMPLOYERGROUP, ADDEDDATE, REMARKS,FILETYPE,USERLOG,TRANSFERTYPE,SKIPROWS,OPTIONALLY,DELIMITER,OVERRIDDENDATE,ISOVERRIDDEN, CTL_FIRST_STRING,CTL_SECOND_STRING,INTERCLIENTAPPFLAG) "
				+ " VALUES ((SELECT MAX(SN)+1 FROM IMP_CLIENTPATTERNS),'"
				+ client
				+ "','"
				+ pattern.replaceAll("\'", "\''")
				+ "', "
				+ " '"
				+ layout
				+ "', '"
				+ empgrpPattern
				+ "', "
				+ " SYSDATE,'"
				+ remarks
				+ "','"
				+ subLayoutDesc
				+ "','"
				+ getUserinfo().getFullname()
				+ "','"
				+ transferType
				+ "','"
				+ this.skipRow
				+ "','"
				+ this.optEnc
				
				+ "','"
				+ this.delimiter
				+ "','"
				+ this.datetypedetail + "','" + this.isOverriden + "','"+
				(this.ctlfirstString.isEmpty()?this.ctlfirstString : this.ctlfirstString.replaceAll("\'", "\'\'"))+"','"+ 
				(this.ctlsecondString.isEmpty() ? this.ctlsecondString : this.ctlsecondString.replaceAll("\'", "\'\'"))+"','"+this.interClientAppFlag+"')";*/
		
		String pattern_main = "INSERT INTO imp_clientpatterns_emp_main  (sn,PATTERNSN,PATTERNSHORTNAME,USERNAME,CREATEDDATE) " 
							+ " VALUES ('1', (SELECT Max(sn) FROM imp_clientpatterns), '"
							+ empgrpPattern + "', '"
							+ getUserinfo().getFullname() + "', SYSDATE)";
		
		
								
		/*String query = "INSERT INTO IMP_CLIENTPATTERNS(SN,CLIENTID, PATTERN, LAYOUTID, "
				+ " EMPLOYERGROUP, ADDEDDATE, REMARKS,FILETYPE,USERLOG,TRANSFERTYPE,SKIPROWS,OPTIONALLY,DELIMITER,OVERRIDDENDATE,ISOVERRIDDEN, CTL_FIRST_STRING,CTL_SECOND_STRING,INTERCLIENTAPPFLAG) "
				+ " VALUES((SELECT MAX(SN)+1 FROM IMP_CLIENTPATTERNS),'"
				+ client
				+ "','"
				+ pattern.replaceAll("\'", "\''")
				+ "', "
				+ " '"
				+ layout
				+ "',  '"
				+ employerGroup.replaceAll("\'", "\'\'")
				+ "', "
				+ " SYSDATE,'"
				+ remarks
				+ "','"
				+ subLayoutDesc
				+ "','"
				+ getUserinfo().getFullname()
				+ "','"
				+ transferType
				+ "','"
				+ this.skipRow
				+ "','"
				+ this.optEnc
				
				+ "','"
				+ this.delimiter
				+ "','"
				+ this.datetypedetail + "','" + this.isOverriden + "','"+(this.ctlfirstString.isEmpty()?this.ctlfirstString : this.ctlfirstString.replaceAll("\'", "\'\'"))+"','"+ (this.ctlsecondString.isEmpty() ? this.ctlsecondString : this.ctlsecondString.replaceAll("\'", "\'\'"))+"','"+this.interClientAppFlag+"')";
		*/
		ConnectDB db = new ConnectDB();
		db.initialize();
		try {
			
			if (this.pattern.compareTo("") != 0) {
				log.info("Date inserting in the pattern........ : " + query);
				String patternResult = db.executeDML(query);
				log.info("Date inserted in the pattern.");
				if (patternResult.compareTo("1") == 0) {
					log.info("Date inserting in the pattern main........ : " + pattern_main);
					String patternMain = db.executeDML(pattern_main);
					log.info("Date inserted in the pattern main.");
					if (patternMain.compareTo("1") == 0) {
						for (int i = 0; i<empgrpSelected.size();i++) {
							String pattern_detail = "INSERT INTO imp_clientpatterns_emp_detail (sn,mainsn,empgrp,empid) "
									+ "VALUES ('1', (SELECT Max(sn) FROM imp_clientpatterns_emp_main), '" 
									+ empgrpSelected.get(i).replaceAll("\'", "\''") + "', (SELECT STANDARDEMPLOYERID FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" WHERE STANDARDEMPLOYERNAME='"
									+ empgrpSelected.get(i).replaceAll("\'", "\''") + "' ))";
							log.info("Date inserting in the pattern main detail........ : " + pattern_detail);
							db.executeDML(pattern_detail);
							log.info("Date inserting in the pattern main.");
						}
					}
				}
				String sn = "";
				String queryFornewSn = "select max(sn) from imp_clientpatterns where userlog ='" + getUserinfo().getFullname() + "'";
				List<List<String>> rs = db.resultSetToListOfList(queryFornewSn);
				sn = rs.get(1).get(0);
				insertAppIDInformation(sn,db);
				
				this.sessionData.setNewAdditionComplete(true);
			} else {
				displayErrorMessageToUser("Pattern cannot be empty", "ERROR");
			}
		} catch (Exception ex) {
			displayErrorMessageToUser("Insert Failed", "ERROR");
			return;
		}
		db.endConnection();

		if (this.pattern.compareTo("") != 0) {

			RequestContext.getCurrentInstance().execute(
					"parent.PF('dlg').hide();");
		}
		reset();
		this.sessionData.setValidpattern("");
		//this.sessionData.setValidctlpattern("");
	}
	
	
	private String makeEmpPattern() {
		// TODO Auto-generated method stub
		String empPattern = "_";
		if (empgrpSelected.size() > 0) {
			for (int i = 0; i < empgrpSelected.size(); i++) {
				/*String query = "SELECT empshortname from imp_employer_master where empname = '" + this.empgrpSelected.get(i) + "'";
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> empshortname = db.resultSetToListOfList(query);
				db.endConnection();*/

					empPattern = empPattern + empgrpSelected.get(i).substring(0, 3) + "_";
			
			}
		}
		
		return empPattern;
	}



	public void insertAppIDInformation(String sn, ConnectDB db)
	{
		for(int i=0;i<this.appidSelected.size();i++)
		{
		String query = "Insert into imp_pattern_appid_reln(patternid, appid, created_date, created_by) values('"+sn+"','"+this.appidSelected.get(i) + "', sysdate , '" + this.userinfo.getFullname() + "')";
		System.out.println(query);
		db.executeDML(query);
		}
	}

	public void reset() {
		this.payer = "";
		this.client = "";
		this.layouts = null;
		this.layout = "";
		this.employerGroup = "";
		this.pattern = "";
		this.subLayoutDesc = "";
		this.remarks = "";
		this.transferType = "";
	}

	public void handleLayoutChange() {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT OPTIONALLY,SKIPROW FROM imp_layouts WHERE layoutid='"
				+ this.layout + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null && rs.size() > 1) {
			setSkipRow(rs.get(1).get(1));
			setOldSkprow(rs.get(1).get(1));
			setOptEnc(rs.get(1).get(0));
			setOldOptEnc(rs.get(1).get(0));
		}
		getOtherParameters();

	}
	
	public void handleFileTypeChange()
	{
		this.payers = new LinkedHashMap<>();
		String query = "SELECT Upper(Payor), Count(*) FROM aip_dashboard_pattern where category_name='"+this.subLayoutDesc + "'"
				+ " GROUP BY Upper(payor) ORDER BY upper(PAYOR)";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> payerList = db.resultSetToListOfList(query);
		db.endConnection();

		if (payerList.size() > 0) {
			for (int i = 1; i < payerList.size(); i++) {
				payers.put(payerList.get(i).get(0) + " ("
						+ payerList.get(i).get(1) + ")", payerList.get(i)
						.get(0));
			}
		}

	if(!this.payer.isEmpty() || this.payer.compareTo("")!=0)
	{
		handlePayerChange();
	}
	}

	/**
	 *  Returns the override parameters for the layout 
	 */
	public void getOtherParameters() {
		String query = "SELECT DISTINCT(LAYOUTTYPE) FROM imp_sub_layouts WHERE layoutid='"
				+ this.layout + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		if (rs != null) {
			if (rs.size() > 1) {
				if (rs.size() > 2) {
					this.disableDelimiterOverride = true;
				} else {
					this.disableDelimiterOverride = false;
					this.delimiter = rs.get(1).get(0);
					this.oldDelm = rs.get(1).get(0);
					System.out.println(this.delimiter);
					if (this.delimiter.compareTo("Fixed length") == 0) {
						this.disableDelimiterOverride = true;
					} else {
						this.oldDelm = rs.get(1).get(0);
						this.disableDateTypeDetailOverride = false;
					}
				}
			} else {
				this.disableDelimiterOverride = true;
			}
		} else {
			this.disableDelimiterOverride = true;
		}

		String query1 = "SELECT DISTINCT(datetypedetial) FROM imp_layouts_fields WHERE layoutid='"
				+ this.layout + "' AND datetypedetial IS NOT null";

		List<List<String>> rs1 = db.resultSetToListOfList(query1);
		System.out.println(rs1.size());
		if (rs1 != null) {
			if (rs1.size() > 1) {
				if (rs1.size() > 2) {
					this.disableDateTypeDetailOverride = true;
				} else {
					this.datetypedetail = rs1.get(1).get(0);
					System.out.println("CHECKING>>>>");
					this.oldDatetypeDetail = rs1.get(1).get(0);
					this.disableDateTypeDetailOverride = false;
				}
			} else {
				this.disableDateTypeDetailOverride = false;
			}
		}

		System.out.println(this.disableDateTypeDetailOverride);
		db.endConnection();

	}

	public boolean isOptChanged() {
		System.out.println("OLD : " + this.oldOptEnc + " NEW : " + this.optEnc);

		System.out.println(this.oldOptEnc.trim().compareTo(this.optEnc.trim()));
		if (this.oldOptEnc.compareTo(this.optEnc) == 0) {
			return false;
		} else {
			return true;
		}
	}

	public boolean isDelmChanged() {
		if (this.oldDelm.compareTo(this.delimiter) == 0) {
			return false;
		} else {
			return true;
		}
	}

	public boolean isSkipChanged() {
		if (this.oldSkprow.compareTo(this.skipRow) == 0) {
			return false;
		} else {
			return true;
		}
	}

	public boolean isDateChanged() {

		if (this.oldDatetypeDetail.compareTo(this.datetypedetail) == 0) {
			return false;
		} else {
			return true;
		}

	}



	public ArrayList<String> getListofFileTypes() {
		return listofFileTypes;
	}



	public void setListofFileTypes(ArrayList<String> listofFileTypes) {
		
		ConnectDB db =new ConnectDB();
		db.initialize();
		String query = "select distinct category_name from aip_dashboard_pattern";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
				this.listofFileTypes.add(rs.get(i).get(0));
				}
			}
		}
		this.listofFileTypes = listofFileTypes;
	}



	public ArrayList<String> getListofAppIds() {
		return listofAppIds;
	}



	public void setListofAppIds(ArrayList<String> listofAppIds) {
		this.listofAppIds = listofAppIds;
	}



	public String getInterClientAppFlag() {
		return interClientAppFlag;
	}



	public void setInterClientAppFlag(String interClientAppFlag) {
		this.interClientAppFlag = interClientAppFlag;
	}

	
	public void handleFlagChange()
	{
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query ="";
		this.listofAppIds = new ArrayList<>();
		
		if(this.interClientAppFlag.compareTo("N")==0)
		{
			//query = "select distinct applicationid from cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" where legacyclientid = '"+this.client+"'";
			query = "SELECT distinct a.applicationid FROM cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" a left JOIN cpd.cp_clientstandardization@"+AIConstant.CPD_LINK+" b ON a.LEGACYCLIENTID = b.LEGACYCLIENTID WHERE b.STANDARDCLIENTID = '"+this.client+"'";
		}
		else
		{
			query = "select distinct applicationid from cpd.cp_clientapplication@"+AIConstant.CPD_LINK;
		}
		
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		log.info("App Id query is: " + query);				
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					this.listofAppIds.add(rs.get(i).get(0));
				}
			}
		}
		
	}



	public ArrayList<String> getAppidSelected() {
		return appidSelected;
	}



	public void setAppidSelected(ArrayList<String> appidSelected) {
		this.appidSelected = appidSelected;
	}
}
