/* 
 *Class Name : ControlTotal.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;

/**
 * Model Class for Control Total Layout
 * 
 * @author Aashish Dhungana
 *
 * @version 1.0 17 Sep 2014
 */
@ManagedBean
public class ControlTotal implements Serializable {

	private static final long serialVersionUID = -1753797330934765660L;
	private String formattype;
	private String columnname;
	private int index = 0;
	private String layouttype;
	private int colno = 0;
	private String position;
	private String dateFormat;
	private String datatype;

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDateFormat() {
		return dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getLayouttype() {
		return layouttype;
	}

	public void setLayouttype(String layouttype) {
		this.layouttype = layouttype;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getColumnname() {
		return columnname;
	}

	public void setColumnname(String columnname) {
		this.columnname = columnname;
	}

	public String getFormattype() {
		return formattype;
	}

	public void setFormattype(String formattype) {
		this.formattype = formattype;
	}

	/* Constructor for horizontal */
	public ControlTotal(String formattype, String fieldname, int colno,
			int index, String layouttype, String position, String dateFormat) {
		this.formattype = formattype;
		this.columnname = fieldname;
		this.layouttype = layouttype;
		this.position = position;
		this.dateFormat = dateFormat;
		this.colno = colno;
		this.index = index;
	}

	/* Constructor for Vertical */
	public ControlTotal(String formattype, String fieldname, int colno,
			String layouttype, String position, String dateFormat) {
		this.formattype = formattype;
		this.columnname = fieldname;
		this.layouttype = layouttype;
		this.position = position;
		this.dateFormat = dateFormat;
		this.colno = colno;
		this.index = 0;
	}

	public ControlTotal() {
	}

	public int getColno() {
		return colno;
	}

	public void setColno(int colno) {
		this.colno = colno;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

}
