/* 
 *Class Name : StatsCheck.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;

/**
 * @author Sagar Shrestha
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 10 Dec 2014
 */
public class StatsCheck implements Serializable {

	private static final long serialVersionUID = 2548158465508633196L;
	private String layoutID = "";
	private String subLayoutID = "";
	private String columnID = "";
	private String columnName = "";
	private String dataType = "";
	private String dateTypeDetail = "";
	private String fieldLength = "";
	private String sn = "";
	private String statsFunction = "";
	private String frm_layoutid = "";

	public StatsCheck(String layoutID, String subLayoutID, String columnID,
			String columnName, String dataType, String dateTypeDeatil,
			String fieldLength, String sn, String statsFunction,
			String frm_layoutid) {
		super();

		this.layoutID = layoutID;
		this.subLayoutID = subLayoutID;
		this.columnID = columnID;
		this.columnName = columnName;
		this.dataType = dataType;
		this.dateTypeDetail = dateTypeDeatil;
		this.fieldLength = fieldLength;
		this.sn = sn;
		this.statsFunction = statsFunction;
		this.frm_layoutid = frm_layoutid;

	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getSubLayoutID() {
		return subLayoutID;
	}

	public void setSubLayoutID(String subLayoutID) {
		this.subLayoutID = subLayoutID;
	}

	public String getColumnID() {
		return columnID;
	}

	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDateTypeDetail() {
		return dateTypeDetail;
	}

	public void setDateTypeDetail(String dateTypeDeatil) {
		this.dateTypeDetail = dateTypeDeatil;
	}

	public String getFieldLength() {
		return fieldLength;
	}

	public void setFieldLength(String fieldLength) {
		this.fieldLength = fieldLength;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getFrm_layoutid() {
		return frm_layoutid;
	}

	public void setFrm_layoutid(String frm_layoutid) {
		this.frm_layoutid = frm_layoutid;
	}

	public String getStatsFunction() {
		return statsFunction;
	}

	public void setStatsFunction(String statsFunction) {
		this.statsFunction = statsFunction;
	}
}
