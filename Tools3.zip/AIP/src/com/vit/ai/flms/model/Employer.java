/*
 *Class Name : Employer.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.flms.model;

/**
 * Model Class for Employer
 * 
 * @author Binesh Sah
 *
 * @version 1.0 24 Jun 2014
 */
public class Employer {

	String clientid;
	String empgrpname;
	String shortname;
	String createddate;

	String createdby;
	private String oldempgroupname;

	public Employer() {

	}

	public Employer(String clientid, String shortname, String empgroupname,
			String oldempgroupname, String createddate, String createdby) {
		this.clientid = clientid;
		this.shortname = shortname;
		this.empgrpname = empgroupname;
		this.oldempgroupname = this.empgrpname;
		this.createddate = createddate;
		this.createdby = createdby;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getEmpgrpname() {
		return empgrpname;
	}

	public void setEmpgrpname(String empgrpname) {
		this.empgrpname = empgrpname;
	}

	public String getOldempgroupname() {
		return oldempgroupname;
	}

	public void setOldempgroupname(String oldempgroupname) {
		this.oldempgroupname = oldempgroupname;
	}

	public String getShortname() {
		return shortname;
	}

	public void setShortname(String shortname) {
		this.shortname = shortname;
	}

	public String getCreateddate() {
		return createddate;
	}

	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

}
