/* 
 *Class Name : PartialDuplicateModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 10 Oct 2014
 */
public class PartialDuplicateModel implements Serializable {
	
	private static final long serialVersionUID = -4016451058175818223L;
	private String columnId;
	private String columnName;
	private String dataType;
	private String datetypeDetail;
	private String start;
	private String end;

	public String getColumnId() {
		return columnId;
	}

	public void setColumnId(String columnId) {
		this.columnId = columnId;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDatetypeDetail() {
		return datetypeDetail;
	}

	public void setDatetypeDetail(String datetypeDetail) {
		this.datetypeDetail = datetypeDetail;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public PartialDuplicateModel(String columnId, String columnName,
			String dataType, String datetypeDetail, String start, String end) {
		// super();
		this.columnId = columnId;
		this.columnName = columnName;
		this.dataType = dataType;
		this.datetypeDetail = datetypeDetail;
		this.start = start;
		this.end = end;
	}

}
