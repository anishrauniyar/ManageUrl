/* 
 *Class Name : Layout.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;
import java.util.List;
import org.tmatesoft.svn.core.io.SVNRepository;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;
import com.vit.ai.remoteConnection.ProcessBuilderRunner;
import com.vit.ai.svnconnection.ConnecttoSVN;

/**
 * Model class for data layout
 * 
 * @author Aashish Dhungana
 * @author Binesh Sah
 * 
 * @version 1.0 07 Jun 2014
 */
public class Layout extends AbstractController implements Serializable {

	private static final long serialVersionUID = -4379386152265508244L;
	private String prevlayoutID;
	private String layoutID;
	private String payor;
	private String dataType;
	private String punchCharFlag;
	private String optionallyEnclosedFlag;
	private String skipRow;
	private String numOfChild;
	private String subLayoutID;
	private String layoutType;
	private String layoutDetail;
	private String whereClause;
	private String numOfLayout;
	private String trailerSkip;
	private String payorID;
	private String layoutDesc;
	private String sourceInfo;
	private String subLayoutDesc;
	private String numOfFields;
	private String trailerSkipCondition;
	private String activeFlag;
	private boolean selectable;
	private String userlog;
	private boolean layoutWarn = true;
	private boolean uploadWarn = true;
	private boolean checkinWarn = true;
	private boolean dsrmapWarn = true;
	private String ctltype;
	private String manualFlag;
	private boolean manualoverride = false;
	private String layoutstatus;
	private String importedtablename;
	private String effectivedate;
	private String modifieddate;
	private String verified;
	private String characterSet;
	private String icd10Flag;
	private String datadictionaryuploaded="";
	private String sumflag="";
	private String trailerflag="";

	public String getUserlog() {
		return userlog;
	}

	public void setUserlog(String userlog) {
		this.userlog = userlog;
	}

	public boolean isSelectable() {
		if (this.activeFlag.compareTo("N") == 0) {
			this.selectable = true;
		} else {
			this.selectable = false;
		}
		return selectable;
	}

	public void setSelectable(boolean selectable) {
		this.selectable = selectable;
	}

	public Layout() {
	}

	public Layout(String prevLayoutID, String layoutID, String payor,
			String dataType, String punchCharFlag,
			String optionallyEnclosedFlag, String skipRow, String numOfChild,
			String subLayoutID, String layoutType, String layoutDetail,
			String whereClause, String numOfLayout, String trailerSkip,
			String payorID, String layoutDesc, String sourceInfo,
			String subLayoutDesc, String numOfFields,
			String trailerSkipCondition, String activeFlag, String userlog,
			String ctltype, String manualflag, String layoutstatus,
			String verified,String characterSet,String icd10flag,String datadictionaryuploaded,String sumflag, String trailerflag) {
		this.prevlayoutID = prevLayoutID;
		this.layoutID = layoutID;
		this.payor = payor;
		this.dataType = dataType;
		this.punchCharFlag = punchCharFlag;
		this.optionallyEnclosedFlag = optionallyEnclosedFlag;
		this.skipRow = skipRow;
		this.numOfChild = numOfChild;
		this.subLayoutID = subLayoutID;
		this.layoutType = layoutType;
		this.layoutDetail = layoutDetail;
		this.whereClause = whereClause;
		this.numOfLayout = numOfLayout;
		this.trailerSkip = trailerSkip;
		this.payorID = payorID;
		this.layoutDesc = layoutDesc;
		this.sourceInfo = sourceInfo;
		this.subLayoutDesc = subLayoutDesc;
		this.setNumOfFields(numOfFields);
		this.trailerSkipCondition = trailerSkipCondition;
		this.activeFlag = activeFlag;
		this.userlog = userlog;
		this.ctltype = ctltype;
		this.manualFlag = manualflag;
		this.layoutstatus = layoutstatus;
		this.verified = verified;
		this.characterSet=characterSet;
		this.icd10Flag=icd10flag;
		this.datadictionaryuploaded = datadictionaryuploaded;
		this.sumflag = sumflag;
		this.trailerflag = trailerflag;
		this.importedtablename = "AI_" + this.layoutID + "_" + this.subLayoutID
				+ "_" + getShortPayor(this.payor);
		checkEffectiveDate();

		checkpending(layoutID);

	}

	public void checkEffectiveDate() {
		this.effectivedate = "";
		this.modifieddate = "";
		String query = "select from_date from imp_svn_checkin where layoutid='"
				+ this.layoutID + "' order by from_date asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				this.effectivedate = rs.get(1).get(0);

				this.modifieddate = rs.get(rs.size() - 1).get(0);
			}
		}

	}

	public String getShortPayor(String payorname) {

		String shrtpayor = "";
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select distinct(SHORTPAYOR) from imp_layouts where UPPER(payor)='"
				+ payorname.toUpperCase() + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				shrtpayor = rs.get(1).get(0);
			}
		}

		return shrtpayor;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getPunchCharFlag() {
		return punchCharFlag;
	}

	public void setPunchCharFlag(String punchCharFlag) {
		this.punchCharFlag = punchCharFlag;
	}

	public String getOptionallyEnclosedFlag() {
		return optionallyEnclosedFlag;
	}

	public void setOptionallyEnclosedFlag(String optionallyEnclosedFlag) {
		this.optionallyEnclosedFlag = optionallyEnclosedFlag;
	}

	public String getSkipRow() {
		return skipRow;
	}

	public void setSkipRow(String skipRow) {
		this.skipRow = skipRow;
	}

	public String getNumOfChild() {
		return numOfChild;
	}

	public void setNumOfChild(String numOfChild) {
		this.numOfChild = numOfChild;
	}

	public String getSubLayoutID() {
		return subLayoutID;
	}

	public void setSubLayoutID(String subLayoutID) {
		this.subLayoutID = subLayoutID;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getLayoutDetail() {
		return layoutDetail;
	}

	public void setLayoutDetail(String layoutDetail) {
		this.layoutDetail = layoutDetail;
	}

	public String getWhereClause() {
		return whereClause;
	}

	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}

	public String getNumOfLayout() {
		return numOfLayout;
	}

	public void setNumOfLayout(String numOfLayout) {
		this.numOfLayout = numOfLayout;
	}

	public String getTrailerSkip() {
		return trailerSkip;
	}

	public void setTrailerSkip(String trailerSkip) {
		this.trailerSkip = trailerSkip;
	}

	public String getPayorID() {
		return payorID;
	}

	public void setPayorID(String payorID) {
		this.payorID = payorID;
	}

	public String getLayoutDesc() {
		return layoutDesc;
	}

	public void setLayoutDesc(String layoutDesc) {
		this.layoutDesc = layoutDesc;
	}

	public String getSourceInfo() {
		return sourceInfo;
	}

	public void setSourceInfo(String sourceInfo) {
		this.sourceInfo = sourceInfo;
	}

	public String getSubLayoutDesc() {
		return subLayoutDesc;
	}

	public void setSubLayoutDesc(String subLayoutDesc) {
		this.subLayoutDesc = subLayoutDesc;
	}

	public String getPrevlayoutID() {
		return prevlayoutID;
	}

	public void setPrevlayoutID(String prevlayoutID) {
		this.prevlayoutID = prevlayoutID;
	}

	public String getNumOfFields() {
		return numOfFields;
	}

	public void setNumOfFields(String numOfFields) {
		this.numOfFields = numOfFields;
	}

	public String getTrailerSkipCondition() {
		return trailerSkipCondition;
	}

	public void setTrailerSkipCondition(String trailerSkipCondition) {
		this.trailerSkipCondition = trailerSkipCondition;
	}

	public String getActiveFlag() {
		return activeFlag;

	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public int ConditionalCheck() {
		int count = 0;
		int sizeofActiveClients = 0;
		String query = "select distinct CLIENTID from imp_clientpatterns where LAYOUTID='"
				+ this.layoutID + "' or ctl_layoutid='" + this.layoutID + "'";
		ConnectDB db=new ConnectDB();
		db.initialize();
		List<List<String>> rs= db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				count=rs.size()-1;
			}
		}
		
		
		sizeofActiveClients = count;

		return sizeofActiveClients;
	}

	/*
	 * public void saveScript(String layoutid) {
	 * 
	 * //GenerateImportScript objGIS = new GenerateImportScript(); String
	 * importScript = ProcessBuilderRunner.runImportScript(layoutid,"N");
	 * 
	 * String importScriptPath = AIConstant.IMPORT_SCRIPT_DUMP_LOCATION_SERVER;
	 * RemoteTerminal objRT = new RemoteTerminal(AIConstant.DEFAULT_SERVER_IP);
	 * String command =
	 * "cd \""+importScriptPath+"\"; cat > IP_"+layoutid+".sql <<EOF\n"
	 * +importScript+"\nEOF"; String result = objRT.runCommand(command); command
	 * = "cd \""+importScriptPath+"\"; chmod 777 IP_"+layoutid+".sql ";
	 * objRT.runCommand(command); objRT.disconnectSSH();
	 * 
	 * if(result.equalsIgnoreCase("notconnected")) {
	 * displayErrorMessageToUser("Script cannot be saved.", "Save Script"); }
	 * else { displayInfoMessageToUser("Script saved at "+importScriptPath,
	 * "Save Script"); }
	 * 
	 * }
	 */

	public void checkinScript(String layoutid, String userid) {

		if (this.getDataType().compareTo("Control Total") == 0) {
			this.checkinCattr(this.getLayoutID(), userid);
		} else {

			String importScript = "";
			String attr = "";
			String cattr = "";

			importScript = ProcessBuilderRunner.runImportScript(layoutid, "N");
			attr = ProcessBuilderRunner.runAttr(layoutid);
			cattr = ProcessBuilderRunner.runCAttr(layoutid);
			ConnecttoSVN conn = new ConnecttoSVN();
			SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
			if (this.manualFlag.compareTo("N") == 0) {

				try {
					if (importScript.isEmpty() || importScript == null
							|| importScript.compareTo("ERROR") == 0) {
						System.out.println("IMPORT SCRIPT :  " + importScript);

					} else {
						conn.committoSVNwithfile(repos, AIConstant.SVNSQL_PATH,
								"IP_" + layoutid + ".sql", importScript);
						displayInfoMessageToUser("IP_" + layoutid
								+ ".sql checked in successfully", "SVN-CheckIn");
						conn.SVNPopulatedb(layoutID, "Import", "IP_" + layoutID
								+ ".sql", userid);

					}
				} catch (Exception e) {

					displayInfoMessageToUser(
							"SVN Checkin-Falied.Please try again ",
							"SVN-CheckIn");
				}
			} else {
				displayErrorMessageToUser(
						"Manual Flag is set.Could not Checkin Import Script",
						"SVN-Check in Failed");
			}
			try {
				repos = conn.connect(AIConstant.SVNATTR_PATH);
				if (attr.isEmpty() || attr == null
						|| attr.compareTo("ERROR") == 0) {
					System.out.println("No Attribute Definition");
				} else {
					conn.committoSVNwithfile(repos, AIConstant.SVNATTR_PATH,
							layoutid + ".attr", attr);
					displayInfoMessageToUser(layoutid
							+ ".attr checked in successfully", "SVN-CheckIn");
					conn.SVNPopulatedb(layoutID, "attr", layoutID + ".attr",
							userid);
				}
			} catch (Exception e) {

				displayInfoMessageToUser(
						"SVN Checkin-Falied.Please try again ", "SVN-CheckIn");
			}
			try {
				repos = conn.connect(AIConstant.SVNCATTR_PATH);

				if (cattr.contains("INVALID")) {
					displayErrorMessageToUser(
							"No Mappings defined for Control total",
							"Error in Cattr Checkin");
					return;
				}
				if (cattr.isEmpty() || cattr == null
						|| cattr.compareTo("ERROR") == 0) {

				} else {
					conn.committoSVNwithfile(repos, AIConstant.SVNCATTR_PATH,
							layoutid + ".cattr", cattr);
					displayInfoMessageToUser(layoutid
							+ ".cattr checked in successfully", "SVN-CheckIn");
					conn.SVNPopulatedb(layoutID, "cattr", layoutID + ".cattr",
							userid);
				}

			} catch (Exception e) {
				displayInfoMessageToUser(
						"SVN Checkin-Falied.Please try again ", "SVN-CheckIn");
			}
		}

	}

	public void checkinScriptOnly(String layoutid, String userid) {

		displayInfoMessageToUser("Checking in", "Check-in");
		if (this.manualFlag.compareTo("N") == 0) {
			String importScript = ProcessBuilderRunner.runImportScript(layoutid, "N");

			if (importScript.isEmpty() || importScript == null
					|| importScript.compareTo("ERROR") == 0) {

				displayInfoMessageToUser("No Import Script to check in", "Info");
			} else {
				ConnecttoSVN conn = new ConnecttoSVN();
				SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
				try {

					conn.committoSVNwithfile(repos, AIConstant.SVNSQL_PATH,
							"IP_" + layoutid + ".sql", importScript);
					displayInfoMessageToUser("IP_" + layoutid
							+ ".sql checked in successfully", "SVN-CheckIn");
					conn.SVNPopulatedb(layoutID, "Import", "IP_" + layoutID
							+ ".sql", userid);

				}

				catch (Exception e) {
					displayInfoMessageToUser(
							"SVN Checkin-Falied.Please try again ",
							"SVN-CheckIn");
				}
			}

		} else {
			displayErrorMessageToUser("Manual Flag is set.Could not Checkin",
					"SVN-Check in Failed");
		}
	}

	public void checkinCattr(String layoutid, String userid) {
		String cattr = ProcessBuilderRunner.runCAttr(layoutid);
		if (cattr.contains("INVALID")) {
			displayErrorMessageToUser("No Mappings Defined for this layout.",
					"Error in checkin");
			return;
		}

		ConnecttoSVN conn = new ConnecttoSVN();
		SVNRepository repos = conn.connect(AIConstant.SVNSQL_PATH);
		try {
			repos = conn.connect(AIConstant.SVNCATTR_PATH);

			if (cattr.isEmpty() || cattr == null
					|| cattr.compareTo("ERROR") == 0) {

			} else {
				conn.committoSVNwithfile(repos, AIConstant.SVNCATTR_PATH,
						layoutid + ".cattr", cattr);
				displayInfoMessageToUser(layoutid
						+ ".cattr checked in successfully", "SVN-CheckIn");
				conn.SVNPopulatedb(layoutID, "cattr", layoutID + ".cattr",
						userid);
			}
		} catch (Exception ex) {
			displayErrorMessageToUser(ex.toString(), "Checkin Failed");
		}

	}

	public void checkpending(String id) {
		int upcount = 0;
		int mapcount = 0;
		ConnectDB db = new ConnectDB();
		db.initialize();

		String query = "SELECT layoutid from imp_layout_repo WHERE layoutid='"
				+ id + "'";
		List<List<String>> rs = null;

		rs = db.resultSetToListOfList(query);

		if (rs != null) {
			if (rs.size() > 1) {
				upcount++;
				this.uploadWarn = false;

			} else {
				this.uploadWarn = true;
			}
		} else {
			this.uploadWarn = true;
		}

		if (upcount == 0) {
			this.uploadWarn = true;
		}

		query = "SELECT * from ps_rules_master  WHERE "
				+ "TGTFIELD IN  ('PAIDAMT'  ,'ENRID','MEMID','BILLEDAMT','COVERAGECODE','EFFDATE' , 'PAIDDATE','SERVICEDATE','ALLOWEDAMT','ENRPAID', 'TERMDATE','FILLDATE' ) "
				+ " AND  RULE IS null and layoutid='" + id + "'";

		rs = db.resultSetToListOfList(query);

		if (rs != null) {
			if (rs.size() > 1) {
				mapcount++;
				this.dsrmapWarn = false;
			} else {
				this.dsrmapWarn = true;
			}
		} else {
			this.dsrmapWarn = true;
		}
		if (mapcount == 0) {
			this.dsrmapWarn = true;
		}

		/*
		 * query="select layoutid from imp_svn_checkin where layoutid='" + id
		 * +"' and end_date is null"; try { rs=p.executeQuery(query); } catch
		 * (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); displayErrorMessageToUser(e.toString(),
		 * "ERROR"); } try { while(rs.next()) { svcount++;
		 * 
		 * } } catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); displayErrorMessageToUser(e.toString(),
		 * "ERROR"); } if(svcount>0) { query=
		 * "select c.layoutid from imp_svn_checkin c left join (select a.layoutid, greatest(NVL(a.dateupdated,to_date('01-01-1990','mm-dd-yyyy')),NVL(b.dateupdated,to_date('01-01-1990','mm-dd-yyyy'))) as dateupdated "
		 * +
		 * " from imp_layouts a,imp_sub_layouts b where a.layoutid=b.layoutid and a.layoutid='"
		 * + id + "') d  on c.layoutid=d.layoutid " + "  where c.layoutid='" +
		 * id +
		 * "' and  c.scripttype!='Import' and  c.end_date is null and d.dateupdated > c.from_date "
		 * ;
		 * 
		 * try { rs=p.executeQuery(query); } catch (SQLException e1) { // TODO
		 * Auto-generated catch block e1.printStackTrace();
		 * displayErrorMessageToUser(e1.toString(), "ERROR"); } try {
		 * while(rs.next()) { lmod++;
		 * 
		 * this.checkinWarn=true; } } catch (SQLException e) { // TODO
		 * Auto-generated catch block e.printStackTrace();
		 * displayErrorMessageToUser(e.toString(), "ERROR"); } if(lmod==0) {
		 * 
		 * this.checkinWarn=false; } else { this.checkinWarn=true; }
		 * 
		 * } else { this.checkinWarn=true; }
		 */
		if (this.layoutstatus.compareTo("WORKING") == 0) {
			this.checkinWarn = true;

		} else {
			this.checkinWarn = false;
		}

		/*
		 * if(upcount>0 && mapcount>0 && svcount>0 && lmod==0) {
		 * this.layoutWarn=false; } else { this.layoutWarn=true;
		 * 
		 * }
		 */

		db.endConnection();
		if (this.dsrmapWarn == true || this.checkinWarn == true
				|| this.uploadWarn == true) {
			this.layoutWarn = true;
		} else {
			this.layoutWarn = false;
		}

	}

	public boolean isLayoutWarn() {
		return layoutWarn;
	}

	public void setLayoutWarn(boolean layoutWarn) {
		this.layoutWarn = layoutWarn;
	}

	public boolean isUploadWarn() {
		return uploadWarn;
	}

	public void setUploadWarn(boolean uploadWarn) {
		this.uploadWarn = uploadWarn;
	}

	public boolean isCheckinWarn() {
		return checkinWarn;
	}

	public void setCheckinWarn(boolean checkinWarn) {
		this.checkinWarn = checkinWarn;
	}

	public boolean isDsrmapWarn() {
		return dsrmapWarn;
	}

	public void setDsrmapWarn(boolean dsrmapWarn) {
		this.dsrmapWarn = dsrmapWarn;
	}

	public String getCtltype() {
		return ctltype;
	}

	public void setCtltype(String ctltype) {
		this.ctltype = ctltype;
	}

	public String getManualFlag() {
		return manualFlag;
	}

	public void setManualFlag(String manualFlag) {
		this.manualFlag = manualFlag;
	}

	public boolean isManualoverride() {
		return manualoverride;
	}

	public void setManualoverride(boolean manualoverride) {
		this.manualoverride = manualoverride;
	}

	public String getLayoutstatus() {
		return layoutstatus;
	}

	public void setLayoutstatus(String layoutstatus) {
		this.layoutstatus = layoutstatus;
	}

	public String getImportedtablename() {
		return importedtablename;
	}

	public void setImportedtablename(String importedtablename) {
		this.importedtablename = importedtablename;
	}

	public String getEffectivedate() {
		return effectivedate;
	}

	public void setEffectivedate(String effectivedate) {
		this.effectivedate = effectivedate;
	}

	public String getModifieddate() {
		return modifieddate;
	}

	public void setModifieddate(String modifieddate) {
		this.modifieddate = modifieddate;
	}

	public String getVerified() {
		return verified;
	}

	public void setVerified(String verified) {
		this.verified = verified;
	}

	public String getCharacterSet() {
		return characterSet;
	}

	public void setCharacterSet(String characterSet) {
		this.characterSet = characterSet;
	}

	public String getIcd10Flag() {
		return icd10Flag;
	}

	public void setIcd10Flag(String icd10Flag) {
		this.icd10Flag = icd10Flag;
	}

	public String getDatadictionaryuploaded() {
		return datadictionaryuploaded;
	}

	public void setDatadictionaryuploaded(String datadictionaryuploaded) {
		this.datadictionaryuploaded = datadictionaryuploaded;
	}

	public String getSumflag() {
		return sumflag;
	}

	public void setSumflag(String sumflag) {
		this.sumflag = sumflag;
	}

	public String getTrailerflag() {
		return trailerflag;
	}

	public void setTrailerflag(String trailerflag) {
		this.trailerflag = trailerflag;
	}

}
