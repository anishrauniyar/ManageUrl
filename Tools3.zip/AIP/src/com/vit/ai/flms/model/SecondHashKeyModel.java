package com.vit.ai.flms.model;

public class SecondHashKeyModel {

	private String fieldname;
	private String fieldsn;
	private String uniqueHashFlag;
	private boolean hashkeyGenerated = false;

	public SecondHashKeyModel(String fieldname, String fieldsn,
			String uniqueHashFlag) {
		this.fieldname = fieldname;
		this.fieldsn = fieldsn;
		this.uniqueHashFlag = uniqueHashFlag;
	}

	public String getFieldname() {
		return fieldname;
	}

	public void setFieldname(String fieldname) {
		this.fieldname = fieldname;
	}

	public String getFieldsn() {
		return fieldsn;
	}

	public void setFieldsn(String fieldsn) {
		this.fieldsn = fieldsn;
	}

	public String getUniqueHashFlag() {
		return uniqueHashFlag;
	}

	public void setUniqueHashFlag(String uniqueHashFlag) {
		this.uniqueHashFlag = uniqueHashFlag;
	}

	public boolean isHashkeyGenerated() {
		return hashkeyGenerated;
	}

	public void setHashkeyGenerated(boolean hashkeyGenerated) {
		this.hashkeyGenerated = hashkeyGenerated;
	}

}
