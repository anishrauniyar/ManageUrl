/*
 *Class Name : LayoutFieldsModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 01 Oct 2014
 */
public class LayoutFieldsModel {

	private ArrayList<LayoutFields> layoutfields;
	private ArrayList<LayoutFields> layoutfieldsbysublayout;
	private String layoutID = "";
	private String subLayoutid="";

	public LayoutFieldsModel() {
	}

	public LayoutFieldsModel(String layoutID) {
		setLayoutID(layoutID);
		layoutfields = new ArrayList<LayoutFields>();
		setLayoutfields(layoutfields);
	}
	
	public LayoutFieldsModel(String layoutID,String sublayoutID)
	{
		setLayoutID(layoutID);
		setSubLayoutid(sublayoutID);
		layoutfieldsbysublayout = new ArrayList<LayoutFields>();
		setLayoutfieldsbysublayout(layoutfieldsbysublayout,sublayoutID);
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public ArrayList<LayoutFields> getLayoutfields() {
		return layoutfields;
	}

	public void setLayoutfields(ArrayList<LayoutFields> layoutfields) {

		ConnectDB db = new ConnectDB();
		db.initialize();

		String query = "SELECT LAYOUTID,sublayoutid,COLUMNID, COLUMNNAME, DATATYPE,DATETYPEDETIAL, "
				+ " FIELDLENGTH,SN,Nvl(STARTPOS,0),Nvl(ENDPOS,0),FIELDLINENUMBER,FIELDDELIMITER,FIELDPOSITION,BUSINESSNAME"
				+ " FROM IMP_LAYOUTS_FIELDS WHERE "
				+ " LAYOUTID='"
				+ getLayoutID() + "' ORDER BY " + " SUBLAYOUTID,COLUMNID";
		List<List<String>> fieldsList = db.resultSetToListOfList(query);

		db.endConnection();

		if (fieldsList.size() > 0) {

			for (int i = 1; i < fieldsList.size(); i++) {
				layoutfields.add(new LayoutFields(fieldsList.get(i).get(0),
						fieldsList.get(i).get(1), fieldsList.get(i).get(2),
						fieldsList.get(i).get(3), fieldsList.get(i).get(4),
						fieldsList.get(i).get(5), fieldsList.get(i).get(6),
						fieldsList.get(i).get(7), Integer.parseInt(fieldsList
								.get(i).get(8)), Integer.parseInt(fieldsList
								.get(i).get(9)), fieldsList.get(i).get(10),
						fieldsList.get(i).get(11), fieldsList.get(i).get(12),fieldsList.get(i).get(13)));
			}
		}

	}

	public ArrayList<LayoutFields> getLayoutfieldsbysublayout() {
		return layoutfieldsbysublayout;
	}

	public void setLayoutfieldsbysublayout(ArrayList<LayoutFields> layoutfieldsbysublayout,String slid) {
		ConnectDB db = new ConnectDB();
		db.initialize();

		String query = "SELECT LAYOUTID,sublayoutid,COLUMNID, COLUMNNAME, DATATYPE,DATETYPEDETIAL, "
				+ " FIELDLENGTH,SN,Nvl(STARTPOS,0),Nvl(ENDPOS,0),FIELDLINENUMBER,FIELDDELIMITER,FIELDPOSITION,BUSINESSNAME"
				+ " FROM IMP_LAYOUTS_FIELDS WHERE "
				+ " LAYOUTID='"
				+ getLayoutID() + "' and sublayoutid='"+slid+"' ORDER BY " + " SUBLAYOUTID,COLUMNID";
		System.out.println("QUERYYYYY : "  + query);
		List<List<String>> fieldsList = db.resultSetToListOfList(query);

		db.endConnection();

		if (fieldsList.size() > 0) {

			for (int i = 1; i < fieldsList.size(); i++) {
				layoutfieldsbysublayout.add(new LayoutFields(fieldsList.get(i).get(0),
						fieldsList.get(i).get(1), fieldsList.get(i).get(2),
						fieldsList.get(i).get(3), fieldsList.get(i).get(4),
						fieldsList.get(i).get(5), fieldsList.get(i).get(6),
						fieldsList.get(i).get(7), Integer.parseInt(fieldsList
								.get(i).get(8)), Integer.parseInt(fieldsList
								.get(i).get(9)), fieldsList.get(i).get(10),
						fieldsList.get(i).get(11), fieldsList.get(i).get(12),fieldsList.get(i).get(13)));
			}
		}
	}

	public String getSubLayoutid() {
		return subLayoutid;
	}

	public void setSubLayoutid(String subLayoutid) {
		this.subLayoutid = subLayoutid;
	}
}
