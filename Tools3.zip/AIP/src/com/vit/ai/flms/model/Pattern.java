/* 
 *Class Name : Pattern.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.event.CellEditEvent;

import com.vit.ai.session.UserInformation;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @Modified By Binesh Sah
 * 
 * @Modified By Anish Rauniyar
 * 
 * @version 1.1 07 Oct 2014
 */

public class Pattern implements Serializable {

	private static final long serialVersionUID = 8656223902032002587L;
	
	private static Logger log = Logger.getLogger(Pattern.class); 
	private String sn = "";
	private String clientID = "";
	private String pattern = "";
	private String layoutID = "";
	private String employerGroup = "";
	private String addedDate = "";
	private String remark = "";
	private String fileType = "";
	private String transferType = "";
	private String ignoreexception = "";

	/* For layout table */

	private String dataType = "";
	private String layoutType = "";
	private String layoutDetail = "";

	/* For row expansion */

	private String payer = "";
	private String payerID = "";
	private String punchCharFlag = "";
	private String optionally = "";
	private String skipRow = "";
	private String trailerSkipRow = "";
	private String layoutDescription = "";
	private String sourceInfo = "";
	private String ctllayoutid = "";
	private String ctlpattern = "";
	private String delimiter = "";
	private String overridendate = "";
	private String isoverriden = "";
	private String ctlFirstString;
	private String ctlSecondString;
	
	private ArrayList<String> listofAppIds = new ArrayList<>();
	private String interClientAppFlag ="";
	private String concatApps="";
	
	private UserInformation userinfo;

	private String username;
	
	private String inuse_status;
	private String inuse_status_remarks;
	 
	private String ediFlag;
	private String ediMapper;
	
		
	public String getEdiFlag() {
		return ediFlag;
	}

	public void setEdiFlag(String ediFlag) {
		this.ediFlag = ediFlag;
	}

	public String getEdiMapper() {
		return ediMapper;
	}

	public void setEdiMapper(String ediMapper) {
		this.ediMapper = ediMapper;
	}

	public String getInuse_status() {
		return inuse_status;
	}

	public void setInuse_status(String inuse_status) {
		this.inuse_status = inuse_status;
	}

	public String getInuse_status_remarks() {
		return inuse_status_remarks;
	}

	public void setInuse_status_remarks(String inuse_status_remarks) {
		this.inuse_status_remarks = inuse_status_remarks;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public String getCtlFirstString() {
		return ctlFirstString;
	}

	public void setCtlFirstString(String ctlFirstString) {
		this.ctlFirstString = ctlFirstString;
	}

	public String getCtlSecondString() {
		return ctlSecondString;
	}

	public void setCtlSecondString(String ctlSecondString) {
		this.ctlSecondString = ctlSecondString;
	}

	private LinkedHashMap<String, String> layoutTypes;

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	public String getPayerID() {
		return payerID;
	}

	public void setPayerID(String payerID) {
		this.payerID = payerID;
	}

	public String getPunchCharFlag() {
		return punchCharFlag;
	}

	public void setPunchCharFlag(String punchCharFlag) {
		this.punchCharFlag = punchCharFlag;
	}

	public String getOptionally() {
		return optionally;
	}

	public void setOptionally(String optionally) {
		this.optionally = optionally;
	}

	public String getSkipRow() {
		return skipRow;
	}

	public void setSkipRow(String skipRow) {
		this.skipRow = skipRow;
	}

	public String getTrailerSkipRow() {
		return trailerSkipRow;
	}

	public void setTrailerSkipRow(String trailerSkipRow) {
		this.trailerSkipRow = trailerSkipRow;
	}

	public String getLayoutDescription() {
		return layoutDescription;
	}

	public void setLayoutDescription(String layoutDescription) {
		this.layoutDescription = layoutDescription;
	}

	public String getSourceInfo() {
		return sourceInfo;
	}

	public void setSourceInfo(String sourceInfo) {
		this.sourceInfo = sourceInfo;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getLayoutType() {
		return layoutType;
	}

	public void setLayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public String getLayoutDetail() {
		return layoutDetail;
	}

	public void setLayoutDetail(String layoutDetail) {
		this.layoutDetail = layoutDetail;
	}

	
	
	public Pattern(String sn, String clientID, String pattern, String layoutID,
			String employerGroup, String addedDate, String remark,
			String fileType, String dataType, String layoutType,
			String layoutDetail, String transferType, String payer,
			String payerID, String punchCharFlag, String optionally,
			String skipRow, String trailerSkipRow, String layoutDescription,
			String sourceInfo, String ignoreexception, String ctlpattern,
			String ctllayoutid, String delimiter, String overridendate,
			String isoverriden,String ctlfirstString,String ctlsecondString, String interClientAppFlag, String inuse_status, String ediFlag, String ediMapper, String username) {
		super();
		this.sn = sn;
		this.clientID = clientID;
		this.pattern = pattern;
		this.layoutID = layoutID;
		this.employerGroup = employerGroup;
		this.addedDate = addedDate;
		this.remark = remark;
		this.fileType = fileType;
		this.transferType = transferType;
		this.dataType = dataType;
		this.layoutType = layoutType;
		this.layoutDetail = layoutDetail;
		this.payer = payer;
		this.payerID = payerID;
		this.punchCharFlag = punchCharFlag;
		this.optionally = optionally;
		this.skipRow = skipRow;
		this.trailerSkipRow = trailerSkipRow;
		this.layoutDescription = layoutDescription;
		this.sourceInfo = sourceInfo;
		this.ignoreexception = ignoreexception;
		this.ctlpattern = ctlpattern;
		this.ctllayoutid = ctllayoutid;
		this.delimiter = delimiter;
		this.overridendate = overridendate;
		this.isoverriden = isoverriden;
		this.ctlFirstString=ctlfirstString;
		this.ctlSecondString=ctlsecondString;
		this.interClientAppFlag = interClientAppFlag;
		this.inuse_status = inuse_status;
		this.ediFlag = ediFlag;
		this.ediMapper = ediMapper;
		this.username = username;
		setConcatApps(concatApps);
	}

	public Pattern(String sn, String clientID, String pattern, String layoutID,
			String employerGroup, String addedDate, String remark,
			String fileType, String dataType, String layoutType,
			String layoutDetail, String transferType) {
		super();
		this.sn = sn;
		this.clientID = clientID;
		this.pattern = pattern;
		this.layoutID = layoutID;
		this.employerGroup = employerGroup;
		this.addedDate = addedDate;
		this.remark = remark;
		this.fileType = fileType;
		this.dataType = dataType;
		this.layoutType = layoutType;
		this.layoutDetail = layoutDetail;
		this.transferType = transferType;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getEmployerGroup() {
		return employerGroup;
	}

	public void setEmployerGroup(String employerGroup) {
		this.employerGroup = employerGroup;
	}

	public String getAddedDate() {
		return addedDate;
	}

	public void setAddedDate(String addedDate) {
		this.addedDate = addedDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Pattern(String sn, String clientID, String pattern, String layoutID,
			String employerGroup, String addedDate, String remark,
			String fileType) {
		this.sn = sn;
		this.clientID = clientID;
		this.pattern = pattern;
		this.layoutID = layoutID;
		this.employerGroup = employerGroup;
		this.addedDate = addedDate;
		this.remark = remark;
		this.fileType = fileType;
	}

	public void onCellEdit(CellEditEvent event) {
		Object oldValue = event.getOldValue();
		Object newValue = event.getNewValue();
		String query = "";
		String columnName = event.getColumn().getColumnKey()
				.substring(event.getColumn().getColumnKey().indexOf("_") + 1);

		if (newValue != null && !newValue.equals(oldValue)) {
			newValue = newValue.toString().replaceAll("'", "''");

			ConnectDB db = new ConnectDB();
			db.initialize();
			System.out.println("The column name is: " + columnName);
			/*if (columnName.equals("EMPLOYERGROUP")) {
				query = "UPDATE imp_clientpatterns SET EMPLOYERGROUP = (SELECT STANDARDEMPLOYERID FROM cpd.cp_employermaster@nvaipd1 WHERE STANDARDEMPLOYERNAME = '"+ newValue +"') WHERE sn = '" + getSn() + "'";
			} else {*/
			String userLog  = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) VALUES ('1','"+columnName.toUpperCase()+"_EDIT'," 
							+ " 'PATTERNSN: "+getSn()+" | CLIENTID: "+getClientID()+" | "+columnName.toUpperCase()+" CHANGED FROM ' || (SELECT "+columnName+" FROM IMP_CLIENTPATTERNS WHERE sn='"+getSn()+"') ||' TO "+newValue+"','"
							+ this.username  + "',SYSDATE)";
			try {
				db.executeDML(userLog);
			} catch (Exception e) {
				log.info("There is a problem in maintaining the user log: " + e.getMessage());
			}
			query = "UPDATE IMP_CLIENTPATTERNS SET " + columnName + "='"
					+ newValue + "' WHERE SN='" + getSn() + "'";
			//}
			System.out.println("The query is: " + query);
			String result = db.executeDML(query);
			db.endConnection();
			FacesMessage msg = null;
			if (result.equalsIgnoreCase("1")) {
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, columnName
						+ " Changed", "Old: " + oldValue + ", New:" + newValue);
				if (columnName.equalsIgnoreCase("layoutid")) {
					this.layoutID = (String) newValue;
				}
			} else {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating " + columnName, result);
			}

			FacesContext.getCurrentInstance().addMessage(null, msg);
		}

	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public Pattern() {

	}

	public String getIgnoreexception() {
		return ignoreexception;
	}

	public void setIgnoreexception(String ignoreexception) {
		this.ignoreexception = ignoreexception;
	}

	public String getCtllayoutid() {
		return ctllayoutid;
	}

	public void setCtllayoutid(String ctllayoutid) {
		this.ctllayoutid = ctllayoutid;
	}

	public String getCtlpattern() {
		return ctlpattern;
	}

	public void setCtlpattern(String ctlpattern) {
		this.ctlpattern = ctlpattern;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getOverridendate() {
		return overridendate;
	}

	public void setOverridendate(String overridendate) {
		this.overridendate = overridendate;
	}

	public String getIsoverriden() {
		return isoverriden;
	}

	public void setIsoverriden(String isoverriden) {
		this.isoverriden = isoverriden;
	}

	public LinkedHashMap<String, String> getLayoutTypes() {
		return layoutTypes;
	}

	public void setLayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		this.layoutTypes = layoutTypes;
	}

	public ArrayList<String> getListofAppIds() {
		return listofAppIds;
	}

	public void setListofAppIds(ArrayList<String> listofAppIds) {
		
		this.listofAppIds = listofAppIds;
		
	}

	public String getInterClientAppFlag() {
		return interClientAppFlag;
	}

	public void setInterClientAppFlag(String interClientAppFlag) {
		this.interClientAppFlag = interClientAppFlag;
	}

	public String getConcatApps() {
		return concatApps;
	}

	public void setConcatApps(String concatApps) {
		
		this.concatApps = concatApps;
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = " SELECT distinct appid FROM imp_pattern_appid_reln  where patternid = '" + this.sn + "'" ;
		//System.out.println(query);
		
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					this.listofAppIds.add(rs.get(i).get(0));
					this.concatApps += rs.get(i).get(0) + ",";
					
				}
			}
			
			
			if(!this.concatApps.isEmpty())
			{
			this.concatApps = this.concatApps.substring(0,this.concatApps.length()-1);
			}
			
		}
	
		
	}

	
}
