/*
 * Author: Aashish Dhungana
 * 
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.primefaces.event.CellEditEvent;

import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 29 Dec 2014
 */
public class StatsCheckctl extends AbstractController implements Serializable {

	private static final long serialVersionUID = 2283093761077402148L;
	private String layoutID = "";
	private String subLayoutID = "";
	private String columnID = "";
	private String columnName = "";
	private String dataType = "";
	private String dateTypeDetail = "";
	private String fieldLength = "";
	ArrayList<String> statsFunctionList = new ArrayList<String>();
	private String frm_layout_layoutid = "";
	private String sn = "";
	private String ctlfield = "";
	private boolean edited = false;
	private String udfValue = "";

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getCtlfield() {
		return ctlfield;
	}

	public void setCtlfield(String ctlfield) {
		this.ctlfield = ctlfield;
	}

	public StatsCheckctl(String layoutID, String sn, String subLayoutID,
			String columnID, String columnName, String dataType,
			String dateTypeDetail, String fieldLength, String ctlfield,
			ArrayList<String> statsFunctionList, String frm_layout_layoutid,
			String udfValue) {
		super();
		this.layoutID = layoutID;
		this.subLayoutID = subLayoutID;
		this.columnID = columnID;
		this.columnName = columnName;
		this.dataType = dataType;
		this.dateTypeDetail = dateTypeDetail;
		this.fieldLength = fieldLength;
		this.statsFunctionList = statsFunctionList;
		this.frm_layout_layoutid = frm_layout_layoutid;
		this.sn = sn;
		this.ctlfield = ctlfield;
		this.udfValue = udfValue;

	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getSubLayoutID() {
		return subLayoutID;
	}

	public void setSubLayoutID(String subLayoutID) {
		this.subLayoutID = subLayoutID;
	}

	public String getColumnID() {
		return columnID;
	}

	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDateTypeDetail() {
		return dateTypeDetail;
	}

	public void setDateTypeDetail(String dateTypeDeatil) {
		this.dateTypeDetail = dateTypeDeatil;
	}

	public String getFieldLength() {
		return fieldLength;
	}

	public void setFieldLength(String fieldLength) {
		this.fieldLength = fieldLength;
	}

	public ArrayList<String> getStatsFunctionList() {
		return statsFunctionList;
	}

	public void setStatsFunctionList(ArrayList<String> statsFunctionList) {
		this.statsFunctionList = statsFunctionList;
	}

	public void onCellEdit(String columnName) {
		this.edited = true;
		
		String newValue = this.ctlfield;
		System.out.println("NEW CTL : " + this.ctlfield);
	
		System.out.println(columnName);

	
			String query = "";
			String t_statsFunc = "";
			if (columnName.equalsIgnoreCase("CTLFIELD")) {
				t_statsFunc = (String) newValue;
				columnName = "CTRL_FIELD";
			}
		

			
			String checkquery = "Select * from IMP_CTRL_MAP where layout_sn= '"
					+ getSn() + "'";
			System.out.println("Check query : " + checkquery);
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> check = new ArrayList<>();

			check = db.resultSetToListOfList(checkquery);

			if (check != null) {
				if (check.size() > 1) {
					query = "UPDATE IMP_CTRL_MAP SET " + columnName + "='"
							+ newValue + "' WHERE " + " layout_sn='" + getSn()
							+ "' ";
				}

				else {
					query = "INSERT INTO IMP_CTRL_MAP(layout_sn,ctrl_field) "
							+ " VALUES('" + getSn() + "','" + t_statsFunc
							+ "')";
					System.out.println("Insert query : " + query);

				}

				String tresult = db.executeDML(query);
				if(!this.ctlfield.contains("UDF"))
				{
					db.executeDML("delete from imp_ctrl_udf_map where field_sn='" + this.sn + "'");
				}
				db.endConnection();

				FacesMessage msg = null;
				if (tresult.compareTo("1") == 0) {
					msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
							columnName + " Changed", ""
									+ ", New:" + newValue);

				} else {
					msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"Error Updating " + columnName, "");

				}
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}
		

	}

	public void insertintoudfTable() {
		
		String query = "Insert into imp_ctrl_udf_map (layoutid, field_sn, udf_definition, udf_mapping) values ('"
				+ this.layoutID
				+ "','"
				+ this.sn
				+ "','"
				+ this.ctlfield
				+ "','" + this.udfValue + "')";
		
		ConnectDB db = new ConnectDB();
		db.initialize();
		String stat = db.executeDML(query);
		db.endConnection();
		if(stat.compareTo("1")==0)
		{
			displayInfoMessageToUser("Update Successful", "Update UDFFIELD");

		} else {
			displayErrorMessageToUser("Cannot Update.Please try again", "ERROR UPDATING");
		}
		
	}

	public String getFrm_layout_layoutid() {
		return this.frm_layout_layoutid;
	}

	public void setFrm_layout_layoutid(String frm_layout_layoutid) {
		this.frm_layout_layoutid = frm_layout_layoutid;
	}

	public boolean isEdited() {
		return edited;
	}

	public void setEdited(boolean edited) {
		this.edited = edited;
	}

	public String getUdfValue() {
		return udfValue;
	}

	public void setUdfValue(String udfValue) {
		this.udfValue = udfValue;
	}

}
