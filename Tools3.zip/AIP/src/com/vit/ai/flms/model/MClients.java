/* 
 *Class Name : MClients.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 07 Apr 2014
 */
public class MClients implements Serializable {

	private static final long serialVersionUID = 1L;
	private String client = "";
	private boolean fromMaster;

	private LinkedHashMap<String, String> clients;

	public MClients() {
		setFromMaster(true);
		clients = new LinkedHashMap<String, String>();
		setClients(clients);
	}

	public MClients(boolean fromMaster) {
		setFromMaster(fromMaster);
		clients = new LinkedHashMap<String, String>();
		setClients(clients);
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		String query = "SELECT Nvl(CLIENTID,'NA'),Nvl(CLIENTNAME,'NA') FROM HAWKEYEMASTER.M_CLIENTS ORDER BY CLIENTID asc";
		if (!fromMaster) {
			query = "SELECT A.CLIENTID, B.CLIENTNAME "
					+ "      FROM ( "
					+ "      SELECT CLIENTID FROM IMP_CLIENTPATTERNS GROUP BY CLIENTID "
					+ "      ) A " + "      LEFT JOIN "
					+ "      HAWKEYEMASTER.M_CLIENTS B "
					+ "      ON A.CLIENTID = B.CLIENTID ORDER BY CLIENTID asc";
		}
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}

	}

	public boolean isFromMaster() {
		return fromMaster;
	}

	public void setFromMaster(boolean fromMaster) {
		this.fromMaster = fromMaster;
	}

}
