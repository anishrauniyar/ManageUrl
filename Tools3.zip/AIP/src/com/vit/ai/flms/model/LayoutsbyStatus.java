/* 
 *Class Name : LayoutsbyStatus.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 01 Oct 2014
 */
public class LayoutsbyStatus implements Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<Layout> layouts;
	private String selectedStatus = "";
	private String payer = "";
	private ArrayList<String> layoutids;

	public ArrayList<String> getLayoutids() {
		return layoutids;
	}

	public LayoutsbyStatus(String payer, String status) {
		layouts = new ArrayList<Layout>();
		this.payer = payer;
		this.selectedStatus = status;
		setLayouts(layouts);

	}

	public LayoutsbyStatus(String payer) {

		this.payer = payer;
		layoutids = new ArrayList<String>();
		setLayoutids(layoutids);

	}

	public ArrayList<Layout> getLayouts() {
		return layouts;
	}

	public void setLayouts(ArrayList<Layout> layoutList) {
		String query = "";
		if (payer != null || payer != "" && selectedStatus != null
				|| selectedStatus != "") {
			if (this.payer.compareTo("ALL PAYERS") == 0) {

				if (this.selectedStatus.compareTo("WORKING") == 0
						|| this.selectedStatus.compareTo("FINALIZED") == 0) {
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE a.layout_status='"
							+ this.selectedStatus
							+ "'"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				} else if (this.selectedStatus.compareTo("pmanagement") == 0) {
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE verified='Y'"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";

				} else if (this.selectedStatus.compareTo("migrated") == 0) {
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE verified!='Y' "
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				}
				else if(this.selectedStatus.compareTo("icd10") == 0)
				{
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE a.icd10flag='Y' "
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				}
				else if(this.selectedStatus.compareTo("icd10havingstatusn") == 0)
				{
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE a.icd10flag='N' "
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				}
				else if(this.selectedStatus.compareTo("icd10havingstatusblank") == 0)
				{
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE a.icd10flag IS NULL"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				}



			} else {
				if (this.selectedStatus.compareTo("WORKING") == 0
						|| this.selectedStatus.compareTo("FINALIZED") == 0) {
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag"
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE a.layout_status='"
							+ this.selectedStatus
							+ "' AND a.payor='"
							+ this.payer
							+ "'"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				} else if (this.selectedStatus.compareTo("pmanagement") == 0) {
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag"
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE verified='Y' AND a.payor='"
							+ this.payer
							+ "'"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";

				} else if (this.selectedStatus.compareTo("migrated") == 0) {
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag"
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE verified!='Y' AND a.payor='"
							+ this.payer
							+ "'"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";

				}
				else if(this.selectedStatus.compareTo("icd10") == 0)
				{
					query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
							+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
							+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
							+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
							+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
							+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
							+ " ON a.LAYOUTID=c.LAYOUTID "
							+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
							+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
							+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE a.icd10flag='Y' AND a.payor='"
							+ this.payer 
							+ "'"
							+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
				}
			}

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> layoutsList = db.resultSetToListOfList(query);
			db.endConnection();
			if (layoutsList != null) {
				if (layoutsList.size() > 0) {
					for (int i = 1; i < layoutsList.size(); i++) {
						layoutList.add(new Layout(
								layoutsList.get(i - 1).get(0), layoutsList.get(
										i).get(0), layoutsList.get(i).get(1),
								layoutsList.get(i).get(2), layoutsList.get(i)
										.get(3), layoutsList.get(i).get(4),
								layoutsList.get(i).get(5), layoutsList.get(i)
										.get(6), layoutsList.get(i).get(7),
								layoutsList.get(i).get(8), layoutsList.get(i)
										.get(9), layoutsList.get(i).get(10),
								layoutsList.get(i).get(11), layoutsList.get(i)
										.get(12), layoutsList.get(i).get(13),
								layoutsList.get(i).get(14), layoutsList.get(i)
										.get(15), layoutsList.get(i).get(16),
								layoutsList.get(i).get(17), layoutsList.get(i)
										.get(18), layoutsList.get(i).get(19),
								layoutsList.get(i).get(20), layoutsList.get(i)
										.get(21), layoutsList.get(i).get(22),
								layoutsList.get(i).get(23), layoutsList.get(i)
										.get(24),layoutsList.get(i).get(25),layoutsList.get(i).get(26),layoutsList.get(i).get(27),layoutsList.get(i).get(28),layoutsList.get(i).get(29)));
					}
				}
			} else {

			}
		}

	}

	public void setLayoutids(ArrayList<String> layoutids) {
		String query = "";
		if (this.payer.compareTo("ALL PAYERS") == 0) {
			query = "SELECT DISTINCT LAYOUTID FROM IMP_LAYOUTS";
		} else {

			query = "SELECT DISTINCT LAYOUTID FROM IMP_LAYOUTS WHERE PAYOR='"
					+ this.payer + "'";
		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> IDList = db.resultSetToListOfList(query);
		db.endConnection();
		if (IDList.size() > 0) {
			for (int i = 1; i < IDList.size(); i++) {

				this.layoutids.add(IDList.get(i).get(0));

			}
		}

	}

	/**
	 * @return the selectedStatus
	 */
	public String getSelectedStatus() {
		return selectedStatus;
	}

	/**
	 * @param selectedStatus
	 *            the selectedStatus to set
	 */
	public void setSelectedStatus(String selectedStatus) {
		this.selectedStatus = selectedStatus;
	}

}
