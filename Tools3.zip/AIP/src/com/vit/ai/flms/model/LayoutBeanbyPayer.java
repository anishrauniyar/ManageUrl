/*
 * Author: Binesh Sah
 * 
 *Class Name : LayoutBeanbyPayer.java
 *
 *Version : 1.0
 *
 *Date: 2014/10/01
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

public class LayoutBeanbyPayer {

	private ArrayList<Layout> layouts;
	private String payerid = "";

	public LayoutBeanbyPayer() {
	}

	public LayoutBeanbyPayer(String payer) {
		setPayerid(payer);
		layouts = new ArrayList<Layout>();
		setLayouts(layouts);
	}

	public ArrayList<Layout> getLayouts() {
		return layouts;
	}

	public void setLayouts(ArrayList<Layout> layoutList) {
		String query = "";
		if (this.getPayerid().compareTo("ALL PAYERS") == 0) {
			query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
					+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
					+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
					+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag "
					+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
					+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
					+ " ON a.LAYOUTID=c.LAYOUTID "
					+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
					+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
					+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID "
					+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
		} else {
			query = "SELECT a.LAYOUTID, a.PAYOR, a.DATATYPE, a.PUCHCHARFLAG, a.OPTIONALLY, "
					+ " a.SKIPROW, c.NOOFCHILD,b.SUBLAYOUTID, b.LAYOUTTYPE, b.LAYOUTDETAIL, "
					+ " b.WHERECLAUSE,NULL AS nocflayout,a.TRAILERSKIP, "
					+ " a.PAYORID,a.LAYOUTDESCIPTION,a.SOURCEINFO,b.SUBLAYOUTDESC,F.NUMOFFIELDS,b.trailerSkipCondition,A.ACTIVEFLAG,a.userlog,a.ctltype,a.manualflag,a.layout_status,a.verified,a.characterSet,a.icd10flag,a.datadictionaryuploaded,b.sumflag,b.trailerflag"
					+ " FROM  IMP_LAYOUTS a left join IMP_SUB_LAYOUTS b ON a.LAYOUTID=b.LAYOUTID "
					+ " left JOIN (SELECT Count(*) NOOFCHILD,LAYOUTID FROM IMP_SUB_LAYOUTS GROUP BY LAYOUTID ) c "
					+ " ON a.LAYOUTID=c.LAYOUTID "
					+ " LEFT JOIN (SELECT COUNT(*) NUMOFFIELDS,LAYOUTID,SUBLAYOUTID "
					+ " FROM IMP_LAYOUTS_FIELDS GROUP BY  LAYOUTID,SUBLAYOUTID) F ON A.LAYOUTID=F.LAYOUTID "
					+ " AND B.SUBLAYOUTID=F.SUBLAYOUTID WHERE Upper(PAYOR)='"
					+ getPayerid()
					+ "' "
					+ " ORDER BY a.LAYOUTID,b.SUBLAYOUTID";
		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> layoutsList = db.resultSetToListOfList(query);
		db.endConnection();

		if (layoutsList.size() > 0) {
			for (int i = 1; i < layoutsList.size(); i++) {
				layoutList.add(new Layout(layoutsList.get(i - 1).get(0),
						layoutsList.get(i).get(0), layoutsList.get(i).get(1),
						layoutsList.get(i).get(2), layoutsList.get(i).get(3),
						layoutsList.get(i).get(4), layoutsList.get(i).get(5),
						layoutsList.get(i).get(6), layoutsList.get(i).get(7),
						layoutsList.get(i).get(8), layoutsList.get(i).get(9),
						layoutsList.get(i).get(10), layoutsList.get(i).get(11),
						layoutsList.get(i).get(12), layoutsList.get(i).get(13),
						layoutsList.get(i).get(14), layoutsList.get(i).get(15),
						layoutsList.get(i).get(16), layoutsList.get(i).get(17),
						layoutsList.get(i).get(18), layoutsList.get(i).get(19),
						layoutsList.get(i).get(20), layoutsList.get(i).get(21),
						layoutsList.get(i).get(22), layoutsList.get(i).get(23),
						layoutsList.get(i).get(24),layoutsList.get(i).get(25),layoutsList.get(i).get(26),layoutsList.get(i).get(27),layoutsList.get(i).get(28),layoutsList.get(i).get(29)));
			}
		}

	}

	public String getPayerid() {
		return payerid;
	}

	public void setPayerid(String payerid) {
		this.payerid = payerid;
	}

}
