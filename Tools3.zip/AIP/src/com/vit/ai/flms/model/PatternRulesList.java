/* 
 *Class Name : PatternRulesList.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 18 May 2014
 */
public class PatternRulesList implements Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<Pattern> patternList;
	private String client = "";
	private ArrayList<String> employers;
	private ArrayList<String> payors;
	private ArrayList<String> dataType;
	private String username;
	
	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public PatternRulesList(String clientID, String username) {
		setClient(clientID);
		patternList = new ArrayList<Pattern>();
		setUsername(username);
		setPatternList(patternList);

	}

	public ArrayList<Pattern> getPatternList() {
		return patternList;
	}

	public void setPatternList(ArrayList<Pattern> patternList) {
		employers = new ArrayList<String>();
		payors = new ArrayList<String>();
		dataType = new ArrayList<String>();

		Set<String> emp = new HashSet<String>();
		Set<String> payor = new HashSet<String>();
		Set<String> dataT = new HashSet<String>();

		/*String query = "SELECT a.SN, a.CLIENTID, a.PATTERN, a.LAYOUTID, a.EMPLOYERGROUP, a.ADDEDDATE, "
				+ "a.REMARKS, a.FILETYPE,b.DATATYPE,c.LAYOUTTYPE,c.LAYOUTDETAIL,a.TRANSFERTYPE,b.PAYOR, "
				+ " b.PAYORID, b.PUCHCHARFLAG, a.OPTIONALLY, a.SKIPROWS, b.TRAILERSKIP, b.LAYOUTDESCIPTION, "
				+ " b.SOURCEINFO,a.ignoreexception,a.CTL_PATTERN,a.CTL_LAYOUTID,a.delimiter,a.OVERRIDDENDATE,NVL(a.ISOVERRIDDEN,'N'),a.CTL_FIRST_STRING,  a.CTL_SECOND_STRING,a.INTERCLIENTAPPFLAG,a.inuse_status,a.ediflag,a.edimapper FROM  "
				+ "( "
				+ "SELECT * FROM IMP_CLIENTPATTERNS   "
				+ "WHERE CLIENTID='"
				+ client
				+ "' ) a "
				+ "LEFT JOIN "
				+ "IMP_LAYOUTS b  "
				+ "ON a.LAYOUTID = b.LAYOUTID "
				+ "LEFT JOIN  "
				+ "(SELECT * FROM IMP_SUB_LAYOUTS WHERE SUBLAYOUTID='1') c "
				+ "ON a.LAYOUTID = c.LAYOUTID  "
				+ "ORDER BY EMPLOYERGROUP,DATATYPE,LAYOUTTYPE";*/
		String query = "SELECT a.SN, a.CLIENTID, a.PATTERN, a.LAYOUTID, a.EMPLOYERGROUP, a.ADDEDDATE, "
				+ "a.REMARKS, a.FILETYPE,b.DATATYPE,c.LAYOUTTYPE,c.LAYOUTDETAIL,a.TRANSFERTYPE,b.PAYOR, "
				+ " b.PAYORID, b.PUCHCHARFLAG, a.OPTIONALLY, a.SKIPROWS, b.TRAILERSKIP, b.LAYOUTDESCIPTION, "
				+ " b.SOURCEINFO,a.ignoreexception,a.CTL_PATTERN,a.CTL_LAYOUTID,a.delimiter,a.OVERRIDDENDATE,NVL(a.ISOVERRIDDEN,'N'),a.CTL_FIRST_STRING,  a.CTL_SECOND_STRING,a.INTERCLIENTAPPFLAG,a.inuse_status,a.ediflag,a.edimapper FROM  "
				+ "( "
				+ "SELECT * FROM IMP_CLIENTPATTERNS   "
				+ "WHERE CLIENTID='"
				+ client
				+ "' ) a "
				+ "LEFT JOIN "
				+ "IMP_LAYOUTS b  "
				+ "ON a.LAYOUTID = b.LAYOUTID "
				+ "LEFT JOIN  "
				+ "(SELECT * FROM IMP_SUB_LAYOUTS WHERE SUBLAYOUTID='1') c "
				+ "ON a.LAYOUTID = c.LAYOUTID  "
				+ "ORDER BY EMPLOYERGROUP,DATATYPE,LAYOUTTYPE";

		System.out.println(query);

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rulesList = db.resultSetToListOfList(query);
		db.endConnection();

		if (rulesList.size() > 0) {
			for (int i = 1; i < rulesList.size(); i++) {
				patternList.add(new Pattern(rulesList.get(i).get(0), rulesList
						.get(i).get(1), rulesList.get(i).get(2), rulesList.get(
						i).get(3), rulesList.get(i).get(4), rulesList.get(i)
						.get(5), rulesList.get(i).get(6), rulesList.get(i).get(
						7), rulesList.get(i).get(8), rulesList.get(i).get(9),
						rulesList.get(i).get(10), rulesList.get(i).get(11),
						rulesList.get(i).get(12), rulesList.get(i).get(13),
						rulesList.get(i).get(14), rulesList.get(i).get(15),
						rulesList.get(i).get(16), rulesList.get(i).get(17),
						rulesList.get(i).get(18), rulesList.get(i).get(19),
						rulesList.get(i).get(20), rulesList.get(i).get(21),
						rulesList.get(i).get(22), rulesList.get(i).get(23),
						rulesList.get(i).get(24), rulesList.get(i).get(25),
						rulesList.get(i).get(26), rulesList.get(i).get(27),
						rulesList.get(i).get(28), rulesList.get(i).get(29),
						rulesList.get(i).get(30), rulesList.get(i).get(31),
						this.getUsername()

				));
				emp.add(rulesList.get(i).get(4));
				payor.add(rulesList.get(i).get(12));
				dataT.add(rulesList.get(i).get(8));
			}
			this.employers.addAll(emp);
			this.payors.addAll(payor);
			this.dataType.addAll(dataT);
			
		}

	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public ArrayList<String> getEmployers() {
		return employers;
	}

	public void setEmployers(ArrayList<String> employers) {
		this.employers = employers;
	}

	public ArrayList<String> getPayors() {
		return payors;
	}

	public void setPayors(ArrayList<String> payors) {
		this.payors = payors;
	}

	public ArrayList<String> getDataType() {
		return dataType;
	}

	public void setDataType(ArrayList<String> dataType) {
		this.dataType = dataType;
	}

}
