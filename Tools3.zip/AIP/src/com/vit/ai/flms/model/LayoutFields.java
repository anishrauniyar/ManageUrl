/* 
 *Class Name : LayoutFiles.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.flms.model;

import java.io.Serializable;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 07 July 2014
 */
public class LayoutFields implements Serializable {

	private static final long serialVersionUID = 1208174889301713568L;
	private String layoutID;
	private String subLayoutID;
	private String columnID;
	private String columnName;
	private String dataType;
	private String dateTypeDetail;
	private String fieldLength;
	private String sn;
	private int start;
	private int end;
	private String linenumber;
	private String fieldposition;
	private String fieldDelimiter;
	private String businessname;

	public LayoutFields() {
	}

	public LayoutFields(String layoutID, String subLayoutID, String columnID,
			String columnName, String dataType, String dateTypeDetail,
			String fieldLength, String sn, int start, int end,
			String linenumber, String fieldDelimiter, String fieldposition,String businessname) {
		super();
		this.layoutID = layoutID;
		this.subLayoutID = subLayoutID;
		this.columnID = columnID;
		this.columnName = columnName;
		this.dataType = dataType;
		this.dateTypeDetail = dateTypeDetail;
		this.fieldLength = fieldLength;
		this.sn = sn;
		this.start = start;
		this.end = end;
		this.linenumber = linenumber;
		this.fieldposition = fieldposition;
		this.fieldDelimiter = fieldDelimiter;
		this.businessname=businessname;
		
	}

	public LayoutFields(String columnID, String columnName, String dataType,
			String dateTypeDetail, String fieldLength, int start, int end,String businessname) {
		super();
		
		this.columnID = columnID;
		this.columnName = columnName;
		this.dataType = dataType;
		this.dateTypeDetail = dateTypeDetail;
		this.fieldLength = fieldLength;
		this.start = start;
		this.end = end;
		this.businessname=businessname;
	
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getSubLayoutID() {
		return subLayoutID;
	}

	public void setSubLayoutID(String subLayoutID) {
		this.subLayoutID = subLayoutID;
	}

	public String getColumnID() {
		return columnID;
	}

	public void setColumnID(String columnID) {
		this.columnID = columnID;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDateTypeDetail() {
		return dateTypeDetail;
	}

	public void setDateTypeDetail(String dateTypeDetail) {
		this.dateTypeDetail = dateTypeDetail;
	}

	public String getFieldLength() {
		return fieldLength;
	}

	public void setFieldLength(String fieldLength) {
		this.fieldLength = fieldLength;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	public String getLinenumber() {
		return linenumber;
	}

	public void setLinenumber(String linenumber) {
		this.linenumber = linenumber;
	}

	/**
	 * @return the fieldposition
	 */
	public String getFieldposition() {
		return fieldposition;
	}

	/**
	 * @param fieldposition
	 *            the fieldposition to set
	 */
	public void setFieldposition(String fieldposition) {
		this.fieldposition = fieldposition;
	}

	/**
	 * @return the fieldDelimiter
	 */
	public String getFieldDelimiter() {
		return fieldDelimiter;
	}

	/**
	 * @param fieldDelimiter
	 *            the fieldDelimiter to set
	 */
	public void setFieldDelimiter(String fieldDelimiter) {
		this.fieldDelimiter = fieldDelimiter;
	}

	public boolean equalsForFixedLength(LayoutFields obj) {
		boolean status = true;
		if (this.columnID.compareTo(obj.getColumnID()) != 0) {
			status = false;
			return status;
		}
		if (this.columnName.toUpperCase().compareTo(
				obj.getColumnName().toUpperCase()) != 0) {
			status = false;
			return status;
		}
		if (this.dataType.toUpperCase().compareTo(
				obj.getDataType().toUpperCase()) != 0) {
			status = false;
			return status;
		}
		if (this.dateTypeDetail.toUpperCase().compareTo(
				obj.getDateTypeDetail().toUpperCase()) != 0) {
			status = false;
			return status;
		}
		if (this.fieldLength.compareTo(obj.getFieldLength()) != 0) {
			status = false;
			return status;
		}
		if (this.start != obj.getStart()) {
			status = false;
			return status;
		}
		if (this.end != obj.getEnd()) {
			status = false;
			return status;
		}

		return status;

	}

	public boolean equalsForDelimited(LayoutFields obj) {
		boolean status = true;
		if (this.columnID.compareTo(obj.getColumnID()) != 0) {
			status = false;
			return status;
		}
		if (this.columnName.toUpperCase().compareTo(
				obj.getColumnName().toUpperCase()) != 0) {
			status = false;
			return status;
		}
		if (this.dataType.toUpperCase().compareTo(
				obj.getDataType().toUpperCase()) != 0) {
			status = false;
			return status;
		}
		if (this.dateTypeDetail.toUpperCase().compareTo(
				obj.getDateTypeDetail().toUpperCase()) != 0) {
			status = false;
			return status;
		}

		return status;

	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

}
