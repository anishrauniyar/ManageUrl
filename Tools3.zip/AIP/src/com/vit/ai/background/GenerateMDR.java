/* 
 *Class Name : GenerateMDR.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.background;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.genericreports.controller.GenericReportViewController;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 05 Feb 2015
 */
public class GenerateMDR implements Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(GenerateMDR.class.getName());

	/**
	 * Runnable class for generating and logging MDR reports
	 * 
	 */
	public class ExecutePLSQL implements Runnable {
		private String reportID = "";
		private String clid = "";
		private Date startdate;
		private Date enddate;
		private String fileID = "";
		private boolean fileSelected;
		private String createdBy = "";
		private String createdDate = "";
		private String reportName = "";
		private String requestType = "";
		private String username = "";
		private String mdrinput;
		private GenericReportViewController obj1;
		Thread imps = null;

		public String getClid() {
			return clid;
		}

		public void setClid(String clid) {
			this.clid = clid;
		}

		public Date getStartdate() {
			return startdate;
		}

		public void setStartdate(Date startdate) {
			this.startdate = startdate;
		}

		public Date getEnddate() {
			return enddate;
		}

		public void setEnddate(Date enddate) {
			this.enddate = enddate;
		}

		public String getFileID() {
			return fileID;
		}

		public void setFileID(String fileID) {
			this.fileID = fileID;
		}

		public boolean isFileSelected() {
			return fileSelected;
		}

		public void setFileSelected(boolean fileSelected) {
			this.fileSelected = fileSelected;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}

		public String getReportName() {
			return reportName;
		}

		public void setReportName(String reportName) {
			this.reportName = reportName;
		}

		public GenericReportViewController getObj1() {
			return obj1;
		}

		public void setObj1(GenericReportViewController obj1) {
			this.obj1 = obj1;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getReportID() {
			return reportID;
		}

		public void setReportID(String reportID) {
			this.reportID = reportID;
		}

		public String getRequestType() {
			return requestType;
		}

		public void setRequestType(String requestType) {
			this.requestType = requestType;
		}

		public ExecutePLSQL(String clid, Date startDate, Date endDate,
				boolean fileSelected, String fileID, String createdBy,
				String createdDate, String reportName, String requesttype,
				String reportid,String mdrinput) {

			this.reportID = reportid;
			this.createdBy = createdBy;
			this.createdDate = createdDate;
			this.reportName = reportName;
			this.clid = clid;
			this.startdate = startDate;
			this.enddate = endDate;
			this.fileSelected = true;
			this.fileID = fileID;
			this.requestType = requesttype;
			this.mdrinput=mdrinput;

		}

		public void init() {

			imps = new Thread(this);
			imps.start();

		}

		@SuppressWarnings("deprecation")
		@Override
		public void run() {

			
			if (this.requestType.compareTo("NEW") == 0) {
				InsertToTable();
			}
			String cmd = AIConstant.shFilelocation
					+ "./runMDR.sh -r " + this.reportID + " -n " + this.mdrinput;
			log.info("Executing MDR Package : " + cmd); 
			RuntimeExecutor terminalObj = new RuntimeExecutor(AIConstant.DASHBOARD_SERVER_IP);
			terminalObj.runSimpleCommand(cmd);		
			log.info("MDR package Run Complete--Releasing MDR Thread--");
			imps.stop();

		}

		/**
		 * @param clientid
		 * @return Server on which the clientid is imported
		 */
			public String getServer(String clientid) {
			String server = "";
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "select distinct(machine) from aip_client_server where clientid='"
					+ clientid + "'";
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			if (rs != null) {
				if (rs.size() > 1) {
					server = rs.get(1).get(0);
				} else {
					System.out.println("No Server Information found for "
							+ this.clid);
				}
			}
			return server;
		}

		public void updateStatus() {
			String query = "update IMP_INVENTORY_REP_LOG set status='COMPLETE' where reportid='"
					+ this.reportID
					+ "' and created_by='"
					+ this.createdBy
					+ "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
		}

		public void InsertToTable() {
			String sn = "0";
			String dateformat = "yyyy.MM.dd hh24:mi:ss";
			ConnectDB db = new ConnectDB();
			db.initialize();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String queryforID = "SELECT MAX(reportid) +1 FROM imp_inventory_rep_log";
			List<List<String>> snList = db.resultSetToListOfList(queryforID);
			db.endConnection();
			if (snList.size() > 1) {
				sn = snList.get(1).get(0);

			} else {
				sn = "0";
			}
			if (sn == null || sn.isEmpty()) {
				sn = "0";
			}
			this.reportID = sn;
			String[] filelist = null;
			if (this.fileSelected) {
				filelist = fileID.replaceAll("\'", "").split(",");

			} else {

				
			}
			this.reportName = sn + "_" + this.reportName;
			String sdate = "";
			String edate = "";
			if (this.startdate != null) {
				sdate = dateFormat.format(this.startdate);
			}
			if (this.enddate != null) {
				edate = dateFormat.format(this.enddate);
			}
			String processStartdate = dateFormat.format(new Date());
			String query = "INSERT INTO IMP_INVENTORY_REP_LOG(REPORTID, REPORTTYPE, CLIENTID, STARTDATE, ENDDATE, REPORTNAME, CREATEDDATE, STATUS, CREATED_BY,PROCESSSTARTDATE,TOPNVALUE)"
					+ " VALUES('"
					+ this.reportID
					+ "','MDR','"
					+ this.clid
					+ "',"
					+ "TO_DATE('"
					+ sdate
					+ "','"
					+ dateformat
					+ "'),"
					+ "TO_DATE('"
					+ edate
					+ "','"
					+ dateformat
					+ "'),'"
					+ this.reportName
					+ "',"
					+"sysdate,'RUNNING','"
					+ this.createdBy
					+ "',"
					+ "TO_DATE('"
					+ processStartdate
					+ "','"
					+ dateformat
					+ "')" + ",'"+this.getMdrinput()+"')";
			log.info("MDR Insert Query : " + query);
			ConnectDB db1 = new ConnectDB();
			db1.initialize();
			db1.executeDML(query);
			for(int i=0;i<filelist.length;i++)
			{
				String queryfile="Insert into imp_inventory_rep_log_details(reportid,fileid) values('"+this.reportID+"','"+filelist[i]+"')";
				db1.executeDML(queryfile);
			}
			db1.endConnection();

		}

		public String getMdrinput() {
			return mdrinput;
		}

		public void setMdrinput(String mdrinput) {
			this.mdrinput = mdrinput;
		}
	}

}
