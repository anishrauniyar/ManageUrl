/* 
 * Class Name : RunbackgroundExceptionImport.java
 *
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.background;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.logging.Logger;

import com.vit.ai.utils.AbstractController;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 05 Oct 2014
 */
public class RunbackgroundExceptionImport implements Serializable {
	private static final long serialVersionUID = 7080106260775308236L;
	int count = 0;

	/**
	 * Runnable class for importing exception files
	 * 
	 */
	public class importexception extends AbstractController implements Runnable {

		private final Logger LOG = Logger.getLogger(importexception.class
				.getName());
		String username;
		String command;
		Thread imps = null;
		
		ProcessBuilder processbuilder = null;
		InputStream inputStream=null;
		Process process=null;
		String line=null;


		public void init(String command) throws InterruptedException {
			this.command = command;

			Thread imps = new Thread(this);

			imps.start();
			
		}

		@Override
		public void run() {
			
			LOG.info(username + " : " + command);
			
			try {
				
				processbuilder = new ProcessBuilder(new String[]{"bash", "-c", command});
							
				processbuilder.redirectErrorStream(true);
				process = processbuilder.start();
				inputStream = process.getInputStream();

				BufferedReader reader = new BufferedReader(new InputStreamReader(
						process.getInputStream()));
				
				while ((line = reader.readLine()) != null) {

					line=null;
				}
			process.destroy();

			
			} catch (IOException e) {
				displayInfoMessageToUser("Unexpected Error Occured", "ERROR");
			}
			finally {
				try {

					if (inputStream != null) {
						inputStream.close();
					}

				} catch (IOException ex) {
					
					displayErrorMessageToUser(ex.toString(), "ERROR");
					
				}
			}
		
			
			LOG.info("Exception Import Called");
			

		}
		
	}

}
