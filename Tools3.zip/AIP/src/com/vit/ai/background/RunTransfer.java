/*
 * Class Name : RunTransfer.java
 *
 * Copyright: Verisk Information Technologies
 */

package com.vit.ai.background;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.RuntimeExecutor;

/**
 * Runnable class for transfer
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 15 Dec 2014
 */
public class RunTransfer implements Runnable, Serializable {

	private static final long serialVersionUID = -3490375226111100273L;
	private static Logger log = Logger.getLogger(RunTransfer.class.getName());
	private String commandtoRun;
	private Thread imps;

	public Thread getImps() {
		return imps;
	}

	public void setImps(Thread imps) {
		this.imps = imps;
	}

	public String getCommandtoRun() {
		return commandtoRun;
	}

	public void setCommandtoRun(String commandtoRun) {
		this.commandtoRun = commandtoRun;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void run() {
		try {
			RuntimeExecutor rt = new RuntimeExecutor(
					AIConstant.DASHBOARD_SERVER_NAME);
			log.info("RUNNING TRANSFER :" + this.commandtoRun);
			rt.runSimpleCommand(this.commandtoRun);
			rt.endProcess();
		} catch (Exception ex) {
			log.debug("RUN TRANSFER ERROR : " + ex.toString());
		}
		log.info("RELEASING TRANSFER THREAD");
		imps.stop();

	}

	public void init() {
		imps = new Thread(this);
		imps.start();

	}
}
