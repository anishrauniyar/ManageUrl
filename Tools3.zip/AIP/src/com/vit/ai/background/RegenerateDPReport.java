package com.vit.ai.background;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.RuntimeExecutor;

public class RegenerateDPReport implements Serializable {
	private static final long serialVersionUID = 1118646373669110712L;
	private static Logger log = Logger.getLogger(RunReport.class.getName());

	/**
	 * Runnable Class for generating user defined reports
	 */
	public class RunReport implements Runnable {
		private String fileid="";
		private String server="";
		Thread imps = null;

		
		public RunReport(String fileid,String server) {
			this.fileid=fileid;
			this.server=server;
			

		}
	
		public void init() {
			imps = new Thread(this);
			imps.start();

		}
		
		public void regenerate(String fileid,String server)
		{
			
			
		}
		
		


		@SuppressWarnings("deprecation")
		@Override
		public void run() {

			
			//	displayInfoMessageToUser("Regenerating Data Profiler Report For FileID : " + fileid, "Data Profiler");
				
				try
				{
				RuntimeExecutor robj= new RuntimeExecutor(this.server);
				String command="/"+AIConstant.DP_SCRIPT_PATH+"runDP.sh -i "+ fileid ;
				String stat=robj.runSimpleCommand(command);
				System.out.println("Command to Regenerate : " + command);
				robj.endProcess();
				System.out.println(stat);
			
				
				}
				catch(Exception ex)
				{
					
					log.error("ERROR WHILE REGENERATING : " + ex.toString());
				}
			imps.stop();
		}

		public String getFileid() {
			return fileid;
		}

		public void setFileid(String fileid) {
			this.fileid = fileid;
		}

	}

}
