/* 
 *Class Name : HealthCheckStatus.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.background;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.vit.dbconnection.ConnectDB;

/**
 * Managed Bean for checking the health of AIP application
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 04 Apr 2015
 */
@ManagedBean
@RequestScoped
public class HealthCheckStatus {

	private String serverStatus = "";

	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}

	/**
	 * @return Pass : Server is up,Fail : Server is down
	 */
	public String getServerStatus() {

		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select 1 from dual";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			this.serverStatus = "PASS";
		} else {
			this.serverStatus = "FAIL";
		}
		return serverStatus;
	}

}
