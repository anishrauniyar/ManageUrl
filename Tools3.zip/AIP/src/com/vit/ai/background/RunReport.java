/*
 * Class Name : RunReport.java
 * 
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.background;

import java.io.Serializable;

import org.apache.log4j.Logger;

import com.vit.ai.genericreports.controller.AddNewReport;
import com.vit.ai.genericreports.controller.GenericReportViewController;
import com.vit.ai.poireport.controller.GenericReportController;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 15 Nov 2014
 */
public class RunReport implements Serializable {

	private static final long serialVersionUID = 1118646373669110712L;
	private static Logger log = Logger.getLogger(RunReport.class.getName());

	/**
	 * Runnable Class for generating user defined reports
	 */
	public class RunExcel implements Runnable {
		private AddNewReport object;
		private String username;
		private GenericReportViewController obj1;
		Thread imps = null;

		public GenericReportViewController getObj1() {
			return obj1;
		}

		public void setObj1(GenericReportViewController obj1) {
			this.obj1 = obj1;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public AddNewReport getObject() {
			return object;
		}

		public void setObject(AddNewReport object) {
			this.object = object;
		}

		public RunExcel(AddNewReport obj, GenericReportViewController obj1,
				String username) {
			this.username = username;
			this.object = obj;
			this.setObj1(obj1);

		}

		public void init() {
			imps = new Thread(this);
			imps.start();

		}

		@SuppressWarnings("deprecation")
		@Override
		public void run() {

			GenericReportController r = new GenericReportController();
			log.info("--RUNNING REPORT THREAD--CALL FOR EXCEL GENERATION--");
			r.process(this.object, this.object.getGeneratedQuery(),
					this.object.getReportname(), this.object.getSheetname(),
					this.object.getHeaderMerge(), this.object.isTemplateUsed(),
					this.object.getTemplateName(), this.object.getFormula(),
					this.username);
			log.info("--RELEASING REPORT THREAD--");
			imps.stop();
		}

	}
}
