/* 
 *Class Name : ReportThreadController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.ReportProcess;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;

/**
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.1 30 Julyn 2014
 */
public class ReportThreadController implements Runnable, ReportProcess {

	private static final Logger logger = LoggerFactory
			.getLogger(ReportThreadController.class);

	RProcessKey key;
	RProcessRegistry processRegister;
	ReportProcess reportProcess;

	public ReportThreadController(ReportProcess reportProcess) {
		this.reportProcess = reportProcess;
	}

	public ReportThreadController() {

	}

	@Override
	public void run() {
		RWorkBook book = (RWorkBook) reportProcess;
		try {
			logger.info("START: Report " + book.getName() + " at "
					+ new Date().toString());
			reportProcess.init();
			reportProcess.saveReport();
		} catch (Exception e) {
			releaseProcess();
			logger.error(e.getMessage());
		} finally {
			releaseProcess();
			logger.info("END: Report " + book.getName() + " at "
					+ new Date().toString());
		}
	}

	private void releaseProcess() {
		processRegister.release(key);
	}

	@SuppressWarnings("unused")
	private boolean isAllThreadCompleted() {
		return processRegister.getProcessRegistry().size() == 0;
	}

	public ReportThreadController setProcessRegistry(RProcessKey key,
			RProcessRegistry registry) {
		if (key == null || registry == null) {
			throw new IllegalArgumentException("Cannot be null");
		}
		this.key = key;
		this.processRegister = registry;
		return this;
	}

	@Override
	public void createDataTable() {
		// TODO Auto-generated method stub

	}

	@Override
	public void postAction() {
		// TODO Auto-generated method stub

	}

	@Override
	public void init() {
		// TODO Auto-generated method stub

	}

	@Override
	public void saveReport() {
		// TODO Auto-generated method stub

	}

}
