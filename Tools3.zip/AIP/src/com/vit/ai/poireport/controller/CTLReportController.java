/*
 *Class Name : CTLReportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.RWorkBookSheet;
import com.vit.ai.poireport.writer.RGenericSheet;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.1 01 Dec 2014
 */
public class CTLReportController implements Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(CTLReportController.class
			.getName());
	private String fileID;
	private String filterCondition;

	public CTLReportController() {

	}

	public void process(String fileID, String fileName) {
		this.fileID = fileID;
		ConnectDB db = new ConnectDB();
		db.initialize();
		String ctlQuery = getQuery(1);
		String controltotalheader = ",,,,,,,,,,,VH,,,,,,,,,,,,,,,,Vendor,,,,,,,,,,,,,,,,Variance,,,,,,,,,,,,,, "
				+ "<NextRow>FileID,Source Filename,Data Layoutid, CTL FileID, CTL Filename, CTL Layoutid, Control Type, Received Month, Category,Payor, PayorName,"
				+ " Billed Amount,Allowed Amount,Plan Paid Amount,Employee Paid,Employee Count,Member Count,Record Count,UDF1,UDF2,UDF3,UDF4,UDF5,UDF6,UDF7,UDF8,UDF9,Billed Amount, "
				+ " Allowed Amount,Plan Paid Amount,Employee Paid,Employee Count,"
				+ " Member Count, Record Count , UDF1,UDF2,UDF3,UDF4,UDF5,UDF6,UDF7,UDF8,UDF9, Billed Amount ,Allowed Amount ,Plan Paid Amount ,Employee Paid, Employee Count, Member Count, Record Count ,UDF1,UDF2,UDF3,UDF4,UDF5,UDF6,UDF7,UDF8,UDF9 ";
	
		String[] customMergeRegion={ "A1:K1","L1:AA1","AB1:AQ1","AR1:BG1"};
		List<RWorkBook> ctlWorkBookFile = new ArrayList<RWorkBook>();

		RWorkBook ctlWorkBook = new RWorkBook();
		ctlWorkBook.setName(fileName);
		ctlWorkBook.setLocation(AIConstant.CTL_REPORT_DUMP_LOCATION);

		ctlWorkBook.setTemplateUsed(true);
		ctlWorkBook.setTemplateName(AIConstant.REPORT_TEMPLATES_PATH
				+ AIConstant.CTL_TEMPLATE_NAME_H);
		List<RWorkBookSheet> ctlSheets = new ArrayList<RWorkBookSheet>();

		RGenericSheet ctlsheet1 = new RGenericSheet("File ControlTotal");
		ctlsheet1.setSheetCreatedInTemplate(true);
		ctlsheet1.setPostActionEnabled(true);
		ctlsheet1.setCustomMergeRegion(customMergeRegion);
		
		List<RDataTable> listOfDataTables = new ArrayList<RDataTable>();
		RDataTable dataTable;
		RDataTable datatableforheader=new RDataTable(controltotalheader);
		listOfDataTables.add(datatableforheader);
		

		dataTable = new RDataTable(false, ctlQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		listOfDataTables.add(dataTable);
		listOfDataTables.get(0).setProperty("control");
		//ctlsheet1.applyCustomStyle(6, listOfDataTables.get(0));
		ctlsheet1.setTables(listOfDataTables);
		ctlsheet1.setBookName(fileName);
		ctlSheets.add(ctlsheet1);

		/* add sheets into workbook */
		ctlWorkBook.setWorksheets(ctlSheets);
		ctlWorkBookFile.add(ctlWorkBook);

		RProcessRegistry processRegister = new RProcessRegistry();
		processRegister.init();
		for (RWorkBook workBook : ctlWorkBookFile) {
			workBook.setFileID(fileID);
			processRegister.registerProcess(
					new RProcessKey(workBook.getLocation(), "UserID"
							+ System.currentTimeMillis()), workBook);

		}

		db.endConnection();

		processRegister.shutDown();
		while (!processRegister.isProcessTerminated()) {

		}

	}

	public String getQuery(int tabIndex) {
		String query = "";
		switch (tabIndex) {
		case 1:
			 query = " select fileid, filename, datalayoutid, ctlfileid,ctlfilename,ctllayout,controltype, receivedmonth, category, "
					+ "shortpayor, payername, vh_billed_amt, vh_allowed_amt, vh_paid_amt,"
					+ " vh_employee_amt, vh_employee_cnt, vh_member_cnt, vh_record_cnt,vh_udf1,vh_udf2,vh_udf3,vh_udf4,vh_udf5,vh_udf6,vh_udf7,vh_udf8,vh_udf9,"
					+ " v_billed_amt, v_allowed_amt, v_paid_amt, v_employee_amt,"
					+ " v_employee_cnt, v_member_cnt, v_record_cnt,v_udf1,v_udf2,v_udf3,v_udf4,v_udf5,v_udf6,v_udf7,v_udf8,v_udf9, var_billed_amount, "
					+ "var_allowed_amount, var_paid_amount, var_emp_amount, var_emp_count," +
					"var_mem_count, var_rec_count,var_udf1,var_udf2,var_udf3,var_udf4,var_udf5,var_udf6,var_udf7,var_udf8,var_udf9 from aip_dashboard_ctl where fileid IN ('"
					+ fileID + "')";
			log.info(" CTLReportController query " + query);

			
			break;
		}
		return query;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFilterCondition() {
		return filterCondition;
	}

	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}
}
