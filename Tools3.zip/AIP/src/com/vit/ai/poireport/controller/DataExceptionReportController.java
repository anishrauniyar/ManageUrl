/* 
 *Class Name : DataExceptionReportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.RWorkBookSheet;
import com.vit.ai.poireport.writer.RGenericSheet;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;
import com.vit.ai.remoteConnection.ExecuteUsingSQLPLUS;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to generate exception report
 * 
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.1 04 July 2014
 */
public class DataExceptionReportController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(DSRReportController.class
			.getName());
	private String fileID;
	private String clientID;

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	private String filterCondition;

	private String dataExceptionSummaryQuery;

	public String getDataExceptionSummaryQuery() {
		return dataExceptionSummaryQuery;
	}

	public void setDataExceptionSummaryQuery(String dataExceptionSummaryQuery) {
		this.dataExceptionSummaryQuery = dataExceptionSummaryQuery;
	}

	public String getDataExceptionDetailsQuery() {
		return dataExceptionDetailsQuery;
	}

	public void setDataExceptionDetailsQuery(String dataExceptionDetailsQuery) {
		this.dataExceptionDetailsQuery = dataExceptionDetailsQuery;
	}

	public String getLayoutcheckQuery() {
		return layoutcheckQuery;
	}

	public void setLayoutcheckQuery(String layoutcheckQuery) {
		this.layoutcheckQuery = layoutcheckQuery;
	}

	private String dataExceptionDetailsQuery;
	private String layoutcheckQuery;
	private String dateNumberExcepQuery;

	ConnectDB db = new ConnectDB();
	CustomUtility objCU = new CustomUtility();

	public DataExceptionReportController() {

	}

	public String getFileIds(String fileids) {
		String ids = "";
		System.out.println("Retrieved FileIds : " + fileids);
		String[] listofids = fileids.split(",");
		for (int i = 0; i < listofids.length; i++) {
			ids = ids + listofids[i].split("_")[0] + "',";
		}

		System.out.println("FInal ids : "
				+ ids.substring(0, ids.lastIndexOf(",") - 1));
		return ids.substring(0, ids.lastIndexOf(",") - 1);

	}
	
	public int runExceptionDetail()
	{
		String cmd = "Exec gen_exception_detail('" + this.fileID.replaceAll("\'", "") + "')";
		log.info("Executing Exception Detail Package : " + cmd);
		String servertoexecute= AIConstant.RAC_SERVER_NAME;
		

		try {
			ExecuteUsingSQLPLUS obj = new ExecuteUsingSQLPLUS("EXCEPTION",
					servertoexecute, cmd, AIConstant.DEFAULT_SCHEMA_NAME,
					AIConstant.DEFAULT_SCHEMA_PASSWORD,
					AIConstant.RAC_SERVICE_SID, AIConstant.RAC_SERVICE_PORT);
			obj.run();
			Thread.sleep(1000);
			return 1;
		} catch (Exception ex) {
			log.debug("ERROR EXECUTING EXCEPTION PACKAGE : " + ex.toString());
			return 0;
		}

		
		

	}

	public void process(String fileID, String fileName, String clientID) {
		
		this.fileID = fileID;
		this.fileID = getFileIds(this.fileID);
		int check=runExceptionDetail();
		if(check==0)
		{
			log.info("EXCEPTION DETAIL PACKAGE FAILED");
		}
		this.clientID = clientID.split("-")[0].trim();
		setFilterCondition(" WHERE FILEID IN('" + this.fileID + "') ");

		db.initialize();

		setQueries();

		String dexcepsummaryheader = "FILEID,FILENAME,DATATYPE, LAYOUTID ,SUBLAYOUTID,FIELDNAME,CHECKTYPE,TOTAL_RECORD, VALID_RECORD, INVALID_RECORD, PERCENTAGE";
		String exceptiondetailsheader = "FILEID,FILENAME,DATATYPE	,LAYOUTID,SUBLAYOUTID,FIELDNAME,	CHECKTYPE,	FIELD VALUES,RECORD COUNT";
		String layoutcheckheader = "LAYOUT_ID,COLUMNID,COLUMNNAME,GETSTATSFUNCTION,FIELD_VALUE";
		String dnmbrexcepheader = "FileID,Filename,Tablename,Category,Payor,FieldName,Layout Format,Source Value,Value Count,Total Record Count";

		List<RWorkBook> dsrWorkBookFile = new ArrayList<RWorkBook>();

		RWorkBook dsrWorkBook = new RWorkBook();
		dsrWorkBook.setName(fileName);
		dsrWorkBook.setLocation(AIConstant.FSR_REPORT_DUMP_LOCATION);

		dsrWorkBook.setTemplateUsed(false);
		List<RWorkBookSheet> dsrSheets = new ArrayList<RWorkBookSheet>();

		List<RDataTable> listOfDataTables = new ArrayList<RDataTable>();
		RDataTable dataTable;

		RGenericSheet dexcepSheet = new RGenericSheet("Data Exception Summary");
		dexcepSheet.setPostActionEnabled(true);
		listOfDataTables = new ArrayList<RDataTable>();

		listOfDataTables.add(new RDataTable(dexcepsummaryheader));

		dataTable = new RDataTable(false, dataExceptionSummaryQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);

		listOfDataTables.add(dataTable);

		dexcepSheet.setTables(listOfDataTables);
		dexcepSheet.setBookName(fileName);
		dsrSheets.add(dexcepSheet);

		// Second Sheet

		RGenericSheet dexcepdetailSheet = new RGenericSheet(
				"Data Exception Details");
		dexcepdetailSheet.setPostActionEnabled(true);
		listOfDataTables = new ArrayList<RDataTable>();

		listOfDataTables.add(new RDataTable(exceptiondetailsheader));

		dataTable = new RDataTable(false, dataExceptionDetailsQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);

		listOfDataTables.add(dataTable);

		dexcepdetailSheet.setTables(listOfDataTables);
		dexcepdetailSheet.setBookName(fileName);
		dsrSheets.add(dexcepdetailSheet);

		// Third Sheet

		RGenericSheet layoutchecksheet = new RGenericSheet("Layout Check");
		layoutchecksheet.setPostActionEnabled(true);
		listOfDataTables = new ArrayList<RDataTable>();

		listOfDataTables.add(new RDataTable(layoutcheckheader));

		dataTable = new RDataTable(false, layoutcheckQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		listOfDataTables.add(dataTable);
		layoutchecksheet.setTables(listOfDataTables);
		layoutchecksheet.setBookName(fileName);
		dsrSheets.add(layoutchecksheet);

		listOfDataTables = new ArrayList<RDataTable>();
		RGenericSheet dnmbrSheet = new RGenericSheet("Date Number Exceptions");
		dnmbrSheet.setPostActionEnabled(true);
		listOfDataTables.add(new RDataTable(dnmbrexcepheader));

		dataTable = new RDataTable(false, dateNumberExcepQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		listOfDataTables.add(dataTable);

		dnmbrSheet.setTables(listOfDataTables);
		dnmbrSheet.setBookName(fileName);
		dsrSheets.add(dnmbrSheet);

		/* add sheets into workbook */
		dsrWorkBook.setWorksheets(dsrSheets);
		dsrWorkBookFile.add(dsrWorkBook);

		RProcessRegistry processRegister = new RProcessRegistry();
		processRegister.init();
		for (RWorkBook workBook : dsrWorkBookFile) {
			workBook.setFileID(fileID);
			processRegister.registerProcess(
					new RProcessKey(workBook.getLocation(), "UserID"
							+ System.currentTimeMillis()), workBook);

		}

		db.endConnection();

		processRegister.shutDown();
		while (!processRegister.isProcessTerminated()) {

		}

	}

	public void setQueries() {

		this.dataExceptionSummaryQuery = " WITH ZZZ_DATA AS "
				+ " (SELECT "
				+ " A.FILEID, B.FILENAME, B.DATATYPE , A.LAYOUTID, A.SUBLAYOUTID ,"
				+ " A.FIELDNAME ,A.CHECKTYPE,"
				+ " REGEXP_SUBSTR(A.RESULT, '\\d+', 1) AS TOTAL_RECORD,"
				+ " REGEXP_SUBSTR(A.RESULT, '\\d+', 1,2)  AS VALID_RECORD ,"
				+ " REGEXP_SUBSTR(A.RESULT, '\\d+', 1,3) AS INVALID_RECORD   ,CHECKDETAIL"
				+ " FROM IMP_FILE_STATS_LOG A join IMP_MAIN_LOG B"
				+ " ON  A.FILEID=B.FILEID||'_'||DMFILEID  AND  A.FIELDNAME IS NOT NULL"
				+ "    AND b.FILEID IN ('"
				+ this.fileID
				+ "') )"
				+ " SELECT B.* FROM  ("
				+ " SELECT  FILEID, FILENAME, DATATYPE, LAYOUTID, SUBLAYOUTID, FIELDNAME,"
				+ " CASE WHEN CHECKDETAIL='EMPTY' THEN 'EMPTY CHECK' ELSE 'VALUE CHECK' END AS CHECKTYPE, TOTAL_RECORD, VALID_RECORD, INVALID_RECORD "
				+ " , CASE WHEN CHECKDETAIL='EMPTY' THEN ROUND( (VALID_RECORD/TOTAL_RECORD )*100 , 2) ELSE ROUND( (INVALID_RECORD/TOTAL_RECORD )*100 ,2) END  AS PERCENTAGE"
				+ " FROM ZZZ_DATA A    ORDER BY   A.FILEID,A.LAYOUTID,A.SUBLAYOUTID   ) B"
				+ " WHERE   TOTAL_RECORD!=0  AND PERCENTAGE >1";

		this.dataExceptionDetailsQuery = "select fileid, filename, datatype, layoutid, sublayoutid,  fieldname, checktype, field_values, record_cnt from rpt_data_exception where aip_file_id IN ('"+this.fileID+"')";
		
		
		
		this.layoutcheckQuery = " SELECT  LAYOUT_ID,  columnid,  Upper(columnname) AS columnname , "
				+ " CASE WHEN FIELD_VALUE='EMPTY' then 'EMPTY CHECK' WHEN GETSTATSFUNCTION ='CHKVAL' THEN 'VALUE CHECK' ELSE GETSTATSFUNCTION END  AS GETSTATSFUNCTION,"
				+ " field_value "
				+ " from "
				+ "  imp_layout_details a "
				+ "  JOIN imp_layouts_fields b "
				+ "  ON     a.layout_id=b.layoutid and a.layout_sn=b.sn"
				+ "  WHERE  EXISTS (SELECT 1 FROM imp_main_log  c WHERE b.layoutid=c.layoutid  AND  c.FILEID IN ('" + this.fileID + "') ) "
				+" ORDER BY a.LAYOUT_ID , b.sublayoutid,To_Number(columnid)";

		this.dateNumberExcepQuery = "SELECT a.fileid,b.filename DATA_SOURCE, 'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||c.shortpayor AS TABLENAME,b.datatype DATA_TYPE , c.payor,Upper(a.colname ) FIELD_NAME , "
				+ " a.dataformat LAYOUT_FORMAT, Nvl(flval,'BLANKNULL') SOURCE_VALUE ,  a.rc RECORD_COUNT ,import_record_cnt "
				+ " FROM "
				+ " (SELECT e.* , f.FILEID, f.layoutid,f.sublayoutid FROM rpt_chk_date_number e,rpt_main_log f WHERE e.sn=f.sn "
				+ " AND reporttype ='DTE_NUM_CHK'   ) a,"
				+ " imp_main_log b  , imp_layouts   c "
				+ " WHERE "
				+ " a.fileid=b.fileid||'_'||b.dmfileid"
				+ " AND b.layoutid=c.layoutid "
				+ " and 	b.fileid IN  ('"
				+ this.fileID + "') " + " ORDER BY  a.fileid , FLVAL,rc";

		log.info(" 3. DER Report Controller " + this.dataExceptionSummaryQuery);

		log.info(" 3. DER Report Controller: date number exception " + this.dateNumberExcepQuery);

		log.info(" 4. DER Report Controller Data details " + this.dataExceptionDetailsQuery);

	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFilterCondition() {
		return filterCondition;
	}

	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}

	public String getDateNumberExcepQuery() {
		return dateNumberExcepQuery;
	}

	public void setDateNumberExcepQuery(String dateNumberExcepQuery) {
		this.dateNumberExcepQuery = dateNumberExcepQuery;
	}

}
