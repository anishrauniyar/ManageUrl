/* 
 *Class Name : MDRReportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.RWorkBookSheet;
import com.vit.ai.poireport.writer.RGenericSheet;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to genarate meta data report
 * 
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.1 12 Aug 2014
 */
public class MDRReportController implements Serializable {

	private static Logger log = Logger.getLogger(MDRReportController.class
			.getName());
	private static final long serialVersionUID = 1L;
	private String fileID;

	public MDRReportController() {

	}

	ConnectDB db = new ConnectDB();

	public void process(String reportid, String fileName,String clientID,String clientName,ArrayList<String> empgroup,ArrayList<String> payor,String username,String createddate,String noOffile,String mdrInput) {
		this.fileID = reportid;
		this.fileID = this.fileID.replaceAll(",", "\',\'");
		System.out.println(this.fileID);
		db.initialize();

		String firstTabQuery = getQuery(1,reportid);
		String secondTabQuery = getQuery(2,reportid);

		String metaHeader1 = " , , , , , , 	  "
				+ " Total Paid Amount , ,  , Paid Amount Percentage , , "
				+ "<NextRow>LayoutID,DATA TYPE,DATA SOURCE,TABLE NAME,FIELD NAME,NUMBER OF UNIQUE VALUES,TOTAL RECORD COUNT,NUMBER OF NULL COUNT,PERCENTAGE OF NULL COUNT,TOTAL PAID AMOUNT,PAID AMOUNT OF NULL,PERCENTAGE OF NULL PAID AMOUNT";
		String metaHeader2 = " , , , , , , 	  "
				+ " Total Paid Amount , ,  , Paid Amount Percentage , , "
				+ "<NextRow>LAYOUTID,DATA TYPE,DATA SOURCE,TABLE NAME,FIELD NAME,DATA VALUE,TOTAL RECORD COUNT,NUMBER OF RECORDS,PERCENTAGE OF RECORD COUNT,TOTAL PAID AMOUNT,PAID AMOUNT,PERCENTAGE OF TOTAL PAID AMOUNT";
		String summary_header="Client ID, "
							+clientID
							+"<NextRow> Client Name, "
							+clientName
							+"<NextRow> Group Name, "
							+empgroup.toString().replaceAll(",", "|")
							+"<NextRow> Payor, "
							+payor.toString().replaceAll(",", "|")
							+"<NextRow> # File, "
							+noOffile
							+"<NextRow> Data Source, "
							+"<NextRow> Update Date, "
							+createddate
							+"<NextRow> Highlights, "
							+"<NextRow> Reviewed by VH, "
							+username
							+"<NextRow> Approved by Client, ";
		
		String columnStyleMetaData[] = { "9:percentage_style_meta",
				"12:percentage_style_meta" };
		String formulaMetaData[] = { "9<Formula>IF(VALUE(G@)=0,0,100*(VALUE(H@)/VALUE(G@)))",
				"12<Formula>IF(VALUE(J@)=0,0,100*(VALUE(K@)/VALUE(J@)))" };
		String[] customMergeRegion = { "G1:I1", "J1:L1" };

		List<RWorkBook> mdrWorkBookFile = new ArrayList<RWorkBook>();

		RWorkBook mdrWorkBook = new RWorkBook();
		mdrWorkBook.setName(fileName);
		mdrWorkBook.setLocation(AIConstant.FMDR_REPORT_DUMP_LOCATION);
		mdrWorkBook.setTemplateUsed(true);
		mdrWorkBook.setTemplateName(AIConstant.REPORT_TEMPLATES_PATH
				+ AIConstant.FMDR_TEMPLATE_NAME);

		List<RWorkBookSheet> mdrSheets = new ArrayList<RWorkBookSheet>();
		

		RGenericSheet genericSheet0 = new RGenericSheet("Summary");
		genericSheet0.setPostActionEnabled(true);
		genericSheet0.setCustomMergeRegion(customMergeRegion);
		

		List<RDataTable> listOfDataTables0 = new ArrayList<RDataTable>();
		listOfDataTables0.add(new RDataTable(summary_header));
		genericSheet0.setTables(listOfDataTables0);
		genericSheet0.setBookName(fileName);
		mdrSheets.add(genericSheet0);

		RDataTable dataTable = new RDataTable();

		RGenericSheet genericSheet1 = new RGenericSheet("1.Data Assessment");
		genericSheet1.setPostActionEnabled(true);
		genericSheet1.setCustomMergeRegion(customMergeRegion);

		List<RDataTable> listOfDataTables = new ArrayList<RDataTable>();
		listOfDataTables.add(new RDataTable(metaHeader1));

		dataTable = new RDataTable(false, firstTabQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		dataTable.setEnableColumnFormula(true);
		dataTable.setCustomStyles(columnStyleMetaData);
		dataTable.setFormulaForColumns(formulaMetaData);
		listOfDataTables.add(dataTable);

		genericSheet1.setTables(listOfDataTables);
		genericSheet1.setBookName(fileName);
		mdrSheets.add(genericSheet1);

		RGenericSheet genericSheet2 = new RGenericSheet(
				"2.Top "+mdrInput+" Values & Null Value");
		genericSheet2.setPostActionEnabled(true);
		genericSheet2.setCustomMergeRegion(customMergeRegion);

		List<RDataTable> listOfDataTable2 = new ArrayList<RDataTable>();
		listOfDataTable2.add(new RDataTable(metaHeader2));

		RDataTable dataTable2 = new RDataTable(false, secondTabQuery);
		dataTable2.setEnableDefaultStyles(true);
		dataTable2.setEnableColumnFormula(true);
		dataTable2.setCustomStyles(columnStyleMetaData);
		dataTable2.setFormulaForColumns(formulaMetaData);
		listOfDataTable2.add(dataTable2);

		genericSheet2.setTables(listOfDataTable2);
		genericSheet2.setBookName(fileName);
		mdrSheets.add(genericSheet2);
		mdrWorkBook.setWorksheets(mdrSheets);
		mdrWorkBookFile.add(mdrWorkBook);

		RProcessRegistry processRegister = new RProcessRegistry();
		processRegister.init();
		for (RWorkBook workBook : mdrWorkBookFile) {
			workBook.setFileID(fileID);
			processRegister.registerProcess(
					new RProcessKey(workBook.getLocation(), "UserID"
							+ System.currentTimeMillis()), workBook);

		}

		db.endConnection();

		processRegister.shutDown();
		while (!processRegister.isProcessTerminated()) {

		}

	}

	public String getQuery(int tabIndex,String reportid) {
		String query = "";
		switch (tabIndex) {
		case 1:
			/*query = " "
					+ "SELECT a.layoutid, C.DATATYPE AS DATATYPE, "
					+ "C.FILENAME AS DATASOURCE, "
					+ "'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||(select distinct(SHORTPAYOR) from imp_layouts where layoutid=a.layoutid) AS TABLENAME, "
					+ "A.FIELDNAME AS FIELDNAME, "
					+ "A.COUNT_DISTINCT AS NUMOFUNIQUEVALUES, "
					+ "A.TOTALCOUNT, "
					+ "( A.TOTALCOUNT - A.COUNT_NOTNULL ) AS NUMOFNULLS, "
					+ "'' AS PERCENTPOPULATED, "
					+ "A.PAIDAMT TOTALPAIDAMT, "
					+ "NVL(B.PAIDAMT, 0) AS NULLPAIDAMT, "
					+ "'' AS NULLPAIDPERCENT "
					+ "FROM "
					+ "( "
					+ "SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='MDR' WHERE FILEID IN ('"
					+ fileID
					+ "')  AND TYPEVALUE = 'DENSITY' ) "
					+ ") A "
					+ "LEFT JOIN "
					+ "( "
					+ "SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='MDR'  	WHERE FILEID IN ('"
					+ fileID
					+ "') AND TYPEVALUE = 'TOPREC-NULL') "
					+ ") B "
					+ "ON A.FILEID = B.FILEID "
					+ "AND A.COLUMN_ID = B.COLUMN_ID "
					+ "AND A.FIELDNAME = B.FIELDNAME "
					+ "AND A.sublayoutid = B.sublayoutid "
					+ " LEFT JOIN "
					+ "( "
					+ "SELECT FILEID||'_'||DMFILEID AS FILEID,DATATYPE,FILENAME  FROM IMP_MAIN_LOG "
					+ "WHERE EXISTS (select distinct(fileid) from imp_inventory_rep_log_details b where reportid='"+reportid+"' and a.fileid||'_'||a.dmfileid=b.fileid)"
					+ ")C " + "ON A.FILEID=C.FILEID "
					+ "ORDER BY C.FILENAME, TABLENAME, TO_NUMBER(A.COLUMN_ID) ";*/
			query="SELECT a.layoutid, C.DATATYPE AS DATATYPE, C.FILENAME AS DATASOURCE, "
				+" 'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||(select distinct(SHORTPAYOR) from imp_layouts where layoutid=a.layoutid) "
				+" AS TABLENAME, A.FIELDNAME AS FIELDNAME, A.COUNT_DISTINCT AS NUMOFUNIQUEVALUES, A.TOTALCOUNT, " 
				+" ( A.TOTALCOUNT - A.COUNT_NOTNULL ) AS NUMOFNULLS, '' AS PERCENTPOPULATED, A.PAIDAMT TOTALPAIDAMT, " 
				+" NVL(B.PAIDAMT, 0) AS NULLPAIDAMT, '' AS NULLPAIDPERCENT FROM ( SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, " 
				+" f.sublayoutid FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='MDR' "
				+" join imp_inventory_rep_log_details i "
				+" on f.fileid=i.fileid "
				+" and i.reportid='"+reportid+"' " 
				+" where TYPEVALUE = 'DENSITY' ) ) A " 
				+" LEFT JOIN ( SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM " 
				+" RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='MDR' "  
				+" join imp_inventory_rep_log_details i "
				+" on f.fileid=i.fileid "
				+" and i.reportid='"+reportid+"'             WHERE  TYPEVALUE = 'TOPREC-NULL') ) " 
				+" B ON A.FILEID = B.FILEID AND A.COLUMN_ID = B.COLUMN_ID AND A.FIELDNAME = B.FIELDNAME AND A.sublayoutid=B.sublayoutid " 
   
  				+" LEFT JOIN " 
  				+" (  SELECT FILEID||'_'||DMFILEID AS FILEID,DATATYPE,FILENAME  FROM IMP_MAIN_LOG   )  C  ON A.FILEID=C.FILEID " 
   
   				+" ORDER BY C.FILENAME, TABLENAME, TO_NUMBER(A.COLUMN_ID)";
			
			log.debug(" MDRReport Query1 " + query);
		
			break;
		case 2:
			/*query = "SELECT   a.layoutid, C.DATATYPE AS DATATYPE, "
					+ "C.FILENAME AS DATASOURCE, "
					+ "'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||(select distinct(SHORTPAYOR) from imp_layouts where layoutid=a.layoutid) AS TABLENAME, "
					+ "A.FIELDNAME AS FIELDNAME, "
					+ "A.COLVALUE      AS DATAVALUES, "
					+ "B.TOTALCOUNT    TOTALRECORDCOUNT, "
					+ "A.COUNT_NOTNULL AS OFRECORDS, "
					+ "''              AS PERCENTTOT,"
					+ " B.PAIDAMT       TOTALPAIDAMT, "
					+ "A.PAIDAMT       AS PAIDAMT, "
					+ "''              AS PERCENTPAIDAMT "
					+

					"FROM "
					+

					" (SELECT * FROM "
					+ "(SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='MDR' "
					+ " WHERE FILEID IN ('"
					+ fileID
					+ "')  AND TYPEVALUE LIKE 'TOPREC%' ) "
					+ ") A "
					+ "LEFT JOIN "
					+ "( "
					+ "SELECT FILEID, "
					+ " FIELDNAME, "
					+ " MAX(TOTALCOUNT) AS TOTALCOUNT, "
					+ "MAX(PAIDAMT)    AS PAIDAMT,sublayoutid FROM (SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn "
					+ " AND REPORTTYPE='MDR' WHERE FILEID IN('"
					+ fileID
					+ "') AND TYPEVALUE = 'DENSITY') ) "
					+ "	GROUP BY FILEID,sublayoutid, "
					+ " FIELDNAME) B "
					+ " ON A.FILEID = B.FILEID "
					+ " AND A.FIELDNAME = B.FIELDNAME "
					+ "AND A.sublayoutid = B.sublayoutid "
					+ " LEFT JOIN "
					+ "( "
					+ " SELECT FILEID||'_'||DMFILEID AS FILEID,DATATYPE,FILENAME  FROM IMP_MAIN_LOG "
					+ " EXISTS (select distinct(fileid) from imp_inventory_rep_log_details b where reportid='"+reportid+"' and a.fileid||'_'||a.dmfileid=b.fileid)"
					+ "') "
					+ " )C "
					+ " ON A.FILEID=C.FILEID "
					+ " ORDER BY C.FILENAME, TABLENAME ,TO_NUMBER(A.COLUMN_ID) ,TO_NUMBER(OFRECORDS) DESC ";*/
			query = "SELECT   a.layoutid, C.DATATYPE AS DATATYPE, C.FILENAME AS DATASOURCE, "
					+" 'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||(select distinct(SHORTPAYOR) from imp_layouts "
					+" where layoutid=a.layoutid) AS TABLENAME, A.FIELDNAME AS FIELDNAME, A.COLVALUE      AS DATAVALUES, B.TOTALCOUNT    TOTALRECORDCOUNT, "
					+" A.COUNT_NOTNULL AS OFRECORDS, '' AS PERCENTTOT, B.PAIDAMT       TOTALPAIDAMT, A.PAIDAMT       AS PAIDAMT, " 
					+" ''              AS PERCENTPAIDAMT FROM "  
					+" (SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, f.sublayoutid " 
							+" FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='MDR' " 
							+" join imp_inventory_rep_log_details i "
							+" on f.fileid=i.fileid "
							+" and i.reportid='"+reportid+"' "
							+" WHERE  TYPEVALUE LIKE 'TOPREC%' ) ) A "
							+" LEFT JOIN " 
					+" ( SELECT FILEID, "
					 +" FIELDNAME,  MAX(TOTALCOUNT) AS TOTALCOUNT, MAX(PAIDAMT)    AS PAIDAMT,sublayoutid FROM " 
					 +" (SELECT * FROM (SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_MDR e JOIN rpt_main_log f on e.sn=f.sn " 
					  +" AND REPORTTYPE='MDR'   join imp_inventory_rep_log_details i "
					  +" on f.fileid=i.fileid "
					  +" and i.reportid='"+reportid+"' "
					  +" WHERE TYPEVALUE = 'DENSITY') ) "   
					  	+" GROUP BY FILEID,sublayoutid,  FIELDNAME) B "
					  	+" ON A.FILEID = B.FILEID  AND A.FIELDNAME = B.FIELDNAME AND A.sublayoutid = B.sublayoutid " 
		
			+" LEFT JOIN " 
			+" (  SELECT FILEID||'_'||DMFILEID AS FILEID,DATATYPE,FILENAME  FROM IMP_MAIN_LOG   )  C  ON A.FILEID=C.FILEID " 
        	
 	+" ORDER BY C.FILENAME, TABLENAME ,TO_NUMBER(A.COLUMN_ID) ,TO_NUMBER(OFRECORDS) DESC";
			
			log.debug(" MDRReport Query2 " + query);
			break;

		}
		return query;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}
}
