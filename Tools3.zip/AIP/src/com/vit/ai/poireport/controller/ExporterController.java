/* 
 *Class Name : ExporterController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.vit.ai.poireport.format.ExcelFormattingStyles;

/**
 * Class to populate excel file from DataTable
 * 
 * @author Sagar Shrestha
 * 
 * @modified By Binesh Sah
 * 
 * @version 17 April 2014
 */
@ManagedBean
@ViewScoped
public class ExporterController implements Serializable {

	private static final long serialVersionUID = 1L;

	public void postProcessXLSX(Object document) {
		try{
			
		

		XSSFWorkbook wb = (XSSFWorkbook) document;

		ExcelFormattingStyles eF = new ExcelFormattingStyles();
		Map<String, CellStyle> styles = new HashMap<String, CellStyle>();
		styles = eF.getStyler(wb);

		XSSFSheet sheet = wb.getSheetAt(0);

		/* Removing merged header row */
		Row mergedRow = sheet.getRow(5);
		Cell cell = mergedRow.getCell(0);
		sheet.removeMergedRegion(cell.getColumnIndex());

		/* Formatting header */
		Row header = sheet.getRow(5);
		for (int i = 0; i < header.getPhysicalNumberOfCells(); i++) {
			header.getCell(i).setCellStyle(styles.get("heading_style"));
		}

		/* Putting styles */
		Row normalRow;
		for (int i = 6; i <= sheet.getLastRowNum(); i++) {
			normalRow = sheet.getRow(i);
			for (int j = 0; j < normalRow.getPhysicalNumberOfCells(); j++) {
				normalRow.getCell(j).setCellStyle(styles.get("normal_style"));
				
			}
		}

		sheet.removeRow(sheet.getRow(4));
		}catch(Exception e){
			FacesContext context = FacesContext.getCurrentInstance();

			context.addMessage(null, new FacesMessage(
					"Error Occured. Please try again "+e.getMessage()));
					
				}
			}
}
