/* 
 *Class Name : DSRReportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.RWorkBookSheet;
import com.vit.ai.poireport.writer.RGenericSheet;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to generate data summary report
 * 
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.1 04 June 2014
 */
public class DSRReportController extends AbstractController implements
		Serializable {
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(DSRReportController.class
			.getName());
	private String fileID = "";
	private String clientID = "";

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	private String filterCondition;
	private String medRxquery;
	private String mmQuery;
	private String srcFileQuery;
	private String claimsDetailQuery;
	private String algorithmsQuery;
	private String dataExceptionQuery;
	private String dateNumberExcepQuery;

	ConnectDB db = new ConnectDB();
	CustomUtility objCU = new CustomUtility();

	public DSRReportController() {

	}

	public void process(String fileID, String fileName, String clientID) {
		this.fileID = fileID;
		this.clientID = clientID.split("-")[0].trim();
		setFilterCondition(" WHERE FILEID IN('" + this.fileID + "') ");
		db.initialize();
		String monthsVal[][] = this.getMonthsVal();
		setQueries(monthsVal);
		String monthHeader = "";
		int totalMonths = monthsVal[0].length;

		for (int k = 0; k < totalMonths; k++) {
			monthHeader = monthHeader + "," + monthsVal[0][k];
			objCU.IntToLetters(k + 5);
		}

		String medAndRxHeader = "LayoutID,Filename,Received Month,File ID,Payor Name,Table Name,Group Name,Data Type-Date"
				+ monthHeader;
		String mmHeader = "Filename,Received Month,File ID,Payor Name,Table Name,Group Name,Data Type-Count"
				+ monthHeader;
		String sfHeader = "File ID,Filename,Tablename,Received Month, Category, Employer Group, Payor, Billed Amount,"
				+ "Allowed Amount, Plan Paid Amount, Employee Paid Amount, Employee Count, Member Count, Record Count";
		String cdHeader = "FileID,FileName,Payor,Group,Table Name,Received Month,Data and Data Type, Month, Billed Amount, Allowed Amount, Plan Paid Amount,"
				+ " Employee Paid Amount, Employee Count, Member Count, Record Count";
		String algorithmsheader = "LAYOUTID,LAYOUTTYPE,PAIDAMT,ENRID,MEMID,BILLEDAMT,COVERAGECODE,EFFDATE,PAIDDATE,SERVICEDATE,ALLOWEDAMT,ENRPAID,TERMDATE,FILLDATE,END_DATE";
		// String dexcepheader =
		// "FileID	,Filename,Category,Field Name,Function Check,Function Check Values,Actual Values";
		// String dnmbrexcepheader =
		// "FileID,Filename,Tablename,Category,Payor,FieldName,Layout Format,Source Value,Value Count,Total Record Count";

		List<RWorkBook> dsrWorkBookFile = new ArrayList<RWorkBook>();

		RWorkBook dsrWorkBook = new RWorkBook();
		dsrWorkBook.setName(fileName);
		dsrWorkBook.setLocation(AIConstant.FSR_REPORT_DUMP_LOCATION);

		dsrWorkBook.setTemplateUsed(true);
		dsrWorkBook.setTemplateName(AIConstant.REPORT_TEMPLATES_PATH
				+ AIConstant.FSR_TEMPLATE_NAME_H);
		List<RWorkBookSheet> dsrSheets = new ArrayList<RWorkBookSheet>();

		/* 1.Med & Rx */
		RGenericSheet medRxSheet = new RGenericSheet("1. Med & Rx");
		medRxSheet.setPostActionEnabled(true);

		List<RDataTable> listOfDataTables = new ArrayList<RDataTable>();
		RDataTable dataTable;
		listOfDataTables.add(new RDataTable(medAndRxHeader));

		dataTable = new RDataTable(false, medRxquery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		dataTable.setMonthsHeader(monthsVal);
		dataTable.setStyleUsingHeader("DOLLAR");
		listOfDataTables.add(dataTable);

		medRxSheet.setTables(listOfDataTables);
		medRxSheet.setBookName(fileName);
		dsrSheets.add(medRxSheet);

		/* 2.Member Months */

		RGenericSheet mmSheet = new RGenericSheet("2. Member Months");
		mmSheet.setPostActionEnabled(true);

		listOfDataTables = new ArrayList<RDataTable>();
		listOfDataTables.add(new RDataTable(mmHeader));

		dataTable = new RDataTable(false, mmQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		dataTable.setMonthsHeader(monthsVal);
		dataTable.setStyleUsingHeader("NUMBER");
		listOfDataTables.add(dataTable);

		mmSheet.setTables(listOfDataTables);
		mmSheet.setBookName(fileName);
		dsrSheets.add(mmSheet);

		/* 3.Source Files */

		RGenericSheet sfSheet = new RGenericSheet("3. Source Files");
		sfSheet.setPostActionEnabled(true);

		listOfDataTables = new ArrayList<RDataTable>();
		listOfDataTables.add(new RDataTable(sfHeader));

		dataTable = new RDataTable(false, srcFileQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		listOfDataTables.add(dataTable);

		sfSheet.setTables(listOfDataTables);
		sfSheet.setBookName(fileName);
		dsrSheets.add(sfSheet);

		/* 4.Claims Detail */

		RGenericSheet cdSheet = new RGenericSheet("4. Claims Detail");
		cdSheet.setPostActionEnabled(true);

		listOfDataTables = new ArrayList<RDataTable>();
		listOfDataTables.add(new RDataTable(cdHeader));

		dataTable = new RDataTable(false, claimsDetailQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		listOfDataTables.add(dataTable);

		cdSheet.setTables(listOfDataTables);
		cdSheet.setBookName(fileName);
		dsrSheets.add(cdSheet);
		listOfDataTables = new ArrayList<RDataTable>();
		RGenericSheet algoSheet = new RGenericSheet("5. Algorithms");
		algoSheet.setPostActionEnabled(true);

		listOfDataTables.add(new RDataTable(algorithmsheader));

		dataTable = new RDataTable(false, algorithmsQuery);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		listOfDataTables.add(dataTable);
		algoSheet.setTables(listOfDataTables);
		algoSheet.setBookName(fileName);
		dsrSheets.add(algoSheet);

		/* add sheets into workbook */
		dsrWorkBook.setWorksheets(dsrSheets);
		dsrWorkBookFile.add(dsrWorkBook);

		RProcessRegistry processRegister = new RProcessRegistry();
		processRegister.init();
		for (RWorkBook workBook : dsrWorkBookFile) {
			workBook.setFileID(fileID);
			processRegister.registerProcess(
					new RProcessKey(workBook.getLocation(), "UserID"
							+ System.currentTimeMillis()), workBook);

		}

		db.endConnection();

		processRegister.shutDown();
		while (!processRegister.isProcessTerminated()) {

		}

	}

	public void setQueries(String[][] months) {
		this.medRxquery = "SELECT FILEID,a.Payor ,'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||a.shortpayor AS TABLENAME ,EMPGRP,FLAG";

		String tempMMQuery = "SELECT a.FILEID,a.Payor , 'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||a.shortpayor AS TABLENAME"
				+ " ,EMPGRP,"
				+ "CASE WHEN UPPER(CoverageCode)='MED' THEN 'Medical-Member Count'  ELSE UPPER(CoverageCode)||'-Member Count' END AS FLAG ";

		this.mmQuery = "SELECT B.FILENAME,To_Char(To_Date(b.processdate,'YYYY-MM-DD HH24:mi:ss'),'YYYYMM') ReceivedMonth,A.* FROM "
				+ " ( SELECT a.FILEID,a.Payor , 'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||a.shortpayor "
				+ " AS TABLENAME ,EMPGRP,CASE WHEN UPPER(CoverageCode)='MED' THEN 'Medical-Employee Count'  ELSE UPPER(CoverageCode)||'-Employee Count' END AS FLAG ";

		for (int k = 0; k < months[0].length; k++) {
			this.medRxquery += " ,SUM(CASE WHEN YYMM = '" + months[0][k]
					+ "' THEN PAIDAMOUNT ELSE 0 END)";
			this.mmQuery += " ,SUM(CASE WHEN YYMM = '" + months[0][k]
					+ "' THEN EMPCOUNT ELSE 0 END)";
			tempMMQuery += " ,SUM(CASE WHEN YYMM = '" + months[0][k]
					+ "' THEN MEMCOUNT ELSE 0 END)";
		}

		this.medRxquery += " FROM  ( SELECT e.* , f.fileid,f.layoutid, f.sublayoutid,payor,shortpayor FROM RPT_DSR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='DSR' "
				+ " LEFT JOIN IMP_LAYOUTS C ON f.LAYOUTID = C.LAYOUTID "
				+ " WHERE  f.FILEID IN ('"
				+ this.fileID
				+ "') AND  Upper(FLAG) LIKE '%DATE%'  ) A "
				+ " GROUP BY FILEID,EMPGRP,FLAG,layoutid, sublayoutid , payor , shortpayor ORDER BY FILEID,EMPGRP,FLAG  ) A "
				+ " LEFT JOIN IMP_MAIN_LOG B ON A.FILEID = B.FILEID||'_'||B.DMFILEID ";

		this.medRxquery = "SELECT A.LayoutID  B.FILENAME, To_Char(To_Date(b.processdate,'YYYY-MM-DD HH24:mi:ss'),'YYYYMM') ReceivedMonth,A.* FROM ( "
				+ this.medRxquery;

		this.mmQuery += " FROM( SELECT e.* , f.fileid,f.layoutid, f.sublayoutid,payor,shortpayor FROM RPT_DSR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='DSR' "
				+ " LEFT JOIN IMP_LAYOUTS C ON f.LAYOUTID = C.LAYOUTID "
				+ " WHERE FILEID IN ('"
				+ this.fileID
				+ "') AND Upper(FLAG) IN('MEMBER MONTH') ) a "
				+ " GROUP BY FILEID,EMPGRP,CASE WHEN UPPER(CoverageCode)='MED' THEN 'Medical-Employee Count' "
				+ " ELSE UPPER(CoverageCode)||'-Employee Count' END , layoutid, sublayoutid,payor , shortpayor ORDER BY FILEID,EMPGRP,FLAG  ) A "
				+ " LEFT JOIN IMP_MAIN_LOG B ON A.FILEID = B.FILEID||'_'||B.DMFILEID ";
		this.mmQuery = "SELECT a.* FROM ( " + this.mmQuery;

		tempMMQuery += " FROM ( SELECT e.* , f.fileid,f.layoutid, f.sublayoutid,payor , shortpayor FROM RPT_DSR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='DSR' "
				+ "LEFT JOIN IMP_LAYOUTS C ON f.LAYOUTID = C.LAYOUTID "
				+ " WHERE FILEID IN  ('"
				+ this.fileID
				+ "')  AND Upper(FLAG) IN('MEMBER MONTH') ) A "
				+ " GROUP BY FILEID,EMPGRP,CASE WHEN UPPER(CoverageCode)='MED' THEN 'Medical-Member Count'  ELSE UPPER(CoverageCode)||'-Member Count' END , layoutid, sublayoutid,payor ,shortpayor ORDER BY FILEID,EMPGRP,FLAG  ) A "
				+ " LEFT JOIN IMP_MAIN_LOG B ON A.FILEID = B.FILEID||'_'||B.DMFILEID  ) a ORDER BY 3 ";

		tempMMQuery = "SELECT B.FILENAME,To_Char(To_Date(b.processdate,'YYYY-MM-DD HH24:mi:ss'),'YYYYMM') ReceivedMonth,"
				+ " A.* FROM ( " + tempMMQuery;// +" ) A "

		this.mmQuery = this.mmQuery + " UNION ALL " + tempMMQuery;

		this.srcFileQuery = " SELECT A.FILEID,NVL(A.FILENAME,'No File Name') AS FileName,'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||shortpayor AS TABLENAME, "
				+ " To_Char(To_Date(b.processdate,'YYYY-MM-DD HH24:mi:ss'),'YYYYMM') ReceivedMonth , B.DATATYPE AS CATEGORY, A.EMPGRP, "
				+ " C.PAYOR,Nvl(BILLEDAMOUNT,0),NVL(ALLOWEDAMOUNT,0),NVL(PAIDAMOUNT,0),NVL(EMPLOYEEPAID,0),  NVL(EMPCOUNT,0),NVL(MEMCOUNT,0),NVL(RECORDCOUNT,0) "
				+ " FROM( SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_DSR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='DSR' WHERE  f.FILEID IN ('"
				+ this.fileID
				+ "')   AND  Upper(FLAG) = ('SOURCE FILE') ) A "
				+ " LEFT JOIN IMP_MAIN_LOG B ON A.FILEID = B.FILEID||'_'||B.DMFILEID LEFT JOIN IMP_LAYOUTS C ON B.LAYOUTID = C.LAYOUTID ORDER BY CATEGORY,RCVMONTH,fileid,PAIDAMOUNT ";

		this.claimsDetailQuery = "SELECT  A.FILEID,NVL(A.FILENAME,'No File Name') AS FileName,C.PAYOR,A.EMPGRP, "
				+ "'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||shortpayor AS TABLENAME,To_Char(To_Date(b.processdate,'YYYY-MM-DD HH24:mi:ss'),'YYYYMM')"
				+ " ReceivedMonth,A.FLAG,A.YYMM,NVL(A.BILLEDAMOUNT,0),NVL(A.ALLOWEDAMOUNT,0),NVL(A.PAIDAMOUNT,0), NVL(A.EMPLOYEEPAID,0),NVL(A.EMPCOUNT,0),"
				+ " NVL(A.MEMCOUNT,0),NVL(A.RECORDCOUNT,0)  "
				+ " FROM "
				+ " ( SELECT e.* , f.fileid,f.layoutid, f.sublayoutid FROM RPT_DSR e JOIN rpt_main_log f on e.sn=f.sn AND REPORTTYPE='DSR' WHERE  f.FILEID IN  ('"
				+ this.fileID
				+ "')   AND  Upper(FLAG) LIKE '%DATE%' ) A "
				+ " LEFT JOIN IMP_MAIN_LOG B ON A.FILEID = B.FILEID||'_'||B.DMFILEID LEFT JOIN IMP_LAYOUTS C ON B.LAYOUTID = C.LAYOUTID ORDER BY 1,FLAG,TO_DATE(YYMM,'YYYYMM') ";

		this.algorithmsQuery = "SELECT  a.LAYOUTID,datatype,nvl(PAIDAMT,'NULL') AS PAIDAMT  ,Nvl(ENRID,'NULL') AS ENRID, "
				+ " Nvl(MEMID,'NULL') AS MEMID ,Nvl(BILLEDAMT,'NULL') AS BILLEDAMT ,Nvl(COVERAGECODE,NULL) AS COVERAGECODE ,"
				+ " Nvl(EFFDATE,'NULL') AS EFFDATE , Nvl(PAIDDATE,'NULL') AS PAIDDATE ,Nvl(SERVICEDATE,'NULL') AS SERVICEDATE,Nvl(ALLOWEDAMT,'NULL') AS ALLOWEDAMT,"
				+ " Nvl(ENRPAID,'NULL') AS ENRPAID, Nvl(TERMDATE,'NULL') AS TERMDATE , Nvl(FILLDATE,'NULL') AS FILLDATE  ,Nvl(END_DATE,'NULL') AS END_DATE "
				+ " FROM (   SELECT * FROM ( "
				+ "SELECT COALESCE(C.LAYOUTID,B.LAYOUTID) AS LAYOUTID ,COALESCE(b.TGTFIELD,c.TGTFIELD) AS TGTFIELD , COALESCE(b.RULE,c.RULE,c.SRCFIELD) AS RULE  FROM ( "
				+ " (SELECT * FROM importdb.PS_RULES_CLIENT WHERE LAYOUTID IN ('"
				+ getLayoutID()
				+ "')  ) b "
				+ " full join "
				+ " (SELECT * FROM importdb.PS_RULES_MASTER WHERE LAYOUTID IN ('"
				+ getLayoutID()
				+ "' ))  c "
				+ " ON c.TGTFIELD = B.TGTFIELD AND b.layoutid=c.layoutid  ) )   a"
				+ " WHERE   TGTFIELD in ('PAIDAMT'  ,'ENRID','MEMID','BILLEDAMT','COVERAGECODE','EFFDATE' , 'PAIDDATE','SERVICEDATE','ALLOWEDAMT','ENRPAID', 'TERMDATE','FILLDATE','END_DATE') ) "
				+ " pivot ( Max(rule)  FOR  TGTFIELD IN    ('PAIDAMT' as PAIDAMT,'ENRID' as ENRID,'MEMID' AS MEMID,'BILLEDAMT' AS BILLEDAMT,'COVERAGECODE' AS COVERAGECODE "
				+ ",'EFFDATE' AS EFFDATE , "
				+ " 'PAIDDATE' AS PAIDDATE,'SERVICEDATE' AS SERVICEDATE,'ALLOWEDAMT' AS ALLOWEDAMT,'ENRPAID' AS ENRPAID, 'TERMDATE' AS TERMDATE , 'FILLDATE' as FILLDATE, 'END_DATE' AS END_DATE) )  a "
				+ " left JOIN importdb.imp_layouts b ON a.layoutid=b.layoutid";

		this.dataExceptionQuery = " SELECT FILEID ,  FILENAME ,   DATA_TYPE  ,   FIELD_NAME  ,   CHECKTYPE ,  CHECKDETAIL  ,RESULT "
				+ " from ( "
				+ " SELECT   a.fileid,b.filename,b.datatype as DATA_TYPE  ,FIELDNAME AS FIELD_NAME,checktype, checkdetail, result, "
				+

				" CASE WHEN CHECKTYPE  IN ('COLSUM','COLSUMFIXED') AND RESULT = 0.00 THEN 1 "
				+ " WHEN CHECKTYPE  IN ('CHKVAL','CHKVALFIXED') AND exception_check(checkdetail,result)=1 "
				+ " THEN 1 END AS excep "
				+ "from "
				+ " imp_file_stats_log  a "
				+ " JOIN imp_main_log b "
				+ " ON a.fileid=b.fileid||'_'||b.dmfileid    AND	a.fileid IN ('"
				+ this.fileID
				+ "') ) where excep='1' ORDER BY fileid,FIELD_NAME ";

		this.dateNumberExcepQuery = "SELECT a.fileid,b.filename DATA_SOURCE, 'AI_'||a.layoutid||'_'||a.sublayoutid||'_'||c.shortpayor AS TABLENAME,b.datatype DATA_TYPE , c.payor,Upper(a.colname ) FIELD_NAME , "
				+ " a.dataformat LAYOUT_FORMAT, Nvl(flval,'BLANKNULL') SOURCE_VALUE ,  a.rc RECORD_COUNT ,import_record_cnt "
				+ " FROM "
				+ " (SELECT e.* , f.FILEID, f.layoutid,f.sublayoutid FROM rpt_chk_date_number e,rpt_main_log f WHERE e.sn=f.sn "
				+ " AND reporttype ='DTE_NUM_CHK'   ) a,"
				+ " imp_main_log b  , imp_layouts   c "
				+ " WHERE "
				+ " a.fileid=b.fileid||'_'||b.dmfileid"
				+ " AND b.layoutid=c.layoutid "
				+ " and 	a.fileid IN  ('"
				+ this.fileID + "') " + " ORDER BY  a.fileid , FLVAL,rc";

		log.info(" 1. DSR Report Controller " + this.algorithmsQuery);
		log.info(" 2. DSR Report Controller " + this.dateNumberExcepQuery);
		log.info(" 3. DSR Report Controller " + this.dataExceptionQuery);
		log.info(" 4. DSR Report Controller " + this.claimsDetailQuery);
		log.info(" 5. DSR Report Controller " + this.srcFileQuery);

	}

	private String getLayoutID() {
		String layoutID = "";
		String query = "Select distinct layoutid from imp_main_log where fileid||'_'||dmfileid in ('"
				+ this.fileID + "')  and clientid ='" + this.clientID + "'";

		List<List<String>> rs = db.resultSetToListOfList(query);
		for (int i = 1; i < rs.size(); i++) {
			layoutID = layoutID + "," + rs.get(i).get(0);
		}
		if (layoutID.startsWith(",")) {
			layoutID = layoutID.substring(1);
			layoutID = layoutID.replaceAll(",", "','");
		}

		return layoutID;
	}

	public String[][] getMonthsVal() {

		CustomUtility objCU = new CustomUtility();

		return db.getAllRows(getMonthsQuery(objCU.getStartDate(),
				objCU.getEndDate()));
	}

	public String getMonthsQuery(String startDate, String endDate) {

		String queryMonths = "SELECT round(Months_Between(Last_Day(To_Date('"
				+ endDate + "','YYYY-MM-DD')),To_Date('" + startDate
				+ "','YYYY-MM-DD'))) FROM dual";

		String queryMonth = "";

		try {
			String outputMonths[][] = db.getAllRows(queryMonths);

			queryMonth = "SELECT To_Char(To_Date('" + startDate
					+ "','YYYY-MM-DD'),'YYYYMM') YYYYMM FROM dual ";

			for (int i = 1; i < Integer.parseInt(outputMonths[0][0]); i++) {
				queryMonth = queryMonth + " UNION ALL "
						+ "SELECT To_Char(Add_Months(To_Date('" + startDate
						+ "','YYYY-MM-DD')," + i
						+ "),'YYYYMM') YYYYMON FROM dual";
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(queryMonth);
			log.debug(queryMonths);
			displayErrorMessageToUser(e.toString(), "ERROR");
			return queryMonth;
		}

		return queryMonth;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getMedRxquery() {
		return medRxquery;
	}

	public void setMedRxquery(String medRxquery) {
		this.medRxquery = medRxquery;
	}

	public String getMmQuery() {
		return mmQuery;
	}

	public void setMmQuery(String mmQuery) {
		this.mmQuery = mmQuery;
	}

	public String getSrcFileQuery() {
		return srcFileQuery;
	}

	public void setSrcFileQuery(String srcFileQuery) {
		this.srcFileQuery = srcFileQuery;
	}

	public String getClaimsDetailQuery() {
		return claimsDetailQuery;
	}

	public void setClaimsDetailQuery(String claimsDetailQuery) {
		this.claimsDetailQuery = claimsDetailQuery;
	}

	public String getAlgorithmsQuery() {
		return algorithmsQuery;
	}

	public void setAlgorithsQuery(String algorithmsQuery) {
		this.algorithmsQuery = algorithmsQuery;
	}

	public String getFilterCondition() {
		return filterCondition;
	}

	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}

	public String getDateNumberExcepQuery() {
		return dateNumberExcepQuery;
	}

	public void setDateNumberExcepQuery(String dateNumberExcepQuery) {
		this.dateNumberExcepQuery = dateNumberExcepQuery;
	}

	public String getDataExceptionQuery() {
		return dataExceptionQuery;
	}

	public void setDataExceptionQuery(String dataExceptionQuery) {
		this.dataExceptionQuery = dataExceptionQuery;
	}

}
