/* 
 *Class Name : GenericReportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.genericreports.controller.AddNewReport;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.RWorkBookSheet;
import com.vit.ai.poireport.writer.RGenericSheet;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;
import com.vit.ai.utils.ReportUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 04 Sep 2014
 */
public class GenericReportController implements Serializable {

	private static final long serialVersionUID = 1L;
	private String fileID = "";
	private String filterCondition = "";
	private String reportname = "";
	private String query = "";
	ReportUtility reportUtility;

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public void process(AddNewReport obj, String query, String fileName,
			String sheetname, String[] custommerge, boolean template,
			String templateName, String formula, String Username) {
		this.reportname = fileName;
		String querytobeExecuted = query;
		List<RWorkBook> udWorkBookFile = new ArrayList<RWorkBook>();

		RWorkBook UdWorkBook = new RWorkBook();
		UdWorkBook.setName(fileName + "_" + Username);
		UdWorkBook.setLocation(AIConstant.UD_REPORT_DUMP_LOCATION);

		UdWorkBook.setTemplateUsed(template);
		if (template) {
			UdWorkBook.setTemplateName(templateName);
		}
		List<RWorkBookSheet> udSheets = new ArrayList<RWorkBookSheet>();

		RGenericSheet udsheet1 = new RGenericSheet(sheetname);

		if (template) {
			udsheet1.setSheetCreatedInTemplate(true);
		}
		udsheet1.setPostActionEnabled(true);
		List<RDataTable> listOfDataTables = new ArrayList<RDataTable>();
		RDataTable dataTable;
		ConnectDB db1 = new ConnectDB();
		db1.initialize();
		List<List<String>> rs = db1.resultSetToListOfList("select * from ("
				+ query + ")where 1=0");
		db1.endConnection();
		String header = "";
		if (rs != null && rs.size() > 0) {
			header = rs.get(0).toString().replaceAll("\\[", "")
					.replaceAll("\\]", "");
		}
		listOfDataTables.add(new RDataTable(header));

		dataTable = new RDataTable(false, querytobeExecuted);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(false);
		listOfDataTables.add(dataTable);
		udsheet1.setTables(listOfDataTables);
		udsheet1.setBookName(fileName);
		udSheets.add(udsheet1);

		/* add sheets into workbook */
		UdWorkBook.setWorksheets(udSheets);
		udWorkBookFile.add(UdWorkBook);

		RProcessRegistry processRegister = new RProcessRegistry();
		processRegister.init();
		for (RWorkBook workBook : udWorkBookFile) {
			processRegister.registerProcess(
					new RProcessKey(workBook.getLocation(), "UserID"
							+ System.currentTimeMillis()), workBook);

		}

		processRegister.shutDown();
		while (!processRegister.isProcessTerminated()) {

		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		String dml = "Update aip_generic_reports set Runstatus='COMPLETED' where reportid='"
				+ obj.getReportid() + "'";
		db.executeDML(dml);
		db.endConnection();

	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFilterCondition() {
		return filterCondition;
	}

	public void setFilterCondition(String filterCondition) {
		this.filterCondition = filterCondition;
	}

}
