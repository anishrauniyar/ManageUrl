/* 
 *Class Name : InventoryReportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.RWorkBookSheet;
import com.vit.ai.poireport.writer.RGenericSheet;
import com.vit.ai.poireport.writer.RProcessKey;
import com.vit.ai.poireport.writer.RProcessRegistry;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to generate inventory report
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 03 Nov 2015
 */
public class TestDataExporter implements Serializable {

	private static final long serialVersionUID = 1L;
	private String fileID="";
	private String schema="tempimport";
	public TestDataExporter() {

	}

	

	
	

	public void processTestImportData(String layoutid,String aiQuery,String nrowsAIData,String aiTablename) {
		//ConnectDB db = new ConnectDB();
		this.fileID=layoutid;
		String aiHeader = "";
		if(nrowsAIData!=""){
			if(Character.isLetter(nrowsAIData.charAt(0))){
				nrowsAIData="20";
			}
			aiQuery = aiQuery.replaceAll("where rownum < 21", "where rownum < "+nrowsAIData);
		}else{
			nrowsAIData="20";
		}
		ConnectDB db = new ConnectDB();
		db.initialize(AIConstant.RAC_SERVER_NAME,
				AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID,
				AIConstant.TEST_SCHEMA_NAME, "LOCAL");
		
		List<List<String>> rs = db.resultSetToListOfList("SELECT COLUMN_NAME FROM  USER_TAB_COLUMNS WHERE TABLE_NAME='"+aiTablename+"' ORDER by COLUMN_ID asc");
		db.endConnection();
		
	
			if (rs.size() > 0) {
				for(int i=1;i<rs.size();i++){
				aiHeader=aiHeader+rs.get(i).get(0)+",";
				}
				//displayInfoMessageToUser(message, "SUCCESS");
			} else {
				//displayErrorMessageToUser("No Records to Display", "ERROR");
			}
		
		String header = ",,,,TOP "+nrowsAIData+" AI DATA , , , , , , , , , , , , , , ,  "
				+ "<NextRow> "+aiHeader;
			
				

		List<RWorkBook> mdrWorkBookFile = new ArrayList<RWorkBook>();

		RWorkBook mdrWorkBook = new RWorkBook();
		mdrWorkBook.setName(layoutid);
		mdrWorkBook.setLocation(AIConstant.TEMPORARY_FILE_LOCATION);
		List<RWorkBookSheet> mdrSheets = new ArrayList<RWorkBookSheet>();
		RDataTable dataTable = new RDataTable();

		RGenericSheet genericSheet1 = new RGenericSheet(layoutid);
		genericSheet1.setPostActionEnabled(true);

		List<RDataTable> listOfDataTables = new ArrayList<RDataTable>();
		listOfDataTables.add(new RDataTable(header));
		dataTable = new RDataTable(false, aiQuery,schema);
		dataTable.setEnableOverriddenStyles(false);
		dataTable.setEnableDefaultStyles(true);
		dataTable.setConditionalFormat(5);
		listOfDataTables.get(0).setProperty(layoutid);
		listOfDataTables.add(dataTable);
		genericSheet1.setTables(listOfDataTables);
		genericSheet1.setBookName(layoutid);

		mdrSheets.add(genericSheet1);
		mdrWorkBook.setWorksheets(mdrSheets);
		mdrWorkBookFile.add(mdrWorkBook);
		RProcessRegistry processRegister = new RProcessRegistry();
		processRegister.init();
		for (RWorkBook workBook : mdrWorkBookFile) {
			workBook.setFileID(fileID);
			processRegister.registerProcess(
					new RProcessKey(workBook.getLocation(), "UserID"
							+ System.currentTimeMillis()), workBook);

		}

		processRegister.shutDown();
		while (!processRegister.isProcessTerminated()) {

		}


	}

	/*
	


	public String genReleaseInvQuery(String fileid,String aiTableName) {
		String queryReport = "";
		System.out.println("File ID" + fileid+" And AI table "+aiTableName);
		queryReport = "SELECT * FROM "+aiTableName+" where rownum < "+ (21)  ;

		
		log.info("Inventroy by tag QUERY   :" + queryReport);

		return queryReport;
	}*/
}
