/* 
 *Class Name : RCell.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 26 May 2014
 */
public class RCell {
	private Object cellValue;
	private RCustomStyle customStyle;
	private String formula;

	public Object getCellValue() {
		return cellValue;
	}

	public void setCellValue(Object cellValue) {
		this.cellValue = cellValue;
	}

	public RCustomStyle getCustomStyle() {
		return customStyle;
	}

	public void setCustomStyle(RCustomStyle cellStyle) {
		this.customStyle = cellStyle;
	}

	public String getFormula() {
		return formula;
	}

	public void setFormula(String formula) {
		this.formula = formula;
	}
}
