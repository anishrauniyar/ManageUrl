/*
 *Class Name : RCommonModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

import org.apache.poi.ss.usermodel.Workbook;

import com.vit.ai.utils.ReportUtility;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 18 May 2014
 */
public class RCommonModel {
	protected Workbook workBook;

	protected ReportUtility reportUtility;

	public Workbook getWorkBook() {
		return workBook;
	}

	public void setWorkBook(Workbook workBook) {
		this.workBook = workBook;
	}

	public ReportUtility getReportUtility() {
		return reportUtility;
	}

	public void setReportUtility(ReportUtility reportUtility) {
		this.reportUtility = reportUtility;
	}
}
