/*
 *Class Name : RCustomStyle.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

import org.apache.poi.ss.usermodel.CellStyle;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 14 Aug 2014
 */
public class RCustomStyle {
	private int mergeUpto;

	private CellStyle cellStyle;

	public int getMergeUpto() {
		return mergeUpto;
	}

	public void setMergeUpto(int mergeUpto) {
		this.mergeUpto = mergeUpto;
	}

	public CellStyle getCellStyle() {
		return cellStyle;
	}

	public void setCellStyle(CellStyle cellStyle) {
		this.cellStyle = cellStyle;
	}

}
