/* 
 *Class Name : RCellIndex.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 29 june 2014
 */
public class RCellIndex {
	private int startIndex;
	private int endIndex;

	public RCellIndex() {

	}

	public RCellIndex(int startIndex, int endIndex) {
		this.setStartIndex(startIndex);
		this.setEndIndex(endIndex);
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
}
