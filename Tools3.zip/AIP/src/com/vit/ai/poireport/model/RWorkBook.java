/*
 *Class Name : RWorkBook.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.vit.ai.utils.ReportUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 29 May 2014
 */
public class RWorkBook extends RWorkBookSheet implements ReportProcess {

	private static final long serialVersionUID = -671641353341480177L;
	private static Logger log = Logger.getLogger(RWorkBook.class.getName());
	protected String name = "";
	private List<RWorkBookSheet> worksheets;
	private String location = "";
	private String fileID = "";

	private Workbook wb;
	private String templateName = "";
	private boolean templateUsed;

	ConnectDB db = new ConnectDB();

	@Override
	public void init() {
		db.initialize();

		SXSSFWorkbook swb;

		if (isTemplateUsed()) {
			try {
				FileInputStream inputStream = new FileInputStream(templateName);
				XSSFWorkbook wb_template = new XSSFWorkbook(inputStream);

				inputStream.close();
				swb = new SXSSFWorkbook(wb_template);
				swb.setCompressTempFiles(true);

				wb = swb;
			} catch (Exception e) {

				log.error(" Template " + e.getMessage());

			}
		} else {
			wb = new XSSFWorkbook();
		}

		ReportUtility reportUtility = new ReportUtility(wb);
		reportUtility.setDb(db);

		for (RWorkBookSheet sheet : worksheets) {
			sheet.setWorkBook(wb);
			sheet.setReportUtility(reportUtility);
			sheet.init();
			sheet.createDataTable();
			sheet.run();
			sheet.postAction();
		}
	}

	@Override
	public void createDataTable() {

	}

	@Override
	public void run() {
		super.run();
	}

	@Override
	public void saveReport() {
		String dumpLocation = this.getLocation();
		if (!new File(dumpLocation).exists()) {
			new File(dumpLocation).mkdir();
		}
		String file = dumpLocation + this.getName() + ".xls";
		if (wb instanceof XSSFWorkbook || wb instanceof SXSSFWorkbook)
			file += "x";
		FileOutputStream out;
		try {
			out = new FileOutputStream(file);
			wb.write(out);
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			log.error(" File write error: " + e.getMessage());
		} catch (IOException e) {
			log.error(" File input out error: " + e.getMessage());
		}

		/* making Wb null and then calling garbage collection */

		wb = null;
	}

	@Override
	public void postAction() {
		super.postAction();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<RWorkBookSheet> getWorksheets() {
		return worksheets;
	}

	public void setWorksheets(List<RWorkBookSheet> worksheets) {
		this.worksheets = worksheets;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public boolean isTemplateUsed() {
		return templateUsed;
	}

	public void setTemplateUsed(boolean templateUsed) {
		this.templateUsed = templateUsed;
	}

}
