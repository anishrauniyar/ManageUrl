/*
 *Class Name : RRow.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

import java.util.List;

/** 
 * Class to generate cell and row height for excel sheet
 * 
 * @author Sagar Shrestha
 * 
 * @version 1.0 29 May 2014
 */
public class RRow {
	private List<RCell> cells;
	private float rowHeight = 13.75f;

	public List<RCell> getCells() {
		return cells;
	}

	public RRow setCells(List<RCell> cells) {
		this.cells = cells;
		return this;
	}

	public float getRowHeight() {
		return rowHeight;
	}

	public void setRowHeight(float rowHeight) {
		this.rowHeight = rowHeight;
	}

}
