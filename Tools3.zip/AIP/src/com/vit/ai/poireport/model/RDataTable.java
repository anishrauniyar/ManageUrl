/* 
 *Class Name : RDataTable.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

import java.util.List;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 29 July 2014
 */
public class RDataTable {

	private String title = "";
	private List<RRow> headerRows;
	private String headerAsString = "N/A";
	private List<RRow> dataRows;
	private List<RRow> footerRows;
	private String property = "";

	private boolean horizontallyAligned = true;
	private boolean enableColumnFormula = false;
	private boolean enableDefaultStyles = false;
	private boolean enableOverriddenStyles = false;
	private boolean enableCellSpecificFormula = false;
	private boolean hasHeader = true;
	private String schemaName="";

	private boolean formulaInHeader = false;

	private int spaceBetweenTwoTables = 0;
	private String querytoGetData;
	private String[] customStyles;
	private String[] formulaForColumns;
	private String[] formulaForRows;
	private String rowWiseMerge = "";
	private String column_Name_For_Row_Wise_Merge = "N/A";
	private List<RCellIndex> cellIndexs;
	private List<RCellIndex> listOfColumnWiseRowMerge;
	private boolean enableValueWiseColumnMerge = false;

	private int startColumnIndexOFConditionalFormat = 5;

	private int conditionalFormat = 0;

	private String populateCustomData;
	private String monthsHeader[][];
	private String styleUsingHeader;

	public RDataTable() {

	}

	public RDataTable(String headerAsString) {
		this.headerAsString = headerAsString;
	}

	public RDataTable(String headerAsString, boolean horizontallyAligned) {
		this.headerAsString = headerAsString;
		this.horizontallyAligned = horizontallyAligned;
	}

	public RDataTable(String headerAsString, boolean horizontallyAligned,
			int spaceBetweenTwoTables) {
		this.headerAsString = headerAsString;
		this.horizontallyAligned = horizontallyAligned;
		this.spaceBetweenTwoTables = spaceBetweenTwoTables;
	}

	public RDataTable(String headerAsString, String queryToGetData) {
		this.headerAsString = headerAsString;
		this.querytoGetData = queryToGetData;

	}

	public RDataTable(boolean hasHeader, String queryToGetData) {
		this.hasHeader = hasHeader;
		this.querytoGetData = queryToGetData;
	}
	public RDataTable(boolean hasHeader, String queryToGetData,String schema) {
		this.hasHeader = hasHeader;
		this.querytoGetData = queryToGetData;
		this.setSchemaName(schema);
	}

	public RDataTable(boolean hasHeader, String queryToGetData,
			int spaceBetweenTwoTables) {
		this.hasHeader = hasHeader;
		this.querytoGetData = queryToGetData;
		this.spaceBetweenTwoTables = spaceBetweenTwoTables;
	}

	public RDataTable(String headerAsString, String queryToGetData,
			int spaceBetweenTwoTables) {
		this.headerAsString = headerAsString;
		this.querytoGetData = queryToGetData;
		this.spaceBetweenTwoTables = spaceBetweenTwoTables;
	}

	public RDataTable(boolean hasHeader, String queryToGetData,
			int spaceBetweenTwoTables, boolean horizontallyAligned) {
		this.hasHeader = hasHeader;
		this.querytoGetData = queryToGetData;
		this.spaceBetweenTwoTables = spaceBetweenTwoTables;
		this.horizontallyAligned = horizontallyAligned;
	}

	public RDataTable(String headerAsString, String queryToGetData,
			int spaceBetweenTwoTables, boolean horizontallyAligned) {
		this.headerAsString = headerAsString;
		this.querytoGetData = queryToGetData;
		this.spaceBetweenTwoTables = spaceBetweenTwoTables;
		this.horizontallyAligned = horizontallyAligned;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<RRow> getHeaderRows() {
		return headerRows;
	}

	public RDataTable setHeaderRows(List<RRow> headerRows) {
		this.headerRows = headerRows;
		return this;
	}

	public String getHeaderAsString() {
		return headerAsString;
	}

	public void setHeaderAsString(String headerAsString) {
		this.headerAsString = headerAsString;
	}

	public List<RRow> getDataRows() {
		return dataRows;
	}

	public void setDataRows(List<RRow> dataRows) {
		this.dataRows = dataRows;
	}

	public List<RRow> getFooterRows() {
		return footerRows;
	}

	public void setFooterRows(List<RRow> footerRows) {
		this.footerRows = footerRows;
	}

	public boolean isHorizontallyAligned() {
		return horizontallyAligned;
	}

	public void setHorizontallyAligned(boolean horizontallyAligned) {
		this.horizontallyAligned = horizontallyAligned;
	}

	public boolean isEnableColumnFormula() {
		return enableColumnFormula;
	}

	public void setEnableColumnFormula(boolean enableColumnFormula) {
		this.enableColumnFormula = enableColumnFormula;
	}

	public boolean isEnableDefaultStyles() {
		return enableDefaultStyles;
	}

	public void setEnableDefaultStyles(boolean enableDefaultStyles) {
		this.enableDefaultStyles = enableDefaultStyles;
	}

	public boolean isEnableOverriddenStyles() {
		return enableOverriddenStyles;
	}

	public void setEnableOverriddenStyles(boolean enableOverriddenStyles) {
		this.enableOverriddenStyles = enableOverriddenStyles;
	}

	public boolean isEnableCellSpecificFormula() {
		return enableCellSpecificFormula;
	}

	public void setEnableCellSpecificFormula(boolean enableCellSpecificFormula) {
		this.enableCellSpecificFormula = enableCellSpecificFormula;
	}

	public boolean isHasHeader() {
		return hasHeader;
	}

	public void setHasHeader(boolean hasHeader) {
		this.hasHeader = hasHeader;
	}

	public int getSpaceBetweenTwoTables() {
		return spaceBetweenTwoTables;
	}

	public void setSpaceBetweenTwoTables(int spaceBetweenTwoTables) {
		this.spaceBetweenTwoTables = spaceBetweenTwoTables;
	}

	public String getQuerytoGetData() {
		return querytoGetData;
	}

	public void setQuerytoGetData(String querytoGetData) {
		this.querytoGetData = querytoGetData;
	}

	public String[] getCustomStyles() {
		return customStyles;
	}

	public void setCustomStyles(String[] customStyles) {
		this.customStyles = customStyles;
	}

	public String[] getFormulaForColumns() {
		return formulaForColumns;
	}

	public void setFormulaForColumns(String[] formulaForColumns) {
		this.formulaForColumns = formulaForColumns;
	}

	public String[] getFormulaForRows() {
		return formulaForRows;
	}

	public void setFormulaForRows(String[] formulaForRows) {
		this.formulaForRows = formulaForRows;
	}

	public String getRowWiseMerge() {
		return rowWiseMerge;
	}

	public void setRowWiseMerge(String rowWiseMerge) {
		this.rowWiseMerge = rowWiseMerge;
	}

	public String getColumn_Name_For_Row_Wise_Merge() {
		return column_Name_For_Row_Wise_Merge;
	}

	public void setColumn_Name_For_Row_Wise_Merge(
			String column_Name_For_Row_Wise_Merge) {
		this.column_Name_For_Row_Wise_Merge = column_Name_For_Row_Wise_Merge;
	}

	public List<RCellIndex> getCellIndexs() {
		return cellIndexs;
	}

	public void setCellIndexs(List<RCellIndex> cellIndexs) {
		this.cellIndexs = cellIndexs;
	}

	public List<RCellIndex> getListOfColumnWiseRowMerge() {
		return listOfColumnWiseRowMerge;
	}

	public void setListOfColumnWiseRowMerge(
			List<RCellIndex> listOfColumnWiseRowMerge) {
		this.listOfColumnWiseRowMerge = listOfColumnWiseRowMerge;
	}

	public boolean isEnableValueWiseColumnMerge() {
		return enableValueWiseColumnMerge;
	}

	public void setEnableValueWiseColumnMerge(boolean enableValueWiseColumnMerge) {
		this.enableValueWiseColumnMerge = enableValueWiseColumnMerge;
	}

	public int getStartColumnIndexOFConditionalFormat() {
		return startColumnIndexOFConditionalFormat;
	}

	public void setStartColumnIndexOFConditionalFormat(
			int startColumnIndexOFConditionalFormat) {
		this.startColumnIndexOFConditionalFormat = startColumnIndexOFConditionalFormat;
	}

	public int getConditionalFormat() {
		return conditionalFormat;
	}

	public void setConditionalFormat(int conditionalFormat) {
		this.conditionalFormat = conditionalFormat;
	}

	public String getCustomData() {
		return populateCustomData;
	}

	public void setCustomData(String customData) {
		this.populateCustomData = customData;
	}

	public boolean isFormulaInHeader() {
		return formulaInHeader;
	}

	public void setFormulaInHeader(boolean formulaInHeader) {
		this.formulaInHeader = formulaInHeader;
	}

	public String[][] getMonthsHeader() {
		return monthsHeader;
	}

	public void setMonthsHeader(String monthsHeader[][]) {
		this.monthsHeader = monthsHeader;
	}

	public String getStyleUsingHeader() {
		return styleUsingHeader;
	}

	public void setStyleUsingHeader(String styleUsingHeader) {
		this.styleUsingHeader = styleUsingHeader;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

}
