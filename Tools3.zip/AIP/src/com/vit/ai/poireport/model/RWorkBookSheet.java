/* 
 *Class Name : RWorkBookSheet.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Sagar Shrestha
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.1 29 May 2014
 */
public class RWorkBookSheet extends RCommonModel implements ReportProcess,
		Serializable {

	private static final long serialVersionUID = 4021080889055621009L;
	private String name = "";
	private static final Logger logger = LoggerFactory
			.getLogger(RWorkBookSheet.class);
	private List<RRow> headerRows;
	protected List<RDataTable> tables;
	private boolean postActionEnabled = true;
	private String[] customMergeRegion;
	private String bookName = "";
	protected boolean sheetCreatedInTemplate = false;

	public boolean isSheetCreatedInTemplate() {
		return sheetCreatedInTemplate;
	}

	public void setSheetCreatedInTemplate(boolean sheetCreatedInTemplate) {
		this.sheetCreatedInTemplate = sheetCreatedInTemplate;
	}

	@Override
	public void init() {

	}

	@Override
	public void createDataTable() {

	}

	@Override
	public void run() {
		if (this.getWorkBook() == null || this.getName() == null) {
			logger.error("Workbook is null " + new Date().toString());
			return;
		}

		Sheet sheet;
		if (isSheetCreatedInTemplate()) {
			sheet = this.getWorkBook().getSheet(this.getName());
		} else {
			sheet = this.getWorkBook().createSheet(this.getName());
		}

		int tmpStartRowIndex = 0;
		int tempRowsCounter = 0;
		int verticalTableCount = 0;
		int i = 0;
		int j=0;
		RCustomStyle cellStyleCommon = new RCustomStyle();
		cellStyleCommon.setCellStyle(this
				.getReportUtility().getStyle()
				.get("common_style"));
		
		RCustomStyle cellStyleVendor = new RCustomStyle();
		cellStyleVendor.setCellStyle(this
				.getReportUtility().getStyle()
				.get("vendor_style"));
		RCustomStyle cellStyleVH = new RCustomStyle();
		cellStyleVH.setCellStyle(this
				.getReportUtility().getStyle()
				.get("vh_style"));
		RCustomStyle cellStyleVariance = new RCustomStyle();
		cellStyleVariance.setCellStyle(this
				.getReportUtility().getStyle()
				.get("variance_style"));
		for (RDataTable table : tables) {
			if (table.isHorizontallyAligned()) {
				tmpStartRowIndex += table.getSpaceBetweenTwoTables();
			} else {
				verticalTableCount++;
				if (verticalTableCount == 1) {
					tempRowsCounter = tmpStartRowIndex;
				}
			}

			if (table.isHasHeader()) {

				if (table.getHeaderRows() != null) {
					for (RRow row : table.getHeaderRows()) {
						Row customRRow;
						if (sheet.getRow(tempRowsCounter) != null) {
							customRRow = sheet.getRow(tempRowsCounter);
						} else {
							customRRow = sheet.createRow(tempRowsCounter);
						}
						int tmpHeaderCellIndex = 0;
						if (!table.isHorizontallyAligned()) {
							tmpHeaderCellIndex = table
									.getSpaceBetweenTwoTables()
									+ row.getCells().size();
						}
						for (RCell cell : row.getCells()) {
							Cell customHeader = customRRow
									.createCell(tmpHeaderCellIndex);

							if (table.isFormulaInHeader()) {
								customHeader.setCellFormula((String) cell
										.getFormula());
							} else {
								customHeader.setCellValue((String) cell
										.getCellValue());
							}

							if (table.getProperty().compareTo("Inventory") == 0) {
								i++;
								if (i <= 20)

								{
									RCustomStyle cellStyle = new RCustomStyle();
									cellStyle.setCellStyle(this
											.getReportUtility().getStyle()
											.get("heading_style_LC"));
									if (i > 3 && i < 6) {
										customHeader.setCellStyle(cellStyle
												.getCellStyle());
									} else if (i > 8 && i < 11) {
										customHeader.setCellStyle(cellStyle
												.getCellStyle());
									} else if (i > 13 && i < 16) {
										customHeader.setCellStyle(cellStyle
												.getCellStyle());
									} else if (i > 18 && i < 21) {
										customHeader.setCellStyle(cellStyle
												.getCellStyle());
									}
								}

								if (i > 20) {
									customHeader.setCellStyle(cell
											.getCustomStyle().getCellStyle());
								}
							} else {
								customHeader.setCellStyle(cell.getCustomStyle()
										.getCellStyle());
							}
							
							if (table.getProperty().compareTo("control") == 0) {
								j++;
								
								if(j>=0 && j<6)
								{
									customHeader.setCellStyle(cellStyleCommon.getCellStyle());
								}

								else if(j>=6 && j<21)
								{
									System.out.println("FOR VH");
									customHeader.setCellStyle(cellStyleVH.getCellStyle());
								}

								else if(j>=22 && j<37)
								{
									System.out.println("FOR VH");
									customHeader.setCellStyle(cellStyleVendor.getCellStyle());
								}

								else if(j>=38 && j<53)
								{
									customHeader.setCellStyle(cellStyleVariance.getCellStyle());
								}
								else
								{
									
										customHeader.setCellStyle(cell
												.getCustomStyle().getCellStyle());
									
								}
								
							} else {
								customHeader.setCellStyle(cell.getCustomStyle()
										.getCellStyle());
							}

							tmpHeaderCellIndex++;
						}
						tempRowsCounter++;
					}
				}
			}

			/* Apply conditional */

			if (table.getConditionalFormat() != 0) {

				this.applyCustomStyle(table.getConditionalFormat(), table);
			}

			if (!table.isHasHeader()) {
				List<RCellIndex> cellIndexs = new ArrayList<RCellIndex>();
				cellIndexs.add(new RCellIndex(tempRowsCounter + 1,
						tempRowsCounter + table.getDataRows().size()));
				table.setCellIndexs(cellIndexs);

			}

			if (!table.getColumn_Name_For_Row_Wise_Merge().equals("N/A")
					&& table.isHorizontallyAligned()) {

				table.setListOfColumnWiseRowMerge(this.mergeByRowValues(
						tempRowsCounter, CellReference
								.convertColStringToIndex(table
										.getColumn_Name_For_Row_Wise_Merge()),
						table));

			}

			if (!table.getColumn_Name_For_Row_Wise_Merge().equals("N/A")
					&& !table.isHorizontallyAligned()
					&& table.getHeaderRows() != null) {

				int indexToMerge = CellReference.convertColStringToIndex(table
						.getColumn_Name_For_Row_Wise_Merge());
				int indexTest = table.getHeaderRows()
						.get(table.getHeaderRows().size() - 1).getCells()
						.size();
				table.setListOfColumnWiseRowMerge(this.mergeByRowValues(
						tempRowsCounter,
						indexToMerge - indexTest
								- table.getSpaceBetweenTwoTables(), table));

			}

			for (RRow dataRow : table.getDataRows()) {
				Row customRRow;
				if (sheet.getRow(tempRowsCounter) != null) {
					customRRow = sheet.getRow(tempRowsCounter);
					;
				} else {
					customRRow = sheet.createRow(tempRowsCounter);
				}
				customRRow.setHeightInPoints(dataRow.getRowHeight());
				int tmpDataCellIndex = 0;
				if (!table.isHorizontallyAligned()) {
					tmpDataCellIndex = table.getSpaceBetweenTwoTables()
							+ dataRow.getCells().size();
				}

				for (RCell customVHRDataCell : dataRow.getCells()) {
					Cell poiCell = customRRow.createCell(tmpDataCellIndex);
					Object customCell = customVHRDataCell.getCellValue();
					
				

				//	customCell = parseAlways(customCell);
					if (customCell instanceof String) {

						String cellString = (String) customCell;
						
						poiCell.setCellValue(cellString);

					} else {
				
						Double cellString = (Double) customCell;
						if (cellString != null) {
							poiCell.setCellValue(cellString);
						} else {
							poiCell.setCellValue("");
						}
					}

					if (customVHRDataCell.getFormula() != null
							&& !customVHRDataCell.getFormula().equals(
									"NOTFOUND")) {
						poiCell.setCellFormula(customVHRDataCell.getFormula()
								.replace("@",
										String.valueOf(tempRowsCounter + 1)));

					}

					if (customVHRDataCell.getCustomStyle() != null) {
						poiCell.setCellStyle(customVHRDataCell.getCustomStyle()
								.getCellStyle());

					}

					tmpDataCellIndex++;
				}
				tempRowsCounter++;
			}

		}

		this.getWorkBook().setForceFormulaRecalculation(true);
	}

	@Override
	public void postAction() {
		this.mergeCells();
		this.reSize();
		this.freezePanel();
		if (!this.isPostActionEnabled()) {
			return;
		}
		if (this.getCustomMergeRegion() != null
				&& this.getCustomMergeRegion().length > 0) {
			for (String s : this.getCustomMergeRegion()) {
				this.getWorkBook().getSheet(this.getName())
						.addMergedRegion(CellRangeAddress.valueOf(s));
			}
		}
	}

	public void mergeCells() {

		for (RDataTable dataTable : tables) {

			if (!dataTable.isHasHeader()
					&& !dataTable.getRowWiseMerge().equals("")) {
				for (String s : dataTable.getRowWiseMerge().split(",")) {

					for (RCellIndex cellIndex : dataTable.getCellIndexs()) {

						if (cellIndex.getEndIndex() > cellIndex.getStartIndex()) {
							this.getWorkBook()
									.getSheet(this.getName())
									.addMergedRegion(
											CellRangeAddress.valueOf(s
													+ cellIndex.getStartIndex()
													+ ":" + s
													+ cellIndex.getEndIndex()));

						}

					}
				}

			}

			if (!dataTable.getColumn_Name_For_Row_Wise_Merge().equals("N/A")) {

				for (RCellIndex cellIndex : dataTable
						.getListOfColumnWiseRowMerge()) {
					if (cellIndex.getEndIndex() > cellIndex.getStartIndex()) {

						this.getWorkBook()
								.getSheet(this.getName())
								.addMergedRegion(
										CellRangeAddress.valueOf(dataTable
												.getColumn_Name_For_Row_Wise_Merge()
												+ cellIndex.getStartIndex()
												+ ":"
												+ dataTable
														.getColumn_Name_For_Row_Wise_Merge()
												+ cellIndex.getEndIndex()));
					}
				}
			}

		}
	}

	public RDataTable transPose(RDataTable dataTable, int initailColumn,
			int maxColumn) {
		List<RRow> test1 = dataTable.getDataRows();
		int rowSize = dataTable.getDataRows().size();
		List<RRow> pivotedRow = new ArrayList<RRow>();
		for (int i = initailColumn; i < maxColumn; i++) {
			List<RCell> cells = new ArrayList<RCell>();
			for (int k = 0; k < rowSize; k++) {
				RCell cell = test1.get(k).getCells().get(i);
				cells.add(cell);
			}
			pivotedRow.add(new RRow().setCells(cells));

		}
		dataTable.setDataRows(pivotedRow);
		return dataTable;
	}

	public List<RCellIndex> mergeByRowValues(int rowNumber, int lookUpIndex,
			RDataTable dataTable) {
		List<RCellIndex> listOfcell = new ArrayList<RCellIndex>();
		int mergeStart = 0;
		int mergeEnd = 0;
		rowNumber = rowNumber + 1;
		for (int i = 0; i < dataTable.getDataRows().size() - 1; i++) {

			for (int k = lookUpIndex; k < lookUpIndex + 1; k++) {
				if (!dataTable
						.getDataRows()
						.get(i)
						.getCells()
						.get(k)
						.getCellValue()
						.toString()
						.trim()
						.equalsIgnoreCase(
								(dataTable.getDataRows().get(i + 1).getCells()
										.get(k).getCellValue()).toString()
										.trim())) {

					mergeEnd = i;
					RCellIndex cellIndex = new RCellIndex(mergeStart
							+ rowNumber, mergeEnd + rowNumber);
					listOfcell.add(cellIndex);

					/* Another merge starts when one completes */

					mergeStart = mergeEnd + 1;
				}

			}
		}

		/* Adding for last rows */

		listOfcell.add(new RCellIndex(mergeStart + rowNumber, dataTable
				.getDataRows().size() + rowNumber - 1));
		return listOfcell;

	}

	public void freezePanel() {

		if (this.getHeaderRows() != null) {
			this.getWorkBook().getSheet(this.getName())
					.createFreezePane(0, this.getHeaderRows().size());
		}

	}

	@SuppressWarnings("unused")
	public void applyCustomFormula() {
		RDataTable dataTable = tables.get(0);
		int headerSize = dataTable.getHeaderRows().size();
		int dataSize = dataTable.getDataRows().size();
		int xAxis = headerSize + dataSize;
		int yAxis = dataTable.getDataRows()
				.get(dataTable.getDataRows().size() - 1).getCells().size();

	}

	public void extractRowfromContent(int columnIndex, String textToCheck) {
		for (RDataTable dataTable : tables) {
			if (!dataTable.isEnableCellSpecificFormula()) {
				return;
			}
			@SuppressWarnings("unused")
			int rowNumber = 1;
			for (RRow row : dataTable.getDataRows()) {
				if (row.getCells().get(columnIndex).getCellValue()
						.equals(textToCheck)) {

				}

				rowNumber++;
			}
		}
	}

	public RDataTable applyCustomStyle(int i, RDataTable dataTable) {

		
		
		switch (i) {
		
		case 1:
			return applyConditionalFormat1(dataTable);

		case 2:
			return applyConditionalFormat2(dataTable);

		case 3:
			return applyConditionalFormat3(dataTable);
		case 4:
			return applyConditionalFormat4(dataTable);
		case 5:
			return applyConditionalFormat5(dataTable);
		case 6 : 
			return applyConditionalFormat6(dataTable);

		default:
			return dataTable;
		}
	}

	public RDataTable applyConditionalFormat1(RDataTable dataTable) {
		for (int k = 0; dataTable.getDataRows() != null
				&& k < dataTable.getDataRows().size() - 1; k++) {

			Double percentageToCheck1 = new Double(5);
			Double percentageToCheck2 = new Double(3);
			Double percentageToCheck3 = new Double(10);
			Double percentageToCheck4 = new Double(6);

			for (int i = dataTable.getStartColumnIndexOFConditionalFormat() + 1; i < dataTable
					.getDataRows().get(k).getCells().size(); i++) {

				Double memberCount = Double
						.parseDouble(dataTable.getDataRows().get(k + 1)
								.getCells().get(i).getCellValue().toString());

				Double employeeDifference = Double.parseDouble(dataTable
						.getDataRows().get(k).getCells().get(i).getCellValue()
						.toString())
						- Double.parseDouble(dataTable.getDataRows().get(k)
								.getCells().get(i - 1).getCellValue()
								.toString());
				employeeDifference = Math.abs(employeeDifference);

				Double memberDifference = Double.parseDouble(dataTable
						.getDataRows().get(k + 1).getCells().get(i)
						.getCellValue().toString())
						- Double.parseDouble(dataTable.getDataRows().get(k + 1)
								.getCells().get(i - 1).getCellValue()
								.toString());
				memberDifference = Math.abs(memberDifference);

				Double employeeChangePercentage = employeeDifference
						* 100
						/ (Double.parseDouble(dataTable.getDataRows().get(k)
								.getCells().get(i).getCellValue().toString()) == 0 ? 1
								: Double.parseDouble(dataTable.getDataRows()
										.get(k).getCells().get(i)
										.getCellValue().toString()));

				Double memberDifferencePercentage = memberDifference
						* 100
						/ (Double.parseDouble(dataTable.getDataRows()
								.get(k + 1).getCells().get(i).getCellValue()
								.toString()) == 0 ? 1 : Double
								.parseDouble(dataTable.getDataRows().get(k + 1)
										.getCells().get(i).getCellValue()
										.toString()));

				RCustomStyle cellStyle1 = new RCustomStyle();
				cellStyle1.setCellStyle(this.getReportUtility().getStyle()
						.get("integer_style"));
				dataTable.getDataRows().get(k).getCells().get(i)
						.setCustomStyle(cellStyle1);

				if (memberCount > 10000) {
					if (employeeChangePercentage > percentageToCheck2
							|| memberDifferencePercentage > percentageToCheck2) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_integer_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);
						dataTable.getDataRows().get(k + 1).getCells().get(i)
								.setCustomStyle(cellStyle);

					}

					/* Applying to 1st month */

					if (employeeChangePercentage > percentageToCheck4) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("yellowFilled_integer_style"));
						dataTable
								.getDataRows()
								.get(k)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);
						dataTable
								.getDataRows()
								.get(k + 1)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);
					}

				} else {
					if (employeeChangePercentage > percentageToCheck1
							|| memberDifferencePercentage > percentageToCheck1) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_integer_style"));
						dataTable.getDataRows().get(k + 1).getCells().get(i)
								.setCustomStyle(cellStyle);
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);
					}

					/* Applying to 1st month */

					if (memberDifferencePercentage > percentageToCheck3) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("yellowFilled_integer_style"));
						dataTable
								.getDataRows()
								.get(k)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);
						dataTable
								.getDataRows()
								.get(k + 1)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);
					}

				}

			}

		}
		return dataTable;
	}

	/**
	 * 
	 * @param dataTable
	 * @return
	 */
	public RDataTable applyConditionalFormat2(RDataTable dataTable) {

		for (int k = 0; dataTable.getDataRows() != null
				&& k < dataTable.getDataRows().size(); k++) {

			for (int i = dataTable.getStartColumnIndexOFConditionalFormat() + 1; i < dataTable
					.getDataRows().get(k).getCells().size(); i++) {

				Double difference = Double.parseDouble(dataTable.getDataRows()
						.get(k).getCells().get(i).getCellValue().toString())
						- Double.parseDouble(dataTable.getDataRows().get(k)
								.getCells().get(i - 1).getCellValue()
								.toString());
				difference = Math.abs(difference);

				Double differencePercentage = difference
						* 100
						/ (Double.parseDouble(dataTable.getDataRows().get(k)
								.getCells().get(i).getCellValue().toString()) == 0 ? 1
								: Double.parseDouble(dataTable.getDataRows()
										.get(k).getCells().get(i)
										.getCellValue().toString()));

				/* Paid Amount */

				if (k == 0) {

					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("dollar_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);
					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_dollar_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);

					}

					/**
					 * 1st month check
					 */
					if (differencePercentage > new Double(15)) {

						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("yellowFilled_dollar_style"));
						dataTable
								.getDataRows()
								.get(k)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);

					}

				}

				/* Allowed Amount */

				else if (k == 1) {

					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("dollar_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);

					if (differencePercentage > new Double(5)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_dollar_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);

					}

					/* 1st month check */

					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("yellowFilled_dollar_style"));
						dataTable
								.getDataRows()
								.get(k)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);
					}
				} else if (k == 2) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("integer_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);
				}

				else if (k == 3 || k == 4) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("dollar_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);

					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_dollar_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);
					}
				}

				else if (k == 5) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("percentage_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);

					if (!(Double.parseDouble(dataTable.getDataRows().get(k)
							.getCells().get(i).getCellValue().toString()) >= 5 && Double
							.parseDouble(dataTable.getDataRows().get(k)
									.getCells().get(i).getCellValue()
									.toString()) <= 25)
							&& Double.parseDouble(dataTable.getDataRows()
									.get(k).getCells().get(i).getCellValue()
									.toString()) != 0) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_percentage_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);
					}
				}

			}

		}
		return dataTable;

	}

	/**
	 * 
	 * @param dataTable
	 * @return
	 */
	public RDataTable applyConditionalFormat3(RDataTable dataTable) {

		for (int k = 0; dataTable.getDataRows() != null
				&& k < dataTable.getDataRows().size(); k++) {

			for (int i = dataTable.getStartColumnIndexOFConditionalFormat() + 1; i < dataTable
					.getDataRows().get(k).getCells().size(); i++) {

				Double difference = Double.parseDouble(dataTable.getDataRows()
						.get(k).getCells().get(i).getCellValue().toString())
						- Double.parseDouble(dataTable.getDataRows().get(k)
								.getCells().get(i - 1).getCellValue()
								.toString());
				difference = Math.abs(difference);

				Double differencePercentage = difference
						* 100
						/ (Double.parseDouble(dataTable.getDataRows().get(k)
								.getCells().get(i).getCellValue().toString()) == 0 ? 1
								: Double.parseDouble(dataTable.getDataRows()
										.get(k).getCells().get(i)
										.getCellValue().toString()));

				/* Paid Amount */

				if (k == 0) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("dollar_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);

					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_dollar_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);

					}

					/* 1st month check */

					if (differencePercentage > new Double(15)) {

						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("yellowFilled_dollar_style"));
						dataTable
								.getDataRows()
								.get(k)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);

					}

				}

				/* Allowed Amount */

				else if (k == 1) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("dollar_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);
					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_dollar_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);

					}

					/* 1st month check */

					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("yellowFilled_dollar_style"));
						dataTable
								.getDataRows()
								.get(k)
								.getCells()
								.get(dataTable
										.getStartColumnIndexOFConditionalFormat())
								.setCustomStyle(cellStyle);
					}
				} else if (k == 2) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("integer_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);
				} else if (k == 3 || k == 4) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("dollar_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);
					if (differencePercentage > new Double(10)) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_dollar_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);
					}
				} else if (k == 5) {
					RCustomStyle cellStyle1 = new RCustomStyle();
					cellStyle1.setCellStyle(this.getReportUtility().getStyle()
							.get("percentage_style"));
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);

					if (!(Double.parseDouble(dataTable.getDataRows().get(k)
							.getCells().get(i).getCellValue().toString()) >= 5 && Double
							.parseDouble(dataTable.getDataRows().get(k)
									.getCells().get(i).getCellValue()
									.toString()) <= 25)
							&& Double.parseDouble(dataTable.getDataRows()
									.get(k).getCells().get(i).getCellValue()
									.toString()) != 0) {
						RCustomStyle cellStyle = new RCustomStyle();
						cellStyle.setCellStyle(this.getReportUtility()
								.getStyle().get("redfilled_percentage_style"));
						dataTable.getDataRows().get(k).getCells().get(i)
								.setCustomStyle(cellStyle);
					}
				}

			}

		}
		return dataTable;

	}

	public RDataTable applyConditionalFormat4(RDataTable dataTable) {

		for (int k = 0; dataTable.getDataRows() != null
				&& k < dataTable.getDataRows().size(); k++) {

			String checktypevalue = "";
			if (dataTable.getDataRows().get(k).getCells().get(7).getCellValue() != null) {
				checktypevalue = dataTable.getDataRows().get(k).getCells()
						.get(7).getCellValue().toString();
			}
			RCustomStyle cellStyle = new RCustomStyle();
			cellStyle.setCellStyle(this.getReportUtility().getStyle()
					.get("redfilled_integer_style"));

			if (checktypevalue.compareTo("EXCEPTION") == 0) {

				for (int i = 0; i < dataTable.getDataRows().get(k).getCells()
						.size(); i++) {
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle);
				}

			}

		}
		return dataTable;
	}

	public RDataTable applyConditionalFormat5(RDataTable dataTable) {

		for (int k = 0; dataTable.getDataRows() != null
				&& k < dataTable.getDataRows().size(); k++) {

			String checktypevalue = "";

			if (dataTable.getDataRows().get(k).getCells().get(9).getCellValue() != null) {
				checktypevalue = dataTable.getDataRows().get(k).getCells()
						.get(9).getCellValue().toString();

			}
			RCustomStyle cellStyle = new RCustomStyle();
			cellStyle.setCellStyle(this.getReportUtility().getStyle()
					.get("redfilled_style"));
			RCustomStyle cellStyle1 = new RCustomStyle();
			cellStyle1.setCellStyle(this.getReportUtility().getStyle()
					.get("yellowFilled_Style"));
			RCustomStyle cellStyle2 = new RCustomStyle();
			cellStyle2.setCellStyle(this.getReportUtility().getStyle()
					.get("normal_style"));
			if (checktypevalue.compareTo("UNKNOWN") == 0) {

				for (int i = 0; i < dataTable.getDataRows().get(k).getCells()
						.size(); i++) {
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle1);
				}
			}

			else if (checktypevalue.compareTo("EXCEPTIONS") == 0) {
				for (int i = 0; i < dataTable.getDataRows().get(k).getCells()
						.size(); i++) {
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle);
				}
			}

			else {
				for (int i = 0; i < dataTable.getDataRows().get(k).getCells()
						.size(); i++) {
					dataTable.getDataRows().get(k).getCells().get(i)
							.setCustomStyle(cellStyle2);
				}
			}

		}

		return dataTable;

	}
	public RDataTable applyConditionalFormat6(RDataTable dataTable) {
		
		System.out.println("Applying cutom style");
		RCustomStyle cellStyleCommon=new RCustomStyle();
		cellStyleCommon.setCellStyle(this.getReportUtility().getStyle().get("redfilled_style"));
		
		
			for(int i=5;i<9;i++)
			{
				
				
				System.out.println("Value : " + dataTable.getHeaderRows().get(0).getCells().get(i).getCellValue());
				
				dataTable.getHeaderRows().get(1).getCells().get(i)
				.setCustomStyle(cellStyleCommon);
			}

		

		return dataTable;

	}

	

	
	public Object parseAlways(Object input) {
		try {
			if (input instanceof String) {
				return Double.parseDouble((String) input);
			}
			return input;
		} catch (Exception e) {
			return input;
		}
	}

	public void reSize() {
		int size = 10;
		try {
			if (this.getWorkBook().getSheet(this.getName()) != null) {
				if (this.getHeaderRows() != null) {
					if (this.getHeaderRows()
							.get(this.getHeaderRows().size() - 1).getCells() != null) {
						size = this.getHeaderRows()
								.get(this.getHeaderRows().size() - 1)
								.getCells().size();
					}
				}

				for (int i = 0; i < size; i++) {

					this.getWorkBook().getSheet(this.getName())
							.autoSizeColumn(i, true);
				}
			}
		} catch (java.lang.ArrayIndexOutOfBoundsException e) {
			logger.error("Array out of bound "
					+ this.getWorkBook().getSheet(this.getName()));

		}

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<RRow> getHeaderRows() {
		return headerRows;
	}

	public void setHeaderRows(List<RRow> headerRows) {
		this.headerRows = headerRows;
	}

	public boolean isPostActionEnabled() {
		return postActionEnabled;
	}

	public void setPostActionEnabled(boolean postActionEnabled) {
		this.postActionEnabled = postActionEnabled;
	}

	public String[] getCustomMergeRegion() {
		return customMergeRegion;
	}

	public void setCustomMergeRegion(String[] customMergeRegion) {
		this.customMergeRegion = customMergeRegion;
	}

	@Override
	public void saveReport() {

	}

	public List<RDataTable> getTables() {
		return tables;
	}

	public void setTables(List<RDataTable> tables) {
		this.tables = tables;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

}
