/* 
 *Class Name : ReportProcess.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.model;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 29 June 2014
 */
public interface ReportProcess {

	public void init();

	public void createDataTable();

	public void run();

	public void postAction();

	public void saveReport();

}
