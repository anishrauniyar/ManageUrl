/* 
 *Class Name : RProcessKey.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.writer;

/**
 * Class to generate key for each process
 * 
 * @author Sagar Shrestha
 * 
 * @version 1.0 30 May 2014
 */
public class RProcessKey {
	private String processID;
	private String parentID;

	public RProcessKey(String parentID, String processID) {
		this.parentID = parentID;
		this.processID = processID;
	}

	public String getProcessID() {
		return processID;
	}

	public void setProcessID(String processID) {
		this.processID = processID;
	}

	public String getParentID() {
		return parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}

	public boolean equals(Object obj) {
		if (obj instanceof RProcessKey) {
			RProcessKey tskKey = (RProcessKey) obj;
			if (tskKey.processID.equals(processID)) {
				return true;
			}
		}
		return false;
	}
}
