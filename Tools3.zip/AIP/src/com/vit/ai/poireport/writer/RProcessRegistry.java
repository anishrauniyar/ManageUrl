/* 
 *Class Name : RProcessRegistry.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.writer;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.vit.ai.poireport.controller.ReportThreadController;
import com.vit.ai.poireport.model.ReportProcess;

/**
 * Class to register report and execute process
 * 
 * @author Sagar Shrestha
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.1 30 May 2014
 */
public class RProcessRegistry {
	private ExecutorService executor;
	private Map<RProcessKey, ReportThreadController> processRegistry;
	final int scaleFactor = 1;

	public void init() {
		int noofcpu = Runtime.getRuntime().availableProcessors();
		int maxThreads = noofcpu * scaleFactor;
		maxThreads = (maxThreads > 0 ? maxThreads : 1);
		executor = new ThreadPoolExecutor(
				maxThreads,
				maxThreads,
				1,
				TimeUnit.MINUTES,
				new ArrayBlockingQueue<Runnable>(maxThreads, true),
				new org.apache.tomcat.util.threads.ThreadPoolExecutor.CallerRunsPolicy());
		processRegistry = new HashMap<RProcessKey, ReportThreadController>();
	}

	public ReportProcess registerProcess(RProcessKey key, ReportProcess process) {

		ReportThreadController writeProcess = null;

		if (key == null || process == null) {
			throw new IllegalArgumentException(
					"Cannot register process with process key or process null");
		}
		writeProcess = (ReportThreadController) processRegistry.get(key);
		if (writeProcess != null) {
			System.out
					.println("Process already found, cannot register process");
			return writeProcess;
		}

		else
			synchronized (processRegistry) {
				writeProcess = (ReportThreadController) processRegistry
						.get(key);
				if (writeProcess != null) {
					/* Process found in Sync block */
					return writeProcess;
				} else {
					writeProcess = new ReportThreadController(process)
							.setProcessRegistry(key, this);
					processRegistry.put(key, writeProcess);
					startProcess(writeProcess);
					shutDown();

				}

			}
		return writeProcess;
	}

	private void startProcess(ReportThreadController process) {

		executor.execute(process);
	}

	public Map<RProcessKey, ReportThreadController> getProcessRegistry() {
		return processRegistry;
	}

	public RProcessRegistry release(RProcessKey key) {
		processRegistry.remove(key);
		return this;
	}

	public void shutDown() {

		executor.shutdown();

	}

	public boolean isProcessTerminated() {
		return executor.isTerminated();
	}
}
