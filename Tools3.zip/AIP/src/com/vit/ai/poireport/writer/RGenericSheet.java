/* 
 *Class Name : RGenericSheet.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.writer;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.dao.ReportQueryDAO;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RRow;
import com.vit.ai.poireport.model.RWorkBook;
import com.vit.ai.poireport.model.ReportProcess;

/**
 * @author Sagar Shrestha
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.1 29 May 2014
 */
public class RGenericSheet extends RWorkBook implements ReportProcess {

	private static final long serialVersionUID = 2875360711573450403L;

	private static final Logger logger = LoggerFactory
			.getLogger(RGenericSheet.class);

	List<RRow> headerRows = null;

	public RGenericSheet() {

	}

	public RGenericSheet(String name) {
		this.name = name;
	}

	@Override
	public void init() {
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void createDataTable() {
		if (tables == null) {
			logger.info("Table is null");
			return;
		}

		for (RDataTable rDataTable : tables) {

			if (!rDataTable.getHeaderAsString().equals("N/A")) {
				rDataTable.setHeaderRows(this.getReportUtility().getHeaderRows(
						rDataTable.getHeaderAsString()));
			}

			if (rDataTable.getHeaderRows() != null) {
				headerRows = rDataTable.getHeaderRows();
				super.setHeaderRows(headerRows);
			}
			List dataRows = new ArrayList<>();
			if (rDataTable.getQuerytoGetData() != null) {
				dataRows = new ReportQueryDAO(this.getReportUtility())
						.getData(rDataTable.setHeaderRows(headerRows));
			} else if (rDataTable.getCustomData() != null) {
				String filter = rDataTable.getCustomData();

				if (filter.equalsIgnoreCase("MDR"))
					dataRows = this.getReportUtility()
							.preapreDataForSummary_MDR();
			}
			rDataTable.setDataRows(dataRows);
		}

	}

	@Override
	public void run() {
		super.run();
	}

	@Override
	public void postAction() {
		super.postAction();
	}

}
