/* 
 *Class Name : ExcelFormattingStyles.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.poireport.format;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author Sagar Shrestha
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.1 12 Dec 2014
 */
public class ExcelFormattingStyles {

	public Map<String, CellStyle> getStyler(XSSFWorkbook wb) {

		Map<String, CellStyle> styles = new HashMap<String, CellStyle>();
		DataFormat df = wb.createDataFormat();
		short nf = df.getFormat("#,##0");
		short nf1 = df.getFormat("#,##0.00");
		short nf3 = df.getFormat("#,##0.0000");
		short nf2 = df.getFormat("0");
		@SuppressWarnings("unused")
		short cf = df.getFormat("$#,##0.00");

		XSSFCellStyle no_style, vh_inv, heading_style, heading_style2, heading_style3, integer_style, integer_style2, integer_style3, normal_style, normalRed_style, normalBold_style, integer_style_shade, integer_style2_shade, integer_style3_shade, normal_style_shade, normalRed_style_shade, normalBold_style_shade, integer_style4_shade, integer_style4, normal_style_header, normal_style_header2, heading_style_notop;

		/* Font for vh_inv */
		Font vh_invFont = wb.createFont();
		vh_invFont.setFontName("Arial");
		vh_invFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		vh_invFont.setFontHeightInPoints((short) 10);
		vh_invFont.setColor(HSSFColor.BLACK.index);

		Font Font = wb.createFont();
		Font.setFontName("Arial");
		Font.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_NORMAL);
		Font.setFontHeightInPoints((short) 8);
		Font.setColor(HSSFColor.BLACK.index);

		Font Font2 = wb.createFont();
		Font2.setFontName("Arial");
		Font2.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font2.setFontHeightInPoints((short) 8);
		Font2.setColor(HSSFColor.BLACK.index);

		Font Font3 = wb.createFont();
		Font3.setFontName("Arial");
		Font3.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font3.setFontHeightInPoints((short) 8);
		Font3.setColor(HSSFColor.WHITE.index);

		Font Font4 = wb.createFont();
		Font4.setFontName("Arial");
		Font4.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font4.setFontHeightInPoints((short) 8);
		Font4.setColor(HSSFColor.BLACK.index);

		Font FontRed = wb.createFont();
		FontRed.setFontName("Arial");
		FontRed.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		FontRed.setFontHeightInPoints((short) 8);
		FontRed.setColor(HSSFColor.RED.index);

		no_style = createBorderedStyleWithoutBorders(wb);
		no_style.setAlignment(CellStyle.ALIGN_LEFT);
		no_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		no_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		no_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		no_style.setFont(Font);
		styles.put("no_style", no_style);

		normal_style_header = createBorderedStyleWithoutBorders(wb);
		normal_style_header.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style_header.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normal_style_header.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(219, 229, 241)));
		normal_style_header.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style_header.setFont(Font);
		styles.put("normal_style_header", normal_style_header);

		normal_style_header2 = createBorderedStyleWithoutBorders(wb);
		normal_style_header2.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style_header2.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normal_style_header2.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(229, 224, 236)));
		normal_style_header2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style_header2.setFont(Font2);
		styles.put("normal_style_header2", normal_style_header2);

		heading_style_notop = createBorderedStyleWithoutTopBorder(wb);
		heading_style_notop.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style_notop.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style_notop.setFillForegroundColor(IndexedColors.LIGHT_BLUE
				.getIndex());
		heading_style_notop.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style_notop.setFont(Font3);
		styles.put("heading_style_notop", heading_style_notop);

		vh_inv = createBorderedStyle(wb);
		vh_inv.setAlignment(CellStyle.ALIGN_LEFT);
		vh_inv.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		vh_inv.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		vh_inv.setFillPattern(CellStyle.SOLID_FOREGROUND);
		vh_inv.setFont(vh_invFont);
		styles.put("vh_inventory", vh_inv);

		heading_style = createBorderedStyle(wb);
		heading_style.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style.setFillForegroundColor(IndexedColors.LIGHT_BLUE
				.getIndex());
		heading_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style.setFont(Font3);
		styles.put("heading_style", heading_style);

		heading_style2 = createBorderedStyle(wb);
		heading_style2.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style2.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style2.setFillForegroundColor(IndexedColors.PALE_BLUE
				.getIndex());
		heading_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style2.setFont(Font4);
		styles.put("heading_style2", heading_style2);

		heading_style3 = createBorderedStyle(wb);
		heading_style3.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style3.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style3.setFillForegroundColor(IndexedColors.GREEN.getIndex());
		heading_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style3.setFont(Font4);
		styles.put("heading_style3", heading_style3);

		integer_style = createBorderedStyle(wb);
		integer_style.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style.setFont(Font);
		integer_style.setDataFormat(nf);
		styles.put("integer_style", integer_style);

		integer_style2 = createBorderedStyle(wb);
		integer_style2.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style2.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style2.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style2.setFont(Font);
		integer_style2.setDataFormat(nf2);
		styles.put("integer_style2", integer_style2);

		integer_style3 = createBorderedStyle(wb);
		integer_style3.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style3.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style3.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style3.setFont(Font);
		integer_style3.setDataFormat(nf1);
		styles.put("integer_style3", integer_style3);

		integer_style4 = createBorderedStyle(wb);
		integer_style4.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style4.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style4.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style4.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style4.setFont(Font);
		integer_style4.setDataFormat(nf3);
		styles.put("integer_style4", integer_style4);

		normal_style = createBorderedStyle(wb);
		normal_style.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normal_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normal_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style.setFont(Font);
		styles.put("normal_style", normal_style);

		normalRed_style = createBorderedStyle(wb);
		normalRed_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalRed_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normalRed_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalRed_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalRed_style.setFont(FontRed);
		styles.put("normalRed_style", normalRed_style);

		normalBold_style = createBorderedStyle(wb);
		normalBold_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalBold_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normalBold_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalBold_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalBold_style.setFont(Font2);
		styles.put("normalBold_style", normalBold_style);

		integer_style_shade = createBorderedStyle(wb);
		integer_style_shade.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		integer_style_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style_shade.setFont(Font);
		integer_style_shade.setDataFormat(nf);
		styles.put("integer_style_shade", integer_style_shade);

		integer_style2_shade = createBorderedStyle(wb);
		integer_style2_shade.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style2_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style2_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		integer_style2_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style2_shade.setFont(Font);
		integer_style2_shade.setDataFormat(nf2);
		styles.put("integer_style2_shade", integer_style2_shade);

		integer_style3_shade = createBorderedStyle(wb);
		integer_style3_shade.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style3_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style3_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		integer_style3_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style3_shade.setFont(Font);
		integer_style3_shade.setDataFormat(nf1);
		styles.put("integer_style3_shade", integer_style3_shade);

		integer_style4_shade = createBorderedStyle(wb);
		integer_style4_shade.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style4_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style4_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		integer_style4_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style4_shade.setFont(Font);
		integer_style4_shade.setDataFormat(nf3);
		styles.put("integer_style4_shade", integer_style4_shade);

		normal_style_shade = createBorderedStyle(wb);
		normal_style_shade.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normal_style_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		normal_style_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style_shade.setFont(Font);
		styles.put("normal_style_shade", normal_style_shade);

		normalRed_style_shade = createBorderedStyle(wb);
		normalRed_style_shade.setAlignment(CellStyle.ALIGN_LEFT);
		normalRed_style_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normalRed_style_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		normalRed_style_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalRed_style_shade.setFont(FontRed);
		styles.put("normalRed_style_shade", normalRed_style_shade);

		normalBold_style_shade = createBorderedStyle(wb);
		normalBold_style_shade.setAlignment(CellStyle.ALIGN_LEFT);
		normalBold_style_shade.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normalBold_style_shade.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(234, 234, 234)));
		normalBold_style_shade.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalBold_style_shade.setFont(Font2);
		styles.put("normalBold_style_shade", normalBold_style_shade);

		return styles;
	}

	private static XSSFCellStyle createBorderedStyle(XSSFWorkbook wb) {
		XSSFCellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		return style;

	}

	private static XSSFCellStyle createBorderedStyleWithoutBorders(
			XSSFWorkbook wb) {
		XSSFCellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_NONE);

		style.setBorderBottom(CellStyle.BORDER_NONE);

		style.setBorderLeft(CellStyle.BORDER_NONE);

		style.setBorderTop(CellStyle.BORDER_NONE);
		return style;

	}

	private static XSSFCellStyle createBorderedStyleWithoutTopBorder(
			XSSFWorkbook wb) {
		XSSFCellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_NONE);
		return style;

	}

	private static CellStyle createBorderedStyle(SXSSFWorkbook wb) {
		CellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		return style;

	}

	public Map<String, CellStyle> getStyler(SXSSFWorkbook wb) {

		Map<String, CellStyle> styles = new HashMap<String, CellStyle>();
		DataFormat df = wb.createDataFormat();
		short nf = df.getFormat("#,##0");
		short nf1 = df.getFormat("#,##0.00");
		short nf2 = df.getFormat("0");
		short cf = df.getFormat("$#,##0.00");
		short pf = df.getFormat("0.00%");
		@SuppressWarnings("unused")
		XSSFCellStyle vh_inv, heading_style, heading_style2, heading_style3, heading_style_dy, integer_style, integer_style2, integer_style3, normal_style, normalRed_style, normalBold_style, percentage_style, no_style, styleForsummary, styleForsummary2, dollarstyle, heading_style_gray, heading_stylepb;

		/* Font for vh_inv */
		Font vh_invFont = wb.createFont();
		vh_invFont.setFontName("Arial");
		vh_invFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		vh_invFont.setFontHeightInPoints((short) 10);
		vh_invFont.setColor(HSSFColor.BLACK.index);

		Font Font = wb.createFont();
		Font.setFontName("Arial");
		Font.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_NORMAL);
		Font.setFontHeightInPoints((short) 8);
		Font.setColor(HSSFColor.BLACK.index);

		Font Font2 = wb.createFont();
		Font2.setFontName("Arial");
		Font2.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font2.setFontHeightInPoints((short) 8);
		Font2.setColor(HSSFColor.BLACK.index);

		Font Font3 = wb.createFont();
		Font3.setFontName("Arial");
		Font3.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font3.setFontHeightInPoints((short) 8);
		Font3.setColor(HSSFColor.WHITE.index);

		Font Font4 = wb.createFont();
		Font4.setFontName("Arial");
		Font4.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font4.setFontHeightInPoints((short) 8);
		Font4.setColor(HSSFColor.BLACK.index);

		Font FontRed = wb.createFont();
		FontRed.setFontName("Arial");
		FontRed.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		FontRed.setFontHeightInPoints((short) 8);
		FontRed.setColor(HSSFColor.RED.index);

		Font FontCalibri9 = wb.createFont();
		FontCalibri9.setFontName("Calibri");
		FontCalibri9
				.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		FontCalibri9.setFontHeightInPoints((short) 9);
		FontCalibri9.setColor(HSSFColor.BLACK.index);
		dollarstyle = (XSSFCellStyle) createBorderedStyle(wb);
		dollarstyle.setAlignment(CellStyle.ALIGN_RIGHT);
		dollarstyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		dollarstyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		dollarstyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		dollarstyle.setFont(Font);
		dollarstyle.setDataFormat(cf);
		styles.put("dollar_style", dollarstyle);

		heading_style = (XSSFCellStyle) createBorderedStyle(wb);
		heading_style.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style.setFillForegroundColor(IndexedColors.LIGHT_BLUE
				.getIndex());
		heading_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style.setFont(Font3);
		styles.put("heading_style", heading_style);

		heading_stylepb = (XSSFCellStyle) createBorderedStyle(wb);
		heading_stylepb.setAlignment(CellStyle.ALIGN_CENTER);
		heading_stylepb.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_stylepb.setFillForegroundColor(IndexedColors.PALE_BLUE
				.getIndex());
		heading_stylepb.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_stylepb.setFont(Font4);
		styles.put("heading_stylepb", heading_stylepb);

		heading_style = (XSSFCellStyle) createBorderedStyle(wb);
		heading_style.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style.setFillForegroundColor(new XSSFColor(new java.awt.Color(
				83, 142, 213)));
		heading_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style.setFont(Font3);
		styles.put("heading_style_LB", heading_style);

		heading_style2 = (XSSFCellStyle) createBorderedStyle(wb);
		heading_style2.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style2.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style2.setFillForegroundColor(new XSSFColor(new java.awt.Color(
				215, 228, 188)));
		heading_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style2.setFont(Font4);
		styles.put("heading_style_LC", heading_style2);

		heading_style3 = (XSSFCellStyle) createBorderedStyle(wb);
		heading_style3.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style3.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style3.setFillForegroundColor(new XSSFColor(new java.awt.Color(
				184, 204, 228)));
		heading_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style3.setFont(Font4);
		styles.put("heading_style_CB", heading_style3);

		heading_style_dy = (XSSFCellStyle) createBorderedStyle(wb);
		heading_style_dy.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style_dy.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style_dy.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(194, 214, 154)));
		heading_style_dy.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style_dy.setFont(Font4);
		styles.put("heading_style_DY", heading_style_dy);

		heading_style_gray = (XSSFCellStyle) createBorderedStyle(wb);
		heading_style_gray.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style_gray.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		heading_style_gray.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(191, 191, 191)));
		heading_style_gray.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style_gray.setFont(Font4);
		styles.put("heading_style_gray", heading_style_gray);

		integer_style = (XSSFCellStyle) createBorderedStyle(wb);
		integer_style.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style.setFont(Font);
		integer_style.setDataFormat(nf);
		styles.put("integer_style", integer_style);

		integer_style2 = (XSSFCellStyle) createBorderedStyle(wb);
		integer_style2.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style2.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style2.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style2.setFont(Font);
		integer_style2.setDataFormat(nf2);
		styles.put("integer_style2", integer_style2);

		integer_style3 = (XSSFCellStyle) createBorderedStyle(wb);
		integer_style3.setAlignment(CellStyle.ALIGN_LEFT);
		integer_style3.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		integer_style3.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style3.setFont(Font);
		integer_style3.setDataFormat(nf1);
		styles.put("integer_style3", integer_style3);

		normal_style = (XSSFCellStyle) createBorderedStyle(wb);
		normal_style.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normal_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normal_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style.setFont(Font);
		styles.put("normal_style", normal_style);

		normalRed_style = (XSSFCellStyle) createBorderedStyle(wb);
		normalRed_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalRed_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normalRed_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalRed_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalRed_style.setFont(FontRed);
		styles.put("normalRed_style", normalRed_style);

		normalBold_style = (XSSFCellStyle) createBorderedStyle(wb);
		normalBold_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalBold_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		normalBold_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalBold_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalBold_style.setFont(Font2);
		styles.put("normalBold_style", normalBold_style);

		percentage_style = (XSSFCellStyle) createBorderedStyle(wb);
		percentage_style.setAlignment(CellStyle.ALIGN_LEFT);
		percentage_style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		percentage_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		percentage_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		percentage_style.setFont(Font);
		percentage_style.setDataFormat(pf);
		styles.put("percentage_style", percentage_style);

		no_style = noBorder(wb);
		styles.put("no_style", no_style);

		styleForsummary = (XSSFCellStyle) createBorderedStyle(wb);
		styleForsummary.setAlignment(CellStyle.ALIGN_LEFT);
		styleForsummary.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		styleForsummary.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(242, 242, 242)));
		styleForsummary.setFillPattern(CellStyle.SOLID_FOREGROUND);
		styleForsummary.setFont(FontCalibri9);
		styles.put("summary_main", styleForsummary);

		styleForsummary2 = (XSSFCellStyle) createBorderedStyle(wb);
		styleForsummary2.setAlignment(CellStyle.ALIGN_LEFT);
		styleForsummary2.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		styleForsummary2.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(229, 224, 236)));
		styleForsummary2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		styleForsummary2.setFont(FontCalibri9);
		styles.put("summary_border", styleForsummary2);

		return styles;

	}

	private XSSFCellStyle noBorder(SXSSFWorkbook wb) {
		XSSFCellStyle style = (XSSFCellStyle) wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_NONE);
		style.setBorderBottom(CellStyle.BORDER_NONE);
		style.setBorderLeft(CellStyle.BORDER_NONE);
		style.setBorderTop(CellStyle.BORDER_NONE);

		return style;
	}

}
