package com.vit.ai.bulkmanager.dao;

import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.bulkmanager.model.BulkToHIModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.ProcessBuilderRunner;
import com.vit.dbconnection.ConnectDB;

public class BulkToHIDAO {

	private static Logger log = LoggerFactory.getLogger(BulkToHIDAO.class);
	
	private String clientIds;
	private String startDates;
	private String endDates;
	private String userLogs;
	private String jarPaths;
	private String reportLocations;
	private String reportIds;
	

	public void insertReportInfo(String clientId, Date bulkStartDate,
			Date bulkEndDate, String userLog) {
		// TODO Auto-generated method stub
		String maxReportIdQuery = "SELECT Nvl(Max(reportid)+1, 1) FROM aip_bulk_report_log";
		String startDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(bulkStartDate);
		String endDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(bulkEndDate);
		String createdDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(new Date());
		this.clientIds = clientId;
		this.startDates = startDate;
		this.endDates = endDate;
		this.userLogs = userLog;
		//String jarPath = "O:\\Operations\\AIP\\AIP-aypokhrel\\AIP Production\\BRReport\\BulkReconReport.jar";
		//String reportLocation = "O:\\Operations\\AIP\\AIP-aypokhrel";
		
		String jarPath = AIConstant.BULKTOHIRECON_JARLOCATION + "/BulkReconReport.jar";
		String reportLocation = AIConstant.BULKTOHIRECON_OUTPUTLOCATION;
				
		String OS = System.getProperty("os.name").toLowerCase();
		if (OS.indexOf("win") >= 0) {
			jarPath = AIConstant.LOCAL_BULKTOHIRECON_JARLOCATION + "/BulkReconReport.jar";
			reportLocation = AIConstant.LOCAL_BULKTOHIRECON_OUTPUTLOCATION;
		}
		this.jarPaths = jarPath;
		this.reportLocations = reportLocation;
		
		ConnectDB db = new ConnectDB();
		String reportId = "";
		try {
			db.initialize();
			List<List<String>> result = db.resultSetToListOfList(maxReportIdQuery);
			reportId = result.get(1).get(0);
			log.info("The max id need to be added is: " + reportId);
			String insertReportInfoQuery = "INSERT INTO aip_bulk_report_log VALUES (" + reportId + ", " +
											clientId + ", '" + userLog + "', To_Date('" +  
											createdDate + "','DD.MM.YYYY HH24:MI:SS'), To_Date('" +
											startDate + "', 'DD.MM.YYYY HH24:MI:SS'), To_Date('" +
											endDate + "', 'DD.MM.YYYY HH24:MI:SS'), " +
											"'RUNNING')";
			db.executeDML(insertReportInfoQuery);
			log.info("The report info inserted.");
		} catch (Exception e) {
			log.info("The exception in getting Report ID is: " + e.toString());
		} finally {
			db.endConnection();
		}
		this.reportIds = reportId;
		this.startDates = new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(bulkStartDate);
		this.endDates = new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(bulkEndDate);
		try {
			new Thread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					ProcessBuilderRunner.runBulkToHIReconjar(clientIds, reportIds, reportLocations, jarPaths, 
							startDates,
							endDates);
					log.info("The jar has been started.");
				}
			}).start();
			/*ProcessBuilderRunner.runBulkToHIReconjar(clientId, reportId, reportLocation, jarPath, 
					new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(bulkStartDate),
					new SimpleDateFormat("yyyyMMdd HH:mm:ss").format(bulkEndDate));
			log.info("The jar has been started.");*/
		} catch (Exception e) {
			log.info("Exception in bulk to HI Recon jar runner: " + e.getMessage());
		}
	}

	public static ArrayList<BulkToHIModel> getBulkList() {
		// TODO Auto-generated method stub
		ArrayList<BulkToHIModel> bthm = new ArrayList<BulkToHIModel>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT reportid,clientid,userlog,createddate,startdate,enddate,report_status FROM aip_bulk_report_log ORDER BY createdDate desc";
		List<List<String>> rs = db.resultSetToListOfList(query);
		try{
			if(rs!=null)
			{
				if(rs.size() > 1)
				{
					for(int i=1;i<rs.size();i++)
					{
						BulkToHIModel object = new BulkToHIModel(rs.get(i).get(0),rs.get(i).get(1),rs.get(i).get(2),rs.get(i).get(3),rs.get(i).get(4),rs.get(i).get(5),rs.get(i).get(6));
						bthm.add(object);
					}
				}
				log.info("The bulkToHI controller model query size is: " + bthm.size());
			}
		}
		catch (Exception ex)
		{
			log.error("Bulk To HI Query Failed.: " + ex.toString());
			
		}
		finally
		{
			db.endConnection();
		}
			return bthm;
		}
	
}
