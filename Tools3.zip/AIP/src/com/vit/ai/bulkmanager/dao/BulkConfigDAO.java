package com.vit.ai.bulkmanager.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;


import com.vit.ai.bulkmanager.model.BulkConfigModel;
import com.vit.ai.bulkmanager.model.BulkControlTotalModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.inventory.controller.MainLogBean;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version : 1.0.0
 * 
 * Data Access Class for Bulk Config
 * 
 */
public class BulkConfigDAO {
	
	private ArrayList<BulkConfigModel> listofConfigurations;
	private static Logger log = Logger.getLogger(MainLogBean.class.getName());
	
	
	public ArrayList<BulkConfigModel> getAllConfigurations(String clientid)
	{
		
		
		this.listofConfigurations = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		try
		{
			db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,AIConstant.RAC_SERVICE_SID, "BULKFM", "local");
		String query = "select layoutid, datatype, distribution_type, delimiter, clientid, payor, layout_detail, field_start, field_end, field_position, entered_by, entered_time from bulk_layout_info where clientid = '" + clientid + "' order by 1 desc";
		List<List<String>> rs = db.resultSetToListOfList(query);
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					BulkConfigModel object = new BulkConfigModel(rs.get(i).get(0),rs.get(i).get(1),rs.get(i).get(2),rs.get(i).get(3),rs.get(i).get(4),rs.get(i).get(5),rs.get(i).get(6),rs.get(i).get(7),rs.get(i).get(8),rs.get(i).get(9),rs.get(i).get(10),rs.get(i).get(11));
					object.retrievePolicies();
					this.listofConfigurations.add(object);
				}
			}
		}
		}
		catch(Exception ex)
		{
			log.error("Config DAO Query Failed.: " + ex.toString());
			
		}
		finally
		{
			db.endConnection();
		}
		
		
		return this.listofConfigurations;
		
	}


	public ArrayList<BulkConfigModel> getListofConfigurations() {
		return listofConfigurations;
	}


	public void setListofConfigurations(ArrayList<BulkConfigModel> listofConfigurations) {
		this.listofConfigurations = listofConfigurations;
	}

}
