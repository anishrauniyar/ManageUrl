package com.vit.ai.bulkmanager.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.bulkmanager.model.BulkControlTotalModel;
import com.vit.ai.constant.AIConstant;
import com.vit.dbconnection.ConnectDB;

public class BulkControlTotalDAO {

	private static Logger log = LoggerFactory.getLogger(BulkControlTotalDAO.class); 
	
	public static List<BulkControlTotalModel> getBulkControlTotalList(
			String clientId, String startDate, String endDate) {
		// TODO Auto-generated method stub
		List<BulkControlTotalModel> bctm = new ArrayList<BulkControlTotalModel>();
		ConnectDB db = new ConnectDB();
		try
		{
			/*db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,AIConstant.RAC_SERVICE_SID, AIConstant.DEFAULT_SCHEMA_NAME, "local");*/
			log.info("Initializing the connection......");
			//db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,AIConstant.RAC_SERVICE_SID, AIConstant.DEFAULT_SCHEMA_NAME, "local");
			db.initialize();
			log.info("Connection Established!!!!");
			String query = "SELECT controltype,fileid,filename,receivedmonth,category,shortpayor,payername,vh_record_cnt,v_record_cnt,var_rec_count,clientid,datalayoutid,ctlfileid,ctldmfileid,ctlfilename,ctllayout,datafiledate,ctlfiledate,ctl_status,aip_file_id,dmfileid,data_processdate" + 
					" FROM aip_bulkfm_ctl WHERE clientid = " + clientId + 
					" AND data_processdate BETWEEN To_Date('"+startDate+"', 'DD.MM.YYYY HH24:MI:SS') AND " +
					" To_Date('"+endDate+"', 'DD.MM.YYYY HH24:MI:SS')";
			log.info("The bulk control total query  is: " + query);
			List<List<String>> rs = db.resultSetToListOfList(query);
			if(rs!=null)
			{
				if(rs.size() > 1)
				{
					for(int i=1;i<rs.size();i++)
					{
						BulkControlTotalModel object = new BulkControlTotalModel(rs.get(i).get(0),rs.get(i).get(1),rs.get(i).get(2),rs.get(i).get(3),rs.get(i).get(4),rs.get(i).get(5),rs.get(i).get(6),rs.get(i).get(7),rs.get(i).get(8),rs.get(i).get(9),rs.get(i).get(10),rs.get(i).get(11),rs.get(i).get(12),rs.get(i).get(13),rs.get(i).get(14),rs.get(i).get(15),rs.get(i).get(16),rs.get(i).get(17),rs.get(i).get(18),rs.get(i).get(19),rs.get(i).get(20),rs.get(i).get(21));
						bctm.add(object);
					}
				}
				log.info("The bulk controller model query value is: " + bctm.indexOf("controltype"));
			}
		}
		catch(Exception ex)
		{
			log.error("Bulk Control Total Query Failed.: " + ex.toString());
			
		}
		finally
		{
			db.endConnection();
		}
		
		
		return bctm;
	}
	
}
