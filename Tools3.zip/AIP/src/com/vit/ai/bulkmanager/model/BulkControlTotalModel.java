package com.vit.ai.bulkmanager.model;

public class BulkControlTotalModel {
	
	private String controlType;
	private String fileId;
	private String fileName;
	private String receivedMonth;
	private String category;
	private String shortPayor;
	private String payerName;
	private String vhRecordCnt;
	private String vRecordCnt;
	private String varRecCount;
	private String clientId;
	private String dataLayoutId;
	private String ctlFileId;
	private String ctlDmFileId;
	private String ctlFileName;
	private String ctlLayout;
	private String dataFileDate;
	private String ctlFileDate;
	private String ctlStatus;
	private String aipFileId;
	private String dmFileId;
	private String dataProcessDate;
	
	public BulkControlTotalModel(String controlType, String fileId,
			String fileName, String receivedMonth, String category,
			String shortPayor, String payerName, String vhRecordCnt,
			String vRecordCnt, String varRecCount, String clientId,
			String dataLayoutId, String ctlFileId, String ctlDmFileId,
			String ctlFileName, String ctlLayout, String dataFileDate,
			String ctlFileDate, String ctlStatus, String aipFileId,
			String dmFileId, String dataProcessDate) {
		super();
		this.controlType = controlType;
		this.fileId = fileId;
		this.fileName = fileName;
		this.receivedMonth = receivedMonth;
		this.category = category;
		this.shortPayor = shortPayor;
		this.payerName = payerName;
		this.vhRecordCnt = vhRecordCnt;
		this.vRecordCnt = vRecordCnt;
		this.varRecCount = varRecCount;
		this.clientId = clientId;
		this.dataLayoutId = dataLayoutId;
		this.ctlFileId = ctlFileId;
		this.ctlDmFileId = ctlDmFileId;
		this.ctlFileName = ctlFileName;
		this.ctlLayout = ctlLayout;
		this.dataFileDate = dataFileDate;
		this.ctlFileDate = ctlFileDate;
		this.ctlStatus = ctlStatus;
		this.aipFileId = aipFileId;
		this.dmFileId = dmFileId;
		this.dataProcessDate = dataProcessDate;
	}
	
	public String getAipFileId() {
		return aipFileId;
	}
	public void setAipFileId(String aipFileId) {
		this.aipFileId = aipFileId;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	public String getControlType() {
		return controlType;
	}
	public void setControlType(String controlType) {
		this.controlType = controlType;
	}
	
	public String getCtlDmFileId() {
		return ctlDmFileId;
	}
	public void setCtlDmFileId(String ctlDmFileId) {
		this.ctlDmFileId = ctlDmFileId;
	}
	
	public String getCtlFileDate() {
		return ctlFileDate;
	}
	public void setCtlFileDate(String ctlFileDate) {
		this.ctlFileDate = ctlFileDate;
	}
	
	public String getCtlFileId() {
		return ctlFileId;
	}
	public void setCtlFileId(String ctlFileId) {
		this.ctlFileId = ctlFileId;
	}
	
	public String getCtlFileName() {
		return ctlFileName;
	}
	public void setCtlFileName(String ctlFileName) {
		this.ctlFileName = ctlFileName;
	}
	
	public String getCtlLayout() {
		return ctlLayout;
	}
	public void setCtlLayout(String ctlLayout) {
		this.ctlLayout = ctlLayout;
	}
	
	public String getCtlStatus() {
		return ctlStatus;
	}
	public void setCtlStatus(String ctlStatus) {
		this.ctlStatus = ctlStatus;
	}
	
	public String getDataFileDate() {
		return dataFileDate;
	}
	public void setDataFileDate(String dataFileDate) {
		this.dataFileDate = dataFileDate;
	}
	
	public String getDataLayoutId() {
		return dataLayoutId;
	}
	public void setDataLayoutId(String dataLayoutId) {
		this.dataLayoutId = dataLayoutId;
	}
	
	public String getDataProcessDate() {
		return dataProcessDate;
	}
	public void setDataProcessDate(String dataProcessDate) {
		this.dataProcessDate = dataProcessDate;
	}
	
	public String getDmFileId() {
		return dmFileId;
	}
	public void setDmFileId(String dmFileId) {
		this.dmFileId = dmFileId;
	}
	
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getPayerName() {
		return payerName;
	}
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}
	
	public String getReceivedMonth() {
		return receivedMonth;
	}
	public void setReceivedMonth(String receivedMonth) {
		this.receivedMonth = receivedMonth;
	}
	
	public String getShortPayor() {
		return shortPayor;
	}
	public void setShortPayor(String shortPayor) {
		this.shortPayor = shortPayor;
	}
	
	public String getVarRecCount() {
		return varRecCount;
	}
	public void setVarRecCount(String varRecCount) {
		this.varRecCount = varRecCount;
	}
	
	public String getVhRecordCnt() {
		return vhRecordCnt;
	}
	public void setVhRecordCnt(String vhRecordCnt) {
		this.vhRecordCnt = vhRecordCnt;
	}
	
	public String getvRecordCnt() {
		return vRecordCnt;
	}
	public void setvRecordCnt(String vRecordCnt) {
		this.vRecordCnt = vRecordCnt;
	}
	
	
	
	
}
