package com.vit.ai.bulkmanager.model;

import java.util.Date;

public class BulkToHIModel {

	public String reportId;
	public String clientId;
	public String userLog;
	public String createdDate;
	public String startDate;
	public String endDate;
	public String status;
	
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getUserLog() {
		return userLog;
	}
	public void setUserLog(String userLog) {
		this.userLog = userLog;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public BulkToHIModel(String reportId, String clientId, String userLog,
			String createdDate, String startDate, String endDate, String status) {
		super();
		this.reportId = reportId;
		this.clientId = clientId;
		this.userLog = userLog;
		this.createdDate = createdDate;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
	}
	public BulkToHIModel() {
		super();
	}
	
}
