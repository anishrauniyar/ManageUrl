package com.vit.ai.bulkmanager.model;

public class BulkChildModel {
	
	private String sn="";
	private String dmfileid ="";
	private String child_fileid = "";
	private String child_filename = "";
	private String child_fileSize = "";
	private String child_filedate = "";
	private String child_checksum = "";
	private String datatype = "";
	private String policynum = "";
	private String info_starttime="";
	private String info_endtime="";
	private String processstatus = "";
	private String processedpath = "";
	private String ftpstatus = "";
	private String src_clientid = "";
	private String eigertransferdate="";
	private String layoutId="";
	private String child_recordcnt = "";
	
	public BulkChildModel(String sn, String dmfileid, String child_fielid,
			String child_filename, String child_fileSize,String child_recordcnt,
			String child_filedate, String child_checksum, String datatype,
			String policynum, String info_starttime, String info_endtime,
			String processstatus, String processedpath, String ftpstatus,
			String src_clientid,String eigertransferdate,String layoutid) {
		super();
		this.sn = sn;
		this.dmfileid = dmfileid;
		this.child_fileid = child_fielid;
		this.child_filename = child_filename;
		this.child_fileSize = child_fileSize;
		this.child_filedate = child_filedate;
		this.child_checksum = child_checksum;
		this.child_recordcnt = child_recordcnt;
		this.datatype = datatype;
		this.policynum = policynum;
		this.info_starttime = info_starttime;
		this.info_endtime = info_endtime;
		this.processstatus = processstatus;
		this.processedpath = processedpath;
		this.ftpstatus = ftpstatus;
		this.src_clientid = src_clientid;
		this.eigertransferdate = eigertransferdate;
		this.layoutId = layoutid;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getDmfileid() {
		return dmfileid;
	}
	public void setDmfileid(String dmfileid) {
		this.dmfileid = dmfileid;
	}
	public String getChild_fileid() {
		return child_fileid;
	}
	public void setChild_fielid(String child_fileid) {
		this.child_fileid = child_fileid;
	}
	public String getChild_filename() {
		return child_filename;
	}
	public void setChild_filename(String child_filename) {
		this.child_filename = child_filename;
	}
	public String getChild_fileSize() {
		return child_fileSize;
	}
	public void setChild_fileSize(String child_fileSize) {
		this.child_fileSize = child_fileSize;
	}
	public String getChild_filedate() {
		return child_filedate;
	}
	public void setChild_filedate(String child_filedate) {
		this.child_filedate = child_filedate;
	}
	public String getChild_checksum() {
		return child_checksum;
	}
	public void setChild_checksum(String child_checksum) {
		this.child_checksum = child_checksum;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getPolicynum() {
		return policynum;
	}
	public void setPolicynum(String policynum) {
		this.policynum = policynum;
	}
	public String getInfo_starttime() {
		return info_starttime;
	}
	public void setInfo_starttime(String info_starttime) {
		this.info_starttime = info_starttime;
	}
	public String getInfo_endtime() {
		return info_endtime;
	}
	public void setInfo_endtime(String info_endtime) {
		this.info_endtime = info_endtime;
	}
	public String getProcessstatus() {
		return processstatus;
	}
	public void setProcessstatus(String processstatus) {
		this.processstatus = processstatus;
	}
	public String getProcessedpath() {
		return processedpath;
	}
	public void setProcessedpath(String processedpath) {
		this.processedpath = processedpath;
	}
	public String getFtpstatus() {
		return ftpstatus;
	}
	public void setFtpstatus(String ftpstatus) {
		this.ftpstatus = ftpstatus;
	}
	public String getSrc_clientid() {
		return src_clientid;
	}
	public void setSrc_clientid(String src_clientid) {
		this.src_clientid = src_clientid;
	}
	public String getEigertransferdate() {
		return eigertransferdate;
	}
	public void setEigertransferdate(String eigertransferdate) {
		this.eigertransferdate = eigertransferdate;
	}
	public String getLayoutId() {
		return layoutId;
	}
	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}
	public String getChild_recordcnt() {
		return child_recordcnt;
	}
	public void setChild_recordcnt(String child_recordcnt) {
		this.child_recordcnt = child_recordcnt;
	}

	

}
