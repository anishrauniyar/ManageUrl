/*
 *Class Name : BulkReconciliationModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.bulkmanager.model;

import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 *
 * @version 1.0 4 April 2016
 */
public class BulkChildReconciliationModel {

	private String childFileID, childfileName,childFileSize,childRecordCount,
	dataType, processStatus,ftpStatus,destClientID,processedpath;

	public String getChildfileName() {
		return childfileName;
	}


	public void setChildfileName(String childfileName) {
		this.childfileName = childfileName;
	}


	public String getChildRecordCount() {
		return childRecordCount;
	}


	public void setChildRecordCount(String childRecordCount) {
		this.childRecordCount = childRecordCount;
	}


	public String getDataType() {
		return dataType;
	}


	public void setDataType(String dataType) {
		this.dataType = dataType;
	}


	public String getProcessStatus() {
		return processStatus;
	}


	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}


	public String getFtpStatus() {
		return ftpStatus;
	}


	public void setFtpStatus(String ftpStatus) {
		this.ftpStatus = ftpStatus;
	}


	public String getDestClientID() {
		return destClientID;
	}


	public void setDestClientID(String destClientID) {
		this.destClientID = destClientID;
	}


	public String getChildFileID() {
		return childFileID;
	}


	public void setChildFileID(String childFileID) {
		this.childFileID = childFileID;
	}


	public String getChildFileSize() {
		return childFileSize;
	}


	public void setChildFileSize(String childFileSize) {
		this.childFileSize = childFileSize;
	}


	public BulkChildReconciliationModel(String fileid,String childfilename,String childFilesize,
			String childReccount,String datatype,String processStatus,String ftpSttaus,String destClientID,String processedpath){
		this.childFileID=fileid;
		this.childfileName=childfilename;
		this.childFileSize=childFilesize;
		this.childRecordCount=childReccount;
		this.dataType=datatype;
		this.processStatus=processStatus;
		this.ftpStatus=ftpSttaus;
		this.destClientID=destClientID;
		this.setProcessedpath(processedpath);		
				
		
		
	}
	
	
	public BulkChildReconciliationModel(){
		
	}


	public String getProcessedpath() {
		return processedpath;
	}


	public void setProcessedpath(String processedpath) {
		this.processedpath = processedpath;
	}
	
	
	
	
	

}
