/*
 *Class Name : BulkReconciliationModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.bulkmanager.model;

import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 *
 * @version 1.0 4 April 2016
 */
public class BulkReconciliationModel {

	private String clientID;
	private String dmfileID;
	private String fileName;
	private String fileSize;
	private String fileDate;
	private String eigerTransferDate;
	private String fileStatus;
	private String actionName;
	private String actionStatus;
	private String layoutID;
	private String totalPolicyNum;
	private String matchedPollicyNum;
	private String unmatchedpolicyNum;
	private String recordCount;
	private String prevdmFileID;
	private int sn;
	private ArrayList<BulkChildReconciliationModel> childInfo;

	public ArrayList<BulkChildReconciliationModel> getChildInfo() {
		return childInfo;
	}
	public void setChildInfo(ArrayList<BulkChildReconciliationModel> childInfo) {
		this.childInfo = childInfo;
	}
	public BulkReconciliationModel(int sn,String dmfilID,String prevDmfileid,String fileName,String fileSize,String fileDate,String eigerTransferDate,
			String fileStatus, String actionName,String actionStatuss,String layoutiD,String totalPolicyNum,String matchedPolicyNum,
			String unmatchedPolicyNum,String recordCount){
		this.sn=sn;
		this.dmfileID=dmfilID;
		this.prevdmFileID=prevDmfileid;
		this.fileName=fileName;
		this.fileSize=fileSize;
		this.fileDate=fileDate;
		this.eigerTransferDate=eigerTransferDate;
		this.fileStatus=fileStatus;
		this.actionName=actionName;
		this.actionStatus=actionStatuss;
		this.layoutID=layoutiD;
		this.totalPolicyNum=totalPolicyNum;
		this.matchedPollicyNum=matchedPolicyNum;
		this.unmatchedpolicyNum=unmatchedPolicyNum;
		this.recordCount=recordCount;
		
		setChildInformation();
		
	}
	public void setChildInformation() {
		
		String query = "select CHILD_FILEID,CHILD_FILENAME,CHILD_FILESIZE,CHILD_RECORDCNT,DATATYPE,PROCESSSTATUS,FTPSTATUS,DEST_CLIENTID,PROCESSEDPATH from aip_dashboard_bulkfm_child where DMFILEID='"
				 + this.dmfileID + "'";
	
		
		ConnectDB db = new ConnectDB();
		db.initializeBulk();
		childInfo = new ArrayList<>();
		List<List<String>> rs = db.resultSetToListOfList(query);
		if (rs.size() > 0) {
			for (int i = 1; i < rs.size(); i++) {
				System.out.println("Child info "+rs.get(i).get(0));
				childInfo.add(new BulkChildReconciliationModel(rs.get(i).get(0),rs.get(i).get(1),rs.get(i).get(2),rs.get(i).get(3)
						,rs.get(i).get(4),rs.get(i).get(5),rs.get(i).get(6),rs.get(i).get(7),rs.get(i).get(8)));
				
			}
		}
		db.endConnection();
		
	}
	
	public BulkReconciliationModel(){
		
	}
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getDmfileID() {
		return dmfileID;
	}
	public void setDmfileID(String dmfileID) {
		this.dmfileID = dmfileID;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getFileDate() {
		return fileDate;
	}
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}
	public String getEigerTransferDate() {
		return eigerTransferDate;
	}
	public void setEigerTransferDate(String eigerTransferDate) {
		this.eigerTransferDate = eigerTransferDate;
	}
	public String getFileStatus() {
		return fileStatus;
	}
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
	public String getActionName() {
		return actionName;
	}
	public void setActionName(String actionName) {
		this.actionName = actionName;
	}
	public String getActionStatus() {
		return actionStatus;
	}
	public void setActionStatus(String actionStatus) {
		this.actionStatus = actionStatus;
	}
	public String getLayoutID() {
		return layoutID;
	}
	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}
	public String getTotalPolicyNum() {
		return totalPolicyNum;
	}
	public void setTotalPolicyNum(String totalPolicyNum) {
		this.totalPolicyNum = totalPolicyNum;
	}
	public String getMatchedPollicyNum() {
		return matchedPollicyNum;
	}
	public void setMatchedPollicyNum(String matchedPollicyNum) {
		this.matchedPollicyNum = matchedPollicyNum;
	}
	public String getUnmatchedpolicyNum() {
		return unmatchedpolicyNum;
	}
	public void setUnmatchedpolicyNum(String unmatchedpolicyNum) {
		this.unmatchedpolicyNum = unmatchedpolicyNum;
	}
	public String getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(String recordCount) {
		this.recordCount = recordCount;
	}
	
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
	public String getPrevdmFileID() {
		return prevdmFileID;
	}
	public void setPrevdmFileID(String prevdmFileID) {
		this.prevdmFileID = prevdmFileID;
	}
	
	
	
	

}
