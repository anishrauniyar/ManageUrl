package com.vit.ai.bulkmanager.model;

import java.util.ArrayList;
import java.util.List;

import com.vit.ai.constant.AIConstant;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version : 1.0.0
 * 
 *          Model Class for Bulk Configuration
 * 
 */

public class BulkConfigModel {

	public BulkConfigModel() {

	}
	public BulkConfigModel(String client) {
		this.clientid = client;

	}

	public String getDistribution_type() {
		return distribution_type;
	}

	public BulkConfigModel(String layoutid, String datatype,
			String distribution_type, String delimeter, String clientid,
			String payor, String layout_detail, String fieldStart,
			String fieldEnd, String fieldPosition, String createdBy,
			String createdDate) {
		super();
		this.layoutid = layoutid;
		this.datatype = datatype;
		this.distribution_type = distribution_type;
		this.delimeter = delimeter;
		this.clientid = clientid;
		this.payor = payor;
		this.layout_detail = layout_detail;
		this.fieldStart = fieldStart;
		this.fieldEnd = fieldEnd;
		this.fieldPosition = fieldPosition;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public void setDistribution_type(String distribution_type) {
		this.distribution_type = distribution_type;
	}

	public String getDelimeter() {
		return delimeter;
	}

	public void setDelimeter(String delimeter) {
		
		System.out.println(delimeter);
		this.delimeter = delimeter;
	}

	public String getLayout_detail() {
		return layout_detail;
	}

	public void setLayout_detail(String layout_detail) {
		this.layout_detail = layout_detail;
	}

	private String layoutid="";
	private String datatype="";
	private String distribution_type="";
	private String delimeter="";
	private String clientid="";
	private String payor="";
	private String layout_detail="";
	private String fieldStart="";
	private String fieldEnd="";
	private String fieldPosition="";
	private String createdBy="";
	private String createdDate="";
	private ArrayList<PolicyModel> policies;

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public String getFieldStart() {
		return fieldStart;
	}

	public void setFieldStart(String fieldStart) {
		this.fieldStart = fieldStart;
	}

	public String getFieldEnd() {
		return fieldEnd;
	}

	public void setFieldEnd(String fieldEnd) {
		this.fieldEnd = fieldEnd;
	}

	public String getFieldPosition() {
		return fieldPosition;
	}

	public void setFieldPosition(String fieldPosition) {
		this.fieldPosition = fieldPosition;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * This method retrieves all the policies associated with this
	 * configurations
	 */
	public void retrievePolicies() {
		this.policies = new ArrayList<>();
		if (this.layoutid != null || !(this.layoutid.isEmpty())) {
			String query = "SELECT sn, bulkclientid, layoutid, policy, destclientid, groupname FROM bulk_client_policy_info where layoutid = '" + this.layoutid + "'";

			ConnectDB db = new ConnectDB();
			try {
				db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,AIConstant.RAC_SERVICE_SID, "BULKFM", "local");
				List<List<String>> rs = db.resultSetToListOfList(query);
				if (rs != null) {
					if (rs.size() > 1) {
						for (int i = 1; i < rs.size(); i++) {
							PolicyModel model = new PolicyModel(rs.get(i)
									.get(0), rs.get(i).get(1),
									rs.get(i).get(2), rs.get(i).get(3), rs.get(
											i).get(4), rs.get(i).get(5));
							this.policies.add(model);
						}
					}
				}
			} catch (Exception ex) {
				System.out.println("Error retrieving policy :" + ex.toString());
			} finally {
				db.endConnection();
			}

		}
	}

	public ArrayList<PolicyModel> getPolicies() {
		return policies;
	}

	public void setPolicies(ArrayList<PolicyModel> policies) {
		this.policies = policies;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public boolean policiesExists()
	{
		if(this.policies.size()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
