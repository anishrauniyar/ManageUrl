package com.vit.ai.bulkmanager.model;

public class PolicyModel {
	
	private String layoutid="";
	private String policy="";
	private String destclient="";
	private String groupname="";
	private String sn="";
	private String client="";
	
	public String getLayoutid() {
		return layoutid;
	}
	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}
	public String getPolicy() {
		return policy;
	}
	public void setPolicy(String policy) {
		this.policy = policy;
	}
	public String getDestclient() {
		return destclient;
	}
	public void setDestclient(String destclient) {
		this.destclient = destclient;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	
	
	public PolicyModel()
	{
		
	}
	
	public PolicyModel(String sn,String client,String lid, String policy , String destclient, String groupname)
	{
		this.layoutid = lid;
		this.policy = policy;
		this. destclient = destclient;
		this.groupname = groupname; 
		this.sn = sn;
		this.client = client;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	

}
