package com.vit.ai.bulkmanager.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import com.vit.ai.bulkmanager.model.BulkConfigModel;
import com.vit.ai.bulkmanager.model.PolicyModel;
import com.vit.ai.commons.model.DataType;
import com.vit.ai.commons.model.HRPayerBean;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class PolicyController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = -4541786784767472937L;
	
	private Logger log = Logger.getLogger(PolicyController.class);
	
	private LinkedHashMap<String, String> allClients;
	private String client = "";
	private String winScreenHeight;
	private ArrayList<PolicyModel> filteredLogs;

	private PolicyModel addPolicyModel = new PolicyModel();
	private ArrayList<String> employergroups = new ArrayList<>();
	
	private boolean changesinPolicy = false;
	private PolicyModel editPolicyModel = new PolicyModel();
	private String layoutId= "";
	private ArrayList<PolicyModel> policies;
	private String policynum="";
	private String clientName="";
	private boolean toggleEmp=false;


	public ArrayList<PolicyModel> getPolicies() {
		return policies;
	}

	public void setPolicies(ArrayList<PolicyModel> policies) {
		this.policies = policies;
	}

	public void populateEmpGroups(PolicyModel obj) {

		setChangesinPolicy(true);
		if (obj.getDestclient() != null || !obj.getDestclient().isEmpty()) {
			//String query = "SELECT DISTINCT groupname FROM bulk_client_policy_info WHERE DESTCLIENTID='" + obj.getDestclient() + "' order by 1";
			/*String query = "SELECT DISTINCT STANDARDEMPLOYERNAME FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" a left JOIN bulk_client_policy_info b ON b.GROUPNAME = a.STANDARDEMPLOYERID WHERE b.DESTCLIENTID ='" 
							+ obj.getDestclient() + "' order by 1";*/
			String query = "SELECT DISTINCT STANDARDEMPLOYERNAME FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" WHERE STANDARDCLIENTID ='"+obj.getDestclient()+"' AND DELETED = 0 ";
			log.info("Emp Query: " + query);
			ConnectDB db = new ConnectDB();
			db.initializeBulk();
			List<List<String>> employeeList = db.resultSetToListOfList(query);
			db.endConnection();
			employergroups = new ArrayList<String>();
			if (employeeList.size() > 0) {
				for (int i = 1; i < employeeList.size(); i++) {
					employergroups.add(employeeList.get(i).get(0));

				}
			}
		}

	}

	public void toggleEmpgrp()
	{
		if(this.toggleEmp)
		{
			this.toggleEmp = false;
		}
		else
		{
			this.toggleEmp = true;
		}
		System.out.println("Toggle Employer group : " + this.toggleEmp);
	}

	public PolicyController() {

		

		if(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid")!=null)
		{
			this.setLayoutId(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("lid"));
		}
		else
		{
			this.setLayoutId("");
		}

		if(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("clid")!=null)
		{
			this.setClient(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("clid"));
		 setClientName(clientName);
		}
		else
		{
			this.setLayoutId("");
		}
		
		
		
		

		if( this.layoutId==null || this.layoutId.isEmpty())
		{
			displayErrorMessageToUser("No Bulk Layout Selected", "Select a Bulk Layout");
			
		}
		else
		{
		this.allClients = new LinkedHashMap<>();
		setAllClients(allClients);
		retrievePolicies();
		}

		

		if(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("policynum")!=null)
		{
			this.setPolicynum(FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("policynum"));
			
		}
		else
		{
			this.setPolicynum("");
		}
		this.toggleEmp = false;
	}

	

	/**
	 * @return The new instance for config Model
	 * 
	 */
	
	public void setValue() {
		this.winScreenHeight = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("winScreenHeight");

	}

	

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	
	
	public PolicyModel getAddPolicyModel() {
		return addPolicyModel;
	}

	public void setAddPolicyModel(PolicyModel addPolicyModel) {
		this.addPolicyModel = addPolicyModel;
	}

	public ArrayList<String> getEmployergroups() {
		return employergroups;
	}

	public void setEmployergroups(ArrayList<String> employergroups) {
		this.employergroups = employergroups;
	}

	public LinkedHashMap<String, String> getAllClients() {
		return allClients;
	}

	public void setAllClients(LinkedHashMap<String, String> allClients) {
		String query = "SELECT A.CLIENTID, B.CLIENTNAME "
				+ "      FROM ( "
				+ "      SELECT CLIENTID FROM IMP_CLIENTPATTERNS GROUP BY CLIENTID "
				+ "      ) A " + "      LEFT JOIN "
				+ "      HAWKEYEMASTER.M_CLIENTS B "
				+ "      ON A.CLIENTID = B.CLIENTID  ORDER BY CLIENTID asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		System.out.println(query);
		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				allClients.put(
						clList.get(i).get(0) + "-(" + clList.get(i).get(1)
								+ ")", clList.get(i).get(0));
			}
		}
		this.allClients = allClients;
	}

	/**
	 * @param obj1
	 *            Bulk COnfig Model : Parent object for Policy Model
	 * 
	 *            Initializes object before opening policy add form
	 * 
	 */
	public void openAdd() {
		System.out.println("openinng add");
		
		this.addPolicyModel = new PolicyModel();
		this.addPolicyModel.setClient(this.client);
		this.addPolicyModel.setLayoutid(this.layoutId);
		if(!this.policynum.isEmpty())
		{
			this.addPolicyModel.setPolicy(this.policynum);
		}
		RequestContext.getCurrentInstance().execute("PF('addD').show();");
	}
	
	

	public void openEditPolicy(PolicyModel obj) {
		System.out.println("openinng edit");

		this.editPolicyModel = new PolicyModel();
		
		this.editPolicyModel = obj;
		this.editPolicyModel.setClient(this.client);
		this.editPolicyModel.setLayoutid(this.layoutId);
		populateEmpGroups(obj);
		this.changesinPolicy = false;
		RequestContext.getCurrentInstance().execute("PF('editPD').show();");
	}

	public void deletePolicy(PolicyModel obj) {
		if (obj != null) {
			this.policies.remove(obj);
			String query = "delete from bulk_client_policy_info where sn = '"
					+ obj.getSn() + "'";
			ConnectDB db = new ConnectDB();
			db.initializeBulk();
			String stat = db.executeDML(query);
			db.endConnection();
			if (stat.compareTo("1") == 0) {
				displayInfoMessageToUser("Deleted successfully",
						"Delete Policy Configuration");
				refilter();
			} else {
				displayErrorMessageToUser("Could not delete",
						"Delete Policy Configuration");
				this.policies.add(obj);
				
			}
		}
	}

	public void addPolicyMappings(PolicyModel obj) {
		if(obj!=null)
		{
		if(obj.getPolicy().isEmpty() || obj.getPolicy()==null ||  obj.getDestclient().isEmpty() || obj.getDestclient()==null || obj.getGroupname().isEmpty() || obj.getGroupname()==null)
		{
			displayErrorMessageToUser("Required Fields cannot be empty", "ERROR");
			return;
		
		}
		}
		
		try {
			
			String query = "Insert into bulk_client_policy_info (bulkclientid, layoutid, policy, destclientid, groupname) select '"
					+ obj.getClient()
					+ "','"
					+ obj.getLayoutid()
					+ "','"
					+ obj.getPolicy()
					+ "','"
					+ obj.getDestclient()
					+ "',a.STANDARDEMPLOYERID FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" a WHERE STANDARDEMPLOYERNAME ='"
					+ obj.getGroupname().replaceAll("'", "''") + "'";
			
			/*String query = "Insert into bulk_client_policy_info (bulkclientid, layoutid, policy, destclientid, groupname) values('"
					+ obj.getClient()
					+ "','"
					+ obj.getLayoutid()
					+ "','"
					+ obj.getPolicy()
					+ "','"
					+ obj.getDestclient()
					+ "','"
					+ obj.getGroupname() + "')";*/

			ConnectDB db = new ConnectDB();
			db.initializeBulk();
			String stat = db.executeDML(query);
			db.endConnection();
			if (stat.compareTo("1") == 0) {
				RequestContext.getCurrentInstance().execute(
						"PF('addD').hide();");
				displayInfoMessageToUser(
						"New Policy Added for id : " + obj.getLayoutid(),
						"Policy Configuration");
				this.getPolicies().add(obj);
				this.addPolicyModel = new PolicyModel();
				refilter();

			}
			
		} catch (Exception ex) {

			displayErrorMessageToUser(
					"This Policy already exists for the given id",
					"Policy Configuration");

		}
		
	}
	
	public void refilter()
	{
		
		
		this.policynum="";
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent(":frmINV:inventoryLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
	}

	public void editPolicyMappings(PolicyModel obj) {

		if (this.isChangesinPolicy()) {
			try {

				String query = "Update bulk_client_policy_info set policy =  '"
						+ obj.getPolicy() + "', destclientid ='"
						+ obj.getDestclient() + "', groupname = (SELECT STANDARDEMPLOYERID FROM cpd.cp_employermaster@"+AIConstant.CPD_LINK+" a WHERE STANDARDEMPLOYERNAME ='"
						+ obj.getGroupname().replaceAll("'", "''") + "') where sn = '" + obj.getSn()
						+ "'";
				System.out.println(query);

				ConnectDB db = new ConnectDB();
				db.initializeBulk();
				String stat = db.executeDML(query);
				db.endConnection();
				if (stat.compareTo("1") == 0) {
					RequestContext.getCurrentInstance().execute(
							"PF('editPD').hide();");
					displayInfoMessageToUser(
							"Policy updated for id : " + obj.getLayoutid(),
							"Policy Configuration");
					resetAfterPolicyEdit();
				}
			} catch (Exception ex) {

				displayErrorMessageToUser(
						"This Policy already exists for the given id",
						"Policy Configuration");

			}
		} else {
			RequestContext.getCurrentInstance().execute("PF('editPD').hide();");
			resetAfterPolicyEdit();
		}
	}

	public void resetAfterPolicyEdit() {
		this.changesinPolicy = false;
		this.editPolicyModel = new PolicyModel();
		refilter();
	}


	public boolean isChangesinPolicy() {
		return changesinPolicy;
	}

	public void setChangesinPolicy(boolean changesinPolicy) {
		this.changesinPolicy = changesinPolicy;
	}

	public PolicyModel getEditPolicyModel() {
		return editPolicyModel;
	}

	public void setEditPolicyModel(PolicyModel editPolicyModel) {
		this.editPolicyModel = editPolicyModel;
	}

	

	public String getLayoutId() {
		return layoutId;
	}

	public void setLayoutId(String layoutId) {
		this.layoutId = layoutId;
	}

	
	/**
	 * This method retrieves all the policies associated with this
	 * configurations
	 */
	public void retrievePolicies() {
		this.policies = new ArrayList<>();
		if (this.layoutId != null || !(this.layoutId.isEmpty())) {
			//String query = "SELECT sn, bulkclientid, layoutid, policy, destclientid, groupname FROM bulk_client_policy_info where layoutid = '" + this.layoutId + "'";
			String query = "SELECT a.sn, a.bulkclientid, a.layoutid, a.policy, a.destclientid, b.STANDARDEMPLOYERNAME FROM bulk_client_policy_info a left JOIN cpd.cp_employermaster@"+AIConstant.CPD_LINK+" b ON a.GROUPNAME = b.STANDARDEMPLOYERID WHERE a.layoutid = '" + this.layoutId + "'";
			System.out.println(query);
			ConnectDB db = new ConnectDB();
			try {
				db.initializeBulk();
				List<List<String>> rs = db.resultSetToListOfList(query);
				if (rs != null) {
					if (rs.size() > 1) {
						for (int i = 1; i < rs.size(); i++) {
							PolicyModel model = new PolicyModel(rs.get(i)
									.get(0), rs.get(i).get(1),
									rs.get(i).get(2), rs.get(i).get(3), rs.get(
											i).get(4), rs.get(i).get(5));
							this.policies.add(model);
						}
					}
				}
			} catch (Exception ex) {
				System.out.println("Error retrieving policy :" + ex.toString());
			} finally {
				db.endConnection();
			}

		}
	}

	public ArrayList<PolicyModel> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<PolicyModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public String getPolicynum() {
		return policynum;
	}

	public void setPolicynum(String policynum) {
		this.policynum = policynum;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select clientname from hawkeyemaster.m_clients where clientid = '"+this.client+"'";
		List<List<String>> rs= db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				clientName = rs.get(1).get(0);
			}
		}
		this.clientName = clientName;
	}

	public boolean isToggleEmp() {
		return toggleEmp;
	}

	public void setToggleEmp(boolean toggleEmp) {
		this.toggleEmp = toggleEmp;
	}
}
