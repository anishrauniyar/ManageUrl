package com.vit.ai.bulkmanager.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import com.vit.ai.bulkmanager.model.BulkConfigModel;
import com.vit.ai.commons.model.DataType;
import com.vit.ai.commons.model.HRPayerBean;
import com.vit.ai.commons.model.LayoutType;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class AddBulkLayout extends AbstractController implements Serializable {

	private static final long serialVersionUID = -540612579553852322L;
	private BulkConfigModel configModel;
	private LinkedHashMap<String, String> clients;
	private LinkedHashMap<String, String> payers;
	private LinkedHashMap<String, String> dataTypes;
	private LinkedHashMap<String, String> delimeters;
	private ArrayList<String> distributionmodes;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		String query = "SELECT A.CLIENTID, B.CLIENTNAME "
				+ "      FROM ( "
				+ "      SELECT CLIENTID FROM aip_bulk_client_list GROUP BY CLIENTID "
				+ "      ) A "
				+ "      LEFT JOIN "
				+ "      HAWKEYEMASTER.M_CLIENTS B "
				+ "      ON A.CLIENTID = B.CLIENTID  ORDER BY CLIENTID asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		System.out.println(query);
		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}
		this.clients = clients;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {

		HRPayerBean objHRP = new HRPayerBean();
		payers = objHRP.getPayers();
		this.payers = payers;
	}

	public LinkedHashMap<String, String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(LinkedHashMap<String, String> dataTypes) {
		DataType objDataType = new DataType();
		dataTypes = objDataType.getDataTypes();
		this.dataTypes = dataTypes;
	}

	public LinkedHashMap<String, String> getDelimeters() {
		return delimeters;
	}

	public void setDelimeters(LinkedHashMap<String, String> delimeters) {

		String query = "SELECT nvl(LAYOUTTYPEID,'NA'), nvl(LAYOUTTYPE,'NA') "
				+ "	FROM TBL_FILEPATTERNS_LAYOUT ORDER BY 2";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> ltList = db.resultSetToListOfList(query);
		db.endConnection();

		if (ltList.size() > 0) {
			for (int i = 1; i < ltList.size(); i++) {
				delimeters.put(ltList.get(i).get(1).toUpperCase(), ltList.get(i).get(0).toUpperCase());
			}
		}
	
		
		this.delimeters = delimeters;
	}

	public AddBulkLayout() {
		String client = "";
		this.clients = new LinkedHashMap<>();
		this.dataTypes = new LinkedHashMap<>();
		this.payers = new LinkedHashMap<>();
		this.delimeters = new LinkedHashMap<>();
		this.distributionmodes = new ArrayList<>();
		
		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("clid") != null) {
			client = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("clid");
		}
		this.setConfigModel(new BulkConfigModel(client));
		setClients(clients);
		setDataTypes(dataTypes);
		setPayers(payers);
		setDelimeters(delimeters);
		setDistributionmodes(distributionmodes);

	}

	public BulkConfigModel getConfigModel() {
		return configModel;
	}

	public void setConfigModel(BulkConfigModel configModel) {
		this.configModel = configModel;
	}

	public ArrayList<String> getDistributionmodes() {
		return distributionmodes;
	}

	public void setDistributionmodes(ArrayList<String> distributionmodes) {

		ConnectDB db = new ConnectDB();
		db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID, "BULKFM", "local");
		String query = "select distinct mode_name from bulk_distribution_mode_master";
		List<List<String>> rs = db.resultSetToListOfList(query);

		db.endConnection();

		System.out.println("abc");
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					System.out.println("def");
					this.distributionmodes.add(rs.get(i).get(0));
				}
			}
		}

		this.distributionmodes = distributionmodes;
	}

	public void addConfiguration(BulkConfigModel configObj) {
		
		try
		{
			
			if(configObj.getDelimeter().compareTo("FIXED")!=0)
			{
				configObj.setFieldEnd("");
				configObj.setFieldStart("");
			}
			else
			{
				configObj.setFieldPosition("");
			}
		String query = "Insert into bulk_layout_info (datatype, distribution_type, delimiter, clientid, payor, layout_detail, field_start, field_end, field_position, entered_by, entered_time) values('"
				+ configObj.getDatatype().toUpperCase()
				+ "','DISTRIBUTION' , '"
				+ configObj.getDelimeter().toUpperCase()
				+ "','"
				+ configObj.getClientid()
				+ "','"
				+ configObj.getPayor().split("~")[0]
				+ "','"
				+ configObj.getLayout_detail()
				+ "','"
				+ configObj.getFieldStart()
				+ "','"
				+ configObj.getFieldEnd()
				+ "','"
				+ configObj.getFieldPosition()
				+ "','"
				+ this.getUserinfo().getFullname() + "',sysdate)";
		
		System.out.println("Bulk Addition Query : " + query);
		
		ConnectDB db = new ConnectDB();
		db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID, "BULKFM", "local");
		String stat = db.executeDML(query);
		db.endConnection();
		if(stat.compareTo("1")==0)
		{
			displayInfoMessageToUser("New Bulk Configuration added.Please add related Policy Mappings for this configuration", "Added Successfully");
			RequestContext.getCurrentInstance().closeDialog("addbulklayoutconfig");
			
		}
		else
		{
			displayErrorMessageToUser("Cannot Add.Please try again", "FAILED");
		}
		
	}
	
	catch(Exception ex)
	{
		displayErrorMessageToUser("Cannot Add.Please try again", "FAILED");
	}
	}
}
