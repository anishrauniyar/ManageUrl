package com.vit.ai.bulkmanager.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import com.vit.ai.bulkmanager.dao.BulkConfigDAO;
import com.vit.ai.bulkmanager.model.BulkConfigModel;
import com.vit.ai.bulkmanager.model.PolicyModel;
import com.vit.ai.commons.model.DataType;
import com.vit.ai.commons.model.HRPayerBean;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class BulkConfigController extends AbstractController implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2027923756528194389L;
	private ArrayList<BulkConfigModel> listofConfigurations;
	private BulkConfigModel configModel;
	private BulkConfigModel editModel = new BulkConfigModel();
	private LinkedHashMap<String, String> clients;
	private LinkedHashMap<String, String> allClients;
	private String client = "";
	private String winScreenHeight;
	private ArrayList<BulkConfigModel> filteredLogs;
	private LinkedHashMap<String, String> payers;
	private LinkedHashMap<String, String> dataTypes;
	private LinkedHashMap<String, String> delimeters;
	private ArrayList<String> distributionmodes;
	private boolean changesMade = false;
	private PolicyModel addPolicyModel = new PolicyModel();
	private ArrayList<String> employergroups = new ArrayList<>();
	private BulkConfigModel bulkModelunderEdit;
	private boolean changesinPolicy = false;
	private PolicyModel editPolicyModel = new PolicyModel();

	public ArrayList<String> getDistributionmodes() {
		return distributionmodes;
	}

	public void setDistributionmodes(ArrayList<String> distributionmodes) {

		ConnectDB db = new ConnectDB();
		db.initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID, "BULKFM", "local");
		String query = "select distinct mode_name from bulk_distribution_mode_master";
		List<List<String>> rs = db.resultSetToListOfList(query);

		db.endConnection();

		System.out.println("abc");
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					System.out.println("def");
					this.distributionmodes.add(rs.get(i).get(0));
				}
			}
		}

		this.distributionmodes = distributionmodes;
	}

	public void populateEmpGroups(PolicyModel obj) {

		setChangesinPolicy(true);
		if (obj.getDestclient() != null || !obj.getDestclient().isEmpty()) {
			String query = "SELECT DISTINCT groupname FROM bulk_client_policy_info WHERE DESTCLIENTID='"
					+ obj.getDestclient() + "' order by 1";
			ConnectDB db = new ConnectDB();
			db.initializeBulk();
			List<List<String>> employeeList = db.resultSetToListOfList(query);
			db.endConnection();
			employergroups = new ArrayList<String>();
			if (employeeList.size() > 0) {
				for (int i = 1; i < employeeList.size(); i++) {
					employergroups.add(employeeList.get(i).get(0));

				}
			}
		}

	}

	public LinkedHashMap<String, String> getDelimeters() {
		return delimeters;
	}

	public void setDelimeters(LinkedHashMap<String, String> delimeters) {

		String query = "SELECT nvl(LAYOUTTYPEID,'NA'), nvl(LAYOUTTYPE,'NA') "
				+ "	FROM TBL_FILEPATTERNS_LAYOUT ORDER BY 2";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> ltList = db.resultSetToListOfList(query);
		db.endConnection();

		if (ltList.size() > 0) {
			for (int i = 1; i < ltList.size(); i++) {
				delimeters.put(ltList.get(i).get(1).toUpperCase(), ltList
						.get(i).get(0).toUpperCase());
			}
		}

		this.delimeters = delimeters;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {

		HRPayerBean objHRP = new HRPayerBean();
		payers = objHRP.getPayers();
		this.payers = payers;
	}

	public LinkedHashMap<String, String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(LinkedHashMap<String, String> dataTypes) {
		DataType objDataType = new DataType();
		dataTypes = objDataType.getDataTypes();
		this.dataTypes = dataTypes;
	}

	public BulkConfigController() {

		this.clients = new LinkedHashMap<>();
		this.allClients = new LinkedHashMap<>();

		setClients(this.clients);
		setAllClients(allClients);

	}

	/**
	 * @return The new instance for config Model
	 * 
	 */
	public BulkConfigModel getModel() {
		this.configModel = new BulkConfigModel();
		return new BulkConfigModel();
	}

	public void setValue() {
		this.winScreenHeight = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("winScreenHeight");

	}

	public ArrayList<BulkConfigModel> getListofConfigurations() {
		return listofConfigurations;
	}

	public void setListofConfigurations(
			ArrayList<BulkConfigModel> listofConfigurations) {
		this.listofConfigurations = listofConfigurations;
	}

	public BulkConfigModel getConfigModel() {
		return configModel;
	}

	public void setConfigModel(BulkConfigModel configModel) {
		this.configModel = configModel;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {

		String query = "SELECT A.CLIENTID, B.CLIENTNAME "
				+ "      FROM ( "
				+ "      SELECT CLIENTID FROM aip_bulk_client_list GROUP BY CLIENTID "
				+ "      ) A "
				+ "      LEFT JOIN "
				+ "      HAWKEYEMASTER.M_CLIENTS B "
				+ "      ON A.CLIENTID = B.CLIENTID  ORDER BY CLIENTID asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		System.out.println(query);
		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}
		this.clients = clients;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	/**
	 * Controller Method to handle user selection
	 */
	public void handleClientChange() {
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent(":frmINV:inventoryLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.client.isEmpty() || this.client == null) {
			displayErrorMessageToUser("No Client Selected", "ERROR");
			return;
		} else {
			this.listofConfigurations = new ArrayList<>();
			BulkConfigDAO daoObject = new BulkConfigDAO();
			this.listofConfigurations = daoObject
					.getAllConfigurations(this.client);
		}
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public ArrayList<BulkConfigModel> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<BulkConfigModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public void addbulklayoutWindow() {
		// getSessionData().setWindowOpen(true);
		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(this.client);
		params.put("clid", list1);

		options.put("resizable", false);
		options.put("draggable", false);
		options.put("closable", "true");
		options.put("contentHeight", 300);
		RequestContext.getCurrentInstance().openDialog("addbulklayoutconfig",
				options, params);// ,options,null);

	}

	public void afterLayoutAdd() {
		handleClientChange();
		displayInfoMessageToUser(
				"Bulk Configuration added.Please add the corresponding policy mappings",
				"Configuration Added");

	}

	public void openEdit(BulkConfigModel obj) {
		this.editModel = new BulkConfigModel();
		this.editModel = obj;
		this.payers = new LinkedHashMap<>();
		this.delimeters = new LinkedHashMap<>();
		this.distributionmodes = new ArrayList<>();
		this.dataTypes = new LinkedHashMap<>();
		setPayers(payers);
		obj.setPayor(payers.get(obj.getPayor()));
		setDelimeters(delimeters);
		setDistributionmodes(distributionmodes);
		setDataTypes(dataTypes);
		

		RequestContext.getCurrentInstance().execute("PF('editD').show();");

	}

	public void editConfiguration(BulkConfigModel obj) {

		try {

			System.out.println("Edititng : " + this.isChangesMade());

			if (isChangesMade()) {

				if(obj.getDelimeter().isEmpty() || obj.getDatatype().isEmpty() || obj.getPayor().isEmpty() || obj.getLayout_detail().isEmpty())
				{
					displayErrorMessageToUser("Cannot update.Please enter all the required fields", "ERROR");
					return;
				}
				
				if (obj.getDelimeter().compareTo("FIXED") != 0) {
					obj.setFieldEnd("");
					obj.setFieldStart("");
				} else {
					obj.setFieldPosition("");
				}

				System.out.println("Editing bulk");
				String query = "update bulk_layout_info set datatype = '"
						+ obj.getDatatype().toUpperCase()
						+ "', distribution_type ='"
						+ obj.getDistribution_type() + "' , delimiter ='"
						+ obj.getDelimeter().toUpperCase() + "', payor = '"
						+ obj.getPayor().split("~")[0] + "', layout_detail ='"
						+ obj.getLayout_detail() + "', field_start = '"
						+ obj.getFieldStart() + "', field_end ='"
						+ obj.getFieldEnd() + "', field_position ='"
						+ obj.getFieldPosition() + "' where layoutid='"
						+ obj.getLayoutid() + "'";

				ConnectDB db = new ConnectDB();
				db.initializeBulk();
				String stat = db.executeDML(query);
				db.endConnection();
				if (stat.compareTo("1") == 0) {
					displayInfoMessageToUser("Edit Successfull",
							"Edit Configurations");
					RequestContext.getCurrentInstance().execute(
							"PF('editD').hide();");
					handleClientChange();
					resetEdit();
				} else {
					displayErrorMessageToUser("Edit Failed.Please try again",
							"Edit Configurations");

				}
			} else {
				RequestContext.getCurrentInstance().execute(
						"PF('editD').hide();");
				resetEdit();
			}
		} catch (Exception ex) {
			System.out.println("ERROR EDITING BULK : " + ex.toString());
			displayErrorMessageToUser("Edit Failed.Please try again",
					"Edit Configurations");
		}

	}

	public void resetEdit() {
		this.changesMade = false;
		this.editModel = new BulkConfigModel();
		this.payers = new LinkedHashMap<>();
		this.delimeters = new LinkedHashMap<>();
		this.distributionmodes = new ArrayList<>();
		this.dataTypes = new LinkedHashMap<>();

	}

	public void deleteConfig(BulkConfigModel obj) {
		System.out.println("Deleting configurations");
		String query = "delete from bulk_client_policy_info where layoutid= '"
				+ obj.getLayoutid() + "'";
		ConnectDB db = new ConnectDB();
		db.initializeBulk();
		String stat = db.executeDML(query);
		if (stat.compareTo("1") == 0) {
			stat = db
					.executeDML("delete from bulk_layout_info where layoutid= '"
							+ obj.getLayoutid() + "'");
			if (stat.compareTo("1") == 0) {
				displayInfoMessageToUser("Configuration deleted",
						"Delete Success");
				handleClientChange();
			} else {
				displayErrorMessageToUser("Could not delete", "Failed");
			}
		} else {
			displayErrorMessageToUser("Could not delete", "Failed");
		}

	}

	public BulkConfigModel getEditModel() {
		return editModel;
	}

	public void setEditModel(BulkConfigModel editModel) {
		this.editModel = editModel;
	}

	public boolean isChangesMade() {
		return changesMade;
	}

	public void setChangesMade(boolean changesMade) {
		this.changesMade = changesMade;
	}

	public PolicyModel getAddPolicyModel() {
		return addPolicyModel;
	}

	public void setAddPolicyModel(PolicyModel addPolicyModel) {
		this.addPolicyModel = addPolicyModel;
	}

	public ArrayList<String> getEmployergroups() {
		return employergroups;
	}

	public void setEmployergroups(ArrayList<String> employergroups) {
		this.employergroups = employergroups;
	}

	public LinkedHashMap<String, String> getAllClients() {
		return allClients;
	}

	public void setAllClients(LinkedHashMap<String, String> allClients) {
		String query = "SELECT A.CLIENTID, B.CLIENTNAME "
				+ "      FROM ( "
				+ "      SELECT CLIENTID FROM IMP_CLIENTPATTERNS GROUP BY CLIENTID "
				+ "      ) A " + "      LEFT JOIN "
				+ "      HAWKEYEMASTER.M_CLIENTS B "
				+ "      ON A.CLIENTID = B.CLIENTID  ORDER BY CLIENTID asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		System.out.println(query);
		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				allClients.put(
						clList.get(i).get(0) + "-(" + clList.get(i).get(1)
								+ ")", clList.get(i).get(0));
			}
		}
		this.allClients = allClients;
	}

	/**
	 * @param obj1
	 *            Bulk COnfig Model : Parent object for Policy Model
	 * 
	 *            Initializes object before opening policy add form
	 * 
	 */
	public void openAdd(BulkConfigModel obj1) {
		System.out.println("openinng add");
		this.bulkModelunderEdit = new BulkConfigModel();
		this.bulkModelunderEdit = obj1;
		this.addPolicyModel = new PolicyModel();
		this.addPolicyModel.setClient(obj1.getClientid());
		this.addPolicyModel.setLayoutid(obj1.getLayoutid());
		RequestContext.getCurrentInstance().execute("PF('addD').show();");
	}

	public void openEditPolicy(PolicyModel obj) {
		System.out.println("openinng edit");

		this.editPolicyModel = new PolicyModel();
		this.editPolicyModel = obj;
		populateEmpGroups(obj);
		this.changesinPolicy = false;
		RequestContext.getCurrentInstance().execute("PF('editPD').show();");
	}
	
	
	public void deletePolicy(BulkConfigModel obj1,PolicyModel obj)
	{
		if(obj!=null)
		{
			obj1.getPolicies().remove(obj);
			String query = "delete from bulk_client_policy_info where sn = '" + obj.getSn() + "'";
			ConnectDB db = new ConnectDB();
			db.initializeBulk();
			String stat = db.executeDML(query);
			db.endConnection();
			if(stat.compareTo("1")==0)
			{
				displayInfoMessageToUser("Deleted successfully", "Delete Policy Configuration");
			}
			else
			{
				displayErrorMessageToUser("Could not delete", "Delete Policy Configuration");
				obj1.getPolicies().add(obj);
			}
		}
	}

	public void addPolicyMappings(PolicyModel obj) {
		try {
			String query = "Insert into bulk_client_policy_info (bulkclientid, layoutid, policy, destclientid, groupname) values('"
					+ obj.getClient()
					+ "','"
					+ obj.getLayoutid()
					+ "','"
					+ obj.getPolicy()
					+ "','"
					+ obj.getDestclient()
					+ "','"
					+ obj.getGroupname() + "')";

			ConnectDB db = new ConnectDB();
			db.initializeBulk();
			String stat = db.executeDML(query);
			db.endConnection();
			if (stat.compareTo("1") == 0) {
				RequestContext.getCurrentInstance().execute(
						"PF('addD').hide();");
				displayInfoMessageToUser(
						"New Policy Added for id : " + obj.getLayoutid(),
						"Policy Configuration");
				this.bulkModelunderEdit.getPolicies().add(obj);
				this.addPolicyModel = new PolicyModel();

			}
		} catch (Exception ex) {

			displayErrorMessageToUser(
					"This Policy already exists for the given id",
					"Policy Configuration");

		}
	}

	public void editPolicyMappings(PolicyModel obj) {

		if (this.isChangesinPolicy()) {
			try {

				String query = "Update bulk_client_policy_info set policy =  '"
						+ obj.getPolicy() + "', destclientid ='"
						+ obj.getDestclient() + "', groupname = '"
						+ obj.getGroupname() + "' where sn = '" + obj.getSn()
						+ "'";
				System.out.println(query);

				ConnectDB db = new ConnectDB();
				db.initializeBulk();
				String stat = db.executeDML(query);
				db.endConnection();
				if (stat.compareTo("1") == 0) {
					RequestContext.getCurrentInstance().execute(
							"PF('editPD').hide();");
					displayInfoMessageToUser(
							"Policy updated for id : " + obj.getLayoutid(),
							"Policy Configuration");
					resetAfterPolicyEdit();
				}
			} catch (Exception ex) {

				displayErrorMessageToUser(
						"This Policy already exists for the given id",
						"Policy Configuration");

			}
		} else {
			RequestContext.getCurrentInstance().execute("PF('editPD').hide();");
			resetAfterPolicyEdit();
		}
	}

	public void resetAfterPolicyEdit() {
		this.changesinPolicy = false;
		this.editPolicyModel = new PolicyModel();
	}

	public BulkConfigModel getBulkModelunderEdit() {
		return bulkModelunderEdit;
	}

	public void setBulkModelunderEdit(BulkConfigModel bulkModelunderEdit) {
		this.bulkModelunderEdit = bulkModelunderEdit;
	}

	public boolean isChangesinPolicy() {
		return changesinPolicy;
	}

	public void setChangesinPolicy(boolean changesinPolicy) {
		this.changesinPolicy = changesinPolicy;
	}

	public PolicyModel getEditPolicyModel() {
		return editPolicyModel;
	}

	public void setEditPolicyModel(PolicyModel editPolicyModel) {
		this.editPolicyModel = editPolicyModel;
	}
}
