package com.vit.ai.bulkmanager.controller;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.model.DefaultStreamedContent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.bulkmanager.dao.BulkToHIDAO;
import com.vit.ai.bulkmanager.model.BulkControlTotalModel;
import com.vit.ai.bulkmanager.model.BulkToHIModel;
import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.utils.AbstractController;

@ManagedBean
@ViewScoped
public class BulkToHIController extends AbstractController implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Logger log = LoggerFactory.getLogger(BulkToHIController.class);
	
	private ArrayList<BulkToHIModel> listofBulkReport;

	protected ArrayList<BulkControlTotalModel> selectedLogs;
	protected ArrayList<BulkControlTotalModel> filteredLogs;
	
	private DefaultStreamedContent downloadINV;
	
	//protected String reportOutputLink = "O:/Operations/AIP/AIP-aypokhrel/";
	//protected String reportOutputLink = AIConstant.LOCAL_BULKTOHIRECON_OUTPUTLOCATION + "/";
	protected String reportOutputLink;

	
	private String winScreenHeight;

	
	
	public BulkToHIController()
	{
		//Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//double height = screenSize.getHeight() / 1.6;
		//setWinScreenHeight(Double.toString(height));
		getBulkReport();
		
	}
	
	public DefaultStreamedContent getDownloadINV() {
		return downloadINV;
	}

	public void setDownloadINV(DefaultStreamedContent downloadINV) {
		this.downloadINV = downloadINV;
	}

	public String getReportOutputLink() {
		return reportOutputLink;
	}

	public void setReportOutputLink(String reportOutputLink) {
		this.reportOutputLink = reportOutputLink;
	}

	public ArrayList<BulkControlTotalModel> getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(ArrayList<BulkControlTotalModel> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	public ArrayList<BulkControlTotalModel> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<BulkControlTotalModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}
	
	public ArrayList<BulkToHIModel> getListofBulkReport() {
		return listofBulkReport;
	}

	public void setListofBulkReport(ArrayList<BulkToHIModel> listofBulkReport) {
		this.listofBulkReport = listofBulkReport;
	}
	
	public void getBulkReport() {
		log.info("This is for getting the Bulk To HI report");
		listofBulkReport = BulkToHIDAO.getBulkList();
	}
	
	public void downloadReport(String reportid) {
		
		log.info("Reportid : "+ reportid);
		reportOutputLink = AIConstant.BULKTOHIRECON_OUTPUTLOCATION + "/";
		String OS = System.getProperty("os.name").toLowerCase();
		if (OS.indexOf("win") >= 0) {
			reportOutputLink = AIConstant.LOCAL_BULKTOHIRECON_OUTPUTLOCATION + "/";
		}
		log.info("The report output link is: " + reportOutputLink + "Bulk_Report_" + reportid + ".xlsx");
		File file = new File(reportOutputLink + "Bulk_Report_" + reportid + ".xlsx");
		if (file.exists()) {
			FileController objFC = new FileController(reportOutputLink + "Bulk_Report_" + reportid + ".xlsx");
			setDownloadINV(objFC.getDownload());
			log.info("Downloaded");
		}
	}

}
