package com.vit.ai.bulkmanager.controller;

/* 
 *Class Name : BulkReconciliation.java
 *
 *Copyright: Verisk Information Technologies
 */


import java.io.Serializable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import javax.el.ELContext;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.slf4j.LoggerFactory;

import com.vit.ai.bulkmanager.dao.BulkToHIDAO;
import com.vit.ai.bulkmanager.model.BulkReconciliationModel;
import com.vit.ai.commons.model.MainLogDataModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.ProcessBuilderRunner;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for Bulk File Impport
 * 
 * @author Binesh Sah
 * @edited Anish Rauniyar
 * 
 * @version 1.0 4 April 2016
 */
@ManagedBean
@ViewScoped
public class BulkReconciliation extends AbstractController implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(BulkReconciliation.class.getName());
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String winScreenHeight;
	protected FilterLogController filterData;
	private LinkedHashMap<String, String> clients;
	private String clientid;
	private ArrayList<BulkReconciliationModel> listofBulkData;
	protected ArrayList<BulkReconciliationModel> selectedLogs;
	protected ArrayList<BulkReconciliationModel> filteredLogs;
	protected MainLogDataModel importMainLogs;

	protected Date startDate;
	protected Date endDate;
	
	protected Date bulkStartDate;
	protected Date bulkEndDate;
	protected String bulkStatus;
	
	private Date todaysDate;
	private String startDate_report;
	private String endDate_report;
	private String todaysDate_report;
	
	private String fullname;
	
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public ArrayList<BulkReconciliationModel> getSelectedLogs() {
		return selectedLogs;
	}
	public void setSelectedLogs(ArrayList<BulkReconciliationModel> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	public ArrayList<BulkReconciliationModel> getFilteredLogs() {
		return filteredLogs;
	}
	public void setFilteredLogs(ArrayList<BulkReconciliationModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}
	
	public String getStartDate_report() {
		return startDate_report;
	}
	public void setStartDate_report(String startDate_report) {
		this.startDate_report = startDate_report;
	}

	public String getTodaysDate_report() {
		return todaysDate_report;
	}
	public void setTodaysDate_report(String todaysDate_report) {
		this.todaysDate_report = todaysDate_report;
	}

	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getBulkStartDate() {
		return bulkStartDate;
	}
	public void setBulkStartDate(Date bulkStartDate) {
		this.bulkStartDate = bulkStartDate;
	}
	public Date getBulkEndDate() {
		return bulkEndDate;
	}
	public void setBulkEndDate(Date bulkEndDate) {
		this.bulkEndDate = bulkEndDate;
	}
	
	public String getBulkStatus() {
		return bulkStatus;
	}
	public void setBulkStatus(String bulkStatus) {
		this.bulkStatus = bulkStatus;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}
	public void bulkClientLoad(){


		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmBFM:bulkDataImportLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.setTodaysDate_report(dateFormat.format(todaysDate));
		String queryInv="";
		queryInv = "SELECT DMFILEID,FILENAME,FILESIZE,FILEDATE,EIGERTRANSFERDATE,FILESTATUS,  ACTION_NAME,ACTION_STATUS,LAYOUTID,TOTALPOLICYNUM,MATCHEDPOLICYNUM,UNMATCHEDPOLICYNUM, "
				+" RECORDCNT  from aip_dashboard_bulkfm ";
		String clid = filterData.getClientID();
		log.info("Clientid : " + clid);
		if (clid == null || clid.equals("")) {
			displayErrorMessageToUser("No Client Selected", "Inventory");
			
			return;

		}
		if (clid != null && !clid.equals("")) {
			queryInv += " WHERE CLIENTID='" + clid + "' ";

			if (startDate != null && !startDate.equals("")) {
				queryInv += " AND EIGERTRANSFERDATE" + " >= TO_TIMESTAMP('"
						+ dateFormat.format(startDate) + "','"
						+ timeStampFormat + "')";
				setStartDate_report(dateFormat.format(startDate));
			}
			if (endDate != null && !endDate.equals("")) {
				queryInv += " AND EIGERTRANSFERDATE" + " <= TO_TIMESTAMP('"
						+ dateFormat.format(endDate) + "','" + timeStampFormat
						+ "')";
				setEndDate_report(dateFormat.format(endDate));
			}

		} else if (clid == null || clid.equals("")) {
			if (startDate != null && !startDate.equals("")) {
				queryInv += " WHERE EIGERTRANSFERDATE" + " >= TO_TIMESTAMP('"
						+ dateFormat.format(startDate) + "','"
						+ timeStampFormat + "')";
				setStartDate_report(dateFormat.format(startDate));

				if (endDate != null && !endDate.equals("")) {
					queryInv += " AND EIGERTRANSFERDATE" + "<= TO_TIMESTAMP('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";
					setEndDate_report(dateFormat.format(endDate));
				}
			}
		} else if (clid == null || clid.equals("") && startDate == null
				|| startDate.equals("")) {
			if (endDate != null && !endDate.equals("")) {
				queryInv += " WHERE EIGERTRANSFERDATE" + " <= TO_TIMESTAMP('"
						+ dateFormat.format(endDate) + "','" + timeStampFormat
						+ "')";
				setEndDate_report(dateFormat.format(endDate));
			}

		}
	log.info("listofbulk data load query: " + queryInv);
	ConnectDB db = new ConnectDB();
	db.initializeBulk();
	List<List<String>> rs = db.resultSetToListOfList(queryInv);

	db.endConnection();

	listofBulkData= new ArrayList<>();
	if (rs != null) {
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {
				this.listofBulkData.add(new BulkReconciliationModel(i,rs
						.get(i).get(0),rs.get(i-1).get(0) ,rs.get(i).get(1), rs.get(i).get(2),rs.get(i).get(3), rs.get(i).get(4), rs.get(i)
						.get(5), rs.get(i).get(6),rs.get(i).get(7), rs.get(i).get(8), rs.get(i)
						.get(9), rs.get(i).get(10), rs.get(i).get(11),rs.get(i).get(12)));

			}
		} else {

		}
	} else {
		displayErrorMessageToUser("Query Execution Failed", "ERROR");
	}
	/*this.setListofBulkData(listofBulkData);*/
	
	}

	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}
	
	public BulkReconciliation() {
		bulkStatus = "[Bulk Status Inactive]";
		setTodaysDate(new Date());
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
	/*	MClients objMC = new MClients(false);
		setClients(objMC.getClients());*/
		this.clients = new LinkedHashMap<>();
		setClients(this.clients);
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		String query = "SELECT A.CLIENTID, B.CLIENTNAME "
				+ "      FROM ( "
				+ "      SELECT CLIENTID FROM aip_bulk_client_list GROUP BY CLIENTID "
				+ "      ) A "
				+ "      LEFT JOIN "
				+ "      HAWKEYEMASTER.M_CLIENTS B "
				+ "      ON A.CLIENTID = B.CLIENTID ORDER BY CLIENTID asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		System.out.println(query);
		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}
		this.clients = clients;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		filterData.setClientID(clientid);
		this.clientid = filterData.getClientID();
	}

	public ArrayList<BulkReconciliationModel> getListofBulkData() {
		return listofBulkData;
	}

	public void setListofBulkData(ArrayList<BulkReconciliationModel> listofBulkData) {
		this.listofBulkData = listofBulkData;
	}
	public void handlecurrentDate() {
		try {

			SimpleDateFormat tformat = new SimpleDateFormat("HH:mm:ss");
			log.info("Time " + tformat.format(endDate));
			if (tformat.format(endDate).compareTo("00:00:00") == 0) {

				log.info("Date: " + this.getEndDate());
				SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
				String denddate;

				denddate = dformat.format(this.getEndDate());
				endDate = dformat.parse(denddate);
				Calendar cal = Calendar.getInstance();

				cal.setTime(endDate);
				endDate = cal.getTime();
				log.info("Data cal date " + endDate);
			
				endDate = DateUtils.addHours(endDate, 23);
				endDate = DateUtils.addMinutes(endDate, 59);
				endDate = DateUtils.addSeconds(endDate, 59);
				log.info("Last End Date " + endDate);
				setEndDate(endDate);
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Date Exception Occured. Please try again", "Date");
			return;
		}
	}

	public String getEndDate_report() {
		return endDate_report;
	}

	public void setEndDate_report(String endDate_report) {
		this.endDate_report = endDate_report;
	}

	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}


	public void bulkToHI() {
		log.info("The bulk transfer Start date is: " + bulkStartDate);
		log.info("The bulk transfer End date is: " + bulkEndDate);
		log.info("The bulk clientid and name is: " + clientid + " " + clients);
		log.info("The userLog is: " + fullname);
		String userLog = userinfo.getFullname();
		bulkStatus = "[Started]";
		
		BulkToHIDAO bthd = new BulkToHIDAO();
		
		try {
			bthd.insertReportInfo(clientid, bulkStartDate, bulkEndDate, userLog);
			//ProcessBuilder pb = new ProcessBuilder("java","-jar",jarPath);
		} catch (Exception e) {
			log.info("The exception in inserting is: " + e.toString());
		}
		
		
	}

}
