/**
 * Controller class for Bulk File Impport
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 4 April 2016
 */

package com.vit.ai.bulkmanager.controller;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import com.vit.ai.bulkmanager.model.BulkChildModel;
import com.vit.ai.commons.model.MainLogDataModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class BulkUnmappedController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 3595962266374100568L;
	private static Logger log = Logger.getLogger(BulkReconciliation.class
			.getName());
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String winScreenHeight;
	protected FilterLogController filterData;
	private LinkedHashMap<String, String> clients;
	private String clientid;
	private ArrayList<BulkChildModel> listofBulkData;
	protected ArrayList<BulkChildModel> selectedLogs;
	protected ArrayList<BulkChildModel> filteredLogs;
	protected MainLogDataModel importMainLogs;

	protected Date startDate;
	protected Date endDate;
	private Date todaysDate;
	private String startDate_report;
	private String endDate_report;
	private String todaysDate_report;

	public ArrayList<BulkChildModel> getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(ArrayList<BulkChildModel> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	public ArrayList<BulkChildModel> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<BulkChildModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public String getStartDate_report() {
		return startDate_report;
	}

	public void setStartDate_report(String startDate_report) {
		this.startDate_report = startDate_report;
	}

	public String getTodaysDate_report() {
		return todaysDate_report;
	}

	public void setTodaysDate_report(String todaysDate_report) {
		this.todaysDate_report = todaysDate_report;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public void bulkClientLoad() {

		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot()
					.findComponent("frmBFM:bulkDataImportLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.setTodaysDate_report(dateFormat.format(todaysDate));
		String queryInv = "";
		queryInv = "select B.sn, B.dmfileid, B.child_fileid, B.child_filename, B.child_filesize, B.child_recordcnt, B.child_filedate, B.child_checksum, B.datatype, B.policynum, B.info_starttime, B.info_endtime, B.processstatus, B.processedpath, B.ftpstatus, B.src_clientid,A.eigertransferdate,c.layoutid from bulk_data_child_info B  left join dm_info A on A.dmfileid = B.dmfileid left JOIN dm_file_info C ON B.dmfileid = C.dmfileid  where B.processstatus = 'UNKNOWN'";
		
		String clid = filterData.getClientID();
		log.info("Clientid : " + clid);
		if (clid == null || clid.equals("")) {
			displayErrorMessageToUser("No Client Selected", "Inventory");

			return;

		}
		if (clid != null && !clid.equals("")) {
			queryInv += " AND A.CLIENTID='" + clid + "' ";

			if (startDate != null && !startDate.equals("")) {
				queryInv += " AND A.EIGERTRANSFERDATE" + " >= TO_TIMESTAMP('"
						+ dateFormat.format(startDate) + "','"
						+ timeStampFormat + "')";
				setStartDate_report(dateFormat.format(startDate));
			}
			if (endDate != null && !endDate.equals("")) {
				queryInv += " AND A.EIGERTRANSFERDATE" + " <= TO_TIMESTAMP('"
						+ dateFormat.format(endDate) + "','" + timeStampFormat
						+ "')";
				setEndDate_report(dateFormat.format(endDate));
			}

		} else if (clid == null || clid.equals("")) {
			if (startDate != null && !startDate.equals("")) {
				queryInv += " WHERE A.EIGERTRANSFERDATE" + " >= TO_TIMESTAMP('"
						+ dateFormat.format(startDate) + "','"
						+ timeStampFormat + "')";
				setStartDate_report(dateFormat.format(startDate));

				if (endDate != null && !endDate.equals("")) {
					queryInv += " AND A.EIGERTRANSFERDATE"
							+ "<= TO_TIMESTAMP('" + dateFormat.format(endDate)
							+ "','" + timeStampFormat + "')";
					setEndDate_report(dateFormat.format(endDate));
				}
			}
		} else if (clid == null || clid.equals("") && startDate == null
				|| startDate.equals("")) {
			if (endDate != null && !endDate.equals("")) {
				queryInv += " WHERE A.EIGERTRANSFERDATE" + " <= TO_TIMESTAMP('"
						+ dateFormat.format(endDate) + "','" + timeStampFormat
						+ "')";
				setEndDate_report(dateFormat.format(endDate));
			}

		}
		System.out.println(queryInv);
		ConnectDB db = new ConnectDB();
		db.initializeBulk();
		List<List<String>> rs = db.resultSetToListOfList(queryInv);

		db.endConnection();

		listofBulkData = new ArrayList<>();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					BulkChildModel model = new BulkChildModel(rs.get(i).get(0),
							rs.get(i).get(1), rs.get(i).get(2), rs.get(i)
									.get(3), rs.get(i).get(4),
							rs.get(i).get(5), rs.get(i).get(6), rs.get(i)
									.get(7), rs.get(i).get(8),
							rs.get(i).get(9), rs.get(i).get(10), rs.get(i).get(
									11), rs.get(i).get(12), rs.get(i).get(13),
							rs.get(i).get(14), rs.get(i).get(15),rs.get(i).get(16),rs.get(i).get(17));
					listofBulkData.add(model);
				}
			} else {

			}
		} else {
			displayErrorMessageToUser("Query Execution Failed", "ERROR");
		}
		this.setListofBulkData(listofBulkData);

	}

	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);

	}

	public BulkUnmappedController() {
		setTodaysDate(new Date());
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
		/*
		 * MClients objMC = new MClients(false); setClients(objMC.getClients());
		 */
		this.clients = new LinkedHashMap<>();
		setClients(this.clients);

	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		String query = "SELECT A.CLIENTID, B.CLIENTNAME "
				+ "      FROM ( "
				+ "      SELECT CLIENTID FROM aip_bulk_client_list GROUP BY CLIENTID "
				+ "      ) A "
				+ "      LEFT JOIN "
				+ "      HAWKEYEMASTER.M_CLIENTS B "
				+ "      ON A.CLIENTID = B.CLIENTID  ORDER BY CLIENTID asc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		System.out.println(query);
		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}
		this.clients = clients;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		filterData.setClientID(clientid);
		this.clientid = filterData.getClientID();
	}

	public ArrayList<BulkChildModel> getListofBulkData() {
		return listofBulkData;
	}

	public void setListofBulkData(ArrayList<BulkChildModel> listofBulkData) {
		this.listofBulkData = listofBulkData;
	}

	public void handlecurrentDate() {
		try {

			SimpleDateFormat tformat = new SimpleDateFormat("HH:mm:ss");
			log.info("Time " + tformat.format(endDate));
			if (tformat.format(endDate).compareTo("00:00:00") == 0) {

				log.info("Date: " + this.getEndDate());
				SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
				String denddate;

				denddate = dformat.format(this.getEndDate());
				endDate = dformat.parse(denddate);
				Calendar cal = Calendar.getInstance();

				cal.setTime(endDate);
				endDate = cal.getTime();
				log.info("Data cal date " + endDate);

				endDate = DateUtils.addHours(endDate, 23);
				endDate = DateUtils.addMinutes(endDate, 59);
				endDate = DateUtils.addSeconds(endDate, 59);
				log.info("Last End Date " + endDate);
				setEndDate(endDate);
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Date Exception Occured. Please try again", "Date");
			return;
		}
	}

	public String getEndDate_report() {
		return endDate_report;
	}

	public void setEndDate_report(String endDate_report) {
		this.endDate_report = endDate_report;
	}

	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

}
