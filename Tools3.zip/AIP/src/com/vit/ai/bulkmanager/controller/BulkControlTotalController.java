package com.vit.ai.bulkmanager.controller;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.bulkmanager.dao.BulkControlTotalDAO;
import com.vit.ai.bulkmanager.model.BulkControlTotalModel;
import com.vit.ai.utils.AbstractController;


@ManagedBean
@ViewScoped
public class BulkControlTotalController extends AbstractController implements Serializable {

	public BulkControlTotalController() {
		super();
	}

	private static final long serialVersionUID = 1L;
	private Logger log = LoggerFactory.getLogger(BulkControlTotalController.class);
	private String clientId;
	private Date startDate;
	private Date endDate;
	private ArrayList<BulkControlTotalModel> bulkControlTotalData;
	protected ArrayList<BulkControlTotalModel> selectedLogs;
	protected ArrayList<BulkControlTotalModel> filteredLogs;
	
	private String winScreenHeight;
	
	
	public String getWinScreenHeight() {
		return winScreenHeight;
	}
	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public ArrayList<BulkControlTotalModel> getSelectedLogs() {
		return selectedLogs;
	}
	public void setSelectedLogs(ArrayList<BulkControlTotalModel> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}
	public ArrayList<BulkControlTotalModel> getFilteredLogs() {
		return filteredLogs;
	}
	public void setFilteredLogs(ArrayList<BulkControlTotalModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	
	
	public ArrayList<BulkControlTotalModel> getBulkControlTotalData() {
		return bulkControlTotalData;
	}
	public void setBulkControlTotalData(
			ArrayList<BulkControlTotalModel> bulkControlTotalData) {
		this.bulkControlTotalData = bulkControlTotalData;
	}
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public BulkControlTotalController(String clientId, Date startDate,
			Date endDate) {
		super();
		this.clientId = clientId;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	
	public void getBulkControlData() {
		
		String finalStartDate = "";
		String finalEndDate = "";
		log.info("The clientId is:" + clientId);
		try{
			if (startDate == null && endDate != null ) {
				finalStartDate = "01.09.2015 00:00:00";
				finalEndDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(endDate);
			} else if (startDate != null && endDate == null) {
				finalStartDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(startDate);
				finalEndDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(new Date());
			} else if (startDate == null && endDate == null) {
				finalStartDate = "01.09.2015 00:00:00";
				finalEndDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(new Date());
			} else {
				finalStartDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(startDate);
				finalEndDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(endDate);
			}
			log.info("The start date is:" + finalStartDate);
			log.info("The end date is:" + finalEndDate);
			
			List<BulkControlTotalModel> bctm = new ArrayList<BulkControlTotalModel>();
			
			bctm = BulkControlTotalDAO.getBulkControlTotalList(clientId, finalStartDate, finalEndDate);
			this.bulkControlTotalData = (ArrayList<BulkControlTotalModel>) bctm;
		} catch (Exception e) {
			log.info("The date cannot be parsed.");
		}
		
	}
}
