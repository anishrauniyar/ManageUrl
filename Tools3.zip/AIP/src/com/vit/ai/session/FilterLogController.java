/*
 *Class Name : FilterLogController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.session;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 05 May 2014
 */
@ManagedBean
@SessionScoped
public class FilterLogController implements Serializable {

	private static final long serialVersionUID = 1L;
	private String clientID;
	private String fromTimestamp;
	private String toTimestamp;

	public FilterLogController() {

	}

	@PostConstruct
	public void init() {
		setClientID("");
		setFromTimestamp("");
		setToTimestamp("");
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getToTimestamp() {
		return toTimestamp;
	}

	public void setToTimestamp(String toTimestamp) {
		this.toTimestamp = toTimestamp;
	}

	public String getFromTimestamp() {
		return fromTimestamp;
	}

	public void setFromTimestamp(String fromTimestamp) {
		this.fromTimestamp = fromTimestamp;
	}

}
