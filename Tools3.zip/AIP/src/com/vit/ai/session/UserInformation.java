/**
 * ClassName UserInformation.java
 * 
 * Copyright: Verisk Information Technologies
 */
package com.vit.ai.session;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 11 May 2015
 */
@ManagedBean
@SessionScoped
public class UserInformation implements Serializable {
	private static final long serialVersionUID = 6781665087002565482L;
	private String fullname;
	private String email;

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserInformation() {
		
	}
	
	

}
