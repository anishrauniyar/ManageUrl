/*
 *Class Name : ViewsParameters.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.session;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Properties;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.vit.ai.commons.model.Theme;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.10 18 May 2015
 */
@ManagedBean(name = "loginbean")
@SessionScoped
public class ViewsParameters  implements Serializable {

	private static final long serialVersionUID = 1L;
	private boolean validationComplete = false;
	private boolean newAdditionComplete = false;
	private boolean manualOverrideComplete = false;
	private boolean transferLabelChanged = false;
	private String validpattern = "";
	private String validctlpattern = "";
	private String selectedReportid = "";
	private String email = "";
	private ArrayList<Theme> themes;
	private String clipboard="";

	public Theme getSelectedTheme() {
		return selectedTheme;
	}

	public void setSelectedTheme(Theme selectedTheme) {
		this.selectedTheme = selectedTheme;
	}

	public ArrayList<Theme> getThemes() {
		return themes;
	}

	private String theme;
	private Theme selectedTheme;

	public ViewsParameters() {

		Properties p = new Properties();
		try {
			p.load(Thread.currentThread().getContextClassLoader()
					.getResourceAsStream("config.properties"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		setTheme((String) p.get("default.theme"));
		themes = new ArrayList<Theme>();
		setThemes(themes);

	}

	public boolean getValidationComplete() {
		return validationComplete;
	}

	public void setValidationComplete(boolean validationComplete) {
		this.validationComplete = validationComplete;
	}

	public boolean isNewAdditionComplete() {
		return newAdditionComplete;
	}

	public void setNewAdditionComplete(boolean newAdditionComplete) {
		this.newAdditionComplete = newAdditionComplete;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setThemes(ArrayList<Theme> themes) {
		setTheme(theme);

		String[] themeNames = { "afterdark", "afternoon", "afterwork",
				"aristo", "black-tie", "blitzer", "bluesky", "bootstrap",
				"casablanca", "cruze", "cupertino", "dark-hive", "dot-luv",
				"eggplant", "excite-bike", "flick", "glass-x", "home",
				"hot-sneaks", "humanity", "le-frog", "midnight", "mint-choc",
				"overcast", "pepper-grinder", "redmond", "rocket", "sam",
				"smoothness", "south-street", "start", "sunny", "swanky-purse",
				"trontastic", "ui-darkness", "ui-lightness", "vader" };

		for (String themeName : themeNames) {
			themes.add(new Theme(themeName, themeName + ".png"));
		}
	}

	public boolean isManualOverrideComplete() {
		return manualOverrideComplete;
	}

	public void setManualOverrideComplete(boolean manualOverrideComplete) {
		this.manualOverrideComplete = manualOverrideComplete;
	}

	public boolean isTransferLabelChanged() {
		return transferLabelChanged;
	}

	public void setTransferLabelChanged(boolean transferLabelChanged) {
		this.transferLabelChanged = transferLabelChanged;
	}

	public String getValidpattern() {
		return validpattern;
	}

	public void setValidpattern(String validpattern) {
		this.validpattern = validpattern;
	}

	public String getValidctlpattern() {
		return validctlpattern;
	}

	public void setValidctlpattern(String validctlpattern) {
		this.validctlpattern = validctlpattern;
	}

	public String getSelectedReportid() {
		return selectedReportid;
	}

	public void setSelectedReportid(String selectedReportid) {
		this.selectedReportid = selectedReportid;
	}

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public String getClipboard() {
		return clipboard;
	}

	public void setClipboard(String clipboard) {
		this.clipboard = clipboard;
	}

}
