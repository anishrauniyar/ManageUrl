/*
 * Class Name : EncryptDecrypt.java
 * 
 * Copyright: Verisk Information Technologies
 */

package com.vit.ai.utils;

import java.io.IOException;
import java.io.Serializable;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import org.apache.log4j.Logger;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * Class used to encrypt or decrypt the data, specially passwords
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 05 May 2014
 * 
 */
public class EncryptDecrypt implements Serializable {

	private static final long serialVersionUID = -4908231043390801880L;
	private static Logger log = Logger
			.getLogger(EncryptDecrypt.class.getName());
	private static final char[] PASSWORD = "enfldsgbnlsngdlksdsgm"
			.toCharArray();
	private static final byte[] SALT = { (byte) 0xde, (byte) 0x33, (byte) 0x10,
			(byte) 0x12, (byte) 0xde, (byte) 0x33, (byte) 0x10, (byte) 0x12, };

	/**
	 * @param property
	 *            Data to be encrypted
	 * @return Encrypted data
	 */
	public String encrypt(String property) {

		SecretKeyFactory keyFactory;
		try {
			keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");

			SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));
			Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
			pbeCipher.init(Cipher.ENCRYPT_MODE, key, new PBEParameterSpec(SALT,
					20));
			return base64Encode(pbeCipher.doFinal(property.getBytes("UTF-8")));
		} catch (Exception e) {
			log.error("Encryption failed: " + e.getMessage());
			return "Encryption failed " + e.getMessage();
		}
	}

	private String base64Encode(byte[] bytes) {
		// NB: This class is internal, and you probably should use another impl
		return new BASE64Encoder().encode(bytes);
	}

	/**
	 * @param property
	 *            Data to be decrypted
	 * @return Decrypted data
	 */
	public String decrypt(String property) {
		SecretKeyFactory keyFactory;
		try {
			keyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndDES");

			SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));
			Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
			pbeCipher.init(Cipher.DECRYPT_MODE, key, new PBEParameterSpec(SALT,
					20));
			return new String(pbeCipher.doFinal(base64Decode(property)),
					"UTF-8");
		} catch (Exception e) {
			log.error("Decryption failed: " + e.getMessage());
			return "Decryption failed " + e.getMessage();
		}
	}
	
	
	
	

	private byte[] base64Decode(String property) throws IOException {
		// NB: This class is internal, and you probably should use another impl
		return new BASE64Decoder().decodeBuffer(property);
	}

}
