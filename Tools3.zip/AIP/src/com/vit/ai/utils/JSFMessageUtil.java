/* 
 *Class Name : JSFMessageUtil.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.utils;

import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

/**
 * Class to show message
 * 
 * @author Sagar Shrestha
 * 
 * @version 1.0 28 April 2014
 *
 */
public class JSFMessageUtil {

	public void sendInfoMessageToUser(String message, String title) {
		FacesMessage facesMessage = createMessage(FacesMessage.SEVERITY_INFO,
				title, message);
		addMessageToJsfContext(facesMessage);
	}

	public void sendErrorMessageToUser(String message, String title) {
		FacesMessage facesMessage = createMessage(FacesMessage.SEVERITY_ERROR,
				title, message);
		RequestContext.getCurrentInstance().showMessageInDialog(facesMessage);
	}

	private FacesMessage createMessage(Severity severity, String title,
			String mensagemErro) {
		return new FacesMessage(severity, title, mensagemErro);
	}

	private void addMessageToJsfContext(FacesMessage facesMessage) {
		FacesContext.getCurrentInstance().addMessage(null, facesMessage);
	}

}