/*
 *Class Name : CustomUtility.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 29 April 2014 
 */
public class CustomUtility {

	public CustomUtility() {

	}

	public String convertArrayToString(String[] array, int skipUpto) {

		for (int i = 0; i < skipUpto; i++) {
			array[i] = "";
		}

		StringBuilder builder = new StringBuilder();
		for (String s : array) {
			builder.append(s);
		}
		return builder.toString();
	}

	public String getDateForReport() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMMdd_HHmmss");
		Calendar calendar = Calendar.getInstance();
		return dateFormat.format(calendar.getTime());
	}

	public String IntToLetters(int value) {
		String result = "";
		while (--value >= 0) {
			result = (char) ('A' + value % 26) + result;
			value /= 26;
		}
		return result;
	}

	public String getStartDate() {
		Date today = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(today);
		calendar.add(Calendar.YEAR, -3);
		calendar.set(Calendar.DAY_OF_MONTH,
				calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		Date lastDayOfMonth = calendar.getTime();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		return sdf.format(lastDayOfMonth);
	}

	public String getEndDate() {
		Date today = new Date();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(today);

		calendar.add(Calendar.MONTH, -1);
		calendar.set(Calendar.DAY_OF_MONTH,
				calendar.getActualMaximum(Calendar.DAY_OF_MONTH));

		Date lastDayOfMonth = calendar.getTime();

		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		return sdf.format(lastDayOfMonth);
	}

	public List<List<String>> getAllLayoutID(String payer) {
		String query = "SELECT A.LAYOUTID FROM IMP_LAYOUTS A,IMP_SUB_LAYOUTS B "
				+ " WHERE A.LAYOUTID=B.LAYOUTID  AND A.payor='"
				+ payer
				+ "' AND Upper(SUBLAYOUTDESC)!='CONTROLTOTAL' GROUP BY A.LAYOUTID";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> layoutList = db.resultSetToListOfList(query);
		db.endConnection();

		return layoutList;
	}

	public List<List<String>> getAllLayoutIDBypayorName(String payorName) {
		String query = "SELECT LAYOUTID FROM IMP_LAYOUTS " + " WHERE PAYOR='"
				+ payorName + "' ORDER BY LAYOUTID";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> layoutidList = db.resultSetToListOfList(query);
		db.endConnection();

		return layoutidList;
	}

	public String getHashValue(String value) {

		try {
			MessageDigest m;
			m = MessageDigest.getInstance("MD5");
			m.update(value.getBytes(), 0, value.length());
			String hashedValue = new BigInteger(1, m.digest()).toString(16);
			return hashedValue;
		} catch (NoSuchAlgorithmException e) {
			return null;
		}

	}

	public List<List<String>> getAllLayoutIDforCAtt(String payor) {
		String query = "SELECT A.LAYOUTID FROM IMP_LAYOUTS A,IMP_SUB_LAYOUTS B "
				+ " WHERE A.LAYOUTID=B.LAYOUTID and A.PAYOR='"
				+ payor
				+ "' AND Upper(SUBLAYOUTDESC)='CONTROLTOTAL' GROUP BY A.LAYOUTID";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> layoutList = db.resultSetToListOfList(query);
		db.endConnection();

		return layoutList;
	}

	public List<List<String>> getAllLayoutIDByPayor(String payor) {
		String query = "SELECT A.LAYOUTID FROM IMP_LAYOUTS A,IMP_SUB_LAYOUTS B "
				+ " WHERE A.LAYOUTID=B.LAYOUTID and A.PAYOR='"
				+ payor
				+ "' AND Upper(SUBLAYOUTDESC)='DATAFILE' GROUP BY A.LAYOUTID";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> layoutList = db.resultSetToListOfList(query);
		db.endConnection();

		return layoutList;
	}
	
	/*public String getScreenHeight() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int screenHeight=0;
		int screenWidth=0;
		String winScreenHeight="";
		screenHeight=(int)(screenSize.getHeight());
		screenWidth=(int)(screenSize.getWidth());
		System.out.println("Height: "+screenHeight);
		System.out.println("weight: "+screenWidth);
		if(screenHeight==706 && screenWidth==1366){
			winScreenHeight="320";
		}
		if(screenHeight==1002 && screenWidth==1280){
			winScreenHeight="615";
		}
		
		
		return "320";
	}*/


}
