/*
 *Class Name : ReportUtility.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.utils;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;

import com.vit.ai.poireport.model.RCell;
import com.vit.ai.poireport.model.RCustomStyle;
import com.vit.ai.poireport.model.RRow;
import com.vit.dbconnection.ConnectDB;


/**
 * Utility class for reports
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 29 April 2014
 *
 */
public class ReportUtility {
	private Workbook workBook;
	Map<String, CellStyle> styles = new HashMap<String, CellStyle>();

	ConnectDB db;

	public ConnectDB getDb() {
		return db;
	}

	public void setDb(ConnectDB db) {
		this.db = db;
	}

	@SuppressWarnings("unused")
	public void setStyles() {
		DataFormat df = workBook.createDataFormat();
		short nf = df.getFormat("#,##0");
		short nf1 = df.getFormat("#,##0.00");
		short nf2 = df.getFormat("0");
		short cf = df.getFormat("$#,##0.00");
		short pf = df.getFormat("0.00##\\%");
		short pfm = df.getFormat("0.00%");
		XSSFCellStyle heading_style, heading_style2, heading_style3, heading_style_dy,common_style,vh_style,vendor_style,variance_style, integer_style, integer_style2, integer_style3, normal_style, normalRed_style, normalBold_style, percentage_style, styleForsummary, styleForsummary2, dollarstyle, heading_style_gray, heading_stylepb, redfilled_style, yellowFilled_Style, redfilled_dollar_style, redfilled_percentage_style, redfilled_integer_style, no_style, yellowFilled_dollar_style, yellowFilled_percentage_style, yellowFilled_integer_style, percentage_style_meta;

		Font vh_invFont = workBook.createFont();
		vh_invFont.setFontName("Arial");
		vh_invFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		vh_invFont.setFontHeightInPoints((short) 10);
		vh_invFont.setColor(IndexedColors.BLACK.index);

		Font Font = workBook.createFont();
		Font.setFontName("Arial");
		Font.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_NORMAL);
		Font.setFontHeightInPoints((short) 8);
		Font.setColor(IndexedColors.BLACK.index);

		Font headingFont = workBook.createFont();
		headingFont.setFontName("Calibri");
		headingFont
				.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_NORMAL);
		headingFont.setFontHeightInPoints((short) 11);
		headingFont.setColor(IndexedColors.BLACK.index);

		Font Font2 = workBook.createFont();
		Font2.setFontName("Arial");
		Font2.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font2.setFontHeightInPoints((short) 8);
		Font2.setColor(IndexedColors.BLACK.index);

		Font Font3 = workBook.createFont();
		Font3.setFontName("Calibri");
		Font3.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_NORMAL);
		Font3.setFontHeightInPoints((short) 11);
		Font3.setColor(IndexedColors.WHITE.index);

		Font Font4 = workBook.createFont();
		Font4.setFontName("Arial");
		Font4.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		Font4.setFontHeightInPoints((short) 8);
		Font4.setColor(IndexedColors.BLACK.index);

		Font FontRed = workBook.createFont();
		FontRed.setFontName("Arial");
		FontRed.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		FontRed.setFontHeightInPoints((short) 8);
		FontRed.setColor(IndexedColors.RED.index);

		Font whiteFont = workBook.createFont();
		whiteFont.setFontName("Arial");
		whiteFont
				.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_NORMAL);
		whiteFont.setFontHeightInPoints((short) 8);
		whiteFont.setColor(IndexedColors.WHITE.index);

		Font FontCalibri9 = workBook.createFont();
		FontCalibri9.setFontName("Calibri");
		FontCalibri9
				.setBoldweight(org.apache.poi.ss.usermodel.Font.BOLDWEIGHT_BOLD);
		FontCalibri9.setFontHeightInPoints((short) 9);
		FontCalibri9.setColor(IndexedColors.BLACK.index);

		dollarstyle = (XSSFCellStyle) createBorderedStyle(workBook);
		dollarstyle.setAlignment(CellStyle.ALIGN_RIGHT);
		dollarstyle.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		dollarstyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		dollarstyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		dollarstyle.setFont(Font);
		dollarstyle.setDataFormat(cf);
		styles.put("dollar_style", dollarstyle);

		heading_style = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_style.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_style.setFillForegroundColor(IndexedColors.LIGHT_BLUE
				.getIndex());
		heading_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style.setFont(Font3);
		styles.put("heading_style", heading_style);

		heading_stylepb = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_stylepb.setAlignment(CellStyle.ALIGN_CENTER);
		heading_stylepb.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_stylepb.setFillForegroundColor(IndexedColors.PALE_BLUE
				.getIndex());
		heading_stylepb.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_stylepb.setFont(Font4);
		styles.put("heading_stylepb", heading_stylepb);

		heading_style = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_style.setAlignment(CellStyle.ALIGN_LEFT);
		heading_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_style.setFillForegroundColor(new XSSFColor(new java.awt.Color(
				83, 142, 213)));
		heading_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style.setFont(Font3);
		styles.put("heading_style_LB", heading_style);

		heading_style2 = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_style2.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style2.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_style2.setFillForegroundColor(new XSSFColor(new java.awt.Color(
				215, 228, 188)));
		heading_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style2.setFont(Font4);
		styles.put("heading_style_LC", heading_style2);

		heading_style3 = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_style3.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style3.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_style3.setFillForegroundColor(new XSSFColor(new java.awt.Color(
				184, 204, 228)));
		heading_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style3.setFont(Font4);
		styles.put("heading_style_CB", heading_style3);

		heading_style_dy = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_style_dy.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style_dy.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_style_dy.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(194, 214, 154)));
		heading_style_dy.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style_dy.setFont(Font4);
		styles.put("heading_style_DY", heading_style_dy);

		heading_style_gray = (XSSFCellStyle) createBorderedStyle(workBook);
		heading_style_gray.setAlignment(CellStyle.ALIGN_CENTER);
		heading_style_gray.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		heading_style_gray.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(191, 191, 191)));
		heading_style_gray.setFillPattern(CellStyle.SOLID_FOREGROUND);
		heading_style_gray.setFont(Font4);
		styles.put("heading_style_gray", heading_style_gray);

		integer_style = (XSSFCellStyle) createBorderedStyle(workBook);
		integer_style.setAlignment(CellStyle.ALIGN_RIGHT);
		integer_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		integer_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style.setFont(Font);
		integer_style.setDataFormat(nf);
		styles.put("integer_style", integer_style);

		integer_style2 = (XSSFCellStyle) createBorderedStyle(workBook);
		integer_style2.setAlignment(CellStyle.ALIGN_RIGHT);
		integer_style2.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		integer_style2.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style2.setFont(Font);
		integer_style2.setDataFormat(nf2);
		styles.put("integer_style2", integer_style2);

		integer_style3 = (XSSFCellStyle) createBorderedStyle(workBook);
		integer_style3.setAlignment(CellStyle.ALIGN_RIGHT);
		integer_style3.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		integer_style3.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		integer_style3.setFillPattern(CellStyle.SOLID_FOREGROUND);
		integer_style3.setFont(Font);
		integer_style3.setDataFormat(nf1);
		styles.put("integer_style3", integer_style3);

		normal_style = (XSSFCellStyle) createBorderedStyle(workBook);
		normal_style.setAlignment(CellStyle.ALIGN_LEFT);
		normal_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		normal_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normal_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normal_style.setFont(Font);
		styles.put("normal_style", normal_style);

		normalRed_style = (XSSFCellStyle) createBorderedStyle(workBook);
		normalRed_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalRed_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		normalRed_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalRed_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalRed_style.setFont(FontRed);
		styles.put("normalRed_style", normalRed_style);

		redfilled_style = (XSSFCellStyle) createBorderedStyle(workBook);
		redfilled_style.setAlignment(CellStyle.ALIGN_LEFT);
		redfilled_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		redfilled_style.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
		redfilled_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_style.setFont(whiteFont);
		styles.put("redfilled_style", redfilled_style);

		redfilled_dollar_style = (XSSFCellStyle) createBorderedStyle(workBook);
		redfilled_dollar_style.setAlignment(CellStyle.ALIGN_RIGHT);
		redfilled_dollar_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		redfilled_dollar_style.setFillForegroundColor(IndexedColors.ORANGE
				.getIndex());
		redfilled_dollar_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_dollar_style.setFont(whiteFont);
		redfilled_dollar_style.setDataFormat(cf);
		styles.put("redfilled_dollar_style", redfilled_dollar_style);

		redfilled_percentage_style = (XSSFCellStyle) createBorderedStyle(workBook);
		redfilled_percentage_style.setAlignment(CellStyle.ALIGN_RIGHT);
		redfilled_percentage_style
				.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		redfilled_percentage_style.setFillForegroundColor(IndexedColors.ORANGE
				.getIndex());
		redfilled_percentage_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_percentage_style.setFont(whiteFont);
		redfilled_percentage_style.setDataFormat(pf);
		styles.put("redfilled_percentage_style", redfilled_percentage_style);

		redfilled_integer_style = (XSSFCellStyle) createBorderedStyle(workBook);
		redfilled_integer_style.setAlignment(CellStyle.ALIGN_RIGHT);
		redfilled_integer_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		redfilled_integer_style.setFillForegroundColor(IndexedColors.ORANGE
				.getIndex());
		redfilled_integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		redfilled_integer_style.setFont(whiteFont);
		redfilled_integer_style.setDataFormat(nf);
		styles.put("redfilled_integer_style", redfilled_integer_style);

		yellowFilled_Style = (XSSFCellStyle) createBorderedStyle(workBook);
		yellowFilled_Style.setAlignment(CellStyle.ALIGN_LEFT);
		yellowFilled_Style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		yellowFilled_Style.setFillForegroundColor(IndexedColors.YELLOW
				.getIndex());
		yellowFilled_Style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_Style.setFont(Font);
		styles.put("yellowFilled_Style", yellowFilled_Style);

		yellowFilled_dollar_style = (XSSFCellStyle) createBorderedStyle(workBook);
		yellowFilled_dollar_style.setAlignment(CellStyle.ALIGN_RIGHT);
		yellowFilled_dollar_style
				.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		yellowFilled_dollar_style.setFillForegroundColor(IndexedColors.YELLOW
				.getIndex());
		yellowFilled_dollar_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_dollar_style.setFont(Font);
		yellowFilled_dollar_style.setDataFormat(cf);
		styles.put("yellowFilled_dollar_style", yellowFilled_dollar_style);

		yellowFilled_percentage_style = (XSSFCellStyle) createBorderedStyle(workBook);
		yellowFilled_percentage_style.setAlignment(CellStyle.ALIGN_RIGHT);
		yellowFilled_percentage_style
				.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		yellowFilled_percentage_style
				.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
		yellowFilled_percentage_style
				.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_percentage_style.setFont(Font);
		yellowFilled_percentage_style.setDataFormat(pf);
		styles.put("yellowFilled_percentage_style",
				yellowFilled_percentage_style);

		yellowFilled_integer_style = (XSSFCellStyle) createBorderedStyle(workBook);
		yellowFilled_integer_style.setAlignment(CellStyle.ALIGN_RIGHT);
		yellowFilled_integer_style
				.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		yellowFilled_integer_style.setFillForegroundColor(IndexedColors.YELLOW
				.getIndex());
		yellowFilled_integer_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		yellowFilled_integer_style.setFont(Font);
		yellowFilled_integer_style.setDataFormat(nf);
		styles.put("yellowFilled_integer_style", yellowFilled_integer_style);

		normalBold_style = (XSSFCellStyle) createBorderedStyle(workBook);
		normalBold_style.setAlignment(CellStyle.ALIGN_LEFT);
		normalBold_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		normalBold_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		normalBold_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		normalBold_style.setFont(Font2);
		styles.put("normalBold_style", normalBold_style);

		percentage_style = (XSSFCellStyle) createBorderedStyle(workBook);
		percentage_style.setAlignment(CellStyle.ALIGN_RIGHT);
		percentage_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		percentage_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		percentage_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		percentage_style.setFont(Font);
		percentage_style.setDataFormat(pf);
		styles.put("percentage_style", percentage_style);

		percentage_style_meta = (XSSFCellStyle) createBorderedStyle(workBook);
		percentage_style_meta.setAlignment(CellStyle.ALIGN_RIGHT);
		percentage_style_meta.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		percentage_style_meta.setFillForegroundColor(IndexedColors.WHITE
				.getIndex());
		percentage_style_meta.setFillPattern(CellStyle.SOLID_FOREGROUND);
		percentage_style_meta.setFont(Font);
		percentage_style.setDataFormat(pf);
		styles.put("percentage_style", percentage_style);

		no_style = (XSSFCellStyle) noBorder(workBook);
		styles.put("no_style", no_style);

		styleForsummary = (XSSFCellStyle) createBorderedStyle(workBook);
		styleForsummary.setAlignment(CellStyle.ALIGN_LEFT);
		styleForsummary.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		styleForsummary.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(242, 242, 242)));
		styleForsummary.setFillPattern(CellStyle.SOLID_FOREGROUND);
		styleForsummary.setFont(FontCalibri9);
		styles.put("summary_main", styleForsummary);

		styleForsummary2 = (XSSFCellStyle) createBorderedStyle(workBook);
		styleForsummary2.setAlignment(CellStyle.ALIGN_LEFT);
		styleForsummary2.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		styleForsummary2.setFillForegroundColor(new XSSFColor(
				new java.awt.Color(229, 224, 236)));
		// styleForsummary2.setFillForegroundColor(IndexedColors.GREY_40_PERCENT.index);
		styleForsummary2.setFillPattern(CellStyle.SOLID_FOREGROUND);
		styleForsummary2.setFont(FontCalibri9);
		styles.put("summary_border", styleForsummary2);

		CellStyle backGroundEven = workBook.createCellStyle();
		backGroundEven.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
		backGroundEven.setFillPattern(CellStyle.BIG_SPOTS);
		styles.put("backGroundEven", backGroundEven);

		CellStyle backGroundOdd = workBook.createCellStyle();
		backGroundOdd.setFillBackgroundColor(IndexedColors.WHITE.getIndex());
		backGroundOdd.setFillPattern(CellStyle.BIG_SPOTS);
		styles.put("backGroundOdd", backGroundOdd);
		

		common_style = (XSSFCellStyle) createBorderedStyle(workBook);
		common_style.setAlignment(CellStyle.ALIGN_CENTER);
		common_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		common_style.setFillForegroundColor(IndexedColors.WHITE.getIndex());
		common_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		common_style.setFont(Font4);		
		styles.put("common_style", common_style);
		
		vh_style = (XSSFCellStyle) createBorderedStyle(workBook);
		vh_style.setAlignment(CellStyle.ALIGN_CENTER);
		vh_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		vh_style.setFillForegroundColor(new XSSFColor(new java.awt.Color(217,151,149)));
		vh_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		vh_style.setFont(Font4);
		styles.put("vh_style", vh_style);
		
		vendor_style = (XSSFCellStyle) createBorderedStyle(workBook);
		vendor_style.setAlignment(CellStyle.ALIGN_CENTER);
		vendor_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		vendor_style.setFillForegroundColor(new XSSFColor(new java.awt.Color(155,187,89)));
		vendor_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		vendor_style.setFont(Font4);
		styles.put("vendor_style", vendor_style);
		
		variance_style = (XSSFCellStyle) createBorderedStyle(workBook);
		variance_style.setAlignment(CellStyle.ALIGN_CENTER);
		variance_style.setVerticalAlignment(CellStyle.VERTICAL_BOTTOM);
		variance_style.setFillForegroundColor(new XSSFColor(new java.awt.Color(147,205,221)));
		variance_style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		variance_style.setFont(Font4);
		
		styles.put("variance_style", variance_style);
	}

	public Workbook getWorkBook() {
		return workBook;
	}

	public void setWorkBook(Workbook workBook) {
		this.workBook = workBook;
	}

	public ReportUtility(Workbook wb) {
		setWorkBook(wb);
		this.setStyles();
	}

	public Map<String, CellStyle> getStyle() {
		return styles;

	}

	private static CellStyle createBorderedStyle(Workbook wb) {
		CellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_THIN);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(CellStyle.BORDER_THIN);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(CellStyle.BORDER_THIN);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderTop(CellStyle.BORDER_THIN);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		return style;

	}

	private static CellStyle noBorder(Workbook wb) {
		CellStyle style = wb.createCellStyle();
		style.setBorderRight(CellStyle.BORDER_NONE);
		style.setBorderBottom(CellStyle.BORDER_NONE);
		style.setBorderLeft(CellStyle.BORDER_NONE);
		style.setBorderTop(CellStyle.BORDER_NONE);
		return style;

	}

	public List<RCell> getCellFromString(String[] input) {

		List<RCell> cells = new ArrayList<RCell>();
		for (String s : input) {
			RCell cell = new RCell();
			cell.setCellValue(s);
			RCustomStyle customStyle = new RCustomStyle();
			customStyle.setCellStyle(this.getStyle().get("heading_style"));
			cell.setCustomStyle(customStyle);
			cells.add(cell);
		}

		return cells;
	}

	public List<RRow> getHeaderRows(String header) {

		List<RRow> headerRows = new ArrayList<RRow>();

		if (header.contains("<Formula>")) {

			for (String s : header.split("<NextRow>")) {
				RRow row = new RRow();
				List<RCell> cells = new ArrayList<RCell>();
				for (String s1 : s.split(",")) {
					RCell cell = new RCell();
					RCustomStyle customStyle = new RCustomStyle();
					if (s1.contains("DOLLAR<Formula>")) {
						cell.setFormula(s1.replaceAll("DOLLAR<Formula>", "")
								.replaceAll("@", ","));
						customStyle.setCellStyle(this.getStyle().get(
								"dollar_style"));
					} else if (s1.contains("NUMBER<Formula>")) {
						cell.setFormula(s1.replaceAll("NUMBER<Formula>", "")
								.replaceAll("@", ","));
						customStyle.setCellStyle(this.getStyle().get(
								"integer_style"));
					} else if (s1.equals("")) {
						cell.setCellValue(s1);
						customStyle.setCellStyle(this.getStyle().get(
								"normal_style"));
					} else {
						cell.setCellValue(s1);
						customStyle.setCellStyle(this.getStyle().get(
								"heading_style"));
					}

					cell.setCustomStyle(customStyle);
					cells.add(cell);

				}
				row.setCells(cells);
				headerRows.add(row);
			}
		} else {
			for (String s : header.split("<NextRow>")) {
				RRow row = new RRow();
				List<RCell> cells = new ArrayList<RCell>();
				for (String s1 : s.split(",")) {
					RCell cell = new RCell();
					RCustomStyle customStyle = new RCustomStyle();
					cell.setCellValue(s1);

					customStyle.setCellStyle(this.getStyle().get(
							"heading_style"));
					cell.setCustomStyle(customStyle);
					cells.add(cell);

				}
				row.setCells(cells);
				headerRows.add(row);
			}
		}
		return headerRows;
	}

	public List<RRow> preapreDataForSummary_MDR() {

		String[][] s = {
				{ "Client ID", "" },
				{ "Client Name", "" },
				{ "Group Name", "" },
				{ "Payor", "" },
				{ "", "" },
				{ "Data Source", "" },
				{ "", "" },
				{ "", "" },
				{ "", "" },
				{ "Update Date", "" },
				{ "", "" },
				{ "Highlights", "" },
				{ "", "" },
				{ "", "" },
				{ "", "" },
				{ "", "" },
				{ "Reviewed by VH", "" },
				{ "", "" },
				{ "Approved by Client", "" },
				{ "", "" },
				{ "", "" },
				{
						"* This report will be generated in implementation phase or on demand basis.",
						"" } };
		List<RRow> headerRows = new ArrayList<RRow>();
		RCustomStyle customStyle = new RCustomStyle();

		for (int i = 0; i < s.length; i++) {
			RRow row = new RRow();
			List<RCell> cells = new ArrayList<RCell>();

			for (int j = 0; j < 2; j++) {
				RCell cell = new RCell();
				cell.setCellValue(s[i][j]);
				customStyle.setCellStyle(this.getStyle().get("summary_main"));
				cell.setCustomStyle(customStyle);
				cells.add(cell);
			}
			row.setCells(cells);
			headerRows.add(row);

		}

		return headerRows;
	}

}
