/* 
 *Class Name : AbstractController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.utils;

import org.primefaces.context.RequestContext;

/**
 * Class to manage JSF Dialog and message
 * 
 * @author Sagar Shrestha
 * 
 * @version 1.0 28 April 2014
 */
public class AbstractController {
	private static final String KEEP_DIALOG_OPENED = "KEEP_DIALOG_OPENED";

	public AbstractController() {
		super();
	}

	protected void displayErrorMessageToUser(String message, String title) {
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendErrorMessageToUser(message, title);
	}

	protected void displayInfoMessageToUser(String message, String title) {
		JSFMessageUtil messageUtil = new JSFMessageUtil();
		messageUtil.sendInfoMessageToUser(message, title);
	}

	protected void closeDialog() {
		getRequestContext().addCallbackParam(KEEP_DIALOG_OPENED, false);
	}

	protected void keepDialogOpen() {
		getRequestContext().addCallbackParam(KEEP_DIALOG_OPENED, true);
	}

	protected RequestContext getRequestContext() {
		return RequestContext.getCurrentInstance();
	}
}