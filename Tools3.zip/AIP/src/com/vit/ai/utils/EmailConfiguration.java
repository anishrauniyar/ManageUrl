package com.vit.ai.utils;

import java.util.ArrayList;


import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailConfiguration {

	private String subject;
	private String to;
	private ArrayList<String> cc;
	private String content;
	private String from;
	private String host;
    final  String signature="\n\n\n"
				+ "*******************************************************."
				+ "\nThis is a system Generated Mail. Please donot reply to this mail."
				+ "\n"
				+ "If you have any Queries please contact AIP Team (_vitDA-AIP@verscend.com)";

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public ArrayList<String> getCc() {
		return cc;
	}

	public void setCc(ArrayList<String> cc) {
		this.cc = cc;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public EmailConfiguration() {
		this.host = "localhost";
		this.from = "aip@verscend.com";
		this.cc = new ArrayList<>();
	}

	public int sendMail() {

		Properties properties = System.getProperties();
		// properties.setProperty("mail.smtp.starttls.enable", "true");
		properties.setProperty("mail.smtp.host", host);
		properties.setProperty("mail.smtp.port", "25");
		Session session = Session.getDefaultInstance(properties);
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));
			for (int i = 0; i < this.cc.size(); i++) {
				message.addRecipient(Message.RecipientType.CC,
						new InternetAddress(cc.get(i)));
			}

			message.setSubject(subject);
			System.out.println(this.getSubject());
			message.setText(content + this.signature);
			Transport.send(message);
			return 1;

		} catch (MessagingException ex) {
			System.out.println("ERROR SENDING MAIL");
			ex.printStackTrace();
			return 0;
		}

	}

}
