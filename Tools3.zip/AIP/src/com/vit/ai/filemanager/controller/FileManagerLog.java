/* 
 *Class Name : FileManagerLog.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.filemanager.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.component.datatable.DataTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.commons.model.DataType;
import com.vit.ai.filemanager.model.Manager;
import com.vit.ai.flms.model.LayoutsByClients;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.flms.model.LayoutsbyUser;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for file manager log
 * 
 * @author Binesh Sah
 * 
 * @modified Anish Rauniyar
 * 
 * @verison 1.0 26 Jan 2015
 */
@ManagedBean
@ViewScoped
public class FileManagerLog extends AbstractController implements Serializable {

	private static Logger log = LoggerFactory.getLogger(FileManagerLog.class);
	
	private static final long serialVersionUID = 1L;
	private String user;
	private ArrayList<String> users;
	private String client;
	private ArrayList<String> clients;
	private ArrayList<Manager> uploadList;
	private ArrayList<Manager> filteredLogs;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;
	private String winScreenHeight;
	private String filterType;
	private String selectedFilterType;
	
	

	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getSelectedFilterType() {
		return selectedFilterType;
	}
	public void setSelectedFilterType(String selectedFilterType) {
		this.selectedFilterType = selectedFilterType;
	}
	public ArrayList<String> getClients() {
		return clients;
	}
	public void setClients(ArrayList<String> clients) {
		try {
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> clientList = db
					.resultSetToListOfList("SELECT A.CLIENTID, B.CLIENTNAME "
											+ " FROM ( " 
											+ " SELECT CLIENTID FROM IMP_CLIENTPATTERNS GROUP BY CLIENTID "  
											+ " ) A LEFT JOIN "  
											+ " HAWKEYEMASTER.M_CLIENTS B " 
											+ " ON A.CLIENTID = B.CLIENTID ORDER BY CLIENTID");	
			db.endConnection();
			if (clientList.size() > 0) {
				for (int i = 1; i < clientList.size(); i++) {
					clients.add(clientList.get(i).get(0) + " (" + clientList.get(i).get(1) + ")");
				}
			}
		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(), "Client Not Found");
		}
	}
	public String getFilterType() {
		return filterType;
	}
	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public ArrayList<Manager> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<Manager> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public ArrayList<Manager> getUploadList() {
		return uploadList;
	}

	public void setUploadList(ArrayList<Manager> uploadList) {
		this.uploadList = uploadList;
	}

	public ArrayList<String> getUsers() {
		return users;
	}

	public void setUsers(ArrayList<String> users) {
		try {
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> userList = db
					.resultSetToListOfList("SELECT DISTINCT FULLNAME FROM  AIPD_USERS order by 1");
			db.endConnection();

			if (userList.size() > 0) {
				for (int i = 1; i < userList.size(); i++) {
					users.add(userList.get(i).get(0));
				}
			}

		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(), "User Not Found");
		}
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	@PostConstruct
	public void init() {
		if (getSessionData() != null) {
			this.user = getSessionData().getFullname();
		} else {

		}
	}

	public FileManagerLog() {

		users = new ArrayList<>();
		setUsers(users);
		clients = new ArrayList<>();
		setClients(clients);
		setSelectedFilterType("filterByUser");
		init();
	}

	public void handleUserchnage() {
		try {
			if (this.filteredLogs != null) {
				this.filteredLogs = null;
				DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("frmFM:uploadLog");
				dt1.setFilters(null);
				dt1.reset();

			}

			uploadList = new ArrayList<Manager>();
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "";
			if (getSelectedFilterType() == "filterByUser") {
				query = " SELECT Nvl(B.FILENAME,A.FILENAME) ,NVL(FROM_CLIENTID,'FROM LOCAL') AS FROM_CLIENTID ,"
						+ " TO_CLIENTID ,UPLOADED_DATE,UPLOAD_STATUS, B.FILEID, A.DMFILEID  ,"
						+ " PROCESSSTATUS AS AIP_STATUS,STATUS_IMPORT,SERVERNAME, B.*, A.UPLOADED_BY "
						+ "FROM IMP_FILEMANAGER A  LEFT JOIN AIP_DASHBOARD_INVENTORY B "
						+ " ON A.DMFILEID=B.DMFILEID  WHERE A.UPLOADED_BY='"
						+ this.getUser() + "' ORDER BY A.UPLOADED_DATE DESC";
			} else if (getSelectedFilterType() == "filterByClient") {
				query = " SELECT Nvl(B.FILENAME,A.FILENAME) ,NVL(FROM_CLIENTID,'FROM LOCAL') AS FROM_CLIENTID ,"
						+ " TO_CLIENTID ,UPLOADED_DATE,UPLOAD_STATUS  ,  B.FILEID, A.DMFILEID  ,"
						+ " PROCESSSTATUS AS AIP_STATUS,STATUS_IMPORT,SERVERNAME, B.*, A.UPLOADED_BY "
						+ "FROM IMP_FILEMANAGER A  LEFT JOIN AIP_DASHBOARD_INVENTORY B "
						+ " ON A.DMFILEID=B.DMFILEID  WHERE B.CLIENTID='"
						+ this.getClient().substring(0, Math.min(getClient().length(), 3)) + "' ORDER BY A.UPLOADED_DATE DESC";
			}
			log.info("The query is: " + query);
			List<List<String>> AllInfoList = db.resultSetToListOfList(query);
			db.endConnection();
			log.info("Size of the query is: " + AllInfoList.size());
			if (AllInfoList.size() > 0) {
				for (int i = 1; i < AllInfoList.size(); i++) {
					uploadList.add(new Manager(AllInfoList.get(i).get(0),
							AllInfoList.get(i).get(1), AllInfoList.get(i)
									.get(2), AllInfoList.get(i).get(3),
							AllInfoList.get(i).get(4), AllInfoList.get(i)
									.get(5), AllInfoList.get(i).get(6),
							AllInfoList.get(i).get(7), AllInfoList.get(i)
									.get(8), AllInfoList.get(i).get(9),
							AllInfoList.get(i).get(16), AllInfoList.get(i).get(
									17), AllInfoList.get(i).get(18),
							AllInfoList.get(i).get(22), AllInfoList.get(i).get(
									23), AllInfoList.get(i).get(51)));
				}
			}

		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(), "Data Not Found");
		}
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {

		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}
	
	public void handleFilterChange() {
		try{
			setSelectedFilterType(getFilterType());
			if (getFilterType().compareTo("filterByUser") == 0) {
				//LayoutsbyId ojbLID = new LayoutsbyID("ALL PAYERS");
				//this.layoutids = ojbLID.getLayoutids();
				setSelectedFilterType("filterByUser");
				log.info("This is a User Selection");
			} else if (getFilterType().compareTo("filterByClient") == 0) {
				//LayoutsbyUser objUIDB = new LayoutsbyUser("ALL PAYERS");
				//this.usernames = objUIDB.getUsers();
				log.info("This is a Client Selection");
				setSelectedFilterType("filterByClient");
				//setClients(clients);
			}
		} catch (Exception e) {
			log.info("The exception in handle filter change is: " + e.getMessage());
		}
	}
	
}
