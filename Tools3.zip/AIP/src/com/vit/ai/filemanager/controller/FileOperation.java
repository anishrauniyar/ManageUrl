/*
 *Class Name : FileOperation.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.filemanager.controller;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.vit.ai.flms.controller.EigerPath;
/**
 * Controller Class for Eiger file operation
 * 
 * @author Binesh Sah
 *
 * @version 1.0 26 Nov 2015
 */
@ManagedBean
@ViewScoped
public class FileOperation extends EigerPath implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public FileOperation(){
		
	}
	

}
