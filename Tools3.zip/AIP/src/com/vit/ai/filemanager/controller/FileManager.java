/*
 *Class Name : FileManager.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.filemanager.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.TreeNode;
import org.primefaces.model.UploadedFile;

import com.vit.ai.background.RunbackgroundExceptionImport;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 * 
 * @verison 1.0 25 Jan 2015
 */
@ManagedBean
@ViewScoped
public class FileManager extends AbstractController implements Serializable {

	private static final long serialVersionUID = 769666004936122036L;
	private TreeNode source;
	private TreeNode[] selecttedNodes;
	private ArrayList<String> clients = new ArrayList<>();
	private String client = "";
	private String fromClient = "";
	private String toClient = "";
	String sn;
	private String importStatus = "Y";
	private boolean panelStatus = false;
	int counter = 0;
	private StringBuilder commandforEigerFile = new StringBuilder();
	private StringBuilder commandforLocalFile = new StringBuilder();
	private String server="";

	String uploadTime;

	public boolean isPanelStatus() {
		return panelStatus;
	}

	public void setPanelStatus(boolean panelStatus) {
		this.panelStatus = panelStatus;
	}

	public String getImportStatus() {
		return importStatus;
	}

	public void setImportStatus(String importStatus) {
		this.importStatus = importStatus;
	}

	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public String getFromClient() {
		return fromClient;
	}

	public void setFromClient(String fromClient) {
		this.fromClient = fromClient;
	}

	public String getToClient() {
		return toClient;
	}

	public void setToClient(String toClient) {
		this.toClient = toClient;
	}

	private String path;
	private String sourceLocation = "";

	public TreeNode[] getSelecttedNodes() {
		return selecttedNodes;
	}

	public void setSelecttedNodes(TreeNode[] selecttedNodes) {
		this.selecttedNodes = selecttedNodes;
	}

	public String getSourceLocation() {
		return sourceLocation;
	}

	public void setSourceLocation(String sourceLocation) {
		this.sourceLocation = sourceLocation;
	}

	private UploadedFile uploadFile;
	private DefaultStreamedContent filemedia;

	private String name;
	private ArrayList<String> validSourceLocations = new ArrayList<>(
			Arrays.asList(new String[] { "Local", "Eiger" }));

	public ArrayList<String> getValidSourceLocations() {
		return validSourceLocations;
	}

	public void setValidSourceLocations(ArrayList<String> validSourceLocations) {
		this.validSourceLocations = validSourceLocations;
	}

	public FileManager() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMM");
		Calendar calendar = Calendar.getInstance();
		uploadTime = dateFormat.format(calendar.getTime());
		clients = new ArrayList<>();

		this.importStatus = "Y";
		try {
			

			String command = "ls -dt " + AIConstant.EIGER_PATH + "*/|sort -h|sed 's:"
					+ AIConstant.EIGER_PATH + "::g'";
			// ls -d /eiger/Clients/*/ | sed 's:/eiger/Clients/::g'
			RuntimeExecutor rt = new RuntimeExecutor(
					AIConstant.DASHBOARD_SERVER_NAME);
			String[] listofClients = rt.runeigerCommand(command).toString()
					.split("\\++");
			for (int i = 0; i < listofClients.length; i++) {

				clients.add(listofClients[i].replace("/", ""));
			}

			rt.endProcess();
		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(), "Client Not Found");
		}

	}

	public TreeNode getSource() {
		return source;
	}

	public void setSource(TreeNode source) {

		this.source = source;
	}

	public ArrayList<String> getClients() {
		return clients;
	}

	public void setClients(ArrayList<String> clients) {
		this.clients = clients;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public void handleClient() {

		
		String path = AIConstant.EIGER_PATH + this.getFromClient();
		
		if (this.sourceLocation.equals("Eiger")) {
			FolderBrowserwithCheckbox bs = new FolderBrowserwithCheckbox(path,
					true);
			source = bs.getRoot();
		} else {
			return;
		}

	}

	public void changetoClient() {
		try {

			this.importStatus = "";
			setServer(AIConstant.DASHBOARD_SERVER_NAME);
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "SELECT DISTINCT MACHINE FROM  AIP_CLIENT_SERVER WHERE CLIENTID='"
					+ this.toClient.toString().split("\\-")[0].toString()
							.trim() + "'";
			List<List<String>> serverList = db.resultSetToListOfList(query);
			db.endConnection();
			if (serverList.size() > 1) {
				if(serverList.get(1).get(0)!=null && !serverList.get(1).get(0).isEmpty()){
					//setServer(AIConstant.DASHBOARD_SERVER_NAME);
					setImportStatus("Y");
				}
				

			} else {
				setImportStatus("N");

			}
			if (this.toClient!=null && !this.toClient.isEmpty() && this.sourceLocation.compareTo("Local")==0) {
				RequestContext.getCurrentInstance().execute(
						"PF('confirmtoClient').show();");
			}

		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(), "Serevr Not Found");
		}

	}
	public void resetDestinationClient(){
		this.toClient="";
	}


	public void changeSourceLoation(ValueChangeEvent vchange) {
		setSourceLocation(vchange.getNewValue().toString());

	}

	public String panelStatus() {
		String value = "";
		if (this.sourceLocation.equals("")) {
			value = "";
			return value;
		}
		if (this.sourceLocation.equals("Eiger")) {
			value = "browserPanel";

		} else if (this.sourceLocation.equals("Local")) {
			value = "uploadPanel";
		}
		return value;

	}

	public synchronized void handleFileUpload(FileUploadEvent event)
			throws InterruptedException {

		String query = "";

		FacesMessage msg = null;

		try {
			if (this.toClient == null || this.toClient.isEmpty()
					|| this.toClient == "") {
				displayInfoMessageToUser("Please Select Destination Client ",
						"Upload Status");
				return;
			}
			uploadFile = event.getFile();
			if (uploadFile == null) {
				msg = new FacesMessage(
						FacesMessage.SEVERITY_ERROR,
						"Upload Status",
						"Cannot Upload File.Try again.Make sure you have submitted your previous download");
			}

			InputStream input = null;
			OutputStream output = null;
			OutputStream destFolder=null;
			String fileUploadPath = AIConstant.TEMPORARY_FILE_LOCATION;
			File file = new File(fileUploadPath);
			if (!file.exists()) {
				file.mkdir();
			}
			String fileName = FilenameUtils.getName(uploadFile.getFileName());

			if (fileName == null || fileName.compareTo("") == 0) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Upload Status", "Select a file to upload");
				FacesContext.getCurrentInstance().addMessage(null, msg);
				return;
			}
			String messageString = "";

			try {
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> snLists = db
						.resultSetToListOfList("SELECT MAX(SN)+1 FROM IMP_FILEMANAGER");
				if (snLists.size() > 1) {
					setSn(snLists.get(1).get(0));

				}
				if (this.getSn().isEmpty() || this.getSn() == null) {
					setSn("1");

				}
				String inquery = "INSERT INTO IMP_FILEMANAGER ( SN, FROM_CLIENTID, TO_CLIENTID, UPLOADED_BY, FILE_SOURCE,upload_status,uploaded_date,DESTFILEPATH,filename,source_filepath,SERVERNAME) VALUES("
						+ this.getSn()
						+ ",'','"
						+ this.toClient.replace("'", "''")
						+ "','"
						+ sessionData.getFullname()
						+ "','local','upload in progress',sysdate,'"
						+ AIConstant.AIPFM_FILE_LOCATION
						+ this.toClient.replace("'", "''")
						+ AIConstant.Data
						+ uploadTime
						+ "/"
						+ "','"
						+ fileName.replace("'", "''")
						+ "','','"
						+ this.getServer() + "')";
				db.executeDML(inquery);

				db.endConnection();
				input = uploadFile.getInputstream();
					
				
				String destfilePath=AIConstant.AIPFM_FILE_LOCATION+toClient
						+ AIConstant.Data + uploadTime+"/";
				File monthFolder = new File(destfilePath);
				if(!monthFolder.exists()){
					monthFolder.mkdirs();
				}
				destFolder = new FileOutputStream(new File(destfilePath
						+ fileName));
				
					IOUtils.copyLarge(input, destFolder);
				
				
				
					query = "UPDATE IMP_FILEMANAGER set upload_status='upload completed',uploaded_date=sysdate where sn="
							+ this.getSn() + "";
					commandforLocalFile.append("\""
							+ AIConstant.AIPFM_FILE_LOCATION
							+ toClient
							+ AIConstant.Data
							+ uploadTime
							+ "/"
							+ fileName.toString()
							+ "|"
							+ this.getSn()
							+ "|"
							+ this.getToClient().toString().split("\\-")[0]
									.toString().trim() + "\"");
					ConnectDB adb = new ConnectDB();
					adb.initialize();
					adb.executeDML(query);
					adb.endConnection();
					if (this.importStatus.equals("N")) {
						displayInfoMessageToUser(
								"This client is not migrated to AIP. File(s) uploaded but didn't send for import",
								"Upload and Import Status");
					} else {
						displayInfoMessageToUser(fileName.toString()
								+ " uploaded and sent for import",
								"Upload and Import Status");
						importLocalFiles(commandforLocalFile.toString(),
								this.getServer());
					}

					commandforLocalFile = new StringBuilder();
				

			} catch (IOException e) {
				query = "UPDATE IMP_FILEMANAGER set upload_status='upload failed',uploaded_date=sysdate where sn="
						+ this.getSn() + "";
				messageString = "Cannot upload " + fileName + ": "
						+ e.getMessage();
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Upload Status", messageString);
				ConnectDB db = new ConnectDB();
				db.initialize();
				db.executeDML(query);
				db.endConnection();
				FacesContext.getCurrentInstance().addMessage(null, msg);
			}

			finally {

				IOUtils.closeQuietly(input);
				IOUtils.closeQuietly(output);
			}
		}

		catch (NullPointerException ex) {
			query = "UPDATE IMP_FILEMANAGER set upload_status='upload failed',uploaded_date=sysdate where sn="
					+ this.getSn() + "";
			FacesContext.getCurrentInstance();
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Upload Status", "Cannot locate file.Please Try Again");
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
			FacesContext.getCurrentInstance().addMessage(null, msg);

		} catch (Exception ex) {
			query = "UPDATE IMP_FILEMANAGER set upload_status='upload failed',uploaded_date=sysdate where sn="
					+ this.getSn() + "";
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Upload Status", "Upload Failed");
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query);
			db.endConnection();
			FacesContext.getCurrentInstance().addMessage(null, msg);

		}

	}

	public void importLocalFiles(String command, String server)
			throws InterruptedException {

		commandforLocalFile = new StringBuilder();
		importUploadedFiles(command, server);
	}

	
	public DefaultStreamedContent getFilemedia() {
		return filemedia;
	}

	public void setFilemedia(DefaultStreamedContent filemedia) {
		this.filemedia = filemedia;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public synchronized void uploadSelectedFiles(TreeNode[] nodes)
			throws IOException {
		String desPath = "";
		String query = "";
		int count=0;
		@SuppressWarnings("unused")
		InputStream inputStream=null;
		@SuppressWarnings("unused")
		String line=null;
		commandforEigerFile = new StringBuilder();
		if (this.toClient == null || this.toClient.isEmpty()
				|| this.toClient == "" || this.toClient.equals("Select Client")) {
			displayInfoMessageToUser("Please Select Destination Client ",
					"Upload Status");
			handleClient();
			return;
		}

		if (nodes != null && nodes.length > 0) {
			System.out.println("Node length"+nodes.length);
			for (TreeNode node : nodes) {
				/*if(nodes.length>=30){
					displayErrorMessageToUser("Please donot upload more that 30 files at a time.", "UPLOAD STATUS");
					return ;
				}*/
				if (new File(node.getData().toString()).isDirectory() == false) {
					System.out.println("Files are: "
							+ node.getData().toString());

					File filename = new File(node.getData().toString());
					System.out.println("parent file date"
							+ filename.getParentFile());

					try {
						ConnectDB db = new ConnectDB();

						db.initialize();

						List<List<String>> snList = db
								.resultSetToListOfList("SELECT MAX(SN)+1 FROM IMP_FILEMANAGER");
						if (snList.size() > 1) {
							setSn(snList.get(1).get(0));

						}
						if (this.getSn().isEmpty() || this.getSn() == null) {
							setSn("1");
						}
						desPath = filename.getParentFile().toString()
								.replaceAll(AIConstant.EIGER_PATH, "")
								.replaceAll(fromClient, toClient);

						System.out.println("Des path " + desPath);

						String inquery = "INSERT INTO IMP_FILEMANAGER ( SN, FROM_CLIENTID, TO_CLIENTID, UPLOADED_BY, FILE_SOURCE,upload_status,uploaded_date,DESTFILEPATH,filename,source_filepath,SERVERNAME) VALUES("
								+ this.getSn()
								+ ",'"
								+ this.fromClient.replace("'", "''")
								+ "','"
								+ this.toClient.replace("'", "''")
								+ "','"
								+ sessionData.getFullname()
								+ "','eiger','upload in progress',sysdate,'"
								+ AIConstant.AIPFM_FILE_LOCATION
								+ desPath.replaceAll("'", "''")
								+ "/"
								+ "','"
								+ filename.getName().replaceAll("'", "''")
								+ "','"
								+ node.getData().toString()
										.replaceAll("'", "''")
								+ "','"
								+ this.getServer() + "')";
						db.executeDML(inquery);
						db.endConnection();
						try {
							System.out.println("Souce file path"+node.getData().toString());
							System.out.println("Des file path"+AIConstant.AIPFM_FILE_LOCATION+desPath);
							String command="cp -p "+"\""+node.getData().toString()+"\" "+"\""+AIConstant.AIPFM_FILE_LOCATION+desPath+"/\"";
							System.out.println("Command "+command);
							File destFolder = new File(AIConstant.AIPFM_FILE_LOCATION+desPath);
							
							if(!destFolder.exists()){
								destFolder.mkdirs();
								System.out.println(" Folder created "+destFolder);
							}else{
								System.out.println(" Folder Already exist "+destFolder);
							}
							ProcessBuilder processsbuilder = new ProcessBuilder(new String[] { "bash", "-c",
									command });
							
							processsbuilder.redirectErrorStream(true);
							Process process = processsbuilder.start();
							
							 inputStream = process.getInputStream();

							BufferedReader reader = new BufferedReader(new InputStreamReader(
									process.getInputStream()));
							
							while ((line = reader.readLine()) != null) {

								line=null;
							}
							process.waitFor();
							if(process.exitValue()==0){
								
								query = "UPDATE IMP_FILEMANAGER set upload_status='upload completed',uploaded_date=sysdate where sn="
										+ this.getSn() + "";
								ConnectDB exdb = new ConnectDB();
								exdb.initialize();
								exdb.executeDML(query);
								exdb.endConnection();
								commandforEigerFile.append("\""
										+ AIConstant.AIPFM_FILE_LOCATION
										+ desPath
										+ "/"
										+ filename.getName()
										+ "|"
										+ this.getSn()
										+ "|"
										+ this.getToClient().toString()
												.split("\\-")[0].toString().trim()
										+ "\""+"\n");
								
								if (this.importStatus.equals("N")) {
									displayInfoMessageToUser(
											"This client is not migrated to AIP. File(s) uploaded but didn't send for import",
											"Upload and Import Status");
									return;
								} else {
									count++;
									/*displayInfoMessageToUser(filename.getName()
											+ " uploaded and sent for import",
											"Upload and Import Status");*/
									
									/*importUploadedFiles(
											commandforEigerFile.toString(),
											this.getServer());*/
								}
							}else{
								String equery = "UPDATE IMP_FILEMANAGER set upload_status='upload failed',uploaded_date=sysdate where sn="
										+ this.getSn() + "";
								ConnectDB exdb = new ConnectDB();
								exdb.initialize();
								exdb.executeDML(equery);
								exdb.endConnection();
							}
							process.destroy();
							//Runtime.getRuntime().exec(new String[]{"bash", "-c", command});
							
							

							//commandforEigerFile = new StringBuilder();
														
							
						} catch (IllegalThreadStateException e) {
							String equery = "UPDATE IMP_FILEMANAGER set upload_status='upload failed',uploaded_date=sysdate where sn="
									+ this.getSn() + "";
							ConnectDB exdb = new ConnectDB();
							exdb.initialize();
							exdb.executeDML(equery);
							exdb.endConnection();
							displayErrorMessageToUser("File Upload Failed", "Error");
							
						}	


					} catch (Exception e) {
						query = "UPDATE IMP_FILEMANAGER set upload_status='upload failed',uploaded_date=sysdate where sn="
								+ this.getSn() + "";
						displayErrorMessageToUser("Cannot uploaded file "
								+ filename, "Upload Failed");
						ConnectDB db = new ConnectDB();
						db.initialize();
						db.executeDML(query);
						db.endConnection();
						System.out.println(query);
					}
				} else {
					if (new File(node.getData().toString()).isDirectory() == true && nodes.length<2) {
						displayInfoMessageToUser("Folder "
								+ new File(node.getData().toString())
								+ " is empty", "Upload Status");
					}
				}

			}

		} else {
			displayErrorMessageToUser("Please Select File(s)", "Upload Failed");
		}
		
		if(commandforEigerFile.length()!=0){
			File exceptionFileName = new File(
					AIConstant.TEMPORARY_FILE_LOCATION
							+ this.toClient.toString().split("\\-")[0].toString().trim() + "dmfileList"
							+ getFileNamewithtimestamp() + ".txt");
			if (!exceptionFileName.exists()) {
				try {
					exceptionFileName.createNewFile();
					FileWriter fw = new FileWriter(
							exceptionFileName.getAbsoluteFile());
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(commandforEigerFile.toString());
					bw.close();

					runCommand(AIConstant.shFilelocation
							+ "./processAIPFM.sh -l "
							+ exceptionFileName.getAbsolutePath(),
							this.getServer());
					displayInfoMessageToUser(count +" file(s)"
							+ " uploaded and sent for import",
							"Upload and Import Status");
				}catch(Exception e){
					
				}
			}
		}else{
			displayErrorMessageToUser("Folder is Empty", "Folder Empty");
		}
		
		this.setSelecttedNodes(null);
		handleClient();

	}

	public void runCommand(String commmand, String importserver)
					throws InterruptedException {
				
				System.out.println("Command "+commmand);
			
				RunbackgroundExceptionImport obFM = new RunbackgroundExceptionImport();
				obFM.new importexception().init(commmand);
			

				
				
			}

	public void importUploadedFiles(String command, String server)
			throws InterruptedException {
		
		System.out.println("Parameter passed to processAIPFM.sh is:  "
				+ command);

	RunbackgroundExceptionImport obFM = new RunbackgroundExceptionImport();
		obFM.new importexception().init(AIConstant.shFilelocation
				+ "./processAIPFM.sh -s " + command);
		System.out.println("Command "+command);
		

	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}
	private synchronized String getFileNamewithtimestamp() {
		String timeStamp = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"YYYYMMHHmmss.ssssss");
		Calendar calendar = Calendar.getInstance();
		timeStamp = dateFormat.format(calendar.getTimeInMillis());

		return timeStamp;
	}

}
