/* 
 *Class Name : Manager.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.filemanager.model;

import java.io.Serializable;

/**
 * Class for File manager log
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 05 Feb 2015
 */
public class Manager implements Serializable {

	private static final long serialVersionUID = -5408859007155356723L;
	private String fromClient = "";
	private String toClient = "";
	private String filename = "";
	private String serverName = "";
	private String uploadStatus = "";
	private String uploadedDate = "";
	private String uploadedBy = "";
	private String fileID = "";
	private String dmfileID = "";
	private String layoutID = "";
	private String aipStatus = "";
	private String importStatus = "";
	private String dataType = "";
	private String fileSize = "";
	private String fileRecordCount = "";
	private String importRecordCount = "";

	
	
	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getDmfileID() {
		return dmfileID;
	}

	public void setDmfileID(String dmfileID) {
		this.dmfileID = dmfileID;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getAipStatus() {
		return aipStatus;
	}

	public void setAipStatus(String aipStatus) {
		this.aipStatus = aipStatus;
	}

	public String getImportStatus() {
		return importStatus;
	}

	public void setImportStatus(String importStatus) {
		this.importStatus = importStatus;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileRecordCount() {
		return fileRecordCount;
	}

	public void setFileRecordCount(String fileRecordCount) {
		this.fileRecordCount = fileRecordCount;
	}

	public String getImportRecordCount() {
		return importRecordCount;
	}

	public void setImportRecordCount(String importRecordCount) {
		this.importRecordCount = importRecordCount;
	}

	public Manager(String fileName, String fromClient, String toClient,
			String uploadedDate, String uploadStatus, String fileID,
			String dmfileID, String aipStatus, String importStatus,
			String serverName, String layoutID, String dataType,
			String fileSize, String fileRecordcount, String importrecordCount, String uploadedBy) {
		this.filename = fileName;
		this.fromClient = fromClient;
		this.toClient = toClient;
		this.uploadedDate = uploadedDate;
		this.uploadStatus = uploadStatus;
		this.fileID = fileID;
		this.dmfileID = dmfileID;
		this.aipStatus = aipStatus;
		this.importStatus = importStatus;
		this.serverName = serverName;
		this.layoutID = layoutID;
		this.dataType = dataType;
		this.fileSize = fileSize;
		this.fileRecordCount = fileRecordcount;
		this.importRecordCount = importrecordCount;
		this.uploadedBy = uploadedBy;
	}

	public String getFromClient() {
		return fromClient;
	}

	public void setFromClient(String fromClient) {
		this.fromClient = fromClient;
	}

	public String getToClient() {
		return toClient;
	}

	public void setToClient(String toClient) {
		this.toClient = toClient;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getUploadStatus() {
		return uploadStatus;
	}

	public void setUploadStatus(String uploadStatus) {
		this.uploadStatus = uploadStatus;
	}

	public String getUploadedDate() {
		return uploadedDate;
	}

	public void setUploadedDate(String uploadedDate) {
		this.uploadedDate = uploadedDate;
	}
}
