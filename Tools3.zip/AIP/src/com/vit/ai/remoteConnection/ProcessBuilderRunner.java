/* 
 *Class Name : ProcessBuilderRunner.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.remoteConnection;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import org.apache.log4j.Logger;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.constant.AIPasswords;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Class for generating dynamic procedures and providing parameter to generator
 * for generating importscript,attributes,c-attributes
 * 
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.1 05 April 2015
 */
public class ProcessBuilderRunner extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 6004122718406486086L;
	private static Logger log = Logger.getLogger(ProcessBuilderRunner.class
			.getName());

	public static String runAttr(String layoutID) {
		String content = "";
		String path = AIConstant.GENERATOR_PATH + "Generator.jar ";
	
		String OS = System.getProperty("os.name").toLowerCase();
		ProcessBuilder probuilder = null;
//AIPDB/ @(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=npaipracp1)(PORT=1521))(CONNECT_DATA=(SID=VHAIP1)))
		if (OS.indexOf("win") >= 0) {
		String[] command = {
					"java",
					"-jar",
					path,
					"-t",
					"A",
					"-c",
					"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + ")))",
					"-u", AIConstant.DEFAULT_SCHEMA_NAME, "-p",
					AIConstant.DEFAULT_SCHEMA_PASSWORD, "-l", layoutID };
		System.out.println("pass1 "+Arrays.toString(command));
		 probuilder = new ProcessBuilder(command);
			
			
		}
		else
		{
			String commandgen="java -jar "+AIConstant.GENERATOR_PATH+"Generator.jar -t"+
					" A"+
					" -c"+
					" \"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + "))) \""+
					" -u "+ AIConstant.DEFAULT_SCHEMA_NAME + " -p "+ 
					AIConstant.DEFAULT_SCHEMA_PASSWORD +  " -l " +  layoutID;
		
			ArrayList<String> commands=new ArrayList<String>();
			commands.add("/bin/sh");
			commands.add("-c");
			commands.add(commandgen);
		System.out.println("pass2 "+commands.toString());
		 probuilder = new ProcessBuilder(commands);
		}

		probuilder.redirectErrorStream(true);
		try {
			Process p = probuilder.start();

			int erroCode = p.waitFor();
			System.out.println("ERROR CODE : " + erroCode);
			/*if (erroCode != 0) {
				content = "ERROR";
				return content;
			}*/
			System.out.println("PROCESS STARTED");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = in.readLine()) != null) {
				content += line + "\n";
				System.out.println("CONTENTS ATTR : " + content);
			}
			in.close();

			p.destroy();

		} catch (IOException e) {
			log.error("Process Builedr Error : " + e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return content;

	}

	
	public static String runCAttr(String layoutID) {
		String content = "";
		String path = AIConstant.GENERATOR_PATH + "Generator.jar ";
	
		String OS = System.getProperty("os.name").toLowerCase();
		ProcessBuilder probuilder = null;

		if (OS.indexOf("win") >= 0) {
		String[] command = {
					"java",
					"-jar",
					path,
					"-t",
					"C",
					"-c",
					"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + ")))",
					"-u", AIConstant.DEFAULT_SCHEMA_NAME, "-p",
					AIConstant.DEFAULT_SCHEMA_PASSWORD, "-l", layoutID };
		System.out.println("Passs8 "+Arrays.toString(command));
		 probuilder = new ProcessBuilder(command);
			
			
		}
		else
		{
			String commandgen="java -jar "+AIConstant.GENERATOR_PATH+"Generator.jar -t"+
					" C"+
					" -c"+
					" \"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + "))) \""+
					" -u "+ AIConstant.DEFAULT_SCHEMA_NAME + " -p "+ 
					AIConstant.DEFAULT_SCHEMA_PASSWORD +  " -l " +  layoutID;
		
			ArrayList<String> commands=new ArrayList<String>();
			commands.add("/bin/sh");
			commands.add("-c");
			commands.add(commandgen);
		System.out.println("Pass 3"+commands.toString());
		 probuilder = new ProcessBuilder(commands);
		}

		probuilder.redirectErrorStream(true);
		try {
			Process p = probuilder.start();

			int erroCode = p.waitFor();
			System.out.println("ERROR CODE : " + erroCode);
			if (erroCode != 0) {
				content = "ERROR";
				return content;
			}
			System.out.println("PROCESS STARTED");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = in.readLine()) != null) {
				content += line + "\n";
				System.out.println(content);
				
			}
			in.close();

			p.destroy();

		} catch (IOException e) {
			log.error("Process Builedr Error : " + e.getMessage());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return content;

	}
	/*[/bin/sh, -c, java -jar /aipfs/AIP/datadashboard/utilities/Generator.jar -t I -c 
	 "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=nveigerworkq1)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=d2he)(SERVER=DEDICATED))) "
	 -u aipdb -p DD_DP_FLMS -l 43 -i N]
*/
	public static String runImportScript(String layoutID, String test) {
		String content = "";
		System.out.println("runImport Script");
		String path = AIConstant.GENERATOR_PATH + "Generator.jar ";
	
		String OS = System.getProperty("os.name").toLowerCase();
		ProcessBuilder probuilder = null;

		if (OS.indexOf("win") >= 0) {
		String[] command = {
					"java",
					"-jar",
					path,
					"-t",
					"I",
					"-c",
					"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + ")))",
					"-u", AIConstant.DEFAULT_SCHEMA_NAME, "-p",
					AIConstant.DEFAULT_SCHEMA_PASSWORD, "-l",layoutID,"-i",test };
		System.out.println("Pass4 "+Arrays.toString(command));
		 probuilder = new ProcessBuilder(command);
			
			
		}
		else
		{
			String commandgen="java -jar "+AIConstant.GENERATOR_PATH+"Generator.jar -t"+
					" I"+
					" -c "+
					" \"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + "))) \""+
					" -u "+ AIConstant.DEFAULT_SCHEMA_NAME + " -p "+ 
					AIConstant.DEFAULT_SCHEMA_PASSWORD +  " -l " +  layoutID + " -i " + test;
		
			ArrayList<String> commands=new ArrayList<String>();
			commands.add("/bin/sh");
			commands.add("-c");
			commands.add(commandgen);
		System.out.println("pass5 "+commands.toString());
		 probuilder = new ProcessBuilder(commands);
		}

		probuilder.redirectErrorStream(true);
		try {
			Process p = probuilder.start();
			System.out.println("  PROCESS STARTED");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = in.readLine()) != null) {
				content += line + "\n";
			
			}
			in.close();

			p.destroy();

		} catch (IOException e) {
			log.error("Process Builedr Error : " + e.getMessage());
		}
		return content;

	}

	public static String runImportScriptForTest(String layoutID, String test) {
		
		AIPasswords passwordobj=new AIPasswords();
		passwordobj.init();
		String password=passwordobj.getPassword(AIConstant.TEST_SCHEMA_NAME);
		passwordobj.close();
		String content = "";
		String path = AIConstant.GENERATOR_PATH + "Generator.jar ";
	
		String OS = System.getProperty("os.name").toLowerCase();
		ProcessBuilder probuilder = null;

		if (OS.indexOf("win") >= 0) {
		String[] command = {
					"java",
					"-jar",
					path,
					"-t",
					"I",
					"-c",
					"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + ")))",
					"-u", AIConstant.TEST_SCHEMA_NAME, "-p",
					password, "-l",layoutID,"-i",test };
		System.out.println("Pass7 "+Arrays.toString(command));
		 probuilder = new ProcessBuilder(command);
			
			
		}
		else
		{
			String commandgen="java -jar "+AIConstant.GENERATOR_PATH+"Generator.jar -t"+
					" I"+
					" -c "+
					" \"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + "))) \""+
					" -u "+ AIConstant.TEST_SCHEMA_NAME + " -p "+ 
					password +  " -l " +  layoutID + "- i " + test;
		
			ArrayList<String> commands=new ArrayList<String>();
			commands.add("/bin/sh");
			commands.add("-c");
			commands.add(commandgen);
		System.out.println("Pass6 "+commands.toString());
		 probuilder = new ProcessBuilder(commands);
		}

		probuilder.redirectErrorStream(true);
		try {
			Process p = probuilder.start();

			System.out.println("PROCESS STARTED");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = in.readLine()) != null) {
				content += line + "\n";
		
			}
			in.close();

			p.destroy();

		} catch (IOException e) {
			log.error("Process Builedr Error : " + e.getMessage());
		}
		return content;

	}
	
	public static void runBulkToHIReconjar(String clientId, String reportId, String reportLocation, String  jarLocation, 
			String startDate, String endDate) {
		AIPasswords passwordobj=new AIPasswords();
		passwordobj.init();
		String password=passwordobj.getPassword(AIConstant.TEST_SCHEMA_NAME);
		passwordobj.close();
		String content = "";
		//String path = AIConstant.BULK_RECON_REPORT_PATH + "BulkReconReport.jar ";
		String path = jarLocation;
		String OS = System.getProperty("os.name").toLowerCase();
		ProcessBuilder probuilder = null;
		
		if (OS.indexOf("win") >= 0) {
			String[] command = {
						"java",
						"-jar",
						path,
						"-c",
						AIConstant.RAC_SERVER_NAME + ":" + AIConstant.RAC_SERVICE_PORT + ":" + AIConstant.RAC_SERVICE_SID,
						"-u",
						AIConstant.DEFAULT_SCHEMA_NAME,
						"-p",
						AIConstant.DEFAULT_SCHEMA_PASSWORD,
						"-l",
						reportLocation,
						"-s",
						startDate,
						"-e",
						endDate,
						"-i",
						reportId,
						"-k",
						clientId};
			
			System.out.println("Pass in Windows: "+Arrays.toString(command));
			probuilder = new ProcessBuilder(command);
		}
		else
		{
			String commandgen="java -jar " + path +
					" -c "+
					" \"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
							+ AIConstant.RAC_SERVER_NAME + ")(PORT="
							+ AIConstant.RAC_SERVICE_PORT
							+ "))(CONNECT_DATA=(SID="
							+ AIConstant.RAC_SERVICE_SID + "))) \""+
					" -u "+ AIConstant.DEFAULT_SCHEMA_NAME + " -p "+ 
					AIConstant.DEFAULT_SCHEMA_PASSWORD +  
					" -l " + 
					reportLocation +
					" -s '" +
					startDate +
					"' -e '" +
					endDate +
					"' -i " +
					reportId +
					" -k " +
					clientId;
		
			ArrayList<String> commands=new ArrayList<String>();
			commands.add("/bin/sh");
			commands.add("-c");
			commands.add(commandgen);
			System.out.println("Pass in Linux: "+ commandgen);
			probuilder = new ProcessBuilder(commands);
		}

		probuilder.redirectErrorStream(true);
		try {
			Process p = probuilder.start();

			System.out.println("PROCESS FOR BULK TO HI RECON STARTED");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = in.readLine()) != null) {
				content += line + "\n";
			}
			in.close();
			p.destroy();
		} catch (IOException e) {
			log.error("Process Builder Error : " + e.getMessage());
		}
	}
	
	public static void generateSQLScript(String pname, String scriptLocation,
			String contents) {

		/* COPYING THE IMPORT SCRIPT INTO TEMPORARY LOCATION */

		File file = new File(scriptLocation + pname + ".sql");
		FileWriter fw = null;

		if (!file.exists()) {
			try {
				file.createNewFile();

			} catch (IOException e) {
				log.error("Error copyig import script: " + e.getMessage());

			}
		}

		try {
			fw = new FileWriter(file);

		} catch (IOException e1) {
			log.error("File Writer Error! compileProcedure: " + e1.getMessage());

		}

		
		BufferedWriter bw = new BufferedWriter(fw);
		
		

		String content = "PROMPT COMPILING IMPORT PROCEDURE " + pname + "\n"
				 + contents;

		if (!content.substring(content.trim().length() - 1).equals("/")) {
			content = content + "\n/";
		}
		try {
			bw.write(content.trim());
			bw.newLine();
		} catch (IOException e) {
			log.error("Can't write to file: " + e.getMessage());

		}

		try {
			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e1) {
			log.error("bw closing Error " + e1.getMessage());

		}

	}

	public static void generateSQLScripttosave(String pname,
			String scriptLocation, String contents) {
		File file = new File(scriptLocation + "IP_" + pname + ".sql");
		FileWriter fw = null;

		if (!file.exists()) {
			try {
				file.createNewFile();

			} catch (IOException e) {

				log.error("File Creating Error! compileProcedure"
						+ e.getMessage());

			}
		}

		try {
			fw = new FileWriter(file.getAbsoluteFile());
		} catch (IOException e1) {
			log.error("File Writer Error! compileProcedure" + e1.getMessage());

		}

		BufferedWriter bw = new BufferedWriter(fw);

		String content = "PROMPT COMPILING IMPORT PROCEDURE " + pname + "\n"
				+ contents;
		if (!content.substring(content.trim().length() - 1).equals("/")) {
			content = content + "\n/";
		}
		try {
			bw.write(content.trim());
			bw.newLine();
		} catch (IOException e) {
			log.error("File Writer Error! compileProcedure" + e.getMessage());

		}

		try {
			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e1) {
			log.error("bw closing Error! compileProcedure" + e1.getMessage());

		}

	}

	public static void CompileProcedure(String schemaName, String pwd,
			String server, String port, String sid, String dfilename) {

		String message = "";
		String cmd = ("sqlplus -S " + schemaName + "/" + pwd
				+ "@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=" + server
				+ ")(PORT=" + port + "))(CONNECT_DATA=(SID="
				+ sid + "))) @" + dfilename);
		System.out.println("-COMMAND FOR SQLPLUS-" + cmd);

		try {
			Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			while ((in.readLine()) != null) {

				message = in.readLine();
			}
			System.out.println("MESSAGE FROM COMPILE: " + message);
			in.close();
			p.destroy();

		} catch (IOException e) {

			log.error("Compiling import procedures" + e.getMessage());
		} finally {

		}

	}

	public static void executeProcedure(String pname, String schemaName,
			String pwd, String server, String port, String sid,
			String contents, String pathExecScript) {

		log.info("--EXECUTING PROCEDURE---");
		String dfilename = pathExecScript + pname + "_log.sql";
		log.info("Execution Script : " + dfilename);

		File file = new File(dfilename);
		FileWriter fw = null;

		if (!file.exists()) {
			try {
				file.createNewFile();

			} catch (IOException e) {
				log.error("Failed to create file " + e.getMessage());

			}
		}

		try {
			fw = new FileWriter(file.getAbsoluteFile());
		} catch (IOException e1) {
			log.error(" File writer Error " + e1.getMessage());

		}

		BufferedWriter bw = new BufferedWriter(fw);

		String content = "PROMPT EXECUTING IMPORT PROCEDURE " + pname + "\n"
				+ "SET DEFINE OFF" + "\n" + contents;
		if (!content.substring(content.trim().length() - 1).equals("/")) {
			content = content + "\n/";
		}
		try {
			bw.write(content.trim());
			bw.newLine();
		} catch (IOException e) {
			log.error(" File writer Error " + e.getMessage());

		}

		try {
			bw.newLine();
			bw.write("EXIT");
			bw.newLine();
			bw.write("/");
			bw.newLine();

			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e1) {
			log.error(" File closing Error " + e1.getMessage());

		}

		String cmd = ("sqlplus -S " + schemaName + "/" + pwd
				+ "@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=" + server
				+ ")(PORT=" + port + "))(CONNECT_DATA=(SID="
				+ sid + "))) @" + dfilename);

		log.info("Execution sql command : " + cmd);
		try {
			Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			while ((in.readLine()) != null) {

				System.out.println("MESSAGE ON EXECUTION : " + in.readLine());
			}

			in.close();
			p.destroy();

		} catch (IOException e) {
			log.error(e.getMessage());
		} finally {

			System.out.println("--DELETING LOG---");
			file.delete();
		}

	}

	public static void dropTableandProcedure(String procedurename,
			String tablename) {
		ConnectDB db = new ConnectDB();
		db.initializeTestSchema();
		db.executeDML("DROP TABLE " + tablename + " PURGE");
		db.executeDML("DROP PROCEDURE " + procedurename);
		db.endConnection();
	}

	public static void generateAllScripts(String scriptLocation, String Payor,
			String filename) {

		CustomUtility objCu = new CustomUtility();
		List<List<String>> layoutList = objCu.getAllLayoutIDByPayor(Payor);

		String temp_location = scriptLocation + Payor + "/";
		FileController objFC = new FileController();
		File zipPath = new File(temp_location);
		objFC.delete(zipPath);

		zipPath.mkdir();

		String importScript;
		if (layoutList.size() > 0) {
			for (int i = 1; i < layoutList.size(); i++) {
				importScript = runImportScript(layoutList.get(i).get(0), "N");
				generateSQLScript("IP_" + layoutList.get(i).get(0),
						temp_location, importScript);
			}
			createZip(temp_location, scriptLocation + filename);
		}
	}

	public static void createZip(String filePath, String zipPath) {

		try {
			ArrayList<File> listOfFiles = new ArrayList<File>();
			File[] files = new File(filePath).listFiles();

			for (File file : files) {
				listOfFiles.add(file);
			}
			ZipFile zipFile = new ZipFile(zipPath);
			ZipParameters parameters = new ZipParameters();
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			zipFile.addFiles(listOfFiles, parameters);

		} catch (ZipException e) {
			log.error("Zip Error:" + e.getMessage());

		}
		System.gc();
	}

	public static void generateAttributes(String pname, String scriptLocation,
			String contents) {
		File file = new File(scriptLocation + pname + ".attr");
		FileWriter fw = null;

		if (!file.exists()) {
			try {
				file.createNewFile();

			} catch (IOException e) {
				log.error(e.getMessage()
						+ " File Creating Error! compileProcedure");

			}
		}

		try {
			fw = new FileWriter(file.getAbsoluteFile());
		} catch (IOException e1) {
			System.out.println(e1.getMessage()
					+ " File Writer Error! compileProcedure");
		}

		BufferedWriter bw = new BufferedWriter(fw);

		String content = contents;

		try {
			bw.write(content.trim());
			bw.newLine();
		} catch (IOException e) {
			log.error(e.getMessage() + " File Write Error! compileProcedure");

		}

		try {
			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e1) {
			log.error(e1.getMessage() + " bw Closing Error!");

		}

	}

	public static void generateAllCAttribute(String attributeLocation,
			String payer, String filename) {

		CustomUtility objCu = new CustomUtility();
		List<List<String>> layoutList = objCu.getAllLayoutIDforCAtt(payer);

		String temp_location = attributeLocation + payer + "/";
		FileController objFC = new FileController();
		File zipPath = new File(temp_location);
		objFC.delete(zipPath);

		zipPath.mkdir();

		String attribute;
		if (layoutList.size() > 0) {
			for (int i = 1; i < layoutList.size(); i++) {

				attribute = runCAttr(layoutList.get(i).get(0));

				generateAttributes(layoutList.get(i).get(0), temp_location,
						attribute);
			}
			createZip(temp_location, attributeLocation + filename);
		}

	}

}
