/* 
 *Class Name : ExecuteUsingSQLPLUS.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.remoteConnection;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.utils.AbstractController;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 29 Dec 2014
 *
 */
public class ExecuteUsingSQLPLUS extends AbstractController implements
		Runnable, Serializable {

	private static final long serialVersionUID = -7584440576351278339L;

	private String log_path = AIConstant.EXECUTION_LOG_PATH;

	private static final Logger logger = LoggerFactory
			.getLogger(ExecuteUsingSQLPLUS.class);

	private String what;
	private String server;
	private String content;
	private String schemaName;
	private String pwd;
	private String sid;
	private String port;

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public ExecuteUsingSQLPLUS() {
	}

	public ExecuteUsingSQLPLUS(String what, String content) {
		this.setContent(content);
		this.setWhat(what);
		this.setServer(AIConstant.RAC_SERVER_NAME);
		this.setSchemaName(AIConstant.DEFAULT_SCHEMA_NAME);
		this.setPwd(AIConstant.DEFAULT_SCHEMA_PASSWORD);
		this.setSid(AIConstant.RAC_SERVICE_SID);
		this.setPort(AIConstant.RAC_SERVICE_PORT);
	}

	public ExecuteUsingSQLPLUS(String what, String server, String content,
			String schemaName, String pwd, String sid, String port) {
		super();
		this.what = what;
		this.server = server;
		this.content = content;
		this.schemaName = schemaName;
		this.pwd = pwd;
		this.sid = sid;
		this.port = port;
	}

	public String getWhat() {
		return what;
	}

	public void setWhat(String what) {
		this.what = what;
	}

	public String getServer() {
		return server;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void run() {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
		String dump_filename = what + "_"
				+ dateFormat.format(Calendar.getInstance().getTime());

		// long dump_filename= System.currentTimeMillis();
		File file = new File(log_path + dump_filename + ".sql");
		File file_log = new File(log_path + dump_filename + "_log.txt");
		FileWriter fw = null;
		FileWriter fw_log = null;

		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				logger.error(e.getMessage() + " File Creating Error");
				displayErrorMessageToUser(e.toString(), "ERROR");
			}
		}

		if (!file_log.exists()) {
			try {
				file_log.createNewFile();

			} catch (IOException e) {
				logger.error(e.getMessage() + " Log File Creating Error");
				displayErrorMessageToUser(e.toString(), "ERROR");
			}
		}

		try {
			fw = new FileWriter(file.getAbsoluteFile());
			fw_log = new FileWriter(file_log.getAbsoluteFile());
		} catch (IOException e1) {
			logger.error(e1.getMessage() + " File Writer Error");
			displayErrorMessageToUser(e1.toString(), "ERROR");
		}

		BufferedWriter bw = new BufferedWriter(fw);
		BufferedWriter bw_log = new BufferedWriter(fw_log);

		content = content + "\n";

		try {
			bw.write(content.trim());
			bw.newLine();
		} catch (IOException e) {
			logger.error(e.getMessage() + " File Write Error");
			displayErrorMessageToUser(e.toString(), "ERROR");
		}

		try {
			bw.newLine();
			bw.write("EXIT");
			bw.newLine();
			bw.write("/");

			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e1) {
			logger.error(e1.getMessage() + " bw Closing Error!");
			displayErrorMessageToUser(e1.toString(), "ERROR");
		}
		String dfilename = log_path + dump_filename + ".sql";
		logger.info("Execution of " + what + " starts --" + dump_filename);
		String cmd = ("sqlplus -S " + this.getSchemaName() + "/"
				+ this.getPwd() + "@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
				+ this.getServer() + ")(PORT=" + this.getPort()
				+ "))(CONNECT_DATA=(SID=" + this.getSid()
				+ "))) @" + dfilename);
		
		System.out.println("COMMAND FOR MDR : " + cmd);

		try {
			Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					p.getInputStream()));
			String line = null;
			while ((line = in.readLine()) != null) {
				
				System.out.println("MDR : " + line);
				bw_log.write(line);
				bw_log.newLine();
			}

			in.close();
			p.destroy();

			bw_log.flush();
			fw_log.flush();
			bw_log.close();

			fw_log.close();
		} catch (IOException e) {
			logger.error(e.getMessage() + " Execution Error!");
			// displayErrorMessageToUser(e.toString(), "ERROR");
		} finally {
			logger.info("Execution of " + what + " ends --" + dump_filename);

		}

	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

}
