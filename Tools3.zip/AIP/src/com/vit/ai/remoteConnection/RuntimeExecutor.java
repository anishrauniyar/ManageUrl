/* 
 *Class Name : RemoteTerminal.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.remoteConnection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;

import org.apache.log4j.Logger;

import com.jcraft.jsch.UserInfo;
import com.vit.ai.utils.AbstractController;

/**
 * Class for executing remote terminal command
 * 
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @version 1.4 04 April 2015
 */
public class RuntimeExecutor extends AbstractController implements Serializable {

	private static final long serialVersionUID = -1061995920486566049L;

	private static Logger log = Logger.getLogger(RuntimeExecutor.class
			.getName());
	String Host = "";
	Process process;
	ProcessBuilder processsbuilder = null;

	public RuntimeExecutor(String server) {
		
		this.Host = server;

	}

	public RuntimeExecutor() {
	}

	/**
	 * Function for executing remote command and waiting for channel status
	 * 
	 * @param _cmd
	 *            command to execute
	 */

	public String runCommand(String _cmd) {

		String CommandLineOutput = "";
		String CommandForSQLPlusImport = _cmd;
		InputStream inputStream = null;
		try {
			processsbuilder = new ProcessBuilder(new String[] { "bash", "-c",
					CommandForSQLPlusImport });
			/*
			 * process = Runtime.getRuntime().exec( new String[] { "bash", "-c",
			 * CommandForSQLPlusImport });
			 */
			processsbuilder.redirectErrorStream(true);
			process = processsbuilder.start();
			inputStream = process.getInputStream();
			String line="";
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			while ((line = reader.readLine()) != null) {
				if(line.contains("GETFILESTATSPATH")){
					CommandLineOutput+=line+"^";
				}
				if(line.contains("FLID")){
					CommandLineOutput+=line+"\n";
					
				}
			}
			
			try {
				process.waitFor();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(!CommandLineOutput.contains("FLID")){
				CommandLineOutput = CommandLineOutput+String.valueOf(process.exitValue());	
			}else{
				CommandLineOutput=CommandLineOutput+"~"+String.valueOf(process.exitValue());
			}
			System.out.println("Commmandlineoutput"+CommandLineOutput);

		} catch (IOException ex) {
			System.out.println(ex.getMessage() + " 2.RunCommand  " + this.Host);
			displayErrorMessageToUser(ex.toString(), "ERROR");
			return "notconnected";
		}

		finally {
			try {

				inputStream.close();

			} catch (IOException ex) {
				System.out.println(ex.getMessage() + " 4.RunCommand "
						+ this.Host);
				displayErrorMessageToUser(ex.toString(), "ERROR");
				return "notconnected";
			}
		}

		return CommandLineOutput;
	}

	/**
	 * Function for executing simple remote command
	 * 
	 * @param _cmd
	 *            Command to execute
	 */
	public String runSimpleCommand(String _cmd) {

		String line = "";
		String CommandLineOutput = "";
		String CommandForSQLPlusImport = _cmd;
		/* Get the stream from the Shell */
		InputStream inputStream = null;

		try {
			processsbuilder = new ProcessBuilder(new String[] { "bash", "-c",
					CommandForSQLPlusImport });
			/*
			 * process = Runtime.getRuntime().exec( new String[] { "bash", "-c",
			 * CommandForSQLPlusImport });
			 */
			processsbuilder.redirectErrorStream(true);
			process = processsbuilder.start();
			inputStream = process.getInputStream();

			BufferedReader reader = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			while ((line = reader.readLine()) != null) {

				CommandLineOutput += line + "\n";
			}

		} catch (IOException ex) {
			System.out.println(ex.getMessage() + " 2.RunCommand  " + this.Host);
			displayErrorMessageToUser(ex.toString(), "ERROR");
			return "notconnected";
		}

		finally {
			try {

				if (inputStream != null) {
					inputStream.close();
				}

			} catch (IOException ex) {
				System.out.println(ex.getMessage() + " 4.RunCommand "
						+ this.Host);
				displayErrorMessageToUser(ex.toString(), "ERROR");
				return "notconnected";
			}
		}

		return CommandLineOutput;
	}

	public void endProcess() {
		log.info("Destroying Process");
		this.process.destroy();

	}

	public static class MyUserInfo implements UserInfo {

		String pass = "";
		Boolean isPwdSet = true;

		public MyUserInfo(String _pass) {
			this.pass = _pass;
		}

		public String getPassphrase() {
			return null;
		}

		public String getPassword() {
			return this.pass;
		}

		public boolean promptPassword(String arg0) {
			return true;
		}

		public boolean promptPassphrase(String arg0) {
			return true;
		}

		public boolean promptYesNo(String arg0) {
			return true;
		}

		public void showMessage(String arg0) {
		}
	}

	/**
	 * Function to download file
	 * 
	 * @param fileName
	 *            Download file from temp folder and display into the browser
	 */

	public String runeigerCommand(String _cmd) {

		String CommandLineOutput = "";

		String linuxCommand = _cmd;
		String line = "";

		/* Get the stream from the Shell */
		InputStream inputStream = null;

		try {

			System.out.println("Command " + linuxCommand);
			processsbuilder = new ProcessBuilder(new String[] { "bash", "-c",
					linuxCommand });
			processsbuilder.redirectErrorStream(true);
			process = processsbuilder.start();
			/*
			 * process = Runtime.getRuntime().exec( new String[] { "bash", "-c",
			 * linuxCommand });
			 */
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					process.getInputStream()));
			while ((line = reader.readLine()) != null) {
				CommandLineOutput += line;
				CommandLineOutput += "++";

			}

		} catch (IOException ex) {
			System.out.println(ex.getMessage() + " 2.RunCommand  " + this.Host);
			displayErrorMessageToUser(ex.toString(), "ERROR");
			return "notconnected";
		}

		finally {
			try {

				if (inputStream != null) {
					inputStream.close();
				}

			} catch (IOException ex) {
				System.out.println(ex.getMessage() + " 4.RunCommand "
						+ this.Host);
				displayErrorMessageToUser(ex.toString(), "ERROR");
				return "notconnected";
			}
		}

		return CommandLineOutput;
	}

}
