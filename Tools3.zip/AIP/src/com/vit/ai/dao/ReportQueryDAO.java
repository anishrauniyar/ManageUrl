/* 
 *Class Name : ReportQueryDAO.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.poireport.model.RCell;
import com.vit.ai.poireport.model.RCustomStyle;
import com.vit.ai.poireport.model.RDataTable;
import com.vit.ai.poireport.model.RRow;
import com.vit.ai.utils.ReportUtility;

/**
 * @author Sagar Shrestha
 * 
 * @version 1.0 30 Feb 2014
 */
public class ReportQueryDAO implements Serializable {

	private static final long serialVersionUID = 1L;
	List<Integer> indexTosetPercentage = new ArrayList<Integer>();
	List<Integer> indexToDoller = new ArrayList<Integer>();
	List<Integer> indexToNumber = new ArrayList<Integer>();

	Map<Integer, String> mapToStoreOverriddenStyle = new HashMap<Integer, String>();

	Map<Integer, String> mapToStoreFormula = new HashMap<Integer, String>();
	ReportUtility reportUtility;
	private String schemaName="";

	private static final Logger logger = LoggerFactory
			.getLogger(ReportQueryDAO.class);

	public ReportQueryDAO() {

	}

	public ReportQueryDAO(ReportUtility reportUtility) {
		this.reportUtility = reportUtility;

	}

	private void init(RDataTable dataTable) {

		if (dataTable.isEnableDefaultStyles()) {
			doInitilizeForDefaultStyle(
					dataTable.getHeaderRows()
							.get(dataTable.getHeaderRows().size() - 1)
							.getCells(), dataTable.getMonthsHeader(),
					dataTable.getStyleUsingHeader());
		}

		if (dataTable.isEnableOverriddenStyles()) {
			doInitilizeToOverrideStyle(dataTable.getCustomStyles());
		}

		if (dataTable.isEnableColumnFormula()) {
			doInitilizeForFormula(dataTable.getFormulaForColumns());
		}

	}

	public void doInitilizeForDefaultStyle(List<RCell> cells,
			String monthsHeader[][], String styleFilter) {

		for (int i = 0; cells != null && i < cells.size(); i++) {
			RCell cell = (RCell) cells.get(i);
			String test = (String) cell.getCellValue();

			for (String s : AIConstant.HEADER_CONSTANT_FOR_PERCENTAGE) {
				if (test.toUpperCase().contains(s)) {
					if (!indexTosetPercentage.contains(i + 1)) {
						indexTosetPercentage.add(i + 1);
					}
					break;
				}
			}

			for (String s1 : AIConstant.HEADER_CONSTANT_FOR_DOLLER) {
				if (test.toUpperCase().contains(s1)) {
					if (!indexToDoller.contains(i + 1)
							&& !indexTosetPercentage.contains(i + 1)) {
						indexToDoller.add(i + 1);
					}
					break;
				}
			}

			if (monthsHeader != null) {
				if (styleFilter.equalsIgnoreCase("DOLLAR")) {
					for (String s1 : monthsHeader[0]) {
						if (test.toUpperCase().contains(s1)) {
							if (!indexToDoller.contains(i + 1)
									&& !indexTosetPercentage.contains(i + 1)) {
								indexToDoller.add(i + 1);
							}
							break;
						}
					}
				} else {
					for (String s2 : monthsHeader[0]) {
						if (test.toUpperCase().contains(s2)) {
							if (!indexToDoller.contains(i + 1)
									&& !indexTosetPercentage.contains(i + 1)
									&& !indexToNumber.contains(i + 1)) {
								indexToNumber.add(i + 1);
							}
							break;
						}
					}
				}
			}

			for (String s2 : AIConstant.HEADER_CONSTANT_FOR_INTEGER) {
				if (test.toUpperCase().contains(s2)) {
					if (!indexToDoller.contains(i + 1)
							&& !indexTosetPercentage.contains(i + 1)
							&& !indexToNumber.contains(i + 1)) {
						indexToNumber.add(i + 1);
					}
					break;
				}
			}

		}

	}

	public void doInitilizeToOverrideStyle(String[] styleToOverride) {
		for (String s : styleToOverride) {
			String[] s1 = s.split(":");
			mapToStoreOverriddenStyle.put(Integer.parseInt(s1[0]), s1[1]);

		}

	}

	public void doInitilizeForFormula(String[] cellFormula) {
		for (String s : cellFormula) {
			String[] s1 = s.split("<Formula>");

			mapToStoreFormula.put(Integer.parseInt(s1[0]), s1[1]);

		}
	}

	public RCustomStyle getOverridenStye(int index) {
		RCustomStyle customStyle = new RCustomStyle();
		if (!mapToStoreOverriddenStyle.containsKey(index)) {
			customStyle.setCellStyle(reportUtility.getStyle().get(
					"normal_style"));
			return customStyle;
		}
		customStyle.setCellStyle(reportUtility.getStyle().get(
				mapToStoreOverriddenStyle.get(index)));
		return customStyle;

	}

	private RCustomStyle getDefaultCellStyle(int index) {
		RCustomStyle customStyle = new RCustomStyle();

		if (indexTosetPercentage.contains(index)) {
			customStyle.setCellStyle(reportUtility.getStyle().get(
					"percentage_style"));
			return customStyle;
		} else if (indexToDoller.contains(index)) {
			customStyle.setCellStyle(reportUtility.getStyle().get(
					"dollar_style"));
			return customStyle;
		}

		else if (indexToNumber.contains(index)) {
			customStyle.setCellStyle(reportUtility.getStyle().get(
					"integer_style"));
			return customStyle;
		}
		customStyle.setCellStyle(reportUtility.getStyle().get("normal_style"));

		return customStyle;
	}

	public String getFormula(int index) {

		String test = (String) mapToStoreFormula.get(index);
		if (test != null) {
			return test;
		} else {
			return "NOTFOUND";
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getData(String query) {
		
		ResultSet rs = null;
		Statement stmt = null;
		List rows = new ArrayList();
		try {
			System.out.println("Schema name to get query "+schemaName);
			if(schemaName.compareTo("tempimport")==0){
				stmt = this.reportUtility.getDb().getConnection(AIConstant.RAC_SERVER_NAME,
				AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID,
				AIConstant.TEST_SCHEMA_NAME, "LOCAL").createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			}else{
				stmt = this.reportUtility
						.getDb()
						.getConn()
						.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
								ResultSet.CONCUR_READ_ONLY);
			}
			
			rs = stmt.executeQuery(query);
			ResultSetMetaData metaData = rs.getMetaData();

			int columns = metaData.getColumnCount();

			while (rs.next()) {
				List<RCell> cells = new ArrayList<RCell>();
				for (int i = 0; i < columns; i++) {

					RCell cell = new RCell();
					cell.setCellValue(getExtractor(rs,
							metaData.getColumnType(i), i));
					cell.setCustomStyle(getCellStyle(i,
							getExtractor(rs, metaData.getColumnType(i), i)));

					cells.add(cell);
				}
				RRow row = new RRow();
				row.setCells(cells);
				rows.add(row);
			}

			rs.close();
			stmt.close();
		} catch (Exception e) {
			logger.info(" getting query() +############ Error while running this query ##################");
			logger.info(query);
			logger.error(e.getMessage());
		}
		return rows;

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getData(RDataTable dataTable) {
		// logger.info(dataTable.getQuerytoGetData());
		init(dataTable);
		ResultSet rs = null;
		Statement stmt = null;
		schemaName=dataTable.getSchemaName();
		List rows = new ArrayList();
		try {
			System.out.println("Schema name to get data "+schemaName);
			if(schemaName.compareTo("tempimport")==0){
				stmt = this.reportUtility.getDb().getConnection(AIConstant.RAC_SERVER_NAME,
				AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID,
				AIConstant.TEST_SCHEMA_NAME, "LOCAL").createStatement();
			}else{
				stmt = this.reportUtility.getDb().getConn().createStatement();
			}
			
			rs = stmt.executeQuery(dataTable.getQuerytoGetData());

			ResultSetMetaData metaData = rs.getMetaData();

			int columns = metaData.getColumnCount();
			RCustomStyle[] style = new RCustomStyle[columns + 1];

			/**
			 * Getting styles of every column Assumption is Excel styles applied
			 * column basis Not with every cell independently
			 */
			for (int i = 1; i <= columns; i++) {
				style[i] = getCellStyle(i, dataTable);
			}

			/**
			 * Getting formula for every column Assumption is Excel styles
			 * applied column basis
			 * 
			 */
			String[] formula = null;
			if (dataTable.isEnableColumnFormula()) {
				formula = new String[columns + 1];
				for (int i = 1; i <= columns; i++) {
					formula[i] = getFormula(i);
				}
			}

			while (rs.next()) {
				List<RCell> cells = new ArrayList<RCell>();
				for (int i = 1; i <= columns; i++) {
					RCell cell = new RCell();

					cell.setCellValue(rs.getString(i));

					// cell.setCellValue(getExtractor(rs,
					// metaData.getColumnType(i),
					// i));
					cell.setCustomStyle(style[i]);

					if (dataTable.isEnableColumnFormula()
							&& !formula[i].equals("NOTFOUND")) {
						cell.setFormula(formula[i]);
					}

					cells.add(cell);
				}
				RRow row = new RRow();
				row.setCells(cells);
				rows.add(row);
			}

			rs.close();
			stmt.close();
		} catch (Exception e) {
			logger.info("getting Datatable ############ Error while running this query ##################");
			logger.info(dataTable.getQuerytoGetData());
			logger.error(e.getMessage());
		}
		return rows;

	}

	public RCustomStyle getCellStyle(int index, RDataTable dataTable) {
		if (dataTable.isEnableDefaultStyles()) {
			return getDefaultCellStyle(index);
		} else if (dataTable.isEnableOverriddenStyles()) {
			return getOverridenStye(index);
		}
		RCustomStyle customStyle = new RCustomStyle();
		customStyle.setCellStyle(reportUtility.getStyle().get("normal_style"));
		return customStyle;
	}

	public Object getExtractor(ResultSet rs, int type, int index)
			throws SQLException {
		if (type == Types.VARCHAR || type == Types.CHAR) {
			return rs.getString(index);
		} else if (type == Types.DATE) {
			return rs.getDate(index);
		} else {
			return rs.getDouble(index);
		}
	}

	public RCustomStyle getCellStyle(int cellIndex, Object value) {

		RCustomStyle customStyle = new RCustomStyle();
		customStyle.setCellStyle(reportUtility.getStyle().get("dollar_style"));
		return customStyle;

	}

}
