/* 
 *Class Name : ConnecttoSVN.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.svnconnection;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;

import org.apache.log4j.Logger;
import org.tmatesoft.svn.core.SVNCommitInfo;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNNodeKind;
import org.tmatesoft.svn.core.SVNURL;
import org.tmatesoft.svn.core.auth.ISVNAuthenticationManager;
import org.tmatesoft.svn.core.internal.io.dav.DAVRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.fs.FSRepositoryFactory;
import org.tmatesoft.svn.core.internal.io.svn.SVNRepositoryFactoryImpl;
import org.tmatesoft.svn.core.io.ISVNEditor;
import org.tmatesoft.svn.core.io.SVNRepository;
import org.tmatesoft.svn.core.io.SVNRepositoryFactory;
import org.tmatesoft.svn.core.io.diff.SVNDeltaGenerator;
import org.tmatesoft.svn.core.wc.SVNWCUtil;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.constant.AIPasswords;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to manage script and file into the svn
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 01 Dec 2014
 */
@ManagedBean
@RequestScoped
public class ConnecttoSVN extends AbstractController implements Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(ConnecttoSVN.class.getName());
	private String SVN_DEPOSIT_URL = AIConstant.SVNDepositURL;
	private String SVN_BASE_URL = AIConstant.SVNBASE_LOCATION;
	private SVNRepository repository;
	private String SVN_USERNAME = AIConstant.SVN_USERNAME;
	private String SVN_PASSWORD ;
	private SVNRepository repos;
	private String FMDR_PATH_SVN = AIConstant.SVNFMDR_PATH;
	private String FSR_PATH_SVN = AIConstant.SVNFSR_PATH;

	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public SVNRepository getRepository() {
		return repository;
	}

	public void setRepository(SVNRepository repository) {
		this.repository = repository;
	}

	public String getSVN_BASE_URL() {
		return SVN_BASE_URL;
	}

	public void setSVN_BASE_URL(String sVN_BASE_URL) {
		SVN_BASE_URL = sVN_BASE_URL;
	}

	public String getFMDR_PATH_SVN() {
		return FMDR_PATH_SVN;
	}

	public void setFMDR_PATH_SVN(String fMDR_PATH_SVN) {
		FMDR_PATH_SVN = fMDR_PATH_SVN;
	}

	public String getFSR_PATH_SVN() {
		return FSR_PATH_SVN;
	}

	public void setFSR_PATH_SVN(String fSR_PATH_SVN) {
		FSR_PATH_SVN = fSR_PATH_SVN;
	}

	public void init() {
		DAVRepositoryFactory.setup();
		FSRepositoryFactory.setup();
		SVNRepositoryFactoryImpl.setup();

	}

	public String getSVN_DEPOSIT_URL() {
		return SVN_DEPOSIT_URL;
	}

	public void setSVN_DEPOSIT_URL(String sVN_DEPOSIT_URL) {
		SVN_DEPOSIT_URL = sVN_DEPOSIT_URL;
	}

	public String getSVN_USERNAME() {
		return SVN_USERNAME;
	}

	public void setSVN_USERNAME(String sVN_USERNAME) {
		SVN_USERNAME = sVN_USERNAME;
	}

	public String getSVN_PASSWORD() {
		return SVN_PASSWORD;
	}

	public void setSVN_PASSWORD(String sVN_PASSWORD) {
		SVN_PASSWORD = sVN_PASSWORD;
	}

	public ConnecttoSVN() {
		AIPasswords passwordObj = new AIPasswords();
		passwordObj.init();
		String password=passwordObj.getPassword(AIConstant.SVN_USERNAME.toUpperCase());
		
		passwordObj.close();
		this.SVN_PASSWORD=password;
		init();

	}

	public static SVNCommitInfo addFile(ISVNEditor editor, String filePath,
			byte[] data) throws SVNException {

		try {
			editor.openRoot(-1);
		} catch (SVNException e) {
			log.error("1. Error: Connect To SVN " + e.toString());

		}

		try {
			editor.addFile(filePath, null, -1);
		} catch (SVNException e) {
			log.error("2. Error: Connect To SVN " + e.toString());
		}

		try {
			editor.applyTextDelta(filePath, null);
		} catch (SVNException e) {
			log.error("3. Error: Connect To SVN " + e.toString());

		}
		SVNDeltaGenerator deltaGenerator = new SVNDeltaGenerator();
		String checksum = null;
		try {
			checksum = deltaGenerator.sendDelta(filePath,
					new ByteArrayInputStream(data), editor, true);
		} catch (SVNException e) {
			log.error("4. Error: Connect To SVN " + e.toString());

		}
		try {
			editor.closeFile(filePath, checksum);
		} catch (SVNException e1) {
			log.error("5. Error: Connect To SVN " + e1.toString());

		}

		return editor.closeEdit();

	}

	public static SVNCommitInfo copyDir(ISVNEditor editor, String srcDirPath,
			String dstDirPath, long revision) throws SVNException {

		editor.openRoot(-1);
		editor.addDir(dstDirPath, srcDirPath, revision);
		editor.closeDir();
		editor.closeDir();
		return editor.closeEdit();
	}

	public static SVNCommitInfo deleteDir(ISVNEditor editor, String dirPath)
			throws SVNException {

		editor.openRoot(-1);
		editor.deleteEntry(dirPath, -1);
		editor.closeDir();
		return editor.closeEdit();
	}

	public static SVNCommitInfo deleteFile(SVNRepository repository,
			String filePath) throws SVNException {

		ISVNEditor editor = repository.getCommitEditor(
				"directory and file delete", null);
		editor.openRoot(-1);
		editor.deleteEntry(filePath, -1);
		return editor.closeEdit();
	}

	public SVNRepository connect(String URL) {
		SVNURL url;
		SVNRepository reposit = null;
		try {
			url = SVNURL.parseURIEncoded(URL);
			reposit = SVNRepositoryFactory.create(url);
			this.repos = SVNRepositoryFactory.create(url);
			ISVNAuthenticationManager authManager = SVNWCUtil
					.createDefaultAuthenticationManager(this.SVN_USERNAME,
							this.SVN_PASSWORD);
			reposit.setAuthenticationManager(authManager);
			this.repos.setAuthenticationManager(authManager);
		} catch (SVNException e) {
			log.error("6. Error: Connect To SVN " + e.toString());

		}

		return reposit;
	}

	public boolean committoSVNwithfile(SVNRepository repository, String URL,
			String filename, String contents) {

		try {
			byte[] content = contents.getBytes();
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			SVNNodeKind nodeKind = repository.checkPath("" + filename, -1);
			repository.getLatestRevision();
			ISVNEditor editor = repository.getCommitEditor(
					"directory and file added", null);
			if (nodeKind == SVNNodeKind.NONE) {
				addFile(editor, filename, content);

			} else if (nodeKind == SVNNodeKind.FILE) {

				repos.getFile(filename, -1, null, baos);
				try {
					baos.close();
				} catch (Exception e1) {
					log.error("7. Error: Connect To SVN " + e1.toString());
				}
				String str = null;
				try {
					str = new String(baos.toByteArray(), "utf-8");
				} catch (Exception e) {
					log.error("8. Error: Connect To SVN " + e.toString());

				}
				byte[] oldcontent = str.getBytes();

				modifyFile(editor, URL, filename, oldcontent, content);

			}
		} catch (SVNException e) {
			log.error("9. Error: Connect To SVN " + e.toString());
			displayErrorMessageToUser("Could not check-in to SVN", "ERROR");
			return false;
		}
		return true;
	}

	public static SVNCommitInfo modifyFile(ISVNEditor editor, String dirPath,
			String filePath, byte[] oldData, byte[] newData)
			throws SVNException {
		editor.openRoot(-1);
		editor.openDir(dirPath, -1);
		editor.openFile(filePath, -1);
		editor.applyTextDelta(filePath, null);
		SVNDeltaGenerator deltaGenerator = new SVNDeltaGenerator();
		String checksum = deltaGenerator.sendDelta(filePath,
				new ByteArrayInputStream(oldData), 0, new ByteArrayInputStream(
						newData), editor, true);
		editor.closeFile(filePath, checksum);
		editor.closeDir();
		editor.closeDir();
		return editor.closeEdit();
	}

	public void SVNPopulatedb(String layoutid, String Scripttype,
			String ScriptName, String username) {

		/* Condition if already exists then update needs to be done */
		String querySelect = "select * from imp_svn_checkin  where layoutid='"
				+ layoutid + "' and scripttype='" + Scripttype
				+ "' and end_date is null";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(querySelect);
		if (rs.size() > 1) {
			String queryupdate = "Update imp_svn_checkin set end_date=sysdate where layoutid='"
					+ layoutid
					+ "' and scripttype='"
					+ Scripttype
					+ "' and end_date is null";
			db.executeDML(queryupdate);
			String query = "Insert into imp_svn_checkin values ('" + layoutid
					+ "','" + Scripttype + "','" + ScriptName + "',"
					+ "sysdate," + "null" + ",sysdate,'" + username + "')";
			db.executeDML(query);
		} else {
			String query = "Insert into imp_svn_checkin values ('" + layoutid
					+ "','" + Scripttype + "','" + ScriptName + "',"
					+ "sysdate," + "null" + ",sysdate,'" + username + "')";
			db.executeDML(query);

		}

		String querylayout = "update imp_layouts set layout_status='FINALIZED' where layoutid='"
				+ layoutid + "'";
		db.executeDML(querylayout);
		db.endConnection();

	}

	public void SVNPopulatedb(String layoutid, String Scripttype,
			String ScriptName, String username, String controltotal) {

		/* Condition if already exists then update needs to be done */
		String querySelect = "select * from imp_svn_checkin  where layoutid='"
				+ layoutid + "' and scripttype='" + Scripttype
				+ "' and end_date is null";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(querySelect);
		if (rs.size() > 1) {
			String queryupdate = "Update imp_svn_checkin set end_date=sysdate where layoutid='"
					+ layoutid
					+ "' and scripttype='"
					+ Scripttype
					+ "' and end_date is null";
			db.executeDML(queryupdate);
			String query = "Insert into imp_svn_checkin values ('" + layoutid
					+ "','" + Scripttype + "','" + ScriptName + "',"
					+ "sysdate," + "null" + ",sysdate,'" + username + "')";
			db.executeDML(query);
		} else {
			String query = "Insert into imp_svn_checkin values ('" + layoutid
					+ "','" + Scripttype + "','" + ScriptName + "',"
					+ "sysdate," + "null" + ",sysdate,'" + username + "')";
			db.executeDML(query);

		}

		db.endConnection();

	}

	public SVNRepository getRepos() {
		return repos;
	}

	public void setRepos(SVNRepository repos) {
		this.repos = repos;
	}

	public String checkoutSVNwithfile(SVNRepository repos2, String sVNSQL_PATH,
			String filename) {
		String impContent = "";

		try {

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			SVNNodeKind nodeKind = repos2.checkPath("" + filename, -1);
			repos2.getLatestRevision();

			if (nodeKind == SVNNodeKind.NONE) {
				impContent = "NO FILE FOUND";

			} else if (nodeKind == SVNNodeKind.FILE) {

				repos2.getFile(filename, -1, null, baos);
				try {
					baos.close();
				} catch (Exception e1) {
					log.error("10. Error: Connect To SVN " + e1.toString());
				}

				try {
					impContent = new String(baos.toByteArray(), "utf-8");
				} catch (Exception e) {
					log.error("11. Error: Connect To SVN " + e.toString());
				}
			}
		} catch (SVNException e) {
			log.error("12. Error: Connect To SVN " + e.toString());
			displayErrorMessageToUser("Could not check-out from SVN", "ERROR");

		}
		return impContent;
	}

}
