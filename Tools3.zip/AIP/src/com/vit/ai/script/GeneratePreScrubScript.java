/* 
 *Class Name : GeneratePreScrubScript.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.script;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedProperty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.scrub.controller.MappingModel;
import com.vit.ai.session.ViewsParameters;

/**
 * Class to generate pre scrub script
 * 
 * @author Sagar Shrestha
 * 
 * @version 1.0 19 May 2014
 */
public class GeneratePreScrubScript implements Serializable {

	private static final long serialVersionUID = 1L;
	private String layoutID = "";
	private String subLayoutID = "";
	private String clientID = "";
	private String payerID = "";
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	private static final Logger logger = LoggerFactory
			.getLogger(GeneratePreScrubScript.class);

	public GeneratePreScrubScript() {

	}

	public GeneratePreScrubScript(String layoutID, String subLayoutID,
			String clientID, String payerID) {
		super();
		this.setLayoutID(layoutID);
		this.setSubLayoutID(subLayoutID);
		this.setClientID(clientID);
		this.setPayerID(payerID);
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getSubLayoutID() {
		return subLayoutID;
	}

	public void setSubLayoutID(String subLayoutID) {
		this.subLayoutID = subLayoutID;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getPayerID() {
		return payerID;
	}

	public void setPayerID(String payerID) {
		this.payerID = payerID;
	}

	public String generatePreScrubScript(ArrayList<MappingModel> psMappings,
			String scriptLocation) {
		String procName = "PS_" + getLayoutID() + "_" + getSubLayoutID();
		String startofScript = "CREATE OR REPLACE PROCEDURE "
				+ procName
				+ " (p_FileID VARCHAR2 DEFAULT NULL,p_SchemaName VARCHAR2 DEFAULT NULL,p_CLIENTID VARCHAR2 DEFAULT NULL,"
				+ " p_EMPGRP VARCHAR2 DEFAULT NULL)\nIS\n	d_StartDate VARCHAR2(50);\n	v_QueryID NUMBER(22);\n	v_Query VARCHAR2(32657);\n	"
				+ " SourceDirectory VARCHAR2(1000);\n	FileName VARCHAR2(500) ;\n	n_RowCount NUMBER(22);\n	"
				+ " v_ErrMsg VARCHAR2(2000);\n\n"
				+ " BEGIN\n	SourceDirectory:=SubStr(p_FilePath,1,InStr(p_FilePath,'/',-1)) ;\n"
				+ "	FileName:=SubStr(p_FilePath,InStr(p_FilePath,'/',-1)+1) ;\n	v_QueryID:=0;\n"
				+ "	d_StartDate :=TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:Mi:SS');\n"
				+ "\tv_ErrMsg:='SUCCESS';\n-------\n";

		String script = "BEGIN \n\tv_Query:='INSERT INTO " + procName + " \n";

		for (int i = 0; i < psMappings.size(); i++) {
			script += psMappings.get(i).getScrubFieldName() + ",\n\t";
		}
		script = script.substring(0, script.lastIndexOf(","));

		script += "\nSELECT\n";
		for (int i = 0; i < psMappings.size(); i++) {
			if (psMappings.get(i).getScrubLogic() == null
					|| psMappings.get(i).getScrubLogic().equals("")) {
				script += "\tNULL AS " + psMappings.get(i).getScrubFieldName()
						+ ",\n";
			} else {
				if (psMappings.get(i).getScrubFieldName()
						.equalsIgnoreCase("VHPAYORID")) {
					script += "\t''" + payerID + "'' AS "
							+ psMappings.get(i).getScrubFieldName() + ",\n";
				} else if (psMappings.get(i).getScrubFieldName()
						.equalsIgnoreCase("VHLAYOUTID")) {
					script += "\t''" + layoutID + "'' AS "
							+ psMappings.get(i).getScrubFieldName() + ",\n";
				} else {
					script += "\t"
							+ psMappings.get(i).getScrubLogic()
									.replaceAll("'", "''") + " AS "
							+ psMappings.get(i).getScrubFieldName() + ",\n";
				}
			}
		}

		script = script.substring(0, script.lastIndexOf(","));

		script += "\nFROM '||p_SchemaName||'.AI_" + getLayoutID() + "_"
				+ getSubLayoutID() + " ';\n";
		script += " EXECUTE IMMEDIATE v_Query; EXCEPTION WHEN OTHERS THEN NULL; END; \n COMMIT; \n END "
				+ procName + ";\n /";

		script = startofScript + script;

		savePSScript(procName, scriptLocation, script);
		return script;

	}

	public void savePSScript(String pname, String scriptLocation,
			String contents) {
		File file = new File(scriptLocation + pname + ".sql");
		FileWriter fw = null;

		if (!file.exists()) {
			try {
				file.createNewFile();

			} catch (IOException e) {
				logger.error(" File Not Found " + e.getMessage());
			}
		}

		try {
			fw = new FileWriter(file.getAbsoluteFile());
		} catch (IOException e) {
			logger.error(" File Input Output Error " + e.getMessage());
		}

		BufferedWriter bw = new BufferedWriter(fw);

		String content = "PROMPT COMPILING PRE-SCRUB PROCEDURE " + pname + "\n"
				+ contents;

		if (!content.substring(content.trim().length() - 1).equals("/")) {
			content = content + "\n/";
		}
		try {
			bw.write(content.trim());
			bw.newLine();
		} catch (IOException e) {
			logger.error(" File writing error" + e.getMessage());
		}

		try {
			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e) {
			logger.error(" File closing error" + e.getMessage());
		}

	}

}
