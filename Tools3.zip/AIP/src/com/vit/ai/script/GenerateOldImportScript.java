/*
 *Class Name : GenerateOldImportScript.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.script;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.faces.bean.ManagedProperty;

import org.apache.log4j.Logger;

import com.vit.ai.session.ViewsParameters;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to generate old import script
 * 
 * @author Sagar Shrestha
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.1 06 Jun 2014
 */
public class GenerateOldImportScript implements Serializable {

	private static Logger log = Logger.getLogger(GenerateOldImportScript.class
			.getName());
	private static final long serialVersionUID = 1L;
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public GenerateOldImportScript() {

	}

	@SuppressWarnings("rawtypes")
	public void imprtScrptGeneration(String layoutid, String procName,
			String HITABLENAME, String LayoutId, String scriptLocation,
			String fileName) {
		ConnectDB db = new ConnectDB();
		String query = " SELECT DISTINCT C.LAYOUTTYPEID,A.SKIPROW,A.PUCHCHARFLAG,A.OPTIONALLY "
				+ "      FROM  "
				+ "      (SELECT * FROM IMP_LAYOUTS WHERE LAYOUTID='"
				+ LayoutId
				+ "') A "
				+ "      LEFT JOIN  "
				+ "      IMP_SUB_LAYOUTS B "
				+ "      ON  "
				+ "      A.LAYOUTID= B.LAYOUTID"
				+ "	   LEFT JOIN "
				+ "      TBL_FILEPATTERNS_LAYOUT C"
				+ "      ON UPPER(B.LAYOUTTYPE) = UPPER(C.LAYOUTTYPE)";

		db.initialize();
		List<List<String>> basicInfo = db.resultSetToListOfList(query);

		String DelimType = basicInfo.get(1).get(0);
		String skip = basicInfo.get(1).get(1);
		String punchChr = basicInfo.get(1).get(2);
		String optEnc = basicInfo.get(1).get(3);

		query = "SELECT  distinct SUBLAYOUTID FROM IMP_SUB_LAYOUTS WHERE LAYOUTID='"
				+ LayoutId + "' AND " + " SUBLAYOUTID IS NOT NULL";
		String DateFormat = "YYYY-MM-DD";

		List noSubLayout = null;
		List result = null;

		noSubLayout = db.resultSetToListOfList(query);

		String[] tablename = new String[noSubLayout.size() - 1];
		String[] ztbl_fields = new String[noSubLayout.size() - 1];
		String[] zzz_fields = new String[noSubLayout.size() - 1];
		String[] HITABLEFIELDS = new String[noSubLayout.size() - 1];
		String[] InsertBlocktrim = new String[noSubLayout.size() - 1];
		String[] InsertBlock = new String[noSubLayout.size() - 1];
		String[] HiInsertBlock = new String[noSubLayout.size() - 1];

		for (int sl = 1; sl < noSubLayout.size(); sl++) {
			ztbl_fields[sl - 1] = "";
			zzz_fields[sl - 1] = "";
			InsertBlock[sl - 1] = "";
			InsertBlocktrim[sl - 1] = "";
			HITABLEFIELDS[sl - 1] = "";
			HiInsertBlock[sl - 1] = "";

			int substrpos = 1;
			query = "SELECT  SN,Nvl(COLUMNNAME,'NA') COLUMNNAME, Nvl(DATATYPE,'NA') DATATYPE, "
					+ " FIELDLENGTH, Nvl(DATETYPEDETIAL,'NA') DATETYPEDETIAL,"
					+ " SUBLAYOUTID FROM IMP_LAYOUTS_FIELDS "
					+ " WHERE LAYOUTID='"
					+ LayoutId
					+ "' and SUBLAYOUTID='"
					+ ((List) (noSubLayout.get(sl))).get(0).toString()
					+ "' ORDER BY SN";
			result = db.resultSetToListOfList(query);
			/* Table Name */
			if (sl == 1)
				tablename[sl - 1] = HITABLENAME;
			else
				tablename[sl - 1] = HITABLENAME + "_"
						+ ((List) (noSubLayout.get(sl))).get(0).toString();
			/* ZZZ Fields */
			for (int k = 1; k < result.size(); k++) {
				if (k == result.size() - 1)
					zzz_fields[sl - 1] = zzz_fields[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ "\tVARCHAR2(4000)";
				else
					zzz_fields[sl - 1] = zzz_fields[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ "\tVARCHAR2(200),\n";
				/* Ztbl Fields */
				ztbl_fields[sl - 1] = ztbl_fields[sl - 1] + "\t\t"
						+ ((List) (result.get(k))).get(1).toString()
						+ "\tVARCHAR2(200),\n";
				/* Insert into upper fields */
				InsertBlock[sl - 1] = InsertBlock[sl - 1] + "\t\t"
						+ ((List) (result.get(k))).get(1).toString() + ",\n";
				/* Insert into ztbl fields */
				if (DelimType.equals("FIXED")) {
					InsertBlocktrim[sl - 1] = InsertBlocktrim[sl - 1]
							+ "\t\tTRIM(SUBSTR(ClientData," + substrpos + ","
							+ ((List) (result.get(k))).get(3).toString()
							+ ")) AS "
							+ ((List) (result.get(k))).get(1).toString()
							+ ",\n";
					substrpos = substrpos
							+ Integer.parseInt(((List) (result.get(k))).get(3)
									.toString());
				} else
					InsertBlocktrim[sl - 1] = InsertBlocktrim[sl - 1]
							+ "\t\tTRIM("
							+ ((List) (result.get(k))).get(1).toString()
							+ ") AS "
							+ ((List) (result.get(k))).get(1).toString()
							+ ",\n";
				/* Hi table Block */
				if (((List) (result.get(k))).get(2).toString().toUpperCase()
						.startsWith("DATE")) {
					DateFormat = ((List) (result.get(k))).get(4).toString();
					HITABLEFIELDS[sl - 1] = HITABLEFIELDS[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ "\tDATE,\n";

					HiInsertBlock[sl - 1] = HiInsertBlock[sl - 1]
							+ "\t\tCASE WHEN ISDATE("
							+ ((List) (result.get(k))).get(1).toString()
							+ ",''" + DateFormat + "'') = 1 THEN TO_DATE("
							+ ((List) (result.get(k))).get(1).toString()
							+ ",''" + DateFormat + "'') ELSE NULL END AS "
							+ ((List) (result.get(k))).get(1).toString()
							+ ",\n";
				} else if (((List) (result.get(k))).get(2).toString()
						.toUpperCase().startsWith("NUMBER")) {
					HITABLEFIELDS[sl - 1] = HITABLEFIELDS[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ "\tNUMBER(19,4),\n";
					if (punchChr.toUpperCase().equals("Y"))
						HiInsertBlock[sl - 1] = HiInsertBlock[sl - 1]
								+ "\t\tCASE WHEN ISNUMERIC(Punch_Char("
								+ ((List) (result.get(k))).get(1).toString()
								+ "))=1 THEN TO_NUMBER(Punch_Char("
								+ ((List) (result.get(k))).get(1).toString()
								+ ")) ELSE 0 END AS "
								+ ((List) (result.get(k))).get(1).toString()
								+ ",\n";
					else
						HiInsertBlock[sl - 1] = HiInsertBlock[sl - 1]
								+ "\t\tCASE WHEN ISNUMERIC("
								+ ((List) (result.get(k))).get(1).toString()
								+ ")=1 THEN TO_NUMBER("
								+ ((List) (result.get(k))).get(1).toString()
								+ ") ELSE 0 END AS "
								+ ((List) (result.get(k))).get(1).toString()
								+ ",\n";
				} else if (((List) (result.get(k))).get(2).toString()
						.toUpperCase().startsWith("INT")) {
					HITABLEFIELDS[sl - 1] = HITABLEFIELDS[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ "\tNUMBER(10),\n";
					if (punchChr.toUpperCase().equals("Y"))
						HiInsertBlock[sl - 1] = HiInsertBlock[sl - 1]
								+ "\t\tCASE WHEN ISNUMERIC(Punch_Char("
								+ ((List) (result.get(k))).get(1).toString()
								+ "))=1 THEN TO_NUMBER(Punch_Char("
								+ ((List) (result.get(k))).get(1).toString()
								+ ")) ELSE 0 END AS "
								+ ((List) (result.get(k))).get(1).toString()
								+ ",\n";
					else
						HiInsertBlock[sl - 1] = HiInsertBlock[sl - 1]
								+ "\t\tCASE WHEN ISNUMERIC("
								+ ((List) (result.get(k))).get(1).toString()
								+ ")=1 THEN TO_NUMBER("
								+ ((List) (result.get(k))).get(1).toString()
								+ ") ELSE 0 END AS "
								+ ((List) (result.get(k))).get(1).toString()
								+ ",\n";
				} else {
					HITABLEFIELDS[sl - 1] = HITABLEFIELDS[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ "\tVARCHAR2("
							+ ((List) (result.get(k))).get(3).toString()
							+ "),\n";
					HiInsertBlock[sl - 1] = HiInsertBlock[sl - 1] + "\t\t"
							+ ((List) (result.get(k))).get(1).toString()
							+ " AS "
							+ ((List) (result.get(k))).get(1).toString()
							+ ",\n";
				}

			}
			/* For substring insert into zzz block */
			if (DelimType.toUpperCase().equals("FIXED"))
				zzz_fields[sl - 1] = "\t\tClientData       VARCHAR2(4000)";
		}
		List lay = db
				.resultSetToListOfList("SELECT FIELDTERMINATOR FROM TBL_FILEPATTERNS_LAYOUT   WHERE Upper(LAYOUTTYPEID)='"
						+ DelimType.toUpperCase() + "'");

		if (lay != null && lay.size() > 1) {
			DelimType = "\"" + ((List) (lay.get(1))).get(0).toString() + "\"";

		} else {
			DelimType = "NA";
		}

		String optionalEnc = "";

		if (optEnc.toLowerCase().equals("y")) {
			optionalEnc = "\n OPTIONALLY ENCLOSED BY ''\"'' ";
		}

		String comment = "------Old Script for AIP Layoutid : " + layoutid
				+ "\n \n \n";
		String startofScript = "";
		String createZtblLoop = "";
		String createHiTblLoop = "";
		String cursorBlock = "";
		String InsertIntoHI = "";
		String InsertIntoZtblHI = "";
		String endOfCursor = "";
		String endofScript = "";

		int nv_QueryID = 1;
		for (int z = 0; z < ztbl_fields.length; z++) {

			startofScript = "PROMPT CREATE OR REPLACE PROCEDURE "
					+ procName
					+ " \nCREATE OR REPLACE PROCEDURE "
					+ procName
					+ " (p_Path VARCHAR2, p_FileFilterCondition VARCHAR2 DEFAULT NULL, p_ProcessedDate VARCHAR2 DEFAULT NULL)\nIS\n	v_Path               VARCHAR2(2000);\n	v_Query              VARCHAR2(32657);\n	v_ErrMsg             VARCHAR2(2000);\n	d_StartDate          DATE;\n	v_Phase              VARCHAR2(200);\n	v_Stage              VARCHAR2(200);\n	v_QueryID            VARCHAR2(200);\n	v_ClientID           VARCHAR2(3);\n	v_DataTypeID         VARCHAR2(4);\n	v_EmployerGroupID    VARCHAR2(4);\n	v_PayerID            VARCHAR2(4);\n	v_MetaID             VARCHAR2(800);\n	v_HITablename        VARCHAR2(30);\n	v_ScriptID           VARCHAR2(800);\n	v_ProcedureName      VARCHAR2(30);\n	n_RowCount           NUMBER(22);\n	v_FileFiterCondition VARCHAR2(20000);\n	v_TableExists        NUMBER(1);\n	v_Processeddate      VARCHAR2(30);\n	v_temp      VARCHAR2(4000);\n	v_temp2      VARCHAR2(4000);\n	v_temp3      VARCHAR2(4000);\n	v_temp4      VARCHAR2(4000);\n	v_temp5      VARCHAR2(4000);\n	v_temp6      VARCHAR2(4000);\nBEGIN\n\nv_ScriptID:=p_FileFilterCondition;\nv_MetaID:=v_ScriptID;\nBEGIN\n	v_Query:='SELECT FILENAMES,FILENAMES2,FILENAMES3,FILENAMES4,FILENAMES5,FILENAMES6,Upper(PROCEDURENAME) FROM TBL_AUTOIMPORT_PROCPOOL@DATADASHBOARD	WHERE SN_IMPORT_ID||''_''||SN='''||v_ScriptID||'''';\n	EXECUTE IMMEDIATE v_Query INTO  v_temp,v_temp2,v_temp3,v_temp4,v_temp5,v_temp6, v_ProcedureName;\nEXCEPTION WHEN No_Data_Found THEN NULL ;\nEND;\n\n v_FileFiterCondition:=v_temp||v_temp2||v_temp3||v_temp4||v_temp5||v_temp6;\n\n--STARTS IMPORTING ONLY IF THIS IS NOT MAIN HI SCHEMA\nIF Upper(USER) NOT LIKE 'HI0______'  THEN\n--------------------------------------------------------------------------------\nv_QueryID := '2000';\n--------------------------------------------------------------------------------\nBEGIN\n	v_QueryID := '2010';\n	v_Query:='Script ID ==> '|| v_ScriptID;\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@Datadashboard(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n				VALUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''','''||v_Stage||''','''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''STARTED'', NULL, NULL, NULL, SYSDATE, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query;\n	COMMIT;\nEND;\n--------------------------------------------------------------------------------\nBEGIN	EXECUTE IMMEDIATE 'DROP TABLE LF_'||v_ScriptID||' PURGE';\n	EXCEPTION WHEN OTHERS THEN NULL;\nEND;\n--------------------------------------------------------------------------------\nBEGIN	EXECUTE IMMEDIATE 'CREATE TABLE LF_'||v_ScriptID||'(SourceDirectory VARCHAR2(500),FileName VARCHAR2(500)) NOLOGGING';\nEND;\n--------------------------------------------------------------------------------\nDECLARE	vTemplist sys.OS_Operation_pkg.tab_DirectoryFile;\n	v_Path  VARCHAR2(1024) ;\n	i NUMBER := 1;\nBEGIN\n	d_StartDate :=SYSDATE;\n	v_Query:=NULL;\n	v_Path:= Trim(p_Path)|| CASE WHEN SubStr(Trim(p_Path),-1) <> '/' THEN '/' END ;\n\n	sys.OS_Operation_pkg.GetFilesList (v_Path,vTemplist);\n	FOR i IN 1..vTemplist.Count LOOP\n		EXECUTE IMMEDIATE 'INSERT INTO  LF_'||v_ScriptID||'(SourceDirectory,FileName) VALUES ('''||Substr(vTemplist(i),1, InStr(vTemplist(i),'/',-1))||''','''||SUBSTR(vTemplist(i),INSTR(vTemplist(i),'/',-1)+1)||''' )'  ;\n	END LOOP;\n	COMMIT;\nEND;";
			createZtblLoop = createZtblLoop
					+ "--------------------------------------------------------------------------------\nBEGIN\n	EXECUTE IMMEDIATE 'DROP TABLE ZTBL_"
					+ tablename[z]
					+ "  PURGE';\n	EXCEPTION WHEN OTHERS THEN NULL;\nEND;\n--------------------------------------------------------------------------------\nBEGIN\n	v_QueryID := '202"
					+ nv_QueryID
					+ "';\n\nv_Query:=\n	'CREATE TABLE ZTBL_"
					+ tablename[z]
					+ "\n	(\n"
					+ ztbl_fields[z]
					+ "\t\tSourceFileName VARCHAR2(255)\n	) NOLOGGING';\n--------------------------------------------------------------------------------\n	d_StartDate :=SYSDATE;\n	EXECUTE IMMEDIATE v_Query;\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE,  STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n				VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''SUCCESS'', NULL, NULL, NULL, :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\n	COMMIT;\nEND;";
			createHiTblLoop = createHiTblLoop
					+ "--------------------------------------------------------------------------------\nBEGIN\n\tEXECUTE IMMEDIATE 'DROP TABLE "
					+ tablename[z]
					+ " PURGE'; \n\tEXCEPTION WHEN OTHERS THEN NULL; \nEND;\n--------------------------------------------------------------------------------\nBEGIN\n\tv_QueryID :='203"
					+ nv_QueryID
					+ "';\nv_Query:=\n\t'CREATE TABLE "
					+ tablename[z]
					+ "\n\t(\n"
					+ HITABLEFIELDS[z]
					+ "\t\tUDF1\tVARCHAR2(200),\n\t\tUDF2\tVARCHAR2(200),\n\t\tUDF3\tVARCHAR2(200),\n\t\tUDF4\tVARCHAR2(200),\n\t\tUDF5\tVARCHAR2(200),\n\t\tSourceFileName\tVARCHAR2(255),\n\t\tReceivedMonth\tVARCHAR2(6),\n\t\tImportedDate\tDate\n\t) NOLOGGING';\n--------------------------------------------------------------------------------\n	d_StartDate :=SYSDATE;\n	EXECUTE IMMEDIATE v_Query;\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n				VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''SUCCESS'', NULL, NULL, NULL, :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\n	COMMIT;\nEND;";
			cursorBlock = "--------------------------------------------------------------------------------\n\nDECLARE	rowcnt NUMBER;\n	TYPE t_crs is REF CURSOR;\n	file_cursor        t_crs;\n	v_SourceDirectory  VARCHAR2(500);\n	v_Filename         VARCHAR2(500);\n--------------------------------------------------------------------------------\n\n--HANDLES 'AND' OR 'WHERE' IN FILEFILTERCONDITION PARAMETER\nBEGIN\n	v_QueryID := '2040';\n	v_Query:=NULL;\n\n--------------------------------------------------------------------------------\n--FILEFILTERCONDITION APPLIED IN CURSOR\n\nv_Query:='SELECT SourceDirectory,FileName FROM LF_'||v_ScriptID||'\n			WHERE Upper(FileName) NOT LIKE ''%.BAD'' AND Upper(FileName) NOT LIKE ''%.LOG'' '||v_FileFiterCondition;\n\n--------------------------------------------------------------------------------\nEXECUTE IMMEDIATE  'SELECT /*+parallel(a,4)*/  count(*) FROM ('|| v_Query || ' ) a '  INTO n_RowCount ;\n\nIF n_RowCount IS NULL OR n_RowCount=0 THEN\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n			VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''NO FILE FOUND'', NULL, NULL, NULL, :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\nELSE\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n			VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''SUCCESS'', NULL, NULL, NULL, :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\nEND IF;\nCOMMIT;\n--------------------------------------------------------------------------------\n\nOPEN file_cursor FOR v_Query;\nLOOP\nFETCH file_cursor INTO  v_SourceDirectory, v_Filename;\n	EXIT WHEN file_cursor%NOTFOUND;\n\n	v_QueryID := '2050';\n	v_Path:= v_SourceDirectory;\n	v_Query:='CREATE OR REPLACE DIRECTORY ID_'||v_ScriptID||' AS '''|| v_Path || '''';\n	COMMIT;\n	EXECUTE IMMEDIATE v_Query;\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n				VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''SUCCESS'', '''||v_Filename||''', NULL, NULL, :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\n	COMMIT;\n--------------------------------------------------------\n\n--------------------------------------------------------\nv_QueryID := '2060';\n\nBEGIN\n	EXECUTE IMMEDIATE'DROP TABLE ZZZ_"
					+ tablename[0]
					+ " PURGE';\n	EXCEPTION WHEN OTHERS THEN NULL;\nEND;\n--------------------------------------------------------\n\nv_Query:=\n	'CREATE TABLE ZZZ_"
					+ tablename[0]
					+ "\n	(\n"
					+ zzz_fields[0]
					+ "\n	)\n	ORGANIZATION EXTERNAL\n	(\n		TYPE ORACLE_LOADER\n		DEFAULT DIRECTORY ID_'||v_ScriptID||'\n		ACCESS PARAMETERS\n		(\n			RECORDS DELIMITED BY NEWLINE CHARACTERSET US7ASCII\n			SKIP  "
					+ skip
					+ " \n			READSIZE 1048576\n			FIELDS TERMINATED BY "
					+ DelimType
					+ "  "
					+ optionalEnc
					+ " LDRTRIM\n			MISSING FIELD VALUES ARE NULL\n			REJECT ROWS WITH ALL NULL FIELDS\n		)\n		LOCATION ('''||v_Filename||''')\n	)\n	PARALLEL 4\n	REJECT LIMIT UNLIMITED';\n--------------------------------------------------------\nd_StartDate :=SYSDATE;\nEXECUTE IMMEDIATE v_Query;\n--------------------------------------------------------\nEXECUTE IMMEDIATE 'SELECT /*+parallel(a,4)*/ COUNT(*) FROM ZZZ_"
					+ tablename[0]
					+ " a ' INTO n_RowCount;\n\nEXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n			VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''', :v_Query, ''SUCCESS'', '''||v_Path||v_Filename||''',  '''||n_RowCount||''',''ZZZ TABLE IMPORTED'', :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\nCOMMIT;\n--------------------------------------------------------\n";
			InsertIntoZtblHI = InsertIntoZtblHI
					+ "v_QueryID := '207"
					+ nv_QueryID
					+ "';\n\nv_Query:=\n	'INSERT INTO ZTBL_"
					+ tablename[z]
					+ "\n	(\n"
					+ InsertBlock[z]
					+ "\t\tSourceFileName\n	)\n	SELECT\n"
					+ InsertBlocktrim[z]
					+ "\t\t'''||v_Filename||'''\n	FROM\n		ZZZ_"
					+ tablename[0]
					+ "\n	--WHERE ABC=''''\n	';\n--------------------------------------------------------------------------------\nd_StartDate :=SYSDATE;\nEXECUTE IMMEDIATE v_Query;\nn_RowCount:=SQL%ROWCOUNT;\nCOMMIT;\nEXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE, PROCESSEDDATE)\n			VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''', :v_Query, ''SUCCESS'',  '''||v_Path||v_Filename||''', '''||n_RowCount||''',''ZTBL TABLE IMPORTED'', :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\nCOMMIT;\n--------------------------------------------------------------------------------\n";
			endOfCursor = "END LOOP;\nCLOSE file_cursor;\nEND;";
			InsertIntoHI = InsertIntoHI
					+ "--------------------------------------------------------------------------------\nBEGIN\nv_QueryID := '208"
					+ nv_QueryID
					+ "';\n\nv_Query:=\n	'INSERT INTO  "
					+ tablename[z]
					+ "\n (\n"
					+ InsertBlock[z]
					+ "\t\tUDF1,\n\t\tUDF2,\n\t\tUDF3,\n\t\tUDF4,\n\t\tUDF5,\n\t\tSourceFileName,\n\t\tReceivedMonth,\n\t\tIMPORTEDDATE\n )\n SELECT\n"
					+ HiInsertBlock[z]
					+ "\t\tNULL,\n\t\tNULL,\n\t\tNULL,\n\t\tNULL,\n\t\tNULL,\n\t\tSourceFileName,\n\t\tTO_CHAR(SYSDATE,''YYYYMM'') ,\n\t\tSYSDATE\nFROM\n\tZTBL_"
					+ tablename[z]
					+ "';\n\n--------------------------------------------------------------------------------\n	d_StartDate :=SYSDATE;\n	EXECUTE IMMEDIATE v_Query;\n	n_RowCount:=SQL%ROWCOUNT;\n	COMMIT;\n	DBMS_OUTPUT.PUT_LINE('Data Dumpted to HI table completed at ' || TO_CHAR(SYSDATE,'DD-MM-YYYY HH24:Mi:SS'));\n	EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE,PROCESSEDDATE)\n				VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''',  :v_Query, ''SUCCESS'',  NULL,'''||n_RowCount||''', ''HI TABLE IMPORTED'', :d_StartDate, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query, d_StartDate;\n\n	COMMIT;\nEND ;\n--------------------------------------------------------------------------------\n";
			endofScript = "v_QueryID := '2090';\n		v_Query:='Script ID ==> '|| v_ScriptID;\n		EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE,PROCESSEDDATE)\n					VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''', :v_Query, ''COMPLETED'',  NULL, NULL, NULL, SYSDATE, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query;\n		COMMIT;\n--------------------------------------------------------------------------------\nv_Phase:='"
					+ DateFormat
					+ "';\n--Supply fields for their distribution as third parameter below seperated by pipe(|).E.g.SP_IMPORT_VERIFICATION(v_ScriptID,v_Phase,'GENDER'),SP_IMPORT_VERIFICATION(v_ScriptID,v_Phase,'GENDER|STATE')\nSP_IMPORT_VERIFICATION(v_ScriptID,v_Phase);\n--------------------------------------------------------------------------------\n	ELSE\n		Dbms_Output.put_line('ABORTED ! MAIN SCHEMA USED FOR IMPORT');\n		v_Query:='Script ID ==> '|| v_ScriptID;\n		EXECUTE IMMEDIATE 'INSERT INTO TBL_EXECUTION_STATUS@DATADASHBOARD(ScriptID,CLIENTID, EMPLOYERGROUPID, PAYERID, METAID, DATATYPEID, PHASE, STAGE, HITABLENAME, QUERYID, QUERYCODE, STATUS, SOURCEFILENAME, ROWSAFFECTED,REMARKS, STARTDATE, ENDDATE,PROCESSEDDATE)\n					VAlUES ('''||v_ScriptID||''','''||v_ClientID||''', '''||v_EmployerGroupID||''','''||v_PayerID||''','''||v_MetaID||''','''||v_DataTypeID||''','''||v_Phase||''', '''||v_Stage||''', '''||v_HITablename||''', '''||v_QueryID||''', :v_Query, ''ABORTED ! MAIN SCHEMA USED FOR IMPORT'',  NULL, NULL, NULL, SYSDATE, SYSDATE,to_date('''||v_Processeddate||''',''YYYY-MM-DD HH24:Mi:SS''))' USING v_Query;\n		COMMIT;\n\n	END IF;\n\nEND "
					+ procName
					+ ";\n/\n--------------------------------------------------------------------------------";

			nv_QueryID = nv_QueryID + 2;
		}

		db.endConnection();

		File file = new File(scriptLocation + fileName);

		FileWriter fw = null;

		if (!file.exists()) {
			try {
				file.createNewFile();

			} catch (IOException e) {
				log.error(" File Creating Error " + e.toString());

			}
		}

		try {
			fw = new FileWriter(file.getAbsoluteFile());
		} catch (IOException e1) {
			log.error(" FileWriter Error " + e1.toString());

		}

		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(comment);
			bw.newLine();
			bw.write(startofScript);
			bw.newLine();
			bw.write(createZtblLoop);
			bw.newLine();
			bw.write(createHiTblLoop);

			bw.newLine();
			bw.write(cursorBlock);
			bw.newLine();
			bw.write(InsertIntoZtblHI);
			bw.newLine();
			bw.write(endOfCursor);
			bw.newLine();
			bw.write(InsertIntoHI);
			bw.newLine();
			bw.write(endofScript);

		} catch (IOException e) {
			log.error(" file write error " + e.toString());

		}

		try {

			bw.flush();
			fw.flush();
			bw.close();

			fw.close();

		} catch (IOException e1) {
			log.error(" File close error " + e1.toString());

		}

	}
}
