package com.vit.ai.payormanagement.controller;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.flms.controller.CheckDuplicateLayout;
import com.vit.ai.flms.model.Layout;
import com.vit.ai.flms.model.LayoutFields;
import com.vit.ai.flms.model.LayoutFieldsModel;
import com.vit.ai.flms.model.LayoutsbyID;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class PayorManagementActions extends AbstractController implements
		Serializable {
	private static final long serialVersionUID = 1465748423026626949L;
	private String layoutid;
	private ArrayList<Layout> layouts;
	private ArrayList<String> layoutids;
	private String reason="";
	private Layout selectedLayout = new Layout();
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	static Logger log = Logger
			.getLogger(PayorManagementActions.class.getName());
	private DefaultStreamedContent downloadDupDet;

	

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public ArrayList<Layout> getLayouts() {
		return layouts;
	}

	public void setLayouts(ArrayList<Layout> layouts) {
		this.layouts = layouts;
	}

	public ArrayList<String> getLayoutids() {
		return layoutids;
	}

	public void setLayoutids(ArrayList<String> layoutids) {
		this.layoutids = layoutids;
	}

	public PayorManagementActions() {

	}

	@PostConstruct
	public void init() {
		System.out.println("INITIALIZING");
		loadLayoutids();

	}

	public void loadLayoutids() {
		this.layoutids = new ArrayList<>();
		LayoutsbyID ojbLID = new LayoutsbyID("ALL PAYERS");
		this.layoutids = ojbLID.getLayoutids();
	}

	public void handleSubmit() {
		if (this.layoutid.isEmpty()) {
			displayErrorMessageToUser("No Layoutid Selected", "ERROR");

		} else {
			this.layouts = new ArrayList<>();
			LayoutsbyID ojbLID = new LayoutsbyID("", this.layoutid);
			setLayouts(ojbLID.getLayouts());
			this.selectedLayout = ojbLID.getLayouts().get(0);
		}
	}

	public void checkForDuplicates(Layout layout) {

		CustomUtility utilObj = new CustomUtility();
		String time = utilObj.getDateForReport();
		String filename = AIConstant.DUPLICATEFILE_LOCATION
				+ layout.getLayoutID() + "_partialDuplicateDetails_" + time
				+ ".csv";
		int count = 0;
		int statDup = 0;
		System.out.println("CHECKING FOR DUPLICATES");

		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select distinct(layoutid) from imp_layouts where payor='"
				+ layout.getPayor() + "'";

		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();

		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {

					LayoutsbyID layoutObj = new LayoutsbyID(rs.get(i).get(0),
							"1", "");
					Layout mainlayout = new Layout();
					mainlayout = layoutObj.getLayouts().get(0);

					LayoutFieldsModel modelObj = new LayoutFieldsModel(rs
							.get(i).get(0), "1");

					ArrayList<LayoutFields> mainLayoutFields = new ArrayList<>();
					mainLayoutFields = modelObj.getLayoutfieldsbysublayout();

					ArrayList<LayoutFields> newLayoutFields = new ArrayList<>();
					LayoutFieldsModel fieldsObj = new LayoutFieldsModel(
							layout.getLayoutID(), "1");

					newLayoutFields = fieldsObj.getLayoutfieldsbysublayout();
					if (mainLayoutFields.size() == newLayoutFields.size()) {
						count++;
						CheckDuplicateLayout duplicateCheck = new CheckDuplicateLayout(
								mainlayout, layout, mainLayoutFields,
								newLayoutFields);
						duplicateCheck.setDumpToExcel(true);
						duplicateCheck.setFilename(filename);
						int stat = duplicateCheck.checkForPartialDuplicate();
						if (stat == 1) {
							statDup++;
						}

					}

				}
				if (count == 0 || statDup < 2) {
					displayInfoMessageToUser("No Duplicate Found",
							"NO DUPLICATES");

				} else {

					displayInfoMessageToUser(statDup - 1
							+ " possible duplicates found.Plese Verify.",
							"Duplicates Found");
					prepDownload(filename);

				}

			}
		}
	}

	public void prepDownload(String filename) {

		
		
		try
		{
		File file = new File(filename);
		if (file.exists()) {
			FileController objFC = new FileController(filename);
			setDownloadDupDet(objFC.getDownload());
		} else {
			setDownloadDupDet(null);
		}
		}
		catch(Exception ex)
		{
			displayErrorMessageToUser("Cannot Download File.", "ERROR");
			setDownloadDupDet(null);
		}

	}

	public void checkinScript(Layout obj, String username) {
		if (obj.getDataType().compareTo("Control Total") == 0) {
			obj.checkinCattr(obj.getLayoutID(), username);
		} else {
			obj.checkinScript(obj.getLayoutID(), username);
		}
		refreshPage();

	}

	public void activateLayout(Layout obj) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "update imp_layouts set ActiveFlag='Y' where layoutid='"
				+ obj.getLayoutID() + "'";
		db.executeDML(query);
		db.endConnection();
		refreshPage();
		displayInfoMessageToUser("Layout Activated", "Activate");
	}

	public void deactivatelayout(Layout obj) {
		int clientstatus = obj.ConditionalCheck();
		if (clientstatus > 0) {
			displayErrorMessageToUser(
					"Layout is already in use by :"
							+ clientstatus
							+ "client. Please Remove Client patterns and deactivate the layout",
					"Update Failed");
			return;
		} else {
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "update imp_layouts set ActiveFlag='N' where layoutid='"
					+ obj.getLayoutID() + "'";
			db.executeDML(query);
			db.endConnection();
			refreshPage();
			displayInfoMessageToUser("Layout Deactivated", "Deactivate");

		}
	}

	public void approve() {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "update imp_layouts set activeflag='Y',verified='Y',layout_status='WORKING',approveColumn='"+reason.replaceAll("\'", "''") + "' where layoutid='"
				+ this.selectedLayout.getLayoutID() + "'";
		db.executeDML(query);
		refreshPage();
		displayInfoMessageToUser("Layout Approved", "Approve");
	}

	public void checkindialog(Layout obj) {
		System.out.println("CHECKED IN");

		setSelectedLayout(obj);
		System.out.println("STATUS : " + obj.getLayoutstatus());
		if (obj.getLayoutstatus().compareTo("WORKING") == 0) {
			RequestContext.getCurrentInstance().execute(
					"PF('layoutworking').show();");
		} else {
			RequestContext.getCurrentInstance().execute(
					"PF('layoutfinal').show();");
		}
	}

	public Layout getSelectedLayout() {
		return selectedLayout;
	}

	public void setSelectedLayout(Layout selectedLayout) {
		System.out.println("Selecting Layout");
		this.selectedLayout = selectedLayout;
	}

	public void delete() {

		Layout layout = this.selectedLayout;

		ConnectDB db = new ConnectDB();
		db.initialize();
		String checkquery = "select count(clientid) from imp_clientpatterns where layoutid='"
				+ layout.getLayoutID()
				+ "' or ctl_layoutid='"
				+ layout.getLayoutID() + "'";
		System.out.println("Delete Query : " + checkquery);
		List<List<String>> rs = db.resultSetToListOfList(checkquery);
		if (rs.size() > 0) {
			if (Integer.parseInt(rs.get(1).get(0)) > 0) {
				displayErrorMessageToUser(
						"This Layout is used by clients.Cannot be deleted",
						"Delete");
				return;
			}
		}

		String result = "";
		try {
			result = db.executeDML("DELETE FROM IMP_LAYOUTS WHERE "
					+ " LAYOUTID='" + layout.getLayoutID() + "'");
			this.layoutid = "";
			refreshPage();
		} catch (Exception ex) {
			log.debug("Delete Layout Exception : " + ex.toString());
		}

		FacesMessage msg = null;

		if (result.equalsIgnoreCase("1")) {

			msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Delete layout",
					"Success");
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error occured", result);

		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
		db.endConnection();
	}

	public void setLayout(Layout obj) {
		System.out.println("SETTING LAYOUT");
		this.selectedLayout = obj;

	}

	@PreDestroy
	public void destroy() {

		System.out.println("DESTROYED");
	}

	public DefaultStreamedContent getDownloadDupDet() {
		return downloadDupDet;
	}

	public void setDownloadDupDet(DefaultStreamedContent downloadDupDet) {
		this.downloadDupDet = downloadDupDet;
	}

	public void refreshPage() {
		if (!this.layoutid.isEmpty()) {
			handleSubmit();
		} else {
			this.layouts = new ArrayList<>();
		}
	}

	public void openLayouteditframework() {
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 650);
		options.put("height", 450);
		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 600);
		options.put("contentHeight", 400);
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		String layoutid = this.selectedLayout.getLayoutID();
		List<String> list1 = new ArrayList<String>();
		list1.add(layoutid);
		params.put("lid", list1);
		RequestContext.getCurrentInstance().openDialog("utilities", options,
				params);// ,options,null);
	}
	public void closeLayoutEditForm(){
		
		RequestContext.getCurrentInstance().closeDialog("utilities");
		refreshPage();
	}

	public void afterLayoutedit() {
		refreshPage();
	}
}
