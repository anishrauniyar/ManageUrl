/* 
 *Class Name : EditProfiler.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dataprofiler;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.bean.ViewScoped;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;

import com.vit.ai.dataprofiler.model.StatsCheck;

/**
 * @author Aashish Dhungana
 * 
 *         Controller for Edit Checks for DP
 * 
 * @version 1.0 12 July 2015
 */
@ManagedBean
@ViewScoped
public class EditProfiler extends AddProfiler implements Serializable {
	static Logger log = Logger.getLogger(EditProfiler.class.getName());
	private static final long serialVersionUID = -668325629658887577L;
	private boolean valueModified = false;
	private boolean requiredModified = false;

	public EditProfiler() {

		init();
	}

	/**
	 * @LocalParams
	 * 
	 *              index : Index of the enabled checks arrays when edit is
	 *              requested on individual checks.
	 * 
	 *              listOfAvailableChecks : list of valid checks for a category
	 *              - list of enabled checks for that field.
	 * 
	 *              listofSelectedChecks : list of checks set for operation.
	 * 
	 *              type : GLOBAL/CLIENT/PATERN
	 * 
	 *              csvValues : valid value checks values.
	 */
	@Override
	public void init() {

		String index = "";

		this.csvValues = "No Values added";

		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();

		this.statchk = (StatsCheck) sessionMap.get("statscheck");

		this.type = FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("type");

		this.setClientid(FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("clid"));

		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("index") != null) {
			index = FacesContext.getCurrentInstance().getExternalContext()
					.getRequestParameterMap().get("index");
		}

		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("sn") != null) {
			this.patternsn = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("sn");
		}

		this.listOfAvailableChecks = new ArrayList<>();
		this.listOfEnabledChecks = new ArrayList<>();

		this.dataType = this.statchk.getDatatype();
		this.businessname = this.statchk.getBusinessname();

		this.fieldsn = statchk.getSn();
		this.category = statchk.getCategory();
		this.layoutid = statchk.getLayoutid();
		this.listOfEnabledChecks = statchk.getChecks();
		this.listOfSelectedChecks = new ArrayList<>();

		if (index.isEmpty()) {
			/**
			 * If index is empty, request is from edit all option.
			 */
			this.listOfSelectedChecks.addAll(this.listOfEnabledChecks);
		} else {
			this.listOfSelectedChecks.add(this.statchk.getChecks().get(
					Integer.parseInt(index)));
		}

		if (!this.listOfSelectedChecks.isEmpty()) {
			if (this.listOfSelectedChecks.get(0).isRequired()) {
				this.required = true;
			}
		}

	}

	/**
	 * @param status
	 *            = type of request(this.type)
	 * 
	 *            Method that updates all the active checks if required flag is
	 *            modified
	 */
	public void updateAll(String status) {

		for (int i = 0; i < listOfEnabledChecks.size(); i++) {
			if (this.required) {
				this.listOfEnabledChecks.get(i).setRequired(true);
			} else {
				this.listOfEnabledChecks.get(i).setRequired(false);
			}

			if (this.listOfEnabledChecks.get(i).getSelectedValueType()
					.compareTo("LIST") == 0) {

				listOfEnabledChecks.get(i).enableCheck(status,
						getUserinfo().getFullname(), this.fieldsn,
						this.layoutid, this.clientid, true, this.patternsn);
				this.valueModified = false;

			} else {

				listOfEnabledChecks.get(i).enableCheck(status,
						getUserinfo().getFullname(), this.fieldsn,
						this.layoutid, this.clientid, true, this.patternsn);
			}

		}
	}

	/**
	 * @param status
	 * 
	 *            Method that performs edit function for profiler checks
	 */
	public void editChecks(String status) {

		if (!this.listOfSelectedChecks.isEmpty()) {

			if (this.isRequiredModified()) {
				updateAll(status);
			}

			else {

				for (int i = 0; i < listOfSelectedChecks.size(); i++) {

					if (listOfSelectedChecks.get(i).isModified())

					{

						if (this.listOfSelectedChecks.get(i)
								.getSelectedValueType().compareTo("LIST") == 0) {

							if (valueModified) {
								listOfSelectedChecks.get(i).enableCheck(status,
										getUserinfo().getFullname(),
										this.fieldsn, this.layoutid,
										this.clientid, true, this.patternsn);
								this.valueModified = false;
							} else {
								listOfSelectedChecks.get(i).enableCheck(status,
										getUserinfo().getFullname(),
										this.fieldsn, this.layoutid,
										this.clientid, true, this.patternsn);
							}

						} else {

							listOfSelectedChecks.get(i).enableCheck(status,
									getUserinfo().getFullname(), this.fieldsn,
									this.layoutid, this.clientid, true,
									this.patternsn);
						}

					}
				}
			}

			displayInfoMessageToUser("CHECKS UPDATED", "DATA PROFILER");
			RequestContext.getCurrentInstance().closeDialog("editProfiler");
		}

	}

	public boolean isValueModified() {
		return valueModified;
	}

	public void setValueModified(boolean valueModified) {
		this.valueModified = valueModified;
	}

	public boolean isRequiredModified() {
		return requiredModified;
	}

	public void setRequiredModified(boolean requiredModified) {
		this.requiredModified = requiredModified;
	}

}
