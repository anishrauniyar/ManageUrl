/* 
 *Class Name : ViewProfiler.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dataprofiler;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.vit.ai.dataprofiler.model.StatsCheck;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 13 July 2015
 */
@ManagedBean
@ViewScoped
public class ViewProfiler extends AddProfiler implements Serializable {

	private static final long serialVersionUID = -743393136542665780L;

	public ViewProfiler() {

	}

	@PostConstruct
	public void init() {
		String index = "";
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		this.statchk = (StatsCheck) sessionMap.get("statscheck");
		this.type = FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("type");
		this.setClientid(FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("clid"));
		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("index") != null) {
			index = FacesContext.getCurrentInstance().getExternalContext()
					.getRequestParameterMap().get("index");
		}

		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("sn") != null) {
			this.patternsn = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("sn");
		}

		this.listOfAvailableChecks = new ArrayList<>();
		this.listOfEnabledChecks = new ArrayList<>();

		this.dataType = this.statchk.getDatatype();
		this.businessname = this.statchk.getBusinessname();
		
		this.fieldsn = statchk.getSn();
		this.category = statchk.getCategory();
		this.layoutid = statchk.getLayoutid();
		this.listOfEnabledChecks = statchk.getChecks();
		this.listOfSelectedChecks = new ArrayList<>();
		if (index.isEmpty()) {
			this.listOfSelectedChecks.addAll(this.listOfEnabledChecks);
		} else {
			this.listOfSelectedChecks.add(this.statchk.getChecks().get(
					Integer.parseInt(index)));
		}

	}

}
