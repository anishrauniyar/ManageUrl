/* 
 *Class Name : StatsCheck.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dataprofiler.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 10 Dec 2014
 */
public class StatsCheck implements Serializable {

	private static final long serialVersionUID = 2548158465508633196L;
	private String layoutid, sublayoutid, columnid, columnname, datatype,
			category;
	private String previousCategory = "";
	private String businessname = "";
	private String semanticname = "";
	private String sn;
	private boolean allowMoreChecks = true;
	private ArrayList<CheckList> checks;
	private int noOfChecks = 0;

	private String concatenatedEnabledchecks = "";

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public String getSublayoutid() {
		return sublayoutid;
	}

	public void setSublayoutid(String sublayoutid) {
		this.sublayoutid = sublayoutid;
	}

	public String getColumnid() {
		return columnid;
	}

	public void setColumnid(String columnid) {
		this.columnid = columnid;
	}

	public String getColumnname() {
		return columnname;
	}

	public void setColumnname(String columnname) {
		this.columnname = columnname;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public StatsCheck(String layoutid, String sublayoutid, String columnid,
			String columnname, String datatype, String category, String sn,
			String businessname, String semanticname) {
		this.checks = new ArrayList<>();

		this.layoutid = layoutid;
		this.sublayoutid = sublayoutid;
		this.columnid = columnid;
		this.columnname = columnname;
		this.businessname = businessname;
		this.datatype = datatype;

		if (category.isEmpty()) {
			category = remapCategory();
		}

		this.category = category;

		this.previousCategory = category;
		this.sn = sn;
		this.semanticname = semanticname;

	}

	/* Find appropriate category if category is not pre populated */
	public String remapCategory() {
		String category = "";

		String query = "SELECT a.DATATYPE_NAME,b.CATEGORY_NAME FROM dp_catgry_datatype_mapping a left JOIN DP_CHECK_CATEGORIES  b ON   a.cat_sn = b.cat_sn where  a.DATATYPE_NAME='"
				+ this.datatype + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				category = rs.get(1).get(1);
			} else {
				category = this.datatype;
			}
		}
		return category;

	}

	public void makeListofchecks(ArrayList<CheckList> checkstoconcatenate) {
		for (int i = 0; i < checkstoconcatenate.size(); i++) {
			this.concatenatedEnabledchecks = this.concatenatedEnabledchecks
					+ "," + checks.get(i).getCheckName();
		}

		if (!this.concatenatedEnabledchecks.isEmpty()) {
			this.concatenatedEnabledchecks = this.concatenatedEnabledchecks
					.substring(1);

		}

	}

	public String getConcatenatedEnabledchecks() {
		return concatenatedEnabledchecks;
	}

	public void setConcatenatedEnabledchecks(String concatenatedEnabledchecks) {
		this.concatenatedEnabledchecks = concatenatedEnabledchecks;
	}

	public ArrayList<CheckList> getChecks() {
		return checks;
	}

	public void setChecks(ArrayList<CheckList> checks) {
		this.checks = checks;
		setAllowMoreChecks(allowMoreChecks);
		makeListofchecks(this.checks);
		this.setNoOfChecks(getNumberofChecks());
	}

	/* Get total number of checks excluding checks that are disabled */
	public int getNumberofChecks() {
		int count = 0;
		for (int i = 0; i < this.checks.size(); i++) {
			if (this.checks.get(i).isEnabled()) {
				count++;
			}
		}
		return count;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public boolean isAllowMoreChecks() {
		return allowMoreChecks;
	}

	public void setAllowMoreChecks(boolean allowMoreChecks) {
		ArrayList<String> noOfChecks = new ArrayList<>();
		String query = "SELECT  a.MAS_ID,a.NAME, a.SYS_DFLT_THRSHLD ,a. SHORT_DESCRIPTION, b.DEFAULT_FLAG  FROM  dp_checks_master a left JOIN dp_catgry_chk_list b ON a.mas_id=b.mas_id WHERE b.cat_sn=(SELECT cat_sn FROM dp_check_categories"
				+ " WHERE CATEGORY_NAME='"
				+ this.category
				+ "' ) and a.is_enabled='1'";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					noOfChecks.add(rs.get(i).get(0));
				}
			}
		}

		if (noOfChecks.size() == this.checks.size()) {

			allowMoreChecks = false;
		} else {
			allowMoreChecks = true;
		}
		this.allowMoreChecks = allowMoreChecks;
	}

	public int getNoOfChecks() {
		return noOfChecks;
	}

	public void setNoOfChecks(int noOfChecks) {
		this.noOfChecks = noOfChecks;
	}

	public String getPreviousCategory() {
		return previousCategory;
	}

	public void setPreviousCategory(String previousCategory) {
		this.previousCategory = previousCategory;
	}

	public String getSemanticname() {
		return semanticname;
	}

	public void setSemanticname(String semanticname) {
		this.semanticname = semanticname;
	}

}
