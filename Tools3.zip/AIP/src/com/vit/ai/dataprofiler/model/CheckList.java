/* 
 *Class Name : CheckList.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dataprofiler.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 11 July 2015
 */
public class CheckList extends AbstractController implements Serializable {

	private static final long serialVersionUID = -131115786223784700L;
	private String checkid;
	private String checkName;
	private boolean enabled = false;
	private ArrayList<String> valueTypes;
	private String shortDesc;
	private boolean defaultCheck;
	private String selectedValueType = "";
	private String threshold = "";
	private String minValue = "";
	private String maxValue = "";
	private String value = "";
	private String layoutsn = "";
	private ArrayList<String> listOfValues;
	private boolean modified = false;
	private boolean valueType = true; // true if input types available is more
										// than 1
	private String csvvalues = "";
	private String checkLevel = "";
	private boolean required=false;
	
	private Date startDate;
	private Date endDate;

	
	
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCsvvalues() {
		return csvvalues;
	}

	public void setCsvvalues(String csvvalues) {
		this.csvvalues = csvvalues;
	}

	public String getMinValue() {
		return minValue;
	}

	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}

	public String getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}

	public String getCheckName() {
		return checkName;
	}

	public void setCheckName(String checkName) {
		this.checkName = checkName;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public void setValueTypes(ArrayList<String> valueTypes) {

		valueTypes = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select distinct(input_type) from dp_master_input_types where mas_id='"
				+ this.checkid + "' order by case  input_type when 'LIST' THEN '0' WHEN 'EQUAL' then '1' when 'NOT EQUAL' THEN '2' end";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					valueTypes.add(rs.get(i).get(0));
				}
			}
		}

		this.valueTypes = valueTypes;
		if (this.valueTypes.isEmpty()) {
			this.selectedValueType = "DEFAULT";

		} else {
			this.selectedValueType = this.valueTypes.get(0);
		}
		if (this.valueTypes.size() == 1) {
			this.valueType = false;
		} else {
			this.valueType = true;
		}
	}

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public boolean isDefaultCheck() {
		return defaultCheck;
	}

	public void setDefaultCheck(boolean defaultCheck) {
		this.defaultCheck = defaultCheck;
	}

	public String getSelectedValueType() {
		return selectedValueType;
	}

	public void setSelectedValueType(String selectedValueType) {
		this.selectedValueType = selectedValueType;
	}

	public String getThreshold() {
		return threshold;
	}

	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ArrayList<String> getValueTypes() {
		return valueTypes;
	}

	public String getCheckid() {
		return checkid;
	}

	public void setCheckid(String checkid) {
		this.checkid = checkid;
		setValueTypes(this.valueTypes);
	}

	public String getLayoutsn() {
		return layoutsn;
	}

	public void setLayoutsn(String layoutsn) {
		this.layoutsn = layoutsn;
	}

	public boolean isValueType() {
		return valueType;
	}

	public void setValueType(boolean valueType) {
		this.valueType = valueType;
	}

	public ArrayList<String> getListOfValues() {
		return listOfValues;
	}

	public void setListOfValues(ArrayList<String> listOfValues) {
		this.listOfValues = new ArrayList<>();
		this.listOfValues = listOfValues;

		this.csvvalues = getCSVString(this.listOfValues);

	}

	public String getCSVString(ArrayList<String> values) {
		this.csvvalues = "";
		if (!values.isEmpty()) {

			for (int i = 0; i < values.size(); i++) {
				this.csvvalues = this.csvvalues + "\n" + values.get(i);
			}

			this.csvvalues = this.csvvalues.substring(1);
		}
		return this.csvvalues;
	}

	public String getCheckLevel() {
		return checkLevel;
	}

	public void setCheckLevel(String checkLevel) {
		this.checkLevel = checkLevel;
	}

	public void disableCheck(String status, String userlog, String field_sn,
			String layoutid, String clientid, String patternsn) {

		if (status.compareTo("GLOBAL") == 0) {
			String query = "select * from dp_layouts_configuration where lay_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_layouts_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where lay_sn='"
							+ this.layoutsn + "'";
					String stat = db.executeDML(queryupdate);
					db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			int check = inserttolayout(userlog, "0", field_sn, layoutid, false);
			if (check == 1) {
				displayInfoMessageToUser("CHECK DISABLED", "DISABLE");
				this.enabled = false;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		} else if (status.compareTo("CLIENT") == 0) {
			String query = "select * from dp_clients_configuration where cli_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_clients_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where cli_sn='"
							+ this.layoutsn + "'";
					String stat = db.executeDML(queryupdate);

					db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			int check = inserttoclient(userlog, "0", field_sn, layoutid,
					clientid, false);
			if (check == 1) {
				displayInfoMessageToUser("CHECK DISABLED", "DISABLE");
				this.enabled = false;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		} else if (status.compareTo("PATTERN") == 0) {
			String query = "select * from dp_patterns_configuration where pat_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_patterns_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where pat_sn='"
							+ this.layoutsn + "'";
					String stat = db.executeDML(queryupdate);

					db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			int check = inserttopattern(userlog, "0", field_sn, layoutid,
					clientid, false, patternsn);
			if (check == 1) {
				displayInfoMessageToUser("CHECK DISABLED", "DISABLE");
				this.enabled = false;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		}

	}

	public void enableCheck(String status, String userlog, String field_sn,
			String layoutid, String clientid, String patternsn) {

		if (this.selectedValueType.compareTo("RANGE") == 0) {
			if (Integer.parseInt(this.getMinValue()) > Integer.parseInt(this
					.getMaxValue())) {

				displayErrorMessageToUser(
						"Minimum value cannot be greater than maximum", "ERROR");
				return;
			}
		}

		if (status.compareTo("GLOBAL") == 0) {
			String query = "select * from dp_layouts_configuration where lay_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_layouts_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where lay_sn='"
							+ this.layoutsn + "'";

					String stat = db.executeDML(queryupdate);
					db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			int check = inserttolayout(userlog, "1", field_sn, layoutid, false);
			if (check == 1) {
				displayInfoMessageToUser("CHECK ENABLED", "ENABLE");
				this.enabled = true;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		} else if (status.compareTo("CLIENT") == 0) {
			String query = "select * from dp_clients_configuration where cli_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_clients_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where cli_sn='"
							+ this.layoutsn + "'";

					String stat = db.executeDML(queryupdate);

					db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			int check = inserttoclient(userlog, "1", field_sn, layoutid,
					clientid, false);
			if (check == 1) {
				displayInfoMessageToUser("CHECK ENABLED", "ENABLE");
				this.enabled = true;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		} else if (status.compareTo("PATTERN") == 0) {
			String query = "select * from dp_patterns_configuration where pat_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_patterns_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where pat_sn='"
							+ this.layoutsn + "'";

					String stat = db.executeDML(queryupdate);

					db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			int check = inserttopattern(userlog, "1", field_sn, layoutid,
					clientid, false, patternsn);
			if (check == 1) {
				displayInfoMessageToUser("CHECK ENABLED", "ENABLE");
				this.enabled = true;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		}

	}

	public void enableCheck(String status, String userlog, String field_sn,
			String layoutid, String clientid, boolean edit, String patternsn) {

		if (this.selectedValueType.compareTo("RANGE") == 0) {

			if (Integer.parseInt(this.getMinValue()) > Integer.parseInt(this
					.getMaxValue())) {
				displayErrorMessageToUser(
						"Minimum value cannot be greater than maximum", "ERROR");
				return;
			}
		}

		if (status.compareTo("GLOBAL") == 0) {
			String query = "select * from dp_layouts_configuration where lay_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_layouts_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where lay_sn='"
							+ this.layoutsn + "'";

					String stat = db.executeDML(queryupdate);
					// db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}

			if (this.selectedValueType.compareTo("LIST") == 0) {
				String queryval = "select * from dp_layout_values where lay_sn='"
						+ this.layoutsn + "'";

				rs = db.resultSetToListOfList(queryval);
				if (rs != null) {
					if (rs.size() > 1) {
						String queryupdate = "update dp_layout_values set updated_by='"
								+ userlog
								+ "',effective_to=sysdate,is_active='0' where lay_sn='"
								+ this.layoutsn + "'";

						String stat = db.executeDML(queryupdate);
						// db.endConnection();
						if (stat.compareTo("1") != 0) {
							displayErrorMessageToUser(
									"Could not complete the request.Please try again",
									"ERROR");
							return;
						}
					}
				}
			}
			db.endConnection();
			int check = inserttolayout(userlog, "1", field_sn, layoutid, true);
			if (check == 1) {
				displayInfoMessageToUser("CHECK ENABLED", "DISABLE");
				this.enabled = true;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		} else if (status.compareTo("CLIENT") == 0) {
			String query = "select * from dp_clients_configuration where cli_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_clients_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where cli_sn='"
							+ this.layoutsn + "'";

					String stat = db.executeDML(queryupdate);

					// db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			if (this.selectedValueType.compareTo("LIST") == 0) {
				String queryval = "select * from dp_client_values where cli_sn='"
						+ this.layoutsn + "'";

				rs = db.resultSetToListOfList(queryval);
				if (rs != null) {
					if (rs.size() > 1) {
						String queryupdate = "update dp_client_values set updated_by='"
								+ userlog
								+ "',effective_to=sysdate,is_active='0' where cli_sn='"
								+ this.layoutsn + "'";

						String stat = db.executeDML(queryupdate);
						// db.endConnection();
						if (stat.compareTo("1") != 0) {
							displayErrorMessageToUser(
									"Could not complete the request.Please try again",
									"ERROR");
							return;
						}
					}
				}
			}
			db.endConnection();
			int check = inserttoclient(userlog, "1", field_sn, layoutid,
					clientid, true);
			if (check == 1) {
				displayInfoMessageToUser("CHECK DISABLED", "DISABLE");
				this.enabled = true;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		} else if (status.compareTo("PATTERN") == 0) {
			String query = "select * from dp_patterns_configuration where pat_sn='"
					+ this.layoutsn + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			if (rs != null) {
				if (rs.size() > 1) {
					String queryupdate = "update dp_patterns_configuration set updated_by='"
							+ userlog
							+ "',effective_to=sysdate where pat_sn='"
							+ this.layoutsn + "'";

					String stat = db.executeDML(queryupdate);

					// db.endConnection();
					if (stat.compareTo("1") != 0) {
						displayErrorMessageToUser(
								"Could not complete the request.Please try again",
								"ERROR");
						return;
					}
				}
			}
			if (this.selectedValueType.compareTo("LIST") == 0) {
				String queryval = "select * from dp_pat_values where pat_sn='"
						+ this.layoutsn + "'";

				rs = db.resultSetToListOfList(queryval);
				if (rs != null) {
					if (rs.size() > 1) {
						String queryupdate = "update dp_pat_values set updated_by='"
								+ userlog
								+ "',effective_to=sysdate,is_active='0' where pat_sn='"
								+ this.layoutsn + "'";

						String stat = db.executeDML(queryupdate);
						// db.endConnection();
						if (stat.compareTo("1") != 0) {
							displayErrorMessageToUser(
									"Could not complete the request.Please try again",
									"ERROR");
							return;
						}
					}
				}
			}
			db.endConnection();
			int check = inserttopattern(userlog, "1", field_sn, layoutid,
					clientid, true, patternsn);
			if (check == 1) {
				displayInfoMessageToUser("CHECK DISABLED", "DISABLE");
				this.enabled = true;

			} else {
				displayErrorMessageToUser("Update Failed.Please try again",
						"ERROR");
			}

		}

	}

	public int inserttolayout(String userlog, String is_enabled,
			String field_sn, String layoutid, boolean edit) {
		
		String requiredflag="N";
		if(this.required)
		{
			requiredflag="Y";
		}
		ConnectDB db = new ConnectDB();
		db.initialize();
		int lay_sn = 0;
		String snquery = "SELECT dp_lay_config_seq.NEXTVAL FROM dual";
		List<List<String>> rs = db.resultSetToListOfList(snquery);
		if (rs != null) {
			if (rs.size() > 1) {
				lay_sn = Integer.parseInt(rs.get(1).get(0));
				if (this.getSelectedValueType().isEmpty()) {
					this.setSelectedValueType("DEFAULT");
				} else if (this.getSelectedValueType().compareTo("RANGE") == 0) {

					if (Integer.parseInt(this.getMinValue()) > Integer
							.parseInt(this.getMaxValue())) {
						displayErrorMessageToUser(
								"Minimum value cannot be greater than maximum",
								"ERROR");
						return 0;
					}
					value = this.getMinValue() + "TO" + this.getMaxValue();

				} else if (this.getSelectedValueType().compareTo("EQUAL") == 0
						|| this.getSelectedValueType().compareTo("NOT EQUAL") == 0) {
					value = this.getValue().replaceAll("\'", "\'\'");
				} else {

					value = ""; 
				}

				String insertintomain = "INSERT INTO dp_layouts_configuration(lay_sn, mas_id, field_sn, layoutid, is_enabled, user_log,"
						+ " date_created, input_type, threshold,input_detail,effective_from,requiredflag) VALUES('"
						+ lay_sn
						+ "','"
						+ this.getCheckid()
						+ "','"

						+ field_sn
						+ "','"
						+ layoutid
						+ "','"
						+ is_enabled
						+ "','"
						+ userlog
						+ "',"
						+ "SYSDATE"
						+ ",'"
						+ this.getSelectedValueType()
						+ "','"
						+ this.getThreshold() + "','" + value + "',sysdate,'"+requiredflag+"')";
				String checkstat = db.executeDML(insertintomain);
				this.layoutsn = String.valueOf(lay_sn);
				if (edit && this.selectedValueType.compareTo("LIST") == 0) {
					inserttodetailslayout(lay_sn, db, userlog);
				}
				db.endConnection();

				if (checkstat.compareTo("1") != 0) {
					return 0;
				}
			}

		}
		return 1;
	}

	public void inserttodetailslayout(int sn, ConnectDB db, String userlog) {

		for (int i = 0; i < this.getListOfValues().size(); i++) {
			
			if(this.listOfValues.get(i).trim().compareTo(" ")!=0 && !this.listOfValues.get(i).trim().isEmpty())
			{
			String insertdetails = "INSERT INTO DP_LAYOUT_VALUES(lay_sn, value_list,created_date, created_by, is_active,effective_from)"
					+ "values('"
					+ sn
					+ "','"
					+ this.getListOfValues().get(i).replaceAll("\'", "\'\'").trim()
					+ "',sysdate" + ",'" + userlog + "','1',sysdate)";
			db.executeDML(insertdetails);

		}
		}
	}

	public void inserttodetailsclient(int sn, ConnectDB db, String userlog) {

		for (int i = 0; i < this.getListOfValues().size(); i++) {

			if(this.listOfValues.get(i).trim().compareTo(" ")!=0 && !this.listOfValues.get(i).trim().isEmpty())
			{
			String insertdetails = "INSERT INTO DP_CLIENT_VALUES(cli_sn, value_list,created_date, created_by, is_active,effective_from)"
					+ "values('"
					+ sn
					+ "','"
					+ this.getListOfValues().get(i).replaceAll("\'", "\'\'").trim()
					+ "',sysdate" + ",'" + userlog + "','1',sysdate)";
			db.executeDML(insertdetails);
			}

		}
	}

	public void inserttodetailspattern(int sn, ConnectDB db, String userlog) {

		for (int i = 0; i < this.getListOfValues().size(); i++) {

			if(this.listOfValues.get(i).trim().compareTo(" ")!=0 && !this.listOfValues.get(i).trim().isEmpty())
			{
			String insertdetails = "INSERT INTO DP_pat_VALUES(pat_sn, value_list,created_date, created_by, is_active,effective_from)"
					+ "values('"
					+ sn
					+ "','"
					+ this.getListOfValues().get(i).replaceAll("\'", "\'\'").trim()
					+ "',sysdate" + ",'" + userlog + "','1',sysdate)";
			db.executeDML(insertdetails);
			}

		}
	}

	public int inserttoclient(String userlog, String is_enabled,
			String field_sn, String layoutid, String clientid, boolean edit) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		int lay_sn = 0;
		String requiredflag="N";
		if(this.required)
		{
			requiredflag="Y";
		}
		String snquery = "SELECT dp_cli_config_seq.NEXTVAL FROM dual";

		List<List<String>> rs = db.resultSetToListOfList(snquery);
		if (rs != null) {
			if (rs.size() > 1) {
				lay_sn = Integer.parseInt(rs.get(1).get(0));
				if (this.getSelectedValueType().isEmpty()) {
					this.setSelectedValueType("DEFAULT");
				}
				if (this.getSelectedValueType().compareTo("RANGE") == 0) {
					if (Integer.parseInt(this.getMinValue()) > Integer
							.parseInt(this.getMaxValue())) {
						displayErrorMessageToUser(
								"Minimum value cannot be greater than maximum",
								"ERROR");
						return 0;
					}
					value = this.getMinValue() + "TO" + this.getMaxValue();
					System.out.println("VALUE : " + value);
				}
				else if (this.getSelectedValueType().compareTo("EQUAL") == 0
						|| this.getSelectedValueType().compareTo("NOT EQUAL") == 0) {
					value = this.getValue().replaceAll("\'", "\'\'");
				} else {
					value = "";
				}

				String insertintomain = "INSERT INTO dp_clients_configuration(cli_sn, mas_id, field_sn, layoutid, is_enabled, user_log,"
						+ " date_created, input_type, threshold,input_detail,client_id,effective_from,requiredflag) VALUES('"
						+ lay_sn
						+ "','"
						+ this.getCheckid()
						+ "','"

						+ field_sn
						+ "','"
						+ layoutid
						+ "','"
						+ is_enabled
						+ "','"
						+ userlog
						+ "',"
						+ "SYSDATE"
						+ ",'"
						+ this.getSelectedValueType()
						+ "','"
						+ this.getThreshold()
						+ "','"
						+ value
						+ "','"
						+ clientid + "',sysdate,'"+requiredflag+"')";
				String checkstat = db.executeDML(insertintomain);
				
				System.out.println("Insert into client : " + insertintomain);

				this.layoutsn = String.valueOf(lay_sn);
				if (edit && this.selectedValueType.compareTo("LIST") == 0) {
					inserttodetailsclient(lay_sn, db, userlog);
				}
				db.endConnection();

				if (checkstat.compareTo("1") != 0) {
					return 0;
				}
			}

		}
		return 1;
	}

	public int inserttopattern(String userlog, String is_enabled,
			String field_sn, String layoutid, String clientid, boolean edit,
			String patternsn) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		int lay_sn = 0;
		String requiredflag="N";
		if(this.required)
		{
			requiredflag="Y";
		}
		String snquery = "SELECT dp_pat_config_seq.NEXTVAL FROM dual";

		List<List<String>> rs = db.resultSetToListOfList(snquery);
		if (rs != null) {
			if (rs.size() > 1) {
				lay_sn = Integer.parseInt(rs.get(1).get(0));
				if (this.getSelectedValueType().isEmpty()) {
					this.setSelectedValueType("DEFAULT");
				}
				if (this.getSelectedValueType().compareTo("RANGE") == 0) {

					if (Integer.parseInt(this.getMinValue()) > Integer
							.parseInt(this.getMaxValue())) {
						displayErrorMessageToUser(
								"Minimum value cannot be greater than maximum",
								"ERROR");
						return 0;
					}
					value = this.getMinValue() + "TO" + this.getMaxValue();
				}
				else if (this.getSelectedValueType().compareTo("EQUAL") == 0
						|| this.getSelectedValueType().compareTo("NOT EQUAL") == 0) {
					value = this.getValue().replaceAll("\'", "\'\'");
				} else {
					value = "";
				}

				String insertintomain = "INSERT INTO dp_patterns_configuration(pat_sn, mas_id, field_sn, layoutid, is_enabled, user_log,"
						+ " date_created, input_type, threshold,input_detail,client_id,effective_from,pattern_sn,requiredflag) VALUES('"
						+ lay_sn
						+ "','"
						+ this.getCheckid()
						+ "','"

						+ field_sn
						+ "','"
						+ layoutid
						+ "','"
						+ is_enabled
						+ "','"
						+ userlog
						+ "',"
						+ "SYSDATE"
						+ ",'"
						+ this.getSelectedValueType()
						+ "','"
						+ this.getThreshold()
						+ "','"
						+ value
						+ "','"
						+ clientid + "',sysdate,'" + patternsn + "','"+requiredflag+"')";
				String checkstat = db.executeDML(insertintomain);
				this.layoutsn = String.valueOf(lay_sn);

				if (edit && this.selectedValueType.compareTo("LIST") == 0) {
					inserttodetailspattern(lay_sn, db, userlog);
				}
				db.endConnection();

				if (checkstat.compareTo("1") != 0) {
					return 0;
				}
			}

		}
		return 1;
	}

	public boolean isModified() {
		return modified;
	}

	public void setModified(boolean modified) {
		this.modified = modified;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	

}
