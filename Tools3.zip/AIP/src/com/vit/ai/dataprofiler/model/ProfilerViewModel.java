package com.vit.ai.dataprofiler.model;

import java.io.Serializable;

public class ProfilerViewModel implements Serializable{

	private static final long serialVersionUID = -5304945869631771788L;
	private String sn;
	private String fileid;
	private String filename;
	private String importeddate;
	private String filedate;
	private String layoutid;
	private String clientid;
	private String empgrp;
	private String reportname;
	private String payor;
	private String approvedstatus;
	private String reportstatus;
	private String dpstatus;
	private String patternsn;
	private String clientname;
	private String datatype;
	private String startdate;
	private String enddate;
	private String exceptionremark;
	private String processDate;
	public String getFileid() {
		return fileid;
	}
	public void setFileid(String fileid) {
		this.fileid = fileid;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getImporteddate() {
		return importeddate;
	}
	public void setImporteddate(String importeddate) {
		this.importeddate = importeddate;
	}
	public String getLayoutid() {
		return layoutid;
	}
	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}
	public String getClientid() {
		return clientid;
	}
	public void setClientid(String clientid) {
		this.clientid = clientid;
	}
	public String getEmpgrp() {
		return empgrp;
	}
	public void setEmpgrp(String empgrp) {
		this.empgrp = empgrp;
	}
	public String getReportname() {
		return reportname;
	}
	public void setReportname(String reportname) {
		this.reportname = reportname;
	}
	public String getPayor() {
		return payor;
	}
	public void setPayor(String payor) {
		this.payor = payor;
	}
	public String getApprovedstatus() {
		return approvedstatus;
	}
	public void setApprovedstatus(String approvedstatus) {
		this.approvedstatus = approvedstatus;
	}
	public String getReportstatus() {
		return reportstatus;
	}
	public void setReportstatus(String reportstatus) {
		this.reportstatus = reportstatus;
	}
	public String getDpstatus() {
		return dpstatus;
	}
	public void setDpstatus(String dpstatus) {
		this.dpstatus = dpstatus;
	}
	
	public ProfilerViewModel(String fileid,String filename,String reportname,String payor,String layoutid,String clientid,String empgrp,String rptstatus,String dpstatus,String importeddate,String approved,String patternsn,String filedate,String sn,String clientname,String datatype,String startdate,String enddate,String exceptionremark,String processDate)
	
	{
		this.fileid=fileid;
		this.filename=filename;
		this.reportname=reportname;
		this.payor=payor;
		this.layoutid=layoutid;
		this.clientid=clientid;
		this.empgrp=empgrp;
		this.reportstatus=rptstatus;
		this.dpstatus=dpstatus;
		this.importeddate=importeddate;
		this.approvedstatus=approved;
		this.patternsn=patternsn;
		this.filedate=filedate;
		this.sn=sn;
		this.clientname=clientname;
		this.startdate=startdate;
		this.enddate=enddate;
		this.exceptionremark=exceptionremark;
		this.processDate=processDate;
		this.setDatatype(datatype);
	}
	public String getPatternsn() {
		return patternsn;
	}
	public void setPatternsn(String patternsn) {
		this.patternsn = patternsn;
	}
	public String getFiledate() {
		return filedate;
	}
	public void setFiledate(String filedate) {
		this.filedate = filedate;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getClientname() {
		return clientname;
	}
	public void setClientname(String clientname) {
		this.clientname = clientname;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getExceptionremark() {
		return exceptionremark;
	}
	public void setExceptionremark(String exceptionremark) {
		this.exceptionremark = exceptionremark;
	}
	public String getProcessDate() {
		return processDate;
	}
	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}
	

}
