/* 
 *Class Name : AddProfiler.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dataprofiler;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import com.vit.ai.dataprofiler.model.CheckList;
import com.vit.ai.dataprofiler.model.StatsCheck;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 12 Jul 2015
 */
@ManagedBean
@ViewScoped
public class AddProfiler extends AbstractController implements Serializable {

	static Logger log = Logger.getLogger(AddProfiler.class.getName());
	protected static final long serialVersionUID = -7460336445138219636L;
	protected boolean selectedCheck;
	protected ArrayList<String> listofChecks;
	protected ArrayList<String> listofClients;
	protected ArrayList<String> listofFilePatterns;
	protected String patternsn;

	protected String selectedClient = "";
	protected String selectedFilePatterns = "";
	protected String type = "";
	protected String clientid = "";
	protected String filepattern = "";
	protected String dataType = "";
	protected String businessname = "";
	protected String fieldsn;
	protected String category = "";
	protected boolean isClient = false;
	protected boolean isFile = false;
	protected boolean selectall = false;
	@ManagedProperty(value = "#{userInformation}")
	protected UserInformation userinfo;
	protected StatsCheck statchk;
	protected String csvValues = "";
	protected CheckList selectedCheckObj;
	protected boolean required = false;
	
	protected Date todaysDate;

	
	
	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	protected ArrayList<CheckList> listOfAvailableChecks;
	protected ArrayList<CheckList> listOfSelectedChecks;

	public void setListOfAvailableChecks(
			ArrayList<CheckList> listOfAvailableChecks) {
		this.listOfAvailableChecks = listOfAvailableChecks;
	}

	protected ArrayList<CheckList> listOfEnabledChecks;

	public ArrayList<CheckList> getListOfAvailableChecks() {
		return listOfAvailableChecks;
	}

	public ArrayList<CheckList> getListOfEnabledChecks() {
		return listOfEnabledChecks;
	}

	public void setListOfEnabledChecks(ArrayList<CheckList> listOfEnabledChecks) {
		this.listOfEnabledChecks = listOfEnabledChecks;
	}

	public String getSelectedClient() {
		return selectedClient;
	}

	public void setSelectedClient(String selectedClient) {
		this.selectedClient = selectedClient;
	}

	public String getSelectedFilePatterns() {
		return selectedFilePatterns;
	}

	public void setSelectedFilePatterns(String selectedFilePatterns) {
		this.selectedFilePatterns = selectedFilePatterns;
	}

	protected String layoutid;

	public ArrayList<String> getListofChecks() {
		return listofChecks;
	}

	public void setListofChecks(ArrayList<String> listofChecks) {
		this.listofChecks = listofChecks;
	}

	public ArrayList<String> getListofClients() {
		return listofClients;
	}

	public void setListofClients(ArrayList<String> listofClients) {
		this.listofClients = listofClients;
	}

	public ArrayList<String> getListofFilePatterns() {
		return listofFilePatterns;
	}

	public void setListofFilePatterns(ArrayList<String> listofFilePatterns) {
		this.listofFilePatterns = listofFilePatterns;
	}

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public boolean getSelectedCheck() {
		return selectedCheck;
	}

	public void setSelectedCheck(boolean selectedCheck) {
		this.selectedCheck = selectedCheck;
	}

	public AddProfiler() {
		setTodaysDate(new Date());
	}

	@PostConstruct
	public void init() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		this.statchk = (StatsCheck) sessionMap.get("statscheck");
		this.type = FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("type");
		this.setClientid(FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("clid"));
		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("sn") != null) {
			this.patternsn = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("sn");
		}

		log.info("--INITIALIING ADD PROFILER --"
				+ this.getUserinfo().getFullname());
		log.info("LAYOUT ID : " + this.statchk.getLayoutid());
		log.info("TYPE : " + this.type);
		log.info("CLIENTID : " + this.clientid);
		log.info("Pattern sn : " + this.patternsn);
		this.listOfAvailableChecks = new ArrayList<>();
		this.listOfEnabledChecks = new ArrayList<>();

		this.dataType = this.statchk.getDatatype();
		this.businessname = this.statchk.getBusinessname();
		this.fieldsn = statchk.getSn();
		this.category = statchk.getCategory();
		this.layoutid = statchk.getLayoutid();
		this.listOfEnabledChecks = statchk.getChecks();
		this.listOfSelectedChecks = new ArrayList<>();

		getAllChecks();
		removeEnabledChecksforAdd();

	}

	public ArrayList<CheckList> getAllChecks() {

		String query = "SELECT  a.MAS_ID,a.NAME, a.SYS_DFLT_THRSHLD ,a. SHORT_DESCRIPTION, b.DEFAULT_FLAG  FROM  dp_checks_master a left JOIN dp_catgry_chk_list b ON a.mas_id=b.mas_id WHERE b.cat_sn=(SELECT cat_sn FROM dp_check_categories"
				+ " WHERE CATEGORY_NAME='"
				+ this.category
				+ "' ) and a.is_enabled='1'";
		log.info("GETTING ALL CHECKS---" + query);

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					CheckList obj = new CheckList();
					obj.setCheckid(rs.get(i).get(0));
					obj.setCheckName(rs.get(i).get(1));
					obj.setThreshold(rs.get(i).get(2));
					obj.setShortDesc(rs.get(i).get(3));

					if (rs.get(i).get(4).compareTo("1") == 0) {
						obj.setDefaultCheck(true);

					}
					this.listOfAvailableChecks.add(obj);

				}

				log.info("TOTAL AVAILABLE CHECKS : "
						+ this.listOfAvailableChecks.size());
			} else {
				log.error("CATEGORY NOT DEFINED : ");
				displayErrorMessageToUser("Category not defined", "ERROR");
			}
		}

		return this.listOfAvailableChecks;

	}

	/**
	 * Method that removes the already enabled checks from the list of available
	 * checks
	 */
	public void removeEnabledChecksforAdd() {
		int count = 0;

		ArrayList<CheckList> availableChecks = new ArrayList<>();

		for (int i = 0; i < listOfAvailableChecks.size(); i++) {
			for (int j = 0; j < this.listOfEnabledChecks.size(); j++) {

				if (this.listOfEnabledChecks.get(j).isRequired()) {
					this.required = true;
				} else {
					this.required = false;
				}

				if (this.listOfAvailableChecks
						.get(i)
						.getCheckid()
						.compareTo(this.listOfEnabledChecks.get(j).getCheckid()) == 0) {
					// Skip equal objects

					count++;

				}

			}
			if (count == 0) {
				availableChecks.add(this.listOfAvailableChecks.get(i));

			} else {
				count = 0;
			}
		}
		this.listOfAvailableChecks = availableChecks;

	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getFilepattern() {
		return filepattern;
	}

	public void setFilepattern(String filepattern) {
		this.filepattern = filepattern;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getFieldsn() {
		return fieldsn;
	}

	public void setFieldsn(String fieldsn) {
		this.fieldsn = fieldsn;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public ArrayList<CheckList> getListOfSelectedChecks() {
		return listOfSelectedChecks;
	}

	public void setListOfSelectedChecks(
			ArrayList<CheckList> listOfSelectedChecks) {
		this.listOfSelectedChecks = listOfSelectedChecks;
	}

	public void manageChecks(CheckList obj) {

		if (!this.selectedCheck) {
			if (!obj.isDefaultCheck()) {
				removeChecks(obj);
			} else {
				displayErrorMessageToUser("Default check cannot be disabled",
						"Invalid Request");
			}
		} else {
			addChecks(obj);
		}
	}

	public void addChecks(CheckList obj) {

		this.listOfSelectedChecks.add(obj);
	}

	public void removeChecks(CheckList obj) {
		this.listOfSelectedChecks.remove(obj);
	}

	public void addGlobalChecks() {

		int lay_sn = 0;

		String value = "";
		String requiredflag = "N";
		ConnectDB db = new ConnectDB();
		db.initialize();
		if (this.listOfSelectedChecks.size() > 0) {
			try {

				for (CheckList obj : this.listOfSelectedChecks) {
					String snquery = "SELECT dp_lay_config_seq.NEXTVAL FROM dual";

					List<List<String>> rs = db.resultSetToListOfList(snquery);
					if (rs != null) {
						if (rs.size() > 1) {
							lay_sn = Integer.parseInt(rs.get(1).get(0));
							if (obj.getSelectedValueType().isEmpty()) {
								obj.setSelectedValueType("DEFAULT");
							}

							if (this.required) {
								obj.setRequired(true);
								requiredflag = "Y";
							} else {
								obj.setRequired(false);
							}
							if (obj.getSelectedValueType().compareTo("RANGE") == 0) {
								if (Integer.parseInt(obj.getMinValue()) > Integer
										.parseInt(obj.getMaxValue())) {
									displayErrorMessageToUser(
											"Minimum value cannot be greater than maximum",
											"ERROR");
									return;
								}
								value = obj.getMinValue() + "TO"
										+ obj.getMaxValue();

							}
							if (obj.getSelectedValueType().compareTo("EQUAL") == 0
									|| obj.getSelectedValueType().compareTo(
											"NOT EQUAL") == 0) {
								value = obj.getValue();
							}
							if (obj.getSelectedValueType().compareTo("DATERANGE") == 0) {
								log.info("This is a date range check.");
								Date startDate = obj.getStartDate();
								log.info("Start Date: " + startDate);
								Date endDate = obj.getEndDate();
								log.info("End Date: " +  endDate);
								String start = new SimpleDateFormat("yyyyMMddHHmmss").format(startDate);
								String end = new SimpleDateFormat("yyyyMMddHHmmss").format(endDate);
								value = start + "TO" + end;
							}

							String insertintomain = "INSERT INTO dp_layouts_configuration(lay_sn, mas_id, field_sn, layoutid, is_enabled, user_log,"
									+ " date_created, input_type, threshold,input_detail,effective_from,requiredFlag) VALUES('"
									+ lay_sn
									+ "','"
									+ obj.getCheckid()
									+ "','"

									+ this.getFieldsn()
									+ "','"
									+ this.layoutid
									+ "','1','"
									+ getUserinfo().getFullname()
									+ "',"
									+ "SYSDATE"
									+ ",'"
									+ obj.getSelectedValueType()
									+ "','"
									+ obj.getThreshold()
									+ "','"
									+ value
									+ "',sysdate,'" + requiredflag + "')";
							db.executeDML(insertintomain);

							if (obj.getSelectedValueType().compareTo("LIST") == 0) {
								insertintodetails(lay_sn, obj);
							}

						}

					} else {
						displayErrorMessageToUser("INSERT FAILED", "ERROR");
						break;

					}

				}
				RequestContext.getCurrentInstance().closeDialog("addProfiler");
				db.endConnection();
				displayInfoMessageToUser("GLOBAL CHECKS ADDED", "DATA PROFILER");

			} catch (Exception ex) {
				log.error("DATA PROFILER INSERT : " + ex.toString());
				displayErrorMessageToUser("INSERT FAILED", "ERROR");
			} finally {
				if (db != null) {
					db.endConnection();
				}
			}

		} else {
			displayErrorMessageToUser("No checks to add.", "ERROR");
		}

	}

	public void insertintodetails(int lay_sn, CheckList obj) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		for (int i = 0; i < obj.getListOfValues().size(); i++) {

			if (obj.getListOfValues().get(i).trim().compareTo(" ") != 0
					&& !obj.getListOfValues().get(i).trim().isEmpty()) {
				String insertdetails = "INSERT INTO DP_LAYOUT_VALUES(lay_sn, value_list,created_date, created_by, is_active,effective_from)"
						+ "values('"
						+ lay_sn
						+ "','"
						+ obj.getListOfValues().get(i).replaceAll("\'", "\'\'")
								.trim()
						+ "',sysdate"
						+ ",'"
						+ getUserinfo().getFullname() + "','1',sysdate)";
				db.executeDML(insertdetails);
			}
		}
		db.endConnection();
	}

	public void insertintodetailsclient(int lay_sn, CheckList obj, ConnectDB db) {
		for (int i = 0; i < obj.getListOfValues().size(); i++) {
			if (obj.getListOfValues().get(i).trim().compareTo(" ") != 0
					&& !obj.getListOfValues().get(i).trim().isEmpty()) {
				String insertdetails = "INSERT INTO DP_CLIENT_VALUES(cli_sn, value_list,created_date, created_by, is_active,effective_from)"
						+ "values('"
						+ lay_sn
						+ "','"
						+ obj.getListOfValues().get(i).replaceAll("\'", "\'\'")
								.trim()
						+ "',sysdate"
						+ ",'"
						+ getUserinfo().getFullname() + "','1',sysdate)";
				db.executeDML(insertdetails);
			}

		}
	}

	public void insertintodetailspattern(int lay_sn, CheckList obj, ConnectDB db) {

		for (int i = 0; i < obj.getListOfValues().size(); i++) {
			if (obj.getListOfValues().get(i).trim().compareTo(" ") != 0
					&& !obj.getListOfValues().get(i).trim().isEmpty()) {
				String insertdetails = "INSERT INTO DP_pat_VALUES(pat_sn, value_list,created_date, created_by, is_active,effective_from)"
						+ "values('"
						+ lay_sn
						+ "','"
						+ obj.getListOfValues().get(i).replaceAll("\'", "\'\'")
								.trim()
						+ "',sysdate"
						+ ",'"
						+ getUserinfo().getFullname() + "','1',sysdate)";
				db.executeDML(insertdetails);
			}

		}
	}

	public void addPatternChecks() {

		int lay_sn = 0;

		String value = "";
		String requiredflag = "N";
		ConnectDB db = new ConnectDB();
		db.initialize();
		if (this.listOfSelectedChecks.size() > 0) {
			try {

				for (CheckList obj : this.listOfSelectedChecks) {
					String snquery = "SELECT dp_pat_config_seq.NEXTVAL FROM dual";

					List<List<String>> rs = db.resultSetToListOfList(snquery);
					if (rs != null) {
						if (rs.size() > 1) {
							lay_sn = Integer.parseInt(rs.get(1).get(0));
							if (obj.getSelectedValueType().isEmpty()) {
								obj.setSelectedValueType("DEFAULT");
							}
							if (obj.getSelectedValueType().compareTo("RANGE") == 0) {
								if (Integer.parseInt(obj.getMinValue()) > Integer
										.parseInt(obj.getMaxValue())) {
									displayErrorMessageToUser(
											"Minimum value cannot be greater than maximum",
											"ERROR");
									return;
								}
								value = obj.getMinValue() + "TO"
										+ obj.getMaxValue();
							}
							if (obj.getSelectedValueType().compareTo("EQUAL") == 0
									|| obj.getSelectedValueType().compareTo(
											"NOT EQUAL") == 0) {
								value = obj.getValue();
							}
							if (this.required) {
								obj.setRequired(true);
								requiredflag = "Y";
							}

							String insertintomain = "INSERT INTO dp_patterns_configuration(pat_sn, mas_id, field_sn, layoutid, is_enabled, user_log,"
									+ " date_created, input_type, threshold,input_detail,client_id,effective_from,pattern_sn,requiredflag) VALUES('"
									+ lay_sn
									+ "','"
									+ obj.getCheckid()
									+ "','"

									+ this.getFieldsn()
									+ "','"
									+ this.layoutid
									+ "','1','"
									+ getUserinfo().getFullname()
									+ "',"
									+ "SYSDATE"
									+ ",'"
									+ obj.getSelectedValueType()
									+ "','"
									+ obj.getThreshold()
									+ "','"
									+ value
									+ "','"
									+ this.clientid
									+ "',sysdate,'"
									+ this.patternsn
									+ "','"
									+ requiredflag
									+ "')";
							db.executeDML(insertintomain);

							if (obj.getSelectedValueType().compareTo("LIST") == 0) {
								insertintodetailspattern(lay_sn, obj, db);
							}

						}

					} else {
						displayErrorMessageToUser("INSERT FAILED", "ERROR");
						break;

					}

				}
				db.endConnection();
				RequestContext.getCurrentInstance().closeDialog("addProfiler");
				displayInfoMessageToUser("CLIENT CHECKS ADDED", "DATA PROFILER");

			} catch (Exception ex) {

				log.error("DATA PROFILER INSERT : " + ex.toString());
				displayErrorMessageToUser("INSERT FAILED", "ERROR");
			} finally {
				if (db != null) {
					db.endConnection();
				}
			}

		} else {
			displayErrorMessageToUser("No checks to add.", "ERROR");
		}

	}

	public void addClientChecks() {

		int lay_sn = 0;
		String requiredflag = "N";
		String value = "";
		ConnectDB db = new ConnectDB();
		db.initialize();
		if (this.listOfSelectedChecks.size() > 0) {
			try {

				for (CheckList obj : this.listOfSelectedChecks) {
					String snquery = "SELECT dp_cli_config_seq.NEXTVAL FROM dual";

					List<List<String>> rs = db.resultSetToListOfList(snquery);
					if (rs != null) {
						if (rs.size() > 1) {
							lay_sn = Integer.parseInt(rs.get(1).get(0));
							if (obj.getSelectedValueType().isEmpty()) {
								obj.setSelectedValueType("DEFAULT");
							}
							if (obj.getSelectedValueType().compareTo("RANGE") == 0) {
								if (Integer.parseInt(obj.getMinValue()) > Integer
										.parseInt(obj.getMaxValue())) {
									displayErrorMessageToUser(
											"Minimum value cannot be greater than maximum",
											"ERROR");
									return;
								}
								value = obj.getMinValue() + "TO"
										+ obj.getMaxValue();
							}
							if (obj.getSelectedValueType().compareTo("EQUAL") == 0
									|| obj.getSelectedValueType().compareTo(
											"NOT EQUAL") == 0) {
								value = obj.getValue();
							}
							if (this.required) {
								obj.setRequired(true);
								requiredflag = "Y";
							}

							String insertintomain = "INSERT INTO dp_clients_configuration(cli_sn, mas_id, field_sn, layoutid, is_enabled, user_log,"
									+ " date_created, input_type, threshold,input_detail,client_id,effective_from,requiredflag) VALUES('"
									+ lay_sn
									+ "','"
									+ obj.getCheckid()
									+ "','"

									+ this.getFieldsn()
									+ "','"
									+ this.layoutid
									+ "','1','"
									+ getUserinfo().getFullname()
									+ "',"
									+ "SYSDATE"
									+ ",'"
									+ obj.getSelectedValueType()
									+ "','"
									+ obj.getThreshold()
									+ "','"
									+ value
									+ "','"
									+ this.clientid
									+ "',sysdate,'"
									+ requiredflag + "')";
							db.executeDML(insertintomain);

							if (obj.getSelectedValueType().compareTo("LIST") == 0) {
								insertintodetailsclient(lay_sn, obj, db);
							}

						}

					} else {
						displayErrorMessageToUser("INSERT FAILED", "ERROR");
						break;

					}

				}
				db.endConnection();
				RequestContext.getCurrentInstance().closeDialog("addProfiler");
				displayInfoMessageToUser("CLIENT CHECKS ADDED", "DATA PROFILER");

			} catch (Exception ex) {

				log.error("DATA PROFILER INSERT : " + ex.toString());
				displayErrorMessageToUser("INSERT FAILED", "ERROR");
			} finally {
				if (db != null) {
					db.endConnection();
				}
			}

		} else {
			displayErrorMessageToUser("No checks to add.", "ERROR");
		}

	}

	public boolean isClient() {
		return isClient;
	}

	public void setClient(boolean isClient) {
		this.isClient = isClient;
	}

	public boolean isFile() {
		return isFile;
	}

	public void setFile(boolean isFile) {
		this.isFile = isFile;
	}

	public void handleSelectAll() {
		if (this.selectall) {
			this.selectedCheck = true;

			this.listOfSelectedChecks.clear();
			this.listOfSelectedChecks.addAll(this.listOfAvailableChecks);

		} else {
			this.selectedCheck = false;

			this.listOfSelectedChecks.clear();

		}
	}

	public boolean isSelectall() {
		return selectall;
	}

	public void setSelectall(boolean selectall) {
		this.selectall = selectall;
	}

	public StatsCheck getStatchk() {
		return statchk;
	}

	public void setStatchk(StatsCheck statchk) {
		this.statchk = statchk;
	}

	public void handleAddValues(CheckList obj) {

		this.setSelectedCheckObj(obj);
		this.csvValues = this.selectedCheckObj.getCsvvalues();

		RequestContext.getCurrentInstance().execute("PF('addval').show();");
	}

	public CheckList getSelectedCheckObj() {
		return selectedCheckObj;
	}

	public void setSelectedCheckObj(CheckList selectedCheckObj) {
		this.selectedCheckObj = selectedCheckObj;
	}

	public String getCsvValues() {
		return csvValues;
	}

	public void setCsvValues(String csvValues) {
		this.csvValues = csvValues;
	}

	public void addValues() {
		if (this.csvValues.isEmpty()) {
			displayErrorMessageToUser("Values cannot be empty", "EMPTY VALUES");

			return;
		}
		if (csvValues.contains("\n")) {
			try {
				String[] lov = csvValues.split("\n");
				ArrayList<String> listofvalues = new ArrayList<>();
				for (int i = 0; i < lov.length; i++) {
					if (!lov[i].isEmpty()) {

						listofvalues.add(lov[i]);

					}

				}
				this.selectedCheckObj.setListOfValues(listofvalues);

			} catch (Exception ex) {
				log.error("DATA PROFILER INSERT VALUES : " + ex.toString());
				displayErrorMessageToUser("Could not Add", "ERROR");
				return;
			}

		} else {
			ArrayList<String> values = new ArrayList<>();
			values.add(this.csvValues);

			this.selectedCheckObj.setListOfValues(values);

		}

		RequestContext.getCurrentInstance().execute("PF('addval').hide();");
	}

	public String getPatternsn() {
		return patternsn;
	}

	public void setPatternsn(String patternsn) {
		this.patternsn = patternsn;
	}

	public void doNothing() {

	}

	public void setRequiredAll(String fieldsn) {

	}

}
