package com.vit.ai.dataprofiler;

import java.io.File;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.background.RegenerateDPReport;
import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.dataprofiler.model.ProfilerViewModel;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class ProfilerViewController extends AbstractController implements
		Serializable {
	private static final long serialVersionUID = 2310542434092713951L;
	
	private Logger log = Logger.getLogger(ProfilerViewController.class);
	
	private Date filestartdate;
	private Date fileenddate;
	private Date todaysDate;
	private ProfilerViewModel selectedReport;
	private ArrayList<ProfilerViewModel> listofFiles;
	private ArrayList<ProfilerViewModel> filteredValues;
	private DefaultStreamedContent downloadDPR;
	private String selectedfiltertype = "";
	private String client = "";
	private String reportID = "";
	private String releaseNum;
	protected ArrayList<String> reportsIDs;
	protected ArrayList<String> releaseNos;
	private String filtertype;
	protected LinkedHashMap<String, String> clients;
	private String reason = "";
	private String fileidselected = "";
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String winScreenHeight;
	private String fileID="";
	
	private String editReason;
	
	
	

	public String getEditReason() {
		return editReason;
	}

	public void setEditReason(String editReason) {
		this.editReason = editReason;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clientList = db
				.resultSetToListOfList("SELECT DISTINCT B.CLIENTID , A.CLIENTNAME FROM IMP_MAIN_LOG B JOIN HAWKEYEMASTER.M_CLIENTS A ON   A.CLIENTID=B.CLIENTID order by clientid asc");

		db.endConnection();

		if(clientList!=null)
		{
		if (clientList.size() > 0) {
			for (int i = 1; i < clientList.size(); i++) {
				clients.put(clientList.get(i).get(0) + "-("
						+ clientList.get(i).get(1) + ")", clientList.get(i)
						.get(0));
			}
			}
		}
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(String releaseNum) {
		this.releaseNum = releaseNum;
	}

	public ArrayList<String> getReportsIDs() {
		return reportsIDs;
	}

	public void setReportsIDs(ArrayList<String> reportsIDs) {
		String query = "SELECT REPORTID FROM  IMP_INVENTORY_REP_LOG where reporttype='INVENTORY' order by reportid desc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					reportsIDs.add(rs.get(i).get(0));
				}
			}
		}
	}

	public ArrayList<String> getReleaseNos() {
		return releaseNos;
	}

	public void setReleaseNos(ArrayList<String> releaseNos) {
		log.info("check");
		String query = "select  release_number from AIP_CYCLE_MASTER order by release_number desc";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					releaseNos.add(rs.get(i).get(0));
				}
			}
		}
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}

	public Date getFilestartdate() {
		return filestartdate;
	}

	public void setFilestartdate(Date filestartdate) {
		this.filestartdate = filestartdate;
	}

	public Date getFileenddate() {
		return fileenddate;
	}

	public void setFileenddate(Date fileenddate) {
		this.fileenddate = fileenddate;
	}

	public ArrayList<ProfilerViewModel> getListofFiles() {
		return listofFiles;
	}

	public void setListofFiles(ArrayList<ProfilerViewModel> listofFiles) {

		this.listofFiles = listofFiles;

	}

	public void setValue() {
		this.winScreenHeight = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("winScreenHeight");

	}

	public void handleLoad() {
		this.filteredValues = new ArrayList<>();
		this.listofFiles = new ArrayList<>();
		String query = "select * from (select fileid, filename, reportlocation, payor, layoutid, clientid, empgrp, reportstatus, dpstatus, importeddate, approvedstatus, patternsn, filedate,reportsn,clientname,datatype,startdate,enddate,exceptionremark,processdate from dp_dashboard_report_display ) where rownum<100";
		log.info(query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.listofFiles.add(new ProfilerViewModel(
							rs.get(i).get(0), rs.get(i).get(1), rs.get(i)
									.get(2), rs.get(i).get(3),
							rs.get(i).get(4), rs.get(i).get(5), rs.get(i)
									.get(6), rs.get(i).get(7),
							rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(
									10), rs.get(i).get(11), rs.get(i).get(12),
							rs.get(i).get(13), rs.get(i).get(14), rs.get(i)
									.get(15), rs.get(i).get(16), rs.get(i).get(
									17), rs.get(i).get(18), rs.get(i).get(19)));
				}

			}

			setListofFiles(this.listofFiles);
			setFilteredValues(this.listofFiles);
		}
	}

	public void init() {
		handleLoad();

		/*
		 * if(FacesContext.getCurrentInstance().getRenderResponse()) {
		 * 
		 * RequestContext.getCurrentInstance().execute(
		 * "jQuery('#submitload').trigger('click');"); }
		 */

	}

	public void handleSubmit() {
		
		if (this.filteredValues != null) {
			this.filteredValues = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.client.isEmpty()) {
			displayErrorMessageToUser("Please Select a client", "ERROR");
			return;
		}
		this.listofFiles = new ArrayList<>();
		String query = "select * from (select fileid, filename, reportlocation, payor, layoutid, clientid, empgrp, reportstatus, dpstatus, importeddate, approvedstatus, patternsn, filedate,reportsn,clientname,datatype,startdate,enddate,exceptionremark,processdate from dp_dashboard_report_display where clientid='"
				+ this.client + "' ) ";
		log.info(query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.listofFiles.add(new ProfilerViewModel(
							rs.get(i).get(0), rs.get(i).get(1), rs.get(i)
									.get(2), rs.get(i).get(3),
							rs.get(i).get(4), rs.get(i).get(5), rs.get(i)
									.get(6), rs.get(i).get(7),
							rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(
									10), rs.get(i).get(11), rs.get(i).get(12),
							rs.get(i).get(13), rs.get(i).get(14), rs.get(i)
									.get(15), rs.get(i).get(16), rs.get(i).get(
									17), rs.get(i).get(18), rs.get(i).get(19)));
				}

			}
		}
		setListofFiles(this.listofFiles);
	}

	public void handleSubmitReleaseTag() {
		if (this.filteredValues != null) {
			this.filteredValues = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.releaseNum.isEmpty()) {
			displayErrorMessageToUser("Please Select a Value", "ERROR");
			return;
		}
		this.listofFiles = new ArrayList<>();
		String query = "select * from (select fileid, filename, reportlocation, payor, layoutid, clientid, empgrp, reportstatus, dpstatus, importeddate, approvedstatus, patternsn, filedate,reportsn,clientname,datatype,startdate,enddate,exceptionremark,processdate from dp_dashboard_report_display where releaseno='"
				+ this.releaseNum + "' ) ";
		log.info(query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.listofFiles.add(new ProfilerViewModel(
							rs.get(i).get(0), rs.get(i).get(1), rs.get(i)
									.get(2), rs.get(i).get(3),
							rs.get(i).get(4), rs.get(i).get(5), rs.get(i)
									.get(6), rs.get(i).get(7),
							rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(
									10), rs.get(i).get(11), rs.get(i).get(12),
							rs.get(i).get(13), rs.get(i).get(14), rs.get(i)
									.get(15), rs.get(i).get(16), rs.get(i).get(
									17), rs.get(i).get(18), rs.get(i).get(19)));
				}

			}
		}
		setListofFiles(this.listofFiles);
	}

	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

	public ProfilerViewController() {
		setTodaysDate(new Date());
		init();
	}

	public DefaultStreamedContent getDownloadDPR() {
		return downloadDPR;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	
	public void setDownloadDPR(DefaultStreamedContent downloadDPR) {
		this.downloadDPR = downloadDPR;
	}

	public void prepDownload(ProfilerViewModel obj) {
		String path = AIConstant.DP_REPORTS_PATH + obj.getReportname();
		log.info(path);
		File file = new File(AIConstant.DP_REPORTS_PATH + obj.getReportname());
		if (file.exists()) {
			FileController objFC = new FileController(
					AIConstant.DP_REPORTS_PATH + obj.getReportname());
			setDownloadDPR(objFC.getDownload());
		} else {

			setDownloadDPR(null);
			displayErrorMessageToUser("FILE NOT FOUND", "CANNOT DOWNLOAD");
			// regenerateInventory(username);

		}

	}

	public void handleReasonSave(String state) {
		log.info("The state is: " + state);
		if (!this.reason.isEmpty() || !this.editReason.isEmpty()) {
			this.fileidselected = this.selectedReport.getFileid();
			
			ConnectDB db = new ConnectDB();
			
			if(state.compareTo("APPROVE")==0)
			{
				/*String queryupdateRemarks = "update imp_main_log set EXCEPTION_REMARK='"
						+ this.reason.replaceAll("\'", "\'\'")
						+ "' where fileid='"
						+ this.fileidselected + "'";*/
				String queryupdateRemarks = "UPDATE imp_clientpatterns SET exception_remarks = '"+this.reason.replaceAll("\'", "\'\'")+"' WHERE sn = (SELECT pattern_sn FROM imp_main_log WHERE fileid = '"+this.fileidselected+"')";
				db.initialize();
				log.info("UPDATE APPROVE " + queryupdateRemarks);
				db.update(queryupdateRemarks);
				db.endConnection();
				RequestContext.getCurrentInstance().execute("PF('approveDialog').hide();");
				approve();
			}
			else if (state.compareTo("REJECT")==0)
			{
				/*String queryupdateRemarks = "update imp_main_log set EXCEPTION_REMARK='"
						+ this.reason.replaceAll("\'", "\'\'")
						+ "' where fileid='"
						+ this.fileidselected + "'";*/
				String queryupdateRemarks = "UPDATE imp_clientpatterns SET exception_remarks = '"+this.reason.replaceAll("\'", "\'\'")+"' WHERE sn = (SELECT pattern_sn FROM imp_main_log WHERE fileid = '"+this.fileidselected+"')";
				db.initialize();
				log.info("UPDATE REJECT " + queryupdateRemarks);
				db.update(queryupdateRemarks);
				db.endConnection();
				RequestContext.getCurrentInstance().execute("PF('rejectDialog').hide();");
				reject();
			} else if (state.compareTo("EDIT")==0) {
				/*String queryupdateRemarksEdit = "update imp_main_log set EXCEPTION_REMARK='"
						+ this.editReason.replaceAll("\'", "\'\'")
						+ "' where fileid='"
						+ this.fileidselected + "'";*/
				String queryupdateRemarksEdit = "UPDATE imp_clientpatterns SET exception_remarks = '"+this.editReason.replaceAll("\'", "\'\'")+"' WHERE sn = (SELECT pattern_sn FROM imp_main_log WHERE fileid = '"+this.fileidselected+"')";
				this.fileidselected = "";
				db.initialize();
				log.info("UPDATE EDIT " + queryupdateRemarksEdit);
				db.update(queryupdateRemarksEdit);
				db.endConnection();
				refresh();
				RequestContext.getCurrentInstance().execute("PF('editDialog').hide();");
			}
		}
		else
		{
			displayErrorMessageToUser("Reason cannot be empty", "ERROR");
		}
		
		
	}
	public void approve() {
		ProfilerViewModel obj = this.selectedReport;
		if(this.selectedReport == null)
		{
			displayErrorMessageToUser("No Report Selected", "ERROR");
		}
		else
		{
			this.fileidselected = obj.getFileid();
			String query = "update dp_profiler_report set approval_status='Y',approved_by='"
					+ getUserinfo().getFullname()
					+ "',approved_date=sysdate where sn='" + obj.getSn() + "'";
			/*String query = "update dp_profiler_report set approval_status='Y',approved_by='"
							+ getUserinfo().getFullname()
							+ "',approved_date=sysdate "
							+ " WHERE fileid IN (SELECT fileid FROM imp_main_log WHERE pattern_sn = " 
							+ " (SELECT pattern_sn FROM imp_main_log WHERE fileid = " 
							+ " (SELECT fileid FROM dp_profiler_report WHERE " 
							+ "sn = '"+obj.getSn()+"')))";
			
	*/
			ConnectDB db = new ConnectDB();
			db.initialize();
			int stat = db.update(query);
	
			if (stat > 0) {
				obj.setApprovedstatus("Y");
	
				displayInfoMessageToUser(
						"Report Approved for fileid  " + obj.getFileid(), "Update");
			} else {
				displayErrorMessageToUser("Update Failed.Please try again", "ERROR");
			}
			db.endConnection();
		}
	}

	public void reject() {
		ProfilerViewModel obj = this.selectedReport;
		if(this.selectedReport == null)
		{
			displayErrorMessageToUser("No Report Selected", "ERROR");
		}
		else
		{
		this.fileidselected = obj.getFileid();
		String query = "update dp_profiler_report set approval_status='N',approved_by='"
				+ getUserinfo().getFullname()
				+ "',approved_date=sysdate where sn='" + obj.getSn() + "'";
		/*String query = "update dp_profiler_report set approval_status='N',approved_by='"
				+ getUserinfo().getFullname()
				+ "',approved_date=sysdate "
				+ " WHERE fileid IN (SELECT fileid FROM imp_main_log WHERE pattern_sn = " 
				+ " (SELECT pattern_sn FROM imp_main_log WHERE fileid = " 
				+ " (SELECT fileid FROM dp_profiler_report WHERE " 
				+ "sn = '"+obj.getSn()+"')))";
	*/

		ConnectDB db = new ConnectDB();
		db.initialize();
		int stat = db.update(query);

		if (stat > 0) {
			obj.setApprovedstatus("N");

			displayInfoMessageToUser(
					"Report Rejected for fileid  " + obj.getFileid(), "Update");
		} else {
			displayErrorMessageToUser("Update Failed.Please try again", "ERROR");
		}
		db.endConnection();
		}
	}
	public String getSelectedfiltertype() {
		return selectedfiltertype;
	}

	public void setSelectedfiltertype(String selectedfiltertype) {
		this.selectedfiltertype = selectedfiltertype;
	}

	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	public void handleFilterchange() {

		log.info("The selected filter is : " + this.getFiltertype() + " " + this.filtertype);
		
		setSelectedfiltertype(this.getFiltertype());
		if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
			releaseNos = new ArrayList<String>();
			setReleaseNos(releaseNos);
		}

		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			reportsIDs = new ArrayList<String>();
			setReportsIDs(reportsIDs);
		}
		if (this.getFiltertype().compareTo("filterbyclientid") == 0) {
			clients = new LinkedHashMap<>();
			setClients(clients);
		}
	}

	public void handleSubmitReportId() {
		if (this.filteredValues != null) {
			log.info("Setting to null");
			this.filteredValues = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.reportID.isEmpty()) {
			displayErrorMessageToUser("Please Select a Value", "ERROR");
			return;
		}
		this.listofFiles = new ArrayList<>();
		String query = "select * from (select a.fileid, a.filename, a.reportlocation, a.payor, a.layoutid, a.clientid, a.empgrp, a.reportstatus, a.dpstatus, a.importeddate, a.approvedstatus, a.patternsn, a.filedate,a.reportsn,a.clientname,a.datatype,a.startdate,a.enddate,a.exceptionremark,processdate from dp_dashboard_report_display  a where EXISTS (select distinct(fileid) from imp_inventory_rep_log_details b where reportid='"
				+ this.reportID
				+ "' and a.fileid||'_'||a.dmfileid=b.fileid )) ";
		log.info(query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.listofFiles.add(new ProfilerViewModel(
							rs.get(i).get(0), rs.get(i).get(1), rs.get(i)
									.get(2), rs.get(i).get(3),
							rs.get(i).get(4), rs.get(i).get(5), rs.get(i)
									.get(6), rs.get(i).get(7),
							rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(
									10), rs.get(i).get(11), rs.get(i).get(12),
							rs.get(i).get(13), rs.get(i).get(14), rs.get(i)
									.get(15), rs.get(i).get(16), rs.get(i).get(
									17), rs.get(i).get(18), rs.get(i).get(19)));
				}

			}
		}
	}

	public void handleSubmitTimeStamp() {
		if (this.filteredValues != null) {
			this.filteredValues = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.filestartdate == null) {
			displayErrorMessageToUser("Please Select start date", "ERROR");
			return;
		}
		String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		this.listofFiles = new ArrayList<>();
		String query = "select * from (select fileid, filename, reportlocation, payor, layoutid, clientid, empgrp, reportstatus, dpstatus, importeddate, approvedstatus, patternsn, filedate,reportsn,clientname,datatype,startdate,enddate,exceptionremark,processdate from dp_dashboard_report_display where PROCESSDATE >= TO_TIMESTAMP('"
				+ dateFormat.format(filestartdate)
				+ "','"
				+ timeStampFormat
				+ "')";

		if (fileenddate != null && !fileenddate.equals("")) {
			query += " AND  PROCESSDATE <= TO_TIMESTAMP('"
					+ dateFormat.format(fileenddate) + "','" + timeStampFormat
					+ "'))";

		} else {
			query += ")";
		}

		log.info(query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.listofFiles.add(new ProfilerViewModel(
							rs.get(i).get(0), rs.get(i).get(1), rs.get(i)
									.get(2), rs.get(i).get(3),
							rs.get(i).get(4), rs.get(i).get(5), rs.get(i)
									.get(6), rs.get(i).get(7),
							rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(
									10), rs.get(i).get(11), rs.get(i).get(12),
							rs.get(i).get(13), rs.get(i).get(14), rs.get(i)
									.get(15), rs.get(i).get(16), rs.get(i).get(
									17), rs.get(i).get(18), rs.get(i).get(19)));
				}

			}
		}
	}

	public void refresh() {
		log.info("FILTER SELECTED : " + this.selectedfiltertype);
		if (this.selectedfiltertype.isEmpty()) {
			init();
		} else if (this.selectedfiltertype.compareTo("filterbyclientid") == 0) {
			handleSubmit();
		} else if (this.selectedfiltertype.compareTo("filterbyreportid") == 0) {
			handleSubmitReportId();
		} else if (this.selectedfiltertype.compareTo("filterbyreleaseno") == 0) {
			handleSubmitReleaseTag();
		} else if (this.selectedfiltertype.compareTo("filterbytimestamp") == 0) {
			handleSubmitTimeStamp();
		}
	}
	public void storeFileID(String fileid){
		log.info("set : " + fileid);
		setFileID(fileid);
		RequestContext.getCurrentInstance().execute("jQuery('#confirmregenerate').trigger('click')");
		
	}

	public void regenerate() {
		try{
		if(this.fileID!=""){
			RegenerateDPReport regenerateObject = new RegenerateDPReport();
			regenerateObject.new RunReport(this.fileID, AIConstant.DASHBOARD_SERVER_NAME).init();

			displayInfoMessageToUser(
					"Regenerating Data Profiler Report For FileID : " + this.fileID,
					"Data Profiler");

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			refresh();
		}
		}catch(Exception e){
			displayErrorMessageToUser("Unexpected Error Occured.Please try again!", "ERROR");
		}
		

	}

	/*public String getServer(String clientid) {
		String server = "";
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select machine from aip_client_server where clientid='"
				+ clientid + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		if (rs != null) {
			if (rs.size() > 1) {
				server = rs.get(1).get(0);
			}
		}

		return server;
	}*/

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getFileidselected() {
		return fileidselected;
	}

	public void setFileidselected(String fileidselected) {
		this.fileidselected = fileidselected;
	}

	public String getWinScreenHeight() {
		this.winScreenHeight = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("winScreenHeight");
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {

		this.winScreenHeight = winScreenHeight;
	}

	public void doNothing() {
		log.info("Calling");
		log.info("WIN : " + this.winScreenHeight);
	}

	public ArrayList<ProfilerViewModel> getFilteredValues() {
		return filteredValues;
	}

	public void setFilteredValues(ArrayList<ProfilerViewModel> filteredValues) {
		this.filteredValues = filteredValues;
	}
	public void handlecurrentDate(){
		try{
			
			SimpleDateFormat tformat = new SimpleDateFormat("HH:mm:ss");
			log.info("Time "+tformat.format(fileenddate));
			if(tformat.format(fileenddate).compareTo("00:00:00")==0){
				
				log.info("Date: "+this.getFileenddate());
				SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
				String denddate;
				
				denddate=dformat.format(this.getFileenddate());
				fileenddate=dformat.parse(denddate);
				Calendar cal = Calendar.getInstance();
				
				cal.setTime(fileenddate);
				fileenddate=cal.getTime();
				log.info("Data cal date "+fileenddate);
				//data_end_date=dformat.parse(data_end_date);
				fileenddate=DateUtils.addHours(fileenddate, 23);
				fileenddate=DateUtils.addMinutes(fileenddate, 59);
				fileenddate=DateUtils.addSeconds(fileenddate, 59);
				log.info("Last End Date "+fileenddate);
				setFileenddate(fileenddate);
				}
		}
		catch(Exception e){
			displayErrorMessageToUser("Date Exception Occured. Please try again", "Date");
			return;
		}
	}
	

	public void setSelectedReport(ProfilerViewModel selectedReport,String state) {
		log.info("Selected Report id : " + selectedReport.getFileid());
		this.selectedReport = selectedReport;
		if(state.compareTo("APPROVE")==0)
		{
			RequestContext.getCurrentInstance().execute("PF('approveDialog').show();");
		}
		else if (state.compareTo("REJECT")==0)
		{
			RequestContext.getCurrentInstance().execute("PF('rejectDialog').show();");
		} else if (state.compareTo("EDIT")==0) {
			//String query = "SELECT exception_remark FROM imp_main_log WHERE fileid = '" + this.selectedReport.getFileid() + "'";
			String query = "SELECT exception_remarks FROM imp_clientpatterns WHERE sn = (SELECT pattern_sn FROM imp_main_log WHERE fileid = '"+this.selectedReport.getFileid()+"')";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> result = db.resultSetToListOfList(query);
			db.endConnection();
			log.info("The result exception remark is: " + result.get(1).get(0));
			this.editReason = result.get(1).get(0);
			RequestContext.getCurrentInstance().execute("PF('editDialog').show();");
		}
	}

	public ProfilerViewModel getSelectedReport() {
		return selectedReport;
	}

	public void setSelectedReport(ProfilerViewModel selectedReport) {
		this.selectedReport = selectedReport;
	}
	
}
