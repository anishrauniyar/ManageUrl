/* 
 *Class Name : FileStatsCheckBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.dataprofiler;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import com.vit.ai.dataprofiler.model.CheckList;
import com.vit.ai.dataprofiler.model.StatsCheck;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Class to get the checklist for a data layout attributes
 * 
 * @author Aashish Dhungana
 * 
 * @version 2.0 10 July 2015
 */
@ManagedBean
@ViewScoped
public class FileStatsCheckBean extends AbstractController implements
		Serializable {

	private String datatype = "";
	private String layoutdetail = "";
	private String payor = "";
	private String clientname = "";
	private String winScreenHeight;
	
	public String getClientname() {
		return clientname;
	}

	public void setClientname(String clientname) {
		this.clientname = clientname;
	}

	private String pattern = "";

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public String getLayoutdetail() {
		return layoutdetail;
	}

	public void setLayoutdetail(String layoutdetail) {
		this.layoutdetail = layoutdetail;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	static Logger log = Logger.getLogger(FileStatsCheckBean.class.getName());
	private static final long serialVersionUID = 1L;
	private ArrayList<StatsCheck> statsChkList;
	private String layoutID;
	private String selectedClient = "";
	private LinkedHashMap<String,String> listOfClients;
	private ArrayList<String> listOfCategories;
	private ArrayList<String> listOfSemanticNames;
	private String status = "";
	private String patternsn = "";
	ArrayList<CheckList> tempListofChecks;
	private StatsCheck checkobj;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public String getPatternsn() {
		return patternsn;
	}

	public void setPatternsn(String patternsn) {
		this.patternsn = patternsn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSelectedClient() {
		return selectedClient;
	}

	public void setSelectedClient(String selectedClient) {
		this.selectedClient = selectedClient;
	}

	public LinkedHashMap<String,String> getListOfClients() {
		return listOfClients;
	}

	public void setListOfClients(LinkedHashMap<String,String> listOfClients) {
		this.listOfClients = listOfClients;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public void init(String status) {
		
	

		statsChkList = new ArrayList<StatsCheck>();
		System.out.println("STATUS : " + status);
		if (status.compareTo("GLOBAL") == 0) {
			setStatsChkList(statsChkList);
		} else if (status.compareTo("CLIENT") == 0) {
			System.out.println("CALLING CLIENT");
			setStatsChkList(statsChkList, this.selectedClient);
		} else if(status.compareTo("PATTERN")==0) {
			System.out.println("CALLING PATTERN");
			setStatsChkList(statsChkList, this.selectedClient, this.patternsn);
		} 

		this.listOfClients =new LinkedHashMap<>();
		this.listOfClients = getListofClients();
		this.listOfCategories = new ArrayList<String>();
		setListOfCategories(this.listOfCategories);
		this.listOfSemanticNames = new ArrayList<>();
		setListOfSemanticNames(this.listOfSemanticNames);
		
	}

	public LinkedHashMap<String,String> getListofClients() {
		LinkedHashMap<String,String> clients = new LinkedHashMap<>();
		
			String query = "SELECT A.CLIENTID, B.CLIENTNAME "
					+ "      FROM ( "
					+ "      SELECT distinct(CLIENTID) FROM IMP_CLIENTPATTERNS where layoutid='"+this.layoutID + "' GROUP BY CLIENTID "
					+ "      ) A " + "      LEFT JOIN "
					+ "      HAWKEYEMASTER.M_CLIENTS B "
					+ "      ON A.CLIENTID = B.CLIENTID ORDER BY CLIENTID";
		
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clList = db.resultSetToListOfList(query);
		db.endConnection();

		if (clList.size() > 0) {
			for (int i = 1; i < clList.size(); i++) {
				clients.put(clList.get(i).get(0) + "-(" + clList.get(i).get(1)
						+ ")", clList.get(i).get(0));
			}
		}
		return clients;
	}

	public ArrayList<StatsCheck> getStatsChkList() {
		return statsChkList;
	}

	public void setStatsChkList(ArrayList<StatsCheck> statsChkList) {

		String query = "select * from ( "
				+ " select q.*, case CHECKLEVEL "
				
				+ " WHEN 'LAYOUT' then 1 "
				+ " ELSE 2 "
				+ "end as priority from (select  layoutid, sublayoutid, columnid, columnname, datatype, "
				+ "checkname, threshold, fieldsn, checkid, inputtype,category, checklevel, "
				+ "inputdetail, layoutsn,is_enabled,NVL(businessname,columnname),requiredflag,semanticname from dp_dashboard_layout_config where layoutid='"
				+ this.layoutID + "') q order by layoutid,sublayoutid,columnid,checkname,priority )";

		System.out.println(query);
		log.info("LAYOUT QUERY : " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> statsList = db.resultSetToListOfList(query);
		db.endConnection();
		getList(statsList);
		getLayoutInformation(this.layoutID);
		//printAllStatsCheck();

	}
	
	public void updateSemanticNames(StatsCheck obj)
	{
		
		if(!obj.getSemanticname().isEmpty())
		{
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "update imp_layouts_fields set semantickey = (select sn from imp_semantic_master where semantic_name='"+obj.getSemanticname()+"') where sn = '" + obj.getSn() + "'";
		db.executeDML(query);
		db.endConnection();
		displayInfoMessageToUser("Semantic Name Updated", "Data Profiler");
		}
		else
		{
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "update imp_layouts_fields set semantickey = '' where sn = '" + obj.getSn() + "'";
			db.executeDML(query);
			db.endConnection();
			displayInfoMessageToUser("Semantic Name Updated", "Data Profiler");
		}
		
	}

	public void getLayoutInformation(String lid) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select a.payor,a.datatype,b.layoutdetail from imp_layouts a left join imp_sub_layouts b on a.layoutid=b.layoutid where a.layoutid='"
				+ lid + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				this.payor = rs.get(1).get(0);
				this.datatype = rs.get(1).get(1);
				this.layoutdetail = rs.get(1).get(2);
			}
		}
	}

	public void setStatsChkList(ArrayList<StatsCheck> statsChkList,
			String clientid) {

		if (clientid.isEmpty()) {
			init("GLOBAL");
			return;
		}

		String query = "select * from ( "
				+ " select q.*, case CHECKLEVEL "
				+ "WHEN 'PATTERN' then 1 "
				+ "  WHEN 'CLIENT' then 2 "
				+ " WHEN 'LAYOUT' then 3 "
				+ " ELSE 4 "
				+ "end as priority   from (select  layoutid, sublayoutid, columnid, columnname, datatype, "
				+ "checkname, threshold, fieldsn, checkid, inputtype, NVL(category,datatype), checklevel, "
				+ "inputdetail, configsn,is_enabled,NVL(businessname,columnname),requiredflag,semanticname from dp_dashboard_client_config  where clientid='"
				+ clientid
				+ "'"
				+ " and layoutid='"
				+ this.layoutID
				+ "'  union select  layoutid, sublayoutid, columnid, columnname, datatype, "
				+ "checkname, threshold, fieldsn, checkid, inputtype, NVL(category,datatype), checklevel, "
				+ "inputdetail, layoutsn,is_enabled,NVL(businessname,columnname),requiredflag,semanticname from dp_dashboard_layout_config where layoutid='"
				+ this.layoutID + "')q ) order by layoutid,sublayoutid,columnid,checkname,priority";
		System.out.println("CLIENT : " + query);

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> statsList = db.resultSetToListOfList(query);
		db.endConnection();
		getList(statsList);
		getLayoutInformation(this.layoutID);
		getClientInformation(clientid);

	}

	public void getClientInformation(String cid) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select CLIENTNAME from hawkeyemaster.m_clients where clientid='"
				+ cid + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				this.clientname = rs.get(1).get(0);
			}
		}
	}

	public void getPatternInformation(String patsn) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select pattern from imp_clientpatterns where sn='"
				+ patsn + "'";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				this.pattern = rs.get(1).get(0);
			}
		}
	}

	public ArrayList<CheckList> addChecksFilter(ArrayList<CheckList> loc) {

		int count = 0;

		ArrayList<ArrayList<CheckList>> totalarrays = new ArrayList<>();
		ArrayList<CheckList> temp = new ArrayList<>();
		ArrayList<CheckList> finalLOC = new ArrayList<>();
		for (int i = 0; i < loc.size(); i++) {
			String sn = loc.get(count).getCheckid();
			if (loc.get(i).getCheckid().compareTo(sn) == 0) {

				temp.add(loc.get(i));

			} else {

				count = i;

				totalarrays.add(temp);

				temp = new ArrayList<>();
				temp.add(loc.get(i));

			}

		}

		totalarrays.add(temp);

		for (int j = 0; j < totalarrays.size(); j++) {
			finalLOC.addAll(inheritance(totalarrays.get(j)));
		}

		return finalLOC;

	}

	public ArrayList<CheckList> inheritance(ArrayList<CheckList> loc) {

		ArrayList<CheckList> temp = new ArrayList<>();
		if (loc.size() < 2) {
			return loc;
		} else {
			for (int i = 0; i < loc.size(); i++) {
				if (loc.get(i).getCheckLevel().compareTo("PATTERN") == 0) {

					temp.add(loc.get(i));
					break;

				} else if (loc.get(i).getCheckLevel().compareTo("CLIENT") == 0) {

					temp.add(loc.get(i));
					break;

				} else if (loc.get(i).getCheckLevel().compareTo("LAYOUT") == 0) {

					temp.add(loc.get(i));
					break;

				}

				else if (loc.get(i).getCheckLevel().compareTo("DEFAULT") == 0) {
					temp.add(loc.get(i));
					break;

				}

			}
			return temp;
		}

	}

	public void setStatsChkList(ArrayList<StatsCheck> statsChkList,
			String clientid, String patternsn) {

		if (clientid.isEmpty() && patternsn.isEmpty()) {
			init("GLOBAL");
			return;
		} else if (!clientid.isEmpty() && patternsn.isEmpty()) {
			init("CLIENT");
		}

		String query = "select * from ( "
				+ " select q.*, case CHECKLEVEL "
				+ "WHEN 'PATTERN' then 1 "
				+ "  WHEN 'CLIENT' then 2 "
				+ " WHEN 'LAYOUT' then 3 "
				+ " ELSE 4 "
				+ "end as priority   from (select  layoutid, sublayoutid, columnid, columnname, datatype, "
				+ "checkname, threshold, fieldsn, checkid, inputtype, NVL(category,datatype), checklevel, "
				+ "inputdetail, configsn,is_enabled,NVL(businessname,columnname),requiredflag,semanticname from dp_dashboard_pattern_config  where "
				+ " pattern_sn='"
				+ this.patternsn
				+ "' union select  layoutid, sublayoutid, columnid, columnname, datatype, "
				+ "checkname, threshold, fieldsn, checkid, inputtype, NVL(category,datatype), checklevel, "
				+ "inputdetail, configsn,is_enabled,NVL(businessname,columnname),requiredflag,semanticname from dp_dashboard_client_config  where clientid='"
				+ clientid
				+ "'"
				+ " and layoutid='"
				+ this.layoutID
				+ "'  union select  layoutid, sublayoutid, columnid, columnname, datatype, "
				+ "checkname, threshold, fieldsn, checkid, inputtype, category, checklevel, "
				+ "inputdetail, layoutsn,is_enabled,NVL(businessname,columnname),requiredflag,semanticname from dp_dashboard_layout_config where layoutid='"
				+ this.layoutID
				+ "' ) q ) order by layoutid,sublayoutid,columnid,checkname,priority";
		
		System.out.println("PATTERN :  " + query);

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> statsList = db.resultSetToListOfList(query);
		db.endConnection();
		getList(statsList);
		getLayoutInformation(this.layoutID);
		getClientInformation(clientid);
		getPatternInformation(this.patternsn);

	}

	public void getListofValues(CheckList obj) {
		ArrayList<String> lov = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "";
		if (obj.getCheckLevel().compareTo("LAYOUT") == 0) {
			query = "select VALUE_LIST from dp_layout_values where lay_sn='"
					+ obj.getLayoutsn() + "' and is_active='1'";
		} else if (obj.getCheckLevel().compareTo("CLIENT") == 0) {
			query = "select VALUE_LIST from dp_client_values where cli_sn='"
					+ obj.getLayoutsn() + "' and is_active='1'";
		} else if (obj.getCheckLevel().compareTo("PATTERN") == 0) {
			query = "select VALUE_LIST from dp_pat_values where pat_sn='"
					+ obj.getLayoutsn() + "' and is_active='1'";
		}
		List<List<String>> rs = db.resultSetToListOfList(query);

		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					lov.add(rs.get(i).get(0));
				}
			}
		}
		obj.setListOfValues(lov);

	}

	public String getLayoutID() {

		return layoutID;
	}

	public FileStatsCheckBean() {
		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("lid") != null) {
			this.layoutID = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("lid");
		}
		if (this.status.isEmpty()) {
			
			if (FacesContext.getCurrentInstance().getExternalContext()
					.getRequestParameterMap().get("status") != null) {
				this.status = FacesContext.getCurrentInstance()
						.getExternalContext().getRequestParameterMap()
						.get("status");
			}
		}
		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("clid") != null) {
			this.selectedClient = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("clid");

		}

		if (FacesContext.getCurrentInstance().getExternalContext()
				.getRequestParameterMap().get("sn") != null) {
			this.patternsn = FacesContext.getCurrentInstance()
					.getExternalContext().getRequestParameterMap().get("sn");

		}

		init(this.status);

	}

	public void openAdd(String Options, StatsCheck obj) {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		sessionMap.put("statscheck", obj);

		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 800);
		options.put("contentHeight", 350);
		options.put("height", 380);

		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		/*
		 * String layoutid = this.layoutID; List<String> list1 = new
		 * ArrayList<String>(); list1.add(layoutid); params.put("lid", list1);
		 */
		List<String> list2 = new ArrayList<String>();
		list2.add(Options);
		params.put("type", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(this.selectedClient);
		params.put("clid", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(this.patternsn);
		params.put("sn", list4);

		RequestContext.getCurrentInstance().openDialog("addProfiler", options,
				params);

	}

	public void openEdit(String Options, StatsCheck obj) {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		sessionMap.put("statscheck", obj);

		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 800);
		options.put("contentHeight", 350);
		options.put("height", 380);

		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
	
		List<String> list2 = new ArrayList<String>();
		list2.add(Options);
		params.put("type", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(this.selectedClient);
		params.put("clid", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(this.patternsn);
		params.put("sn", list4);

		RequestContext.getCurrentInstance().openDialog("editProfiler", options,
				params);

	}

	public void openView(String Options, StatsCheck obj) {

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		sessionMap.put("statscheck", obj);

		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 800);
		options.put("contentHeight", 350);
		options.put("height", 380);

		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();

		List<String> list2 = new ArrayList<String>();
		list2.add(Options);
		params.put("type", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(this.selectedClient);
		params.put("clid", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(this.patternsn);
		params.put("sn", list4);

		RequestContext.getCurrentInstance().openDialog("viewProfiler", options,
				params);

	}

	public void openEditSingle(String Options, StatsCheck obj, CheckList cobj) {

		String index = String.valueOf(obj.getChecks().indexOf(cobj));

		Map<String, Object> options = new HashMap<String, Object>();
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance()
				.getExternalContext().getSessionMap();
		sessionMap.put("statscheck", obj);

		options.put("resizable", "true");
		options.put("draggable", "true");
		options.put("dynamic", "true");
		options.put("contentWidth", 800);
		options.put("contentHeight", 350);
		options.put("height", 380);

		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();

		List<String> list2 = new ArrayList<String>();
		list2.add(Options);
		params.put("type", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(this.selectedClient);
		params.put("clid", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(index);
		params.put("index", list4);
		List<String> list5 = new ArrayList<String>();
		list5.add(this.patternsn);
		params.put("sn", list5);
		RequestContext.getCurrentInstance().openDialog("editProfiler", options,
				params);

	}

	public ArrayList<String> getListOfCategories() {
		return listOfCategories;
	}

	public void setListOfCategories(ArrayList<String> listOfCategories) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select category_name from dp_check_categories";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					listOfCategories.add(rs.get(i).get(0));
				}

			} else {
				displayErrorMessageToUser("Category Table Empty", "ERROR");
			}
		} else {
			displayErrorMessageToUser("Category Table Not Found!!", "ERROR");
		}
		this.listOfCategories = listOfCategories;
	}

	public void reinit() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.remove("statscheck");
		init(this.status);
	}

	public void refreshPage() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.remove("statscheck");
		DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
				.getViewRoot().findComponent("frmSC:list");
		//dt1.setFilters(dt1.getFilters());
		//dt1.reset();
		dt1.setFilters(null);
		dt1.resetValue();
	
		
		
		init(this.status);
		displayInfoMessageToUser("CHECKS UPDATED", "DATA PROFILER");

	}

	public void getMessage() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
				.remove("statscheck");
		init(this.status);

		displayInfoMessageToUser("DATA PROFILER UPDATED", "UPDATE");
	}

	public void enableClientOverride() {
		
		if(this.selectedClient.isEmpty())
		{
			this.status="GLOBAL";
			try {
				FacesContext.getCurrentInstance().getExternalContext().redirect("fileStatsCheck.jsf?lid="+this.layoutID+"&status=GLOBAL");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
		this.status = "CLIENT";
		try {
			FacesContext.getCurrentInstance().getExternalContext().redirect("fileStatsCheck.jsf?lid="+this.layoutID+"&status=CLIENT&clid="+this.selectedClient);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		//init(this.status);
	}

	public void setCheckobj(StatsCheck obj) {

		this.checkobj = obj;
	}

	public void resetValues() {
		this.checkobj.setCategory(this.checkobj.getPreviousCategory());
	}

	public void handleCategoryChange() {
		this.checkobj.setPreviousCategory(this.checkobj.getCategory());
		String query1 = "update dp_layout_values set effective_to=sysdate , updated_by='"
				+ getUserinfo().getFullname()
				+ "' where lay_sn in (select lay_sn from dp_layouts_configuration where field_sn='"
				+ this.checkobj.getSn() + "')";

		String query2 = "update dp_layouts_configuration set effective_to=sysdate , updated_by='"
				+ getUserinfo().getFullname()
				+ "' where field_sn='"
				+ checkobj.getSn() + "'";

		String query3 = "update dp_client_values set effective_to=sysdate , updated_by='"
				+ getUserinfo().getFullname()
				+ "' where cli_sn in (select cli_sn from dp_clients_configuration where field_sn='"
				+ checkobj.getSn() + "')";

		String query4 = "update dp_clients_configuration set effective_to=sysdate , updated_by='"
				+ getUserinfo().getFullname()
				+ "' where field_sn='"
				+ checkobj.getSn() + "'";

		String query5 = "update  dp_pat_values set effective_to=sysdate , updated_by='"
				+ getUserinfo().getFullname()
				+ "' where pat_sn in (select pat_sn from dp_patterns_configuration where field_sn='"
				+ checkobj.getSn() + "')";

		String query6 = "update  dp_patterns_configuration set effective_to=sysdate , updated_by='"
				+ getUserinfo().getFullname()
				+ "' where field_sn='"
				+ checkobj.getSn() + "'";

		String query7 = "Update imp_layouts_fields set category='"
				+ checkobj.getCategory() + "' where sn='" + checkobj.getSn()
				+ "'";
		System.out.println("Category : " + checkobj.getCategory());
		ConnectDB db = new ConnectDB();
		db.initialize();
		db.executeDML(query1);
		db.executeDML(query2);
		db.executeDML(query3);
		db.executeDML(query4);
		db.executeDML(query5);
		db.executeDML(query6);
		db.executeDML(query7);
		db.endConnection();
		displayInfoMessageToUser("CATEGORY UPDATED", "DATA PROFILER");
		reinit();
	}

	public void getList(List<List<String>> statsList) {
		StatsCheck statobj = null;

		this.tempListofChecks = new ArrayList<>();
		ArrayList<CheckList> listofChecks = new ArrayList<>();
		if (statsList != null) {

			if (statsList.size() > 1) {

				for (int i = 1; i < statsList.size(); i++) {
					
					if (i == 1) {
						statobj = new StatsCheck(statsList.get(i).get(0),
								statsList.get(i).get(1), statsList.get(i)
										.get(2), statsList.get(i).get(3),
								statsList.get(i).get(4), statsList.get(i).get(
										10), statsList.get(i).get(7),statsList.get(i).get(15),statsList.get(i).get(17));
						CheckList obj = new CheckList();
						obj.setCheckid(statsList.get(i).get(8));
						obj.setCheckName(statsList.get(i).get(5));
						obj.setThreshold(statsList.get(i).get(6));
						obj.setCheckLevel(statsList.get(i).get(11));
						obj.setLayoutsn(statsList.get(i).get(13));
						if(statsList.get(i).get(16).compareTo("Y")==0)
						{
							obj.setRequired(true);
						}
						
						if (statsList.get(i).get(11).compareTo("DEFAULT") == 0) {
							obj.setDefaultCheck(true);
						} else {
							obj.setDefaultCheck(false);
						}
						if (statsList.get(i).get(14).compareTo("1") == 0) {
							obj.setEnabled(true);
						} else {

							obj.setEnabled(false);
						}

						obj.setSelectedValueType(statsList.get(i).get(9));
						if (!statsList.get(i).get(12).isEmpty()
								&& obj.getSelectedValueType()
										.compareTo("RANGE") == 0) {
							obj.setMaxValue(statsList.get(i).get(12)
									.split("TO")[1]);
							obj.setMinValue(statsList.get(i).get(12)
									.split("TO")[0]);
						} else if (!statsList.get(i).get(12).isEmpty()
								&& (obj.getSelectedValueType().compareTo(
										"EQUAL") == 0 || obj
										.getSelectedValueType().compareTo(
												"NOT EQUAL") == 0)) {
							obj.setValue(statsList.get(i).get(12));
						} else if (statsList.get(i).get(9).compareTo("LIST") == 0) {
							getListofValues(obj);
						}

						listofChecks.add(obj);
					} else {
						if (statsList.get(i).get(7)
								.compareTo(statsList.get(i - 1).get(7)) == 0) 
						{
																			
							

							CheckList obj = new CheckList();

							obj.setCheckid(statsList.get(i).get(8));
							obj.setCheckName(statsList.get(i).get(5));
							obj.setThreshold(statsList.get(i).get(6));
							obj.setCheckLevel(statsList.get(i).get(11));
							obj.setLayoutsn(statsList.get(i).get(13));
							if(statsList.get(i).get(16).compareTo("Y")==0)
							{
								obj.setRequired(true);
							}
							
							if (statsList.get(i).get(11).compareTo("DEFAULT") == 0) {
								obj.setDefaultCheck(true);
							} else {
								obj.setDefaultCheck(false);
							}
							if (statsList.get(i).get(14).compareTo("1") == 0) {
								obj.setEnabled(true);
							} else {
								obj.setEnabled(false);
							}

							obj.setSelectedValueType(statsList.get(i).get(9));
							if (!statsList.get(i).get(12).isEmpty()
									&& obj.getSelectedValueType().compareTo(
											"RANGE") == 0) {
								
								System.out.println("Range : " + statsList.get(i).get(12) );
								obj.setMaxValue(statsList.get(i).get(12)
										.split("TO",-1)[1]);
								obj.setMinValue(statsList.get(i).get(12)
										.split("TO",-1)[0]);
							} else if (!statsList.get(i).get(12).isEmpty()
									&& (obj.getSelectedValueType().compareTo(
											"EQUAL") == 0 || obj
											.getSelectedValueType().compareTo(
													"NOT EQUAL") == 0)) {
								obj.setValue(statsList.get(i).get(12));
							} else if (statsList.get(i).get(9)
									.compareTo("LIST") == 0) {
								getListofValues(obj);
							}

							if (!obj.getCheckid().isEmpty()) {
								listofChecks.add(obj);
							}
							if(i==statsList.size()-1)
							{
								System.out.println("ADDING LAST OBJECT : " +statobj.getColumnname() );
								statobj.setChecks(addChecksFilter(listofChecks));
								this.statsChkList.add(statobj);
							}

						} else {
							
						
							
							statobj.setChecks(addChecksFilter(listofChecks));
							this.statsChkList.add(statobj);
							listofChecks = new ArrayList<>();
							statobj = new StatsCheck(statsList.get(i).get(0),
									statsList.get(i).get(1), statsList.get(i)
											.get(2), statsList.get(i).get(3),
									statsList.get(i).get(4), statsList.get(i)
											.get(10), statsList.get(i).get(7),statsList.get(i).get(15),statsList.get(i).get(17));
							
							CheckList obj = new CheckList();
							obj.setCheckid(statsList.get(i).get(8));
							obj.setCheckName(statsList.get(i).get(5));
							obj.setThreshold(statsList.get(i).get(6));
							obj.setCheckLevel(statsList.get(i).get(11));
							obj.setLayoutsn(statsList.get(i).get(13));
							if(statsList.get(i).get(16).compareTo("Y")==0)
							{
								obj.setRequired(true);
							}
							
							if (statsList.get(i).get(11).compareTo("DEFAULT") == 0) {
								obj.setDefaultCheck(true);
							} else {
								obj.setDefaultCheck(false);
							}
							if (statsList.get(i).get(14).compareTo("1") == 0) {
								obj.setEnabled(true);
							} else {
								obj.setEnabled(false);
							}
							obj.setSelectedValueType(statsList.get(i).get(9));
							if (!statsList.get(i).get(12).isEmpty()
									&& obj.getSelectedValueType().compareTo(
											"RANGE") == 0) {
								obj.setMaxValue(statsList.get(i).get(12)
										.split("TO")[1]);
								obj.setMinValue(statsList.get(i).get(12)
										.split("TO")[0]);
							} else if (!statsList.get(i).get(12).isEmpty()
									&& (obj.getSelectedValueType().compareTo(
											"EQUAL") == 0 || obj
											.getSelectedValueType().compareTo(
													"NOT EQUAL") == 0)) {
								obj.setValue(statsList.get(i).get(12));
							} else if (statsList.get(i).get(9)
									.compareTo("LIST") == 0) {
								getListofValues(obj);
							}

							if (!obj.getCheckid().isEmpty()) {
								listofChecks.add(obj);
							}
							if(i==statsList.size()-1)
							{
								
								statobj.setChecks(addChecksFilter(listofChecks));
								this.statsChkList.add(statobj);
							}

							
							
							
						}
						

					}

				}

			}
		}
	}
	
	
	public void printAllStatsCheck()
	{
		for(int i=0;i<this.statsChkList.size();i++)
		{
			System.out.println(this.statsChkList.get(i).getColumnname());
		}
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public ArrayList<String> getListOfSemanticNames() {
		return listOfSemanticNames;
	}
	public void setListOfSemanticNames(ArrayList<String> listOfSemanticNames) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "select semantic_name from imp_semantic_master where UPPER(datatype) = '" + this.datatype.toUpperCase() + "'";
		
		System.out.println(query);
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					this.listOfSemanticNames.add(rs.get(i).get(0));
				}

			} else {
				this.listOfSemanticNames.add("");
			}
		} else {
			displayErrorMessageToUser("Master Table for semantic names not found!!", "ERROR");
		}
	
		this.listOfSemanticNames = listOfSemanticNames;
	}

	

	
	
	
}
