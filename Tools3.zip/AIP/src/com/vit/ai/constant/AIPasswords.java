package com.vit.ai.constant;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import com.vit.ai.utils.EncryptDecrypt;
import com.vit.dbconnection.ConnectDB;

public class AIPasswords implements Serializable {
	private static final long serialVersionUID = -3396981092673689858L;
	static Logger log = Logger.getLogger(AIPasswords.class.getName());
	public String schemaPassword="";
	public ConnectDB db;
	
	
	
	public void init()
	{
		db=new ConnectDB();
		db.initialize();
	}
	
	public void close()
	{
		db.endConnection();
	}
	
	
	public String getPassword(String schema)
	{
		
		EncryptDecrypt enc=new EncryptDecrypt();
		try
		{
		String query="select schema_password from aip_schema_details where schema_name='"+schema.toUpperCase()+"'";
		
		List<List<String>> rs= this.db.resultSetToListOfList(query);
		
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				this.schemaPassword=rs.get(1).get(0);
			}
		}
		}
		catch(Exception ex)
		{
			System.out.println("Exce : " + ex.toString());
			log.error("PASSWORD NOT FOUND FOR SCHEMA " + schema);
		}
		
		
		if(!this.schemaPassword.isEmpty())return enc.decrypt(this.schemaPassword);
		else return "oracle";
	}
	
	

}
