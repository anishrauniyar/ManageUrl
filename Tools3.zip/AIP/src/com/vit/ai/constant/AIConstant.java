/*
 *Class Name : RunTransfer.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.constant;

import com.vit.ai.utils.EncryptDecrypt;
import com.vit.resources.ConfigurationManager;

/**
 * Class containing the constant values obtained from config file of the system
 * 
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @author Anish Rauniyar
 * 
 * @version 1.10 15 Dec 2014
 */
public class AIConstant {

	static ConfigurationManager CM = new ConfigurationManager();
	static EncryptDecrypt ED = new EncryptDecrypt();

	/* SSH */
	public static String SSH_USERNAME = CM.getProperty("groupUsername");
	public static String SSH_PASSWORD = ED.decrypt(CM.getProperty("groupPwd"));
	
	
	/*DASHBOARD */
	public static String DASHBOARD_SERVER_IP = CM
			.getProperty("default_ServermonitorIP");
	public static String DASHBOARD_SERVER_NAME = CM
			.getProperty("default_ServermonitorName");
	
	

	/* SVN */
	public static String SVN_USERNAME = CM.getProperty("SVN_Username");

	/* RAC */
	public static String ORACLE_DRIVER = CM.getProperty("Oracle_Driver");
	public static String RAC_NODE1_IP= CM.getProperty("RAC_node1IP");
	public static String RAC_SERVER_NAME= CM.getProperty("RAC_serverName");
	
	
	public static String RAC_SERVICE_PORT = CM.getProperty("RAC_service_port");
	public static String RAC_SERVICE_SID = CM.getProperty("RAC_service");
	public static String DEFAULT_SCHEMA_PASSWORD = ED.decrypt(CM
			.getProperty("default_Pwd"));
	public static String DEFAULT_SCHEMA_NAME = CM.getProperty("default_Schema");
	public static String CPD_LINK = CM.getProperty("cpd_link");

	/* Test Import Schema */
	public static String TEST_SCHEMA_NAME = CM.getProperty("testImportSchema");

	/* Report constants */
	public static String[] HEADER_CONSTANT_FOR_PERCENTAGE = { "PERCENTAGE", "%" };

	public static String[] HEADER_CONSTANT_FOR_DOLLER = { "AMOUNT",
			"DOLLAR_AMT", "PAID_AMT", "AMT", "TOTALPAIDAMT" };

	public static String[] HEADER_CONSTANT_FOR_INTEGER = { "NUMBER", "COUNT",
			"MATCH_CNT", "TOTALCOUNT" };

	public static final int MAXIMUM_NUMBER_OF_THREADS = 4;

	/* Locations */
	public static String DUPLICATEFILE_LOCATION= CM.getProperty("duplicatefilepath");
	public static String BASE_LOCATION = CM.getProperty("Main_base_Path");
	public static String REPORT_DUMP_BASE_LOCATION = CM.getProperty("Report_base_Path");
	public static String REPORT_TEMPLATES_PATH = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("Report_template_Path");

	public static String IMPORT_SCRIPT_DUMP_LOCATION = BASE_LOCATION
			+ CM.getProperty("ImportScripts_Path");	
	public static String IMPORT_SCRIPT_DUMP_LOCATION_ZIPPED = BASE_LOCATION
			+ CM.getProperty("ImportScripts_Zipped_Path");
	public static String PRESCRUB_SCRIPT_DUMP_LOCATION = BASE_LOCATION
			+ CM.getProperty("PreScrubScripts_Path");
	public static String CATTR_DUMP_LOCATION = CM
			.getProperty("CAttr_PathOnServer");
	public static String CATTR_DUMP_LOCATION_ZIPPED = BASE_LOCATION
			+ CM.getProperty("CAttr_Zipped_Path");


	public static String ATTR_DUMP_LOCATION_SERVER = CM
			.getProperty("Attr_PathOnServer");

	public static String MDR_REPORT_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("MDR_Reports_Path");
	public static String DSR_REPORT_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("DSR_Reports_Path");
	public static String FMDR_REPORT_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("FMDR_Reports_Path");
	public static String FSR_REPORT_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("FSR_Reports_Path");
	public static String CTL_REPORT_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("CTL_Reports_Path");

	public static String UD_REPORT_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("GenericReportsPath");
	public static String INV_REP_DUMP_LOCATION = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("InventoryReportsPath");
	public static String RELEASE_REPORT_PATH = REPORT_DUMP_BASE_LOCATION
			+ CM.getProperty("ReleaseReportPath");

	public static String LAYOUT_UPLOAD_PATH = BASE_LOCATION
			+ CM.getProperty("LayoutUpload_Path");
	public static String EXECUTION_PATH = BASE_LOCATION
			+ CM.getProperty("Execution_Path");
	public static String EXECUTION_LOG_PATH = BASE_LOCATION
			+ CM.getProperty("Execution_Log_Path");
	public static String TEMPORARY_FILE_LOCATION = BASE_LOCATION
			+ CM.getProperty("temporary_file_location");
	public static String AIPFM_FILE_LOCATION = CM.getProperty("AIPFM_LOCATION");
	public static String DP_REPORTS_PATH=CM.getProperty("DPReportsPath");
	public static String DP_SCRIPT_PATH=CM
			.getProperty("processsh_file_location");
	
	public static String LOCAL_BULKTOHIRECON_OUTPUTLOCATION = CM.getProperty("Local_BulkToHIRecon_Report_Output");
	public static String LOCAL_BULKTOHIRECON_JARLOCATION = CM.getProperty("Local_BulkToHIRecon_Jar_Path");
	public static String BULKTOHIRECON_OUTPUTLOCATION = CM.getProperty("BulkToHIRecon_Report_Output");
	public static String BULKTOHIRECON_JARLOCATION = CM.getProperty("BulkToHIRecon_Jar_Path");

	/* Report Naming Conventions */
	public static String MDR_REPORT_NAME = "MDR_";
	public static String DSR_REPORT_NAME = "DSR_";
	public static String FMDR_REPORT_NAME = "FileMetaDataReport_";
	public static String FSR_REPORT_NAME = "FileSummaryReport_";
	public static String CTL_REPORT_NAME = "ControlTotalReport_";

	/* Template name */
	public static String MDR_TEMPLATE_NAME = CM
			.getProperty("MDR_Template_Name");
	public static String DSR_TEMPLATE_NAME_H = CM
			.getProperty("DSR_H_Template_Name");
	public static String FMDR_TEMPLATE_NAME = CM
			.getProperty("FMDR_Template_Name");
	public static String FSR_TEMPLATE_NAME_H = CM
			.getProperty("FSR_H_Template_Name");
	public static String CTL_TEMPLATE_NAME_H = CM
			.getProperty("CTL_H_Template_Name");
	public static String INVENTORY_TEMPLATE_NAME_H = CM
			.getProperty("Inventory_H_Template_Name");

	/* SVN */
	public static String SVNBASE_LOCATION = CM.getProperty("SVN_base_url");
	public static String SVNDepositURL = SVNBASE_LOCATION
			+ CM.getProperty("SVN_path");
	public static String SVNFMDR_PATH = SVNDepositURL
			+ CM.getProperty("SVN_FMDR_PATH");
	public static String SVNFSR_PATH = SVNDepositURL
			+ CM.getProperty("SVN_FSR_PATH");
	public static String SVNATTR_PATH = SVNDepositURL
			+ CM.getProperty("SVN_ATTR_PATH");
	public static String SVNCATTR_PATH = SVNDepositURL
			+ CM.getProperty("SVN_CATTR_PATH");
	public static String SVNSQL_PATH = SVNDepositURL
			+ CM.getProperty("SVN_SCRIPTS_PATH");
	public static String shFilelocation = CM
			.getProperty("processsh_file_location");
	public static String GENERATOR_PATH = CM.getProperty("Generator_Path");
	public static String EXCELTOTEXT_TEMP_LOCATION = CM
			.getProperty("EXCELTOTEXT_LOCATION");
	public static String EIGER_PATH = CM.getProperty("Eiger_Path");
	public static String Data = CM.getProperty("Data");
	public static String OracleLogPath=CM.getProperty("ORACLELOGPATH");
	public static String EDILogPath=CM.getProperty("EDILOGPATH");
	
	public static String RAC_LINK=CM.getProperty("nodelink");
	
	/*fmon file paths */
	public static String FMON_PATH=CM.getProperty("fmon_path");
	public static String CONFIG_FILE_PATH=CM.getProperty("config_file_path");
	public static String CLIENT_FILE_PATH=CM.getProperty("client_file_path");
	public static String EDITABLE_LAYOUT_PATH=CM.getProperty("editable_layout_path");

}
