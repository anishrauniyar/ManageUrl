/*
 *Class Name : ControlTotalBrowser.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.exceptions.controller;

import java.io.File;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.logging.Logger;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.exceptions.model.CtlUnknownFile;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller for Manual Control Total
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 23 Sep 2014
 */
@ManagedBean
@ViewScoped
public class ControlTotalBrowser extends AbstractController implements
		Serializable {

	private static final Logger LOG = Logger
			.getLogger(ControlTotalBrowser.class.getName());
	private static final long serialVersionUID = 769666004936122036L;
	private String source;
	private String selectedSource;
	private String outputText;
	private DefaultStreamedContent fileMedia;
	private ArrayList<String> clients;
	private String client;
	private String path;
	private String clientID;
	private String selectedSchema;
	private String selectedTable;
	protected LinkedHashMap<String, String> sourceFileNames;
	private ArrayList<String> unknownFiles = new ArrayList<String>();
	protected ArrayList<CtlUnknownFile> unknownfileLogs;
	protected ArrayList<CtlUnknownFile> ctlfileLogs;

	private String clientid;
	private String selectedSourceFileName;
	private String formsourcefilename;
	private String formreceivedmonth;
	private String formcatagory;
	private String formempgroup;
	private String formempgroupname;
	private String formpayor;
	private String formpayorname;
	private String layoutID;

	private String formbilledamount;
	private String formallowedamount;
	private String formppaidamount;
	private String formepaid;
	private String formecount;
	private String formmembercount;
	private String formrecordcount;
	private String formimporteddate;

	private String formvitbilledamount;
	private String formvitallowedamount;
	private String formvitppaidamount;
	private String formvitepaid;
	private String formvitecount;
	private String formvitmembercount;
	private String formvitrecordcount;

	private boolean sourcefilenamemenuStatus = true;
	private boolean browsermenuStatus = false;
	private String fileIDdmfileID;
	private String fileID;
	private String ctlfile;
	private String fileid;
	private boolean ctlfilestatus = false;
	private boolean unknownfilestatus = false;
	ArrayList<String> formempgroups;
	private Date startDate;
	private Date endDate;
	private Date todaysDate;

	protected LinkedHashMap<String, String> months;
	private String month;
	protected ArrayList<String> ctlFiles;
	protected ArrayList<String> unknFiles;
	protected ArrayList<String> ctlunknFiles;

	public ArrayList<String> getCtlunknFiles() {
		return ctlunknFiles;
	}

	public void setCtlunknFiles(ArrayList<String> ctlunknFiles) {
		this.ctlunknFiles = ctlunknFiles;
	}

	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public ArrayList<String> getClients() {
		return clients;
	}

	public void setClients(ArrayList<String> clients) {
		this.clients = clients;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public ArrayList<String> getFormempgroups() {
		return formempgroups;
	}

	public void setFormempgroups(ArrayList<String> formempgroups) {
		this.formempgroups = formempgroups;
	}

	public String getCtlfile() {
		return ctlfile;
	}

	public void setCtlfile(String ctlfile) {
		this.ctlfile = ctlfile;
	}

	public ArrayList<String> getCtlFiles() {
		return ctlFiles;
	}

	public void setCtlFiles(ArrayList<String> ctlFiles) {
		this.ctlFiles = ctlFiles;
	}

	public ArrayList<String> getUnknFiles() {
		return unknFiles;
	}

	public void setUnknFiles(ArrayList<String> unknFiles) {
		this.unknFiles = unknFiles;
	}

	public ArrayList<CtlUnknownFile> getUnknownfileLogs() {
		return unknownfileLogs;
	}

	public void setUnknownfileLogs(ArrayList<CtlUnknownFile> unknownfileLogs) {

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> unknFileList = db
				.resultSetToListOfList("SELECT processfilepath,filename,IMPORTSERVER FROM imp_main_log "
						+ " WHERE   (PROCESSSTATUS= 'UNKNOWN' AND clientid='"
						+ this.clientid
						+ "' AND TO_CHAR(PROCESSSTARTTIME,'YYYY-MON') ='"
						+ this.getMonth() + "') ORDER BY  filename ASC");

		unknFiles = new ArrayList<String>();
		db.endConnection();

		if (unknFileList.size() > 0) {
			for (int i = 1; i < unknFileList.size(); i++) {
				unknownfileLogs.add(new CtlUnknownFile(unknFileList.get(i)
						.get(0).toString(), unknFileList.get(i).get(1),
						unknFileList.get(i).get(2)));
				unknFiles.add(unknFileList.get(i).get(1));
			}
		}

	}

	public ArrayList<CtlUnknownFile> getCtlfileLogs() {
		return ctlfileLogs;
	}

	public void setCtlfileLogs(ArrayList<CtlUnknownFile> ctlfileLogs) {

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> ctlFileList = db
				.resultSetToListOfList("SELECT processfilepath,filename,IMPORTSERVER FROM imp_main_log "
						+ " WHERE   (PROCESSSTATUS ='CONTROL' AND clientid='"
						+ this.clientid
						+ "' AND TO_CHAR(PROCESSSTARTTIME,'YYYY-MON') ='"
						+ this.getMonth() + "') ORDER BY  filename ASC");

		db.endConnection();
		ctlFiles = new ArrayList<String>();

		if (ctlFileList.size() > 0) {
			for (int i = 1; i < ctlFileList.size(); i++) {
				ctlfileLogs.add(new CtlUnknownFile(ctlFileList.get(i).get(0)
						.toString(), ctlFileList.get(i).get(1), ctlFileList
						.get(i).get(2)));
				ctlFiles.add(ctlFileList.get(i).get(1));
			}
		}
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFormimporteddate() {
		return formimporteddate;
	}

	public void setFormimporteddate(String formimporteddate) {
		this.formimporteddate = formimporteddate;
	}

	public boolean isBrowsermenuStatus() {
		return browsermenuStatus;
	}

	public void setBrowsermenuStatus(boolean browsermenuStatus) {
		this.browsermenuStatus = browsermenuStatus;
	}

	public boolean isSourcefilenamemenuStatus() {
		return sourcefilenamemenuStatus;
	}

	public void setSourcefilenamemenuStatus(boolean sourcefilenamemenuStatus) {
		this.sourcefilenamemenuStatus = sourcefilenamemenuStatus;
	}

	public ControlTotalBrowser() {

		setTodaysDate(new Date());
		try {
			ConnectDB db = new ConnectDB();
			db.initialize();

			List<List<String>> ctl = db
					.resultSetToListOfList("SELECT DISTINCT B.CLIENTID , A.CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS A JOIN IMP_MAIN_LOG  B ON   A.CLIENTID=B.CLIENTID order by clientid asc");
			db.endConnection();
			clients = new ArrayList<String>();
			if (ctl.size() > 0) {
				for (int i = 1; i < ctl.size(); i++) {
					clients.add(ctl.get(i).get(0) + "-(" + ctl.get(i).get(1)
							+ ")");
				}
			}

		} catch (Exception e) {

			LOG.info(" Failed To Load Client " + e.toString());

			displayErrorMessageToUser(e.toString(), "Client Not Found");
		}

	}

	public void updatemonths() {
		try {

			String clientname = this.client;
			String[] client = clientname.split("\\-");
			clientid = client[0];
			setClientID(clientid);
			months = new LinkedHashMap<String, String>();
			setMonths(months);
			sourcefilenamemenuStatus = false;

		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(),
					"Unable to connect database");
		}

	}

	public void handleClientchange() {
		try {
			sourceFileNames = new LinkedHashMap<String, String>();
			setSourceFileNames(sourceFileNames);
			sourcefilenamemenuStatus = false;
			unknownfileLogs = new ArrayList<CtlUnknownFile>();
			setUnknownfileLogs(unknownfileLogs);
			ctlfileLogs = new ArrayList<CtlUnknownFile>();
			setCtlfileLogs(ctlfileLogs);

			setCtlFiles(getCtlFiles());
			setUnknFiles(getUnknFiles());

			ctlunknFiles = new ArrayList<String>();
			ctlunknFiles.addAll(ctlFiles);
			ctlunknFiles.addAll(unknFiles);
			setCtlunknFiles(ctlunknFiles);
		} catch (Exception e) {
			displayErrorMessageToUser(e.toString(),
					"Unable to connect database");
		}

	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {

		this.source = source;
	}

	public String getSelectedSource() {
		return selectedSource;
	}

	public void setSelectedSource(String selectedSource) {
		this.selectedSource = selectedSource;
	}

	public String getOutputText() {
		return outputText;
	}

	public void setOutputText(String outputText) {
		this.outputText = outputText;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public void prepareCommand(String filename, String serverName,
			String processfilepath) {

		setSelectedSource(filename);
		File file = new File(processfilepath + "/" + filename.toString());
		if (file.exists()) {
			FileController objFC = new FileController(processfilepath + "/"
					+ filename.toString());
			setFileMedia(objFC.getDownload());
		} else {

			setFileMedia(null);
			displayErrorMessageToUser("FILE NOT FOUND", "FILE NOT FOUND");
		}
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSelectedSchema() {
		if (selectedSchema == null) {
			return "";
		}
		return selectedSchema;
	}

	public void setSelectedSchema(String selectedSchema) {
		this.selectedSchema = selectedSchema;
	}

	public String getSelectedTable() {
		if (selectedTable == null) {
			return "";
		}
		return selectedTable;
	}

	public void setSelectedTable(String selectedTable) {
		this.selectedTable = selectedTable;
	}

	public LinkedHashMap<String, String> getSourceFileNames() {

		return sourceFileNames;
	}

	public void setSourceFileNames(LinkedHashMap<String, String> sourceFileNames) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String quer = "SELECT DISTINCT FILEID||'_'||DMFILEID||':  '||FILENAME ||'|'|| SubStr(processfilepath,1,InStr(processfilepath,'/',-1))  FROM IMP_MAIN_LOG WHERE ("
				+ " clientid='"
				+ this.clientid
				+ "'"
				+ " AND DATATYPE NOT IN ('CONTROL TOTAL','UNKN') "
				+ " AND TO_CHAR(PROCESSSTARTTIME,'YYYY-MON') ='"
				+ this.month
				+ "' )";
		List<List<String>> sourcefilenamelist = db.resultSetToListOfList(quer);

		LOG.info("  Getting Source File Names " + quer);
		if (sourcefilenamelist.size() > 0) {
			for (int i = 1; i < sourcefilenamelist.size(); i++) {
				sourceFileNames.put(
						sourcefilenamelist
								.get(i)
								.get(0)
								.substring(
										0,
										sourcefilenamelist.get(i).get(0)
												.indexOf("|")),
						sourcefilenamelist.get(i).get(0));

			}
		}

		String query = "SELECT DISTINCT empname FROM imp_employer_master WHERE CLIENTID='"
				+ this.clientid + "'";

		List<List<String>> employeeList = db.resultSetToListOfList(query);

		formempgroups = new ArrayList<String>();
		if (employeeList.size() > 0) {
			for (int i = 1; i < employeeList.size(); i++) {
				formempgroups.add(employeeList.get(i).get(0));

			}

		}
		db.endConnection();

	}

	public String getSelectedSourceFileName() {
		if (selectedSourceFileName == null) {
			return "";
		}
		return selectedSourceFileName;
	}

	public void setSelectedSourceFileName(String selectedSourceFileName) {
		this.selectedSourceFileName = selectedSourceFileName;
	}

	public String getFormsourcefilename() {
		return formsourcefilename;
	}

	public void setFormsourcefilename(String formsourcefilename) {
		this.formsourcefilename = formsourcefilename;
	}

	public String getFormreceivedmonth() {
		return formreceivedmonth;
	}

	public void setFormreceivedmonth(String formreceivedmonth) {
		this.formreceivedmonth = formreceivedmonth;
	}

	public String getFormcatagory() {
		return formcatagory;
	}

	public void setFormcatagory(String formcatagory) {
		this.formcatagory = formcatagory;
	}

	public String getFormempgroup() {
		return formempgroup;
	}

	public void setFormempgroup(String formempgroup) {
		this.formempgroup = formempgroup;
	}

	public String getFormempgroupname() {
		return formempgroupname;
	}

	public void setFormempgroupname(String formempgroupname) {
		this.formempgroupname = formempgroupname;
	}

	public String getFormpayor() {
		return formpayor;
	}

	public void setFormpayor(String formpayor) {
		this.formpayor = formpayor;
	}

	public String getFormpayorname() {
		return formpayorname;
	}

	public void setFormpayorname(String formpayorname) {
		this.formpayorname = formpayorname;
	}

	public String getFormbilledamount() {
		return formbilledamount;
	}

	public void setFormbilledamount(String formbilledamount) {
		this.formbilledamount = formbilledamount;
	}

	public String getFormallowedamount() {
		return formallowedamount;
	}

	public void setFormallowedamount(String formallowedamount) {
		this.formallowedamount = formallowedamount;
	}

	public String getFormppaidamount() {
		return formppaidamount;
	}

	public void setFormppaidamount(String formppaidamount) {
		this.formppaidamount = formppaidamount;
	}

	public String getFormepaid() {
		return formepaid;
	}

	public void setFormepaid(String formepaid) {
		this.formepaid = formepaid;
	}

	public String getFormecount() {
		return formecount;
	}

	public void setFormecount(String formecount) {
		this.formecount = formecount;
	}

	public String getFormmembercount() {
		return formmembercount;
	}

	public void setFormmembercount(String formmembercount) {
		this.formmembercount = formmembercount;
	}

	public String getFormrecordcount() {
		return formrecordcount;
	}

	public void setFormrecordcount(String formrecordcount) {
		this.formrecordcount = formrecordcount;
	}

	public String getFormvitbilledamount() {
		return formvitbilledamount;
	}

	public void setFormvitbilledamount(String formvitbilledamount) {
		this.formvitbilledamount = formvitbilledamount;
	}

	public String getFormvitallowedamount() {
		return formvitallowedamount;
	}

	public void setFormvitallowedamount(String formvitallowedamount) {
		this.formvitallowedamount = formvitallowedamount;
	}

	public String getFormvitppaidamount() {
		return formvitppaidamount;
	}

	public void setFormvitppaidamount(String formvitppaidamount) {
		this.formvitppaidamount = formvitppaidamount;
	}

	public String getFormvitepaid() {
		return formvitepaid;
	}

	public void setFormvitepaid(String formvitepaid) {
		this.formvitepaid = formvitepaid;
	}

	public String getFormvitecount() {
		return formvitecount;
	}

	public void setFormvitecount(String formvitecount) {
		this.formvitecount = formvitecount;
	}

	public String getFormvitmembercount() {
		return formvitmembercount;
	}

	public void setFormvitmembercount(String formvitmembercount) {
		this.formvitmembercount = formvitmembercount;
	}

	public String getFormvitrecordcount() {
		return formvitrecordcount;
	}

	public void setFormvitrecordcount(String formvitrecordcount) {
		this.formvitrecordcount = formvitrecordcount;
	}

	public void sourceFileNameSelected(ValueChangeEvent vchange) {
		this.browsermenuStatus = true;
		InitializeTextFields();
		if (vchange.getNewValue() == null) {
			this.fileIDdmfileID = null;
			this.fileID = "";
			this.browsermenuStatus = false;
		} else {
			this.clientID = clientid;
			fileIDdmfileID = vchange.getNewValue().toString().split("\\:")[0];
			fileID = fileIDdmfileID.toString().split("_")[0];
			selectedSourceFileName = (vchange.getNewValue().toString());
			String sourcefilename = vchange.getNewValue().toString()
					.split("\\|")[0];

			formsourcefilename = sourcefilename.toString().split("\\:")[1];

		}

		String query = "SELECT A.CLIENTID ,A.FILENAME  ,A.EMPGRP,TO_CHAR(A.PROCESSSTARTTIME,'YYYYMM') AS RECEIVEDMONTH    ,A.DATATYPE AS CATEGORY,C.SHORTPAYOR ,C.PAYOR AS PAYERNAME,"
				+ " BILLEDAMOUNT AS VH_BILLED_AMT, ALLOWEDAMOUNT AS VH_ALLOWED_AMT, PAIDAMOUNT AS VH_PAID_AMT, EMPLOYEEPAID AS VH_EMPLOYEE_AMT,"
				+ " EMPCOUNT AS VH_EMPLOYEE_CNT, MEMCOUNT AS VH_MEMBER_CNT, NVL(RECORDCOUNT,IMPORT_RECORD_CNT) AS VH_RECORD_CNT"
				+ " FROM  IMP_MAIN_LOG A "
				+ " LEFT JOIN RPT_MAIN_LOG    C"
				+ " ON A.FILEID||'_'||A.DMFILEID = C.FILEID  AND  REPORTTYPE='DSR'  AND SUBLAYOUTID=1"
				+ " LEFT JOIN RPT_DSR B"
				+ " ON C.SN=B.SN 	AND  FLAG ='Source File'"
				+ " JOIN IMP_LAYOUTS C"
				+ " ON C.LAYOUTID=A.LAYOUTID"
				+ " JOIN IMP_SUB_LAYOUTS E"
				+ " ON C.LAYOUTID=E.LAYOUTID AND C.SUBLAYOUTID=E.SUBLAYOUTID"
				+ " WHERE   A.FILEID||'_'||A.DMFILEID = '"
				+ fileIDdmfileID
				+ "' AND A.CLIENTID ='" + this.clientID + "'";

		LOG.info(" Query To Extract Existing VIT Data: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> controlTotal = db.resultSetToListOfList(query);

		if (controlTotal.size() == 2) {
			String clientid = controlTotal.get(1).get(0);
			String filename = controlTotal.get(1).get(1);
			String empgrp = controlTotal.get(1).get(2);
			String receivedmonth = controlTotal.get(1).get(3);
			String category = controlTotal.get(1).get(4);
			String shortpayor = controlTotal.get(1).get(5);
			String payorname = controlTotal.get(1).get(6);
			String vhbilledamount = controlTotal.get(1).get(7);
			String vhallowedamount = controlTotal.get(1).get(8);
			String vhpaidamount = controlTotal.get(1).get(9);
			String vhemployeeamount = controlTotal.get(1).get(10);
			String vhempcount = controlTotal.get(1).get(11);
			String vhmemcount = controlTotal.get(1).get(12);
			String vhrecordcount = controlTotal.get(1).get(13);

			clientID = clientid;
			formsourcefilename = filename;
			formvitbilledamount = vhbilledamount;
			formvitallowedamount = vhallowedamount;
			formvitppaidamount = vhpaidamount;
			formvitepaid = vhemployeeamount;
			formvitecount = vhempcount;
			formvitmembercount = vhmemcount;
			formvitrecordcount = vhrecordcount;
			formpayor = shortpayor;
			formpayorname = payorname;
			formcatagory = category;
			formempgroup = empgrp;
			formreceivedmonth = receivedmonth;

		}

		db.endConnection();

	}

	public void InitializeTextFields() {
		this.clientID = "";
		this.formsourcefilename = "";
		this.formvitbilledamount = "";
		this.formvitallowedamount = "";
		this.formvitppaidamount = "";
		this.formvitepaid = "";
		this.formvitecount = "";
		this.formvitmembercount = "";
		this.formvitrecordcount = "";
		this.formpayor = "";
		this.formpayorname = "";
		this.formcatagory = "";
		this.formempgroup = "";
		this.formreceivedmonth = "";
		this.formimporteddate = "";
		this.formbilledamount = "";
		this.formallowedamount = "";
		this.formppaidamount = "";
		this.formepaid = "";
		this.formecount = "";
		this.formmembercount = "";
		this.formrecordcount = "";
	}

	public void refreshEntryformfield() {

		this.formbilledamount = "";
		this.formallowedamount = "";
		this.formppaidamount = "";
		this.formepaid = "";
		this.formecount = "";
		this.formmembercount = "";
		this.formrecordcount = "";

	}

	public void checkDuplicate() {

		fileid = this.fileID;

		if (this.getCtlfile().isEmpty() && this.ctlfile == null) {
			displayInfoMessageToUser("Control Total",
					"Please Select Control Total File or Unknown File!");
			return;
		}

		if (!this.getCtlfile().isEmpty()) {
			String query = "";

			try {
				ConnectDB con = new ConnectDB();
				con.initialize();
				query = "SELECT * FROM IMP_VH_CONTROL_TOTAL WHERE FILEID='"
						+ fileid + "' AND CTLFILENAME='" + this.getCtlfile()
						+ "' ";
				LOG.info(" Query To Check Existing CTL File: " + query);
				List<List<String>> ctlSize = con.resultSetToListOfList(query);
				con.endConnection();
				if (ctlSize.size() >= 2) {
					RequestContext.getCurrentInstance().execute(
							"PF('cnfrmaddctl').show();");
					return;
				} else {

					add();

				}
			} catch (Exception e) {

				LOG.severe(" Error: " + e.getMessage());

				LOG.info(" Failed To Check Existing CTL File  : " + query);
			}
		}

	}

	public void add() {
		String sql = "";
		try {
			String dformat = "yyyy.MM.dd hh24:mi:ss";
			ConnectDB con = new ConnectDB();

			con.initialize();

			sql = "INSERT INTO IMP_VH_CONTROL_TOTAL (CLIENTID,FILEID,CTLFILENAME,DATAFILENAME,IMPORTEDDATE,CATEGORY,EMPNAME,PAYOR,PAYORNNAME,FROMDATE,TODATE,BILLED_AMT,ALLOWED_AMT,PAID_AMT,EMPLOYEE_AMT,EMPLOYEE_CNT,MEMBER_CNT,RECORD_CNT,USERLOG,CREATED_DATE) "
					+ "VALUES("
					+ "'"
					+ this.clientID
					+ "','"
					+ this.fileID
					+ "','"
					+ this.getCtlfile()
					+ "','"

					+ this.formsourcefilename.trim()
					+ "','"
					+ this.formimporteddate
					+ "','"
					+ this.formcatagory
					+ "','"
					+ this.formempgroup
					+ "','"
					+ this.formpayor
					+ "','"
					+ this.formpayorname + "',";
			if (this.startDate != null && this.endDate != null) {
				// TO_DATE('2015-10-30 23:59:59','yyyy.MM.dd hh24:mi:ss')
				sql += "TO_DATE('" + dateFormat.format(this.startDate) + "','"
						+ dformat + "'),";
				sql += "TO_DATE('" + dateFormat.format(this.endDate) + "','"
						+ dformat + "'),'";

			} else {
				sql += "null,null,'";

			}
			sql += this.formbilledamount + "','" + this.formallowedamount
					+ "','" + this.formppaidamount + "','" + this.formepaid
					+ "','" + this.formecount + "','" + this.formmembercount
					+ "','" + this.formrecordcount + "','"
					+ getSessionData().getFullname() + "'," + "SYSDATE" + ")";

			LOG.info(" Query To Add Control Total Information: " + sql);
			String result = con.executeDML(sql);
			con.endConnection();
			if (result.compareTo("1") == 0) {
				refreshEntryformfield();
				FacesContext context = FacesContext.getCurrentInstance();

				context.addMessage(null, new FacesMessage(
						"Record Added Successfully for " + this.getCtlfile()));
			} else {
				FacesContext context = FacesContext.getCurrentInstance();

				context.addMessage(null, new FacesMessage(
						"Failed to add. Please try again "));

			}

		} catch (Exception e) {
			LOG.severe(" Error: " + e.toString());
			LOG.info(" Control Total Information Failed To Add  : " + sql);
			displayErrorMessageToUser(e.toString(), "ERROR");
		}

	}

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public void update() {
		String dformat = "yyyy.MM.dd hh24:mi:ss";
		String query = "";
		if (!this.getCtlfile().isEmpty()) {
			query = "UPDATE  IMP_VH_CONTROL_TOTAL SET CLIENTID='"
					+ this.getClientID() + "',DATAFILENAME='"
					+ this.getFormsourcefilename().trim() + "',IMPORTEDDATE='"
					+ this.getFormimporteddate() + "',CATEGORY='"
					+ this.getFormcatagory() + "',EMPNAME='"
					+ this.getFormempgroup() + "',PAYOR='"
					+ this.getFormpayor() + "',PAYORNNAME='"
					+ this.getFormpayorname() + "',";

			if (this.startDate != null && this.endDate != null) {
				query += " FROMDATE= TO_DATE('"
						+ dateFormat.format(this.startDate) + "','" + dformat
						+ "'),";
				query += " TODATE= TO_DATE('" + dateFormat.format(this.endDate)
						+ "','" + dformat + "')";
			} else {
				query += " FROMDATE=null, TODATE=null";
			}
			query += ",BILLED_AMT='" + this.getFormbilledamount() + "'," +

			"ALLOWED_AMT='" + this.getFormallowedamount() + "',PAID_AMT='"
					+ this.getFormppaidamount() + "'," + "EMPLOYEE_AMT='"
					+ this.getFormepaid() + "',EMPLOYEE_CNT='"
					+ this.getFormecount() + "',MEMBER_CNT='"
					+ this.getFormmembercount() + "'," + "RECORD_CNT='"
					+ this.getFormrecordcount() + "',USERLOG='"
					+ this.getSessionData().getFullname()
					+ "',CREATED_DATE=SYSDATE WHERE (FILEID='" + fileid
					+ "' AND CTLFILENAME='" + this.getCtlfile() + "')";
			LOG.info(" Query To Update Information For CTL File: " + query);

		} else {
			displayErrorMessageToUser("File is not selected. Please try again",
					"Error");
			return;
		}

		try {

			ConnectDB con = new ConnectDB();
			con.initialize();
			LOG.info(" Control Total Information Updated  : " + query);

			String result = con.executeDML(query);
			con.endConnection();
			if (result.compareTo("1") == 0) {
				refreshEntryformfield();
				FacesContext context = FacesContext.getCurrentInstance();

				context.addMessage(null, new FacesMessage(
						"Record Updated Successfully for " + this.getCtlfile()));

			} else {
				FacesContext context = FacesContext.getCurrentInstance();

				context.addMessage(null, new FacesMessage(
						"Failed to update. Please try again "));
			}

		} catch (Exception e) {
			LOG.severe(" Error: " + e.toString());
			LOG.info(" Control Total Information Failed To Updated  : " + query);
			displayErrorMessageToUser(e.toString(), "ERROR");
		}

	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public LinkedHashMap<String, String> getMonths() {
		return months;
	}

	public void setMonths(LinkedHashMap<String, String> months) {
		String clientname = this.client;
		String[] client = clientname.split("\\-");
		clientid = client[0];

		ConnectDB db = new ConnectDB();

		db.initialize();

		List<List<String>> monthList = db
				.resultSetToListOfList("SELECT mnt from(select DISTINCT TO_CHAR(PROCESSSTARTTIME,'YYYY-MON') as mnt FROM IMP_MAIN_LOG A WHERE  clientid='"
						+ clientid + "' )order by To_Date(mnt,'YYYY-Mon') asc");

		db.endConnection();

		if (monthList.size() > 0) {
			for (int i = 1; i < monthList.size(); i++) {
				months.put(monthList.get(i).get(0), monthList.get(i).get(0));

			}
		}
		this.browsermenuStatus = false;
		setFormempgroups(getFormempgroups());

	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public ArrayList<String> getUnknownFiles() {
		return unknownFiles;
	}

	public void setUnknownFiles(ArrayList<String> unknownFiles) {
		this.unknownFiles = unknownFiles;
	}

	public boolean isUnknownfilestatus() {
		return unknownfilestatus;
	}

	public void setUnknownfilestatus(boolean unknownfilestatus) {
		this.unknownfilestatus = unknownfilestatus;
	}

	public boolean isCtlfilestatus() {
		return ctlfilestatus;
	}

	public void setCtlfilestatus(boolean ctlfilestatus) {
		this.ctlfilestatus = ctlfilestatus;
	}

	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

	public void doNothing() {

	}

	public DefaultStreamedContent getFileMedia() {
		return fileMedia;
	}

	public void setFileMedia(DefaultStreamedContent fileMedia) {
		this.fileMedia = fileMedia;
	}

}
