/* 
 *Class Name : ExceptionImportController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.exceptions.controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Clob;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import com.vit.ai.background.RunbackgroundExceptionImport;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.exceptions.model.ExceptionDataModel;
import com.vit.ai.exceptions.model.MainLogex;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Exception Import
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 13 July 2014
 */
@ManagedBean
@ViewScoped
public class ExceptionImportController extends AbstractController implements
		Serializable {

	private static Logger log = Logger
			.getLogger(ExceptionImportController.class.getName());
	private static final long serialVersionUID = 1L;
	protected ArrayList<MainLogex> filteredLogsRunning;
	protected ArrayList<MainLogex> filteredLogsImport;
	protected ArrayList<MainLogex> filteredLogsUnknown;
	protected ArrayList<MainLogex> filteredLogsControlTotal;
	protected ArrayList<MainLogex> filterLogsdonotuse;
	private ArrayList<MainLogex> selectedLogs;
	protected LinkedHashMap<String, String> clients;

	private String client;
	protected String query;
	private String month;
	protected LinkedHashMap<String, String> months;
	private ArrayList<MainLogex> exceptionList;
	private ArrayList<MainLogex> unknownList;
	private ArrayList<MainLogex> runningList;
	private ArrayList<MainLogex> controlList;
	private ArrayList<MainLogex> donotList;

	private Date todaysDate;
	protected Date endDate;
	protected Date startDate;

	protected ExceptionDataModel runningLogs;
	protected ExceptionDataModel exceptionLogs;
	protected ExceptionDataModel unknownLogs;
	protected ExceptionDataModel controlLogs;
	protected ExceptionDataModel donotLogs;
	public double i = 0;
	private String importServer;
	private String filtertype;
	private String selectedfiltertype;
	private String reportID;
	protected ArrayList<String> reportsIDs;
	protected ArrayList<String> releaseNos;
	private String releaseNo;
	protected FilterLogController filterData;

	protected ArrayList<String> appIdList;
	protected String appId;
	protected ArrayList<String> releaseTagList;
	protected String releaseTag;
	
	
	
	public ArrayList<String> getAppIdList() {
		return appIdList;
	}

	public void setAppIdList(ArrayList<String> appIdList) {
		String query = "SELECT DISTINCT(APP_ID) FROM IMP_FILES_RELTAG_RELN WHERE CLIENTID = '"+filterData.getClientID()+"'";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					appIdList.add(rs.get(i).get(0));
				}
			}
		}
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public ArrayList<String> getReleaseTagList() {
		return releaseTagList;
	}

	public void setReleaseTagList(ArrayList<String> releaseTagList) {
		this.releaseTagList = releaseTagList;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	public ArrayList<String> getReleaseNos() {
		return releaseNos;
	}

	public void setReleaseNos(ArrayList<String> releaseNos) {
		System.out.println("check");

		String query = "select  nvl(SUBRELEASENUMBER,release_number) as releaseno from AIP_CYCLE_MASTER";
		if (filterData.getClientID() != null) {
			query = query + " where  clientid='" + filterData.getClientID()
					+ "' order by sn desc";

		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {
					System.out.println(rs.get(i).get(0) + "releaseno");
					releaseNos.add(rs.get(i).get(0));
				}
			}
		}
	}

	public String getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(String releaseNo) {
		this.releaseNo = releaseNo;
	}

	public ArrayList<String> getReportsIDs() {
		return reportsIDs;
	}

	public void setReportsIDs(ArrayList<String> reportsIDs) {
		String query = "SELECT REPORTID FROM  IMP_INVENTORY_REP_LOG";
		if (filterData.getClientID() != null) {
			query = query + " where clientid='" + filterData.getClientID()
					+ "' and reporttype='INVENTORY' order by REPORTID DESC";

		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					reportsIDs.add(rs.get(i).get(0));
				}
			}
		}

	}

	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;

	public ArrayList<MainLogex> getExceptionList() {
		return exceptionList;
	}

	public void setExceptionList(ArrayList<MainLogex> exceptionList) {
		this.exceptionList = exceptionList;
	}

	public ArrayList<MainLogex> getUnknownList() {
		return unknownList;
	}

	public void setUnknownList(ArrayList<MainLogex> unknownList) {
		this.unknownList = unknownList;
	}

	public ArrayList<MainLogex> getRunningList() {
		return runningList;
	}

	public void setRunningList(ArrayList<MainLogex> runningList) {
		this.runningList = runningList;
	}

	public ArrayList<MainLogex> getControlList() {
		return controlList;
	}

	public void setControlList(ArrayList<MainLogex> controlList) {
		this.controlList = controlList;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

	public ExceptionDataModel getRunningLogs() {
		return runningLogs;
	}

	public void setRunningLogs(ExceptionDataModel runningLogs) {
		this.runningLogs = runningLogs;
	}

	public ExceptionDataModel getExceptionLogs() {
		return exceptionLogs;
	}

	public void setExceptionLogs(ExceptionDataModel exceptionLogs) {
		this.exceptionLogs = exceptionLogs;
	}

	public ExceptionDataModel getUnknownLogs() {
		return unknownLogs;
	}

	public void setUnknownLogs(ExceptionDataModel unknownLogs) {
		this.unknownLogs = unknownLogs;
	}

	public ExceptionDataModel getControlLogs() {
		return controlLogs;
	}

	public void setControlLogs(ExceptionDataModel controlLogs) {
		this.controlLogs = controlLogs;
	}

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public ExceptionImportController() {
		i = 0;
		init();
	}
	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}

	public void init() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
		clients = new LinkedHashMap<String, String>();
		setClients(clients);

	}

	public void handleClientChange() {
		resetFilters();
		/*String clientname = this.filterData.getClientID();
		String[] client = clientname.split("\\-");*/
		this.client = filterData.getClientID();
		reportsIDs = new ArrayList<String>();
		setReportsIDs(reportsIDs);
		releaseNos = new ArrayList<String>();
		setReleaseNos(releaseNos);
		this.appId = "";
		appIdList = new ArrayList<String>();
		setAppIdList(appIdList);
		handleAppIdChange();
	}

	public void handleAppIdChange() {
		log.info("This is an app id change filter.");
		String query = "SELECT DISTINCT releasetagidbyapp FROM (SELECT releasetagidbyapp FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+this.appId+"'" + 
						" ORDER BY CREATED DESC) UNION SELECT DISTINCT RELTAG FROM imp_files_reltag_reln WHERE app_id = '"+this.appId+"'";
		log.info(query);
		this.releaseTagList = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					releaseTagList.add(rs.get(i).get(0));
				}
			}
		}
	}
	
	public void refresh() {
		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			setReportID(this.reportID);
			filterbyReportID();

		} else if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
			setReleaseNo(this.releaseNo);
			filterbyReleaseno();
		} else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			setAppId(getAppId());
			setReleaseTag(getReleaseTag());
			filterbyReleaseTag(); 
		} else {
			filterLog();
		}
	}

	public void handleFilterchange() {
		setSelectedfiltertype(this.getFiltertype());
		System.out.println("Selectted filter "+this.filtertype);
		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			reportsIDs = new ArrayList<String>();
			setReportsIDs(reportsIDs);
		}
		if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
			releaseNos = new ArrayList<String>();
			setReleaseNos(this.releaseNos);
		}
		if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			appIdList = new ArrayList<String>();
			setAppIdList(this.appIdList);
		}
	}

	public void filterbyReleaseno() {
		try {

			if (this.releaseNo.isEmpty() && this.releaseNo == "") {
				displayErrorMessageToUser("Please select Data Batch", "");
				return;
			}
			resetFiltersbyStatus();

			String query = "SELECT FILEID, DMFILEID, FILENAME, FILE_DATE, OLDLAYOUTID, NEWLAYOUTID, STATUS_OF_IMPORT, PROCESSSTATUS, NEWDATATYPE, EMPGRP, SKIPROWS, DELIMITER, PROCESSFILEPATH, IMPORTSERVER,"
					+ " IGNOREEXCEPTION, PAYOR, CLIENTID, ORIGINAL_FILENAME, COLORFLAG, PATTERN_SN, OVERRIDDENDATE, RELEASENO, DEFAULTPATTERNSN,PROCESSDATE,DASHBOARD_FILE_CATEGORY,category_id,MANUALFLAG from aip_dashboard_exception where clientid='"
					+ this.client
					+ "'"
					+ " and (releaseno='"
					+ this.releaseNo
					+ "' )";

			log.info(" Exception Import by data batch Query " + query);
			/*String viewDefination = "SELECT dbms_metadata.get_ddl ('VIEW','AIP_DASHBOARD_EXCEPTION','AIPDB') AS DEF FROM dual";
			ConnectDB db = new ConnectDB();
			db.initialize();
			Clob viewDef = db.resultSetToClob(viewDefination);
			db.endConnection();
			String queryDef = viewDef.getSubString(viewDef.getSubString(1, (int) viewDef.length()).indexOf(" AS ") + 4, (int) viewDef.length());
			String batchFilter = " AND b.clientid='" + this.client + "' AND (b.releaseno='" + this.releaseNo + "') ";
			queryDef = queryDef.replaceAll("--Filters", batchFilter).replaceAll("\noptionally_enc,", "");
			log.info("The batch exception query id: " + queryDef);*/
			setQuery(query);

			runningList = new ArrayList<MainLogex>();
			exceptionList = new ArrayList<MainLogex>();
			unknownList = new ArrayList<MainLogex>();
			controlList = new ArrayList<MainLogex>();
			donotList= new ArrayList<MainLogex>();
			storeExtractededData();
		} catch (Exception e) {
			displayErrorMessageToUser("Query Execution Failed", "");
		}
	}

	public void filterbyReleaseTag() {
		try {

			//String excQuery = loadResource("/aipfs/AIP/");
			
			if (this.getReleaseTag().isEmpty() && this.getReleaseTag() == "") {
				displayErrorMessageToUser("Please Select Release Tag", "");
				return;
			}
			resetFiltersbyStatus();
			
			/*String query = "SELECT FILEID, DMFILEID, FILENAME, FILE_DATE, OLDLAYOUTID, NEWLAYOUTID, STATUS_OF_IMPORT, PROCESSSTATUS, NEWDATATYPE, EMPGRP, SKIPROWS, DELIMITER, PROCESSFILEPATH, IMPORTSERVER, " 
						   + "IGNOREEXCEPTION, PAYOR, CLIENTID, ORIGINAL_FILENAME, COLORFLAG, PATTERN_SN, OVERRIDDENDATE, RELEASENO, DEFAULTPATTERNSN,PROCESSDATE,DASHBOARD_FILE_CATEGORY,category_id," 
						   + "MANUALFLAG FROM AIP_DASHBOARD_EXCEPTION a  WHERE a.clientid='"+this.client+"' and  EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='"+this.releaseTag+"' " 
						   + "AND a.dmfileid=b.dmfileid and a.filename=b.filename )";
	
			log.info(" Exception Import by Release Tag Query " + query);*/
			String viewDefination = "SELECT dbms_metadata.get_ddl ('VIEW','AIP_DASHBOARD_EXCEPTION','AIPDB') AS DEF FROM dual";
			ConnectDB db = new ConnectDB();
			db.initialize();
			Clob viewDef = db.resultSetToClob(viewDefination);
			db.endConnection();
			String queryDef = viewDef.getSubString(viewDef.getSubString(1, (int) viewDef.length()).indexOf(" AS ") + 4, (int) viewDef.length());
			String relTagFilter = " AND b.clientid='" + this.client + "' AND EXISTS (SELECT distinct(dmfileid) FROM imp_files_reltag_reln rel WHERE rel.reltag='" + this.releaseTag + "' AND b.dmfileid=rel.dmfileid and b.filename=rel.filename) ";
			queryDef = queryDef.replaceAll("--Filters", relTagFilter).replaceAll("\noptionally_enc,", "");
			log.info("The release tag exception query id: " + queryDef);
			setQuery(queryDef);

			runningList = new ArrayList<MainLogex>();
			exceptionList = new ArrayList<MainLogex>();
			unknownList = new ArrayList<MainLogex>();
			controlList = new ArrayList<MainLogex>();
			donotList= new ArrayList<MainLogex>();
			storeExtractededData();
		} catch (Exception e) {
			displayErrorMessageToUser("Query Execution Failed", "");
		}
	}
	
	public void filterbyReportID()  {
		try {

			//String excQuery = loadResource("/aipfs/AIP/");
			
			if (this.getReportID().isEmpty() && this.getReportID() == "") {
				displayErrorMessageToUser("Please select inventory ID", "");
				return;
			}
			resetFiltersbyStatus();
			
			/*String query = "SELECT FILEID, DMFILEID, FILENAME, FILE_DATE, OLDLAYOUTID, NEWLAYOUTID, STATUS_OF_IMPORT, PROCESSSTATUS, NEWDATATYPE, EMPGRP, SKIPROWS, DELIMITER, PROCESSFILEPATH, IMPORTSERVER, "
					+ "IGNOREEXCEPTION, PAYOR, CLIENTID, ORIGINAL_FILENAME, COLORFLAG, PATTERN_SN, OVERRIDDENDATE, RELEASENO, DEFAULTPATTERNSN,PROCESSDATE,DASHBOARD_FILE_CATEGORY,category_id,MANUALFLAG FROM AIP_DASHBOARD_EXCEPTION a "
					+ " WHERE a.clientid='"
					+ this.client
					+ "' and  EXISTS (SELECT 1 FROM imp_inventory_rep_log_details b WHERE b.reportid='"
					+ this.getReportID()
					+ "' AND a.fileid||'_'||a.dmfileid=b.fileid  ) ";*/
			String viewDefination = "SELECT dbms_metadata.get_ddl ('VIEW','AIP_DASHBOARD_EXCEPTION','AIPDB') AS DEF FROM dual";
			ConnectDB db = new ConnectDB();
			db.initialize();
			Clob viewDef = db.resultSetToClob(viewDefination);
			db.endConnection();
			String queryDef = viewDef.getSubString(viewDef.getSubString(1, (int) viewDef.length()).indexOf(" AS ") + 4, (int) viewDef.length());
			String invFilter = " AND b.clientid='"+this.client+"' AND EXISTS (SELECT DISTINCT(fileid) FROM imp_inventory_rep_log_details r WHERE r.reportid='" + this.getReportID() + "' AND b.fileid||'_'||b.dmfileid=r.fileid) ";
			queryDef = queryDef.replaceAll("--Filters", invFilter).replaceAll("\noptionally_enc,", "");
			log.info(" Exception Import by inventory Query " + queryDef);
			setQuery(queryDef);

			runningList = new ArrayList<MainLogex>();
			exceptionList = new ArrayList<MainLogex>();
			unknownList = new ArrayList<MainLogex>();
			controlList = new ArrayList<MainLogex>();
			donotList= new ArrayList<MainLogex>();
			storeExtractededData();
		} catch (Exception e) {
			displayErrorMessageToUser("Query Execution Failed", "");
		}
	}

	public void filterLog() {
		try {
			String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			resetFiltersbyStatus();

			
			/*String query = "SELECT FILEID, DMFILEID, FILENAME, FILE_DATE, OLDLAYOUTID, NEWLAYOUTID, STATUS_OF_IMPORT, PROCESSSTATUS, NEWDATATYPE, EMPGRP, SKIPROWS, DELIMITER, PROCESSFILEPATH, IMPORTSERVER, IGNOREEXCEPTION, PAYOR, CLIENTID, "
					+ "		ORIGINAL_FILENAME, COLORFLAG, PATTERN_SN, OVERRIDDENDATE, RELEASENO, DEFAULTPATTERNSN,PROCESSDATE,DASHBOARD_FILE_CATEGORY,category_id,MANUALFLAG FROM AIP_DASHBOARD_EXCEPTION ";*/
			String viewDefination = "SELECT dbms_metadata.get_ddl ('VIEW','AIP_DASHBOARD_EXCEPTION','AIPDB') AS DEF FROM dual";
			ConnectDB db = new ConnectDB();
			db.initialize();
			Clob viewDef = db.resultSetToClob(viewDefination);
			db.endConnection();
			String queryDef = viewDef.getSubString(viewDef.getSubString(1, (int) viewDef.length()).indexOf(" AS ") + 4, (int) viewDef.length());
			String processDateFilter = "";			
			/*if (this.client != null && !this.client.equals("")) {
				processDateFilter = " AND b.clientid='" + this.client + "' ";

				if (startDate != null && !startDate.equals("")) {
					processDateFilter += " AND b.PROCESSDATE >= TO_DATE('"
							+ dateFormat.format(startDate) + "','"
							+ timeStampFormat + "')";

				}
				if (endDate != null && !endDate.equals("")) {
					processDateFilter += " AND b.PROCESSDATE <= TO_DATE('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";

				}

			} else if (this.client == null || this.client.equals("")) {
				if (startDate != null && !startDate.equals("")) {
					processDateFilter += " AND b.PROCESSDATE >= TO_DATE('"
							+ dateFormat.format(startDate) + "','"
							+ timeStampFormat + "')";

					if (endDate != null && !endDate.equals("")) {
						processDateFilter += " AND b.PROCESSDATE <= TO_DATE('"
								+ dateFormat.format(endDate) + "','"
								+ timeStampFormat + "')";

					}
				}
			} else if (this.client == null || this.client.equals("")
					&& startDate == null || startDate.equals("")) {
				if (endDate != null && !endDate.equals("")) {
					processDateFilter += " AND b.PROCESSDATE <= TO_DATE('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";

				}
			}*/
			if (this.client != null && !this.client.equals("")) {
				processDateFilter = " AND b.clientid='" + this.client + "' ";

				if (startDate != null && !startDate.equals("")) {
					processDateFilter += " AND b.processstarttime >= TO_DATE('"
							+ dateFormat.format(startDate) + "','"
							+ timeStampFormat + "') ";

				}
				if (endDate != null && !endDate.equals("")) {
					processDateFilter += " AND b.processstarttime <= TO_DATE('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "') ";

				}

			} else if (this.client == null || this.client.equals("")) {
				if (startDate != null && !startDate.equals("")) {
					processDateFilter += " AND b.processstarttime >= TO_DATE('"
							+ dateFormat.format(startDate) + "','"
							+ timeStampFormat + "') ";

					if (endDate != null && !endDate.equals("")) {
						processDateFilter += " AND b.processstarttime <= TO_DATE('"
								+ dateFormat.format(endDate) + "','"
								+ timeStampFormat + "') ";

					}
				}
			} else if (this.client == null || this.client.equals("")
					&& startDate == null || startDate.equals("")) {
				if (endDate != null && !endDate.equals("")) {
					processDateFilter += " AND b.processstarttime <= TO_DATE('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "') ";

				}
			}
			queryDef = queryDef.replaceAll("--Filters", processDateFilter).replaceAll("\noptionally_enc,", "");
			log.info(" Process Date Exception Import Query " + queryDef);
			setQuery(queryDef);

			runningList = new ArrayList<MainLogex>();
			exceptionList = new ArrayList<MainLogex>();
			unknownList = new ArrayList<MainLogex>();
			controlList = new ArrayList<MainLogex>();
			donotList= new ArrayList<MainLogex>();
			storeExtractededData();
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Query execution failed " + e.getMessage(), "");
		}
	}

	private void storeExtractededData() {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> logList = db.resultSetToListOfList(query);
		db.endConnection();
		if (logList.size() > 0) {
			for (int i = 1; i < logList.size(); i++) {
				String status = logList.get(i).get(24).toLowerCase();
				
				switch (status) {

				case "running":
					runningList.add(new MainLogex(logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(17), logList.get(i).get(18),
							logList.get(i).get(19), logList.get(i).get(20),
							logList.get(i).get(22),logList.get(i).get(23),
							logList.get(i).get(24),logList.get(i).get(25),logList.get(i).get(26)));

					break;
				case "manual submitted exceptions":
					runningList.add(new MainLogex(logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(17), logList.get(i).get(18),
							logList.get(i).get(19), logList.get(i).get(20),
							logList.get(i).get(22),logList.get(i).get(23),
							logList.get(i).get(24),logList.get(i).get(25),logList.get(i).get(26)));
					break;
				case "unknown":
					unknownList.add(new MainLogex(logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(17), logList.get(i).get(18),
							logList.get(i).get(19), logList.get(i).get(20),
							logList.get(i).get(22),logList.get(i).get(23),
							logList.get(i).get(24),logList.get(i).get(25),logList.get(i).get(26)));
					break;

				case "control":
					controlList.add(new MainLogex(logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(17), logList.get(i).get(18),
							logList.get(i).get(19), logList.get(i).get(20),
							logList.get(i).get(22),logList.get(i).get(23),
							logList.get(i).get(24),logList.get(i).get(25),logList.get(i).get(26)));
					break;
				case "donotuse":
					donotList.add(new MainLogex(logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(17), logList.get(i).get(18),
							logList.get(i).get(19), logList.get(i).get(20),
							logList.get(i).get(22),logList.get(i).get(23),
							logList.get(i).get(24),logList.get(i).get(25),logList.get(i).get(26)));
					break;


				default:
					exceptionList.add(new MainLogex(logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(17), logList.get(i).get(18),
							logList.get(i).get(19), logList.get(i).get(20),
							logList.get(i).get(22),logList.get(i).get(23),
							logList.get(i).get(24),logList.get(i).get(25),logList.get(i).get(26)));

				}
				// mainLogs.add(new
				// MainLogex(logList.get(i-1).get(0),logList.get(i).get(0),logList.get(i).get(1),logList.get(i).get(2),logList.get(i).get(3),logList.get(i).get(4),logList.get(i).get(5),logList.get(i).get(6),logList.get(i).get(7),logList.get(i).get(8),logList.get(i).get(9),logList.get(i).get(10),logList.get(i).get(11),logList.get(i).get(12),logList.get(i).get(13),logList.get(i).get(14),logList.get(i).get(15),logList.get(i).get(17),logList.get(i).get(18),logList.get(i).get(19),logList.get(i).get(20)));

			}
			setRunningList(runningList);
			runningLogs = new ExceptionDataModel(runningList);
			setExceptionList(exceptionList);
			exceptionLogs = new ExceptionDataModel(exceptionList);
			setUnknownList(unknownList);
			unknownLogs = new ExceptionDataModel(unknownList);
			setControlList(controlList);
			controlLogs = new ExceptionDataModel(controlList);
			donotLogs = new ExceptionDataModel(donotList);

		}

	}

	public void doNothing() {

	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clientList = db
				.resultSetToListOfList("SELECT DISTINCT B.CLIENTID , A.CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS A JOIN IMP_MAIN_LOG  B ON   A.CLIENTID=B.CLIENTID ORDER BY clientid asc");
		db.endConnection();

		if (clientList.size() > 0) {
			for (int i = 1; i < clientList.size(); i++) {
				clients.put(clientList.get(i).get(0) + "-("
						+ clientList.get(i).get(1) + ")", clientList.get(i)
						.get(0));
			}
		}
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public LinkedHashMap<String, String> getMonths() {
		return months;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getClient() {

		return filterData.getClientID();
	}

	public void setClient(String client) {
		filterData.setClientID(client);
		this.client = filterData.getClientID();
	}

	public ArrayList<MainLogex> getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(ArrayList<MainLogex> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	
	public void movetoImportselectedfile() throws InterruptedException {
		try {
			StringBuilder commandbuilder = new StringBuilder();
			String listofFiles="";
			int count = 0;
			String selectedskiprows = "";

			if (selectedLogs.isEmpty()) {
				displayErrorMessageToUser(
						"No File Selected.Please select files to import.",
						"Import");
				return;
			}
			
			for (int j = 0; j < selectedLogs.size(); j++) {

				if ((!selectedLogs.get(j).getNewlayoutID()
						.equalsIgnoreCase("0")
						&& !selectedLogs.get(j).getNewlayoutID()
								.equalsIgnoreCase("1")
						&& !selectedLogs.get(j).getNewlayoutID()
								.equalsIgnoreCase("3")
						&& !selectedLogs.get(j).getProcessStatus()
								.equalsIgnoreCase("RUNNING")
						&& !selectedLogs
								.get(j)
								.getProcessStatus()
								.equalsIgnoreCase("MANUAL SUBMITTED EXCEPTIONS")
						&& !selectedLogs.get(j).getNewdatatype().isEmpty() && !selectedLogs
						.get(j).getEmpGroup().isEmpty())) {
					count++;
					listofFiles=listofFiles+",'"+selectedLogs.get(j).getFileID()+"'";

					if (selectedLogs.get(j).getSkiprows().isEmpty()) {
						selectedskiprows = "0";
					}
					else
					{
						selectedskiprows = selectedLogs.get(j).getSkiprows();
					}
				
					commandbuilder.append("\"\"\""
							+ selectedLogs.get(j).getProcessfilepath() + "/"
							+ selectedLogs.get(j).getOriginalFileName()
							+ "\"\"|");
					commandbuilder.append(selectedLogs.get(j).getNewlayoutID()
							+ "|");
					commandbuilder.append(selectedLogs.get(j).getFileID() + "_"
							+ selectedLogs.get(j).getDmfileID() + "|");
					commandbuilder.append("\"" + "\""
							+ selectedLogs.get(j).getEmpGroup() + "\"\"" + "|");
					commandbuilder.append("\"\""
							+ selectedLogs.get(j).getProcessStatus() + "\"\""
							+ "|");
					commandbuilder.append("\"\""
							+ selectedLogs.get(j).getNewdatatype() + "\"\""
							+ "|" + selectedskiprows + "|" + "\"\""
							+ selectedLogs.get(j).getDelimiter() + "\"\"" + "|"
							+ selectedLogs.get(j).getExceptionflag() + "|"
							+ "\"\"" + getSessionData().getFullname() + "\"\""
							+ "|" + selectedLogs.get(j).getOldlayoutID() + "|"
							+ "\"\"" + "E" + "\"\"" + "|"
							+ selectedLogs.get(j).getPatternSN() + "|" + "\""
							+ selectedLogs.get(j).getOverriddenDate() + "\""
							+ "|" + this.client + "|"
							+ selectedLogs.get(j).getDefaultpatternSn() +"|"+selectedLogs.get(j).getCategoryID()+"|"+selectedLogs.get(j).getManualFalg()+ "\"");
								
						commandbuilder.append("\n");
				

					}

				}
			if(listofFiles.startsWith(",")){
				listofFiles=listofFiles.substring(1);
			}
			
			
			File exceptionFileName = new File(
					AIConstant.TEMPORARY_FILE_LOCATION
							+ this.client + "dmfileList"
							+ getexceptionFileName() + ".txt");
			if (!exceptionFileName.exists()) {
				try {
					exceptionFileName.createNewFile();
					FileWriter fw = new FileWriter(
							exceptionFileName.getAbsoluteFile());
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write(commandbuilder.toString());
					bw.close();
					
						ConnectDB db = new ConnectDB();
						db.initialize();
						db.executeDML("UPDATE imp_main_log set  PROCESSSTATUS ='MANUAL SUBMITTED EXCEPTIONS' ,status_of_import=''  WHERE fileid in ("+listofFiles+")");
						System.out
						.println("No of file whose status are updated as MANUAL SUBMITTED EXCEPTIONS : "
								+ count);
						db.endConnection();

						runCommand(AIConstant.shFilelocation
								+ "processDashboard.sh -l "
								+ exceptionFileName.getAbsolutePath(),
								AIConstant.DASHBOARD_SERVER_NAME);
									displayInfoMessageToUser(count
									+ " file(s) sent for import.",
									"Exception Import");

				} catch (IOException e) {
					displayErrorMessageToUser(
							"List of Files Not Found",
							"Exception Import");
				}
			}
			
			
			if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
				setReportID(this.reportID);
				filterbyReportID();
			} else if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
				setReleaseNo(this.releaseNo);
				filterbyReleaseno();
			}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
				setAppId(getAppId());
				setReleaseTag(getReleaseTag());
				filterbyReleaseTag(); 
			} else {
				filterLog();
			}
		} catch (Exception e) {
			displayErrorMessageToUser("Error Occured: " + e.getMessage(), "");
		}

	}

	private synchronized String getexceptionFileName() {
		String timeStamp = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"YYYYMMHHmmss.ssssss");
		Calendar calendar = Calendar.getInstance();
		timeStamp = dateFormat.format(calendar.getTimeInMillis());

		return timeStamp;
	}

	public void runCommand(String commmand, String importserver) throws InterruptedException
			 {
	
		RunbackgroundExceptionImport obFM = new RunbackgroundExceptionImport();
		obFM.new importexception().init(commmand);
	

		
		
	}

	public void unselectAllrows() {
		setSelectedLogs(null);
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {

		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public String getImportServer() {
		return importServer;
	}

	public void setImportServer(String importServer) {
		this.importServer = importServer;
	}

	public String setRowColor(String prevFileID, String FileID) {

		String value = "";

		if ((FileID.equals(prevFileID))) {
			value = "#color1";
		} else {
			value = "";
		}

		return value;

	}

	public void resetFiltersbyStatus() {
		
						
			if (this.filteredLogsRunning != null) {
				this.filteredLogsRunning = null;
				DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("frmEX:runningDataTable");
				dt1.setFilters(null);
				dt1.reset();
			}

			if (this.filteredLogsImport != null) {
				this.filteredLogsImport = null;

				DataTable dt2 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot()
						.findComponent("frmEX:exceptionDataTable");
				dt2.setFilters(null);
				dt2.reset();
			}

			if (this.filteredLogsUnknown != null) {
				this.filteredLogsUnknown = null;
				DataTable dt3 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("frmEX:unknownDataTable");
				dt3.setFilters(null);
				dt3.reset();
			}

			if (this.filteredLogsControlTotal != null) {
				this.filteredLogsControlTotal = null;
				DataTable dt4 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("frmEX:controlDataTable");
				dt4.setFilters(null);
				dt4.reset();
			}

			if (this.filterLogsdonotuse != null) {
				this.filterLogsdonotuse = null;
				DataTable dt4 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("frmEX:donotuseDataTable");
				dt4.setFilters(null);
				dt4.reset();
			}
	}

	public ArrayList<MainLogex> getFilteredLogsRunning() {
		return filteredLogsRunning;
	}

	public void setFilteredLogsRunning(ArrayList<MainLogex> filteredLogsRunning) {
		this.filteredLogsRunning = filteredLogsRunning;
	}

	public ArrayList<MainLogex> getFilteredLogsImport() {
		return filteredLogsImport;
	}

	public void setFilteredLogsImport(ArrayList<MainLogex> filteredLogsImport) {
		this.filteredLogsImport = filteredLogsImport;
	}

	public ArrayList<MainLogex> getFilteredLogsUnknown() {
		return filteredLogsUnknown;
	}

	public void setFilteredLogsUnknown(ArrayList<MainLogex> filteredLogsUnknown) {
		this.filteredLogsUnknown = filteredLogsUnknown;
	}

	public ArrayList<MainLogex> getFilteredLogsControlTotal() {
		return filteredLogsControlTotal;
	}

	public void setFilteredLogsControlTotal(
			ArrayList<MainLogex> filteredLogsControlTotal) {
		this.filteredLogsControlTotal = filteredLogsControlTotal;
	}

	public void resetFilters() {
	}

	public String getSelectedfiltertype() {
		return selectedfiltertype;
	}

	public void setSelectedfiltertype(String selectedfiltertype) {
		this.selectedfiltertype = selectedfiltertype;
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}
	public void handlecurrentDate(){
		try{
			
			SimpleDateFormat tformat = new SimpleDateFormat("HH:mm:ss");
			System.out.println("Time "+tformat.format(endDate));
			if(tformat.format(endDate).compareTo("00:00:00")==0){
				
				System.out.println("Date: "+this.getEndDate());
				SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
				String denddate;
				
				denddate=dformat.format(this.getEndDate());
				endDate=dformat.parse(denddate);
				Calendar cal = Calendar.getInstance();
				
				cal.setTime(endDate);
				endDate=cal.getTime();
				System.out.println("Data cal date "+endDate);
				//data_end_date=dformat.parse(data_end_date);
				endDate=DateUtils.addHours(endDate, 23);
				endDate=DateUtils.addMinutes(endDate, 59);
				endDate=DateUtils.addSeconds(endDate, 59);
				System.out.println("Last End Date "+endDate);
				setEndDate(endDate);
				}
		}
		catch(Exception e){
			displayErrorMessageToUser("Date Exception Occured. Please try again", "Date");
			return;
		}
	}

	public ArrayList<MainLogex> getDonotList() {
		return donotList;
	}

	public void setDonotList(ArrayList<MainLogex> donotList) {
		this.donotList = donotList;
	}

	public ExceptionDataModel getDonotLogs() {
		return donotLogs;
	}

	public void setDonotLogs(ExceptionDataModel donotLogs) {
		this.donotLogs = donotLogs;
	}

	public ArrayList<MainLogex> getFilterLogsdonotuse() {
		return filterLogsdonotuse;
	}

	public void setFilterLogsdonotuse(ArrayList<MainLogex> filterLogsdonotuse) {
		this.filterLogsdonotuse = filterLogsdonotuse;
	}
	
	
}