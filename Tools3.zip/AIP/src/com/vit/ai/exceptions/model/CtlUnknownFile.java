/* 
 *Class Name : CtlUnknownFile.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.exceptions.model;

import java.io.Serializable;

/**
 * Model Class for Manual Control Total
 * 
 * @author Binesh Sah
 *
 * @version 1.0 23 Sep 2015
 */
public class CtlUnknownFile implements Serializable {

	private static final long serialVersionUID = 6141937894802155921L;
	String fileName;
	String processFilepath;
	String serverName;

	public CtlUnknownFile() {

	}

	public CtlUnknownFile(String processfilepath, String filename,
			String importserver) {
		this.processFilepath = processfilepath;
		this.fileName = filename;
		this.serverName = importserver;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getProcessFilepath() {
		return processFilepath;
	}

	public void setProcessFilepath(String processFilepath) {
		this.processFilepath = processFilepath;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

}
