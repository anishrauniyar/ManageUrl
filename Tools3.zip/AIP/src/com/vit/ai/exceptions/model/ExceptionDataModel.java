/*
 * Author: Binesh Sah
 * 
 *Class Name : ExceptionDataModel.java
 *
 *Version : 1.0
 *
 *Date: 2014/08/03
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.exceptions.model;

import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.model.ListDataModel;

import org.primefaces.model.SelectableDataModel;

public class ExceptionDataModel extends ListDataModel<MainLogex> implements
		SelectableDataModel<MainLogex>, Serializable {

	private static final long serialVersionUID = 5267272302747606014L;

	public ExceptionDataModel() {

	}

	public ExceptionDataModel(ArrayList<MainLogex> mainLog) {
		super(mainLog);

	}

	@Override
	public Object getRowKey(MainLogex object) {

		return object.getFileID();
	}

	@SuppressWarnings("unchecked")
	@Override
	public MainLogex getRowData(String rowKey) {

		ArrayList<MainLogex> logs = (ArrayList<MainLogex>) getWrappedData();

		for (MainLogex log : logs) {
			if (log.getFileID().equals(rowKey)) {
				return log;
			}
		}
		return null;
	}

}