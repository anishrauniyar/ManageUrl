/* 
 *Class Name : MainLogex.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.exceptions.model;

import java.io.Serializable;

/**
 * Model class for Exception Import and Re-Import
 * 
 * @author Binesh Sah
 *
 * @verison 1.0 03 Jun 2014
 */
public class MainLogex implements Serializable {

	private static final long serialVersionUID = 2268052981791966232L;

	private String fileID;

	private String fileName;
	private String clientID;
	private String oldlayoutID;
	private String newlayoutID;
	private String statusOfImport;
	private String startTime;
	private String processStatus;
	private String empGroup;
	private String processfilepath;
	private String dmfileID;
	private String newdatatype;
	private String skiprows;
	private String delimiter;
	private String importServer;
	private String import_record_cnt;
	private String exceptionflag;
	private String fileDate;
	private String payor;

	private String originalFileName;
	private String colorFlag;
	private String prevFileID;
	private String patternSN;
	private String overriddenDate;
	private String defaultpatternSn;
	private String processDate;
	private String exceptionType;
	private String categoryID;
	private String manualFalg;

	public String getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(String categoryID) {
		this.categoryID = categoryID;
	}

	public String getNewlayoutID() {
		return newlayoutID;
	}

	public void setNewlayoutID(String newlayoutID) {
		this.newlayoutID = newlayoutID;
	}

	public String getPatternSN() {
		return patternSN;
	}

	public void setPatternSN(String patternSN) {
		this.patternSN = patternSN;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getNewdatatype() {
		return newdatatype;
	}

	public void setNewdatatype(String newdatatype) {
		this.newdatatype = newdatatype;
	}

	public String getDmfileID() {
		return dmfileID;
	}

	public void setDmfileID(String dmfileID) {
		this.dmfileID = dmfileID;
	}

	public String getEmpGroup() {
		return empGroup;
	}

	public void setEmpGroup(String empGroup) {
		this.empGroup = empGroup;
	}

	public String getProcessfilepath() {
		return processfilepath;
	}

	public void setProcessfilepath(String processfilepath) {
		this.processfilepath = processfilepath;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getStatusOfImport() {
		return statusOfImport;
	}

	public void setStatusOfImport(String statusOfImport) {
		this.statusOfImport = statusOfImport;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public MainLogex() {

	}

	/* Exception import constructor */
	public MainLogex(String prevfileid, String fileID, String dmfileid,
			String fileName, String fileDate, String oldlayoutID,
			String newlayoutID, String statusOfImport, String processStatus,
			String newdatatype, String empgroup, String skiprows,
			String delimiter, String processfilepath, String importserver,
			String exceptionflag, String payor, String originalfilename,
			String colorflag, String patternSN, String overriddenDate,String defaultpsn,String processDate,String exceptionType,String categoryID,String manualFlag) {

		this.prevFileID = prevfileid;
		this.fileID = fileID;
		this.dmfileID = dmfileid;
		this.fileName = fileName;
		this.fileDate = fileDate;
		this.oldlayoutID = oldlayoutID;
		this.newlayoutID = newlayoutID;
		this.statusOfImport = statusOfImport;
		this.processStatus = processStatus;
		this.newdatatype = newdatatype;
		this.empGroup = empgroup;
		this.skiprows = skiprows;
		this.delimiter = delimiter;
		this.processfilepath = processfilepath;
		this.importServer = importserver;
		this.exceptionflag = exceptionflag;
		this.payor = payor;
		this.originalFileName = originalfilename;
		this.colorFlag = colorflag;
		this.patternSN = patternSN;
		this.overriddenDate = overriddenDate;
		this.defaultpatternSn=defaultpsn;
		this.processDate=processDate;
		this.exceptionType=exceptionType;
		this.categoryID=categoryID;
		this.manualFalg=manualFlag;
		
		
	}

	/* Re-import constructor */
	public MainLogex(String prefileid, String fileID, String dmfileid,
			String fileName, String fileDate, String oldlayoutID,
			String newlayoutID, String statusOfImport, String processStatus,
			String newdatatype, String empgroup, String skiprows,
			String delimiter, String processfilepath, String importserver,
			String import_record_cnt, String exceptionflag, String payor,
			String originalfilename, String colorflag, String patternSN,
			String overriddenDate,String defaultpsn,String processDate,String exceptionType,String categoryID,String manualFlag) {

		this.prevFileID = prefileid;
		this.fileID = fileID;
		this.dmfileID = dmfileid;
		this.fileName = fileName;
		this.fileDate = fileDate;
		this.oldlayoutID = oldlayoutID;
		this.newlayoutID = newlayoutID;
		this.statusOfImport = statusOfImport;
		this.processStatus = processStatus;
		this.newdatatype = newdatatype;
		this.empGroup = empgroup;
		this.skiprows = skiprows;
		this.delimiter = delimiter;
		this.processfilepath = processfilepath;
		this.importServer = importserver;
		this.import_record_cnt = import_record_cnt;
		this.exceptionflag = exceptionflag;
		this.payor = payor;
		this.originalFileName = originalfilename;
		this.colorFlag = colorflag;
		this.patternSN = patternSN;
		this.overriddenDate = overriddenDate;
		this.defaultpatternSn=defaultpsn;
		this.processDate=processDate;
		this.exceptionType=exceptionType;
		this.categoryID=categoryID;
		this.manualFalg=manualFlag;
	}

	public String getSkiprows() {
		return skiprows;
	}

	public void setSkiprows(String skiprows) {
		this.skiprows = skiprows;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getImportServer() {
		return importServer;
	}

	public void setImportServer(String importServer) {
		this.importServer = importServer;
	}

	public String getImport_record_cnt() {
		return import_record_cnt;
	}

	public void setImport_record_cnt(String import_record_cnt) {
		this.import_record_cnt = import_record_cnt;
	}

	public String getOldlayoutID() {
		return oldlayoutID;
	}

	public void setOldlayoutID(String oldlayoutID) {
		this.oldlayoutID = oldlayoutID;
	}

	public String getExceptionflag() {
		return exceptionflag;
	}

	public void setExceptionflag(String exceptionflag) {
		this.exceptionflag = exceptionflag;
	}

	public String getFileDate() {
		return fileDate;
	}

	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public String getColorFlag() {
		return colorFlag;
	}

	public void setColorFlag(String colorFlag) {
		this.colorFlag = colorFlag;
	}

	public String getPrevFileID() {
		return prevFileID;
	}

	public void setPrevFileID(String prevFileID) {
		this.prevFileID = prevFileID;
	}

	public String getOverriddenDate() {
		return overriddenDate;
	}

	public void setOverriddenDate(String overriddenDate) {
		this.overriddenDate = overriddenDate;
	}

	public String getDefaultpatternSn() {
		return defaultpatternSn;
	}

	public void setDefaultpatternSn(String defaultpatternSn) {
		this.defaultpatternSn = defaultpatternSn;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	

	public String getExceptionType() {
		return exceptionType;
	}

	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}

	public String getManualFalg() {
		return manualFalg;
	}

	public void setManualFalg(String manualFalg) {
		this.manualFalg = manualFalg;
	}

	
	
}