package com.vit.ai.inventory.dao;

import java.util.ArrayList;
import java.util.List;

import com.vit.ai.inventory.model.PipeLineModel;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 *         Data Access Class for Pipeline
 */
public class PipeLineDAO {

	private ArrayList<PipeLineModel> listofFiles = new ArrayList<>();

	/**
	 * @return
	 * List of Inventory Pipelines Model
	 */
	public ArrayList<PipeLineModel> getAllFiles(String clientid) {
		
		
		
		String query = "select clientid,dmfileid,filename,datatype,filereceiveddate,filesize,payor,employergroup,layoutid,pattern,eigertransferdate,checksum,mappedondate,fullfilepath,status from aip_dashboard_pipeline where clientid ='" + clientid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					PipeLineModel model = new PipeLineModel(rs.get(i).get(0), rs.get(i).get(1), rs.get(i).get(2), rs.get(i).get(3), rs.get(i).get(4), rs.get(i).get(5), rs.get(i).get(6), rs.get(i).get(7), rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(10), rs.get(i).get(11), rs.get(i).get(12), rs.get(i).get(13), rs.get(i).get(14));
					this.listofFiles.add(model);
				}
			}
		}
		db.endConnection();
		return listofFiles;
	}

	public ArrayList<PipeLineModel> getListofFiles() {
		return listofFiles;
	}

	public void setListofFiles(ArrayList<PipeLineModel> listofFiles) {
		this.listofFiles = listofFiles;
	}

}