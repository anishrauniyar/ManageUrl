package com.vit.ai.inventory.principle;

public  interface  InventoryReports_Standard {
	
	
	
	
	public void  getSelectedFiles();
	public void filterFiles();
	public void  generateReportid();	
	public  void storeReport();
	public void storeFileids();
	public void generateReport();
	public void updateTable();	
	public String getErrorMsg();
	public void setErrorMsg(String errorMsg);
	public boolean isHasErrors() ;
	public void setHasErrors(boolean hasErrors);

}
