/**
 * @author Aashish Dhungana
 * 
 * Report Generator Engine for All Inventory Reports
 * 
 * Date Created : 29 December 2015
 */

package com.vit.ai.inventory.principle;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

public class ReportGenerator_Main implements Runnable {

	static Logger log = Logger.getLogger(ReportGenerator_Main.class.getName());

	InventoryReports_Standard reportObject;

	private String errorMsg = "";
	private boolean hasErrors = false;

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public boolean isHasErrors() {
		return hasErrors;
	}

	public void setHasErrors(boolean hasErrors) {
		this.hasErrors = hasErrors;
	}

	/**
	 * 
	 * @param obj
	 *            Any Report Object implementing InventoryReport_Standard
	 *            Interface
	 */
	public ReportGenerator_Main(InventoryReports_Standard obj) {

		if (obj != null) {
			this.reportObject = obj;

		}

	}

	public boolean init() {
		Thread thread = new Thread(this);
		thread.run();
		return this.hasErrors;
	}

	@Override
	public void run() {

		this.reportObject.filterFiles();
		if (this.reportObject.isHasErrors()) {
			this.hasErrors = true;
			this.errorMsg = this.reportObject.getErrorMsg();
			return;
		}
		this.reportObject.getSelectedFiles();
		if (this.reportObject.isHasErrors()) {
			this.hasErrors = true;
			this.errorMsg = this.reportObject.getErrorMsg();
			return;
		}
		this.reportObject.generateReportid();
		if (this.reportObject.isHasErrors()) {
			this.hasErrors = true;
			this.errorMsg = this.reportObject.getErrorMsg();
			return;
		}
		this.reportObject.storeReport();

		if (this.reportObject.isHasErrors()) {
			this.hasErrors = true;
			this.errorMsg = this.reportObject.getErrorMsg();
			return;
		}
		this.reportObject.storeFileids();
		if (this.reportObject.isHasErrors()) {
			this.hasErrors = true;
			this.errorMsg = this.reportObject.getErrorMsg();
			return;
		}
		
		ExecutorService service = Executors.newFixedThreadPool(2);
		service.submit(new Runnable(){
			public void run()
			{
				ReportGenerator_Main.this.reportObject.generateReport();
				if (ReportGenerator_Main.this.reportObject.isHasErrors()) {
					ReportGenerator_Main.this.hasErrors = true;
					ReportGenerator_Main.this.errorMsg = ReportGenerator_Main.this.reportObject.getErrorMsg();
					return;
				}
				ReportGenerator_Main.this.reportObject.updateTable();
				if (ReportGenerator_Main.this.reportObject.isHasErrors()) {
					ReportGenerator_Main.this.hasErrors = true;
					ReportGenerator_Main.this.errorMsg = ReportGenerator_Main.this.reportObject.getErrorMsg();
					return;
				}
			}
		});

		

	}
}
