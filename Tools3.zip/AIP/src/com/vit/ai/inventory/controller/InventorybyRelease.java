package com.vit.ai.inventory.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.inventory.principle.InventoryReports_Standard;
import com.vit.ai.poireport.controller.InventoryReportController;
import com.vit.dbconnection.ConnectDB;

public class InventorybyRelease implements InventoryReports_Standard {

	private ArrayList<MainLog> logList;
	private ArrayList<MainLog> filteredList;
	private ArrayList<String> listofFileids;
	private String reportid;
	private String userLog;
	private String clientid;
	private String reportname;
	private String errorMsg = "";
	private boolean hasErrors = false;
	private Date startDate;
	private Date endDate;
	private String releaseNum = "";
	private String releaseDetails = "";
	private String rCreatedBy = "";
	
	
	LinkedHashMap<String, String> reportIDfileList = new LinkedHashMap<>();

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	public ArrayList<MainLog> getFilteredList() {
		return filteredList;
	}

	public void setFilteredList(ArrayList<MainLog> filteredList) {
		this.filteredList = filteredList;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public void setLogList(ArrayList<MainLog> logList) {
		this.logList = logList;
		this.setHasErrors(false);
	}

	public String getUserLog() {
		return userLog;
	}

	public void setUserLog(String userLog) {
		this.userLog = userLog;
	}

	static Logger log = Logger.getLogger(Inventory.class.getName());

	public InventorybyRelease(ArrayList<MainLog> logList, String userLog,
			String clientid, String reportname,String releaseNum) {
		super();
		this.logList = new ArrayList<>();
		this.listofFileids = new ArrayList<>();
		this.logList = logList;
		this.userLog = userLog;
		this.clientid = clientid;
		this.reportname = reportname;
		this.releaseNum = releaseNum;
		

		log.info("------GENERATING INVENTORY REPORT BY " + this.userLog
				+ " FOR CLIENT " + this.clientid + " ---------------");
	}

	@Override
	public void getSelectedFiles() {

		try {
			if (this.filteredList.size() > 0) {
				for (int i = 0; i < this.filteredList.size(); i++) {
					this.listofFileids.add(this.filteredList.get(i)
							.getMergedFileId());
				}

				log.info("--TOTAL NUMBER OF MERGED FILEIDS  "
						+ this.listofFileids.size() + "----");
			}
		} catch (Exception ex) {
			log.info(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
			return;
		}

	}

	@Override
	/**
	 * Filters applied to remove duplicate files
	 */
	public void filterFiles() {
		// TODO Auto-generated method stub
		String check_status = "";
		
		log.info("--FILTERING FILES---");

		log.info("--TOTAL FILES ---" + this.logList.size());

		if (this.logList.size() < 1) {
			this.hasErrors = true;
			this.errorMsg = "No Files Selected";
			return;
		}

		this.filteredList = new ArrayList<>();

		log.info("--APPLTING FILTERS---CHECKING FOR EXISTING FILES IN INVENTORY---");

		ConnectDB db = new ConnectDB();
		db.initialize();
		for (int i = 0; i < this.logList.size(); i++) {
			check_status = "";
			String check_query = " SELECT   Count(*),a.reportid FROM  imp_inventory_rep_log  a , imp_inventory_rep_log_details b  WHERE "
					+ " a.reportid=b.reportid  AND   a .RELEASENO = '"
					+ releaseNum
					+ "' AND  created_by='"
					+ userLog
					+ "' AND b.fileid= '"
					+ this.logList.get(i).getFileID()
					+ "_"
					+ this.logList.get(i).getDmFileID()
					+ "' group by a.reportid";

			log.info("--CHECK QUERY ----" + check_query);
			List<List<String>> checkList = db
					.resultSetToListOfList(check_query);

			if (checkList.size() > 1) {
				check_status = checkList.get(1).get(0);
				String reportId = checkList.get(1).get(1);
				reportIDfileList.put(this.logList.get(i).getFileID() + "_"
						+ this.logList.get(i).getDmFileID(), reportId);

			}

			if (check_status.compareTo("1")!=0) {

				this.filteredList.add(logList.get(i));

			}

		}
		
		if(this.filteredList.isEmpty())
		{
			this.hasErrors = true;
			this.errorMsg = "Inventory cannot be generated.All files have already been considered for previous inventory";
			return;
		}

		log.info("TOTAL SIZE AFTER FILTER --- " + this.filteredList.size());
		

	}

	@Override
	public void generateReportid() {
		// TODO Auto-generated method stub
		ConnectDB db = new ConnectDB();
		try {
			log.info("---GENERATING REPORTID -----");

			db.initialize();
			String query = "SELECT Max(reportid)+1 FROM imp_inventory_rep_log";
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			if (rs != null) {
				if (rs.size() > 1) {
					this.reportid = rs.get(1).get(0);
				} else {
					this.reportid = "0";
				}
			} else {
				this.reportid = "0";
			}

			log.info("-----REPORTID " + this.reportid + "----");
		} catch (Exception ex) {
			log.error(ex.toString());

			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		} finally {
			db.endConnection();
		}
		

	}

	@Override
	public void storeReport() {
		// TODO Auto-generated method stub
		ConnectDB db = new ConnectDB();
		try {
			log.info("--INSERTING REPORT DETAILS---");
			String dateformat = "yyyy.MM.dd hh24:mi:ss";
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			this.reportname = this.reportid + "_" + this.reportname;
			String sdate = "";
			String edate = "";
			if (this.startDate != null) {
				sdate = dateFormat.format(this.startDate);
			}
			if (this.endDate != null) {
				edate = dateFormat.format(this.endDate);
			}
			String query = "INSERT INTO IMP_INVENTORY_REP_LOG(REPORTID, REPORTTYPE, CLIENTID, STARTDATE, ENDDATE, REPORTNAME,  CREATEDDATE, STATUS, CREATED_BY,RELEASENO)"
					+ " VALUES('"
					+ this.reportid
					+ "','INVENTORY','"
					+ this.clientid
					+ "',"
					+ "TO_DATE('"
					+ sdate
					+ "','"
					+ dateformat
					+ "'),"
					+ "TO_DATE('"
					+ edate
					+ "','"
					+ dateformat
					+ "'),'"
					+ this.reportname
					+ "',"

					+ "sysdate,'RUNNING','"
					+ this.userLog
					+ "','"
					+ this.releaseNum + "')";

			log.info("--Inventory Insert query-- : " + query);

			db.initialize();
			db.executeDML(query);
			UpdateDetailsLog(reportIDfileList);
		} catch (Exception ex) {
			log.error(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		}
		

		finally {
			if (db != null) {
				db.endConnection();
			}
		}

	}

	/**
	 * Method to verify if files selected for inventory already is included in
	 * another inventory and update fileDetails accordingly
	 */
	public void UpdateDetailsLog(LinkedHashMap<String, String> reportIDfileList) {

		log.info("--UPDATING DETAILS LOG--");
		String reportids = "";
		ConnectDB db = new ConnectDB();
		try {

			db.initialize();

			ArrayList<String> reportIDs = new ArrayList<String>();
			Set<Entry<String, String>> set = reportIDfileList.entrySet();
			Iterator<Entry<String, String>> i = set.iterator();
			while (i.hasNext()) {
				Entry<String, String> me = i.next();
				if (reportIDs.contains(me.getValue())) {
					continue;
				} else {
					reportIDs.add(me.getValue().toString());
				}
			}

			for (int j = 0; j < reportIDs.size(); j++) {
				String existingfileid = "";

				Set<Entry<String, String>> set1 = reportIDfileList.entrySet();
				Iterator<Entry<String, String>> i1 = set1.iterator();
				String existfileid_query = "SELECT fileid_details from imp_inventory_rep_log where reportid='"
						+ this.reportid + "'";

				List<List<String>> field_details = db
						.resultSetToListOfList(existfileid_query);

				if (field_details.size() > 1) {
					existingfileid = field_details.get(1).get(0);

				}
				
				if (!existingfileid.isEmpty()) {
					reportids = existingfileid + " and File ID(s) ";
				} else {
					reportids += "File ID(s)";
				}
				while (i1.hasNext()) {

					Entry<String, String> me = i1.next();
					if (reportIDs.get(j).equals(me.getValue())) {

						reportids += "," + me.getKey();

					}

				}

				reportids += " exists in ReportID " + reportIDs.get(j);

				

			}
			
			String updateQuery = "UPDATE imp_inventory_rep_log set fileid_details='"
					+ reportids.replace("File ID(s),", "File ID(s) ")
					+ "' where reportid='" + this.reportid + "'";
			db.executeDML(updateQuery);
			
			
			log.info("Update Query  : " + updateQuery);

			log.info("---UPDATE COMPLETED---");
		} catch (Exception ex) {
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error has occured.Please report to AIP Team";

		}

		finally {
			if (db != null)
				db.endConnection();
		}

	}

	@Override
	public void storeFileids() {

		// TODO Auto-generated method stub
		ConnectDB db = new ConnectDB();
		try {

			log.info("--STORING FILEIDS--");
			db.initialize();
			for (int i = 0; i < this.listofFileids.size(); i++) {
				String queryfile = "Insert into imp_inventory_rep_log_details(reportid,fileid) values('"
						+ this.reportid
						+ "','"
						+ this.listofFileids.get(i)
						+ "')";
				db.executeDML(queryfile);

			}
		} catch (Exception ex) {
			log.error(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		} finally {
			if (db != null) {
				db.endConnection();
			}
		}

	}

	@Override
	synchronized public void generateReport() {
		// TODO Auto-generated method stub
		try{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		log.info("--GENERATING REPORT---");
		ConnectDB db = new ConnectDB();
		db.initialize();

		List<List<String>> infoList = db
				.resultSetToListOfList("SELECT  created_by,releasetype,data_start_date,data_end_date FROM AIP_CYCLE_MASTER WHERE NVL(subreleasenumber,release_number)='"
						+ this.releaseNum + "'");
		db.endConnection();

		if (infoList.size() > 1) {
			this.rCreatedBy = infoList.get(1).get(0);
			this.releaseDetails = infoList.get(1).get(1);
			this.startDate=dateFormat.parse(infoList.get(1).get(2));
			this.endDate=dateFormat.parse(infoList.get(1).get(3));

		}

		InventoryReportController r = new InventoryReportController();

		r.processRelaseInventory(this.clientid, this.releaseNum,
				this.startDate, this.endDate, this.reportid, this.reportname,
				this.userLog, String.valueOf(this.filteredList.size()),
				this.releaseDetails, this.rCreatedBy);

		log.info("---RELEASE INVENTORY REPORT COMPLETE--" + this.reportname);

		log.info("--RELEASE RELEASING INVENTORY THREAD--");
		}catch(Exception e){
			log.info(e.getMessage());
		}

	}

	@Override
	public void updateTable() {
		// TODO Auto-generated method stub

		log.info("--UPDATING TABLE---");
		ConnectDB db = new ConnectDB();
		try {
			String query = "update IMP_INVENTORY_REP_LOG set status='COMPLETE' where reportid='"
					+ this.reportid + "' and created_by='" + this.userLog + "'";

			db.initialize();
			db.executeDML(query);
		} catch (Exception ex) {
			log.error(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		} finally {
			db.endConnection();
		}

		log.info("--REPORT COMPLETED---");
	}

	public ArrayList<MainLog> getLogList() {
		return logList;
	}

	public ArrayList<String> getListofFileids() {
		return listofFileids;
	}

	public void setListofFileids(ArrayList<String> listofFileids) {
		this.listofFileids = listofFileids;
	}

	public String getReportid() {
		return reportid;
	}

	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

	@Override
	public String getErrorMsg() {
		return errorMsg;
	}

	@Override
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	@Override
	public boolean isHasErrors() {
		return hasErrors;
	}

	@Override
	public void setHasErrors(boolean hasErrors) {
		this.hasErrors = hasErrors;
	}

	public String getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(String releaseNum) {
		this.releaseNum = releaseNum;
	}

	public String getReleaseDetails() {
		return releaseDetails;
	}

	public void setReleaseDetails(String releaseDetails) {
		this.releaseDetails = releaseDetails;
	}

	public String getrCreatedBy() {
		return rCreatedBy;
	}

	public void setrCreatedBy(String rCreatedBy) {
		this.rCreatedBy = rCreatedBy;
	}

}
