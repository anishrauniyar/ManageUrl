package com.vit.ai.inventory.controller;

import java.io.Serializable;

public class MessageObject implements Serializable {

	private static final long serialVersionUID = 7281862700025877800L;

	String clientid = "";
	String releaseTag = "";
	String processstartdate = "";
	String processenddate = "";
	int totalnumberoffiles = 0;
	int totalfileSelected = 0;
	String message = "";
	String type = "";
	String filename = "";
	boolean enableAllSelection = false;

	public boolean isEnableAllSelection() {
		return enableAllSelection;
	}

	public void setEnableAllSelection(boolean enableAllSelection) {
		this.enableAllSelection = enableAllSelection;
	}

	public MessageObject(String clientid, String releaseTag,
			String processstartdate, String processenddate, int totalnumberoffiles,
			int totalfileSelected) {
		super();
		this.clientid = clientid;
		this.releaseTag = releaseTag;
		this.processstartdate = processstartdate;
		this.processenddate = processenddate;
		this.totalnumberoffiles = totalnumberoffiles;
		this.totalfileSelected = totalfileSelected;
		
		if (this.totalfileSelected == totalnumberoffiles) {
			enableAllSelection = true;
			
		} else
			enableAllSelection = false;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	

	public int getTotalnumberoffiles() {
		return totalnumberoffiles;
	}

	public void setTotalnumberoffiles(int totalnumberoffiles) {
		this.totalnumberoffiles = totalnumberoffiles;
	}

	public int getTotalfileSelected() {
		return totalfileSelected;
	}

	public void setTotalfileSelected(int totalfileSelected) {
		this.totalfileSelected = totalfileSelected;
	}

	public String getProcessstartdate() {
		return processstartdate;
	}

	public void setProcessstartdate(String processstartdate) {
		this.processstartdate = processstartdate;
	}

	public String getProcessenddate() {
		return processenddate;
	}

	public void setProcessenddate(String processenddate) {
		this.processenddate = processenddate;
	}

}
