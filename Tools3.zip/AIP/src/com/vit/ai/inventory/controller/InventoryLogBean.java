/* 
 *Class Name : InventoryLogBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.controller;

import java.io.File;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.inventory.model.InventoryLog;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.poireport.controller.MDRReportController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Inventory Log
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 21 Aug 2014
 */
@ManagedBean
@ViewScoped
public class InventoryLogBean extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private ArrayList<InventoryLog> invlogs;
	private DefaultStreamedContent downloadINV;
	private String user;
	private ArrayList<String> users;
	private String reportname;
	private String reportid;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String rpttype = "";
	private String clientid = "";
	private LinkedHashMap<String, String> clients;
	private ArrayList<String> empgroup;
	private ArrayList<String> payor;
	private String winScreenHeight;

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	public String getReportid() {
		return reportid;
	}

	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

	private String query;

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public void setMainLogs(ArrayList<MainLog> mainLogs) {
		

	}

	public ArrayList<String> getUsers() {
		return users;
	}

	public void setUsers(ArrayList<String> users) {
		try {

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> userList = db
					.resultSetToListOfList("SELECT DISTINCT FULLNAME FROM  AIPD_USERS order by 1");
			db.endConnection();

			if (userList.size() > 0) {
				for (int i = 1; i < userList.size(); i++) {
					users.add(userList.get(i).get(0));
				}
			}

			// TODO: handle exception
		} catch (Exception e) {
			displayErrorMessageToUser("Users Not Found", "Inventory Log");
		}
	}

	@PostConstruct
	public void init() {
		if (getUserinfo() != null) {
			this.user = getUserinfo().getFullname();
			this.clients = new LinkedHashMap<>();
			setClients(clients);

		} else {

		}
	}

	public InventoryLogBean() {

		users = new ArrayList<>();
		setUsers(users);
		init();
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void doNothing() {

	}

	public ArrayList<InventoryLog> getInvlogs() {
		return invlogs;
	}


	public void setInvlogs(ArrayList<InventoryLog> invlogs) {
		this.invlogs = invlogs;
	}

	public void downloadReport(String reportname, String reportid,
			String username, String reporttype, String fileid,String releaseno,String clientid,String mdrInput)
			throws ParseException {
		this.reportid = reportid;
		this.reportname = reportname;
		String message="";
		if (!releaseno.isEmpty() && releaseno!=null && reporttype.compareTo("INVENTORY")==0) {
			File file = new File(AIConstant.RELEASE_REPORT_PATH + reportname
					+ ".xlsx");
		
			if (file.exists()) {
				FileController objFC = new FileController(
						AIConstant.RELEASE_REPORT_PATH + reportname + ".xlsx");
				setDownloadINV(objFC.getDownload());
				ConnectDB db = new ConnectDB();
				db.initialize();
				String query= "select fileid_details from imp_inventory_rep_log where reportid = '" + this.reportid + "'";
				List<List<String>> rs = db.resultSetToListOfList(query);
				db.endConnection();
				if(rs!=null)
				{
					if(rs.size()>1)
					{
						message = rs.get(1).get(0);
					}
				}
				if(!message.isEmpty())
				{
					displayInfoMessageToUser(message + "\n\r these files are discarded in this inventory", "WARNING");
					
				}
			} else {

				setDownloadINV(null);
				System.out.println("FileNOTFOUND");
				displayErrorMessageToUser("File not found.", "ERROR Dwonloading");

			}
		}
		
		if (releaseno.isEmpty() && reporttype.compareTo("INVENTORY") == 0) {
			File file = new File(AIConstant.INV_REP_DUMP_LOCATION + reportname
					+ ".xlsx");
			if (file.exists()) {
				FileController objFC = new FileController(
						AIConstant.INV_REP_DUMP_LOCATION + reportname + ".xlsx");
				setDownloadINV(objFC.getDownload());
			} else {

				setDownloadINV(null);
				System.out.println("FileNOTFOUND");
				displayErrorMessageToUser("File not found.", "ERROR Dwonloading");

			}
		} 
		
		 if(reporttype.compareTo("MDR")==0){
			 empgroup = new ArrayList<String>();
			 payor = new ArrayList<String>();
			 String clientName="";
			 String noOffile="";
			 ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> infoList = db
						.resultSetToListOfList(" SELECT DISTINCT a.empgrp,b.payor FROM imp_main_log a " +
								"JOIN IMP_LAYOUTS b ON a.layoutid=b.layoutid "
 
        			+" join imp_inventory_rep_log_details c " 
        			+" ON a.fileid||'_'||a.dmfileid=c.fileid and c.reportid='"+reportid+"'");
				List<List<String>> clientname = db
						.resultSetToListOfList("SELECT DISTINCT CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS  where CLIENTID='"+clientid+"'");
				List<List<String>> fileList = db
						.resultSetToListOfList("SELECT count(fileid) FROM imp_inventory_rep_log_details  where reportid='"+reportid+"'");
				db.endConnection();

				if (infoList.size() > 0) {
					for (int i = 1; i < infoList.size(); i++) {
						if(empgroup.contains(infoList.get(i).get(0))){
							continue;
						}else{
							empgroup.add(infoList.get(i).get(0));
						}
						{
							if(payor.contains(infoList.get(i).get(1))){
								continue;
							}else{
								payor.add(infoList.get(i).get(1));
							}
						}
					
						
					}
				}
				if(clientname.size()>0){
					clientName=clientname.get(1).get(0);
				}
				if(fileList.size()>0){
					noOffile=fileList.get(1).get(0);
				}
			 
			String fileID = reportid;
			CustomUtility customUtility = new CustomUtility();
			String fileName = reportname
					+ customUtility.getDateForReport();

			MDRReportController r = new MDRReportController();

			SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
			
			
			r.process(fileID, fileName,clientid,clientName,empgroup,payor,username,dformat.format(Calendar.getInstance().getTime()),noOffile,mdrInput);

			FileController objFC = new FileController(
					AIConstant.FMDR_REPORT_DUMP_LOCATION + fileName + ".xlsx");
			setDownloadINV(objFC.getDownload());

		}


	}

	/**
	 * This methiod is disabled for now. 
	 */
	/*public void regenerateInventory(String username,String releasetag) throws ParseException {

		// String FileName = "O:\\data1\\AIP\\datadashboard\test.xlsx";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String clientid = "";
		String reportname = "";
		String startdate = "";
		String enddate = "";
		String fileid = "";
		boolean fileSelected = false;
		Date sdate = null;
		Date edate = null;
		String createdby = "";
		String totalfile="";
		String query = "select CLIENTID,STARTDATE,ENDDATE,REPORTNAME,CREATED_BY from imp_inventory_rep_log where reportid='"
				+ this.reportid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		List<List<String>> filelist = db.resultSetToListOfList("SELECT Count(*) from imp_inventory_rep_log_details  WHERE reportid='"
				+ this.reportid + "'");
		if (filelist != null) {
			if (filelist.size() > 1) {
				
				totalfile = filelist.get(1).get(0);
				
				
			}
		}
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					clientid = rs.get(i).get(0);
					startdate = rs.get(i).get(1);
					enddate = rs.get(i).get(2);
					reportname = rs.get(i).get(3);
					createdby = rs.get(i).get(4);
				}
			}
		}

		fileSelected=true;
		
		if (!startdate.isEmpty()) {
			sdate = dateFormat.parse(startdate);
		}
		if (!enddate.isEmpty()) {
			edate = dateFormat.parse(enddate);
		}
		CustomUtility obj = new CustomUtility();
		// String fileName="AIP_INVENTORY_LOG";

		displayInfoMessageToUser(
				"Inventory is in progress.Refer to log for status",
				"Re-Generate Inventory");
		if(releasetag.compareTo("ReleaseTag")==0){
			GenerateRelease genInv = new GenerateRelease();
			genInv.new GenerateExcel(totalfile,clientid, reportname.split("\\_")[3],sdate, edate, fileSelected, fileid,
					createdby, obj.getDateForReport().toString(), reportname,
					"UPDATE", this.reportid).init();
		}else{
		GenerateInventory genInv = new GenerateInventory();
		genInv.new GenerateExcel(totalfile,clientid, sdate, edate, fileSelected,fileid,
				createdby, obj.getDateForReport().toString(), reportname,
				"UPDATE", this.reportid).init();
		}
		updateRepLog();

	}*/

	public void updateRepLog() {
		String query = "Update imp_inventory_rep_log set status='RUNNING' where reportid='"
				+ this.reportid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		db.executeDML(query);
		db.endConnection();
		handleFilterChange();

	}

	public DefaultStreamedContent getDownloadINV() {
		return downloadINV;
	}

	public void setDownloadINV(DefaultStreamedContent downloadINV) {
		this.downloadINV = downloadINV;
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		// RequestContext.getCurrentInstance().execute("patternTable.filter();");
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public String getRpttype() {
		return rpttype;
	}

	public void setRpttype(String rpttype) {
		this.rpttype = rpttype;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clientList = db
				.resultSetToListOfList("SELECT DISTINCT B.CLIENTID , A.CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS A JOIN IMP_INVENTORY_REP_LOG  B ON   A.CLIENTID=B.CLIENTID order by clientid asc");

		db.endConnection();

		if (clientList.size() > 0) {
			for (int i = 1; i < clientList.size(); i++) {
				clients.put(clientList.get(i).get(0) + "-("
						+ clientList.get(i).get(1) + ")", clientList.get(i)
						.get(0));
			}
		}
	}

	public void submit(String query) {
		this.invlogs = new ArrayList<InventoryLog>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					InventoryLog log = new InventoryLog(rs.get(i).get(0), rs
							.get(i).get(1), rs.get(i).get(2), rs.get(i).get(3),
							rs.get(i).get(4), rs.get(i).get(5), rs.get(i)
									.get(6), rs.get(i).get(7),
							rs.get(i).get(8), rs.get(i).get(9), rs.get(i).get(
									10), rs.get(i).get(11), rs.get(i).get(12),rs.get(i).get(13),rs.get(i).get(14));
					this.invlogs.add(log);
				}
			}
		}

	}

	public void handleFilterChange() {
		
		if(this.user.isEmpty() && this.clientid.isEmpty() && this.rpttype.isEmpty())
		{
			this.invlogs=new ArrayList<>();
			displayErrorMessageToUser("Please Select atleast one filter value", "ERROR");
			return;
		}
		String query=buildQuery();
		submit(query);
	}
	
	public String buildQuery()
	{
		String query = "select reportid,reportname,created_by,createddate,status,clientid,startdate,enddate,reporttype,FILEIDLIST,processstartdate,processenddate,releaseno,fileid_details,TOPNVALUE from imp_inventory_rep_log where";
		
		if(!this.user.isEmpty())
		{
			query=query + " created_By='"+this.user.replace("'", "''")+"' and ";
		}
		if(!this.clientid.isEmpty())
		{
			query=query + " clientid='"+ this.clientid + "' and ";
		}
		if(!this.rpttype.isEmpty())
		{
			query = query + " reporttype='" + this.rpttype +"' and ";
		}
		
		if(query.endsWith(" and "))
		{
			query = query.substring(0, query.length()-4) ;
		}
		
		query=query + "order by reportid desc";
		
		System.out.println("Query for Report Log : " + query);
		return query;
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

}
