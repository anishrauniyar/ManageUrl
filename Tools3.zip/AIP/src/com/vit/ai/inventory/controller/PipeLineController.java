package com.vit.ai.inventory.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.inventory.dao.PipeLineDAO;
import com.vit.ai.inventory.model.PipeLineModel;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

@ManagedBean
@ViewScoped
public class PipeLineController extends AbstractController {

	private String clientid;
	protected String winScreenHeight;

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	private ArrayList<PipeLineModel> listofFiles;
	private ArrayList<PipeLineModel> filteredLogs;
	private LinkedHashMap<String, String> clients;
	private static final Logger logger = LoggerFactory
			.getLogger(PipeLineController.class);

	public String getClientid() {
		return clientid;
	}
	
	public void setValue() {
		this.winScreenHeight = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("winScreenHeight");

	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public PipeLineController() {
		init();

	}

	public void init() {
		this.listofFiles = new ArrayList<>();
		this.clients = new LinkedHashMap<>();
		setClients(clients);
		FacesContext facesContext = FacesContext.getCurrentInstance();
		if(facesContext.getExternalContext()
				.getRequestParameterMap().get("clid")!=null)
		{
		
		this.clientid = facesContext.getExternalContext()
				.getRequestParameterMap().get("clid");
		if(!this.clientid.isEmpty() || this.clientid!=null)
		{
			handleClientChange();
			
					}
		}
		
	}

	public ArrayList<PipeLineModel> getListofFiles() {
		return listofFiles;
	}

	public void setListofFiles(ArrayList<PipeLineModel> listofFiles) {
		this.listofFiles = listofFiles;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		System.out.println("setting");
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clientList = db
				.resultSetToListOfList("SELECT DISTINCT B.CLIENTID , A.CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS A JOIN IMP_MAIN_LOG  B ON   A.CLIENTID=B.CLIENTID order by clientid asc");

		db.endConnection();

		if (clientList.size() > 0) {
			for (int i = 1; i < clientList.size(); i++) {
				clients.put(clientList.get(i).get(0) + "-("
						+ clientList.get(i).get(1) + ")", clientList.get(i)
						.get(0));
			}
		}
		System.out.println(this.clients.size());
		this.clients = clients;
	}

	/**
	 * Functions that gets the data from dao after a client change request is
	 * made
	 */
	public int handleClientChange() {
		logger.info("--Changing Client to : " + this.clientid);
		if (this.clientid != null || !this.clientid.isEmpty()) {
			this.listofFiles = new ArrayList<>();
			this.listofFiles = new PipeLineDAO().getAllFiles(this.clientid);
			this.filteredLogs = this.listofFiles;
			// pushMethodinBackground();
		
			return 1;
		} else {
			logger.error("No Client Selected");
			displayErrorMessageToUser("Please select a client",
					"No Client Selected");
			return 0;
		}

	}

	/**
	 * Update function for live monitor
	 */
	public int update() {
		if (this.listofFiles != null) {
			if (this.clientid != null || !this.clientid.isEmpty()) {
				System.out.println("Updating");
				this.listofFiles = new PipeLineDAO().getAllFiles(this.clientid);
				this.filteredLogs = this.listofFiles;
				return 1;
			} else {
				logger.error("No Client Selected");
				return 0;
			}
		} else {
			logger.error("List is Null");
			return 0;
		}
	}

	public ArrayList<PipeLineModel> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<PipeLineModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	/**
	 * Runs Monitoring method in a runnable interface
	 */
	/*
	 * public void pushMethodinBackground() { Thread t = new Thread(new
	 * Runnable(){ public void run() {
	 * System.out.println("--Starting Live Monitoring---"); liveMonitor(); } });
	 * 
	 * t.start(); }
	 *//**
	 * Method that refreshes the page after every 5 minutes
	 */
	/*
	 * public void liveMonitor() {
	 * 
	 * while(true) { System.out.println("Inside Monitor"); int stat = update();
	 * // RequestContext.getCurrentInstance().update("inventoryLogTable");
	 * System.out.println("After Update"); if(stat==0) { break; } try {
	 * //Thread.sleep(18000); Thread.sleep(20); } catch (InterruptedException e)
	 * { // TODO Auto-generated catch block logger.error("Thread Interrupted");
	 * e.printStackTrace(); } }
	 * 
	 * }
	 */
}
