package com.vit.ai.inventory.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.inventory.principle.InventoryReports_Standard;
import com.vit.ai.poireport.controller.InventoryReportController;
import com.vit.dbconnection.ConnectDB;

public class Inventory implements InventoryReports_Standard {

	private ArrayList<MainLog> logList;
	private ArrayList<MainLog> filteredList;
	private ArrayList<String> listofFileids;
	private String reportid;
	private String userLog;
	private String clientid;
	private String reportname;
	private String errorMsg="";
	private boolean hasErrors=false;
	
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	private boolean fileSelected;
	private Date startDate;
	private Date endDate;

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	

	public boolean isFileSelected() {
		return fileSelected;
	}

	public void setFileSelected(boolean fileSelected) {
		this.fileSelected = fileSelected;
	}

	public ArrayList<MainLog> getFilteredList() {
		return filteredList;
	}

	public void setFilteredList(ArrayList<MainLog> filteredList) {
		this.filteredList = filteredList;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public void setLogList(ArrayList<MainLog> logList) {
		this.logList = logList;
		this.setHasErrors(false);
	}

	public String getUserLog() {
		return userLog;
	}

	public void setUserLog(String userLog) {
		this.userLog = userLog;
	}

	static Logger log = Logger.getLogger(Inventory.class.getName());

	public Inventory(ArrayList<MainLog> logList, 
			String userLog, String clientid,
			String reportname, boolean fileSelected, Date startDate,
			Date endDate) {
		super();
		this.logList = new ArrayList<>();
		this.listofFileids = new ArrayList<>();
		this.logList = logList;
		this.userLog = userLog;
		this.clientid = clientid;
		this.reportname = reportname;
		this.fileSelected = fileSelected;
		this.startDate = startDate;
		this.endDate = endDate;
		log.info("------GENERATING INVENTORY REPORT BY " + this.userLog
				+ " FOR CLIENT " + this.clientid + " ---------------");
	}

	@Override
	public void getSelectedFiles() {

		try
		{
		if (this.filteredList.size() > 0) {
			for (int i = 0; i < this.filteredList.size(); i++) {
				this.listofFileids.add(this.filteredList.get(i)
						.getMergedFileId());
			}
			
			log.info("--TOTAL NUMBER OF MERGED FILEIDS  " + this.listofFileids.size() + "----");
		}
		}
		catch(Exception ex)
		{
			log.info(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
			return;
		}
		

	}

	@Override
	/**
	 * No specific Filters Required.Add all files to the list
	 */
	public void filterFiles() {
		// TODO Auto-generated method stub

		log.info("--FILTERING FILES---");
		
		log.info("--TOTAL FILES ---" + this.logList.size());
		
		if(this.logList.size()<1)
		{
			this.hasErrors = true;
			this.errorMsg = "No Files Selected";
			return;
		}
		
		this.filteredList = new ArrayList<>();
		
		log.info("--NO FILTERS APPLIED---");
		
		this.filteredList = this.logList;
		
		log.info("TOTAL SIZE AFTER FILTER --- " + this.filteredList.size());

	}

	@Override
	public void generateReportid() {
		// TODO Auto-generated method stub
		ConnectDB db = new ConnectDB();
		try
		{
		log.info("---GENERATING REPORTID -----");
		
		db.initialize();
		String query = "SELECT Max(reportid)+1 FROM imp_inventory_rep_log";
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				this.reportid = rs.get(1).get(0);
			}
			else
			{
				this.reportid = "0";
			}
		}
		else
		{
			this.reportid = "0";
		}
		
		log.info("-----REPORTID " + this.reportid + "----");
		}
		catch(Exception ex)
		{
			log.error(ex.toString());

			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		}
		finally
		{
			db.endConnection();
		}

	}

	@Override
	public void storeReport() {
		// TODO Auto-generated method stub
		ConnectDB db = new ConnectDB();
		try
		{
			log.info("--INSERTING REPORT DETAILS---");
		String dateformat = "yyyy.MM.dd hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		this.reportname= this.reportid + "_" + this.reportname;
		String sdate = "";
		String edate = "";
		if (this.startDate != null) {
			sdate = dateFormat.format(this.startDate);
		}
		if (this.endDate != null) {
			edate = dateFormat.format(this.endDate);
		}
		String query = "INSERT INTO IMP_INVENTORY_REP_LOG(REPORTID, REPORTTYPE, CLIENTID, STARTDATE, ENDDATE, REPORTNAME,  CREATEDDATE, STATUS, CREATED_BY)"
				+ " VALUES('"
				+ this.reportid
				+ "','INVENTORY','"
				+ this.clientid
				+ "',"
				+ "TO_DATE('"
				+ sdate
				+ "','"
				+ dateformat
				+ "'),"
				+ "TO_DATE('"
				+ edate
				+ "','"
				+ dateformat
				+ "'),'"
				+ this.reportname
				+ "',"
				+ "sysdate,'RUNNING','" + this.userLog.replace("'","''")+ "')";
		
		log.info("Inventory Insert query : " + query);
		
		db.initialize();
		db.executeDML(query);
		}
		catch(Exception ex)
		{
			log.error(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		}
		
		finally
		{
			if(db!=null)
			{
				db.endConnection();
			}
		}

	}

	@Override
	public void storeFileids() {
		// TODO Auto-generated method stub
		ConnectDB db = new ConnectDB();
		try
		{
		
			log.info("--STORING FILEIDS--");
		db.initialize();
		for(int i=0;i<this.listofFileids.size();i++)
		{
			String queryfile="Insert into imp_inventory_rep_log_details(reportid,fileid) values('"+this.reportid+"','"+this.listofFileids.get(i)+"')";
			db.executeDML(queryfile);
			
		}
		}
		catch(Exception ex)
		{
			log.error(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		}
		finally
		{
			if(db!=null)
			{
				db.endConnection();
			}
		}

	}

	@Override
	synchronized
	public void generateReport() {
		// TODO Auto-generated method stub		

		log.info("--GENERATING REPORT---");
		InventoryReportController r = new InventoryReportController();

		r.process(String.valueOf(this.filteredList.size()),this.clientid, this.startDate, this.endDate, this.reportid,
				this.reportname, this.userLog);
		log.info("---INVENTORY REPORT COMPLETE--" + this.reportname);	
		
		
		
		

	}

	@Override
	public void updateTable() {
		// TODO Auto-generated method stub

		log.info("--UPDATING TABLE---");
		ConnectDB db = new ConnectDB();
		try
		{
		String query = "update IMP_INVENTORY_REP_LOG set status='COMPLETE' where reportid='"
				+ this.reportid
				+ "' and created_by='"
				+ this.userLog
				+ "'";

		db.initialize();
		db.executeDML(query);
		}
		catch(Exception ex)
		{
			log.error(ex.toString());
			this.hasErrors = true;
			this.errorMsg = "Unexpected Error.Please report to AIP Team";
		}
		finally
		{
		db.endConnection();
		}
		
		log.info("--REPORT COMPLETED---");
	}

	public ArrayList<MainLog> getLogList() {
		return logList;
	}

	

	public ArrayList<String> getListofFileids() {
		return listofFileids;
	}

	public void setListofFileids(ArrayList<String> listofFileids) {
		this.listofFileids = listofFileids;
	}

	public String getReportid() {
		return reportid;
	}

	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

	@Override
	public String getErrorMsg() {
		return errorMsg;
	}

	@Override
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	@Override
	public boolean isHasErrors() {
		return hasErrors;
	}

	@Override
	public void setHasErrors(boolean hasErrors) {
		this.hasErrors = hasErrors;
	}

	

}
