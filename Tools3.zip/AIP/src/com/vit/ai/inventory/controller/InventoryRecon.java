/*
 *Class Name : InventoryRecon.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;

import com.vit.ai.commons.model.MainLogDataModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.session.FilterLogController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Inventory Recon
 * 
 * @author Binesh Sah
 * 
 * @author Aashish Dhungana 2015/08/20
 * 
 * @author Anish Rauniyar
 * 
 * @version 1.0 26 May 2015
 */
@ManagedBean
@ViewScoped
public class InventoryRecon extends MainLogBean {

	private final Logger log = Logger.getLogger(InventoryRecon.class);
	
	private String hiservertodel = "";
	private String hischematodel = "";
	private ArrayList<String> hiServernames;
	private boolean schemanameChanged = false;
	private String reportID;
	private ArrayList<String> reportsIDs;
	private String filtertype;
	private String selectedfiltertype;
	private String startDate_report;
	private String endDate_report;
	private String todaysDate_report;
	protected ArrayList<String> releaseNos;
	private String releaseNo;
	private int noofFile;
	private int nooftransferSuccess;
	private int notoftransferFailed;
	private int noofreconException;
	private int noofnottransfer;
	
	protected ArrayList<String> appIds;
	protected String appId = "";
	
	protected ArrayList<String> releaseTags;
	protected String releaseTag = "";
	
	

	public ArrayList<String> getReleaseTags() {
		return releaseTags;
	}

	public void setReleaseTags(ArrayList<String> releaseTags) {
		this.releaseTags = releaseTags;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public ArrayList<String> getAppIds() {
		return appIds;
	}

	public void setAppIds(ArrayList<String> appIds) {
		String query = "SELECT DISTINCT(APP_ID) FROM IMP_FILES_RELTAG_RELN WHERE CLIENTID = '"+filterData.getClientID()+"'";
		log.info("App ID: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					appIds.add(rs.get(i).get(0));
				}
			}
		}
	}
	
	public int getNoofFile() {
		return noofFile;
	}

	public void setNoofFile(int noofFile) {
		this.noofFile = noofFile;
	}

	public int getNooftransferSuccess() {
		return nooftransferSuccess;
	}

	public void setNooftransferSuccess(int nooftransferSuccess) {
		this.nooftransferSuccess = nooftransferSuccess;
	}

	public int getNotoftransferFailed() {
		return notoftransferFailed;
	}

	public void setNotoftransferFailed(int notoftransferFailed) {
		this.notoftransferFailed = notoftransferFailed;
	}

	public int getNoofreconException() {
		return noofreconException;
	}

	public void setNoofreconException(int noofreconException) {
		this.noofreconException = noofreconException;
	}

	public ArrayList<String> getReleaseNos() {
		return releaseNos;
	}

	public void setReleaseNos(ArrayList<String> releaseNos) {
		System.out.println("check");
		
		String query = "select  nvl(SUBRELEASENUMBER,release_number) as releaseno from AIP_CYCLE_MASTER";
		if (filterData.getClientID() != null) {
			query = query + " where  clientid='" + filterData.getClientID()+ "' order by sn desc";
			
		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {
					System.out.println(rs.get(i).get(0) + "releaseno");
					releaseNos.add(rs.get(i).get(0));
				}
			}
		}
	}

	public String getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(String releaseNo) {
		this.releaseNo = releaseNo;
	}

	public String getStartDate_report() {
		return startDate_report;
	}

	public void setStartDate_report(String startDate_report) {
		this.startDate_report = startDate_report;
	}

	public String getEndDate_report() {
		return endDate_report;
	}

	public void setEndDate_report(String endDate_report) {
		this.endDate_report = endDate_report;
	}

	public String getTodaysDate_report() {
		return todaysDate_report;
	}

	public void setTodaysDate_report(String todaysDate_report) {
		this.todaysDate_report = todaysDate_report;
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}

	public String getSelectedfiltertype() {
		return selectedfiltertype;
	}

	public void setSelectedfiltertype(String selectedfiltertype) {
		this.selectedfiltertype = selectedfiltertype;
	}

	public String getHiservertodel() {
		return hiservertodel;
	}

	public void setHiservertodel(String hiservertodel) {
		System.out.println("Setting  : " + hiservertodel);
		this.hiservertodel = hiservertodel;
	}

	public String getHischematodel() {
		return hischematodel;
	}

	public void setHischematodel(String hischematodel) {
		this.hischematodel = hischematodel;
	}

	public InventoryRecon() {

		this.init();
	}

	@Override
	public void init() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));

		setTodaysDate(new Date());

		clients = new LinkedHashMap<String, String>();
		setClients(clients);

	}

	private static final long serialVersionUID = 1L;

	@Override
	public void filterLog() {
		try{
		String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot()
					.findComponent("frmML:inventoryReconLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}

		String clid = filterData.getClientID();
		if (clid.isEmpty()) {
			displayErrorMessageToUser("No Client Selected", "ERROR");
			return;
		}

		
		String query = "SELECT  A, FILEID, CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, FILEDATE,FILE_RECORD_CNT,  TRANSFER_RECORD, IMPORT_RECORD_CNT, VARIANCE1, "
						+" STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, NVL(TRANSFERSTATUS,'NOT TRANSFERED'), "
						+" RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE FROM (  SELECT 'DATA' AS A, A.FILEID, NULL AS CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, " 
						+" FILEDATE,FILE_RECORD_CNT, TRANSFER_RECORD, IMPORT_RECORD_CNT AS IMPORT_RECORD_CNT , NULL VARIANCE1 ,STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, "
						+" EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, TRANSFERSTATUS, RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE " 
						+" FROM AIP_DASHBOARD_INVENTORY_RECON A  ";
		if (clid != null && !clid.equals("")) {
			query += "WHERE  CLIENTID='" + clid + "' ";
			if (startDate != null && !startDate.equals("")) {
				query += " AND PROCESSDATE " 
						+ " >= TO_TIMESTAMP('" + dateFormat.format(startDate)
						+ "','" + timeStampFormat + "')";
			}

			if (endDate != null && !endDate.equals("")) {
				query += " AND PROCESSDATE " 
						+ " <= TO_TIMESTAMP('" + dateFormat.format(endDate)
						+ "','" + timeStampFormat + "')";
			}
		} else if (clid == null || clid.equals(""))

		{
			if (startDate != null && !startDate.equals("")) {
				query += " WHERE PROCESSDATE"
						+ " >= TO_TIMESTAMP('" + dateFormat.format(startDate)
						+ "','" + timeStampFormat + "')";
			}

			if (endDate != null && !endDate.equals("")) {
				query += " AND PROCESSDATE "
						+ " <= TO_TIMESTAMP('" + dateFormat.format(endDate)
						+ "','" + timeStampFormat + "')";
			}
		} else if (clid == null || clid.equals("") && startDate == null
				|| startDate.equals("")) {
			if (endDate != null && !endDate.equals("")) {
				query += "WHERE PROCESSDATE " 
						+ " <= TO_TIMESTAMP('" + dateFormat.format(endDate)
						+ "','" + timeStampFormat + "')";
			}
		}

		query += " UNION ALL "  
				  +" SELECT 'SUMMARY' AS A,A.FILEID, COUNT(*) AS CNT , " 
				  +" NULL DMFILEID, NULL FILENAME,NULL CLIENTID, NULL LAYOUTID,NULL DATATYPE,  NULL FILE_SIZE,NULL FILEDATE,NULL FILE_RECORD_CNT, " 
				  +" SUM(TRANSFER_RECORD) AS TRANSFER_RECORD, "
				   +" SUMMARY_IMPORT_CNT as IMPORT_RECORD_CNT,  SUMMARY_IMPORT_CNT-SUM(TRANSFER_RECORD) AS  VARIANCE1,NULL STATUS_IMPORT, NULL PROCESSSTATUS,  NULL IMPORTSERVER, " 
				   +" NULL INFO13, NULL EXCEPTIONDETAIL, NULL EMPGRP, NULL EXCEPTION_REMARK, NULL PAYOR, NULL AITABLENAME,  NULL HISCHEMANAME, NULL HITABLENAME, " 
				   +" NULL TRANSFERSTATUS, NULL RETRANSFER_DETAIL, NULL WHERECONDITION,PROCESSDATE " 
				 +" FROM AIP_DASHBOARD_INVENTORY_RECON A ";

		if (clid != null && !clid.equals("")) {
			query += " WHERE  CLIENTID='" + clid + "' ";
			if (startDate != null && !startDate.equals("")) {
				query += " AND PROCESSDATE "
						+ " >= TO_TIMESTAMP('" + dateFormat.format(startDate)
						+ "','" + timeStampFormat + "')";
			}

			if (endDate != null && !endDate.equals("")) {
				query += " AND PROCESSDATE "
						+ " <= TO_TIMESTAMP('" + dateFormat.format(endDate)
						+ "','" + timeStampFormat + "')";
			}
		} else if (clid == null || clid.equals(""))

		{
			if (startDate != null && !startDate.equals("")) {
				query += " WHERE PROCESSDATE " 
						+ " >= TO_TIMESTAMP('" + dateFormat.format(startDate)
						+ "','" + timeStampFormat + "')";
			}

			if (endDate != null && !endDate.equals("")) {
				query += " AND PROCESSDATE " 
						+ " <= TO_TIMESTAMP('" + dateFormat.format(endDate)
						+ "','" + timeStampFormat + "')";
			}
		} else if (clid == null || clid.equals("") && startDate == null
				|| startDate.equals("")) {
			if (endDate != null && !endDate.equals("")) {
				query += "WHERE PROCESSDATE " 
						+ " <= TO_TIMESTAMP('" + dateFormat.format(endDate)
						+ "','" + timeStampFormat + "')";
			}
		}

		query += " GROUP BY A.FILEID,SUMMARY_IMPORT_CNT,PROCESSDATE ) ORDER BY FILEID,A";

		System.out.println(query);
		setQuery(query);

		mainLogs = new ArrayList<MainLog>();
		setMainLogs(mainLogs);

		importMainLogs = new MainLogDataModel(mainLogs);
		}catch(Exception e){
			displayErrorMessageToUser("Query execution failed. Please try again", "");
		}
	}

	@Override
	public void setMainLogs(ArrayList<MainLog> mainLogs) {
		this.noofFile=0;
		this.noofreconException=0;
		this.nooftransferSuccess=0;
		this.notoftransferFailed=0;
		this.noofnottransfer=0;
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> logList = db.resultSetToListOfList(query);
		db.endConnection();
		
		if (logList.size() > 0) {
			
			for (int i = 1; i < logList.size(); i++) {

				MainLog obj = new MainLog(i, logList.get(i).get(0), logList
						.get(i - 1).get(1), logList.get(i).get(1), logList.get(
						i).get(2), logList.get(i - 1).get(3), logList.get(i)
						.get(3), logList.get(i).get(4), logList.get(i).get(5),
						logList.get(i).get(6), logList.get(i).get(7), logList
								.get(i).get(8), logList.get(i).get(9), logList
								.get(i).get(10), logList.get(i).get(11),
						logList.get(i).get(12), logList.get(i).get(13), logList
								.get(i).get(14), logList.get(i).get(15),
						logList.get(i).get(16), logList.get(i).get(17), logList
								.get(i).get(18), logList.get(i).get(19),
						logList.get(i).get(20), logList.get(i).get(21), logList
								.get(i).get(22), logList.get(i).get(23),
						logList.get(i).get(24), logList.get(i).get(25), logList
								.get(i).get(26), logList.get(i).get(27),logList.get(i).get(28));
				
				System.out.println("type "+logList.get(i).get(0));
				if(logList.get(i).get(0).compareTo("DATA")==0 && logList.get(i - 1).get(3).compareTo(logList.get(i).get(3))!=0){
					
					noofFile++;
				}
				if(logList.get(i).get(25).compareTo("SUCCESS")==0 && logList.get(i - 1).get(3).compareTo(logList.get(i).get(3))!=0){
					nooftransferSuccess++;
				}
				if(logList.get(i).get(25).compareTo("FAILED")==0){
					notoftransferFailed++;
				}
				if(logList.get(i).get(0).compareTo("DATA")==0 && logList.get(i).get(25).compareTo("NOT TRANSFERED")==0){
					
					noofnottransfer++;
				}
				System.out.println("variance "+logList.get(i).get(13));
				if(logList.get(i).get(13)!=null && !logList.get(i).get(13).isEmpty()){
					if(Integer.parseInt(logList.get(i).get(13))>0){
						noofreconException++;
					}
				}
				
				if (this.mainLogs.size() > 0) {
					if (isSummaryRendered(obj)) {
						mainLogs.add(obj);
					} else {
						mainLogs.get(mainLogs.size() - 1).setVariance(
								obj.getVariance());
					}
				}

				else {
					mainLogs.add(obj);
				}

			}

		}
		setNooftransferSuccess(nooftransferSuccess);
		setNotoftransferFailed(notoftransferFailed);
		setNoofreconException(noofreconException);
		setNoofnottransfer(noofnottransfer);

	}

	public String handleRowcolor(String count, String type) {

		String value = "";
		if (count != null && !count.isEmpty()) {
			int cnt = Integer.parseInt(count);

			if (cnt > 1 && type.compareTo("SUMMARY") == 0) {
				value = "#color1";
			}
		}
		return value;
	}

	public ArrayList<String> getHiServernames() {
		return hiServernames;
	}

	public void setHiServernames(ArrayList<String> hiServernames) {
		this.hiServernames = hiServernames;
	}

	public boolean isSchemanameChanged() {
		return schemanameChanged;
	}

	public void setSchemanameChanged(boolean schemanameChanged) {
		this.schemanameChanged = schemanameChanged;
	}

	public void handleFilterchange() {
		setSelectedfiltertype(this.getFiltertype());
		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			reportsIDs = new ArrayList<>();
			setReportsIDs(reportsIDs);
		}
		if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
			releaseNos = new ArrayList<String>();
			setReleaseNos(this.releaseNos);
		}
		if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			appIds = new ArrayList<String>();
			setAppIds(this.appIds);
		}

	}

	public void handleReportID() {
		reportsIDs = new ArrayList<>();
		setReportsIDs(reportsIDs);
		releaseNos = new ArrayList<String>();
		setReleaseNos(releaseNos);
		this.appId = "";
		appIds = new ArrayList<String>();
		setAppIds(appIds);
		handleAppIdChange();
	}
	
	public void handleAppIdChange() {
		log.info("This is an app id change filter.");
		String query = "SELECT DISTINCT releasetagidbyapp FROM (SELECT releasetagidbyapp FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+this.appId+"'" + 
						" ORDER BY CREATED DESC) UNION SELECT DISTINCT RELTAG FROM imp_files_reltag_reln WHERE app_id = '"+this.appId+"'";
		log.info(query);
		this.releaseTags = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					releaseTags.add(rs.get(i).get(0));
				}
			}
		} 
		//setReleaseTags(releaseTags);
	}
	
	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	public ArrayList<String> getReportsIDs() {
		return reportsIDs;
	}

	public void setReportsIDs(ArrayList<String> reportsIDs) {
		String query = "SELECT REPORTID FROM  IMP_INVENTORY_REP_LOG";
		if (filterData.getClientID() != null) {
			query = query + " where clientid='" + filterData.getClientID()
					+ "' and reporttype='INVENTORY' order by REPORTID DESC ";
			
			System.out.println("QUERY : "  + query);

		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					reportsIDs.add(rs.get(i).get(0));
				}
			}
		}
	}

	public void filterbyReleaseno(){
		try{
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot()
					.findComponent("frmML:inventoryReconLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.releaseNo.isEmpty() || this.releaseNo == null)

		{
			displayErrorMessageToUser("Please select a releasetag", "ERROR");
			return;

		}
		String clid = filterData.getClientID();
		if (clid.isEmpty()) {
			displayErrorMessageToUser("No Client Selected", "ERROR");
			return;
		}

		
		String query = "SELECT  A, FILEID, CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, FILEDATE,FILE_RECORD_CNT,  TRANSFER_RECORD, IMPORT_RECORD_CNT, VARIANCE1, "
				+" STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, NVL(TRANSFERSTATUS,'NOT TRANSFERED'), "
				+" RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE FROM (  SELECT 'DATA' AS A, A.FILEID, NULL AS CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, " 
				+" FILEDATE,FILE_RECORD_CNT, TRANSFER_RECORD, IMPORT_RECORD_CNT AS IMPORT_RECORD_CNT , NULL VARIANCE1 ,STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, "
				+" EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, TRANSFERSTATUS, RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE " 
				+" FROM AIP_DASHBOARD_INVENTORY_RECON A  ";
		if (clid != null && !clid.equals("")) {
			query += "WHERE  CLIENTID='" + clid + "' and releaseno='"+this.releaseNo+"'";
		}
		query += " UNION ALL "  
				  +" SELECT 'SUMMARY' AS A,A.FILEID, COUNT(*) AS CNT , " 
				  +" NULL DMFILEID, NULL FILENAME,NULL CLIENTID, NULL LAYOUTID,NULL DATATYPE,  NULL FILE_SIZE,NULL FILEDATE,NULL FILE_RECORD_CNT, " 
				  +" SUM(TRANSFER_RECORD) AS TRANSFER_RECORD, "
				   +" SUMMARY_IMPORT_CNT as IMPORT_RECORD_CNT,  SUMMARY_IMPORT_CNT-SUM(TRANSFER_RECORD) AS  VARIANCE1,NULL STATUS_IMPORT, NULL PROCESSSTATUS,  NULL IMPORTSERVER, " 
				   +" NULL INFO13, NULL EXCEPTIONDETAIL, NULL EMPGRP, NULL EXCEPTION_REMARK, NULL PAYOR, NULL AITABLENAME,  NULL HISCHEMANAME, NULL HITABLENAME, " 
				   +" NULL TRANSFERSTATUS, NULL RETRANSFER_DETAIL, NULL WHERECONDITION,PROCESSDATE " 
				 +" FROM AIP_DASHBOARD_INVENTORY_RECON A ";

		if (clid != null && !clid.equals("")) {
			query += " WHERE  CLIENTID='" + clid + "' and releaseno='"+this.releaseNo+"'";
			
		}

		query += " GROUP BY A.FILEID,SUMMARY_IMPORT_CNT,PROCESSDATE   ) ORDER BY FILEID,A";

		System.out.println(query);
		setQuery(query);

		mainLogs = new ArrayList<MainLog>();
		setMainLogs(mainLogs);

		importMainLogs = new MainLogDataModel(mainLogs);
		}catch(Exception e){
			displayErrorMessageToUser("Query execution failed. Please try again", "");
		}
	}
	public void filterbyReportID() {
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot()
					.findComponent("frmIR:inventoryReconLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.reportID.isEmpty() || this.reportID == null)

		{
			displayErrorMessageToUser("Please select a reportid", "ERROR");
			return;

		}
		
		String query = "SELECT  A, FILEID, CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, FILEDATE,FILE_RECORD_CNT,  TRANSFER_RECORD, IMPORT_RECORD_CNT, VARIANCE1, "
				+" STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, NVL(TRANSFERSTATUS,'NOT TRANSFERED'), "
				+" RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE FROM (  SELECT 'DATA' AS A, A.FILEID, NULL AS CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, " 
				+" FILEDATE,FILE_RECORD_CNT, TRANSFER_RECORD, IMPORT_RECORD_CNT AS IMPORT_RECORD_CNT , NULL VARIANCE1 ,STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, "
				+" EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, TRANSFERSTATUS, RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE " 
				+" FROM AIP_DASHBOARD_INVENTORY_RECON A  "
				+ " WHERE a.clientid='"
				+ this.getClient()
				+ "' AND  EXISTS (SELECT 1 "
				+ " FROM imp_inventory_rep_log_details c WHERE c.reportid='"
				+ this.getReportID()
				+ "' AND a.fileid||'_'||a.dmfileid=c.fileid    )) "
				+ " UNION ALL "  
				  +" SELECT 'SUMMARY' AS A,A.FILEID, COUNT(*) AS CNT , " 
				  +" NULL DMFILEID, NULL FILENAME,NULL CLIENTID, NULL LAYOUTID,NULL DATATYPE,  NULL FILE_SIZE,NULL FILEDATE,NULL FILE_RECORD_CNT, " 
				  +" SUM(TRANSFER_RECORD) AS TRANSFER_RECORD, "
				   +" SUMMARY_IMPORT_CNT as IMPORT_RECORD_CNT, SUMMARY_IMPORT_CNT-SUM(TRANSFER_RECORD) AS  VARIANCE1,NULL STATUS_IMPORT, NULL PROCESSSTATUS,  NULL IMPORTSERVER, " 
				   +" NULL INFO13, NULL EXCEPTIONDETAIL, NULL EMPGRP, NULL EXCEPTION_REMARK, NULL PAYOR, NULL AITABLENAME,  NULL HISCHEMANAME, NULL HITABLENAME, " 
				   +" NULL TRANSFERSTATUS, NULL RETRANSFER_DETAIL, NULL WHERECONDITION,PROCESSDATE " 
				 +" FROM AIP_DASHBOARD_INVENTORY_RECON A"
				+ " WHERE a.clientid='"
				+ this.getClient()
				+ "' AND EXISTS (SELECT 1 FROM imp_inventory_rep_log_details c "
				+ "  WHERE c.reportid='"
				+ this.getReportID()
				+ "' AND a.fileid||'_'||a.dmfileid=c.fileid    ) "
				+ "    GROUP BY a.fileid,SUMMARY_IMPORT_CNT,PROCESSDATE "
				+ "ORDER BY FILEID,A   ";

		mainLogs = new ArrayList<MainLog>();
		setQuery(query);

		System.out.println("Inventory Recon : " + query);
		setMainLogs(mainLogs);
		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public void filterByReleaseTag() {
		log.info("This is the release tag filter for inventory recon.");
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot()
					.findComponent("frmIR:inventoryReconLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
		if (this.releaseTag.isEmpty() || this.releaseTag == null)

		{
			displayErrorMessageToUser("Please select a Release Tag", "ERROR");
			return;

		}
		
		String query = "SELECT  A, FILEID, CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, FILEDATE,FILE_RECORD_CNT,  TRANSFER_RECORD, IMPORT_RECORD_CNT, VARIANCE1, " + 
					   " STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, EMPGRP, EXCEPTION_REMARK, PAYOR, AITABLENAME,  HISCHEMANAME, HITABLENAME, " +
					   " NVL(TRANSFERSTATUS,'NOT TRANSFERED'), RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE FROM " +
					   " (  SELECT 'DATA' AS A, A.FILEID, NULL AS CNT, DMFILEID, FILENAME, CLIENTID,LAYOUTID,DATATYPE, FILE_SIZE, FILEDATE,FILE_RECORD_CNT, TRANSFER_RECORD, " +
					   " IMPORT_RECORD_CNT AS IMPORT_RECORD_CNT , NULL VARIANCE1 ,STATUS_IMPORT, PROCESSSTATUS,  IMPORTSERVER, INFO13, EXCEPTIONDETAIL, EMPGRP, EXCEPTION_REMARK, PAYOR, " +
					   " AITABLENAME,  HISCHEMANAME, HITABLENAME, TRANSFERSTATUS, RETRANSFER_DETAIL, WHERECONDITION,PROCESSDATE FROM AIP_DASHBOARD_INVENTORY_RECON A  " +
					   " WHERE a.clientid='"+this.client+"' AND  EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='"+this.releaseTag+"' AND a.dmfileid=b.dmfileid and a.filename=b.filename )) " +
					   " UNION ALL SELECT 'SUMMARY' AS A,A.FILEID, COUNT(*) AS CNT , NULL DMFILEID, NULL FILENAME,NULL CLIENTID, NULL LAYOUTID,NULL DATATYPE, " +
					   " NULL FILE_SIZE,NULL FILEDATE,NULL FILE_RECORD_CNT, SUM(TRANSFER_RECORD) AS TRANSFER_RECORD, " +
					   " SUMMARY_IMPORT_CNT as IMPORT_RECORD_CNT, SUMMARY_IMPORT_CNT-SUM(TRANSFER_RECORD) AS  VARIANCE1,NULL STATUS_IMPORT, NULL PROCESSSTATUS,  NULL IMPORTSERVER,  " +
					   " NULL INFO13, NULL EXCEPTIONDETAIL, NULL EMPGRP, NULL EXCEPTION_REMARK, NULL PAYOR, NULL AITABLENAME,  NULL HISCHEMANAME, NULL HITABLENAME, " +   
					   " NULL TRANSFERSTATUS, NULL RETRANSFER_DETAIL, NULL WHERECONDITION,PROCESSDATE FROM AIP_DASHBOARD_INVENTORY_RECON A" +
					   " WHERE a.clientid='"+this.client+"' AND EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='"+this.releaseTag+"' AND a.dmfileid=b.dmfileid and a.filename=b.filename ) " +
					   " GROUP BY a.fileid,SUMMARY_IMPORT_CNT,PROCESSDATE ORDER BY FILEID,A";
		
		mainLogs = new ArrayList<MainLog>();
		setQuery(query);

		System.out.println("Inventory Recon : " + query);
		setMainLogs(mainLogs);
		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public boolean isSummaryRendered(MainLog obj) {
		if (obj != null) {
			if (obj.getType().compareTo("SUMMARY") == 0) {

				if (this.mainLogs.size() == 2) {
					return false;
				}

				try {

					if (obj.getFileID().compareTo(
							this.mainLogs.get(this.mainLogs.size() - 2)
									.getFileID()) == 0) {

						System.out.println(obj.getFileID());
						return true;
					} else {
						return false;
					}

				} catch (ArrayIndexOutOfBoundsException ex) {
					return false;
				}
			} else {
				return true;
			}
		} else {
			return false;
		}
		

	}
	public void generateSummary(){
		
	}

	public int getNoofnottransfer() {
		return noofnottransfer;
	}

	public void setNoofnottransfer(int noofnottransfer) {
		this.noofnottransfer = noofnottransfer;
	}

}
