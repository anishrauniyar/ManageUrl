/* 
 *Class Name : MainLogBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.controller;

import java.io.File;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.background.GenerateMDR;
import com.vit.ai.commons.controller.FileController;
import com.vit.ai.commons.model.MainLogDataModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.inventory.principle.ReportGenerator_Main;
import com.vit.ai.poireport.controller.CTLReportController;
import com.vit.ai.poireport.controller.DSRReportController;
import com.vit.ai.poireport.controller.DataExceptionReportController;
import com.vit.ai.releasetag.dao.ReleaseTagDAO;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for Inventory Import
 * 
 * @author Aashish Dhungana
 * @author Binesh Sah
 * @author Anish Rauniyar
 * 
 * @version 1.11 27 March 2015
 */
@ManagedBean
@ViewScoped
public class MainLogBean extends AbstractController implements Serializable {
	private static Logger log = Logger.getLogger(MainLogBean.class.getName());

	private static final long serialVersionUID = 1L;
	protected ArrayList<MainLog> mainLogs;
	protected ArrayList<MainLog> filteredLogs;
	private String startDate_report;
	private String endDate_report;
	private String todaysDate_report;
	protected ArrayList<MainLog> ReportLogs;
	protected ArrayList<MainLog> temporaryLogs;
	private boolean fileSelected = false;
	private String queryInv = "";
	private String latestinventory;
	private String topTenRecord = "No Records Found";
	private String lastTenRecord = "No Records Found";
	private DefaultStreamedContent downloadDPR;
	protected String winScreenHeight;
	protected ArrayList<MainLog> selectedLogs;
	private MainLog selectedLog;
	protected LinkedHashMap<String, String> clients;
	protected String client;
	protected String query;
	protected Date startDate;
	protected Date endDate;
	private Date todaysDate;
	private Date inventory_endDate;
	protected MainLogDataModel importMainLogs;
	protected FilterLogController filterData;
	private String hiMainLog;
	public double i = 0;
	private String value = "duplicate1";
	private String pdialogmessage;
	private boolean dialog = true;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String releaseNum;
	protected String reportID;
	protected ArrayList<String> reportsIDs;

	private String force_releasefileList;
	protected ArrayList<String> releaseNos;
	private String filtertype;
	protected String selectedfiltertype;
	private String upreleaseNum;
	private String mdrInput = "10";
	private String reportAlert = "";
	private DefaultStreamedContent fileMedia;
	private MessageObject msgObject;
	private int pipeLinecount = 0; //number of files that are in pipe line
	private int totalClick = 0; //check if the submit button is pressed more than once in a single view

	private String doNotUseType;
	
	private String replacefileList;
	protected LinkedHashMap<String, String> replacefileNos;
	private String tagStatus;
	protected ArrayList<String> reltagFileReplaceNos;
	
	private String reltagforrepalce;
	
	private String dmFileId;
	private String fileId;
	private String upreplaceNum; 
	
	protected ArrayList<String> appIds;
	protected String appId = "";
	
	protected ArrayList<String> releaseTags;
	protected String releaseTag = "";
	
	private String viewAppId;
	private String viewReleaseTag;
	private ArrayList<MainLog> releaseTagLists;
	
	private DefaultStreamedContent downloadFile;
	
	
	
	
	public DefaultStreamedContent getDownloadFile() {
		return downloadFile;
	}

	public void setDownloadFile(DefaultStreamedContent downloadFile) {
		this.downloadFile = downloadFile;
	}

	public String getViewAppId() {
		return viewAppId;
	}

	public void setViewAppId(String viewAppId) {
		this.viewAppId = viewAppId;
	}

	public String getViewReleaseTag() {
		return viewReleaseTag;
	}

	public void setViewReleaseTag(String viewReleaseTag) {
		this.viewReleaseTag = viewReleaseTag;
	}

	public ArrayList<MainLog> getReleaseTagLists() {
		return releaseTagLists;
	}

	public void setReleaseTagLists(ArrayList<MainLog> releaseTagLists) {
		this.releaseTagLists = releaseTagLists;
	}

	public ArrayList<String> getReleaseTags() {
		return releaseTags;
	}

	public void setReleaseTags(ArrayList<String> releaseTags) {
		this.releaseTags = releaseTags;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public ArrayList<String> getAppIds() {
		return appIds;
	}

	public void setAppIds(ArrayList<String> appIds) {
		String query = "SELECT DISTINCT(APP_ID) FROM IMP_FILES_RELTAG_RELN WHERE CLIENTID = '"+filterData.getClientID()+"'";
		log.info("App ID: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {
					
					appIds.add(rs.get(i).get(0));
				}
			}
		}
	}


	public String getUpreplaceNum() {
		return upreplaceNum;
	}

	public void setUpreplaceNum(String upreplaceNum) {
		this.upreplaceNum = upreplaceNum;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getDmFileId() {
		return dmFileId;
	}

	public void setDmFileId(String dmFileId) {
		this.dmFileId = dmFileId;
	}

	public String getReltagforrepalce() {
		return reltagforrepalce;
	}

	public void setReltagforrepalce(String reltagforrepalce) {
		this.reltagforrepalce = reltagforrepalce;
	}
	
	public String getReplacefileList() {
		return replacefileList;
	}

	public void setReplacefileList(String replacefileList) {
		this.replacefileList = replacefileList;
	}

	public LinkedHashMap<String, String> getReplacefileNos() {
		return replacefileNos;
	}

	public void setReplacefileNos(LinkedHashMap<String, String> replacefileNos) {
		this.replacefileNos = replacefileNos;
	}

	public String getTagStatus() {
		return tagStatus;
	}

	public void setTagStatus(String tagStatus) {
		this.tagStatus = tagStatus;
	}

	public ArrayList<String> getReltagFileReplaceNos() {
		return reltagFileReplaceNos;
	}

	public void setReltagFileReplaceNos(ArrayList<String> reltagFileReplaceNos) {
		this.reltagFileReplaceNos = reltagFileReplaceNos;
	}

	public String getDoNotUseType() {
		return doNotUseType;
	}

	public void setDoNotUseType(String doNotUseType) {
		this.doNotUseType = doNotUseType;
	}

	public Date getInventory_endDate() {
		return inventory_endDate;
	}

	public void setInventory_endDate(Date inventory_endDate) {
		this.inventory_endDate = inventory_endDate;
	}

	public String getWinScreenHeight() {
		return this.winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	public String getMdrInput() {
		return mdrInput;
	}

	public void setMdrInput(String mdrInput) {
		this.mdrInput = mdrInput;
	}

	private List<String> aipStatus;

	public List<String> getAipStatus() {
		return aipStatus;
	}

	public void setAipStatus(List<String> aipStatus) {
		this.aipStatus = aipStatus;
	}

	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	public ArrayList<String> getReportsIDs() {
		return reportsIDs;
	}

	public void setReportsIDs(ArrayList<String> reportsIDs) {
		String query = "SELECT REPORTID FROM  IMP_INVENTORY_REP_LOG";
		if (filterData.getClientID() != null) {
			query = query + " where clientid='" + filterData.getClientID()
					+ "' and reporttype='INVENTORY' order by REPORTID DESC ";

		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					reportsIDs.add(rs.get(i).get(0));
				}
			}
		}
	}

	public String getForce_releasefileList() {
		return force_releasefileList;
	}

	public void setForce_releasefileList(String force_releasefileList) {
		this.force_releasefileList = force_releasefileList;
	}

	public ArrayList<String> getReleaseNos() {
		return releaseNos;
	}

	public void setReleaseNos(ArrayList<String> releaseNos) {
		log.info("check");
		String query = "SELECT nvl(SUBRELEASENUMBER,release_number) as releaseno from AIP_CYCLE_MASTER";
		if (filterData.getClientID() != null) {
			query = query + " where clientid='" + filterData.getClientID()
					+ "' ORDER BY sn desc ";

		}

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {
					log.info(rs.get(i).get(0) + "releaseno");
					releaseNos.add(rs.get(i).get(0));
				}
			}
		}
	}

	public String getFiltertype() {
		return filtertype;
	}

	public void setFiltertype(String filtertype) {
		this.filtertype = filtertype;
	}

	public String getSelectedfiltertype() {
		return selectedfiltertype;
	}

	public void setSelectedfiltertype(String selectedfiltertype) {
		this.selectedfiltertype = selectedfiltertype;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public ArrayList<MainLog> getReportLogs() {
		return ReportLogs;
	}

	public void setReportLogs(ArrayList<MainLog> reportLogs) {
		ReportLogs = reportLogs;
	}

	public String getStartDate_report() {
		return startDate_report;
	}

	public void setStartDate_report(String startDate_report) {
		this.startDate_report = startDate_report;
	}

	public String getEndDate_report() {
		return endDate_report;
	}

	public void setEndDate_report(String endDate_report) {
		this.endDate_report = endDate_report;
	}

	public String getTodaysDate_report() {
		return todaysDate_report;
	}

	public void setTodaysDate_report(String todaysDate_report) {
		this.todaysDate_report = todaysDate_report;
	}

	public ArrayList<String> hashkeys = new ArrayList<String>();

	public MainLogBean() {
		i = 0;
		this.dialog = true;
		init();
	}

	public void init() {
		System.out.println("This main log bean...");
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
		setTodaysDate(new Date());
		ReportLogs = new ArrayList<MainLog>();

		clients = new LinkedHashMap<String, String>();
		this.temporaryLogs = new ArrayList<>();
		setClients(clients);

	}

	public ArrayList<MainLog> getMainLogs() {
		return mainLogs;
	}

	public void setMainLogs(ArrayList<MainLog> mainLogs) {

		this.aipStatus = new ArrayList<String>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> logList = db.resultSetToListOfList(query);
		db.endConnection();

		if (logList.size() > 0) {
			for (int i = 1; i < logList.size(); i++) {

				mainLogs.add(new MainLog(logList.get(i).get(0), logList.get(i)
						.get(1), logList.get(i - 1).get(2), logList.get(i).get(
						2), logList.get(i).get(3), logList.get(i).get(4),
						logList.get(i).get(5), logList.get(i).get(6), logList
								.get(i).get(7), logList.get(i).get(8), logList
								.get(i).get(9), logList.get(i).get(10), logList
								.get(i).get(11), logList.get(i).get(12),
						logList.get(i).get(13), logList.get(i).get(14), logList
								.get(i).get(15), logList.get(i).get(16),
						logList.get(i).get(17), logList.get(i).get(18), logList
								.get(i).get(19), logList.get(i).get(20),
						logList.get(i).get(21), logList.get(i).get(22), logList
								.get(i).get(23), logList.get(i).get(24),
						logList.get(i).get(25), logList.get(i).get(26), logList
								.get(i).get(27), logList.get(i).get(28),
						logList.get(i).get(29), logList.get(i).get(30), logList
								.get(i).get(31), logList.get(i).get(32),
						logList.get(i).get(33), logList.get(i).get(34), logList
								.get(i).get(35), logList.get(i).get(36),
						logList.get(i).get(37),logList.get(i).get(38)));
				if (aipStatus.contains(logList.get(i).get(23))) {
					continue;
				} else {
					aipStatus.add(logList.get(i).get(23));

				}

			}

		}
		setAipStatus(aipStatus);

	}

	public void filterLog() {

		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();

		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				+ " DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				+ " IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "
				+ "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH,"
				+ "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL,"
				+ "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory";
		String clid = filterData.getClientID();
		log.info("Clientid : " + clid);
		if (clid == null || clid.equals("")) {
			displayErrorMessageToUser("No Client Selected", "Inventory");
			mainLogs = new ArrayList<MainLog>();
			return;

		}
		if (clid != null && !clid.equals("")) {
			queryInv += " WHERE CLIENTID='" + clid + "' ";

			if (startDate != null && !startDate.equals("")) {
				queryInv += " AND PROCESSDATE" + " >= TO_TIMESTAMP('"
						+ dateFormat.format(startDate) + "','"
						+ timeStampFormat + "')";
				setStartDate_report(dateFormat.format(startDate));
			}
			if (endDate != null && !endDate.equals("")) {
				queryInv += " AND PROCESSDATE" + " <= TO_TIMESTAMP('"
						+ dateFormat.format(endDate) + "','" + timeStampFormat
						+ "')";
				setEndDate_report(dateFormat.format(endDate));
			}

		} else if (clid == null || clid.equals("")) {
			if (startDate != null && !startDate.equals("")) {
				queryInv += " WHERE PROCESSDATE" + " >= TO_TIMESTAMP('"
						+ dateFormat.format(startDate) + "','"
						+ timeStampFormat + "')";
				setStartDate_report(dateFormat.format(startDate));

				if (endDate != null && !endDate.equals("")) {
					queryInv += " AND PROCESSDATE" + "<= TO_TIMESTAMP('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";
					setEndDate_report(dateFormat.format(endDate));
				}
			}
		} else if (clid == null || clid.equals("") && startDate == null
				|| startDate.equals("")) {
			if (endDate != null && !endDate.equals("")) {
				queryInv += " WHERE PROCESSDATE" + " <= TO_TIMESTAMP('"
						+ dateFormat.format(endDate) + "','" + timeStampFormat
						+ "')";
				setEndDate_report(dateFormat.format(endDate));
			}

		}
		queryInv += " )A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION ";

		log.info("Inventory Query" + queryInv);
		this.setTodaysDate_report(dateFormat.format(todaysDate));

		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);

		setMainLogs(mainLogs);
		setReportLogs(mainLogs);
		getLatestInventory(clid);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
			RequestContext.getCurrentInstance().execute("PF('bar').show();");
			totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public void doNothing() {

	}

	public ArrayList<MainLog> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<MainLog> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> clientList = db
				.resultSetToListOfList("SELECT DISTINCT B.CLIENTID , A.CLIENTNAME FROM HAWKEYEMASTER.M_CLIENTS A JOIN IMP_MAIN_LOG  B ON   A.CLIENTID=B.CLIENTID order by clientid asc");

		db.endConnection();
		System.out.println("The size of the client is: " + clientList.size());
		if (clientList.size() > 0) {
			for (int i = 1; i < clientList.size(); i++) {
				clients.put(clientList.get(i).get(0) + "-("
						+ clientList.get(i).get(1) + ")", clientList.get(i)
						.get(0));
			}
		}
	}

	/*
	 * public String getfileList(){
	 * 
	 * String selectedFileIds="";
	 * 
	 * if (selectedLogs.size() > 0) {
	 * 
	 * if(selectedLogs.size()==1){
	 * selectedFileIds=selectedLogs.get(0).getFileID(
	 * )+"_"+selectedLogs.get(0).getDmFileID();
	 * 
	 * }else{ selectedFileIds=
	 * selectedLogs.get(0).getFileID()+"_"+selectedLogs.get(0).getDmFileID();
	 * 
	 * for (int j = 1; j < selectedLogs.size(); j++) { selectedFileIds=
	 * selectedFileIds
	 * +","+selectedLogs.get(j).getFileID()+"_"+selectedLogs.get(j
	 * ).getDmFileID(); } }
	 * 
	 * }else{ displayInfoMessageToUser("Please select file.",
	 * "Distribution Status"); return selectedFileIds; } return selectedFileIds;
	 * }
	 */
	/*
	 * public void distributeDataManual(){
	 * 
	 * try { String hiSchema=""; String scrubServer=""; String importserver="";
	 * String selectedFileIds=getfileList(); if(selectedFileIds!=""){
	 * hiSchema=selectedLogs.get(0).getHischemaname();
	 * scrubServer=selectedLogs.get(0).getHiservername();
	 * importserver=selectedLogs.get(0).getServername(); String command =
	 * AIConstant.shFilelocation + "./runBulkTransferManual.sh "; command +=
	 * "-c "; command += this.client + " -f"; command += " '" + selectedFileIds
	 * +"' -h '"; command += hiSchema + "' -s '"; command += scrubServer +
	 * "' -i '"; command +=importserver + "'"; RunTransfer rtransfer = new
	 * RunTransfer(); log.info("Distribution Command "+command);
	 * rtransfer.setCommandtoRun(command); rtransfer.init(); }
	 * 
	 * setSelectedLogs(null); filterLog();
	 * 
	 * } catch (Exception e) { displayErrorMessageToUser(
	 * "Error in Distribution!!! Please Verify it ", "Transfer Error"); } }
	 */

	
	

	public ArrayList<String> groupinto4(String selectedFileIds) {
		String[] check = selectedFileIds.split(",");
		int noofFiles = check.length;
		String seperatedFileids = "";
		log.info("Number : " + noofFiles);
		ArrayList<String> groups = new ArrayList<String>();
		if (noofFiles < 4) {
			groups.add(selectedFileIds);
		} else {
			int x = (noofFiles / 4);
			log.info("Divided Files : " + x);
			for (int i = 0; i < x & i < noofFiles; i++) {
				seperatedFileids = seperatedFileids + "," + check[i];
			}
			if (seperatedFileids.length() > 0) {
				seperatedFileids = seperatedFileids.substring(1);
			}
			groups.add(seperatedFileids);
			log.info("Group 1 : " + seperatedFileids);
			seperatedFileids = "";
			for (int i = x; i < 2 * x & i < noofFiles; i++) {
				seperatedFileids = seperatedFileids + "," + check[i];
			}
			if (seperatedFileids.length() > 0) {
				seperatedFileids = seperatedFileids.substring(1);
			}
			groups.add(seperatedFileids);
			log.info("Group 2 : " + seperatedFileids);
			seperatedFileids = "";
			for (int i = 2 * x; i < 3 * x & i < noofFiles; i++) {
				seperatedFileids = seperatedFileids + "," + check[i];
			}
			if (seperatedFileids.length() > 0) {
				seperatedFileids = seperatedFileids.substring(1);
			}
			groups.add(seperatedFileids);

			log.info("Group 3 : " + seperatedFileids);
			seperatedFileids = "";
			for (int i = 3 * x; i < noofFiles; i++) {
				seperatedFileids = seperatedFileids + "," + check[i];
			}
			if (seperatedFileids.length() > 0) {
				seperatedFileids = seperatedFileids.substring(1);
			}
			groups.add(seperatedFileids);
			log.info("Group 4 : " + seperatedFileids);
		}
		return groups;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getClient() {
		return filterData.getClientID();
	}

	public void setClient(String client) {
		filterData.setClientID(client);
		this.client = filterData.getClientID();
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getTodaysDate() {
		return todaysDate;
	}

	public void setTodaysDate(Date todaysDate) {
		this.todaysDate = todaysDate;
	}

	public ArrayList<MainLog> getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(ArrayList<MainLog> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	public MainLogDataModel getImportMainLogs() {
		return importMainLogs;
	}

	public void setImportMainLogs(MainLogDataModel importMainLogs) {
		this.importMainLogs = importMainLogs;
	}

	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}

	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	/*
	 * Reports
	 */
	private DefaultStreamedContent downloadMDR;
	private DefaultStreamedContent downloadDSR;
	private DefaultStreamedContent downloadDER;

	private DefaultStreamedContent downloadCTL;

	public void setDownloadDER(DefaultStreamedContent downloadDER) {
		this.downloadDER = downloadDER;
	}

	public ArrayList<String> checkifExists(String query) {
		log.info(query);
		ArrayList<String> result = new ArrayList<String>();
		ConnectDB conn = new ConnectDB();
		conn.initialize();
		List<List<String>> rs = conn.resultSetToListOfList(query);
		conn.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					result.add(rs.get(i).get(0));
				}
			}
		}

		return result;

	}

	public void ProcessDownload(String choice) {

		String fileID = getSelectedFileIds();
		String msg = "";
		String message = "Do you want to proceed? ";
		String queryfmdr = "select distinct fileid from importdb.rpt_main_log where fileid in ('"
				+ fileID + "') and reporttype ='MDR'";

		String queryfsr = "select distinct fileid from importdb.rpt_main_log where fileid in ('"
				+ fileID + "') and reporttype ='DSR'";

		ArrayList<String> mdrinfo = new ArrayList<String>();
		switch (choice) {
		case "MDR":
			mdrinfo = checkifExists(queryfmdr);
			break;
		case "DSR":
			mdrinfo = checkifExists(queryfsr);
			break;

		}
		int size = mdrinfo.size();
		if (fileID.compareTo("") == 0 || fileID == null) {
			displayErrorMessageToUser(
					"No File Selected.Select some files to view its report.",
					"File Download");
			this.dialog = false;
		} else {
			String[] splitValues = fileID.split(",");
			if (size > 0) {
				if (size == splitValues.length) {
					this.pdialogmessage = message;
				} else {

					for (int i = 0; i < splitValues.length; i++) {

						if (!mdrinfo.contains(splitValues[i]
								.replaceAll("'", "").trim())) {
							msg = msg + "  " + splitValues[i];
						}
					}
					this.pdialogmessage = "Reports for File ID \n" + msg
							+ " \n donot exist." + message;
				}

			} else {
				this.pdialogmessage = choice + "reports are not available. "
						+ message;
			}

			switch (choice) {
			case "MDR":
				RequestContext.getCurrentInstance().execute(
						"PF('reportdialogfmdr').show();");
				break;
			case "DSR":
				RequestContext.getCurrentInstance().execute(
						"PF('reportdialogfsr').show();");
				break;

			}
		}

	}

	public DefaultStreamedContent getDownloadMDR() {
		RequestContext.getCurrentInstance().execute(
				"PF('reportdialog').hide();");
		// String fileID = getSelectedFileIds();
		CustomUtility customUtility = new CustomUtility();
		String fileName = AIConstant.FMDR_REPORT_NAME
				+ customUtility.getDateForReport();

		// MDRReportController r = new MDRReportController();
		// r.process(fileID, fileName);

		FileController objFC = new FileController(
				AIConstant.FMDR_REPORT_DUMP_LOCATION + fileName + ".xlsx");
		setDownloadMDR(objFC.getDownload());
		return downloadMDR;
	}

	public void setDownloadMDR(DefaultStreamedContent downloadMDR) {
		this.downloadMDR = downloadMDR;
	}

	public MainLog getSelectedLog() {
		return selectedLog;
	}

	public void setSelectedLog(MainLog selectedLog) {
		this.selectedLog = selectedLog;
	}

	public String getAllSelectedFileIds() {
		String selectedFileIds = "";
		for (int j = 0; j < this.selectedLogs.size(); j++) {
			selectedFileIds = selectedFileIds + ","
					+ this.selectedLogs.get(j).getFileID() + "_"
					+ this.selectedLogs.get(j).getDmFileID();

		}
		if (selectedFileIds.startsWith(",")) {
			selectedFileIds = selectedFileIds.substring(1);
			selectedFileIds = selectedFileIds.replaceAll(",", "','");
		}

		return selectedFileIds;
	}

	public String getSelectedFileIds() {
		String selectedFileIds = "";

		if (this.selectedLogs.size() > 0) {
			this.temporaryLogs = this.selectedLogs;
			this.fileSelected = true;
		} else {
			this.temporaryLogs = this.ReportLogs;
			this.fileSelected = false;
		}

		if (ReportLogs.size() > 0) {

			for (int j = 0; j < temporaryLogs.size(); j++) {

				if (temporaryLogs.get(j).getStatusOfImport().toUpperCase()
						.contains("SUCCESS")
						|| temporaryLogs.get(j).getStatusOfImport()
								.toUpperCase().compareTo("CONTROL") == 0
						|| temporaryLogs.get(j).getProcessStatus()
								.toUpperCase().compareTo("CONTROL") == 0
						&& (!temporaryLogs.get(j).getStatusOfImport()
								.equalsIgnoreCase("DO NOT USE"))
						&& (!temporaryLogs.get(j).getStatusOfImport()
								.equalsIgnoreCase("DELETE"))
						&& temporaryLogs.get(j).getExceptionflag().isEmpty()) {
					selectedFileIds = selectedFileIds + ","
							+ temporaryLogs.get(j).getFileID() + "_"
							+ temporaryLogs.get(j).getDmFileID();

					log.info(selectedFileIds);
				}
			}
			if (selectedFileIds.startsWith(",")) {
				selectedFileIds = selectedFileIds.substring(1);
				selectedFileIds = selectedFileIds.replaceAll(",", "','");
			}
		} else {
			log.info("EMPTY Values: " + ReportLogs.size());

			return selectedFileIds;
		}

		return selectedFileIds;
	}

	public String getSelectedFileIds(String type) {
		String selectedFileIds = "";

		if (this.selectedLogs.size() > 0) {
			this.temporaryLogs = this.selectedLogs;
			this.fileSelected = true;
		} else {
			this.temporaryLogs = this.ReportLogs;
			this.fileSelected = false;
		}

		if (ReportLogs.size() > 0) {

			for (int j = 0; j < temporaryLogs.size(); j++) {

				selectedFileIds = selectedFileIds + ","
						+ temporaryLogs.get(j).getFileID() + "_"
						+ temporaryLogs.get(j).getDmFileID();

			}
			if (selectedFileIds.startsWith(",")) {
				selectedFileIds = selectedFileIds.substring(1);
				selectedFileIds = selectedFileIds.replaceAll(",", "','");
			}
		} else {

			return selectedFileIds;
		}

		return selectedFileIds;
	}

	public DefaultStreamedContent getDownloadDER() {
		CustomUtility customUtility = new CustomUtility();
		String fileID = getSelectedFileIds();

		if (fileID == null || fileID.compareTo("") == 0) {
			displayErrorMessageToUser("No File Selected",
					"Data Exception  Reports");
		} else {

			String fileName = "DataExceptionReport"
					+ customUtility.getDateForReport();

			DataExceptionReportController r = new DataExceptionReportController();
			r.process(fileID, fileName, this.client);

			FileController objFC = new FileController(
					AIConstant.FSR_REPORT_DUMP_LOCATION + fileName + ".xlsx");
			setDownloadDER(objFC.getDownload());
		}
		return downloadDER;
	}

	public DefaultStreamedContent getDownloadDSR() {
		CustomUtility customUtility = new CustomUtility();
		String fileID = getSelectedFileIds();

		String fileName = AIConstant.FSR_REPORT_NAME
				+ customUtility.getDateForReport();

		DSRReportController r = new DSRReportController();
		r.process(fileID, fileName, this.client);

		FileController objFC = new FileController(
				AIConstant.FSR_REPORT_DUMP_LOCATION + fileName + ".xlsx");
		setDownloadDSR(objFC.getDownload());
		return downloadDSR;
	}

	public void setDownloadDSR(DefaultStreamedContent downloadDSR) {
		this.downloadDSR = downloadDSR;
	}

	public String getHiMainLog() {
		return hiMainLog;
	}

	public void setHiMainLog(String hiMainLog) {
		this.hiMainLog = hiMainLog;
	}

	public void viewLog(MainLog mainLog) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> logList = db
				.resultSetToListOfList(""
						+ " SELECT CLIENTID,EMPLOYERNAME,HITABLENAME,HIROWS,HISTATUS, HIERRMSG, "
						+ "    HISTARTTIME,HIENDTIME,TRANSFERTYPE "
						+ "    FROM HI_MAIN_LOG WHERE FILEID='"
						+ mainLog.getFileID() + "' and sn='" + mainLog.getSn()
						+ "'");
		db.endConnection();

		this.hiMainLog = "";

		if (logList.size() > 1) {
			for (int i = 0; i < 9; i++) {
				this.hiMainLog += logList.get(0).get(i) + ": "
						+ logList.get(1).get(i) + "<br/><br/>";
			}

		} else {
			this.hiMainLog = "No information found.";
		}
	}

	public String HandleRowColor(String dupvalue, String HashKey) {
		if (dupvalue == "" || dupvalue == null) {
			value = "orginal";

		} else {
			hashkeys.add(HashKey);
			if (value.compareTo("orginal") == 0) {
				value = "duplicate1";
			}
			if (hashkeys.size() > 1) {

				if (hashkeys.get(hashkeys.size() - 1).compareTo(
						hashkeys.get(hashkeys.size() - 2)) != 0) {
					setValue("duplicate1", "duplicate2");

				}

			}

		}

		return value;
	}

	public void setValue(String value1, String value2) {
		if (value.compareTo(value1) == 0) {
			value = value2;
		} else if (value.compareTo(value2) == 0) {
			value = value1;
		}
	}

	public void setFuture() {

		if (!this.selectedLogs.isEmpty()) {
			ConnectDB conn = new ConnectDB();
			conn.initialize();

			String query = "UPDATE imp_main_log SET EXCEPTIONFLAG ='FUTURE',exceptionflagby='"
					+ getUserinfo().getFullname()
					+ "' WHERE fileid||'_'||dmfileID IN ('"
					+ getAllSelectedFileIds() + "')";
			log.info("The future update query is: " + query);
			String releaseTagUpdate = "UPDATE imp_files_reltag_reln SET reltag = 'FUTURE', RELEASEFLAG='IF' WHERE dmfileid||'_'||filename IN " 
									  + "(SELECT dmfileid||'_'||filename FROM imp_main_log WHERE fileid||'_'||dmfileid IN ('"+getAllSelectedFileIds()+"'))";
			log.info("The release tag future update query is: " + releaseTagUpdate);
			String x = conn.executeDML(query);
			x = conn.executeDML(releaseTagUpdate);			
			conn.endConnection();
			log.info(this.getFiltertype());
			if (x.compareTo("1") == 0) {
				displayInfoMessageToUser("Set Future Successful", "Import Log");
				if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
					setReleaseNum(getReleaseNum());
					filterbyReleaseNo();
				} else if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
					setReportID(getReportID());
					filterbyReportID();
				} else if (this.getFiltertype().compareTo("filterbytimestamp") == 0) {
					filterLog();
				}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
					setAppId(getAppId());
					setReleaseTag(getReleaseTag());
					filterbyReleaseTag(); 
				} else if (this.getFiltertype().compareTo("filterbyholdfile") == 0) {
					filterbyFilehold();
				} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
					filterbyFilefuture();
				} else {
					filterbyUnreleased();
				}
			} else {
				displayErrorMessageToUser("Action Failed.Please try again",
						"Set Delete");
			}

		} else {

			displayInfoMessageToUser("No File is Selected", "Import Log");
		}

	}

	public void openConfirmDialog() {
		log.info("This is a confirmation box");
		if (!this.selectedLogs.isEmpty()) {
			if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
				setReleaseNum(getReleaseNum());
				filterbyReleaseNo();
			} else if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
				setReportID(getReportID());
				filterbyReportID();
			} else if (this.getFiltertype().compareTo("filterbytimestamp") == 0) {
				filterLog();
			} else if (this.getFiltertype().compareTo("filterbyholdfile") == 0) {
				filterbyFilehold();
			} else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
				setAppId(getAppId());
				setReleaseTag(getReleaseTag());
				filterbyReleaseTag();
			} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
				filterbyFilefuture();
			} else {
				filterbyUnreleased();
			}
			RequestContext.getCurrentInstance().execute("PF('patternConfirmD').show();");
		} else {
			displayInfoMessageToUser("No File is Selected", "Import Log");
		}
		
	}
	
	public void SetDoNotUseForPattern() {
		log.info("This is a set do not use for pattern");
		if (!this.selectedLogs.isEmpty()) {
			ConnectDB conn = new ConnectDB();
			conn.initialize();
			setDoNotUseType("PATTERN");
			String query = "UPDATE imp_main_log SET EXCEPTIONFLAG ='DO NOT USE',exceptionflagby='"
					+ getUserinfo().getFullname()
					+ "' WHERE fileid||'_'||dmfileid IN ('"
					+ getAllSelectedFileIds() + "')";
			
			//String layoutQuery = "SELECT layoutid FROM imp_clientpatterns WHERE sn IN (SELECT pattern_sn FROM imp_main_log WHERE fileid||'_'||dmfileid = '"+selectedFileIds+"')";
			
			String queryForPattern = "UPDATE imp_clientpatterns SET LAYOUTID = '3', FILETYPE='DONOTUSE' WHERE sn IN (SELECT pattern_sn FROM imp_main_log WHERE fileid||'_'||dmfileid IN ('" + getAllSelectedFileIds() + "'))";
			String x = conn.executeDML(query);
			String y = conn.executeDML(queryForPattern);
			conn.endConnection();
			
			String userLog = "";	
			for (int j = 0; j < this.selectedLogs.size(); j++) {
				userLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) VALUES ('1','PATTERN_DONOTUSE_LOG','SET AS DO NOT USE BY USER CLIENTID:"
								+ getClient() + " | FILEID:" + this.selectedLogs.get(j).getFileID() + " | DMFILEID:" + this.selectedLogs.get(j).getDmFileID() + " | LAYOUTID: "+this.selectedLogs.get(j).getLayoutID()+"','"
								+this.userinfo.getFullname()+"',SYSDATE)";
				conn.initialize();
				try {
					conn.executeDML(userLog);
				} catch (Exception e) {
					log.info("There is a problem in user log for do not use: " + e.getMessage());
				}
			}
			
			
			if (x.compareTo("1") == 0 && y.compareTo("1") == 0) {
				displayInfoMessageToUser("Set Donotuse for file and pattern is Successful",
						"Import Log");
				if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
					setReleaseNum(getReleaseNum());
					filterbyReleaseNo();
				} else if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
					setReportID(getReportID());
					filterbyReportID();
				} else if (this.getFiltertype().compareTo("filterbytimestamp") == 0) {
					filterLog();
				} else if (this.getFiltertype().compareTo("filterbyholdfile") == 0) {
					filterbyFilehold();
				} else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
					setAppId(getAppId());
					setReleaseTag(getReleaseTag());
					filterbyReleaseTag(); 					
				} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
					filterbyFilefuture();
				} else {
					filterbyUnreleased();
				}
			} else {
				displayErrorMessageToUser("Action Failed.Please try again",
						"Set Donotuse");
			}

		} else {

			displayInfoMessageToUser("No File is Selected", "Import Log");
		}
	}
	
	public void SetDoNotUse() {
		log.info("This is a set do not use for file");
		if (!this.selectedLogs.isEmpty()) {
			ConnectDB conn = new ConnectDB();
			conn.initialize();
			setDoNotUseType("FILE");
			String query = "UPDATE imp_main_log SET EXCEPTIONFLAG ='DO NOT USE',exceptionflagby='"
					+ getUserinfo().getFullname()
					+ "' WHERE fileid||'_'||dmfileid IN ('"
					+ getAllSelectedFileIds() + "')";
			String releaseTagUpdate = "UPDATE imp_files_reltag_reln SET reltag = 'DO NOT USE', RELEASEFLAG='IF' WHERE dmfileid||'_'||filename IN " +
									  "(SELECT dmfileid||'_'||filename FROM imp_main_log WHERE fileid||'_'||dmfileid IN ('"+getAllSelectedFileIds()+"'))";
			String x = conn.executeDML(query);
			String y = conn.executeDML(releaseTagUpdate);
			conn.endConnection();
			String userLog = "";	
			for (int j = 0; j < this.selectedLogs.size(); j++) {
				userLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) VALUES ('1','FILE_DONOTUSE_LOG','SET AS DO NOT USE BY USER CLIENTID:"
						+ getClient() + " | FILEID:" + this.selectedLogs.get(j).getFileID() + " | DMFILEID:" + this.selectedLogs.get(j).getDmFileID() + "','"
						+this.userinfo.getFullname()+"',SYSDATE)";
				conn.initialize();
				try {
					conn.executeDML(userLog);
				} catch (Exception e) {
					log.info("There is a problem in user log for do not use: " + e.getMessage());
				}
			}
			if (x.compareTo("1") == 0 && y.compareTo("1") == 0) {
				displayInfoMessageToUser("Set Donotuse Successful in the file and in the release tag",
						"Import Log");
				if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
					setReleaseNum(getReleaseNum());
					filterbyReleaseNo();
				} else if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
					setReportID(getReportID());
					filterbyReportID();
				} else if (this.getFiltertype().compareTo("filterbytimestamp") == 0) {
					filterLog();
				} else if (this.getFiltertype().compareTo("filterbyholdfile") == 0) {
					filterbyFilehold();
				}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
					setAppId(getAppId());
					setReleaseTag(getReleaseTag());
					filterbyReleaseTag(); 
				} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
					filterbyFilefuture();
				} else {
					filterbyUnreleased();
				}
			} else if (x.compareTo("1") != 0 || y.compareTo("1") != 0) {
				if (x.compareTo("1") != 0 && y.compareTo("1") != 0) {
					displayErrorMessageToUser("File cannot be set as DO NOT USE in Release Tag and in Inventory",
							"Set Donotuse");
				} else if (x.compareTo("1") != 0) {
					displayErrorMessageToUser("File cannot be set as DO NOT USE in Inventory",
							"Set Donotuse");
				} else if (y.compareTo("1") != 0) {
					displayErrorMessageToUser("File cannot be set as DO NOT USE in Release Tag",
							"Set Donotuse");
				} 
				//displayErrorMessageToUser("Action Failed.Please try again",	"Set Donotuse");
			}
		} else {

			displayInfoMessageToUser("No File is Selected", "Import Log");
		}

	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public String getPdialogmessage() {
		return pdialogmessage;
	}

	public void setPdialogmessage(String pdialogmessage) {
		this.pdialogmessage = pdialogmessage;
	}

	public boolean isDialog() {
		return dialog;
	}

	public void setDialog(boolean dialog) {
		this.dialog = dialog;
	}

	public DefaultStreamedContent getDownloadCTL() {

		CustomUtility customUtility = new CustomUtility();
		String fileID = getSelectedFileIds();
		if (fileID == null || fileID.compareTo("") == 0) {

			displayErrorMessageToUser("No File Selected",
					"Control Total Reports");
		} else {

			String fileName = AIConstant.CTL_REPORT_NAME
					+ customUtility.getDateForReport();

			CTLReportController r = new CTLReportController();
			r.process(fileID, fileName);

			FileController objFC = new FileController(
					AIConstant.CTL_REPORT_DUMP_LOCATION + fileName + ".xlsx");
			setDownloadCTL(objFC.getDownload());
		}

		return downloadCTL;
	}

	public void setDownloadCTL(DefaultStreamedContent downloadCTL) {
		this.downloadCTL = downloadCTL;
	}

	public void prepareCommand(String filename, String server) {

		File file = new File(filename.toString());

		if (file.exists()) {
			FileController objFC = new FileController(filename);
			setFileMedia(objFC.getDownload());
		} else {

			setFileMedia(null);
			displayErrorMessageToUser("FILE NOT FOUND", "CANNOT DOWNLOAD");
			// regenerateInventory(username);

		}

	}

	public void SetExceptionFlagNull() {
		String selectedFileIds = "";
		int donotuseFlag = 0;
		if (!this.selectedLogs.isEmpty()) {
			ConnectDB conn = new ConnectDB();
			conn.initialize();
			
			for (int j = 0; j < this.selectedLogs.size(); j++) {
				selectedFileIds = this.selectedLogs.get(j).getFileID() + "_" + this.selectedLogs.get(j).getDmFileID();

				String patternQuery = "SELECT layoutid FROM imp_clientpatterns WHERE sn IN (SELECT pattern_sn FROM imp_main_log WHERE fileid||'_'||dmfileid = '"+selectedFileIds+"')";
				List<List<String>> layout = conn.resultSetToListOfList(patternQuery);
				log.info("Pattern Query: " + patternQuery + " SIZE: " + layout.size());
				//log.info(" VALUE: " + layout.get(1).get(0));
				if (layout.size() > 1) {
					if (layout.get(1).get(0).compareTo("3") == 0) {
						donotuseFlag += 1; 
					} else {
						String updateQuery = "UPDATE imp_main_log SET EXCEPTIONFLAG ='',exceptionflagby='' WHERE fileid||'_'||dmfileid IN ('"
								+ selectedFileIds + "') ";
						String releaseTagUpdate = "UPDATE imp_files_reltag_reln SET reltag = 'UNKNOWN', RELEASEFLAG='R' WHERE dmfileid||'_'||filename IN " 
								  + "(SELECT dmfileid||'_'||filename FROM imp_main_log WHERE fileid||'_'||dmfileid IN ('"+selectedFileIds+"'))";						
						log.info("Update Query: " + updateQuery);
						try {
							conn.executeDML(updateQuery);
							conn.executeDML(releaseTagUpdate);
						} catch (Exception e) {
							log.info("Error while updating exeption flag: " + e.getMessage());
						}
					}
				} else {
					String updateQuery = "UPDATE imp_main_log SET EXCEPTIONFLAG ='',exceptionflagby='' WHERE fileid||'_'||dmfileid IN ('"
							+ selectedFileIds + "') ";
					String releaseTagUpdate = "UPDATE imp_files_reltag_reln SET reltag = 'UNKNOWN', RELEASEFLAG='R' WHERE dmfileid||'_'||filename IN " 
							  + "(SELECT dmfileid||'_'||filename FROM imp_main_log WHERE fileid||'_'||dmfileid IN ('"+selectedFileIds+"'))";
					log.info("Update Query: " + updateQuery);
					try {
						conn.executeDML(updateQuery);
						conn.executeDML(releaseTagUpdate);
					} catch (Exception e) {
						log.info("Error while updating exeption flag: " + e.getMessage());
					}
				}
			}
			
			
			
			String x = conn.executeDML(query);
			conn.endConnection();
			if (x.compareTo("1") == 0) {
				if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
					setReleaseNum(getReleaseNum());
					filterbyReleaseNo();
				} else if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
					setReportID(getReportID());
					filterbyReportID();
				} else if (this.getFiltertype().compareTo("filterbytimestamp") == 0) {
					filterLog();
				} else if (this.getFiltertype().compareTo("filterbyholdfile") == 0) {
					filterbyFilehold();
				}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
					setAppId(getAppId());
					setReleaseTag(getReleaseTag());
					filterbyReleaseTag(); 
				} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
					filterbyFilefuture();
				} else {
					filterbyUnreleased();
				}
				displayInfoMessageToUser("Reset Exception Successful",
						"Import Log");
			} else {
				displayErrorMessageToUser("Action Failed.Please try again",
						"Reset Exception");
			}

		} else {

			displayInfoMessageToUser("No File is Selected", "Import Log");
		}
		if (donotuseFlag > 0) {
			displayInfoMessageToUser("Some Files were permanently DO NOT USE which cannot be reset", "Import Log");
		}

	}

	/**
	 * Method to generate Inventory from a release Tag
	 * @param username
	 */
	public void generateInventoryByReleaseTag() {
		try{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		ArrayList<MainLog> listofFiles = new ArrayList<>();
		if (this.selectedLogs.size() > 0) {
			listofFiles = this.selectedLogs;

		} else {
			listofFiles = this.ReportLogs;
		}

		if (listofFiles.isEmpty()) {
			displayErrorMessageToUser("Nothing to Select", "Inventory Failed");
			return;
		}
		String query = "SELECT DATA_START_DATE,DATA_END_DATE FROM AIP_CYCLE_MASTER WHERE NVL(SUBRELEASENUMBER,RELEASE_NUMBER)='"+this.getReleaseNum()+"'";
		
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					this.startDate=dateFormat.parse(rs.get(1).get(0));
					this.endDate=dateFormat.parse(rs.get(1).get(1));
				}
			}
		}
		log.info("Start date "+this.startDate);
		log.info("End date "+this.endDate);
		String startdate = "";
		
		
		if (this.startDate != null) {
		
			startdate = this.startDate.toString();
		}
		if (this.endDate == null) {
			this.endDate = this.todaysDate;
		}
		CustomUtility obj = new CustomUtility();
		String fileName = "AIP_INVENTORY_" + this.getReleaseNum() + "_"
				+ obj.getDateForReport();
		
		this.msgObject = new MessageObject(this.client,this.releaseNum,startdate,this.endDate.toString(),this.ReportLogs.size(),listofFiles.size());
		this.msgObject.setType("INVENTORY BY RELEASE TAG");
		this.msgObject.setFilename(fileName);
		this.msgObject.setMessage("Important information based on the selected file(s)");
		
		RequestContext.getCurrentInstance().execute("PF('msgDialog').show();");
		}catch(Exception e){
			displayErrorMessageToUser("Error Occured. PLease try again", "ERROR");
		}
	}

	

	public void generateInventory() {
		
		ArrayList<MainLog> listofFiles = new ArrayList<>();
		if (this.selectedLogs.size() > 0) {
			listofFiles = this.selectedLogs;

		} else {
			listofFiles = this.ReportLogs;
		}

		if (listofFiles.isEmpty()) {
			displayErrorMessageToUser("Nothing to Select", "Inventory Failed");
			return;
		}
		if (this.startDate == null) {
			displayErrorMessageToUser(
					"No Start Date Selected.Cannot Generate Inventory",
					"Inventory Failed");
			return;
		}
		if (this.endDate == null) {
			//this.endDate = this.todaysDate;
			this.endDate = new Date();
			this.inventory_endDate = this.endDate;
		}
		CustomUtility obj = new CustomUtility();
		String fileName = "AIP_INVENTORY_CLID-" + this.client + "_"
				+ obj.getDateForReport();
		
		
		this.msgObject = new MessageObject(this.client,this.releaseNum,this.startDate.toString(),this.endDate.toString(),this.ReportLogs.size(),listofFiles.size());
		this.msgObject.setType("INVENTORY BY FILE DATE");
		this.msgObject.setFilename(fileName);
		this.msgObject.setMessage("Important information based on the selected file(s)");
		
		RequestContext.getCurrentInstance().execute("PF('msgDialog').show();");
		
	
	}
	
	public void executeGenerateReport(String username,MessageObject objMsg)
	{
		if(objMsg!=null)
		{
		
		ArrayList<MainLog> listofFiles = new ArrayList<>();
		if (this.selectedLogs.size() > 0) {
			listofFiles = this.selectedLogs;

		} else {
			listofFiles = this.ReportLogs;
		}

			
		if(objMsg.enableAllSelection)
		{
			listofFiles = this.ReportLogs;
		}
		
		
		if (listofFiles.isEmpty()) {
			displayErrorMessageToUser("Nothing to Select", "Inventory Failed");
			return;
		}
		
		if(objMsg.getType().compareTo("INVENTORY BY FILE DATE")==0)
		{
			if (this.endDate == null) {
				this.endDate = this.inventory_endDate;
				//this.endDate = new Date();
			}
		CustomUtility obj = new CustomUtility();
		String fileName = "AIP_INVENTORY_CLID-" + this.client + "_"
				+ obj.getDateForReport();
		
		Inventory inventory = new Inventory(listofFiles, username, this.client,
				fileName, true, startDate, endDate);
		ReportGenerator_Main repObject = new ReportGenerator_Main(inventory);
		boolean hasErrors = repObject.init();
		if (!hasErrors) {
			RequestContext.getCurrentInstance().execute("PF('msgDialog').hide();");
			displayInfoMessageToUser(
					"Inventory is being generated.Please check status from report log",
					"Inventory in Progress");

		} else {
			String errorMessage = repObject.getErrorMsg();
			displayErrorMessageToUser(errorMessage, "Inventory Failed");
			return;
		}
		
		}
		else if (objMsg.getType().compareTo("INVENTORY BY RELEASE TAG")==0)
		{
			CustomUtility obj = new CustomUtility();
			String fileName = "AIP_INVENTORY_" + this.getReleaseNum() + "_"
					+ obj.getDateForReport();
			InventorybyRelease inventory = new InventorybyRelease(listofFiles, username, this.client, fileName,this.releaseNum);
			ReportGenerator_Main repObject = new ReportGenerator_Main(inventory);
			boolean hasErrors = repObject.init();
			//String message="";
			if (!hasErrors) {
				
				RequestContext.getCurrentInstance().execute("PF('msgDialog').hide();");
				displayInfoMessageToUser(
						"Inventory is being generated.Please check status from report log",
						"Inventory in Progress");
				
			

			} else {
				String errorMessage = repObject.getErrorMsg();
				displayErrorMessageToUser(errorMessage, "Inventory Failed");
				return;

			}
		}
		}
	}

	public void getLatestInventory(String clientid) {

		String userlog = "";

		if (getUserinfo() != null) {
			userlog = getUserinfo().getFullname();

			String latestInventory = "";
			if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
				String query = " SELECT reportname FROM imp_inventory_rep_log  WHERE reporttype='INVENTORY'  AND created_by='"
						+ userlog
						+ "' and clientid='"
						+ clientid
						+ "' and releaseno='"
						+ this.releaseNum
						+ "' ORDER BY reportid desc";
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> rs = db.resultSetToListOfList(query);
				if (rs != null) {
					if (rs.size() > 1) {
						latestInventory = "Latest Generated Inventory: "
								+ rs.get(1).get(0);
					} else {
						latestInventory = "No Inventory Generated";
					}
				} else {
					latestInventory = "No Inventory Generated";
				}
			} else if (this.getFiltertype().compareTo("filterbytimestamp") == 0) {

				String query = " SELECT STARTDATE,ENDDATE FROM imp_inventory_rep_log  WHERE reporttype='INVENTORY'  AND created_by='"
						+ userlog
						+ "' and clientid='"
						+ clientid
						+ "' ORDER BY reportid desc";
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> rs = db.resultSetToListOfList(query);
				if (rs != null) {
					if (rs.size() > 1) {
						latestInventory = "Latest Inventory Generated- FROM "
								+ rs.get(1).get(0) + " TO : "
								+ rs.get(1).get(1);
					} else {
						latestInventory = "No Inventory Generated";
					}
				} else {
					latestInventory = "No Inventory Generated";
				}
			}

			this.setLatestinventory(latestInventory);
		}
	}

	public void storeMDR(String username) {

		String fileID = getSelectedFileIds("MDR");
		if (ReportLogs.size() == 0) {
			displayErrorMessageToUser("Nothing to select", "Inventory Log");
			return;
		}

		CustomUtility obj = new CustomUtility();
		String fileName = "AIP_MDR_REPORT_CLID-" + this.client + "_"
				+ obj.getDateForReport();
		displayInfoMessageToUser(
				"MDR is in progress.Please go to Report Log for progress status",
				"Generate MDR");
		log.info("MDR input " + this.getMdrInput());
		GenerateMDR genmdr = new GenerateMDR();
		genmdr.new ExecutePLSQL(client, this.startDate, this.endDate,
				fileSelected, fileID, username, obj.getDateForReport()
						.toString(), fileName, "NEW", "", this.getMdrInput())
				.init();
		this.mdrInput = "10";

	}

	public boolean isFileSelected() {
		return fileSelected;
	}

	public void setFileSelected(boolean fileSelected) {
		this.fileSelected = fileSelected;
	}

	public String getLatestinventory() {
		return latestinventory;
	}

	public void setLatestinventory(String latestinventory) {
		this.latestinventory = latestinventory;
	}

	public void showReleaseTag(String dmFileId, String fileName) { 		
		log.info(dmFileId + " " + fileName);
		String query = "SELECT app_id, reltag FROM imp_files_reltag_reln WHERE dmfileid = '" + dmFileId + "' AND filename = '" + fileName + "'";
		log.info("Release Tag query is: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		this.releaseTagLists = new ArrayList<MainLog>();		
		MainLog ml = new MainLog();
		log.info("The size is: " + rs.size());
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {
				ml.setAppId(rs.get(i).get(0));
				ml.setReleaseTag(rs.get(i).get(1));
				this.releaseTagLists.add(ml);
			}
			RequestContext.getCurrentInstance().execute("PF('releaseTagWidget').show();");
		} else {			
			displayErrorMessageToUser("No Release Tag found for this file", "Error");
		}
	}
	
	public void gettopTenandLastTen() {
		String servertoconnect = getServer(this.client);

		RuntimeExecutor objRT = new RuntimeExecutor(servertoconnect);
		if (this.selectedLogs.size() == 0) {
			displayErrorMessageToUser("No File Selected!!", "ERROR");
			return;
		}
		MainLog obj = this.selectedLogs.get(this.selectedLogs.size() - 1);

		String headcmd = "cat -n \"" + obj.getProcessFilePath() + "/"
				+ obj.getFileName() + "\" | head -n 10 ";

		String tailcmd = "cat -n \"" + obj.getProcessFilePath() + "/"
				+ obj.getFileName() + "\" | tail -n 10 ";
		
		log.info("Head: " + headcmd + " Tail: " + tailcmd);

		try {
			this.topTenRecord = objRT.runSimpleCommand(headcmd);
			this.lastTenRecord = objRT.runSimpleCommand(tailcmd);
			if (this.topTenRecord.isEmpty() && this.lastTenRecord.isEmpty()) {
				displayErrorMessageToUser("File Not Found", "Error");
				return;
			} else {
				RequestContext.getCurrentInstance().execute(
						"PF('samplerecords').show();");
			}
		} catch (Exception ex) {
			log.info(ex.toString());
			displayErrorMessageToUser("File Not Found", "Error");
		}

	}

	public String getServer(String clientid) {
		String serverinfo = "";
		String query = "select distinct(MACHINE) from aip_client_server where clientid='"
				+ clientid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				serverinfo = rs.get(1).get(0);
			}
		}

		return serverinfo;

	}

	public String getTopTenRecord() {
		return topTenRecord;
	}

	public void setTopTenRecord(String topTenRecord) {
		this.topTenRecord = topTenRecord;
	}

	public String getLastTenRecord() {
		return lastTenRecord;
	}

	public void setLastTenRecord(String lastTenRecord) {
		this.lastTenRecord = lastTenRecord;
	}

	public void saveExceptionRemarks(MainLog mainlog, String remark) {
		String query = "UPDATE IMP_MAIN_LOG SET EXCEPTION_REMARK='"
				+ remark.toString().replace("'", "''") + "'"
				+ " WHERE FILEID='" + mainlog.getFileID() + "' ";
		ConnectDB db = new ConnectDB();
		db.initialize();
		String status = db.executeDML(query);

		db.endConnection();
		if (status.compareTo("1") == 0) {
			displayInfoMessageToUser("Your remark saved ", "Exception Remark");
		} else {
			displayErrorMessageToUser("Action Failed.Please try again",
					"Exception Remark");
		}

	}

	public void filterbyReleaseNo() {
		if (this.releaseNum.isEmpty() && this.releaseNum == "") {
			displayErrorMessageToUser("Please select Data Batch", "");
			return;
		}
		this.aipStatus = new ArrayList<String>();
		setAipStatus(aipStatus);

		log.info("Release no is " + this.releaseNum);
		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();

		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				+ " DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				+ " IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "
				+ "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH,"
				+ "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL,"
				+ "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory where clientid='"
				+ filterData.getClientID()
				+ "'"
				+ " and releaseno='"
				+ this.releaseNum
				+ "'"
				+ " )A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION ";
		getLatestInventory(filterData.getClientID());

		this.setTodaysDate_report(dateFormat.format(todaysDate));
		log.info("release tag " + queryInv);
		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);
		setReportLogs(mainLogs);
		setMainLogs(mainLogs);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
				RequestContext.getCurrentInstance().execute("PF('bar').show();");
				totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public void filterbyReportID() {
		if (this.reportID.isEmpty() && this.reportID == "") {
			displayErrorMessageToUser("Please select inventory ID", "");
			return;
		}
		this.aipStatus = new ArrayList<String>();
		setAipStatus(aipStatus);

		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();

		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				+ " DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				+ " IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "
				+ "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH,"
				+ "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL,"
				+ "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory a where a.clientid='"
				+ this.client
				+ "'"
				+ " AND EXISTS (SELECT 1 FROM imp_inventory_rep_log_details b WHERE b.reportid='"
				+ this.getReportID()
				+ "' AND a.fileid||'_'||a.dmfileid=b.fileid  ) "
				+ " )A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION ";

		this.setTodaysDate_report(dateFormat.format(todaysDate));
		log.info("release tag " + queryInv);
		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);
		setReportLogs(mainLogs);
		setMainLogs(mainLogs);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
			RequestContext.getCurrentInstance().execute("PF('bar').show();");
			totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public void filterbyReleaseTag() {
		log.info("This is the release tag filter.");
		if (this.releaseTag.isEmpty() && this.releaseTag == "") {
			displayErrorMessageToUser("Please select Release Tag", "");
			return;
		}
		log.info("This is a release tag filter.");
		this.aipStatus = new ArrayList<String>();
		setAipStatus(aipStatus);

		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();

		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "  
				   + "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, " 
				   + "IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "  
				   + "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				   + "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				   + "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' " 
				   + "THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory a where a.clientid='"+this.client+"' "
				   + "AND EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='"+this.releaseTag+"' AND a.dmfileid=b.dmfileid and a.filename=b.filename ) " 
				   + ")A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION";
		log.info("Release Tag Query: " + queryInv);
		this.setTodaysDate_report(dateFormat.format(todaysDate));
		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);
		setReportLogs(mainLogs);
		setMainLogs(mainLogs);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
			RequestContext.getCurrentInstance().execute("PF('bar').show();");
			totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
		
	}
	
	
	public void filterbyUnreleased() {

		this.aipStatus = new ArrayList<String>();
		setAipStatus(aipStatus);

		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();
		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				+ " DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				+ " IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "
				+ "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH,"
				+ "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL,"
				+ "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory"
				+ " where clientid='"
				+ filterData.getClientID()
				+ "'"
				+ " and releaseno='Release Tag Not Generated' or exceptionflag IN ('HOLD','IMPLEMENTATION') )A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION";

		this.setTodaysDate_report(dateFormat.format(todaysDate));
		log.info("filter by unreleased " + queryInv);
		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);
		setReportLogs(mainLogs);
		setMainLogs(mainLogs);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
			RequestContext.getCurrentInstance().execute("PF('bar').show();");
			totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public void filterbyFilehold() {
		this.aipStatus = new ArrayList<String>();
		setAipStatus(aipStatus);

		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();
		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				+ " DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				+ " IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "
				+ "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH,"
				+ "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL,"
				+ "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory"
				+ " where clientid='"
				+ filterData.getClientID()
				+ "'"
				+ " and exceptionflag in ('HOLD','IMPLEMENTATION')"
				+ " )A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION";

		this.setTodaysDate_report(dateFormat.format(todaysDate));
		log.info("filter by file implementation " + queryInv);
		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);
		setReportLogs(mainLogs);
		setMainLogs(mainLogs);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
			RequestContext.getCurrentInstance().execute("PF('bar').show();");
			totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
	}
	
	public void filterbyFilefuture() {
		this.aipStatus = new ArrayList<String>();
		setAipStatus(aipStatus);

		this.startDate_report = "";
		this.endDate_report = "";
		this.todaysDate_report = "";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		resetFilterbyStatus();
		queryInv = "SELECT EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH, "
				+ " DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL, "
				+ " IMPORTSERVER,PAYOR,EXCEPTION_REMARK,EMPGRP,RELEASENO,DPSTATUS,APPROVEDBY,APPROVEDDATE,B.CATEGORY,B.COMMENTS,PROCESSDATE   FROM ( "
				+ "select  EXCEPTIONFLAG,FLAG,FILEID,FILENAME,CLIENTID,LAYOUTID,DATATYPE,FILE_SIZE,FILEDATE,TIMESTAMP,FILE_HASHKEY,FILE_RECORD_CNT,IMPORT_RECORD_CNT,UNIQUE_RECORDS_HASH,"
				+ "DUP_RECORD_CNT,STATUS_IMPORT,PATH,GETSTAT,STARTTIME,ENDTIME,TRANSFER_STATUS,DMFILEID,PROCESSFILEPATH,PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL,"
				+ "IMPORTSERVER,payor,exception_remark,empgrp,releaseno,dpstatus,approvedby,approveddate, CASE WHEN INFO13 LIKE '%ERROR OCCURED: IMPORTSTATUS|FAILURE 1.%' THEN 'ERROR OCCURED: IMPORTSTATUS|FAILURE 1. <ORACLE ERROR MESSAGE>' ELSE INFO13 END AS ERRORCATEGORY,PROCESSDATE   from aip_dashboard_inventory"
				+ " where clientid='"
				+ filterData.getClientID()
				+ "'"
				+ " and exceptionflag in ('FUTURE')"
				+ " )A LEFT JOIN AIP_ERROR_CATEGORIES B ON  A.ERRORCATEGORY= B.ERROR_DESCRIPTION";

		this.setTodaysDate_report(dateFormat.format(todaysDate));
		log.info("filter by file future: " + queryInv);
		mainLogs = new ArrayList<MainLog>();
		ReportLogs = new ArrayList<MainLog>();
		setQuery(queryInv);
		setReportLogs(mainLogs);
		setMainLogs(mainLogs);
		this.pipeLinecount = countPipeLine();
		if(this.pipeLinecount>0)
		{
			if(totalClick==0)
			{
			RequestContext.getCurrentInstance().execute("PF('bar').show();");
			totalClick++;
			}
			
		}

		importMainLogs = new MainLogDataModel(mainLogs);
	}

	public void changeReleaseTag() {
		resetFilters();
		releaseNos = new ArrayList<String>();
		setReleaseNos(releaseNos);
		reportsIDs = new ArrayList<String>();
		setReportsIDs(reportsIDs);
		this.latestinventory = "";
		this.appId = "";
		appIds = new ArrayList<String>();
		setAppIds(appIds);
		handleAppIdChange();
	}

	public void resetFilterbyStatus() {

		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}
	}

	public void fileForceRelease() {
		try {
			String fileID = "";
			if (this.selectedLogs.size() > 0) {
				if (this.selectedLogs.size() == 1) {
					fileID = selectedLogs.get(0).getFileID();
				} else {
					fileID = selectedLogs.get(0).getFileID();
					for (int i = 1; i < selectedLogs.size(); i++) {
						fileID = fileID + "," + selectedLogs.get(i).getFileID()
								+ "_" + selectedLogs.get(i).getDmFileID();
					}
				}

				log.info("Selected file for force release" + fileID);
				setForce_releasefileList(fileID);
				RequestContext.getCurrentInstance().execute(
						"PF('forceFilereleaseDialog').show();");
			} else {
				displayErrorMessageToUser(
						"No File Selected.Select some files for force release.",
						"Force File");
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Ops, we could not tag. Try again later! " + e.getMessage(),
					"Force File Status");
		}
		/*
		 * String fileID = getSelectedFileIds(); if (fileID.compareTo("") == 0
		 * || fileID == null) { displayErrorMessageToUser(
		 * "No File Selected.Select some files to force release.",
		 * "Force File Release"); } else {
		 * 
		 * setForce_releasefileList(fileID);
		 * RequestContext.getCurrentInstance().execute(
		 * "PF('forceFilereleaseDialog').show();"); }
		 */

	}

	public void forceFileRelease(String releasenum) {
		try {

			if (releasenum.compareTo(" ") == 0) {
				displayErrorMessageToUser("Please select release Tag",
						"Force File Status");
				return;
			}
			if (this.selectedLogs.size() > 0) {
				String result = "";
				ConnectDB db = new ConnectDB();
				db.initialize();
				for (int i = 0; i < selectedLogs.size(); i++) {
					String query = "UPDATE IMP_MAIN_LOG SET RELEASENO='"
							+ this.getUpreleaseNum()
							+ "', exceptionflag='', exceptionflagby='"
							+ getUserinfo().getFullname()
							+ "' WHERE  fileid||'_'||dmfileid ='"
							+ selectedLogs.get(i).getFileID() + "_"
							+ selectedLogs.get(i).getDmFileID() + "'";
					result = db.executeDML(query);
				}
				db.endConnection();
				if (result.compareTo("1") == 0) {
					if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
						setReleaseNum(getReleaseNum());
						filterbyReleaseNo();
					} else if (this.getFiltertype().compareTo(
							"filterbyreportid") == 0) {
						setReportID(getReportID());
						filterbyReportID();
					} else if (this.getFiltertype().compareTo(
							"filterbytimestamp") == 0) {
						filterLog();
					} else if (this.getFiltertype().compareTo(
							"filterbyholdfile") == 0) {
						filterbyFilehold();
					} else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
						setAppId(getAppId());
						setReleaseTag(getReleaseTag());
						filterbyReleaseTag(); 
					} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
						filterbyFilefuture();
					} else {
						filterbyUnreleased();
					}

					displayInfoMessageToUser(
							"Selected file(s) tagged for selected release Tag",
							"Force File Status");

				} else {
					displayErrorMessageToUser(
							"Failed to tag this file for selected release No",
							"Force File Status");
				}

			} else {
				displayErrorMessageToUser(
						"Please select file(s) for force release",
						"Force File Status");

			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Ops, we could not tag. Try again later! " + e.getMessage(),
					"Force File Status");
		}


	}

	public void fileHold() {
		try {
			if (this.selectedLogs.size() > 0) {
				ConnectDB db = new ConnectDB();
				db.initialize();
				String status = "";
				for (int i = 0; i < selectedLogs.size(); i++) {

					String query = "UPDATE IMP_MAIN_LOG SET exceptionflag='HOLD',releaseno='',exceptionflagby='"
							+ getUserinfo().getFullname()
							+ "' WHERE clientid='"
							+ this.getClient()
							+ "' and fileid||'_'||dmfileid ='"
							+ this.selectedLogs.get(i).getFileID()
							+ "_"
							+ this.selectedLogs.get(i).getDmFileID() + "'";
					status = db.executeDML(query);
				}
				db.endConnection();
				if (status.compareTo("1") == 0) {
					if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
						setReleaseNum(getReleaseNum());
						filterbyReleaseNo();
					} else if (this.getFiltertype().compareTo(
							"filterbyreportid") == 0) {
						setReportID(getReportID());
						filterbyReportID();
					} else if (this.getFiltertype().compareTo(
							"filterbytimestamp") == 0) {
						filterLog();
					} else if (this.getFiltertype().compareTo(
							"filterbyholdfile") == 0) {
						filterbyFilehold();
					}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
						setAppId(getAppId());
						setReleaseTag(getReleaseTag());
						filterbyReleaseTag(); 
					} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
						filterbyFilefuture();
					} else {
						filterbyUnreleased();
					}
					displayInfoMessageToUser(
							"Selected file(s) hold for this Data Batch",
							"File Hold Status");

				} else {
					displayErrorMessageToUser("Failed to tag this file",
							"File Hold Status");
				}

			} else {
				displayErrorMessageToUser("Please select file(s) for hold",
						"File Hold Status");

			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Ops, we could not hold this file . Try again later! "
							+ e.getMessage(), "File Hold Status");
		}

	}

	public void fileImplementation() {
		try {
			if (this.selectedLogs.size() > 0) {
				ConnectDB db = new ConnectDB();
				db.initialize();
				String status = "";
				for (int i = 0; i < selectedLogs.size(); i++) {

					String query = "UPDATE IMP_MAIN_LOG SET exceptionflag='IMPLEMENTATION',releaseno='',exceptionflagby='"
							+ getUserinfo().getFullname()
							+ "' WHERE clientid='"
							+ this.getClient()
							+ "' and fileid||'_'||dmfileid ='"
							+ this.selectedLogs.get(i).getFileID()
							+ "_"
							+ this.selectedLogs.get(i).getDmFileID() + "'";
					log.info("Update query for implementation is: " + query);
					String impTagQuery = "UPDATE IMP_FILES_RELTAG_RELN SET RELTAG='IMPLEMENTATION',RELEASEFLAG='IF' WHERE dmfileid||'_'||filename = '" 
										+ this.selectedLogs.get(i).getDmFileID() + "_" + this.selectedLogs.get(i).getFileName() + "'";
					log.info("Update query for release tag implementation is: " + impTagQuery);
			 		String userLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) VALUES ('1','FILE_INV_IMPLEMENTATION','SET AS IMPLEMENTATION OF CLIENTID:"
							+ this.client + " | FILEID:" + this.selectedLogs.get(i).getFileID() + " | DMFILEID:" + this.selectedLogs.get(i).getDmFileID() + "','"
							+this.userinfo.getFullname()+"',SYSDATE)";
			 		log.info("The user log for file implementation: " + userLog);
					status = db.executeDML(query);
					status = db.executeDML(impTagQuery);
					db.executeDML(userLog);
				}
				db.endConnection();
				if (status.compareTo("1") == 0) {
					if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
						setReleaseNum(getReleaseNum());
						filterbyReleaseNo();
					} else if (this.getFiltertype().compareTo(
							"filterbyreportid") == 0) {
						setReportID(getReportID());
						filterbyReportID();
					} else if (this.getFiltertype().compareTo(
							"filterbytimestamp") == 0) {
						filterLog();
					} else if (this.getFiltertype().compareTo(
							"filterbyholdfile") == 0) {
						filterbyFilehold();
					}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
						setAppId(getAppId());
						setReleaseTag(getReleaseTag());
						filterbyReleaseTag();
					} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
						filterbyFilefuture();
					} else {
						filterbyUnreleased();
					}
					displayInfoMessageToUser(
							"Selected file(s) Implementation for this Data Batch",
							"File Implementation Status");

				} else {
					displayErrorMessageToUser("Failed to tag this file",
							"File Implementation Status");
				}

			} else {
				displayErrorMessageToUser("Please select file(s) for Implementation",
						"File Implementation Status");

			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Ops, we could not put this file in Implementation. Try again later! "
							+ e.getMessage(), "File Implementation Status");
		}
	}
	
	public void reset() {
		this.force_releasefileList = "";

	}

	public void handleFilterchange() {
		this.latestinventory = "";
		resetFilters();
		setSelectedfiltertype(this.getFiltertype());
		if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
			releaseNos = new ArrayList<String>();
			setReleaseNos(releaseNos);
		}

		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			reportsIDs = new ArrayList<String>();
			setReportsIDs(reportsIDs);
		}
		
		if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			log.info("This is a release tag filter.");
			appIds = new ArrayList<String>();
			setAppIds(appIds);
		}
	}
	
	public void handleAppIdChange() {
		log.info("This is an app id change filter.");
		String query = "SELECT DISTINCT releasetagidbyapp FROM (SELECT releasetagidbyapp FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+this.appId+"'" + 
						" ORDER BY CREATED DESC) UNION SELECT DISTINCT RELTAG FROM imp_files_reltag_reln WHERE app_id = '"+this.appId+"'";
		log.info(query);
		this.releaseTags = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					releaseTags.add(rs.get(i).get(0));
				}
			}
		} 
		//setReleaseTags(releaseTags);
	}

	public String getReleaseNum() {
		return releaseNum;
	}

	public void setReleaseNum(String releaseNum) {
		this.releaseNum = releaseNum;
	}

	public String getUpreleaseNum() {
		return upreleaseNum;
	}

	public void setUpreleaseNum(String upreleaseNum) {
		this.upreleaseNum = upreleaseNum;
	}

	public void resetFilters() {
	}

	public void prepareOracleCommand(MainLog mainlog, String server) {

	
		String oraclelogPath = AIConstant.OracleLogPath + mainlog.getFileName()
				+ "_" + mainlog.getFileID() + "_" + mainlog.getDmFileID() + "."
				+ this.filterData.getClientID() + ".log";
		log.info("Oracle Log Path :" + oraclelogPath);
		File file = new File(oraclelogPath);
		if (file.exists()) {
			FileController objFC = new FileController(oraclelogPath);
			setFileMedia(objFC.getDownload());
		} else {

			setFileMedia(null);
			displayErrorMessageToUser("FILE NOT FOUND", "CANNOT DOWNLOAD");
			// regenerateInventory(username);

		}

	}
	
	public void showTopEDILog(MainLog mainlog, String server) {
		String EDILogPath = AIConstant.EDILogPath + mainlog.getFileName() + "." + mainlog.getClientID() + ".log";
		log.info("EDI File Log Path is: " + EDILogPath);
		String servertoconnect = getServer(this.client);
		log.info("Server: " + servertoconnect);
		
		RuntimeExecutor objRT = new RuntimeExecutor(servertoconnect);

		String topCommand = "head -15 " + EDILogPath;
		log.info("The head command is: " + topCommand);		

		try {
			this.topTenRecord = objRT.runSimpleCommand(topCommand);
			if (this.topTenRecord.isEmpty()) {
				displayErrorMessageToUser("File Not Found", "Error");
				return;
			} else {				
				RequestContext.getCurrentInstance().execute("PF('EDILogBox').show();");
				log.info("This is EDI Error box");
			}
		} catch (Exception ex) {
			log.info(ex.toString());
			displayErrorMessageToUser("File Not Found", "Error");
		}
				
		FileController objFC = new FileController(EDILogPath);
		setDownloadFile(objFC.getDownload());
		
	}

	public void prepDownloadReport(MainLog obj) {
		String path = AIConstant.DP_REPORTS_PATH + "DPR_" + obj.getFileID()
				+ ".xlsx";
		log.info(path);
		File file = new File(path);
		if (file.exists()) {
			FileController objFC = new FileController(path);
			setDownloadDPR(objFC.getDownload());
		} else {

			setDownloadDPR(null);
			displayErrorMessageToUser("FILE NOT FOUND", "CANNOT DOWNLOAD");
			// regenerateInventory(username);

		}

	}

	public DefaultStreamedContent getDownloadDPR() {
		return downloadDPR;
	}

	public void setDownloadDPR(DefaultStreamedContent downloadDPR) {
		this.downloadDPR = downloadDPR;
	}

	public DefaultStreamedContent getFileMedia() {
		return fileMedia;
	}

	public void setFileMedia(DefaultStreamedContent fileMedia) {
		this.fileMedia = fileMedia;
	}

	public void handlecurrentDate() {
		try {

			SimpleDateFormat tformat = new SimpleDateFormat("HH:mm:ss");
			log.info("Time " + tformat.format(endDate));
			if (tformat.format(endDate).compareTo("00:00:00") == 0) {

				log.info("Date: " + this.getEndDate());
				SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
				String denddate;

				denddate = dformat.format(this.getEndDate());
				endDate = dformat.parse(denddate);
				Calendar cal = Calendar.getInstance();

				cal.setTime(endDate);
				endDate = cal.getTime();
				log.info("Data cal date " + endDate);
				// data_end_date=dformat.parse(data_end_date);
				endDate = DateUtils.addHours(endDate, 23);
				endDate = DateUtils.addMinutes(endDate, 59);
				endDate = DateUtils.addSeconds(endDate, 59);
				log.info("Last End Date " + endDate);
				setEndDate(endDate);
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Date Exception Occured. Please try again", "Date");
			return;
		}
	}



	public String getReportAlert() {
		return reportAlert;
	}

	public void setReportAlert(String reportAlert) {
		this.reportAlert = reportAlert;
	}

	public MessageObject getMsgObject() {
		return msgObject;
	}

	public void setMsgObject(MessageObject msgObject) {
		this.msgObject = msgObject;
	}

	public int getPipeLinecount() {
		return pipeLinecount;
	}

	public void setPipeLinecount(int pipeLinecount) {
		this.pipeLinecount = pipeLinecount;
	}
	
	public int countPipeLine()
	{
		int count  = 0;
		if(!this.client.isEmpty() || this.client !=null)
		{
		ConnectDB db = new ConnectDB();
		db.initialize();
		//String query = "select count(*) from aip_dashboard_pipeline where clientid ='" + this.client + "'";
		String query = "SELECT Count(*) FROM (SELECT CLIENTID, fileid AS dmfileid,FILENAME, CHECKSUM,FILESIZE, RECEIVEDDATE AS FILERECEIVEDDATE,FILEDATE AS mappedondate, " +
					   " '\\eiger'||DESTPATH AS FullFilePath, 'IN QUEUE' AS status,eigertransferdate   FROM imp_dmfilelist a WHERE NOT EXISTS" +
					   " (SELECT 1 FROM aip_dmfilelist_log b WHERE a.fileid=b.dmfileid) UNION SELECT * FROM aip_alldmfilelist_query ) WHERE " +
					   " clientid = '" + this.client + "'";
		log.info("Counting query is: " + query);
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		
		if(rs!=null)
		{
			count = Integer.parseInt(rs.get(1).get(0));
		}
		else
		{
			count = 0;
		}
		
		}
		else
		{
			count = 0;
		}
		return count;
	}

	public int getTotalClick() {
		return totalClick;
	}

	public void setTotalClick(int totalClick) {
		this.totalClick = totalClick;
	}
	
	public void openfilerepalementDialog() {
		
		if (!this.selectedLogs.isEmpty()) {
			if (this.selectedLogs.size()==1){
				 log.info("file replacement dialog goes here ");
				 setDmFileId(this.selectedLogs.get(0).getDmFileID());
				 setFileId(this.selectedLogs.get(0).getFileID());
				 String layoutid= this.selectedLogs.get(0).getLayoutID();
				 
				String querycheck = "SELECT  count(1) as dcheck FROM imp_main_log"
			              + " where clientid='" + this.client + "' AND fileid='"+ this.fileId +"' AND dmfileid='"+ this.dmFileId
			              + "' AND  EXCEPTIONFLAG='DO NOT USE'";

					
				 ConnectDB dbcheck = new ConnectDB();
				 dbcheck.initialize();
				 List<List<String>> rscheck = dbcheck.resultSetToListOfList(querycheck);
				 //log.info(" filelist query:" + querycheck);
				 dbcheck.endConnection();
				 String   checkvalue="";;
				 if (rscheck.size()>1){
					 checkvalue=rscheck.get(1).get(0); 
				 }
				 if (layoutid.compareTo("3") !=0){	 
					 if (checkvalue.compareTo("1") != 0)	{ 
						 //load replacement value in select box 
						 replacefileNos = new LinkedHashMap<String, String>();
						 String query = "SELECT  FILEID, FILENAME,DMFILEID FROM imp_main_log"
						            + " where clientid='" + this.client + "' AND (EXCEPTIONFLAG !='DO NOT USE' OR LAYOUTID !='3')"
                                    + " order by FILENAME ASC ";
					
						 ConnectDB db = new ConnectDB();
						 db.initialize();
						 List<List<String>> rs = db.resultSetToListOfList(query);
						 log.info(" filelist query:" + query);
						 db.endConnection();
						 if (rs != null) {
							 if (rs.size() > 0) {
								 for (int i = 1; i < rs.size(); i++) {
						              if(!(this.fileId.equals(rs.get(i).get(0)))){
						            	  //replacefileNos.add(rs.get(i).get(0)+"-"+rs.get(i).get(1));
						            	  replacefileNos.put(rs.get(i).get(0)+"-("
													+ rs.get(i).get(1) + ")", rs.get(i).get(2));
						            	 // log.info("list value: " + replacefileNos.get(i-1));
						               }
									}
								} 
							}
							
							 setReplacefileNos(replacefileNos);
							 
							 RequestContext.getCurrentInstance().execute(
									"PF('fileReplacementDialog').show();");
						}else{
						    displayInfoMessageToUser("File you selected is  do not use file!","File Replacement Status");
						}
					 }else{
						 displayInfoMessageToUser("File you selected is  do not use file!","File Replacement Status");
					 }
				}else{
					displayInfoMessageToUser("Multiple files are selected,Please select only one file!","File Replacement Status");
				}
			}else{
				displayInfoMessageToUser("No file is selected!","File Replacement Status");
			}
	 	 
		}
	

	public void handlerelStatusChange() {
		log.info("handle status change started: ");
		setDmFileId(this.selectedLogs.get(0).getDmFileID());
		setFileId(this.selectedLogs.get(0).getFileID());
			 
		//load replacement value in select box 
		String query = "SELECT  APP_ID FROM imp_files_reltag_reln"
	               + " where DMFILEID='" + this.dmFileId +"'";
				   
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		log.info(" filelist query:"+ query+ " " + rs.size());
		db.endConnection();
		String appId = "";
		if (rs.size() > 1) {
			appId=rs.get(1).get(0);
		}
		
		log.info("appid:"+appId);
		reltagFileReplaceNos = new ArrayList<String>();
		
		//load releasetab  value by app id 
		   
		String queryrel = "SELECT  DISTINCT(releasetagidbyapp) FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK
			               + " where APPLICATIONID='" + appId + "' AND STATUS='"+this.tagStatus 
						    + "'  order by APPLICATIONID ASC ";

		ConnectDB dbrel = new ConnectDB();
		dbrel.initialize();
		List<List<String>> rsrel = dbrel.resultSetToListOfList(queryrel);
		log.info(" filelist query:" + queryrel + " "+rsrel.size());
		dbrel.endConnection();
		if (rsrel != null) {
				if (rsrel.size() > 1) {
						for (int i = 1; i < rs.size(); i++) {
			
							reltagFileReplaceNos.add(rsrel.get(i).get(0));
							log.info("list value: " + reltagFileReplaceNos.get(i-1));
						}
					} 
		}
		setReltagFileReplaceNos(reltagFileReplaceNos);	
	}
	
	public void handleLogDownload(MainLog mainlog) {
		String filePath = AIConstant.EDILogPath + mainlog.getFileName() + "." + mainlog.getClientID() + ".log";
		FileController objFC = new FileController(filePath);
		setDownloadFile(objFC.getDownload());
	}
	
	public void filereplacement() {
		log.info("file replacement goes here ");
	 	
		log.info("clientid: "+ this.client);
	 	log.info("dmfileid: "+ this.dmFileId);
	 	log.info("fileid: "+ this.fileId);
	 	log.info("Replace dmfileid: "+ this.upreplaceNum);
	 	log.info("Release tag status: : "+ this.tagStatus);
	 	log.info("Release tag : "+ this.reltagforrepalce);
      
	 	if (this.upreplaceNum !=""){
	 		log.info("Started DO NOT USE for existing file  ");
	 		String userLog = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) VALUES ('1','FILE REPLACEMENT_DONOTUSE_LOG','SET AS DO NOT USE BY FILE REPLACEMENT CLIENTID:"
					+ this.client + " | FILEID:" + this.fileId + " | DMFILEID:" + this.dmFileId + "','"
					+this.userinfo.getFullname()+"',SYSDATE)";
	
			ConnectDB db = new ConnectDB();
			db.initialize();
			try {
				db.executeDML(userLog);
			} catch (Exception e) {
				log.info("There is a problem in user log for filereplacement do not use: " + e.getMessage());
			}
			db.endConnection();
			
			ConnectDB conn = new ConnectDB();
			conn.initialize();
			String query = "UPDATE imp_main_log SET EXCEPTIONFLAG ='DO NOT USE',exceptionflagby='"
					+ getUserinfo().getFullname()
					+ "' WHERE fileid='"+this.fileId+"' AND dmfileid ='"+this.dmFileId+"'";
		    try{    
			conn.executeDML(query);
			log.info(" donnot update query:" + query);
		    }catch (Exception e) {
				log.info("there is error on updating Do not user: "+ e.getMessage());
			}
			conn.endConnection();
							
				
			log.info("Started force release  replacecement file to releasetag assoicated to whith existing file");
			if(this.reltagforrepalce !=""){	
				//for user log
				String userLogs = "INSERT INTO IMP_USER_LOG (SN,LOGTYPE,LOGDETAIL,USERNAME,LOGDATE) VALUES ('1','FORCE_RELTAG BY FIlE REPLACEMENT','FORCE RELEASED FROM FILE REPLACE TO :"
						+ this.reltagforrepalce + " | DMFILEID:" + this.upreplaceNum + "','"
						+this.userinfo.getFullname()+"',SYSDATE)";
		
				ConnectDB dbtag = new ConnectDB();
				dbtag.initialize();
				try {
					dbtag.executeDML(userLogs);
				} catch (Exception e) {
					log.info("There is a problem in user log for filereplacement do not use: " + e.getMessage());
				}
				dbtag.endConnection();
				
				ConnectDB connrel = new ConnectDB();
				connrel.initialize();
				String queryrel = "UPDATE imp_files_reltag_reln set RELTAG='"+ this.reltagforrepalce
									+ "' WHERE DMFILEID = '"+ this.upreplaceNum +"'"; 
				try{			
					String y=connrel.executeDML(queryrel);
					log.info(" force release update query:" + queryrel);
					if (y.compareTo("1") == 0) {
						if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
							setReleaseNum(getReleaseNum());
							filterbyReleaseNo();
						} else if (this.getFiltertype().compareTo(
								"filterbyreportid") == 0) {
							setReportID(getReportID());
							filterbyReportID();
						} else if (this.getFiltertype().compareTo(
								"filterbytimestamp") == 0) {
							filterLog();
						} else if (this.getFiltertype().compareTo(
								"filterbyholdfile") == 0) {
							filterbyFilehold();
						}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
							setAppId(getAppId());
							setReleaseTag(getReleaseTag());
							filterbyReleaseTag(); 
						} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
							filterbyFilefuture();
						} else {
							filterbyUnreleased();
						}
						displayInfoMessageToUser(
								"File replacement is done successfully",
								"File Replacement");
	
					} else {
						displayErrorMessageToUser("Failed to forcetag this file",
								"File Replacement");
					}
	
				}catch (Exception e){
					 log.info("There is error on updating on force release: "+e.getMessage());
				}
				connrel.endConnection();
			}else{
				if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
					setReleaseNum(getReleaseNum());
					filterbyReleaseNo();
				} else if (this.getFiltertype().compareTo(
						"filterbyreportid") == 0) {
					setReportID(getReportID());
					filterbyReportID();
				} else if (this.getFiltertype().compareTo(
						"filterbytimestamp") == 0) {
					filterLog();
				} else if (this.getFiltertype().compareTo(
						"filterbyholdfile") == 0) {
					filterbyFilehold();
				}  else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
					setAppId(getAppId());
					setReleaseTag(getReleaseTag());
					filterbyReleaseTag(); 
				} else if (this.getFiltertype().compareTo("filterbyfuturefile") == 0) {
					filterbyFilefuture();
				} else {
					filterbyUnreleased();
				}
				displayInfoMessageToUser("File Replaced But Force release tag is not found associated with replaced File","File Replacement Status");
			}
		 }else{
		 		displayInfoMessageToUser("Please select one replacement file!","File Replacement Status");
		 		openfilerepalementDialog();
		 }
	}

}
