/*
 *Class Name : ImportRelease.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.controller;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.flms.model.MClients;
import com.vit.ai.inventory.model.ImportReleaseModel;
import com.vit.ai.poireport.controller.InventoryReportController;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.ai.utils.CustomUtility;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 2015/05/18
 */
@ManagedBean
@ViewScoped
public class ImportRelease extends AbstractController implements Serializable {
	private static Logger log = Logger.getLogger(ImportRelease.class.getName());

	private static final long serialVersionUID = 1L;
	private ArrayList<ImportReleaseModel> listofConfigurations;
	private LinkedHashMap<String, String> clients;
	private String clientid;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private Date data_start_date;
	private Date data_end_date;
	
	private String batch_name;
	private String release_number;
	private String created_by;
	private String updated_by;
	private String releaseBy;
	private String releaseType;
	private String remarks;
	private String releaseDetails;
	private boolean valueChanged = false;
	private String winScreenHeight;
	protected FilterLogController filterData;
	private String end_date;
	
	

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	private DefaultStreamedContent downloadReleaseReport;
	private String reportID;
	private String releaseStatus;

	public DefaultStreamedContent getDownloadReleaseReport() {
		return downloadReleaseReport;
	}

	public void setDownloadReleaseReport(
			DefaultStreamedContent downloadReleaseReport) {
		this.downloadReleaseReport = downloadReleaseReport;
	}

	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	private String reportName;
	private boolean subRelease = false;
	private String mainRelease;

	

	
	public boolean isValueChanged() {
		return valueChanged;
	}

	public void setValueChanged(boolean valueChanged) {
		this.valueChanged = valueChanged;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getReleaseBy() {
		return releaseBy;
	}

	public void setReleaseBy(String releaseBy) {
		this.releaseBy = releaseBy;
	}

	
	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	private String sn;

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public Date getData_start_date() {
		return data_start_date;
	}

	public void setData_start_date(Date data_start_date) {
		this.data_start_date = data_start_date;
	}

	public Date getData_end_date() {
		return data_end_date;
	}

	public void setData_end_date(Date data_end_date) {
		this.data_end_date = data_end_date;
	}

	public String getBatch_name() {
		return batch_name;
	}

	public void setBatch_name(String batch_name) {
		this.batch_name = batch_name;
	}

	public String getRelease_number() {
		return release_number;
	}

	public void setRelease_number(String release_number) {
		this.release_number = release_number;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public String getClientid() {
		return filterData.getClientID();
	}

	public void setClientid(String clientid) {
		filterData.setClientID(clientid);
		this.clientid = filterData.getClientID();
		
	}

	public void doNothing() {

	}
	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}
	public ImportRelease() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
		MClients objMC = new MClients(false);
		setClients(objMC.getClients());
		this.subRelease = false;
		
	}

	public void handleTimestamp(){
		try{
			
			SimpleDateFormat tformat = new SimpleDateFormat("HH:mm:ss");
			log.info("Time "+tformat.format(data_end_date));
			if(tformat.format(data_end_date).compareTo("00:00:00")==0){
				
				log.info("Date: "+this.getData_end_date());
				SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd");
				String denddate;
				
				denddate=dformat.format(this.getData_end_date());
				data_end_date=dformat.parse(denddate);
				Calendar cal = Calendar.getInstance();
				
				cal.setTime(data_end_date);
				data_end_date=cal.getTime();
				log.info("Data cal date "+data_end_date);
				//data_end_date=dformat.parse(data_end_date);
				data_end_date=DateUtils.addHours(data_end_date, 23);
				data_end_date=DateUtils.addMinutes(data_end_date, 59);
				data_end_date=DateUtils.addSeconds(data_end_date, 59);
				log.info("Last End Date "+data_end_date);
				setData_end_date(data_end_date);
				}
		}
		catch(Exception e){
			displayErrorMessageToUser("Date Exception Occured. Please try again", "Date");
			return;
		}
		
		
		
	}
	public void handleClientChange() {
		reset();
		
		this.listofConfigurations = new ArrayList<>();
	
		/*String query = "SELECT CLIENTID,DATA_START_DATE,DATA_END_DATE,NVL(subReleasenumber,RELEASE_NUMBER) as releasenum, RELEASE_STARTDATE,REMARKS,CREATED_BY,SN,RELEASETYPE , "
					+" (SELECT count(dmfileid) AS filenum FROM aip_dashboard_inventory WHERE releaseno=NVL(subReleasenumber,RELEASE_NUMBER) ) AS FileNum "
					+" FROM  AIP_CYCLE_MASTER A   WHERE A.clientid='"+this.clientid+"' ORDER BY release_number desc,sn";*/
		String query = "SELECT b.CLIENTID,DATA_START_DATE,DATA_END_DATE,NVL(subReleasenumber,RELEASE_NUMBER) as releasenum, RELEASE_STARTDATE,REMARKS,CREATED_BY,SN,RELEASETYPE, Nvl(filenum,0) AS filenum "
					   + " FROM AIP_CYCLE_MASTER b left JOIN (SELECT count(dmfileid) AS filenum,releaseno ,clientid FROM  aip_dashboard_inventory  GROUP BY releaseno,clientid) a "
					   + " ON a.releaseno=NVL(b.subReleasenumber,b.RELEASE_NUMBER) AND a.clientid=b.clientid WHERE b.clientid='"+this.clientid+"' ORDER BY release_number desc,sn";
		log.info(" Batch display query: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);

		db.endConnection();

		
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					log.info(rs.get(i).get(3));

					this.listofConfigurations.add(new ImportReleaseModel(rs
							.get(i).get(0), rs.get(i).get(1), rs.get(i).get(2),
							rs.get(i - 1).get(3), rs.get(i).get(3), rs.get(i)
									.get(4), rs.get(i).get(5),
							rs.get(i).get(6), rs.get(i - 1).get(7), rs.get(i)
									.get(7), rs.get(i).get(8), rs.get(i).get(9)));

				}
			} else {

			}
		} else {
			displayErrorMessageToUser("Query Execution Failed", "ERROR");
		}

		

	}

	/**
	 * @return the listofConfigurations
	 */
	public ArrayList<ImportReleaseModel> getListofConfigurations() {
		return listofConfigurations;
	}

	/**
	 * @param listofConfigurations
	 *            the listofConfigurations to set
	 */
	public void setListofConfigurations(
			ArrayList<ImportReleaseModel> listofConfigurations) {
		this.listofConfigurations = listofConfigurations;
	}

	/**
	 * @return the clients
	 */
	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	/**
	 * @param clients
	 *            the clients to set
	 */
	public void setClients(LinkedHashMap<String, String> clients) {
		this.clients = clients;
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}


	public Calendar getCallenderCurrentIntance() {
		return Calendar.getInstance();

	}

	public void startProcess(ImportReleaseModel cycleModel) {
		try {
			String release_Details = "";
			
			
			log.info("Data end date " + getData_end_date());
			if (cycleModel.getData_end_date().isEmpty()
					&& cycleModel.getData_end_date() == null) {
				displayInfoMessageToUser(
						"Process End date could not be empty. Please provide process end date.",
						"Batch Status");
				return;
			}
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> dateList = db
					.resultSetToListOfList("SELECT max(data_end_date) FROM AIP_CYCLE_MASTER WHERE CLIENTID='"
							+ this.clientid
							+ "'");

			log.info("Batch Details are " + release_Details);
			String query = "UPDATE AIP_CYCLE_MASTER SET RELEASE_STARTDATE=sysdate WHERE SN='"
					+ cycleModel.getSn() + "'";
		
			
			  String setrelease_query = " UPDATE IMP_MAIN_LOG SET RELEASENO='"
			  + cycleModel.getRelease_number() + "' where CLIENTID='" +
			  cycleModel.getClientid() + "' AND " +
			  " PROCESSSTARTTIME >= TO_TIMESTAMP('"
			  + cycleModel.getData_start_date().split("\\.")[0] +
			  "','YYYY-MM-DD HH24:MI:SS') " +
			  " AND PROCESSSTARTTIME <= TO_TIMESTAMP('"
			  + cycleModel.getData_end_date().split("\\.")[0] +
			  "','YYYY-MM-DD HH24:MI:SS')";
			

			log.info("Set Batch Query: " + setrelease_query);
			String result = db.executeDML(setrelease_query);
			String status = db.executeDML(query);

			db.endConnection();
			if (result.compareTo("1") == 0 && status.compareTo("1") == 0) {
				handleClientChange();
				setSubRelease(false);
				if (cycleModel.getRelease_status().compareTo("Main Batch") != 0) {
					displayInfoMessageToUser(
							"Data batch is set for the file between provided process start date and process end date.",
							"Batch Status");
				} else {
					
					SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					if (dateList != null) {
						if (dateList.size() > 1) {
							log.info("Date size "+dateList.size());
							//if(dateList.size()==1){
								log.info("Date size1 "+dateList.get(1).get(0));
								 this.data_start_date = DateUtils.addSeconds(
										  dformat.parse(dateList.get(1).get(0)), 1);
								  setData_start_date(this.data_start_date); 
						

							}
						} 
					 else {
						displayErrorMessageToUser("Query Execution Failed", "ERROR");
					}
					

					RequestContext.getCurrentInstance().execute(
							"PF('addnextCycle').show();");
				}

			} else {
				displayErrorMessageToUser("Batch Failed.Please Try again",
						"Batch Status");
			}
		} catch (Exception e) {
			displayErrorMessageToUser("Batch Failed.Please Try again",
					"Batch Status");
		}

	}
	

	/**
	 * @throws ParseException
	 */
	public void add() throws ParseException {
		
		 try{
		 

		SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// SimpleDateFormat formatcheck= new SimpleDateFormat("MM");
		this.subRelease = false;
		if (this.releaseType.compareTo("releasetype") == 0) {
			displayErrorMessageToUser(
					"Batch type could not be empty.Please Try again",
					"Batch Status");
			return;
		}
		
			this.sn = "";
			String dstartDate = "";
			String dendDate="";

			String dateformat = "yyyy.MM.dd hh24:mi:ss";
			log.info("abc");

			this.release_number = getReleaseNumber();
			if (this.release_number == "") {
				displayErrorMessageToUser(
						"Batch No not generated.Please try again.",
						"Batch Generation Status");
				return;
			}
			if (this.data_start_date != null) {
				dstartDate = dformat.format(this.data_start_date);
			} else {
				displayErrorMessageToUser(
						"Process Start Date Could not be Empty.Please Try again",
						"Cycle Date Status");
				return;
			}
			if(this.data_end_date !=null){
				/*this.data_end_date = DateUtils.addHours((this.data_end_date), 23);
				this.data_end_date = DateUtils.addMinutes((this.data_end_date), 59);
				this.data_end_date = DateUtils.addSeconds((this.data_end_date), 59);*/
				dendDate=dformat.format(this.data_end_date);
			}else{
				/*this.data_end_date = Calendar.getInstance().getTime();
				dendDate=dformat.format(this.data_end_date);*/
				displayErrorMessageToUser(
						"Process End Date Could not be Empty.Please Try again",
						"Cycle Date Status");
				return;
			}

			if (dformat.format(this.data_end_date).compareTo(
					dformat.format(this.data_start_date)) < 0) {
				displayErrorMessageToUser(
						"Process End Date is before the Process Start Date. Please try again",
						"Batch Status");
				return;
			}
			
			String query = "Insert into aip_cycle_master(CLIENTID, DATA_START_DATE, DATA_END_DATE,REMARKS, RELEASE_NUMBER,RELEASETYPE, "
					+ "CREATED_BY, CREATED_DATE) values "
					+ "('"
					+ this.clientid + "'";

			query = query + ",TO_DATE('" + dstartDate + "','" + dateformat
					+ "')";
			

				query = query + ",TO_DATE('"
						+ dendDate + "','"
						+ dateformat + "')";
			
			query = query  + ",'"
					+ this.remarks.replace("'", "''") + "','"
					+ this.release_number + "','Main Batch','"
					+ this.getUserinfo().getFullname() + "',sysdate)";

			log.info("INsert query" + query);
			int index = this.listofConfigurations.size();
		
			if (index > 0 ) {
					log.info("Index " + index);
					for (int k = 0; k < index; k++) {

						if (listofConfigurations.get(k).getData_start_date()
								.split("\\.")[0].toString()
								.compareTo(
										dformat.format(this.data_start_date)
												.toString()) == 0
								&& listofConfigurations.get(k)
										.getData_end_date().split("\\.")[0]
										.toString().compareTo(
												dformat.format(
														this.data_end_date)
														.toString()) == 0
								
								&& listofConfigurations.get(k)
										.getRelease_status()
										.compareTo("Main Batch") == 0) {
							displayErrorMessageToUser(
									"Duplicate main batch cycle with Batch No: "
											+ listofConfigurations.get(k)
													.getRelease_number()
											+ " . Please try again.",
									"Duplicate Cycle");

							return;
						}
						
							if ((dformat.format(this.data_start_date)
									.compareTo(
											listofConfigurations.get(k)
													.getData_start_date()
													.split("\\.")[0]) > 0 && dformat
									.format(this.data_start_date).compareTo(
											listofConfigurations.get(k)
													.getData_end_date()
													.split("\\.")[0]) < 0)
									|| (dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) > 0 && dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) < 0)
									|| (dformat
											.format(this.data_start_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) < 0 && dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) > 0)
									|| (dformat
											.format(this.data_start_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) < 0 && dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) > 0)
									|| dformat
											.format(this.data_start_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) == 0
									|| dformat.format(this.data_start_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) == 0
									|| dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) == 0
									|| dformat.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) == 0) {
								displayErrorMessageToUser(
										"Date is overlapped with Batch No: "
												+ listofConfigurations.get(k)
														.getRelease_number()
												+ " . please try again",
										"Batch Status");
								return;
							}
						

						

					}
				}

		
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result = db.executeDML(query);
			
			db.endConnection();
			

			db.endConnection();
			if (result.compareTo("1") == 0) {

				displayInfoMessageToUser("Successfully added",
						"Cycle Date addded");
				this.setValueChanged(false);
				handleClientChange();
				RequestContext.getCurrentInstance().execute(
						"PF('addCycle').hide();");

			} else {
				displayErrorMessageToUser(
						"Cycle Addition Failed.Please Try again", "Failed");
			}
	
		
		  }catch(Exception e){
		  displayErrorMessageToUser("Failed to add Data Batch. Please try again"
		  , "Batch Status"); }
		 

	}

	@SuppressWarnings("deprecation")
	public String getReleaseNumber() {
		SimpleDateFormat dformat = new SimpleDateFormat("yyyy");
		String existsubRelease = "";
		String existReleaseno = "";
		String rnum = "";
		try {
			if (this.data_start_date != null) {
				int mm = this.data_start_date.getMonth();
				String month = "";
				if (mm < 10) {
					month = "0" + String.valueOf(mm + 1);
				} else {
					month = String.valueOf(mm + 1);
				}
				String year = "";

				/*int yy = this.data_start_date.getYear();
				year = String.valueOf(yy).substring(1);*/
				year=dformat.format(this.data_start_date);
				log.info("Year : " + year);
				rnum = this.clientid + "." + year + "." + month+".S0";
			}

			ConnectDB db = new ConnectDB();
			db.initialize();
			String query="SELECT  RELEASE_NUMBER FROM AIP_CYCLE_MASTER WHERE CLIENTID='"
							+ this.clientid
							+ "' AND RELEASE_NUMBER is not null AND RELEASE_NUMBER LIKE '%"
							+ rnum.replace(".S0","") + "%' ORDER BY   sn asc";
			List<List<String>> existing_release_List = db
					.resultSetToListOfList(query);
			log.info(query);
			db.endConnection();
			if (existing_release_List.size() >0) {
				existReleaseno = existing_release_List.get(
						existing_release_List.size()-1).get(0);
				log.info("LST "+existing_release_List.get(
						existing_release_List.size()-1).get(0));
				
				log.info("Size" +existing_release_List.size());
				if (rnum.compareTo(existReleaseno) == 0) {
					rnum=rnum.replace(".S0", "")+"-A.S0";
					log.info("Second "+rnum);
					//rnum += "-A";
				} else {
					if (existReleaseno.contains("-")) {

						log.info("Existing Batch containing - : "
								+ existsubRelease);
						String status = existReleaseno.toString().replaceAll(".S0", "").split("\\-")[1];
						rnum = rnum.toString().replaceAll(".S0", "");
						log.info("Status: " + status);
						switch (status) {
						case "A":
							rnum += "-B.S0";
							break;

						case "B":
							rnum += "-C.S0";
							break;

						case "C":
							rnum += "-D.S0";
							break;

						case "D":
							rnum += "-E.S0";
							break;

						case "E":
							rnum += "-F.S0";
							break;

						case "F":
							rnum += "-G.S0";
							break;

						case "G":
							rnum += "-H.S0";
							break;

						case "H":
							rnum += "-I.S0";
							break;

						case "I":
							rnum += "-J.S0";
							break;

						case "J":
							rnum += "-K.S0";
							break;

						case "K":
							rnum += "-L.S0";
							break;

						case "L":
							rnum += "-M.S0";
							break;

						case "M":
							rnum += "-N.S0";
							break;

						case "N":
							rnum += "-O.S0";
							break;

						case "O":
							rnum += "-P.S0";
							break;

						case "P":
							rnum += "-Q.S0";
							break;

						case "Q":
							rnum += "-R.S0";
							break;

						case "R":
							rnum += "-S.S0";
							break;

						case "S":
							rnum += "-T.S0";
							break;

						case "T":
							rnum += "-U.S0";
							break;

						case "U":
							rnum += "-V.S0";
							break;

						case "V":
							rnum += "-W.S0";
							break;

						case "W":
							rnum += "-X.S0";
							break;

						case "X":
							rnum += "-Y.S0";
							break;

						case "Y":
							rnum += "-Z.S0";
							break;

						default:
							displayErrorMessageToUser(
									"Batch No can't be generated. Please contact AIP Team.",
									"Batch Status");
							break;

							
						}
						
					}
				}

			}
			log.info("Batch nono: "+rnum);

		} catch (Exception e) {
			displayErrorMessageToUser(
					"Batch No can't be generated. Please contact AIP Team."
							+ e.getMessage(), "Batch Status");

		}
		return rnum;
	}


	public void updateCycle(ImportReleaseModel cycleModel)
			throws ParseException {
		try {

			SimpleDateFormat dformat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			if (!cycleModel.getData_end_date().isEmpty()
					&& cycleModel.getData_end_date() != null) {
				this.data_end_date = dformat.parse(cycleModel
						.getData_end_date());
			} else {
				this.data_end_date = null;
			}
			if (cycleModel.getRelease_status().compareTo("Sub Batch") == 0) {
				subRelease = true;
				String subreleaseNum = cycleModel.getRelease_number();
				log.info("Sub Batch num: " + subreleaseNum);

				subreleaseNum = subreleaseNum.split(".S")[0];
				
			} else {
				subRelease = false;
			}
			this.clientid = cycleModel.getClientid();
			
			
			setSn(cycleModel.getSn());
			setRemarks(cycleModel.getRemarks());
			setReleaseStatus(cycleModel.getRelease_status());
			setData_start_date(dformat.parse(cycleModel.getData_start_date()));
			RequestContext.getCurrentInstance().execute(
					"PF('updateCycle').show();");
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Failed to open update dialog. Please try again",
					"Batch update Status");
			return;
		}
	}

	public void update() {
		SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dendDate = "";
		String dateformat = "yyyy.MM.dd hh24:mi:ss";
		if (isValueChanged()) {
			if (this.data_end_date != null) {
				dendDate = dformat.format(this.data_end_date);
			} else {
				displayErrorMessageToUser(
						"Process End Date Could not be Empty.Please Try again",
						"Cycle Date Status");
				return;
				/*this.data_end_date = Calendar.getInstance().getTime();
				dendDate=dformat.format(this.data_end_date);
				log.info("Update Date end date: "
						+ this.data_end_date);*/
			}
			log.info("Process date " + this.data_start_date);
			log.info("Batch type " + this.releaseType);
			if (dformat.format(this.data_end_date).compareTo(
					dformat.format(this.data_start_date)) < 0) {
				displayErrorMessageToUser(
						"Process End Date is before the Process Start Date. Please try again",
						"Batch Status");
				return;
			}
			int index = this.listofConfigurations.size();
			if (index > 0 ) {
				log.info("Index " + index);
				for (int k = 0; k < index; k++) {

					if (listofConfigurations.get(k).getData_start_date()
							.split("\\.")[0].toString()
							.compareTo(
									dformat.format(this.data_start_date)
											.toString()) == 0
							&& listofConfigurations.get(k)
									.getData_end_date().split("\\.")[0]
									.toString().compareTo(
											dformat.format(
													this.data_end_date)
													.toString()) == 0
							
							&& listofConfigurations.get(k)
									.getRelease_status()
									.compareTo(this.releaseStatus) == 0
							&& listofConfigurations.get(k).getSn()
											.compareTo(this.sn) != 0) {
						displayErrorMessageToUser(
								"Duplicate main batch cycle with Batch No: "
										+ listofConfigurations.get(k)
												.getRelease_number()
										+ " . Please try again.",
								"Duplicate Cycle");

						return;
					}
					if(listofConfigurations.get(k).getSn()
							.compareTo(this.sn) != 0){
					if ((dformat.format(this.data_start_date)
								.compareTo(
										listofConfigurations.get(k)
												.getData_start_date()
												.split("\\.")[0]) > 0 && dformat
								.format(this.data_start_date).compareTo(
										listofConfigurations.get(k)
												.getData_end_date()
												.split("\\.")[0]) < 0)
								|| (dformat
										.format(this.data_end_date)
										.compareTo(
												listofConfigurations
														.get(k)
														.getData_start_date()
														.split("\\.")[0]) > 0 && dformat
										.format(this.data_end_date)
										.compareTo(
												listofConfigurations.get(k)
														.getData_end_date()
														.split("\\.")[0]) < 0)
								|| (dformat
										.format(this.data_start_date)
										.compareTo(
												listofConfigurations
														.get(k)
														.getData_start_date()
														.split("\\.")[0]) < 0 && dformat
										.format(this.data_end_date)
										.compareTo(
												listofConfigurations.get(k)
														.getData_end_date()
														.split("\\.")[0]) > 0)
								|| (dformat
										.format(this.data_start_date)
										.compareTo(
												listofConfigurations
														.get(k)
														.getData_start_date()
														.split("\\.")[0]) < 0 && dformat
										.format(this.data_end_date)
										.compareTo(
												listofConfigurations.get(k)
														.getData_end_date()
														.split("\\.")[0]) > 0)
								|| dformat
										.format(this.data_start_date)
										.compareTo(
												listofConfigurations
														.get(k)
														.getData_start_date()
														.split("\\.")[0]) == 0
								|| dformat.format(this.data_start_date)
										.compareTo(
												listofConfigurations.get(k)
														.getData_end_date()
														.split("\\.")[0]) == 0
								|| dformat
										.format(this.data_end_date)
										.compareTo(
												listofConfigurations
														.get(k)
														.getData_start_date()
														.split("\\.")[0]) == 0
								|| dformat.format(this.data_end_date)
										.compareTo(
												listofConfigurations.get(k)
														.getData_end_date()
														.split("\\.")[0]) == 0) {
							displayErrorMessageToUser(
									"Date is overlapped with Batch No: "
											+ listofConfigurations.get(k)
													.getRelease_number()
											+ " . please try again",
									"Batch Status");
							return;
						}
					

					}

				}
			}


			String query = "Update aip_cycle_master set data_end_date=";
			
				query = query + "TO_DATE('" + dendDate + "','" + dateformat
						+ "')";
			

			query = query + ", UPDATED_DATE=sysdate,REMARKS='"
					+ this.getRemarks().replaceAll("'", "''")
					+ "', UPDATED_BY='" + getUserinfo().getFullname()
					+ "' where sn='" + this.sn + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			String result = db.executeDML(query);
			db.endConnection();
		

			if (result.compareTo("1") == 0) {
				RequestContext.getCurrentInstance().execute(
						"PF('updateCycle').hide();");
				displayInfoMessageToUser("Successfully Updated",
						"Cycle Date Updated");
				handleClientChange();
			} else {
				displayErrorMessageToUser("Update Failed.Please Try again",
						"Failed");
			}

		}

	}

	public void subReleases(ImportReleaseModel cycle) {
		try {
			
			this.data_end_date = null;
			this.batch_name = "";
			this.releaseType = "";
			this.remarks = "";
			
			  SimpleDateFormat dformat = new SimpleDateFormat(
			  "yyyy-MM-dd HH:mm:ss"); 
			 
				
			
			subRelease = true;
			this.setMainRelease(cycle.getRelease_number());
			
			this.setSn(cycle.getSn());

			ConnectDB db = new ConnectDB();
			db.initialize();
			
			
			List<List<String>> dateList = db
					.resultSetToListOfList("SELECT data_end_date FROM AIP_CYCLE_MASTER WHERE sn=(SELECT max(sn) from AIP_CYCLE_MASTER where CLIENTID='"
							+ this.clientid
							+ "'  AND release_number='"
							+ cycle.getRelease_number()
							+ "' )");
			db.endConnection();
			
			if (dateList != null) {
				if (dateList.size() > 1) {
					log.info("Date size "+dateList.size());
					//if(dateList.size()==1){
						log.info("Date size1 "+dateList.get(1).get(0));
						 this.data_start_date = DateUtils.addSeconds(
								  dformat.parse(dateList.get(1).get(0)), 1);
						 setEnd_date(dformat.format(this.data_start_date));
						 setData_start_date(this.data_start_date); 
						  
						  

					}
				} 
			 else {
				displayErrorMessageToUser("Query Execution Failed", "ERROR");
			}
			
		} catch (Exception e) {
			displayErrorMessageToUser("Sub Batch Failed" + e.getMessage(),
					"ERROR");
		}

		RequestContext.getCurrentInstance().execute("PF('addCycle').show();");
	}

	public void addSubRelease() {
		try {
			SimpleDateFormat dformat = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			String subReleasenum = "";
			String existReleaseno = "";

			subReleasenum = this.getMainRelease().replace(".S0", "");

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> existing_release_List = db
					.resultSetToListOfList("SELECT subReleasenumber FROM AIP_CYCLE_MASTER WHERE CLIENTID='"
							+ this.clientid
							+ "' AND subReleasenumber is not null AND subReleasenumber LIKE '%"
							+ subReleasenum
							+ "%' ORDER BY   sn asc");
			db.endConnection();
			log.info("Sub relea: "
					+ existing_release_List.get(0).get(0));
			if (existing_release_List.size() > 1) {
				existReleaseno = existing_release_List.get(
						existing_release_List.size() - 1).get(0);
				if (subReleasenum.compareTo(existReleaseno) == 0) {
					subReleasenum += ".S1";
				} else {
					if (existReleaseno.contains(".S")) {
						String lastTwoString = existReleaseno.split("\\.")[3]
								.replace("S", "");
						log.info("Last Two String " + lastTwoString);
						int increment = Integer.parseInt(lastTwoString);
						increment++;
						log.info(" after increment " + increment);
						subReleasenum = existReleaseno.toString().split("\\.S")[0]
								+ ".S" + increment;
						log.info("Sub Batch no: " + subReleasenum);

					}
				}

			} else {
				subReleasenum += ".S1";
			}
			log.info("Sub Batch no" + subReleasenum);
			if (this.releaseType.compareTo("releasetype") == 0) {
				displayErrorMessageToUser(
						"Batch type could not be empty.Please Try again",
						"Batch Status");
				return;
			}
			
		
				this.sn = "";
				String dstartDate = "";
				String dendDate="";
				String dateformat = "yyyy.MM.dd hh24:mi:ss";
				log.info("abc");
				if (subReleasenum == "") {
					displayErrorMessageToUser(
							"Error creating Sub Batch no.Please Try again",
							"Sub Batch Status");
					return;
				}

				if (this.data_start_date != null) {
					dstartDate = dformat.format(this.data_start_date);
				} else {
					displayErrorMessageToUser(
							"Process Start Date Could not be Empty.Please Try again",
							"Cycle Date Status");
					return;
				}
				if(this.data_end_date!=null){
					/*this.data_end_date = DateUtils.addHours((this.data_end_date), 23);
					this.data_end_date = DateUtils.addMinutes((this.data_end_date), 59);
					this.data_end_date = DateUtils.addSeconds((this.data_end_date), 59);*/
					dendDate=dformat.format(this.data_end_date);
				}else{
					displayErrorMessageToUser(
							"Process End Date Could not be Empty.Please Try again",
							"Cycle Date Status");
					return;
					/*this.data_end_date = Calendar.getInstance().getTime();
					log.info("Sub Default Date end date: "
						+ this.data_end_date);
					dendDate=dformat.format(this.data_end_date);*/
					
				}
				log.info("Client is: " + this.clientid);
				log.info("end date: " + this.data_end_date);
				if (dformat.format(this.data_end_date).compareTo(
						dformat.format(this.data_start_date)) < 0) {
					displayErrorMessageToUser(
							"Process End Date is before the Process Start Date. Please try again",
							"Batch Status");
					return;
				}
				
				String query = "Insert into aip_cycle_master(CLIENTID, DATA_START_DATE, DATA_END_DATE,REMARKS,release_number,subReleasenumber,RELEASETYPE, "
						+ "CREATED_BY, CREATED_DATE) values "
						+ "('"
						+ this.clientid + "'";

				query = query + ",TO_DATE('" + dstartDate + "','" + dateformat
						+ "')";
				query = query + ",TO_DATE('"
							+ dendDate + "','"
							+ dateformat + "')";
				query = query + ",'"
						+ this.remarks.replace("'", "''") + "','"
						+ this.getMainRelease() + "','" + subReleasenum
						+ "','Sub Batch','"
						+ this.getUserinfo().getFullname() + "',sysdate)";
				int index = this.listofConfigurations.size();
				if (index > 0 ) {
					log.info("Index " + index);
					for (int k = 0; k < index; k++) {

						
						if (listofConfigurations.get(k).getData_start_date()
								.split("\\.")[0].toString()
								.compareTo(
										dformat.format(this.data_start_date)
												.toString()) == 0
								&& listofConfigurations.get(k)
										.getData_end_date().split("\\.")[0]
										.toString().compareTo(
												dformat.format(
														this.data_end_date)
														.toString()) == 0
								
								&& listofConfigurations.get(k)
										.getRelease_status()
										.compareTo(this.releaseStatus) == 0
								) {
							displayErrorMessageToUser(
									"Duplicate main batch cycle with Batch No: "
											+ listofConfigurations.get(k)
													.getRelease_number()
											+ " . Please try again.",
									"Duplicate Cycle");

							return;
						}
						
							if ((dformat.format(this.data_start_date)
									.compareTo(
											listofConfigurations.get(k)
													.getData_start_date()
													.split("\\.")[0]) > 0 && dformat
									.format(this.data_start_date).compareTo(
											listofConfigurations.get(k)
													.getData_end_date()
													.split("\\.")[0]) < 0)
									|| (dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) > 0 && dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) < 0)
									|| (dformat
											.format(this.data_start_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) < 0 && dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) > 0)
									|| (dformat
											.format(this.data_start_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) < 0 && dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) > 0)
									|| dformat
											.format(this.data_start_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) == 0
									|| dformat.format(this.data_start_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) == 0
									|| dformat
											.format(this.data_end_date)
											.compareTo(
													listofConfigurations
															.get(k)
															.getData_start_date()
															.split("\\.")[0]) == 0
									|| dformat.format(this.data_end_date)
											.compareTo(
													listofConfigurations.get(k)
															.getData_end_date()
															.split("\\.")[0]) == 0) {
								displayErrorMessageToUser(
										"Date is overlapped with Batch No: "
												+ listofConfigurations.get(k)
														.getRelease_number()
												+ " . please try again",
										"Batch Status");
								return;
							}
						

						

					}
				}

				
				
				
				ConnectDB db1 = new ConnectDB();
				db1.initialize();
				String status=db1.executeDML(query);
				if (status.compareTo("1") == 0) {
					RequestContext.getCurrentInstance().execute(
							"PF('addCycle').hide();");
					displayInfoMessageToUser("Successfully added Sub Batch ",
							"Sub Batch Cycle");

					handleClientChange();

				} else {
					displayErrorMessageToUser(
							"Sub Batch Addition Failed.Please Try again",
							"Failed");
				}
			

		} catch (Exception e) {
			displayErrorMessageToUser(
					"Failed to Add Sub Batch Cycle.Please try again! "
							+ e.getMessage(), "Sub Batch Status");
		}

	}


	public void reset() {
		this.sn = "";
		this.data_start_date = null;
		this.data_end_date = null;
		this.batch_name = "";
		this.release_number = "";
		this.releaseType = "";
		this.remarks = "";
		this.subRelease = false;
		this.releaseStatus="";
	}

	public String getReleaseType() {
		return releaseType;
	}

	public void setReleaseType(String releaseType) {
		this.releaseType = releaseType;
	}

	

	public String getReleaseDetails() {
		return releaseDetails;
	}

	public void setReleaseDetails(String releaseDetails) {
		this.releaseDetails = releaseDetails;
	}

	

	public void setChanged() {
		this.setValueChanged(true);
	}

	

	public boolean isSubRelease() {
		return subRelease;
	}

	public void setSubRelease(boolean subRelease) {
		this.subRelease = subRelease;
	}

	public String getMainRelease() {
		return mainRelease;
	}

	public void setMainRelease(String mainRelease) {
		this.mainRelease = mainRelease;
	}

	public void downloadReport(ImportReleaseModel cycleModel)
			throws ParseException, InterruptedException {
		String prevreleasenum="";
		String mainReleaseNo="";
		log.info("generating Batch report");
		CustomUtility obj = new CustomUtility();

		SimpleDateFormat dformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String created_date = obj.getDateForReport().toString();
	
		InventoryReportController r = new InventoryReportController();

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> releaseList = db
				.resultSetToListOfList("SELECT RELEASE_NUMBER FROM AIP_CYCLE_MASTER WHERE  NVL(SUBRELEASENUMBER,RELEASE_NUMBER)='"+cycleModel.getRelease_number()+"' and CLIENTID='"
						+ clientid
						+ "'");
		if (releaseList != null) {
			if (releaseList.size() > 1) {
				mainReleaseNo=releaseList.get(1).get(0);
			}
		}
		List<List<String>> revreleaseList = db
				.resultSetToListOfList("SELECT release_number FROM AIP_CYCLE_MASTER WHERE release_number = ( "
		        +" SELECT release_NUMBER FROM aip_cycle_master WHERE  sn  =( "
		        +" SELECT Max(sn) FROM   aip_cycle_master WHERE CLIENTID='"+clientid+"' and  SUBRELEASENUMBER IS NULL AND sn  < ( "
		        +" SELECT sn FROM  aip_cycle_master  a WHERE RELEASE_NUMBER ='"+mainReleaseNo+"' and  SUBRELEASENUMBER IS NULL ))) ");
		
		if (revreleaseList != null) {
			if (revreleaseList.size() > 1) {
				
				prevreleasenum=revreleaseList.get(1).get(0);
				
			}
		}
		db.endConnection();
		
		
			r.processReleaseReport(clientid, cycleModel.getRelease_number(),
					dformat.parse(cycleModel.getData_start_date()),
					dformat.parse(cycleModel.getData_end_date()),
					cycleModel.getRelease_status(),
					cycleModel.getCreated_by(), created_date,mainReleaseNo,prevreleasenum);
			log.info("---Batch REPORT COMPLETE--"
					+ cycleModel.getRelease_number());

			FileController objFC = new FileController(
					AIConstant.RELEASE_REPORT_PATH
							+ cycleModel.getRelease_number() + ".xlsx");
			log.info("File name " + AIConstant.RELEASE_REPORT_PATH
					+ cycleModel.getRelease_number() + ".xlsx");
			setDownloadReleaseReport(objFC.getDownload());
		
		
		

	}


	public String getReleaseStatus() {
		return releaseStatus;
	}

	public void setReleaseStatus(String releaseStatus) {
		this.releaseStatus = releaseStatus;
	}

	public void deleteCycle(ImportReleaseModel cycleModel) {
		this.release_number = cycleModel.getRelease_number();
		this.sn = cycleModel.getSn();
		if (this.release_number != null) {
			RequestContext.getCurrentInstance().execute(
					"PF('deleteCycle').show()");
		}
	}

	public void deleteReleaseCycle(String releaseno, String sn) {
		try {

			log.info("Delet re" + releaseno);
			log.info("Delet sn" + sn);
			ConnectDB db = new ConnectDB();
			db.initialize();
			String Detail_result = db
					.executeDML("Delete from AIP_CYCLE_MASTER where NVL(subReleasenumber,RELEASE_NUMBER)='"
								+ releaseno + "'");
			db.endConnection();
			
			if (Detail_result.compareTo("1") == 0) {
				displayInfoMessageToUser(
						" Cycle Deleted having Data Batch " + releaseno,
						"Batch Status");
				handleClientChange();
				RequestContext.getCurrentInstance().execute(
						"PF('deleteCycle').hide()");
			} else {
				displayErrorMessageToUser(
						"Failed to delete. Please try again.", "Batch Status");
				return;
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Failed to delete. Please try again." + e.getMessage(),
					"Batch Status");
		}
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

}
