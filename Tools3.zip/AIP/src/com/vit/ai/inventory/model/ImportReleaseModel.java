/*
 *Class Name : ClientConfigurationModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.model;

/**
 * @author Binesh Sah
 *
 * @version 1.0 2015/05/18
 */
public class ImportReleaseModel {

	private String sn;
	private String clientid;
	private String cycle_start_date;
	private String cycle_end_date;
	private String data_start_date;
	private String data_end_date;
	private String batch_name;
	private String release_number;
	private String created_by;
	private String updated_by;
	private String releaseStartDate;

	private String remarks;
	private String prevSn;
	private String release_status;
	private String prevReleasenum;
	private String fileCount;
	

	public String getFileCount() {
		return fileCount;
	}

	public void setFileCount(String fileCount) {
		this.fileCount = fileCount;
	}

	public String getReleaseStartDate() {
		return releaseStartDate;
	}

	public String getRelease_status() {
		return release_status;
	}

	public void setRelease_status(String release_status) {
		this.release_status = release_status;
	}

	public void setReleaseStartDate(String releaseStartDate) {
		this.releaseStartDate = releaseStartDate;
	}


	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getCycle_start_date() {
		return cycle_start_date;
	}

	public void setCycle_start_date(String cycle_start_date) {
		this.cycle_start_date = cycle_start_date;
	}

	public String getCycle_end_date() {
		return cycle_end_date;
	}

	public void setCycle_end_date(String cycle_end_date) {
		this.cycle_end_date = cycle_end_date;
	}

	public String getData_start_date() {
		return data_start_date;
	}

	public void setData_start_date(String data_start_date) {
		this.data_start_date = data_start_date;
	}

	public String getData_end_date() {
		return data_end_date;
	}

	public void setData_end_date(String data_end_date) {
		this.data_end_date = data_end_date;
	}

	public String getBatch_name() {
		return batch_name;
	}

	public void setBatch_name(String batch_name) {
		this.batch_name = batch_name;
	}

	public String getRelease_number() {
		return release_number;
	}

	public void setRelease_number(String release_number) {
		this.release_number = release_number;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public ImportReleaseModel(String clientid,
			String datastartdate, String dataenddate,String prevReleaseno ,String releasenumber,
			String releasestartdate, String remarks, String createdby,String prevsn,String sn,String releasestatus,String filecount) {
		
		this.clientid = clientid;
		this.data_start_date = datastartdate;
		this.data_end_date = dataenddate;
		this.prevReleasenum=prevReleaseno;
		this.release_number = releasenumber;
		this.releaseStartDate=releasestartdate;
		this.remarks=remarks;
		this.created_by = createdby;
		this.prevSn=prevsn;
		this.sn = sn;
		this.release_status=releasestatus;
		this.fileCount=filecount;
		

	}

	public ImportReleaseModel() {
	}

	/**
	 * @return the sn
	 */
	public String getSn() {
		return sn;
	}

	/**
	 * @param sn
	 *            the sn to set
	 */
	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getPrevSn() {
		return prevSn;
	}

	public void setPrevSn(String prevSn) {
		this.prevSn = prevSn;
	}

	public String getPrevReleasenum() {
		return prevReleasenum;
	}

	public void setPrevReleasenum(String prevReleasenum) {
		this.prevReleasenum = prevReleasenum;
	}

	


}
