/* 
 *Class Name : MainLog.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @author Binesh Sah
 * 
 * @author Anish Rauniyar
 * 
 * @version 1.2 07 Jul 2014
 */
public class MainLog implements Serializable {

	private static final long serialVersionUID = -237778625535849118L;
	private String variance;
	private String exceptionflag;
	private String prevfileID;
	private String duplicateflag;
	private String fileID;
	private String dmFileID;
	private String fileName;
	private String clientID;
	private String layoutID;
	private String dataType;
	private String fileSize;
	private String fileDate;
	private String timeStamp;
	private String fileHashKey;
	private String fileRecordCnt;
	private String importRecordCnt;
	private String transferdetail;
	private String remark;
	private String sn;
	private String prevhiservername;
	private String prevhischemaname;
	int privatesn;
	private String processDate;

	private String processStatus;
	private String emailStatus;
	private String cuttingFloor;
	private String processType;
	private String prevDmfileID;

	private String processTypeDetail;
	private String colorcode;
	private String servername;
	private String empgrp;
	private String hiservername;
	private String hischemaname;
	private String hitablename;
	private String whereclause;
	private String type;
	private String count;
	private String fileDeleteStatus="";

	

	private String empName;
	private String aiTableName;
	private String hierrMSG;
	private String hiStatus;
	private String hiStartTime;
	private String hiEndTime;
	private String transferType;
	private String aipRecord;
	private String hiRecord;
	private String uniqueRecordsHash;
	private String dupRecordCnt;
	private String statusOfImport;
	private String fullPath;
	private String getStat;
	private String startTime;
	private String endTime;
	private String transferStatus;
	private String processFilePath;
	private String importServer;
	private String releaseNo;
	private ArrayList<String> sublayoutid, aischemaname, aitablename,
			filerecordcount, recordcount;
	private String info;
	private boolean showLog=false;	
	public String dpstatus;
	private String approvedby="";
	private String approveddate="";
	private String errorCategory;
	private String errorResponsible;
	private String appId;
	private String releaseTag;	
	
	private boolean showEDILog=false;
	
	
 	
	public boolean isShowEDILog() {
		return showEDILog;
	}

	public void setShowEDILog(boolean showEDILog) {
		this.showEDILog = showEDILog;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	public String getDpstatus() {
		return dpstatus;
	}

	public void setDpstatus(String dpstatus) {
		this.dpstatus = dpstatus;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getExceptionDetails() {
		return exceptionDetails;
	}

	public void setExceptionDetails(String exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}

	public String getExceptionRemarks() {
		return exceptionRemarks;
	}

	public void setExceptionRemarks(String exceptionRemarks) {
		this.exceptionRemarks = exceptionRemarks;
	}

	public String getRetransferDetails() {
		return retransferDetails;
	}

	public void setRetransferDetails(String retransferDetails) {
		this.retransferDetails = retransferDetails;
	}

	private String exceptionDetails;
	private String exceptionRemarks;
	private String retransferDetails;

	public String getExceptionflag() {
		return exceptionflag;
	}

	public void setExceptionflag(String exceptionflag) {
		this.exceptionflag = exceptionflag;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getPrevhiservername() {
		return prevhiservername;
	}

	public void setPrevhiservername(String prevhiservername) {
		this.prevhiservername = prevhiservername;
	}

	public String getPrevhischemaname() {
		return prevhischemaname;
	}

	public void setPrevhischemaname(String prevhischemaname) {
		this.prevhischemaname = prevhischemaname;
	}

	public int getPrivatesn() {
		return privatesn;
	}

	public void setPrivatesn(int privatesn) {
		this.privatesn = privatesn;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	private String payor;

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getImportServer() {
		return importServer;
	}

	public void setImportServer(String importServer) {
		this.importServer = importServer;
	}

	public String getPrevDmfileID() {
		return prevDmfileID;
	}

	public void setPrevDmfileID(String prevDmfileID) {
		this.prevDmfileID = prevDmfileID;
	}

	public String getEmpgrp() {
		return empgrp;
	}

	public void setEmpgrp(String empgrp) {
		this.empgrp = empgrp;
	}

	public String getHiservername() {
		return hiservername;
	}

	public void setHiservername(String hiservername) {
		this.hiservername = hiservername;
	}

	public String getHischemaname() {
		return hischemaname;
	}

	public void setHischemaname(String hischemaname) {
		this.hischemaname = hischemaname;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getAiTableName() {
		return aiTableName;
	}

	public void setAiTableName(String aiTableName) {
		this.aiTableName = aiTableName;
	}

	public String getHierrMSG() {
		return hierrMSG;
	}

	public void setHierrMSG(String hierrMSG) {
		this.hierrMSG = hierrMSG;
	}

	public String getHiStatus() {
		return hiStatus;
	}

	public void setHiStatus(String hiStatus) {
		this.hiStatus = hiStatus;
	}

	public String getHiStartTime() {
		return hiStartTime;
	}

	public void setHiStartTime(String hiStartTime) {
		this.hiStartTime = hiStartTime;
	}

	public String getHiEndTime() {
		return hiEndTime;
	}

	public void setHiEndTime(String hiEndTime) {
		this.hiEndTime = hiEndTime;
	}

	public String getTransferType() {
		return transferType;
	}

	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	public String getAipRecord() {
		return aipRecord;
	}

	public void setAipRecord(String aipRecord) {
		this.aipRecord = aipRecord;
	}

	public String getHiRecord() {
		return hiRecord;
	}

	public void setHiRecord(String hiRecord) {
		this.hiRecord = hiRecord;
	}

	public String getHitablename() {
		return hitablename;
	}

	public void setHitablename(String hitablename) {
		this.hitablename = hitablename;
	}

	public String getWhereclause() {
		return whereclause;
	}

	public void setWhereclause(String whereclause) {
		this.whereclause = whereclause;
	}

	public ArrayList<String> getSublayoutid() {
		return sublayoutid;
	}

	public void setSublayoutid(ArrayList<String> sublayoutid) {
		this.sublayoutid = sublayoutid;
	}

	public ArrayList<String> getAischemaname() {
		return aischemaname;
	}

	public void setAischemaname(ArrayList<String> aischemaname) {
		this.aischemaname = aischemaname;
	}

	public ArrayList<String> getAitablename() {
		return aitablename;
	}

	public void setAitablename(ArrayList<String> aitablename) {
		this.aitablename = aitablename;
	}

	public ArrayList<String> getRecordcount() {
		return recordcount;
	}

	public void setRecordcount(ArrayList<String> recordcount) {
		this.recordcount = recordcount;
	}

	public String getFileID() {
		return fileID;
	}

	public void setFileID(String fileID) {
		this.fileID = fileID;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileDate() {
		return fileDate;
	}

	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getFileHashKey() {
		return fileHashKey;
	}

	public void setFileHashKey(String fileHashKey) {
		this.fileHashKey = fileHashKey;
	}

	public String getFileRecordCnt() {
		return fileRecordCnt;
	}

	public void setFileRecordCnt(String fileRecordCnt) {
		this.fileRecordCnt = fileRecordCnt;
	}

	public String getImportRecordCnt() {
		return importRecordCnt;
	}

	public void setImportRecordCnt(String importRecordCnt) {
		this.importRecordCnt = importRecordCnt;
	}

	public String getUniqueRecordsHash() {
		return uniqueRecordsHash;
	}

	public void setUniqueRecordsHash(String uniqueRecordsHash) {
		this.uniqueRecordsHash = uniqueRecordsHash;
	}

	public String getDupRecordCnt() {
		return dupRecordCnt;
	}

	public void setDupRecordCnt(String dupRecordCnt) {
		this.dupRecordCnt = dupRecordCnt;
	}

	public String getStatusOfImport() {
		return statusOfImport;
	}

	public void setStatusOfImport(String statusOfImport) {
		this.statusOfImport = statusOfImport;
	}

	public String getFullPath() {
		return fullPath;
	}

	public void setFullPath(String fullPath) {
		this.fullPath = fullPath;
	}

	public String getGetStat() {
		return getStat;
	}

	public void setGetStat(String getStat) {
		this.getStat = getStat;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getTransferStatus() {
		return transferStatus;
	}

	public void setTransferStatus(String transferStatus) {
		this.transferStatus = transferStatus;
	}

	public String getProcessFilePath() {
		return processFilePath;
	}

	public void setProcessFilePath(String processFilePath) {
		this.processFilePath = processFilePath;
	}

	public String getProcessStatus() {
		return processStatus;
	}

	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	public String getEmailStatus() {
		return emailStatus;
	}

	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}

	public String getCuttingFloor() {
		return cuttingFloor;
	}

	public void setCuttingFloor(String cuttingFloor) {
		this.cuttingFloor = cuttingFloor;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getProcessTypeDetail() {
		return processTypeDetail;
	}

	public void setProcessTypeDetail(String processTypeDetail) {
		this.processTypeDetail = processTypeDetail;
	}

	public MainLog(String exceptionflag, String dupcount, String prevFileID,
			String fileID, String fileName, String clientID, String layoutID,
			String dataType, String fileSize, String fileDate,
			String timeStamp, String fileHashKey, String fileRecordCnt,
			String importRecordCnt, String uniqueRecordsHash,
			String dupRecordCnt, String statusOfImport, String fullPath,
			String getStat, String startTime, String endTime,
			String transferStatus, String dmFileID, String processFilePath,
			String processStatus, String emailStatus, String cuttingFloor,
			String processType, String processDetail, String importServer,
			String payor, String remark, String empgrp,String releaseno,String dpstatus,String approvedby,String approveddate,String errorCategory,String errorResponsible,String processDate) {
		this.prevfileID = prevFileID;
		this.exceptionflag = exceptionflag;
		this.duplicateflag = dupcount;
		this.fileID = fileID;
		this.fileName = fileName;
		this.clientID = clientID;
		this.layoutID = layoutID;
		this.dataType = dataType;
		this.fileSize = fileSize;
		this.fileDate = fileDate;
		this.timeStamp = timeStamp;
		this.fileHashKey = fileHashKey;
		this.fileRecordCnt = fileRecordCnt;
		this.importRecordCnt = importRecordCnt;
		this.uniqueRecordsHash = uniqueRecordsHash;
		this.dupRecordCnt = dupRecordCnt;
		this.statusOfImport = statusOfImport;
		this.fullPath = fullPath;
		this.getStat = getStat;
		this.startTime = startTime;
		this.endTime = endTime;
		this.transferStatus = transferStatus;
		this.dmFileID = dmFileID;
		this.processFilePath = processFilePath;
		this.processStatus = processStatus;
		this.emailStatus = emailStatus;
		this.cuttingFloor = cuttingFloor;
		this.processType = processType;
		this.processTypeDetail = processDetail;
		this.importServer = importServer;
		this.payor = payor;
		this.remark = remark;
		this.empgrp = empgrp;
		this.releaseNo=releaseno;
		this.dpstatus=dpstatus;
		this.approvedby=approvedby;
		this.approveddate=approveddate;
		this.errorCategory=errorCategory;
		this.errorResponsible=errorResponsible;
		this.processDate=processDate;

		if(this.processStatus.compareTo("EXCEPTIONS")==0 && this.statusOfImport.contains("ORA-"))
		{
			this.showLog=true;
		}
		else
		{
			this.showLog=false;
		}
		
		if (this.processStatus.equals("ERROR : CONVERSION FROM EDI TO CDF FAILED.")) {
			this.showEDILog = true;
		} else {
			this.showEDILog = false;
		}
		
		setMainDetails();
	}

	public void setMainDetails() {
		String query = "select sublayoutid,  AISCHEMANAME,AITABLENAME, FILERECORDCOUNT, RECORDCOUNT from imp_main_det_log where fileid='"
				+ this.fileID + "_" + this.dmFileID + "'";
		this.sublayoutid = new ArrayList<String>();
		this.aischemaname = new ArrayList<String>();
		this.aitablename = new ArrayList<String>();
		this.filerecordcount = new ArrayList<String>();
		this.recordcount = new ArrayList<String>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		if (rs.size() > 0) {
			for (int i = 1; i < rs.size(); i++) {
				this.sublayoutid.add(rs.get(i).get(0));
				this.aischemaname.add(rs.get(i).get(1));
				this.aitablename.add(rs.get(i).get(2));
				this.filerecordcount.add(rs.get(i).get(3));
				this.recordcount.add(rs.get(i).get(4));
			}
		}
		db.endConnection();
	}

	public MainLog(int privatesn, String prevfileID, String fileID,
			String fileName, String Payor, String clientID, String layoutID,
			String dataType, String fileSize, String fileDate,
			String timeStamp, String fileHashKey, String fileRecordCnt,
			String importRecordCnt, String uniqueRecordsHash,
			String dupRecordCnt, String statusOfImport, String fullPath,
			String getStat, String startTime, String endTime,
			String transferStatus, String prevdmfileID, String dmFileID,
			String processFilePath, String processStatus, String emailStatus,
			String cuttingFloor, String processType, String processDetail,
			String servername, String empgrp, String aiTableName,
			String prevservername, String hiservername,
			String prevshichemaname, String hischemaname, String hitablename,
			String whereclause, String sn, String transferdetail,String releaseno,String processDate,String delete_status) {
		this.privatesn = privatesn;
		this.prevfileID = prevfileID;
		this.fileID = fileID;
		this.fileName = fileName;
		this.clientID = clientID;
		this.layoutID = layoutID;
		this.dataType = dataType;
		this.payor = Payor;
		this.fileSize = fileSize;
		this.fileDate = fileDate;
		this.timeStamp = timeStamp;

		this.fileHashKey = fileHashKey;
		this.fileRecordCnt = fileRecordCnt;
		this.importRecordCnt = importRecordCnt;
		this.uniqueRecordsHash = uniqueRecordsHash;
		this.dupRecordCnt = dupRecordCnt;
		this.statusOfImport = statusOfImport;
		this.fullPath = fullPath;
		this.getStat = getStat;
		this.startTime = startTime;
		this.endTime = endTime;
		this.transferStatus = transferStatus;
		this.prevDmfileID = prevdmfileID;
		this.dmFileID = dmFileID;
		this.processFilePath = processFilePath;
		this.processStatus = processStatus;
		this.emailStatus = emailStatus;
		this.cuttingFloor = cuttingFloor;
		this.processType = processType;
		this.processTypeDetail = processDetail;
		this.servername = servername;
		this.empgrp = empgrp;
		this.aiTableName = aiTableName;
		this.prevhiservername = prevservername;
		this.hiservername = hiservername;
		this.prevhischemaname = prevshichemaname;
		this.hischemaname = hischemaname;
		this.hitablename = hitablename;
		this.whereclause = whereclause;
		this.sn = sn;
		this.transferdetail = transferdetail;
		this.releaseNo=releaseno;
		this.processDate=processDate;
		this.fileDeleteStatus = delete_status;

	}
	

	public MainLog(String prevfileID, String fileID, String prevDmfileID,
			String dmfileID, String layoutID, String employerName,
			String aiTableName, String hiSchemaName, String hiTableName,
			String aipRecord, String hiRecord, String transferType,
			String hiStatus, String hierrMSG, String hiStartTime,
			String hiEndTime, String payor, String datatype, String filename) {
		this.prevfileID = prevfileID;
		this.fileID = fileID;
		this.prevDmfileID = prevDmfileID;
		this.dmFileID = dmfileID;
		this.layoutID = layoutID;
		this.empName = employerName;
		this.aiTableName = aiTableName;
		this.hischemaname = hiSchemaName;
		this.hitablename = hiTableName;
		this.aipRecord = aipRecord;
		this.hiRecord = hiRecord;
		this.transferType = transferType;
		this.hiStatus = hiStatus;
		this.hierrMSG = hierrMSG;
		this.hiStartTime = hiStartTime;
		this.hiEndTime = hiEndTime;
		this.payor = payor;
		this.dataType = datatype;
		this.fileName = filename;

	}

	public MainLog(int privatesn,String type, String prevfileID, String fileID,String count,String prevdmfileID,String dmfileID,
			String fileName,String clientID, String layoutID,
			String dataType, String fileSize, String fileDate,
			String fileRecordCnt,String transferReccount,
			String importRecordCnt,String varience,String statusOfImport, String processStatus,
			String importServer,
			String info13, String exceptionDetails, String empGroup,
			
			
			
			String exceptionRemark, String payor, String aiTableName,
			String hiSchema, String hiTableName,
			String transferStatus, String retransferDetail,
			String wherecondition,String processDate) {
		
		this.privatesn=privatesn;
		this.type=type;
		this.prevfileID=prevfileID;
		this.fileID=fileID;
		this.count=count;
		this.prevDmfileID=prevdmfileID;
		this.dmFileID=dmfileID;
		this.fileName=fileName;
		this.clientID=clientID;
		this.layoutID=layoutID;
		this.dataType=dataType;
		this.fileSize=fileSize;
		this.fileDate=fileDate;
		this.fileRecordCnt=fileRecordCnt;
		this.hiRecord=transferReccount;
		this.importRecordCnt=importRecordCnt;
		this.setVariance(varience);
		this.statusOfImport=statusOfImport;
		this.processStatus=processStatus;
		this.importServer=importServer;
		this.info=info13;
		this.exceptionDetails=exceptionDetails;
		this.empgrp=empGroup;
		this.exceptionRemarks=exceptionRemark;
		this.payor=payor;
		this.aiTableName=aiTableName;
		this.hischemaname=hiSchema;
		this.hitablename=hiTableName;
		this.transferStatus=transferStatus;
		this.retransferDetails=retransferDetail;
		this.whereclause=wherecondition;
		this.processDate=processDate;
		
		
		
	}	public MainLog() {

	}

	public String getDmFileID() {
		return dmFileID;
	}

	public void setDmFileID(String dmFileID) {
		this.dmFileID = dmFileID;
	}

	public String getDuplicateflag() {
		return duplicateflag;
	}

	public void setDuplicateflag(String duplicateflag) {
		this.duplicateflag = duplicateflag;
	}

	public String getColorcode() {
		return colorcode;
	}

	public void setColorcode(String colorcode) {
		this.colorcode = colorcode;
	}

	public ArrayList<String> getFilerecordcount() {
		return filerecordcount;
	}

	public void setFilerecordcount(ArrayList<String> filerecordcount) {
		this.filerecordcount = filerecordcount;
	}

	public String getServername() {
		return servername;
	}

	public void setServername(String servername) {
		this.servername = servername;
	}

	public String getPrevfileID() {
		return prevfileID;
	}

	public void setPrevfileID(String prevfileID) {
		this.prevfileID = prevfileID;
	}

	public String getTransferdetail() {
		return transferdetail;
	}

	public void setTransferdetail(String transferdetail) {
		this.transferdetail = transferdetail;
	}
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getVariance() {
		return variance;
	}

	public void setVariance(String variance) {
		this.variance = variance;
	}

	public String getReleaseNo() {
		return releaseNo;
	}

	public void setReleaseNo(String releaseNo) {
		this.releaseNo = releaseNo;
	}

	public boolean isShowLog() {
		return showLog;
	}

	public void setShowLog(boolean showLog) {
		this.showLog = showLog;
	}

	public String getApproveddate() {
		return approveddate;
	}

	public void setApproveddate(String approveddate) {
		this.approveddate = approveddate;
	}

	public String getApprovedby() {
		return approvedby;
	}

	public void setApprovedby(String approvedby) {
		this.approvedby = approvedby;
	}

	public String getErrorCategory() {
		return errorCategory;
	}

	public void setErrorCategory(String errorCategory) {
		this.errorCategory = errorCategory;
	}

	public String getErrorResponsible() {
		return errorResponsible;
	}

	public void setErrorResponsible(String errorResponsible) {
		this.errorResponsible = errorResponsible;
	}
	
	public String getMergedFileId()
	{
		return this.fileID+"_"+this.dmFileID;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getFileDeleteStatus() {
		return fileDeleteStatus;
	}

	public void setFileDeleteStatus(String fileDeleteStatus) {
		this.fileDeleteStatus = fileDeleteStatus;
	}

}
