/*
 *Class Name : InventoryLog.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.inventory.model;

/**
 * Model Class for Inventory Log
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 21 March 2015
 */
public class InventoryLog {

	private String clientid;
	private String startDate;
	private String endDate;
	private String fileidlist;
	private String processstartdate;
	private String processenddate;
	private String releaseno;
	private String fileIDList;
	private String mdrInput;

	public String getProcessstartdate() {
		return processstartdate;
	}

	public void setProcessstartdate(String processstartdate) {
		this.processstartdate = processstartdate;
	}

	public String getProcessenddate() {
		return processenddate;
	}

	public void setProcessenddate(String processenddate) {
		this.processenddate = processenddate;
	}

	public String getClientid() {
		return clientid;
	}

	public String getFileidlist() {
		return fileidlist;
	}

	public void setFileidlist(String fileidlist) {
		this.fileidlist = fileidlist;
	}

	public String getReporttype() {
		return reporttype;
	}

	public void setReporttype(String reporttype) {
		this.reporttype = reporttype;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	private String username;
	private String reportID;

	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	public String getCreateddate() {
		return createddate;
	}

	public void setCreateddate(String createddate) {
		this.createddate = createddate;
	}

	public String getRunstatus() {
		return runstatus;
	}

	public void setRunstatus(String runstatus) {
		this.runstatus = runstatus;
	}

	private String createdby;
	private String createddate;
	private String runstatus;
	private String reportName;
	private String reporttype = "";

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public InventoryLog(String reportID, String reportname, String createdby,
			String createddate, String runstatus, String clientid,
			String startdate, String enddate, String reporttype, String fileid,
			String processstartdate, String processenddate,String releaseno,String filelist,String mdrinput) {
		super();
		this.reportID = reportID;
		this.reportName = reportname;
		this.createdby = createdby;
		this.createddate = createddate;
		this.runstatus = runstatus;
		this.clientid = clientid;
		this.startDate = startdate;
		this.endDate = enddate;
		this.reporttype = reporttype;
		this.fileidlist = fileid;
		this.processstartdate = processstartdate;
		this.processenddate = processenddate;
		this.releaseno=releaseno;
		this.fileIDList=filelist;
		this.mdrInput=mdrinput;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getReleaseno() {
		return releaseno;
	}

	public void setReleaseno(String releaseno) {
		this.releaseno = releaseno;
	}

	public String getFileIDList() {
		return fileIDList;
	}

	public void setFileIDList(String fileIDList) {
		this.fileIDList = fileIDList;
	}

	public String getMdrInput() {
		return mdrInput;
	}

	public void setMdrInput(String mdrInput) {
		this.mdrInput = mdrInput;
	}

}
