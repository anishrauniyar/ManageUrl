package com.vit.ai.inventory.model;

/**
 * @author Aashish Dhungana
 * 
 * Model Class for Pending Inventory
 */
public class PipeLineModel {

	private String clientid;
	private String dmfileid;
	private String filename;
	private String filetype;
	private String fileRecievedDate;
	private String fileSize;
	private String payer;
	private String empGroup;
	private String layoutid;
	private String pattern;
	private String importStartTime;
	private String eigerTrasnferDate;
	private String checkSum;
	private String mappedOnDate;
	private String fullFilePath;
	private String status;
	public String getClientid() {
		return clientid;
	}
	public void setClientid(String clientid) {
		this.clientid = clientid;
	}
	public String getDmfileid() {
		return dmfileid;
	}
	public void setDmfileid(String dmfileid) {
		this.dmfileid = dmfileid;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public String getFileRecievedDate() {
		return fileRecievedDate;
	}
	public void setFileRecievedDate(String fileRecievedDate) {
		this.fileRecievedDate = fileRecievedDate;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getPayer() {
		return payer;
	}
	public void setPayer(String payer) {
		this.payer = payer;
	}
	public String getEmpGroup() {
		return empGroup;
	}
	public void setEmpGroup(String empGroup) {
		this.empGroup = empGroup;
	}
	public String getLayoutid() {
		return layoutid;
	}
	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	public String getImportStartTime() {
		return importStartTime;
	}
	public void setImportStartTime(String importStartTime) {
		this.importStartTime = importStartTime;
	}
	public String getEigerTrasnferDate() {
		return eigerTrasnferDate;
	}
	public void setEigerTrasnferDate(String eigerTrasnferDate) {
		this.eigerTrasnferDate = eigerTrasnferDate;
	}
	public String getCheckSum() {
		return checkSum;
	}
	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}
	public String getMappedOnDate() {
		return mappedOnDate;
	}
	public void setMappedOnDate(String mappedOnDate) {
		this.mappedOnDate = mappedOnDate;
	}
	public String getFullFilePath() {
		return fullFilePath;
	}
	public void setFullFilePath(String fullFilePath) {
		this.fullFilePath = fullFilePath;
	}
	
	public PipeLineModel(String clientid, String dmfileid,
			String filename, String filetype, String fileRecievedDate,
			String fileSize, String payer, String empGroup, String layoutid,
			String pattern,  String eigerTrasnferDate,
			String checkSum, String mappedOnDate, String fullFilePath,String status) {
		super();
		this.clientid = clientid;
		this.dmfileid = dmfileid;
		this.filename = filename;
		this.filetype = filetype;
		this.fileRecievedDate = fileRecievedDate;
		this.fileSize = fileSize;
		this.payer = payer;
		this.empGroup = empGroup;
		this.layoutid = layoutid;
		this.pattern = pattern;
	
		this.eigerTrasnferDate = eigerTrasnferDate;
		this.checkSum = checkSum;
		this.mappedOnDate = mappedOnDate;
		this.fullFilePath = fullFilePath;
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
