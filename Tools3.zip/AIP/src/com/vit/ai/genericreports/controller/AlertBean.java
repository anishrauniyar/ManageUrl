/*
 * Class Name : AlertBean.java
 * 
 * Copyright: Verisk Information Technologies
 */

package com.vit.ai.genericreports.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

import com.vit.ai.genericreports.model.ReportModel;
import com.vit.dbconnection.ConnectDB;

/**
 * Managed Bean to handle Alerts View
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 17 Nov 2014
 */
@ManagedBean
@ViewScoped
public class AlertBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(AlertBean.class.getName());
	private String userid;
	private String username;
	private String email;
	private String reportID;
	private String flag;
	private ArrayList<ReportModel> generalReports;
	private ArrayList<ReportModel> clientReports;
	private List<String> selectedclients;
	private ArrayList<String> clients;
	private String selectedReport = "";
	private ArrayList<String> creports;

	public ArrayList<ReportModel> getGeneralReports() {

		return generalReports;
	}

	public void setGeneralReports(ArrayList<ReportModel> generalReports) {
		this.generalReports = generalReports;
	}

	public ArrayList<ReportModel> getClientReports() {
		return clientReports;
	}

	public void setClientReports(ArrayList<ReportModel> clientReports) {
		this.clientReports = clientReports;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
		loadGeneralReports();
		loadClientReports();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReportID() {
		return reportID;
	}

	public void setReportID(String reportID) {
		this.reportID = reportID;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public List<String> getSelectedclients() {
		return selectedclients;
	}

	public void setSelectedclients(List<String> selectedclients) {
		this.selectedclients = selectedclients;
	}

	public ArrayList<String> getClients() {
		return clients;
	}

	public void setClients(ArrayList<String> clients) {
		this.clients = clients;
	}

	public ArrayList<String> getCreports() {
		return creports;
	}

	public void setCreports(ArrayList<String> creports) {
		this.creports = creports;
	}

	public String getSelectedReport() {
		return selectedReport;
	}

	public void setSelectedReport(String selectedReport) {
		this.selectedReport = selectedReport;
	}

	public boolean isreportSelected() {

		if (this.selectedReport.isEmpty() || this.selectedReport == null) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * @param reportname
	 *            Name of the report whose id is to be returned
	 * @return Id for the report name
	 */
	public String getReportid(String reportname) {
		String reportid = "";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db
				.resultSetToListOfList("select reportid from aip_rpt_lst where reportname='"
						+ reportname + "'");
		db.endConnection();
		if (rs.size() > 0) {
			reportid = rs.get(1).get(0);
		}

		return reportid;
	}

	public AlertBean() {

	}

	public void loadClientReports() {

		this.creports = new ArrayList<String>();
		this.clientReports = new ArrayList<ReportModel>();
		String query = " select  listagg(b.clientid,',') WITHin GROUP(ORDER BY  Reportname ) clients,	a.reportid,  	a.reportname, a.reportdesc,"
				+ " nvl(b.subscribe,'N') subscribe   from  	aip_rpt_lst a  left join 	(select * from aip_rpt_subscriber where clientid != '999' and userid='"
				+ this.userid
				+ "' ) b "
				+ "on  a.reportid = b.reportid and userid = '"
				+ this.userid
				+ "' where a.clientflag = 'Y' "
				+ " GROUP BY    	a.reportid,  	a.reportname, a.reportdesc,subscribe ";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		log.info(username + " Query To Load Client Reports: " + query);
		if (rs.size() > 0) {
			for (int i = 1; i < rs.size(); i++) {
				clientReports.add(new ReportModel(rs.get(i).get(0), rs.get(i)
						.get(1), rs.get(i).get(2), rs.get(i).get(3), rs.get(i)
						.get(4)));
				this.creports.add(rs.get(i).get(2));

			}

		}

	}

	public void handleReportSelected() {
		
		if(!this.selectedReport.isEmpty())
		{
			
		
		this.clients = new ArrayList<String>();
		String query = "select a.clientid ||'-('|| clientname || ')' from hawkeyemaster.m_clients a  WHERE NOT EXISTS(SELECT clientid FROM aip_rpt_subscriber WHERE aip_rpt_subscriber.clientid=a.clientid AND aip_rpt_subscriber.userid='"
				+ this.userid
				+ "' and aip_rpt_subscriber.reportid='"
				+ getReportid(this.selectedReport) + "')";
		log.info(username + " Query To Handle Selected Report : " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		if (rs.size() > 0) {
			for (int i = 1; i < rs.size(); i++) {
				this.clients.add(rs.get(i).get(0));
			}
		}
		db.endConnection();
		}
		else
		{
			this.clients.clear();
		}
	}

	public void loadGeneralReports() {
		this.generalReports = new ArrayList<ReportModel>();
		String query = " select  	a.reportid,  	a.reportname, a.reportdesc,	nvl(b.subscribe,'N') subscribe   from  	aip_rpt_lst a  left join 	(select * from aip_rpt_subscriber where clientid = '999' and userid='"
				+ this.userid
				+ "' ) b on "
				+ " a.reportid = b.reportid and userid = '"
				+ this.userid
				+ "' where a.clientflag is null ";

		ConnectDB db = new ConnectDB();
		db.initialize();
		log.info(username + " Query To Load Generic Report: " + query);
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs.size() > 0) {
			// clientid 999 denotes all clients

			for (int i = 1; i < rs.size(); i++) {
				generalReports.add(new ReportModel("999", rs.get(i).get(0), rs
						.get(i).get(1), rs.get(i).get(2), rs.get(i).get(3)));
			}
		}

	}
	public void unsubscribe(String clientid, String userid,String reportid,String reportname) {
		

		String updateStatement = "";
		updateStatement = "delete from aip_rpt_subscriber where reportid = "
				+ reportid + " and userid = '" + userid + "' and clientid = '"
				+ clientid + "'";

		try {
			String message ="";
			ConnectDB db = new ConnectDB();
			db.initialize();
			log.info(" Deleting Subscribed User: " + updateStatement);
			String status=db.executeDML(updateStatement);
			if(status.compareTo("1")==0){
				setUserid(this.userid);
				loadGeneralReports();
				loadClientReports();
				
				 message = reportname + " for client " + clientid
						+ " Unsubscribed";
			}else{
				message=" Failed to Unsubscribe ";
			}
			db.endConnection();
			
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(message));
		} catch (Exception e)
		// No need to handle
		{
			log.error(" Error While Deleting Subscribed User: "
					+ e.getMessage());
		}
	}
	public void updateTable(List<String> clients, String userid, String emailid,String reportid,String reportname) {

		System.out.println("Report ID"+reportid);
		if (clients.isEmpty()) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage("Select Clients First."));
			return;
		}
		int count = 0;
		ConnectDB db = new ConnectDB();
		db.initialize();
		String updateStatement = "";
		for (int i = 0; i < clients.size(); i++) {
			count++;

			updateStatement = "insert into aip_rpt_subscriber(reportid,clientid, userid, emailid, subscribe) values ('"
					+ reportid
					+ "','"
					+ clients.get(i).split("-")[0]
					+ "','"
					+ userid + "','" + emailid + "','Y')";
			log.info("Storing Subscribed User Information: " + updateStatement);
			db.executeDML(updateStatement);
			
		}
		db.endConnection();

		String message = reportname + " : ";
		
		loadClientReports();
		loadGeneralReports();

		message = message + "Subscribed for " + count + "clients";
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(message));

	}

}
