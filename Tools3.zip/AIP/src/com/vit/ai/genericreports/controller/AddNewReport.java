/* 
 *Class Name : AddNewReport.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.genericreports.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.genericreports.model.Parameters;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for adding new user defined reports
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 15 Dec 2014
 */
@ManagedBean
@ViewScoped
public class AddNewReport extends AbstractController implements Serializable {

	static Logger log = Logger.getLogger(AddNewReport.class.getName());
	protected static final long serialVersionUID = -5273473842948130476L;
	protected String reportname;
	protected String sheetname;
	protected String typeOfReport;
	protected String availability;
	protected LinkedHashMap<String, String> aliases = new LinkedHashMap<String, String>();
	protected String genericQuery;
	protected String generatedQuery;
	protected String[] headerMerge;
	protected LinkedHashMap<String, String> parameters = new LinkedHashMap<String, String>();
	protected boolean templateUsed = false;
	protected String templateName = "";
	protected String formula = "";
	protected String customHeader = "";
	protected String reportDesc;
	protected boolean validQuery = false;
	protected boolean hasAlias = false;
	protected ArrayList<Parameters> listofParameters = new ArrayList<Parameters>();
	protected DefaultStreamedContent downloadUDR;
	protected String inputvalue;
	protected String inputvalue1;
	protected ArrayList<String> listofaliases;
	protected String reportid = "";
	protected String createdby = "";
	protected String createdDate = "";
	protected String paramstring;
	protected String aliasstring;
	protected boolean calledFromAnother = false;
	protected boolean nextStatus = false;
	protected int paramcheck = 0;
	protected ArrayList<String> listofTables;
	protected ArrayList<String> listofColumns;
	protected Parameters currentParameter = new Parameters();
	protected String name;
	protected String valueType = "";// Values are MULTI or MONO
	protected String valueRestrction = "";// Values are FREE or CONSTRAINED
	protected ArrayList<String> inputvalues = new ArrayList<String>();
	protected String runDate = "";
	protected String runStatus = "";
	protected boolean queryReference = false;
	protected String referenceQuery = "";
	protected ArrayList<String> LOV = new ArrayList<String>();
	protected ArrayList<String> multivalues = new ArrayList<String>();
	protected String monovalue;
	protected String tableReference;
	protected String columnReference;
	protected String parameterDescription;

	public String getRunDate() {
		return runDate;
	}

	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}

	public String getRunStatus() {
		return runStatus;
	}

	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}

	public String getName() {
		return name;
	}

	public String getColumnReference() {
		return columnReference;
	}

	public void setColumnReference(String columnReference) {
		this.columnReference = columnReference;
	}

	public ArrayList<String> getInputvalues() {
		return inputvalues;
	}

	public void setInputvalues(ArrayList<String> inputvalues) {
		this.inputvalues = inputvalues;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReferenceQuery() {
		return referenceQuery;
	}

	public void setReferenceQuery(String referenceQuery) {
		this.referenceQuery = referenceQuery;
	}

	public boolean isQueryReference() {
		return queryReference;
	}

	public void setQueryReference(boolean queryReference) {
		this.queryReference = queryReference;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public String getValueRestrction() {
		return valueRestrction;
	}

	public void setValueRestrction(String valueRestrction) {
		this.valueRestrction = valueRestrction;
	}

	public ArrayList<String> getLOV() {
		return LOV;
	}

	public void setLOV(ArrayList<String> lOV) {
		LOV = lOV;
	}

	public ArrayList<String> getMultivalues() {
		return multivalues;
	}

	public void setMultivalues(ArrayList<String> multivalues) {
		this.multivalues = multivalues;
	}

	public String getMonovalue() {
		return monovalue;
	}

	public void setMonovalue(String monovalue) {
		this.monovalue = monovalue;
	}

	public String getTableReference() {
		return tableReference;
	}

	public void setTableReference(String tableReference) {
		this.tableReference = tableReference;
	}

	public String getParameterDescription() {
		return parameterDescription;
	}

	public void setParameterDescription(String parameterDescription) {
		this.parameterDescription = parameterDescription;
	}

	public void setListofColumns(ArrayList<String> listofColumns) {
		this.listofColumns = listofColumns;
	}

	public boolean isNextStatus() {
		return nextStatus;
	}

	public void setNextStatus(boolean nextStatus) {
		this.nextStatus = nextStatus;
	}

	public int getParamcheck() {
		return paramcheck;
	}

	public void setParamcheck(int paramcheck) {
		this.paramcheck = paramcheck;
	}

	public boolean isCalledFromAnother() {
		return calledFromAnother;
	}

	public void setCalledFromAnother(boolean calledFromAnother) {
		this.calledFromAnother = calledFromAnother;
	}

	public String getParamstring() {
		return paramstring;
	}

	public void setParamstring(String paramstring) {
		this.paramstring = paramstring;
	}

	public String getAliasstring() {
		return aliasstring;
	}

	public void setAliasstring(String aliasstring) {
		this.aliasstring = aliasstring;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public ArrayList<Parameters> getListofParameters() {
		return listofParameters;
	}

	public void setListofParameters(ArrayList<Parameters> listofParameters) {
		this.listofParameters = listofParameters;
	}

	public void setDownloadUDR(DefaultStreamedContent downloadUDR) {
		this.downloadUDR = downloadUDR;

	}

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	public String getSheetname() {
		return sheetname;
	}

	public void setSheetname(String sheetname) {
		this.sheetname = sheetname;
	}

	public String getTypeOfReport() {
		return typeOfReport;
	}

	public void setTypeOfReport(String typeOfReport) {
		this.typeOfReport = typeOfReport;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public LinkedHashMap<String, String> getAliases() {
		return aliases;
	}

	public void setAliases(LinkedHashMap<String, String> aliases) {
		this.aliases = aliases;
	}

	public String getGenericQuery() {
		return genericQuery;
	}

	public void setGenericQuery(String genericQuery) {
		this.genericQuery = genericQuery;
	}

	public String getGeneratedQuery() {
		return generatedQuery;
	}

	public void setGeneratedQuery(String generatedQuery) {
		this.generatedQuery = generatedQuery;
	}

	public String[] getHeaderMerge() {
		return headerMerge;
	}

	public void setHeaderMerge(String[] headerMerge) {
		this.headerMerge = headerMerge;
	}

	public LinkedHashMap<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(LinkedHashMap<String, String> parameters) {
		this.parameters = parameters;
	}

	public boolean isTemplateUsed() {
		return templateUsed;
	}

	public void setTemplateUsed(boolean templateUsed) {
		this.templateUsed = templateUsed;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getFormula() {
		return formula;
	}

	public void setFormula(String formula) {
		this.formula = formula;
	}

	public String getCustomHeader() {
		return customHeader;
	}

	public void setCustomHeader(String customHeader) {
		this.customHeader = customHeader;
	}

	public boolean isValidQuery() {
		return validQuery;
	}

	public void setValidQuery(boolean validQuery) {
		this.validQuery = validQuery;
	}

	public DefaultStreamedContent getDownloadUDR() {
		return downloadUDR;
	}

	public String getReportDesc() {
		return reportDesc;
	}

	public void setReportDesc(String reportDesc) {
		this.reportDesc = reportDesc;
	}

	public boolean isHasAlias() {
		return hasAlias;
	}

	public void setHasAlias(boolean hasAlias) {
		this.hasAlias = hasAlias;
	}

	public String getInputvalue() {
		return inputvalue;
	}

	public void setInputvalue(String inputvalue) {
		this.inputvalue = inputvalue;
	}

	public ArrayList<String> getListofaliases() {
		return listofaliases;
	}

	public void setListofaliases(ArrayList<String> listofaliases) {
		this.listofaliases = listofaliases;
	}

	public String getInputvalue1() {
		return inputvalue1;
	}

	public void setInputvalue1(String inputvalue1) {
		this.inputvalue1 = inputvalue1;
	}

	public String getReportid() {
		return reportid;
	}

	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

	public Parameters getCurrentParameter() {

		return currentParameter;
	}

	public void setCurrentParameter(Parameters currentParameter) {
		this.currentParameter = currentParameter;
	}

	public ArrayList<String> getListofTables() {
		return listofTables;
	}

	public void setListofTables(ArrayList<String> listofTables) {
		this.listofTables = listofTables;
	}

	public ArrayList<String> getListofColumns() {
		return listofColumns;
	}

	public void setListofClients(ArrayList<String> listofColumns) {
		this.listofColumns = listofColumns;
	}

	public void handleRestrictionChange() {

		this.listofTables = new ArrayList<String>();
		String query = "SELECT table_name FROM all_tables WHERE owner='AIPDB'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {

				this.listofTables.add(rs.get(i).get(0));
			}
		}

	}

	public void handleTableChange(String tablename) {
		this.listofColumns = new ArrayList<String>();
		String query = " select DISTINCT column_name from all_tab_cols where table_name=Upper('"
				+ tablename + "')  and owner='AIPDB' ORDER BY column_name";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {

				this.listofColumns.add(rs.get(i).get(0));
			}
		}

	}

	public void ExtractParameters() {
		int result = checkifExists(); // returns 1 for modify layout so that
										// report name should not be validated
		if (result != 1) {
			validateReportName(this.reportname);
		} else {
			this.validQuery = true;
		}
		if (this.validQuery) {

			this.validQuery = false;
			this.listofParameters = new ArrayList<Parameters>();
			this.paramcheck = 0;

			String parameters = "";

			String regex = "@prompt[\\(].[[a-z]*.[A-Z]*.[\\.]]*.[A-Z]*.[a-z]*.[0-9]*[\\)]";

			int count = getcountofParameters(this.genericQuery);

			Pattern p = Pattern.compile(regex);

			String testquery = this.genericQuery;

			int k = 0;

			while (!testquery.isEmpty()) {
				Matcher m = p.matcher(testquery);
				if (m.find()) {
					k++;

					parameters += m.group() + " and ";

					testquery = testquery
							.substring(m.end(), testquery.length());

					System.out.println("Parameters : " + parameters);

				}

				if (k == count) {
					break;
				}

			}

			if (!parameters.isEmpty()) {
				String[] checkparameters = parameters.split(" and ");

				for (int i = 0; i < checkparameters.length; i++) {

					this.listofParameters.add(new Parameters(checkparameters[i]
							.substring(checkparameters[i].indexOf("(") + 1,
									checkparameters[i].indexOf(")"))));

					if (this.listofParameters.get(i).getName().contains(".")) {
						this.hasAlias = true;
					}

				}
				if (this.listofParameters.size() > 1) {
					this.nextStatus = true;
				}
			}
			if (!calledFromAnother) {

				if (hasAlias) {
					checkforAliases();
					if (this.listofParameters.size() > 0) {
						setCurrentParameter(this.listofParameters.get(0));
					}

					RequestContext.getCurrentInstance().execute(
							"PF('aliasDialog').show()");
				}

				else {

					if (this.listofParameters.size() > 0) {
						setCurrentParameter(this.listofParameters.get(0));
						RequestContext.getCurrentInstance().execute(
								"PF('configparameterdialog').show();");

					}

					else {
						makeQuery();

					}

				}

			}
		} else {

			return;
		}
	}

	/**
	 * @param rptname
	 *            Report name to be validated
	 */
	public void validateReportName(String rptname) {

		String query = "select distinct reportname from aip_generic_reports order by reportname";
		ArrayList<String> listofNames = new ArrayList<String>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs.size() > 1) {
			for (int i = 1; i < rs.size(); i++) {
				listofNames.add(rs.get(i).get(0));
			}
		}
		if (listofNames.contains(rptname)) {
			displayErrorMessageToUser("Report Name already Exists",
					"Validation Error");
			this.validQuery = false;
			return;
		} else {
			this.validQuery = true;
		}
	}

	public int checkifExists() {
		int result = 0;
		if (!this.reportid.isEmpty()) {
			String query = "select 1 from aip_generic_reports where reportid='"
					+ this.reportid + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			if (rs != null) {
				if (rs.size() > 1) {
					result = 1;
				}
			}
		}

		return result;
	}

	public void addNewReport(String username) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT NVL(MAX(reportid) +1,1) FROM aip_generic_reports";
		String sn = "0";
		List<List<String>> snList = db.resultSetToListOfList(query);
		if (snList.size() > 1) {
			sn = snList.get(1).get(0);
			// setr(sn);
		} else {
			sn = "0";
		}
		int result = checkifExists();
		if (result == 1) {
			String deleteQuery = "Delete from aip_generic_reports where reportid='"
					+ this.reportid + "'";
			db.executeDML(deleteQuery);
			sn = this.reportid;
		}

		String insertquery = "insert into aip_generic_reports values" + "('"
				+ sn + "','" + this.reportname + "','" + this.sheetname + "','"
				+ this.reportDesc + "'," + "'" + username + "',sysdate,'"
				+ this.genericQuery.replaceAll("\\'", "\"") + "','"
				+ this.aliases + "'," + "'" + this.availability + "','"
				+ this.headerMerge + "','" + this.templateName + "','"
				+ this.customHeader + "','" + this.formula + "','"
				+ this.runDate + "','" + this.runStatus + "')";
		log.info("Insert New Report Query : " + insertquery);
		db.executeDML(insertquery);

		for (int i = 0; i < this.listofParameters.size(); i++) {
			String parameterquery = "Insert into aip_generic_parameters values"
					+ "('" + sn + "','" + listofParameters.get(i).getName()
					+ "','" + listofParameters.get(i).getValueType() + "','"
					+ listofParameters.get(i).getValueRestrction() + "','"
					+ listofParameters.get(i).getTableReference() + "','"
					+ listofParameters.get(i).getColumnReference() + "','"
					+ listofParameters.get(i).getReferenceQuery() + "')";

			System.out.println(parameterquery);
			db.executeDML(parameterquery);
		}
		db.endConnection();

		if (result == 1) {
			RequestContext.getCurrentInstance().closeDialog("modifyReport");

		} else {
			displayInfoMessageToUser("Report Saved Successfully", "Save Report");
		}

	}

	/*
	 * public void openParameter() { if(this.listofParameters.size()>0) {
	 * RequestContext
	 * .getCurrentInstance().execute("PF('parameterdialog').show();"); } else {
	 * makeQuery(); } }
	 */

	public void configParameters() {
		if (this.listofParameters.size() > 0) {
			RequestContext.getCurrentInstance().execute(
					"PF('configparameterdialog').show();");
		} else {
			makeQuery();
		}
	}

	public void createHashMap(ValueChangeEvent e) {
		String value = "";
		if (e.getNewValue() != null) {
			value = (e.getNewValue().toString().trim());
		}
		FacesContext context = FacesContext.getCurrentInstance();
		String key = context.getApplication().evaluateExpressionGet(context,
				"#{par.name}", String.class);
		System.out.println("Key : " + key + "and Value : " + value);
		this.parameters.put(key, value.trim());

	}

	public void createHashAlias(ValueChangeEvent e) {
		String value = "";
		if (e.getNewValue() != null) {
			value = (e.getNewValue().toString().trim());
		}
		FacesContext context = FacesContext.getCurrentInstance();
		String key = context.getApplication().evaluateExpressionGet(context,
				"#{ali}", String.class);
		System.out.println("Key : " + key + "and Value : " + value);
		this.aliases.put(key, value);

	}

	public int getcountofParameters(String query2) {

		int count = 0;
		int lastIndex = 0;
		while (lastIndex != -1) {
			lastIndex = query2.indexOf("@prompt", lastIndex);
			if (lastIndex != -1) {
				count++;
				lastIndex += "@prompt".length();
			}

		}

		return count;
	}

	public void checkforAliases() {
		this.listofaliases = new ArrayList<String>();
		for (int i = 0; i < listofParameters.size(); i++) {
			if (listofParameters.get(i).getName().contains(".")) {
				String key = listofParameters.get(i).getName().split("\\.")[0]
						.replaceAll("\\(", "");

				if (!this.listofaliases.contains(key))
					this.listofaliases.add(key);
			}
		}

	}

	public void makeQuery() {
		System.out.println("Building query...");
		String tempQuery = this.genericQuery.replaceAll("\"", "'");

		for (int i = 0; i < this.listofParameters.size(); i++) {
			
			System.out.println("Parameter : " + this.listofParameters.get(i).getMultivalues());
			tempQuery = tempQuery.replace("@prompt("
					+ this.listofParameters.get(i).getName() + ")",
					this.listofParameters.get(i).getName());
			if (this.parameters.get(this.listofParameters.get(i).getName()) == null) {
				displayErrorMessageToUser("Values are empty", "ERROR");
				return;
			}
			if (this.parameters.get(this.listofParameters.get(i).getName())
					.contains("[")) {
				tempQuery = tempQuery.replace(
						"$" + this.listofParameters.get(i).getName(),
						this.parameters
								.get(this.listofParameters.get(i).getName())
								.replaceAll(",","\\',\\'")
								.replaceAll("\\[","(\\'")
								.replaceAll("\\]","\\')").replaceAll("\\s", ""));
			} else {
				tempQuery = tempQuery.replace(
						"$" + this.listofParameters.get(i).getName(),
						"'"
								+ this.parameters.get(
										this.listofParameters.get(i).getName())
										.replaceAll(",","\\',\\'").trim() + "'");
				
				System.out.println("Temp Query : " + tempQuery);
			}
		}
		this.generatedQuery = tempQuery;
		log.info("Generated Query : " + this.generatedQuery);
		validate(this.generatedQuery);

	}

	public void validate(String generatedQuery2) {
		String tempQuery = "select count(*) from (" + generatedQuery2 + ")";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(tempQuery);
		db.endConnection();
		if (rs == null) {
			this.setValidQuery(false);
			displayErrorMessageToUser(
					"Invalid Query.Please Make sure the query is correct",
					"Query Validation Error");
			return;
		} else {
			if (rs.size() > 0) {
				System.out.println(Integer.parseInt(rs.get(1).get(0)));
				if (Integer.parseInt(rs.get(1).get(0)) > 1000000) {
					displayErrorMessageToUser(
							"Invalid Query.Query results in more than 50000 records",
							"Query Validation Error");
					this.validQuery = false;
				} else {
					// Validating the maximum count
					this.validQuery = true;
				}
			}
		}

	}

	public void handleNext() {
		if (!this.queryReference) {
			if (this.valueType.isEmpty() || this.valueRestrction.isEmpty()) {
				displayErrorMessageToUser("Required Fields cannot be empty",
						"Validation Error");
				return;
			}
			this.listofParameters.get(paramcheck).setValueRestrction(
					this.valueRestrction);
			this.listofParameters.get(paramcheck).setValueType(this.valueType);
			this.listofParameters.get(paramcheck).setTableReference(
					this.tableReference);
			this.listofParameters.get(paramcheck).setColumnReference(
					this.columnReference);
			this.listofParameters.get(paramcheck).setReferenceQuery("");
		} else if (this.queryReference) {

			if (this.valueType.isEmpty() || this.valueRestrction.isEmpty()
					|| this.referenceQuery.isEmpty()) {
				displayErrorMessageToUser("Required Fields cannot be empty",
						"Validation Error");
				return;
			}
			if (validateReferenceQuery().compareTo("Invalid Query") == 0) {

				displayErrorMessageToUser(
						"Invalid Reference Query.Cannot process Report",
						"Validation Error");
				return;
			}
			this.listofParameters.get(paramcheck).setValueRestrction(
					this.valueRestrction);
			this.listofParameters.get(paramcheck).setValueType(this.valueType);
			this.listofParameters.get(paramcheck).setTableReference("");
			this.listofParameters.get(paramcheck).setColumnReference("");
			this.listofParameters.get(paramcheck).setQueryReference(
					this.queryReference);
			this.listofParameters.get(paramcheck).setReferenceQuery(
					this.referenceQuery);

		}
		if (this.listofParameters.get(paramcheck).getValueRestrction()
				.compareTo("CONSTRAINED") == 0) {
			this.listofParameters.get(paramcheck).populateLOV();
		}
		this.name = "";
		this.valueType = "";
		this.valueRestrction = "";
		this.tableReference = "";
		this.columnReference = "";
		this.queryReference = false;
		this.referenceQuery = "";
		this.paramcheck++;
		this.currentParameter = this.listofParameters.get(paramcheck);
		if (paramcheck == listofParameters.size() - 1) {
			this.nextStatus = false;
		}
	}

	public void handleSubmit() {
		if (!this.queryReference) {

			if (this.valueType.isEmpty() || this.valueRestrction.isEmpty()) {
				displayErrorMessageToUser("Required Fields cannot be empty",
						"Validation Error");
				return;
			}
			this.listofParameters.get(paramcheck).setValueRestrction(
					this.valueRestrction);
			this.listofParameters.get(paramcheck).setValueType(this.valueType);
			this.listofParameters.get(paramcheck).setTableReference(
					this.tableReference);
			this.listofParameters.get(paramcheck).setColumnReference(
					this.columnReference);
			this.listofParameters.get(paramcheck).setReferenceQuery("");
		} else if (this.queryReference) {
			if (this.valueType.isEmpty() || this.valueRestrction.isEmpty()
					|| this.referenceQuery.isEmpty()) {
				displayErrorMessageToUser("Required Fields cannot be empty",
						"Validation Error");
				return;
			}
			if (validateReferenceQuery().compareTo("Valid Query") != 0) {
				this.paramcheck = 0;
				displayErrorMessageToUser(
						"Invalid Reference Query.Cannot process Report",
						"Validation Error");
				return;
			}
			this.listofParameters.get(paramcheck).setValueRestrction(
					this.valueRestrction);
			this.listofParameters.get(paramcheck).setValueType(this.valueType);
			this.listofParameters.get(paramcheck).setTableReference("");
			this.listofParameters.get(paramcheck).setColumnReference("");
			this.listofParameters.get(paramcheck).setQueryReference(
					this.queryReference);
			System.out.println(referenceQuery);
			this.listofParameters.get(paramcheck).setReferenceQuery(
					this.referenceQuery);

		}
		if (this.listofParameters.get(paramcheck).getValueRestrction()
				.compareTo("CONSTRAINED") == 0) {
			this.listofParameters.get(paramcheck).populateLOV();
		}
		this.name = "";
		this.valueType = "";
		this.valueRestrction = "";
		this.tableReference = "";
		this.columnReference = "";
		this.referenceQuery = "";
		this.queryReference = false;
		RequestContext.getCurrentInstance().execute(
				"PF('parametervalidationDialog').show();");
	}

	public void prepDownload(AddNewReport obj) {
		FileController objFC = new FileController(
				AIConstant.UD_REPORT_DUMP_LOCATION + obj.getReportname()
						+ ".xlsx");
		if (objFC != null) {
			obj.setDownloadUDR(objFC.getDownload());
		}

	}

	public String validateReferenceQuery() {
		String msg = "";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList("select * from ("
				+ this.referenceQuery + ") where 1=0");
		db.endConnection();

		if (rs == null) {
			msg = "Invalid Query";
		} else {
			msg = "Valid Query";
		}
		System.out.println(msg);
		return msg;
	}

}
