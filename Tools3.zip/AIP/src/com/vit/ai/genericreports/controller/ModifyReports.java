/*
 *Class Name : ModifyReports.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.genericreports.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Modify Generic Reports
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 27 Feb 2015
 */
@ManagedBean
@ViewScoped
public class ModifyReports extends AddNewReport {

	private static final long serialVersionUID = 1L;
	private String reportidtoModify;

	public ModifyReports() {
		super();
	}

	@PostConstruct
	public void init() {

		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.reportidtoModify = facesContext.getExternalContext()
				.getRequestParameterMap().get("sn");
		populateReportStructure();
	}

	public void populateReportStructure() {
		String query = "select REPORTID,REPORTNAME,SHEETNAME,REPORTDESC,Dbms_Lob.substr(QUERY,4000,1)"
				+ " from aip_generic_reports where reportid='"
				+ this.reportidtoModify + "'";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {

			if (rs.size() > 1) {
				this.setReportid(rs.get(1).get(0));
				this.setReportname(rs.get(1).get(1));
				this.setSheetname(rs.get(1).get(2));
				this.setReportDesc(rs.get(1).get(3));
				this.setGenericQuery(rs.get(1).get(4));

			}
		}

	}

	public String getReportidtoModify() {
		return reportidtoModify;
	}

	public void setReportidtoModify(String reportidtoModify) {
		this.reportidtoModify = reportidtoModify;
	}

	public void updateComplete() {
		populateReportStructure();
		displayInfoMessageToUser("Update Successful.Availability set to local",
				"Update");
	}
}
