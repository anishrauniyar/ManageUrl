/* 
 *Class Name : GenericReportViewController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.genericreports.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;

import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.background.RunReport;
import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.genericreports.model.Parameters;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for generic reports
 * 
 * @author Aashish Dhungana
 *
 * @version 1.0 21 Nov 2014
 */
@ManagedBean
@ViewScoped
public class GenericReportViewController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = -1877832076983909726L;
	private ArrayList<AddNewReport> listofReports;
	private ArrayList<AddNewReport> listofLReports;
	private ArrayList<MainLog> filteredLogs;
	private ArrayList<Parameters> listofParameters;
	private DefaultStreamedContent downloadUDR;
	private LinkedHashMap<String, String> selectedalias = new LinkedHashMap<>();
	@ManagedProperty(value="#{userInformation}")
	private UserInformation userinfo;

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	private String username = "";

	public ArrayList<AddNewReport> getListofLReports() {
		return listofLReports;
	}

	public void setListofLReports(ArrayList<AddNewReport> listofLReports) {
		this.listofLReports = listofLReports;
	}

	private AddNewReport selectedReport = new AddNewReport();

	public AddNewReport getSelectedReport() {
		return selectedReport;
	}

	public void setSelectedReport(AddNewReport selectedReport) {
		this.selectedReport = selectedReport;
	}

	private String reportid;

	public GenericReportViewController() {

	}

	@PostConstruct
	public void init() {
		this.username = getUserinfo().getFullname();
		listGlobalReports();
		listLocalReports();

	}

	public void listGlobalReports() {
		this.listofReports = new ArrayList<AddNewReport>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT REPORTID,REPORTNAME,SHEETNAME,REPORTDESC,CREATEDBY,CREATEDDATE,Dbms_Lob.substr(QUERY,4000,1),REFERENCE,AVAILABILITY,"
				+ "CUSTOMMERGEHEADER,TEMPLATENAME ,CUSTOMHEADER,FORMULA,RUNDATE,RUNSTATUS  FROM aip_generic_reports where AVAILABILITY='G' order by reportid desc";

		List<List<String>> rs = db.resultSetToListOfList(query);

		System.out.println(query);
		if (rs.size() > 1) {

			LinkedHashMap<String, String> acontainer;
			for (int i = 1; i < rs.size(); i++) {

				acontainer = new LinkedHashMap<String, String>();

				AddNewReport obj = new AddNewReport();
				obj.setReportid(rs.get(i).get(0));
				obj.setReportname(rs.get(i).get(1));
				obj.setSheetname(rs.get(i).get(2));
				obj.setReportDesc(rs.get(i).get(3));
				obj.setCreatedby(rs.get(i).get(4));
				obj.setCreatedDate(rs.get(i).get(5));
				obj.setGenericQuery(rs.get(i).get(6));
				String queryp = "select PARAMETERS,PARAMETER_TYPE,PARAMETER_RESTRICTION,TABLE_REFERENCE,COLUMN_REFERENCE,REFERENCE_QUERY from aip_generic_parameters where reportid='"
						+ obj.getReportid() + "'";

				List<List<String>> rs1 = db.resultSetToListOfList(queryp);

				if (rs.size() > 1) {
					for (int j = 1; j < rs1.size(); j++) {
						obj.getListofParameters().add(
								new Parameters(rs1.get(j).get(0), rs1.get(j)
										.get(1), rs1.get(j).get(2), rs1.get(j)
										.get(3), rs1.get(j).get(4), rs1.get(j)
										.get(5)));
					}
				}

				String alias = rs.get(i).get(7).toString();
				System.out.println(alias);
				@SuppressWarnings("unused")
				String aliasstring = "";
				if (alias.length() > 2) {
					String checkalias[] = alias.split(",");

					for (int j = 0; j < checkalias.length; j++) {
						aliasstring += checkalias[j].replaceAll("\\{", "");

						String split[] = checkalias[j].split("=");
						acontainer.put(split[0], split[1]);
					}
				}

				obj.setAliases(acontainer);
				obj.setAvailability(rs.get(i).get(8));
				obj.setRunDate(rs.get(i).get(13));
				obj.setRunStatus(rs.get(i).get(14));

				this.listofReports.add(obj);

			}
			db.endConnection();
		}
	}

	public void listLocalReports() {

		this.listofLReports = new ArrayList<AddNewReport>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT REPORTID,REPORTNAME,SHEETNAME,REPORTDESC,CREATEDBY,CREATEDDATE,Dbms_Lob.substr(QUERY,4000,1),REFERENCE,AVAILABILITY,"
				+ "CUSTOMMERGEHEADER,TEMPLATENAME ,CUSTOMHEADER,FORMULA,RUNDATE,RUNSTATUS  FROM aip_generic_reports where AVAILABILITY='L' and createdby='"
				+ username + "' order by reportid";

		List<List<String>> rs = db.resultSetToListOfList(query);

		System.out.println(query);
		if (rs.size() > 1) {

			LinkedHashMap<String, String> acontainer;
			for (int i = 1; i < rs.size(); i++) {

				acontainer = new LinkedHashMap<String, String>();

				AddNewReport obj = new AddNewReport();
				obj.setReportid(rs.get(i).get(0));
				obj.setReportname(rs.get(i).get(1));
				obj.setSheetname(rs.get(i).get(2));
				obj.setReportDesc(rs.get(i).get(3));
				obj.setCreatedby(rs.get(i).get(4));
				obj.setCreatedDate(rs.get(i).get(5));
				obj.setGenericQuery(rs.get(i).get(6));
				String queryp = "select PARAMETERS,PARAMETER_TYPE,PARAMETER_RESTRICTION,TABLE_REFERENCE,COLUMN_REFERENCE,REFERENCE_QUERY from aip_generic_parameters where reportid='"
						+ obj.getReportid() + "'";

				List<List<String>> rs1 = db.resultSetToListOfList(queryp);

				if (rs.size() > 1) {
					for (int j = 1; j < rs1.size(); j++) {
						obj.getListofParameters().add(
								new Parameters(rs1.get(j).get(0), rs1.get(j)
										.get(1), rs1.get(j).get(2), rs1.get(j)
										.get(3), rs1.get(j).get(4), rs1.get(j)
										.get(5)));
					}
				}

				String alias = rs.get(i).get(7).toString();
				System.out.println(alias);
				@SuppressWarnings("unused")
				String aliasstring = "";
				if (alias.length() > 2) {
					String checkalias[] = alias.split(",");

					for (int j = 0; j < checkalias.length; j++) {
						aliasstring += checkalias[j].replaceAll("\\{", "");

						String split[] = checkalias[j].split("=");
						acontainer.put(split[0], split[1]);
					}
				}

				obj.setAliases(acontainer);
				obj.setAvailability(rs.get(i).get(8));
				obj.setRunDate(rs.get(i).get(13));
				obj.setRunStatus(rs.get(i).get(14));
				// obj.setHeaderMerge()
				this.listofLReports.add(obj);

			}
			db.endConnection();
		}
	}

	public ArrayList<AddNewReport> getListofReports() {
		return listofReports;
	}

	public void setListofReports(ArrayList<AddNewReport> listofReports) {
		this.listofReports = listofReports;
	}

	public ArrayList<MainLog> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<MainLog> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public void viewParameter(AddNewReport obj) {
		this.listofParameters = new ArrayList<Parameters>();
		this.listofParameters = obj.getListofParameters();
		this.selectedalias = obj.getAliases();
		RequestContext.getCurrentInstance().execute(
				"PF('parameterDialog').show();");

	}

	public LinkedHashMap<String, String> getSelectedalias() {
		return selectedalias;
	}

	public void setSelectedalias(LinkedHashMap<String, String> selectedalias) {
		this.selectedalias = selectedalias;
	}

	public void setSelectedReportid(String rptid) {
		this.reportid = rptid;
		System.out.println("Report ID selected : " + this.reportid);
	}

	public void deleteReport() {
		String query = "Delete from aip_generic_reports where reportid='"
				+ this.reportid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		db.executeDML(query);
		db.endConnection();
		displayInfoMessageToUser("Delete Succesfully", "Delete");
		listGlobalReports();
		listLocalReports();

		// this.parameters.put(key, value);
	}

	public String getReportid() {
		return reportid;
	}

	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

	public void extractparameter(AddNewReport obj, String username) {
		this.selectedReport = new AddNewReport();
		this.selectedReport = obj;
		// this.selectedReport.setCalledFromAnother(true);
		// this.selectedReport.ExtractParameters();
		if (this.selectedReport.getListofParameters().size() > 0) {
			RequestContext.getCurrentInstance().execute(
					"PF('parameterviewDialog').show();");
		} else {
			genQuery(obj, username);
		}
	}

	public void genQuery(AddNewReport obj, String username) {

		obj.makeQuery();
		if (obj.isValidQuery()) {
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query = "Update aip_generic_reports set RunDate=sysdate , Runstatus='RUNNING' where reportid='"
					+ obj.getReportid() + "'";
			db.executeDML(query);
			db.endConnection();
		}
		System.out.println("Generated Query : " + obj.getGeneratedQuery());
		downLoadExcel(obj, username);
		this.listGlobalReports();
		this.listLocalReports();

	}

	public void setLocal(String reportid) {
		String query = "update aip_generic_reports set availability='L' where reportid='"
				+ reportid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		try {
			db.executeDML(query);
			displayInfoMessageToUser("Availability changed to Local", "");
		} catch (Exception ex) {
			displayErrorMessageToUser("Availability update Failed", "ERROR");
		}
		listGlobalReports();
		listLocalReports();
	}

	public void setGlobal(String reportid) {
		String query = "update aip_generic_reports set availability='G' where reportid='"
				+ reportid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		try {
			db.executeDML(query);
			displayInfoMessageToUser("Availability changed to Global", "");
		} catch (Exception ex) {
			displayErrorMessageToUser("Availability update Failed", "ERROR");
		}
		listGlobalReports();
		listLocalReports();
	}

	public void downLoadExcel(AddNewReport obj, String username) {
		displayInfoMessageToUser("Report is in progress", "Run Report");

		RunReport runreport = new RunReport();
		runreport.new RunExcel(obj, this, username).init();

		/*
		 * try { Thread.sleep(1000); } catch (InterruptedException e1) { // TODO
		 * Auto-generated catch block e1.printStackTrace(); }
		 * while(monitorreportprogress.getStatus().compareTo("COMPLETED")!=0) {
		 * try { Thread.sleep(1000); } catch (InterruptedException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } }
		 */

	}

	public void reloadReports() {
		System.out.println("Reloading...");
		RequestContext.getCurrentInstance().execute(
				"jQuery('#reloadReports').trigger('click');");
		// RequestContext.getCurrentInstance().execute("reload();");
	}

	/*
	 * public void downLoadHTML(AddNewReport obj) {
	 * displayInfoMessageToUser("Report is in progress", "Run Report");
	 * RunReport runreport=new RunReport(); runreport.new RunHTML(obj).init();
	 * 
	 * }
	 */
	public void updateUI(AddNewReport object) {

		if (object.getDownloadUDR() != null) {
			System.out.println("Its coming here");
			RequestContext.getCurrentInstance().execute(
					"jQuery('#download').trigger('click');");
		}

	}

	public void openModify() {
		String id = this.reportid;

		/*
		 * FacesContext context=FacesContext.getCurrentInstance();
		 * Map<String,String>
		 * map=context.getExternalContext().getRequestParameterMap(); String
		 * id=map.get("sn");
		 */
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 800);
		options.put("height", 500);
		options.put("contentWidth", 800);
		options.put("contentHeight", 500);
		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(id);
		params.put("sn", list1);
		RequestContext.getCurrentInstance().openDialog("modifyReport", options,
				params);// ,options,null)
	}

	public ArrayList<Parameters> getListofParameters() {
		return listofParameters;
	}

	public void setListofParameters(ArrayList<Parameters> listofParameters) {
		this.listofParameters = listofParameters;
	}

	public DefaultStreamedContent getDownloadUDR() {

		return downloadUDR;
	}

	public void prepDownload(AddNewReport obj, String username) {
		System.out.println("OBJECT : " + obj.getReportname() + "_" + username);
		FileController objFC = new FileController(
				AIConstant.UD_REPORT_DUMP_LOCATION + obj.getReportname() + "_"
						+ username + ".xlsx");
		setDownloadUDR(objFC.getDownload());
	}

	public void setDownloadUDR(DefaultStreamedContent downloadUDR) {
		this.downloadUDR = downloadUDR;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void updateView() {

		displayInfoMessageToUser("Update Successful.Availability set to local",
				"Update");
		listGlobalReports();
		listLocalReports();
	}
}
