/* 
 *Class Name : Parameters.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.genericreports.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 07 Dec 2014
 */
public class Parameters implements Serializable {

	private static final long serialVersionUID = 6946153894006973463L;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public String getValueRestrction() {
		return valueRestrction;
	}

	public void setValueRestrction(String valueRestrction) {
		this.valueRestrction = valueRestrction;
	}

	public ArrayList<String> getLOV() {
		return LOV;
	}

	public void setLOV(ArrayList<String> lOV) {
		LOV = lOV;
	}

	public ArrayList<String> getMultivalues() {
		return multivalues;
	}

	public void setMultivalues(ArrayList<String> multivalues) {
		this.multivalues = multivalues;
	}

	public String getMonovalue() {
		return monovalue;
	}

	public void setMonovalue(String monovalue) {
		this.monovalue = monovalue;
	}

	public String getTableReference() {
		return tableReference;
	}

	public void setTableReference(String tableReference) {
		this.tableReference = tableReference;
	}

	public String getColumnReference() {
		return columnReference;
	}

	public void setColumnReference(String columnReference) {
		this.columnReference = columnReference;
	}

	private String name;
	private String valueType;/* Values are MULTI or MONO */
	private String valueRestrction;/* Values are FREE or CONSTRAINED */
	private ArrayList<String> LOV = new ArrayList<String>();
	private ArrayList<String> multivalues = new ArrayList<String>();
	private String monovalue;
	private String tableReference;
	private String columnReference;
	private String parameterDescription;
	private boolean queryReference = false;
	private String referenceQuery = "";

	public Parameters(String name) {
		super();
		this.name = name;
	}

	public Parameters(String name, String valueType, String valueRestriction,
			String tableReference, String columnReference, String queryReference) {
		super();
		this.name = name;
		this.valueType = valueType;
		this.valueRestrction = valueRestriction;
		this.tableReference = tableReference;
		this.columnReference = columnReference;
		this.referenceQuery = queryReference;
		if (!this.referenceQuery.isEmpty()) {
			this.queryReference = true;
		}
		if (this.valueRestrction.compareTo("CONSTRAINED") == 0) {
			populateLOV();
		}
	}

	public void populateLOV() {

		if (!this.isQueryReference()) {
			if (!this.columnReference.isEmpty()
					|| !this.tableReference.isEmpty()) {

				String query = "select distinct " + this.columnReference
						+ " from " + this.tableReference + " order by "
						+ this.columnReference;

				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> rs = db.resultSetToListOfList(query);
				db.endConnection();
				if (rs.size() > 1) {
					for (int i = 1; i < rs.size(); i++) {
						this.LOV.add(rs.get(i).get(0));
					}
				}

			}
		} else {
			if (!this.referenceQuery.isEmpty()) {
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> rs = db
						.resultSetToListOfList(this.referenceQuery);
				db.endConnection();
				if (rs.size() > 1) {
					for (int i = 1; i < rs.size(); i++) {
						this.LOV.add(rs.get(i).get(0));
					}
				}

			}
		}

	}

	public Parameters() {
	}

	public String getParameterDescription() {
		return parameterDescription;
	}

	public void setParameterDescription(String parameterDescription) {
		this.parameterDescription = parameterDescription;
	}

	public boolean isQueryReference() {
		return queryReference;
	}

	public void setQueryReference(boolean queryReference) {
		this.queryReference = queryReference;
	}

	public String getReferenceQuery() {
		return referenceQuery;
	}

	public void setReferenceQuery(String referenceQuery) {
		this.referenceQuery = referenceQuery;
	}

}