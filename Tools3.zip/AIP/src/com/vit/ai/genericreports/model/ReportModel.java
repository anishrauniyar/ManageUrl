/* 
 * Class Name : ReportModel.java
 *
 * Copyright: Verisk Information Technologies
 */

package com.vit.ai.genericreports.model;

import java.io.Serializable;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;

import com.vit.ai.session.ViewsParameters;
import com.vit.dbconnection.ConnectDB;

/**
 * Model class for subscribable reports accessed from alerts view
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 17 Nov 2014
 */
public class ReportModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static Logger log = Logger.getLogger(ReportModel.class.getName());
	private String reportid;
	private String reportname;
	private String reportdesc;
	private boolean subscribe;
	private String clientid;
	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public String getReportid() {
		return reportid;
	}

	public void setReportid(String reportid) {
		this.reportid = reportid;
	}

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	public String getReportdesc() {
		return reportdesc;
	}

	public void setReportdesc(String reportdesc) {
		this.reportdesc = reportdesc;
	}

	public boolean isSubscribe() {
		return subscribe;
	}

	public void setSubscribe(boolean subscribe) {
		this.subscribe = subscribe;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public ReportModel(String clientid, String reportid, String reportname,
			String reportdesc, String subscribed) {

		this.clientid = clientid;
		this.reportid = reportid;
		this.reportname = reportname;
		this.reportdesc = reportdesc;
		if (subscribed.toUpperCase().compareTo("Y") == 0) {
			this.subscribe = true;
		} else {
			this.subscribe = false;
		}
	}

	public void updateTable(List<String> clients, String userid, String emailid) {

		if (clients.isEmpty()) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage("Select Clients First."));
			return;
		}
		int count = 0;
		ConnectDB db = new ConnectDB();
		db.initialize();
		String updateStatement = "";
		for (int i = 0; i < clients.size(); i++) {
			count++;

			updateStatement = "insert into aip_rpt_subscriber(reportid,clientid, userid, emailid, subscribe) values ('"
					+ reportid
					+ "','"
					+ clients.get(i).split("-")[0]
					+ "','"
					+ userid + "','" + emailid + "','Y')";
			log.info("Storing Subscribed User Information: " + updateStatement);
			db.executeDML(updateStatement);
			db.endConnection();
		}

		String message = reportname + " : ";

		message = message + "Subscribed for " + count + "clients";
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(message));

	}

	public void updateTable(String userid, String emailid) {
		String updateStatement = "";

		if (subscribe) {

			updateStatement = "insert into aip_rpt_subscriber(reportid,clientid, userid, emailid, subscribe) values ('"
					+ reportid
					+ "','"
					+ clientid
					+ "','"
					+ userid
					+ "','"
					+ emailid + "','Y')";

		} else {

			updateStatement = "delete from aip_rpt_subscriber where reportid = "
					+ reportid
					+ " and userid = '"
					+ userid
					+ "' and clientid = '" + clientid + "'";
		}

		try {
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(updateStatement);
			db.endConnection();

		} catch (Exception e) {
			log.error(" Error while Updating User Subscription: "
					+ e.getMessage());

		}

		String message = reportname + " : ";
		if (subscribe) {
			message = message + "Subscribed";
		} else {
			message = message + "Unsubscribed";
		}

		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(message));
	}

	/*public void unsubscribe(String clientid, String userid,boolean status) {
		System.out.println(" Status "+status);

		String updateStatement = "";
		updateStatement = "delete from aip_rpt_subscriber where reportid = "
				+ reportid + " and userid = '" + userid + "' and clientid = '"
				+ clientid + "'";

		try {
			ConnectDB db = new ConnectDB();
			db.initialize();
			log.info(" Deleting Subscribed User: " + updateStatement);
			db.executeDML(updateStatement);
			db.endConnection();
			String message = reportname + " for client " + clientid
					+ " Unsubscribed";
			this.subscribe = false;
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(message));
		} catch (Exception e)
		// No need to handle
		{
			log.error(" Error While Deleting Subscribed User: "
					+ e.getMessage());
		}
	}*/
}
