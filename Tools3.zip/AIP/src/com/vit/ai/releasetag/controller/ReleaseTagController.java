package com.vit.ai.releasetag.controller;

import java.io.Serializable;
import java.sql.Clob;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;



import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.bulkmanager.controller.BulkToHIController;
import com.vit.ai.commons.model.ReleaseTagDataModel;
import com.vit.ai.releasetag.dao.ReleaseTagDAO;
import com.vit.ai.releasetag.model.ReleaseTagModel;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;



@ManagedBean
@ViewScoped
public class ReleaseTagController extends AbstractController implements Serializable {


	private static final long serialVersionUID = -8742200385681610274L;
	
	private static Logger log = LoggerFactory.getLogger(ReleaseTagController.class);

	private String selectedFilter="byApp";
	private String releaseTag="";
	protected String winScreenHeight;
	private ArrayList<String> listofAppReleaseTags;
	private ArrayList<String> listofClientReleaseTags;
	private String appid="";
	private LinkedHashMap<String,String> listofAppids;
	private ArrayList<String> listofAppReleaseTagsToTag;
	private String releaseTagToTag="";
	
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;

	private String forceAppid = "";
	private ArrayList<String> listofForceAppids;
	
	
	
	public String getForceAppid() {
		return forceAppid;
	}

	public void setForceAppid(String forceAppid) {
		this.forceAppid = forceAppid;
	}

	public ArrayList<String> getListofForceAppids() {
		return listofForceAppids;
	}

	public void setListofForceAppids(ArrayList<String> listofForceAppids) {
		this.listofForceAppids = listofForceAppids;
		this.listofForceAppids = new ReleaseTagDAO().getListofForceAppids(this.appid);
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

	private ArrayList<ReleaseTagModel> listofFiles;
	private ReleaseTagDataModel releaseMainLogs;
	private ArrayList<ReleaseTagModel> filteredLogs;
	private ArrayList<ReleaseTagModel> selectedLogs;
	
	private static final Logger logger = LoggerFactory
			.getLogger(ReleaseTagController.class);

	
	public void setValue() {
		this.winScreenHeight = FacesContext.getCurrentInstance()
				.getExternalContext().getRequestParameterMap()
				.get("winScreenHeight");

	}

	
	public ReleaseTagController() {
		init();

	}

	public void init() {
		
		
		this.selectedLogs = new ArrayList<>();
		this.listofAppids = new LinkedHashMap<>();
		this.listofFiles = new ArrayList<>();
		
	
		setListofAppids(listofAppids);
	
		
		
	}

	public LinkedHashMap<String,String> getListofAppids() {
		return listofAppids;
	}

	public void setListofAppids(LinkedHashMap<String,String> listofAppids) {
		this.listofAppids = listofAppids;
		this.listofAppids = new ReleaseTagDAO().getListofAppids();
	}

	public ArrayList<ReleaseTagModel> getListofFiles() {
		return listofFiles;
	}

	public void setListofFiles(ArrayList<ReleaseTagModel> listofFiles) {
		this.listofFiles = listofFiles;
	}


	

	/**
	 * Functions that gets the data from dao after a client change with filter request is
	 * made
	 */
	public void submitFilters() {
		
		if (this.filteredLogs!= null) {
			log.info("Setting to null");
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();
		}
		
		if(this.releaseTag.isEmpty())
		{
			displayErrorMessageToUser("Please select a value", "ERROR");
			return;
		}
		
		if (this.appid != null || !this.appid.isEmpty()) {
			this.listofFiles = new ArrayList<>();
			
			if(this.selectedFilter.compareTo("byApp")==0)
			{
			this.listofFiles = new ReleaseTagDAO().getAllFilesByAppReleaseTag(releaseTag, this.appid);
			}
			else if (this.selectedFilter.compareTo("byClient")==0)
			{
				this.listofFiles = new ReleaseTagDAO().getAllFilesByClientReleaseTag(releaseTag, this.appid);
			}
			else
			{
				displayErrorMessageToUser("No Appropriate filter selected", "ERROR");
			}
			this.filteredLogs = this.listofFiles;
			this.releaseMainLogs = new ReleaseTagDataModel(this.listofFiles);
			log.info("Row count : " + this.releaseMainLogs.getRowCount());
		
		
		} else {
			logger.error("No Client Selected");
			displayErrorMessageToUser("Please select a client",
					"No Client Selected");
		
		}

	}
	
	public void forceReleaseList() {
		if (this.appid != null || !this.appid.isEmpty()) {
			//this.getListofAppReleaseTag = ReleaseTagDAO.getListofAppReleaseTag(appid);
			log.info("This is a update of release tag");
		} else {
			logger.error("No AppId selected");
			displayErrorMessageToUser("Please select the app id", "No AppId selected");
		}
	}
	
	public void resetFilters()
	{
		this.selectedFilter = "";
		if(this.listofAppReleaseTags!=null)
		{
		this.listofAppReleaseTags.clear();
		}
		if(this.listofClientReleaseTags!=null)
		{
		this.listofClientReleaseTags.clear();
		}
	}


	public ArrayList<ReleaseTagModel> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<ReleaseTagModel> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public String getSelectedFilter() {
		return selectedFilter;
	}

	public void setSelectedFilter(String selectedFilter) {
		this.selectedFilter = selectedFilter;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}
	
	public void handleForceReleaseChange(){
		this.listofAppReleaseTagsToTag = new ArrayList<>();
		this.listofAppReleaseTagsToTag = new ReleaseTagDAO().getListofAppReleaseTagToTag(this.forceAppid);
	}
	
	public void handleFilterChange()
	{
		log.info("The app id selected is: " + this.appid);
		if(!this.selectedFilter.isEmpty())
		{
			if(this.selectedFilter.compareTo("byApp")==0)
			{
				this.listofAppReleaseTags = new ArrayList<>();
				this.listofAppReleaseTags = new ReleaseTagDAO().getListofAppReleaseTag(this.appid);
				
			}
			else if (this.selectedFilter.compareTo("byClient")==0)
			{

				this.listofClientReleaseTags = new ArrayList<>();
				this.listofClientReleaseTags = new ReleaseTagDAO().getListofClientReleaseTag(this.appid);
				
			}
		}
	}

	public ArrayList<String> getListofClientReleaseTags() {
		return listofClientReleaseTags;
	}

	public void setListofClientReleaseTags(ArrayList<String> listofClientReleaseTags) {
		this.listofClientReleaseTags = listofClientReleaseTags;
	}

	public ArrayList<String> getListofAppReleaseTags() {
		return listofAppReleaseTags;
	}

	public void setListofAppReleaseTags(ArrayList<String> listofAppReleaseTags) {
		this.listofAppReleaseTags = listofAppReleaseTags;
	}

	public ArrayList<ReleaseTagModel> getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(ArrayList<ReleaseTagModel> selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	public ReleaseTagDataModel getReleaseMainLogs() {
		return releaseMainLogs;
	}

	public void setReleaseMainLogs(ReleaseTagDataModel releaseMainLogs) {
		this.releaseMainLogs = releaseMainLogs;
	}

	public void futureFiles()
	{
		int count=0;
		ConnectDB db =new ConnectDB();
		db.initialize();
		String query = "";
		if(this.selectedLogs.size()>0)
		{
			
			for(int i=0;i<this.selectedLogs.size();i++)
			{
				if(this.selectedLogs.get(i).getReleasetag().compareTo("FUTURE")!=0)
				{
					String userLog = "INSERT INTO imp_user_log (sn,logtype,logdetail,username,logdate) "  
							+ " VALUES ('1', 'FUTURE_RELTAG', " 
							+ " 'APPID: "+ getAppid() +" | DMFILEID:" + this.selectedLogs.get(i).getDmfileid() + " | SN:" + this.selectedLogs.get(i).getSn() + " | RELEASE TAGGED FROM '||(SELECT reltag FROM imp_files_reltag_reln WHERE sn='" + this.selectedLogs.get(i).getSn() + "')||' TO HOLD', '"
							+ this.userinfo.getFullname() + "', SYSDATE)";
					try {
						db.executeDML(userLog);
					} catch (Exception e) {
						log.info("The user log in force release can not be inserted with: " + e.getMessage());
					}
					//query = "update imp_files_reltag_reln set reltag='FUTURE' where dmfileid='"+this.selectedLogs.get(i).getDmfileid()+"' AND reltag='" + this.selectedLogs.get(i).getReleasetag() + "'";
					query = "update imp_files_reltag_reln set reltag='FUTURE',releaseflag='F' where sn='"+this.selectedLogs.get(i).getSn()+"'";
					log.info("Release tag update is: " + query);
					String inventoryQuery = "UPDATE imp_main_log SET EXCEPTIONFLAG ='FUTURE',exceptionflagby='"
							+ getUserinfo().getFullname()
							+ "' WHERE dmfileid||'_'||filename = '" + this.selectedLogs.get(i).getDmfileid() + "_" + this.selectedLogs.get(i).getFilename() + "'";
					log.info("File Inventory update is: " + inventoryQuery);
					String stat =  db.executeDML(query);
					stat = db.executeDML(inventoryQuery);
					handleFilterChange();
					if(stat.compareTo("1")==0)
					{
						count++;
						
					}
					 
				}
			}
			db.endConnection();
			if(count>0)
			{
				displayInfoMessageToUser(count + " files have been updated to future", "FUTURE FILES");
				submitFilters();
			}
			
		}
		else
		{
			displayErrorMessageToUser("No files selected", "Select Files");
		}
	}
	
	public void implementationFiles()
	{
		int count=0;
		ConnectDB db =new ConnectDB();
		db.initialize();
		String query = "";
		logger.info("This is a implementation files in release tag.");
		if(this.selectedLogs.size()>0)
		{
			
			for(int i=0;i<this.selectedLogs.size();i++)
			{
				if(this.selectedLogs.get(i).getReleasetag().compareTo("IMPLEMENTATION")!=0)
				{
					String userLog = "INSERT INTO imp_user_log (sn,logtype,logdetail,username,logdate) "  
							+ " VALUES ('1', 'IMPLEMENTATION_RELTAG', " 
							+ " 'APPID: "+ getAppid() +" |  DMFILEID:" + this.selectedLogs.get(i).getDmfileid() + " | SN:" + this.selectedLogs.get(i).getSn() + " | RELEASE TAGGED FROM '||(SELECT reltag FROM imp_files_reltag_reln WHERE sn='" + this.selectedLogs.get(i).getSn() + "')||' TO IMPLEMENTATION', '"
							+ this.userinfo.getFullname() +"', SYSDATE)";
					try {
						db.executeDML(userLog);
					} catch (Exception e) {
						log.info("The user log in force release can not be inserted with: " + e.getMessage());
					}
					//query = "update imp_files_reltag_reln set reltag='IMPLEMENTATION' where dmfileid='"+this.selectedLogs.get(i).getDmfileid()+"' AND reltag='" + this.selectedLogs.get(i).getReleasetag() + "'";
					query = "update imp_files_reltag_reln set reltag='IMPLEMENTATION',releaseflag='F' where sn='"+this.selectedLogs.get(i).getSn()+"'";
					String inventoryQuery = "UPDATE IMP_MAIN_LOG SET exceptionflag='IMPLEMENTATION',releaseno='',exceptionflagby='"
							+ getUserinfo().getFullname()
							+ "' WHERE dmfileid||'_'||filename = '" + this.selectedLogs.get(i).getDmfileid() + "_" + this.selectedLogs.get(i).getFilename() + "'";
					String stat =  db.executeDML(query);
					stat = db.executeDML(inventoryQuery);
					handleFilterChange();
					if(stat.compareTo("1")==0)
					{
						count++;
						
					}
					 
				}
			}
			if(count>0)
			{
				displayInfoMessageToUser(count + " files have been updated to implementation", "IMPLEMENTATION FILES");
				submitFilters();
			}
			
		}
		else
		{
			displayErrorMessageToUser("No files selected", "Select Files");
		}
	}
	
	public void doNotUseFiles()
	{
		int count=0;
		ConnectDB db =new ConnectDB();
		db.initialize();
		String query = "";
		logger.info("This is to tag Do Not Use files in release tag.");
		if(this.selectedLogs.size()>0)
		{
			
			for(int i=0;i<this.selectedLogs.size();i++)
			{
				if(this.selectedLogs.get(i).getReleasetag().compareTo("DO NOT USE")!=0)
				{
					String userLog = "INSERT INTO imp_user_log (sn,logtype,logdetail,username,logdate) "  
							+ " VALUES ('1', 'DONOTUSE_RELTAG', " 
							+ " 'APPID: "+ getAppid() +" |  DMFILEID:" + this.selectedLogs.get(i).getDmfileid() + " | SN:" + this.selectedLogs.get(i).getSn() + " | RELEASE TAGGED FROM '||(SELECT reltag FROM imp_files_reltag_reln WHERE sn='" + this.selectedLogs.get(i).getSn() + "')||' TO DO NOT USE', '"
							+ this.userinfo.getFullname() +"', SYSDATE)";
					try {
						db.executeDML(userLog);
						db.endConnection();
					} catch (Exception e) {
						log.info("The user log in force release can not be inserted with: " + e.getMessage());
					}
					//query = "update imp_files_reltag_reln set reltag='IMPLEMENTATION' where dmfileid='"+this.selectedLogs.get(i).getDmfileid()+"' AND reltag='" + this.selectedLogs.get(i).getReleasetag() + "'";
					query = "update imp_files_reltag_reln set reltag='DO NOT USE',releaseflag='F' where sn='"+this.selectedLogs.get(i).getSn()+"'";
					String inventoryQuery = "UPDATE IMP_MAIN_LOG SET exceptionflag='DO NOT USE',releaseno='',exceptionflagby='"
							+ getUserinfo().getFullname()
							+ "' WHERE dmfileid||'_'||filename = '" + this.selectedLogs.get(i).getDmfileid() + "_" + this.selectedLogs.get(i).getFilename() + "'";
					db.initialize();
					String stat =  db.executeDML(query);
					stat = db.executeDML(inventoryQuery);
					db.endConnection();
					handleFilterChange();
					if(stat.compareTo("1")==0)
					{
						count++;
						
					}
					 
				}
			}
			if(count>0)
			{
				displayInfoMessageToUser(count + " files have been updated to DO NOT USE", "DO NOT USE FILES");
				submitFilters();
			}
			
		}
		else
		{
			displayErrorMessageToUser("No files selected", "Select Files");
		}
	}
	
	public void openForceDialog()
	{
		this.listofForceAppids = new ArrayList<String>();
		setListofForceAppids(listofForceAppids);
		RequestContext.getCurrentInstance().execute("PF('confirmD').show();"); 
	}
	
	public void openConfirmForceDialog()
	{
		log.info("Entered to display the confirm box.");
		this.listofAppReleaseTagsToTag = new ArrayList<>();
		this.listofAppReleaseTagsToTag = new ReleaseTagDAO().getListofAppReleaseTagToTag(appid);
		RequestContext.getCurrentInstance().execute("PF('forceConfirmD').show();");
	}

	public void ForceFiles(String releasetag, String forceAppId)
	{
		log.info("Selected size: " + this.selectedLogs.size());
		log.info("Force release to appId: " + forceAppId + " and release tag: " + releasetag);
		int count=0;
		int existsFiles = 0;
		ConnectDB db =new ConnectDB();
		
		String query = "";
		if(this.selectedLogs.size()>0)
		{
			
			for(int i=0;i<this.selectedLogs.size();i++)
			{
				String userLog = "INSERT INTO imp_user_log (sn,logtype,logdetail,username,logdate) "  
								+ " VALUES ('1', 'FORCE_RELTAG', " 
								+ " 'APPID: "+ getAppid() +" | DMFILEID:" + this.selectedLogs.get(i).getDmfileid() + " | SN:" + this.selectedLogs.get(i).getSn() + " | FORCE RELEASED FROM '||(SELECT reltag FROM imp_files_reltag_reln WHERE sn='" + this.selectedLogs.get(i).getSn() + "')||' TO "+releasetag+"', '"
								+ this.userinfo.getFullname() + "', SYSDATE)";
				log.info("User Log query: " + userLog);
				try {
					db.initialize();
				} catch (Exception e) {
					log.info("The user log in force release can not be inserted with: " + e.getMessage());
				}
				//query = "update imp_files_reltag_reln set reltag='"+releasetag+"' where dmfileid='"+this.selectedLogs.get(i).getDmfileid()+"' AND reltag='" + this.selectedLogs.get(i).getReleasetag() + "'";
				
				String stat = "";
				try {
					String checkQuery = "SELECT * FROM imp_files_reltag_reln WHERE filename=(SELECT filename FROM imp_files_reltag_reln WHERE sn='" + this.selectedLogs.get(i).getSn() + "')" +
										" AND dmfileid=(SELECT dmfileid FROM imp_files_reltag_reln WHERE sn='"+ this.selectedLogs.get(i).getSn() +"') AND app_id='" + forceAppId + "' AND reltag='" + releasetag + "'";
					log.info("Check Query is: " + checkQuery);
					List<List<String>> checkList = db.resultSetToListOfList(checkQuery);
					query = "update imp_files_reltag_reln set app_id='"+forceAppId+"', reltag='"+releasetag+"', releaseflag='F' where sn = '"+this.selectedLogs.get(i).getSn()+"'";
					log.info("Update query: " + query);
					log.info("The size of check list is: " + checkList.size());
					if (checkList.size() > 1) {
						log.info("The file already exists in this release tag. No need to force.");
						existsFiles++;
					} else {
						db.executeDML(userLog);
						stat = db.executeDML(query);
					}
					db.endConnection();
				} catch (Exception e) {
					log.info("The error is: " + e.getMessage());
				}
				handleFilterChange();
				if(stat.compareTo("1")==0)
				{
					count++;	
				} 
			}
			if(count>0 || existsFiles>0)
			{				
				if (count > 0 && existsFiles == 0) {
					displayInfoMessageToUser(count + " files have been tagged to " + releasetag, "FORCE RELEASE");
				} else if (count == 0 && existsFiles > 0) {
					displayInfoMessageToUser(existsFiles + " files were not tagged since they already exists in " + releasetag , "FORCE RELEASE PROBLEM");
				} else if (count > 0 && existsFiles > 0) {
					displayInfoMessageToUser(count + " files have been tagged to " + releasetag, "FORCE RELEASE");
					displayInfoMessageToUser(existsFiles + " files were not tagged since they already exists in " + releasetag , "FORCE RELEASE PROBLEM");
				}
				RequestContext.getCurrentInstance().execute("PF('confirmD').hide();");
				RequestContext.getCurrentInstance().execute("PF('forceConfirmD').hide();");
				submitFilters();
			}
			else
			{
				displayErrorMessageToUser("No files are in hold to be tagged to release tag", "FORCE RELEASE");
				RequestContext.getCurrentInstance().execute("PF('confirmD').hide();");
				RequestContext.getCurrentInstance().execute("PF('forceConfirmD').hide();");
			}
			
		}
		else
		{
			displayErrorMessageToUser("No files selected", "Select Files");
		}
	}

	public void ForceFilesWithPrev(String releasetag,String forceAppId)
	{
		log.info("Selected Log size: " + this.selectedLogs.size());
		int count=0;
		int existsFiles = 0;
		ConnectDB db =new ConnectDB();
		db.initialize();
		String query = "";
		if(this.selectedLogs.size()>0)
		{
			
			for(int i=0;i<this.selectedLogs.size();i++)
			{
				String userLog = "INSERT INTO imp_user_log (sn,logtype,logdetail,username,logdate) "  
						+ " VALUES ('1', 'FORCE_RELTAG', " 
						+ " 'APPID: "+ getAppid() +" | DMFILEID:" + this.selectedLogs.get(i).getDmfileid() + " | SN:" + this.selectedLogs.get(i).getSn() + " | FORCE RELEASED FROM '||(SELECT reltag FROM imp_files_reltag_reln WHERE sn='" + this.selectedLogs.get(i).getSn() + "')||' TO "+releasetag+"', '"
						+ this.userinfo.getFullname() + "', SYSDATE)";
				/*try {					
				} catch (Exception e) {
					log.info("The user log in force release can not be inserted with: " + e.getMessage());
				}*/
				String checkQuery = "SELECT * FROM imp_files_reltag_reln WHERE filename='" + this.selectedLogs.get(i).getFilename() +
						"' AND dmfileid = '" + this.selectedLogs.get(i).getDmfileid() + "' AND app_id='" + forceAppId + "' AND reltag='" + releasetag + "'";
				log.info("Check Query is: " + checkQuery);
				//query = "insert into imp_files_reltag_reln set reltag='"+releasetag+"' where dmfileid='"+this.selectedLogs.get(i).getDmfileid()+"'";
				query = "INSERT INTO imp_files_reltag_reln (DMFILEID,FILENAME,APP_ID,RELTAG,CLIENTID,RELEASEFLAG) VALUES ('" +
						this.selectedLogs.get(i).getDmfileid() + "','" +
						this.selectedLogs.get(i).getFilename() + "','" +
						forceAppId + "','" +
						releasetag + "',(SELECT clientid FROM imp_files_reltag_reln WHERE sn='"+this.selectedLogs.get(i).getSn()+"'), 'F')";
						//forceAppId.substring(0, 3) + "', 'F')";
				log.info("New insertion query is: " + query);
				String stat = "";
				try {
					db.initialize();
					List<List<String>> checkList = db.resultSetToListOfList(checkQuery);
					if (checkList.size() > 1) {
						log.info("The file already exists in this release tag. No need to force.");
						existsFiles++;
					} else {		
						db.executeDML(userLog);					
						stat =  db.executeDML(query);
					}
					db.endConnection();
					log.info("The insert query is: " + query);
				} catch (Exception e) {
					log.info("There is a problem while inserting into userlog or relation table: " + e.getMessage());
				}
				handleFilterChange();
				if(stat.compareTo("1")==0)
				{
					count++;
					
				}
					 
			}
			if(count > 0 || existsFiles > 0)
			{
				if (count > 0 && existsFiles == 0) {
					displayInfoMessageToUser(count + " files have been inserted to " + releasetag, "FORCE RELEASE");
				} else if (count == 0 && existsFiles > 0) {
					displayInfoMessageToUser(existsFiles + " files were not tagged since they already exists in " + releasetag , "FORCE RELEASE PROBLEM");
				} else if (count > 0 && existsFiles > 0) {
					displayInfoMessageToUser(count + " files have been inserted to " + releasetag, "FORCE RELEASE");
					displayInfoMessageToUser(existsFiles + " files were not tagged since they already exists in " + releasetag , "FORCE RELEASE PROBLEM");
				}
				RequestContext.getCurrentInstance().execute("PF('confirmD').hide();");
				RequestContext.getCurrentInstance().execute("PF('forceConfirmD').hide();");
				submitFilters();
			}
			else
			{
				displayErrorMessageToUser("No files are added to be tagged to release tag", "FORCE RELEASE");
				RequestContext.getCurrentInstance().execute("PF('confirmD').hide();");
				RequestContext.getCurrentInstance().execute("PF('forceConfirmD').hide();");
			}
			
		}
		else
		{
			displayErrorMessageToUser("No files selected", "Select Files");
		}
	}
	
	public ArrayList<String> getListofAppReleaseTagsToTag() {
		return listofAppReleaseTagsToTag;
	}

	public void setListofAppReleaseTagsToTag(
			ArrayList<String> listofAppReleaseTagsToTag) {
		this.listofAppReleaseTagsToTag = listofAppReleaseTagsToTag;
	}

	public String getReleaseTagToTag() {
		return releaseTagToTag;
	}

	public void setReleaseTagToTag(String releaseTagToTag) {
		this.releaseTagToTag = releaseTagToTag;
	}

}
