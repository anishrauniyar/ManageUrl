package com.vit.ai.releasetag.dao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.releasetag.model.ReleaseTagModel;
import com.vit.dbconnection.ConnectDB;

public class ReleaseTagDAO {

	private ArrayList<ReleaseTagModel> listofFiles;
	
	private static Logger log = Logger.getLogger(ReleaseTagDAO.class);

	public ArrayList<ReleaseTagModel> getListofFiles() {
		return listofFiles;
	}

	public void setListofFiles(ArrayList<ReleaseTagModel> listofFiles) {
		this.listofFiles = listofFiles;
	}

	public ArrayList<ReleaseTagModel> getAllFilesByAppReleaseTag(
			String releaseTag, String appid) {

		this.listofFiles = new ArrayList<>();
		String query = "";
		if (releaseTag.equalsIgnoreCase("UNKNOWN")) {
			query = "select app_id,a.dmfileid,a.fileid,a.filename,payor,datatype,layoutid,RELTAG AS releasetag,processstatus,'UNKNOWN' AS clientreleasetag,b.sn " + 
					"FROM aip_dashboard_inventory a left JOIN imp_files_reltag_reln b ON b.dmfileid = a.dmfileid AND b.filename = a.filename " +
					"WHERE b.clientid = (SELECT a.STANDARDCLIENTID FROM cpd.cp_clientstandardization@"+AIConstant.CPD_LINK+" a left JOIN cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" b ON a.LEGACYCLIENTID = b.LEGACYCLIENTID " +
					"WHERE b.applicationid = '"+appid+"') AND b.reltag = 'UNKNOWN'";
		} else {
			query = "select app_id,a.dmfileid,a.fileid,a.filename,payor,datatype,layoutid,RELTAG AS releasetag,processstatus,c.releasetagid AS clientreleasetag,b.sn FROM AIPDB.aip_dashboard_inventory a left JOIN AIPDB.imp_files_reltag_reln b ON b.dmfileid = a.dmfileid AND b.filename = a.filename left JOIN cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+" c ON b.reltag = c.releasetagidbyapp where reltag='"
				+ releaseTag + "' AND app_id = '" + appid + "'";
		}
		
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					ReleaseTagModel model = new ReleaseTagModel(rs.get(i)
							.get(0), rs.get(i).get(1), rs.get(i).get(2), rs
							.get(i).get(3), rs.get(i).get(4), rs.get(i).get(5),
							rs.get(i).get(6), rs.get(i).get(7), rs.get(i)
									.get(8), rs.get(i).get(9), rs.get(i).get(10));
					this.listofFiles.add(model);
				}
			}
		}

		log.info(query);
		log.info(this.listofFiles.size());
		return listofFiles;

	}
	
	public ArrayList<ReleaseTagModel> getAllFilesByClientReleaseTag(
			String releaseTag, String appid) {

		this.listofFiles = new ArrayList<>();
		String query = "select app_id,a.dmfileid,a.fileid,a.filename,payor,datatype,layoutid,RELTAG AS releasetag,processstatus,c.releasetagid AS clientreleasetag,b.sn FROM AIPDB.aip_dashboard_inventory a left JOIN AIPDB.imp_files_reltag_reln b ON b.dmfileid = a.dmfileid AND b.filename = a.filename left JOIN cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+" c ON b.reltag = c.releasetagidbyapp where releasetagid='"
				+ releaseTag + "' AND app_id = '" + appid + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 1) {
				for (int i = 1; i < rs.size(); i++) {
					ReleaseTagModel model = new ReleaseTagModel(rs.get(i)
							.get(0), rs.get(i).get(1), rs.get(i).get(2), rs
							.get(i).get(3), rs.get(i).get(4), rs.get(i).get(5),
							rs.get(i).get(6), rs.get(i).get(7), rs.get(i)
									.get(8), rs.get(i).get(9), rs.get(i).get(10));
					this.listofFiles.add(model);
				}
			}
		}

		return listofFiles;

	}
	
	public ArrayList<String> getListofAppReleaseTag(String appid)
	{
		ArrayList<String> releaseTags = new ArrayList<>();
		
		//String query = "select distinct reltag from imp_files_reltag_reln where app_id = '"+appid+"'";
		String query = "SELECT DISTINCT(releasetagidbyapp) FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+appid+"'" + 
						" UNION SELECT DISTINCT RELTAG FROM imp_files_reltag_reln WHERE app_id = '"+appid+"'";
		log.info(query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					releaseTags.add(rs.get(i).get(0));
				}
			}
		}
		releaseTags.add("UNKNOWN");
		
		
		return releaseTags;
	}
	
	
	public ArrayList<String> getListofAppReleaseTagToTag(String appid)
	{
		ArrayList<String> releaseTags = new ArrayList<>();
		
		String query = "SELECT DISTINCT(releasetagidbyapp) FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+appid+"'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					releaseTags.add(rs.get(i).get(0));
				}
			}
		}
		
		
		return releaseTags;
	}
	
	public ArrayList<String> getListofClientReleaseTag(String appid)
	{
		ArrayList<String> releaseTags = new ArrayList<>();

		String query = "SELECT DISTINCT(releasetagidbyapp) FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+appid+"'";
		//String query = "select distinct reltag from imp_files_reltag_reln where app_id = '"+appid+"'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					releaseTags.add(rs.get(i).get(0));
				}
			}
		}
		
		
		return releaseTags;
	}
	
	
	public LinkedHashMap<String,String> getListofAppids()
	{
		LinkedHashMap<String,String> appids = new LinkedHashMap<>();
		//String query = "select distinct applicationid from cpd.cp_clientapplication@nvscrubstgp1";
		//String query = "SELECT DISTINCT applicationname || '('||APPLICATIONID||')' AS app_name,applicationid FROM cpd.cp_clientapplication@nvscrubstgp1 order by app_name asc";
		String query = "SELECT DISTINCT APPLICATIONID || ' (' || applicationname || ')' AS app_name,applicationid FROM cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" order by applicationid asc";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					appids.put(rs.get(i).get(0),rs.get(i).get(1));
				}
			}
		}
		return appids;
	}

	public ArrayList<String> getListofForceAppids(String appid) {
		// TODO Auto-generated method stub
		ArrayList<String> appIds = new ArrayList<>();
		//String query = "select distinct applicationid from cpd.cp_clientapplication@nvscrubstgp1";
		//String query = "SELECT DISTINCT applicationname || '('||APPLICATIONID||')' AS app_name,applicationid FROM cpd.cp_clientapplication@nvscrubstgp1 order by app_name asc";
		//String query = "SELECT DISTINCT applicationid FROM cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" WHERE legacyclientid ='"+appid.substring(0, 3)+"'";
		String query = "SELECT distinct a.applicationid FROM cpd.cp_clientapplication@"+AIConstant.CPD_LINK+" a left JOIN cpd.cp_clientstandardization@"+AIConstant.CPD_LINK+" b ON a.LEGACYCLIENTID = b.LEGACYCLIENTID WHERE b.STANDARDCLIENTID = '"+appid.substring(0, 3)+"'";
		log.info("The query for force release for appid is: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				for(int i=1;i<rs.size();i++)
				{
					appIds.add(rs.get(i).get(0));
				}
			}
		}
				
		return appIds;
	}

	
}
