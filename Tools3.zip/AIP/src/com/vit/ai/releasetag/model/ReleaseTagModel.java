package com.vit.ai.releasetag.model;

public class ReleaseTagModel {

	private String appid = "";
	private String dmfileid = "";
	private String fileid = "";
	private String filename = "";
	private String payor = "";
	private String datatype = "";
	private String layoutid = "";
	private String releasetag = "";
	private String processstatus = "";
	private String clientreleasetag = "";
	private String sn = "";
	

	public ReleaseTagModel(String appid, String dmfileid, String fileid,
			String filename, String payor, String datatype, String layoutid,
			String releasetag, String processstatus, String clientreleasetag, String sn) {
		super();
		this.appid = appid;
		this.dmfileid = dmfileid;
		this.fileid = fileid;
		this.filename = filename;
		this.payor = payor;
		this.datatype = datatype;
		this.layoutid = layoutid;
		this.releasetag = releasetag;
		this.processstatus = processstatus;
		this.clientreleasetag = clientreleasetag;
		this.sn = sn;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getDmfileid() {
		return dmfileid;
	}

	public void setDmfileid(String dmfileid) {
		this.dmfileid = dmfileid;
	}

	public String getFileid() {
		return fileid;
	}

	public void setFileid(String fileid) {
		this.fileid = fileid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getPayor() {
		return payor;
	}

	public void setPayor(String payor) {
		this.payor = payor;
	}

	public String getDatatype() {
		return datatype;
	}

	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}

	public String getLayoutid() {
		return layoutid;
	}

	public void setLayoutid(String layoutid) {
		this.layoutid = layoutid;
	}

	public String getReleasetag() {
		return releasetag;
	}

	public void setReleasetag(String releasetag) {
		this.releasetag = releasetag;
	}

	public String getProcessstatus() {
		return processstatus;
	}

	public void setProcessstatus(String processstatus) {
		this.processstatus = processstatus;
	}

	public String getClientreleasetag() {
		return clientreleasetag;
	}

	public void setClientreleasetag(String clientreleasetag) {
		this.clientreleasetag = clientreleasetag;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	

}
