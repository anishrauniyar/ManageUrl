/* 
 *Class Name : MappingModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.scrub.controller;

import org.primefaces.event.NodeSelectEvent;

/**
 * Class for advanced mapping
 * 
 * @author Binesh Sah
 * 
 * @version 1.0 25 Nov 2014
 */
public class MappingModel {

	private int sn;
	private String scrubFieldName;
	private String scrubLogic;
	private String originalScrubLogic;
	private String originalGlobalScrubLogic;;
	private String filterValue;
	private boolean fieldLoadStatus;
	private String globalScrubLogic;
	private String prevscrubFieldName;
	private String remark;
	private String subLayoutID;

	public MappingModel(int sn,String subLayoutID,String prevscrubFieldName,
			String scrubFieldName, String globalScrubLogic, String scrubLogic,
			 String remark) {
		super();
		this.setSn(sn);
		this.subLayoutID=subLayoutID;
		this.prevscrubFieldName = prevscrubFieldName;
		this.scrubFieldName = scrubFieldName;
	
		this.globalScrubLogic = globalScrubLogic;
		setOriginalGlobalScrubLogic(globalScrubLogic);
		this.scrubLogic = scrubLogic;
		setOriginalScrubLogic(scrubLogic);
		
		this.remark = remark;
	
		
	}
	public MappingModel(int sn,String prevscrubFieldName,
			String scrubFieldName, String globalScrubLogic, String scrubLogic,
			 String remark) {
		super();
		this.setSn(sn);
		
		this.prevscrubFieldName = prevscrubFieldName;
		this.scrubFieldName = scrubFieldName;
	
		this.globalScrubLogic = globalScrubLogic;
		setOriginalGlobalScrubLogic(globalScrubLogic);
		this.scrubLogic = scrubLogic;
		setOriginalScrubLogic(scrubLogic);
		
		this.remark = remark;
	
		
	}

	public String getScrubFieldName() {
		return scrubFieldName;
	}

	public void setScrubFieldName(String scrubFieldName) {
		this.scrubFieldName = scrubFieldName;
	}

	public String getScrubLogic() {
		return scrubLogic;
	}

	public void setScrubLogic(String scrubLogic) {
		this.scrubLogic = scrubLogic;
	}

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public void onNodeSelect(NodeSelectEvent event) {
		this.scrubLogic = this.scrubLogic + event.getTreeNode().toString();
	}

	public void onGlobalNodeSelect(NodeSelectEvent event) {
		this.globalScrubLogic = this.globalScrubLogic
				+ event.getTreeNode().toString();
	}


	public String getOriginalScrubLogic() {
		return originalScrubLogic;
	}

	public void setOriginalScrubLogic(String originalScrubLogic) {
		this.originalScrubLogic = originalScrubLogic;
	}

	public String getFilterValue() {
		return filterValue;
	}

	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}

	public String getPrevscrubFieldName() {
		return prevscrubFieldName;
	}

	public void setPrevscrubFieldName(String prevscrubFieldName) {
		this.prevscrubFieldName = prevscrubFieldName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getGlobalScrubLogic() {
		return globalScrubLogic;
	}

	public void setGlobalScrubLogic(String globalScrubLogic) {
		this.globalScrubLogic = globalScrubLogic;
	}

	public String getOriginalGlobalScrubLogic() {
		return originalGlobalScrubLogic;
	}

	public void setOriginalGlobalScrubLogic(String originalGlobalScrubLogic) {
		this.originalGlobalScrubLogic = originalGlobalScrubLogic;
	}

	public boolean isFieldLoadStatus() {
		return fieldLoadStatus;
	}

	public void setFieldLoadStatus(boolean fieldLoadStatus) {
		this.fieldLoadStatus = fieldLoadStatus;
	}

	public String getSubLayoutID() {
		return subLayoutID;
	}

	public void setSubLayoutID(String subLayoutID) {
		this.subLayoutID = subLayoutID;
	}

}
