/*
 *Class Name : ScrubMappingBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.scrub.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.context.RequestContext;
import org.primefaces.extensions.event.CompleteEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import com.vit.ai.commons.controller.FileController;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.script.GeneratePreScrubScript;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 25 Nov 2014
 * 
 */
@ManagedBean
@ViewScoped
public class ScrubMappingBean extends AbstractController implements
		Serializable {

	private static Logger log = Logger.getLogger(ScrubMappingBean.class
			.getName());
	private static final long serialVersionUID = 1L;
	private ArrayList<MappingModel> scrubFieldMappings;
	private ArrayList<MappingModel> mdrscrubFieldMappings;
	private ArrayList<String> hiFields;
	private ArrayList<String> functions;
	private ArrayList<String> operators;
	private TreeNode root;
	private TreeNode selectedNode;
	private String layoutID="";
	private String clientID;
	private String payerID;
	private String clientid;
	private boolean generic = true;
	
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String layoutstatus="";
	private String subLayoutid="";
	private String existSublayoutid="";
	private String mappedSublayoutid="";
	private String mappedSublayoutidMDR="";
	private String mappingType="";
	public String getMappedSublayoutidMDR() {
		return mappedSublayoutidMDR;
	}

	public void setMappedSublayoutidMDR(String mappedSublayoutidMDR) {
		this.mappedSublayoutidMDR = mappedSublayoutidMDR;
	}

	private ArrayList<String> subLayoutids;

	public String getSubLayoutid() {
		return subLayoutid;
	}

	public void setSubLayoutid(String subLayoutid) {
		this.subLayoutid = subLayoutid;
	}

	public ArrayList<String> getSubLayoutids() {
		return subLayoutids;
	}

	public void setSubLayoutids(ArrayList<String> subLayoutids) {
		if(this.getLayoutID()!=""){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT SUBLAYOUTID FROM IMP_SUB_LAYOUTS WHERE LAYOUTID='"+this.getLayoutID()+"' AND  SUBLAYOUTDESC!='CONTROLTOTAL' ORDER BY SUBLAYOUTID ASC";
		log.info(" Sub layouts " + query);
		List<List<String>> sublayoutList = db.resultSetToListOfList(query);
		db.endConnection();

		if (sublayoutList.size() > 0) {
			for (int i = 1; i < sublayoutList.size(); i++) {
				subLayoutids.add(sublayoutList.get(i).get(0));
			}
		}
	}
		this.subLayoutids = subLayoutids;
	}

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	ArrayList<String> suggestions;

	private DefaultStreamedContent preScrubScript;

	public ScrubMappingBean() {

		init();

	}

	public void init() {
		
		FacesContext context = FacesContext.getCurrentInstance();
		Map<String, String> paramMap = context.getExternalContext()
				.getRequestParameterMap();
		setClientID(paramMap.get("clientID"));
		setLayoutID(paramMap.get("lid"));
		setLayoutstatus(paramMap.get("layoutstatus"));
		if(this.layoutID!=null && !this.layoutID.equals("")){
			retrieveSublayoutid();
			retrieveSublayoutidMDR();
		}
		System.out.println("Layout Status : " + this.layoutstatus);

		if (getClientID() != null && !getClientID().equals("")) {

			setGeneric(false);
		}
		System.out.println("Clientid " + clientID);
		setPayerID(payerID);

		scrubFieldMappings = new ArrayList<MappingModel>();
		setScrubFieldMappings(scrubFieldMappings);
		
		mdrscrubFieldMappings = new ArrayList<MappingModel>();
		setMdrscrubFieldMappings(mdrscrubFieldMappings);
		
		hiFields = new ArrayList<String>();
		operators = new ArrayList<String>();
		functions = new ArrayList<String>();
		root = new DefaultTreeNode("Root", null);
		subLayoutids = new ArrayList<String>();
		setSubLayoutids(subLayoutids);
		suggestions = new ArrayList<String>();
		if(getSubLayoutid()!=null && ! getSubLayoutid().equals("")){
			setHiFields(hiFields);
			setFunctions(functions);
			setOperators(operators);
			TreeNode fieldsTree = new DefaultTreeNode("Layout Fields", root);
			TreeNode functionsTree = new DefaultTreeNode("Functions", root);
			TreeNode operatorsTree = new DefaultTreeNode("Operators", root);

			fieldsTree.setSelectable(false);
			functionsTree.setSelectable(false);
			operatorsTree.setSelectable(false);

			ArrayList<TreeNode> rootNodes = new ArrayList<TreeNode>();
			ArrayList<TreeNode> rootNodes2 = new ArrayList<TreeNode>();
			ArrayList<TreeNode> rootNodes3 = new ArrayList<TreeNode>();

			for (int i = 0; i < hiFields.size(); i++) {
				rootNodes.add(new DefaultTreeNode(hiFields.get(i).toUpperCase(),
						fieldsTree));
			}

			for (int i = 0; i < functions.size(); i++) {
				rootNodes2.add(new DefaultTreeNode(functions.get(i).toUpperCase(),
						functionsTree));
			}
			for (int i = 0; i < operators.size(); i++) {
				rootNodes3.add(new DefaultTreeNode(operators.get(i).toUpperCase(),
						operatorsTree));
			}

			suggestions = new ArrayList<String>();
			suggestions.addAll(hiFields);
			suggestions.addAll(functions);
		}
	}
	public void retrieveSublayoutid(){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT DISTINCT SUBLAYOUTID FROM IMP_CTRL_RULES_MASTER WHERE LAYOUTID='"+this.layoutID+"' AND   SUBLAYOUTID IS NOT NULL";
		log.info("Mapped Sub layoutID " + query);
		List<List<String>> sublayoutList = db.resultSetToListOfList(query);
		db.endConnection();

		if (sublayoutList.size() >=2 ) {
			System.out.println("Sub layoutid "+sublayoutList.get(1).get(0));
					this.setMappedSublayoutid(sublayoutList.get(1).get(0));
		}else{
			setMappedSublayoutid("");
		}
	}
	public void retrieveSublayoutidMDR(){
		this.setMappedSublayoutidMDR("1");
		
		
	}
	
	public void loadFieldforSublayout(String mappingType){
		try{
			if(mappingType.equals("MDR")){
				setMappedSublayoutidMDR("1");
				setMappingType(mappingType);
			}else{
			setMappedSublayoutid(this.subLayoutid);
			}
			
			String tableQuery = "";
			hiFields = new ArrayList<String>();
			setHiFields(hiFields);

			functions = new ArrayList<String>();
			setFunctions(functions);

			operators = new ArrayList<String>();
			setOperators(operators);

			/* Prepare tree list of fields and function */
			root = new DefaultTreeNode("Root", null);
			TreeNode fieldsTree = new DefaultTreeNode("Layout Fields", root);
			TreeNode functionsTree = new DefaultTreeNode("Functions", root);
			TreeNode operatorsTree = new DefaultTreeNode("Operators", root);

			fieldsTree.setSelectable(false);
			functionsTree.setSelectable(false);
			operatorsTree.setSelectable(false);

			ArrayList<TreeNode> rootNodes = new ArrayList<TreeNode>();
			ArrayList<TreeNode> rootNodes2 = new ArrayList<TreeNode>();
			ArrayList<TreeNode> rootNodes3 = new ArrayList<TreeNode>();

			for (int i = 0; i < hiFields.size(); i++) {
				rootNodes.add(new DefaultTreeNode(hiFields.get(i).toUpperCase(),
						fieldsTree));
			}

			for (int i = 0; i < functions.size(); i++) {
				rootNodes2.add(new DefaultTreeNode(functions.get(i).toUpperCase(),
						functionsTree));
			}
			for (int i = 0; i < operators.size(); i++) {
				rootNodes3.add(new DefaultTreeNode(operators.get(i).toUpperCase(),
						operatorsTree));
			}

			suggestions = new ArrayList<String>();
			suggestions.addAll(hiFields);
			suggestions.addAll(functions);
			ConnectDB db = new ConnectDB();
			db.initialize();
			if(mappingType.equals("MDR")){
				tableQuery = "CREATE TABLE ZZZ_" + layoutID + "_" + "1 "
						+ " (";
			}else{
			tableQuery = "CREATE TABLE ZZZ_" + layoutID + "_" + this.subLayoutid
					+ " (";
			}
			String getcol_query = "  SELECT COLUMNNAME||' '||DATATYPE||CASE WHEN Upper(DATATYPE)='NUMBER' THEN '(19,4)' "
					+ "     WHEN Upper(DATATYPE)='DATE' THEN '' "
					+ "     WHEN Upper(DATATYPE)='INTEGER' THEN '' "
					+ "     WHEN Upper(DATATYPE)='TIMESTAMP' THEN '' "
					+ "     ELSE  '('||FIELDLENGTH||')' "
					+ "     END||',' "
					+ "     FROM IMP_LAYOUTS_FIELDS  "
					+ "     WHERE LAYOUTID='"
					+ layoutID
					+ "' AND SUBLAYOUTID='";
			if(mappingType.equals("MDR")){
				getcol_query+= "1' "
				+ "     ORDER BY COLUMNID  ";
			}else{
				getcol_query+= this.subLayoutid
				+ "' "
				+ "     ORDER BY COLUMNID  ";
			}
					
			System.out.println("Get col query "+getcol_query);
			List<List<String>> fieldList = db
					.resultSetToListOfList(getcol_query);
			db.endConnection();
			if (fieldList.size() > 0) {
				for (int i = 1; i < fieldList.size(); i++) {
					tableQuery = tableQuery + fieldList.get(i).get(0);
				}
				tableQuery = tableQuery.substring(0, tableQuery.length() - 1);
			}
			tableQuery += ") NOLOGGING";

			ConnectDB tempdb = new ConnectDB();
			tempdb.initialize(AIConstant.RAC_SERVER_NAME,
					AIConstant.RAC_SERVICE_PORT, AIConstant.RAC_SERVICE_SID,
					AIConstant.TEST_SCHEMA_NAME, "LOCAL");
			System.out.println("Creating temporary table "+tableQuery);
			if(mappingType.equals("MDR")){
				tempdb.createTable(getLayoutID(), "1 ", tableQuery);
			}else{
				tempdb.createTable(getLayoutID(), this.subLayoutid, tableQuery);
			}
			tempdb.endConnection();
			System.out.println();
		
		}catch(Exception e){
			displayErrorMessageToUser("Unexpected Error occured.Please try again!! "+e.getMessage(), "Error");
		}
		
	}
	

	public ArrayList<String> getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(ArrayList<String> suggestions) {
		this.suggestions = suggestions;
	}

	public ArrayList<MappingModel> getScrubFieldMappings() {
		return scrubFieldMappings;
	}

	public void setScrubFieldMappings(ArrayList<MappingModel> scrubFieldMappings) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "";

			query = "SELECT * FROM ( "
					+ " SELECT A.LAYOUTTYPE  ,B.SUBLAYOUTID , A.COLUMNNAME  ,COALESCE (B.RULE,A.DEFAULTRULE) GLOBALRULE ,null CLIENTRULE ,B.remark "
					+ " FROM RPT_MASTER_FIELDS  A LEFT JOIN "
					+ " (SELECT A.*   FROM IMP_CTRL_RULES_MASTER A WHERE LAYOUTID='"
					+ getLayoutID()
					+ "') B "
					+ " ON  A.COLUMNNAME = B.TGTFIELD "

					+ " WHERE A.REPORT_TYPE='CTL' AND A.LAYOUTTYPE=(SELECT DATATYPE FROM IMP_LAYOUTS WHERE LAYOUTID='"
					+ getLayoutID() + "')   ) ORDER BY  COLUMNNAME ";

		
		log.info(" Scrub query " + query);
		List<List<String>> mList = db.resultSetToListOfList(query);

		if (mList.size() > 0) {

			for (int i = 1; i < mList.size(); i++) {
				scrubFieldMappings.add(new MappingModel(i, mList.get(i).get(1),mList.get(i - 1)
						.get(2), mList.get(i).get(2), mList.get(i).get(3),
						mList.get(i).get(4), mList.get(i).get(5)));
			}
			
		}

		this.scrubFieldMappings = scrubFieldMappings;

	}

	public ArrayList<String> getHiFields() {
		return hiFields;
	}

	public void setHiFields(ArrayList<String> hiFields) {
		if(this.subLayoutid!=null &&!this.subLayoutid.equals("")){
			
			ConnectDB db = new ConnectDB();
			db.initialize();
			String query ="";
			if(this.mappingType.equals("MDR")){
				query = "SELECT COLUMNNAME FROM "
						+ " IMP_LAYOUTS_FIELDS WHERE Sublayoutid='1'  AND LAYOUTID='"
						+ getLayoutID() + "' ORDER BY 1";
			}else{
				query= "SELECT COLUMNNAME FROM "
						+ " IMP_LAYOUTS_FIELDS WHERE Sublayoutid='"+this.getSubLayoutid()+"'  AND LAYOUTID='"
						+ getLayoutID() + "' ORDER BY 1";
			}
			
			log.info(" Hi Fields " + query);
			List<List<String>> fList = db.resultSetToListOfList(query);
			db.endConnection();

			if (fList.size() > 0) {
				
				for (int i = 1; i < fList.size(); i++) {
					hiFields.add(fList.get(i).get(0));
				}
			}
		}

		this.hiFields = hiFields;

	}

	public TreeNode getRoot() {
		return root;
	}

	public TreeNode getSelectedNode() {
		return selectedNode;
	}

	public void setRoot(TreeNode root) {
		this.root = root;
	}

	public void setSelectedNode(TreeNode selectedNode) {
		this.selectedNode = selectedNode;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String LayoutID) {
		this.layoutID = LayoutID;
	}

	public ArrayList<String> getFunctions() {
		return functions;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public void setFunctions(ArrayList<String> functions) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT FUNCTION_FORMAT FROM "
				+ " IMP_CTRL_RULE_FUNCTION WHERE PARAMETER_NUM<>'-1' ORDER BY FUNCTIONNAME ";

		List<List<String>> fList = db.resultSetToListOfList(query);
		db.endConnection();
		if (fList.size() > 0) {
			for (int i = 1; i < fList.size(); i++) {
				functions.add(fList.get(i).get(0));
			}
		}

		this.functions = functions;
	}

	public List<String> complete(final CompleteEvent event) {
		String queryString = event.getToken().toLowerCase();

		ArrayList<String> to_ret = new ArrayList<String>();

		for (int i = 0; i < suggestions.size(); i++) {
			if (suggestions.get(i).toLowerCase().startsWith(queryString)) {
				to_ret.add(suggestions.get(i));
			}
		}
		return to_ret;

	}

	public void handleCancel(MappingModel mappingModel) {
		mappingModel.setGlobalScrubLogic(mappingModel
				.getOriginalGlobalScrubLogic());
	}

	public void handleSave(MappingModel mappingModel) {

		if (!mappingModel.getGlobalScrubLogic().equals(
				mappingModel.getOriginalGlobalScrubLogic())
				&& !mappingModel.getGlobalScrubLogic().startsWith("form:")) {

			String result = "";

			FacesMessage msg = null;

			
			System.out.println("Field name "+mappingModel.getScrubFieldName());
			if(!mappingModel.getScrubFieldName().equals("RECORD_CNT")){
				ConnectDB db1 = new ConnectDB();
				db1.initialize();
				
				String check_query ="SELECT DISTINCT SUBLAYOUTID FROM IMP_CTRL_RULES_MASTER WHERE LAYOUTID='"+this.layoutID+"' AND SUBLAYOUTID IS NOT NULL";
				List<List<String>> sublayoutList = db1.resultSetToListOfList(check_query);
				db1.endConnection();
				if (sublayoutList.size()>=2) {
					setExistSublayoutid(sublayoutList.get(1).get(0));
					
					if(!sublayoutList.get(1).get(0).equals(this.subLayoutid)){
						setExistSublayoutid(sublayoutList.get(1).get(0));
						System.out.println("Existing subllayout "+existSublayoutid +" sublayout "+this.subLayoutid);
						RequestContext.getCurrentInstance().execute("PF('vhconfirmDialog').show();");
					return;
					}
				}
				
				String chk = "1";
				
				if (!mappingModel.getGlobalScrubLogic().equals("")
					&& mappingModel.getGlobalScrubLogic() != null) {
				ConnectDB tempdb = new ConnectDB();
				tempdb.initialize(AIConstant.RAC_SERVER_NAME,
						AIConstant.RAC_SERVICE_PORT,
						AIConstant.RAC_SERVICE_SID,
						AIConstant.TEST_SCHEMA_NAME, "LOCAL");

				chk = checkValidation(
						"SELECT " + mappingModel.getGlobalScrubLogic()
								+ " FROM ZZZ_" + getLayoutID() + "_"+this.subLayoutid, tempdb);
				tempdb.endConnection();
			}

			if (chk.equalsIgnoreCase("1")) {
				

				ConnectDB db = new ConnectDB();
				db.initialize();
				String tableName = "IMP_CTRL_RULES_MASTER";

				String query = "UPDATE  "
						+ tableName
						+ " SET RULE='"
						+ mappingModel.getGlobalScrubLogic().replaceAll("'",
								"''")
						+ "'"
						+ ",dateupdated=sysdate,SUBLAYOUTID='"+this.subLayoutid+"'  WHERE LAYOUTID='"
						+ getLayoutID() + "'  AND TGTFIELD='"
						+ mappingModel.getScrubFieldName() + "' ";

				int rowsAffected = db.update(query);

				if (rowsAffected == -1) {
					mappingModel.setGlobalScrubLogic(mappingModel
							.getOriginalGlobalScrubLogic());
					result = "Error";
				} else if (rowsAffected == 0) {
					query = "INSERT INTO " + tableName
							+ "(LAYOUTID,SUBLAYOUTID ,TGTFIELD, RULE, "
							+ " DATECREATED, CREATEDBY  ";

					query += ") VALUES('"
							+ getLayoutID()
							+ "','"
							+this.subLayoutid+"','"
							+ mappingModel.getScrubFieldName()
							+ "',"
							+ "'"
							+ mappingModel.getGlobalScrubLogic().replaceAll(
									"'", "''") + "',SYSDATE,'"
							+ getUserinfo().getFullname() + "'";

					query += ")";

					result = db.executeDML(query);
				} else {
					result = "1";
				}
				db.endConnection();
			} else {
				mappingModel.setGlobalScrubLogic(mappingModel
						.getOriginalGlobalScrubLogic());

				result = chk;
			}

			if (result.equalsIgnoreCase("1")) {

				mappingModel.setOriginalGlobalScrubLogic(mappingModel
						.getGlobalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Rule For "
						+ mappingModel.getScrubFieldName() + " Changed",
						"New rule:" + mappingModel.getGlobalScrubLogic());
				
				
			} else {
				mappingModel.setGlobalScrubLogic(mappingModel
						.getOriginalGlobalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating Rule For "
								+ mappingModel.getScrubFieldName(), result);
			}

			FacesContext.getCurrentInstance().addMessage(null, msg);
		}else{
			System.out.println("Record cnt");
			System.out.println("Global rule "+mappingModel.getGlobalScrubLogic());
			if( mappingModel.getGlobalScrubLogic().toUpperCase().equals("ALL")|| mappingModel.getGlobalScrubLogic().toUpperCase().equals("")||  mappingModel.getGlobalScrubLogic().equals(this.getMappedSublayoutid())||mappingModel.getGlobalScrubLogic().equals(mappingModel.getSubLayoutID())){
				
				ConnectDB db = new ConnectDB();
				db.initialize();
				String tableName = "IMP_CTRL_RULES_MASTER";

				String query = "UPDATE  "
						+ tableName
						+ " SET RULE='"
						+ mappingModel.getGlobalScrubLogic().replaceAll("'",
								"''")
						+ "'"
						+ ",dateupdated=sysdate,CREATEDBY='"+getUserinfo().getFullname()+"',SUBLAYOUTID='"+this.subLayoutid+"'  WHERE LAYOUTID='"
						+ getLayoutID() + "'  AND TGTFIELD='"
						+ mappingModel.getScrubFieldName() + "' ";

				int rowsAffected = db.update(query);

				if (rowsAffected == -1) {
					mappingModel.setGlobalScrubLogic(mappingModel
							.getOriginalGlobalScrubLogic());
					result = "Error";
				} else if (rowsAffected == 0) {
					query = "INSERT INTO " + tableName
							+ "(LAYOUTID,SUBLAYOUTID ,TGTFIELD, RULE, "
							+ " DATECREATED, CREATEDBY  ";

					query += ") VALUES('"
							+ getLayoutID()
							+ "','"
							+this.subLayoutid+"','"
							+ mappingModel.getScrubFieldName()
							+ "',"
							+ "'"
							+ mappingModel.getGlobalScrubLogic().replaceAll(
									"'", "''") + "',SYSDATE,'"
							+ getUserinfo().getFullname() + "'";

					query += ")";

					result = db.executeDML(query);
				} else {
					result = "1";
				}
				db.endConnection();
			}else{
				result="Error";
			}
			
			if (result.equalsIgnoreCase("1")) {

				mappingModel.setOriginalGlobalScrubLogic(mappingModel
						.getGlobalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Rule For "
						+ mappingModel.getScrubFieldName() + " Changed",
						"New rule:" + mappingModel.getGlobalScrubLogic());
				
				
			} else {
				mappingModel.setGlobalScrubLogic(mappingModel
						.getOriginalGlobalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating Rule For "
								+ mappingModel.getScrubFieldName(), result);
			}

			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}
	}

	public void removeMapping(){
		ConnectDB db = new ConnectDB();
		db.initialize();
		String update_query = "UPDATE  IMP_CTRL_RULES_MASTER"
				+ " SET RULE=''"
			
				+ ",dateupdated=sysdate,SUBLAYOUTID='',CREATEDBY='"+getUserinfo().getFullname()+"'  WHERE LAYOUTID='"
				+ getLayoutID() + "' ";
		String result=db.executeDML(update_query);
		db.endConnection();
		if(result.equals("1")){
			scrubFieldMappings = new ArrayList<MappingModel>();
			setScrubFieldMappings(scrubFieldMappings);
			/*mdrscrubFieldMappings = new ArrayList<MappingModel>();
			setMdrscrubFieldMappings(mdrscrubFieldMappings);*/
			displayInfoMessageToUser("Mapping Deleted for the sublayoutid: "+this.existSublayoutid, "Mapping Deleted");
		}else{
			displayErrorMessageToUser("Error Occured. Please try again", "Delete Failed");
		}

	}
	public void handleClientCancel(MappingModel mappingModel) {
		mappingModel.setScrubLogic(mappingModel.getOriginalScrubLogic());
	}

	public void handleClientMappSave(MappingModel mappingModel) {
		if (!mappingModel.getScrubLogic().equals(
				mappingModel.getOriginalScrubLogic())
				&& !mappingModel.getScrubLogic().startsWith("form:")) {
			String result = "";
			FacesMessage msg = null;

			String chk = "1";
			if (!mappingModel.getScrubLogic().equals("")
					&& mappingModel.getScrubLogic() != null) {
				ConnectDB tempdb = new ConnectDB();
				tempdb.initialize(AIConstant.RAC_SERVER_NAME,
						AIConstant.RAC_SERVICE_PORT,
						AIConstant.RAC_SERVICE_SID,
						AIConstant.TEST_SCHEMA_NAME, "LOCAL");

				chk = checkValidation("SELECT " + mappingModel.getScrubLogic()
						+ " FROM ZZZ_" + getLayoutID() + "_1", tempdb);
				tempdb.endConnection();
			}

			if (chk.equalsIgnoreCase("1")) {
				ConnectDB db = new ConnectDB();
				db.initialize();
				String tableName = "IMP_CTRL_RULES_CLIENT";

				String query = "UPDATE  " + tableName + " SET RULE='"
						+ mappingModel.getScrubLogic().replaceAll("'", "''")
						+ "'" + " WHERE LAYOUTID='" + getLayoutID()
						+ "' AND TGTFIELD='" + mappingModel.getScrubFieldName()
						+ "' ";

				query += " AND CLIENTID='" + getClientID() + "' ";
				int rowsAffected = db.update(query);

				if (rowsAffected == -1) {
					mappingModel.setScrubLogic(mappingModel
							.getOriginalScrubLogic());
					result = "Error";
				} else if (rowsAffected == 0) {
					query = "INSERT INTO " + tableName
							+ "(LAYOUTID, TGTFIELD, RULE, "
							+ " DATECREATED, CREATEDBY ";

					query += ",CLIENTID";

					query += ") VALUES('"
							+ getLayoutID()
							+ "','"
							+ mappingModel.getScrubFieldName()
							+ "',"
							+ "'"
							+ mappingModel.getScrubLogic()
									.replaceAll("'", "''") + "',SYSDATE,'"
							+ getUserinfo().getFullname() + "' ";

					query += ",'" + getClientID() + "' ";

					query += ")";

					result = db.executeDML(query);
				} else {
					result = "1";
				}
				db.endConnection();
			} else {
				mappingModel
						.setScrubLogic(mappingModel.getOriginalScrubLogic());
				result = chk;
			}

			if (result.equalsIgnoreCase("1")) {
				mappingModel
						.setOriginalScrubLogic(mappingModel.getScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Rule For "
						+ mappingModel.getScrubFieldName() + " Changed",
						"New rule:" + mappingModel.getScrubLogic());
			} else {
				mappingModel
						.setScrubLogic(mappingModel.getOriginalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating Rule For "
								+ mappingModel.getScrubFieldName(), result);
			}

			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	public String checkValidation(String query, ConnectDB db) {
		return db.executeDML(query);
	}

	public ArrayList<String> getOperators() {
		return operators;
	}

	public void setOperators(ArrayList<String> operators) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT FUNCTION_FORMAT FROM "
				+ " IMP_CTRL_RULE_FUNCTION WHERE PARAMETER_NUM='-1' ORDER BY FUNCTIONNAME ";

		List<List<String>> oList = db.resultSetToListOfList(query);
		db.endConnection();
		if (oList.size() > 0) {
			for (int i = 1; i < oList.size(); i++) {
				operators.add(oList.get(i).get(0));
			}
		}

		this.operators = operators;
	}

	public boolean isGeneric() {
		return generic;
	}

	public void setGeneric(boolean generic) {
		this.generic = generic;
	}

	public DefaultStreamedContent getPreScrubScript() {
		GeneratePreScrubScript objGPSS = new GeneratePreScrubScript(layoutID,
			this.subLayoutid, clientID, payerID);

		String scriptLocation = AIConstant.PRESCRUB_SCRIPT_DUMP_LOCATION;
		String filename = "PS_" + layoutID + "_1.sql";

		objGPSS.generatePreScrubScript(scrubFieldMappings, scriptLocation);

		FileController objFC = new FileController(scriptLocation + filename);
		setPreScrubScript(objFC.getDownload());
		return preScrubScript;
	}

	public void setPreScrubScript(DefaultStreamedContent preScrubScript) {
		this.preScrubScript = preScrubScript;
	}

	public String getPayerID() {
		return payerID;
	}

	public void setPayerID(String payerID) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "SELECT PAYORID FROM " + " IMP_LAYOUTS WHERE LAYOUTID="
				+ layoutID + "";

		System.out.println(query);

		List<List<String>> pList = db.resultSetToListOfList(query);
		db.endConnection();

		if (pList.size() > 0) {
			payerID = pList.get(1).get(0);
		}
		this.payerID = payerID;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public void saveBusinesslogic(MappingModel mappingModel,
			String businessLogic) {

		ConnectDB db = new ConnectDB();
		db.initialize();

		if (businessLogic != null && !businessLogic.equals("")) {
			String query = "UPDATE IMP_CTRL_RULES_MASTER SET REMARK='"
					+ businessLogic + "'" + " WHERE LAYOUTID='" + getLayoutID()
					+ "' AND TGTFIELD='" + mappingModel.getScrubFieldName()
					+ "' ";

			String result =db.executeDML(query);
			if(result.equals("1")){
				displayInfoMessageToUser("Business Logic changed", "Business Logic ");
			}else{
				displayErrorMessageToUser("Failed to update business logic", "Error");
			}
		} 
		db.endConnection();
	}

	public void saveBusinesslogicMDR(MappingModel mappingModel,
			String businessLogic) {

		ConnectDB db = new ConnectDB();
		db.initialize();

		if (businessLogic != null && !businessLogic.equals("")) {
			String query = "UPDATE MDR_RULES_LAYOUT SET REMARK='"
					+ businessLogic + "'" + " WHERE LAYOUTID='" + getLayoutID()
					+ "' AND TGTFIELD='" + mappingModel.getScrubFieldName()
					+ "' ";

			String result =db.executeDML(query);
			if(result.equals("1")){
				displayInfoMessageToUser("Business Logic changed", "Business Logic ");
			}else{
				displayErrorMessageToUser("Failed to update business logic", "Error");
			}
		} 
		db.endConnection();
	}

	
	public String getLayoutstatus() {
		return layoutstatus;
	}

	public void setLayoutstatus(String layoutstatus) {
		this.layoutstatus = layoutstatus;
	}

	public String getExistSublayoutid() {
		return existSublayoutid;
	}

	public void setExistSublayoutid(String existSublayoutid) {
		this.existSublayoutid = existSublayoutid;
	}

	public String getMappedSublayoutid() {
		return mappedSublayoutid;
	}

	public void setMappedSublayoutid(String mappedSublayoutid) {
		this.mappedSublayoutid = mappedSublayoutid;
	}

	public ArrayList<MappingModel> getMdrscrubFieldMappings() {
		return mdrscrubFieldMappings;
	}

	public void setMdrscrubFieldMappings(ArrayList<MappingModel> mdrscrubFieldMappings) {
		ConnectDB db = new ConnectDB();
		db.initialize();
		String query = "";

			query = "SELECT * FROM ( "
					+ " SELECT A.LAYOUTTYPE , A.COLUMNNAME  ,COALESCE (B.RULE,A.DEFAULTRULE) GLOBALRULE ,null CLIENTRULE ,B.remark "
					+ " FROM RPT_MASTER_FIELDS  A LEFT JOIN "
					+ " (SELECT A.*   FROM mdr_rules_layout A WHERE LAYOUTID='"
					+ getLayoutID()
					+ "') B "
					+ " ON  A.COLUMNNAME = B.TGTFIELD "

					+ " WHERE A.REPORT_TYPE='MDR' AND A.LAYOUTTYPE=(SELECT DATATYPE FROM IMP_LAYOUTS WHERE LAYOUTID='"
					+ getLayoutID() + "')   ) ORDER BY  COLUMNNAME ";

		
		log.info(" Scrub query " + query);
		List<List<String>> mList = db.resultSetToListOfList(query);

		if (mList.size() > 0) {

			for (int i = 1; i < mList.size(); i++) {
				mdrscrubFieldMappings.add(new MappingModel(i,mList.get(i - 1)
						.get(1), mList.get(i).get(1), mList.get(i).get(2),
						mList.get(i).get(3), mList.get(i).get(4)));
			}
			
		}

		this.mdrscrubFieldMappings = mdrscrubFieldMappings;
	}
	public void handleSaveMDR(MappingModel mappingModel) {

		if (!mappingModel.getGlobalScrubLogic().equals(
				mappingModel.getOriginalGlobalScrubLogic())
				&& !mappingModel.getGlobalScrubLogic().startsWith("form:")) {

			String result = "";

			FacesMessage msg = null;

			String chk = "1";

			if (!mappingModel.getGlobalScrubLogic().equals("")
					&& mappingModel.getGlobalScrubLogic() != null) {
				ConnectDB tempdb = new ConnectDB();
				tempdb.initialize(AIConstant.RAC_SERVER_NAME,
						AIConstant.RAC_SERVICE_PORT,
						AIConstant.RAC_SERVICE_SID,
						AIConstant.TEST_SCHEMA_NAME, "LOCAL");

				chk = checkValidation(
						"SELECT " + mappingModel.getGlobalScrubLogic()
								+ " FROM ZZZ_" + getLayoutID() + "_1", tempdb);
				tempdb.endConnection();
			}

			if (chk.equalsIgnoreCase("1")) {
				ConnectDB db = new ConnectDB();
				db.initialize();
				String tableName = "mdr_rules_layout";

				String query = "UPDATE  "
						+ tableName
						+ " SET RULE='"
						+ mappingModel.getGlobalScrubLogic().replaceAll("'",
								"''")
						+ "'"
						+ ",dateupdated=sysdate, RERELEASESTATUS='N' WHERE LAYOUTID='"
						+ getLayoutID() + "' AND TGTFIELD='"
						+ mappingModel.getScrubFieldName() + "' ";

				int rowsAffected = db.update(query);

				if (rowsAffected == -1) {
					mappingModel.setGlobalScrubLogic(mappingModel
							.getOriginalGlobalScrubLogic());
					result = "Error";
				} else if (rowsAffected == 0) {
					query = "INSERT INTO " + tableName
							+ "(LAYOUTID, TGTFIELD, RULE, "
							+ " DATECREATED, CREATEDBY,RERELEASESTATUS  ";

					query += ") VALUES('"
							+ getLayoutID()
							+ "','"
							+ mappingModel.getScrubFieldName()
							+ "',"
							+ "'"
							+ mappingModel.getGlobalScrubLogic().replaceAll(
									"'", "''") + "',SYSDATE,'"
							+ getUserinfo().getFullname() + "','N' ";

					query += ")";

					result = db.executeDML(query);
				} else {
					result = "1";
				}
				db.endConnection();
			} else {
				mappingModel.setGlobalScrubLogic(mappingModel
						.getOriginalGlobalScrubLogic());

				result = chk;
			}

			if (result.equalsIgnoreCase("1")) {

				mappingModel.setOriginalGlobalScrubLogic(mappingModel
						.getGlobalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Rule For "
						+ mappingModel.getScrubFieldName() + " Changed",
						"New rule:" + mappingModel.getGlobalScrubLogic());
				
				
			} else {
				mappingModel.setGlobalScrubLogic(mappingModel
						.getOriginalGlobalScrubLogic());
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Error Updating Rule For "
								+ mappingModel.getScrubFieldName(), result);
			}

			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}
	public void handleCancelMDR(MappingModel mappingModel) {
		mappingModel.setGlobalScrubLogic(mappingModel
				.getOriginalGlobalScrubLogic());
	}

	public String getMappingType() {
		return mappingType;
	}

	public void setMappingType(String mappingType) {
		this.mappingType = mappingType;
	}


}
