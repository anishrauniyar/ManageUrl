/* 
 *Class Name : DataType.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.commons.model;

import java.util.LinkedHashMap;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version : 1.0 15 June 2014
 */
public class DataType {

	private String dataType = "";

	private LinkedHashMap<String, String> dataTypes;

	public DataType() {
		dataTypes = new LinkedHashMap<String, String>();
		setDataTypes(dataTypes);
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public LinkedHashMap<String, String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(LinkedHashMap<String, String> dataTypes) {
		String query = "SELECT nvl(DATATYPEID,'NA'), nvl(DATATYPE,'NA') FROM "
				+ " TBL_FILEPATTERNS_DATATYPE ORDER BY 2";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> dtList = db.resultSetToListOfList(query);
		db.endConnection();

		if (dtList.size() > 0) {
			for (int i = 1; i < dtList.size(); i++) {
				dataTypes.put(dtList.get(i).get(1), dtList.get(i).get(1));
			}
		}
	}

}
