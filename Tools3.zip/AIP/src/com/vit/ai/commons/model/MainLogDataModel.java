/*
 *Class Name : MainLogDataModel.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.commons.model;

import java.util.ArrayList;

import javax.faces.model.ListDataModel;

import org.primefaces.model.SelectableDataModel;
import com.vit.ai.inventory.model.MainLog;

/**
 * Datamodel to display row numbers in datatable
 * 
 * @author Sagar Shrestha
 * 
 * @version 1.0 07 Apr 2014
 */
public class MainLogDataModel extends

ListDataModel<MainLog> implements SelectableDataModel<MainLog> {

	public MainLogDataModel() {

	}

	public MainLogDataModel(ArrayList<MainLog> mainLog) {
		super(mainLog);

	}
	

	@Override
	public Object getRowKey(MainLog object) {

		return object.getFileID();
	}

	@SuppressWarnings("unchecked")
	@Override
	public MainLog getRowData(String rowKey) {

		ArrayList<MainLog> logs = (ArrayList<MainLog>) getWrappedData();

		for (MainLog log : logs) {
			if (log.getFileID().equals(rowKey)) {
				return log;
			}
		}
		return null;
	}

}
