/*
 *Class Name : HRPayerBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.commons.model;

import java.util.LinkedHashMap;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 06 Oct 2014
 */
public class HRPayerBean {

	private String payer = "";

	private LinkedHashMap<String, String> payers;

	public HRPayerBean() {
		payers = new LinkedHashMap<String, String>();
		setPayers(payers);
	}

	public String getPayer() {
		return payer;
	}

	public void setPayer(String payer) {
		this.payer = payer;
	}

	public LinkedHashMap<String, String> getPayers() {
		return payers;
	}

	public void setPayers(LinkedHashMap<String, String> payers) {
		String query = "SELECT SHORTNAME, upper(VHPAYORNAME),VHPAYORID  FROM HR_GLOBAL_VHPAYORS@hawkeyerules ORDER BY  upper(VHPAYORNAME)";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> payerList = db.resultSetToListOfList(query);
		db.endConnection();

		if (payerList.size() > 0) {
			for (int i = 1; i < payerList.size(); i++) {
				payers.put(payerList.get(i).get(1), payerList.get(i).get(1)
						+ "~" + payerList.get(i).get(2) + "~"
						+ payerList.get(i).get(0));
			}
		}

	}
}
