/* 
 *Class Name : LayoutFiles.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.commons.model;

import java.io.Serializable;

import org.primefaces.model.DefaultStreamedContent;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 07 July 2014
 */
public class LayoutFiles implements Serializable {

	private static final long serialVersionUID = -3226546270117187314L;
	private String sn;
	private String layoutID;
	private DefaultStreamedContent downloadFile;
	private String fileName;
	private String entryDate;
	private String originalFileName;

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getLayoutID() {
		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getUserLog() {
		return userLog;
	}

	public void setUserLog(String userLog) {
		this.userLog = userLog;
	}

	private String userLog;

	public DefaultStreamedContent getDownloadFile() {
		return downloadFile;
	}

	public void setDownloadFile(DefaultStreamedContent downloadFile) {
		this.downloadFile = downloadFile;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public LayoutFiles(String sn, String layoutID,
			DefaultStreamedContent downloadFile, String fileName,
			String originalFileName, String entryDate, String userLog) {
		super();
		this.sn = sn;
		this.layoutID = layoutID;
		this.downloadFile = downloadFile;
		this.fileName = fileName;
		this.setOriginalFileName(originalFileName);
		this.entryDate = entryDate;
		this.userLog = userLog;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

}
