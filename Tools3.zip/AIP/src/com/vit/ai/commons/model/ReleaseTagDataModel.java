package com.vit.ai.commons.model;

/*
 *Class Name : MainLogDataModel.java
 *
 *Copyright: Verisk Information Technologies
 */

import java.util.ArrayList;
import java.util.Spliterator;
import java.util.function.Consumer;

import javax.faces.model.ListDataModel;

import org.primefaces.model.SelectableDataModel;

import com.vit.ai.releasetag.model.ReleaseTagModel;

/**
 * Datamodel to display row numbers in datatable
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 4th Apr 2016
 */
public class ReleaseTagDataModel extends ListDataModel<ReleaseTagModel>
		implements SelectableDataModel<ReleaseTagModel> {

	public ReleaseTagDataModel() {

	}

	public ReleaseTagDataModel(ArrayList<ReleaseTagModel> mainLog) {
		super(mainLog);

	}

	@Override
	public Object getRowKey(ReleaseTagModel object) {

		return object.getDmfileid();
	}

	@Override
	public void forEach(Consumer<? super ReleaseTagModel> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Spliterator<ReleaseTagModel> spliterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReleaseTagModel getRowData(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
