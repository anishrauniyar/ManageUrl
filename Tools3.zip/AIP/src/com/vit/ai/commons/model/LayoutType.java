/* 
 *Class Name : LayoutType.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.commons.model;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * 
 * @version 1.0 02 Oct 2014
 */
public class LayoutType implements Serializable {

	private static final long serialVersionUID = 1L;

	private String layoutType = "";

	private LinkedHashMap<String, String> layoutTypes;

	public LayoutType() {
		layoutTypes = new LinkedHashMap<String, String>();
		setlayoutTypes(layoutTypes);
	}

	public String getlayoutType() {
		return layoutType;
	}

	public void setlayoutType(String layoutType) {
		this.layoutType = layoutType;
	}

	public LinkedHashMap<String, String> getlayoutTypes() {
		return layoutTypes;
	}

	public void setlayoutTypes(LinkedHashMap<String, String> layoutTypes) {
		String query = "SELECT nvl(LAYOUTTYPEID,'NA'), nvl(LAYOUTTYPE,'NA') "
				+ "	FROM TBL_FILEPATTERNS_LAYOUT ORDER BY 2";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> ltList = db.resultSetToListOfList(query);
		db.endConnection();

		if (ltList.size() > 0) {
			for (int i = 1; i < ltList.size(); i++) {
				layoutTypes.put(ltList.get(i).get(1), ltList.get(i).get(1));
			}
		}
	}
}
