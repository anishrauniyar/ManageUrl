/*
 *Class Name : UploadLayoutController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.commons.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.primefaces.component.fileupload.FileUploadRenderer;
import org.primefaces.context.RequestContext;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.session.UserInformation;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for upload
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 30 June 2014 
 */
@ManagedBean
@ViewScoped
public class UploadLayoutController extends FileUploadRenderer implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private String fileName;
	private UploadedFile uploadFile;
	private String layoutID;
	private boolean done = false;
	private boolean upload = false;
	private boolean fromMaster = false;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;
	private boolean datadictionaryUploaded = false;
	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public UploadedFile getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(UploadedFile uploadFile) {
		this.uploadFile = uploadFile;
	}

	public UploadLayoutController() {
		
		if (!this.isFromMaster()) {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			this.layoutID = (String) facesContext.getExternalContext()
					.getRequestParameterMap().get("layoutid");
		} else {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			this.layoutID = (String) facesContext.getExternalContext()
					.getRequestParameterMap().get("lid");
		}
		init();

	}

	public void init() {

		FacesContext facesContext = FacesContext.getCurrentInstance();
		String check = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("isFromMaster");
		getLayoutID();
		if (check != null) {
			if (check.compareTo("true") == 0) {
				this.fromMaster = true;
			} else {
				this.fromMaster = false;
			}
		} else {
			this.fromMaster = false;
		}

	}

	public void handleFileUpload(FileUploadEvent event) {
		
		System.out.println("Layoutid : " + this.layoutID);
		FacesMessage msg = null;
		try {
			uploadFile = event.getFile();
			if (uploadFile == null) {
				msg = new FacesMessage(
						FacesMessage.SEVERITY_ERROR,
						"Upload Status",
						"Cannot Upload File.Try again.Make sure you have submitted your previous download");
			}
			InputStream input = null;
			OutputStream output = null;
			if (layoutID == null || layoutID.compareTo("") == 0) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Upload Status", "No Layout Selected");
				FacesContext.getCurrentInstance().addMessage(null, msg);
				this.done = true;
				return;
			}
			String fileUploadPath = AIConstant.LAYOUT_UPLOAD_PATH + layoutID
					+ "/";
			File file = new File(fileUploadPath);
			if (!file.exists()) {

				file.mkdir();
			}
			String fileName = FilenameUtils.getName(uploadFile.getFileName());
			if (fileName == null || fileName.compareTo("") == 0) {
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Upload Status", "Select a file to upload");
				FacesContext.getCurrentInstance().addMessage(null, msg);

				return;
			}

			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"yyyyMMdd_hhmmss");
			Calendar calendar = Calendar.getInstance();
			String uploadTime = dateFormat.format(calendar.getTime());

			String messageString = "";

			try {
				input = uploadFile.getInputstream();
				output = new FileOutputStream(new File(fileUploadPath,
						uploadTime + "_" + fileName));
				IOUtils.copy(input, output);

				ConnectDB db = new ConnectDB();

				db.initialize();

				String query = "INSERT INTO IMP_LAYOUT_REPO(SN, LAYOUTID, FILENAME, ORIGINALFILENAME, ENTRYDATE, USERLOG) "
						+ " VALUES((SELECT MAX(SN) +1 FROM IMP_LAYOUT_REPO),'"
						+ layoutID
						+ "', "
						+ " '"
						+ uploadTime
						+ "_"
						+ fileName.replaceAll("'", "''")
						+ "', "
						+ " '"
						+ fileName.replaceAll("'", "''")
						+ "',SYSDATE,'"
						+ getSessionData().getFullname() + "')";

				db.executeDML(query);
				db.endConnection();
				
				messageString = "File " + fileName + " uploaded";
				msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
						"Upload Status", messageString);

			} catch (IOException e) {

				messageString = "Cannot upload " + fileName + ": "
						+ e.getMessage();
				msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
						"Upload Status", messageString);
			}

			finally {
				IOUtils.closeQuietly(input);
				IOUtils.closeQuietly(output);

			}
		}

		catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Upload Status", "Cannot locate file.Please Try Again");
			FacesContext.getCurrentInstance().addMessage(null, msg);

		} catch (Exception ex) {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Upload Status", "Upload Failed");
			FacesContext.getCurrentInstance().addMessage(null, msg);

		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
		this.upload = true;

	}

	public String getLayoutID() {

		if(this.layoutID==null || this.layoutID.isEmpty())
		{
		if (!this.isFromMaster()) {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			this.layoutID = (String) facesContext.getExternalContext()
					.getRequestParameterMap().get("layoutid");
		} else {
			FacesContext facesContext = FacesContext.getCurrentInstance();
			this.layoutID = (String) facesContext.getExternalContext()
					.getRequestParameterMap().get("lid");
		}
		}
	
		
		return layoutID;

	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}

	public boolean isUpload() {
		return upload;
	}

	public void setUpload(boolean upload) {
		this.upload = upload;
	}

	public void handleDone() {
		this.upload = false;
		String ddup = "";
		System.out.println("DATA DICTIONARY  : " + this.datadictionaryUploaded + "Layoutid : " + layoutID);
		if(this.datadictionaryUploaded)
		{
			ddup = "Y";
			ConnectDB db = new ConnectDB();
			try
			{
			
			db.initialize();
			String query = "update imp_layouts set datadictionaryUploaded = '" + ddup + "' WHERE layoutid = '" + getLayoutID() + "'" ;
			System.out.println("QUERY : " + query);
			db.executeDML(query);
			}
			catch(Exception ex)
			{
				System.out.println("ERROR : " + ex.toString());
			}
			finally
			{
				if(db!=null)
				{
				db.endConnection();
				}
			}
		}
		else
		{
			ddup = "N";
		}
		if (this.fromMaster) {
			FacesContext.getCurrentInstance();
			RequestContext.getCurrentInstance().closeDialog("uploadLayout");
			
		} else {
			RequestContext.getCurrentInstance().execute(
					"parent.PF('subframe').hide();");
			FacesContext.getCurrentInstance();

		}
		
		
		
	}

	public boolean isFromMaster() {

		return fromMaster;
	}

	public void setFromMaster(boolean fromMaster) {
		this.fromMaster = fromMaster;
	}

	public void close() {
		this.upload = false;

		RequestContext.getCurrentInstance().closeDialog("uploadLayout");
		
	}

	public boolean isDatadictionaryUploaded() {
		return datadictionaryUploaded;
	}

	public void setDatadictionaryUploaded(boolean datadictionaryUploaded) {
		
		System.out.println("FLAG UPDATED : " + datadictionaryUploaded);
		this.datadictionaryUploaded = datadictionaryUploaded;
	}

}
