/* 
 *Class Name : DownloadLayoutController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.commons.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;
import org.primefaces.model.DefaultStreamedContent;

import com.vit.ai.commons.model.LayoutFiles;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.session.UserInformation;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for download
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 21 June 2014
 */
@ManagedBean
@ViewScoped
public class DownloadLayoutController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;
	private String fileName;
	private String layoutID;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation sessionData;
	private ArrayList<LayoutFiles> layoutFiles;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public DownloadLayoutController() {
		init();
	}

	public void init() {

			layoutFiles = new ArrayList<LayoutFiles>();
			setLayoutFiles(layoutFiles);

		}

	

	public UserInformation getSessionData() {
		return sessionData;
	}

	public void setSessionData(UserInformation sessionData) {
		this.sessionData = sessionData;
	}

	public DefaultStreamedContent prepDownload(String fileName,
			String originalFilename) {

		File file = new File(AIConstant.LAYOUT_UPLOAD_PATH + getLayoutID()
				+ "/" + fileName);
		if (getLayoutID() == null || getLayoutID().compareTo("") == 0) {
			displayErrorMessageToUser("No Layout Selected", "ERROR");
		}
		InputStream input = null;
		try {
			input = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			displayErrorMessageToUser(e.toString(), "Download Failed");
		} catch (NullPointerException ex) {
			FacesContext.getCurrentInstance();
			displayErrorMessageToUser("Cannot locate file.Please Try Again",
					"Error");
		}

		ExternalContext externalContext = FacesContext.getCurrentInstance()
				.getExternalContext();

		DefaultStreamedContent to_retContent = new DefaultStreamedContent(
				input, externalContext.getMimeType(file.getName()),
				originalFilename);
		return to_retContent;

	}

	public String getLayoutID() {

		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.layoutID = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("lid");

		return layoutID;
	}

	public void setLayoutID(String layoutID) {
		this.layoutID = layoutID;
	}

	public ArrayList<LayoutFiles> getLayoutFiles() {

		if (layoutFiles.size() > 0) {
			for (int i = 0; i < layoutFiles.size(); i++) {
				layoutFiles.get(i).setDownloadFile(
						prepDownload(layoutFiles.get(i).getFileName(),
								layoutFiles.get(i).getOriginalFileName()));
			}
		}
		return layoutFiles;
	}

	public void setLayoutFiles(ArrayList<LayoutFiles> layoutFiles) {
		ConnectDB db = new ConnectDB();
		db.initialize();

		String query = "SELECT  SN, LAYOUTID, FILENAME, ORIGINALFILENAME, "
				+ " To_Char(ENTRYDATE,'MM/DD/YYYY hh24:mi:ss') ENTRYDATE, USERLOG "
				+ " FROM IMP_LAYOUT_REPO WHERE LAYOUTID='" + getLayoutID()
				+ "' ORDER BY Upper(ORIGINALFILENAME)";

		System.out.println(query);

		List<List<String>> layoutList = db.resultSetToListOfList(query);

		db.endConnection();
		layoutFiles = new ArrayList<LayoutFiles>();

		if (layoutList.size() > 0) {
			File file;
			for (int i = 1; i < layoutList.size(); i++) {
				file = new File(AIConstant.LAYOUT_UPLOAD_PATH + getLayoutID()
						+ "/" + layoutList.get(i).get(2));
				if (file.exists()) {
					layoutFiles
							.add(new LayoutFiles(layoutList.get(i).get(0),
									layoutList.get(i).get(1), prepDownload(
											layoutList.get(i).get(2),
											layoutList.get(i).get(3)),
									layoutList.get(i).get(2), layoutList.get(i)
											.get(3), layoutList.get(i).get(4),
									layoutList.get(i).get(5)));
				}
			}
		}
		this.layoutFiles = layoutFiles;
	}

	public void delete(LayoutFiles layoutFiles) {

		FacesMessage msg = null;

		ConnectDB db = new ConnectDB();
		db.initialize();
		String result = db.executeDML("DELETE FROM IMP_LAYOUT_REPO WHERE "
				+ "	SN='" + layoutFiles.getSn() + "'");

		db.endConnection();
		if (result.equalsIgnoreCase("1")) {
			msg = new FacesMessage(FacesMessage.SEVERITY_INFO,
					"Delete layout document", "Success");
			init();
		} else {
			msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					"Error occured", result);
		}

		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public void close() {
		RequestContext.getCurrentInstance().closeDialog("downloadLayout");

	}

}
