/* 
 *Class Name : FileController.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.ai.commons.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serializable;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.UploadedFile;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.utils.AbstractController;

/**
 * Controller Class for file upload and download 
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 05 July 2014
 */
public class FileController extends AbstractController implements Serializable {

	private static final long serialVersionUID = 1L;
	private String fileName;
	private UploadedFile uploadFile;
	private DefaultStreamedContent download;

	public void setDownload(DefaultStreamedContent download) {
		this.download = download;
	}

	public DefaultStreamedContent getDownload() {
		return download;
	}

	public UploadedFile getUploadFile() {
		return uploadFile;
	}

	public void setUploadFile(UploadedFile uploadFile) {
		this.uploadFile = uploadFile;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public FileController() {

	}

	public FileController(String fileName) {
		setFileName(fileName);
		prepDownload();
	}

	public void prepDownload() {

		File file = new File(fileName);
		InputStream input = null;
		try {
			input = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			displayErrorMessageToUser(e.toString(), "Download Failed");
			return;
		}
		ExternalContext externalContext = FacesContext.getCurrentInstance()
				.getExternalContext();

		setDownload(new DefaultStreamedContent(input,
				externalContext.getMimeType(file.getName()), file.getName()));

	}

	public void handleFileUpload(FileUploadEvent event) {
		uploadFile = event.getFile();
		InputStream input = null;
		OutputStream output = null;
		try {
			input = uploadFile.getInputstream();
			output = new FileOutputStream(new File(
					AIConstant.LAYOUT_UPLOAD_PATH,
					FilenameUtils.getName(uploadFile.getFileName())));
			IOUtils.copy(input, output);
		} catch (IOException e) {
			displayErrorMessageToUser(e.toString(), "ERROR");
		} finally {
			IOUtils.closeQuietly(input);
			IOUtils.closeQuietly(output);
		}
	}

	public void delete(File file) {

		if (file.isDirectory()) {
			// directory is empty, then delete it
			if (file.list().length == 0) {
				file.delete();
			} else {
				// list all the directory contents
				String files[] = file.list();

				for (String temp : files) {
					// construct the file structure
					File fileDelete = new File(file, temp);
					// recursive delete
					delete(fileDelete);
				}

				// check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
				}
			}

		} else {
			// if file, then delete it
			file.delete();
		}

	}

}