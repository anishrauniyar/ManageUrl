/* 
 *Class Name : LegacyTransferController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.controller;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import com.vit.ai.flms.model.MClients;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.session.UserInformation;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.transfer.model.LegacyTransfer;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Aashish Dhungana
 * @author Binesh Sah
 * 
 * @version 1.1 July 27
 */
@ManagedBean
@ViewScoped
public class LegacyTransferController extends AbstractController implements
		Serializable {

	private static final long serialVersionUID = 1L;
	
	private Logger log = Logger.getLogger(LegacyTransferController.class);
	
	private ArrayList<LegacyTransfer> listOfLegacyTransfer;
	private ArrayList<LegacyTransfer> transferLogs;
	private LinkedHashMap<String, String> clients;
	private String mainclient;
	private LinkedHashMap<String, String> aiTables;
	private ArrayList<String> empgrps;
	private ArrayList<String> upempgrps;
	private LegacyTransfer selectedLogs;
	private String aiTableName;
	private String hiSchemaName;
	private String hiTableName;
	private String empGrp;
	private String whereCondition;
	private String createdBy;
	private String createdDate;
	private String hiservername;
	private String client;
	private ArrayList<String> hiServernames;
	@ManagedProperty(value = "#{userInformation}")
	private UserInformation userinfo;
	private String winScreenHeight;
	protected FilterLogController filterData;

	public FilterLogController getFilterData() {
		return filterData;
	}

	public void setFilterData(FilterLogController filterData) {
		this.filterData = filterData;
	}

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	@ManagedProperty(value = "#{loginbean}")
	private ViewsParameters sessionData;

	public UserInformation getUserinfo() {
		return userinfo;
	}

	public void setUserinfo(UserInformation userinfo) {
		this.userinfo = userinfo;
	}

	public String getAiTableName() {
		return aiTableName;
	}

	public void setAiTableName(String aiTableName) {
		this.aiTableName = aiTableName;
	}

	public String getHiSchemaName() {
		return hiSchemaName;
	}

	public void setHiSchemaName(String hiSchemaName) {
		this.hiSchemaName = hiSchemaName;
	}

	public String getHiTableName() {
		return hiTableName;
	}

	public void setHiTableName(String hiTableName) {
		this.hiTableName = hiTableName;
	}

	public String getEmpGrp() {
		return empGrp;
	}

	public void setEmpGrp(String empGrp) {
		this.empGrp = empGrp;
	}

	public String getWhereCondition() {
		return whereCondition;
	}

	public void setWhereCondition(String whereCondition) {
		this.whereCondition = whereCondition;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getHiservername() {
		return hiservername;
	}

	public void setHiservername(String hiservername) {
		this.hiservername = hiservername;
	}

	public LegacyTransferController() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));
		MClients objMC = new MClients(false);
		clients = objMC.getClients();

		try {
			this.hiServernames = new ArrayList<String>();
			String query = "SELECT DISTINCT SVR_NAME FROM AIP_SCRUB_SERVER_MASTER";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> allservernames = db.resultSetToListOfList(query);
			db.endConnection();

			for (int i = 1; i < allservernames.size(); i++) {
				this.hiServernames.add(allservernames.get(i).get(0));
			}
		} catch (Exception e) {

			displayErrorMessageToUser(
					"Ops, Field mismatch in table aip_scrub_server_master or this table not found . Try again later!",
					"Status");

		}

	}

	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}

	public ArrayList<LegacyTransfer> getListOfLegacyTransfer() {
		return listOfLegacyTransfer;
	}

	public void setListOfLegacyTransfer(
			ArrayList<LegacyTransfer> listOfLegacyTransfer) {
		this.listOfLegacyTransfer = listOfLegacyTransfer;
	}

	public void createLegacyTransfer() {
		try {
			LegacyTransfer obj = new LegacyTransfer(this.getClient().split(
					"\\-")[0], getAiTableName().replace("'", "''"),
					getHiSchemaName().replace("'", "''").toUpperCase(),
					getHiTableName().replace("'", "''").toUpperCase(),
					getEmpGrp().replace("'", "''"), getWhereCondition()
							.replace("'", "''"), getUserinfo().getFullname(),
					new Date().toString(), getHiservername().replace("'", "''")
							.toUpperCase(), "");
			String query = "INSERT INTO HI_LEGACY_TRANSFER (CLIENTID, AITABLENAME, HISCHEMANAME, HITABLENAME, EMPGRP, WHERECONDITION, CREATEDBY, CREATEDDATE, HISERVERNAME,LABEL_CHANGE_FLAG)"
					+ " VALUES ('"
					+ obj.getClientID()
					+ "','"
					+ obj.getAiTableName()
					+ "','"
					+ obj.getHiSchemaName()
					+ "','"
					+ obj.getHiTableName()
					+ "','"
					+ obj.getEmpGrp()
					+ "','"
					+ obj.getWhereCondition()
					+ "','"
					+ obj.getCreatedBy()
					+ "',sysdate,'"
					+ obj.getHiservername()
					+ "','"
					+ obj.getLabelChangeFlag()
					+ "')";

			ConnectDB db = new ConnectDB();
			db.initialize();
			String status = db.executeDML(query);
			db.endConnection();
			if (status.equals("1")) {
				closeDialog();
				displayInfoMessageToUser("Added With Sucess", "Status");
				setMainclient(this.getClient());
				loadLegacyTransfers();
				resetLegacyTransfer();
			}
			if (!status.equals("1")) {
				keepDialogOpen();
				displayErrorMessageToUser(
						"Ops, we could not add. Try again later!", "Status");
			}

		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not add. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void deletelabelChanger() {
		String query = "delete from hi_legacy_label_chg where sn='"
				+ this.selectedLogs.getSn() + "'";
		ConnectDB db = new ConnectDB();
		db.initialize();
		db.executeDML(query);
		db.endConnection();

	}

	public void updateLegacyTransfer(int sn) {
		try {

			String querycheck = "select count(*) from hi_legacy_label_chg where sn='"
					+ sn + "'";
			ConnectDB dbc = new ConnectDB();
			dbc.initialize();
			List<List<String>> rsc = dbc.resultSetToListOfList(querycheck);
			dbc.endConnection();
			if (rsc != null) {
				if (rsc.size() > 1) {
					int number_of_configurations = Integer.parseInt(rsc.get(1)
							.get(0));
					if (number_of_configurations > 0) {
						RequestContext.getCurrentInstance().execute(
								"PF('confrmupdate').show();");
					}
				}
			}

			LegacyTransfer obj = new LegacyTransfer(this.getMainclient().split(
					"\\-")[0], this.selectedLogs.getAiTableName().replace("'",
					"''"), this.selectedLogs.getHiSchemaName()
					.replace("'", "''").toUpperCase(), this.selectedLogs
					.getHiTableName().replace("'", "''").toUpperCase(),
					this.selectedLogs.getEmpGrp().replace("'", "''"),
					this.selectedLogs.getWhereCondition().replace("'", "''"),
					getUserinfo().getFullname(), new Date().toString(),
					this.selectedLogs.getHiservername().replace("'", "''")
							.toUpperCase(), "");
			String query = " UPDATE  HI_LEGACY_TRANSFER SET  AITABLENAME='"
					+ this.selectedLogs.getAiTableName().replace("'", "''")
					+ "', HISCHEMANAME='"
					+ this.selectedLogs.getHiSchemaName().replace("'", "''")
							.toUpperCase()
					+ "', HITABLENAME='"
					+ this.selectedLogs.getHiTableName().replace("'", "''")
							.toUpperCase()
					+ "', "
					+ " EMPGRP='"
					+ this.selectedLogs.getEmpGrp().replace("'", "''")
					+ "', WHERECONDITION='"
					+ this.selectedLogs.getWhereCondition().replace("'", "''")
					+ "', "
					+ " CREATEDBY='"
					+ getUserinfo().getFullname()
					+ "', CREATEDDATE=sysdate, HISERVERNAME='"
					+ this.selectedLogs.getHiservername().replace("'", "''")
							.toUpperCase() + "',label_change_flag='"
					+ obj.getLabelChangeFlag() + "'" + " where (clientid='"
					+ this.mainclient.split("\\-")[0] + "' and sn=" + sn + ")";

			ConnectDB db = new ConnectDB();
			db.initialize();
			String status = db.executeDML(query);
			db.endConnection();
			
			String query_log = "INSERT INTO HI_LEGACYTRANSFER_LOG(CLIENTID, AITABLENAME, HISCHEMANAME, HITABLENAME, HISERVERNAME, EMPGROUP, WHERECONDITION, SN, USERNAME, CREATED_ON)"
					+ " VALUES ('"
					+ this.mainclient.split("\\-")[0]
					+ "','"
					+ this.selectedLogs.getAiTableName().replace("'", "''")
					+ "','"
					+ this.selectedLogs.getHiSchemaName().replace("'", "''").toUpperCase()
					+ "','"
					+ this.selectedLogs.getHiTableName().replace("'", "''").toUpperCase()
					+ "','"
					+ this.selectedLogs.getHiservername().replace("'", "''").toUpperCase()
					+ "','"
					+ this.selectedLogs.getEmpGrp().replace("'", "''")
					+ "','"
					+ this.selectedLogs.getWhereCondition().replace("'", "''")
					+ "','"
					+  sn
					+ "','"
					+ this.userinfo.getFullname()
					//+ getUserinfo().getFullname()
					+ "',sysdate)";

			ConnectDB dblog = new ConnectDB();
			dblog.initialize();
			try{
				log.info("The query is: " + query_log);
				dblog.executeDML(query_log);
			}catch (Exception e) {
				
				log.info("there is error inserting log: "+ e.getMessage());
			}
			dblog.endConnection();
			
			if (status.compareTo("1") == 0) {
				closeDialog();
				displayInfoMessageToUser("Updated With Sucess", "Status");
				loadLegacyTransfers();
				resetLegacyTransfer();

			} else {
				keepDialogOpen();
				displayErrorMessageToUser("Updated Failed. Please try again"
						+ status, "");

			}

		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not update. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void deleteLegacyTransfer(int sn) {
		try {
			String query = "DELETE FROM HI_LEGACY_TRANSFER WHERE (sn=" + sn
					+ " and clientid='" + this.mainclient.split("\\-")[0]
					+ "')";
			String query1 = "DELETE FROM hi_legacy_label_chg where sn='" + sn
					+ "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			db.executeDML(query1);
			String status = db.executeDML(query);
			db.endConnection();
			if (status.equals("1")) {
				closeDialog();
				displayInfoMessageToUser("Deleted With Sucess", "Status");
				loadLegacyTransfers();
				resetLegacyTransfer();
			}
			if (!status.equals("1")) {
				keepDialogOpen();
				displayErrorMessageToUser(
						"Ops, we could not delete. Try again later!", "Status");
			}

		} catch (Exception e) {
			keepDialogOpen();
			displayErrorMessageToUser(
					"Ops, we could not delete. Try again later! Error:"
							+ e.getMessage(), "Status");

		}
	}

	public void loadLegacyTransfers() {
		try {
			String clientID;
			if (this.transferLogs != null) {
				this.transferLogs = null;
				DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("frmLT:legacyTransferID");
				dt1.setFilters(null);
				dt1.reset();
			}

			if (this.mainclient.isEmpty() || this.mainclient == null) {
				displayErrorMessageToUser("No Client Selected", "ERROR");
			}

			if (getClient() != "" && getClient() != null
					&& !getClient().contains("Select Client")) {
				clientID = this.client.split("\\-")[0];

			}
			if (getClient() != "" && getClient() != null
					&& !getClient().contains("Select Client")
					&& getMainclient() != "" && getMainclient() != null) {
				clientID = this.getMainclient().split("\\-")[0];
			} else {
				clientID = this.getMainclient().split("\\-")[0];
			}

			listOfLegacyTransfer = new ArrayList<LegacyTransfer>();

			String query = "SELECT  CLIENTID, AITABLENAME, HISCHEMANAME, HITABLENAME, EMPGRP, WHERECONDITION, "
					+ "CREATEDBY, CREATEDDATE, SN,HISERVERNAME, LABEL_CHANGE_FLAG "
					+ " FROM HI_LEGACY_TRANSFER where clientid='"
					+ clientID
					+ "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> listAll = db.resultSetToListOfList(query);
			db.endConnection();
			if (listAll.size() > 0) {
				for (int i = 1; i < listAll.size(); i++) {
					listOfLegacyTransfer.add(new LegacyTransfer(listAll.get(i)
							.get(0), listAll.get(i).get(1), listAll.get(i).get(
							2), listAll.get(i).get(3), listAll.get(i).get(4),
							listAll.get(i).get(5), listAll.get(i).get(6),
							listAll.get(i).get(7), Integer.parseInt(listAll
									.get(i).get(8)), listAll.get(i).get(9),
							listAll.get(i).get(10)));
					setListOfLegacyTransfer(listOfLegacyTransfer);
				}
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}
	}

	public void resetLegacyTransfer() {
		this.aiTableName = "";
		this.hiSchemaName = "";
		this.hiTableName = "";
		this.empGrp = "";
		this.whereCondition = "";
		this.hiservername = "";
		this.client = "Select Client";
		setAiTables(null);

	}

	public LinkedHashMap<String, String> getClients() {
		return clients;
	}

	public void setClients(LinkedHashMap<String, String> clients) {
		this.clients = clients;
	}

	public void handleClientChange() {
		try {
			String query = "SELECT A.TABLE_NAME||'_'||SHORTPAYOR TABLE_NAME ,A.LAYOUTID,B.PAYOR,B.DATATYPE,C.LAYOUTTYPE,C.LAYOUTDETAIL "
					+ " FROM ( "
					+ " SELECT distinct 'AI_'||y.LAYOUTID||'_'||x.sublayoutid AS TABLE_NAME, y.LAYOUTID,x.sublayoutid  FROM IMP_CLIENTPATTERNS y left join imp_sub_layouts x on y.layoutid=x.layoutid AND  SUBLAYOUTDESC  ='DATAFILE' WHERE CLIENTID='"
					+ getClient().split("\\-")[0]
					+ "'"

					+ " ) A"
					+ " LEFT JOIN "
					+ " IMP_LAYOUTS B "
					+ " ON A.LAYOUTID = B.LAYOUTID "
					+ " LEFT JOIN"
					+ " IMP_SUB_LAYOUTS C"
					+ " ON (A.LAYOUTID=C.LAYOUTID AND a.sublayoutid=c.sublayoutid  )  "
					+ " ORDER BY LAYOUTID";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> aiTableList = db.resultSetToListOfList(query);
			db.endConnection();

			aiTables = new LinkedHashMap<String, String>();
			if (aiTableList.size() > 0) {
				for (int i = 1; i < aiTableList.size(); i++) {
					aiTables.put(aiTableList.get(i).get(0) + "-"
							+ aiTableList.get(i).get(2) + "-"
							+ aiTableList.get(i).get(3) + "-"
							+ aiTableList.get(i).get(4) + "-"
							+ aiTableList.get(i).get(5), aiTableList.get(i)
							.get(0));
				}
			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}

	}

	public LinkedHashMap<String, String> getAiTables() {
		return aiTables;
	}

	public void setAiTables(LinkedHashMap<String, String> aiTables) {
		this.aiTables = aiTables;
	}

	public String getMainclient() {
		return filterData.getClientID();
	}

	public void setMainclient(String mainclient) {
		filterData.setClientID(mainclient);
		this.mainclient = filterData.getClientID();
	}

	public ArrayList<String> getEmpgrps() {
		return empgrps;
	}

	public void setEmpgrps(ArrayList<String> empgrps) {
		this.empgrps = empgrps;
	}

	public void handleAIChange() {
		try {
			if (this.getAiTableName().compareTo("") != 0) {
				this.empgrps = new ArrayList<String>();

				String layoutID = this.getAiTableName().split("_")[1];
				String query = "  SELECT DISTINCT EMPLOYERGROUP FROM IMP_CLIENTPATTERNS WHERE  layoutid  ='"
						+ layoutID
						+ "'  AND clientid='"
						+ this.client.split("\\-")[0] + "'";
				ConnectDB db = new ConnectDB();
				db.initialize();
				List<List<String>> rs = db.resultSetToListOfList(query);
				db.endConnection();

				for (int i = 1; i < rs.size(); i++) {
					this.empgrps.add(rs.get(i).get(0));
				}

			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}
	}

	public void updateempgroup() {
		try {
			this.upempgrps = new ArrayList<String>();
			String query = "  SELECT DISTINCT EMPLOYERGROUP FROM IMP_CLIENTPATTERNS WHERE clientid='"
					+ this.getMainclient().split("\\-")[0]
					+ "' and layoutid='"
					+ this.selectedLogs.getAiTableName().split("\\_")[1] + "'";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(query);
			db.endConnection();
			for (int i = 1; i < rs.size(); i++) {
				this.upempgrps.add(rs.get(i).get(0));
			}
		} catch (Exception e) {
			displayErrorMessageToUser("Error Occured. Please try again",
					"Error");
		}

	}

	public ArrayList<String> getUpempgrps() {
		return upempgrps;
	}

	public void setUpempgrps(ArrayList<String> upempgrps) {
		this.upempgrps = upempgrps;
	}

	public void displayMessage() {

		if (this.sessionData.isTransferLabelChanged()) {
			loadLegacyTransfers();
			displayInfoMessageToUser("Successfully Updated Label Values",
					"Label Changer");
			this.sessionData.setTransferLabelChanged(false);

		}

	}

	public LegacyTransfer getSelectedLogs() {
		return selectedLogs;
	}

	public void setSelectedLogs(LegacyTransfer selectedLogs) {
		this.selectedLogs = selectedLogs;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}

	public ArrayList<LegacyTransfer> getTransferLogs() {
		return transferLogs;
	}

	public void setTransferLogs(ArrayList<LegacyTransfer> transferLogs) {
		this.transferLogs = transferLogs;
	}

	public ArrayList<String> getHiServernames() {
		return hiServernames;
	}

	public void setHiServernames(ArrayList<String> hiServernames) {
		this.hiServernames = hiServernames;

	}

	public void updateWherecondition() {
		if (this.getEmpGrp().equals(" ")) {
			setWhereCondition("");
		} else {
			setWhereCondition("EMPGRP='" + this.getEmpGrp() + "'");
		}

	}

	public void updateWhereconditionforUpdate() {

		if (this.selectedLogs.getEmpGrp().equals(" ")) {
			this.selectedLogs.setWhereCondition("");
		} else {
			this.selectedLogs.setWhereCondition("EMPGRP='"
					+ this.selectedLogs.getEmpGrp() + "'");
		}

	}

	public void openLabelChangerView(String sn, String clid, String aitable,
			String hiserver, String hischema, String hitable, String user) {
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 800);
		options.put("height", 500);
		options.put("contentWidth", 800);
		options.put("contentHeight", 500);
		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(sn);
		params.put("sn", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add(clid);
		params.put("clid", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(aitable);
		params.put("aitable", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(hiserver);
		params.put("hiserver", list4);
		List<String> list5 = new ArrayList<String>();
		list5.add(hischema);
		params.put("hischema", list5);
		List<String> list6 = new ArrayList<String>();
		list6.add(hitable);
		params.put("hitable", list6);
		List<String> list7 = new ArrayList<String>();
		list7.add(user);
		params.put("user", list7);
		List<String> list8 = new ArrayList<String>();
		list8.add("view");
		params.put("mode", list8);

		System.out.println("Loading Label Changer Dialog");
		RequestContext.getCurrentInstance().openDialog("labelChanger", options,
				params);// ,options,null);
	}

	public void openLabelChangerModify(String sn, String clid, String aitable,
			String hiserver, String hischema, String hitable, String user) {
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 800);
		options.put("height", 500);
		options.put("contentWidth", 800);
		options.put("contentHeight", 500);
		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(sn);
		params.put("sn", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add(clid);
		params.put("clid", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(aitable);
		params.put("aitable", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(hiserver);
		params.put("hiserver", list4);
		List<String> list5 = new ArrayList<String>();
		list5.add(hischema);
		params.put("hischema", list5);
		List<String> list6 = new ArrayList<String>();
		list6.add(hitable);
		params.put("hitable", list6);
		List<String> list7 = new ArrayList<String>();
		list7.add(user);
		params.put("user", list7);
		List<String> list8 = new ArrayList<String>();
		list8.add("edit");
		params.put("mode", list8);

		RequestContext.getCurrentInstance().openDialog("labelChanger", options,
				params);// ,options,null);
	}

	public void openLabelChanger(String sn, String clid, String aitable,
			String hiserver, String hischema, String hitable, String user) {
		Map<String, Object> options = new HashMap<String, Object>();
		options.put("width", 800);
		options.put("height", 500);
		options.put("contentWidth", 800);
		options.put("contentHeight", 500);
		options.put("closable", "true");
		Map<String, List<String>> params = new HashMap<String, List<String>>();
		List<String> list1 = new ArrayList<String>();
		list1.add(sn);
		params.put("sn", list1);
		List<String> list2 = new ArrayList<String>();
		list2.add(clid);
		params.put("clid", list2);
		List<String> list3 = new ArrayList<String>();
		list3.add(aitable);
		params.put("aitable", list3);
		List<String> list4 = new ArrayList<String>();
		list4.add(hiserver);
		params.put("hiserver", list4);
		List<String> list5 = new ArrayList<String>();
		list5.add(hischema);
		params.put("hischema", list5);
		List<String> list6 = new ArrayList<String>();
		list6.add(hitable);
		params.put("hitable", list6);
		List<String> list7 = new ArrayList<String>();
		list7.add(user);
		params.put("user", list7);
		List<String> list8 = new ArrayList<String>();
		list8.add("add");
		params.put("mode", list8);

		RequestContext.getCurrentInstance().openDialog("labelChanger", options,
				params);// ,options,null);
	}

	public String getWinScreenHeight() {
		return winScreenHeight;
	}

	public void setWinScreenHeight(String winScreenHeight) {
		this.winScreenHeight = winScreenHeight;
	}

}
