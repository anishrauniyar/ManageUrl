/*
 *Class Name : MainLogBeanScrub.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import com.vit.ai.background.RunTransfer;
import com.vit.ai.commons.model.MainLogDataModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.inventory.controller.MainLogBean;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.remoteConnection.RuntimeExecutor;
import com.vit.ai.session.FilterLogController;
import com.vit.ai.transfer.dao.MainLogBeanScrubDAO;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Transfer to HI
 * 
 * @author Aashish Dhungana
 * @author Binesh Sah
 * 
 * @version 1.6 05 Jan 2015
 */
@ManagedBean
@ViewScoped
public class MainLogBeanScrub extends MainLogBean {

	private static Logger log = Logger.getLogger(MainLogBeanScrub.class); 
	
	private String hiservertodel = "";
	private String hischematodel = "";
	private ArrayList<String> hiServernames;
	protected MainLogDataModel importMainLogs;
	
	protected ArrayList<String> appIdList;
	protected String appId="";
	
	protected ArrayList<String> releaseTagList;
	protected String releaseTag;
	
	
	
	
	
	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public ArrayList<String> getReleaseTagList() {
		return releaseTagList;
	}

	public void setReleaseTagList(ArrayList<String> releaseTagList) {
		this.releaseTagList = releaseTagList;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	public ArrayList<String> getAppIdList() {
		return appIdList;
	}

	public void setAppIdList(ArrayList<String> appIdList) {
		String query = "SELECT DISTINCT(APP_ID) FROM IMP_FILES_RELTAG_RELN WHERE CLIENTID = '"+filterData.getClientID()+"'";
		log.info("App Id: " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					appIdList.add(rs.get(i).get(0));
				}
			}
		}
	}

	public MainLogDataModel getImportMainLogs() {
		return importMainLogs;
	}

	public void setImportMainLogs(MainLogDataModel importMainLogs) {
		this.importMainLogs = importMainLogs;
	}

	private boolean schemanameChanged = false;

	public String getHiservertodel() {
		return hiservertodel;
	}

	public void setHiservertodel(String hiservertodel) {
		System.out.println("Setting  : " + hiservertodel);
		this.hiservertodel = hiservertodel;
	}

	public String getHischematodel() {
		return hischematodel;
	}

	public void setHischematodel(String hischematodel) {
		this.hischematodel = hischematodel;
	}

	ArrayList<String> color = new ArrayList<String>();

	public ArrayList<String> getColor() {
		return color;
	}

	public void setColor(ArrayList<String> color) {
		this.color = color;
	}

	public MainLogBeanScrub() {

		this.init();
	}

	@Override
	public void init() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));

		setTodaysDate(new Date());

		clients = new LinkedHashMap<String, String>();
		setClients(clients);

	}

	private static final long serialVersionUID = 1L;

	@Override
	public void filterLog() {
		try {
			String timeStampFormat = "yyyy-MM-dd hh24:mi:ss";
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			resetFilterbyStatus();

			String clid = filterData.getClientID();
			if (clid.isEmpty()) {
				displayErrorMessageToUser("No Client Selected", "ERROR");
				return;
			}

			String query = "SELECT a.FILEID, a.FILENAME,a.Payor, a.CLIENTID, a.LAYOUTID, a.DATATYPE, a.FILE_SIZE, a.FILE_DATE, "
					+ "	TIMESTAMP, FILE_HASHKEY, FILE_RECORD_CNT, IMPORT_RECORD_CNT, UNIQUE_RECORDS_HASH, "
					+ "	DUP_RECORD_CNT, STATUS_OF_IMPORT, FULLPATH, GETSTAT, STARTTIME, ENDTIME, TRANSFER_STATUS,a.DMFILEID,PROCESSFILEPATH, PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL "
					+ "	,importserver , a.empgrp  ,a.aitablename,a.HISERVERNAME,a.HISCHEMANAME,a.hitablename,a.wherecondition,a.sn,a.retransfer_detail,a.releaseno,a.processdate,a.DELETE_STATUS FROM AIP_DASHBOARD_TRANSFER a ";

			if (clid != null && !clid.equals("")) {
				query += "WHERE  a.CLIENTID='" + clid + "' ";
				if (startDate != null && !startDate.equals("")) {
					query += " AND PROCESSDATE >= TO_TIMESTAMP('"
							+ dateFormat.format(startDate) + "','"
							+ timeStampFormat + "')";
				}

				if (endDate != null && !endDate.equals("")) {
					query += " AND PROCESSDATE <= TO_TIMESTAMP('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";
				}
			} else if (clid == null || clid.equals(""))

			{
				if (startDate != null && !startDate.equals("")) {
					query += " WHERE AND PROCESSDATE >= TO_TIMESTAMP('"
							+ dateFormat.format(startDate) + "','"
							+ timeStampFormat + "')";
				}

				if (endDate != null && !endDate.equals("")) {
					query += " AND PROCESSDATE<= TO_TIMESTAMP('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";
				}
			} else if (clid == null || clid.equals("") && startDate == null
					|| startDate.equals("")) {
				if (endDate != null && !endDate.equals("")) {
					query += "WHERE AND PROCESSDATE <= TO_TIMESTAMP('"
							+ dateFormat.format(endDate) + "','"
							+ timeStampFormat + "')";
				}
			}

			query += " ORDER BY  To_Number(FILEID) DESC,a.HISERVERNAME,a.HISCHEMANAME,aitablename";

			setQuery(query);

			mainLogs = new ArrayList<MainLog>();
			setMainLogs(mainLogs);

			importMainLogs = new MainLogDataModel(mainLogs);
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}
	}

	@Override
	public void setMainLogs(ArrayList<MainLog> mainLogs) {

		try {

			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> logList = db.resultSetToListOfList(query);
			db.endConnection();

			if (logList.size() > 0) {
				for (int i = 1; i < logList.size(); i++) {

					mainLogs.add(new MainLog(i, logList.get(i - 1).get(0),
							logList.get(i).get(0), logList.get(i).get(1),
							logList.get(i).get(2), logList.get(i).get(3),
							logList.get(i).get(4), logList.get(i).get(5),
							logList.get(i).get(6), logList.get(i).get(7),
							logList.get(i).get(8), logList.get(i).get(9),
							logList.get(i).get(10), logList.get(i).get(11),
							logList.get(i).get(12), logList.get(i).get(13),
							logList.get(i).get(14), logList.get(i).get(15),
							logList.get(i).get(16), logList.get(i).get(17),
							logList.get(i).get(18), logList.get(i).get(19),
							logList.get(i - 1).get(20), logList.get(i).get(20),
							logList.get(i).get(21), logList.get(i).get(22),
							logList.get(i).get(23), logList.get(i).get(24),
							logList.get(i).get(25), logList.get(i).get(26),
							logList.get(i).get(27), logList.get(i).get(28),
							logList.get(i).get(29), logList.get(i - 1).get(30),
							logList.get(i).get(30), logList.get(i - 1).get(31),
							logList.get(i).get(31), logList.get(i).get(32),
							logList.get(i).get(33), logList.get(i).get(34),
							logList.get(i).get(35), logList.get(i).get(36),logList.get(i).get(37),logList.get(i).get(38)));
				}

			}
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}

	}

	public String handleRowcolor(String dmFileID, String prevdmFileID) {

		String value = "";
		if (color.isEmpty()) {
			value = "#color1";
		}

		else {
			if (!dmFileID.equals(prevdmFileID)
					&& color.get((color.size() - 1)) == "#color2") {
				value = "#color1";
			}
			if (!dmFileID.equals(prevdmFileID)
					&& color.get((color.size() - 1)) == "#color1") {
				value = "#color2";
			}
			if (dmFileID.equals(prevdmFileID)) {
				value = color.get(color.size() - 1);
			}
		}
		color.add(value);
		return value;
	}

	public ArrayList<String> getHiServernames() {
		return hiServernames;
	}

	public void setHiServernames(ArrayList<String> hiServernames) {
		this.hiServernames = hiServernames;
	}

	public void initTruncate() {
		this.hiServernames = new ArrayList<String>();
		String query = "SELECT DISTINCT SVR_NAME FROM AIP_SCRUB_SERVER_MASTER";
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> allservernames = db.resultSetToListOfList(query);
		db.endConnection();

		for (int i = 1; i < allservernames.size(); i++) {
			this.hiServernames.add(allservernames.get(i).get(0));
		}

		if (!getClient().isEmpty()) {
			this.hischematodel = "HI0" + getClient() + "001_T";
		}

		RequestContext.getCurrentInstance()
				.execute("PF('cnfrmdelete').show();");
	}

	public void truncateSchema() {
		try {
			if (this.hiservertodel.isEmpty() || this.hiservertodel == null) {
				displayErrorMessageToUser("HI SERVER REQUIRED", "ERROR");
				return;
			}
			RuntimeExecutor objRT = new RuntimeExecutor(
					AIConstant.DASHBOARD_SERVER_NAME);
			String command = AIConstant.shFilelocation
					+ "./runTransferPreCleanup.sh -c " + getClient() + " -s "
					+ this.hiservertodel + " -h " + this.hischematodel
					+ " -u '" + getUserinfo().getFullname() + "'";

			objRT.runSimpleCommand(command);
			RequestContext.getCurrentInstance().execute(
					"PF('cnfrmdelete').hide();");
			displayInfoMessageToUser("Cleanup Successful",
					"Pre-Transfer Cleanup");
		} catch (Exception ex) {
			displayErrorMessageToUser("Truncate Failed.Please try again",
					"Truncate Schema");
		}
	}

	public boolean isSchemanameChanged() {
		return schemanameChanged;
	}

	public void setSchemanameChanged(boolean schemanameChanged) {
		this.schemanameChanged = schemanameChanged;
	}

	public void checkschemaname() {
		if (this.hischematodel.compareTo("HI0" + getClient() + "001_T") != 0) {
			this.schemanameChanged = true;
		} else {
			this.schemanameChanged = false;
		}
	}

	public void filterbyReleaseNumber() {

		try {
			if (this.getReleaseNum().isEmpty() && this.getReleaseNum() == "") {
				displayErrorMessageToUser("Please select Data Batch", "");
				return;
			}
			resetFilterbyStatus();
			String query = "SELECT a.FILEID, a.FILENAME,a.Payor, a.CLIENTID, a.LAYOUTID, a.DATATYPE, a.FILE_SIZE, a.FILE_DATE,"
					+ " TIMESTAMP, FILE_HASHKEY, FILE_RECORD_CNT, IMPORT_RECORD_CNT, UNIQUE_RECORDS_HASH,"
					+ " DUP_RECORD_CNT, STATUS_OF_IMPORT, FULLPATH, GETSTAT, STARTTIME, ENDTIME, TRANSFER_STATUS,a.DMFILEID,PROCESSFILEPATH, PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL "
					+ ",importserver , a.empgrp  ,a.aitablename,a.HISERVERNAME,a.HISCHEMANAME,a.hitablename,a.wherecondition,a.sn,a.retransfer_detail,a.releaseno,a.PROCESSDATE,a.DELETE_STATUS FROM AIP_DASHBOARD_TRANSFER a WHERE"
					+ " a.clientid='"
					+ filterData.getClientID()
					+ "'"
					+ " and a.releaseno='" + this.getReleaseNum() + "'";

			mainLogs = new ArrayList<MainLog>();
			setQuery(query);
			setMainLogs(mainLogs);
			importMainLogs = new MainLogDataModel(mainLogs);
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}
	}

	public void handleFilterchange() {
		resetFilters();
		setSelectedfiltertype(this.getFiltertype());
		if (this.getFiltertype().compareTo("filterbyreleaseno") == 0) {
			releaseNos = new ArrayList<String>();
			setReleaseNos(releaseNos);
		}

		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			reportsIDs = new ArrayList<String>();
			setReportsIDs(reportsIDs);
		}
		
		if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			appIdList = new ArrayList<String>();
			setAppIdList(appIdList);
		}
	}
	
	public void handleAppIdChange() {
		log.info("This is an app id change filter.");
		String query = "SELECT DISTINCT releasetagidbyapp FROM (SELECT releasetagidbyapp FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+this.appId+"'" + 
						" ORDER BY CREATED DESC) UNION SELECT DISTINCT RELTAG FROM imp_files_reltag_reln WHERE app_id = '"+this.appId+"'";
		log.info(query);
		this.releaseTagList = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					releaseTagList.add(rs.get(i).get(0));
				}
			}
		}
	}

	@Override
	public void resetFilterbyStatus() {
		/*
		 * if(reset) {
		 */
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmML:importMainLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}

		/*
		 * } this.reset=false;
		 */
	}

	@Override
	public void resetFilters() {/*
								 * 
								 * this.reset=true;
								 */
	}

	public void filterbyReportIDs() {
		try {
			if (this.getReportID().isEmpty() && this.getReportID() == "") {
				displayErrorMessageToUser("Please select inventory ID", "");
				return;
			}
			resetFilterbyStatus();

			query = "SELECT a.FILEID, a.FILENAME,a.Payor, a.CLIENTID, a.LAYOUTID, a.DATATYPE, a.FILE_SIZE, a.FILE_DATE,"
					+ " TIMESTAMP, FILE_HASHKEY, FILE_RECORD_CNT, IMPORT_RECORD_CNT, UNIQUE_RECORDS_HASH,"
					+ " DUP_RECORD_CNT, STATUS_OF_IMPORT, FULLPATH, GETSTAT, STARTTIME, ENDTIME, TRANSFER_STATUS,a.DMFILEID,PROCESSFILEPATH, PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL "
					+ ",importserver , a.empgrp  ,a.aitablename,a.HISERVERNAME,a.HISCHEMANAME,a.hitablename,a.wherecondition,a.sn,a.retransfer_detail,a.releaseno,a.PROCESSDATE,a.DELETE_STATUS from AIP_DASHBOARD_TRANSFER a  where a.clientid='"
					+ this.getClient()
					+ "'"
					+ " and EXISTS (SELECT 1 FROM imp_inventory_rep_log_details b WHERE b.reportid='"
					+ this.getReportID()
					+ "' AND a.fileid||'_'||a.dmfileid=b.fileid  ) ";

			System.out.println("transfer filter by report id : " + query);
			mainLogs = new ArrayList<MainLog>();
			setQuery(query);
			setMainLogs(mainLogs);
			importMainLogs = new MainLogDataModel(mainLogs);
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}
	}

	public void filterbyReleaseTag() {
		try {
			if (this.getReleaseTag().isEmpty() && this.getReleaseTag() == "") {
				displayErrorMessageToUser("Please select Release Tag", "");
				return;
			}
			resetFilterbyStatus();

			query = "SELECT a.FILEID, a.FILENAME,a.Payor, a.CLIENTID, a.LAYOUTID, a.DATATYPE, a.FILE_SIZE, a.FILE_DATE, "
					+ "TIMESTAMP, FILE_HASHKEY, FILE_RECORD_CNT, IMPORT_RECORD_CNT, UNIQUE_RECORDS_HASH,DUP_RECORD_CNT, STATUS_OF_IMPORT, FULLPATH, GETSTAT, " 
					+ "STARTTIME, ENDTIME, TRANSFER_STATUS,a.DMFILEID,PROCESSFILEPATH, PROCESSSTATUS,EMAILSTATUS,CUTTINGFLOOR,PROCESS_TYPE,PROCESS_TYPE_DETAIL , " 
					+ "importserver , a.empgrp  ,a.aitablename,a.HISERVERNAME,a.HISCHEMANAME,a.hitablename, "
					+ "a.wherecondition,a.sn,a.retransfer_detail,a.releaseno,a.PROCESSDATE,a.DELETE_STATUS from AIP_DASHBOARD_TRANSFER a "  
					+ "where a.clientid='"+this.getClient()+"' and EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='"+this.getReleaseTag()+"' AND a.dmfileid=b.dmfileid and a.filename=b.filename )";

			System.out.println("transfer filter by release tag : " + query);
			mainLogs = new ArrayList<MainLog>();
			setQuery(query);
			setMainLogs(mainLogs);
			importMainLogs = new MainLogDataModel(mainLogs);
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Unexpected Error Occured. Please try again!!", "Error "
							+ e.getMessage());
		}
	}
	
	@Override
	public void changeReleaseTag() {
		resetFilters();

		reportsIDs = new ArrayList<String>();
		setReportsIDs(reportsIDs);
		this.appId = "";
		appIdList = new ArrayList<String>();
		setAppIdList(appIdList);
		handleAppIdChange();
	}
	
	@SuppressWarnings("rawtypes")
	public void newInitTransferToHI() throws InterruptedException {

		log.info("This is a new transfer platform");
		
		try {
			int firstIndex = 0;
			String selectedFileIds = "";
			if (selectedLogs.isEmpty()) {
				displayErrorMessageToUser("No Files Selected", "Transfer Error");
				return;
			}
			else
			{
				firstIndex++;
			}
			LinkedHashMap<String, String> linkedmap = new LinkedHashMap<String, String>();
			LinkedHashMap<String, String> selectedFieldsID = new LinkedHashMap<String, String>();
			LinkedHashMap<String, String> importserver = new LinkedHashMap<String, String>();

			System.out.println("Selected log size: " + selectedLogs.size());
			for (int j = 0; j < selectedLogs.size(); j++) {
				if (selectedLogs.get(j).getStatusOfImport()
						.equalsIgnoreCase("SUCCESS")
						&& !selectedLogs.get(j).getTransferStatus()
								.equalsIgnoreCase("QUEUED")
						&& !selectedLogs.get(j).getTransferStatus()
								.equalsIgnoreCase("RUNNING")
						&& !selectedLogs.get(j).getHischemaname().isEmpty()
						&& !selectedLogs.get(j).getServername().isEmpty()
						&& !selectedLogs.get(j).getHiservername().isEmpty()) {

					linkedmap.put(selectedLogs.get(j).getHischemaname(),
							selectedLogs.get(j).getHiservername());

					importserver.put(selectedLogs.get(j).getServername(), "");

				}
			}

			Set set1 = null;
			set1 = importserver.entrySet();
			Iterator ii = set1.iterator();
			while (ii.hasNext()) {
				Map.Entry mee = null;
				mee = (Map.Entry) ii.next();

				Set set = null;
				set = linkedmap.entrySet();
				Iterator i = set.iterator();
				//while (i.hasNext()) {
					Map.Entry me = null;
					me = (Map.Entry) i.next();
					for (int j = 0; j < selectedLogs.size(); j++) {
						if (selectedLogs.get(j).getStatusOfImport()
								.equalsIgnoreCase("SUCCESS")
								&& !selectedLogs.get(j).getTransferStatus()
										.equalsIgnoreCase("QUEUED")
								&& !selectedLogs.get(j).getTransferStatus()
										.equalsIgnoreCase("RUNNING")
								&& !selectedLogs.get(j).getHischemaname()
										.isEmpty()
								&& !selectedLogs.get(j).getServername()
										.isEmpty()
								&& !selectedLogs.get(j).getHiservername()
										.isEmpty()) {

							if (mee.getKey().equals(
									selectedLogs.get(j).getServername())) {

								if (me.getKey().equals(
										selectedLogs.get(j).getHischemaname())
										&& me.getValue().equals(
												selectedLogs.get(j)
														.getHiservername())) {
									selectedFieldsID.put(
											selectedLogs.get(j).getFileID()
													+ "_"
													+ selectedLogs.get(j)
															.getDmFileID(), "");

								}

							}
						}
					}

					Set fileiddmfileidset = null;
					fileiddmfileidset = selectedFieldsID.entrySet();
					Iterator dm = fileiddmfileidset.iterator();
					while (dm.hasNext()) {
						Map.Entry id = null;
						id = (Map.Entry) dm.next();
						selectedFileIds = selectedFileIds + "," + id.getKey();

					}
					if (selectedFileIds.length() > 0) {
						selectedFileIds = selectedFileIds.substring(1);

					}
					ArrayList<String> selectedFiles = new ArrayList<String>();
					//selectedFiles = groupinto4(selectedFileIds);
					MainLogBeanScrubDAO mlbsd = new MainLogBeanScrubDAO();
					String requestId = "";
					try {
						mlbsd.insertForTransfer(selectedLogs, getUserinfo().getFullname());
						requestId = mlbsd.getReportId();
						log.info("The requestId is: " + requestId);
					} catch (Exception e) {
						e.printStackTrace();
						log.info("The insertion have a problem : " + e.getMessage() + " " + e.getMessage());
					}
					
					String command = AIConstant.shFilelocation + "runTransfer.sh ";
					
					/*command += "-c ";
					command += this.client + " -f";
					command += " '" + selectedFiles.get(l) + "' -h '";
					command += me.getValue() + "' -s '";
					command += me.getKey() + "' -i '";
					command += mee.getKey() + "'";*/
					
					command += "-r ";
					command += requestId;
					log.info("The command to run is: " + command); 
					RunTransfer rtransfer = new RunTransfer();
					log.info("The transfer has been started.");
					rtransfer.setCommandtoRun(command);
					rtransfer.init();
					log.info("The transfer process is finished!!!!!");

					command = "";
					firstIndex++;

					Thread.sleep(1000);
					selectedFileIds = "";
					selectedFieldsID.clear();
					log.info("This is the inner while loop");
				//}
				log.info("This is a outside of innner while");

			}

			if (firstIndex > 0) {
				String msg = "Your transfer request has been submitted.Please refer transfer log for more details";

				displayInfoMessageToUser(msg, "Transfer Status");
			} else {
				displayErrorMessageToUser("No Files Selected", "Transfer Error");
				return;
			}

			setSelectedLogs(null);
			filterLog();

		} catch (Exception e) {
			displayErrorMessageToUser(
					"Error in Transfer Configurations!!! Please Verify it ",
					"Transfer Error");
		}
		
		updateView();

	}
	
	@SuppressWarnings("rawtypes")
	public void oldInitTransferToHI() throws InterruptedException {

		log.info("This is a old transfer platform");
		try {
			int firstIndex = 0;
			String selectedFileIds = "";
			if (selectedLogs.isEmpty()) {
				displayErrorMessageToUser("No Files Selected", "Transfer Error");
				return;
			}
			LinkedHashMap<String, String> linkedmap = new LinkedHashMap<String, String>();
			LinkedHashMap<String, String> selectedFieldsID = new LinkedHashMap<String, String>();
			LinkedHashMap<String, String> importserver = new LinkedHashMap<String, String>();

			System.out.println("Selected log size: " + selectedLogs.size());
			for (int j = 0; j < selectedLogs.size(); j++) {
				if (selectedLogs.get(j).getStatusOfImport()
						.equalsIgnoreCase("SUCCESS")
						&& !selectedLogs.get(j).getTransferStatus()
								.equalsIgnoreCase("QUEUED")
						&& !selectedLogs.get(j).getTransferStatus()
								.equalsIgnoreCase("RUNNING")
						&& !selectedLogs.get(j).getTransferStatus()
								.equalsIgnoreCase("SUCCESS")
						&& !selectedLogs.get(j).getTransferStatus()
								.equalsIgnoreCase("FAILED")
						&& !selectedLogs.get(j).getHischemaname().isEmpty()
						&& !selectedLogs.get(j).getServername().isEmpty()
						&& !selectedLogs.get(j).getHiservername().isEmpty()) {

					linkedmap.put(selectedLogs.get(j).getHischemaname(),
							selectedLogs.get(j).getHiservername());

					importserver.put(selectedLogs.get(j).getServername(), "");

				}
			}

			Set set1 = null;
			set1 = importserver.entrySet();
			Iterator ii = set1.iterator();
			while (ii.hasNext()) {
				Map.Entry mee = null;
				mee = (Map.Entry) ii.next();

				Set set = null;
				set = linkedmap.entrySet();
				Iterator i = set.iterator();
				while (i.hasNext()) {
					Map.Entry me = null;
					me = (Map.Entry) i.next();
					for (int j = 0; j < selectedLogs.size(); j++) {
						if (selectedLogs.get(j).getStatusOfImport()
								.equalsIgnoreCase("SUCCESS")
								&& !selectedLogs.get(j).getTransferStatus()
										.equalsIgnoreCase("QUEUED")
								&& !selectedLogs.get(j).getTransferStatus()
										.equalsIgnoreCase("RUNNING")
								&& !selectedLogs.get(j).getTransferStatus()
										.equalsIgnoreCase("FAILED")
								&& !selectedLogs.get(j).getTransferStatus()
										.equalsIgnoreCase("SUCCESS")
								&& !selectedLogs.get(j).getHischemaname()
										.isEmpty()
								&& !selectedLogs.get(j).getServername()
										.isEmpty()
								&& !selectedLogs.get(j).getHiservername()
										.isEmpty()) {

							if (mee.getKey().equals(
									selectedLogs.get(j).getServername())) {

								if (me.getKey().equals(
										selectedLogs.get(j).getHischemaname())
										&& me.getValue().equals(
												selectedLogs.get(j)
														.getHiservername())) {
									selectedFieldsID.put(
											selectedLogs.get(j).getFileID()
													+ "_"
													+ selectedLogs.get(j)
															.getDmFileID(), "");

								}

							}
						}
					}

					Set fileiddmfileidset = null;
					fileiddmfileidset = selectedFieldsID.entrySet();
					Iterator dm = fileiddmfileidset.iterator();
					while (dm.hasNext()) {
						Map.Entry id = null;
						id = (Map.Entry) dm.next();
						selectedFileIds = selectedFileIds + "," + id.getKey();

					}
					if (selectedFileIds.length() > 0) {
						selectedFileIds = selectedFileIds.substring(1);

					}
					ArrayList<String> selectedFiles = new ArrayList<String>();
					selectedFiles = groupinto4(selectedFileIds);

					for (int l = 0; l < selectedFiles.size(); l++) {
						String command = AIConstant.shFilelocation
								+ "./runTransferOld.sh ";
						command += "-c ";
						command += this.client + " -f";
						command += " '" + selectedFiles.get(l) + "' -h '";
						command += me.getValue() + "' -s '";
						command += me.getKey() + "' -i '";
						command += mee.getKey() + "'";
						RunTransfer rtransfer = new RunTransfer();
						System.out.println(command);
						rtransfer.setCommandtoRun(command);
						rtransfer.init();

						command = "";
						firstIndex++;

					}
					Thread.sleep(1000);
					selectedFileIds = "";
					selectedFieldsID.clear();
				}

			}

			if (firstIndex > 0) {
				String msg = "Your transfer request has been submitted.Please refer transfer log for more details";

				displayInfoMessageToUser(msg, "Transfer Status");
			} else {
				displayErrorMessageToUser("No Files Selected", "Transfer Error");
				return;
			}

			setSelectedLogs(null);
			filterLog();

		} catch (Exception e) {
			displayErrorMessageToUser(
					"Error in Transfer Configurations!!! Please Verify it ",
					"Transfer Error");
		}
		
		updateView();

	}
	
	public void reinitTransferToHI(MainLog mainlog) {

		try {
			displayInfoMessageToUser("File " + mainlog.getFileName()
					+ " has been processed for re-transfer",
					"Re-transfer Status");
			//String command = AIConstant.shFilelocation + "./runTransfer.sh ";runTransferOld
			String command = AIConstant.shFilelocation + "./runTransferOld.sh ";
			command += "-c ";
			command += this.client + " -f";
			command += " '" + mainlog.getFileID() + "_" + mainlog.getDmFileID()
					+ "' -h '";
			command += mainlog.getHiservername() + "' -s '";
			command += mainlog.getHischemaname() + "' -i '";
			command += mainlog.getServername() + "' -r '";
			command += mainlog.getSn() + "'";
			RunTransfer rtransfer = new RunTransfer();
			rtransfer.setCommandtoRun(command);
			rtransfer.init();
			System.out.println("Command for Re-transfer: " + command);
			updateView();
		} catch (Exception e) {
			displayErrorMessageToUser(
					"Error in Re-transfer Configuations!!! Please Verify it ",
					"Re-transfer Error");
		}

	}
	
	public void updateView()
	{
		System.out.println("VIEW : " + this.selectedfiltertype);
		if(this.selectedfiltertype==null || this.selectedfiltertype.isEmpty())
		{
			filterLog();
		}
		else if(this.selectedfiltertype.compareTo("filterbyreportid")==0)
		{
			
			filterbyReportIDs();	
			
		}
		else if(this.selectedfiltertype.compareTo("filterbyreleaseno")==0)
		{
			
			filterbyReleaseNumber();
		}
		else if(this.selectedfiltertype.compareTo("filterbytimestamp")==0)
		{
		
			filterLog();
		} else if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			setAppId(getAppId());
			setReleaseTag(getReleaseTag());
			filterbyReleaseTag(); 
		} 
	}


}
