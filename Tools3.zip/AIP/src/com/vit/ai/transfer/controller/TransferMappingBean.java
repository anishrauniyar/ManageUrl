/*
 *Class Name : TransferMappingBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.controller;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import com.vit.ai.transfer.model.AIStructure_key;
import com.vit.ai.transfer.model.HIStructure_value;

/**
 * Mapper Controller for label changer 
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 30 Mar 2015
 */
public class TransferMappingBean {

	private AIStructure_key aiobject;
	private HIStructure_value hiobject;

	private boolean matches = false;

	public TransferMappingBean(AIStructure_key aiobject,
			HIStructure_value hiobject) {
		this.aiobject = aiobject;
		this.hiobject = hiobject;
		if (aiobject.getName().compareTo(hiobject.getName()) == 0) {

			this.matches = true;
		} else {
			this.matches = false;
		}
	}

	public boolean isMatches() {
		return matches;
	}

	public void setMatches(boolean matches) {
		this.matches = matches;
	}

	public AIStructure_key getAiobject() {
		return aiobject;
	}

	public void setAiobject(AIStructure_key aiobject) {
		this.aiobject = aiobject;
	}

	public HIStructure_value getHiobject() {
		return hiobject;
	}

	public void setHiobject(HIStructure_value hiobject) {
		this.hiobject = hiobject;
	}

	public void setMapped(ValueChangeEvent e) {
		HIStructure_value value = new HIStructure_value();
		@SuppressWarnings("unused")
		String val = "";
		if (e.getNewValue() != null) {
			val = (e.getNewValue().toString());
		}

		FacesContext context = FacesContext.getCurrentInstance();
		value = context.getApplication().evaluateExpressionGet(context,
				"#{mapped}", HIStructure_value.class);

		this.hiobject = value;

	}

}
