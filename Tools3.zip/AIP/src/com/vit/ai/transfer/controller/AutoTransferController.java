/*
 *Class Name : AutoTransferController.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.component.datatable.DataTable;

import com.vit.ai.transfer.model.AutoTransferConf;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 07 Dec 2015
 */
@ManagedBean
@ViewScoped
public class AutoTransferController extends AbstractController implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ArrayList<AutoTransferConf> listofAutoTransferConf;
	private ArrayList<AutoTransferConf> filteredLogs;

	public ArrayList<AutoTransferConf> getListofAutoTransferConf() {
		return listofAutoTransferConf;
	}

	public void setListofAutoTransferConf(
			ArrayList<AutoTransferConf> listofAutoTransferConf) {
		this.listofAutoTransferConf = listofAutoTransferConf;
	}

	public AutoTransferController() {

	}

	@PostConstruct
	public void init() {

		loadTransferConfiguration();
	}

	private void loadTransferConfiguration() {
		try {
			if (this.filteredLogs != null) {
				this.filteredLogs = null;
				DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
						.getViewRoot().findComponent("autoTForm:autoTConfLog");
				dt1.setFilters(null);
				dt1.reset();
			}
			listofAutoTransferConf = new ArrayList<AutoTransferConf>();
			String query = "  SELECT  B.CLIENTID||'-('||A.ClientName||')', B.MACHINE, B.CREATED_DATE, B.USERLOG, B.FREQUENCY, "
					+ " B.MONITOR_START_DATE, B.AUTOTRANSFER  FROM HAWKEYEMASTER.M_CLIENTS A "
					+ " JOIN AIP_CLIENT_SERVER B  ON A.CLIENTID=B.CLIENTID "
					+ " ORDER BY B.CLIENTID  ASC ";
			ConnectDB db = new ConnectDB();
			db.initialize();
			List<List<String>> listAll = db.resultSetToListOfList(query);
			db.endConnection();
			if (listAll.size() > 0) {
				for (int i = 1; i < listAll.size(); i++) {
					listofAutoTransferConf.add(new AutoTransferConf(listAll
							.get(i).get(0), listAll.get(i).get(1), listAll.get(
							i).get(2), listAll.get(i).get(3), listAll.get(i)
							.get(4), listAll.get(i).get(5), listAll.get(i).get(
							6)));
					setListofAutoTransferConf(listofAutoTransferConf);
				}
			}
		} catch (Exception e) {
			displayInfoMessageToUser("Query Execution Failed", "ERROR");
		}

	}

	public void handleSave(AutoTransferConf obj) {
		try {
			String query = "update AIP_CLIENT_SERVER  set autotransfer= '"
					+ obj.getAutotransfer() + "' where clientID='"
					+ obj.getClientID().split("\\-")[0].toString().trim() + "'";

			ConnectDB db = new ConnectDB();
			db.initialize();

			int status = db.update(query);

			db.endConnection();
			if (status == 1) {
				displayInfoMessageToUser("Successfully Updated",
						"Auto Transfer Status");
				loadTransferConfiguration();
			} else {
				displayErrorMessageToUser("Unable to update. Please try again",
						"ERROR");
			}
		} catch (Exception ex) {
			displayErrorMessageToUser("Update Failed", "Sorry");
		}

	}

	public ArrayList<AutoTransferConf> getFilteredLogs() {
		return filteredLogs;
	}

	public void setFilteredLogs(ArrayList<AutoTransferConf> filteredLogs) {
		this.filteredLogs = filteredLogs;
	}

	public boolean filterByName(Object value, Object filter, Locale locale) {
		String filterText = (filter == null) ? null : filter.toString().trim();
		if (filterText == null || filterText.equals("")) {
			return true;
		}

		if (value == null) {
			return false;
		}

		String Name = value.toString().toUpperCase();
		filterText = filterText.toUpperCase();

		if (Name.contains(filterText)) {
			return true;
		} else {
			return false;
		}
	}
}
