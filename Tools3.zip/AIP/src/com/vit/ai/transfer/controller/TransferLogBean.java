/* 
 *Class Name : TransferLogBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import com.vit.ai.commons.model.MainLogDataModel;
import com.vit.ai.constant.AIConstant;
import com.vit.ai.inventory.controller.MainLogBean;
import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.session.FilterLogController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller Class for Transfer Log
 * 
 * @author Binesh Sah
 *
 * @version 1.0 30 July 2014
 */
@ManagedBean
@ViewScoped
public class TransferLogBean extends MainLogBean {

	private static Logger log = Logger.getLogger(TransferLogBean.class);
	
	protected ArrayList<String> appIdList;
	protected String appId;
	
	protected ArrayList<String> releaseTagList;
	protected String releaseTag;
	
	@Override
	public void changeReleaseTag() {
		resetFilters();
		releaseNos = new ArrayList<String>();
		setReleaseNos(releaseNos);
		reportsIDs = new ArrayList<String>();
		setReportsIDs(reportsIDs);
		this.appId = "";
		appIdList = new ArrayList<String>();
		setAppIdList(appIdList);
		handleAppIdChange();
	}
	
	public ArrayList<String> getAppIdList() {
		return appIdList;
	}

	public void setAppIdList(ArrayList<String> appIdList) {
		String query = "SELECT DISTINCT(APP_ID) FROM IMP_FILES_RELTAG_RELN WHERE CLIENTID = '"+filterData.getClientID()+"'";

		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					appIdList.add(rs.get(i).get(0));
				}
			}
		}
	}

	public void handleAppIdChange() {
		log.info("This is an app id change filter.");
		String query = "SELECT DISTINCT releasetagidbyapp FROM (SELECT releasetagidbyapp FROM cpd.cp_releasetagbyapp@"+AIConstant.CPD_LINK+"  WHERE applicationid = '"+this.appId+"'" + 
						" ORDER BY CREATED DESC) UNION SELECT DISTINCT RELTAG FROM imp_files_reltag_reln WHERE app_id = '"+this.appId+"'";
		log.info(query);
		this.releaseTagList = new ArrayList<>();
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				for (int i = 1; i < rs.size(); i++) {

					releaseTagList.add(rs.get(i).get(0));
				}
			}
		}
	}
	
	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public ArrayList<String> getReleaseTagList() {
		return releaseTagList;
	}

	public void setReleaseTagList(ArrayList<String> releaseTagList) {
		this.releaseTagList = releaseTagList;
	}

	public String getReleaseTag() {
		return releaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		this.releaseTag = releaseTag;
	}

	public TransferLogBean() {

		this.init();
	}

	@Override
	public void init() {
		setFilterData((FilterLogController) getSessionBean("filterLogController"));

		setTodaysDate(new Date());

		clients = new LinkedHashMap<String, String>();
		setClients(clients);

	}

	private static final long serialVersionUID = 1L;

	@Override
	public void filterLog() {

		try{
			
		
		String timeStampFormat = "dd.MM.yyyy hh24:mi:ss";
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmTL:transferLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}

		String query = "SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename,d.releaseno "
				+ " FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d"
				+ " WHERE (a.fileid||'_'||a.dmfileid=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid ";

		String clid = filterData.getClientID();

		if (clid != null && !clid.equals("")) {
			query += " AND a.CLIENTID='" + clid + "' ";
		}

		if (startDate != null && !startDate.equals("")) {
			query += " AND a.histarttime >= TO_DATE('"
					+ dateFormat.format(startDate) + "','" + timeStampFormat
					+ "')";
		}

		if (endDate != null && !endDate.equals("")) {
			query += " AND a.hiendtime <= TO_DATE('"
					+ dateFormat.format(endDate) + "','" + timeStampFormat
					+ "')";
		}

		query += ") ORDER BY  To_Number(FILEID) DESC";

		setQuery(query);
		mainLogs = new ArrayList<MainLog>();
		setMainLogs(mainLogs);
		importMainLogs = new MainLogDataModel(mainLogs);
		}catch(Exception e){
			displayErrorMessageToUser("Query Execution Failed"+e.getMessage(), "Query Failed");
			
		}

	}

	@Override
	public void setMainLogs(ArrayList<MainLog> mainLogs) {
		try{
			
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> logList = db.resultSetToListOfList(query);
		db.endConnection();

		if (logList.size() > 0) {
			for (int i = 1; i < logList.size(); i++) {

				mainLogs.add(new MainLog(logList.get(i - 1).get(0), logList
						.get(i).get(0), logList.get(i - 1).get(1), logList.get(
						i).get(1), logList.get(i).get(2),
						logList.get(i).get(3), logList.get(i).get(4), logList
								.get(i).get(5), logList.get(i).get(6), logList
								.get(i).get(7), logList.get(i).get(8), logList
								.get(i).get(9), logList.get(i).get(10), logList
								.get(i).get(11), logList.get(i).get(12),
						logList.get(i).get(13), logList.get(i).get(14), logList
								.get(i).get(15), logList.get(i).get(16)));
			}

		}
		}
		catch(Exception e){
			displayErrorMessageToUser("Query Execution Failed"+e.getMessage(), "Query Failed");
			
		}

	}
	public void filterbyReleaseNumber() {
		try{
			
		
		if(this.getReleaseNum().isEmpty() && this.getReleaseNum()==""){
			displayErrorMessageToUser("Please select Data Batch", "");
			return;
		}
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmTL:transferLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}

		String query = "SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename "
				+ ",d.releaseno FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d"
				+ " WHERE (a.fileid||'_'||a.dmfileid)=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid and" +
				" a.clientid='"
				+ filterData.getClientID()
				+ "'"
				+ " and d.releaseno='"
				+ this.getReleaseNum() + "'";

		log.info("transfer log filter by relesseno "+query);

		setQuery(query);
		mainLogs = new ArrayList<MainLog>();
		setMainLogs(mainLogs);
		importMainLogs = new MainLogDataModel(mainLogs);
		}catch(Exception e){
			displayErrorMessageToUser("Query Execution Failed"+e.getMessage(), "Query Failed");
			
		}
	}
	public void handleFilterchange(){
		setSelectedfiltertype(this.getFiltertype());
				
		if(this.getFiltertype().compareTo("filterbyreleaseno")==0){
			releaseNos = new ArrayList<String>();
			setReleaseNos(releaseNos);
		}
		
		if (this.getFiltertype().compareTo("filterbyreportid") == 0) {
			reportsIDs = new ArrayList<String>();
			setReportsIDs(reportsIDs);
		}
		
		if (this.getFiltertype().compareTo("filterbyreleasetag") == 0) {
			appIdList = new ArrayList<String>();
			setAppIdList(appIdList);
		}
	}
	public void filterbyReportID(){
		log.info("report id is "+this.reportID);
		
		try{
			if(this.reportID.isEmpty() && this.reportID==""){
				displayErrorMessageToUser("Please select Report ID", "");
				return;
			}
		
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmTL:transferLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}

		query = "SELECT * FROM (SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename "
				+ ",d.releaseno FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d"
				+ " WHERE (a.fileid||'_'||a.dmfileid)=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid) c"
				+ " where EXISTS (SELECT 1 FROM imp_inventory_rep_log_details b WHERE b.reportid='"+this.getReportID()+"' AND c.fileid||'_'||c.dmfileid=b.fileid  ) " ;
				

		log.info("transfer log filter by report id : "+query);

		setQuery(query);
		mainLogs = new ArrayList<MainLog>();
		setMainLogs(mainLogs);
		importMainLogs = new MainLogDataModel(mainLogs);
		}catch(Exception e){
			displayErrorMessageToUser("Query execution failed "+e.getMessage(), "Query Status");
		}
	}

	public void filterbyReleaseTag() {
		log.info("Release Tag is "+this.releaseTag);
		
		try{
			if(this.releaseTag.isEmpty() && this.releaseTag==""){
				displayErrorMessageToUser("Please select Release Tag", "");
				return;
			}
		
		if (this.filteredLogs != null) {
			this.filteredLogs = null;
			DataTable dt1 = (DataTable) FacesContext.getCurrentInstance()
					.getViewRoot().findComponent("frmTL:transferLogTable");
			dt1.setFilters(null);
			dt1.reset();

		}

		query = "SELECT * FROM (SELECT a.fileid ,a.dmfileid,a.layoutid, employername, a.aitablename, hischemaname, hitablename,b.recordcount AS AIP_record, hirows as  hi_record, transfertype, histatus, hierrmsg, histarttime, hiendtime,c.payor,c.datatype,d.filename "
				+ ",d.releaseno FROM hi_main_log   a , imp_main_det_log b ,imp_layouts  c,imp_main_log d"
				+ " WHERE (a.fileid||'_'||a.dmfileid)=b.fileid and  a.aitablename=b.aitablename AND d.fileid=a.fileid AND a.layoutid=c.layoutid) c"
				+ " where EXISTS (SELECT 1 FROM IMP_FILES_RELTAG_RELN b WHERE b.reltag='"+this.releaseTag+"' AND b.dmfileid=c.dmfileid) " ;
				

		log.info("transfer log filter by Release Tag : "+query);

		setQuery(query);
		mainLogs = new ArrayList<MainLog>();
		setMainLogs(mainLogs);
		importMainLogs = new MainLogDataModel(mainLogs);
		}catch(Exception e){
			displayErrorMessageToUser("Query execution failed "+e.getMessage(), "Query Status");
		}
	}
}
