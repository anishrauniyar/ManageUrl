/* 
 *Class Name : LabelChangerBean.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;

import org.primefaces.context.RequestContext;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.session.ViewsParameters;
import com.vit.ai.transfer.model.AIStructure_key;
import com.vit.ai.transfer.model.HIStructure_value;
import com.vit.ai.transfer.model.LegacyTransfer;
import com.vit.ai.utils.AbstractController;
import com.vit.dbconnection.ConnectDB;

/**
 * Controller class for Label changer -Transfer Configuration 
 * 
 * @author Aashish Dhungana
 *
 * @version 1.0 21 Sep 2014
 */
@ManagedBean
@ViewScoped
public class LabelChangerBean extends AbstractController {
	private String sn;
	private String clientid;
	private String aiservername;
	private String hischemaname;
	private ArrayList<AIStructure_key> listofAIFields;
	private ArrayList<HIStructure_value> listofHIFields;
	private String selectedname;
	private String sid="";
	private String tcpport="";
	private String pwd="";

	// private LinkedHashMap<String,String> selectlistofHIFields;

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getTcpport() {
		return tcpport;
	}

	public void setTcpport(String tcpport) {
		this.tcpport = tcpport;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	private ArrayList<HIStructure_value> selectlistofHIFields;

	public ArrayList<HIStructure_value> getSelectlistofHIFields() {
		return selectlistofHIFields;
	}

	public void setSelectlistofHIFields(
			ArrayList<HIStructure_value> selectlistofHIFields) {
		this.selectlistofHIFields = selectlistofHIFields;
	}

	private String mode;
	@ManagedProperty(value = "#{loginbean}")
	protected ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	private String username;
	private ArrayList<TransferMappingBean> listoftransfercolumns;

	public String getHischemaname() {
		return hischemaname;
	}

	public void setHischemaname(String hischemaname) {
		this.hischemaname = hischemaname;
	}

	private String aitablename;
	private String hiservername;
	private String hitablename;

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public String getAitablename() {
		return aitablename;
	}

	public void setAitablename(String aitablename) {
		this.aitablename = aitablename;
	}

	public String getHiservername() {
		return hiservername;
	}

	public void setHiservername(String hiservername) {
		this.hiservername = hiservername;
	}

	public String getHitablename() {
		return hitablename;
	}

	public ArrayList<TransferMappingBean> getListoftransfercolumns() {
		return listoftransfercolumns;
	}

	public void setListoftransfercolumns(
			ArrayList<TransferMappingBean> listoftransfercolumns) {
		this.listoftransfercolumns = listoftransfercolumns;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public void setHitablename(String hitablename) {
		this.hitablename = hitablename;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAiservername() {
		return aiservername;
	}

	public void setAiservername(String aiservername) {
		this.aiservername = aiservername;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getSelectedname() {
		return selectedname;
	}

	public void setSelectedname(String selectedname) {
		this.selectedname = selectedname;
	}

	public LabelChangerBean(String value) {

	}

	public LabelChangerBean() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		this.sn = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("sn");
		this.clientid = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("clid");
		this.aitablename = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("aitable");
		this.hiservername = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("hiserver");
		this.hitablename = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("hitable");
		this.mode = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("mode");
		this.hischemaname = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("hischema");
		// this.hischemaname="HI0"+this.clientid+"001";
		this.username = (String) facesContext.getExternalContext()
				.getRequestParameterMap().get("user");
		this.aiservername = populateaiServer(this.clientid);
		populateHitoSelect();// Function that sets the dropdown for hi fields.

		if (this.mode.compareTo("edit") == 0
				|| this.mode.compareTo("view") == 0) {
			populateFields();
			populateobjects();
		} else {
			populateaifields();
			populatehifields();
			populateobjects();
		}

	}

	public String populateaiServer(String client) {
		
		this.aiservername=AIConstant.RAC_SERVER_NAME;
		return this.aiservername;
	}

	public void populateobjects() {
		this.listoftransfercolumns = new ArrayList<TransferMappingBean>();
		String possible_cases = TestCases();

		if (this.listofAIFields.size() > 0 && this.listofHIFields.size() > 0) {

			switch (possible_cases) {
			case "case1": {
				System.out.println("case1 selected");
				for (int i = 0; i < this.listofAIFields.size(); i++) {

					if (i >= this.listofHIFields.size()) {
						HIStructure_value hiobject = new HIStructure_value("0",
								"NOT APPLICABLE");
						TransferMappingBean mappingobject = new TransferMappingBean(
								this.listofAIFields.get(i), hiobject);
						this.listoftransfercolumns.add(mappingobject);
					} else {
						TransferMappingBean mappingobject = new TransferMappingBean(
								this.listofAIFields.get(i),
								this.listofHIFields.get(i));
						this.listoftransfercolumns.add(mappingobject);
					}
				}
				break;
			}
			case "case2": {
				System.out.println("case2 selected");
				System.out.println("Size HI and AI : " + this.listofHIFields.size() + "and " + this.listofAIFields.size());
				for (int i = 0; i < this.listofHIFields.size(); i++) {
					if (i >= this.listofAIFields.size()) {
						System.out.println("Getting here : " + i);
						AIStructure_key aiobject = new AIStructure_key("0",
								"NOT APPLICABLE");
						TransferMappingBean mappingobject = new TransferMappingBean(
								aiobject, this.listofHIFields.get(i));
						this.listoftransfercolumns.add(mappingobject);
					} else {
						TransferMappingBean mappingobject = new TransferMappingBean(
								this.listofAIFields.get(i),
								this.listofHIFields.get(i));
						this.listoftransfercolumns.add(mappingobject);
					}
				}
				break;
			}

			case "case3": {
				System.out.println("case3 selected");
				for (int i = 0; i < this.listofHIFields.size(); i++) {

					TransferMappingBean mappingobject = new TransferMappingBean(
							this.listofAIFields.get(i),
							this.listofHIFields.get(i));
					this.listoftransfercolumns.add(mappingobject);

				}
				break;
			}
			}
		}

	}

	public String TestCases() {
		String cases = "";

		// Case 1: AI has more fields than HI
		if (this.listofAIFields.size() > this.listofHIFields.size()) {
			cases = "case1";
		}
		// case 2 : Hi has more fields than AI
		else if (this.listofHIFields.size() > this.listofAIFields.size()) {
			cases = "case2";
		}
		// case 3 : AI and HI fields are same
		else if (this.listofHIFields.size() == this.listofAIFields.size()) {
			cases = "case3";
		}

		return cases;
	}

	public void populateFields() {
		String aischema = "AI0" + this.clientid;
		String query = " SELECT A.COLUMN_ID,COLUMN_NAME,Nvl(b.HICOLUMNID,a.COLUMN_ID)  AS HICOLUMNID ,  "
				+ " Nvl(b.HICOLUMNNAME,a.COLUMN_NAME) AS HICOLUMNNAME   FROM "
				+ " (SELECT  COLUMN_NAME,COLUMN_ID,TABLE_NAME FROM ALL_TAB_COLS "
				+ " WHERE TABLE_NAME=UPPER('"
				+ aitablename
				+ "')  and owner='"
				+ aischema
				+ "'  ) A "
				+ " LEFT JOIN  ( SELECT DISTINCT  AITABLENAME,CLIENTID FROM  AIPDB.HI_LEGACY_TRANSFER )C "
				+ " ON C.AITABLENAME = A.TABLE_NAME AND C.CLIENTID='"
				+ this.clientid
				+ "' "
				+ " LEFT JOIN AIPDB.HI_LEGACY_LABEL_CHG B "
				+ " ON A.COLUMN_ID=B.AICOLUMNID "
				+ " AND B.SN='"
				+ this.sn
				+ "' ORDER BY A.COLUMN_ID ";
		System.out.println("Connecting to AISChema to Populate Both Fields : " + query);

		ConnectDB db = new ConnectDB();
		db.initialize(this.aiservername, AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID, aischema,"LOCAL");
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		this.listofAIFields = new ArrayList<AIStructure_key>();
		this.listofHIFields = new ArrayList<HIStructure_value>();

		if (rs == null) {
			displayErrorMessageToUser(
					"Cannot conenct to AISERVER.Please make you have provided the correct configuration",
					"AISERVER");
		} else {

			for (int i = 1; i < rs.size(); i++) {
				AIStructure_key aiobject = new AIStructure_key(
						rs.get(i).get(0), rs.get(i).get(1).trim());
				this.listofAIFields.add(aiobject);
				HIStructure_value hiobject = new HIStructure_value(rs.get(i)
						.get(2), rs.get(i).get(3).trim());

				this.listofHIFields.add(hiobject);

			}

		}
	}

	public void populateHitoSelect() {

		this.selectlistofHIFields = new ArrayList<>();
		setHiParameters();
		String query1 = " select  column_name,column_id from all_tab_cols where table_name=Upper('"
				+ hitablename
				+ "')  and owner='"
				+ this.hischemaname
				+ "' order by column_id";

		ConnectDB db1 = new ConnectDB();
		
		
		
		db1.initialize(this.hiservername, this.tcpport,
				this.sid, this.hischemaname,"REMOTE");
		List<List<String>> rs1 = db1.resultSetToListOfList(query1);
		db1.endConnection();
		if (rs1 != null) {
			for (int i = 1; i < rs1.size(); i++) {
				HIStructure_value hiobject1 = new HIStructure_value(rs1.get(i)
						.get(1), rs1.get(i).get(0).trim());
				this.selectlistofHIFields.add(hiobject1);

			}
			this.selectlistofHIFields.add(new HIStructure_value("0",
					"NOT APPLICABLE"));
		}

	}

	public void populateaifields() {
		populateaiServer(this.clientid);
		String aischema = "AI0" + this.clientid;
		String query = " select  column_name,column_id from all_tab_cols where table_name=Upper('"
				+ aitablename
				+ "')  and owner='"
				+ aischema
				+ "' order by column_id ";
		System.out.println("Query Run in AISCHEMA for AI FIELDS : " + query);
		ConnectDB db = new ConnectDB();

		db.initialize(this.aiservername, AIConstant.RAC_SERVICE_PORT,
				AIConstant.RAC_SERVICE_SID, aischema,"LOCAL");

		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();

		this.listofAIFields = new ArrayList<AIStructure_key>();

		if (rs == null) {
			System.out.println("Failed");

			displayErrorMessageToUser(
					"Cannot conenct to AISERVER.Please make you have provided the correct configuration",
					"AISERVER");
		} else {

			for (int i = 1; i < rs.size(); i++) {

				AIStructure_key aiobject = new AIStructure_key(
						rs.get(i).get(1), rs.get(i).get(0).trim());
				this.listofAIFields.add(aiobject);

			}
		}

	}

	public void populatehifields() {
		String query = " select  column_name,column_id from all_tab_cols where table_name=Upper('"
				+ hitablename
				+ "')  and owner='"
				+ this.hischemaname
				+ "' order by column_id";
		System.out.println("QUERY RUN IN HISERVER TO POPULATE HI FIELDS  : " + query);
		setHiParameters();
		ConnectDB db = new ConnectDB();

		db.initialize(this.hiservername, this.tcpport,
				this.sid, this.hischemaname,"REMOTE");
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		this.listofHIFields = new ArrayList<HIStructure_value>();

		if (rs == null) {
			displayErrorMessageToUser(
					"Cannot conenct to HISERVER.Please make you have provided the correct configuration",
					"HISERVER");
		} else {

			for (int i = 1; i < rs.size(); i++) {
				HIStructure_value hiobject = new HIStructure_value(rs.get(i)
						.get(1), rs.get(i).get(0).trim());

				this.listofHIFields.add(hiobject);

				System.out.println(hiobject.getId() + "," + hiobject.getName());

			}

		}

	}

	public void updateTable(String aicid, String aifname, String hicid,
			String value) {
		this.sessionData.setTransferLabelChanged(true);
		String queryupd = "";
		String query = "select * from hi_legacy_label_chg where sn= '"
				+ this.sn + "' and aicolumnid='" + aicid + "'";
		System.out.println("Select Query : " + query);
		ConnectDB db = new ConnectDB();
		db.initialize();
		List<List<String>> rs = db.resultSetToListOfList(query);

		if (rs.size() > 1) {
			queryupd = "Update hi_legacy_label_chg set hicolumnname='" + value
					+ "',hicolumnid='" + hicid + "'  where sn='" + this.sn
					+ "'and aicolumnid='" + aicid + "'";
			System.out.println("Update Query : " + queryupd);
		} else {
			queryupd = "Insert into hi_legacy_label_chg( sn,aicolumnid,aicolumnname,hicolumnid,hicolumnname,userlog) values ('"
					+ this.sn
					+ "','"
					+ aicid
					+ "','"
					+ aifname
					+ "','"
					+ hicid
					+ "','" + value + "','" + this.username + "')";
			System.out.println("Insert Query : " + queryupd);
		}
		try {
			db.executeDML(queryupd);

			displayInfoMessageToUser("Value Updated", "Transfer Label Changed");
		} catch (Exception ex) {
			displayErrorMessageToUser("Value Update Failed", "Error");
		}
		db.endConnection();
	}

	public void handleSubmit() {
		for (int i = 0; i < listoftransfercolumns.size(); i++) {
			if (!this.listoftransfercolumns.get(i).isMatches()
					&& this.listoftransfercolumns.get(i).getHiobject().getId()
							.compareTo(" ") != 0
					&& this.listoftransfercolumns.get(i).getAiobject().getId()
							.compareTo(" ") != 0) {
				updateTable(listoftransfercolumns.get(i).getAiobject().getId(),
						listoftransfercolumns.get(i).getAiobject().getName(),
						listoftransfercolumns.get(i).getHiobject().getId(),
						listoftransfercolumns.get(i).getHiobject().getName());
			}

		}
		updateLabelChangerFlag();
		
		RequestContext.getCurrentInstance().closeDialog("labelChanger");

	}

	public void updateLabelChangerFlag() {
		String query = "";
		LegacyTransfer obj = new LegacyTransfer(this.hischemaname,
				this.hiservername, this.clientid, this.aitablename,
				this.hitablename, this.sn);
		if (obj.getLabelChangeFlag().compareTo("N") == 0) {
			query = "update hi_legacy_transfer set label_change_flag='N' where clientid='"
					+ this.clientid + "' and sn='" + this.sn + "'";
		} else {
			if (obj.getLabelChangeFlag().compareTo("Y") == 0) {
				query = "update hi_legacy_transfer set label_change_flag='S' where clientid='"
						+ this.clientid + "' and sn='" + this.sn + "'";
			}
		}
		ConnectDB db = new ConnectDB();
		db.initialize();
		db.executeDML(query);
		db.endConnection();
	}

	public void setMapped(String value, TransferMappingBean obj) {
		System.out.println("Original ID : " + obj.getHiobject().getId());

		System.out.println("Mapped Value : " + value);

		for (int i = 0; i < this.selectlistofHIFields.size(); i++) {
			System.out.println("ID  : "
					+ this.selectlistofHIFields.get(i).getId() + "Name : "
					+ this.selectlistofHIFields.get(i).getName());

			if (this.selectlistofHIFields.get(i).getName().compareTo(value) == 0) {

				System.out.println("MappedID"
						+ this.selectlistofHIFields.get(i).getId());

				// System.out.println(this.hiobject.getName());
				obj.getHiobject().setId(
						this.selectlistofHIFields.get(i).getId());
				obj.getHiobject().setName(
						this.selectlistofHIFields.get(i).getName());

			}
		}
	}
	
	public void setHiParameters()
	{
		ConnectDB db=new ConnectDB();
		db.initialize();
		String query=" SELECT SVR_TCP_PORT,SVR_SID FROM aip_scrub_server_master WHERE SVR_NAME='"+this.hiservername+"'";
		System.out.println("QUERY THAT RUNS IN HISERVER TO POPULATE HI FIELDS : " + query);
		List<List<String>> rs=db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				this.tcpport=rs.get(1).get(0);
				this.sid=rs.get(1).get(1);
			}
			else
			{
				this.tcpport=AIConstant.RAC_SERVICE_PORT;
				this.sid=AIConstant.RAC_SERVICE_SID;
				//this.sid="d2he";
			}
		}
	}

}
