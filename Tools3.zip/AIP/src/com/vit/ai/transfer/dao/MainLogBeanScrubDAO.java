package com.vit.ai.transfer.dao;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.bean.ManagedProperty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.inventory.model.MainLog;
import com.vit.ai.session.UserInformation;
import com.vit.dbconnection.ConnectDB;

public class MainLogBeanScrubDAO {

	private static Logger log = LoggerFactory.getLogger(MainLogBeanScrubDAO.class);
	protected String reportId;
	
	public String getReportId() {
		return reportId;
	}
	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public void insertForTransfer(ArrayList<MainLog> selectedLogs, String userinfo) {
		
		ConnectDB db = new ConnectDB();
		
		String requestId = "";
		Date presentDate = new Date();
		String parsedDate = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(presentDate);
		
		//INSERTING VALUES IN THE MAIN LOG TABLE
		String insertMainLog = "INSERT INTO hi_request_main_log (REQUESTID, CLIENTID, REQUESTEDBY, REQUESTEDON) " + 
								" VALUES (1, '" + 
								selectedLogs.get(0).getClientID() + "', '" +
								userinfo + "', " +
								" TO_DATE('" + parsedDate + "', 'DD.MM.YYYY HH24:MI:SS'))";
		try {
			db.initialize();
			log.info("Insertion to Main Log is started......");
			log.info("With Query: " + insertMainLog);
			db.executeDML(insertMainLog);
			log.info("Insertion at Main Log completed!!!!");
		} catch (Exception e) {
			log.info("Insertion problem at Main Log : "+ e.getMessage());
		} finally {
			db.endConnection();
		}
		
		//GETTING THE REQUEST ID OF LATEST INSERTED VALUE 
		String requestidQuery = "SELECT requestid FROM hi_request_main_log WHERE " +
							" clientid = '" + selectedLogs.get(0).getClientID() + "' AND " + 
							" requestedby = '" + userinfo + "' AND " +  
							" requestedon = To_Date('" + parsedDate + "', 'DD.MM.YYYY HH24:MI:SS')";
		try {
			db.initialize();
			List<List<String>> rs = db.resultSetToListOfList(requestidQuery);
			requestId = rs.get(1).get(0);
			log.info("The request ID is: " + requestId);
			setReportId(requestId);
		} catch (Exception e) {
			log.info("Problem in getting request ID : " + e.getMessage());
		} finally {
			db.endConnection();
		}
		
		//INSERTING THE VALUE IN THE DETAIL LOG TABLE
		log.info("The total number of selected Logs are: " + selectedLogs.size());
		for (int q = 0; q < selectedLogs.size(); q++) {
			String insertDetailLog = "INSERT INTO hi_request_detail_log " +
									" (REQUESTID, DETAILID, FILEID, DMFILEID, LAYOUTID, SUBLAYOUTID, EMPLOYERNAME, HISCHEMANAME, HITABLENAME, HISERVERNAME) " +
									" VALUES (" + requestId + ", NULL, '" +
									selectedLogs.get(q).getFileID() + "', '" + 
									selectedLogs.get(q).getDmFileID() + "', '" +
									selectedLogs.get(q).getLayoutID() + "', 1, '" +
									selectedLogs.get(q).getEmpgrp().replaceAll("\'", "\''") + "', '" +
									selectedLogs.get(q).getHischemaname() + "', '" +
									selectedLogs.get(q).getHitablename() + "', '" +
									selectedLogs.get(q).getHiservername() + "')";
			try {
				db.initialize();
				log.info("The insertion in Detail Log " + q + " has started....");
				log.info(q + " query: " + insertDetailLog);
				db.executeDML(insertDetailLog);
				log.info(q + " Insertion is completed");
			} catch (Exception e) {
				log.info("Problem in inserting " + q + " log : " + e.getMessage());
			} finally {
				db.endConnection();
			}
		}
		
	}
	
}
