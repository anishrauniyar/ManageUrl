/* 
 *Class Name : AIStructure_key.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.model;

import java.io.Serializable;

/**
 * Model class for Label Changer Ai Structure
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 20 Feb 2014
 */
public class AIStructure_key implements Serializable {

	private static final long serialVersionUID = 957007848488885575L;
	private String id;
	private String name;

	public AIStructure_key(String id, String name) {
		this.setId(id);
		this.setName(name);

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
