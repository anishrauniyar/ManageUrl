/* 
 *Class Name : LegacyTransfer.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.model;

import java.io.Serializable;
import java.util.List;

import com.vit.ai.constant.AIConstant;
import com.vit.dbconnection.ConnectDB;

/**
 * Class for transfer from AI to HI
 * 
 * @author Aashish Dhungana
 * 
 *	@author Binesh Sah
 *
 * @version 1.2 08 July 2014
 */
public class LegacyTransfer implements Serializable {
	private static final long serialVersionUID = 8428424757723375187L;
	private int sn;
	private String clientID;
	private String aiTableName;
	private String hiSchemaName;
	private String hiTableName;
	private String empGrp;
	private String whereCondition;
	private String createdBy;
	private String createdDate;
	private String hiservername;
	private String labelChangeFlag;
	private String tcpport;
	private String sid;

	public LegacyTransfer(String clientID, String aiTableName,
			String hiSchemaName, String hiTableName, String empGrp,
			String whereCondition, String createdBy, String createdDate,
			int sn, String servername, String labelChangeFlag) {
		super();
		this.clientID = clientID;
		this.aiTableName = aiTableName;
		this.hiSchemaName = hiSchemaName;
		this.hiTableName = hiTableName;
		this.empGrp = empGrp;
		this.whereCondition = whereCondition;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.sn = sn;
		this.hiservername = servername;
		if (labelChangeFlag.isEmpty()) {
			this.labelChangeFlag = "Y";
		} else {
			this.labelChangeFlag = labelChangeFlag;
		}
	}

	public LegacyTransfer(String clientID, String aiTableName,
			String hiSchemaName, String hiTableName, String empGrp,
			String whereCondition, String createdBy, String createdDate,
			String servername, String labelChangeFlag) {
		super();
		this.clientID = clientID;
		this.aiTableName = aiTableName;
		this.hiSchemaName = hiSchemaName;
		this.hiTableName = hiTableName;
		this.empGrp = empGrp;
		this.whereCondition = whereCondition;
		this.createdBy = createdBy;
		this.createdDate = createdDate;

		this.hiservername = servername;
		this.labelChangeFlag = computeLabelDifferences();
	}

	public LegacyTransfer(String hischemaname, String hiservername,
			String clientid, String aitablename, String hitablename, String sn) {
		this.hiSchemaName = hischemaname;
		this.hiservername = hiservername;
		this.clientID = clientid;
		this.aiTableName = aitablename;
		this.hiTableName = hitablename;
		this.sn = Integer.parseInt(sn);
		this.labelChangeFlag = computeLabelDifferences();
	}

	public String computeLabelDifferences() {
		//String clientservername = getServerName(this.clientID);
		setHiParameters();
		String labelChange = "Y";
		String query = "SELECT Count(*) FROM (select  column_name,column_id from all_tab_cols@vhaip"
				+ " where table_name=Upper('"
				+ this.aiTableName
				+ "')  and owner='AI0"
				+ this.clientID
				+ "'  AND column_name NOT IN ('PAYORNAME','CLIENTID','EMPGRP','FILEID','ROWNUMBER','HASHKEY')  "
				+

				"minus "
				+ " select  column_name,column_id from all_tab_cols where "
				+ " table_name=Upper('"
				+ this.hiTableName
				+ "')  and owner='"
				+ this.hiSchemaName
				+ "' "
				+

				" UNION ALL "
				+ " select  column_name,column_id from all_tab_cols where "
				+ " table_name=Upper('"
				+ this.hiTableName
				+ "')  and owner='"
				+ this.hiSchemaName
				+ "'  AND column_name NOT IN ('PAYORNAME','CLIENTID','EMPGRP','FILEID','ROWNUMBER','HASHKEY') "
				+

				" MINUS "
				+ " select  column_name,column_id from all_tab_cols@vhaip"
				+ " where table_name=Upper('"
				+ this.aiTableName
				+ "')  and owner='AI0"
				+ this.clientID
				+ "'  AND column_name NOT IN ('PAYORNAME','CLIENTID','EMPGRP','FILEID','ROWNUMBER','HASHKEY')  "
				+ " )";
		
		System.out.println("QUERY RUN IN HISERVER FOR DIFFERENCE BETWEEN AI FIELDS AND HI FIELDS : " + query);
		ConnectDB db = new ConnectDB();
		db.initialize(this.hiservername, this.tcpport,
				this.sid, this.hiSchemaName,"REMOTE");
		List<List<String>> rs = db.resultSetToListOfList(query);
		db.endConnection();
		if (rs != null) {
			if (rs.size() > 0) {
				int count = Integer.parseInt(rs.get(1).get(0));
				if (count > 0) {
					this.labelChangeFlag = "Y";
				} else {
					this.labelChangeFlag = "N";
				}
			} else {
				this.labelChangeFlag = "Y";
			}

		} else {
			System.out.println("HI0" + this.clientID + " " + query);
			this.labelChangeFlag = "Y";
		}

		labelChange = this.labelChangeFlag;
		return labelChange;
	}
	
	public void setHiParameters()
	{
		ConnectDB db=new ConnectDB();
		db.initialize();
		String query=" SELECT SVR_TCP_PORT,SVR_SID FROM aip_scrub_server_master WHERE SVR_NAME='"+this.hiservername+"'";
		List<List<String>> rs=db.resultSetToListOfList(query);
		db.endConnection();
		if(rs!=null)
		{
			if(rs.size()>1)
			{
				this.tcpport=rs.get(1).get(0);
				this.sid=rs.get(1).get(1);
			}
			else
			{
				this.tcpport=AIConstant.RAC_SERVICE_PORT;
				this.sid=AIConstant.RAC_SERVICE_SID;
				//	this.sid="d2he";
			}
			
		}
		}

	public String getTcpport() {
		return tcpport;
	}

	public void setTcpport(String tcpport) {
		this.tcpport = tcpport;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getServerName(String cid) {
		return AIConstant.RAC_SERVER_NAME;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getAiTableName() {
		return aiTableName;
	}

	public void setAiTableName(String aiTableName) {
		this.aiTableName = aiTableName;
	}

	public String getHiSchemaName() {
		return hiSchemaName;
	}

	public void setHiSchemaName(String hiSchemaName) {
		this.hiSchemaName = hiSchemaName;
	}

	public String getEmpGrp() {
		return empGrp;
	}

	public void setEmpGrp(String empGrp) {
		this.empGrp = empGrp;
	}

	public String getWhereCondition() {
		return whereCondition;
	}

	public void setWhereCondition(String whereCondition) {
		this.whereCondition = whereCondition;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public LegacyTransfer() {

	}

	public String getHiTableName() {
		return hiTableName;
	}

	public void setHiTableName(String hiTableName) {
		this.hiTableName = hiTableName;
	}

	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	public String getHiservername() {
		return hiservername;
	}

	public void setHiservername(String servername) {
		this.hiservername = servername;
	}

	public String getLabelChangeFlag() {
		return labelChangeFlag;
	}

	public void setLabelChangeFlag(String labelChangeFlag) {
		this.labelChangeFlag = labelChangeFlag;
	}
}
