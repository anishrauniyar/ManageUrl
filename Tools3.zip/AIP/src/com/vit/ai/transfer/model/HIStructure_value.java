/*
 *Class Name : HIStructure_value.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.model;

import java.io.Serializable;

/**
 * Model Class for Label Changer-HI Structure
 * 
 * @author Aashish Dhungana
 * 
 * @version 07 Jun 2014
 */
public class HIStructure_value implements Serializable {

	private static final long serialVersionUID = -3885309650342447206L;
	private String id;
	private String name;

	public HIStructure_value() {
	}

	public HIStructure_value(String id, String name) {
		this.setId(id);
		this.setName(name);
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
