/*
 *Class Name : LayoutType.java
 *
 *Copyright: Verisk Information Technologies
 */
package com.vit.ai.transfer.model;

import java.io.Serializable;

/**
 * @author Binesh Sah
 * 
 * @version 1.0 25 Dec 2015
 */
public class AutoTransferConf implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String clientID="";
	private String machine="";
	private String created_date="";
	private String userLog="";
	private String frequency="";
	private String monitor_start_date="";
	private String autotransfer="";
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getMachine() {
		return machine;
	}
	public void setMachine(String machine) {
		this.machine = machine;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
	public String getUserLog() {
		return userLog;
	}
	public void setUserLog(String userLog) {
		this.userLog = userLog;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getMonitor_start_date() {
		return monitor_start_date;
	}
	public void setMonitor_start_date(String monitor_start_date) {
		this.monitor_start_date = monitor_start_date;
	}
	public String getAutotransfer() {
		return autotransfer;
	}
	public void setAutotransfer(String autotransfer) {
		this.autotransfer = autotransfer;
	}
	public AutoTransferConf() {

	}
	
	public AutoTransferConf(String clientID, String machine, String created_date,
			String userlog, String frequency, String monitor_start_date, String autotransfer) {
		this.clientID=clientID;
		this.machine=machine;
		this.created_date=created_date;
		this.userLog=userlog;
		this.frequency=frequency;
		this.monitor_start_date=monitor_start_date;
		this.autotransfer=autotransfer;
		
		
	}

}
