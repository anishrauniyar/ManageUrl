/* 
 * Class Name : ConfigurationManager.java
 *
 * Copyright: Verisk Information Technologies
 */

package com.vit.resources;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Properties;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class accessing the resources from configuration properties of the system
 * 
 * @author Aashish Dhungana
 * 
 * @version 1.0 12 June 2014
 */
@ManagedBean
@RequestScoped
public class ConfigurationManager implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory
			.getLogger(ConfigurationManager.class);
	private String configFilePath = "";
	private Properties properties = new Properties();
	private String defaultServerIP = "";
	private String defaultServerName = "";
	private String defaultSchema = "";
	private String defaultPassword = "";
	private String defaultPort = "";
	private String defaultSid = "";
	private String defaultUrl = "";

	/* Function to read AIP configuration file */
	public ConfigurationManager() {
		String OS = System.getProperty("os.name").toLowerCase();
		//this.configFilePath = "/data1/AIP/datadashboard/AIP_config.properties";
		this.configFilePath = "/home/fmon/datadashboard/AIP_config.properties";

		if (OS.indexOf("win") >= 0) {
			this.configFilePath = "C:/AIP/AIP_config.properties";
		}
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(configFilePath);
			properties.load(fis);
		} catch (FileNotFoundException ex) {
			logger.error(ex.getMessage()
					+ " Configuration Manager FileNotFound");
		} catch (IOException e) {
			logger.error(e.getMessage() + " Configuration Manager IOException");
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					logger.error(e.getMessage()
							+ " Final Configuration Manager IOEx");
				}
			}
		}

	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	public String getProperty(String key, String defaultValue) {
		return properties.getProperty(key, defaultValue);
	}

	public void setProperty(String key, String value) {
		properties.setProperty(key, value);
	}

	public String getDefaultServerIP() {
		return defaultServerIP;
	}

	public void setDefaultServerIP(String defaultServerIP) {
		this.defaultServerIP = defaultServerIP;
	}

	public String getDefaultServerName() {
		return defaultServerName;
	}

	public void setDefaultServerName(String defaultServerName) {
		this.defaultServerName = defaultServerName;
	}

	public String getDefaultSchema() {
		return defaultSchema;
	}

	public void setDefaultSchema(String defaultSchema) {
		this.defaultSchema = defaultSchema;
	}

	public String getDefaultPassword() {
		return defaultPassword;
	}

	public void setDefaultPassword(String defaultPassword) {
		this.defaultPassword = defaultPassword;
	}

	public String getDefaultPort() {
		return defaultPort;
	}

	public void setDefaultPort(String defaultPort) {
		this.defaultPort = defaultPort;
	}

	public String getDefaultSid() {
		return defaultSid;
	}

	public void setDefaultSid(String defaultSid) {
		this.defaultSid = defaultSid;
	}

	public String getDefaultUrl() {
		return defaultUrl;
	}

	public void setDefaultUrl(String defaultUrl) {
		this.defaultUrl = defaultUrl;
	}

}