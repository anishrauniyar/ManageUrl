/*
 *Class Name : ConnectDB.java
 *
 *Copyright: Verisk Information Technologies
 */

package com.vit.dbconnection;

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import oracle.jdbc.OracleConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vit.ai.constant.AIConstant;
import com.vit.ai.constant.AIPasswords;
import com.vit.ai.session.ViewsParameters;

/**
 * Class Handling all the connections to oracle database
 * 
 * @author Aashish Dhungana
 * 
 * @modified by Binesh Sah
 * 
 * @modified by Anish Rauniyar
 * 
 * @version 1.0 12 May 2014
 */
@ManagedBean
@RequestScoped
public class ConnectDB implements Serializable {

	private static final long serialVersionUID = 1L;
	protected Connection conn;
	protected ResultSet rst;
	protected Statement stmt;

	private static final Logger logger = LoggerFactory
			.getLogger(ConnectDB.class);
	protected String execModule;

	private ViewsParameters sessionData;

	public ViewsParameters getSessionData() {
		return sessionData;
	}

	public void setSessionData(ViewsParameters sessionData) {
		this.sessionData = sessionData;
	}

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	/** Creates a new instance of ConnectDB */
	public ConnectDB() {

	}

	public Connection getConnection() {
		
		Context initContext;
		Connection conn = null;

		try {
			initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			DataSource ds = (DataSource) envContext.lookup("jdbc/"
					+ AIConstant.DEFAULT_SCHEMA_NAME);

			conn = ds.getConnection();

		} catch (NamingException e) {
			logger.error(e.getMessage() + " Connection Failed Naming Exception");
		} catch (SQLException e) {
			logger.error(e.getMessage() + " Connection Failed SQL Exception");
		}
		return conn;
	}

	public Connection getConnectionTestSchema() {
		AIPasswords passwordObj = new AIPasswords();
		passwordObj.init();
		String password = passwordObj.getPassword("TEMPIMPORT");
		passwordObj.close();
//jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=npaipracp1)(PORT=1521))(CONNECT_DATA=(SID=vhaip1)))
		
		String url = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
				+ AIConstant.RAC_SERVER_NAME
				+ ")(PORT="
				+ AIConstant.RAC_SERVICE_PORT
				+ "))(CONNECT_DATA=(SID="
				+ AIConstant.RAC_SERVICE_SID
				+ ")))";
		/*String url = "jdbc:oracle:thin:@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = npaipracpsca.d2hawkeye.net)(PORT = 152)) "  + 
				"(LOAD_BALANCE = YES) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = VHAIPSRV) " +
				"(FAILOVER_MODE = (TYPE = SELECT)(METHOD = BASIC)(RETRIES = 180)(DELAY = 5) )))";*/
		Connection c = null;
		try {
			Class.forName(AIConstant.ORACLE_DRIVER);
			c = DriverManager.getConnection(url, AIConstant.TEST_SCHEMA_NAME,
					password);
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage() + " Driver Class not found");
		} catch (SQLException e) {
			logger.error(e.getMessage() + " Connection Failed For Test Schema");
		}
		return c;
	}

	public Connection getConnection(String server, String tcp, String sid,
			String schema, String access) {

		String url = "";

		if (access.compareTo("REMOTE") == 0) {

			url = "jdbc:oracle:thin:@" + server + ":" + tcp + ":" + sid;
			/*url = "jdbc:oracle:thin:@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = npaipracpsca.d2hawkeye.net)(PORT = 152)) "  + 
					"(LOAD_BALANCE = YES) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = VHAIPSRV) " +
					"(FAILOVER_MODE = (TYPE = SELECT)(METHOD = BASIC)(RETRIES = 180)(DELAY = 5) )))";*/
			
		} else {

			url = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
					+ server
					+ ")(PORT="
					+ tcp
					+ "))(CONNECT_DATA=(SID="
					+ sid
					+ ")))";
			/*url = "jdbc:oracle:thin:@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = npaipracpsca.d2hawkeye.net)(PORT = 152)) "  + 
					"(LOAD_BALANCE = YES) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = VHAIPSRV) " +
					"(FAILOVER_MODE = (TYPE = SELECT)(METHOD = BASIC)(RETRIES = 180)(DELAY = 5) )))";*/
		}

		Connection c = null;
		String password="";
		
			AIPasswords passwordObj = new AIPasswords();
			passwordObj.init();
			password = passwordObj.getPassword(schema);
			passwordObj.close();
			try {
		

			Class.forName(AIConstant.ORACLE_DRIVER);
			c = DriverManager.getConnection(url, schema, password);
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage()
					+ " Driver Class not found Without Pool");
		} catch (SQLException e) {
			logger.error(e.getMessage() + " Connection Failed");
		}
		if(c==null)
		{
			System.out.println("CONNECTION NOT FOUND");
		}
		else
		{
			System.out.println("Connection Found : " + c);
		}
		return c;
	}

	public void initialize() {

		try {

			conn = getConnection();

			stmt = conn.createStatement();

		} catch (Exception e) {

			logger.error(e.getMessage() + " Initialize dashboard Connection");
		}
	}

	public void initialize(String server, String tcp, String sid,
			String schema, String access) {
		try {
			conn = getConnection(server, tcp, sid, schema, access);

			stmt = conn.createStatement();

			String[] metrics = new String[OracleConnection.END_TO_END_STATE_INDEX_MAX];
			metrics[OracleConnection.END_TO_END_CLIENTID_INDEX] = "CLIENT_ID";
			((OracleConnection) conn).setEndToEndMetrics(metrics, (short) 0);

		} catch (Exception e) {

			System.out
					.println("ERROR IS HERE : " + server + tcp + sid + schema);
			logger.error(e.getMessage() + " Initialize dashboard Connection ");

		}
	}

	public void initializeTestSchema() {
		try {
			conn = getConnectionTestSchema();
			stmt = conn.createStatement();
		} catch (Exception e) {
			logger.error(e.getMessage() + " Initialize test schema Connection ");
		}
	}

	public List<List<String>> resultSetToListOfList(String sql) {
		try {
			Statement stm = this.conn.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			int numberOfColumns = metaData.getColumnCount();
			List<String> columnNames = new ArrayList<String>(numberOfColumns);
			// Get the column names
			for (int column = 0; column < numberOfColumns; column++) {
				columnNames.add(metaData.getColumnLabel(column + 1));
			}
			// Get all rows, but first make the first row the column names
			List<List<String>> rows = new ArrayList<List<String>>();
			rows.add(columnNames);
			while (rs.next()) {
				List<String> newRow = new ArrayList<String>(numberOfColumns);
				for (int i = 1; i <= numberOfColumns; i++) {
					if (rs.getObject(i) != null && rs.getObject(i) != "") {
						newRow.add(rs.getObject(i).toString());
					} else {
						newRow.add("");
					}
				}
				rows.add(newRow);
			}
			if (rs != null || !rs.isClosed()) {
				rs.close();
			}
			stm.close();
			return rows;

		} catch (Exception e) {
			logger.error(e.getMessage() + " Result Set To List OF List " + sql);
			return null;
		}
	}

	public Clob resultSetToClob(String sqlQuery) throws SQLException {
		System.out.println("This is a clob value: " + sqlQuery);
		Statement stm = this.conn.createStatement();
		ResultSet rs = stm.executeQuery(sqlQuery);
		Clob value = null;
		try {
			while (rs.next()) {
				value = rs.getClob("DEF");
			}
		} catch (SQLException e) {
			System.out.println("This is a error: " + e.getMessage());
		}
		System.out.println("the value is: " + value.length() + ": " + value.getSubString(value.getSubString(1, (int) value.length()).indexOf(" AS ") + 4, (int) value.length()));
		return value;
	}
	
	
	public void endConnection() {
		try {
			if (rst != null) {
				rst.close();
			}
			if (conn != null) {
				conn.close();
			}
			if (stmt != null) {
				stmt.close();
			}
		} catch (Exception e) {
			logger.error(e.getMessage() + " EndConnection");
		}
	}

	public String executeDML(String Query) {
		if (Query != null && Query != "") {
			try {
				PreparedStatement pstatement = null;
				pstatement = conn.prepareStatement(Query);
				pstatement.executeUpdate();
				pstatement.close();
				return "1";
			} catch (Exception e) {
				logger.error(e.getMessage() + " " + Query + " "
						+ " executeDML Query");
				return e.getMessage();
			}
		} else {
			return "Empty Query";
		}
	}

	public int update(String Query) {
		int rowsAffected = 0;
		if (Query != null && Query != "") {
			try {
				PreparedStatement pstatement = null;
				pstatement = conn.prepareStatement(Query);
				pstatement.executeUpdate();
				rowsAffected = pstatement.getUpdateCount();
				pstatement.close();
			} catch (Exception e) {
				logger.error(e.getMessage() + " " + Query + " "
						+ " Update Query");
				rowsAffected = -1;
			}
		} else {
			rowsAffected = -1;
		}
		return rowsAffected;

	}

	public void dropTable(String layoutID, String subLayoutID) {
		this.executeDML("DROP TABLE ZZZ_" + layoutID + "_" + subLayoutID
				+ " PURGE");
	}

	public String createTable(String layoutID, String subLayoutID,String tableQuery) {
		/*String tableQuery = "CREATE TABLE ZZZ_" + layoutID + "_" + subLayoutID
				+ "(";

		String query = "  SELECT COLUMNNAME||' '||DATATYPE||CASE WHEN Upper(DATATYPE)='NUMBER' THEN '(19,4)' "
				+ "     WHEN Upper(DATATYPE)='DATE' THEN '' "
				+ "     ELSE  '('||FIELDLENGTH||')' "
				+ "     END||',' "
				+ "     FROM IMP_LAYOUTS_FIELDS  "
				+ "     WHERE LAYOUTID='"
				+ layoutID
				+ "' AND SUBLAYOUTID='"
				+ subLayoutID
				+ "' "
				+ "     ORDER BY COLUMNID  ";

		List<List<String>> fieldList = this.resultSetToListOfList(query);

		if (fieldList.size() > 0) {
			for (int i = 1; i < fieldList.size(); i++) {
				tableQuery = tableQuery + fieldList.get(i).get(0);
			}
			tableQuery = tableQuery.substring(0, tableQuery.length() - 1);
		}
		tableQuery += ") NOLOGGING";*/
		this.executeDML("DROP TABLE ZZZ_" + layoutID + "_" + subLayoutID
				+ " PURGE");
		String to_ret = this.executeDML(tableQuery);
		return to_ret;
	}

	public String getHostName() {
		String hostName = "";
		try {
			InetAddress addr;
			addr = InetAddress.getLocalHost();
			hostName = addr.getHostName();
			return hostName;
		} catch (UnknownHostException ex) {
			return "Unknown";
		}

	}

	public Object getSessionBean(String sessionBeanName) {
		return FacesContext
				.getCurrentInstance()
				.getApplication()
				.getELResolver()
				.getValue(FacesContext.getCurrentInstance().getELContext(),
						null, sessionBeanName);
	}

	public String[][] getAllRows(String query) {
		ResultSet rs = null;
		ResultSet rs1 = null;
		Statement stmt = null;
		ArrayList<String> list = new ArrayList<String>();
		try {
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rs1 = stmt.executeQuery("SELECT COUNT(*) AS CNT FROM ( " + query
					+ " )");
			int rowCount = 0;
			while (rs1.next()) {
				rowCount = rs1.getInt(1);
			}

			rs = stmt.executeQuery(query);
			ResultSetMetaData metaData = null;
			metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();

			String[][] rulesTableVals = new String[columnCount][rowCount];

			for (int i = 1; i <= columnCount; i++) {
				while (rs.next()) {
					list.add(rs.getString(i));
				}

				// copy the contents of dynamic array list into static string
				// array.
				for (int j = 0; j < rowCount; j++) {
					rulesTableVals[i - 1][j] = (String) list.get(j);
				}
				list.clear();
				rs.beforeFirst();
			}
			rs1.close();
			rs.close();
			// conn.close();
			stmt.close();
			return rulesTableVals;

		} catch (SQLException sqlex) {
			logger.error(sqlex.getMessage() + " sqlex getAllRows ConnectDB "
					+ query);
			return null;
		} catch (Exception ex) {
			logger.error(ex.getMessage() + " getAllRows ConnectDB " + query);
			return null;
		}
	}

	public String getPreScrubServerName(String clientID) {
		String query = "SELECT PRESCRUB_SERVER FROM OAM_CLIENTAPPS@HAWKEYEOAM WHERE CLIENTID='"
				+ clientID + "' GROUP BY PRESCRUB_SERVER";
		List<List<String>> serverList = this.resultSetToListOfList(query);
		String server = "";
		if (serverList.size() > 1) {
			server = serverList.get(1).get(0);
		}
		return server;
	}

	public String getSchemaName(String clientID) {
		String query = "SELECT HISCHEMANAME FROM HI_LEGACY_TRANSFER WHERE CLIENTID='"
				+ clientID + "' GROUP BY HISCHEMANAME";
		List<List<String>> schemaList = this.resultSetToListOfList(query);
		String schema = "HI0" + clientID + "001_T";
		if (schemaList.size() > 1) {
			schema = schemaList.get(1).get(0);
		}
		return schema;
	}

	public Connection getConnectionFromSchema(String Schema) {
		// String url = "jdbc:oracle:thin:@//<" + AIConstant.RAC_SERVER_NAME +
		// ">:"
		// + AIConstant.RAC_SERVICE_PORT + ":" + AIConstant.RAC_SERVICE_SID;
		String url = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST="
				+ AIConstant.RAC_SERVER_NAME
				+ ")(PORT="
				+ AIConstant.RAC_SERVICE_PORT
				+ "))(CONNECT_DATA=(SID="
				+ AIConstant.RAC_SERVICE_SID
				+ ")))";
		/*String url = "jdbc:oracle:thin:@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = npaipracpsca.d2hawkeye.net)(PORT = 152)) "  + 
					"(LOAD_BALANCE = YES) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = VHAIPSRV) " +
					"(FAILOVER_MODE = (TYPE = SELECT)(METHOD = BASIC)(RETRIES = 180)(DELAY = 5) )))";*/
		AIPasswords passwordObj = new AIPasswords();
		passwordObj.init();
		String password = passwordObj.getPassword(Schema);
		passwordObj.close();
		Connection c = null;
		try {
			Class.forName(AIConstant.ORACLE_DRIVER);
			c = DriverManager.getConnection(url, Schema, password);
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage()
					+ " Driver Class not found Without Pool");

		} catch (SQLException e) {
			logger.error(e.getMessage() + " Connection Failed Without Pool");
		}
		return c;

	}
	
	public void initializeBulk()
	{
		initialize(AIConstant.RAC_SERVER_NAME, AIConstant.RAC_SERVICE_PORT,AIConstant.RAC_SERVICE_SID, "BULKFM", "local");
	}

}
